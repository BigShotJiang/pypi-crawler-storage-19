// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

/**
 * @file rosetta_functions.cpp
 * @brief DuckDB SQL functions for Rosetta
 *
 * Provides SQL functions for reading files through Rosetta:
 *   - rosetta_read(path) - Read any supported format
 *   - rosetta_detect_format(path) - Detect file format
 *   - rosetta_version() - Get Rosetta version
 */

#include "duckdb.hpp"
#include "duckdb/main/extension_util.hpp"
#include "duckdb/parser/parsed_data/create_scalar_function_info.hpp"
#include "duckdb/parser/parsed_data/create_table_function_info.hpp"
#include "duckdb/function/table_function.hpp"
#include "duckdb/common/types.hpp"

extern "C" {
#include "rosetta.h"
}

#include <cstring>

namespace rosetta {

using namespace duckdb;

// =============================================================================
// rosetta_version() - Scalar function returning version string
// =============================================================================

static void RosettaVersionFunction(DataChunk &args, ExpressionState &state, Vector &result) {
    const char* version = ::rosetta_version();
    result.SetValue(0, Value(version));
}

// =============================================================================
// rosetta_detect_format(path) - Detect file format
// =============================================================================

static void RosettaDetectFormatFunction(DataChunk &args, ExpressionState &state, Vector &result) {
    auto &path_vector = args.data[0];
    auto count = args.size();

    UnaryExecutor::Execute<string_t, string_t>(path_vector, result, count,
        [&](string_t path) {
            std::string path_str = path.GetString();
            RosettaFormat format = rosetta_detect_format(path_str.c_str());

            const char* format_name;
            switch (format) {
                case ROSETTA_FORMAT_PARQUET_V1: format_name = "parquet_v1"; break;
                case ROSETTA_FORMAT_PARQUET_V2: format_name = "parquet_v2"; break;
                case ROSETTA_FORMAT_VORTEX: format_name = "vortex"; break;
                case ROSETTA_FORMAT_LANCE: format_name = "lance"; break;
                case ROSETTA_FORMAT_F3: format_name = "f3"; break;
                case ROSETTA_FORMAT_FASTLANES: format_name = "fastlanes"; break;
                default: format_name = "unknown"; break;
            }

            return StringVector::AddString(result, format_name);
        });
}

// =============================================================================
// rosetta_read(path) - Table function for reading files
// =============================================================================

struct RosettaReadBindData : public TableFunctionData {
    string file_path;
    bool finished = false;
};

struct RosettaReadGlobalState : public GlobalTableFunctionState {
    uint8_t* data = nullptr;
    size_t data_len = 0;
    bool consumed = false;

    ~RosettaReadGlobalState() {
        if (data) {
            rosetta_bytes_free(data, data_len);
            data = nullptr;
        }
    }

    idx_t MaxThreads() const override {
        return 1;
    }
};

static unique_ptr<FunctionData> RosettaReadBind(ClientContext &context,
                                                  TableFunctionBindInput &input,
                                                  vector<LogicalType> &return_types,
                                                  vector<string> &names) {
    auto result = make_uniq<RosettaReadBindData>();

    if (input.inputs.empty()) {
        throw BinderException("rosetta_read requires a file path argument");
    }

    result->file_path = input.inputs[0].GetValue<string>();

    // Get schema from file
    RosettaStringResult schema_result = rosetta_get_schema_json(result->file_path.c_str());

    if (schema_result.error_message) {
        string error_msg = schema_result.error_message;
        rosetta_string_free(schema_result.error_message);
        throw BinderException("Failed to read schema: " + error_msg);
    }

    // Parse the JSON schema
    // For now, return a simple schema that Parquet will provide
    // In production, we'd parse the actual Arrow schema JSON

    if (schema_result.value) {
        // Parse Arrow schema JSON to determine columns
        // Simplified: we'll rely on DuckDB's Parquet reader to determine schema
        rosetta_string_free(schema_result.value);
    }

    // Return parquet data type - DuckDB will parse the Parquet bytes
    // This is a "passthrough" where we return raw bytes that DuckDB's
    // Parquet reader will handle
    return_types.push_back(LogicalType::BLOB);
    names.push_back("parquet_data");

    return std::move(result);
}

static unique_ptr<GlobalTableFunctionState> RosettaReadInit(ClientContext &context,
                                                             TableFunctionInitInput &input) {
    return make_uniq<RosettaReadGlobalState>();
}

static void RosettaReadFunction(ClientContext &context, TableFunctionInput &data,
                                 DataChunk &output) {
    auto &bind_data = data.bind_data->Cast<RosettaReadBindData>();
    auto &state = data.global_state->Cast<RosettaReadGlobalState>();

    if (state.consumed) {
        return;
    }

    // Read and transcode the file
    auto* fileio = rosetta_fileio_new();
    if (!fileio) {
        throw IOException("Failed to initialize Rosetta FileIO");
    }

    RosettaBytesResult result = rosetta_fileio_read(fileio, bind_data.file_path.c_str());
    rosetta_fileio_free(fileio);

    if (result.error_message) {
        string error_msg = result.error_message;
        rosetta_string_free(result.error_message);
        throw IOException("Rosetta read error: " + error_msg);
    }

    // Store data for cleanup
    state.data = result.data;
    state.data_len = result.len;
    state.consumed = true;

    // Return the Parquet bytes as a blob
    output.SetCardinality(1);
    auto &blob_vector = output.data[0];
    blob_vector.SetValue(0, Value::BLOB(result.data, result.len));
}

// =============================================================================
// rosetta_read_parquet(path) - Table function using Parquet reader
// =============================================================================

// This is a more complete implementation that actually returns table data
// by using DuckDB's built-in Parquet functionality on the transcoded bytes

struct RosettaReadParquetBindData : public TableFunctionData {
    string file_path;
    vector<LogicalType> types;
    vector<string> names;
};

static unique_ptr<FunctionData> RosettaReadParquetBind(ClientContext &context,
                                                        TableFunctionBindInput &input,
                                                        vector<LogicalType> &return_types,
                                                        vector<string> &names) {
    auto result = make_uniq<RosettaReadParquetBindData>();

    if (input.inputs.empty()) {
        throw BinderException("rosetta_read_parquet requires a file path argument");
    }

    result->file_path = input.inputs[0].GetValue<string>();

    // For the prototype, we return a simple representation
    // In production, this would introspect the actual schema

    // Get schema from Rosetta
    RosettaStringResult schema_result = rosetta_get_schema_json(result->file_path.c_str());

    if (schema_result.error_message) {
        string error_msg = schema_result.error_message;
        rosetta_string_free(schema_result.error_message);
        throw BinderException("Failed to read schema: " + error_msg);
    }

    // Parse schema JSON (simplified for prototype)
    // A full implementation would parse the Arrow schema JSON
    if (schema_result.value) {
        rosetta_string_free(schema_result.value);
    }

    // Default: return as if it's a simple table with blob column
    // Real implementation would parse schema and create proper columns
    return_types.push_back(LogicalType::VARCHAR);
    names.push_back("_rosetta_placeholder");

    return std::move(result);
}

// =============================================================================
// Register all functions
// =============================================================================

void RegisterRosettaFunctions(DatabaseInstance& db) {
    // rosetta_version() -> VARCHAR
    {
        ScalarFunction version_func("rosetta_version", {}, LogicalType::VARCHAR,
                                     RosettaVersionFunction);
        ExtensionUtil::RegisterFunction(db, version_func);
    }

    // rosetta_detect_format(path) -> VARCHAR
    {
        ScalarFunction detect_func("rosetta_detect_format",
                                    {LogicalType::VARCHAR},
                                    LogicalType::VARCHAR,
                                    RosettaDetectFormatFunction);
        ExtensionUtil::RegisterFunction(db, detect_func);
    }

    // rosetta_read(path) -> TABLE
    // Note: For the prototype, this returns raw Parquet bytes
    // A production version would integrate with DuckDB's Parquet reader
    {
        TableFunction read_func("rosetta_read", {LogicalType::VARCHAR},
                                RosettaReadFunction, RosettaReadBind, RosettaReadInit);
        ExtensionUtil::RegisterFunction(db, read_func);
    }
}

} // namespace rosetta
