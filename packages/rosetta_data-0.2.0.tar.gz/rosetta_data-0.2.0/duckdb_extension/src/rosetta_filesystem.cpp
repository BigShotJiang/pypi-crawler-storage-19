// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

/**
 * @file rosetta_filesystem.cpp
 * @brief DuckDB custom filesystem for Rosetta
 *
 * Implements a virtual filesystem that intercepts reads to rosetta:// URLs
 * and transcodes the underlying file to Parquet bytes.
 */

#include "duckdb.hpp"
#include "duckdb/common/file_system.hpp"
#include "duckdb/main/database.hpp"

extern "C" {
#include "rosetta.h"
}

#include <cstring>
#include <memory>
#include <mutex>

namespace rosetta {

using namespace duckdb;

// Global FileIO handle (thread-safe, singleton pattern)
static std::once_flag fileio_init_flag;
static RosettaFileIOHandle* g_fileio = nullptr;

static RosettaFileIOHandle* GetFileIO() {
    std::call_once(fileio_init_flag, []() {
        g_fileio = rosetta_fileio_new();
    });
    return g_fileio;
}

/**
 * File handle wrapper for Rosetta-transcoded files
 */
class RosettaFileHandle : public FileHandle {
public:
    RosettaFileHandle(FileSystem &fs, const string &path, uint8_t* data, size_t len)
        : FileHandle(fs, path), data_(data), len_(len), pos_(0) {
    }

    ~RosettaFileHandle() override {
        if (data_) {
            rosetta_bytes_free(data_, len_);
            data_ = nullptr;
        }
    }

    void Close() override {
        // Data freed in destructor
    }

    // Read interface
    int64_t Read(void *buffer, idx_t nr_bytes) {
        if (pos_ >= len_) {
            return 0;
        }
        size_t to_read = std::min(static_cast<size_t>(nr_bytes), len_ - pos_);
        memcpy(buffer, data_ + pos_, to_read);
        pos_ += to_read;
        return static_cast<int64_t>(to_read);
    }

    // Seek interface
    void Seek(idx_t position) {
        pos_ = std::min(static_cast<size_t>(position), len_);
    }

    idx_t SeekPosition() {
        return static_cast<idx_t>(pos_);
    }

    idx_t GetFileSize() {
        return static_cast<idx_t>(len_);
    }

    bool CanSeek() {
        return true;
    }

    bool OnDiskFile() {
        return false; // This is a virtual file
    }

private:
    uint8_t* data_;
    size_t len_;
    size_t pos_;
};

/**
 * Rosetta virtual filesystem for DuckDB
 */
class RosettaFileSystem : public FileSystem {
public:
    // Filesystem name for registration
    std::string GetName() const override {
        return "RosettaFileSystem";
    }

    // Check if this filesystem can handle the path
    bool CanHandleFile(const string &path) override {
        // Handle rosetta:// scheme
        if (path.rfind("rosetta://", 0) == 0) {
            return true;
        }
        // Also handle files with supported extensions
        return ShouldTranscode(path);
    }

    // Open a file for reading
    unique_ptr<FileHandle> OpenFile(const string &path, FileOpenFlags flags,
                                     optional_ptr<FileOpener> opener = nullptr) override {
        // Only support reading
        if (flags.OpenForWriting()) {
            throw IOException("Rosetta filesystem is read-only");
        }

        auto* fileio = GetFileIO();
        if (!fileio) {
            throw IOException("Failed to initialize Rosetta FileIO");
        }

        // Strip rosetta:// prefix if present
        string actual_path = path;
        if (path.rfind("rosetta://", 0) == 0) {
            actual_path = path.substr(10); // len("rosetta://")
        }

        // Read and transcode the file
        RosettaBytesResult result = rosetta_fileio_read(fileio, actual_path.c_str());

        if (result.error_message) {
            string error_msg = result.error_message;
            rosetta_string_free(result.error_message);
            throw IOException("Rosetta read error: " + error_msg);
        }

        return make_uniq<RosettaFileHandle>(*this, path, result.data, result.len);
    }

    // Read from file handle
    int64_t Read(FileHandle &handle, void *buffer, int64_t nr_bytes) override {
        auto& rh = dynamic_cast<RosettaFileHandle&>(handle);
        return rh.Read(buffer, static_cast<idx_t>(nr_bytes));
    }

    // Seek in file
    void Seek(FileHandle &handle, idx_t location) override {
        auto& rh = dynamic_cast<RosettaFileHandle&>(handle);
        rh.Seek(location);
    }

    // Get current position
    idx_t SeekPosition(FileHandle &handle) override {
        auto& rh = dynamic_cast<RosettaFileHandle&>(handle);
        return rh.SeekPosition();
    }

    // Get file size
    int64_t GetFileSize(FileHandle &handle) override {
        auto& rh = dynamic_cast<RosettaFileHandle&>(handle);
        return static_cast<int64_t>(rh.GetFileSize());
    }

    // Check if file exists
    bool FileExists(const string &filename, optional_ptr<FileOpener> opener = nullptr) override {
        auto* fileio = GetFileIO();
        if (!fileio) {
            return false;
        }

        string actual_path = filename;
        if (filename.rfind("rosetta://", 0) == 0) {
            actual_path = filename.substr(10);
        }

        RosettaBoolResult result = rosetta_fileio_exists(fileio, actual_path.c_str());

        if (result.error_message) {
            rosetta_string_free(result.error_message);
            return false;
        }

        return result.value;
    }

    // Not supported operations (read-only filesystem)
    void Write(FileHandle &handle, void *buffer, int64_t nr_bytes, idx_t location) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    int64_t Write(FileHandle &handle, void *buffer, int64_t nr_bytes) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    void Truncate(FileHandle &handle, int64_t new_size) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    void RemoveFile(const string &filename, optional_ptr<FileOpener> opener = nullptr) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    void CreateDirectory(const string &directory, optional_ptr<FileOpener> opener = nullptr) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    void RemoveDirectory(const string &directory, optional_ptr<FileOpener> opener = nullptr) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    void MoveFile(const string &source, const string &target, optional_ptr<FileOpener> opener = nullptr) override {
        throw IOException("Rosetta filesystem is read-only");
    }

    bool DirectoryExists(const string &directory, optional_ptr<FileOpener> opener = nullptr) override {
        return false;
    }

    bool ListFiles(const string &directory, const std::function<void(const string &, bool)> &callback,
                   FileOpener *opener = nullptr) override {
        return false;
    }

    time_t GetLastModifiedTime(FileHandle &handle) override {
        return 0;
    }

    FileType GetFileType(FileHandle &handle) override {
        return FileType::FILE_TYPE_REGULAR;
    }

    bool CanSeek() override {
        return true;
    }

    bool OnDiskFile(FileHandle &handle) override {
        return false;
    }

    bool IsPipe(const string &filename, optional_ptr<FileOpener> opener = nullptr) override {
        return false;
    }

private:
    bool ShouldTranscode(const string &path) {
        // Check file extension
        auto dot_pos = path.rfind('.');
        if (dot_pos == string::npos) {
            return false;
        }

        string ext = path.substr(dot_pos + 1);
        // Convert to lowercase
        for (char &c : ext) {
            c = std::tolower(c);
        }

        return ext == "vortex" || ext == "lance" || ext == "f3";
    }
};

/**
 * Register the Rosetta filesystem with DuckDB
 */
void RegisterRosettaFileSystem(DatabaseInstance& db) {
    auto& fs = db.GetFileSystem();
    fs.RegisterSubSystem(make_uniq<RosettaFileSystem>());
}

} // namespace rosetta
