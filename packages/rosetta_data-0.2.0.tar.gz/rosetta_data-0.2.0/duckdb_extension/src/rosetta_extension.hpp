// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

/**
 * @file rosetta_extension.hpp
 * @brief DuckDB extension class declaration for Rosetta
 */

#pragma once

#include "duckdb.hpp"

namespace duckdb {

/**
 * Rosetta extension for DuckDB
 *
 * Enables transparent reading of any columnar format:
 *   - Vortex (.vortex)
 *   - Lance (.lance)
 *   - F3 (.f3)
 *   - And more...
 *
 * Usage:
 *   LOAD rosetta;
 *   SELECT * FROM read_parquet('rosetta://data.vortex');
 *   SELECT * FROM rosetta_read('data.lance');
 *   SELECT rosetta_detect_format('data.vortex');
 */
class RosettaExtension : public Extension {
public:
    void Load(DuckDB &db) override;
    std::string Name() override;
    std::string Version() const override;
};

} // namespace duckdb

// Forward declarations for internal functions
namespace rosetta {
    void RegisterRosettaFileSystem(duckdb::DatabaseInstance& db);
    void RegisterRosettaFunctions(duckdb::DatabaseInstance& db);
}
