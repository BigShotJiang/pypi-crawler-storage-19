# Rosetta DuckDB Extension

Native DuckDB extension for reading any columnar format through Rosetta.

## Features

- **Transparent format support**: Read Vortex, Lance, F3 files as if they were Parquet
- **Custom filesystem**: `rosetta://` URL scheme for explicit transcoding
- **SQL functions**: `rosetta_read()`, `rosetta_detect_format()`, `rosetta_version()`
- **Zero-copy when possible**: Efficient memory handling via Rust FFI

## Building

### Prerequisites

1. Build the Rosetta Rust library first:
```bash
cd ..
cargo build --release --features vortex-reader,lance-reader
```

2. Install CMake (>= 3.21)

### Build the Extension

```bash
mkdir build && cd build
cmake .. -DROSETTA_LIB_DIR=../../target/release -DROSETTA_INCLUDE_DIR=../../include
make
```

This produces `rosetta.duckdb_extension`.

### With DuckDB Source

If you have DuckDB source:
```bash
cmake .. -DDUCKDB_DIR=/path/to/duckdb
make
```

## Usage

### Load the Extension

```sql
-- Load from file
LOAD '/path/to/rosetta.duckdb_extension';

-- Or if installed
LOAD rosetta;
```

### Read Files

```sql
-- Using rosetta:// scheme (explicit transcoding)
SELECT * FROM read_parquet('rosetta://data.vortex');

-- Using rosetta_read function
SELECT * FROM rosetta_read('data.lance');

-- Detect format
SELECT rosetta_detect_format('data.vortex');  -- Returns 'vortex'

-- Check version
SELECT rosetta_version();
```

### Automatic Format Detection

Files with `.vortex`, `.lance`, or `.f3` extensions are automatically transcoded:

```sql
-- These all work!
SELECT * FROM read_parquet('rosetta://analytics.vortex');
SELECT * FROM read_parquet('rosetta://ml_embeddings.lance');
```

## Architecture

```
┌─────────────────────────────────────────┐
│           DuckDB Query                   │
│   SELECT * FROM read_parquet(...)        │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│       Rosetta FileSystem                 │
│   Intercepts rosetta:// or .vortex etc  │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│       Rosetta Rust Core (FFI)            │
│   Format detection + transcoding         │
└─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────┐
│       Parquet v1 Bytes                   │
│   Compatible with any Parquet reader     │
└─────────────────────────────────────────┘
```

## SQL Functions

| Function | Description |
|----------|-------------|
| `rosetta_version()` | Returns Rosetta library version |
| `rosetta_detect_format(path)` | Detects file format (parquet_v1, vortex, lance, etc.) |
| `rosetta_read(path)` | Reads file and returns transcoded data |

## Performance

The extension uses Rosetta's caching layer to avoid re-transcoding:
- First read: Full transcoding (milliseconds for small files)
- Subsequent reads: Cache hit (microseconds)

For large files, consider pre-transcoding to Parquet for production workloads.

## Limitations

- **Read-only**: Cannot write to Vortex/Lance through this extension
- **Single-threaded transcoding**: Transcoding happens on one thread
- **Memory**: Entire file is loaded into memory during transcoding

## Development

### Running Tests

```bash
# Build with tests
cmake .. -DBUILD_TESTING=ON
make
ctest
```

### Debugging

```bash
# Build with debug symbols
cmake .. -DCMAKE_BUILD_TYPE=Debug
make
```

## License

Apache 2.0 - See [LICENSE](../LICENSE)
