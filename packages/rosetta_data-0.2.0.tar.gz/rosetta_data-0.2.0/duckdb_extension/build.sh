#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Build script for Rosetta DuckDB extension

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROSETTA_ROOT="$(dirname "$SCRIPT_DIR")"

echo "=== Building Rosetta DuckDB Extension ==="

# Step 1: Build Rosetta Rust library
echo "Step 1: Building Rosetta Rust library..."
cd "$ROSETTA_ROOT"

# Check if we need nightly for vortex
if cargo +nightly --version &>/dev/null; then
    CARGO_CMD="cargo +nightly"
else
    CARGO_CMD="cargo"
fi

$CARGO_CMD build --release --features vortex-reader,lance-reader

# Check library was built
if [[ -f "$ROSETTA_ROOT/target/release/librosetta.a" ]] || \
   [[ -f "$ROSETTA_ROOT/target/release/librosetta.dylib" ]] || \
   [[ -f "$ROSETTA_ROOT/target/release/librosetta.so" ]]; then
    echo "  ✓ Rosetta library built"
else
    echo "  ✗ Failed to build Rosetta library"
    exit 1
fi

# Step 2: Build C++ extension
echo "Step 2: Building DuckDB extension..."
cd "$SCRIPT_DIR"

mkdir -p build
cd build

cmake .. \
    -DROSETTA_LIB_DIR="$ROSETTA_ROOT/target/release" \
    -DROSETTA_INCLUDE_DIR="$ROSETTA_ROOT/include" \
    -DCMAKE_BUILD_TYPE=Release

make -j$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)

# Check extension was built
EXTENSION_FILE=""
for ext in "rosetta.duckdb_extension" "librosetta.duckdb_extension"; do
    if [[ -f "$ext" ]]; then
        EXTENSION_FILE="$ext"
        break
    fi
done

if [[ -n "$EXTENSION_FILE" ]]; then
    echo "  ✓ DuckDB extension built: $EXTENSION_FILE"
    echo ""
    echo "=== Build Complete ==="
    echo ""
    echo "To use in DuckDB:"
    echo "  LOAD '$SCRIPT_DIR/build/$EXTENSION_FILE';"
    echo "  SELECT rosetta_version();"
    echo "  SELECT * FROM read_parquet('rosetta://your_file.vortex');"
else
    echo "  ✗ Extension not found"
    exit 1
fi
