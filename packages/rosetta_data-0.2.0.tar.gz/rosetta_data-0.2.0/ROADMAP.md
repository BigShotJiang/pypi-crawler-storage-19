# Rosetta Roadmap: Path to Demo & Acquisition

## Current State (January 2026)

### Completed
- [x] Core readers: Parquet (v1/v2), Vortex, Lance
- [x] F3/WASM runtime for self-describing files
- [x] Format detection (magic bytes + directory structure)
- [x] Transcoder (any format → Parquet)
- [x] DuckDB extension
- [x] Iceberg FileIO integration
- [x] FUSE filesystem
- [x] S3 proxy
- [x] Python bindings (scaffolded)
- [x] Performance optimized (~0% overhead for Parquet passthrough)
- [x] 109 tests passing

### Performance Benchmarks
```
Parquet Passthrough (100K rows):
├── Native:        2.84 ms (413 MiB/s)
├── Rosetta Sync:  2.54 ms (461 MiB/s)  ~0% overhead ✅
└── Rosetta Async: 3.14 ms (373 MiB/s)  ~11% overhead

Format Detection: ~150 µs per file
```

---

## Phase 1: Polish for Demo (Days 1-2)

**Goal:** Create something impressive to show potential users/partners

### 1.1 Complete Python Bindings
- [ ] Build PyO3 bindings with maturin
- [ ] Test all Python APIs work correctly
- [ ] Add type stubs for IDE support
- [ ] Create Python examples

**Files:** `python/`, `src/python.rs`

### 1.2 Polish CLI
- [ ] Add `rosetta read <file>` - read any format, output stats
- [ ] Add `rosetta convert <input> <output>` - convert between formats
- [ ] Add `rosetta detect <file>` - show detected format
- [ ] Add `rosetta info <file>` - show schema, row counts, metadata
- [ ] Add `rosetta bench <file>` - quick performance test

**Files:** `src/main.rs`

### 1.3 Documentation
- [ ] Write comprehensive README.md
- [ ] Add usage examples for each integration
- [ ] Document performance characteristics
- [ ] Add architecture diagram

**Files:** `README.md`, `docs/`

### 1.4 Demo Script
Create `demo.sh` showing:
```bash
# 1. Read Vortex file through standard Parquet API
rosetta read data.vortex

# 2. Use in DuckDB transparently
duckdb -c "SELECT * FROM 'data.vortex' LIMIT 10"

# 3. Mount as FUSE filesystem
rosetta mount ./source ./mount
cat ./mount/data.vortex  # Returns Parquet bytes!

# 4. Python usage
python -c "import rosetta; print(rosetta.read('data.vortex'))"
```

### Deliverables
- Working Python package installable via `pip install`
- CLI with useful commands
- README that sells the value proposition
- 5-minute demo script

---

## Phase 2: Progressive Upgrade (Days 3-6)

**Goal:** Build the key differentiator - upgrade files without full migration

### 2.1 Column-Level Upgrade API
```rust
pub struct UpgradeOptions {
    /// Columns to upgrade (None = all)
    columns: Option<Vec<String>>,
    /// Target encoding for upgraded columns
    target_encoding: TargetEncoding,
    /// Keep original file as backup
    backup: bool,
    /// Preserve partitioning structure
    preserve_partitioning: bool,
}

pub enum TargetEncoding {
    /// Use Vortex encodings (FastLanes, ALP, etc.)
    Vortex,
    /// Use Parquet v2 encodings (DELTA_BINARY_PACKED, etc.)
    ParquetV2,
    /// Auto-select based on column statistics
    Auto,
}

impl Transcoder {
    /// Upgrade specific columns in a Parquet file
    pub async fn upgrade_columns(
        &self,
        input: &Path,
        output: &Path,
        options: UpgradeOptions,
    ) -> Result<UpgradeReport>;
}
```

**Files:** `src/transcoder.rs`, `src/upgrade.rs` (new)

### 2.2 Encoding Selection Logic
```rust
fn select_encoding(column: &Column, stats: &ColumnStats) -> Encoding {
    match column.data_type() {
        // Sequential integers → Delta encoding
        DataType::Int64 if stats.is_monotonic() =>
            Encoding::DeltaBinaryPacked,

        // Low cardinality strings → Dictionary + FSST
        DataType::Utf8 if stats.cardinality < 10_000 =>
            Encoding::DictionaryFSST,

        // Floats with patterns → Byte stream split
        DataType::Float64 if stats.has_repeated_patterns() =>
            Encoding::ByteStreamSplit,

        // Embeddings → Keep as-is or use Vortex
        DataType::FixedSizeBinary(n) if *n >= 256 =>
            Encoding::Vortex,

        // Default: safe Parquet v1
        _ => Encoding::PlainV1,
    }
}
```

**Files:** `src/encoding.rs` (new)

### 2.3 CLI Integration
```bash
# Upgrade specific columns
rosetta upgrade data.parquet \
  --columns embedding,feature_vector \
  --encoding vortex \
  --output data_upgraded.parquet

# Upgrade entire directory
rosetta upgrade s3://bucket/warehouse/ \
  --columns embedding \
  --encoding auto \
  --recursive \
  --dry-run  # Show what would change

# Report on potential improvements
rosetta analyze data.parquet
# Output:
# Column 'id': Sequential integers, could save 70% with delta encoding
# Column 'name': 500 unique values, could save 40% with dictionary
# Column 'embedding': 1536-dim vectors, could save 20% with Vortex
```

### 2.4 Upgrade Report
```rust
pub struct UpgradeReport {
    pub input_size: u64,
    pub output_size: u64,
    pub compression_ratio: f64,
    pub columns_upgraded: Vec<ColumnUpgrade>,
    pub duration: Duration,
}

pub struct ColumnUpgrade {
    pub name: String,
    pub original_encoding: String,
    pub new_encoding: String,
    pub original_size: u64,
    pub new_size: u64,
    pub savings_percent: f64,
}
```

### Deliverables
- `rosetta upgrade` command
- `rosetta analyze` command
- Column-level encoding selection
- Upgrade reports with savings estimates

---

## Phase 3: TPC-H Validation (Days 7-9)

**Goal:** Credible benchmarks that acquirers trust

### 3.1 TPC-H Data Generation
```bash
# Generate TPC-H scale factor 1 (1GB)
rosetta tpch generate --scale 1 --format parquet --output ./tpch/

# Convert to other formats
rosetta convert ./tpch/*.parquet --format vortex --output ./tpch-vortex/
rosetta convert ./tpch/*.parquet --format lance --output ./tpch-lance/
```

### 3.2 Query Benchmarks
Run standard TPC-H queries through:
1. Native Parquet (baseline)
2. Rosetta reading Parquet (overhead test)
3. Rosetta reading Vortex (transcoding test)
4. Rosetta reading Lance (transcoding test)

### 3.3 Benchmark Suite
```bash
rosetta benchmark tpch \
  --queries 1,6,12,14 \  # Key queries
  --formats parquet,vortex,lance \
  --iterations 10 \
  --output results.json
```

### 3.4 Results Publication
- Generate benchmark report (markdown + charts)
- Compare against published DuckDB/DataFusion numbers
- Highlight zero-overhead Parquet passthrough
- Show transcoding overhead is acceptable

### Deliverables
- TPC-H data generator
- Benchmark suite
- Published results with methodology
- Reproducible benchmark scripts

---

## Success Metrics

### Phase 1 Complete When:
- [ ] `pip install rosetta` works
- [ ] `rosetta --help` shows useful commands
- [ ] Demo script runs end-to-end
- [ ] README has clear value proposition

### Phase 2 Complete When:
- [ ] `rosetta upgrade` reduces file sizes by 20%+ on test data
- [ ] Column-level upgrade works correctly
- [ ] Upgrade reports show accurate savings
- [ ] Upgraded files readable by standard Parquet tools

### Phase 3 Complete When:
- [ ] TPC-H queries run successfully
- [ ] Benchmark results are reproducible
- [ ] Results show competitive performance
- [ ] Published benchmark report

---

## Timeline

```
Week 1:
├── Days 1-2: Phase 1 (Polish for Demo)
├── Days 3-6: Phase 2 (Progressive Upgrade)
└── Days 7-9: Phase 3 (TPC-H Validation)

Week 2:
├── Partner outreach (SpiralDB, LanceDB)
├── Community launch (GitHub, HN, Reddit)
└── Iterate based on feedback
```

---

## Key Files Reference

```
src/
├── main.rs              # CLI entry point
├── lib.rs               # Library exports
├── readers/
│   ├── parquet_reader.rs   # Parquet with sync optimization
│   ├── vortex_reader.rs    # Vortex format
│   ├── lance_reader.rs     # Lance format
│   ├── f3_reader.rs        # F3/WASM runtime
│   └── unified.rs          # Format-agnostic reader
├── writers/
│   └── parquet_writer.rs   # Parquet output
├── transcoder.rs        # Format conversion
├── format.rs            # Format detection
├── duckdb/              # DuckDB extension
├── iceberg/             # Iceberg FileIO
├── fuse/                # FUSE filesystem
├── proxy/               # S3 proxy
└── upgrade.rs           # [NEW] Progressive upgrade

python/
├── rosetta/
│   ├── __init__.py
│   └── _rosetta.pyi     # Type stubs
└── tests/

benches/
└── read_benchmark.rs    # Criterion benchmarks
```

---

## Risks & Mitigations

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| Python bindings have compatibility issues | Medium | Test on multiple Python versions |
| Progressive upgrade corrupts data | Low | Extensive testing, backup by default |
| TPC-H shows poor performance | Low | We've already validated ~0% overhead |
| Partner conversations stall | Medium | Multiple targets, OSS community backup |

---

## Next Action

Start Phase 1.1: Complete Python bindings

```bash
cd /Users/tchopra/claude-projects/rosetta
maturin develop --features python
python -c "import rosetta; print(rosetta.__version__)"
```
