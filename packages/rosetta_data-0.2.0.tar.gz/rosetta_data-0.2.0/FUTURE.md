# Rosetta: The Road to Storage Virtualization

> **From "Format Bridge" to "LLVM for Data Access"**

---

## Executive Summary

Rosetta began as a solution to the N×M integration problem: N formats × M tools = explosion of work. The initial vision was a **format bridge** — read any format from any tool.

But expert analysis reveals a sharper, more valuable thesis:

> **"The next breakout data infra company won't replace Parquet. It will virtualize storage semantics — letting multiple physical formats coexist behind a single logical contract."**

This document outlines how Rosetta evolves from a format bridge into **the polymorphic storage contract for the AI era** — what we're calling "LLVM for data access."

---

## The Expert Critique That Shaped This Vision

An expert review of Rosetta's thesis identified the deeper insight:

> **"Query engines are semantically coupled to physical layouts... Parquet didn't just win on format. It won because engines evolved around it. That's why replacing it is so hard."**

The proposed evolution:

> **"The next breakout data infra company won't replace Parquet. It will virtualize storage semantics — letting multiple physical formats coexist behind a single logical contract."**
>
> Think:
> - "LLVM for data access"
> - "Storage IR"
> - "Universal scan/seek API with cost models"

This reframes the problem from "Parquet is old" to **"We lack a polymorphic storage contract."**

---

## Where We Are Today

### Current Architecture (v1.0)

```
┌─────────────────────────────────────────────────────────────┐
│                    Tool Integrations                         │
│  Spark DataSource │ Iceberg FileIO │ DuckDB │ DataFusion    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Rosetta Core                              │
│  FormatReader trait │ Expression IR │ Statistics            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Native Format Readers                     │
│  ParquetReader │ VortexReader │ LanceReader                 │
└─────────────────────────────────────────────────────────────┘
```

### What We Have (The Foundation)

| Component | Status | Description |
|-----------|--------|-------------|
| **FormatReader trait** | ✅ Complete | Polymorphic storage contract |
| **Expression IR** | ✅ Complete | Unified filter language → format-native translation |
| **Statistics API** | ✅ Complete | Row counts, column stats, min/max |
| **Filter Pushdown** | ✅ Complete | Full pushdown to all formats |
| **Parquet Reader** | ✅ Complete | Native arrow-rs with ArrowPredicate |
| **Vortex Reader** | ✅ Complete | Native vortex crate integration |
| **Lance Reader** | ✅ Complete | Native lance crate integration |
| **Transcoder** | ✅ Complete | Any format → Parquet v1 bytes |
| **Python Bindings** | ✅ Complete | PyO3 with expression API |
| **DuckDB Extension** | ✅ Complete | Native C++ with SQL functions |
| **DataFusion Provider** | ✅ Complete | TableProvider implementation |
| **Spark DataSource** | ✅ Complete | DataSource V2 with JNI bridge |
| **Iceberg FileIO** | ✅ Complete | Mixed-format table support |

### The Key Insight

The `FormatReader` trait **is** a polymorphic storage contract:

```rust
pub trait FormatReader: Send + Sync {
    fn schema(&self) -> SchemaRef;
    fn statistics(&self) -> Option<Statistics>;
    fn push_filter(&mut self, filter: &Expr) -> FilterPushdownResult;
    fn push_projection(&mut self, columns: &[String]) -> Result<()>;
    fn partitions(&self) -> Result<Vec<Partition>>;
    async fn read_all(&self) -> Result<Vec<RecordBatch>>;
}
```

The Expression system **is** a Storage IR:

```
SQL Predicate → Rosetta Expr → Format-Native
                    │
    ┌───────────────┼───────────────┐
    ▼               ▼               ▼
ArrowPredicate  VortexExpr    Lance SQL string
 (Parquet)      (native)       (filter API)
```

**The architecture is right. The evolution is about adding capabilities.**

---

## The Evolution: Three Phases

### Phase 1: Capability-Aware Abstraction

**Goal**: Let query engines understand what each format can do efficiently.

Currently, Rosetta tells you *what happened* after a filter push:

```rust
pub enum FilterPushdownResult {
    Pushed,
    Partial { pushed: Option<Box<Expr>>, remaining: Box<Expr> },
    NotPushed(Box<Expr>),
}
```

**Evolution**: Tell engines *what's possible* before they plan:

```rust
/// Format capabilities for query planning
#[derive(Debug, Clone)]
pub struct FormatCapabilities {
    /// Random access performance characteristic
    pub random_access: AccessComplexity,

    /// Sequential scan throughput class
    pub scan_throughput: ThroughputClass,

    /// Filter operations natively supported
    pub filter_support: FilterCapabilities,

    /// Whether format supports efficient point lookups
    pub point_lookup: bool,

    /// Whether format supports vector similarity search
    pub vector_search: bool,

    /// Compression CPU cost (affects GPU data starvation)
    pub decode_cpu_cost: CpuCost,

    /// Native support for nested/complex types
    pub nested_type_support: NestedTypeSupport,
}

/// Access complexity for random reads
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AccessComplexity {
    /// O(1) - constant time (e.g., Lance with index)
    Constant,
    /// O(log n) - logarithmic (e.g., sorted data with stats)
    Logarithmic,
    /// O(n) - linear scan required (e.g., unindexed Parquet)
    Linear,
}

/// Throughput classification for scan operations
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ThroughputClass {
    /// >1 GB/s single-threaded
    VeryHigh,
    /// 500MB - 1GB/s
    High,
    /// 100MB - 500MB/s
    Medium,
    /// <100MB/s
    Low,
}

/// CPU cost for decompression/decoding
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CpuCost {
    /// Minimal CPU (e.g., uncompressed, simple encoding)
    Minimal,
    /// Low CPU (e.g., LZ4, simple dictionary)
    Low,
    /// Medium CPU (e.g., Zstd, complex dictionary)
    Medium,
    /// High CPU (e.g., nested decompression, complex encodings)
    High,
}

/// Filter capabilities by operation type
#[derive(Debug, Clone, Default)]
pub struct FilterCapabilities {
    pub comparison: bool,      // =, !=, <, >, <=, >=
    pub logical: bool,         // AND, OR, NOT
    pub in_list: bool,         // IN (...)
    pub between: bool,         // BETWEEN
    pub like: bool,            // LIKE, ILIKE
    pub is_null: bool,         // IS NULL, IS NOT NULL
    pub regexp: bool,          // Regular expressions
    pub vector_distance: bool, // Vector similarity (L2, cosine, etc.)
}
```

**FormatReader extension**:

```rust
pub trait FormatReader: Send + Sync {
    // ... existing methods ...

    /// Get format capabilities for query planning
    fn capabilities(&self) -> FormatCapabilities;
}
```

**Per-format implementation**:

```rust
impl FormatReader for VortexReader {
    fn capabilities(&self) -> FormatCapabilities {
        FormatCapabilities {
            random_access: AccessComplexity::Logarithmic,
            scan_throughput: ThroughputClass::VeryHigh,   // 10-20x Parquet
            decode_cpu_cost: CpuCost::Low,                // No GPU starvation
            point_lookup: false,
            vector_search: false,
            filter_support: FilterCapabilities {
                comparison: true,
                logical: true,
                in_list: false,  // Requires OR expansion
                between: true,
                like: false,
                is_null: true,
                ..Default::default()
            },
            ..Default::default()
        }
    }
}

impl FormatReader for LanceReader {
    fn capabilities(&self) -> FormatCapabilities {
        FormatCapabilities {
            random_access: AccessComplexity::Constant,    // O(1) with indices
            scan_throughput: ThroughputClass::High,
            decode_cpu_cost: CpuCost::Low,
            point_lookup: true,                           // Designed for this
            vector_search: true,                          // Native ANN support
            filter_support: FilterCapabilities {
                comparison: true,
                logical: true,
                in_list: true,
                between: true,
                like: true,
                is_null: true,
                vector_distance: true,                    // L2, cosine, dot
                ..Default::default()
            },
            ..Default::default()
        }
    }
}

impl FormatReader for ParquetReader {
    fn capabilities(&self) -> FormatCapabilities {
        FormatCapabilities {
            random_access: AccessComplexity::Linear,      // Page-level granularity
            scan_throughput: ThroughputClass::Medium,     // CPU-bound decoding
            decode_cpu_cost: CpuCost::High,               // Dictionary + RLE + compression
            point_lookup: false,                          // Terrible for this
            vector_search: false,
            filter_support: FilterCapabilities {
                comparison: true,
                logical: true,
                in_list: true,
                between: true,
                like: true,
                is_null: true,
                ..Default::default()
            },
            ..Default::default()
        }
    }
}
```

---

### Phase 2: Cost Model API

**Goal**: Enable cost-based optimization across formats.

Query engines need to estimate costs to choose execution strategies. Currently they guess. Rosetta can provide accurate estimates.

```rust
/// Cost estimation for query planning
pub trait CostEstimator {
    /// Estimate cost of a full table scan
    fn estimate_scan_cost(&self, projection: &[String]) -> ScanCostEstimate;

    /// Estimate cost of a filtered read
    fn estimate_filter_cost(
        &self,
        filter: &Expr,
        projection: &[String]
    ) -> FilterCostEstimate;

    /// Estimate cost of a point lookup (if supported)
    fn estimate_point_lookup_cost(
        &self,
        key_columns: &[String]
    ) -> Option<PointLookupCostEstimate>;

    /// Estimate cost of vector similarity search (if supported)
    fn estimate_vector_search_cost(
        &self,
        k: usize,
        ef_search: usize
    ) -> Option<VectorSearchCostEstimate>;
}

/// Cost estimate for scan operations
#[derive(Debug, Clone)]
pub struct ScanCostEstimate {
    /// Estimated bytes to read from storage
    pub io_bytes: usize,

    /// Estimated CPU cycles for decoding
    pub cpu_cycles: u64,

    /// Estimated wall-clock time (milliseconds)
    pub estimated_ms: f64,

    /// Estimated rows returned
    pub estimated_rows: usize,

    /// Confidence interval (0.0 - 1.0)
    pub confidence: f64,
}

/// Cost estimate for filtered reads
#[derive(Debug, Clone)]
pub struct FilterCostEstimate {
    /// Base scan cost
    pub scan_cost: ScanCostEstimate,

    /// Selectivity estimate (0.0 - 1.0)
    pub selectivity: f64,

    /// Whether filter can skip row groups/pages
    pub can_skip_io: bool,

    /// Estimated IO reduction from pushdown
    pub io_reduction_factor: f64,
}

/// Cost estimate for point lookups
#[derive(Debug, Clone)]
pub struct PointLookupCostEstimate {
    /// Estimated latency per lookup (milliseconds)
    pub latency_ms: f64,

    /// Estimated bytes read per lookup
    pub bytes_per_lookup: usize,

    /// Maximum throughput (lookups/second)
    pub max_throughput: f64,
}

/// Cost estimate for vector similarity search
#[derive(Debug, Clone)]
pub struct VectorSearchCostEstimate {
    /// Estimated latency for k results (milliseconds)
    pub latency_ms: f64,

    /// Recall estimate at given ef_search
    pub estimated_recall: f64,

    /// Bytes read for search
    pub io_bytes: usize,
}
```

**Integration with FormatReader**:

```rust
pub trait FormatReader: Send + Sync + CostEstimator {
    // ... existing methods ...
}
```

**Example implementation**:

```rust
impl CostEstimator for VortexReader {
    fn estimate_scan_cost(&self, projection: &[String]) -> ScanCostEstimate {
        let stats = self.statistics().unwrap_or_default();
        let total_rows = stats.num_rows.unwrap_or(0);
        let total_bytes = stats.total_byte_size.unwrap_or(0);

        // Calculate projected column bytes
        let projected_bytes = self.estimate_projected_bytes(projection, total_bytes);

        // Vortex: ~500 MB/s decode throughput, minimal CPU
        let throughput_bytes_per_ms = 500_000.0;
        let estimated_ms = projected_bytes as f64 / throughput_bytes_per_ms;

        ScanCostEstimate {
            io_bytes: projected_bytes,
            cpu_cycles: projected_bytes as u64 * 10, // Low CPU per byte
            estimated_ms,
            estimated_rows: total_rows,
            confidence: 0.85,
        }
    }

    fn estimate_filter_cost(
        &self,
        filter: &Expr,
        projection: &[String]
    ) -> FilterCostEstimate {
        let scan_cost = self.estimate_scan_cost(projection);
        let selectivity = self.estimate_selectivity(filter);

        // Vortex can skip row groups based on zone maps
        let can_skip = self.can_use_zone_maps(filter);
        let io_reduction = if can_skip { 1.0 - selectivity } else { 0.0 };

        FilterCostEstimate {
            scan_cost: ScanCostEstimate {
                io_bytes: (scan_cost.io_bytes as f64 * (1.0 - io_reduction * 0.8)) as usize,
                estimated_ms: scan_cost.estimated_ms * (1.0 - io_reduction * 0.7),
                ..scan_cost
            },
            selectivity,
            can_skip_io: can_skip,
            io_reduction_factor: io_reduction,
        }
    }

    fn estimate_point_lookup_cost(&self, _: &[String]) -> Option<PointLookupCostEstimate> {
        None // Vortex not optimized for point lookups
    }

    fn estimate_vector_search_cost(&self, _: usize, _: usize) -> Option<VectorSearchCostEstimate> {
        None // Vortex doesn't support vector search
    }
}

impl CostEstimator for LanceReader {
    fn estimate_point_lookup_cost(&self, _: &[String]) -> Option<PointLookupCostEstimate> {
        // Lance is optimized for random access
        Some(PointLookupCostEstimate {
            latency_ms: 0.1,           // ~100μs per lookup
            bytes_per_lookup: 4096,    // One page
            max_throughput: 10000.0,   // 10K lookups/sec
        })
    }

    fn estimate_vector_search_cost(&self, k: usize, ef_search: usize) -> Option<VectorSearchCostEstimate> {
        // Lance native vector search
        Some(VectorSearchCostEstimate {
            latency_ms: 5.0 + (k as f64 * 0.1) + (ef_search as f64 * 0.01),
            estimated_recall: (ef_search as f64 / (ef_search as f64 + k as f64)).min(0.99),
            io_bytes: ef_search * 512,
        })
    }
}
```

---

### Phase 3: Multi-Format Routing

**Goal**: Same logical data, multiple physical formats, automatic routing.

This is the "LLVM for data access" vision fully realized. The system chooses the optimal format based on query characteristics.

```rust
/// A router that directs queries to optimal format replicas
pub struct FormatRouter {
    /// Available format replicas for the same logical data
    replicas: Vec<FormatReplica>,

    /// Routing strategy
    strategy: RoutingStrategy,
}

/// A physical format replica of logical data
pub struct FormatReplica {
    /// Path to the data
    pub path: String,

    /// Format of this replica
    pub format: FileFormat,

    /// Reader instance
    pub reader: Box<dyn FormatReader>,

    /// Hints about what this replica is optimized for
    pub optimization_hints: Vec<OptimizationHint>,
}

/// Hints about format optimization targets
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OptimizationHint {
    /// Optimized for full table scans
    Scan,
    /// Optimized for point lookups
    PointLookup,
    /// Optimized for range scans
    RangeScan,
    /// Optimized for vector similarity
    VectorSearch,
    /// Optimized for time-series queries
    TimeSeries,
    /// Optimized for low storage cost (archival)
    Archival,
}

/// Strategy for choosing between format replicas
pub enum RoutingStrategy {
    /// Always use the first available replica
    FirstAvailable,

    /// Choose based on query pattern
    QueryAware,

    /// Choose based on cost estimation
    CostBased,

    /// Custom routing logic
    Custom(Box<dyn RoutingPolicy>),
}

/// Characteristics of a query for routing decisions
#[derive(Debug, Clone)]
pub struct QueryCharacteristics {
    /// Filter predicates
    pub filters: Option<Expr>,

    /// Projected columns
    pub projection: Vec<String>,

    /// Expected selectivity (if known)
    pub selectivity_hint: Option<f64>,

    /// Query pattern classification
    pub pattern: QueryPattern,

    /// Latency requirement
    pub latency_requirement: Option<LatencyRequirement>,
}

/// Classification of query patterns
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum QueryPattern {
    /// Full table scan (SELECT * or aggregations)
    FullScan,
    /// Point lookup (WHERE pk = value)
    PointLookup,
    /// Range scan (WHERE col BETWEEN a AND b)
    RangeScan,
    /// Vector similarity (ORDER BY distance LIMIT k)
    VectorSimilarity,
    /// Time-series (WHERE timestamp > X ORDER BY timestamp)
    TimeSeries,
    /// Unknown/mixed pattern
    Unknown,
}
```

**Routing implementation**:

```rust
impl FormatRouter {
    /// Route a query to the optimal format
    pub fn route(&self, query: &QueryCharacteristics) -> &FormatReplica {
        match &self.strategy {
            RoutingStrategy::FirstAvailable => &self.replicas[0],
            RoutingStrategy::QueryAware => self.route_by_query_pattern(query),
            RoutingStrategy::CostBased => self.route_by_cost(query),
            RoutingStrategy::Custom(policy) => policy.choose_replica(query, &self.replicas),
        }
    }

    fn route_by_query_pattern(&self, query: &QueryCharacteristics) -> &FormatReplica {
        let target_hint = match query.pattern {
            QueryPattern::FullScan => OptimizationHint::Scan,
            QueryPattern::PointLookup => OptimizationHint::PointLookup,
            QueryPattern::RangeScan => OptimizationHint::RangeScan,
            QueryPattern::VectorSimilarity => OptimizationHint::VectorSearch,
            QueryPattern::TimeSeries => OptimizationHint::TimeSeries,
            QueryPattern::Unknown => OptimizationHint::Scan,
        };

        self.replicas
            .iter()
            .find(|r| r.optimization_hints.contains(&target_hint))
            .unwrap_or(&self.replicas[0])
    }

    fn route_by_cost(&self, query: &QueryCharacteristics) -> &FormatReplica {
        self.replicas
            .iter()
            .min_by(|a, b| {
                let cost_a = self.estimate_query_cost(a, query);
                let cost_b = self.estimate_query_cost(b, query);
                cost_a.partial_cmp(&cost_b).unwrap()
            })
            .unwrap()
    }
}
```

**Example usage**:

```rust
// Same data, three format replicas optimized for different workloads
let router = FormatRouter::new(
    vec![
        FormatReplica {
            path: "s3://data/sales.parquet".into(),
            format: FileFormat::Parquet,
            reader: Box::new(ParquetReader::open("s3://data/sales.parquet").await?),
            optimization_hints: vec![OptimizationHint::Archival],
        },
        FormatReplica {
            path: "s3://data/sales.vortex".into(),
            format: FileFormat::Vortex,
            reader: Box::new(VortexReader::open("s3://data/sales.vortex").await?),
            optimization_hints: vec![OptimizationHint::Scan],
        },
        FormatReplica {
            path: "s3://data/sales.lance".into(),
            format: FileFormat::Lance,
            reader: Box::new(LanceReader::open("s3://data/sales.lance").await?),
            optimization_hints: vec![
                OptimizationHint::PointLookup,
                OptimizationHint::VectorSearch,
            ],
        },
    ],
    RoutingStrategy::CostBased,
);

// Analytics query → routes to Vortex (fast scans)
let analytics = QueryCharacteristics {
    filters: Some(col("region").eq(lit("US"))),
    projection: vec!["revenue".into(), "quantity".into()],
    pattern: QueryPattern::FullScan,
    ..Default::default()
};
let reader = router.route(&analytics); // → VortexReader

// Feature lookup → routes to Lance (O(1) access)
let feature_lookup = QueryCharacteristics {
    filters: Some(col("user_id").eq(lit(12345))),
    projection: vec!["embedding".into()],
    pattern: QueryPattern::PointLookup,
    ..Default::default()
};
let reader = router.route(&feature_lookup); // → LanceReader

// Vector search → routes to Lance (native ANN)
let vector_search = QueryCharacteristics {
    pattern: QueryPattern::VectorSimilarity,
    ..Default::default()
};
let reader = router.route(&vector_search); // → LanceReader
```

---

## The Write Path (Future)

Currently Rosetta is read-focused with transcoding to Parquet v1. The full vision includes format-aware writes:

```rust
/// Format writer abstraction
pub trait FormatWriter: Send + Sync {
    async fn write(&mut self, batches: &[RecordBatch]) -> Result<WriteResult>;
    async fn close(self) -> Result<WriteStats>;
    fn optimal_batch_size(&self) -> usize;
    fn capabilities(&self) -> WriterCapabilities;
}

/// Tiered storage writer - automatic format selection based on data characteristics
pub struct TieredWriter {
    /// Hot tier: optimized for recent/frequent access (e.g., Lance)
    hot_writer: Box<dyn FormatWriter>,

    /// Warm tier: balanced storage/performance (e.g., Vortex)
    warm_writer: Box<dyn FormatWriter>,

    /// Cold tier: optimized for storage cost (e.g., Parquet)
    cold_writer: Box<dyn FormatWriter>,

    /// Policy for tier assignment
    policy: TieringPolicy,
}
```

---

## Integration Evolution

### DataFusion with Capabilities

```rust
impl TableProvider for RosettaTableProvider {
    fn scan(&self, ...) -> DFResult<Arc<dyn ExecutionPlan>> {
        // Use capabilities for planning
        let caps = self.reader.capabilities();

        // Use cost estimation for optimization
        let cost = self.reader.estimate_filter_cost(&filters, &projection);

        // Report capabilities to DataFusion optimizer
        let props = PlanProperties::new(...)
            .with_predicate_pushdown(caps.filter_support.comparison)
            .with_projection_pushdown(true);

        Ok(Arc::new(RosettaExec { ... }))
    }
}
```

### Iceberg with Format Routing

```rust
/// Enhanced FileIO with format routing
pub struct RosettaFileIO {
    inner: Arc<dyn FileIO>,
    router: Option<FormatRouter>,
    cost_tracker: CostTracker,
}

impl FileIO for RosettaFileIO {
    fn new_input(&self, path: &str) -> Result<Arc<dyn InputFile>> {
        // Track access patterns for routing optimization
        self.cost_tracker.record_access(path, AccessType::Read);

        // If router available, potentially redirect to better replica
        if let Some(router) = &self.router {
            if let Some(better_path) = router.suggest_replica(path) {
                return self.create_input_file(&better_path);
            }
        }

        self.create_input_file(path)
    }
}
```

---

## Success Metrics

### Phase 1: Capability-Aware
| Metric | Target |
|--------|--------|
| All readers expose capabilities | 100% |
| DataFusion uses capabilities for planning | Yes |
| DuckDB extension uses capabilities | Yes |

### Phase 2: Cost Model
| Metric | Target |
|--------|--------|
| Cost estimate accuracy | ±20% of actual |
| Cost-based routing improves query time | >30% for mixed workloads |
| Query engines use Rosetta costs | 2+ engines |

### Phase 3: Multi-Format Routing
| Metric | Target |
|--------|--------|
| Automatic format selection accuracy | >90% |
| Latency improvement for mixed workloads | >50% |
| Zero-config routing for common patterns | Yes |

---

## The Competitive Moat

Once Rosetta provides:
1. **Capability advertisement** — Engines know what formats can do
2. **Cost estimation** — Engines can optimize across formats
3. **Multi-format routing** — Automatic format selection

...it becomes **infrastructure that engines depend on**.

This is the LLVM pattern:
- LLVM didn't replace compilers, it became the compilation target
- Rosetta doesn't replace formats, it becomes the storage abstraction

**Formats compete on capability. Tools integrate once. Everyone wins.**

---

## Why This Matters

### The Current State

Query engines are semantically coupled to physical layouts:
- Predicate pushdown semantics
- Statistics exposure
- Row group pruning
- Memory models
- Vectorization assumptions
- Fault tolerance boundaries

Parquet didn't just win on format. **It won because engines evolved around it.**

### The Rosetta Thesis

Decouple format innovation from engine evolution:

1. **Phase 1**: Make the contract explicit (capabilities)
2. **Phase 2**: Make the contract measurable (cost models)
3. **Phase 3**: Make the contract actionable (routing)

The result: **A polymorphic storage contract that lets the ecosystem evolve.**

### The Opportunity

The [Iceberg File Format API proposal](https://github.com/apache/iceberg/issues/12225) signals that the community recognizes this need. Rosetta can provide the reference implementation — proving the pattern works at production scale before it's formalized in the spec.

---

## Summary

| Phase | Goal | Key Addition |
|-------|------|--------------|
| **Current** | Format Bridge | FormatReader trait, Expression IR |
| **Phase 1** | Capability-Aware | `FormatCapabilities` struct |
| **Phase 2** | Cost-Based | `CostEstimator` trait |
| **Phase 3** | Auto-Routing | `FormatRouter` with multi-replica support |

**The architecture is already 80% there. The evolution is about making the implicit contract explicit.**

---

*This document describes the long-term strategic vision for Rosetta. See [ROADMAP.md](./ROADMAP.md) for near-term execution plans.*
