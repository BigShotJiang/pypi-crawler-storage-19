#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors
#
# Build native libraries for all supported platforms
#
# Usage:
#   ./scripts/build-native.sh           # Build for current platform
#   ./scripts/build-native.sh --all     # Build for all platforms (requires cross)
#   ./scripts/build-native.sh --release # Build release version

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
JAVA_NATIVE_DIR="$PROJECT_ROOT/java/rosetta-jni/src/main/resources/native"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

# Parse arguments
BUILD_ALL=false
BUILD_RELEASE=true
FEATURES="vortex-reader,lance-reader,jni"

while [[ $# -gt 0 ]]; do
    case $1 in
        --all)
            BUILD_ALL=true
            shift
            ;;
        --debug)
            BUILD_RELEASE=false
            shift
            ;;
        --release)
            BUILD_RELEASE=true
            shift
            ;;
        --features)
            FEATURES="$2"
            shift 2
            ;;
        *)
            error "Unknown option: $1"
            ;;
    esac
done

# Set cargo profile
if $BUILD_RELEASE; then
    CARGO_PROFILE="--release"
    TARGET_DIR="release"
else
    CARGO_PROFILE=""
    TARGET_DIR="debug"
fi

# Detect current platform
OS=$(uname -s)
ARCH=$(uname -m)

case "$OS" in
    Darwin)
        PLATFORM="macos"
        if [ "$ARCH" = "arm64" ]; then
            NATIVE_TARGET="aarch64-apple-darwin"
            NATIVE_ARCH="aarch64"
        else
            NATIVE_TARGET="x86_64-apple-darwin"
            NATIVE_ARCH="x86_64"
        fi
        LIB_EXT="dylib"
        LIB_PREFIX="lib"
        ;;
    Linux)
        PLATFORM="linux"
        if [ "$ARCH" = "aarch64" ]; then
            NATIVE_TARGET="aarch64-unknown-linux-gnu"
            NATIVE_ARCH="aarch64"
        else
            NATIVE_TARGET="x86_64-unknown-linux-gnu"
            NATIVE_ARCH="x86_64"
        fi
        LIB_EXT="so"
        LIB_PREFIX="lib"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        PLATFORM="windows"
        NATIVE_TARGET="x86_64-pc-windows-msvc"
        NATIVE_ARCH="x86_64"
        LIB_EXT="dll"
        LIB_PREFIX=""
        ;;
    *)
        error "Unsupported OS: $OS"
        ;;
esac

info "Building Rosetta native library"
info "Platform: $PLATFORM ($ARCH)"
info "Features: $FEATURES"
info "Profile: $([ "$BUILD_RELEASE" = true ] && echo "release" || echo "debug")"

cd "$PROJECT_ROOT"

# Create output directories
mkdir -p "$JAVA_NATIVE_DIR/$NATIVE_ARCH"

# Build for current platform
build_current_platform() {
    info "Building for $NATIVE_TARGET..."

    cargo +nightly build $CARGO_PROFILE --features "$FEATURES"

    # Copy library to Java resources
    local src="$PROJECT_ROOT/target/$TARGET_DIR/${LIB_PREFIX}rosetta.$LIB_EXT"
    local dest="$JAVA_NATIVE_DIR/$NATIVE_ARCH/${LIB_PREFIX}rosetta.$LIB_EXT"

    if [ -f "$src" ]; then
        cp "$src" "$dest"
        info "Copied library to: $dest"
    else
        error "Library not found: $src"
    fi
}

# Build for all platforms (requires cross-compilation setup)
build_all_platforms() {
    info "Building for all platforms..."

    # Check if cross is available
    if ! command -v cross &> /dev/null; then
        warn "cross not found. Install with: cargo install cross"
        warn "Building for current platform only."
        build_current_platform
        return
    fi

    # List of targets to build
    local targets=(
        "x86_64-unknown-linux-gnu"
        "aarch64-unknown-linux-gnu"
        "x86_64-apple-darwin"
        "aarch64-apple-darwin"
        "x86_64-pc-windows-msvc"
    )

    for target in "${targets[@]}"; do
        info "Building for $target..."

        # Determine architecture from target
        local arch
        case "$target" in
            x86_64-*)
                arch="x86_64"
                ;;
            aarch64-*)
                arch="aarch64"
                ;;
        esac

        # Determine library extension
        local lib_ext
        local lib_prefix="lib"
        case "$target" in
            *-apple-darwin)
                lib_ext="dylib"
                ;;
            *-windows-*)
                lib_ext="dll"
                lib_prefix=""
                ;;
            *)
                lib_ext="so"
                ;;
        esac

        # Build with cross
        cross build $CARGO_PROFILE --target "$target" --features "$FEATURES" || {
            warn "Failed to build for $target, skipping..."
            continue
        }

        # Create target directory and copy library
        mkdir -p "$JAVA_NATIVE_DIR/$arch"
        local src="$PROJECT_ROOT/target/$target/$TARGET_DIR/${lib_prefix}rosetta.$lib_ext"
        local dest="$JAVA_NATIVE_DIR/$arch/${lib_prefix}rosetta.$lib_ext"

        if [ -f "$src" ]; then
            cp "$src" "$dest"
            info "Copied library to: $dest"
        fi
    done
}

# Run build
if $BUILD_ALL; then
    build_all_platforms
else
    build_current_platform
fi

# Also copy the C header file
info "Copying C header file..."
mkdir -p "$PROJECT_ROOT/java/rosetta-jni/src/main/resources/native/include"
cp "$PROJECT_ROOT/include/rosetta.h" "$PROJECT_ROOT/java/rosetta-jni/src/main/resources/native/include/"

info "Build complete!"
info ""
info "Native libraries are in: $JAVA_NATIVE_DIR"
info ""
info "To build the Java modules:"
info "  cd java && mvn package"
