#!/bin/bash
# Rosetta Installation Script
# This script handles all the complexity of building Rosetta from source.
#
# Usage: ./scripts/install.sh
#
# Prerequisites:
#   - Python 3.9+ with pip
#   - curl (for installing Rust if needed)

set -e

echo "=========================================="
echo "  Rosetta Installation Script"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python version
echo "Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}Error: Python 3 is required but not found.${NC}"
    echo "Install Python 3.9+ from https://www.python.org/"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e "${GREEN}✓ Found Python $PYTHON_VERSION${NC}"

# Check/Install Rust
echo ""
echo "Checking Rust..."
if ! command -v rustup &> /dev/null; then
    echo -e "${YELLOW}Rust not found. Installing via rustup...${NC}"
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi
echo -e "${GREEN}✓ Rust installed${NC}"

# Install nightly toolchain (required for Vortex)
echo ""
echo "Installing Rust nightly toolchain (required for Vortex support)..."
rustup install nightly --quiet
echo -e "${GREEN}✓ Nightly Rust installed${NC}"
echo "  (Using RUSTUP_TOOLCHAIN=nightly for builds, your default is unchanged)"

# Check nightly rustc version
RUSTC_VERSION=$(rustc +nightly --version | awk '{print $2}')
echo "  Nightly rustc: $RUSTC_VERSION"

# Create virtual environment if not in one
echo ""
if [ -z "$VIRTUAL_ENV" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
    source .venv/bin/activate
    echo -e "${GREEN}✓ Virtual environment created at .venv/${NC}"
else
    echo -e "${GREEN}✓ Using existing virtual environment: $VIRTUAL_ENV${NC}"
fi

# Install Python dependencies
echo ""
echo "Installing Python dependencies..."
pip install --quiet --upgrade pip
pip install --quiet maturin pyarrow

# Build and install Rosetta
echo ""
echo "Building Rosetta (this may take a few minutes)..."
RUSTUP_TOOLCHAIN=nightly maturin develop --features "python,vortex-reader,lance-reader" --quiet

echo ""
echo -e "${GREEN}=========================================="
echo "  Installation Complete!"
echo "==========================================${NC}"
echo ""
echo "Try it out:"
echo ""
echo "  python -c \"import rosetta; print(rosetta.__version__)\""
echo ""
echo "Or run an example:"
echo ""
echo "  python examples/python/01_basic_usage.py"
echo ""
