#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors
#
# Run Rosetta JVM benchmarks
#
# Usage:
#   ./scripts/run-benchmarks.sh           # Run all benchmarks
#   ./scripts/run-benchmarks.sh quick     # Quick run for development
#   ./scripts/run-benchmarks.sh jni       # JNI overhead benchmarks only
#   ./scripts/run-benchmarks.sh transcode # Transcoding benchmarks only
#   ./scripts/run-benchmarks.sh spark     # Spark benchmarks only
#   ./scripts/run-benchmarks.sh iceberg   # Iceberg FileIO benchmarks only

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
JAVA_DIR="$PROJECT_ROOT/java"
BENCHMARK_JAR="$JAVA_DIR/rosetta-benchmark/target/rosetta-benchmarks.jar"
DATA_DIR="$PROJECT_ROOT/benchmark-data"
RESULTS_DIR="$PROJECT_ROOT/benchmark-results"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Check if benchmark JAR exists
if [ ! -f "$BENCHMARK_JAR" ]; then
    info "Building benchmark JAR..."
    cd "$JAVA_DIR"
    mvn package -DskipTests -pl rosetta-benchmark -am
fi

# Create data and results directories
mkdir -p "$DATA_DIR"
mkdir -p "$RESULTS_DIR"

# Check if test data exists
if [ ! -f "$DATA_DIR/small.parquet" ]; then
    warn "Test data not found. Generating..."
    java -cp "$BENCHMARK_JAR" io.rosetta.benchmark.TestDataGenerator "$DATA_DIR"
fi

# Parse arguments
MODE="${1:-all}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

run_benchmarks() {
    local name="$1"
    local pattern="$2"
    local extra_args="${3:-}"

    local results_file="$RESULTS_DIR/${name}_${TIMESTAMP}.json"

    info "Running $name benchmarks..."
    info "Results will be saved to: $results_file"

    java -Xmx4g -jar "$BENCHMARK_JAR" \
        "$pattern" \
        -p dataDir="$DATA_DIR" \
        -rf json \
        -rff "$results_file" \
        $extra_args

    info "Completed: $name"
    echo ""
}

case "$MODE" in
    quick)
        info "Running quick benchmarks (development mode)..."
        java -Xmx4g -jar "$BENCHMARK_JAR" \
            -p dataDir="$DATA_DIR" \
            -p size=small \
            -wi 1 -i 3 -f 1 \
            -rf json \
            -rff "$RESULTS_DIR/quick_${TIMESTAMP}.json"
        ;;

    jni)
        run_benchmarks "jni" "JniBenchmark.*" "-wi 3 -i 5 -f 2"
        ;;

    transcode)
        run_benchmarks "transcode" "TranscodeBenchmark.*" "-p size=medium -wi 3 -i 5 -f 2"
        ;;

    spark)
        run_benchmarks "spark" "SparkBenchmark.*" "-p size=medium -wi 2 -i 3 -f 1"
        ;;

    iceberg)
        run_benchmarks "iceberg" "IcebergBenchmark.*" "-p size=medium -p bufferSize=65536 -wi 3 -i 5 -f 2"
        ;;

    all)
        info "Running full benchmark suite (this may take 30+ minutes)..."
        echo ""

        run_benchmarks "jni" "JniBenchmark.*" "-wi 3 -i 5 -f 2"
        run_benchmarks "transcode" "TranscodeBenchmark.*" "-p size=medium -wi 3 -i 5 -f 2"
        run_benchmarks "iceberg" "IcebergBenchmark.*" "-p size=medium -p bufferSize=65536 -wi 3 -i 5 -f 2"
        run_benchmarks "spark" "SparkBenchmark.*" "-p size=medium -wi 2 -i 3 -f 1"

        info "All benchmarks complete!"
        info "Results saved in: $RESULTS_DIR"
        ;;

    *)
        echo "Usage: $0 [quick|jni|transcode|spark|iceberg|all]"
        exit 1
        ;;
esac

# Print summary
echo ""
echo "=========================================="
echo "Benchmark Results"
echo "=========================================="
ls -la "$RESULTS_DIR"/*.json 2>/dev/null | tail -5 || echo "No results found"
echo ""
info "View results with: cat $RESULTS_DIR/<file>.json | jq '.'"
