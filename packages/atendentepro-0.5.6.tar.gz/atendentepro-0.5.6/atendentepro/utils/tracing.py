# -*- coding: utf-8 -*-
"""
Tracing configuration for AtendentePro.

Provides optional Application Insights integration for telemetry.
"""

from __future__ import annotations

import logging
from typing import Optional

from atendentepro.config import get_config

logger = logging.getLogger(__name__)


def configure_tracing(connection_string: Optional[str] = None) -> bool:
    """
    Configure Application Insights tracing if connection string is available.
    
    Args:
        connection_string: Optional connection string. If not provided,
                          uses the value from configuration.
                          
    Returns:
        True if tracing was configured, False otherwise.
    """
    config = get_config()
    conn_str = connection_string or config.application_insights_connection_string
    
    if not conn_str:
        logger.debug("No Application Insights connection string provided. Tracing disabled.")
        return False
    
    try:
        # Try to configure Application Insights
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        
        # Check if azure monitor is available
        try:
            from azure.monitor.opentelemetry.exporter import AzureMonitorTraceExporter
            
            exporter = AzureMonitorTraceExporter(connection_string=conn_str)
            provider = TracerProvider()
            processor = BatchSpanProcessor(exporter)
            provider.add_span_processor(processor)
            trace.set_tracer_provider(provider)
            
            logger.info("Application Insights tracing configured successfully.")
            return True
            
        except ImportError:
            logger.warning(
                "Azure Monitor exporter not available. "
                "Install 'azure-monitor-opentelemetry-exporter' for Application Insights support."
            )
            return False
            
    except ImportError:
        logger.warning(
            "OpenTelemetry not available. "
            "Install 'opentelemetry-sdk' for tracing support."
        )
        return False
    except Exception as e:
        logger.error(f"Failed to configure tracing: {e}")
        return False

