"""
Package pathtraits
"""
