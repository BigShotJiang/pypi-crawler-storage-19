"""
DYF-RS - Fast Outlier Classification (Rust Core)

This is the Rust-accelerated core for the dyf package.
Install the 'dyf' package for the full Python interface.

Example:
    >>> from dyf_rs import OutlierClassifier
    >>> classifier = OutlierClassifier(embedding_dim=384)
    >>> classifier.fit(embeddings)
    >>> print(classifier.report())
"""

from ._core import (
    PyOutlierClassifier as OutlierClassifier,
    PyOutlierReport as OutlierReport,
    PyOutlierStatus as OutlierStatus,
)

__version__ = "0.1.0"
__all__ = ["OutlierClassifier", "OutlierReport", "OutlierStatus"]
