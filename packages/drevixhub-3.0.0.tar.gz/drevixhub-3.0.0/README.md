# Drevix Library 🚀
مكتبة بايثون احترافية لبناء بوتات منصة Drevix.

## التثبيت
pip install drevix

## الاستخدام
from drevix import Bot
...
