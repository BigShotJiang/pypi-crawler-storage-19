from setuptools import setup, find_packages

setup(
    name="drevixhub",                # اسم المكتبة (سيستخدم في pip install)
    version="3.0.0",              # الإصدار
    author="maystre Developer",   # اسمك
    description="Professional Bot Library for Drevix Platform",
    long_description="A powerful library to build bots connected to Drevix Firebase system.",
    packages=find_packages(),     # البحث التلقائي عن الأكواد
    install_requires=[            # المكتبات التي يحتاجها البوت
        'requests'
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
