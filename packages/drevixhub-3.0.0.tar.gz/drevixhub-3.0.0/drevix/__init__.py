import requests
import time
import threading
import json
import os

# =====================================================
# 🛠️ محرك قاعدة البيانات المحلي (Server-Side Storage)
# هذا يمثل "قاعدة البيانات" الموجودة في استضافتك الخاصة
# =====================================================
class LocalDB:
    def __init__(self, bot_token):
        # ننشئ مجلد خاص للداتا لترتيب الملفات مثل السيرفرات الحقيقية
        self.folder = "drevix_data"
        if not os.path.exists(self.folder):
            os.makedirs(self.folder)
            
        # اسم الملف يعتمد على التوكن (لكل بوت ملف خاص)
        safe_token = bot_token[-8:] if len(bot_token) > 8 else bot_token
        self.filename = f"{self.folder}/db_{safe_token}.json"
        self.data = self._load()

    def _load(self):
        """تحميل قاعدة البيانات من القرص الصلب (Hosting Disk)"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {} # لو الملف تالف نرجع قاموس فارغ
        return {}

    def _save(self):
        """حفظ البيانات في القرص الصلب"""
        with open(self.filename, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=4)

    def set(self, key, value):
        """تخزين قيمة (مثل SQL Insert/Update)"""
        self.data[str(key)] = value
        self._save()

    def get(self, key, default=None):
        """جلب قيمة (مثل SQL Select)"""
        return self.data.get(str(key), default)

    def delete_key(self, key):
        """حذف سجل معين"""
        if str(key) in self.data:
            del self.data[str(key)]
            self._save()

# =====================================================
# 🤖 كلاس البوت (The Engine)
# =====================================================
class Bot:
    def __init__(self, token):
        self.token = token
        self.db_url = "https://test-e7f1b-default-rtdb.firebaseio.com"
        self.handlers = []
        self.running = False
        
        # 🔥 ربط البوت بقاعدة بيانات محلية في الاستضافة
        self.storage = LocalDB(token)

    def send_message(self, chat_id, text):
        """إرسال الرد إلى Firebase (ليظهر للمستخدم)"""
        url = f"{self.db_url}/chat_rooms/{self.token}/{chat_id}.json"
        data = {
            "msg": text,
            "sender": "bot",
            "type": "text",
            "timestamp": {".sv": "timestamp"}
        }
        try:
            requests.post(url, json=data)
        except Exception as e:
            print(f"❌ فشل الإرسال: {e}")

    def message_handler(self, func):
        self.handlers.append(func)
        return func

    def polling(self, interval=1.0):
        """
        تشغيل السيرفر (Long Polling Loop)
        هذا الكود يجب أن يبقى يعمل 24/7 في الاستضافة
        """
        print(f"✅ تم تشغيل البوت على السيرفر المحلي...")
        print(f"📂 مسار قاعدة البيانات: {self.storage.filename}")
        print("📡 جاري الاتصال بـ Drevix Cloud لاستقبال الرسائل...")
        
        self.running = True
        while self.running:
            try:
                # 1. الاستماع للرسائل الجديدة
                # نطلب آخر 10 رسائل لتقليل استهلاك النت
                url = f"{self.db_url}/chat_rooms/{self.token}.json?orderBy=\"$key\"&limitToLast=10"
                response = requests.get(url, timeout=10)
                
                if response.status_code == 200 and response.json():
                    self._process_updates(response.json())
            
            except requests.exceptions.RequestException:
                print("⚠️ ضعف في الاتصال... إعادة المحاولة")
            except Exception as e:
                print(f"❌ خطأ غير متوقع: {e}")
            
            time.sleep(interval) # استراحة قصيرة للمعالج

    def _process_updates(self, data):
        if not isinstance(data, dict): return

        for user_id, chats in data.items():
            if isinstance(chats, dict):
                for msg_id, content in chats.items():
                    # التحقق من أن الرسالة "معلقة" (Pending) وجديدة
                    if content.get('status') == 'pending' and content.get('sender') == 'user':
                        
                        # A. توثيق الاستلام فوراً (ACK)
                        # نخبر Firebase أننا استلمنا الرسالة لكي لا يعيد إرسالها
                        requests.patch(
                            f"{self.db_url}/chat_rooms/{self.token}/{user_id}/{msg_id}.json",
                            json={"status": "processing"} 
                        )

                        # B. تشغيل المنطق الخاص بالمطور (في خيط منفصل)
                        msg_obj = Message(user_id, content.get('msg'), self, msg_id)
                        
                        for handler in self.handlers:
                            threading.Thread(target=handler, args=(msg_obj,)).start()
                            
                        # C. بعد الانتهاء نحولها لمقروءة (أو نحذفها حسب الرغبة)
                        requests.patch(
                            f"{self.db_url}/chat_rooms/{self.token}/{user_id}/{msg_id}.json",
                            json={"status": "read"}
                        )

# =====================================================
# 📩 كلاس الرسالة
# =====================================================
class Message:
    def __init__(self, chat_id, text, bot, msg_id):
        self.chat_id = chat_id
        self.text = text
        self.bot = bot
        self.id = msg_id

    def reply(self, text):
        self.bot.send_message(self.chat_id, text)
