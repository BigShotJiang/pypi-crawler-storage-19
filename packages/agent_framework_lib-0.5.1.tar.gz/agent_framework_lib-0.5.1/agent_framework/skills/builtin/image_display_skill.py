"""
Image Display Skill - Image display capability.

This skill provides the ability to display images in the chat interface
from URLs. Images are rendered with download buttons and click-to-open
functionality.

Note: This is a UI-only skill with no associated tools - it provides
instructions for generating image JSON that the frontend renders.
"""

from ..base import Skill, SkillMetadata, SkillCategory


IMAGE_DISPLAY_INSTRUCTIONS = """
## Image Display Instructions

You can display images in the chat by using a JSON block with an "image" key.
Images are rendered with a download button and click-to-open functionality.

### When to Use Image Display
- Displaying charts, diagrams, or visualizations from external sources
- Showing screenshots or reference images
- Presenting generated images from image generation APIs
- Including logos, icons, or other visual assets
- Displaying images from URLs

### Image JSON Structure

Use a JSON object with an "image" key containing the image configuration:

```json
{
  "image": {
    "url": "https://example.com/image.png",
    "alt": "Description of the image",
    "caption": "Optional caption below the image"
  }
}
```

### Properties

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `url` | string | Yes | URL of the image (HTTP/HTTPS) |
| `alt` | string | No | Alt text for accessibility |
| `caption` | string | No | Caption displayed below image |
| `width` | string | No | CSS width (e.g., "400px", "100%") |
| `height` | string | No | CSS height (e.g., "300px", "auto") |
| `filename` | string | No | Custom filename for download |

### Examples

**Simple image with just URL:**
```json
{"image": {"url": "https://example.com/chart.png"}}
```

**Image with alt text and caption:**
```json
{
  "image": {
    "url": "https://example.com/sales-chart.png",
    "alt": "Sales chart Q4 2024",
    "caption": "Quarterly sales performance"
  }
}
```

**Image with size constraints:**
```json
{
  "image": {
    "url": "https://example.com/diagram.png",
    "alt": "Architecture diagram",
    "caption": "System architecture overview",
    "width": "600px",
    "height": "auto",
    "filename": "architecture-diagram.png"
  }
}
```

**Full-width responsive image:**
```json
{
  "image": {
    "url": "https://example.com/banner.jpg",
    "alt": "Welcome banner",
    "width": "100%",
    "height": "auto"
  }
}
```

### Behavior

- Images are displayed with max-width constraints for responsive layout
- Clicking on the image opens it in a new tab for full-size viewing
- A download button (💾) appears below the image for easy downloading
- If the image fails to load, an error placeholder is shown with the alt text
- Multiple images can be included in a single response

### Best Practices

1. **Always include alt text** - Important for accessibility
2. **Use descriptive captions** - Help users understand the image context
3. **Specify dimensions when needed** - Prevent layout shifts
4. **Use HTTPS URLs** - Ensure secure image loading
5. **Provide meaningful filenames** - For better download experience

### URL Requirements

- Must be a valid HTTP or HTTPS URL
- URL should point directly to an image file
- Supported formats: PNG, JPG, JPEG, GIF, WebP, SVG

### When NOT to Use Image Display

- For user-uploaded images → Use the file upload feature
- For generating new charts → Use the chart skill with save_chart_as_image
- For generating diagrams → Use the mermaid skill with save_mermaid_as_image
- For local files → Use file_access_skill to get data URIs

### Multiple Images

You can include multiple images in a single response by using multiple
image JSON blocks:

```json
{"image": {"url": "https://example.com/image1.png", "caption": "First image"}}
```

```json
{"image": {"url": "https://example.com/image2.png", "caption": "Second image"}}
```
"""


def create_image_display_skill() -> Skill:
    """
    Create the image display skill.

    This skill provides instructions for displaying images from URLs.
    It has no associated tools - images are rendered by the UI from JSON.

    Returns:
        Skill instance for image display
    """
    return Skill(
        metadata=SkillMetadata(
            name="image_display",
            description="Display images from URLs with download and view functionality",
            trigger_patterns=[
                "display image",
                "show image",
                "image url",
                "render image",
                "embed image",
                "picture",
                "photo",
                "screenshot",
            ],
            category=SkillCategory.UI,
            version="1.0.0",
        ),
        instructions=IMAGE_DISPLAY_INSTRUCTIONS,
        tools=[],  # UI-only skill, no tools
        dependencies=[],
        config={},
    )


__all__ = ["create_image_display_skill", "IMAGE_DISPLAY_INSTRUCTIONS"]
