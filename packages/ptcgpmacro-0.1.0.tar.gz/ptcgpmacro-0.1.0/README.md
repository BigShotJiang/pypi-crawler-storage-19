# ptcgp

Python 라이브러리로 `macro3.py`와 `special.py` exe를 빌드하고, 이미지/JSON 파일과 함께 `ptcgp.zip` 생성.

## 사용법

```python
import ptcgpmacro

# 라이브러리 명령어로 ptcgp.zip 생성
ptcgpmacro.build_ptcgp_zip("ptcgp.zip")
