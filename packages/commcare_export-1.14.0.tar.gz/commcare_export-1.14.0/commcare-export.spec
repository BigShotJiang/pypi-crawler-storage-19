# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['commcare_export/cli.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('./commcare_export', './commcare_export'),
        ('./migrations', './migrations'),
    ],
    hiddenimports=[
        'sqlalchemy.sql.default_comparator',
    ],
    hookspath=[],
    runtime_hooks=['build_exe/runtime_hook.py'],
    excludes=[],
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='commcare-export',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
