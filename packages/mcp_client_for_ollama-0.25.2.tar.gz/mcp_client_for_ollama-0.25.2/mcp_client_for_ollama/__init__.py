"""MCP Client for Ollama package."""

__version__ = "0.25.2"
