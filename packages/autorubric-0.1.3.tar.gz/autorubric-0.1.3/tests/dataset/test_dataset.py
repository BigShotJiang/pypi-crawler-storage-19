"""Tests for autorubric.dataset module."""

import json
import tempfile
from pathlib import Path

import pytest

from autorubric import Criterion, CriterionVerdict, Rubric
from autorubric.dataset import DataItem, RubricDataset


# =============================================================================
# DataItem Tests
# =============================================================================


class TestDataItem:
    """Tests for DataItem dataclass."""

    def test_create_without_ground_truth(self):
        """DataItem can be created without ground truth."""
        item = DataItem(text="Hello world", description="Simple text")
        assert item.text == "Hello world"
        assert item.description == "Simple text"
        assert item.ground_truth is None

    def test_create_with_ground_truth(self):
        """DataItem can be created with ground truth verdicts."""
        verdicts = [CriterionVerdict.MET, CriterionVerdict.UNMET]
        item = DataItem(
            text="Test text",
            description="Test description",
            ground_truth=verdicts,
        )
        assert item.ground_truth == verdicts

    def test_ground_truth_validation_rejects_non_verdict(self):
        """DataItem rejects non-CriterionVerdict ground truth values."""
        with pytest.raises(ValueError, match="must be CriterionVerdict"):
            DataItem(
                text="Test",
                description="Test",
                ground_truth=["MET", "UNMET"],  # Strings, not CriterionVerdict
            )

    def test_ground_truth_validation_rejects_mixed_types(self):
        """DataItem rejects mixed types in ground truth."""
        with pytest.raises(ValueError, match="must be CriterionVerdict"):
            DataItem(
                text="Test",
                description="Test",
                ground_truth=[CriterionVerdict.MET, "UNMET"],
            )


# =============================================================================
# RubricDataset Tests
# =============================================================================


@pytest.fixture
def sample_rubric() -> Rubric:
    """Create a sample rubric for testing."""
    return Rubric([
        Criterion(name="Accuracy", weight=10.0, requirement="Must be accurate"),
        Criterion(name="Clarity", weight=5.0, requirement="Must be clear"),
        Criterion(name="Errors", weight=-3.0, requirement="Contains errors"),
    ])


@pytest.fixture
def sample_dataset(sample_rubric: Rubric) -> RubricDataset:
    """Create a sample dataset for testing."""
    dataset = RubricDataset(
        prompt="Explain the topic",
        rubric=sample_rubric,
    )
    dataset.add_item(
        text="Good response with accurate information.",
        description="High quality",
        ground_truth=[
            CriterionVerdict.MET,
            CriterionVerdict.MET,
            CriterionVerdict.UNMET,
        ],
    )
    dataset.add_item(
        text="Poor response.",
        description="Low quality",
        ground_truth=[
            CriterionVerdict.UNMET,
            CriterionVerdict.UNMET,
            CriterionVerdict.MET,
        ],
    )
    return dataset


class TestRubricDatasetCreation:
    """Tests for RubricDataset creation and validation."""

    def test_create_empty_dataset(self, sample_rubric: Rubric):
        """Empty dataset can be created."""
        dataset = RubricDataset(prompt="Test prompt", rubric=sample_rubric)
        assert len(dataset) == 0
        assert dataset.prompt == "Test prompt"
        assert dataset.rubric == sample_rubric

    def test_create_with_items(self, sample_rubric: Rubric):
        """Dataset can be created with initial items."""
        items = [
            DataItem(
                text="Text 1",
                description="Desc 1",
                ground_truth=[
                    CriterionVerdict.MET,
                    CriterionVerdict.MET,
                    CriterionVerdict.UNMET,
                ],
            ),
        ]
        dataset = RubricDataset(
            prompt="Test prompt",
            rubric=sample_rubric,
            items=items,
        )
        assert len(dataset) == 1

    def test_validation_rejects_mismatched_ground_truth(self, sample_rubric: Rubric):
        """Dataset rejects items with wrong number of ground truth verdicts."""
        items = [
            DataItem(
                text="Text",
                description="Desc",
                ground_truth=[CriterionVerdict.MET],  # Only 1, but rubric has 3
            ),
        ]
        with pytest.raises(ValueError, match="ground truth values"):
            RubricDataset(prompt="Test", rubric=sample_rubric, items=items)


class TestRubricDatasetProperties:
    """Tests for RubricDataset properties."""

    def test_criterion_names(self, sample_dataset: RubricDataset):
        """criterion_names returns criterion names."""
        assert sample_dataset.criterion_names == ["Accuracy", "Clarity", "Errors"]

    def test_criterion_names_fallback(self):
        """criterion_names falls back to C{index} for unnamed criteria."""
        rubric = Rubric([
            Criterion(weight=1.0, requirement="R1"),  # No name
            Criterion(name="Named", weight=1.0, requirement="R2"),
        ])
        dataset = RubricDataset(prompt="Test", rubric=rubric)
        assert dataset.criterion_names == ["C1", "Named"]

    def test_num_criteria(self, sample_dataset: RubricDataset):
        """num_criteria returns correct count."""
        assert sample_dataset.num_criteria == 3

    def test_total_positive_weight(self, sample_dataset: RubricDataset):
        """total_positive_weight sums only positive weights."""
        # 10.0 + 5.0 = 15.0 (excludes -3.0)
        assert sample_dataset.total_positive_weight == 15.0


class TestRubricDatasetAddItem:
    """Tests for RubricDataset.add_item()."""

    def test_add_item_without_ground_truth(self, sample_rubric: Rubric):
        """Items without ground truth can be added."""
        dataset = RubricDataset(prompt="Test", rubric=sample_rubric)
        dataset.add_item(text="Text", description="Desc")
        assert len(dataset) == 1
        assert dataset[0].ground_truth is None

    def test_add_item_with_ground_truth(self, sample_rubric: Rubric):
        """Items with ground truth can be added."""
        dataset = RubricDataset(prompt="Test", rubric=sample_rubric)
        verdicts = [
            CriterionVerdict.MET,
            CriterionVerdict.UNMET,
            CriterionVerdict.UNMET,
        ]
        dataset.add_item(text="Text", description="Desc", ground_truth=verdicts)
        assert dataset[0].ground_truth == verdicts

    def test_add_item_rejects_mismatched_ground_truth(self, sample_rubric: Rubric):
        """add_item rejects wrong number of ground truth verdicts."""
        dataset = RubricDataset(prompt="Test", rubric=sample_rubric)
        with pytest.raises(ValueError, match="Ground truth has"):
            dataset.add_item(
                text="Text",
                description="Desc",
                ground_truth=[CriterionVerdict.MET],  # Only 1
            )


class TestRubricDatasetComputeWeightedScore:
    """Tests for RubricDataset.compute_weighted_score()."""

    def test_all_met_normalized(self, sample_dataset: RubricDataset):
        """All MET verdicts (no errors) gives normalized score of 1.0."""
        verdicts = [
            CriterionVerdict.MET,  # +10
            CriterionVerdict.MET,  # +5
            CriterionVerdict.UNMET,  # -3 not applied (UNMET)
        ]
        score = sample_dataset.compute_weighted_score(verdicts, normalize=True)
        # (10 + 5) / 15 = 1.0
        assert score == 1.0

    def test_all_met_with_errors_normalized(self, sample_dataset: RubricDataset):
        """MET error criterion reduces normalized score."""
        verdicts = [
            CriterionVerdict.MET,  # +10
            CriterionVerdict.MET,  # +5
            CriterionVerdict.MET,  # -3 (error present)
        ]
        score = sample_dataset.compute_weighted_score(verdicts, normalize=True)
        # (10 + 5 - 3) / 15 = 0.8
        assert score == pytest.approx(0.8)

    def test_raw_score(self, sample_dataset: RubricDataset):
        """Raw (unnormalized) score is weighted sum."""
        verdicts = [
            CriterionVerdict.MET,  # +10
            CriterionVerdict.UNMET,  # +0
            CriterionVerdict.UNMET,  # +0
        ]
        score = sample_dataset.compute_weighted_score(verdicts, normalize=False)
        assert score == 10.0

    def test_score_clamped_to_zero(self, sample_dataset: RubricDataset):
        """Normalized score is clamped to [0, 1]."""
        verdicts = [
            CriterionVerdict.UNMET,  # +0
            CriterionVerdict.UNMET,  # +0
            CriterionVerdict.MET,  # -3
        ]
        score = sample_dataset.compute_weighted_score(verdicts, normalize=True)
        # (-3) / 15 = -0.2, clamped to 0.0
        assert score == 0.0


class TestRubricDatasetIteration:
    """Tests for RubricDataset iteration and indexing."""

    def test_len(self, sample_dataset: RubricDataset):
        """len() returns number of items."""
        assert len(sample_dataset) == 2

    def test_iter(self, sample_dataset: RubricDataset):
        """Dataset is iterable."""
        items = list(sample_dataset)
        assert len(items) == 2
        assert all(isinstance(item, DataItem) for item in items)

    def test_getitem(self, sample_dataset: RubricDataset):
        """Items can be accessed by index."""
        assert sample_dataset[0].description == "High quality"
        assert sample_dataset[1].description == "Low quality"


class TestRubricDatasetSerialization:
    """Tests for RubricDataset serialization."""

    def test_to_json(self, sample_dataset: RubricDataset):
        """Dataset can be serialized to JSON."""
        json_str = sample_dataset.to_json()
        data = json.loads(json_str)

        assert data["prompt"] == "Explain the topic"
        assert len(data["rubric"]) == 3
        assert len(data["items"]) == 2
        assert data["items"][0]["ground_truth"] == ["MET", "MET", "UNMET"]

    def test_from_json(self, sample_dataset: RubricDataset):
        """Dataset can be deserialized from JSON."""
        json_str = sample_dataset.to_json()
        loaded = RubricDataset.from_json(json_str)

        assert loaded.prompt == sample_dataset.prompt
        assert len(loaded) == len(sample_dataset)
        assert loaded.num_criteria == sample_dataset.num_criteria
        assert loaded[0].ground_truth == sample_dataset[0].ground_truth

    def test_roundtrip_json(self, sample_dataset: RubricDataset):
        """Dataset survives JSON roundtrip."""
        json_str = sample_dataset.to_json()
        loaded = RubricDataset.from_json(json_str)
        json_str2 = loaded.to_json()

        assert json.loads(json_str) == json.loads(json_str2)

    def test_from_json_missing_prompt(self):
        """from_json raises ValueError for missing prompt."""
        with pytest.raises(ValueError, match="Missing required field: 'prompt'"):
            RubricDataset.from_json('{"rubric": []}')

    def test_from_json_missing_rubric(self):
        """from_json raises ValueError for missing rubric."""
        with pytest.raises(ValueError, match="Missing required field: 'rubric'"):
            RubricDataset.from_json('{"prompt": "Test"}')

    def test_from_json_invalid_json(self):
        """from_json raises ValueError for invalid JSON."""
        with pytest.raises(ValueError, match="Failed to parse JSON"):
            RubricDataset.from_json("not valid json")

    def test_from_json_invalid_verdict(self):
        """from_json raises ValueError for invalid verdict."""
        json_str = json.dumps({
            "prompt": "Test",
            "rubric": [{"weight": 1.0, "requirement": "R1"}],
            "items": [
                {
                    "text": "T",
                    "description": "D",
                    "ground_truth": ["INVALID"],
                }
            ],
        })
        with pytest.raises(ValueError, match="invalid verdict"):
            RubricDataset.from_json(json_str)


class TestRubricDatasetFileIO:
    """Tests for RubricDataset file I/O."""

    def test_to_file_and_from_file(self, sample_dataset: RubricDataset):
        """Dataset can be saved and loaded from file."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as f:
            temp_path = Path(f.name)

        try:
            sample_dataset.to_file(temp_path)
            loaded = RubricDataset.from_file(temp_path)

            assert loaded.prompt == sample_dataset.prompt
            assert len(loaded) == len(sample_dataset)
        finally:
            temp_path.unlink()

    def test_from_file_not_found(self):
        """from_file raises FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            RubricDataset.from_file("/nonexistent/path.json")

    def test_from_file_accepts_string_path(self, sample_dataset: RubricDataset):
        """from_file accepts string path."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as f:
            temp_path = f.name

        try:
            sample_dataset.to_file(temp_path)
            loaded = RubricDataset.from_file(temp_path)  # String path
            assert loaded.prompt == sample_dataset.prompt
        finally:
            Path(temp_path).unlink()
