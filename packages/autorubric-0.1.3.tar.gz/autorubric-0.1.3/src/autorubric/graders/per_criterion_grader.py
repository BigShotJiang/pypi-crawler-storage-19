"""Per Criterion grader evaluates each criterion separately in parallel LLM calls."""

import asyncio
import logging
from dataclasses import dataclass, field

from pydantic import ValidationError

from autorubric.graders.base import Grader
from autorubric.llm import GenerateResult, LLMClient, LLMConfig
from autorubric.prompts import GRADER_SYSTEM_PROMPT_DEFAULT, build_user_prompt
from autorubric.types import (
    Criterion,
    CriterionJudgment,
    CriterionReport,
    CriterionVerdict,
    EvaluationReport,
    LengthPenalty,
    TokenUsage,
)

logger = logging.getLogger(__name__)


@dataclass
class CriterionResult:
    """Result from evaluating a single criterion, including usage data."""

    report: CriterionReport
    usage: TokenUsage | None = None
    cost: float | None = None


@dataclass
class JudgeResults:
    """Results from judging all criteria, with aggregated usage data."""

    criterion_results: list[CriterionResult] = field(default_factory=list)

    @property
    def reports(self) -> list[CriterionReport]:
        """Get just the criterion reports."""
        return [r.report for r in self.criterion_results]

    @property
    def total_usage(self) -> TokenUsage | None:
        """Get aggregated token usage across all criteria."""
        usages = [r.usage for r in self.criterion_results if r.usage is not None]
        if not usages:
            return None
        return sum(usages, TokenUsage())

    @property
    def total_cost(self) -> float | None:
        """Get total cost across all criteria."""
        costs = [r.cost for r in self.criterion_results if r.cost is not None]
        if not costs:
            return None
        return sum(costs)


class PerCriterionGrader(Grader):
    """Concrete grader that evaluates each criterion independently.

    Uses structured output with CriterionJudgment for type-safe LLM responses.
    """

    def __init__(
        self,
        llm_config: LLMConfig,
        *,
        system_prompt: str = GRADER_SYSTEM_PROMPT_DEFAULT,
        length_penalty: LengthPenalty | None = None,
        normalize: bool = True,
    ):
        super().__init__(length_penalty=length_penalty, normalize=normalize)
        self.llm_config = llm_config
        self.system_prompt = system_prompt
        self._client = LLMClient(llm_config)

    async def _judge_single_criterion(
        self, criterion: Criterion, to_grade: str, query: str | None = None
    ) -> CriterionResult:
        user_prompt = build_user_prompt(criterion, to_grade, query)

        try:
            # Use return_result=True to get usage and cost data
            result: GenerateResult = await self._client.generate(
                system_prompt=self.system_prompt,
                user_prompt=user_prompt,
                response_format=CriterionJudgment,
                return_result=True,
            )

            # result.parsed contains the CriterionJudgment instance
            judgment: CriterionJudgment = result.parsed

            report = CriterionReport(
                requirement=criterion.requirement,
                verdict=judgment.criterion_status,
                reason=judgment.explanation,
                weight=criterion.weight,
                name=criterion.name,
            )

            return CriterionResult(
                report=report,
                usage=result.usage,
                cost=result.cost,
            )

        except (ValidationError, Exception) as e:
            # Conservative default: assume worst case for each criterion type
            # - Positive criteria: UNMET (requirement not met)
            # - Negative criteria: MET (assume error is present)
            default_verdict = (
                CriterionVerdict.MET if criterion.weight < 0 else CriterionVerdict.UNMET
            )
            logger.warning(
                f"Error evaluating criterion '{criterion.requirement[:50]}...': {e}"
            )
            report = CriterionReport(
                requirement=criterion.requirement,
                verdict=default_verdict,
                reason=f"Error parsing judge response: {str(e)}",
                weight=criterion.weight,
                name=criterion.name,
            )
            # Return with no usage data on error
            return CriterionResult(report=report, usage=None, cost=None)

    async def judge(
        self, to_grade: str, rubric: list[Criterion], query: str | None = None
    ) -> JudgeResults:
        criterion_tasks = [
            self._judge_single_criterion(criterion, to_grade, query)
            for criterion in rubric
        ]
        criterion_results = list(await asyncio.gather(*criterion_tasks))
        return JudgeResults(criterion_results=criterion_results)

    async def aggregate(
        self, judge_results: JudgeResults, *, normalize: bool = True
    ) -> EvaluationReport:
        # Extract reports from judge results
        reports = judge_results.reports

        total_positive_weight = sum(max(0.0, report.weight) for report in reports)
        total_negative_weight = sum(
            abs(report.weight) for report in reports if report.weight < 0
        )
        weighted_score_sum = sum(
            (1.0 if report.verdict == CriterionVerdict.MET else 0.0) * report.weight
            for report in reports
        )

        raw_score = weighted_score_sum

        if normalize:
            if total_positive_weight > 0:
                score = max(0.0, min(1.0, weighted_score_sum / total_positive_weight))
            elif total_negative_weight > 0:
                # All-negative rubric: score starts at 1.0, errors (MET) subtract from it
                # weighted_score_sum is <= 0 for all-negative rubrics
                # Formula: 1.0 + (negative_sum / total_negative) gives 1.0 when no errors, 0.0 when all errors
                score = max(
                    0.0, min(1.0, 1.0 + weighted_score_sum / total_negative_weight)
                )
            else:
                score = 0.0
        else:
            score = raw_score

        return EvaluationReport(
            score=score,
            raw_score=raw_score,
            llm_raw_score=raw_score,  # Same as raw_score for per-criterion graders
            report=reports,
            token_usage=judge_results.total_usage,
            completion_cost=judge_results.total_cost,
        )
