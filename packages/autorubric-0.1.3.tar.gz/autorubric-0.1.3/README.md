# AutoRubric

A Python library for evaluating text outputs against weighted criteria using LLM-as-a-judge.

---

<p align="center">
  <a href="https://pypi.org/project/autorubric/">
    <img src="https://img.shields.io/pypi/v/autorubric" alt="PyPI version" />
  </a>
  <a href="https://pypi.org/project/autorubric/">
    <img src="https://img.shields.io/pypi/pyversions/autorubric" alt="Python versions" />
  </a>
  <a href="https://github.com/delip/autorubric/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License" />
  </a>
</p>

## Installation

```bash
uv add autorubric
```

or

```bash
pip install autorubric
```

## Quick Start

```python
import asyncio
from autorubric import Rubric, LLMConfig
from autorubric.graders import PerCriterionGrader

async def main():
    # Configure LLM (model is required)
    grader = PerCriterionGrader(LLMConfig(model="openai/gpt-4.1-mini"))

    # Build rubric for evaluating Li-ion battery cathode material comparison
    rubric = Rubric.from_dict([
        {"weight": 10.0, "requirement": "States NMC cell-level energy density in the 250-300 Wh/kg range"},
        {"weight": 8.0, "requirement": "Identifies LFP thermal runaway threshold (~270°C) as higher than NMC (~210°C)"},
        {"weight": 6.0, "requirement": "States LFP cycle life advantage (2000-5000 cycles vs 1000-2000 for NMC)"},
        {"weight": -15.0, "requirement": "Incorrectly claims LFP has higher gravimetric energy density than NMC"}
    ])

    # Grade a technical response
    result = await rubric.grade(
        to_grade="""NMC cathodes (LiNixMnyCozO2) achieve 250-280 Wh/kg at the cell level,
        while LFP (LiFePO4) typically reaches 150-205 Wh/kg. However, LFP offers superior
        thermal stability with decomposition onset at ~270°C compared to ~210°C for NMC,
        and delivers 2000-5000 charge cycles versus 1000-2000 for NMC.""",
        grader=grader,
        query="Compare NMC and LFP cathode materials for EV battery applications.",
    )

    print(f"Score: {result.score:.2f}")  # Score is 0.0-1.0
    for criterion in result.report:
        print(f"  [{criterion.verdict}] {criterion.requirement}")
        print(f"    -> {criterion.reason}")

asyncio.run(main())
```

## LLM Configuration

AutoRubric uses [LiteLLM](https://docs.litellm.ai/) under the hood, providing access to 100+ LLM providers with a unified interface.

### Supported Providers

| Provider | Model Format | Environment Variable |
|----------|-------------|---------------------|
| OpenAI | `openai/gpt-4.1`, `openai/gpt-4.1-mini` | `OPENAI_API_KEY` |
| Anthropic | `anthropic/claude-sonnet-4-5-20250929`, `anthropic/claude-opus-4-5-20251101` | `ANTHROPIC_API_KEY` |
| Google | `gemini/gemini-2.5-flash`, `gemini/gemini-2.5-pro` | `GEMINI_API_KEY` |
| Azure OpenAI | `azure/openai/gpt-4.1` | `AZURE_API_KEY`, `AZURE_API_BASE` |
| Groq | `groq/llama-3.1-70b-versatile` | `GROQ_API_KEY` |
| Ollama | `ollama/qwen3:14b`, `ollama/llama3` | (local, no key needed) |

See the [LiteLLM Provider Documentation](https://docs.litellm.ai/docs/providers) for the full list of supported providers.

### Environment Variables

Set API keys for your chosen provider:

```bash
# OpenAI
export OPENAI_API_KEY=your_key_here

# Anthropic
export ANTHROPIC_API_KEY=your_key_here

# Google
export GEMINI_API_KEY=your_key_here

# Azure OpenAI
export AZURE_API_KEY=your_key_here
export AZURE_API_BASE=https://your-resource.openai.azure.com

# Groq
export GROQ_API_KEY=your_key_here
```

AutoRubric automatically loads environment variables from `.env` files.

## LLMConfig Options

`LLMConfig` is the central configuration class for LLM calls:

```python
from autorubric import LLMConfig

config = LLMConfig(
    # REQUIRED - Model identifier in LiteLLM format
    model="openai/gpt-4.1-mini",

    # Sampling parameters
    temperature=0.0,           # 0.0 = deterministic (default)
    max_tokens=1024,           # Maximum tokens in response
    top_p=None,                # Nucleus sampling parameter

    # Request handling
    timeout=60.0,              # Request timeout in seconds
    max_retries=3,             # Retry attempts for transient failures

    # Response caching (diskcache-based)
    cache_enabled=False,       # Enable response caching
    cache_dir=".autorubric_cache",  # Cache directory
    cache_ttl=None,            # Cache TTL in seconds (None = no expiration)

    # Thinking/Reasoning (unified across providers)
    thinking=None,             # "low", "medium", "high", or token budget (e.g., 32000)
    prompt_caching=True,       # Anthropic prompt caching (enabled by default)
    seed=None,                 # OpenAI reproducibility seed

    # Advanced options
    api_key=None,              # Override environment variable
    api_base=None,             # Custom API endpoint
    extra_headers={},          # Additional HTTP headers
    extra_params={},           # Additional provider-specific parameters
)
```

## YAML Configuration

Load LLM configuration from YAML files for easier management:

```yaml
# llm_config.yaml
model: openai/gpt-4.1
temperature: 0.0
max_tokens: 1024
cache_enabled: true
cache_ttl: 3600
```

```python
from autorubric import LLMConfig
from autorubric.graders import PerCriterionGrader

config = LLMConfig.from_yaml("llm_config.yaml")
grader = PerCriterionGrader(config)
```

You can also save configurations:

```python
config = LLMConfig(model="openai/gpt-4.1", temperature=0.0)
config.to_yaml("llm_config.yaml")
```

## Grading Strategy

### PerCriterionGrader

Evaluates each criterion in **parallel LLM calls**. This is the recommended approach for accurate, detailed evaluations.

```python
from autorubric import LLMConfig
from autorubric.graders import PerCriterionGrader

grader = PerCriterionGrader(
    LLMConfig(model="openai/gpt-4.1-mini"),
    system_prompt="Optional custom system prompt",  # Override default
)
```

**How it works:**
- Makes one LLM call per criterion concurrently via `asyncio.gather()`
- Returns detailed `CriterionReport` for each criterion with verdict and explanation
- Computes weighted score from individual verdicts

**Scoring Formula:**

For each criterion $i$:

- If verdict = MET, contribution = $w_i$
- If verdict = UNMET, contribution = 0

Final score:

$$
\text{score} = \max\left(0, \min\left(1, \frac{\sum_{i=1}^{n} \mathbb{1}[\text{verdict}_i = \text{MET}] \cdot w_i}{\sum_{i=1}^{n} \max(0, w_i)}\right)\right)
$$

## Provider-Specific Features

### Extended Thinking/Reasoning

Enable step-by-step reasoning for complex evaluations (works across providers):

```python
from autorubric import LLMConfig
from autorubric.graders import PerCriterionGrader

# Level-based (cross-provider)
grader = PerCriterionGrader(
    LLMConfig(
        model="anthropic/claude-sonnet-4-5-20250929",
        thinking="high",  # "low", "medium", "high", or "none"
    )
)

# Token budget (for fine-grained control)
grader = PerCriterionGrader(
    LLMConfig(
        model="anthropic/claude-opus-4-5-20251101",
        thinking=32000,  # Explicit token budget
    )
)
```

When `thinking` is enabled, the LLM reasons step-by-step before responding. The thinking trace is available in structured output types via the `reasoning` field. Supported providers: Anthropic (Claude), OpenAI (o-series), Gemini (2.5+), DeepSeek.

### Prompt Caching

Reduce latency and cost on repeated calls with the same system prompt. This is **enabled by default** for supported providers:

```python
grader = PerCriterionGrader(
    LLMConfig(
        model="anthropic/claude-sonnet-4-5-20250929",
        prompt_caching=True,  # Default: enabled
    )
)
```

For Anthropic models, LLMClient automatically adds `cache_control` to the system message and includes the appropriate beta header.

### OpenAI Reproducibility

Use a seed for reproducible outputs:

```python
grader = PerCriterionGrader(
    LLMConfig(
        model="openai/gpt-4.1",
        seed=42,  # Fixed seed for reproducibility
    )
)
```

## Response Caching

AutoRubric uses [diskcache](https://grantjenks.com/docs/diskcache/) for efficient, thread-safe response caching:

```python
from autorubric import LLMConfig
from autorubric.graders import PerCriterionGrader

grader = PerCriterionGrader(
    LLMConfig(
        model="openai/gpt-4.1-mini",
        cache_enabled=True,          # Enable caching
        cache_dir=".autorubric_cache",  # Cache directory
        cache_ttl=3600,              # 1 hour TTL (None = no expiration)
    )
)

# The grader uses an LLMClient internally
# For direct client access:
from autorubric import LLMClient, LLMConfig

client = LLMClient(LLMConfig(model="openai/gpt-4.1-mini", cache_enabled=True))

# Cache management
client.clear_cache()       # Clear all cached responses
stats = client.cache_stats()  # Get cache statistics
# {'size': 1024, 'count': 10, 'directory': '.autorubric_cache'}
```

Cache keys are generated from model, system prompt, user prompt, and response format, ensuring identical requests return cached responses.

## Structured Outputs

AutoRubric uses Pydantic models for type-safe LLM responses. The grader automatically handles JSON parsing and validation:

```python
from autorubric import CriterionJudgment  # Single criterion judgment

# CriterionJudgment contains:
# - criterion_status: CriterionVerdict (MET or UNMET)
# - explanation: str (why the criterion was met or not)
# - reasoning: str | None (thinking trace when thinking is enabled)
```

This type is used internally by the grader but is exported for custom implementations.

## Score Fields

The `EvaluationReport` returned by `rubric.grade()` contains several score fields:

| Field | Description |
|-------|-------------|
| `score` | Final score (0-1 if normalized, raw weighted sum if `normalize=False`) |
| `raw_score` | Weighted sum before normalization |
| `llm_raw_score` | Same as raw_score (for consistency) |
| `report` | Per-criterion breakdown with verdicts and explanations |
| `error` | Error message if grading failed (e.g., JSON parse error). Filter these in training. |
| `token_usage` | Aggregated token usage across all LLM calls (see Usage Tracking section) |
| `completion_cost` | Total cost in USD for all LLM calls (see Usage Tracking section) |

## Usage Tracking

AutoRubric automatically tracks token usage and completion cost for all grading operations using LiteLLM's built-in usage tracking.

### Accessing Usage Data

The `EvaluationReport` includes `token_usage` and `completion_cost` fields:

```python
import asyncio
from autorubric import Rubric, LLMConfig
from autorubric.graders import PerCriterionGrader

async def main():
    grader = PerCriterionGrader(LLMConfig(model="openai/gpt-4.1-mini"))
    rubric = Rubric.from_dict([
        {"weight": 10.0, "requirement": "States the correct answer"},
        {"weight": 5.0, "requirement": "Provides clear explanation"},
    ])

    result = await rubric.grade(
        to_grade="The answer is 42 because...",
        grader=grader,
    )

    print(f"Score: {result.score:.2f}")

    # Access token usage
    if result.token_usage:
        print(f"Prompt tokens: {result.token_usage.prompt_tokens}")
        print(f"Completion tokens: {result.token_usage.completion_tokens}")
        print(f"Total tokens: {result.token_usage.total_tokens}")

    # Access completion cost
    if result.completion_cost:
        print(f"Cost: ${result.completion_cost:.6f}")

asyncio.run(main())
```

### TokenUsage Fields

The `TokenUsage` dataclass contains:

| Field | Description |
|-------|-------------|
| `prompt_tokens` | Number of tokens in the prompt/input |
| `completion_tokens` | Number of tokens in the completion/output |
| `total_tokens` | Total tokens (prompt + completion) |
| `cache_creation_input_tokens` | Tokens used to create cache entries (Anthropic) |
| `cache_read_input_tokens` | Tokens read from cache (Anthropic) |

### Aggregating Usage Across Multiple Grading Operations

For batch grading, use the helper functions to aggregate usage:

```python
import asyncio
from autorubric import (
    Rubric, LLMConfig, TokenUsage,
    aggregate_token_usage, aggregate_completion_cost, aggregate_evaluation_usage
)
from autorubric.graders import PerCriterionGrader

async def batch_grade_with_usage():
    grader = PerCriterionGrader(LLMConfig(model="openai/gpt-4.1-mini"))
    rubric = Rubric.from_file("rubric.yaml")

    responses = ["Response 1...", "Response 2...", "Response 3..."]

    # Grade all responses
    tasks = [rubric.grade(to_grade=r, grader=grader) for r in responses]
    results = await asyncio.gather(*tasks)

    # Aggregate usage and cost
    total_usage, total_cost = aggregate_evaluation_usage(results)

    if total_usage:
        print(f"Total tokens used: {total_usage.total_tokens}")
    if total_cost:
        print(f"Total cost: ${total_cost:.4f}")

    # Or aggregate manually
    usages = [r.token_usage for r in results]
    costs = [r.completion_cost for r in results]

    total_usage = aggregate_token_usage(usages)
    total_cost = aggregate_completion_cost(costs)
```

### Cost Calculation

Completion cost is calculated using LiteLLM's `completion_cost()` function, which has built-in pricing data for all supported providers. The cost is in USD.

**Note:** Cost calculation may return `None` if:
- The provider doesn't report usage data
- The model's pricing is not in LiteLLM's database
- An error occurs during calculation

## Length Penalty

Length penalty discourages excessively verbose outputs during evaluation. It is configured on the **grader constructor** and is subtracted from the score after grading.

### Configuration

```python
from autorubric import LengthPenalty

penalty = LengthPenalty(
    free_budget=6000,        # No penalty below this count
    max_cap=8000,            # Maximum penalty at/above this count
    penalty_at_cap=0.5,      # Max penalty to subtract from score
    exponent=1.6,            # Curve steepness (higher = more lenient near budget)
    count_fn=None,           # Custom counting function (default: word count)
    penalty_type="ALL",      # Which sections to count: "ALL", "OUTPUT_ONLY", "THINKING_ONLY"
)
```

### Usage

```python
from autorubric import Rubric, LLMConfig, LengthPenalty
from autorubric.graders import PerCriterionGrader

rubric = Rubric.from_file("rubric.yaml")

# With length penalty
grader = PerCriterionGrader(
    LLMConfig(model="openai/gpt-4.1-mini"),
    length_penalty=LengthPenalty()
)
result = await rubric.grade(to_grade=response, grader=grader)

# With custom tokenizer
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained("gpt2")

grader = PerCriterionGrader(
    LLMConfig(model="openai/gpt-4.1-mini"),
    length_penalty=LengthPenalty(
        free_budget=8000,
        max_cap=10000,
        count_fn=lambda t: len(tokenizer.encode(t))
    )
)
result = await rubric.grade(to_grade=response, grader=grader)
```

### Penalty Formula

```
if count <= free_budget:
    penalty = 0
elif count >= max_cap:
    penalty = penalty_at_cap
else:
    frac = (count - free_budget) / (max_cap - free_budget)
    penalty = penalty_at_cap * (frac ** exponent)

final_score = max(0.0, base_score - penalty)
```

## Thinking/Output Token Support

For models that generate thinking/reasoning steps separately from final output (e.g., Claude with extended thinking), you can apply length penalties to specific sections.

### Input Formats

```python
# Dict format (explicit)
await rubric.grade(
    to_grade={
        "thinking": "Let me reason through this step by step...",
        "output": "The final answer is 42"
    },
    grader=grader
)

# String with markers (auto-parsed)
await rubric.grade(
    to_grade="<thinking>My reasoning process...</thinking><output>Final answer</output>",
    grader=grader
)

# Plain string (backwards compatible)
await rubric.grade(to_grade="Just a regular response", grader=grader)  # Treated as all output
```

### Penalty Type Selection

```python
penalty = LengthPenalty(
    free_budget=8000,
    max_cap=10000,
    penalty_at_cap=0.5,
    penalty_type="OUTPUT_ONLY"  # Options: "ALL", "OUTPUT_ONLY", "THINKING_ONLY"
)
```

- `"ALL"` - Count both thinking and output tokens (default)
- `"OUTPUT_ONLY"` - Only count output tokens (useful for RL training to allow long reasoning)
- `"THINKING_ONLY"` - Only count thinking tokens

## Training / RL Use Cases

For reinforcement learning training, normalized 0-1 scores can make optimization difficult. Use `normalize=False` to get raw weighted sums:

```python
from autorubric import Rubric, LLMConfig, LengthPenalty
from autorubric.graders import PerCriterionGrader
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("your-model")

grader = PerCriterionGrader(
    LLMConfig(model="openai/gpt-4.1-mini"),
    normalize=False,  # Return raw weighted sums
    length_penalty=LengthPenalty(
        free_budget=8000,
        max_cap=10000,
        penalty_at_cap=50.0,  # Absolute penalty for raw scores
        exponent=1.6,
        count_fn=lambda text: len(tokenizer.encode(text, add_special_tokens=False))
    )
)

rubric = Rubric.from_file("rubric.yaml")
result = await rubric.grade(to_grade=response, grader=grader)

# result.score = raw weighted sum - length penalty
# result.raw_score = raw weighted sum (before length penalty)
```

### Batch Processing

```python
import asyncio

async def compute_rewards_batch(
    responses: list[str],
    rubrics: list[Rubric],
    grader: PerCriterionGrader,
    queries: list[str] | None = None,
) -> list[float]:
    tasks = []
    for i, (response, rubric) in enumerate(zip(responses, rubrics)):
        query = queries[i] if queries else None
        tasks.append(rubric.grade(to_grade=response, grader=grader, query=query))

    results = await asyncio.gather(*tasks)
    return [r.score for r in results]
```

### Key Differences from Normalized Mode

| Aspect | Normalized (default) | Training (normalize=False) |
|--------|---------------------|---------------------------|
| Score range | 0.0 to 1.0 | Can be negative or > 1 |
| Length penalty | Fractional (e.g., 0.5) | Absolute (e.g., 50.0) |
| Clamping | Score clamped to [0, 1] | No clamping |
| Use case | Evaluation, reporting | RL reward signals |

## Loading Rubrics

```python
from autorubric import Rubric, Criterion

# Direct construction (with optional name field)
rubric = Rubric([
    Criterion(name="margin", weight=10.0, requirement="States Q4 2023 base margin as 17.2%"),
    Criterion(name="attribution", weight=8.0, requirement="Explicitly uses Shapley attribution for decomposition"),
    Criterion(name="error_deliveries", weight=-15.0, requirement="Uses total deliveries instead of cash-only deliveries")
])

# From list of dictionaries (name field is optional)
rubric = Rubric.from_dict([
    {"name": "margin", "weight": 10.0, "requirement": "States Q4 2023 base margin as 17.2%"},
    {"name": "attribution", "weight": 8.0, "requirement": "Explicitly uses Shapley attribution for decomposition"},
    {"weight": -15.0, "requirement": "Uses total deliveries instead of cash-only deliveries"}  # name is optional
])

# From JSON string
rubric = Rubric.from_json('[{"weight": 10.0, "requirement": "Example requirement"}]')

# From YAML string
yaml_data = '''
- weight: 10.0
  requirement: "Example requirement"
'''
rubric = Rubric.from_yaml(yaml_data)

# From files
rubric = Rubric.from_file('rubric.json')
rubric = Rubric.from_file('rubric.yaml')
```

### JSON Format

```json
[
  {
    "name": "margin",
    "weight": 10.0,
    "requirement": "States Q4 2023 base margin as 17.2%"
  },
  {
    "name": "attribution",
    "weight": 8.0,
    "requirement": "Explicitly uses Shapley attribution for decomposition"
  },
  {
    "weight": -15.0,
    "requirement": "Uses total deliveries instead of cash-only deliveries"
  }
]
```

Note: The `name` field is optional. When provided, it can be used to reference criteria in reports.

### YAML Format

```yaml
- name: margin        # Optional identifier
  weight: 10.0
  requirement: "States Q4 2023 base margin as 17.2%"
- name: attribution
  weight: 8.0
  requirement: "Explicitly uses Shapley attribution for decomposition"
- weight: -15.0       # name is optional
  requirement: "Uses total deliveries instead of cash-only deliveries"
```

### Sectioned Format

You can organize criteria into sections for better readability:

```yaml
# rubric.yaml with sections
rubric:
  sections:
    - name: "Accuracy"
      criteria:
        - weight: 10.0
          requirement: "States the correct answer"
        - weight: 5.0
          requirement: "Provides supporting evidence"
    - name: "Errors"
      criteria:
        - weight: -15.0
          requirement: "Contains factual errors"
```

Or as a JSON object:

```json
{
  "rubric": {
    "sections": [
      {
        "name": "Accuracy",
        "criteria": [
          {"weight": 10.0, "requirement": "States the correct answer"}
        ]
      }
    ]
  }
}
```

Criteria from all sections are flattened during evaluation.

## Error Handling

### Parse Failure Behavior

When the LLM returns invalid JSON or the response cannot be parsed, the grader uses **conservative defaults** to avoid biasing scores:

| Criterion Type | Default Verdict | Rationale |
|---------------|-----------------|-----------|-
| Positive (weight > 0) | UNMET | Assume requirement not met |
| Negative (weight < 0) | MET | Assume error is present |

This ensures parse failures result in worst-case scores rather than artificially inflating results.

## Dataset Support

AutoRubric provides classes for organizing evaluation datasets with ground truth labels:

```python
from autorubric import Rubric, Criterion, CriterionVerdict, DataItem, RubricDataset

# Create a rubric
rubric = Rubric([
    Criterion(name="Accuracy", weight=10.0, requirement="Factually correct"),
    Criterion(name="Clarity", weight=5.0, requirement="Clear and concise"),
])

# Create a dataset
dataset = RubricDataset(
    prompt="Explain photosynthesis",
    rubric=rubric,
)

# Add items with ground truth
dataset.add_item(
    text="Photosynthesis is the process by which plants convert sunlight...",
    description="Good response",
    ground_truth=[CriterionVerdict.MET, CriterionVerdict.MET]
)

# Serialize to JSON
json_str = dataset.to_json()
dataset.to_file("dataset.json")

# Load from JSON
loaded = RubricDataset.from_json(json_str)
loaded = RubricDataset.from_file("dataset.json")

# Compute scores from verdicts
score = dataset.compute_weighted_score(
    [CriterionVerdict.MET, CriterionVerdict.UNMET],
    normalize=True
)
```

## Public Exports

```python
from autorubric import (
    # Dataset classes
    DataItem,
    RubricDataset,

    # LLM Infrastructure
    GenerateResult,
    LLMClient,
    LLMConfig,
    ThinkingConfig,
    ThinkingLevel,
    ThinkingLevelLiteral,
    ThinkingParam,
    generate,

    # Core types
    Rubric,
    Criterion,
    CriterionJudgment,
    CriterionReport,
    CriterionVerdict,
    EvaluationReport,
    LengthPenalty,
    CountFn,
    TokenUsage,

    # Thinking/output support
    PenaltyType,
    ThinkingOutputDict,
    ToGradeInput,

    # Utility functions
    aggregate_completion_cost,
    aggregate_evaluation_usage,
    aggregate_token_usage,
    compute_length_penalty,
    normalize_to_grade_input,
    parse_thinking_output,
    word_count,
)

from autorubric.graders import (
    Grader,
    PerCriterionGrader,
)
```

## Requirements

- Python 3.10+
- [LiteLLM](https://docs.litellm.ai/) for multi-provider LLM support
- [diskcache](https://grantjenks.com/docs/diskcache/) for response caching
- [Pydantic](https://docs.pydantic.dev/) for structured outputs
- [tenacity](https://tenacity.readthedocs.io/) for retry logic

## License

MIT License - see LICENSE file for details.
