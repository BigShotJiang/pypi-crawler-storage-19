def parent(idx):
    return idx // 2

class MaxHeap:
    def __init__(self, external_array=None):
        if external_array is None:
            self.arr = []
        else:
            self.arr = external_array
            # We only need to fix from the second layer up
            # since the bottom layer is all "singletons"
            # (i.e. a subheap with just one node is always valid.)
            for i in range(len(self.arr) // 2 - 1, -1, -1):
                self.fix(i)

    def __repr__(self):
        return str(self.arr)

    def swap_at(self, l, r):
        self.arr[l], self.arr[r] = self.arr[r], self.arr[l]

    def fix(self, idx):
        l = 2 * idx + 1
        r = 2 * idx + 2

        # Find the index of the max of:
        # (arr[idx], arr[l], arr[r])
        max_idx = idx
        if l < len(self.arr) and self.arr[l] > self.arr[max_idx]:
            max_idx = l
        if r < len(self.arr) and self.arr[r] > self.arr[max_idx]:
            max_idx = r

        if idx != max_idx:
            # Resolve violation.
            self.swap_at(idx, max_idx)
            self.fix(max_idx)

    def pop(self):
        if len(self.arr) == 0:
            raise Exception('Cannot pop from an empty heap.')
        max_element = self.arr[0]
        # Move last element to front.
        self.arr[0] = self.arr.pop()

        # Resolve heap violations.
        self.fix(0)
        return max_element

    def max(self):
        if len(self.arr) == 0:
            raise Exception('Heap is empty.')
        return self.arr[0]

    # Redundant, just wanted another way of spelling it.
    def top(self):
        return self.max()

    def push(self, val):
        idx = len(self.arr)
        self.arr.append(val)
        while self.arr[idx] > self.arr[parent(idx)]:
            self.swap_at(idx, parent(idx))
            idx = parent(idx)

class MinHeap:
    def __init__(self, external_array=None):
        if external_array is None:
            self.arr = []
        else:
            self.arr = external_array
            # We only need to fix from the second layer up
            # since the bottom layer is all "singletons"
            # (i.e. a subheap with just one node is always valid.)
            for i in range(len(self.arr) // 2 - 1, -1, -1):
                self.fix(i)

    def __repr__(self):
        return str(self.arr)

    def swap_at(self, l, r):
        self.arr[l], self.arr[r] = self.arr[r], self.arr[l]

    def fix(self, idx):
        l = 2 * idx + 1
        r = 2 * idx + 2

        # Find the index of the max of:
        # (arr[idx], arr[l], arr[r])
        min_idx = idx
        if l < len(self.arr) and self.arr[l] < self.arr[min_idx]:
            min_idx = l
        if r < len(self.arr) and self.arr[r] < self.arr[min_idx]:
            min_idx = r

        if idx != min_idx:
            self.swap_at(idx, min_idx)
            self.fix(min_idx)

    def pop(self):
        if len(self.arr) == 0:
            raise Exception('Cannot pop from an empty heap.')
        max_element = self.arr[0]
        # Move last element to front.
        self.arr[0] = self.arr.pop()

        # Resolve heap violations.
        self.fix(0)
        return max_element

    def min(self):
        return self.arr[0]

    # Redundant, just wanted another way of spelling it.
    def top(self):
        return self.min()

    def push(self, val):
        idx = len(self.arr)
        self.arr.append(val)
        while self.arr[idx] < self.arr[parent(idx)]:
            # Resolve violation.
            self.swap_at(idx, parent(idx))
            idx = parent(idx)