version = "3.0.2"
"""software version"""
