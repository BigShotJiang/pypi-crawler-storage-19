"""Script runner for executing Playwright scripts."""

from __future__ import annotations

import asyncio
import re
import time
from typing import Any

import structlog
from playwright.async_api import Page

from nova_agent.settings import get_settings

logger = structlog.get_logger(__name__)

# 위험한 패턴 목록 (정규식)
# Runner가 생성한 스크립트만 실행되어야 하지만, 추가 안전장치로 검증
# NOTE: 패턴은 단독 호출만 차단 (메서드 체인의 .open() 등은 허용)
DANGEROUS_PATTERNS = [
    r"\bimport\s+os\b",
    r"\bimport\s+sys\b",
    r"\bimport\s+subprocess\b",
    r"\bimport\s+shutil\b",
    r"\bfrom\s+os\b",
    r"\bfrom\s+sys\b",
    r"\bfrom\s+subprocess\b",
    r"\bfrom\s+shutil\b",
    r"\b__import__\s*\(",
    r"\beval\s*\(",
    r"\bexec\s*\(",
    r"\bcompile\s*\(",
    r"(?<![.\w])open\s*\(",  # 단독 open() 호출만 차단, .open()은 허용
    r"(?<![.\w])os\.",  # 단독 os. 만 차단
    r"(?<![.\w])sys\.",  # 단독 sys. 만 차단
    r"\bsubprocess\.",
    r"\bshutil\.",
    r"\b__builtins__\b",
    r"\b__globals__\b",
    r"\b__code__\b",
    r"\bgetattr\s*\(",
    r"\bsetattr\s*\(",
    r"\bdelattr\s*\(",
]

# 컴파일된 패턴
DANGEROUS_PATTERN_RE = re.compile("|".join(DANGEROUS_PATTERNS), re.IGNORECASE)


class ScriptValidationError(Exception):
    """스크립트 검증 실패 예외."""

    pass


class ScriptRunner:
    """Playwright 스크립트 실행기.

    Runner가 생성한 Playwright 스크립트를 실행합니다.

    Responsibilities:
        1. 스크립트 파싱 및 검증
        2. 스크립트 실행
        3. 실행 결과 반환
    """

    def __init__(self, page: Page) -> None:
        """Initialize script runner.

        Args:
            page: Playwright 페이지
        """
        self._page = page

    async def run(self, script: str, timeout: int | None = None) -> dict[str, Any]:
        """스크립트 실행.

        Args:
            script: 실행할 Playwright 스크립트
            timeout: 타임아웃 (초). None이면 설정값 사용

        Returns:
            실행 결과:
            - success: 성공 여부
            - error: 에러 메시지 (실패 시)
            - duration_ms: 실행 시간 (밀리초)
            - timed_out: 타임아웃 여부
        """
        settings = get_settings()
        execution_timeout = timeout if timeout is not None else settings.script_timeout

        logger.debug(
            "running_script",
            script_length=len(script),
            timeout_seconds=execution_timeout,
        )
        start_time = time.time()

        try:
            # 스크립트 실행 (타임아웃 적용)
            # 스크립트는 page를 사용하는 Python 코드
            # exec()를 사용하여 실행하되, 안전한 환경에서 실행
            await asyncio.wait_for(
                self._execute_script(script),
                timeout=execution_timeout,
            )

            duration_ms = int((time.time() - start_time) * 1000)
            logger.info("script_executed_successfully", duration_ms=duration_ms)

            return {
                "success": True,
                "duration_ms": duration_ms,
            }

        except asyncio.TimeoutError:
            duration_ms = int((time.time() - start_time) * 1000)
            error_msg = f"Script execution timed out after {execution_timeout} seconds"
            logger.error(
                "script_execution_timeout",
                timeout_seconds=execution_timeout,
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": error_msg,
                "duration_ms": duration_ms,
                "timed_out": True,
            }

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(
                "script_execution_failed",
                error=str(e),
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": str(e),
                "duration_ms": duration_ms,
            }

    def _validate_script(self, script: str) -> None:
        """스크립트 보안 검증.

        위험한 패턴이 포함되어 있는지 검사합니다.
        Runner가 생성한 스크립트만 실행되어야 하지만,
        추가 안전장치로 검증합니다.

        Args:
            script: 검증할 스크립트

        Raises:
            ScriptValidationError: 위험한 패턴 발견 시
        """
        match = DANGEROUS_PATTERN_RE.search(script)
        if match:
            dangerous_code = match.group()
            logger.warning(
                "dangerous_script_pattern_detected",
                pattern=dangerous_code,
                script_preview=script[:200] if len(script) > 200 else script,
            )
            raise ScriptValidationError(
                f"Script contains potentially dangerous code: '{dangerous_code}'"
            )

    async def _execute_script(self, script: str) -> None:
        """스크립트 실행 (내부).

        Args:
            script: 실행할 스크립트

        Raises:
            ScriptValidationError: 위험한 스크립트 감지 시
            Exception: 실행 실패 시
        """
        # 보안 검증
        self._validate_script(script)

        # 스크립트 실행 컨텍스트 설정
        # page 객체만 제공하고 위험한 builtins는 제한
        # NOTE: 완전한 샌드박스가 아님 - 추가 보안이 필요한 경우 RestrictedPython 사용 권장
        local_vars: dict[str, Any] = {
            "page": self._page,
        }

        # async 스크립트 실행을 위한 래퍼
        # 스크립트가 await를 포함할 수 있으므로 async 함수로 래핑
        wrapped_script = f"""
async def __run_script__():
{self._indent_script(script)}

__result__ = __run_script__()
"""

        # 스크립트 컴파일 및 실행
        exec(wrapped_script, local_vars)

        # 비동기 함수 실행
        coro = local_vars.get("__result__")
        if coro:
            await coro

    def _indent_script(self, script: str) -> str:
        """스크립트 들여쓰기.

        Args:
            script: 원본 스크립트

        Returns:
            4칸 들여쓰기된 스크립트
        """
        lines = script.split("\n")
        indented = ["    " + line for line in lines]
        return "\n".join(indented)

    async def run_action(
        self,
        action: str,
        selector: str | None = None,
        value: str | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """단일 액션 실행.

        스크립트 대신 간단한 액션을 직접 실행합니다.

        Args:
            action: 액션 타입 (click, fill, select, etc.)
            selector: CSS 선택자
            value: 입력값 (fill, select 등)
            timeout: 타임아웃 (초). None이면 설정값 사용

        Returns:
            실행 결과
        """
        settings = get_settings()
        execution_timeout = timeout if timeout is not None else settings.action_timeout

        logger.debug(
            "running_action",
            action=action,
            selector=selector,
            value=value,
            timeout_seconds=execution_timeout,
        )
        start_time = time.time()

        try:
            await asyncio.wait_for(
                self._execute_action(action, selector, value),
                timeout=execution_timeout,
            )

            duration_ms = int((time.time() - start_time) * 1000)
            logger.info(
                "action_executed_successfully",
                action=action,
                duration_ms=duration_ms,
            )

            return {
                "success": True,
                "duration_ms": duration_ms,
            }

        except asyncio.TimeoutError:
            duration_ms = int((time.time() - start_time) * 1000)
            error_msg = f"Action '{action}' timed out after {execution_timeout} seconds"
            logger.error(
                "action_execution_timeout",
                action=action,
                timeout_seconds=execution_timeout,
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": error_msg,
                "duration_ms": duration_ms,
                "timed_out": True,
            }

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(
                "action_execution_failed",
                action=action,
                error=str(e),
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": str(e),
                "duration_ms": duration_ms,
            }

    async def _execute_action(
        self,
        action: str,
        selector: str | None = None,
        value: str | None = None,
    ) -> None:
        """액션 실행 (내부).

        Args:
            action: 액션 타입
            selector: CSS 선택자
            value: 입력값

        Raises:
            ValueError: 알 수 없는 액션
            Exception: 실행 실패 시
        """
        if action == "click" and selector:
            await self._page.click(selector)
        elif action == "fill" and selector and value is not None:
            await self._page.fill(selector, value)
        elif action == "select" and selector and value is not None:
            await self._page.select_option(selector, value)
        elif action == "check" and selector:
            await self._page.check(selector)
        elif action == "uncheck" and selector:
            await self._page.uncheck(selector)
        elif action == "hover" and selector:
            await self._page.hover(selector)
        elif action == "press" and value:
            await self._page.keyboard.press(value)
        elif action == "type" and value:
            await self._page.keyboard.type(value)
        elif action == "wait":
            wait_ms = int(value) if value else 1000
            await self._page.wait_for_timeout(wait_ms)
        elif action == "goto" and value:
            await self._page.goto(value)
        else:
            raise ValueError(f"Unknown action: {action}")
