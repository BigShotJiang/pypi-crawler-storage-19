import os
import requests

class TFAuth:
    def __init__(self):
        # API настройки (ТВОИ КЛЮЧИ)
        self.TAPI = None
        self.GAPI = ""
        self.FAPI = ""
        
        # Ссылка на RAW файл (ТВОЯ ФИКСИРОВАННАЯ ВЕРСИЯ)
        self.GITHUB_KEYS_URL = "https://raw.githubusercontent.com/TLETIFORMAT/apifs/ad181080e15c98116d839ab15f0c54214d1259bf/main/APIKEYS.json"
        
        # Настройки дизайна (ТВОЙ ДИЗАЙН)
        self.color1 = "#ff416c"
        self.color2 = "#4b6cb7"
        
        # Ссылки и БД
        self.db = "database.txt"
        self.forgotpassword = "forgotpassword.html"
        self.successlogin = "successl.html"
        self.sucessregister = "successr.html"

    def _check_access(self):
        """Проверка доступа через GitHub"""
        if not self.TAPI:
            print("[TFAuth] Error: TAPI is not set!")
            return False
        try:
            res = requests.get(self.GITHUB_KEYS_URL, timeout=5)
            if res.status_code == 200:
                allowed_keys = res.json()
                return str(self.TAPI).strip() in allowed_keys
            return False
        except:
            return False

    def generate_html(self):
        # Проверка доступа
        if not self._check_access():
            return f"""<body style='background:#000;color:red;display:flex;justify-content:center;align-items:center;height:100vh;font-family:sans-serif;'>
                <div style='text-align:center;'>
                    <h1>403 ACCESS DENIED</h1>
                    <p>Invalid TAPI Key: {self.TAPI}</p>
                </div>
            </body>"""

        # ПОЛНЫЙ ИНТЕРФЕЙС: Дизайн + GAPI + FAPI + Register
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Auth System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, {self.color1} 0%, {self.color2} 100%);
            height: 100vh; display: flex; align-items: center; justify-content: center;
        }}
        .card {{
            background: #fff; width: 380px; padding: 40px; border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2); text-align: center;
        }}
        h2 {{ margin-bottom: 25px; color: #333; }}
        .input-group {{ text-align: left; margin-bottom: 20px; border-bottom: 2px solid #eee; }}
        .input-group label {{ font-size: 12px; color: #888; font-weight: 600; }}
        .field {{ display: flex; align-items: center; padding: 10px 0; }}
        .field i {{ color: {self.color2}; margin-right: 12px; }}
        .field input {{ border: none; outline: none; width: 100%; font-size: 14px; }}
        .btn {{
            width: 100%; padding: 12px; border: none; border-radius: 25px;
            background: linear-gradient(to right, {self.color1}, {self.color2});
            color: white; font-weight: bold; cursor: pointer; transition: 0.3s; margin: 10px 0;
        }}
        .social-icons {{ display: flex; justify-content: center; gap: 15px; margin: 20px 0; }}
        .social-icons a {{
            width: 40px; height: 40px; border-radius: 50%; display: flex;
            align-items: center; justify-content: center; color: white; text-decoration: none;
        }}
        .fb {{ background: #3b5998; }} .gp {{ background: #db4437; }}
        .toggle-link {{ font-size: 13px; color: #666; cursor: pointer; }}
        .toggle-link b {{ color: {self.color1}; }}
        .hidden {{ display: none; }}
    </style>
</head>
<body>
    <div class="card">
        <div id="login-form">
            <h2>Login</h2>
            <div class="input-group"><label>Username</label><div class="field"><i class="fa fa-user"></i><input type="text" placeholder="Username"></div></div>
            <div class="input-group"><label>Password</label><div class="field"><i class="fa fa-lock"></i><input type="password" placeholder="Password"></div></div>
            <a href="{self.forgotpassword}" style="float:right; font-size:11px; color:#999; text-decoration:none;">Forgot?</a>
            <button class="btn" onclick="location.href='{self.successlogin}'">LOGIN</button>
            <p style="font-size:12px; color:#666; margin-top:20px;">Or Login With</p>
            <div class="social-icons">
                <a href="https://facebook.com/dialog/oauth?client_id={self.FAPI}" class="fb"><i class="fab fa-facebook-f"></i></a>
                <a href="https://accounts.google.com/o/oauth2/v2/auth?client_id={self.GAPI}" class="gp"><i class="fab fa-google"></i></a>
            </div>
            <p class="toggle-link" onclick="toggle()">New here? <b>Sign Up</b></p>
        </div>

        <div id="register-form" class="hidden">
            <h2>Register</h2>
            <div class="input-group"><label>Email</label><div class="field"><i class="fa fa-envelope"></i><input type="email"></div></div>
            <div class="input-group"><label>Username</label><div class="field"><i class="fa fa-user"></i><input type="text"></div></div>
            <div class="input-group"><label>Password</label><div class="field"><i class="fa fa-lock"></i><input type="password"></div></div>
            <button class="btn" onclick="location.href='{self.sucessregister}'">SIGN UP</button>
            <p class="toggle-link" onclick="toggle()">Already have account? <b>Login</b></p>
        </div>
    </div>
    <script>
        function toggle() {{
            document.getElementById('login-form').classList.toggle('hidden');
            document.getElementById('register-form').classList.toggle('hidden');
        }}
    </script>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.generate_html())
        print(f"[TFAuth] Success! File '{filename}' is ready.")
