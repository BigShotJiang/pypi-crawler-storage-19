# server.py
import sys

# ruff: noqa: E402, I001

# Python version check - must be at the very beginning
MIN_PY = (3, 11)
if sys.version_info < MIN_PY:
    sys.stderr.write(
        f"ERROR: STYLY NetSync Server requires Python {MIN_PY[0]}.{MIN_PY[1]}+ "
        f"(current: {sys.version.split()[0]}).\n"
    )
    sys.exit(1)

import argparse
import base64
import json
import logging
import os
import platform
import socket
import threading
import time
import traceback
from functools import lru_cache
from pathlib import Path
from queue import Empty, Full, Queue
from typing import Any, TYPE_CHECKING

try:
    import resource
except Exception:
    resource = None  # type: ignore[assignment]

import zmq
from loguru import logger
from . import binary_serializer
from . import network_utils
from .logging_utils import configure_logging

if TYPE_CHECKING:
    from uvicorn import Server

DEFAULT_DEALER_PORT = 5555
DEFAULT_PUB_PORT = 5556
DEFAULT_SERVER_DISCOVERY_PORT = 9999
DEFAULT_SERVER_NAME = "STYLY-NetSync-Server"


def valid_port(value: str) -> int:
    """Return a validated TCP/UDP port number."""
    try:
        port = int(value)
    except ValueError as exc:  # pragma: no cover - argparse handles messaging
        raise argparse.ArgumentTypeError("Port must be an integer") from exc

    if not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError("Port must be between 1 and 65535")

    return port


@lru_cache(maxsize=1)
def get_version() -> str:
    """
    Return the server version.
    Priority (updated for development mode support):
      1) parse pyproject.toml if in development mode (editable install)
      2) importlib.metadata for 'styly-netsync-server' (when installed normally)
      3) 'unknown'
    """
    # Python 3.11+ guaranteed, so we can use these imports directly
    import importlib.metadata as im
    import tomllib

    # Helper function to detect development mode
    def is_development_mode() -> bool:
        """Detect if package is installed in development mode (pip install -e .)"""
        try:
            dist = im.distribution("styly-netsync-server")
            # Development installs typically have .egg-link or direct path references
            if hasattr(dist, "files") and dist.files:
                # Check if any file path contains 'site-packages' - normal install
                # vs direct source paths - development install
                for file in list(dist.files)[:5]:  # Check first few files
                    if file and "site-packages" not in str(file):
                        return True
            return False
        except im.PackageNotFoundError:
            return False  # If not found in metadata, not development mode

    # 1) For development mode, prioritize pyproject.toml
    if is_development_mode():
        for parent in Path(__file__).resolve().parents:
            toml_path = parent / "pyproject.toml"
            if toml_path.exists():
                try:
                    data = tomllib.loads(toml_path.read_text(encoding="utf-8"))
                    v = (data.get("project") or {}).get("version")
                    if v:
                        return v
                except (tomllib.TOMLDecodeError, OSError, UnicodeDecodeError):
                    # Continue to next fallback if TOML parsing fails
                    pass
                break

    # 2) Try installed package metadata
    try:
        return im.version("styly-netsync-server")
    except im.PackageNotFoundError:
        # Fallback: reverse lookup from package name to distribution
        for dist in im.packages_distributions().get("styly_netsync", []):
            try:
                return im.version(dist)
            except im.PackageNotFoundError:
                pass

    # 3) Final fallback - parse pyproject.toml (for cases where dev mode detection failed)
    for parent in Path(__file__).resolve().parents:
        toml_path = parent / "pyproject.toml"
        if toml_path.exists():
            try:
                data = tomllib.loads(toml_path.read_text(encoding="utf-8"))
                v = (data.get("project") or {}).get("version")
                if v:
                    return v
            except (tomllib.TOMLDecodeError, OSError, UnicodeDecodeError):
                pass
            break

    return "unknown"


class NetSyncServer:
    # Performance and timing constants
    BASE_BROADCAST_INTERVAL = 0.1  # 10Hz base rate
    IDLE_BROADCAST_INTERVAL = 0.5  # 2Hz when idle
    DIRTY_THRESHOLD = 0.05  # 20Hz max rate when very active
    BROADCAST_CHECK_INTERVAL = 0.05  # Check broadcasts every 50ms
    CLEANUP_INTERVAL = 1.0  # Cleanup every 1 second
    STATUS_LOG_INTERVAL = 10.0  # Log status every 10 seconds
    MAIN_LOOP_SLEEP = 0.02  # 50Hz main loop sleep
    CLIENT_TIMEOUT = 1.0  # 1 second timeout for client disconnect
    DEVICE_ID_EXPIRY_TIME = (
        300.0  # 5 minutes - remove device ID mappings after this time
    )
    POLL_TIMEOUT = 100  # ZMQ poll timeout in ms
    ROUTER_BACKLOG = 512  # Accept queue depth for DEALER/ROUTER connections
    PUB_BACKLOG = 512  # Accept queue depth for SUB connections
    DEFAULT_FD_LIMIT = 4096
    ID_MAPPING_DEBOUNCE_INTERVAL = 0.5  # Debounce ID mapping broadcasts (500ms)

    def __init__(
        self,
        dealer_port: int = DEFAULT_DEALER_PORT,
        pub_port: int = DEFAULT_PUB_PORT,
        enable_server_discovery: bool = True,
        server_discovery_port: int = DEFAULT_SERVER_DISCOVERY_PORT,
        server_name: str = DEFAULT_SERVER_NAME,
    ):
        self.dealer_port = dealer_port
        self.pub_port = pub_port
        self.context = zmq.Context()

        # Server discovery settings
        self.enable_server_discovery = enable_server_discovery
        self.server_discovery_port = server_discovery_port
        self.server_name = server_name
        self.server_discovery_socket = None
        self.server_discovery_thread = None
        self.server_discovery_running = False

        # TCP server discovery settings
        self.tcp_server_discovery_socket = None
        self.tcp_server_discovery_thread = None
        self.tcp_server_discovery_running = False

        # Sockets
        self.router = None
        self.pub = None  # Will be created/owned by Publisher thread only

        # Publisher thread infrastructure
        self._pub_queue = Queue(maxsize=10000)  # tuneable
        self._publisher_thread = None
        self._publisher_running = False
        self._pub_ready = threading.Event()  # signaled after successful bind
        self._publisher_exception = None  # bind/run errors are stored here

        # PUB socket monitor for tracking SUB connections
        self._pub_monitor = None
        self._pub_monitor_thread = None
        self._sub_connection_count = 0
        self._sub_connection_lock = threading.Lock()

        # Latest-only coalescing buffer for high-rate topics (e.g., room transforms)
        self._coalesce_lock = threading.Lock()
        # topic_bytes -> message_bytes (keep only the most-recent per topic)
        self._coalesce_latest: dict[bytes, bytes] = {}

        # Thread-safe room management with locks
        self.rooms: dict[str, dict[str, Any]] = (
            {}
        )  # room_id -> {device_id: {client_data}}
        self.room_dirty_flags: dict[str, bool] = (
            {}
        )  # Track which rooms have changed data
        self.room_last_broadcast: dict[str, float] = (
            {}
        )  # Track last broadcast time per room
        self.client_binary_cache: dict[str, bytes] = (
            {}
        )  # Cache client_no -> binary data

        # Client number management per room
        self.room_client_no_counters: dict[str, int] = {}  # room_id -> next_client_no
        self.room_device_id_to_client_no: dict[str, dict[str, int]] = (
            {}
        )  # room_id -> {device_id: client_no}
        self.room_client_no_to_device_id: dict[str, dict[int, str]] = (
            {}
        )  # room_id -> {client_no: device_id}
        self.device_id_last_seen: dict[str, float] = (
            {}
        )  # device_id -> last_seen_timestamp

        # ID Mapping broadcast debouncing
        self.room_id_mapping_dirty: dict[str, bool] = (
            {}
        )  # room_id -> needs ID mapping broadcast
        self.room_last_id_mapping_broadcast: dict[str, float] = (
            {}
        )  # room_id -> last broadcast timestamp

        # Network Variables storage
        self.global_variables: dict[str, dict[str, Any]] = (
            {}
        )  # room_id -> {var_name: {value, timestamp, lastWriterClientNo}}
        self.client_variables: dict[str, dict[int, dict[str, Any]]] = (
            {}
        )  # room_id -> {client_no -> {var_name: {value, timestamp, lastWriterClientNo}}}

        # NV Pending buffers for coalescing (latest-wins per key)
        self.pending_global_nv: dict[str, dict[str, tuple]] = (
            {}
        )  # room_id -> {var_name: (sender_client_no, value, timestamp)}
        self.pending_client_nv: dict[str, dict[tuple, tuple]] = (
            {}
        )  # room_id -> {(target_client_no, var_name): (sender_client_no, value, timestamp)}

        # NV flush cadence configuration
        self.nv_flush_interval = 0.05  # 50ms flush cadence
        self.room_last_nv_flush: dict[str, float] = {}  # room_id -> last_flush_time

        # NV monitoring window (1s sliding window for logging only)
        self.nv_monitor_window: dict[str, list] = {}  # room_id -> [timestamps]
        self.nv_monitor_window_size = 1.0  # 1 second window
        self.nv_monitor_threshold = 200  # Log warning if > 200 NV req/s

        # Network Variables limits
        self.MAX_GLOBAL_VARS = 100
        self.MAX_CLIENT_VARS = 100
        self.MAX_VAR_NAME_LENGTH = 64
        self.MAX_VAR_VALUE_LENGTH = 1024

        # Thread synchronization
        self._rooms_lock = threading.RLock()  # Reentrant lock for nested access
        self._stats_lock = threading.Lock()  # Lock for statistics

        # Threading
        self.running = False
        self.receive_thread = None
        self.periodic_thread = None  # Combined broadcast + cleanup

        # Performance configuration (now using constants)
        self.base_broadcast_interval = self.BASE_BROADCAST_INTERVAL
        self.idle_broadcast_interval = self.IDLE_BROADCAST_INTERVAL
        self.dirty_threshold = self.DIRTY_THRESHOLD

        # Statistics
        self.message_count = 0
        self.broadcast_count = 0
        self.skipped_broadcasts = 0

        # REST bridge lifecycle
        self._rest_thread: threading.Thread | None = None
        self._rest_server: Server | None = None

    def _increment_stat(self, stat_name: str, amount: int = 1):
        """Thread-safe increment of statistics"""
        with self._stats_lock:
            setattr(self, stat_name, getattr(self, stat_name) + amount)

    def _bump_fd_soft_limit(self, target: int):
        """Best-effort bump of RLIMIT_NOFILE for macOS/Linux."""
        if resource is None:
            logger.info(
                "Skipping FD soft limit bump: 'resource' module not available on this platform."
            )
            return

        try:
            soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            new_soft = min(max(soft, target), hard)
            if new_soft != soft:
                resource.setrlimit(resource.RLIMIT_NOFILE, (new_soft, hard))
            else:
                logger.info(
                    "FD limits already sufficient (soft=%d, hard=%d)", soft, hard
                )
        except Exception as exc:
            logger.warning("Failed to raise RLIMIT_NOFILE: %s", exc)

    def _get_fd_snapshot(self) -> tuple[int | None, int | None, int | None]:
        """
        Best-effort snapshot of:
          - open_fds: current process open FD count
          - soft/hard: RLIMIT_NOFILE
        """
        soft: int | None = None
        hard: int | None = None
        if resource is not None:
            try:
                soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
            except Exception:
                pass

        open_fds: int | None = None
        # macOS: /dev/fd is available. Linux often has it too.
        try:
            open_fds = len(os.listdir("/dev/fd"))
        except Exception:
            # fallback (Linux /proc)
            try:
                open_fds = len(os.listdir(f"/proc/{os.getpid()}/fd"))
            except Exception:
                pass

        return open_fds, soft, hard

    def _pub_monitor_loop(self):
        """Monitor PUB socket for SUB connection/disconnection events."""
        from zmq.utils.monitor import recv_monitor_message

        try:
            while self._publisher_running and self._pub_monitor is not None:
                try:
                    # Poll with timeout to allow checking _publisher_running
                    if self._pub_monitor.poll(100):
                        msg = recv_monitor_message(self._pub_monitor)
                        event = msg["event"]
                        if event == zmq.EVENT_ACCEPTED:
                            with self._sub_connection_lock:
                                self._sub_connection_count += 1
                                count = self._sub_connection_count
                            logger.info(f"SUB connected (total: {count})")
                        elif event == zmq.EVENT_DISCONNECTED:
                            with self._sub_connection_lock:
                                self._sub_connection_count = max(
                                    0, self._sub_connection_count - 1
                                )
                                count = self._sub_connection_count
                            logger.info(f"SUB disconnected (total: {count})")
                except zmq.ZMQError as e:
                    logger.debug("PUB monitor ZMQError: %s", e)
                    break
        except Exception as e:
            logger.error(f"PUB monitor error: {e}")
        finally:
            if self._pub_monitor is not None:
                try:
                    self._pub_monitor.close()
                except Exception:
                    pass
                self._pub_monitor = None

    def _get_sub_connection_count(self) -> int:
        """Get current number of connected SUB sockets."""
        with self._sub_connection_lock:
            return self._sub_connection_count

    def _publisher_loop(self):
        """The only place that owns/uses self.pub and performs ZMQ sends."""
        try:
            # Create/bind PUB in this thread to avoid cross-thread use
            self.pub = self.context.socket(zmq.PUB)
            try:
                self.pub.setsockopt(zmq.BACKLOG, self.PUB_BACKLOG)
            except Exception:
                pass
            try:
                self.pub.setsockopt(zmq.SNDHWM, 10000)
            except Exception:
                # Best effort; ignore if high-water mark option is unsupported
                pass
            self.pub.bind(f"tcp://*:{self.pub_port}")

            # Set up socket monitor for tracking SUB connections
            self._pub_monitor = self.pub.get_monitor_socket(
                zmq.EVENT_ACCEPTED | zmq.EVENT_DISCONNECTED
            )
            self._pub_monitor_thread = threading.Thread(
                target=self._pub_monitor_loop, name="PubMonitor", daemon=True
            )
            self._pub_monitor_thread.start()

            self._pub_ready.set()

            while self._publisher_running:
                # 1) Flush coalesced (latest-only) topics first
                try:
                    with self._coalesce_lock:
                        coalesced_items = list(self._coalesce_latest.items())
                        self._coalesce_latest.clear()
                except Exception:
                    coalesced_items = []

                for topic_bytes, message_bytes in coalesced_items:
                    try:
                        self.pub.send_multipart([topic_bytes, message_bytes])
                        self._increment_stat("broadcast_count")
                    except Exception as e:
                        logger.error(f"Publisher failed to send (coalesced): {e}")

                # 2) Then handle normal queue (RPC / NV etc.)
                try:
                    item = self._pub_queue.get(timeout=0.05)
                except Empty:
                    continue

                # Sentinel for shutdown
                if not item or item[0] is None:
                    break

                topic_bytes, message_bytes = item

                try:
                    self.pub.send_multipart([topic_bytes, message_bytes])
                    # Count only *actual* sends
                    self._increment_stat("broadcast_count")
                except Exception as e:
                    logger.error(f"Publisher failed to send: {e}")

        except Exception as e:
            # On bind or loop failure, publish the exception and wake starters
            self._publisher_exception = e
            self._pub_ready.set()
            logger.error(f"Publisher error during startup/run: {e}")
        finally:
            self._publisher_running = False
            if self._pub_monitor_thread:
                self._pub_monitor_thread.join(timeout=1.0)
                self._pub_monitor_thread = None
            if self.pub is not None:
                try:
                    self.pub.close()
                except Exception:
                    pass
                self.pub = None
            logger.info("Publisher loop ended")

    def _enqueue_pub(self, topic_bytes: bytes, message_bytes: bytes):
        """Thread-safe enqueue of a broadcast for reliable/low-rate messages (RPC/NV).
        Backpressure policy: drop the oldest item (ring buffer) to prefer newer updates.
        """
        try:
            self._pub_queue.put_nowait((topic_bytes, message_bytes))
        except Full:
            # Ring-buffer behavior: remove oldest then enqueue latest
            try:
                _ = self._pub_queue.get_nowait()
            except Empty:
                pass
            try:
                self._pub_queue.put_nowait((topic_bytes, message_bytes))
            except Full:
                # If still full, count as skipped
                self._increment_stat("skipped_broadcasts")
                logger.debug("PUB queue full: dropping a message")

    def _get_or_assign_client_no(self, room_id: str, device_id: str) -> int:
        """Get existing client number or assign a new one for the given device ID in the room"""
        with self._rooms_lock:
            # Initialize room structures if needed
            self._initialize_room(room_id)

            # Update last seen time
            self.device_id_last_seen[device_id] = time.monotonic()

            # Check if device ID already has a client number in this room
            if device_id in self.room_device_id_to_client_no[room_id]:
                return self.room_device_id_to_client_no[room_id][device_id]

            # Assign new client number
            client_no = self.room_client_no_counters[room_id]
            if client_no > 65535:  # Max value for 2 bytes
                # Find and reuse expired client numbers
                client_no = self._find_reusable_client_no(room_id)
                if client_no == -1:
                    raise ValueError(
                        f"Room {room_id} has exhausted all available client numbers"
                    )
            else:
                self.room_client_no_counters[room_id] += 1

            # Store mappings
            self.room_device_id_to_client_no[room_id][device_id] = client_no
            self.room_client_no_to_device_id[room_id][client_no] = device_id

            logger.info(
                f"Assigned client number {client_no} to device ID {device_id[:8]}... in room {room_id}"
            )
            return client_no

    def _initialize_room(self, room_id: str):
        """Initialize all room-related data structures"""
        if room_id not in self.rooms:
            self.rooms[room_id] = {}
            self.room_dirty_flags[room_id] = True
            self.room_last_broadcast[room_id] = 0
            self.room_client_no_counters[room_id] = 1
            self.room_device_id_to_client_no[room_id] = {}
            self.room_client_no_to_device_id[room_id] = {}

            # Initialize Network Variables for the room
            self.global_variables[room_id] = {}
            self.client_variables[room_id] = {}

            # Initialize NV pending buffers
            self.pending_global_nv[room_id] = {}
            self.pending_client_nv[room_id] = {}
            self.room_last_nv_flush[room_id] = 0

            # Initialize monitoring window
            self.nv_monitor_window[room_id] = []

            logger.info(f"Created new room: {room_id}")

    def _get_device_id_from_identity(self, client_identity: bytes, room_id: str) -> str:
        """Get device ID from client identity"""
        with self._rooms_lock:
            if room_id in self.rooms:
                for device_id, client_data in self.rooms[room_id].items():
                    if client_data.get("identity") == client_identity:
                        return device_id
        return None

    def _get_client_no_for_device_id(self, room_id: str, device_id: str) -> int:
        """Get client number for a given device ID in a room"""
        with self._rooms_lock:
            if room_id in self.room_device_id_to_client_no:
                return self.room_device_id_to_client_no[room_id].get(device_id, 0)
        return 0

    def _find_reusable_client_no(self, room_id: str) -> int:
        """Find a client number that can be reused (from expired device IDs)"""
        current_time = time.monotonic()

        # Check all client numbers in the room
        for client_no, device_id in list(
            self.room_client_no_to_device_id[room_id].items()
        ):
            if device_id not in self.device_id_last_seen:
                # Device ID has no last seen time, can reuse
                del self.room_client_no_to_device_id[room_id][client_no]
                del self.room_device_id_to_client_no[room_id][device_id]
                return client_no

            if (
                current_time - self.device_id_last_seen[device_id]
                > self.DEVICE_ID_EXPIRY_TIME
            ):
                # Device ID has expired, can reuse
                del self.room_client_no_to_device_id[room_id][client_no]
                del self.room_device_id_to_client_no[room_id][device_id]
                del self.device_id_last_seen[device_id]
                return client_no

        return -1  # No reusable client number found

    def _cleanup_expired_device_id_mappings(self, current_time):
        """Clean up expired device ID to client number mappings"""
        with self._rooms_lock:
            expired_device_ids = []

            # Find expired device IDs
            for device_id, last_seen in list(self.device_id_last_seen.items()):
                if current_time - last_seen > self.DEVICE_ID_EXPIRY_TIME:
                    expired_device_ids.append(device_id)

            # Remove expired mappings
            for device_id in expired_device_ids:
                del self.device_id_last_seen[device_id]

                # Remove from all room mappings
                for room_id in list(self.room_device_id_to_client_no.keys()):
                    if device_id in self.room_device_id_to_client_no[room_id]:
                        client_no = self.room_device_id_to_client_no[room_id][device_id]
                        del self.room_device_id_to_client_no[room_id][device_id]
                        if client_no in self.room_client_no_to_device_id[room_id]:
                            del self.room_client_no_to_device_id[room_id][client_no]
                        logger.info(
                            f"Cleaned up expired device ID {device_id[:8]}... (client number: {client_no}) from room {room_id}"
                        )

            if expired_device_ids:
                logger.info(
                    f"Cleaned up {len(expired_device_ids)} expired device ID mappings"
                )

    def start(self, ip_addresses: list[str] | None = None):
        """Start the server"""
        try:
            # Raise FD soft limit early to avoid connection drops when many clients connect
            self._bump_fd_soft_limit(self.DEFAULT_FD_LIMIT)

            # Setup ROUTER socket
            self.router = self.context.socket(zmq.ROUTER)
            # Increase accept backlog to survive connection stampedes from simulators
            try:
                self.router.setsockopt(zmq.BACKLOG, self.ROUTER_BACKLOG)
            except Exception:
                # Best effort; fall back to default backlog if unsupported
                pass
            try:
                self.router.setsockopt(zmq.RCVHWM, 10000)
            except Exception:
                # Best effort; ignore if high-water mark option is unsupported
                pass
            self.router.bind(f"tcp://*:{self.dealer_port}")

            # Start Publisher thread (it creates/binds PUB)
            self._publisher_running = True
            self._publisher_thread = threading.Thread(
                target=self._publisher_loop, name="PublisherThread", daemon=True
            )
            self._publisher_thread.start()

            # Wait for PUB bind or failure
            if not self._pub_ready.wait(timeout=5.0):
                raise RuntimeError(
                    "Timed out waiting for Publisher thread to bind PUB socket"
                )
            if self._publisher_exception:
                # Clean up and re-raise the failure so callers get a proper error
                if self.router:
                    self.router.close()
                self.context.term()
                raise self._publisher_exception

            self.running = True

            # Start other threads
            self.receive_thread = threading.Thread(
                target=self._receive_loop, name="ReceiveThread"
            )
            self.periodic_thread = threading.Thread(
                target=self._periodic_loop, name="PeriodicThread"
            )

            self.receive_thread.start()
            self.periodic_thread.start()

            # Start server discovery if enabled
            if self.enable_server_discovery:
                self._start_server_discovery()

            try:
                from .rest_bridge import create_app, run_uvicorn_in_thread

                app = create_app(
                    server_addr="tcp://127.0.0.1",
                    dealer_port=self.dealer_port,
                    sub_port=self.pub_port,
                )
                rest_port = int(os.getenv("NETSYNC_REST_PORT", "8800"))
                self._rest_thread, self._rest_server = run_uvicorn_in_thread(
                    app, host="0.0.0.0", port=rest_port
                )
                display_ip = ip_addresses[0] if ip_addresses else "0.0.0.0"
                logger.info(f"REST bridge started on http://{display_ip}:{rest_port}")
                # Display logo after all initialization is complete
                display_logo()
            except Exception as rest_exc:
                logger.error(f"Failed to start REST bridge: {rest_exc}")

            logger.info("Server is ready and waiting for connections...")

        except zmq.error.ZMQError as e:
            if "Address already in use" in str(e) or "Address in use" in str(e):
                logger.error(
                    f"Error: Another server instance is already running on port {self.dealer_port}"
                )
                logger.error(
                    "Please stop the existing server before starting a new one."
                )

                # Provide platform-specific instructions
                if platform.system() == "Windows":
                    logger.error(
                        f"You can find the process using: netstat -ano | findstr :{self.dealer_port}"
                    )
                    logger.error("And stop it using: taskkill /PID <PID> /F")
                else:
                    logger.error(
                        f"You can find the process using: lsof -i :{self.dealer_port}"
                    )
                    logger.error("And stop it using: kill <PID>")

                # Clean up sockets if partially created
                if self.router:
                    self.router.close()
                self.context.term()
                raise SystemExit(1) from e
            else:
                logger.error(f"ZMQ Error: {e}")
                raise
        except Exception as e:
            logger.error(f"Failed to start server: {e}")
            logger.error(traceback.format_exc())
            raise

    def stop(self):
        """Stop the server"""
        logger.info("Stopping server...")
        self.running = False

        # Stop server discovery
        if self.server_discovery_running:
            self._stop_server_discovery()

        if self._rest_server is not None:
            try:
                self._rest_server.should_exit = True
            except Exception as rest_exc:  # pragma: no cover - defensive
                logger.debug("Failed to signal REST bridge shutdown: %s", rest_exc)
        if self._rest_thread and self._rest_thread.is_alive():
            self._rest_thread.join(timeout=2.0)
        self._rest_thread = None
        self._rest_server = None

        if self.receive_thread:
            self.receive_thread.join()
            logger.info("Receive thread stopped")
        if self.periodic_thread:
            self.periodic_thread.join()
            logger.info("Periodic thread stopped")

        # Stop Publisher thread
        self._publisher_running = False
        try:
            self._pub_queue.put_nowait((None, None))  # sentinel
        except Full:
            # Best-effort to make room, then send sentinel
            try:
                _ = self._pub_queue.get_nowait()
            except Empty:
                pass
            try:
                self._pub_queue.put_nowait((None, None))
            except Full:
                pass
        if self._publisher_thread:
            self._publisher_thread.join()
            logger.info("Publisher thread stopped")

        if self.router:
            self.router.close()
        if self.context:
            self.context.term()

        logger.info(
            f"Server stopped. Total messages processed: {self.message_count}, "
            f"Broadcasts sent: {self.broadcast_count}, Skipped broadcasts: {self.skipped_broadcasts}"
        )

    def _receive_loop(self):
        """Receive messages from clients"""
        while self.running:
            try:
                # Check for incoming messages
                if self.router.poll(self.POLL_TIMEOUT, zmq.POLLIN):
                    # Receive multipart message [identity, room_id, message]
                    parts = self.router.recv_multipart()
                    self._increment_stat("message_count")

                    if len(parts) >= 3:
                        client_identity = parts[0]
                        room_id_bytes = parts[1]
                        message_bytes = parts[2]
                        try:
                            room_id = room_id_bytes.decode("utf-8")
                        except UnicodeDecodeError as e:
                            logger.error(f"Failed to decode room ID: {e}")
                            continue
                        # Try binary first, fallback to JSON for compatibility
                        try:
                            msg_type, data, raw_payload = binary_serializer.deserialize(
                                message_bytes
                            )
                            if msg_type == binary_serializer.MSG_CLIENT_TRANSFORM:
                                self._handle_client_transform(
                                    client_identity, room_id, data, raw_payload
                                )
                            elif msg_type == binary_serializer.MSG_RPC:
                                # Get sender's client number from client identity
                                sender_device_id = self._get_device_id_from_identity(
                                    client_identity, room_id
                                )
                                if sender_device_id:
                                    sender_client_no = (
                                        self._get_client_no_for_device_id(
                                            room_id, sender_device_id
                                        )
                                    )
                                    data["senderClientNo"] = sender_client_no
                                # Send RPC to room excluding sender
                                self._send_rpc_to_room(room_id, data)
                            # MSG_RPC_SERVER and MSG_RPC_CLIENT are reserved for future use
                            elif msg_type == binary_serializer.MSG_GLOBAL_VAR_SET:
                                # Buffer global variable set request (no rate limit drops)
                                self._buffer_global_var_set(room_id, data)
                                self._monitor_nv_sliding_window(room_id)
                            elif msg_type == binary_serializer.MSG_CLIENT_VAR_SET:
                                # Buffer client variable set request (no rate limit drops)
                                self._buffer_client_var_set(room_id, data)
                                self._monitor_nv_sliding_window(room_id)
                            else:
                                logger.warning(f"Unknown binary msg_type: {msg_type}")
                        except Exception:
                            # Fallback to JSON for backward compatibility
                            try:
                                message = message_bytes.decode("utf-8")
                                self._process_message(client_identity, room_id, message)
                            except UnicodeDecodeError as e:
                                logger.error(f"Failed to decode message: {e}")

                    else:
                        logger.warning(
                            f"Received incomplete message with only {len(parts)} parts"
                        )

            except Exception as e:
                logger.error(f"Error in receive loop: {e}")
                logger.error(traceback.format_exc())

        logger.info("Receive loop ended")

    def _process_message(self, client_identity: bytes, room_id: str, message: str):
        """Process incoming client message"""
        try:
            msg_data = json.loads(message)
            msg_type = msg_data.get("type")
            data_str = msg_data.get("data", "{}")
            data = json.loads(data_str) if data_str else {}

            # Process client transform messages (support both enum and string formats)
            if msg_type in [0, "ClientTransform", "client_transform"]:
                self._handle_client_transform(client_identity, room_id, data)
            # JSON-based RPC broadcast
            elif msg_type in ["Rpc", "rpc"]:
                logger.info(f"JSON RPC received in room {room_id}: {data}")
                self._send_rpc_to_room(room_id, data)
            else:
                logger.warning(f"Unknown message type: {msg_type}")

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON: {e}")
            logger.error(f"Raw message: {message}")
        except Exception as e:
            logger.error(f"Error processing message: {e}")
            logger.error(traceback.format_exc())

    def _handle_client_transform(
        self,
        client_identity: bytes,
        room_id: str,
        data: dict[str, Any],
        raw_payload: bytes = b"",
    ):
        """Handle client transform update"""
        device_id = data.get("deviceId")  # Receiving device ID from client

        # Detect stealth mode using NaN handshake
        is_stealth = binary_serializer._is_stealth_client(data)

        # Get or assign client number for this device ID
        client_no = self._get_or_assign_client_no(room_id, device_id)

        # Create modified data with client number for internal use
        data_with_client_no = data.copy()
        data_with_client_no["clientNo"] = client_no
        data_with_client_no["deviceId"] = device_id  # Keep device ID for reference

        with self._rooms_lock:
            # Create room if it doesn't exist
            self._initialize_room(room_id)

            # Update or create client (using device ID as key for backward compatibility)
            is_new_client = device_id not in self.rooms[room_id]
            if is_new_client:
                self.rooms[room_id][device_id] = {
                    "identity": client_identity,
                    "last_update": time.monotonic(),
                    "transform_data": data_with_client_no,
                    "client_no": client_no,
                    "is_stealth": is_stealth,
                }
                self.room_dirty_flags[room_id] = True  # Mark room as dirty
                # Cache the binary data if available
                if raw_payload:
                    # Store by client number for efficient broadcast
                    self.client_binary_cache[client_no] = raw_payload
                stealth_text = " (stealth mode)" if is_stealth else ""
                logger.info(
                    f"New client {device_id[:8]}... (client number: {client_no}){stealth_text} joined room {room_id}"
                )
            else:
                # Update existing client and mark room as dirty
                self.rooms[room_id][device_id]["transform_data"] = data_with_client_no
                self.rooms[room_id][device_id]["last_update"] = time.monotonic()
                self.rooms[room_id][device_id]["client_no"] = client_no
                self.rooms[room_id][device_id]["is_stealth"] = is_stealth

                # Update cached binary data if available
                if raw_payload:
                    self.client_binary_cache[client_no] = raw_payload

                # Mark room as dirty since transform data has arrived
                self.room_dirty_flags[room_id] = True

            # Mark room for debounced ID mapping broadcast when a new client joins
            if is_new_client:
                self.room_id_mapping_dirty[room_id] = True

        # Sync network variables to new client (outside lock to avoid deadlocks)
        if is_new_client:
            self._sync_network_variables_to_new_client(room_id)

    def _send_rpc_to_room(self, room_id: str, rpc_data: dict[str, Any]):
        """Send RPC to all clients in room except sender"""
        # Log RPC
        sender_client_no = rpc_data.get("senderClientNo", 0)
        function_name = rpc_data.get("functionName", "unknown")
        args = rpc_data.get("args", [])
        logger.info(
            f"RPC: sender={sender_client_no}, function={function_name}, args={args}, room={room_id}"
        )

        # Prepare topic and payload
        topic_bytes = room_id.encode("utf-8")
        message_bytes = binary_serializer.serialize_rpc_message(rpc_data)

        # Send multipart [roomId, payload]
        self._enqueue_pub(topic_bytes, message_bytes)

    def _monitor_nv_sliding_window(self, room_id: str):
        """Monitor NV request rate for logging only (no gating)"""
        current_time = time.monotonic()
        with self._rooms_lock:
            if room_id not in self.nv_monitor_window:
                self.nv_monitor_window[room_id] = []

            window = self.nv_monitor_window[room_id]

            # Add current timestamp
            window.append(current_time)

            # Remove old timestamps outside window
            cutoff_time = current_time - self.nv_monitor_window_size
            self.nv_monitor_window[room_id] = [t for t in window if t > cutoff_time]

            # Check if over threshold and log warning
            if len(self.nv_monitor_window[room_id]) > self.nv_monitor_threshold:
                logger.warning(
                    f"High NV request rate in room {room_id}: {len(self.nv_monitor_window[room_id])} req/s"
                )

    def _buffer_global_var_set(self, room_id: str, data: dict[str, Any]):
        """Buffer global variable set request for later processing"""
        sender_client_no = data.get("senderClientNo", 0)
        var_name = data.get("variableName", "")[: self.MAX_VAR_NAME_LENGTH]
        var_value = data.get("variableValue", "")[: self.MAX_VAR_VALUE_LENGTH]
        timestamp = data.get("timestamp", time.monotonic())

        if not var_name:
            return

        with self._rooms_lock:
            self._initialize_room(room_id)

            # Buffer the update (latest-wins per key)
            self.pending_global_nv[room_id][var_name] = (
                sender_client_no,
                var_value,
                timestamp,
            )

    def _apply_global_var_set(
        self,
        room_id: str,
        sender_client_no: int,
        var_name: str,
        var_value: str,
        timestamp: float,
    ) -> bool:
        """Apply global variable update (used by flush, returns True if applied)"""
        with self._rooms_lock:
            # Check limits
            global_vars = self.global_variables[room_id]
            if var_name not in global_vars and len(global_vars) >= self.MAX_GLOBAL_VARS:
                logger.warning(f"Global variable limit reached in room {room_id}")
                return False

            # Conflict resolution: last-writer-wins with timestamp comparison
            if var_name in global_vars:
                existing = global_vars[var_name]
                # Skip if value unchanged (no-op)
                if existing.get("value") == var_value:
                    return False
                if timestamp < existing["timestamp"] or (
                    timestamp == existing["timestamp"]
                    and sender_client_no < existing["lastWriterClientNo"]
                ):
                    return False  # Ignore older or lower priority update

            # Store old value for logging
            old_value = global_vars.get(var_name, {}).get("value", None)

            # Update variable
            global_vars[var_name] = {
                "value": var_value,
                "timestamp": timestamp,
                "lastWriterClientNo": sender_client_no,
            }

            logger.info(
                f"Global Variable Changed: room={room_id}, client={sender_client_no}, name='{var_name}', old='{old_value}', new='{var_value}'"
            )
            return True

    def _handle_global_var_set(self, room_id: str, data: dict[str, Any]):
        """Handle global variable set request (for backward compat - immediate apply+broadcast)"""
        sender_client_no = data.get("senderClientNo", 0)
        var_name = data.get("variableName", "")[: self.MAX_VAR_NAME_LENGTH]
        var_value = data.get("variableValue", "")[: self.MAX_VAR_VALUE_LENGTH]
        timestamp = data.get("timestamp", time.monotonic())

        if not var_name:
            return

        if self._apply_global_var_set(
            room_id, sender_client_no, var_name, var_value, timestamp
        ):
            # Broadcast sync to all clients
            self._broadcast_global_var_sync(room_id)

    def _buffer_client_var_set(self, room_id: str, data: dict[str, Any]):
        """Buffer client variable set request for later processing"""
        sender_client_no = data.get("senderClientNo", 0)
        target_client_no = data.get("targetClientNo", 0)
        var_name = data.get("variableName", "")[: self.MAX_VAR_NAME_LENGTH]
        var_value = data.get("variableValue", "")[: self.MAX_VAR_VALUE_LENGTH]
        timestamp = data.get("timestamp", time.monotonic())

        if not var_name:
            return

        with self._rooms_lock:
            self._initialize_room(room_id)

            # Buffer the update (latest-wins per key)
            key = (target_client_no, var_name)
            self.pending_client_nv[room_id][key] = (
                sender_client_no,
                var_value,
                timestamp,
            )

    def _apply_client_var_set(
        self,
        room_id: str,
        sender_client_no: int,
        target_client_no: int,
        var_name: str,
        var_value: str,
        timestamp: float,
    ) -> bool:
        """Apply client variable update (used by flush, returns True if applied)"""
        with self._rooms_lock:
            # Initialize client variables for target if needed
            if target_client_no not in self.client_variables[room_id]:
                self.client_variables[room_id][target_client_no] = {}

            client_vars = self.client_variables[room_id][target_client_no]

            # Check limits
            if var_name not in client_vars and len(client_vars) >= self.MAX_CLIENT_VARS:
                logger.warning(
                    f"Client variable limit reached for client {target_client_no} in room {room_id}"
                )
                return False

            # Conflict resolution: last-writer-wins with timestamp comparison
            if var_name in client_vars:
                existing = client_vars[var_name]
                # Skip if value unchanged (no-op)
                if existing.get("value") == var_value:
                    return False
                if timestamp < existing["timestamp"] or (
                    timestamp == existing["timestamp"]
                    and sender_client_no < existing["lastWriterClientNo"]
                ):
                    return False  # Ignore older or lower priority update

            # Store old value for logging
            old_value = client_vars.get(var_name, {}).get("value", None)

            # Update variable
            client_vars[var_name] = {
                "value": var_value,
                "timestamp": timestamp,
                "lastWriterClientNo": sender_client_no,
            }

            logger.info(
                f"Client Variable Changed: room={room_id}, target={target_client_no}, sender={sender_client_no}, name='{var_name}', old='{old_value}', new='{var_value}'"
            )
            return True

    def _handle_client_var_set(self, room_id: str, data: dict[str, Any]):
        """Handle client variable set request (for backward compat - immediate apply+broadcast)"""
        sender_client_no = data.get("senderClientNo", 0)
        target_client_no = data.get("targetClientNo", 0)
        var_name = data.get("variableName", "")[: self.MAX_VAR_NAME_LENGTH]
        var_value = data.get("variableValue", "")[: self.MAX_VAR_VALUE_LENGTH]
        timestamp = data.get("timestamp", time.monotonic())

        if not var_name:
            return

        if self._apply_client_var_set(
            room_id, sender_client_no, target_client_no, var_name, var_value, timestamp
        ):
            # Broadcast sync to all clients
            self._broadcast_client_var_sync(room_id)

    def _broadcast_global_var_sync(self, room_id: str):
        """Broadcast global variables sync to all clients in room"""
        with self._rooms_lock:
            if room_id not in self.global_variables:
                return

            variables = []
            for var_name, var_data in self.global_variables[room_id].items():
                variables.append(
                    {
                        "name": var_name,
                        "value": var_data["value"],
                        "timestamp": var_data["timestamp"],
                        "lastWriterClientNo": var_data["lastWriterClientNo"],
                    }
                )

            if variables:
                topic_bytes = room_id.encode("utf-8")
                message_bytes = binary_serializer.serialize_global_var_sync(
                    {"variables": variables}
                )
                self._enqueue_pub(topic_bytes, message_bytes)
                logger.debug(
                    f"Broadcasted {len(variables)} global variables to room {room_id}"
                )

    def _broadcast_client_var_sync(self, room_id: str):
        """Broadcast client variables sync to all clients in room"""
        with self._rooms_lock:
            if room_id not in self.client_variables:
                return

            client_variables = {}
            for client_no, variables in self.client_variables[room_id].items():
                client_vars = []
                for var_name, var_data in variables.items():
                    client_vars.append(
                        {
                            "name": var_name,
                            "value": var_data["value"],
                            "timestamp": var_data["timestamp"],
                            "lastWriterClientNo": var_data["lastWriterClientNo"],
                        }
                    )
                if client_vars:
                    client_variables[str(client_no)] = client_vars

            if client_variables:
                topic_bytes = room_id.encode("utf-8")
                message_bytes = binary_serializer.serialize_client_var_sync(
                    {"clientVariables": client_variables}
                )
                self._enqueue_pub(topic_bytes, message_bytes)
                logger.debug(
                    f"Broadcasted client variables for {len(client_variables)} clients to room {room_id}"
                )

    def _sync_network_variables_to_new_client(self, room_id: str):
        """Send current Network Variables state to a newly connected client"""
        self._broadcast_global_var_sync(room_id)
        self._broadcast_client_var_sync(room_id)

    def _flush_nv_drain(self, room_id: str) -> None:
        """Drain all pending NV updates for a room in one go."""
        start = time.perf_counter()

        with self._rooms_lock:
            pending_globals = self.pending_global_nv.get(room_id, {})
            pending_clients = self.pending_client_nv.get(room_id, {})
            globals_to_apply = list(pending_globals.items())
            clients_to_apply = list(pending_clients.items())
            self.pending_global_nv[room_id] = {}
            self.pending_client_nv[room_id] = {}

        applied_globals: list[str] = []
        for var_name, (sender, value, ts) in globals_to_apply:
            if self._apply_global_var_set(room_id, sender, var_name, value, ts):
                applied_globals.append(var_name)

        applied_clients: dict[int, list[dict[str, Any]]] = {}
        for (target_client_no, var_name), (sender, value, ts) in clients_to_apply:
            if self._apply_client_var_set(
                room_id, sender, target_client_no, var_name, value, ts
            ):
                applied_clients.setdefault(target_client_no, []).append(
                    {
                        "name": var_name,
                        "value": value,
                        "timestamp": ts,
                        "lastWriterClientNo": sender,
                    }
                )

        topic = room_id.encode("utf-8")
        if applied_globals:
            vars_payload = []
            with self._rooms_lock:
                for name in applied_globals:
                    d = self.global_variables[room_id][name]
                    vars_payload.append(
                        {
                            "name": name,
                            "value": d["value"],
                            "timestamp": d["timestamp"],
                            "lastWriterClientNo": d["lastWriterClientNo"],
                        }
                    )
            msg = binary_serializer.serialize_global_var_sync(
                {"variables": vars_payload}
            )
            self._enqueue_pub(topic, msg)

        if applied_clients:
            client_vars = {str(cno): lst for cno, lst in applied_clients.items()}
            msg = binary_serializer.serialize_client_var_sync(
                {"clientVariables": client_vars}
            )
            self._enqueue_pub(topic, msg)

        elapsed_ms = (time.perf_counter() - start) * 1000.0
        if elapsed_ms > 10.0:
            logger.info(f"NV flush took {elapsed_ms:.2f} ms (room={room_id})")
        else:
            logger.debug(f"NV flush took {elapsed_ms:.2f} ms (room={room_id})")

    def _broadcast_id_mappings(self, room_id: str):
        """Broadcast all device ID mappings for a room (including stealth clients with flag)"""
        with self._rooms_lock:
            if room_id not in self.room_device_id_to_client_no:
                return

            # Collect all mappings for the room (including stealth clients with their flag)
            mappings = []
            for device_id, client_no in self.room_device_id_to_client_no[
                room_id
            ].items():
                # Get stealth status from client data
                client_data = self.rooms.get(room_id, {}).get(device_id, {})
                is_stealth = client_data.get("is_stealth", False)
                # Include all clients with their stealth flag
                mappings.append((client_no, device_id, is_stealth))

            if mappings:
                # Serialize and broadcast the mappings
                topic_bytes = room_id.encode("utf-8")
                message_bytes = binary_serializer.serialize_device_id_mapping(mappings)
                self._enqueue_pub(topic_bytes, message_bytes)
                sub_count = self._get_sub_connection_count()
                logger.info(
                    f"Broadcasted {len(mappings)} ID mappings to room {room_id} (connected SUBs: {sub_count})"
                )

    def _flush_debounced_id_mapping_broadcasts(self, current_time: float):
        """Flush ID mapping broadcasts that have been debounced long enough."""
        # Get list of rooms that need ID mapping broadcast and mark them as processed
        rooms_to_broadcast: list[str] = []
        with self._rooms_lock:
            for room_id, is_dirty in list(self.room_id_mapping_dirty.items()):
                if not is_dirty:
                    continue
                last_broadcast = self.room_last_id_mapping_broadcast.get(room_id, 0.0)
                if current_time - last_broadcast >= self.ID_MAPPING_DEBOUNCE_INTERVAL:
                    rooms_to_broadcast.append(room_id)

            # Mark rooms as having been broadcast at this time
            for room_id in rooms_to_broadcast:
                self.room_id_mapping_dirty[room_id] = False
                self.room_last_id_mapping_broadcast[room_id] = current_time

        # Broadcast ID mappings for eligible rooms outside the lock
        for room_id in rooms_to_broadcast:
            self._broadcast_id_mappings(room_id)

    def _periodic_loop(self):
        """Combined broadcast and cleanup loop with adaptive rates"""
        last_broadcast_check = 0
        last_cleanup = 0
        last_device_id_cleanup = 0
        last_log = time.monotonic()
        DEVICE_ID_CLEANUP_INTERVAL = 60.0  # Clean up expired device IDs every minute

        while self.running:
            try:
                current_time = time.monotonic()

                # Check for broadcasts at higher frequency but only broadcast when needed
                if current_time - last_broadcast_check >= self.BROADCAST_CHECK_INTERVAL:
                    self._adaptive_broadcast_all_rooms(current_time)

                    # Flush Network Variables after other categories
                    with self._rooms_lock:
                        rooms = list(self.rooms.keys())
                    for room_id in rooms:
                        last_flush = self.room_last_nv_flush.get(room_id, 0.0)
                        if current_time - last_flush >= self.nv_flush_interval:
                            self._flush_nv_drain(room_id)
                            self.room_last_nv_flush[room_id] = current_time

                    last_broadcast_check = current_time

                # Cleanup at regular intervals
                if current_time - last_cleanup >= self.CLEANUP_INTERVAL:
                    self._cleanup_clients(current_time)
                    last_cleanup = current_time

                # Debounced ID mapping broadcasts
                self._flush_debounced_id_mapping_broadcasts(current_time)

                # Clean up expired device ID mappings periodically
                if current_time - last_device_id_cleanup >= DEVICE_ID_CLEANUP_INTERVAL:
                    self._cleanup_expired_device_id_mappings(current_time)
                    last_device_id_cleanup = current_time

                # Log status periodically
                if current_time - last_log >= self.STATUS_LOG_INTERVAL:
                    # Count normal and stealth clients separately
                    normal_clients = 0
                    stealth_clients = 0
                    for room in self.rooms.values():
                        for client in room.values():
                            if client.get("is_stealth", False):
                                stealth_clients += 1
                            else:
                                normal_clients += 1

                    dirty_rooms = sum(
                        1 for flag in self.room_dirty_flags.values() if flag
                    )
                    total_device_ids = len(self.device_id_last_seen)

                    # Get FD information for status log
                    open_fds, soft, _ = self._get_fd_snapshot()
                    fd_part = ""
                    if open_fds is not None:
                        if soft is not None:
                            fd_part = f", FD {open_fds}/{soft}"
                        else:
                            fd_part = f", FD {open_fds}"

                    logger.info(
                        f"Status: {len(self.rooms)} rooms, {normal_clients} normal clients, "
                        f"{stealth_clients} stealth clients, "
                        f"{dirty_rooms} dirty rooms, {total_device_ids} tracked device IDs"
                        f"{fd_part}"
                    )
                    last_log = current_time

                time.sleep(self.MAIN_LOOP_SLEEP)  # 50Hz loop for better responsiveness

            except Exception as e:
                logger.error(f"Error in periodic loop: {e}")

        logger.info("Periodic loop ended")

    def _adaptive_broadcast_all_rooms(self, current_time):
        """Broadcast room state with adaptive rates based on activity"""
        with self._rooms_lock:
            rooms_copy = list(
                self.rooms.items()
            )  # Create copy to avoid holding lock too long

        for room_id, clients in rooms_copy:
            if not clients:  # Skip empty rooms
                continue

            with self._rooms_lock:
                # Check if room needs broadcasting
                last_broadcast = self.room_last_broadcast.get(room_id, 0)
                is_dirty = self.room_dirty_flags.get(room_id, False)

                # Calculate time since last broadcast
                time_since_broadcast = current_time - last_broadcast

                # Determine if we should broadcast based on activity and timing
                should_broadcast = False

                if is_dirty:
                    # Active room - broadcast if minimum dirty threshold time has passed
                    if time_since_broadcast >= self.dirty_threshold:
                        should_broadcast = True
                else:
                    # Idle room - broadcast only if idle interval has passed
                    if time_since_broadcast >= self.idle_broadcast_interval:
                        should_broadcast = True

                if should_broadcast:
                    self._broadcast_room(room_id, clients)
                    self.room_dirty_flags[room_id] = False  # Clear dirty flag
                    self.room_last_broadcast[room_id] = current_time
                else:
                    self._increment_stat("skipped_broadcasts")

    def _enqueue_pub_latest(self, topic_bytes: bytes, message_bytes: bytes):
        """Latest-only coalescing enqueue for high-rate topics (e.g., room transforms)."""
        with self._coalesce_lock:
            self._coalesce_latest[topic_bytes] = message_bytes

    def _broadcast_room(self, room_id, clients):
        """Broadcast a specific room's state"""
        # Filter out stealth clients from broadcasts
        client_transforms = [
            client["transform_data"]
            for client in clients.values()
            if client["transform_data"] and not client.get("is_stealth", False)
        ]

        if client_transforms:
            room_transform = {
                "roomId": room_id,
                "clients": client_transforms,
            }

            # Send binary format with client numbers
            topic_bytes = room_id.encode("utf-8")
            message_bytes = binary_serializer.serialize_room_transform(room_transform)
            # Transform is overwrite-only => keep only the latest per room/topic
            self._enqueue_pub_latest(topic_bytes, message_bytes)

    def _cleanup_clients(self, current_time):
        """Clean up disconnected clients with atomic operations to prevent memory leaks"""
        timeout = self.CLIENT_TIMEOUT

        with self._rooms_lock:
            rooms_to_remove = []

            for room_id, clients in list(self.rooms.items()):
                clients_to_remove = []

                # Use items() to avoid repeated dict lookups
                for device_id, client_data in clients.items():
                    if current_time - client_data["last_update"] > timeout:
                        clients_to_remove.append(device_id)

                # Remove timed out clients in batch
                if clients_to_remove:
                    for device_id in clients_to_remove:
                        client_no = clients[device_id].get("client_no")
                        del clients[device_id]
                        # Clean up binary cache by client number
                        if client_no and client_no in self.client_binary_cache:
                            del self.client_binary_cache[client_no]
                        # Note: We don't remove device ID->clientNo mapping here
                        # It will be cleaned up after DEVICE_ID_EXPIRY_TIME
                        logger.info(
                            f"Client {device_id[:8]}... (client number: {client_no}) removed (timeout)"
                        )

                    # Mark room as dirty since clients were removed
                    self.room_dirty_flags[room_id] = True

                    # Mark room for debounced ID mapping broadcast
                    self.room_id_mapping_dirty[room_id] = True

                # Mark empty rooms for removal
                if not clients:
                    rooms_to_remove.append(room_id)

            # Remove empty rooms and clean up ALL tracking data
            for room_id in rooms_to_remove:
                try:
                    # Delete from all room-related data structures
                    if room_id in self.rooms:
                        del self.rooms[room_id]
                    if room_id in self.room_dirty_flags:
                        del self.room_dirty_flags[room_id]
                    if room_id in self.room_last_broadcast:
                        del self.room_last_broadcast[room_id]
                    if room_id in self.room_client_no_counters:
                        del self.room_client_no_counters[room_id]
                    if room_id in self.room_device_id_to_client_no:
                        del self.room_device_id_to_client_no[room_id]
                    if room_id in self.room_client_no_to_device_id:
                        del self.room_client_no_to_device_id[room_id]

                    # Clean up ID mapping debounce tracking
                    if room_id in self.room_id_mapping_dirty:
                        del self.room_id_mapping_dirty[room_id]
                    if room_id in self.room_last_id_mapping_broadcast:
                        del self.room_last_id_mapping_broadcast[room_id]

                    # Clean up NV-related structures
                    if room_id in self.global_variables:
                        del self.global_variables[room_id]
                    if room_id in self.client_variables:
                        del self.client_variables[room_id]
                    if room_id in self.pending_global_nv:
                        del self.pending_global_nv[room_id]
                    if room_id in self.pending_client_nv:
                        del self.pending_client_nv[room_id]
                    if room_id in self.room_last_nv_flush:
                        del self.room_last_nv_flush[room_id]
                    if room_id in self.nv_monitor_window:
                        del self.nv_monitor_window[room_id]

                    logger.info(f"Removed empty room: {room_id}")

                except Exception as e:
                    logger.error(f"Error during room cleanup for {room_id}: {e}")
                    # Continue with other rooms even if one fails

    def _start_server_discovery(self):
        """Start server discovery service to respond to client requests"""
        # Start UDP server discovery
        try:
            self.server_discovery_socket = socket.socket(
                socket.AF_INET, socket.SOCK_DGRAM
            )
            self.server_discovery_socket.setsockopt(
                socket.SOL_SOCKET, socket.SO_REUSEADDR, 1
            )
            self.server_discovery_socket.bind(("", self.server_discovery_port))
            self.server_discovery_socket.settimeout(
                1.0
            )  # Timeout for graceful shutdown

            self.server_discovery_running = True
            self.server_discovery_thread = threading.Thread(
                target=self._server_discovery_loop,
                name="ServerDiscoveryThread",
                daemon=True,
            )
            self.server_discovery_thread.start()

        except Exception as e:
            logger.error(f"Failed to start UDP discovery service: {e}")
            self.server_discovery_running = False

        # Start TCP server discovery
        self._start_tcp_server_discovery()

    def _stop_server_discovery(self):
        """Stop server discovery service"""
        # Stop UDP server discovery
        self.server_discovery_running = False

        if self.server_discovery_socket:
            self.server_discovery_socket.close()
            self.server_discovery_socket = None

        if self.server_discovery_thread:
            self.server_discovery_thread.join(timeout=2)
            self.server_discovery_thread = None

        # Stop TCP server discovery
        self._stop_tcp_server_discovery()

        logger.info("Stopped discovery service")

    def _server_discovery_loop(self):
        """UDP discovery service loop - responds to client discovery requests"""
        # Response message format: STYLY-NETSYNC|dealerPort|pubPort|serverName
        response = (
            f"STYLY-NETSYNC|{self.dealer_port}|{self.pub_port}|{self.server_name}"
        )
        response_bytes = response.encode("utf-8")

        while self.server_discovery_running:
            try:
                # Wait for client discovery request
                data, client_addr = self.server_discovery_socket.recvfrom(1024)
                request = data.decode("utf-8")

                # Validate request format
                if request == "STYLY-NETSYNC-DISCOVER":
                    # Send response back to requesting client
                    self.server_discovery_socket.sendto(response_bytes, client_addr)
                    logger.debug(
                        f"Responded to UDP discovery request from {client_addr}"
                    )

            except TimeoutError:
                # Timeout is expected for graceful shutdown
                continue
            except Exception as e:
                if (
                    self.server_discovery_running
                ):  # Only log if we're still supposed to be running
                    logger.error(f"UDP discovery service error: {e}")

    def _start_tcp_server_discovery(self):
        """Start TCP-based server discovery service"""
        try:
            self.tcp_server_discovery_socket = socket.socket(
                socket.AF_INET, socket.SOCK_STREAM
            )
            self.tcp_server_discovery_socket.setsockopt(
                socket.SOL_SOCKET, socket.SO_REUSEADDR, 1
            )
            self.tcp_server_discovery_socket.bind(("", self.server_discovery_port))
            self.tcp_server_discovery_socket.listen(5)
            self.tcp_server_discovery_socket.settimeout(
                1.0
            )  # Timeout for graceful shutdown

            self.tcp_server_discovery_running = True
            self.tcp_server_discovery_thread = threading.Thread(
                target=self._tcp_server_discovery_loop,
                name="TcpServerDiscoveryThread",
                daemon=True,
            )
            self.tcp_server_discovery_thread.start()

        except Exception as e:
            logger.error(f"Failed to start TCP discovery service: {e}")
            self.tcp_server_discovery_running = False

    def _stop_tcp_server_discovery(self):
        """Stop TCP-based server discovery service"""
        self.tcp_server_discovery_running = False

        if self.tcp_server_discovery_socket:
            self.tcp_server_discovery_socket.close()
            self.tcp_server_discovery_socket = None

        if self.tcp_server_discovery_thread:
            self.tcp_server_discovery_thread.join(timeout=2)
            self.tcp_server_discovery_thread = None

    def _tcp_server_discovery_loop(self):
        """TCP discovery service loop - responds to client discovery requests"""
        # Response message format: STYLY-NETSYNC|dealerPort|pubPort|serverName\n
        response = (
            f"STYLY-NETSYNC|{self.dealer_port}|{self.pub_port}|{self.server_name}\n"
        )
        response_bytes = response.encode("utf-8")

        while self.tcp_server_discovery_running:
            try:
                # Accept incoming connection
                client_socket, client_addr = self.tcp_server_discovery_socket.accept()
                client_socket.settimeout(2.0)  # Timeout for client operations

                try:
                    # Receive discovery request
                    data = client_socket.recv(1024)
                    request = data.decode("utf-8").strip()

                    # Validate request format
                    if request == "STYLY-NETSYNC-DISCOVER":
                        # Send response back to requesting client
                        client_socket.sendall(response_bytes)
                        logger.debug(
                            f"Responded to TCP discovery request from {client_addr}"
                        )

                except Exception as e:
                    logger.debug(f"Error handling TCP client {client_addr}: {e}")
                finally:
                    client_socket.close()

            except TimeoutError:
                # Timeout is expected for graceful shutdown
                continue
            except Exception as e:
                if (
                    self.tcp_server_discovery_running
                ):  # Only log if we're still supposed to be running
                    logger.error(f"TCP discovery service error: {e}")


def display_logo():
    logo = """
CgobWzM4OzU7MjE2bSDilojilojilojilojilojilojilojilZcg4paI4paIG1szODs1OzIxMG3ilojilojilojilojilojilojilZcg4paI4paI4pWXICAg4paI4paI4pWXIOKWiOKWiOKVlyAgICAbWzM4OzU7MjE2bSAg4paI4paI4pWXICAg4paI4paI4pWXG1szOW0KG1szODs1OzIxNm0g4paI4paI4pWU4pWQ4pWQ4pWQ4pWQ4pWdIOKVmuKVkBtbMzg7NTsyMTBt4pWQ4paI4paI4pWU4pWQ4pWQ4pWdIOKVmuKWiOKWiOKVlyDilojilojilZTilZ0g4paI4paI4pWRICAgIBtbMzg7NTsyMTZtICDilZrilojilojilZcg4paI4paI4pWU4pWdG1szOW0KG1szODs1OzIxNm0g4paI4paI4paI4paI4paI4paI4paI4pWXICAgG1szODs1OzIxMG0g4paI4paI4pWRICAgICDilZrilojilojilojilojilZTilZ0gIOKWiOKWiOKVkSAgICAbWzM4OzU7MjE2bSAgIOKVmuKWiOKWiOKWiOKWiOKVlOKVnSAbWzM5bQobWzM4OzU7MjE2bSDilZrilZDilZDilZDilZDilojilojilZEgICAbWzM4OzU7MjEwbSDilojilojilZEgICAgICDilZrilojilojilZTilZ0gICDilojilojilZEgICAgG1szODs1OzIxNm0gICAg4pWa4paI4paI4pWU4pWdICAbWzM5bQobWzM4OzU7MjE2bSDilojilojilojilojilojilojilojilZEgICAbWzM4OzU7MjEwbSDilojilojilZEgICAgICAg4paI4paI4pWRICAgIOKWiOKWiOKWiOKWiOKWiOKWiOKWiBtbMzg7NTsyMTZt4pWXICAgIOKWiOKWiOKVkSAgIBtbMzltChtbMzg7NTsyMTZtIOKVmuKVkOKVkOKVkOKVkOKVkOKVkOKVnSAgIBtbMzg7NTsyMTBtIOKVmuKVkOKVnSAgICAgICDilZrilZDilZ0gICAg4pWa4pWQ4pWQ4pWQ4pWQ4pWQ4pWQG1szODs1OzIxNm3ilZ0gICAg4pWa4pWQ4pWdICAgG1szOW0KChtbMzg7NTsyMTZtIOKWiOKWiOKWiOKVlyAgIOKWiOKWiOKVlyDilojilojilojilojilojilogbWzM4OzU7MjEwbeKWiOKVlyDilojilojilojilojilojilojilojilojilZcg4paI4paI4paI4paI4paI4paI4paI4pWXIOKWiOKWiOKVlyAgIOKWiOKWiOKVlyDilojilojilojilZcbWzM4OzU7MjE2bSAgIOKWiOKWiOKVlyAg4paI4paI4paI4paI4paI4paI4pWXG1szOW0KG1szODs1OzIxNm0g4paI4paI4paI4paI4pWXICDilojilojilZEg4paI4paI4pWU4pWQ4pWQ4pWQG1szODs1OzIxMG3ilZDilZ0g4pWa4pWQ4pWQ4paI4paI4pWU4pWQ4pWQ4pWdIOKWiOKWiOKVlOKVkOKVkOKVkOKVkOKVnSDilZrilojilojilZcg4paI4paI4pWU4pWdIOKWiOKWiOKWiOKWiBtbMzg7NTsyMTZt4pWXICDilojilojilZEg4paI4paI4pWU4pWQ4pWQ4pWQ4pWQ4pWdG1szOW0KG1szODs1OzIxNm0g4paI4paI4pWU4paI4paI4pWXIOKWiOKWiOKVkSDilojilojilojilojilojilZcbWzM4OzU7MjEwbSAgICAgIOKWiOKWiOKVkSAgICDilojilojilojilojilojilojilojilZcgIOKVmuKWiOKWiOKWiOKWiOKVlOKVnSAg4paI4paI4pWU4paIG1szODs1OzIxNm3ilojilZcg4paI4paI4pWRIOKWiOKWiOKVkSAgICAgG1szOW0KG1szODs1OzIxNm0g4paI4paI4pWR4pWa4paI4paI4pWX4paI4paI4pWRIOKWiOKWiOKVlOKVkOKVkOKVnRtbMzg7NTsyMTBtICAgICAg4paI4paI4pWRICAgIOKVmuKVkOKVkOKVkOKVkOKWiOKWiOKVkSAgIOKVmuKWiOKWiOKVlOKVnSAgIOKWiOKWiOKVkeKVmhtbMzg7NTsyMTZt4paI4paI4pWX4paI4paI4pWRIOKWiOKWiOKVkSAgICAgG1szOW0KG1szODs1OzIxNm0g4paI4paI4pWRIOKVmuKWiOKWiOKWiOKWiOKVkSDilojilojilojilojilojilogbWzM4OzU7MjEwbeKWiOKVlyAgICDilojilojilZEgICAg4paI4paI4paI4paI4paI4paI4paI4pWRICAgIOKWiOKWiOKVkSAgICDilojilojilZEgG1szODs1OzIxNm3ilZrilojilojilojilojilZEg4pWa4paI4paI4paI4paI4paI4paI4pWXG1szOW0KG1szODs1OzIxNm0g4pWa4pWQ4pWdICDilZrilZDilZDilZDilZ0g4pWa4pWQ4pWQ4pWQ4pWQ4pWQG1szODs1OzIxMG3ilZDilZ0gICAg4pWa4pWQ4pWdICAgIOKVmuKVkOKVkOKVkOKVkOKVkOKVkOKVnSAgICDilZrilZDilZ0gICAg4pWa4pWQ4pWdIBtbMzg7NTsyMTZtIOKVmuKVkOKVkOKVkOKVnSAg4pWa4pWQ4pWQ4pWQ4pWQ4pWQ4pWdG1szOW0KCgo=
""".strip()
    sys.stdout.buffer.write(base64.b64decode(logo))
    sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser(description="STYLY NetSync Server")
    parser.add_argument(
        "--no-server-discovery", action="store_true", help="Disable server discovery"
    )
    parser.add_argument(
        "--server-discovery-port",
        type=valid_port,
        metavar="PORT",
        help=f"UDP port used for server discovery (default: {DEFAULT_SERVER_DISCOVERY_PORT})",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {get_version()}",
        help="Show version and exit",
    )
    parser.add_argument(
        "--log-dir",
        type=Path,
        help="Directory for log files (enables file logging with rotation)",
    )
    parser.add_argument(
        "--log-rotation",
        type=str,
        help=(
            "Rotation rule for log files (loguru syntax, e.g., '10 MB', '1 day', "
            "'12:00'); default triggers at 10MB or 7 days"
        ),
    )
    parser.add_argument(
        "--log-retention",
        type=str,
        help=(
            "Retention rule for log files (loguru syntax, e.g., '5', '1 week', "
            "'keep 10 files'); default keeps newest 20 files"
        ),
    )
    parser.add_argument(
        "--log-json-console",
        action="store_true",
        help="Emit console logs as JSON instead of text",
    )
    parser.add_argument(
        "--log-level-console",
        default="INFO",
        help="Console log level (default: INFO)",
    )

    args = parser.parse_args()

    configure_logging(
        log_dir=args.log_dir,
        console_level=args.log_level_console,
        console_json=args.log_json_console,
        rotation=args.log_rotation,
        retention=args.log_retention,
    )

    # Set default values from module constants (previously from argparse)
    dealer_port = DEFAULT_DEALER_PORT
    pub_port = DEFAULT_PUB_PORT
    server_discovery_port = DEFAULT_SERVER_DISCOVERY_PORT
    server_name = DEFAULT_SERVER_NAME

    logger.info("=" * 80)
    logger.info("STYLY NetSync Server Starting")
    logger.info("=" * 80)
    logger.info(f"  Version: {get_version()}")

    # Display local IP addresses
    ip_addresses = network_utils.get_local_ip_addresses()
    if ip_addresses:
        logger.info("  Server IP addresses:")
        for ip in ip_addresses:
            logger.info(f"    - {ip}")
    else:
        logger.info("  Server IP addresses: Unable to detect")

    logger.info(f"  DEALER port: {dealer_port}")
    logger.info(f"  PUB port: {pub_port}")
    if not args.no_server_discovery:
        if args.server_discovery_port is not None:
            server_discovery_port = args.server_discovery_port
        logger.info(f"  Server discovery port: {server_discovery_port}")
        logger.info(f"  Server name: {server_name}")
    else:
        logger.info("  Discovery: Disabled")
    logger.info("=" * 80)

    server = NetSyncServer(
        dealer_port=dealer_port,
        pub_port=pub_port,
        enable_server_discovery=not args.no_server_discovery,
        server_discovery_port=server_discovery_port,
        server_name=server_name,
    )

    try:
        server.start(ip_addresses=ip_addresses)

        logger.info("Server started successfully. Press Ctrl+C to stop.")

        # Keep server running with proper signal handling
        while True:
            try:
                time.sleep(1)
            except KeyboardInterrupt:
                # Handle Ctrl+C gracefully
                logger.info("\nReceived interrupt signal (Ctrl+C)...")
                break

    except SystemExit:
        # Server failed to start due to port already in use
        logger.info("Server startup failed. Exiting...")
        return
    except KeyboardInterrupt:
        # Handle Ctrl+C during startup
        logger.info("\nReceived interrupt signal during startup...")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        logger.error(traceback.format_exc())
    finally:
        # Always try to stop the server cleanly
        try:
            server.stop()
        except Exception as e:
            logger.error(f"Error during server shutdown: {e}")
        logger.info("Server shutdown complete.")
