"""Tests for the AsyncUnraidClient."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from uma_api.async_client import AsyncUnraidClient
from uma_api.exceptions import (
    UnraidAPIError,
    UnraidConflictError,
    UnraidConnectionError,
    UnraidNotFoundError,
    UnraidValidationError,
)
from uma_api.models import (
    CollectorStatus,
    DiskSettings,
    DockerSettings,
    HardwareFullInfo,
    LogContent,
    LogList,
    NetworkAccessUrls,
    NUTInfo,
    ParityHistory,
    RemoteSharesResponse,
    SystemSettings,
    UnassignedDevicesResponse,
    UnassignedInfo,
    VMSettings,
    ZFSArcStats,
)


class TestAsyncUnraidClientInit:
    """Test AsyncUnraidClient initialization."""

    def test_basic_initialization(self):
        """Test basic initialization."""
        client = AsyncUnraidClient(host="192.168.1.100")

        assert client.host == "192.168.1.100"
        assert client.port == 8043
        assert client.timeout == 10
        assert client.verify_ssl is True
        assert client.use_https is False
        assert client.base_url == "http://192.168.1.100:8043/api/v1"

    def test_custom_port(self):
        """Test custom port initialization."""
        client = AsyncUnraidClient(host="192.168.1.100", port=9000)

        assert client.port == 9000
        assert client.base_url == "http://192.168.1.100:9000/api/v1"

    def test_https_initialization(self):
        """Test HTTPS initialization."""
        client = AsyncUnraidClient(host="192.168.1.100", use_https=True)

        assert client.use_https is True
        assert client.base_url == "https://192.168.1.100:8043/api/v1"

    def test_custom_timeout(self):
        """Test custom timeout initialization."""
        client = AsyncUnraidClient(host="192.168.1.100", timeout=30)

        assert client.timeout == 30

    def test_verify_ssl_disabled(self):
        """Test verify_ssl disabled."""
        client = AsyncUnraidClient(host="192.168.1.100", verify_ssl=False)

        assert client.verify_ssl is False


class TestAsyncUnraidClientContextManager:
    """Test AsyncUnraidClient context manager."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test async context manager."""
        async with AsyncUnraidClient(host="192.168.1.100") as client:
            assert client is not None

    @pytest.mark.asyncio
    async def test_context_manager_with_session(self):
        """Test context manager with existing session."""
        mock_session = AsyncMock()
        mock_session.closed = False

        # Session should not be closed since we provided it
        client = AsyncUnraidClient(host="192.168.1.100", session=mock_session)
        await client.close()

        mock_session.close.assert_not_called()


class TestAsyncUnraidClientRequest:
    """Test AsyncUnraidClient _request method."""

    @pytest.mark.asyncio
    async def test_successful_request(self):
        """Test successful request."""
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={"key": "value"})

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_context = MagicMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)
        mock_session.request.return_value = mock_context

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        result = await client._request("GET", "/test")

        assert result == {"key": "value"}

    @pytest.mark.asyncio
    async def test_404_error(self):
        """Test 404 error handling."""
        mock_response = MagicMock()
        mock_response.status = 404
        mock_response.json = AsyncMock(
            return_value={"message": "Not found", "error_code": "NOT_FOUND"}
        )

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_context = MagicMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)
        mock_session.request.return_value = mock_context

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidNotFoundError) as exc:
            await client._request("GET", "/test")

        assert exc.value.status_code == 404
        assert exc.value.error_code == "NOT_FOUND"

    @pytest.mark.asyncio
    async def test_409_error(self):
        """Test 409 conflict error handling."""
        mock_response = MagicMock()
        mock_response.status = 409
        mock_response.json = AsyncMock(
            return_value={"message": "Conflict", "error_code": "CONFLICT"}
        )

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_context = MagicMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)
        mock_session.request.return_value = mock_context

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidConflictError) as exc:
            await client._request("GET", "/test")

        assert exc.value.status_code == 409

    @pytest.mark.asyncio
    async def test_400_error(self):
        """Test 400 validation error handling."""
        mock_response = MagicMock()
        mock_response.status = 400
        mock_response.json = AsyncMock(
            return_value={"message": "Bad request", "error_code": "VALIDATION_ERROR"}
        )

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_context = MagicMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)
        mock_session.request.return_value = mock_context

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidValidationError) as exc:
            await client._request("GET", "/test")

        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_500_error(self):
        """Test 500 error handling."""
        mock_response = MagicMock()
        mock_response.status = 500
        mock_response.json = AsyncMock(
            return_value={"message": "Server error", "error_code": "SERVER_ERROR"}
        )

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_context = MagicMock()
        mock_context.__aenter__ = AsyncMock(return_value=mock_response)
        mock_context.__aexit__ = AsyncMock(return_value=None)
        mock_session.request.return_value = mock_context

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidAPIError) as exc:
            await client._request("GET", "/test")

        assert exc.value.status_code == 500


class TestAsyncUnraidClientEndpoints:
    """Test AsyncUnraidClient endpoint methods."""

    @pytest.fixture
    def client(self):
        """Create a client for testing."""
        return AsyncUnraidClient(host="192.168.1.100")

    @pytest.mark.asyncio
    async def test_health_check(self, client):
        """Test health_check method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"status": "ok", "version": "1.0.0"}

            result = await client.health_check()

            assert result.status == "ok"
            mock_request.assert_called_once_with("GET", "/health")

    @pytest.mark.asyncio
    async def test_get_system_info(self, client):
        """Test get_system_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "hostname": "tower",
                "version": "6.12.0",
                "uptime": "10 days",
                "cpu_model": "Intel",
                "cpu_usage_percent": 25.5,
                "memory_total_bytes": 16000000000,
                "memory_used_bytes": 8000000000,
                "memory_usage_percent": 50.0,
            }

            result = await client.get_system_info()

            assert result.hostname == "tower"
            mock_request.assert_called_once_with("GET", "/system")

    @pytest.mark.asyncio
    async def test_get_array_status(self, client):
        """Test get_array_status method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "state": "STARTED",
                "capacity_bytes": 10000000000000,
                "used_bytes": 5000000000000,
                "free_bytes": 5000000000000,
            }

            result = await client.get_array_status()

            assert result.state == "STARTED"
            mock_request.assert_called_once_with("GET", "/array")

    @pytest.mark.asyncio
    async def test_start_array(self, client):
        """Test start_array method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Array started"}

            result = await client.start_array()

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/array/start")

    @pytest.mark.asyncio
    async def test_stop_array(self, client):
        """Test stop_array method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Array stopped"}

            result = await client.stop_array()

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/array/stop")

    @pytest.mark.asyncio
    async def test_list_disks(self, client):
        """Test list_disks method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "id": "disk1",
                    "name": "Disk 1",
                    "device": "/dev/sda",
                    "size_bytes": 1000000000000,
                    "status": "DISK_OK",
                }
            ]

            result = await client.list_disks()

            assert len(result) == 1
            assert result[0].id == "disk1"
            mock_request.assert_called_once_with("GET", "/disks")

    @pytest.mark.asyncio
    async def test_get_disk(self, client):
        """Test get_disk method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "id": "disk1",
                "name": "Disk 1",
                "device": "/dev/sda",
                "size_bytes": 1000000000000,
                "status": "DISK_OK",
            }

            result = await client.get_disk("disk1")

            assert result.id == "disk1"
            mock_request.assert_called_once_with("GET", "/disks/disk1")

    @pytest.mark.asyncio
    async def test_list_containers(self, client):
        """Test list_containers method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "id": "abc123",
                    "name": "plex",
                    "state": "running",
                    "image": "plexinc/pms-docker",
                }
            ]

            result = await client.list_containers()

            assert len(result) == 1
            assert result[0].name == "plex"
            mock_request.assert_called_once_with("GET", "/docker")

    @pytest.mark.asyncio
    async def test_get_container(self, client):
        """Test get_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "id": "abc123",
                "name": "plex",
                "state": "running",
                "image": "plexinc/pms-docker",
            }

            result = await client.get_container("abc123")

            assert result.id == "abc123"
            mock_request.assert_called_once_with("GET", "/docker/abc123")

    @pytest.mark.asyncio
    async def test_start_container(self, client):
        """Test start_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Started"}

            result = await client.start_container("abc123")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/docker/abc123/start")

    @pytest.mark.asyncio
    async def test_stop_container(self, client):
        """Test stop_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Stopped"}

            result = await client.stop_container("abc123")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/docker/abc123/stop")

    @pytest.mark.asyncio
    async def test_list_vms(self, client):
        """Test list_vms method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "id": "vm1",
                    "name": "Windows 10",
                    "state": "running",
                }
            ]

            result = await client.list_vms()

            assert len(result) == 1
            assert result[0].name == "Windows 10"
            mock_request.assert_called_once_with("GET", "/vm")

    @pytest.mark.asyncio
    async def test_get_vm(self, client):
        """Test get_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "id": "vm1",
                "name": "Windows 10",
                "state": "running",
            }

            result = await client.get_vm("vm1")

            assert result.id == "vm1"
            mock_request.assert_called_once_with("GET", "/vm/vm1")

    @pytest.mark.asyncio
    async def test_list_shares(self, client):
        """Test list_shares method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "name": "media",
                    "path": "/mnt/user/media",
                    "size_bytes": 5000000000000,
                }
            ]

            result = await client.list_shares()

            assert len(result) == 1
            assert result[0].name == "media"
            mock_request.assert_called_once_with("GET", "/shares")

    @pytest.mark.asyncio
    async def test_get_share(self, client):
        """Test get_share method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "name": "media",
                "path": "/mnt/user/media",
                "size_bytes": 5000000000000,
            }

            result = await client.get_share("media")

            assert result.name == "media"
            mock_request.assert_called_once_with("GET", "/shares/media")

    @pytest.mark.asyncio
    async def test_list_network_interfaces(self, client):
        """Test list_network_interfaces method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "name": "eth0",
                    "mac_address": "00:11:22:33:44:55",
                    "ip_address": "192.168.1.100",
                }
            ]

            result = await client.list_network_interfaces()

            assert len(result) == 1
            assert result[0].name == "eth0"
            mock_request.assert_called_once_with("GET", "/network")

    @pytest.mark.asyncio
    async def test_get_hardware_info(self, client):
        """Test get_hardware_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "cpu_model": "Intel Core i7",
                "cpu_cores": 8,
                "memory_total_bytes": 32000000000,
            }

            result = await client.get_hardware_info()

            assert result.cpu_model == "Intel Core i7"
            mock_request.assert_called_once_with("GET", "/hardware")

    @pytest.mark.asyncio
    async def test_list_gpus(self, client):
        """Test list_gpus method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = [
                {
                    "id": "gpu0",
                    "name": "NVIDIA GeForce RTX 3080",
                    "vendor": "NVIDIA",
                }
            ]

            result = await client.list_gpus()

            assert len(result) == 1
            assert result[0].name == "NVIDIA GeForce RTX 3080"
            mock_request.assert_called_once_with("GET", "/hardware/gpus")

    @pytest.mark.asyncio
    async def test_get_ups_info(self, client):
        """Test get_ups_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "status": "online",
                "battery_charge": 100,
                "battery_runtime": 3600,
            }

            result = await client.get_ups_info()

            assert result.status == "online"
            mock_request.assert_called_once_with("GET", "/ups")

    @pytest.mark.asyncio
    async def test_list_notifications(self, client):
        """Test list_notifications method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "notifications": [],
                "unread_count": 0,
            }

            result = await client.list_notifications()

            assert result.unread_count == 0
            mock_request.assert_called_once_with("GET", "/notifications")

    @pytest.mark.asyncio
    async def test_create_notification(self, client):
        """Test create_notification method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "id": "notif1",
                "subject": "Test",
                "message": "Test message",
                "importance": "normal",
                "timestamp": "2026-01-12T00:00:00Z",
            }

            result = await client.create_notification(
                subject="Test",
                message="Test message",
                importance="normal",
            )

            assert result.subject == "Test"
            mock_request.assert_called_once_with(
                "POST",
                "/notifications",
                data={
                    "subject": "Test",
                    "message": "Test message",
                    "importance": "normal",
                },
            )

    @pytest.mark.asyncio
    async def test_reboot_system(self, client):
        """Test reboot_system method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Rebooting"}

            result = await client.reboot_system()

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/system/reboot")

    @pytest.mark.asyncio
    async def test_shutdown_system(self, client):
        """Test shutdown_system method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Shutting down"}

            result = await client.shutdown_system()

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/system/shutdown")

    @pytest.mark.asyncio
    async def test_execute_user_script(self, client):
        """Test execute_user_script method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "success": True,
                "output": "Script executed",
            }

            result = await client.execute_user_script("test_script")

            assert result.success is True
            mock_request.assert_called_once_with(
                "POST",
                "/user-scripts/test_script/run",
                data={"background": False, "arguments": None},
            )

    @pytest.mark.asyncio
    async def test_execute_user_script_with_options(self, client):
        """Test execute_user_script with background and arguments."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "success": True,
                "output": "Script started",
            }

            result = await client.execute_user_script(
                "test_script", background=True, arguments=["arg1", "arg2"]
            )

            assert result.success is True
            mock_request.assert_called_once_with(
                "POST",
                "/user-scripts/test_script/run",
                data={"background": True, "arguments": ["arg1", "arg2"]},
            )


class TestAsyncUnraidClientConnectionError:
    """Test connection error handling."""

    @pytest.mark.asyncio
    async def test_connection_error(self):
        """Test connection error is raised properly."""
        import aiohttp

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_session.request.side_effect = aiohttp.ClientError("Connection failed")

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidConnectionError):
            await client._request("GET", "/test")

    @pytest.mark.asyncio
    async def test_timeout_error(self):
        """Test timeout error is raised properly."""

        mock_session = MagicMock()
        mock_session.closed = False  # Critical: prevent _ensure_session from creating real session
        mock_session.request.side_effect = TimeoutError()

        client = AsyncUnraidClient(host="192.168.1.100")
        client._session = mock_session
        client._owns_session = False

        with pytest.raises(UnraidConnectionError):
            await client._request("GET", "/test")


class TestAsyncUnraidClientSessionManagement:
    """Test session management."""

    @pytest.mark.asyncio
    async def test_own_session_created(self):
        """Test that a session is created if not provided."""
        client = AsyncUnraidClient(host="192.168.1.100")

        assert client._session is None
        assert client._owns_session is True

    @pytest.mark.asyncio
    async def test_provided_session_used(self):
        """Test that provided session is used."""
        mock_session = AsyncMock()

        client = AsyncUnraidClient(host="192.168.1.100", session=mock_session)

        assert client._session is mock_session
        assert client._owns_session is False

    @pytest.mark.asyncio
    async def test_close_own_session(self):
        """Test that own session is closed."""
        client = AsyncUnraidClient(host="192.168.1.100")
        mock_session = AsyncMock()
        client._session = mock_session
        client._owns_session = True

        await client.close()

        mock_session.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_close_provided_session_not_closed(self):
        """Test that provided session is not closed."""
        mock_session = AsyncMock()
        mock_session.closed = False

        client = AsyncUnraidClient(host="192.168.1.100", session=mock_session)

        await client.close()

        mock_session.close.assert_not_called()


class TestAsyncUnraidClientAdditionalEndpoints:
    """Test additional AsyncUnraidClient endpoint methods for coverage."""

    @pytest.fixture
    def client(self):
        """Create a client for testing."""
        return AsyncUnraidClient(host="192.168.1.100")

    @pytest.mark.asyncio
    async def test_restart_container(self, client):
        """Test restart_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Restarted"}

            result = await client.restart_container("plex")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/docker/plex/restart")

    @pytest.mark.asyncio
    async def test_pause_container(self, client):
        """Test pause_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Paused"}

            result = await client.pause_container("plex")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/docker/plex/pause")

    @pytest.mark.asyncio
    async def test_unpause_container(self, client):
        """Test unpause_container method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Unpaused"}

            result = await client.unpause_container("plex")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/docker/plex/unpause")

    @pytest.mark.asyncio
    async def test_start_vm(self, client):
        """Test start_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Started"}

            result = await client.start_vm("windows")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/vm/windows/start")

    @pytest.mark.asyncio
    async def test_stop_vm(self, client):
        """Test stop_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Stopped"}

            result = await client.stop_vm("windows")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/vm/windows/stop")

    @pytest.mark.asyncio
    async def test_restart_vm(self, client):
        """Test restart_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Restarted"}

            result = await client.restart_vm("windows")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/vm/windows/restart")

    @pytest.mark.asyncio
    async def test_pause_vm(self, client):
        """Test pause_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Paused"}

            result = await client.pause_vm("windows")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/vm/windows/pause")

    @pytest.mark.asyncio
    async def test_resume_vm(self, client):
        """Test resume_vm method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Resumed"}

            result = await client.resume_vm("windows")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/vm/windows/resume")

    @pytest.mark.asyncio
    async def test_spin_up_disk(self, client):
        """Test spin_up_disk method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Disk spinning up"}

            result = await client.spin_up_disk("disk1")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/disks/disk1/spinup")

    @pytest.mark.asyncio
    async def test_spin_down_disk(self, client):
        """Test spin_down_disk method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"success": True, "message": "Disk spinning down"}

            result = await client.spin_down_disk("disk1")

            assert result.success is True
            mock_request.assert_called_once_with("POST", "/disks/disk1/spindown")

    @pytest.mark.asyncio
    async def test_get_parity_status(self, client):
        """Test get_parity_status method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "running": False,
                "paused": False,
                "progress_percent": None,
                "errors": 0,
            }

            result = await client.get_parity_status()

            assert result.running is False
            mock_request.assert_called_once_with("GET", "/array/parity")

    @pytest.mark.asyncio
    async def test_get_parity_history(self, client):
        """Test get_parity_history method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"history": []}

            result = await client.get_parity_history()

            assert isinstance(result, ParityHistory)
            mock_request.assert_called_once_with("GET", "/array/parity/history")

    @pytest.mark.asyncio
    async def test_get_network_interface(self, client):
        """Test get_network_interface method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "name": "eth0",
                "ip_address": "192.168.1.100",
                "mac_address": "00:11:22:33:44:55",
                "state": "up",
            }

            result = await client.get_network_interface("eth0")

            assert result.name == "eth0"
            mock_request.assert_called_once_with("GET", "/network/eth0")

    @pytest.mark.asyncio
    async def test_get_network_access_urls(self, client):
        """Test get_network_access_urls method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "local_url": "http://192.168.1.100",
                "remote_url": None,
            }

            result = await client.get_network_access_urls()

            assert isinstance(result, NetworkAccessUrls)
            mock_request.assert_called_once_with("GET", "/network/access-urls")

    @pytest.mark.asyncio
    async def test_get_hardware_full_info(self, client):
        """Test get_hardware_full_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "bios": {"vendor": "AMI"},
                "system": {"manufacturer": "Dell"},
                "baseboard": {"manufacturer": "ASUS"},
                "processor": {"name": "Intel"},
                "memory": {"total_bytes": 16000000000},
            }

            result = await client.get_hardware_full_info()

            assert isinstance(result, HardwareFullInfo)
            mock_request.assert_called_once_with("GET", "/hardware/full")

    @pytest.mark.asyncio
    async def test_get_registration_info(self, client):
        """Test get_registration_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "registered": True,
                "guid": "abc123",
                "type": "Pro",
            }

            result = await client.get_registration_info()

            assert result.registered is True
            mock_request.assert_called_once_with("GET", "/registration")

    @pytest.mark.asyncio
    async def test_list_logs(self, client):
        """Test list_logs method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "logs": [
                    {"name": "syslog", "path": "/var/log/syslog"},
                    {"name": "docker.log", "path": "/var/log/docker.log"},
                ]
            }

            result = await client.list_logs()

            assert isinstance(result, LogList)
            mock_request.assert_called_once_with("GET", "/logs")

    @pytest.mark.asyncio
    async def test_get_log(self, client):
        """Test get_log method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"path": "/var/log/syslog", "content": "log content"}

            result = await client.get_log("syslog")

            assert isinstance(result, LogContent)
            mock_request.assert_called_once_with("GET", "/logs/syslog", params={"lines": 100})

    @pytest.mark.asyncio
    async def test_get_notification_overview(self, client):
        """Test get_notification_overview method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {
                "unread_count": 5,
                "total_count": 10,
            }

            result = await client.get_notification_overview()

            assert result.unread_count == 5
            mock_request.assert_called_once_with("GET", "/notifications/overview")

    @pytest.mark.asyncio
    async def test_get_unassigned_info(self, client):
        """Test get_unassigned_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"devices": [], "remote_shares": []}

            result = await client.get_unassigned_info()

            assert isinstance(result, UnassignedInfo)
            mock_request.assert_called_once_with("GET", "/unassigned")

    @pytest.mark.asyncio
    async def test_list_unassigned_devices(self, client):
        """Test list_unassigned_devices method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"devices": []}

            result = await client.list_unassigned_devices()

            assert isinstance(result, UnassignedDevicesResponse)
            mock_request.assert_called_once_with("GET", "/unassigned/devices")

    @pytest.mark.asyncio
    async def test_list_remote_shares(self, client):
        """Test list_remote_shares method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"remote_shares": []}

            result = await client.list_remote_shares()

            assert isinstance(result, RemoteSharesResponse)
            mock_request.assert_called_once_with("GET", "/unassigned/remote-shares")

    @pytest.mark.asyncio
    async def test_get_system_settings(self, client):
        """Test get_system_settings method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"timezone": "UTC", "language": "en"}

            result = await client.get_system_settings()

            assert isinstance(result, SystemSettings)
            mock_request.assert_called_once_with("GET", "/settings/system")

    @pytest.mark.asyncio
    async def test_get_docker_settings(self, client):
        """Test get_docker_settings method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"enabled": True, "image_path": "/mnt/user/docker"}

            result = await client.get_docker_settings()

            assert isinstance(result, DockerSettings)
            mock_request.assert_called_once_with("GET", "/settings/docker")

    @pytest.mark.asyncio
    async def test_get_vm_settings(self, client):
        """Test get_vm_settings method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"enabled": True, "default_domain": "/mnt/user/domains"}

            result = await client.get_vm_settings()

            assert isinstance(result, VMSettings)
            mock_request.assert_called_once_with("GET", "/settings/vm")

    @pytest.mark.asyncio
    async def test_get_disk_settings(self, client):
        """Test get_disk_settings method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"spindown_delay": 30}

            result = await client.get_disk_settings()

            assert isinstance(result, DiskSettings)
            mock_request.assert_called_once_with("GET", "/settings/disk")

    @pytest.mark.asyncio
    async def test_list_user_scripts(self, client):
        """Test list_user_scripts method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = []

            result = await client.list_user_scripts()

            assert result == []
            mock_request.assert_called_once_with("GET", "/user-scripts")

    @pytest.mark.asyncio
    async def test_list_zfs_pools(self, client):
        """Test list_zfs_pools method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = []

            result = await client.list_zfs_pools()

            assert result == []
            mock_request.assert_called_once_with("GET", "/zfs/pools")

    @pytest.mark.asyncio
    async def test_list_zfs_datasets(self, client):
        """Test list_zfs_datasets method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = []

            result = await client.list_zfs_datasets()

            assert result == []
            mock_request.assert_called_once_with("GET", "/zfs/datasets")

    @pytest.mark.asyncio
    async def test_list_zfs_snapshots(self, client):
        """Test list_zfs_snapshots method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = []

            result = await client.list_zfs_snapshots()

            assert result == []
            mock_request.assert_called_once_with("GET", "/zfs/snapshots")

    @pytest.mark.asyncio
    async def test_get_zfs_arc_stats(self, client):
        """Test get_zfs_arc_stats method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"size": 1000000, "hit_ratio": 0.95}

            result = await client.get_zfs_arc_stats()

            assert isinstance(result, ZFSArcStats)
            mock_request.assert_called_once_with("GET", "/zfs/arc-stats")

    @pytest.mark.asyncio
    async def test_get_nut_info(self, client):
        """Test get_nut_info method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"enabled": True, "ups_name": "myups"}

            result = await client.get_nut_info()

            assert isinstance(result, NUTInfo)
            mock_request.assert_called_once_with("GET", "/nut")

    @pytest.mark.asyncio
    async def test_get_collectors_status(self, client):
        """Test get_collectors_status method."""
        with patch.object(client, "_request", new_callable=AsyncMock) as mock_request:
            mock_request.return_value = {"collectors": []}

            result = await client.get_collectors_status()

            assert isinstance(result, CollectorStatus)
            mock_request.assert_called_once_with("GET", "/collectors")
