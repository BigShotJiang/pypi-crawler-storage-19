"""
Pages for TanML UI.
"""
