#!/usr/bin/env python3
"""
r321cloud 命令行接口
文件加密云存储库
"""

import argparse
import sys
import os

# 导入命令模块
from r321cloud.commands.file_commands import (
    cmd_get, cmd_list, cmd_search, cmd_filelock, cmd_fileunlock, cmd_download, cmd_search_direct
)
from r321cloud.commands.config_commands import cmd_config, cmd_source
from r321cloud.commands.dev_commands import cmd_devmode_upload, cmd_devmode_status
from r321cloud.commands.info_commands import cmd_about

from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji


def main() -> None:
    """主函数：解析命令行参数并执行相应命令"""
    # 检查开发者模式是否启用
    dev_mode_enabled = Config.get("dev_mode", False)
    
    parser = argparse.ArgumentParser(
        prog="r321-cloud",
        description=f"{KAOMOJI['welcome']} r321cloud - 文件加密云存储库",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""{KAOMOJI['happy']} 使用示例:
  r321-cloud get                   获取云端文件列表
  r321-cloud list                  显示本地文件列表
  r321-cloud search <关键词>       搜索文件（依赖本地缓存）
  r321-cloud search-direct <关键词> 直接搜索云端文件（免files.json）
  r321-cloud filelock <文件>       加密文件
  r321-cloud fileunlock <文件>     解密文件
  r321-cloud download <文件>       下载文件
  r321-cloud config                查看配置
  r321-cloud about                 关于信息

{KAOMOJI['info']} 更多帮助: r321-cloud <命令> --help"""
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # 获取文件列表命令
    parser_get = subparsers.add_parser("get", help="从 Gitee 获取文件列表")
    parser_get.set_defaults(func=cmd_get)

    # 显示文件列表命令
    parser_list = subparsers.add_parser("list", help="显示本地文件列表")
    parser_list.set_defaults(func=cmd_list)

    # 搜索文件命令（依赖本地缓存）
    parser_search = subparsers.add_parser("search", help="搜索文件（依赖本地缓存）")
    parser_search.add_argument("keyword", help="搜索关键词")
    parser_search.set_defaults(func=cmd_search)

    # 直接搜索云端文件命令（免files.json）
    parser_search_direct = subparsers.add_parser("search-direct", help="直接搜索云端文件（免files.json）")
    parser_search_direct.add_argument("keyword", help="搜索关键词")
    parser_search_direct.set_defaults(func=cmd_search_direct)

    # 加密文件命令
    parser_filelock = subparsers.add_parser("filelock", help="加密文件")
    parser_filelock.add_argument("file", help="要加密的文件路径")
    parser_filelock.add_argument("--password", help="加密密码")
    parser_filelock.add_argument("--description", help="文件描述", default="")
    parser_filelock.add_argument("--uploader", help="上传者", default="")
    parser_filelock.add_argument("--output", help="输出文件路径")
    parser_filelock.add_argument("--no-lock", action="store_true", 
                                help="无密码加密模式 (不推荐)")
    parser_filelock.set_defaults(func=cmd_filelock)

    # 解密文件命令
    parser_fileunlock = subparsers.add_parser("fileunlock", help="解密文件")
    parser_fileunlock.add_argument("file", help="要解密的文件路径")
    parser_fileunlock.add_argument("--output", help="输出文件路径")
    parser_fileunlock.set_defaults(func=cmd_fileunlock)

    # 下载文件命令
    parser_download = subparsers.add_parser("download", help="下载文件")
    parser_download.add_argument("filename", help="要下载的文件名")
    parser_download.add_argument("--output", help="输出文件路径")
    parser_download.set_defaults(func=cmd_download)

    # 配置管理命令
    parser_config = subparsers.add_parser("config", help="配置管理")
    parser_config.add_argument("--set-token", help="设置 Gitee API 访问令牌")
    parser_config.add_argument("--set-dev-mode", choices=["true", "false"], 
                              help="启用/禁用开发者模式")
    parser_config.set_defaults(func=cmd_config)

    # 配置源管理命令
    parser_source = subparsers.add_parser("source", help="配置源管理",
                                         formatter_class=argparse.RawDescriptionHelpFormatter,
                                         description=f"""{KAOMOJI['thinking']} 配置源管理

功能:
  • export - 导出当前配置为加密字符串
  • import - 从加密字符串导入配置
  • info   - 查看加密配置信息

{KAOMOJI['info']} 注意事项:
  • 导出配置包含敏感的API密钥，请妥善保管
  • 导入配置会覆盖当前的仓库设置
  • 默认加密密码: r321cloud_config""")
    parser_source.add_argument("action", choices=["export", "import", "info"], 
                              help="操作类型: export(导出), import(导入), info(查看信息)")
    parser_source.add_argument("--file", help="加密配置文件路径")
    parser_source.add_argument("--data", dest="config_data", help="加密配置数据字符串")
    parser_source.add_argument("--output", help="导出文件路径")
    parser_source.add_argument("--password", help="加密/解密密码")
    parser_source.set_defaults(func=cmd_source)

    # 信息命令
    parser_about = subparsers.add_parser("about", help="显示制作者/版本/更新记录信息")
    parser_about.set_defaults(func=cmd_about)

    # 开发者模式下的命令
    if dev_mode_enabled:
        parser_devmode = subparsers.add_parser("devmode", help="开发者模式命令 (开发中)",
                                             formatter_class=argparse.RawDescriptionHelpFormatter,
                                             description=f"""{KAOMOJI['thinking']} 开发者模式命令 (开发中)

⚠️  警告: 此功能仍在开发中，可能存在不稳定情况
    启用方法: r321-cloud config --set-dev-mode true

可用命令:
  status   查看开发者模式状态
  upload   上传文件到云端 (开发中)

注意: 禁用开发者模式后此命令将隐藏""")
        devmode_subparsers = parser_devmode.add_subparsers(dest="devmode_command", help="开发者模式子命令")
        
        # 状态命令
        parser_status = devmode_subparsers.add_parser("status", help="查看开发者模式状态")
        parser_status.set_defaults(func=cmd_devmode_status)
        
        # 上传命令 (开发中)
        parser_upload = devmode_subparsers.add_parser("upload", help="上传文件到云端 (开发中)")
        parser_upload.add_argument("file", help="要上传的文件路径")
        parser_upload.add_argument("--message", help="提交信息", default="上传文件")
        parser_upload.set_defaults(func=cmd_devmode_upload)
        


    args = parser.parse_args()

    if args.command:
        # 处理开发者模式命令
        if args.command == "devmode" and dev_mode_enabled:
            if hasattr(args, 'devmode_command') and args.devmode_command:
                args.func(args)
            else:
                parser_devmode.print_help()
        else:
            args.func(args)
    else:
        # 显示帮助信息，如果开发者模式启用则提示
        parser.print_help()


if __name__ == "__main__":
    main()