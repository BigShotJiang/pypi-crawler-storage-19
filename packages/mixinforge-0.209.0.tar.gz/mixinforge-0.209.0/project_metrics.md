# Project Metrics

| Metric | Main code | Unit Tests | Total |
|--------|-----------|------------|-------|
| Lines Of Code (LOC) | 3189 | 5959 | 9148 |
| Source Lines Of Code (SLOC) | 1416 | 3596 | 5012 |
| Classes | 13 | 133 | 146 |
| Functions / Methods | 98 | 557 | 655 |
| Files | 15 | 38 | 53 |
