"""DOM extraction utilities."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import structlog
from playwright.async_api import Page

logger = structlog.get_logger(__name__)


class DomExtractor:
    """DOM 추출기.

    Playwright Page에서 DOM 정보를 추출합니다.

    Responsibilities:
        1. 페이지 HTML 추출
        2. URL, 타이틀 등 메타데이터 수집
        3. DOM 데이터 구조화
    """

    def __init__(self, page: Page) -> None:
        """Initialize DOM extractor.

        Args:
            page: Playwright 페이지
        """
        self._page = page

    async def extract(self) -> dict[str, Any]:
        """DOM 추출.

        Returns:
            DOM 데이터 딕셔너리:
            - url: 현재 URL
            - title: 페이지 타이틀
            - html: 페이지 HTML
            - timestamp: 추출 시간 (ISO 8601)
            - viewport: 뷰포트 크기
        """
        logger.debug("extracting_dom")

        # 페이지 정보 수집
        url = self._page.url
        title = await self._page.title()

        # HTML 추출 (전체 document)
        html = await self._page.content()

        # 뷰포트 크기
        viewport = self._page.viewport_size

        # 타임스탬프
        timestamp = datetime.now(UTC).isoformat()

        dom_data = {
            "url": url,
            "title": title,
            "html": html,
            "timestamp": timestamp,
            "viewport": viewport,
        }

        logger.info(
            "dom_extracted",
            url=url,
            title=title,
            html_length=len(html),
        )

        return dom_data

    async def extract_element(self, selector: str) -> dict[str, Any] | None:
        """특정 요소의 DOM 추출.

        Args:
            selector: CSS 선택자

        Returns:
            요소 정보 또는 None
        """
        element = await self._page.query_selector(selector)
        if not element:
            logger.debug("element_not_found", selector=selector)
            return None

        # 요소 정보 수집
        outer_html = await element.evaluate("el => el.outerHTML")
        inner_text = await element.inner_text()
        bounding_box = await element.bounding_box()

        return {
            "selector": selector,
            "outer_html": outer_html,
            "inner_text": inner_text,
            "bounding_box": bounding_box,
        }

    async def extract_interactive_elements(self) -> list[dict[str, Any]]:
        """상호작용 가능한 요소들 추출.

        Returns:
            상호작용 가능한 요소 목록
        """
        # 클릭 가능한 요소 선택자
        selectors = [
            "a[href]",
            "button",
            "input",
            "select",
            "textarea",
            "[role='button']",
            "[role='link']",
            "[onclick]",
        ]

        elements = []
        for selector in selectors:
            found = await self._page.query_selector_all(selector)
            for el in found:
                try:
                    tag_name = await el.evaluate("el => el.tagName.toLowerCase()")
                    text = await el.inner_text() if tag_name not in ["input", "select"] else ""
                    box = await el.bounding_box()

                    # visible한 요소만 포함
                    if box and box["width"] > 0 and box["height"] > 0:
                        elements.append({
                            "tag": tag_name,
                            "text": text[:100] if text else "",  # 텍스트 길이 제한
                            "selector": selector,
                            "bounding_box": box,
                        })
                except Exception:
                    # 요소 접근 실패 시 스킵
                    continue

        logger.debug("interactive_elements_extracted", count=len(elements))
        return elements
