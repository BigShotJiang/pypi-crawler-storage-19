"""Nova Agent - Browser automation agent for Nova QA platform."""

__version__ = "0.2.2"
__all__ = ["__version__"]
