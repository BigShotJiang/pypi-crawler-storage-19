#!/usr/bin/env python3
"""
RTLViz CLI - Command-line interface for RTL diagram setup and configuration.

Note: Diagram generation is only available via AI IDE (MCP tools).
After setup, ask your AI: "Generate RTL diagram for /path/to/verilog"

Usage:
    rtlviz setup    # Configure MCP for AI IDEs
    rtlviz check    # Verify dependencies
"""

import argparse
import sys
from pathlib import Path

from .telemetry import ping_cli_setup



def cmd_setup(args):
    """Run IDE setup."""
    from .setup import main as setup_main
    import sys
    original_argv = sys.argv
    
    # Build new argv for setup module
    new_argv = ['rtlviz-setup']
    if args.all:
        new_argv.append('--all')
    if args.antigravity:
        new_argv.append('--antigravity')
    if args.claude:
        new_argv.append('--claude')
    if args.cursor:
        new_argv.append('--cursor')
    if args.vscode:
        new_argv.append('--vscode')
    if args.windsurf:
        new_argv.append('--windsurf')
    
    sys.argv = new_argv
    result = setup_main()
    sys.argv = original_argv
    
    if result == 0:
        print("\nPlease restart your IDE (Cursor, VS Code, etc.) to load the new MCP configuration.")
        
    return result




def cmd_check(args):
    """Check dependencies."""
    from .deps import print_dependency_status
    return 0 if print_dependency_status() else 1


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="rtlviz",
        description="RTL Block Diagram Generator - Setup and Configuration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  rtlviz setup     # Configure MCP for AI IDEs (Cursor, Claude, VS Code, etc.)
  rtlviz check     # Verify dependencies

Diagram Generation:
  Diagrams are generated via AI IDE after setup. Just ask your AI:
  "Generate an RTL diagram for /path/to/verilog"
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Setup command
    setup_parser = subparsers.add_parser("setup", help="Configure MCP server for AI IDEs")
    setup_parser.add_argument("--all", action="store_true", help="Force configure all IDEs")
    setup_parser.add_argument("--antigravity", action="store_true", help="Configure Antigravity only")
    setup_parser.add_argument("--claude", action="store_true", help="Configure Claude Desktop only")
    setup_parser.add_argument("--cursor", action="store_true", help="Configure Cursor only")
    setup_parser.add_argument("--vscode", action="store_true", help="Configure VS Code Copilot only")
    setup_parser.add_argument("--windsurf", action="store_true", help="Configure Windsurf only")
    setup_parser.set_defaults(func=cmd_setup)
    
    # Check command
    check_parser = subparsers.add_parser("check", help="Check system dependencies")
    check_parser.set_defaults(func=cmd_check)
    
    # Parse args
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
