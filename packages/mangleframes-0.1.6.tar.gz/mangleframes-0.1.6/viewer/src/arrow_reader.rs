//! Arrow IPC stream parsing and JSON conversion.

use std::io::Cursor;

use arrow::array::RecordBatch;
use arrow_ipc::reader::StreamReader;
use arrow_json::ArrayWriter;
use serde_json::Value;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ArrowError {
    #[error("Failed to parse Arrow IPC: {0}")]
    ParseError(#[from] arrow::error::ArrowError),
}

pub fn parse_arrow_stream(data: &[u8]) -> Result<Vec<RecordBatch>, ArrowError> {
    let cursor = Cursor::new(data);
    let reader = StreamReader::try_new(cursor, None)?;
    let batches: Result<Vec<_>, _> = reader.collect();
    Ok(batches?)
}

/// High-performance JSON conversion returning raw bytes.
/// Skips intermediate Value parsing for maximum speed.
pub fn batches_to_json_bytes(batches: &[RecordBatch], offset: usize, limit: usize) -> (Vec<u8>, usize) {
    if batches.is_empty() {
        return (b"[]".to_vec(), 0);
    }

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    let actual_limit = limit.min(total_rows.saturating_sub(offset));
    if actual_limit == 0 {
        return (b"[]".to_vec(), 0);
    }

    let sliced = slice_batches(batches, offset, actual_limit);
    if sliced.is_empty() {
        return (b"[]".to_vec(), 0);
    }

    let mut buf = Vec::with_capacity(actual_limit * 256);
    {
        let mut writer = ArrayWriter::new(&mut buf);
        for batch in &sliced {
            if writer.write(batch).is_err() {
                return (b"[]".to_vec(), 0);
            }
        }
        if writer.finish().is_err() {
            return (b"[]".to_vec(), 0);
        }
    }

    let row_count = sliced.iter().map(|b| b.num_rows()).sum();
    (buf, row_count)
}

/// Legacy function for compatibility - parses back to Value
pub fn batches_to_json(batches: &[RecordBatch], offset: usize, limit: usize) -> Value {
    let (bytes, _) = batches_to_json_bytes(batches, offset, limit);
    serde_json::from_slice(&bytes).unwrap_or(Value::Array(vec![]))
}

/// Slice batches to extract rows in range [offset, offset+limit)
fn slice_batches(batches: &[RecordBatch], offset: usize, limit: usize) -> Vec<RecordBatch> {
    let mut result = Vec::new();
    let mut current_offset = 0;
    let mut remaining = limit;

    for batch in batches {
        let batch_rows = batch.num_rows();

        if current_offset + batch_rows <= offset {
            current_offset += batch_rows;
            continue;
        }

        let start = if current_offset < offset { offset - current_offset } else { 0 };
        let len = remaining.min(batch_rows - start);

        if len > 0 {
            let sliced = batch.slice(start, len);
            result.push(sliced);
            remaining -= len;
        }

        if remaining == 0 {
            break;
        }
        current_offset += batch_rows;
    }

    result
}

pub fn total_row_count(batches: &[RecordBatch]) -> usize {
    batches.iter().map(|b| b.num_rows()).sum()
}
