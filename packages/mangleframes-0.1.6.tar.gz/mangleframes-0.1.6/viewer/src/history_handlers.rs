//! HTTP handlers for history coverage analysis endpoints.

use std::sync::Arc;

use axum::extract::State;
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;

use crate::history_analysis::{
    FrameKeyStats, FrameTemporalStats, HistoryAnalyzer, PairwiseOverlap,
};
use crate::web_server::AppState;

#[derive(Deserialize)]
pub struct FrameConfig {
    pub frame: String,
    pub columns: Vec<String>,
}

#[derive(Deserialize)]
pub struct HistoryRequest {
    pub frames: Vec<FrameConfig>,
    pub temporal_column: Option<String>,
    pub bucket_size: Option<String>,
}

pub async fn analyze_history(
    State(state): State<Arc<AppState>>,
    Json(req): Json<HistoryRequest>,
) -> impl IntoResponse {
    if req.frames.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "At least one frame required");
    }

    if req.frames.len() > 5 {
        return error_response(StatusCode::BAD_REQUEST, "Maximum 5 frames supported");
    }

    let mut analyzer = HistoryAnalyzer::new();
    let bucket = req.bucket_size.as_deref().unwrap_or("month");

    // Collect key stats for each frame
    for fc in &req.frames {
        match state.client.get_join_keys(&fc.frame, &fc.columns) {
            Ok(result) => {
                let stats = FrameKeyStats {
                    frame: result["frame"].as_str().unwrap_or("").to_string(),
                    columns: fc.columns.clone(),
                    cardinality: result["cardinality"].as_u64().unwrap_or(0) as usize,
                    null_count: result["null_count"].as_u64().unwrap_or(0) as usize,
                    total_rows: result["total_rows"].as_u64().unwrap_or(0) as usize,
                };
                analyzer.add_key_stats(stats);
            }
            Err(e) => {
                return error_response(
                    StatusCode::INTERNAL_SERVER_ERROR,
                    &format!("Failed to get key stats for {}: {}", fc.frame, e),
                );
            }
        }
    }

    // Collect temporal stats if temporal column specified
    if let Some(ref temp_col) = req.temporal_column {
        for fc in &req.frames {
            match state.client.get_join_temporal(&fc.frame, temp_col, bucket) {
                Ok(result) => {
                    let buckets: std::collections::HashMap<String, usize> = result["buckets"]
                        .as_object()
                        .map(|obj| {
                            obj.iter()
                                .map(|(k, v)| (k.clone(), v.as_u64().unwrap_or(0) as usize))
                                .collect()
                        })
                        .unwrap_or_default();

                    let stats = FrameTemporalStats {
                        frame: fc.frame.clone(),
                        column: temp_col.clone(),
                        bucket_size: bucket.to_string(),
                        min: result["min"].as_str().map(String::from),
                        max: result["max"].as_str().map(String::from),
                        buckets,
                    };
                    analyzer.add_temporal_stats(stats);
                }
                Err(e) => {
                    // Temporal column might not exist in all frames - log but continue
                    eprintln!(
                        "Warning: temporal stats failed for {}: {}",
                        fc.frame, e
                    );
                }
            }
        }
    }

    // Compute pairwise overlaps
    for i in 0..req.frames.len() {
        for j in (i + 1)..req.frames.len() {
            let f1 = &req.frames[i];
            let f2 = &req.frames[j];

            match state
                .client
                .get_join_overlap(&f1.frame, &f2.frame, &f1.columns, &f2.columns)
            {
                Ok(result) => {
                    let overlap = PairwiseOverlap {
                        frame1: f1.frame.clone(),
                        frame2: f2.frame.clone(),
                        left_total: result["left_total"].as_u64().unwrap_or(0) as usize,
                        right_total: result["right_total"].as_u64().unwrap_or(0) as usize,
                        left_only: result["left_only"].as_u64().unwrap_or(0) as usize,
                        right_only: result["right_only"].as_u64().unwrap_or(0) as usize,
                        both: result["both"].as_u64().unwrap_or(0) as usize,
                        overlap_pct: result["overlap_pct"].as_f64().unwrap_or(0.0),
                    };
                    analyzer.add_overlap(overlap);
                }
                Err(e) => {
                    return error_response(
                        StatusCode::INTERNAL_SERVER_ERROR,
                        &format!(
                            "Failed to compute overlap between {} and {}: {}",
                            f1.frame, f2.frame, e
                        ),
                    );
                }
            }
        }
    }

    // Compute final coverage result
    let frame_names: Vec<String> = req.frames.iter().map(|f| f.frame.clone()).collect();
    match analyzer.compute_coverage(&frame_names) {
        Ok(result) => Json(result).into_response(),
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

fn error_response(status: StatusCode, msg: &str) -> axum::response::Response {
    (status, Json(json!({"error": msg}))).into_response()
}
