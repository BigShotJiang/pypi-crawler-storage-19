//! DataFusion SQL query engine integration.

use std::sync::Arc;

use arrow::record_batch::RecordBatch;
use datafusion::datasource::MemTable;
use datafusion::prelude::*;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum QueryError {
    #[error("DataFusion error: {0}")]
    DataFusion(#[from] datafusion::error::DataFusionError),
    #[error("No batches to register")]
    NoBatches,
}

pub struct QueryEngine {
    ctx: SessionContext,
}

impl QueryEngine {
    pub fn new() -> Self {
        Self {
            ctx: SessionContext::new(),
        }
    }

    pub async fn register_frame(&self, name: &str, batches: Vec<RecordBatch>) -> Result<(), QueryError> {
        if batches.is_empty() {
            return Err(QueryError::NoBatches);
        }

        let schema = batches[0].schema();
        let table = MemTable::try_new(schema, vec![batches])?;
        self.ctx.register_table(name, Arc::new(table))?;

        Ok(())
    }

    pub async fn execute(&self, sql: &str) -> Result<Vec<RecordBatch>, QueryError> {
        let df = self.ctx.sql(sql).await?;
        let batches = df.collect().await?;
        Ok(batches)
    }
}
