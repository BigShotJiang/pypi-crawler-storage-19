//! Join analysis using DataFusion SQL execution.

use std::sync::Arc;

use arrow::record_batch::RecordBatch;
use datafusion::datasource::MemTable;
use datafusion::prelude::*;
use serde::Serialize;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum JoinError {
    #[error("DataFusion error: {0}")]
    DataFusion(#[from] datafusion::error::DataFusionError),
    #[error("Frame not found: {0}")]
    FrameNotFound(String),
    #[error("No data in frame: {0}")]
    NoData(String),
    #[error("Key count mismatch: left={0}, right={1}")]
    KeyMismatch(usize, usize),
}

#[derive(Serialize)]
pub struct JoinStatistics {
    pub left_total: usize,
    pub right_total: usize,
    pub matched_left: usize,
    pub matched_right: usize,
    pub match_rate_left: f64,
    pub match_rate_right: f64,
    pub cardinality: String,
    pub left_null_keys: usize,
    pub right_null_keys: usize,
    pub left_duplicate_keys: usize,
    pub right_duplicate_keys: usize,
}

#[derive(Serialize)]
pub struct UnmatchedResult {
    pub total: usize,
    pub rows: Vec<serde_json::Value>,
}

#[derive(Serialize)]
pub struct JoinAnalysisResult {
    pub statistics: JoinStatistics,
    pub left_unmatched: UnmatchedResult,
    pub right_unmatched: UnmatchedResult,
}

pub struct JoinAnalyzer {
    ctx: SessionContext,
}

impl JoinAnalyzer {
    pub fn new() -> Self {
        Self { ctx: SessionContext::new() }
    }

    pub async fn analyze(
        &self,
        left: Vec<RecordBatch>,
        right: Vec<RecordBatch>,
        left_keys: &[String],
        right_keys: &[String],
        sample_limit: usize,
    ) -> Result<JoinAnalysisResult, JoinError> {
        if left_keys.len() != right_keys.len() {
            return Err(JoinError::KeyMismatch(left_keys.len(), right_keys.len()));
        }

        self.register_table("left_tbl", left).await?;
        self.register_table("right_tbl", right).await?;

        let stats = self.compute_statistics(left_keys, right_keys).await?;
        let left_unmatched = self.get_unmatched("left_tbl", "right_tbl", left_keys, right_keys, sample_limit).await?;
        let right_unmatched = self.get_unmatched("right_tbl", "left_tbl", right_keys, left_keys, sample_limit).await?;

        Ok(JoinAnalysisResult { statistics: stats, left_unmatched, right_unmatched })
    }

    async fn register_table(&self, name: &str, batches: Vec<RecordBatch>) -> Result<(), JoinError> {
        if batches.is_empty() {
            return Err(JoinError::NoData(name.to_string()));
        }
        let schema = batches[0].schema();
        let table = MemTable::try_new(schema, vec![batches])?;
        self.ctx.register_table(name, Arc::new(table))?;
        Ok(())
    }

    async fn compute_statistics(
        &self,
        left_keys: &[String],
        right_keys: &[String],
    ) -> Result<JoinStatistics, JoinError> {
        let left_total = self.count_rows("left_tbl").await?;
        let right_total = self.count_rows("right_tbl").await?;
        let left_null_keys = self.count_null_keys("left_tbl", left_keys).await?;
        let right_null_keys = self.count_null_keys("right_tbl", right_keys).await?;
        let left_duplicate_keys = self.count_duplicate_keys("left_tbl", left_keys).await?;
        let right_duplicate_keys = self.count_duplicate_keys("right_tbl", right_keys).await?;

        let (matched_left, matched_right, cardinality) =
            self.compute_cardinality(left_keys, right_keys).await?;

        let match_rate_left = if left_total > 0 { matched_left as f64 / left_total as f64 } else { 0.0 };
        let match_rate_right = if right_total > 0 { matched_right as f64 / right_total as f64 } else { 0.0 };

        Ok(JoinStatistics {
            left_total, right_total, matched_left, matched_right,
            match_rate_left, match_rate_right, cardinality,
            left_null_keys, right_null_keys, left_duplicate_keys, right_duplicate_keys,
        })
    }

    async fn count_rows(&self, table: &str) -> Result<usize, JoinError> {
        let sql = format!("SELECT COUNT(*) as cnt FROM {}", table);
        let batches = self.ctx.sql(&sql).await?.collect().await?;
        Ok(extract_count(&batches))
    }

    async fn count_null_keys(&self, table: &str, keys: &[String]) -> Result<usize, JoinError> {
        let null_conditions: Vec<String> = keys.iter().map(|k| format!("\"{}\" IS NULL", k)).collect();
        let sql = format!(
            "SELECT COUNT(*) as cnt FROM {} WHERE {}",
            table,
            null_conditions.join(" OR ")
        );
        let batches = self.ctx.sql(&sql).await?.collect().await?;
        Ok(extract_count(&batches))
    }

    async fn count_duplicate_keys(&self, table: &str, keys: &[String]) -> Result<usize, JoinError> {
        let key_cols = keys.iter().map(|k| format!("\"{}\"", k)).collect::<Vec<_>>().join(", ");
        let sql = format!(
            "SELECT COUNT(*) as cnt FROM (SELECT {key_cols} FROM {table} GROUP BY {key_cols} HAVING COUNT(*) > 1)"
        );
        let batches = self.ctx.sql(&sql).await?.collect().await?;
        Ok(extract_count(&batches))
    }

    async fn compute_cardinality(
        &self,
        left_keys: &[String],
        right_keys: &[String],
    ) -> Result<(usize, usize, String), JoinError> {
        let join_condition = build_join_condition("l", "r", left_keys, right_keys);

        // Count distinct matched keys on each side
        let left_key_expr = keys_to_concat("l", left_keys);
        let right_key_expr = keys_to_concat("r", right_keys);

        let sql = format!(
            "SELECT COUNT(DISTINCT {left_key_expr}) as left_matched, \
             COUNT(DISTINCT {right_key_expr}) as right_matched, \
             COUNT(*) as total_pairs \
             FROM left_tbl l INNER JOIN right_tbl r ON {join_condition}"
        );

        let batches = self.ctx.sql(&sql).await?.collect().await?;
        let (left_matched, right_matched, total_pairs) = extract_cardinality_counts(&batches);

        let cardinality = determine_cardinality(left_matched, right_matched, total_pairs);
        Ok((left_matched, right_matched, cardinality.to_string()))
    }

    async fn get_unmatched(
        &self,
        main_table: &str,
        other_table: &str,
        main_keys: &[String],
        other_keys: &[String],
        limit: usize,
    ) -> Result<UnmatchedResult, JoinError> {
        let join_condition = build_join_condition("m", "o", main_keys, other_keys);

        let count_sql = format!(
            "SELECT COUNT(*) as cnt FROM {main_table} m \
             WHERE NOT EXISTS (SELECT 1 FROM {other_table} o WHERE {join_condition})"
        );
        let count_batches = self.ctx.sql(&count_sql).await?.collect().await?;
        let total = extract_count(&count_batches);

        let data_sql = format!(
            "SELECT m.* FROM {main_table} m \
             WHERE NOT EXISTS (SELECT 1 FROM {other_table} o WHERE {join_condition}) \
             LIMIT {limit}"
        );
        let batches = self.ctx.sql(&data_sql).await?.collect().await?;
        let rows = batches_to_json_values(&batches);

        Ok(UnmatchedResult { total, rows })
    }

    #[allow(clippy::too_many_arguments)]
    pub async fn get_unmatched_page(
        &self,
        left: Vec<RecordBatch>,
        right: Vec<RecordBatch>,
        left_keys: &[String],
        right_keys: &[String],
        side: &str,
        offset: usize,
        limit: usize,
    ) -> Result<UnmatchedResult, JoinError> {
        self.register_table("left_tbl", left).await?;
        self.register_table("right_tbl", right).await?;

        let (main_table, other_table, main_keys, other_keys) = if side == "left" {
            ("left_tbl", "right_tbl", left_keys, right_keys)
        } else {
            ("right_tbl", "left_tbl", right_keys, left_keys)
        };

        let join_condition = build_join_condition("m", "o", main_keys, other_keys);

        let count_sql = format!(
            "SELECT COUNT(*) as cnt FROM {main_table} m \
             WHERE NOT EXISTS (SELECT 1 FROM {other_table} o WHERE {join_condition})"
        );
        let count_batches = self.ctx.sql(&count_sql).await?.collect().await?;
        let total = extract_count(&count_batches);

        let data_sql = format!(
            "SELECT m.* FROM {main_table} m \
             WHERE NOT EXISTS (SELECT 1 FROM {other_table} o WHERE {join_condition}) \
             LIMIT {limit} OFFSET {offset}"
        );
        let batches = self.ctx.sql(&data_sql).await?.collect().await?;
        let rows = batches_to_json_values(&batches);

        Ok(UnmatchedResult { total, rows })
    }
}

fn build_join_condition(left_alias: &str, right_alias: &str, left_keys: &[String], right_keys: &[String]) -> String {
    left_keys.iter().zip(right_keys.iter())
        .map(|(lk, rk)| format!("{}.\"{}\" = {}.\"{}\"", left_alias, lk, right_alias, rk))
        .collect::<Vec<_>>()
        .join(" AND ")
}

fn keys_to_concat(alias: &str, keys: &[String]) -> String {
    if keys.len() == 1 {
        format!("{}.\"{}\"", alias, keys[0])
    } else {
        let parts: Vec<String> = keys.iter().map(|k| format!("CAST({}.\"{}\" AS VARCHAR)", alias, k)).collect();
        format!("CONCAT({})", parts.join(", "))
    }
}

fn extract_count(batches: &[RecordBatch]) -> usize {
    if batches.is_empty() || batches[0].num_rows() == 0 {
        return 0;
    }
    let col = batches[0].column(0);
    if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Int64Array>() {
        arr.value(0) as usize
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::UInt64Array>() {
        arr.value(0) as usize
    } else {
        0
    }
}

fn extract_cardinality_counts(batches: &[RecordBatch]) -> (usize, usize, usize) {
    if batches.is_empty() || batches[0].num_rows() == 0 {
        return (0, 0, 0);
    }
    let batch = &batches[0];
    let left = extract_int_col(batch.column(0));
    let right = extract_int_col(batch.column(1));
    let total = extract_int_col(batch.column(2));
    (left, right, total)
}

fn extract_int_col(col: &arrow::array::ArrayRef) -> usize {
    if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Int64Array>() {
        arr.value(0) as usize
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::UInt64Array>() {
        arr.value(0) as usize
    } else {
        0
    }
}

fn determine_cardinality(left_distinct: usize, right_distinct: usize, total_pairs: usize) -> &'static str {
    if total_pairs == 0 {
        return "N/A";
    }
    let left_ratio = total_pairs as f64 / left_distinct.max(1) as f64;
    let right_ratio = total_pairs as f64 / right_distinct.max(1) as f64;

    match (left_ratio <= 1.05, right_ratio <= 1.05) {
        (true, true) => "1:1",
        (true, false) => "1:N",
        (false, true) => "N:1",
        (false, false) => "N:M",
    }
}

fn batches_to_json_values(batches: &[RecordBatch]) -> Vec<serde_json::Value> {
    use arrow::json::ArrayWriter;
    use std::io::Cursor;

    if batches.is_empty() {
        return vec![];
    }

    let mut buf = Vec::new();
    {
        let cursor = Cursor::new(&mut buf);
        let mut writer = ArrayWriter::new(cursor);
        for batch in batches {
            if batch.num_rows() > 0 {
                let _ = writer.write(batch);
            }
        }
        let _ = writer.finish();
    }

    serde_json::from_slice(&buf).unwrap_or_default()
}
