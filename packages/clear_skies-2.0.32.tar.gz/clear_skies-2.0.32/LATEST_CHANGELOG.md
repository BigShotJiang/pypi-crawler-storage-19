## [2.0.32] - 2026-01-12

### Fixed
- Insert di for port fowarding

