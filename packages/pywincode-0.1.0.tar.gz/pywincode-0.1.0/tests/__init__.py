"""Tests for pywincode."""
