"""Mistode code obfuscation tool - main entry point."""

from .cli import main

if __name__ == "__main__":
    main()
