"""Tests for niveshpy."""
