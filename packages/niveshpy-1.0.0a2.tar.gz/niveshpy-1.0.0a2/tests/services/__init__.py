"""Service tests for niveshpy."""
