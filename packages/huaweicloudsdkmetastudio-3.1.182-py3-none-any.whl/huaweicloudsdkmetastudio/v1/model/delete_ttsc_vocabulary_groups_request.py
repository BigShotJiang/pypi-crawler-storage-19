# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteTtscVocabularyGroupsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'x_request_id': 'str',
        'x_app_user_id': 'str',
        'offset': 'int',
        'limit': 'int',
        'group_id': 'str'
    }

    attribute_map = {
        'x_request_id': 'X-Request-Id',
        'x_app_user_id': 'X-App-UserId',
        'offset': 'offset',
        'limit': 'limit',
        'group_id': 'group_id'
    }

    def __init__(self, x_request_id=None, x_app_user_id=None, offset=None, limit=None, group_id=None):
        r"""DeleteTtscVocabularyGroupsRequest

        The model defined in huaweicloud sdk

        :param x_request_id: 请求requestId，用来标识一路请求，用于问题跟踪定位，建议使用uuId，若不携带，则后台自动生成
        :type x_request_id: str
        :param x_app_user_id: 第三方用户ID。不允许输入中文。
        :type x_app_user_id: str
        :param offset: 查询偏移量,若超过最大数量，则返回最后一页
        :type offset: int
        :param limit: 查询数量
        :type limit: int
        :param group_id: 分组id
        :type group_id: str
        """
        
        

        self._x_request_id = None
        self._x_app_user_id = None
        self._offset = None
        self._limit = None
        self._group_id = None
        self.discriminator = None

        if x_request_id is not None:
            self.x_request_id = x_request_id
        if x_app_user_id is not None:
            self.x_app_user_id = x_app_user_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        self.group_id = group_id

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this DeleteTtscVocabularyGroupsRequest.

        请求requestId，用来标识一路请求，用于问题跟踪定位，建议使用uuId，若不携带，则后台自动生成

        :return: The x_request_id of this DeleteTtscVocabularyGroupsRequest.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this DeleteTtscVocabularyGroupsRequest.

        请求requestId，用来标识一路请求，用于问题跟踪定位，建议使用uuId，若不携带，则后台自动生成

        :param x_request_id: The x_request_id of this DeleteTtscVocabularyGroupsRequest.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    @property
    def x_app_user_id(self):
        r"""Gets the x_app_user_id of this DeleteTtscVocabularyGroupsRequest.

        第三方用户ID。不允许输入中文。

        :return: The x_app_user_id of this DeleteTtscVocabularyGroupsRequest.
        :rtype: str
        """
        return self._x_app_user_id

    @x_app_user_id.setter
    def x_app_user_id(self, x_app_user_id):
        r"""Sets the x_app_user_id of this DeleteTtscVocabularyGroupsRequest.

        第三方用户ID。不允许输入中文。

        :param x_app_user_id: The x_app_user_id of this DeleteTtscVocabularyGroupsRequest.
        :type x_app_user_id: str
        """
        self._x_app_user_id = x_app_user_id

    @property
    def offset(self):
        r"""Gets the offset of this DeleteTtscVocabularyGroupsRequest.

        查询偏移量,若超过最大数量，则返回最后一页

        :return: The offset of this DeleteTtscVocabularyGroupsRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this DeleteTtscVocabularyGroupsRequest.

        查询偏移量,若超过最大数量，则返回最后一页

        :param offset: The offset of this DeleteTtscVocabularyGroupsRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this DeleteTtscVocabularyGroupsRequest.

        查询数量

        :return: The limit of this DeleteTtscVocabularyGroupsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this DeleteTtscVocabularyGroupsRequest.

        查询数量

        :param limit: The limit of this DeleteTtscVocabularyGroupsRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def group_id(self):
        r"""Gets the group_id of this DeleteTtscVocabularyGroupsRequest.

        分组id

        :return: The group_id of this DeleteTtscVocabularyGroupsRequest.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this DeleteTtscVocabularyGroupsRequest.

        分组id

        :param group_id: The group_id of this DeleteTtscVocabularyGroupsRequest.
        :type group_id: str
        """
        self._group_id = group_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteTtscVocabularyGroupsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
