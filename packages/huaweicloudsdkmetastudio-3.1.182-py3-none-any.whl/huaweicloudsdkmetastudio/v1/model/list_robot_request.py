# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListRobotRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'x_app_user_id': 'str',
        'offset': 'int',
        'limit': 'int',
        'room_id': 'str',
        'robot_type': 'str'
    }

    attribute_map = {
        'x_app_user_id': 'X-App-UserId',
        'offset': 'offset',
        'limit': 'limit',
        'room_id': 'room_id',
        'robot_type': 'robot_type'
    }

    def __init__(self, x_app_user_id=None, offset=None, limit=None, room_id=None, robot_type=None):
        r"""ListRobotRequest

        The model defined in huaweicloud sdk

        :param x_app_user_id: 第三方用户ID。不允许输入中文。
        :type x_app_user_id: str
        :param offset: 偏移量，表示从此偏移量开始查询。
        :type offset: int
        :param limit: 每页显示的条目数量。
        :type limit: int
        :param room_id: 智能交互对话房间ID。
        :type room_id: str
        :param robot_type: 交互对接类型  * LIVE:直播交互  * CHAT:智能交互
        :type robot_type: str
        """
        
        

        self._x_app_user_id = None
        self._offset = None
        self._limit = None
        self._room_id = None
        self._robot_type = None
        self.discriminator = None

        if x_app_user_id is not None:
            self.x_app_user_id = x_app_user_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if room_id is not None:
            self.room_id = room_id
        if robot_type is not None:
            self.robot_type = robot_type

    @property
    def x_app_user_id(self):
        r"""Gets the x_app_user_id of this ListRobotRequest.

        第三方用户ID。不允许输入中文。

        :return: The x_app_user_id of this ListRobotRequest.
        :rtype: str
        """
        return self._x_app_user_id

    @x_app_user_id.setter
    def x_app_user_id(self, x_app_user_id):
        r"""Sets the x_app_user_id of this ListRobotRequest.

        第三方用户ID。不允许输入中文。

        :param x_app_user_id: The x_app_user_id of this ListRobotRequest.
        :type x_app_user_id: str
        """
        self._x_app_user_id = x_app_user_id

    @property
    def offset(self):
        r"""Gets the offset of this ListRobotRequest.

        偏移量，表示从此偏移量开始查询。

        :return: The offset of this ListRobotRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListRobotRequest.

        偏移量，表示从此偏移量开始查询。

        :param offset: The offset of this ListRobotRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListRobotRequest.

        每页显示的条目数量。

        :return: The limit of this ListRobotRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListRobotRequest.

        每页显示的条目数量。

        :param limit: The limit of this ListRobotRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def room_id(self):
        r"""Gets the room_id of this ListRobotRequest.

        智能交互对话房间ID。

        :return: The room_id of this ListRobotRequest.
        :rtype: str
        """
        return self._room_id

    @room_id.setter
    def room_id(self, room_id):
        r"""Sets the room_id of this ListRobotRequest.

        智能交互对话房间ID。

        :param room_id: The room_id of this ListRobotRequest.
        :type room_id: str
        """
        self._room_id = room_id

    @property
    def robot_type(self):
        r"""Gets the robot_type of this ListRobotRequest.

        交互对接类型  * LIVE:直播交互  * CHAT:智能交互

        :return: The robot_type of this ListRobotRequest.
        :rtype: str
        """
        return self._robot_type

    @robot_type.setter
    def robot_type(self, robot_type):
        r"""Sets the robot_type of this ListRobotRequest.

        交互对接类型  * LIVE:直播交互  * CHAT:智能交互

        :param robot_type: The robot_type of this ListRobotRequest.
        :type robot_type: str
        """
        self._robot_type = robot_type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListRobotRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
