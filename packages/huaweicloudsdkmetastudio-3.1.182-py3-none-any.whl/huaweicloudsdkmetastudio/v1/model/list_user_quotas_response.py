# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListUserQuotasResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'count': 'int',
        'assets': 'list[UserQuotaInfo]',
        'x_request_id': 'str'
    }

    attribute_map = {
        'count': 'count',
        'assets': 'assets',
        'x_request_id': 'X-Request-Id'
    }

    def __init__(self, count=None, assets=None, x_request_id=None):
        r"""ListUserQuotasResponse

        The model defined in huaweicloud sdk

        :param count: 子账户总数。
        :type count: int
        :param assets: 子账户列表。
        :type assets: list[:class:`huaweicloudsdkmetastudio.v1.UserQuotaInfo`]
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._count = None
        self._assets = None
        self._x_request_id = None
        self.discriminator = None

        if count is not None:
            self.count = count
        if assets is not None:
            self.assets = assets
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def count(self):
        r"""Gets the count of this ListUserQuotasResponse.

        子账户总数。

        :return: The count of this ListUserQuotasResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListUserQuotasResponse.

        子账户总数。

        :param count: The count of this ListUserQuotasResponse.
        :type count: int
        """
        self._count = count

    @property
    def assets(self):
        r"""Gets the assets of this ListUserQuotasResponse.

        子账户列表。

        :return: The assets of this ListUserQuotasResponse.
        :rtype: list[:class:`huaweicloudsdkmetastudio.v1.UserQuotaInfo`]
        """
        return self._assets

    @assets.setter
    def assets(self, assets):
        r"""Sets the assets of this ListUserQuotasResponse.

        子账户列表。

        :param assets: The assets of this ListUserQuotasResponse.
        :type assets: list[:class:`huaweicloudsdkmetastudio.v1.UserQuotaInfo`]
        """
        self._assets = assets

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this ListUserQuotasResponse.

        :return: The x_request_id of this ListUserQuotasResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this ListUserQuotasResponse.

        :param x_request_id: The x_request_id of this ListUserQuotasResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("ListUserQuotasResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListUserQuotasResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
