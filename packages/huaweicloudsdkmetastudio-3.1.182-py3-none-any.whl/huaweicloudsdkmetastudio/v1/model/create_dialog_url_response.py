# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateDialogUrlResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'url': 'str',
        'x_request_id': 'str'
    }

    attribute_map = {
        'url': 'url',
        'x_request_id': 'X-Request-Id'
    }

    def __init__(self, url=None, x_request_id=None):
        r"""CreateDialogUrlResponse

        The model defined in huaweicloud sdk

        :param url: 对话链接。
        :type url: str
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._url = None
        self._x_request_id = None
        self.discriminator = None

        if url is not None:
            self.url = url
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def url(self):
        r"""Gets the url of this CreateDialogUrlResponse.

        对话链接。

        :return: The url of this CreateDialogUrlResponse.
        :rtype: str
        """
        return self._url

    @url.setter
    def url(self, url):
        r"""Sets the url of this CreateDialogUrlResponse.

        对话链接。

        :param url: The url of this CreateDialogUrlResponse.
        :type url: str
        """
        self._url = url

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this CreateDialogUrlResponse.

        :return: The x_request_id of this CreateDialogUrlResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this CreateDialogUrlResponse.

        :param x_request_id: The x_request_id of this CreateDialogUrlResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("CreateDialogUrlResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateDialogUrlResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
