"""
MedLLM Model Package

This package contains the GPT-based transformer architecture for medical QA.
"""

from gptmed.model.architecture import GPTTransformer

__all__ = ["GPTTransformer"]
