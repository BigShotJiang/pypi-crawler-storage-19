def sum_(a, b):
    return a + b

def mult_(a, b):
    return a * b

def sub_(a, b):
    return a - b

def div_(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a / b