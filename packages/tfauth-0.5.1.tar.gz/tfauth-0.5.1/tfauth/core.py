import os
import requests
from datetime import datetime

class TFAuth:
    def __init__(self):
        # Инициализация системных переменных
        self.TAPI = None
        self.version = "1.0.1"  # Теперь точно на месте!
        self.logo = ""
        self.footer_text = "TFAuth Quantum System 2026"
        self.color1 = "#ff416c"
        self.color2 = "#4b6cb7"
        self.GAPI = "not_set"
        self.FAPI = "not_set"
        self.success_login = "successl.html"
        self.GITHUB_RAW_URL = "https://raw.githubusercontent.com/TLETIFORMAT/apifs/ad181080e15c98116d839ab15f0c54214d1259bf/main/APIKEYS.json"

    def _check_access(self):
        if not self.TAPI: return False
        try:
            res = requests.get(self.GITHUB_RAW_URL, timeout=5)
            return str(self.TAPI).strip() in res.json()
        except: return False

    def _get_styles(self):
        return f"""
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Roboto:wght@300;400&display=swap');
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ background: #05050a; height: 100vh; overflow: hidden; font-family: 'Roboto', sans-serif; display: flex; justify-content: center; align-items: center; }}
            
            #preloader {{ position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 9999; transition: 0.8s; }}
            .spinner {{ width: 50px; height: 50px; border: 3px solid transparent; border-top: 3px solid {self.color1}; border-radius: 50%; animation: spin 1s linear infinite; }}
            @keyframes spin {{ to {{ transform: rotate(360deg); }} }}

            #particles-js {{ position: absolute; width: 100%; height: 100%; z-index: 1; }}
            .main-frame {{ position: relative; z-index: 10; width: 400px; padding: 45px; background: rgba(255,255,255,0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.1); border-radius: 35px; text-align: center; box-shadow: 0 40px 80px rgba(0,0,0,0.6); }}
            
            h2 {{ font-family: 'Orbitron'; color: white; margin-bottom: 30px; letter-spacing: 3px; }}
            .input-box {{ position: relative; margin-bottom: 20px; }}
            .input-box input {{ width: 100%; padding: 14px 15px 14px 45px; background: rgba(0,0,0,0.3); border: 1px solid #333; border-radius: 12px; color: white; outline: none; transition: 0.3s; }}
            .input-box input:focus {{ border-color: {self.color1}; box-shadow: 0 0 10px {self.color1}44; }}
            .input-box i {{ position: absolute; left: 15px; top: 16px; color: {self.color1}; }}
            
            .master-btn {{ width: 100%; padding: 16px; border: none; border-radius: 12px; background: linear-gradient(45deg, {self.color1}, {self.color2}); color: white; font-family: 'Orbitron'; font-weight: bold; cursor: pointer; transition: 0.4s; }}
            .master-btn:hover {{ transform: scale(1.02); filter: brightness(1.2); }}

            .social-container {{ display: flex; justify-content: center; gap: 15px; margin-top: 25px; }}
            .social-btn {{ width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.05); color: white; border: 1px solid rgba(255,255,255,0.1); text-decoration: none; transition: 0.3s; }}
            .social-btn:hover {{ background: {self.color1}; transform: translateY(-3px); }}

            #toast-box {{ position: fixed; top: 20px; right: 20px; z-index: 10000; }}
            .toast {{ background: #111; color: #fff; padding: 15px 20px; border-left: 4px solid {self.color1}; border-radius: 8px; margin-bottom: 10px; animation: slide 0.3s ease; }}
            @keyframes slide {{ from {{ transform: translateX(100%); }} to {{ transform: translateX(0); }} }}
        </style>
        """

    def generate_html(self):
        if not self._check_access():
            return f"<body style='background:#000;color:red;display:flex;justify-content:center;align-items:center;height:100vh;'><h1>403: ACCESS DENIED [{self.TAPI}]</h1></body>"

        # Формируем логотип
        logo_html = f'<img src="{self.logo}" style="max-width:80px; margin-bottom:15px; filter: drop-shadow(0 0 10px {self.color1});">' if self.logo else ""

        # Формируем кнопки соцсетей
        social_html = ""
        if self.GAPI != "not_set" or self.FAPI != "not_set":
            social_html = '<div class="social-container">'
            if self.GAPI != "not_set":
                social_html += f'<a href="https://google.com/{self.GAPI}" class="social-btn"><i class="fab fa-google"></i></a>'
            if self.FAPI != "not_set":
                social_html += f'<a href="https://facebook.com/{self.FAPI}" class="social-btn"><i class="fab fa-facebook-f"></i></a>'
            social_html += '</div>'

        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    {self._get_styles()}
</head>
<body>
    <div id="preloader">
        <div class="spinner"></div>
        <p style="color:#fff; font-family:'Orbitron'; font-size:10px; margin-top:15px; letter-spacing:2px;">SECURE BOOT...</p>
    </div>
    <div id="toast-box"></div>
    <div id="particles-js"></div>
    <div class="main-frame">
        {logo_html}
        <h2>AUTHENTICATION</h2>
        <div class="input-box"><i class="fa fa-user"></i><input type="text" id="u" placeholder="IDENTIFIER"></div>
        <div class="input-box"><i class="fa fa-lock"></i><input type="password" id="p" placeholder="SECRET_KEY"></div>
        <button class="master-btn" onclick="auth()">EXECUTE ACCESS</button>
        {social_html}
        <div style="margin-top:25px; font-size:10px; color:#555; letter-spacing:1px;">{self.footer_text}</div>
    </div>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        window.onload = () => setTimeout(() => {{ document.getElementById('preloader').style.opacity='0'; setTimeout(()=>document.getElementById('preloader').style.display='none',800); }}, 1500);
        particlesJS('particles-js', {{ "particles": {{ "number": {{ "value": 70 }}, "color": {{ "value": "#ffffff" }}, "line_linked": {{ "enable": true, "opacity": 0.1 }}, "move": {{ "speed": 2 }} }} }});
        function showT(m) {{ const b = document.getElementById('toast-box'); const t = document.createElement('div'); t.className='toast'; t.innerText=m; b.appendChild(t); setTimeout(()=>t.remove(), 3000); }}
        function auth() {{
            const u = document.getElementById('u').value;
            const p = document.getElementById('p').value;
            if(!u || !p) return showT("⚠️ Empty credentials");
            showT("⌛ Verifying...");
            setTimeout(() => {{
                showT("✅ Identity Confirmed");
                setTimeout(() => location.href='{self.success_login}', 1000);
            }}, 1500);
        }}
    </script>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.generate_html())
        print(f"[TFAuth v{self.version}] Build successful. Created {filename}")