# koruspy/__init__.py

__all__ = ["Some", "nothing", "SomeList", "println", "Okay", "Err", "option_of", "AsyncOption", "async_option", "ResultUnwrapError", "KoruspyError", "OptionUnwrapError"]

from .Option import Some, nothing, option_of, _NoneOption, SomeList
from .Result import Err, Okay
from .Async_option import AsyncOption, async_option
from .errors import ResultUnwrapError, OptionUnwrapError, KoruspyError 

# 1. Tenta importar o println (C-Speed)
try:
    from .printlnUtils.cythonprintln import println
except ImportError:
    # 2. Se falhar, define um println temporário (Python puro) ou aviso
    def println(*args, **kwargs):
        print("🚀 [Koruspy] Rodando em modo compatibilidade. Use koruspy.setup_native() para velocidade C.")
        print(*args, **kwargs)

import os
import sys
import subprocess

def setup_native():
    """Função que o seu usuário vai chamar para compilar o Cython localmente"""
    try:
        import Cython
    except ImportError:
        print("❌ Cython não encontrado. Instale: pip install cython")
        return

    base_path = os.path.dirname(__file__)
    pyx_path = os.path.join(base_path, "printlnUtils", "cythonprintln.pyx")
    
    if not os.path.exists(pyx_path):
        print(f"❌ Erro: {pyx_path} não encontrado.")
        return

    print("🚀 Compilando koruspy native engine...")
    try:
        # Forçamos a compilação para o diretório correto
        args = [sys.executable, "-c", 
                f"from setuptools import setup; from Cython.Build import cythonize; "
                f"setup(ext_modules=cythonize('{pyx_path}', language_level='3'))", 
                "build_ext", "--inplace"]
        
        subprocess.run(args, cwd=base_path, check=True)
        print("✅ Sucesso! Reinicie seu script para usar o println em C.")
    except Exception as e:
        print(f"❌ Falha na compilação: {e}")
        