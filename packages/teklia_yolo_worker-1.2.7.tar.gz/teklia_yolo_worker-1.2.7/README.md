# YOLO

Ultralytics YOLO:
- https://github.com/ultralytics/ultralytics
- https://docs.ultralytics.com/tasks/

## Deployment

### Classifier

1. [Create a worker](https://doc.teklia.com/arkindex/workers/create/#create-a-worker) using the Arkindex frontend. You can set whatever name/slug/type. We'll use:
   - Name: `YOLO Classifier`
   - Slug: `yolo-classifier`
   - Type: `classifier`
2. [Import a new version](https://doc.teklia.com/arkindex/workers/create/#create-a-worker-version) for that worker with the following settings:
   - Docker image reference (from [this registry](https://gitlab.teklia.com/workers/yolo/container_registry/65)): `registry.gitlab.teklia.com/workers/yolo:1.0.7`
   - YAML configuration: Paste the contents of the [arkindex/yolo-classifier.yml](arkindex/yolo-classifier.yml) file found in this repository.

### Segmenter

1. [Create a worker](https://doc.teklia.com/arkindex/workers/create/#create-a-worker) using the Arkindex frontend. You can set whatever name/slug/type. We'll use:
   - Name: `YOLO Segmenter`
   - Slug: `yolo-segmenter`
   - Type: `image-segmenter`
2. [Import a new version](https://doc.teklia.com/arkindex/workers/create/#create-a-worker-version) for that worker with the following settings:
   - Docker image reference (from [this registry](https://gitlab.teklia.com/workers/yolo/container_registry/65)): `registry.gitlab.teklia.com/workers/yolo:1.0.7`
   - YAML configuration: Paste the contents of the [arkindex/yolo-segmenter.yml](arkindex/yolo-segmenter.yml) file found in this repository.


### Models

You can use freely available open-source models [provided by Ultralytics](https://docs.ultralytics.com/models/yolo-world/#available-models-supported-tasks-and-operating-modes):
1. Create a directory where you'll download a model: `mkdir yolo-model`
2. Download model weights using one of the links from the webpage above, and rename it `model.pt`:
```
curl -L https://github.com/ultralytics/assets/releases/download/v8.2.0/yolov8s-world.pt > yolo-model/model.pt
```
3. Write a `.arkindex.yml` with the following content, updating the `name` to match your model:
```yaml
version: 2

models:
  - path: yolo-model
    name: YOLOv8s-Monde
```
4. Upload the model using [Arkindex CLI](https://cli.arkindex.org/arkindex_cli/models/): `arkindex models publish`
5. The model is now available on your Arkindex instance!


## Development

For development and tests purpose it may be useful to install the worker as a editable package with pip.

```shell
pip install -e .
```

### Linter

Code syntax is analyzed before submitting the code.\
To run the linter tools suite you may use pre-commit.

```shell
pip install pre-commit
pre-commit run -a
```

### Run tests

Tests are executed with tox using [pytest](https://pytest.org).

```shell
pip install tox
tox
```

To recreate tox virtual environment (e.g. a dependencies update), you may run `tox -r`
