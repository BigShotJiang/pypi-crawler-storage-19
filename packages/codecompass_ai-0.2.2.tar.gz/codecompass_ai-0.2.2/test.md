
### README.md

# 🧭 CodeCompass

**AI-powered repository understanding assistant**

CodeCompass helps developers quickly understand and navigate unfamiliar codebases using natural language. Ask questions like "How does authentication work?" or "What calls this function?" and get accurate, context-aware answers.

## ✨ Features

- **Semantic Code Search**: Find relevant code using natural language queries
- **Intelligent Tool Use**: Automatically searches, reads files, and traces references
- **Conversation Memory**: Remembers context across questions
- **Git-Aware**: Understands commit history and file changes
- **Local-First**: Runs entirely on your machine with Ollama

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- [Ollama](https://ollama.com) installed and running

### Installation

```bash
pip install codecompass

# Pull required models
ollama pull qwen2.5:7b
ollama pull nomic-embed-text
```

### Usage

```bash
# Navigate to any repository
cd /path/to/repo

# Start chatting
codecompass chat

# Or ask a single question
codecompass ask "How does authentication work?"
```

## 📖 Commands

| Command | Description |
|---------|-------------|
| `codecompass chat [PATH]` | Interactive chat session |
| `codecompass ask QUESTION` | One-shot question answering |
| `codecompass search QUERY` | Semantic code search |
| `codecompass index [PATH]` | Index a repository |
| `codecompass status [PATH]` | Check index status |

## 🛠 Available Tools

CodeCompass uses these tools to answer your questions:

| Tool | Description |
|------|-------------|
| `search_code` | Semantic search for relevant code |
| `read_file` | Read file contents |
| `find_references` | Find where symbols are used |
| `get_file_structure` | Show directory tree |
| `get_git_history` | View commit history |
| `get_dependencies` | Analyze imports |

## ⚙️ Configuration

Configure via environment variables:

```bash
# Use a different model
export CODECOMPASS_CHAT_MODEL=qwen2.5:3b

# Change Ollama host
export CODECOMPASS_OLLAMA_HOST=http://localhost:11434

# Adjust ollama context window
export CODECOMPASS_OLLAMA_CTX_WINDOW=8192
```

## 🙏 Acknowledgments

- [Ollama](https://ollama.com) for local LLM inference
- [LangGraph](https://github.com/langchain-ai/langgraph) for agent orchestration
- [LanceDB](https://lancedb.com) for vector storage
- [Tree-sitter](https://tree-sitter.github.io) for code parsing


# Installation Guide

## Requirements

- **Python**: 3.10 or higher
- **Ollama**: Latest version
- **Disk Space**: ~10GB for models
- **RAM**: 8GB minimum, 16GB recommended

## Install CodeCompass

### From PyPI (recommended)

```bash
pip install codecompass
```

### From Source

```bash
git clone https://github.com/yourusername/codecompass
cd codecompass
pip install -e .
```

## Install Ollama

### macOS

```bash
brew install ollama
```

### Linux

```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Windows

Download from [ollama.com](https://ollama.com/download)

## Pull Models

```bash
# Start Ollama (if not running)
ollama serve

# Pull required models
ollama pull qwen2.5:7b      # Chat model (~4.4GB)
ollama pull nomic-embed-text # Embedding model (~274MB)
```

## Verify Installation

```bash
# Check CodeCompass
codecompass --version

# Check Ollama connection
codecompass status

# Test on a repository
cd /path/to/any/repo
codecompass index .
codecompass ask "What is this project about?"
```

## Troubleshooting

### "Connection refused" error

Ensure Ollama is running:
```bash
ollama serve
```

### Slow responses

- Use GPU if available (Ollama auto-detects)
- Try a smaller model: `CODECOMPASS_CHAT_MODEL=qwen2.5:3b`

### Out of memory

- Close other applications
- Use quantized models (default already uses Q4)

# docs/usage.md

# Usage Guide

## Interactive Chat

The main way to use CodeCompass:

```bash
cd /path/to/repo
codecompass chat
```

### Chat Commands

Inside the chat session:

- `/help` - Show available commands
- `/clear` - Clear conversation history
- `/exit` - Exit chat

### Example Session

```
You: What files are in this project?
CodeCompass: 📁 This project contains:
- src/ - Main source code
  - main.py - Application entry point
  - auth.py - Authentication module
  - database.py - Database connections
- tests/ - Test files
- README.md - Project documentation

You: How does authentication work?
CodeCompass: Based on src/auth.py, authentication works as follows:
1. The `authenticate_user()` function takes username and password
2. It queries the database for the user
3. Passwords are verified using bcrypt hashing
4. Returns a User object on success, None on failure

Key code:
```python
def authenticate_user(username: str, password: str) -> Optional[User]:
    user = db.query(User).filter(User.username == username).first()
    if user and verify_password(password, user.hashed_password):
        return user
    return None
```

You: /exit
Goodbye!
```

## One-Shot Questions

For quick questions without a full session:

```bash
codecompass ask "What is the main entry point?"
```

## Semantic Search

Search for code without asking questions:

```bash
codecompass search "error handling"
codecompass search "database connection" --top-k 10
```

## Indexing

Manually index or re-index:

```bash
# Index current directory
codecompass index

# Index specific path
codecompass index /path/to/repo

# Force re-index
codecompass index --force
```

## Tips for Better Results

1. **Be specific**: "How does user authentication work?" is better than "How does auth work?"

2. **Reference files**: "What does src/main.py do?" helps CodeCompass focus

3. **Ask follow-ups**: CodeCompass remembers context, so "What calls that function?" works after discussing a function

4. **Use search first**: If you're exploring, `codecompass search` can help you find relevant areas
```

### Demo script

```python
# scripts/demo.py
"""Demo script showcasing CodeCompass capabilities."""

import time
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from codecompass.agent.graph import CodeCompassAgent
from codecompass.indexing.store import CodeStore


console = Console()


def demo(repo_path: str):
    """Run an interactive demo."""
    
    repo = Path(repo_path)
    
    console.print(Panel(
        "[bold blue]CodeCompass Demo[/bold blue]\n\n"
        "This demo showcases CodeCompass's ability to understand codebases.",
        title="🧭"
    ))
    
    # Index
    console.print("\n[bold]Step 1: Indexing the repository[/bold]")
    store = CodeStore(repo)
    
    with console.status("[green]Indexing..."):
        stats = store.index()
    
    console.print(f"✓ Indexed {stats['chunk_count']} code chunks\n")
    
    # Create agent
    agent = CodeCompassAgent(repo, use_memory=True)
    
    # Demo questions
    demo_questions = [
        "What is this project about? Give me a quick overview.",
        "What are the main components or modules?",
        "How would I add a new feature to this codebase?",
    ]
    
    console.print("[bold]Step 2: Asking questions about the codebase[/bold]\n")
    
    for i, question in enumerate(demo_questions, 1):
        console.print(f"[bold blue]Question {i}:[/bold blue] {question}\n")
        
        with console.status("[green]Thinking..."):
            start = time.time()
            response = agent.chat(question)
            elapsed = time.time() - start
        
        console.print(Panel(
            Markdown(response),
            title=f"Answer ({elapsed:.1f}s)"
        ))
        console.print()
        
        # Pause between questions
        if i < len(demo_questions):
            input("Press Enter to continue...")
            console.print()
    
    console.print("[bold green]Demo complete![/bold green]")
    console.print("\nTry it yourself: [cyan]codecompass chat[/cyan]")


if __name__ == "__main__":
    import sys
    repo_path = sys.argv[1] if len(sys.argv) > 1 else "."
    demo(repo_path)
```


---
