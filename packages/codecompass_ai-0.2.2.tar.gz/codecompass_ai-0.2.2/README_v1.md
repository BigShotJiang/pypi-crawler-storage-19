# CodeCompass
AI-Powered Repository Onboarding Assistant

**AI-powered repository understanding assistant**

CodeCompass helps developers quickly understand and navigate unfamiliar codebases using natural language. Ask questions like "How does X work?" or "What would break if I change X?" and get accurate, context-aware answers.

## ✨ Features

- **Semantic Code Search**: Find relevant, smartly embedded AST code chunks using natural language queries via hybrid search (semantic and lexical bm25) and various retrieving strategies (hyde, query expansion).
- **Intelligent Tool Use**: Autonomic agent that can call six tools (RAG code search, reads files, traces references, review git history, view file structure etc) as necessary to answer your questions.
- **Conversation Memory**: Remembers context across questions (chat feature)
- **Git-Aware**: Understands commit history and file changes
- **Local-First**: Runs entirely on your machine with Ollama


## Setup

-requirements
1. ollama
2. python3.10
3. gpu or metal recommended for fast inference

- pypi package (recommended)
1. go to project directory
2. make virtualenv
3. pip install codecompass-ai
4. in another terminal, ollama serve (or use ollama desktop app if on mac os which utilizes Metal)
5. ollama pull qwen2.5:7b ; ollama pull nomic-embed-text
6. codecompass

- alternative: use git clone 
1. go to project directory you wish to explore
2. create virtualenv
3. pip install "path/to/codecompass"
4. same steps as above...

## Verify Installation

```bash
# Check CodeCompass
codecompass --version

# Check Ollama connection
codecompass status

# Test on a repository
cd /path/to/any/repo
codecompass index .
codecompass ask "What is this project about?"
```

## Usage
Commands
{!SUMMARIZE cli.py and cli_menu.py and display all commands available}
- codecompass for easy to use arrow navigable terminal
- also supports command (search, index, chat, etc...)
- explain diff between commands (search if u dont need answer just look up code reated to a natural language concept, ask for one shot question, chat for interactive ui and memory)





## Notes (Troubleshooting)
1. ollama context window
ollama_ctx_window: int = 16384
tool calls for huge codebases could return up to 3-5k tokens. if set to default = 4098, model will get flooded and forget system and user prompts for the current conversation turn. ollama handles truncating for next turn (remove everything else except last assistant message and system message)
2. ollama._types.ResponseError: the input length exceeds the context length (status code: 500) while indexing

decreaes chunk_max_chars in config.py to 4000 or 3000.
3. "Connection refused" error
Ensure Ollama is running:
```bash
ollama serve
```
4. Slow responses

- Use GPU if available (Ollama auto-detects)
- Try a smaller model: `CODECOMPASS_CHAT_MODEL=qwen2.5:3b`


## Tips for Better Results

1. **Be specific**: "How does user authentication work?" is better than "How does auth work?"

2. **Reference files**: "What does src/main.py do?" helps CodeCompass focus vs "how does main work"

3. **Ask follow-ups**: CodeCompass remembers context, so "What calls that function?" works after discussing a function

4. **Use search first**: If you dont need llm response, `codecompass search` can help you find relevant areas via retrieval




# More details regarding methologies
## RAG
{!elaborate on how ast chunking is done and stored in lancedb}
{!explain how hybrid search is used and why}

{!explain why nomic-embed-text is used for embedding model? perhaps code interpretation}
{!explain middle part is truncated if doesnt fit embeding model context to preserve more import things like docstring and return statements
def truncate_middle(text: str, max_chars: int) -> str:
    """Truncate middle of text, keeping head and tail"""
    if len(text) <= max_chars:
        return text
    
    head_chars = int(max_chars * 0.85)
    tail_chars = max_chars - head_chars
    
    return text[:head_chars] + "\n\n... [truncated] ...\n\n" + text[-tail_chars:]

}

### Retrieval Strategy Evaluation

Evaluated retrieval strategies on 19 test queries across 5 categories (feature search, concept search, API search, debug search, natural language).

#### Results

| Strategy | Recall@5 | Precision@5 | MRR |
|----------|----------|-------------|-----|
| **HyDE** | **0.733** | 0.295 | 0.671 |
| Query Expansion | 0.718 | 0.295 | 0.737 |
| Baseline (vector search) | 0.644 | 0.263 | 0.754 |
| Query Expansion + Context | 0.428 | 0.189 | 0.399 |

**HyDE** (Hypothetical Document Embedding) performed best, improving recall by **13.9%** over baseline. This approach generates hypothetical code matching the query, then searches for similar real code.

#### Context-Aware Expansion: Negative Result

The context-aware strategy (providing repo imports to the LLM) performed surprisingly poorly. I hypothesized the prompt was suboptimal, so I tested 4 variations:

| Variant | Description | Recall@5 |
|---------|-------------|----------|
| v4: Rule-based | No LLM, keyword matching | 0.691 |
| v2: Pick from list | LLM selects relevant imports | 0.665 |
| v3: Minimal prompt | Simple prompt | 0.644 |
| v1: Fewer imports | 15 imports instead of 100 | 0.600 |
| Original | 100 imports, verbose prompt | 0.428 |

**Finding**: Even the best context variant (rule-based, no LLM) underperformed simple query expansion. Adding repository context introduces noise rather than helping retrieval.

**Takeaway**: Simpler strategies (HyDE, query expansion) outperform complex context-aware approaches for code search.





## Fine-tuning Evaluations

I considered finetuning with xlam-60k from salesforce but after running an tool-calling evaluation script on base model with curated dataset, it already does a good job. So we only finetune for better code explanation.

Considred datasets like CodeSearchNet, code_x_glue_ct_code_to_text but found 
Magicoder-OSS-Instruct-75K to have the best detailed yet concise explanations suitable for our case.
Since we expect user queries to be more abstract questions where code explanation is not the only response to the query, in fact it's only for a subset of most queries, I decided to use a two-pass architecture with hot-swap adapaters, using only the fine-tuned model for explanation portion so we don't see performance degradation for other tasks.

│  User Query                                                  │
│      ↓                                                       │
│  [Base Model] → Tool selection (95% accurate, no training)  │
│      ↓                                                       │
│  [Tools] → Code chunks                                       │
│      ↓                                                       │
│  [Fine-tuned Model] → Explanations only ← TRAIN THIS ONLY   │
│      ↓                                                       │
│  [Base Model] → Final synthesized answer  

And the user shouldn't be downloading two full qwen models so I decided to fine tune with LoRA.

### I. Tool Calling Evaluation

We started around 70% correct tool accuracy with JSON format issues. Through prompt engineering, we were able to get 100% valid json and up to 95.2% tool calling, with 100% tool calling for simpler queries.

#### 1. Benchmark A (21 intent-driven queries simulating real use cases for CodeCompass)

##### a. Sample queries
```
    {
        "id": "concept_3",
        "category": "understanding",
        "question": "How is authentication implemented? Walk me through the flow.",
        "expected_tool": "search_code",
        "why_valuable": "Understanding a system, not just finding a file",
        "notes": "Should search for auth, login, session, token patterns"
    },
```
```
    {
        "id": "impact_1",
        "category": "impact",
        "question": "If I change the User model, what parts of the codebase might be affected?",
        "expected_tool": "find_references",
        "why_valuable": "Impact analysis before making changes",
        "notes": "Should find references to User class/model"
    }
```

##### b. Results
```
======================================================================
BENCHMARK RESULTS: qwen2.5:7b
======================================================================

Overall Metrics:
  Valid JSON:      21/21 (100.0%)
  Correct Tool:    20/21 (95.2%)
  Has Args/Answer: 21/21 (100.0%)

By Category:
  debugging       ██████████ 3/3 (100%)
  impact          ██████░░░░ 2/3 (67%)
  no_tool         ██████████ 3/3 (100%)
  onboarding      ██████████ 3/3 (100%)
  planning        ██████████ 3/3 (100%)
  quality         ██████████ 2/2 (100%)
  understanding   ██████████ 4/4 (100%)

Failures (1):
  [impact_3] Expected: find_references, Got: search_code

======================================================================
ANALYSIS & RECOMMENDATIONS:
======================================================================
  ✓ qwen2.5:7b achieves 95% accuracy.
  → Fine-tuning may NOT be necessary.
```

#### 2. Benchmark B (39 tool-driven, simpler queries for testing general tool invocation)

##### a. Sample queries
```
    {
        "id": "search_4",
        "category": "search_code",
        "question": "Find code related to user permissions and access control",
        "expected_tool": "search_code",
        "rationale": "Broad conceptual search"
    }
```
```
    {
        "id": "refs_6",
        "category": "find_references",
        "question": "Show me all the places that call send_email",
        "expected_tool": "find_references",
        "rationale": "Explicit 'all places that call X' pattern"
    }
```

##### b. Results
```
======================================================================
BENCHMARK RESULTS: qwen2.5:7b
======================================================================

Overall Metrics:
  Valid JSON:      39/39 (100.0%)
  Correct Tool:    39/39 (100.0%)
  Has Args/Answer: 36/39 (92.3%)

By Category:
  find_references      ██████████ 10/10 (100%)
  get_dependencies     ██████████ 5/5 (100%)
  get_file_structure   ██████████ 4/4 (100%)
  get_git_history      ██████████ 4/4 (100%)
  no_tool              ██████████ 5/5 (100%)
  read_file            ██████████ 5/5 (100%)
  search_code          ██████████ 6/6 (100%)

======================================================================
ANALYSIS & RECOMMENDATIONS:
======================================================================

✓  JSON Compliance: 100% (good)
✓  Tool Selection: 100%
   Base model performs well. Fine-tuning may not be needed.
```

### II. Code Explanation Finetuning

The two-phase architecture separates tool selection from code explanation.
We hypothesized the explanation phase might benefit from domain-specific fine-tuning.

#### 1. Methodology
Built an LLM-as-Judge evaluation framework before committing to fine-tuning:

- **10 code patterns** across categories (async, decorators, design patterns)
- **4 quality dimensions**: clarity, accuracy, conciseness, insight
- **Position randomization** to eliminate ordering bias
- **Automated win-rate calculation**

#### 2. Experiment
- **Base model**: Qwen 2.5 7B (4-bit quantized)
- **Fine-tuned**: LoRA adapter trained on Magicoder dataset (1,400 examples)
- **Judge**: Qwen 2.5 7B (separate inference)

#### 3. Results
```
======================================================================
EVALUATION: codecompass:explain vs qwen2.5:7b
Judge: qwen2.5:7b
Test cases: 10
======================================================================

[1/10] retry_backoff...
    ❌ Winner: baseline
[2/10] singleton...
    ❌ Winner: baseline
[3/10] memoize...
    ❌ Winner: baseline
[4/10] context_manager...
    ❌ Winner: baseline
[5/10] async_gather...
    ❌ Winner: baseline
[6/10] property_validator...
    ❌ Winner: baseline
[7/10] factory_method...
    ❌ Winner: baseline
[8/10] generator_pipeline...
    ❌ Winner: baseline
[9/10] descriptor...
    ❌ Winner: baseline
[10/10] rate_limiter...
    ❌ Winner: baseline

======================================================================
EVALUATION RESULTS
======================================================================

📊 Win Rate:
  codecompass:explain: 0/10 (0.0%)
  qwen2.5:7b: 10/10 (100.0%)
  Ties: 0/10 (0.0%)

🔍 Position Bias Check:
  Model as A: 0/4 wins (0.0%)
  Model as B: 0/6 wins (0.0%)

📈 Average Scores (1-5):
  Metric          codecompass:explain qwen2.5:7b     
  ---------------------------------------------
  clarity         3.30            4.50            ↓
  accuracy        4.10            5.00            ↓
  conciseness     2.50            4.00            ↓
  insight         1.60            3.50            ↓

📏 Average Response Length:
  codecompass:explain: 407 chars
  qwen2.5:7b: 1019 chars

======================================================================
SUMMARY STATISTICS
======================================================================

Metric                           Baseline      Fine-tuned            Diff
----------------------------------------------------------------------
Avg words/response                  180.2            59.6          -66.9%
Avg time/response (s)               11.37           25.00         +119.8%
Total words                          1802             596
Total time (s)                      113.7           250.0

======================================================================
VERDICT:
======================================================================
⚠️ qwen2.5:7b performed better (10000% win rate)
   Fine-tuning may have regressed quality. Check training.
```

#### 4. QUALITATIVE RESULTS: SAMPLE RESPONSES

##### a. retry_backoff: Retry with exponential backoff

**Code:**
```python
def retry_with_backoff(func, max_retries=3, base_delay=1):
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt)
            time.sleep(delay)
```

**BASELINE** (178 words, 15.0s):
````
This code defines a `retry_with_backoff` function that attempts to execute another function (`func`) up to `max_retries` times. It introduces exponential backoff between retries, doubling the wait time after each failure.

### Key Points:
- **Purpose**: To retry executing a function with increasing delays if it fails.
- **Design Decisions**:
  - Uses a loop to attempt execution multiple times.
  - Implements exponential backoff to avoid overwhelming the system on repeated failures.
- **Notable Patterns/Techniques**:
  - Exception handling: retries until the last attempt, then rethrows the exception.
  - Exponential backoff: delays increase exponentially (e.g., 1s, 2s, 4s).
- **Edge Cases Handled**:
  - If `func` succeeds on any attempt, it returns immediately without further retries.
  - Retries up to `max_retries`, then rethrows the last exception if all attempts fail.

### Example Usage:
```python
def fetch_data():
    # Simulate a network error
    raise ConnectionError("Network issue")

try:
    result = retry_with_backoff(fetch_data, max_retries=5)
    print(result)
except Exception as e:
    print(f"Failed after retries: {e}")
```

This pattern is useful for handling transient errors in distributed systems where occasional failures are expected and should be retried with increasing delays.
````

**FINE-TUNED** (59 words, 24.9s):
The `retry_with_backoff` function takes the original function to be retried, along with optional parameters for maximum retries and base delay. It attempts to execute the function within a loop, handling any exceptions that may occur. If an exception is caught, it waits for increasing delays before retrying until the maximum number of retries is reached or no exception occurs.

----------------------------------------------------------------------

##### b. singleton: Singleton design pattern

**Code:**
```python
class DatabaseConnection:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._connection = None
        return cls._instance
    
    def connect(self, connection_string):
        if self._connection is None:
            self._connection = create_connection(connection_string)
        return self._connection
```

**BASELINE** (135 words, 9.9s):
````
This code defines a singleton class `DatabaseConnection` that ensures only one database connection exists at any time. Here's a concise breakdown:

- **Purpose**: Ensures a single instance of the database connection to avoid multiple connections.
- **Key Design Decisions**:
  - Uses the Singleton pattern with `__new__` method to control instantiation.
  - Hides the actual connection object (`_connection`) as an attribute.
- **Notable Patterns/Techniques**:
  - **Singleton Pattern**: Ensures only one instance of the class is created and provides a global point of access to it.
  - **Lazy Initialization**: The `_connection` is created only when `connect` is called for the first time.
- **Edge Cases Handled**:
  - Prevents multiple connections by checking if `_connection` exists before creating a new one.

In summary, this class manages database connections efficiently, ensuring that all instances share the same connection object.
````

**FINE-TUNED** (55 words, 24.9s):
The `DatabaseConnection` class ensures that only one instance of the database connection exists throughout the application. The `_instance` attribute acts as a singleton pattern to maintain a single point of access to the database connection. The `connect` method establishes a connection if it hasn't been established yet and returns the connection object for further operations.

----------------------------------------------------------------------

##### c. decorator_cache: Memoization decorator

**Code:**
```python
def memoize(func):
    cache = {}
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        key = (args, tuple(sorted(kwargs.items())))
        if key not in cache:
            cache[key] = func(*args, **kwargs)
        return cache[key]
    return wrapper
```

**BASELINE** (139 words, 9.1s):
````
This code defines a `memoize` function that acts as a decorator to memoize another function's results. Key points:

- It uses a dictionary `cache` to store previously computed results.
- The inner `wrapper` function checks if the current arguments have been seen before; if not, it computes and stores the result.
- It handles both positional and keyword arguments by converting them into a hashable key.
- Uses `functools.wraps` to preserve the wrapped function's metadata.

Notable:
- Sorts kwargs to handle equivalent kwarg orders differently (e.g., `f(a=1, b=2)` vs. `f(b=2, a=1)`).
- Could raise issues with unhashable or non-pickleable arguments.
- May consume significant memory for functions with many unique argument combinations.

Edge cases:
- Functions that always return the same value regardless of input won't be memoized properly.
- Recursive functions need careful handling to avoid infinite recursion.
````

**FINE-TUNED** (82 words, 25.5s):
The `memoize` decorator is implemented using a dictionary to store the results of function calls. The key for each result is generated based on the input arguments and keyword arguments. This ensures that the memoization works correctly even when the order of keyword arguments changes. The `wrapper` function checks if the result for the given inputs is already cached, and returns it if available; otherwise, it computes the result using the original function and stores it in the cache before returning it.


#### 5. Conclusion
The fine-tuned model had more concise explanations but at the cost of explanatory depth.
Base model's pretraining already captured sufficient code understanding.

**Decision**: Single-model architecture using base Qwen 2.5 7B for all stages.

## LangGraph Agent and Tool Calling
{!explain how langraph agent is constructed and describe the tools available}
{!go over tool compression and sliding window for token management but we currently have this disabled because rn just increasing ollama context window works completely fine}
{! explain ollama debugger wrapper module that prints out tokens so easily debuggable}

{!list the tools and descriptions here}
 I dont have test results for this but please make this section look good.



 ```
"""You are CodeCompass, an AI assistant that helps developers understand and navigate codebases.

## Tool Selection Guidelines

Choose the most appropriate tool:

- **search_code**: Conceptual queries when no exact symbol or file is specified. Keep queries SHORT (2-4 keywords). Remove filler words. 
- **find_references**: When you KNOW the exact symbol name. Extract just the symbol. Use **find_references** whenever the user asks what would break, what is affected, or where a symbol is used, even if they phrase it as an impact or dependency question.
- **get_git_history**: Questions about changes, history, who modified, when changed.
- **read_file**: When you know the exact file path.
- **get_file_structure**: Project overview or finding file locations.
- **get_dependencies**: For understanding what a file imports.

Examples:

User: How is authentication implemented?
Response: {{"tool": "search_code", "arguments": {{"query": "authentication"}}}}

User: What would break if I change the UserService class?
Response: {{"tool": "find_references", "arguments": {{"symbol": "UserService"}}}}

User: What changed in src/auth recently?
Response: {{"tool": "get_git_history", "arguments": {{"file_path": "src/auth"}}}}

## Response Guidelines
- Be concise but thorough
- Reference specific files and line numbers
- If initial tool results are insufficient, try a different tool or search query. Combine multiple tools (e.g., `read_file` + `find_references`) if needed to fully answer the question.
- After using tools (multiple if needed to answer the queation), synthesize the information into a clear answer

## Investigation Depth

Match your depth to the question:

- "Where is X used/called/defined?" → Locations and line numbers are sufficient
- "How is X used?" / "What does X do?" → Explain the actual behavior and flow

For "how" questions: finding an assignment like `x = SomeClass()` tells you 
where it's created, not how it's used. Keep investigating until you can 
explain what the code DOES.

Before responding to "how/what" questions, verify:
- Can I explain the behavior, not just the location?
- Would a developer understand the flow from my answer?

If not, make additional tool calls (read_file, find_references, etc.) 
until you can.

## Query Alignment Rules (Important)
- Always respond in direct accordance with the user's question. 
- Avoid tangents or unrelated explanations. Only provide details relevant to the user's specific query.
"""
 ```


 ```
 SYSTEM_PROMPT = """You are CodeCompass, an AI assistant that helps developers understand and navigate codebases.

## Tool Selection Guidelines

Choose the most appropriate tool:

- **search_code**: Conceptual queries when no exact symbol or file is specified. Keep queries SHORT (2-4 keywords). Remove filler words. 
- **find_references**: When you KNOW the exact symbol name. Extract just the symbol. Use **find_references** whenever the user asks what would break, what is affected, or where a symbol is used, even if they phrase it as an impact or dependency question.
- **get_git_history**: Questions about changes, history, who modified, when changed.
- **read_file**: When you know the exact file path.
- **get_file_structure**: Project overview or finding file locations.
- **get_dependencies**: For understanding what a file imports.

Examples:
- "How is authentication implemented?"
  → search_code("authentication")
  → read_file("src/auth/AuthService.py")
  → explain implementation

- "What would break if I change UserService?"
  → find_references("UserService")
  → read_file("src/services/UserService.py")
  → summarize impact

- "What changed in src/auth recently?"
  → get_git_history("src/auth")
  → summarize recent changes

## Workflow Rules
1. For "how is X used" questions: find_references → read_file (1-3 files) → explain. Don't answer from snippets alone.
2. Many find_references results (5+): summarize patterns, read_file only representative examples.
3. search_code isn't exhaustive. Follow up with read_file or find_references for "how/why" questions.
4. find_references is for locating call sites only. Do not explain behavior or include code blocks based solely on find_references; you must read_file the defining file and/or the callsite file first.

## Code Accuracy (CRITICAL)
- ONLY show code that appears EXACTLY in tool results
- NEVER explain what a class or function does unless its definition has been read using read_file in the current turn. If the definition has not been read, say so and call read_file.
- If only a call site or one-line usage is known, say so and call read_file before explaining.

## Read Completeness Rule (CRITICAL)
- A class or function is considered read ONLY if read_file
  includes its full definition body.
- Instantiation lines, imports, or call sites do NOT count.

## Permission Rule (CRITICAL)
- NEVER ask the user for permission to read files (including phrasing like “Would you like me to…?”). If more context is needed, call the tool immediately.
- If context is missing, call read_file immediately.

## Code Synthesis Ban (CRITICAL)
- NEVER generate illustrative or reconstructed code.
- All code blocks must appear verbatim in read_file or search_code output.

## Answer Gate (Mandatory)
- For every function/class you describe: its full definition body has been read via read_file.
- For every file whose functions you explain: that file has been read via read_file.
If any item is false: call the missing tool(s) first; do not answer yet.

## Response Guidelines
- Be concise but thorough
- Reference specific files and line numbers
- If initial tool results are insufficient, try a different tool or search query. Combine multiple tools (e.g., `read_file` + `find_references`) if needed to fully answer the question.
- After using tools as needed to answer the question, synthesize the information into a clear answer.

## Query Alignment Rules (Important)
- Always respond in direct accordance with the user's question.
- Avoid tangents or unrelated explanations. Only provide details relevant to the user's specific query.
"""
```