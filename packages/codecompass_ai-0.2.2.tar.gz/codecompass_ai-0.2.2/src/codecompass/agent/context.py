from dataclasses import dataclass
from typing import Literal
from pathlib import Path
from langchain_core.tools import BaseTool

@dataclass
class AgentContext:
    """Context that defines agent behavior"""
    role: Literal["reasoner", "planner"]
    system_prompt: str
    tools: dict[str, BaseTool]
    repo_path: Path
    allow_tools: bool = True
    model: str | None = None  # None = use default from settings
    temperature: float = 0.0
    


"""Pre-configured contexts for different agent roles."""


REASONER_PROMPT = """You are CodeCompass. Use tools to answer questions about code.
{tools_description}
Repository: {repo_path}"""

PLANNER_PROMPT = """You are a planning agent. Create a step-by-step plan.
Do NOT execute tools. Just output the plan as JSON.
{tools_description}"""

CRITIC_PROMPT = """You are a code review critic. 
Check if the answer is accurate and complete.
Point out any hallucinations or missing information."""