from codecompass.agent.context import AgentContext
from codecompass.agent.messages import AIMessage
from codecompass.agent.state import AgentState

from langchain_core.messages import ToolMessage

from codecompass.llm.ollama import chat



def reason_node(state: AgentState) -> dict:
    """Shared reasoning - behavior determined by context"""
    ctx: AgentContext = state["agent_ctx"]
    
    messages = [{"role": "system", "content": ctx.system_prompt}]
    for msg in state["messages"]:
        # ... convert messages ...
    
    response = chat(
        messages, 
        model=ctx.model,
        temperature=ctx.temperature,
    )
    
    if ctx.allow_tools:
        tool_call = parse_tool_call(response)
        if tool_call and tool_call["name"] in ctx.tools:
            return {
                "pending_tool_calls": [tool_call],
                "iteration": state["iteration"] + 1,
            }
    
    return {
        "final_response": response,
        "messages": [AIMessage(content=response)],
    }


def execute_node(state: AgentState) -> dict:
    """Execute tools - also uses context."""
    ctx: AgentContext = state["agent_ctx"]
    results = []
    
    for call in state["pending_tool_calls"]:
        tool = ctx.tools.get(call["name"])
        if tool is None:
            results.append(ToolMessage(content=f"Unknown tool: {call['name']}", tool_call_id=call["name"]))
            continue
        
        try:
            result = tool.invoke(call["arguments"])
            results.append(ToolMessage(content=str(result), tool_call_id=call["name"]))
        except Exception as e:
            results.append(ToolMessage(content=f"Error: {e} : {str(e)}", tool_call_id=call["name"]))
    
    return {
        "messages": results,
        "pending_tool_calls": [],
    }


def should_continue(state: AgentState) -> str:
    """Routing logic."""
    ctx = state["context"]
    
    if state["iteration"] >= ctx.settings.max_iterations:
        return "done"
    if state.get("pending_tool_calls"):
        return "execute"
    return "done"