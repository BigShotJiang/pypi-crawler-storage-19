from typing import Annotated, Literal
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages


class AgentState(TypedDict):

    messages: Annotated[list, add_messages]
    pending_tool_calls: list[dict]  # [{"name": str, "arguments": dict}]
    iteration: int
    final_response: str | None

from langgraph.graph import MessagesState
from typing import TypedDict

class AgentState(MessagesState):
    """
    State for the CodeCompass agent
    
    Attributes:
        messages: Conversation history (accumulated via add_messages)
        pending_tool_calls: Tool calls waiting to be executed
        iteration: Current iteration count (for limiting loops)
        final_response: The final response to return (signals completion)
    """
    pending_tool_calls: list[dict] # [{"name": str, "arguments": dict}]
    iteration: int
    final_response: str | None