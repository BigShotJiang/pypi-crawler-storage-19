from prompt_gen.cli import main

raise SystemExit(main())
