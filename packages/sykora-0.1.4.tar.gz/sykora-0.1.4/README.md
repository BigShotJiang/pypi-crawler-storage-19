# Sykora


## Installation

```bash
pip install sykora
```

## Usage

### Interactive Mode

```bash
sykora --token xx
```

## Requirements

- Python 3.7+
