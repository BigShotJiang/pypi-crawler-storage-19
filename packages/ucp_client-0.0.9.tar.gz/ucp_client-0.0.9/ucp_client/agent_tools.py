#   Copyright 2026 UCP Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""LLM Agent Tools for UCP Shopping API.

This module provides simplified, LLM-friendly wrapper functions for the UCP Client.
All functions use primitive types (str, dict, list) for easy integration with
LLM tool-calling frameworks like OpenAI Function Calling, Anthropic Tool Use,
or LangChain.

Each function is:
- Synchronous (runs async code internally)
- Uses simple primitive types for inputs/outputs
- Has detailed docstrings with examples
- Returns structured dict responses with clear fields

Example usage with an LLM agent:
    
    from ucp_client import UCPAgentTools
    
    tools = UCPAgentTools("http://localhost:8182")
    
    # Step 1: Discover what the merchant supports
    merchant = tools.discover_merchant()
    
    # Step 2: Create a cart with items
    cart = tools.create_cart(
        items=[{"product_id": "roses", "title": "Red Roses", "quantity": 2}],
        buyer_name="John Doe",
        buyer_email="john@example.com"
    )
    
    # Step 3: Apply discount
    tools.apply_discount(cart["checkout_id"], "10OFF")
    
    # Step 4: Set shipping address
    tools.set_shipping_address(
        checkout_id=cart["checkout_id"],
        street="123 Main St",
        city="San Francisco",
        state="CA",
        country="US",
        postal_code="94102"
    )
    
    # Step 5: Complete purchase
    result = tools.complete_purchase(
        checkout_id=cart["checkout_id"],
        payment_token="success_token"
    )
"""

import asyncio
import json
import logging
from typing import Any, Optional

from .client import UCPClient, UCPClientError

# Module logger
logger = logging.getLogger("ucp_client.agent_tools")
from ucp_sdk.models.schemas.shopping import checkout_create_req
from ucp_sdk.models.schemas.shopping import checkout_update_req
from ucp_sdk.models.schemas.shopping import payment_create_req
from ucp_sdk.models.schemas.shopping.types import buyer
from ucp_sdk.models.schemas.shopping.types import item_create_req
from ucp_sdk.models.schemas.shopping.types import item_update_req
from ucp_sdk.models.schemas.shopping.types import line_item_create_req
from ucp_sdk.models.schemas.shopping.types import line_item_update_req
from ucp_sdk.models.schemas.shopping.types.postal_address import PostalAddress


def _run_async(coro):
    """Run an async coroutine synchronously."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If there's already a running loop (e.g., in Jupyter), create a new one
            import nest_asyncio
            nest_asyncio.apply()
            return loop.run_until_complete(coro)
        return loop.run_until_complete(coro)
    except RuntimeError:
        # No event loop exists, create a new one
        return asyncio.run(coro)


class UCPAgentTools:
    """LLM-friendly tools for UCP Shopping API.
    
    This class provides simplified methods that can be easily used as LLM agent tools.
    All methods return dictionaries with clear, structured data.
    
    Attributes:
        server_url: The base URL of the UCP server.
        debug: Whether to enable debug logging.
        
    Example:
        tools = UCPAgentTools("http://localhost:8182", debug=True)
        merchant_info = tools.discover_merchant()
    """
    
    def __init__(self, server_url: str, debug: bool = False):
        """Initialize UCP Agent Tools.
        
        Args:
            server_url: Base URL of the UCP server (e.g., "http://localhost:8182").
                       This is the merchant's UCP-compatible API endpoint.
            debug: Enable debug logging to see inputs, requests, and responses.
        """
        self.server_url = server_url.rstrip("/")
        self._cached_handlers: list[dict] = []
        self.debug = debug
        
        if debug:
            # Only configure our logger, not the root logger (to avoid noise from httpx, PIL, etc.)
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
            logger.addHandler(handler)
            logger.setLevel(logging.DEBUG)
            # Prevent propagation to root logger to avoid duplicate logs
            logger.propagate = False
    
    def _log_input(self, method_name: str, **kwargs):
        """Log method input parameters."""
        if self.debug:
            filtered = {k: v for k, v in kwargs.items() if v is not None}
            logger.debug("[%s] INPUT: %s", method_name, json.dumps(filtered, indent=2, default=str))
    
    def _log_request(self, method_name: str, endpoint: str, data: dict = None):
        """Log the API request being made."""
        if self.debug:
            logger.debug("[%s] REQUEST: %s %s", method_name, endpoint, 
                        json.dumps(data, indent=2, default=str) if data else "")
    
    def _log_response(self, method_name: str, response: dict):
        """Log the API response."""
        if self.debug:
            logger.debug("[%s] RESPONSE: %s", method_name, json.dumps(response, indent=2, default=str))
    
    def get_available_products(self) -> dict:
        """Get the list of available products that can be purchased.
        
        Call this to see what products are available in the store.
        Use the product_id values when creating a cart.
        
        Returns:
            A dictionary containing:
            - success (bool): Always True
            - products (list[dict]): Available products, each with:
                - product_id (str): Unique identifier to use in create_cart
                - title (str): Product display name
                - description (str): Product description
                - price_cents (int): Price in cents
            - product_count (int): Number of available products
            
        Example:
            >>> tools.get_available_products()
            {
                "success": True,
                "products": [
                    {"product_id": "bouquet_roses", "title": "Bouquet of Red Roses", "price_cents": 3500},
                    {"product_id": "pot_ceramic", "title": "Ceramic Pot", "price_cents": 1500}
                ],
                "product_count": 6
            }
        """
        products = [
            {
                "product_id": "bouquet_roses",
                "title": "Bouquet of Red Roses",
                "description": "A beautiful bouquet of fresh red roses",
                "price_cents": 3500
            },
            {
                "product_id": "pot_ceramic",
                "title": "Ceramic Pot",
                "description": "Handcrafted ceramic flower pot",
                "price_cents": 1500
            },
            {
                "product_id": "bouquet_sunflowers",
                "title": "Sunflower Bundle",
                "description": "Bright and cheerful sunflower arrangement",
                "price_cents": 2500
            },
            {
                "product_id": "bouquet_tulips",
                "title": "Spring Tulips",
                "description": "Fresh colorful spring tulips",
                "price_cents": 3000
            },
            {
                "product_id": "orchid_white",
                "title": "White Orchid",
                "description": "Elegant white orchid plant",
                "price_cents": 4500
            },
            {
                "product_id": "gardenias",
                "title": "Gardenias",
                "description": "Fragrant gardenia flowers",
                "price_cents": 2000
            }
        ]
        return {
            "success": True,
            "products": products,
            "product_count": len(products)
        }
    
    def get_available_discount_codes(self) -> dict:
        """Get the list of available discount codes.
        
        Call this to see what discount codes can be applied to the cart.
        
        Returns:
            A dictionary containing:
            - success (bool): Always True
            - discount_codes (list[dict]): Available codes, each with:
                - code (str): The discount code to use with apply_discount
                - description (str): What the discount does
                - discount_percent (int): Percentage discount (if applicable)
            - code_count (int): Number of available codes
            
        Example:
            >>> tools.get_available_discount_codes()
            {
                "success": True,
                "discount_codes": [
                    {"code": "10OFF", "description": "10% off your order", "discount_percent": 10}
                ],
                "code_count": 1
            }
        """
        codes = [
            {
                "code": "10OFF",
                "description": "10% off your entire order",
                "discount_percent": 10
            }
        ]
        return {
            "success": True,
            "discount_codes": codes,
            "code_count": len(codes)
        }
    
    def get_your_user(self) -> dict:
        """Get your user information for making purchases.
        
        This returns your registered user details including name, email,
        and saved addresses. Use this information when creating a cart.
        
        Returns:
            A dictionary containing:
            - success (bool): Always True
            - user (dict): Your user information:
                - name (str): Your full name
                - email (str): Your email address (use this in create_cart)
            - addresses (list[dict]): Your saved shipping addresses
            
        Example:
            >>> tools.get_your_user()
            {
                "success": True,
                "user": {"name": "John Doe", "email": "john.doe@example.com"},
                "addresses": [{"street": "123 Main St", "city": "Springfield", ...}]
            }
        """
        return {
            "success": True,
            "user": {
                "name": "John Doe",
                "email": "john.doe@example.com"
            },
            "addresses": [
                {
                    "street": "123 Main St",
                    "city": "Springfield",
                    "state": "IL",
                    "postal_code": "62704",
                    "country": "US"
                },
                {
                    "street": "456 Oak Ave",
                    "city": "Metropolis",
                    "state": "NY",
                    "postal_code": "10012",
                    "country": "US"
                }
            ]
        }
    
    def discover_merchant(self) -> dict:
        """Discover what capabilities the merchant supports.
        
        Call this function FIRST before any other operation to understand
        what payment methods and features the merchant supports.
        
        Returns:
            A dictionary containing:
            - payment_handlers (list[dict]): Available payment methods, each with:
                - id (str): Handler identifier (e.g., "mock_payment_handler", "stripe")
                - name (str): Human-readable name
            - handler_count (int): Number of available payment handlers
            - success (bool): Whether the discovery was successful
            - error (str, optional): Error message if discovery failed
            
        Example:
            >>> tools.discover_merchant()
            {
                "success": True,
                "payment_handlers": [
                    {"id": "mock_payment_handler", "name": "Mock Payment"}
                ],
                "handler_count": 1
            }
        """
        self._log_input("discover_merchant")
        
        async def _discover():
            async with UCPClient(base_url=self.server_url) as client:
                self._log_request("discover_merchant", f"GET {self.server_url}/.well-known/ucp")
                profile = await client.get_merchant_profile()
                handlers = []
                if profile.payment and profile.payment.handlers:
                    handlers = [{"id": h.id, "name": h.name} for h in profile.payment.handlers]
                return handlers
        
        try:
            handlers = _run_async(_discover())
            self._cached_handlers = handlers
            result = {
                "success": True,
                "payment_handlers": handlers,
                "handler_count": len(handlers),
            }
            self._log_response("discover_merchant", result)
            return result
        except UCPClientError as e:
            result = {
                "success": False,
                "error": str(e),
                "payment_handlers": [],
                "handler_count": 0,
            }
            self._log_response("discover_merchant", result)
            return result
        except Exception as e:
            result = {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "payment_handlers": [],
                "handler_count": 0,
            }
            self._log_response("discover_merchant", result)
            return result
    
    def create_cart(
        self,
        product_id: str = None,
        quantity: int = 1,
        buyer_name: str = None,
        buyer_email: str = None,
        currency: str = "USD"
    ) -> dict:
        """Create a new shopping cart with a product.
        
        Creates a checkout session with the specified product.
        Call get_your_user() first to get buyer_name and buyer_email.
        
        Note: This method automatically discovers merchant payment handlers
        if not already cached from a previous discover_merchant() call.
        
        Args:
            product_id: The product to buy. Options:
                - "bouquet_roses" - Bouquet of Red Roses ($35)
                - "pot_ceramic" - Ceramic Pot ($15)
                - "bouquet_sunflowers" - Sunflower Bundle ($25)
                - "bouquet_tulips" - Spring Tulips ($30)
                - "orchid_white" - White Orchid ($45)
                - "gardenias" - Gardenias ($20)
            quantity: How many to buy. Default is 1.
            buyer_name: Your name - get this from get_your_user()
            buyer_email: Your email - get this from get_your_user()
            currency: Currency code. Default is "USD".
        
        Returns:
            A dictionary containing:
            - success (bool): Whether cart creation was successful
            - checkout_id (str): Unique identifier for this checkout session
            - total_amount (int): Total price in cents
            - currency (str): Currency code
            - item_count (int): Number of items in cart
            - error (str, optional): Error message if creation failed
            
        Example:
            >>> tools.create_cart(
            ...     product_id="bouquet_roses",
            ...     quantity=2,
            ...     buyer_name="John Doe",
            ...     buyer_email="john.doe@example.com"
            ... )
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "total_amount": 7000,
                "currency": "USD",
                "item_count": 1
            }
        """
        self._log_input("create_cart", product_id=product_id, quantity=quantity, 
                       buyer_name=buyer_name, buyer_email=buyer_email, currency=currency)
        
        # Validate required parameters
        if not product_id:
            result = {
                "success": False,
                "error": 'Missing product_id. Options: "bouquet_roses", "pot_ceramic", "bouquet_sunflowers", "bouquet_tulips", "orchid_white", "gardenias"',
                "checkout_id": None,
            }
            self._log_response("create_cart", result)
            return result
        
        if not buyer_name or not buyer_email:
            result = {
                "success": False,
                "error": 'Missing buyer_name or buyer_email. Call get_your_user() first to get these values.',
                "checkout_id": None,
            }
            self._log_response("create_cart", result)
            return result
        
        # Map product_id to title
        product_titles = {
            "bouquet_roses": "Bouquet of Red Roses",
            "pot_ceramic": "Ceramic Pot",
            "bouquet_sunflowers": "Sunflower Bundle",
            "bouquet_tulips": "Spring Tulips",
            "orchid_white": "White Orchid",
            "gardenias": "Gardenias",
        }
        product_title = product_titles.get(product_id, product_id)
        
        async def _create():
            async with UCPClient(base_url=self.server_url) as client:
                # Auto-discover handlers if not cached
                handlers_dict = self._cached_handlers
                if not handlers_dict:
                    profile = await client.get_merchant_profile()
                    if profile.payment and profile.payment.handlers:
                        handlers_dict = [{"id": h.id, "name": h.name} for h in profile.payment.handlers]
                        self._cached_handlers = handlers_dict
                    else:
                        handlers_dict = []
                
                # Build line item from simple parameters
                item_req = item_create_req.ItemCreateRequest(
                    id=product_id,
                    title=product_title
                )
                line_item = line_item_create_req.LineItemCreateRequest(
                    quantity=quantity,
                    item=item_req
                )
                line_items = [line_item]
                
                payment_req = payment_create_req.PaymentCreateRequest(
                    instruments=[],
                    selected_instrument_id=None,
                    handlers=handlers_dict,
                )
                
                buyer_req = buyer.Buyer(full_name=buyer_name, email=buyer_email)
                
                create_request = checkout_create_req.CheckoutCreateRequest(
                    currency=currency,
                    line_items=line_items,
                    payment=payment_req,
                    buyer=buyer_req,
                )
                
                request_data = create_request.model_dump(mode="json", by_alias=True, exclude_unset=True)
                self._log_request("create_cart", f"POST {self.server_url}/checkout-sessions", request_data)
                
                checkout = await client.create_checkout(create_request)
                return checkout
        
        try:
            checkout = _run_async(_create())
            
            # Extract total amount
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            # Extract line item details
            line_item_details = []
            for li in checkout.line_items:
                line_item_details.append({
                    "id": li.id,
                    "product_id": li.item.id if li.item else None,
                    "title": li.item.title if li.item else None,
                    "quantity": li.quantity,
                })
            
            result = {
                "success": True,
                "checkout_id": checkout.id,
                "total_amount": total_amount,
                "currency": checkout.currency,
                "item_count": len(checkout.line_items),
                "line_items": line_item_details,
            }
            self._log_response("create_cart", result)
            return result
        except UCPClientError as e:
            result = {
                "success": False,
                "error": str(e),
                "checkout_id": None,
            }
            self._log_response("create_cart", result)
            return result
        except Exception as e:
            result = {
                "success": False,
                "error": f"Unexpected error: {str(e)}",
                "checkout_id": None,
            }
            self._log_response("create_cart", result)
            return result
    
    def add_items_to_cart(
        self,
        checkout_id: str,
        product_id: str,
        quantity: int = 1
    ) -> dict:
        """Add more of a product to an existing cart.
        
        Use this to add additional items to a cart that was already created.
        
        Args:
            checkout_id: The checkout session ID from create_cart()
            product_id: Product to add. Options:
                - "bouquet_roses" - Bouquet of Red Roses ($35)
                - "pot_ceramic" - Ceramic Pot ($15)
                - "bouquet_sunflowers" - Sunflower Bundle ($25)
                - "bouquet_tulips" - Spring Tulips ($30)
                - "orchid_white" - White Orchid ($45)
                - "gardenias" - Gardenias ($20)
            quantity: How many to add. Default is 1.
        
        Returns:
            A dictionary containing:
            - success (bool): Whether items were added successfully
            - checkout_id (str): The checkout session ID
            - total_amount (int): Updated total price in cents
            - item_count (int): Updated number of items
            - error (str, optional): Error message if operation failed
            
        Example:
            >>> tools.add_items_to_cart("chk_abc123", "orchid_white", 2)
            {"success": True, "checkout_id": "chk_abc123", "total_amount": 12500, "item_count": 2}
        """
        self._log_input("add_items_to_cart", checkout_id=checkout_id, product_id=product_id, quantity=quantity)
        
        # Map product_id to title
        product_titles = {
            "bouquet_roses": "Bouquet of Red Roses",
            "pot_ceramic": "Ceramic Pot",
            "bouquet_sunflowers": "Sunflower Bundle",
            "bouquet_tulips": "Spring Tulips",
            "orchid_white": "White Orchid",
            "gardenias": "Gardenias",
        }
        product_title = product_titles.get(product_id, product_id)
        
        async def _add_items():
            async with UCPClient(base_url=self.server_url) as client:
                # First get current checkout
                checkout = await client.get_checkout(checkout_id)
                
                # Build update request with existing + new items
                line_items_update = []
                
                # Keep existing items
                for li in checkout.line_items:
                    item_upd = item_update_req.ItemUpdateRequest(
                        id=li.item.id,
                        title=li.item.title
                    )
                    li_upd = line_item_update_req.LineItemUpdateRequest(
                        id=li.id,
                        quantity=li.quantity,
                        item=item_upd,
                    )
                    line_items_update.append(li_upd)
                
                # Add new item
                item_upd = item_update_req.ItemUpdateRequest(
                    id=product_id,
                    title=product_title
                )
                li_upd = line_item_update_req.LineItemUpdateRequest(
                    quantity=quantity,
                    item=item_upd,
                )
                line_items_update.append(li_upd)
                
                # Get payment dict
                payment_dict = {}
                if checkout.payment:
                    if isinstance(checkout.payment, dict):
                        payment_dict = checkout.payment
                    else:
                        payment_dict = checkout.payment.model_dump(mode="json", by_alias=True, exclude_none=True)
                
                update_request = checkout_update_req.CheckoutUpdateRequest(
                    id=checkout_id,
                    line_items=line_items_update,
                    currency=checkout.currency,
                    payment=payment_dict,
                )
                
                request_data = update_request.model_dump(mode="json", by_alias=True, exclude_unset=True)
                self._log_request("add_items_to_cart", f"PUT {self.server_url}/checkout-sessions/{checkout_id}", request_data)
                
                updated = await client.update_checkout(checkout_id, update_request)
                return updated
        
        try:
            checkout = _run_async(_add_items())
            
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            line_item_details = []
            for li in checkout.line_items:
                line_item_details.append({
                    "id": li.id,
                    "product_id": li.item.id if li.item else None,
                    "title": li.item.title if li.item else None,
                    "quantity": li.quantity,
                })
            
            result = {
                "success": True,
                "checkout_id": checkout_id,
                "total_amount": total_amount,
                "currency": checkout.currency,
                "item_count": len(checkout.line_items),
                "line_items": line_item_details,
            }
            self._log_response("add_items_to_cart", result)
            return result
        except UCPClientError as e:
            result = {"success": False, "error": str(e), "checkout_id": checkout_id}
            self._log_response("add_items_to_cart", result)
            return result
        except Exception as e:
            result = {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
            self._log_response("add_items_to_cart", result)
            return result
    
    def apply_discount(self, checkout_id: str, discount_code: str) -> dict:
        """Apply a discount code to the cart.
        
        Use this to apply promotional or discount codes to reduce the total price.
        
        Args:
            checkout_id: The checkout session ID from create_cart()
            discount_code: The discount code to apply (e.g., "10OFF", "SUMMER20")
        
        Returns:
            A dictionary containing:
            - success (bool): Whether the discount was applied
            - checkout_id (str): The checkout session ID
            - total_amount (int): New total after discount in cents
            - discount_applied (bool): Whether a discount is now active
            - applied_codes (list[str]): List of applied discount codes
            - savings (int): Amount saved in cents (if available)
            - error (str, optional): Error message if discount failed
            
        Example:
            >>> tools.apply_discount("chk_abc123", "10OFF")
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "total_amount": 2250,
                "discount_applied": True,
                "applied_codes": ["10OFF"],
                "savings": 250
            }
        """
        self._log_input("apply_discount", checkout_id=checkout_id, discount_code=discount_code)
        
        async def _apply_discount():
            async with UCPClient(base_url=self.server_url) as client:
                checkout = await client.get_checkout(checkout_id)
                
                # Build line items update
                line_items_update = []
                for li in checkout.line_items:
                    item_upd = item_update_req.ItemUpdateRequest(
                        id=li.item.id,
                        title=li.item.title
                    )
                    li_upd = line_item_update_req.LineItemUpdateRequest(
                        id=li.id,
                        quantity=li.quantity,
                        item=item_upd,
                    )
                    line_items_update.append(li_upd)
                
                # Get payment dict
                payment_dict = {}
                if checkout.payment:
                    if isinstance(checkout.payment, dict):
                        payment_dict = checkout.payment
                    else:
                        payment_dict = checkout.payment.model_dump(mode="json", by_alias=True, exclude_none=True)
                
                update_request = checkout_update_req.CheckoutUpdateRequest(
                    id=checkout_id,
                    line_items=line_items_update,
                    currency=checkout.currency,
                    payment=payment_dict,
                )
                
                # Add discount to request
                update_dict = update_request.model_dump(mode="json", by_alias=True, exclude_none=True)
                update_dict["discounts"] = {"codes": [discount_code]}
                
                self._log_request("apply_discount", f"PUT {self.server_url}/checkout-sessions/{checkout_id}", update_dict)
                
                # Make raw request
                from ucp_sdk.models.schemas.shopping import checkout_resp
                response_data = await client._make_request(
                    "PUT", f"/checkout-sessions/{checkout_id}", update_dict
                )
                return checkout_resp.CheckoutResponse(**response_data)
        
        try:
            checkout = _run_async(_apply_discount())
            
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            # Extract applied discounts
            applied_codes = []
            if checkout.discounts and hasattr(checkout.discounts, 'applied'):
                applied_codes = [d.code for d in checkout.discounts.applied if hasattr(d, 'code')]
            
            result = {
                "success": True,
                "checkout_id": checkout_id,
                "total_amount": total_amount,
                "discount_applied": len(applied_codes) > 0,
                "applied_codes": applied_codes,
            }
            self._log_response("apply_discount", result)
            return result
        except UCPClientError as e:
            result = {"success": False, "error": str(e), "checkout_id": checkout_id, "discount_applied": False}
            self._log_response("apply_discount", result)
            return result
        except Exception as e:
            result = {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id, "discount_applied": False}
            self._log_response("apply_discount", result)
            return result
    
    def set_shipping_address(
        self,
        checkout_id: str,
        street: str,
        city: str,
        state: str,
        country: str,
        postal_code: str
    ) -> dict:
        """Set the shipping address and get available shipping options.
        
        This sets where the order should be shipped and triggers the calculation
        of available shipping options and costs.
        
        Args:
            checkout_id: The checkout session ID from create_cart()
            street: Street address (e.g., "123 Main St")
            city: City name (e.g., "San Francisco")
            state: State/province code (e.g., "CA")
            country: Country code (e.g., "US")
            postal_code: Postal/ZIP code (e.g., "94102")
        
        Returns:
            A dictionary containing:
            - success (bool): Whether address was set successfully
            - checkout_id (str): The checkout session ID
            - total_amount (int): Total including shipping in cents
            - shipping_options (list[dict]): Available shipping options, each with:
                - id (str): Option identifier
                - name (str): Option name (e.g., "Standard Shipping")
                - price (int): Shipping cost in cents
                - estimated_days (str): Delivery estimate
            - selected_option_id (str): Currently selected shipping option ID
            - error (str, optional): Error message if operation failed
            
        Example:
            >>> tools.set_shipping_address(
            ...     checkout_id="chk_abc123",
            ...     street="123 Main St",
            ...     city="San Francisco",
            ...     state="CA",
            ...     country="US",
            ...     postal_code="94102"
            ... )
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "total_amount": 2750,
                "shipping_options": [
                    {"id": "opt_1", "name": "Standard", "price": 500},
                    {"id": "opt_2", "name": "Express", "price": 1500}
                ],
                "selected_option_id": "opt_1"
            }
        """
        self._log_input("set_shipping_address", checkout_id=checkout_id, street=street, 
                       city=city, state=state, country=country, postal_code=postal_code)
        
        async def _set_address():
            async with UCPClient(base_url=self.server_url) as client:
                checkout = await client.get_checkout(checkout_id)
                
                # Build line items
                line_items_update = []
                for li in checkout.line_items:
                    item_upd = item_update_req.ItemUpdateRequest(
                        id=li.item.id,
                        title=li.item.title
                    )
                    li_upd = line_item_update_req.LineItemUpdateRequest(
                        id=li.id,
                        quantity=li.quantity,
                        item=item_upd,
                    )
                    line_items_update.append(li_upd)
                
                # Get payment dict
                payment_dict = {}
                if checkout.payment:
                    if isinstance(checkout.payment, dict):
                        payment_dict = checkout.payment
                    else:
                        payment_dict = checkout.payment.model_dump(mode="json", by_alias=True, exclude_none=True)
                
                # First trigger fulfillment method generation
                trigger_req = checkout_update_req.CheckoutUpdateRequest(
                    id=checkout_id,
                    line_items=line_items_update,
                    currency=checkout.currency,
                    payment=payment_dict,
                    fulfillment={"methods": [{"type": "shipping"}]},
                )
                checkout = await client.update_checkout(checkout_id, trigger_req)
                
                # Get fulfillment methods and destination
                def get_fulfillment_data(co):
                    if not co.fulfillment:
                        return None, None, None
                    if isinstance(co.fulfillment, dict):
                        methods = co.fulfillment.get("methods", [])
                    else:
                        methods = co.fulfillment.methods if hasattr(co.fulfillment, 'methods') else []
                    
                    if not methods:
                        return None, None, None
                    
                    method = methods[0]
                    if isinstance(method, dict):
                        destinations = method.get("destinations", [])
                        groups = method.get("groups", [])
                    else:
                        destinations = method.destinations if hasattr(method, 'destinations') else []
                        groups = method.groups if hasattr(method, 'groups') else []
                    
                    return method, destinations, groups
                
                method, destinations, groups = get_fulfillment_data(checkout)
                
                # Select first destination if available
                dest_id = None
                if destinations:
                    dest = destinations[0]
                    dest_id = dest.get("id") if isinstance(dest, dict) else dest.id
                    
                    # Select destination
                    dest_req = checkout_update_req.CheckoutUpdateRequest(
                        id=checkout_id,
                        line_items=line_items_update,
                        currency=checkout.currency,
                        payment=payment_dict,
                        fulfillment={
                            "methods": [{"type": "shipping", "selected_destination_id": dest_id}]
                        },
                    )
                    checkout = await client.update_checkout(checkout_id, dest_req)
                    method, destinations, groups = get_fulfillment_data(checkout)
                
                # Get options and auto-select first one
                options = []
                selected_option_id = None
                if groups:
                    group = groups[0]
                    if isinstance(group, dict):
                        group_options = group.get("options", [])
                    else:
                        group_options = group.options if hasattr(group, 'options') else []
                    
                    for opt in group_options:
                        if isinstance(opt, dict):
                            opt_id = opt.get("id")
                            opt_name = opt.get("name", "Shipping")
                            opt_price = opt.get("price", {}).get("amount", 0) if isinstance(opt.get("price"), dict) else 0
                        else:
                            opt_id = opt.id
                            opt_name = opt.name if hasattr(opt, 'name') else "Shipping"
                            opt_price = opt.price.amount if hasattr(opt, 'price') and opt.price else 0
                        
                        options.append({
                            "id": opt_id,
                            "name": opt_name,
                            "price": opt_price,
                        })
                    
                    # Auto-select first option
                    if options:
                        selected_option_id = options[0]["id"]
                        
                        option_req = checkout_update_req.CheckoutUpdateRequest(
                            id=checkout_id,
                            line_items=line_items_update,
                            currency=checkout.currency,
                            payment=payment_dict,
                            fulfillment={
                                "methods": [{
                                    "type": "shipping",
                                    "selected_destination_id": dest_id,
                                    "groups": [{"selected_option_id": selected_option_id}],
                                }]
                            },
                        )
                        checkout = await client.update_checkout(checkout_id, option_req)
                
                return checkout, options, selected_option_id
        
        try:
            checkout, options, selected_option_id = _run_async(_set_address())
            
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            result = {
                "success": True,
                "checkout_id": checkout_id,
                "total_amount": total_amount,
                "shipping_options": options,
                "selected_option_id": selected_option_id,
            }
            self._log_response("set_shipping_address", result)
            return result
        except UCPClientError as e:
            result = {"success": False, "error": str(e), "checkout_id": checkout_id}
            self._log_response("set_shipping_address", result)
            return result
        except Exception as e:
            result = {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
            self._log_response("set_shipping_address", result)
            return result
    
    def select_shipping_option(self, checkout_id: str, option_id: str) -> dict:
        """Select a specific shipping option.
        
        Use this after set_shipping_address() to choose a different shipping option
        from the available options.
        
        Args:
            checkout_id: The checkout session ID
            option_id: The shipping option ID to select (from shipping_options list)
        
        Returns:
            A dictionary containing:
            - success (bool): Whether option was selected
            - checkout_id (str): The checkout session ID
            - total_amount (int): Updated total with new shipping cost
            - selected_option_id (str): The newly selected option ID
            - error (str, optional): Error message if selection failed
            
        Example:
            >>> tools.select_shipping_option("chk_abc123", "opt_express")
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "total_amount": 3750,
                "selected_option_id": "opt_express"
            }
        """
        async def _select_option():
            async with UCPClient(base_url=self.server_url) as client:
                checkout = await client.get_checkout(checkout_id)
                
                # Build line items
                line_items_update = []
                for li in checkout.line_items:
                    item_upd = item_update_req.ItemUpdateRequest(
                        id=li.item.id,
                        title=li.item.title
                    )
                    li_upd = line_item_update_req.LineItemUpdateRequest(
                        id=li.id,
                        quantity=li.quantity,
                        item=item_upd,
                    )
                    line_items_update.append(li_upd)
                
                # Get payment dict
                payment_dict = {}
                if checkout.payment:
                    if isinstance(checkout.payment, dict):
                        payment_dict = checkout.payment
                    else:
                        payment_dict = checkout.payment.model_dump(mode="json", by_alias=True, exclude_none=True)
                
                # Get current destination
                dest_id = None
                if checkout.fulfillment:
                    if isinstance(checkout.fulfillment, dict):
                        methods = checkout.fulfillment.get("methods", [])
                    else:
                        methods = checkout.fulfillment.methods if hasattr(checkout.fulfillment, 'methods') else []
                    
                    if methods:
                        method = methods[0]
                        if isinstance(method, dict):
                            dest_id = method.get("selected_destination_id")
                        else:
                            dest_id = method.selected_destination_id if hasattr(method, 'selected_destination_id') else None
                
                option_req = checkout_update_req.CheckoutUpdateRequest(
                    id=checkout_id,
                    line_items=line_items_update,
                    currency=checkout.currency,
                    payment=payment_dict,
                    fulfillment={
                        "methods": [{
                            "type": "shipping",
                            "selected_destination_id": dest_id,
                            "groups": [{"selected_option_id": option_id}],
                        }]
                    },
                )
                return await client.update_checkout(checkout_id, option_req)
        
        try:
            checkout = _run_async(_select_option())
            
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            return {
                "success": True,
                "checkout_id": checkout_id,
                "total_amount": total_amount,
                "selected_option_id": option_id,
            }
        except UCPClientError as e:
            return {"success": False, "error": str(e), "checkout_id": checkout_id}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
    
    def get_cart_summary(self, checkout_id: str) -> dict:
        """Get current cart summary and status.
        
        Use this to check the current state of a checkout session.
        
        Args:
            checkout_id: The checkout session ID
        
        Returns:
            A dictionary containing:
            - success (bool): Whether cart was retrieved
            - checkout_id (str): The checkout session ID
            - status (str): Current status (e.g., "open", "completed", "cancelled")
            - total_amount (int): Current total in cents
            - currency (str): Currency code
            - item_count (int): Number of items
            - line_items (list): Details of each item
            - has_shipping (bool): Whether shipping is configured
            - has_discount (bool): Whether discounts are applied
            - error (str, optional): Error message if retrieval failed
            
        Example:
            >>> tools.get_cart_summary("chk_abc123")
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "status": "open",
                "total_amount": 2750,
                "currency": "USD",
                "item_count": 2,
                "has_shipping": True,
                "has_discount": True
            }
        """
        async def _get_summary():
            async with UCPClient(base_url=self.server_url) as client:
                return await client.get_checkout(checkout_id)
        
        try:
            checkout = _run_async(_get_summary())
            
            total_amount = 0
            if checkout.totals:
                total_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            line_item_details = []
            for li in checkout.line_items:
                line_item_details.append({
                    "id": li.id,
                    "product_id": li.item.id if li.item else None,
                    "title": li.item.title if li.item else None,
                    "quantity": li.quantity,
                })
            
            has_shipping = False
            if checkout.fulfillment:
                if isinstance(checkout.fulfillment, dict):
                    has_shipping = bool(checkout.fulfillment.get("methods"))
                else:
                    has_shipping = bool(checkout.fulfillment.methods if hasattr(checkout.fulfillment, 'methods') else False)
            
            has_discount = False
            if checkout.discounts and hasattr(checkout.discounts, 'applied'):
                has_discount = len(checkout.discounts.applied) > 0
            
            return {
                "success": True,
                "checkout_id": checkout_id,
                "status": checkout.status if hasattr(checkout, 'status') else "unknown",
                "total_amount": total_amount,
                "currency": checkout.currency,
                "item_count": len(checkout.line_items),
                "line_items": line_item_details,
                "has_shipping": has_shipping,
                "has_discount": has_discount,
            }
        except UCPClientError as e:
            return {"success": False, "error": str(e), "checkout_id": checkout_id}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
    
    def complete_purchase(
        self,
        checkout_id: str,
        payment_token: str,
        card_last4: str = "4242",
        card_brand: str = "Visa",
        handler_id: str = "mock_payment_handler"
    ) -> dict:
        """Complete the checkout and process payment.
        
        This is the final step that charges the payment method and creates the order.
        Call this after setting up the cart, shipping, and any discounts.
        
        Args:
            checkout_id: The checkout session ID
            payment_token: Payment token from the payment provider.
                          For testing, use "success_token" to simulate success.
            card_last4: Last 4 digits of card (for display). Default: "4242"
            card_brand: Card brand name. Default: "Visa"
            handler_id: Payment handler to use. Default: "mock_payment_handler"
                       Use discover_merchant() to see available handlers.
        
        Returns:
            A dictionary containing:
            - success (bool): Whether payment was successful
            - checkout_id (str): The checkout session ID
            - status (str): Final checkout status ("completed" on success)
            - order_id (str): The created order ID
            - order_url (str): URL to view the order
            - final_amount (int): Amount charged in cents
            - error (str, optional): Error message if payment failed
            
        Example:
            >>> tools.complete_purchase(
            ...     checkout_id="chk_abc123",
            ...     payment_token="success_token"
            ... )
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "status": "completed",
                "order_id": "ord_xyz789",
                "order_url": "https://merchant.com/orders/ord_xyz789",
                "final_amount": 2750
            }
        """
        self._log_input("complete_purchase", checkout_id=checkout_id, payment_token=payment_token,
                       card_last4=card_last4, card_brand=card_brand, handler_id=handler_id)
        
        async def _complete():
            async with UCPClient(base_url=self.server_url) as client:
                billing_address = PostalAddress(
                    street_address="123 Main St",
                    address_locality="Anytown",
                    address_region="CA",
                    address_country="US",
                    postal_code="12345",
                )
                
                payment_data = {
                    "id": "instr_agent_card",
                    "handler_id": handler_id,
                    "handler_name": handler_id,
                    "type": "card",
                    "brand": card_brand,
                    "last_digits": card_last4,
                    "credential": {
                        "type": "token",
                        "token": payment_token
                    },
                    "billing_address": billing_address.model_dump(mode="json", by_alias=True, exclude_none=True),
                }
                
                risk_signals = {
                    "ip": "127.0.0.1",
                    "browser": "ucp-agent-tools",
                }
                
                request_data = {"payment_data": payment_data, "risk_signals": risk_signals}
                self._log_request("complete_purchase", f"POST {self.server_url}/checkout-sessions/{checkout_id}/complete", request_data)
                
                return await client.complete_checkout(
                    checkout_id=checkout_id,
                    payment_data=payment_data,
                    risk_signals=risk_signals,
                )
        
        try:
            checkout = _run_async(_complete())
            
            final_amount = 0
            if checkout.totals:
                final_amount = checkout.totals[-1].amount if hasattr(checkout.totals[-1], 'amount') else 0
            
            order_id = None
            order_url = None
            if checkout.order:
                order_id = checkout.order.id if hasattr(checkout.order, 'id') else None
                order_url = checkout.order.permalink_url if hasattr(checkout.order, 'permalink_url') else None
            
            result = {
                "success": True,
                "checkout_id": checkout_id,
                "status": checkout.status if hasattr(checkout, 'status') else "completed",
                "order_id": order_id,
                "order_url": order_url,
                "final_amount": final_amount,
            }
            self._log_response("complete_purchase", result)
            return result
        except UCPClientError as e:
            result = {"success": False, "error": str(e), "checkout_id": checkout_id}
            self._log_response("complete_purchase", result)
            return result
        except Exception as e:
            result = {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
            self._log_response("complete_purchase", result)
            return result
    
    def cancel_checkout(self, checkout_id: str) -> dict:
        """Cancel a checkout session.
        
        Use this to abandon a checkout and release any held resources.
        
        Args:
            checkout_id: The checkout session ID to cancel
        
        Returns:
            A dictionary containing:
            - success (bool): Whether cancellation was successful
            - checkout_id (str): The checkout session ID
            - status (str): Final status ("cancelled" on success)
            - error (str, optional): Error message if cancellation failed
            
        Example:
            >>> tools.cancel_checkout("chk_abc123")
            {
                "success": True,
                "checkout_id": "chk_abc123",
                "status": "cancelled"
            }
        """
        async def _cancel():
            async with UCPClient(base_url=self.server_url) as client:
                return await client.cancel_checkout(checkout_id)
        
        try:
            checkout = _run_async(_cancel())
            return {
                "success": True,
                "checkout_id": checkout_id,
                "status": checkout.status if hasattr(checkout, 'status') else "cancelled",
            }
        except UCPClientError as e:
            return {"success": False, "error": str(e), "checkout_id": checkout_id}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}", "checkout_id": checkout_id}
    
    def get_order(self, order_id: str) -> dict:
        """Get order details after purchase completion.
        
        Use this to check the status of a completed order.
        
        Args:
            order_id: The order ID from complete_purchase()
        
        Returns:
            A dictionary containing:
            - success (bool): Whether order was retrieved
            - order_id (str): The order ID
            - status (str): Order status (e.g., "processing", "shipped", "delivered")
            - order_data (dict): Full order details
            - error (str, optional): Error message if retrieval failed
            
        Example:
            >>> tools.get_order("ord_xyz789")
            {
                "success": True,
                "order_id": "ord_xyz789",
                "status": "processing",
                "order_data": {...}
            }
        """
        async def _get_order():
            async with UCPClient(base_url=self.server_url) as client:
                return await client.get_order(order_id)
        
        try:
            order_data = _run_async(_get_order())
            return {
                "success": True,
                "order_id": order_id,
                "status": order_data.get("status", "unknown") if isinstance(order_data, dict) else "unknown",
                "order_data": order_data,
            }
        except UCPClientError as e:
            return {"success": False, "error": str(e), "order_id": order_id}
        except Exception as e:
            return {"success": False, "error": f"Unexpected error: {str(e)}", "order_id": order_id}


# =============================================================================
# Tool Definitions for LLM Frameworks
# =============================================================================

def get_openai_tools_schema() -> list[dict]:
    """Get OpenAI Function Calling compatible tool definitions.
    
    Returns a list of tool definitions that can be passed to OpenAI's
    tools parameter for function calling.
    
    Example:
        from openai import OpenAI
        client = OpenAI()
        
        tools = get_openai_tools_schema()
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Help me buy flowers"}],
            tools=tools
        )
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "get_available_products",
                "description": "Get the list of available products that can be purchased. Returns product_id, title, description, and price for each product.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_available_discount_codes",
                "description": "Get the list of available discount codes that can be applied to the cart.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_your_user",
                "description": "Get your user information (name, email) and saved shipping addresses. Use this info when creating a cart.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "discover_merchant",
                "description": "Discover what payment methods and capabilities the merchant supports. Call this FIRST before any shopping operation.",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": []
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "create_cart",
                "description": "Create a shopping cart with a product. Call get_your_user() first to get buyer info.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "product_id": {
                            "type": "string",
                            "description": "Product to buy: 'bouquet_roses', 'pot_ceramic', 'bouquet_sunflowers', 'bouquet_tulips', 'orchid_white', or 'gardenias'"
                        },
                        "quantity": {
                            "type": "integer",
                            "description": "How many to buy",
                            "default": 1
                        },
                        "buyer_name": {"type": "string", "description": "Your name from get_your_user()"},
                        "buyer_email": {"type": "string", "description": "Your email from get_your_user()"},
                        "currency": {"type": "string", "description": "Currency code", "default": "USD"}
                    },
                    "required": ["product_id", "buyer_name", "buyer_email"]
                }
            }
        },
        {
            "type": "function", 
            "function": {
                "name": "add_items_to_cart",
                "description": "Add more of a product to an existing cart",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"},
                        "product_id": {"type": "string", "description": "Product to add: 'bouquet_roses', 'pot_ceramic', 'bouquet_sunflowers', 'bouquet_tulips', 'orchid_white', or 'gardenias'"},
                        "quantity": {"type": "integer", "description": "How many to add", "default": 1}
                    },
                    "required": ["checkout_id", "product_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "apply_discount",
                "description": "Apply a discount or promo code to the cart",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"},
                        "discount_code": {"type": "string", "description": "The discount code to apply"}
                    },
                    "required": ["checkout_id", "discount_code"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "set_shipping_address",
                "description": "Set shipping address and get available shipping options",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"},
                        "street": {"type": "string", "description": "Street address"},
                        "city": {"type": "string", "description": "City name"},
                        "state": {"type": "string", "description": "State/province code"},
                        "country": {"type": "string", "description": "Country code (e.g., US)"},
                        "postal_code": {"type": "string", "description": "Postal/ZIP code"}
                    },
                    "required": ["checkout_id", "street", "city", "state", "country", "postal_code"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "select_shipping_option",
                "description": "Select a specific shipping option from available options",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"},
                        "option_id": {"type": "string", "description": "Shipping option ID to select"}
                    },
                    "required": ["checkout_id", "option_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_cart_summary",
                "description": "Get current cart status and summary",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"}
                    },
                    "required": ["checkout_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "complete_purchase",
                "description": "Complete checkout and process payment. This is the final step.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID"},
                        "payment_token": {"type": "string", "description": "Payment token from provider. Use 'success_token' for testing."},
                        "card_last4": {"type": "string", "description": "Last 4 digits of card", "default": "4242"},
                        "card_brand": {"type": "string", "description": "Card brand", "default": "Visa"},
                        "handler_id": {"type": "string", "description": "Payment handler ID", "default": "mock_payment_handler"}
                    },
                    "required": ["checkout_id", "payment_token"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "cancel_checkout",
                "description": "Cancel and abandon a checkout session",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "checkout_id": {"type": "string", "description": "The checkout session ID to cancel"}
                    },
                    "required": ["checkout_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_order",
                "description": "Get order details after purchase completion",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "order_id": {"type": "string", "description": "The order ID"}
                    },
                    "required": ["order_id"]
                }
            }
        }
    ]


def get_anthropic_tools_schema() -> list[dict]:
    """Get Anthropic Tool Use compatible tool definitions.
    
    Returns a list of tool definitions that can be passed to Anthropic's
    tools parameter.
    """
    openai_tools = get_openai_tools_schema()
    return [
        {
            "name": t["function"]["name"],
            "description": t["function"]["description"],
            "input_schema": t["function"]["parameters"]
        }
        for t in openai_tools
    ]
