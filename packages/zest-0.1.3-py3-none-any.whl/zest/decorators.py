"""Contains the question decorator that defines a function as being the solution to a question."""

from functools import update_wrapper
from typing import Union

from .question import Question


def question(id_or_token: Union[int, str]):
    """
    Defines a function as being the solution for a Question.
    
    Args:
        id_or_token: Either a question ID (int) or a question token (str).
                    If a token is provided, the question ID will be fetched from the server.
    """
    def func_wrapper(func):
        q_obj = Question(id_or_token, func)
        update_wrapper(q_obj, func)
        return q_obj
    return func_wrapper

