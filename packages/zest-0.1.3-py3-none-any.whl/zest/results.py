"""Test result data structures."""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional


@dataclass
class TestResult:
    """Result of a single test case"""
    test_number: int
    description: str = ""
    passed: bool = False
    expected: Any = None
    actual: Any = None
    error: Optional[str] = None
    stdout: str = ""
    stderr: str = ""
    is_hidden: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)
