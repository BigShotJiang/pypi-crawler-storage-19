# Electroacoustics-AUTH

Electroacoustics-AUTH is a Python distribution package for supporting 
educational courses of Electroacoustics in Aristotle University of Thessaloniki. It
consists a tool library, ``electroacoustics``, which contains constants, functions and
other objects of Python programming language used in lectures,
exercises and other teaching material, mainly used in Jupyter Notebooks.

## 📦 Installation

### Install via PyPI

You can install this package from [PyPI](https://pypi.org) using `pip`:

```
pip install electroacoustics-auth
```

### Install via Conda

To install this package using [conda](https://docs.conda.io), make sure you have either [Miniconda](https://docs.conda.io/en/latest/miniconda.html) or [Anaconda](https://www.anaconda.com/products/distribution) installed.

Then, run the following command:

```
conda install csevast::electroacoustics-auth
```

## ✅ Installation verification
To check if the package was installed successfully, try:
```
python -c "import electroacoustics; help(electroacoustics)"
```
If the **electroacoustics-auth** is installed, this command will print all of its help documentation string.

# 💻 Examples of usage
To use the main module `electroacoustics` import it in your programm:
```
import electroacoustics as ea
```
or
```
import electroacoustics.electroacoustics as ea
```
To initialize a Jupyter Notebook for the Electroacoustics courses insert at the beginning of its first Python cell the following code:
```
from electroacoustics.init_ipynb import *
```

## ⚖️ License: GNU GPL v3.0

Copyright (C) 2026 Christos Sevastiadis

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

