# -*- coding: utf-8 -*-
# src\electroacoustics\electroacoustics.py

# License: GNU GPL v3.0
# Copyright (c) 2026 Christos Sevastiadis
# Author: Christos Sevastiadis <csevast@auth.gr>
"""
    Electroacoustics-AUTH Python distribution package.

    Provides supporting functions and classes for the Electroacoustics courses
    of Aristotle University of Thessaloniki.

    Modules:
    - electroacoustics : Provides constants, functions an other objects of Python
        programming language used in lectures, exercises and other teaching material,
        mainly used in Jupyter Notebooks.
    - init_ipynb : Provides the essential imports and settings for running the Jupyter
        Notbooks for the Electroacoustics courses of Aristotle University of
        Thessaloniki. It imports the electroacoustics module of the the
        Electroacoustics-AUTH package, NumPy, Pandas, Matplotlib, etc.

    Examples:
    import electroacoustics
    or
    import electroacoustics as ea

    Documentation:
    Execute in command line:

    >python -c "import electroacoustics; dir(electroacoustics); help(electroacoustics)"

    or in the Python interpreter:
    >import electroacoustics
    >dir(electroacoustics)
    >help(electroacoustics)
    >import electroacoustics.init_ipynb
    >help(electroacoustics.init_ipynb)

"""

__author__ = "Christos Sevastiadis <csevast@ece.auth.gr>"
from importlib.metadata import PackageNotFoundError, version

from . import electroacoustics
from .electroacoustics import *

try:
    __version__ = version("electroacoustics-auth")
except PackageNotFoundError:
    __version__ = "0.0.0"

__doc__ = (__doc__ or "") + "\n\n" + (electroacoustics.__doc__ or "")

__all__ = list(set(electroacoustics.__all__) | {"__version__"})
