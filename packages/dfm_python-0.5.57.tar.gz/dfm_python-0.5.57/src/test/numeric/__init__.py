"""Tests for numeric package."""

