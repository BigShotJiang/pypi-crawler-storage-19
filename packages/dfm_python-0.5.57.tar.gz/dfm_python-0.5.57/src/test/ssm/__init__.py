"""Tests for ssm package."""

