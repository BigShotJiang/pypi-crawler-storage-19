"""Tests for logger package."""

