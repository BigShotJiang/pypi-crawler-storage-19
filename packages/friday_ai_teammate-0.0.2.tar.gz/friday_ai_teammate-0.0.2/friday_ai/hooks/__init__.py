# Friday AI Hooks module
