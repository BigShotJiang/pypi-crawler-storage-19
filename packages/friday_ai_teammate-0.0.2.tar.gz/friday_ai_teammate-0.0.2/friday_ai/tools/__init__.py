# Friday AI Tools module
