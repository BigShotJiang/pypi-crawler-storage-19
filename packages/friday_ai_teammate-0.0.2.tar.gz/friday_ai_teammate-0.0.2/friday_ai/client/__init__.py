# Friday AI Client module
