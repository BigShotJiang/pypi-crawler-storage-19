# Friday AI UI module
