# Friday AI Agent module
