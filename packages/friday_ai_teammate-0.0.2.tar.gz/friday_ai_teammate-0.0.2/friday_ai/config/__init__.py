# Friday AI Config module
