# Friday AI Safety module
