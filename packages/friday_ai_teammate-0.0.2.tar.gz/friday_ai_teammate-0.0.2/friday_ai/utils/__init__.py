# Friday AI Utils module
