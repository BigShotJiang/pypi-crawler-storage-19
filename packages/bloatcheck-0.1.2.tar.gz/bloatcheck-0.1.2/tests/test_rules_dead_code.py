from pathlib import Path

from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index
from bloatcheck.rules import dead_code


def test_dead_code_alias_import_counts_as_use():
    root = Path(__file__).parent / "test_fixtures" / "dead_code_alias"
    config = load_config(root)
    index = build_index(config)
    issues = dead_code(index, config)

    assert not any(
        issue.symbol and issue.symbol.qualname.endswith(":foo") for issue in issues
    )


def test_dead_code_test_only_emits_dead003():
    root = Path(__file__).parent / "test_fixtures" / "dead_code_test_only"
    config = load_config(root)
    index = build_index(config)
    issues = dead_code(index, config)

    codes = {issue.code for issue in issues}
    assert "DEAD003" in codes
