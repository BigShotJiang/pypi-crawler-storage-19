from pathlib import Path

from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index


def test_index_deterministic_and_qualnames():
    root = Path(__file__).parent / "test_fixtures" / "indexing"
    config = load_config(root)

    idx1 = build_index(config)
    idx2 = build_index(config)

    assert [f.rel_path for f in idx1.files] == [f.rel_path for f in idx2.files]
    assert [s.qualname for s in idx1.symbols] == [s.qualname for s in idx2.symbols]

    qualnames = {s.qualname for s in idx1.symbols}
    assert "pkg.mod:Foo" in qualnames
    assert "pkg.mod:Foo.bar" in qualnames
    assert "pkg.mod:baz" in qualnames
