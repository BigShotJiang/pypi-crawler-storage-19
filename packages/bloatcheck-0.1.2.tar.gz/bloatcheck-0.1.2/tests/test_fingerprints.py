from pathlib import Path

from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index
from bloatcheck.rules import todos


def test_fingerprint_stable_across_line_shift():
    root_a = Path(__file__).parent / "test_fixtures" / "todo_fingerprint_a"
    root_b = Path(__file__).parent / "test_fixtures" / "todo_fingerprint_b"

    config_a = load_config(root_a)
    config_b = load_config(root_b)

    issues_a = todos(build_index(config_a), config_a)
    issues_b = todos(build_index(config_b), config_b)

    assert issues_a[0].fingerprint == issues_b[0].fingerprint
