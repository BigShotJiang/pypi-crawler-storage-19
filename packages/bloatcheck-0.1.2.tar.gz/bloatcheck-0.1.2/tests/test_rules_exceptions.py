from pathlib import Path

from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index
from bloatcheck.rules import exceptions


def test_exceptions_bare_except_emits_exc001():
    root = Path(__file__).parent / "test_fixtures" / "exceptions_logging_raise"
    config = load_config(root)
    index = build_index(config)
    issues = exceptions(index, config)

    codes = {issue.code for issue in issues}
    assert "EXC001" in codes
    assert "EXC002" not in codes
