from pathlib import Path

from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index
from bloatcheck.rules import duplicates


def test_duplicates_with_renamed_locals_match():
    root = Path(__file__).parent / "test_fixtures" / "duplicates_renamed_locals"
    config = load_config(root)
    index = build_index(config)
    issues = duplicates(index, config)

    assert len(issues) == 2
    hashes = {issue.evidence[0].data["norm_body_hash"] for issue in issues}
    assert len(hashes) == 1
