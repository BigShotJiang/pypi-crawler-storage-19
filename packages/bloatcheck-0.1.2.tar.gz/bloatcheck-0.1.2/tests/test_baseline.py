from bloatcheck.cli import main as cli_main
from bloatcheck.core.baseline import update_baseline
from bloatcheck.core.config import load_config
from bloatcheck.core.index import build_index
from bloatcheck.rules import exceptions


def test_baseline_prevents_failure(monkeypatch, tmp_path):
    repo_root = tmp_path / "repo"
    src_dir = repo_root / "src"
    src_dir.mkdir(parents=True)
    (src_dir / "exc.py").write_text(
        "def bad():\n    try:\n        return 1\n    except:\n        pass\n",
        encoding="utf-8",
    )

    config = load_config(repo_root)
    index = build_index(config)
    issues = exceptions(index, config)

    baseline_path = repo_root / "baseline.json"
    update_baseline(baseline_path, issues)

    monkeypatch.setenv("PYTHONPATH", str(repo_root))
    monkeypatch.setattr(
        "sys.argv",
        [
            "bloatcheck",
            "--repo-root",
            str(repo_root),
            "--baseline",
            str(baseline_path),
        ],
    )
    exit_code = cli_main()
    assert exit_code == 0
