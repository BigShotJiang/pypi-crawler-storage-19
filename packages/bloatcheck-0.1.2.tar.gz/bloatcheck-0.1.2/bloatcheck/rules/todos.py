"""TODO marker rule."""

from __future__ import annotations

import re

from ..core.config import Config
from ..core.index import RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation
from ..core.util import sha1_json

TODO_RE = re.compile(
    r"#\s*(TODO|FIXME|HACK|XXX|BUG|OPTIMIZE|REFACTOR)\b[:\s]*(.*)", re.IGNORECASE
)


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    for file_index in index.files:
        for line, text in file_index.tokens.comments:
            match = TODO_RE.search(text)
            if not match:
                continue
            marker = match.group(1).upper()
            snippet = match.group(2).strip()[:60]
            issue = Issue(
                code="TD001",
                title="TODO marker",
                message=f"{marker}: {snippet}",
                severity="info",
                confidence="high",
                location=IssueLocation(path=file_index.rel_path, line=line),
                evidence=[
                    Evidence(kind="todo", data={"marker": marker, "snippet": snippet})
                ],
                tags=["todos"],
            )
            issue.fingerprint = _fingerprint(issue, marker, snippet)
            issues.append(issue)
    return issues


def _fingerprint(issue: Issue, marker: str, snippet: str) -> str:
    payload = {
        "code": issue.code,
        "path": issue.location.path,
        "key": f"{marker}:{snippet[:20]}",
    }
    return f"sha1:{sha1_json(payload)}"
