"""Duplicate detection rules."""

from __future__ import annotations

import ast
import difflib
import hashlib
from dataclasses import dataclass

from ..core.config import Config
from ..core.index import FunctionInfo, RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation, IssueSymbol
from ..core.util import sha1_json


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    groups = _group_duplicates(index.functions)

    for norm_hash, funcs in groups.items():
        if len(funcs) < 2:
            continue
        locations = [f"{f.symbol.path}:{f.symbol.lineno}" for f in funcs]
        for func in funcs:
            location = IssueLocation(path=func.symbol.path, line=func.symbol.lineno)
            issue = Issue(
                code="DUP001",
                title="Duplicate function body",
                message=f"Duplicate body with {len(funcs)} occurrences",
                severity="warning",
                confidence="high",
                location=location,
                symbol=IssueSymbol(
                    qualname=func.symbol.qualname, kind=func.symbol.kind
                ),
                evidence=[
                    Evidence(
                        kind="duplicate",
                        data={"norm_body_hash": norm_hash, "locations": locations},
                    )
                ],
                tags=["duplicates"],
            )
            issue.fingerprint = _fingerprint(issue, func, norm_hash)
            issues.append(issue)

    issues.extend(_find_near_duplicates(index.functions, config))

    return issues


def _group_duplicates(
    functions: list[FunctionInfo], min_lines: int = 3
) -> dict[str, list[FunctionInfo]]:
    groups: dict[str, list[FunctionInfo]] = {}
    for func in functions:
        if func.symbol.end_lineno - func.symbol.lineno + 1 < min_lines:
            continue
        norm_dump = _normalized_dump(func.node)
        if not norm_dump:
            continue
        norm_hash = f"sha1:{sha1_json({'body': norm_dump})}"
        groups.setdefault(norm_hash, []).append(func)
    return groups


def _normalized_dump(node: ast.AST) -> str:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return ""
    body = list(node.body)
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
    ):
        if isinstance(body[0].value.value, str):
            body = body[1:]
    normalizer = _Normalizer()
    normalizer.register_args(node.args)
    normalized = [normalizer.visit(stmt) for stmt in body]
    dump = ast.dump(
        ast.Module(body=normalized, type_ignores=[]), include_attributes=False
    )
    return dump


class _Normalizer(ast.NodeTransformer):
    def __init__(self) -> None:
        self._arg_map: dict[str, str] = {}
        self._local_map: dict[str, str] = {}
        self._arg_count = 0
        self._local_count = 0

    def register_args(self, args: ast.arguments) -> None:
        for arg in args.posonlyargs + args.args + args.kwonlyargs:
            self.visit_arg(arg)
        if args.vararg is not None:
            self.visit_arg(args.vararg)
        if args.kwarg is not None:
            self.visit_arg(args.kwarg)

    def visit_arg(self, node: ast.arg) -> ast.arg:
        self._arg_count += 1
        name = f"a{self._arg_count}"
        self._arg_map[node.arg] = name
        return ast.arg(arg=name, annotation=None)

    def visit_Name(self, node: ast.Name) -> ast.Name:
        if node.id in self._arg_map:
            return ast.copy_location(
                ast.Name(id=self._arg_map[node.id], ctx=node.ctx), node
            )
        if isinstance(node.ctx, ast.Store):
            if node.id not in self._local_map:
                self._local_count += 1
                self._local_map[node.id] = f"v{self._local_count}"
            return ast.copy_location(
                ast.Name(id=self._local_map[node.id], ctx=node.ctx), node
            )
        if node.id in self._local_map:
            return ast.copy_location(
                ast.Name(id=self._local_map[node.id], ctx=node.ctx), node
            )
        return node

    def visit_Assign(self, node: ast.Assign) -> ast.Assign:
        node.targets = [self.visit(target) for target in node.targets]
        node.value = self.visit(node.value)
        return node

    def visit_AnnAssign(self, node: ast.AnnAssign) -> ast.AnnAssign:
        node.target = self.visit(node.target)
        if node.value is not None:
            node.value = self.visit(node.value)
        return node

    def visit_AugAssign(self, node: ast.AugAssign) -> ast.AugAssign:
        node.target = self.visit(node.target)
        node.value = self.visit(node.value)
        return node


def _fingerprint(issue: Issue, func: FunctionInfo, norm_hash: str) -> str:
    payload = {
        "code": issue.code,
        "path": issue.location.path,
        "symbol": func.symbol.qualname,
        "key": norm_hash,
    }
    return f"sha1:{sha1_json(payload)}"


def _find_near_duplicates(
    functions: list[FunctionInfo], config: Config, min_lines: int = 12
) -> list[Issue]:
    threshold = config.thresholds.near_duplicate_similarity
    simhash_cutoff = min(0.98, threshold + 0.05)
    candidates = _collect_near_duplicate_candidates(functions, min_lines)

    if len(candidates) < 2:
        return []

    candidates.sort(key=lambda item: len(item.dump))
    clusters, best_ratio = _cluster_near_duplicates(
        candidates, threshold=threshold, simhash_cutoff=simhash_cutoff
    )
    return _build_near_duplicate_issues(candidates, clusters, best_ratio, threshold)


@dataclass(frozen=True)
class Candidate:
    func: FunctionInfo
    dump: str
    simhash: int
    norm_hash: str
    token_count: int


def _collect_near_duplicate_candidates(
    functions: list[FunctionInfo], min_lines: int
) -> list[Candidate]:
    candidates: list[Candidate] = []
    for func in functions:
        if func.symbol.end_lineno - func.symbol.lineno + 1 < min_lines:
            continue
        dump = _normalized_dump(func.node)
        if not dump:
            continue
        candidates.append(
            Candidate(
                func=func,
                dump=dump,
                simhash=_simhash(dump),
                norm_hash=f"sha1:{sha1_json({'body': dump})}",
                token_count=len(dump.split()),
            )
        )
    return candidates


def _cluster_near_duplicates(
    candidates: list[Candidate],
    *,
    threshold: float,
    simhash_cutoff: float,
) -> tuple[dict[int, list[int]], dict[tuple[int, int], float]]:
    parent = list(range(len(candidates)))
    best_ratio: dict[tuple[int, int], float] = {}
    buckets = _simhash_buckets(candidates)

    def find(idx: int) -> int:
        while parent[idx] != idx:
            parent[idx] = parent[parent[idx]]
            idx = parent[idx]
        return idx

    def union(a: int, b: int) -> None:
        ra = find(a)
        rb = find(b)
        if ra != rb:
            parent[rb] = ra

    seen_pairs: set[tuple[int, int]] = set()
    for i, cand_a in enumerate(candidates):
        neighbor_idxs = _neighbor_indices(i, cand_a.simhash, buckets)
        for j in neighbor_idxs:
            if j <= i:
                continue
            pair = (i, j)
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            cand_b = candidates[j]
            if not _passes_near_duplicate_filters(cand_a, cand_b, simhash_cutoff):
                continue
            ratio = difflib.SequenceMatcher(None, cand_a.dump, cand_b.dump).ratio()
            if ratio >= threshold:
                union(i, j)
                best_ratio[(i, j)] = ratio

    clusters: dict[int, list[int]] = {}
    for idx in range(len(candidates)):
        root = find(idx)
        clusters.setdefault(root, []).append(idx)

    return clusters, best_ratio


def _passes_near_duplicate_filters(
    cand_a: Candidate, cand_b: Candidate, simhash_cutoff: float
) -> bool:
    len_a = len(cand_a.dump)
    len_b = len(cand_b.dump)
    if len_b - len_a > int(len_a * 0.2) + 1:
        return False
    if min(cand_a.token_count, cand_b.token_count) < 80:
        return False
    if cand_a.norm_hash == cand_b.norm_hash:
        return False
    sim_ratio = 1.0 - (_hamming_distance(cand_a.simhash, cand_b.simhash) / 64.0)
    return sim_ratio >= simhash_cutoff


def _build_near_duplicate_issues(
    candidates: list[Candidate],
    clusters: dict[int, list[int]],
    best_ratio: dict[tuple[int, int], float],
    threshold: float,
) -> list[Issue]:
    issues: list[Issue] = []
    for members in clusters.values():
        if len(members) < 2:
            continue
        locations = [
            f"{candidates[idx].func.symbol.path}:{candidates[idx].func.symbol.lineno}"
            for idx in members
        ]
        for idx in members:
            func = candidates[idx].func
            best = 0.0
            for other in members:
                if other == idx:
                    continue
                a, b = sorted((idx, other))
                best = max(best, best_ratio.get((a, b), 0.0))
            location = IssueLocation(path=func.symbol.path, line=func.symbol.lineno)
            issue = Issue(
                code="DUP002",
                title="Near-duplicate function body",
                message=f"Near-duplicate body (similarity={best:.2f})",
                severity="info",
                confidence="medium",
                location=location,
                symbol=IssueSymbol(
                    qualname=func.symbol.qualname, kind=func.symbol.kind
                ),
                evidence=[
                    Evidence(
                        kind="duplicate",
                        data={
                            "similarity": round(best, 3),
                            "method": "simhash+ratio",
                            "locations": locations,
                        },
                    )
                ],
                tags=["duplicates"],
            )
            issue.fingerprint = _fingerprint(issue, func, f"near:{threshold}")
            issues.append(issue)

    return issues


def _simhash(text: str) -> int:
    tokens = text.split()
    if not tokens:
        return 0
    weights = [0] * 64
    for token in tokens:
        h = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        val = int.from_bytes(h, "big")
        for bit in range(64):
            if val & (1 << bit):
                weights[bit] += 1
            else:
                weights[bit] -= 1
    out = 0
    for bit, weight in enumerate(weights):
        if weight > 0:
            out |= 1 << bit
    return out


def _hamming_distance(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def _simhash_buckets(
    candidates: list[Candidate], bands: int = 4
) -> dict[tuple[int, int], list[int]]:
    buckets: dict[tuple[int, int], list[int]] = {}
    band_size = 64 // bands
    for idx, cand in enumerate(candidates):
        for band in range(bands):
            shift = band * band_size
            mask = (1 << band_size) - 1
            key = (band, (cand.simhash >> shift) & mask)
            buckets.setdefault(key, []).append(idx)
    return buckets


def _neighbor_indices(
    idx: int,
    simhash: int,
    buckets: dict[tuple[int, int], list[int]],
    bands: int = 4,
    max_bucket_size: int = 50,
) -> set[int]:
    band_size = 64 // bands
    neighbors: set[int] = set()
    for band in range(bands):
        shift = band * band_size
        mask = (1 << band_size) - 1
        key = (band, (simhash >> shift) & mask)
        bucket = buckets.get(key, [])
        if len(bucket) > max_bucket_size:
            continue
        neighbors.update(bucket)
    neighbors.discard(idx)
    return neighbors
