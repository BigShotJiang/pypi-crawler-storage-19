"""Silent exception handler rules."""

from __future__ import annotations

import ast

from ..core.config import Config
from ..core.index import RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation
from ..core.util import sha1_json


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    for file_index in index.files:
        for node in ast.walk(file_index.tree):
            if not isinstance(node, ast.ExceptHandler):
                continue
            issue = _check_handler(node, file_index.rel_path)
            if issue:
                issues.append(issue)
    return issues


def _check_handler(node: ast.ExceptHandler, path: str) -> Issue | None:
    exc_type = _exc_type(node)
    meta = _handler_meta(node, exc_type)
    if meta is None:
        return None
    has_raise = any(isinstance(child, ast.Raise) for child in node.body)
    has_log = _has_logging(node.body)
    if _should_skip_handler(node.body, has_raise, has_log):
        return None

    code, severity, confidence = meta
    location = IssueLocation(path=path, line=node.lineno)
    issue = Issue(
        code=code,
        title="Silent exception handler",
        message=f"{exc_type or 'bare'} handler without raise/log",
        severity=severity,
        confidence=confidence,
        location=location,
        evidence=[
            Evidence(
                kind="exception",
                data={
                    "exception": exc_type or "bare",
                    "has_raise": has_raise,
                    "has_log": has_log,
                },
            )
        ],
        tags=["exceptions"],
    )
    issue.fingerprint = _fingerprint(issue, exc_type or "bare", path)
    return issue


def _handler_meta(
    node: ast.ExceptHandler, exc_type: str | None
) -> tuple[str, str, str] | None:
    if node.type is None:
        return ("EXC001", "error", "high")
    if exc_type == "Exception":
        return ("EXC002", "warning", "medium")
    if exc_type == "BaseException":
        return ("EXC003", "warning", "high")
    return None


def _should_skip_handler(body: list[ast.stmt], has_raise: bool, has_log: bool) -> bool:
    if has_raise or has_log:
        return True
    return not _is_trivial(body)


def _exc_type(node: ast.ExceptHandler) -> str | None:
    if node.type is None:
        return None
    if isinstance(node.type, ast.Name):
        return node.type.id
    return "<other>"


def _is_trivial(body: list[ast.stmt]) -> bool:
    if not body:
        return True
    for stmt in body:
        if isinstance(stmt, (ast.Pass, ast.Return)):
            continue
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Constant):
            continue
        return False
    return True


def _has_logging(body: list[ast.stmt]) -> bool:
    for stmt in body:
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            if _is_log_call(stmt.value):
                return True
    return False


def _is_log_call(call: ast.Call) -> bool:
    if isinstance(call.func, ast.Attribute):
        if call.func.attr in {"exception", "error", "warning"}:
            return True
    if isinstance(call.func, ast.Name):
        if call.func.id in {"exception", "error", "warning"}:
            return True
    return False


def _fingerprint(issue: Issue, exc_type: str, path: str) -> str:
    payload = {
        "code": issue.code,
        "path": path,
        "key": exc_type,
    }
    return f"sha1:{sha1_json(payload)}"
