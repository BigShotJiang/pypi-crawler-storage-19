"""Structure rules for bloatcheck."""

from __future__ import annotations

from pathlib import Path

from ..core.config import Config
from ..core.index import RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation
from ..core.util import read_text, sha1_json


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    issues.extend(_large_modules(index, config))
    issues.extend(_flat_namespace(index, config))
    return issues


def _large_modules(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    threshold = config.thresholds.large_module_lines
    for file_index in index.files:
        if not _is_source_path(file_index.rel_path, config):
            continue
        lines = len(read_text(file_index.path).splitlines())
        if lines <= threshold:
            continue
        issue = Issue(
            code="STR001",
            title="Large module",
            message=f"Module has {lines} lines (> {threshold})",
            severity="warning",
            confidence="medium",
            location=IssueLocation(path=file_index.rel_path, line=1),
            evidence=[
                Evidence(
                    kind="structure",
                    data={"lines": lines, "threshold": threshold},
                )
            ],
            tags=["structure"],
        )
        issue.fingerprint = _fingerprint(issue)
        issues.append(issue)
    return issues


def _flat_namespace(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    threshold = config.thresholds.flat_module_count
    roots = [Path(p) for p in config.src_dirs + config.extra_dirs]
    for root in roots:
        count = 0
        for file_index in index.files:
            parts = Path(file_index.rel_path).parts
            if parts[: len(root.parts)] != root.parts:
                continue
            if len(parts) == len(root.parts) + 1:
                count += 1
        if count <= threshold:
            continue
        rel = str(root) if str(root) else "src"
        issue = Issue(
            code="STR002",
            title="Flat module namespace",
            message=f"{count} top-level modules in {rel} (> {threshold})",
            severity="info",
            confidence="low",
            location=IssueLocation(path=rel, line=1),
            evidence=[
                Evidence(
                    kind="structure",
                    data={"count": count, "threshold": threshold},
                )
            ],
            tags=["structure"],
        )
        issue.fingerprint = _fingerprint(issue)
        issues.append(issue)
    return issues


def _is_source_path(rel_path: str, config: Config) -> bool:
    parts = Path(rel_path).parts
    for root in config.src_dirs + config.extra_dirs:
        root_parts = Path(root).parts
        if parts[: len(root_parts)] == root_parts:
            return True
    return False


def _fingerprint(issue: Issue) -> str:
    payload = {"code": issue.code, "path": issue.location.path}
    return f"sha1:{sha1_json(payload)}"
