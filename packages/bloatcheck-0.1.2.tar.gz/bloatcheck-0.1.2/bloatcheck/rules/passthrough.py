"""Passthrough wrapper rule."""

from __future__ import annotations

import ast

from ..core.config import Config
from ..core.index import FunctionInfo, RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation, IssueSymbol
from ..core.util import sha1_json


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    for func in index.functions:
        issue = _check_passthrough(func)
        if issue:
            issues.append(issue)
    return issues


def _check_passthrough(func: FunctionInfo) -> Issue | None:
    node = func.node
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return None

    call = _single_return_call(node)
    if call is None:
        return None

    if _has_semantics(node):
        return None

    call_args = _call_arg_names(call)
    if call_args is None:
        return None
    if call_args != _function_arg_names(node):
        return None

    called_name = _call_name(call)
    if called_name is None:
        return None

    issue = Issue(
        code="API001",
        title="Passthrough wrapper",
        message=f"{func.symbol.name} delegates directly to {called_name}",
        severity="info",
        confidence="medium",
        location=IssueLocation(path=func.symbol.path, line=func.symbol.lineno),
        symbol=IssueSymbol(qualname=func.symbol.qualname, kind=func.symbol.kind),
        evidence=[
            Evidence(
                kind="passthrough",
                data={"called": called_name, "args": list(call_args)},
            )
        ],
        tags=["api"],
    )
    issue.fingerprint = _fingerprint(issue, func.symbol, called_name)
    return issue


def _call_name(call: ast.Call) -> str | None:
    if isinstance(call.func, ast.Name):
        return call.func.id
    if isinstance(call.func, ast.Attribute):
        return call.func.attr
    return None


def _single_return_call(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> ast.Call | None:
    body = _strip_docstring(list(node.body))
    if len(body) != 1:
        return None
    stmt = body[0]
    if not isinstance(stmt, ast.Return):
        return None
    ret_val = stmt.value
    if isinstance(ret_val, ast.Await):
        ret_val = ret_val.value
    if not isinstance(ret_val, ast.Call):
        return None
    return ret_val


def _strip_docstring(body: list[ast.stmt]) -> list[ast.stmt]:
    if (
        body
        and isinstance(body[0], ast.Expr)
        and isinstance(body[0].value, ast.Constant)
        and isinstance(body[0].value.value, str)
    ):
        return body[1:]
    return body


def _function_arg_names(node: ast.FunctionDef | ast.AsyncFunctionDef) -> list[str]:
    args = [arg.arg for arg in node.args.args]
    if args and args[0] in {"self", "cls"}:
        return args[1:]
    return args


def _call_arg_names(call: ast.Call) -> list[str] | None:
    names: list[str] = []
    for arg in call.args:
        if isinstance(arg, ast.Name):
            names.append(arg.id)
        else:
            return None
    return names


def _has_semantics(node: ast.AST) -> bool:
    for child in ast.walk(node):
        if isinstance(
            child, (ast.If, ast.Try, ast.Assign, ast.AugAssign, ast.Raise, ast.Assert)
        ):
            return True
    return False


def _fingerprint(issue: Issue, symbol, called_name: str) -> str:
    payload = {
        "code": issue.code,
        "path": issue.location.path,
        "symbol": symbol.qualname,
        "key": called_name,
    }
    return f"sha1:{sha1_json(payload)}"
