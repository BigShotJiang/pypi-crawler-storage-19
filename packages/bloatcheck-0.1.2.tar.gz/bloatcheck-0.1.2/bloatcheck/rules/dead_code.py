"""Dead code rules."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..core.config import Config
from ..core.index import RepoIndex, SymbolInfo
from ..core.schema import Evidence, Issue, IssueLocation, IssueSymbol
from ..core.util import sha1_json


@dataclass(frozen=True)
class DeadCodeEvidence:
    total_hits: int
    external_hits: int
    test_only: bool
    exported: bool


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    used_names = _collect_used_names(index)

    for symbol in index.symbols:
        if not _is_source_symbol(symbol.path, config):
            continue
        if symbol.name.startswith("__") and symbol.name.endswith("__"):
            continue
        if symbol.kind == "method" and symbol.name.startswith("visit_"):
            continue
        hits = used_names.get(symbol.name, 0)
        hits = max(hits - _definition_offset(symbol, index), 0)
        external_hits = _external_hits(symbol, index)
        in_tests = _is_test_only(symbol, index, config)
        exported = _is_exported(symbol, index)

        if hits == 0 or in_tests:
            code, severity, confidence = _dead_code_meta(symbol, exported, in_tests)
            evidence = DeadCodeEvidence(
                total_hits=hits,
                external_hits=external_hits,
                test_only=in_tests,
                exported=exported,
            )
            issues.append(_issue(symbol, code, severity, confidence, evidence))

    return issues


def _collect_used_names(index: RepoIndex) -> dict[str, int]:
    counts: dict[str, int] = {}

    for file_index in index.files:
        for name, count in _canonical_counts(file_index).items():
            counts[name] = counts.get(name, 0) + count

    return counts


def _external_hits(symbol: SymbolInfo, index: RepoIndex) -> int:
    hits = 0
    for file_index in index.files:
        if file_index.rel_path == symbol.path:
            continue
        hits += _canonical_counts(file_index).get(symbol.name, 0)
    return hits


def _is_test_only(symbol: SymbolInfo, index: RepoIndex, config: Config) -> bool:
    test_hits = 0
    non_test_hits = 0
    for file_index in index.files:
        hits = _canonical_counts(file_index).get(symbol.name, 0)
        if file_index.rel_path == symbol.path:
            hits = max(hits - 1, 0)
        if hits == 0:
            continue
        if _is_test_path(file_index.rel_path, config):
            test_hits += hits
        else:
            non_test_hits += hits
    return test_hits > 0 and non_test_hits == 0


def _is_exported(symbol: SymbolInfo, index: RepoIndex) -> bool:
    file_index = index.by_path.get(symbol.path)
    if not file_index:
        return False
    return symbol.name in file_index.imports.exported_names


def _dead_code_meta(
    symbol: SymbolInfo, exported: bool, test_only: bool
) -> tuple[str, str, str]:
    if test_only:
        return "DEAD003", "info", "low"
    if symbol.name.startswith("_"):
        return "DEAD001", "warning", "high" if not exported else "medium"
    return "DEAD002", "warning", "medium" if not exported else "low"


def _issue(
    symbol: SymbolInfo,
    code: str,
    severity: str,
    confidence: str,
    evidence: DeadCodeEvidence,
) -> Issue:
    data = {
        "total_hits": evidence.total_hits,
        "external_hits": evidence.external_hits,
        "test_only": evidence.test_only,
        "exported": evidence.exported,
    }

    location = IssueLocation(path=symbol.path, line=symbol.lineno)
    issue = Issue(
        code=code,
        title="Unreferenced symbol",
        message=f"{symbol.name} appears unused",
        severity=severity,
        confidence=confidence,
        location=location,
        symbol=IssueSymbol(qualname=symbol.qualname, kind=symbol.kind),
        evidence=[Evidence(kind="dead_code", data=data)],
        tags=["dead-code"],
    )
    issue.fingerprint = _fingerprint(issue, symbol)
    return issue


def _fingerprint(issue: Issue, symbol: SymbolInfo) -> str:
    payload = {
        "code": issue.code,
        "path": issue.location.path,
        "symbol": symbol.qualname,
        "key": symbol.name,
    }
    return f"sha1:{sha1_json(payload)}"


def _definition_offset(symbol: SymbolInfo, index: RepoIndex) -> int:
    file_index = index.by_path.get(symbol.path)
    if not file_index:
        return 0
    if symbol.name in file_index.tokens.used_names:
        return 1
    return 0


def _is_test_path(rel_path: str, config: Config) -> bool:
    path_parts = tuple(Path(rel_path).parts)
    for test_dir in config.test_dirs:
        test_parts = tuple(Path(test_dir).parts)
        if path_parts[: len(test_parts)] == test_parts:
            return True
    return False


def _is_source_symbol(rel_path: str, config: Config) -> bool:
    path_parts = tuple(Path(rel_path).parts)
    for src_dir in config.src_dirs + config.extra_dirs:
        src_parts = tuple(Path(src_dir).parts)
        if path_parts[: len(src_parts)] == src_parts:
            return True
    return False


def _canonical_counts(file_index) -> dict[str, int]:
    counts: dict[str, int] = {}
    alias_map = file_index.imports.aliases
    for name, count in file_index.tokens.used_names.items():
        canonical = alias_map.get(name, name)
        counts[canonical] = counts.get(canonical, 0) + count
    return counts
