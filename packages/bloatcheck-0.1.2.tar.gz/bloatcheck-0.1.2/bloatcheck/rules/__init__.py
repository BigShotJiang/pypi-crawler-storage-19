"""Rule registry for bloatcheck."""

from __future__ import annotations

from .complexity import run as complexity
from .dead_code import run as dead_code
from .duplicates import run as duplicates
from .exceptions import run as exceptions
from .passthrough import run as passthrough
from .structure import run as structure
from .todos import run as todos


def all_rules():
    return [
        dead_code,
        duplicates,
        exceptions,
        complexity,
        todos,
        passthrough,
        structure,
    ]
