"""Complexity and size rules."""

from __future__ import annotations

import ast

from ..analysis.complexity import cyclomatic_complexity
from ..core.config import Config
from ..core.index import FunctionInfo, RepoIndex
from ..core.schema import Evidence, Issue, IssueLocation, IssueSymbol
from ..core.util import sha1_json


def run(index: RepoIndex, config: Config) -> list[Issue]:
    issues: list[Issue] = []
    for func in index.functions:
        metrics = _compute_metrics(func)
        issues.extend(_emit_metric_issues(func, metrics, config))
    return issues


def _compute_metrics(func: FunctionInfo) -> dict[str, int]:
    node = func.node
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return {}
    return {
        "length": (func.symbol.end_lineno - func.symbol.lineno + 1),
        "cyclomatic": cyclomatic_complexity(node),
        "nesting": _max_nesting(node),
        "params": _param_count(node),
    }


def _emit_metric_issues(
    func: FunctionInfo, metrics: dict[str, int], config: Config
) -> list[Issue]:
    issues: list[Issue] = []
    thresholds = config.thresholds
    mapping = {
        "length": ("LEN001", thresholds.long_function_lines, "Function too long"),
        "cyclomatic": (
            "CMP001",
            thresholds.cyclomatic_complexity,
            "High cyclomatic complexity",
        ),
        "nesting": ("DST001", thresholds.nesting_depth, "Deep nesting"),
        "params": ("SIG001", thresholds.param_count, "Too many parameters"),
    }
    for key, value in metrics.items():
        code, threshold, title = mapping[key]
        if value <= threshold:
            continue
        issue = Issue(
            code=code,
            title=title,
            message=f"{key}={value} exceeds {threshold}",
            severity="warning",
            confidence="high",
            location=IssueLocation(path=func.symbol.path, line=func.symbol.lineno),
            symbol=IssueSymbol(qualname=func.symbol.qualname, kind=func.symbol.kind),
            evidence=[
                Evidence(
                    kind="metric",
                    data={"metric": key, "value": value, "threshold": threshold},
                )
            ],
            tags=["complexity"],
        )
        issue.fingerprint = _fingerprint(issue, func.symbol, key, threshold)
        issues.append(issue)
    return issues


def _param_count(node: ast.AST) -> int:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return 0
    count = len(node.args.posonlyargs) + len(node.args.args) + len(node.args.kwonlyargs)
    if node.args.vararg is not None:
        count += 1
    if node.args.kwarg is not None:
        count += 1
    if node.args.args:
        first = node.args.args[0].arg
        if first in {"self", "cls"}:
            count -= 1
    return max(count, 0)


def _max_nesting(node: ast.AST) -> int:
    max_depth = 0
    nesting = (
        ast.If,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.With,
        ast.AsyncWith,
        ast.Try,
        ast.ExceptHandler,
    )
    stack: list[tuple[ast.AST, int]] = [(node, 0)]
    while stack:
        current, depth = stack.pop()
        if isinstance(current, nesting):
            depth += 1
            max_depth = max(max_depth, depth)
        for child in ast.iter_child_nodes(current):
            stack.append((child, depth))
    return max_depth


def _fingerprint(issue: Issue, symbol, metric: str, threshold: int) -> str:
    payload = {
        "code": issue.code,
        "path": issue.location.path,
        "symbol": symbol.qualname,
        "key": f"{metric}:{threshold}",
    }
    return f"sha1:{sha1_json(payload)}"
