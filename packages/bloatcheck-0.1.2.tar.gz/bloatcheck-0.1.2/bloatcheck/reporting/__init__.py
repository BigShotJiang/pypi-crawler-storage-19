"""Reporting components for bloatcheck."""
