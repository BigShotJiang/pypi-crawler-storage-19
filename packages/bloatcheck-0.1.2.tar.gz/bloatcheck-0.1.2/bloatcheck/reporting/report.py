"""Reporting output for bloatcheck."""

from __future__ import annotations

import json
from collections import Counter

from ..core.schema import Issue, Report
from ..metrics.base import MetricRecord


def summarize(issues: list[Issue], metrics: list[MetricRecord]) -> dict:
    severity_counts = Counter()
    status_counts = Counter()
    active_by_severity = Counter()
    for issue in issues:
        severity_counts[issue.severity] += 1
        status_counts[issue.status] += 1
        if issue.status == "active":
            active_by_severity[issue.severity] += 1

    return {
        "severity": dict(severity_counts),
        "status": dict(status_counts),
        "active_by_severity": dict(active_by_severity),
        "total": len(issues),
        "metrics": len(metrics),
    }


def build_report(issues: list[Issue], metrics: list[MetricRecord]) -> Report:
    return Report(
        issues=issues,
        metrics=[record.to_dict() for record in metrics],
        summary=summarize(issues, metrics),
    )


def render_human(
    issues: list[Issue], no_color: bool = False, top: int | None = None
) -> str:
    lines: list[str] = []
    grouped: dict[str, list[Issue]] = {}
    for issue in issues:
        grouped.setdefault(issue.code[:3], []).append(issue)

    for group in sorted(grouped):
        group_issues = grouped[group]
        lines.append(f"{group} ({len(group_issues)})")
        for issue in group_issues[: top or len(group_issues)]:
            loc = f"{issue.location.path}:{issue.location.line}"
            lines.append(
                f"[{issue.code}] {issue.severity} {issue.confidence} "
                f"{loc} {issue.message}"
            )
        lines.append("")

    summary = summarize(issues, [])
    lines.append("Summary")
    active = summary.get("active_by_severity", {})
    lines.append(
        "Active: "
        f"{summary.get('status', {}).get('active', 0)} "
        f"(error={active.get('error', 0)} "
        f"warning={active.get('warning', 0)} "
        f"info={active.get('info', 0)})"
    )
    lines.append(f"Baselined: {summary.get('status', {}).get('baselined', 0)}")
    lines.append(f"Suppressed: {summary.get('status', {}).get('suppressed', 0)}")

    return "\n".join(lines).strip()


def render_json(report: Report) -> str:
    return json.dumps(report.to_dict(), indent=2, sort_keys=True)
