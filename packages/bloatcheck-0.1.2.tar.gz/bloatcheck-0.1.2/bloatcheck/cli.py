"""CLI for bloatcheck."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core.baseline import apply_baseline, load_baseline, update_baseline
from .core.config import Config, load_config
from .core.index import RepoIndex, build_index
from .core.suppress import SuppressionIndex, build_suppression_index
from .metrics import all_metrics
from .metrics.base import MetricRecord
from .reporting.report import build_report, render_human, render_json
from .rules import all_rules


def main() -> int:
    args = _parse_args()

    repo_root = Path(args.repo_root).resolve()
    config = load_config(
        repo_root, Path(args.config).resolve() if args.config else None
    )

    index = build_index(config)
    suppressions = build_suppression_index(index)

    issues: list = []
    if not args.metrics_only:
        issues = _collect_issues(index, config)
        issues = _filter_issues(issues, args.only, args.skip)
        _apply_suppressions(issues, suppressions)

        baseline_path = _baseline_path(args.baseline, repo_root, config)
        _apply_baseline(issues, baseline_path, args.update_baseline)

    metrics = _collect_metrics(index, config, args)
    _emit_report(issues, metrics, args)
    return _exit_code(
        issues,
        args.fail_on or config.baseline.fail_on,
        baseline_mode=config.baseline.mode,
        update_baseline=args.update_baseline,
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="bloatcheck")
    parser.add_argument("--version", action="version", version=_version())
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--config")
    parser.add_argument("--json", nargs="?", const="-", default=None)
    parser.add_argument("--baseline")
    parser.add_argument("--update-baseline", action="store_true")
    parser.add_argument("--only", action="append", default=[])
    parser.add_argument("--skip", action="append", default=[])
    parser.add_argument("--fail-on", action="append", default=[])
    parser.add_argument("--top", type=int, default=50)
    parser.add_argument("--no-color", action="store_true")
    parser.add_argument("--metrics", action="store_true")
    parser.add_argument("--metrics-only", action="store_true")
    parser.add_argument("--metrics-json", nargs="?", const="-", default=None)
    return parser.parse_args()


def _version() -> str:
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("bloatcheck")
    except PackageNotFoundError:
        try:
            from . import __version__

            return __version__
        except ImportError:
            return "0.0.0"


def _collect_issues(index: RepoIndex, config: Config) -> list:
    issues = []
    for rule in all_rules():
        issues.extend(rule(index, config))
    return issues


def _collect_metrics(
    index: RepoIndex, config: Config, args: argparse.Namespace
) -> list[MetricRecord]:
    if not _should_collect_metrics(args):
        return []
    records: list[MetricRecord] = []
    for collector in all_metrics():
        records.extend(collector(index, config))
    return records


def _filter_issues(issues: list, only: list[str], skip: list[str]) -> list:
    if only:
        allowed = {code.upper() for code in only}
        issues = [issue for issue in issues if issue.code in allowed]
    if skip:
        blocked = {code.upper() for code in skip}
        issues = [issue for issue in issues if issue.code not in blocked]
    return issues


def _apply_suppressions(issues: list, suppressions: SuppressionIndex) -> None:
    for issue in issues:
        qualname = issue.symbol.qualname if issue.symbol else None
        if suppressions.is_suppressed(
            issue.code, issue.location.path, issue.location.line, qualname
        ):
            issue.status = "suppressed"


def _baseline_path(override: str | None, repo_root: Path, config: Config) -> Path:
    if override:
        return Path(override)
    return repo_root / config.baseline.path


def _apply_baseline(issues: list, baseline_path: Path, update: bool) -> None:
    baseline = load_baseline(baseline_path)
    apply_baseline(issues, baseline)
    if update:
        update_baseline(baseline_path, issues)


def _emit_report(
    issues: list, metrics: list[MetricRecord], args: argparse.Namespace
) -> None:
    report = build_report(issues, metrics)
    if args.json is not None:
        output = render_json(report)
        if args.json == "-":
            print(output)
        else:
            Path(args.json).write_text(output, encoding="utf-8")
    else:
        print(render_human(issues, no_color=args.no_color, top=args.top))

    if args.metrics_json is not None:
        payload = {"version": 1, "metrics": [record.to_dict() for record in metrics]}
        output = json.dumps(payload, indent=2, sort_keys=True)
        if args.metrics_json == "-":
            print(output)
        else:
            Path(args.metrics_json).write_text(output, encoding="utf-8")
    elif args.metrics or args.metrics_only:
        _print_metrics_summary(metrics)


def _exit_code(
    issues: list, fail_on: list[str], *, baseline_mode: str, update_baseline: bool
) -> int:
    if update_baseline:
        return 0
    severities = set(fail_on)
    for issue in issues:
        if issue.severity not in severities:
            continue
        if baseline_mode == "all":
            return 1
        if issue.status == "active":
            return 1
    return 0


def _should_collect_metrics(args: argparse.Namespace) -> bool:
    return bool(args.json or args.metrics or args.metrics_only or args.metrics_json)


def _print_metrics_summary(metrics: list[MetricRecord]) -> None:
    if not metrics:
        print("\nMetrics: none")
        return
    by_name: dict[str, int] = {}
    for record in metrics:
        by_name[record.name] = by_name.get(record.name, 0) + 1
    lines = ["", "Metrics"]
    for name in sorted(by_name):
        lines.append(f"{name}: {by_name[name]}")
    print("\n".join(lines))
