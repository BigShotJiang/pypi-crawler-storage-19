"""Configuration loading for bloatcheck."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib  # type: ignore[import-not-found]
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore[import-not-found]


@dataclass(frozen=True)
class Thresholds:
    long_function_lines: int = 50
    cyclomatic_complexity: int = 10
    nesting_depth: int = 4
    param_count: int = 5
    god_class_methods: int = 15
    large_module_lines: int = 600
    flat_module_count: int = 10
    near_duplicate_similarity: float = 0.9


@dataclass(frozen=True)
class BaselineConfig:
    path: str = "bloatcheck_baseline.json"
    mode: str = "regressions"  # or all
    fail_on: list[str] = field(default_factory=lambda: ["error"])


@dataclass(frozen=True)
class Config:
    repo_root: Path
    src_dirs: list[str] = field(default_factory=lambda: ["src"])
    test_dirs: list[str] = field(default_factory=lambda: ["tests"])
    extra_dirs: list[str] = field(default_factory=lambda: ["scripts"])
    exclude_globs: list[str] = field(
        default_factory=lambda: [
            "**/.venv/**",
            "**/__pycache__/**",
            "**/node_modules/**",
        ]
    )
    thresholds: Thresholds = Thresholds()
    baseline: BaselineConfig = BaselineConfig()

    def resolve_dirs(self, dirs: list[str]) -> list[Path]:
        resolved: list[Path] = []
        for d in dirs:
            p = (self.repo_root / d).resolve()
            if p.exists():
                resolved.append(p)
        return resolved


def _load_pyproject(path: Path) -> dict:
    if not path.exists():
        return {}
    data = tomllib.loads(path.read_text(encoding="utf-8"))
    return data.get("tool", {}).get("bloatcheck", {})


def load_config(repo_root: Path, config_path: Path | None = None) -> Config:
    config_path = config_path or (repo_root / "pyproject.toml")
    raw = _load_pyproject(config_path)

    thresholds_raw = raw.get("thresholds", {})
    baseline_raw = raw.get("baseline", {})

    thresholds = Thresholds(
        long_function_lines=int(thresholds_raw.get("long_function_lines", 50)),
        cyclomatic_complexity=int(thresholds_raw.get("cyclomatic_complexity", 10)),
        nesting_depth=int(thresholds_raw.get("nesting_depth", 4)),
        param_count=int(thresholds_raw.get("param_count", 5)),
        god_class_methods=int(thresholds_raw.get("god_class_methods", 15)),
        large_module_lines=int(thresholds_raw.get("large_module_lines", 600)),
        flat_module_count=int(thresholds_raw.get("flat_module_count", 10)),
        near_duplicate_similarity=float(
            thresholds_raw.get("near_duplicate_similarity", 0.9)
        ),
    )

    baseline = BaselineConfig(
        path=str(baseline_raw.get("path", "bloatcheck_baseline.json")),
        mode=str(baseline_raw.get("mode", "regressions")),
        fail_on=list(baseline_raw.get("fail_on", ["error"])),
    )

    return Config(
        repo_root=repo_root,
        src_dirs=list(raw.get("src_dirs", ["src"])),
        test_dirs=list(raw.get("test_dirs", ["tests"])),
        extra_dirs=list(raw.get("extra_dirs", ["scripts"])),
        exclude_globs=list(
            raw.get(
                "exclude_globs",
                ["**/.venv/**", "**/__pycache__/**", "**/node_modules/**"],
            )
        ),
        thresholds=thresholds,
        baseline=baseline,
    )
