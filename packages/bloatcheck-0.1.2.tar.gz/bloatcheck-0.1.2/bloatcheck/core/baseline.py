"""Baseline handling for bloatcheck."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .schema import Issue


@dataclass(frozen=True)
class BaselineEntry:
    fingerprint: str
    code: str
    path: str
    note: str | None = None


@dataclass(frozen=True)
class Baseline:
    version: int
    accepted: list[BaselineEntry]

    def fingerprints(self) -> set[str]:
        return {entry.fingerprint for entry in self.accepted}


def load_baseline(path: Path) -> Baseline | None:
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    accepted = [
        BaselineEntry(
            fingerprint=item.get("fingerprint", ""),
            code=item.get("code", ""),
            path=item.get("path", ""),
            note=item.get("note"),
        )
        for item in data.get("accepted", [])
        if item.get("fingerprint")
    ]
    return Baseline(version=int(data.get("version", 1)), accepted=accepted)


def apply_baseline(issues: list[Issue], baseline: Baseline | None) -> None:
    if not baseline:
        return
    fingerprints = baseline.fingerprints()
    for issue in issues:
        if issue.fingerprint in fingerprints:
            issue.status = "baselined"


def update_baseline(path: Path, issues: list[Issue]) -> None:
    payload = {
        "version": 1,
        "accepted": [
            {
                "fingerprint": issue.fingerprint,
                "code": issue.code,
                "path": issue.location.path,
            }
            for issue in issues
            if issue.status == "active"
        ],
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
