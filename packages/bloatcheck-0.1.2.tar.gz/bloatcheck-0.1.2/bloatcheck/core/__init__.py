"""Core components for bloatcheck."""
