"""Filesystem helpers for bloatcheck."""

from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path


def collect_py_files(
    repo_root: Path, roots: list[Path], exclude_globs: list[str]
) -> list[Path]:
    files: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*.py"):
            if _is_excluded(path, repo_root, exclude_globs):
                continue
            files.append(path)
    return sorted(set(files), key=lambda p: str(p))


def _is_excluded(path: Path, repo_root: Path, exclude_globs: list[str]) -> bool:
    try:
        rel_path = path.relative_to(repo_root)
    except ValueError:
        rel_path = path
    rel_str = rel_path.as_posix()
    for pattern in exclude_globs:
        if fnmatch(rel_str, pattern):
            return True
    return False
