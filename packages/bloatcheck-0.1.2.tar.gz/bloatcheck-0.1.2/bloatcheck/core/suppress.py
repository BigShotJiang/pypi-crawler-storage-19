"""Suppression directives for bloatcheck."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .index import RepoIndex


@dataclass(frozen=True)
class Suppression:
    codes: set[str]
    line: int
    reason: str | None
    target_qualname: str | None


@dataclass(frozen=True)
class FileSuppressions:
    file_codes: set[str] = field(default_factory=set)
    line_suppressions: list[Suppression] = field(default_factory=list)


@dataclass
class SuppressionIndex:
    by_path: dict[str, FileSuppressions]

    def is_suppressed(
        self, code: str, path: str, line: int, qualname: str | None
    ) -> bool:
        entry = self.by_path.get(path)
        if not entry:
            return False
        if code in entry.file_codes:
            return True
        for suppression in entry.line_suppressions:
            if code not in suppression.codes:
                continue
            if suppression.target_qualname and qualname:
                if suppression.target_qualname == qualname:
                    return True
            elif suppression.line == line:
                return True
        return False


IGNORE_RE = re.compile(
    r"#\s*audit:\s*ignore\[(?P<codes>[^\]]+)\](?:\s*reason:\s*(?P<reason>.*))?",
    re.IGNORECASE,
)
IGNORE_FILE_RE = re.compile(
    r"#\s*audit:\s*ignore-file\[(?P<codes>[^\]]+)\](?:\s*reason:\s*(?P<reason>.*))?",
    re.IGNORECASE,
)


def build_suppression_index(
    repo_index: RepoIndex, window: int = 2, file_window: int = 50
) -> SuppressionIndex:
    by_path: dict[str, FileSuppressions] = {}

    for file_index in repo_index.files:
        file_codes: set[str] = set()
        line_suppressions: list[Suppression] = []
        symbols_by_line = sorted(file_index.symbols, key=lambda s: s.lineno)

        for line, text in file_index.tokens.comments:
            file_match = IGNORE_FILE_RE.search(text)
            if file_match and line <= file_window:
                codes = _parse_codes(file_match.group("codes"))
                file_codes.update(codes)
                continue

            match = IGNORE_RE.search(text)
            if not match:
                continue

            codes = _parse_codes(match.group("codes"))
            reason = match.group("reason")
            target = _find_target_symbol(symbols_by_line, line, window)
            line_suppressions.append(
                Suppression(
                    codes=codes, line=line, reason=reason, target_qualname=target
                )
            )

        if file_codes or line_suppressions:
            by_path[file_index.rel_path] = FileSuppressions(
                file_codes=file_codes, line_suppressions=line_suppressions
            )

    return SuppressionIndex(by_path=by_path)


def _parse_codes(raw: str) -> set[str]:
    return {c.strip().upper() for c in raw.split(",") if c.strip()}


def _find_target_symbol(symbols: list, line: int, window: int) -> str | None:
    for symbol in symbols:
        if symbol.lineno >= line and symbol.lineno <= line + window:
            return symbol.qualname
    return None
