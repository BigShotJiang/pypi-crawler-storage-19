"""Schema definitions for bloatcheck reports."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class IssueLocation:
    path: str
    line: int
    column: int | None = None


@dataclass(frozen=True)
class IssueSymbol:
    qualname: str
    kind: str | None = None


@dataclass(frozen=True)
class Evidence:
    kind: str
    message: str | None = None
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class Issue:
    code: str
    title: str
    message: str
    severity: str
    confidence: str
    location: IssueLocation
    symbol: IssueSymbol | None = None
    evidence: list[Evidence] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    fingerprint: str = ""
    status: str = "active"  # active|suppressed|baselined

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "title": self.title,
            "message": self.message,
            "severity": self.severity,
            "confidence": self.confidence,
            "location": {
                "path": self.location.path,
                "line": self.location.line,
                "column": self.location.column,
            },
            "symbol": None
            if self.symbol is None
            else {"qualname": self.symbol.qualname, "kind": self.symbol.kind},
            "evidence": [
                {"kind": e.kind, "message": e.message, "data": e.data}
                for e in self.evidence
            ],
            "tags": list(self.tags),
            "fingerprint": self.fingerprint,
            "status": self.status,
        }


@dataclass
class Report:
    issues: list[Issue] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    metrics: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": 1,
            "issues": [issue.to_dict() for issue in self.issues],
            "summary": self.summary,
            "metrics": self.metrics,
        }
