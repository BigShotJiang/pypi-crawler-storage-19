"""Dependency graph helpers for bloatcheck."""

from __future__ import annotations

from ..core.config import Config
from ..core.index import RepoIndex, module_name_for_path


def module_name_map(index: RepoIndex, config: Config) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for file_index in index.files:
        module = module_name_for_path(file_index.rel_path, config)
        mapping[file_index.rel_path] = module or file_index.rel_path
    return mapping


def internal_imports(modules: set[str], internal: set[str]) -> set[str]:
    return {name for name in modules if name in internal}


def afferent_counts(
    index: RepoIndex,
    module_for_path: dict[str, str],
    internal_modules: set[str],
) -> dict[str, int]:
    afferent: dict[str, int] = {path: 0 for path in module_for_path}
    for file_index in index.files:
        imports = internal_imports(file_index.imports.modules, internal_modules)
        for path, module in module_for_path.items():
            if module in imports and path != file_index.rel_path:
                afferent[path] += 1
    return afferent
