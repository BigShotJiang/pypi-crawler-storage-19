"""Shared complexity calculations for bloatcheck."""

from __future__ import annotations

import ast


def cyclomatic_complexity(node: ast.AST) -> int:
    complexity = 1
    for child in ast.walk(node):
        complexity += _complexity_increment(child)
    return complexity


def _complexity_increment(node: ast.AST) -> int:
    if isinstance(
        node,
        (
            ast.If,
            ast.IfExp,
            ast.For,
            ast.AsyncFor,
            ast.While,
            ast.With,
            ast.AsyncWith,
        ),
    ):
        return 1
    if isinstance(node, ast.ExceptHandler):
        return 1
    if isinstance(node, ast.Assert):
        return 1
    if isinstance(node, ast.comprehension):
        return 1 + len(node.ifs)
    if isinstance(node, ast.BoolOp):
        return max(len(node.values) - 1, 0)
    return 0
