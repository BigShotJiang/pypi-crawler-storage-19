"""Analysis helpers for bloatcheck."""

from __future__ import annotations

from .complexity import cyclomatic_complexity as cyclomatic_complexity

__all__ = ["cyclomatic_complexity"]
