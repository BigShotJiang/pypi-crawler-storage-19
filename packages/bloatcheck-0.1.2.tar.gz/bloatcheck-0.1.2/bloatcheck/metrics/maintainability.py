"""Maintainability index metrics for bloatcheck."""

from __future__ import annotations

import math

from ..analysis.complexity import cyclomatic_complexity
from ..core.config import Config
from ..core.index import RepoIndex
from .base import MetricRecord
from .halstead import halstead_counts, halstead_volume
from .sloc import _sloc_for_path


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for file_index in index.files:
        sloc = _sloc_for_path(file_index.path)
        comment_ratio = sloc["comment_ratio"]
        volume = halstead_volume(halstead_counts(file_index.tree))
        cc = _file_cyclomatic(index, file_index.rel_path)
        mi = maintainability_index(
            volume,
            cc,
            int(sloc["code_lines"]),
            comment_ratio,
        )
        records.append(
            MetricRecord(
                name="maintainability",
                scope="file",
                path=file_index.rel_path,
                values={
                    "mi": round(mi, 2),
                    "volume": round(volume, 2),
                    "cyclomatic": cc,
                    "code_lines": sloc["code_lines"],
                    "comment_ratio": comment_ratio,
                },
                tags=["maintainability"],
            )
        )
    return records


def _file_cyclomatic(index: RepoIndex, rel_path: str) -> int:
    funcs = [func for func in index.functions if func.symbol.path == rel_path]
    return sum(cyclomatic_complexity(func.node) for func in funcs)


def maintainability_index(
    volume: float, cyclomatic: int, sloc: int, comment_ratio: float
) -> float:
    if sloc <= 0:
        return 100.0
    comment_weight = 50.0 * math.sin(math.sqrt(2.4 * (comment_ratio * 100.0)))
    mi = 171.0 - 5.2 * math.log(max(volume, 1.0))
    mi -= 0.23 * cyclomatic
    mi -= 16.2 * math.log(sloc)
    mi += comment_weight
    return max(0.0, min(100.0, mi))
