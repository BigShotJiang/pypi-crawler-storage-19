"""Metric helpers for bloatcheck."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class MetricRecord:
    name: str
    scope: str
    path: str
    symbol: str | None = None
    values: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "scope": self.scope,
            "path": self.path,
            "symbol": self.symbol,
            "values": self.values,
            "tags": list(self.tags),
        }
