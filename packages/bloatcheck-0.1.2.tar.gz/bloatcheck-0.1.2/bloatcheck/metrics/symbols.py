"""Per-symbol metrics for bloatcheck."""

from __future__ import annotations

from ..analysis.complexity import cyclomatic_complexity
from ..core.config import Config
from ..core.index import RepoIndex
from .base import MetricRecord
from .halstead import halstead_counts, halstead_difficulty, halstead_volume
from .maintainability import maintainability_index


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for func in index.functions:
        sloc = func.symbol.end_lineno - func.symbol.lineno + 1
        counts = halstead_counts(func.node)
        volume = halstead_volume(counts)
        difficulty = halstead_difficulty(counts)
        effort = volume * difficulty
        cc = cyclomatic_complexity(func.node)
        mi = maintainability_index(volume, cc, sloc, 0.0)
        records.append(
            MetricRecord(
                name="symbol",
                scope="function",
                path=func.symbol.path,
                symbol=func.symbol.qualname,
                values={
                    "sloc": sloc,
                    "cyclomatic": cc,
                    "halstead_volume": round(volume, 2),
                    "halstead_difficulty": round(difficulty, 2),
                    "halstead_effort": round(effort, 2),
                    "maintainability": round(mi, 2),
                },
                tags=["metrics", "function"],
            )
        )
    return records
