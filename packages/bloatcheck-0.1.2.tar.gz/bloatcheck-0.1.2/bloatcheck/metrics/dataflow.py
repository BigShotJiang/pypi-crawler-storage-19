"""Data-flow metrics for bloatcheck."""

from __future__ import annotations

import ast

from ..core.config import Config
from ..core.index import RepoIndex
from ..core.util import safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for func in index.functions:
        defs, uses, chain = _defs_uses(func.node)
        overlap = defs & uses
        records.append(
            MetricRecord(
                name="data_flow",
                scope="function",
                path=func.symbol.path,
                symbol=func.symbol.qualname,
                values={
                    "unique_defs": len(defs),
                    "unique_uses": len(uses),
                    "def_use_overlap": len(overlap),
                    "def_use_ratio": round(safe_ratio(len(overlap), len(uses)), 4),
                    "def_use_chain_avg": round(chain["avg_gap"], 2),
                    "def_use_chain_max": chain["max_gap"],
                    "def_use_chain_var": round(chain["gap_var"], 2),
                    "live_range_avg": round(chain["live_avg"], 2),
                    "live_range_max": chain["live_max"],
                },
                tags=["dataflow"],
            )
        )
    return records


def _defs_uses(node: ast.AST) -> tuple[set[str], set[str], dict[str, float | int]]:
    defs: set[str] = set()
    uses: set[str] = set()
    chain = _def_use_chain(node)

    params = _param_names(node)

    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            if isinstance(child.ctx, ast.Store) and child.id not in params:
                defs.add(child.id)
            elif isinstance(child.ctx, ast.Load) and child.id not in params:
                uses.add(child.id)
    return defs, uses, chain


def _param_names(node: ast.AST) -> set[str]:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return set()
    names = {arg.arg for arg in node.args.args + node.args.posonlyargs}
    names.update({arg.arg for arg in node.args.kwonlyargs})
    if node.args.vararg is not None:
        names.add(node.args.vararg.arg)
    if node.args.kwarg is not None:
        names.add(node.args.kwarg.arg)
    return names


def _def_use_chain(node: ast.AST) -> dict[str, float | int]:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        return {
            "avg_gap": 0.0,
            "max_gap": 0,
            "gap_var": 0.0,
            "live_avg": 0.0,
            "live_max": 0,
        }

    ordered = _ordered_names(node)
    defs_by_name, uses_by_name = _defs_uses_by_name(node, ordered)
    gaps = _def_use_gaps(defs_by_name, uses_by_name)
    live_ranges = _live_ranges(defs_by_name, uses_by_name)

    if not gaps:
        return {
            "avg_gap": 0.0,
            "max_gap": 0,
            "gap_var": 0.0,
            "live_avg": round(_avg(live_ranges), 2),
            "live_max": max(live_ranges) if live_ranges else 0,
        }
    return {
        "avg_gap": sum(gaps) / float(len(gaps)),
        "max_gap": max(gaps),
        "gap_var": _variance(gaps),
        "live_avg": round(_avg(live_ranges), 2),
        "live_max": max(live_ranges) if live_ranges else 0,
    }


def _ordered_names(node: ast.AST) -> list[tuple[str, int, int, ast.Name]]:
    ordered: list[tuple[str, int, int, ast.Name]] = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            ordered.append((child.id, child.lineno or 0, child.col_offset or 0, child))
    ordered.sort(key=lambda item: (item[1], item[2]))
    return ordered


def _defs_uses_by_name(
    node: ast.AST, ordered: list[tuple[str, int, int, ast.Name]]
) -> tuple[dict[str, list[int]], dict[str, list[int]]]:
    defs_by_name: dict[str, list[int]] = {}
    uses_by_name: dict[str, list[int]] = {}
    params = _param_names(node)
    for idx, (name, _, _, child) in enumerate(ordered):
        if name in params:
            continue
        if isinstance(child.ctx, ast.Store):
            defs_by_name.setdefault(name, []).append(idx)
        elif isinstance(child.ctx, ast.Load):
            uses_by_name.setdefault(name, []).append(idx)
    return defs_by_name, uses_by_name


def _def_use_gaps(
    defs_by_name: dict[str, list[int]],
    uses_by_name: dict[str, list[int]],
) -> list[int]:
    gaps: list[int] = []
    for name, def_positions in defs_by_name.items():
        use_positions = uses_by_name.get(name, [])
        if not use_positions:
            continue
        for dpos in def_positions:
            next_use = next((u for u in use_positions if u > dpos), None)
            if next_use is not None:
                gaps.append(next_use - dpos)
    return gaps


def _live_ranges(
    defs_by_name: dict[str, list[int]],
    uses_by_name: dict[str, list[int]],
) -> list[int]:
    ranges: list[int] = []
    for name, def_positions in defs_by_name.items():
        use_positions = uses_by_name.get(name, [])
        if not use_positions:
            continue
        start = min(def_positions)
        end = max(use_positions)
        if end > start:
            ranges.append(end - start)
    return ranges


def _avg(values: list[int]) -> float:
    if not values:
        return 0.0
    return sum(values) / float(len(values))


def _variance(values: list[int]) -> float:
    if not values:
        return 0.0
    mean = _avg(values)
    return sum((v - mean) ** 2 for v in values) / float(len(values))
