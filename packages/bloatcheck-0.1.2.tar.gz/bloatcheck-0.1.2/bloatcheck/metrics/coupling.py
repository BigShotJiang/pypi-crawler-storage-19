"""Coupling metrics for bloatcheck."""

from __future__ import annotations

from ..core.config import Config
from ..core.index import RepoIndex, module_name_for_path
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    module_names = {
        file_index.rel_path: module_name_for_path(file_index.rel_path, config)
        or file_index.rel_path
        for file_index in index.files
    }

    fan_in: dict[str, int] = {path: 0 for path in module_names}
    for file_index in index.files:
        for module in file_index.imports.modules:
            for path, name in module_names.items():
                if name == module and path != file_index.rel_path:
                    fan_in[path] += 1

    for file_index in index.files:
        fan_out = len(file_index.imports.modules)
        records.append(
            MetricRecord(
                name="coupling",
                scope="file",
                path=file_index.rel_path,
                values={
                    "fan_in": fan_in.get(file_index.rel_path, 0),
                    "fan_out": fan_out,
                },
                tags=["coupling"],
            )
        )
    return records
