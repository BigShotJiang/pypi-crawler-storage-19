"""Halstead metrics for bloatcheck."""

from __future__ import annotations

import ast
import math
from typing import cast

from ..core.config import Config
from ..core.index import RepoIndex
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for file_index in index.files:
        counts = halstead_counts(file_index.tree)
        volume = halstead_volume(counts)
        difficulty = halstead_difficulty(counts)
        effort = volume * difficulty
        records.append(
            MetricRecord(
                name="halstead",
                scope="file",
                path=file_index.rel_path,
                values={
                    **counts,
                    "volume": round(volume, 2),
                    "difficulty": round(difficulty, 2),
                    "effort": round(effort, 2),
                },
                tags=["complexity"],
            )
        )
    return records


def halstead_counts(tree: ast.AST) -> dict[str, int]:
    operator_counts: dict[str, int] = {}
    operand_counts: dict[str, int] = {}

    for node in ast.walk(tree):
        op = _operator_token(node)
        if op:
            operator_counts[op] = operator_counts.get(op, 0) + 1
        operand = _operand_token(node)
        if operand is not None:
            operand_counts[operand] = operand_counts.get(operand, 0) + 1

    n1 = len(operator_counts)
    n2 = len(operand_counts)
    N1 = sum(operator_counts.values())
    N2 = sum(operand_counts.values())
    return {"n1": n1, "n2": n2, "N1": N1, "N2": N2}


def _operator_token(node: ast.AST) -> str | None:
    handler = _OPERATOR_HANDLERS.get(type(node))
    if handler is None:
        return None
    return handler(node)


def _operand_token(node: ast.AST) -> str | None:
    handler = _OPERAND_HANDLERS.get(type(node))
    if handler is None:
        return None
    return handler(node)


def _binop_name(node: ast.AST) -> str:
    binop = cast(ast.BinOp, node)
    return type(binop.op).__name__


def _boolop_name(node: ast.AST) -> str:
    boolop = cast(ast.BoolOp, node)
    return type(boolop.op).__name__


def _unaryop_name(node: ast.AST) -> str:
    unary = cast(ast.UnaryOp, node)
    return type(unary.op).__name__


def _const_repr(node: ast.AST) -> str:
    const = cast(ast.Constant, node)
    return repr(const.value)


_OPERATOR_HANDLERS = {
    ast.BinOp: _binop_name,
    ast.BoolOp: _boolop_name,
    ast.UnaryOp: _unaryop_name,
    ast.Compare: lambda node: "Compare",
    ast.Call: lambda node: "Call",
    ast.Attribute: lambda node: "Attribute",
    ast.Subscript: lambda node: "Subscript",
    ast.Assign: lambda node: "Assign",
    ast.AnnAssign: lambda node: "AnnAssign",
    ast.AugAssign: lambda node: "AugAssign",
    ast.Return: lambda node: "Return",
}

_OPERAND_HANDLERS = {
    ast.Name: lambda node: node.id,
    ast.Constant: _const_repr,
    ast.Attribute: lambda node: node.attr,
}


def halstead_volume(counts: dict[str, int]) -> float:
    n = counts["n1"] + counts["n2"]
    N = counts["N1"] + counts["N2"]
    if n == 0 or N == 0:
        return 0.0
    return N * math.log2(n)


def halstead_difficulty(counts: dict[str, int]) -> float:
    n1 = counts["n1"]
    n2 = max(counts["n2"], 1)
    N2 = counts["N2"]
    return (n1 / 2.0) * (N2 / n2)
