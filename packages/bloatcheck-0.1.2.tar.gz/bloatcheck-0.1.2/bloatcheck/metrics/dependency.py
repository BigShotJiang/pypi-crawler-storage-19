"""Dependency graph metrics for bloatcheck."""

from __future__ import annotations

from ..analysis.dependency import afferent_counts, internal_imports, module_name_map
from ..core.config import Config
from ..core.index import RepoIndex
from ..core.util import safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    module_for_path = module_name_map(index, config)
    internal_modules = set(module_for_path.values())

    afferent = afferent_counts(index, module_for_path, internal_modules)

    for file_index in index.files:
        imports = internal_imports(file_index.imports.modules, internal_modules)
        efferent = len(imports)
        ca = afferent.get(file_index.rel_path, 0)
        instability = safe_ratio(efferent, efferent + ca)
        records.append(
            MetricRecord(
                name="dependency",
                scope="file",
                path=file_index.rel_path,
                values={
                    "afferent": ca,
                    "efferent": efferent,
                    "instability": round(instability, 4),
                },
                tags=["dependency"],
            )
        )
    return records
