"""Risk scoring metrics for bloatcheck."""

from __future__ import annotations

from ..analysis.complexity import cyclomatic_complexity
from ..analysis.dependency import afferent_counts, internal_imports, module_name_map
from ..core.config import Config
from ..core.index import RepoIndex
from ..core.util import safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    module_for_path = module_name_map(index, config)
    internal_modules = set(module_for_path.values())

    afferent = afferent_counts(index, module_for_path, internal_modules)

    for file_index in index.files:
        funcs = [
            func for func in index.functions if func.symbol.path == file_index.rel_path
        ]
        total_cc = sum(cyclomatic_complexity(func.node) for func in funcs)
        avg_cc = safe_ratio(total_cc, len(funcs))
        efferent = len(internal_imports(file_index.imports.modules, internal_modules))
        ca = afferent.get(file_index.rel_path, 0)
        instability = safe_ratio(efferent, efferent + ca)
        risk = _risk_score(avg_cc, instability, config.thresholds.cyclomatic_complexity)
        records.append(
            MetricRecord(
                name="risk",
                scope="file",
                path=file_index.rel_path,
                values={
                    "avg_cc": round(avg_cc, 2),
                    "total_cc": total_cc,
                    "instability": round(instability, 4),
                    "risk_score": round(risk, 2),
                },
                tags=["risk"],
            )
        )
    return records


def _risk_score(avg_cc: float, instability: float, cc_threshold: int) -> float:
    if cc_threshold <= 0:
        return 0.0
    cc_factor = min(avg_cc / float(cc_threshold), 1.0)
    return 100.0 * cc_factor * instability
