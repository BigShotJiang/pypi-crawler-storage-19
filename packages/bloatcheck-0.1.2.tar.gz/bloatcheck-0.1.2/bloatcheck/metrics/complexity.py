"""Complexity metrics for bloatcheck."""

from __future__ import annotations

from ..analysis.complexity import cyclomatic_complexity
from ..core.config import Config
from ..core.index import RepoIndex
from ..core.util import safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for file_index in index.files:
        functions = [
            func for func in index.functions if func.symbol.path == file_index.rel_path
        ]
        total_cc = sum(cyclomatic_complexity(func.node) for func in functions)
        avg_cc = safe_ratio(total_cc, len(functions))
        records.append(
            MetricRecord(
                name="cyclomatic",
                scope="file",
                path=file_index.rel_path,
                values={
                    "functions": len(functions),
                    "total_cc": total_cc,
                    "avg_cc": round(avg_cc, 2),
                },
                tags=["complexity"],
            )
        )
    return records
