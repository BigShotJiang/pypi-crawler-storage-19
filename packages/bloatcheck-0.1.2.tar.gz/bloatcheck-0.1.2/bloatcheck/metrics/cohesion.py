"""Cohesion metrics for bloatcheck."""

from __future__ import annotations

import ast
from collections import defaultdict

from ..core.config import Config
from ..core.index import RepoIndex, module_name_for_path
from ..core.util import safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    methods_by_class = _group_methods(index)
    class_records: list[MetricRecord] = []

    for class_path, methods in methods_by_class.items():
        attr_sets = [_attributes_used(method.node) for method in methods]
        shared_pairs = 0
        disjoint_pairs = 0

        for i in range(len(attr_sets)):
            for j in range(i + 1, len(attr_sets)):
                if attr_sets[i] & attr_sets[j]:
                    shared_pairs += 1
                else:
                    disjoint_pairs += 1

        total_pairs = shared_pairs + disjoint_pairs
        tcc = safe_ratio(shared_pairs, total_pairs)
        lcc = safe_ratio(shared_pairs, shared_pairs + disjoint_pairs)
        lcom = max(disjoint_pairs - shared_pairs, 0)
        record = MetricRecord(
            name="cohesion",
            scope="class",
            path=class_path,
            symbol=methods[0].symbol.qualname.split(":", 1)[1].split(".")[0]
            if methods
            else None,
            values={
                "methods": len(methods),
                "attributes": len({a for s in attr_sets for a in s}),
                "shared_pairs": shared_pairs,
                "disjoint_pairs": disjoint_pairs,
                "tcc": round(tcc, 4),
                "lcc": round(lcc, 4),
                "lcom": lcom,
            },
            tags=["cohesion"],
        )
        records.append(record)
        class_records.append(record)

    records.extend(_package_cohesion(class_records, config))
    return records


def _package_cohesion(
    class_records: list[MetricRecord], config: Config
) -> list[MetricRecord]:
    by_package: dict[str, list[MetricRecord]] = defaultdict(list)
    for record in class_records:
        module = module_name_for_path(record.path, config) or record.path
        package = module.split(".", 1)[0]
        by_package[package].append(record)

    records: list[MetricRecord] = []
    for package, items in by_package.items():
        methods = sum(int(r.values.get("methods", 0)) for r in items)
        shared_pairs = sum(int(r.values.get("shared_pairs", 0)) for r in items)
        disjoint_pairs = sum(int(r.values.get("disjoint_pairs", 0)) for r in items)
        total_pairs = shared_pairs + disjoint_pairs
        tcc = safe_ratio(shared_pairs, total_pairs)
        lcc = safe_ratio(shared_pairs, total_pairs)
        lcom = sum(int(r.values.get("lcom", 0)) for r in items)
        records.append(
            MetricRecord(
                name="cohesion_package",
                scope="package",
                path=package,
                values={
                    "classes": len(items),
                    "methods": methods,
                    "shared_pairs": shared_pairs,
                    "disjoint_pairs": disjoint_pairs,
                    "tcc": round(tcc, 4),
                    "lcc": round(lcc, 4),
                    "lcom_total": lcom,
                },
                tags=["cohesion", "package"],
            )
        )
    return records


def _group_methods(index: RepoIndex) -> dict[str, list]:
    grouped: dict[str, list] = defaultdict(list)
    for func in index.functions:
        if func.symbol.kind != "method":
            continue
        class_name = _class_name_from_qualname(func.symbol.qualname)
        if not class_name:
            continue
        grouped[f"{func.symbol.path}:{class_name}"].append(func)
    return grouped


def _class_name_from_qualname(qualname: str) -> str | None:
    if ":" not in qualname:
        return None
    _, remainder = qualname.split(":", 1)
    if "." not in remainder:
        return None
    return remainder.split(".", 1)[0]


def _attributes_used(node: ast.AST) -> set[str]:
    attrs: set[str] = set()

    class Visitor(ast.NodeVisitor):
        def visit_Attribute(self, attr_node: ast.Attribute) -> None:
            if isinstance(attr_node.value, ast.Name) and attr_node.value.id in {
                "self",
                "cls",
            }:
                attrs.add(attr_node.attr)
            self.generic_visit(attr_node)

    Visitor().visit(node)
    return attrs
