"""Metric registry for bloatcheck."""

from __future__ import annotations

from .cohesion import collect as cohesion
from .complexity import collect as complexity
from .coupling import collect as coupling
from .dataflow import collect as dataflow
from .dependency import collect as dependency
from .halstead import collect as halstead
from .maintainability import collect as maintainability
from .risk import collect as risk
from .sloc import collect as sloc
from .symbols import collect as symbols


def all_metrics():
    return [
        sloc,
        complexity,
        halstead,
        maintainability,
        coupling,
        dependency,
        cohesion,
        dataflow,
        risk,
        symbols,
    ]
