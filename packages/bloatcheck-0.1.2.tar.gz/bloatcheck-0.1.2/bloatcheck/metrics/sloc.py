"""SLOC and comment density metrics."""

from __future__ import annotations

from ..core.config import Config
from ..core.index import RepoIndex
from ..core.util import read_text, safe_ratio
from .base import MetricRecord


def collect(index: RepoIndex, config: Config) -> list[MetricRecord]:
    records: list[MetricRecord] = []
    for file_index in index.files:
        totals = _sloc_for_path(file_index.path)
        records.append(
            MetricRecord(
                name="sloc",
                scope="file",
                path=file_index.rel_path,
                values=totals,
                tags=["sloc", "comments"],
            )
        )
    return records


def _sloc_for_path(path) -> dict[str, int | float]:
    text = read_text(path)
    lines = text.splitlines()
    total = len(lines)
    blank = 0
    comment_only = 0
    for line in lines:
        stripped = line.strip()
        if not stripped:
            blank += 1
        elif stripped.startswith("#"):
            comment_only += 1
    code = max(total - blank - comment_only, 0)
    comment_ratio = safe_ratio(comment_only, code + comment_only)
    return {
        "total_lines": total,
        "code_lines": code,
        "comment_lines": comment_only,
        "blank_lines": blank,
        "comment_ratio": round(comment_ratio, 4),
    }
