"""Core functionality for Hangul syllable and jamo manipulation.

This module provides optimized functions for decomposing and composing Korean
Hangul syllables and jamo characters, leveraging Python 3.13+ features.
"""

from collections.abc import Iterator
from itertools import chain
from typing import NamedTuple

from .constants import (
    COMPOUND_JAMO_SET,
    COMPONENTS_TO_JAMO,
    HANGUL_BASE,
    HCJ_LEADS,
    HCJ_TAILS,
    HCJ_TO_JAMO_LEAD,
    HCJ_TO_JAMO_TAIL,
    HCJ_TO_JAMO_VOWEL,
    HCJ_VOWELS,
    JAMO_COMPOUNDS,
    JAMO_LEAD_BASE,
    JAMO_LEADS,
    JAMO_TAILS,
    JAMO_TAIL_BASE,
    JAMO_TO_HCJ,
    JAMO_VOWEL_BASE,
    JAMO_VOWELS,
    LEAD_TO_INDEX,
    NUM_SYLLABLES_PER_LEAD,
    NUM_TAIL,
    TAIL_TO_INDEX,
    VOWEL_TO_INDEX,
)


class Syllable(NamedTuple):
    """Represents a decomposed Hangul syllable.

    Attributes:
        lead: Leading consonant (초성)
        vowel: Vowel (중성)
        tail: Trailing consonant (종성), None if absent
    """

    lead: str
    vowel: str
    tail: str | None


class HangeulError(Exception):
    """Base exception for Hangeul-related errors."""


class InvalidJamoError(HangeulError):
    """Raised when invalid jamo characters are encountered."""


class InvalidSyllableError(HangeulError):
    """Raised when invalid Hangul syllables are encountered."""


# Validation functions
def is_hangul_syllable(char: str) -> bool:
    """Check if a character is a Hangul syllable (U+AC00 to U+D7A3).

    Args:
        char: A single character to check

    Returns:
        True if the character is a Hangul syllable, False otherwise

    Examples:
        >>> is_hangul_syllable('한')
        True
        >>> is_hangul_syllable('a')
        False
        >>> is_hangul_syllable('ㄱ')
        False
    """
    code = ord(char)
    return 0xAC00 <= code <= 0xD7A3


def is_jamo(char: str) -> bool:
    """Check if a character is a jamo character (U+11xx).

    Args:
        char: A single character to check

    Returns:
        True if the character is a jamo, False otherwise

    Examples:
        >>> is_jamo('ᄀ')
        True
        >>> is_jamo('ㄱ')
        False
        >>> is_jamo('한')
        False
    """
    code = ord(char)
    return (0x1100 <= code <= 0x1112) or (0x1161 <= code <= 0x1175) or (0x11A8 <= code <= 0x11C2)


def is_hcj(char: str) -> bool:
    """Check if a character is a Hangul Compatibility Jamo (U+31xx).

    Args:
        char: A single character to check

    Returns:
        True if the character is HCJ, False otherwise

    Examples:
        >>> is_hcj('ㄱ')
        True
        >>> is_hcj('ᄀ')
        False
        >>> is_hcj('한')
        False
    """
    code = ord(char)
    return (0x3131 <= code <= 0x318E) and code != 0x3164


def is_jamo_lead(char: str) -> bool:
    """Check if a character is a leading jamo consonant.

    Args:
        char: A single character to check

    Returns:
        True if the character is a leading jamo, False otherwise
    """
    return char in LEAD_TO_INDEX


def is_jamo_vowel(char: str) -> bool:
    """Check if a character is a jamo vowel.

    Args:
        char: A single character to check

    Returns:
        True if the character is a jamo vowel, False otherwise
    """
    return char in VOWEL_TO_INDEX


def is_jamo_tail(char: str) -> bool:
    """Check if a character is a trailing jamo consonant.

    Args:
        char: A single character to check

    Returns:
        True if the character is a trailing jamo, False otherwise
    """
    return char in TAIL_TO_INDEX and char is not None


def is_jamo_compound(char: str) -> bool:
    """Check if a jamo is a compound (double consonant, cluster, or diphthong).

    Args:
        char: A single character to check

    Returns:
        True if the character is a compound jamo, False otherwise

    Examples:
        >>> is_jamo_compound('ㄲ')
        True
        >>> is_jamo_compound('ㅘ')
        True
        >>> is_jamo_compound('ㄱ')
        False
    """
    return char in COMPOUND_JAMO_SET


# Decomposition functions
def decompose_syllable(syllable: str) -> Syllable:
    """Decompose a Hangul syllable into its constituent jamo (HCJ form).

    Args:
        syllable: A single Hangul syllable character

    Returns:
        A Syllable namedtuple containing lead, vowel, and tail components

    Raises:
        InvalidSyllableError: If the input is not a valid Hangul syllable

    Examples:
        >>> decompose_syllable('한')
        Syllable(lead='ㅎ', vowel='ㅏ', tail='ㄴ')
        >>> decompose_syllable('가')
        Syllable(lead='ㄱ', vowel='ㅏ', tail=None)
    """
    if not is_hangul_syllable(syllable):
        raise InvalidSyllableError(f"'{syllable}' is not a valid Hangul syllable")

    index = ord(syllable) - HANGUL_BASE

    lead_index = index // NUM_SYLLABLES_PER_LEAD
    vowel_index = (index % NUM_SYLLABLES_PER_LEAD) // NUM_TAIL
    tail_index = index % NUM_TAIL

    return Syllable(
        lead=HCJ_LEADS[lead_index],
        vowel=HCJ_VOWELS[vowel_index],
        tail=HCJ_TAILS[tail_index],
    )


def decompose_syllable_jamo(syllable: str) -> tuple[str, str, str | None]:
    """Decompose a Hangul syllable into jamo characters (U+11xx form).

    Args:
        syllable: A single Hangul syllable character

    Returns:
        A tuple of (lead, vowel, tail) in U+11xx jamo form

    Raises:
        InvalidSyllableError: If the input is not a valid Hangul syllable

    Examples:
        >>> decompose_syllable_jamo('한')
        ('ᄒ', 'ᅡ', 'ᆫ')
    """
    if not is_hangul_syllable(syllable):
        raise InvalidSyllableError(f"'{syllable}' is not a valid Hangul syllable")

    index = ord(syllable) - HANGUL_BASE

    lead_index = index // NUM_SYLLABLES_PER_LEAD
    vowel_index = (index % NUM_SYLLABLES_PER_LEAD) // NUM_TAIL
    tail_index = index % NUM_TAIL

    lead = JAMO_LEADS[lead_index]
    vowel = JAMO_VOWELS[vowel_index]
    tail = JAMO_TAILS[tail_index] if tail_index > 0 else None

    return (lead, vowel, tail)


def decompose(text: str) -> str:
    """Decompose Hangul syllables in text into HCJ jamo characters.

    This is the optimized version for HCJ (Hangul Compatibility Jamo) output.
    For U+11xx jamo output, use decompose_jamo().

    Args:
        text: Input text containing Hangul syllables

    Returns:
        Text with Hangul syllables decomposed into HCJ jamo

    Examples:
        >>> decompose('한글')
        'ㅎㅏㄴㄱㅡㄹ'
        >>> decompose('Hello 한글!')
        'Hello ㅎㅏㄴㄱㅡㄹ!'
    """
    if not text:
        return ''

    result = []
    append = result.append
    hangul_base = HANGUL_BASE
    num_per_lead = NUM_SYLLABLES_PER_LEAD
    num_tail = NUM_TAIL
    hcj_leads = HCJ_LEADS
    hcj_vowels = HCJ_VOWELS
    hcj_tails = HCJ_TAILS

    for char in text:
        code = ord(char)
        if 0xAC00 <= code <= 0xD7A3:
            index = code - hangul_base
            lead_index = index // num_per_lead
            vowel_index = (index % num_per_lead) // num_tail
            tail_index = index % num_tail

            append(hcj_leads[lead_index])
            append(hcj_vowels[vowel_index])
            if tail_index:
                append(hcj_tails[tail_index])
        else:
            append(char)

    return ''.join(result)


def decompose_jamo(text: str) -> str:
    """Decompose Hangul syllables in text into U+11xx jamo characters.

    This function outputs jamo in the U+1100-U+11FF Unicode range.
    For HCJ (Hangul Compatibility Jamo) output, use decompose().

    Args:
        text: Input text containing Hangul syllables

    Returns:
        Text with Hangul syllables decomposed into U+11xx jamo

    Examples:
        >>> decompose_jamo('한글')
        '한글'
        >>> decompose_jamo('Hello 한글!')
        'Hello 한글!'
    """
    if not text:
        return ''

    result = []
    append = result.append
    hangul_base = HANGUL_BASE
    num_per_lead = NUM_SYLLABLES_PER_LEAD
    num_tail = NUM_TAIL
    jamo_lead_base = JAMO_LEAD_BASE
    jamo_vowel_base = JAMO_VOWEL_BASE
    jamo_tail_base = JAMO_TAIL_BASE

    for char in text:
        code = ord(char)
        if 0xAC00 <= code <= 0xD7A3:
            index = code - hangul_base
            lead_index = index // num_per_lead
            vowel_index = (index % num_per_lead) // num_tail
            tail_index = index % num_tail

            append(chr(jamo_lead_base + lead_index))
            append(chr(jamo_vowel_base + vowel_index))
            if tail_index:
                append(chr(jamo_tail_base + tail_index - 1))
        else:
            append(char)

    return ''.join(result)


def decompose_compound(jamo: str) -> tuple[str, ...]:
    """Decompose a compound jamo into its components.

    Args:
        jamo: A compound jamo character (e.g., 'ㄲ', 'ㅘ')

    Returns:
        A tuple of component jamo characters

    Raises:
        InvalidJamoError: If the input is not a compound jamo

    Examples:
        >>> decompose_compound('ㄲ')
        ('ㄱ', 'ㄱ')
        >>> decompose_compound('ㅘ')
        ('ㅗ', 'ㅏ')
    """
    if jamo not in JAMO_COMPOUNDS:
        raise InvalidJamoError(f"'{jamo}' is not a compound jamo")

    return JAMO_COMPOUNDS[jamo]


# Composition functions
def compose_jamo(lead: str, vowel: str, tail: str | None = None) -> str:
    """Compose jamo characters into a Hangul syllable.

    Args:
        lead: Leading consonant (in HCJ form)
        vowel: Vowel (in HCJ form)
        tail: Trailing consonant (in HCJ form), or None

    Returns:
        A composed Hangul syllable

    Raises:
        InvalidJamoError: If the jamo characters are invalid or cannot be composed

    Examples:
        >>> compose_jamo('ㅎ', 'ㅏ', 'ㄴ')
        '한'
        >>> compose_jamo('ㄱ', 'ㅏ')
        '가'
    """
    if lead not in LEAD_TO_INDEX:
        raise InvalidJamoError(f"Invalid leading consonant: '{lead}'")
    if vowel not in VOWEL_TO_INDEX:
        raise InvalidJamoError(f"Invalid vowel: '{vowel}'")
    if tail is not None and tail not in TAIL_TO_INDEX:
        raise InvalidJamoError(f"Invalid trailing consonant: '{tail}'")

    lead_index = LEAD_TO_INDEX[lead]
    vowel_index = VOWEL_TO_INDEX[vowel]
    tail_index = TAIL_TO_INDEX[tail] if tail else 0

    syllable_index = (
        lead_index * NUM_SYLLABLES_PER_LEAD + vowel_index * NUM_TAIL + tail_index
    )

    return chr(HANGUL_BASE + syllable_index)


def compose(text: str) -> str:
    """Compose jamo characters in text into Hangul syllables.

    Uses a smart algorithm to detect valid syllable patterns and compose them.

    Args:
        text: Input text containing jamo characters

    Returns:
        Text with jamo characters composed into Hangul syllables

    Examples:
        >>> compose('ㅎㅏㄴㄱㅡㄹ')
        '한글'
        >>> compose('Hello ㅎㅏㄴㄱㅡㄹ!')
        'Hello 한글!'
    """
    if not text:
        return ''

    result: list[str] = []
    i = 0
    length = len(text)

    while i < length:
        # Try to compose a syllable starting at position i
        lead = text[i]

        # Fast path: check if we can compose
        if i + 1 < length and lead in LEAD_TO_INDEX and text[i + 1] in VOWEL_TO_INDEX:
            vowel = text[i + 1]
            tail = None
            consumed = 2

            # Check if there's a trailing consonant
            if i + 2 < length and text[i + 2] in TAIL_TO_INDEX:
                # Look ahead to see if the next character is a vowel
                # If so, the consonant should be the lead of the next syllable
                if i + 3 < length and text[i + 3] in VOWEL_TO_INDEX:
                    # Don't use the consonant as a tail
                    tail = None
                else:
                    # Use the consonant as a tail
                    tail = text[i + 2]
                    consumed = 3

            # Direct composition without validation (already checked)
            lead_index = LEAD_TO_INDEX[lead]
            vowel_index = VOWEL_TO_INDEX[vowel]
            tail_index = TAIL_TO_INDEX[tail] if tail else 0

            syllable_index = (
                lead_index * NUM_SYLLABLES_PER_LEAD + vowel_index * NUM_TAIL + tail_index
            )
            result.append(chr(HANGUL_BASE + syllable_index))
            i += consumed
        else:
            # Not a composable sequence, add as-is
            result.append(lead)
            i += 1

    return ''.join(result)


def compose_compound(components: tuple[str, ...] | list[str]) -> str:
    """Compose component jamo into a compound jamo.

    Args:
        components: A tuple or list of component jamo characters

    Returns:
        The composed compound jamo

    Raises:
        InvalidJamoError: If the components cannot be composed

    Examples:
        >>> compose_compound(('ㄱ', 'ㄱ'))
        'ㄲ'
        >>> compose_compound(['ㅗ', 'ㅏ'])
        'ㅘ'
    """
    components_tuple = tuple(components)

    if components_tuple not in COMPONENTS_TO_JAMO:
        raise InvalidJamoError(
            f"Cannot compose compound jamo from: {components_tuple}"
        )

    return COMPONENTS_TO_JAMO[components_tuple]


# Conversion functions
def jamo_to_hcj(char: str) -> str:
    """Convert a jamo character (U+11xx) to HCJ (U+31xx).

    Args:
        char: A jamo character

    Returns:
        The corresponding HCJ character, or the input if not convertible

    Examples:
        >>> jamo_to_hcj('ᄀ')
        'ㄱ'
    """
    return JAMO_TO_HCJ.get(char, char)


def hcj_to_jamo(char: str, position: str = 'vowel') -> str:
    """Convert an HCJ character to jamo (U+11xx).

    Args:
        char: An HCJ character
        position: The position context ('lead', 'vowel', or 'tail')

    Returns:
        The corresponding jamo character, or the input if not convertible

    Raises:
        InvalidJamoError: If the position is invalid

    Examples:
        >>> hcj_to_jamo('ㄱ', 'lead')
        'ᄀ'
        >>> hcj_to_jamo('ㅏ', 'vowel')
        'ᅡ'
    """
    match position:
        case 'lead':
            return HCJ_TO_JAMO_LEAD.get(char, char)
        case 'vowel':
            return HCJ_TO_JAMO_VOWEL.get(char, char)
        case 'tail':
            return HCJ_TO_JAMO_TAIL.get(char, char)
        case _:
            raise InvalidJamoError(f"Invalid position: '{position}'")


# Iterator versions for memory efficiency
def iter_decompose(text: str) -> Iterator[str]:
    """Lazily decompose Hangul syllables in text into HCJ jamo characters.

    For U+11xx jamo output, use iter_decompose_jamo().

    Args:
        text: Input text containing Hangul syllables

    Yields:
        Individual HCJ jamo characters

    Examples:
        >>> list(iter_decompose('한글'))
        ['ㅎ', 'ㅏ', 'ㄴ', 'ㄱ', 'ㅡ', 'ㄹ']
    """
    for char in text:
        if is_hangul_syllable(char):
            syllable = decompose_syllable(char)
            yield syllable.lead
            yield syllable.vowel
            if syllable.tail:
                yield syllable.tail
        else:
            yield char


def iter_decompose_jamo(text: str) -> Iterator[str]:
    """Lazily decompose Hangul syllables in text into U+11xx jamo characters.

    For HCJ output, use iter_decompose().

    Args:
        text: Input text containing Hangul syllables

    Yields:
        Individual U+11xx jamo characters

    Examples:
        >>> list(iter_decompose_jamo('한글'))
        ['ᄒ', 'ᅡ', 'ᆫ', 'ᄀ', 'ᅳ', 'ᆯ']
    """
    for char in text:
        if is_hangul_syllable(char):
            lead, vowel, tail = decompose_syllable_jamo(char)
            yield lead
            yield vowel
            if tail:
                yield tail
        else:
            yield char
