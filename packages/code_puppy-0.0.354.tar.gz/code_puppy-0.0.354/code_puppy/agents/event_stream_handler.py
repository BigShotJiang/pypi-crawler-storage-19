"""Event stream handler for processing streaming events from agent runs."""

from collections.abc import AsyncIterable
from typing import Any, Optional

from pydantic_ai import PartDeltaEvent, PartEndEvent, PartStartEvent, RunContext
from pydantic_ai.messages import (
    TextPart,
    TextPartDelta,
    ThinkingPart,
    ThinkingPartDelta,
    ToolCallPart,
    ToolCallPartDelta,
)
from rich.console import Console
from rich.markup import escape
from rich.text import Text

from code_puppy.config import get_banner_color
from code_puppy.messaging.spinner import pause_all_spinners, resume_all_spinners

# Module-level console for streaming output
# Set via set_streaming_console() to share console with spinner
_streaming_console: Optional[Console] = None


def set_streaming_console(console: Optional[Console]) -> None:
    """Set the console used for streaming output.

    This should be called with the same console used by the spinner
    to avoid Live display conflicts that cause line duplication.

    Args:
        console: The Rich console to use, or None to use a fallback.
    """
    global _streaming_console
    _streaming_console = console


def get_streaming_console() -> Console:
    """Get the console for streaming output.

    Returns the configured console or creates a fallback Console.
    """
    if _streaming_console is not None:
        return _streaming_console
    return Console()


async def event_stream_handler(
    ctx: RunContext,
    events: AsyncIterable[Any],
) -> None:
    """Handle streaming events from the agent run.

    This function processes streaming events and emits TextPart, ThinkingPart,
    and ToolCallPart content with styled banners/tokens as they stream in.

    Args:
        ctx: The run context.
        events: Async iterable of streaming events (PartStartEvent, PartDeltaEvent, etc.).
    """
    import time

    from termflow import Parser as TermflowParser
    from termflow import Renderer as TermflowRenderer

    # Use the module-level console (set via set_streaming_console)
    console = get_streaming_console()

    # Track which part indices we're currently streaming (for Text/Thinking/Tool parts)
    streaming_parts: set[int] = set()
    thinking_parts: set[int] = set()  # Track which parts are thinking (for dim style)
    text_parts: set[int] = set()  # Track which parts are text
    tool_parts: set[int] = set()  # Track which parts are tool calls
    banner_printed: set[int] = set()  # Track if banner was already printed
    token_count: dict[int, int] = {}  # Track token count per text/tool part
    did_stream_anything = False  # Track if we streamed any content

    # Termflow streaming state for text parts
    termflow_parsers: dict[int, TermflowParser] = {}
    termflow_renderers: dict[int, TermflowRenderer] = {}
    termflow_line_buffers: dict[int, str] = {}  # Buffer incomplete lines

    def _print_thinking_banner() -> None:
        """Print the THINKING banner with spinner pause and line clear."""
        nonlocal did_stream_anything

        pause_all_spinners()
        time.sleep(0.1)  # Delay to let spinner fully clear
        # Clear line and print newline before banner
        console.print(" " * 50, end="\r")
        console.print()  # Newline before banner
        # Bold banner with configurable color and lightning bolt
        thinking_color = get_banner_color("thinking")
        console.print(
            Text.from_markup(
                f"[bold white on {thinking_color}] THINKING [/bold white on {thinking_color}] [dim]\u26a1 "
            ),
            end="",
        )
        did_stream_anything = True

    def _print_response_banner() -> None:
        """Print the AGENT RESPONSE banner with spinner pause and line clear."""
        nonlocal did_stream_anything

        pause_all_spinners()
        time.sleep(0.1)  # Delay to let spinner fully clear
        # Clear line and print newline before banner
        console.print(" " * 50, end="\r")
        console.print()  # Newline before banner
        response_color = get_banner_color("agent_response")
        console.print(
            Text.from_markup(
                f"[bold white on {response_color}] AGENT RESPONSE [/bold white on {response_color}]"
            )
        )
        did_stream_anything = True

    async for event in events:
        # PartStartEvent - register the part but defer banner until content arrives
        if isinstance(event, PartStartEvent):
            part = event.part
            if isinstance(part, ThinkingPart):
                streaming_parts.add(event.index)
                thinking_parts.add(event.index)
                # If there's initial content, print banner + content now
                if part.content and part.content.strip():
                    _print_thinking_banner()
                    escaped = escape(part.content)
                    console.print(f"[dim]{escaped}[/dim]", end="")
                    banner_printed.add(event.index)
            elif isinstance(part, TextPart):
                streaming_parts.add(event.index)
                text_parts.add(event.index)
                # Initialize termflow streaming for this text part
                termflow_parsers[event.index] = TermflowParser()
                termflow_renderers[event.index] = TermflowRenderer(
                    output=console.file, width=console.width
                )
                termflow_line_buffers[event.index] = ""
                # Handle initial content if present
                if part.content and part.content.strip():
                    _print_response_banner()
                    banner_printed.add(event.index)
                    termflow_line_buffers[event.index] = part.content
            elif isinstance(part, ToolCallPart):
                streaming_parts.add(event.index)
                tool_parts.add(event.index)
                token_count[event.index] = 0  # Initialize token counter
                # Track tool name for display
                banner_printed.add(
                    event.index
                )  # Use banner_printed to track if we've shown tool info

        # PartDeltaEvent - stream the content as it arrives
        elif isinstance(event, PartDeltaEvent):
            if event.index in streaming_parts:
                delta = event.delta
                if isinstance(delta, (TextPartDelta, ThinkingPartDelta)):
                    if delta.content_delta:
                        # For text parts, stream markdown with termflow
                        if event.index in text_parts:
                            # Print banner on first content
                            if event.index not in banner_printed:
                                _print_response_banner()
                                banner_printed.add(event.index)

                            # Add content to line buffer
                            termflow_line_buffers[event.index] += delta.content_delta

                            # Process complete lines
                            parser = termflow_parsers[event.index]
                            renderer = termflow_renderers[event.index]
                            buffer = termflow_line_buffers[event.index]

                            while "\n" in buffer:
                                line, buffer = buffer.split("\n", 1)
                                events_to_render = parser.parse_line(line)
                                renderer.render_all(events_to_render)

                            termflow_line_buffers[event.index] = buffer
                        else:
                            # For thinking parts, stream immediately (dim)
                            if event.index not in banner_printed:
                                _print_thinking_banner()
                                banner_printed.add(event.index)
                            escaped = escape(delta.content_delta)
                            console.print(f"[dim]{escaped}[/dim]", end="")
                elif isinstance(delta, ToolCallPartDelta):
                    # For tool calls, count chunks received
                    token_count[event.index] += 1
                    # Get tool name if available
                    tool_name = getattr(delta, "tool_name_delta", "")
                    count = token_count[event.index]
                    # Display with tool wrench icon and tool name
                    if tool_name:
                        console.print(
                            f"  \U0001f527 Calling {tool_name}... {count} chunks   ",
                            end="\r",
                        )
                    else:
                        console.print(
                            f"  \U0001f527 Calling tool... {count} chunks   ",
                            end="\r",
                        )

        # PartEndEvent - finish the streaming with a newline
        elif isinstance(event, PartEndEvent):
            if event.index in streaming_parts:
                # For text parts, finalize termflow rendering
                if event.index in text_parts:
                    # Render any remaining buffered content
                    if event.index in termflow_parsers:
                        parser = termflow_parsers[event.index]
                        renderer = termflow_renderers[event.index]
                        remaining = termflow_line_buffers.get(event.index, "")

                        # Parse and render any remaining partial line
                        if remaining.strip():
                            events_to_render = parser.parse_line(remaining)
                            renderer.render_all(events_to_render)

                        # Finalize the parser to close any open blocks
                        final_events = parser.finalize()
                        renderer.render_all(final_events)

                        # Clean up termflow state
                        del termflow_parsers[event.index]
                        del termflow_renderers[event.index]
                        del termflow_line_buffers[event.index]
                # For tool parts, clear the chunk counter line
                elif event.index in tool_parts:
                    # Clear the chunk counter line by printing spaces and returning
                    console.print(" " * 50, end="\r")
                # For thinking parts, just print newline
                elif event.index in banner_printed:
                    console.print()  # Final newline after streaming

                # Clean up token count
                token_count.pop(event.index, None)
                # Clean up all tracking sets
                streaming_parts.discard(event.index)
                thinking_parts.discard(event.index)
                text_parts.discard(event.index)
                tool_parts.discard(event.index)
                banner_printed.discard(event.index)

                # Resume spinner if next part is NOT text/thinking/tool (avoid race condition)
                # If next part is None or handled differently, it's safe to resume
                # Note: spinner itself handles blank line before appearing
                next_kind = getattr(event, "next_part_kind", None)
                if next_kind not in ("text", "thinking", "tool-call"):
                    resume_all_spinners()

    # Spinner is resumed in PartEndEvent when appropriate (based on next_part_kind)
