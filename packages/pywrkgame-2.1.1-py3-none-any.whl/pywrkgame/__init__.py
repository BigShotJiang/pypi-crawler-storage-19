# pywrkgame/__init__.py

"""
PyWRKGame Framework

Профессиональный движок для мобильных игр на Python
Теперь с поддержкой WebGL для браузеров! (Этап 1 Roadmap)
"""

__version__ = "2.1.1"

# Основные компоненты (всегда доступны)
try:
    from .core.engine import Engine, GameConfig
    from .core.scene import Scene
    from .core.assets import assets
    from .core.wrk_parser import WRKParser
except ImportError as e:
    print(f"Warning: Core modules not available: {e}")
    # Создаем заглушки для основных классов
    class Engine:
        def __init__(self, config=None): pass
        def init(self): return self
        def run(self, scene): pass
    
    class GameConfig:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    
    class Scene:
        def update(self, dt): pass
        def render(self, renderer): pass
        def on_enter(self): pass
        def on_exit(self): pass
    
    assets = None
    WRKParser = None

# Графика (с fallback)
try:
    from .graphics.renderer import Renderer
    from .graphics.color import Colors, Color
except ImportError:
    print("Warning: Graphics modules not available")
    class Renderer:
        def clear(self, color=None): pass
        def draw_text(self, text, pos, color=None): pass
    
    class Colors:
        WHITE = (255, 255, 255, 255)
        BLACK = (0, 0, 0, 255)
        RED = (255, 0, 0, 255)
        GREEN = (0, 255, 0, 255)
        BLUE = (0, 0, 255, 255)
        DARK_BLUE = (0, 0, 128, 255)
    
    Color = Colors

# Векторы (с fallback)
try:
    from .utils.vector import Vec2, Vec3
except ImportError:
    print("Warning: Vector modules not available")
    class Vec2:
        def __init__(self, x=0, y=0):
            self.x, self.y = x, y
    
    class Vec3:
        def __init__(self, x=0, y=0, z=0):
            self.x, self.y, self.z = x, y, z

# Платформы (опционально)
try:
    from .platforms.platform_detector import PlatformDetector, Platform
except ImportError:
    print("Warning: Platform detection not available")
    PlatformDetector = None
    Platform = None

# WebGL (опционально)
try:
    from .webgl.webgl_renderer import WebGLRenderer
    from .platforms.webgl_platform import WebGLPlatform
except ImportError:
    WebGLRenderer = None
    WebGLPlatform = None

# Консоли (опционально)
try:
    from .console.console_detector import ConsoleDetector, ConsoleType
    from .console.console_renderer import ConsoleRenderer
    from .platforms.console_platform import ConsolePlatform
except ImportError:
    ConsoleDetector = None
    ConsoleType = None
    ConsoleRenderer = None
    ConsolePlatform = None

# Бенчмарки (опционально)
try:
    from .benchmarks.benchmark_runner import BenchmarkRunner, BenchmarkResult
    from .benchmarks.competitor_tests import CompetitorBenchmarks
    from .benchmarks.performance_profiler import PerformanceProfiler
except ImportError:
    BenchmarkRunner = None
    BenchmarkResult = None
    CompetitorBenchmarks = None
    PerformanceProfiler = None


def quick_start(scene_class, width=1280, height=720, title="PyWRK Game", auto_detect_platform=True):
    """
    Запуск игры одной строчкой кода.
    
    Автоматически настраивает конфиг и запускает сцену.
    Теперь с автоматическим определением платформы! (Этап 1 Roadmap)
    
    Args:
        scene_class: Класс сцены или экземпляр Scene для запуска
        width: Ширина окна (по умолчанию 1280)
        height: Высота окна (по умолчанию 720)
        title: Заголовок окна (по умолчанию "PyWRK Game")
        auto_detect_platform: Автоматически определять платформу (по умолчанию True)
    """
    config = GameConfig(
        width=width,
        height=height,
        title=title,
        show_fps=True,
        vsync=True
    )
    
    # Автоматическое определение платформы (если доступно)
    if auto_detect_platform and PlatformDetector:
        try:
            current_platform = PlatformDetector.detect_platform()
            console_type = ConsoleDetector.detect_console() if ConsoleDetector else None
            
            print(f"Detected platform: {current_platform.name}")
            if console_type and hasattr(console_type, 'name'):
                print(f"Detected console: {console_type.name}")
            
            # Здесь можно добавить специфичную логику для платформ
        except Exception as e:
            print(f"Platform detection failed: {e}")
    
    engine = Engine(config)
    
    # Пытаемся автоматически задать папку ассетов
    if assets:
        try:
            assets.set_base_path("assets")
        except:
            pass
    
    engine.init()
    
    # Если передали класс, создаем экземпляр, если объект - используем его
    scene = scene_class() if isinstance(scene_class, type) else scene_class
    
    engine.run(scene)


# Глобальный доступ к наиболее важным элементам
__all__ = [
    'Engine', 'GameConfig', 'Scene', 'assets', 
    'WRKParser', 'Renderer', 'Colors', 'Color', 
    'Vec2', 'Vec3', 'quick_start',
    # WebGL поддержка (Этап 1 Roadmap)
    'PlatformDetector', 'Platform', 'WebGLRenderer', 'WebGLPlatform',
    # Консольная поддержка (Этап 1 Roadmap)
    'ConsoleDetector', 'ConsoleType', 'ConsoleRenderer', 'ConsolePlatform',
    # Performance Benchmarking Suite (Этап 1 Roadmap)
    'BenchmarkRunner', 'BenchmarkResult', 'CompetitorBenchmarks', 'PerformanceProfiler'
]
