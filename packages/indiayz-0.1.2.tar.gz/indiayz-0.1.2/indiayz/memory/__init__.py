"""
Vector memory & search interfaces.
"""
