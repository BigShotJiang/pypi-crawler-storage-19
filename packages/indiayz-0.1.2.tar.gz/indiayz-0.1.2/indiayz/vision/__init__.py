"""
Vision & OCR interfaces.
"""
