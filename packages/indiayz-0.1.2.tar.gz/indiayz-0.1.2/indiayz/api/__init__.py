"""
FastAPI backend integration.
"""
