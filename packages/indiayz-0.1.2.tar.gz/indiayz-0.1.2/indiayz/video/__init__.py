"""
Video processing interfaces.
"""
