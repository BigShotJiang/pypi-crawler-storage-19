# Refineo AI Tools

[![npm version](https://img.shields.io/npm/v/refineo-cli)](https://www.npmjs.com/package/refineo-cli)
[![PyPI version](https://img.shields.io/pypi/v/refineo-cli)](https://pypi.org/project/refineo-cli/)

CLI and MCP tools for [Refineo](https://refineo.app) - Transform AI-generated text into natural human writing.

## Quick Start

### Node.js / TypeScript

```bash
# Using bunx (recommended)
bunx refineo-cli login

# Using npx
npx refineo-cli login

# Global install
npm i -g refineo-cli && refineo login
```

### Python

```bash
# Using uvx (recommended)
uvx refineo-cli login

# Using pipx
pipx run refineo-cli login

# Global install
pip install refineo-cli && refineo login
```

## Commands

```bash
refineo login              # Authenticate with your account
refineo logout             # Clear stored credentials
refineo stats              # Show usage statistics
refineo humanize "text"    # Humanize AI-generated text
```

### Humanize Options

```bash
refineo humanize "text" --model enhanced    # Use enhanced model (default)
refineo humanize "text" --model standard    # Use standard model
refineo humanize --file input.txt           # Read from file
refineo humanize --file input.txt --output output.txt  # Write to file
echo "text" | refineo humanize              # Read from stdin
```

## Requirements

- **Pro or Ultra subscription** - CLI/MCP access is a Pro+ feature
- Node.js 18+ (for Node CLI)
- Python 3.10+ (for Python CLI)

## Authentication

The CLI uses device code flow for secure authentication:

1. Run `refineo login`
2. A browser opens to authorize the device
3. Sign in and confirm the device code
4. Credentials are stored securely in `~/.refineo/`

## MCP Integration

Refineo provides an MCP server for integration with Claude Desktop, Cursor, and other AI assistants.

### Tools Available

| Tool | Description |
|------|-------------|
| `humanize_text` | Transform AI-generated text into natural human writing |
| `get_usage` | Check remaining quota for current billing period |

### Setup for Claude Desktop

1. First, get your access token:
   ```bash
   refineo login
   cat ~/.refineo/credentials.json  # Copy accessToken value
   ```

2. Add to Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):
   ```json
   {
     "mcpServers": {
       "refineo": {
         "url": "https://refineo.app/mcp/mcp",
         "headers": {
           "Authorization": "Bearer YOUR_ACCESS_TOKEN"
         }
       }
     }
   }
   ```

### Setup for Cursor

Add to Cursor MCP settings:

```json
{
  "mcpServers": {
    "refineo": {
      "url": "https://refineo.app/mcp/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_ACCESS_TOKEN"
      }
    }
  }
}
```

### Token Refresh

Access tokens expire after 15 minutes. For long-running MCP sessions, you may need to refresh periodically:

```bash
# Check token status
refineo stats

# Re-login if expired
refineo login
```

## Development

### Node CLI

```bash
cd node
npm install
npm run build
npm start login
```

### Python CLI

```bash
cd python
pip install -e ".[dev]"
refineo login
```

## Links

- [Refineo App](https://refineo.app)
- [Pricing](https://refineo.app/pricing)
- [Manage Connected Devices](https://refineo.app/dashboard/sessions)

## License

MIT
