"""Tests for sklearn-diagnose."""
