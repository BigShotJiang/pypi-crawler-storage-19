"""Templates for tool command."""
