"""Tests for LLM module."""
