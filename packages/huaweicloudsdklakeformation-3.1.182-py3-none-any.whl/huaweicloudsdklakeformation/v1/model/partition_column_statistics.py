# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PartitionColumnStatistics:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'column_statistics_desc': 'PartitionColumnStatisticsDescription',
        'column_statistics_objects': 'list[ColumnStatisticsObj]'
    }

    attribute_map = {
        'column_statistics_desc': 'column_statistics_desc',
        'column_statistics_objects': 'column_statistics_objects'
    }

    def __init__(self, column_statistics_desc=None, column_statistics_objects=None):
        r"""PartitionColumnStatistics

        The model defined in huaweicloud sdk

        :param column_statistics_desc: 
        :type column_statistics_desc: :class:`huaweicloudsdklakeformation.v1.PartitionColumnStatisticsDescription`
        :param column_statistics_objects: 列统计信息
        :type column_statistics_objects: list[:class:`huaweicloudsdklakeformation.v1.ColumnStatisticsObj`]
        """
        
        

        self._column_statistics_desc = None
        self._column_statistics_objects = None
        self.discriminator = None

        self.column_statistics_desc = column_statistics_desc
        self.column_statistics_objects = column_statistics_objects

    @property
    def column_statistics_desc(self):
        r"""Gets the column_statistics_desc of this PartitionColumnStatistics.

        :return: The column_statistics_desc of this PartitionColumnStatistics.
        :rtype: :class:`huaweicloudsdklakeformation.v1.PartitionColumnStatisticsDescription`
        """
        return self._column_statistics_desc

    @column_statistics_desc.setter
    def column_statistics_desc(self, column_statistics_desc):
        r"""Sets the column_statistics_desc of this PartitionColumnStatistics.

        :param column_statistics_desc: The column_statistics_desc of this PartitionColumnStatistics.
        :type column_statistics_desc: :class:`huaweicloudsdklakeformation.v1.PartitionColumnStatisticsDescription`
        """
        self._column_statistics_desc = column_statistics_desc

    @property
    def column_statistics_objects(self):
        r"""Gets the column_statistics_objects of this PartitionColumnStatistics.

        列统计信息

        :return: The column_statistics_objects of this PartitionColumnStatistics.
        :rtype: list[:class:`huaweicloudsdklakeformation.v1.ColumnStatisticsObj`]
        """
        return self._column_statistics_objects

    @column_statistics_objects.setter
    def column_statistics_objects(self, column_statistics_objects):
        r"""Sets the column_statistics_objects of this PartitionColumnStatistics.

        列统计信息

        :param column_statistics_objects: The column_statistics_objects of this PartitionColumnStatistics.
        :type column_statistics_objects: list[:class:`huaweicloudsdklakeformation.v1.ColumnStatisticsObj`]
        """
        self._column_statistics_objects = column_statistics_objects

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PartitionColumnStatistics):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
