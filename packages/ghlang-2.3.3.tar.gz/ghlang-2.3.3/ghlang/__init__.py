"""Language statistics analyzer for GitHub repositories and local files"""

__version__ = "2.3.3"
