"""Chat components."""

import streamlit as st
from typing import Dict


def escape_markdown(text: str) -> str:
    """Escape markdown special characters for user input."""
    # Only escape at start of line for headers
    lines = text.split('\n')
    escaped_lines = []
    for line in lines:
        if line.startswith('#'):
            line = '\\' + line
        escaped_lines.append(line)
    return '\n'.join(escaped_lines)


def render_message(msg: Dict[str, str], index: int):
    """Render a chat message."""
    role = msg.get("role", "user")
    content = msg.get("content", "")

    if role == "user":
        with st.chat_message("user"):
            st.code(content, language=None)
    elif role == "assistant":
        with st.chat_message("assistant"):
            st.code(content, language=None)
    elif role == "system":
        st.caption(f"System: {content}")


def render_chat_input():
    """Render chat input area."""
    return st.chat_input("Type your message...")
