"""
PyLLM Chat - Streamlit Application.

LLM chat interface with streaming responses.
"""

import streamlit as st

from pyllm.ui.state import (
    init_session_state, get_messages, add_message, set_generating, is_generating
)
from pyllm.ui.styles import apply_styles
from pyllm.ui.api import get_client
from pyllm.ui.components.chat import render_message, render_chat_input
from pyllm.ui.components.sidebar import render_sidebar


def main():
    """Main application."""
    st.set_page_config(
        page_title="PyLLM Chat",
        page_icon="P",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    apply_styles()
    init_session_state()

    # Sidebar
    settings = render_sidebar()

    # Main content
    st.title("PyLLM Chat")

    # Display existing messages
    messages = get_messages()
    for i, msg in enumerate(messages):
        render_message(msg, i)

    # Chat input
    user_message = render_chat_input()

    if user_message:
        # Reset generating state at start (in case it got stuck)
        set_generating(False)

        # Add user message
        add_message("user", user_message)
        with st.chat_message("user"):
            st.code(user_message, language=None)

        # Build messages for API
        api_messages = []

        if settings["system_prompt"]:
            api_messages.append({
                "role": "system",
                "content": settings["system_prompt"]
            })

        for msg in get_messages():
            api_messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })

        # Stream response
        with st.chat_message("assistant"):
            client = get_client()
            response_tokens = []
            response_placeholder = st.empty()

            try:
                for token in client.chat_stream(
                    api_messages,
                    temperature=settings["temperature"],
                    max_tokens=settings["max_tokens"],
                ):
                    response_tokens.append(token)
                    response_placeholder.code("".join(response_tokens), language=None)

                response = "".join(response_tokens)
                if response:
                    add_message("assistant", response)
            except Exception as e:
                response_placeholder.error(f"Error: {e}")

        st.rerun()


if __name__ == "__main__":
    main()
