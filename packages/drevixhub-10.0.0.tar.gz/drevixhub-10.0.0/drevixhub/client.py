import requests
import time

class DrevixReceiver:
    def __init__(self, bot_token):
        # الرابط ثابت ومحمي داخل المكتبة لضمان عدم التلاعب
        self.db_url = "https://test-e7f1b-default-rtdb.firebaseio.com"
        self.bot_token = bot_token

    def send_reply(self, user_id, message, owner_token):
        """
        إرسال الرد: المكتبة لا تسمح بالكتابة إلا في مسار المحادثة الخاص بالبوت فقط.
        """
        msg_id = f"msg_bot_{int(time.time()*1000)}"
        # المسار محمي ومحدد داخل المكتبة
        url = f"{self.db_url}/chat_rooms/{self.bot_token}/{user_id}/{msg_id}.json?auth={owner_token}"
        
        data = {
            "msg": message,
            "sender": "bot", # يتم فرضه من المكتبة لمنع انتحال الشخصية
            "timestamp": int(time.time() * 1000),
            "type": "text"
        }
        try:
            res = requests.put(url, json=data)
            return res.status_code == 200
        except:
            return False

    def listen(self, owner_token, callback):
        """
        وظيفة الاستقبال فقط: المكتبة تراقب الرسائل الواردة بصفة 'user' وتمررها للمطور
        """
        print(f"📡 Drevix Gate Active | Monitoring: {self.bot_token}")
        # لضمان عدم تكرار الرسائل القديمة عند التشغيل
        last_processed_time = int(time.time() * 1000)
        
        while True:
            try:
                # الوصول فقط لمجلد البوت المحدد
                target_url = f"{self.db_url}/chat_rooms/{self.bot_token}.json?auth={owner_token}"
                res = requests.get(target_url)
                
                if res.status_code == 200 and res.json():
                    all_chats = res.json()
                    for user_id, messages in all_chats.items():
                        for m_id, m_data in messages.items():
                            m_time = int(m_data.get('timestamp', 0))
                            # فلتر الحماية: استقبال رسائل المستخدمين الجدد فقط
                            if m_data.get('sender') == 'user' and m_time > last_processed_time:
                                callback(user_id, m_data.get('msg'))
                                last_processed_time = m_time
            except Exception as e:
                pass # تجاهل أخطاء الشبكة المؤقتة لضمان استمرار البوت
            
            time.sleep(2) # فحص كل ثانيتين لتقليل الضغط على السيرفر
