from setuptools import setup, find_packages

setup(
    name="drevixhub",
    version="10.0.0",
    packages=find_packages(),
    install_requires=["requests"],
    author="Drevix Dev",
    description="Secure Receiver-Only Bridge for Drevix Bots",
    long_description="A library that acts as a secure gate for receiving and replying to messages only.",
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
