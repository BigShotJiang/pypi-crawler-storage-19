"""Onyx Protocol test suite"""
