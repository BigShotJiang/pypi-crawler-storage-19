"""YFinance MCP Server - AI-friendly financial data tools."""

__version__ = "0.1.1"
