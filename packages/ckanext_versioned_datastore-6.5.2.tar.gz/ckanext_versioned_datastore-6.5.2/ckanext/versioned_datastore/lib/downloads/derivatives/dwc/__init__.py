from .generator import DwcDerivativeGenerator
