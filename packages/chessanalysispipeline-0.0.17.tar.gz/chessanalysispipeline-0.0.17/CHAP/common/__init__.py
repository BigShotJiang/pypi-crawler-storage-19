"""This subpackage of `CHAP` contains `PipelineItem`\ s that are or can
be used in workflows for processing data from multiple different X-ray
techniques.
"""

from CHAP.common.processor import (
#    AnimationProcessor,
    AsyncProcessor,
    BinarizeProcessor,
    ConvertStructuredProcessor,
    ImageProcessor,
    MapProcessor,
    MPICollectProcessor,
    MPIMapProcessor,
    MPISpawnMapProcessor,
    NexusToNumpyProcessor,
#    NexusToTiffsprocessor,
    NexusToXarrayProcessor,
    NormalizeNexusProcessor,
    NormalizeMapProcessor,
    PrintProcessor,
    PyfaiAzimuthalIntegrationProcessor,
    RawDetectorDataMapProcessor,
    SetupNXdataProcessor,
    UpdateNXvalueProcessor,
    UpdateNXdataProcessor,
    UnstructuredToStructuredProcessor,
    NXdataToDataPointsProcessor,
    XarrayToNexusProcessor,
    XarrayToNumpyProcessor,
#    SumProcessor,
)
from CHAP.common.reader import (
    BinaryFileReader,
    ConfigReader,
    FabioImageReader,
    H5Reader,
    LinkamReader,
    NexusReader,
    NXdataReader,
    NXfieldReader,
    SpecReader,
    URLReader,
    YAMLReader,
)
from CHAP.common.writer import (
    ExtractArchiveWriter,
    FileTreeWriter,
    H5Writer,
    ImageWriter,
    MatplotlibAnimationWriter,
    MatplotlibFigureWriter,
    NexusWriter,
    PyfaiResultsWriter,
    YAMLWriter,
    TXTWriter,
)
