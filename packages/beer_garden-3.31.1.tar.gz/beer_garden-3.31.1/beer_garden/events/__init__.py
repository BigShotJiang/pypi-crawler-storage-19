# -*- coding: utf-8 -*-
import asyncio
import logging
import traceback
from datetime import datetime, timezone
from functools import partial

import elasticapm
import wrapt
from brewtils.models import Event, Events

from beer_garden import config as config
from beer_garden.api import accepted_forwarding_events
from beer_garden.metrics import CollectMetrics, extract_custom_context

# In this master process this should be an instance of EventManager, and in entry points
# it should be an instance of EntryPointManager
manager = None

logger = logging.getLogger(__name__)


def publish(event: Event) -> None:
    """Convenience method for publishing events

    All this does is place the event on the queue for the process-wide manager to pick
    up and process.

    Args:
        event: The event to publish

    Returns:
        None
    """

    with CollectMetrics(
        "Publish_Event", f"PUBLISHER::{event.garden}::{event.name}::publish()"
    ):
        try:
            # Do some formatting / tweaking
            if not event.garden:
                event.garden = config.get("garden.name")
            if not event.timestamp:
                event.timestamp = datetime.now(timezone.utc)

            if config.get("metrics.elastic.enabled"):
                extract_custom_context(event)
                if hasattr(event, "metadata") and "_trace_parent" not in event.metadata:
                    trace_parent_string = elasticapm.get_trace_parent_header()
                    if trace_parent_string:
                        event.metadata["_trace_parent"] = trace_parent_string

            if (
                event.garden
                and event.garden != config.get("garden.name")
                and event.name not in accepted_forwarding_events
            ):
                return

            return manager.put(event)
        except Exception as ex:
            logger.exception(f"Error publishing event: {ex}")


def publish_event(event_type: Events):
    """Decorator that will result in an event being published

    This will attempt to publish an event regardless of whether the underlying function
    raised or completed normally.

    If the wrapped function raises the exception will be re-raised.

    The event publishing *itself* will not raise anything. Any exceptions generated
    during publishing will be logged as such, but WILL NOT BE RAISED.

    Args:
        event_type: The Event type

    Raises:
        Any: If the underlying function raised an exception it will be re-raised

    Returns:
        Any: The wrapped function result
    """

    @wrapt.decorator
    def wrapper(wrapped, _, args, kwargs):
        with CollectMetrics(
            "Publish_Event", f"PUBLISHER::{event_type.name}::{wrapped.__name__}()"
        ):
            # Allows for conditionally disabling publishing
            _publish_success = kwargs.pop("_publish_success", True)
            _publish_error = kwargs.pop("_publish_error", True)

            event = Event(name=event_type.name)

            try:

                result = wrapped(*args, **kwargs)

                event.payload_type = result.__class__.__name__
                event.payload = result
                if config.get("metrics.elastic.enabled"):
                    extract_custom_context(result)
                    trace_parent_string = elasticapm.get_trace_parent_header()
                    if trace_parent_string:
                        event.metadata["_trace_parent"] = trace_parent_string

                return result
            except Exception as ex:

                event.error = True

                # Generate Traceback information
                tbe = traceback.TracebackException.from_exception(ex)
                stack_frames = traceback.extract_stack()
                tbe.stack.extend(stack_frames)
                formatted_traceback = "".join(tbe.format())

                # Replicate function call
                args_str = ", ".join(str(arg) for arg in args)
                kwargs_str = ", ".join(f"{key}={kwargs[key]!r}" for key in kwargs)

                function_called = (
                    f"{wrapped.__name__}({args_str}{', ' if args else ''}{kwargs_str})"
                )

                event.error_message = (
                    f"{function_called}\nGenerated Error:\n{str(formatted_traceback)}"
                )

                raise
            finally:
                if (not event.error and _publish_success) or (
                    event.error and _publish_error
                ):
                    publish(event)

    return wrapper


def publish_event_async(event_type: Events):
    """Decorator that will result in an event being published

    This will attempt to publish an event regardless of whether the underlying function
    raised or completed normally.

    If the wrapped function raises the exception will be re-raised.

    The event publishing *itself* will not raise anything. Any exceptions generated
    during publishing will be logged as such, but WILL NOT BE RAISED.

    Args:
        event_type: The Event type

    Raises:
        Any: If the underlying function raised an exception it will be re-raised

    Returns:
        Any: The wrapped function result
    """

    @wrapt.decorator
    def wrapper(wrapped, _, args, kwargs):
        task = asyncio.ensure_future(wrapped(*args, **kwargs))
        task.add_done_callback(partial(_async_callback, event_type=event_type))

        return task

    return wrapper


def _async_callback(task, event_type=None):
    event = Event(name=event_type.name)

    try:
        result = task.result()

        event.payload_type = result.__class__.__name__
        event.payload = result
    except Exception as ex:
        event.error = True
        event.error_message = str(ex)
    finally:
        try:
            publish(event)
        except Exception as ex:
            logger.exception(f"Error publishing event: {ex}")
