def QVX_License():return """
# Qarvexium SOFTWARE LICENSE AGREEMENT (2025)

---

## TABLE OF CONTENTS

1. Definitions  
2. Grant of License  
3. Permitted Uses  
4. Prohibitions  
5. Third-Party Dependencies  
6. Attribution & Trademark  
7. Warranty, Title & Risk  
8. Limitation of Liability  
9. Indemnification  
10. Termination & Conditional Protection Revocation  
11. Chain-Protection, Propagation & Enforcement  
12. Audits & Compliance Certification  
13. Data Privacy & Security Obligations  
14. Export Controls & Legal Compliance  
15. High-Risk Use & Safety-Critical Systems  
16. Severability & Reformation  
17. Governing Law & Dispute Resolution  
18. Notices  
19. Signature

---

## 1. DEFINITIONS

1.1 **“Software”**  
All components provided by Qarvexium, including binary and source code, libraries, scripts, configuration files, build artifacts, examples, documentation, installers, containers, APIs, and related materials.

1.2 **“Licensee” / “You”**  
The individual or legal entity granted rights under this Agreement.

1.3 **“Private Use”**  
Use strictly within Licensee’s organization by employees or contractors authorized under confidentiality obligations, on devices and infrastructure controlled by Licensee. Private Use excludes any third-party distribution, remote public access, or exposure to external users.

1.4 **“Public Use”**  
Any use that exposes the Software to third parties — including distribution, embedding into public products or services, cloud hosting, container images, API endpoints, repositories, or any publicly accessible system.

1.5 **“Modification”**  
Any alteration, adaptation, translation, patching, compilation, obfuscation, reverse-engineering, decompilation, disassembly, or other change to the Software, and any creation of Derivative Works by any means (including manual, automated, or AI-assisted methods).

1.6 **“Derivative Work” / “Derivative Program”**  
Any work that incorporates or is based upon the Software in whole or in part, including subsequent programs, libraries, modules, services, or outputs that depend upon, are generated from, or are built using the Software or any Derivative Program at any depth of derivation.

1.7 **“Immediate Creator” / “Immediate User”**  
The natural person or legal entity that directly produced, deployed, or distributed a Program or Derivative Program.

1.8 **“Malicious Use”**  
Any use that is intended to or reasonably expected to: (a) damage, disrupt, or compromise systems, networks, data, services, or devices; (b) create malware, ransomware, spyware, exploits, botnets, or similar harmful software; (c) facilitate unauthorized access to systems or data; (d) facilitate fraud, phishing, harassment, or invasion of privacy; or (e) otherwise violate applicable law or accepted security practices.

1.9 **“Protected Chain”**  
The hierarchical tree of Derivative Programs originating from Qarvexium Software where each layer propagates protective and restrictive obligations downstream and receives conditional liability protection upstream.

---

## 2. GRANT OF LICENSE

2.1 **License Grant.** Subject to full compliance with this Agreement, Qarvexium grants Licensee a non-exclusive, worldwide, royalty-free, revocable license to:  
  a. Install, execute, and use the Software on Licensee-controlled devices;  
  b. Embed unmodified Software into Licensee Programs provided the full license text (this Agreement) is attached and propagated as required by Section 11;  
  c. Distribute the Software in object (binary) form only, with required attribution and license propagation;  
  d. Create Derivative Programs only in accordance with this Agreement and only if the Derivative Program enforces the obligations in Sections 3–6 and 11.

2.2 **Reserved Rights.** All rights not expressly granted are reserved by Qarvexium.

2.3 **Revocability.** The license is revocable by Qarvexium under the terms of Sections 10 and 11.

---

## 3. PERMITTED USES

3.1 **Personal & Internal Use.** Use for personal, educational, research, development, testing, and internal business purposes is permitted so long as Licensee enforces the obligations and propagation requirements set forth in Section 11.

3.2 **Commercial & Public Use.** Public or commercial deployment is permitted only when Licensee: (a) includes required attribution (Section 6); (b) attaches the full license to distributed artifacts; (c) enforces Malicious Use prohibitions on all downstream users; and (d) complies with Third-Party Dependencies (Section 5) and Export Controls (Section 14).

3.3 **Cloud / Container / SaaS / AI Use.** Use in cloud, containerized, hosted, or AI-assisted environments is permitted under the same obligations. Licensee is responsible for access control, security, attribution, and license propagation for hosted endpoints and images.

---

## 4. PROHIBITIONS

4.1 **No Unauthorized Modification.** Licensee shall not modify, adapt, or create Derivative Works of the Software except as expressly permitted in writing by Qarvexium or as expressly allowed by law (and only for interoperability if legally required). Any permitted Modification must still comply with propagation and anti-malware rules.

4.2 **No Reverse Engineering for Circumvention.** Reverse-engineering, decompilation, disassembly, or other attempts to discover or bypass licensing, security, or attribution mechanisms are prohibited. Reverse-engineering allowed by mandatory law must not be used to evade any license obligation.

4.3 **No Malicious Use.** Use of the Software to create, test, distribute, or facilitate malware, ransomware, exploits, automated attacks, or other Malicious Use is strictly prohibited. **Any Program or Derivative Program that is used to create or distribute malicious software immediately loses all protections under this Agreement (see Section 10).**

4.4 **No Unauthorized Redistribution.** Licensee may not sell, lease, sublicense, or otherwise distribute the Software as a standalone product except under terms that fully propagate this Agreement and achieve chain protection as defined in Section 11.

4.5 **No Circumvention.** Hiding, obfuscating, or otherwise attempting to evade any obligation of this Agreement (including attribution, propagation, auditing, or conditional protection) is prohibited.

4.6 **No Use to Violate Law.** The Software shall not be used to commit unlawful acts or to assist others in doing so.

---

## 5. THIRD-PARTY DEPENDENCIES

5.1 **Acknowledgement & Compliance.** The Software may include or rely upon third-party components subject to separate licenses. Licensee must comply with those terms. Noncompliance constitutes a material breach of this Agreement.

5.2 **Notice Requirement.** When distributing Derivative Programs, Licensee must include or reference all applicable third-party license notices and attributions required by those components.

---

## 6. ATTRIBUTION & TRADEMARK

6.1 **Attribution Required.** For any Public Use or distribution, Licensee must include the following attribution in a prominent place (e.g., UI footer, About page, product documentation, or README):  
> “This product uses software developed by Qarvexium © 2025.”

6.2 **Trademark Use.** Use of the Qarvexium® name or logo is permitted only to accurately identify origin and must not imply endorsement. Any use suggesting endorsement requires prior written permission and compliance with Qarvexium’s trademark guidelines.

6.3 **Propagation of Attribution.** Attribution must propagate with any distributed Derivative Program and be included in any End-User License Agreement (EULA) or terms presented to downstream users.

---

## 7. WARRANTY, TITLE & RISK

7.1 **As-Is.** The Software is provided “as is,” “as available,” without warranties of any kind, express or implied, including merchantability, fitness for a particular purpose, or non-infringement.

7.2 **Title.** Qarvexium represents that it has the rights necessary to license the Software.

7.3 **User Responsibility.** Licensee is solely responsible for determining suitability of the Software for Licensee’s purposes and for compliance with applicable law.

7.4 **Data Protection.** If the Software processes personal data, Licensee is responsible for compliance with applicable data protection laws (e.g., GDPR, CCPA) and for obtaining any necessary consents or legal bases.

7.5 **No Monitoring.** Qarvexium does not undertake proactive monitoring of Licensee’s use. Malicious acts or misuse are the sole responsibility of the Immediate Creator(s) as provided in Sections 9–11.

---

## 8. LIMITATION OF LIABILITY

8.1 **Cap on Liability.** To the maximum extent permitted by law, Qarvexium’s total aggregate liability under this Agreement shall not exceed USD $0. Where applicable law prohibits full exclusion of liability, the minimum liability permitted by such law applies.

8.2 **Excluded Damages.** In no event shall Qarvexium be liable for indirect, incidental, special, consequential, punitive, or exemplary damages, including lost profits, loss of business, or loss of data.

8.3 **Third-Party & Downstream Harm.** Qarvexium is not liable for any harm caused by Derivative Programs or by actions of downstream users.

---

## 9. INDEMNIFICATION

9.1 **By Licensee.** Licensee shall indemnify, defend and hold Qarvexium and its officers, directors, employees and agents harmless from and against all claims, liabilities, damages, losses and expenses (including reasonable attorneys’ fees) arising from:  
  a. Licensee’s use, distribution, or deployment of the Software or any Derivative Program;  
  b. Any breach by Licensee of this Agreement (including failure to propagate and enforce Sections 3–6 and 11);  
  c. Any Malicious Use by Licensee or by any downstream user of Licensee’s Derivative Program.

9.2 **Chain Indemnity.** Each Immediate Creator of a Derivative Program agrees to indemnify upstream authors and Qarvexium for claims arising from actions of their downstream users where the downstream actions arise from the Immediate Creator’s violation or failure to enforce the license obligations.

---

## 10. TERMINATION & CONDITIONAL PROTECTION REVOCATION

10.1 **Automatic Termination for Breach.** Licensee’s rights terminate automatically upon any material breach of this Agreement (including Malicious Use). Termination does not affect any accrued rights or obligations.

10.2 **Conditional Protection Revocation.** If any Program or Derivative Program is used, directly or indirectly, to create or distribute malicious software or otherwise engage in Malicious Use:  
  a. That Program and its Immediate Creator(s) lose all protections granted by this Agreement immediately;  
  b. All downstream Derivative Programs that are derived from the violating Program (at any depth) also lose protection automatically;  
  c. Any distribution, hosting, or sale of such violating Programs or their derivatives is a material breach and subjects the Immediate Creator to legal and equitable remedies, including injunctive relief and damages.

10.3 **Notice & Cure.** For non-Malicious breaches, Qarvexium may deliver written notice specifying the breach and a reasonable cure period (if feasible). For Malicious Use, no cure period is required and protection revocation is immediate.

10.4 **Obligations on Termination.** Upon termination or revocation of protection, Licensee must:  
  a. Immediately cease all use of the Software and affected Derivative Programs;  
  b. Delete and destroy all copies, distributions, containers, and artifacts containing the Software or Derivative Programs under Licensee’s control;  
  c. Provide written certification of deletion and cessation within seven (7) days of request.

10.5 **Public Notice of Revocation.** Qarvexium may publicly declare that a Program and its derivatives are no longer protected, and Licensee must include a clear visible notice in any affected program UI, documentation, or distribution channels indicating loss of Qarvexium protection.

---

## 11. CHAIN-PROTECTION, PROPAGATION & ENFORCEMENT

11.1 **Propagation Requirement.** Every Derivative Program must include the full text of this Agreement (or an unalterable machine-readable reference to it) and must present a terms notice to immediate downstream users that includes: (a) the Malicious Use prohibitions; (b) required attribution; (c) the liability and indemnity provisions; and (d) the conditional protection rules (Section 10).

11.2 **Downstream Enforcement.** Each Immediate Creator must contractually bind their downstream users to the same obligations and propagation requirements. Licensee must implement reasonable technical and administrative controls to enforce restrictions (e.g., EULA acceptance, API keys with terms, package manifest warnings).

11.3 **Protection While Compliant.** Upstream developers (including Qarvexium and any non-violating Immediate Creator) are protected from liability for wrongful acts of downstream users **so long as** they have:  
  a. Complied with propagation obligations;  
  b. Notified downstream users of prohibitions and liability allocations; and  
  c. Taken reasonable steps to respond to known violations (e.g., revocation of keys, takedown requests).

11.4 **Effective Depth & Unlimited Chain.** These propagation and protection rules apply at unlimited depth: any Program distributed within the Protected Chain must continue the propagation obligations to preserve protection for upstream participants.

11.5 **Exception for Authorized Security Research.** If Licensee wishes to perform security research that could produce potentially harmful outputs, Licensee must obtain prior written authorization from Qarvexium and comply with mutually agreed safe-harbor procedures. Unauthorized security research that results in Malicious Use is a Material Breach.

11.6 **Status Disclosure.** Any Program that loses protection per Section 10 must clearly and conspicuously disclose its unprotected status to all downstream users and distribution channels.

---

## 12. AUDITS & COMPLIANCE CERTIFICATION

12.1 **Audit Rights.** Qarvexium (or its designated agent) may, with reasonable notice except where Malicious Use is suspected, audit Licensee’s compliance with this Agreement (including deployed cloud images, container registries, artifact repositories, and distribution manifests). Licensee must cooperate and provide access to records reasonably required.

12.2 **Certification.** Licensee must provide written certification of compliance (format provided by Qarvexium) on reasonable request, including confirmation that: (a) the license text is propagated; (b) attribution is present; (c) measures are in place to prevent Malicious Use.

12.3 **Remedies.** Failure to cooperate with audits or to provide certification constitutes a material breach and may result in revocation consistent with Section 10.

---

## 13. DATA PRIVACY & SECURITY OBLIGATIONS

13.1 **No Automatic Data Collection.** Qarvexium does not automatically collect data from Licensee by reason of distribution of the Software.

13.2 **Licensee Responsibilities.** Licensee is responsible for securely handling keys, credentials, and user data. Licensee must implement reasonable administrative, physical, and technical safeguards consistent with industry standards.

13.3 **Breach Notification.** Licensee must notify Qarvexium within seventy-two (72) hours of discovering a security incident or personal data breach affecting the Software or Derivative Programs.

---

## 14. EXPORT CONTROLS & LEGAL COMPLIANCE

14.1 **Export Compliance.** Licensee shall comply with all applicable export control and sanctions laws and regulations. Licensee shall not export, re-export or transfer the Software to prohibited persons, entities, or locations.

14.2 **Legal Compliance.** Licensee must comply with all applicable laws and regulations in its use of the Software.

---

## 15. SAFETY-CRITICAL SYSTEMS

15.1 **Not Designed For High-Risk Use.** The Software is not designed or certified for safety-critical or similarly high-risk systems. Do not use the Software in these environments.
---

## 16. SEVERABILITY & REFORMATION

16.1 **Severability.** If any provision is held invalid or unenforceable, the remainder of this Agreement remains in effect. The parties shall negotiate in good faith to replace any invalid provision by a valid provision that most closely approximates the economic intent of the invalid provision.

---

## 17. GOVERNING LAW & DISPUTE RESOLUTION

17.1 **Governing Law.** This Agreement shall be governed by and construed in accordance with the laws of Switzerland, excluding its conflicts-of-law rules, except where mandatory provisions of another jurisdiction apply.

17.2 **Arbitration.** Except for injunctive relief and urgent equitable remedies, disputes arising out of this Agreement shall be finally resolved by binding arbitration administered by the International Chamber of Commerce (ICC) in English. The seat of arbitration shall be a neutral location agreed by the parties; absent agreement, the seat shall be Geneva, Switzerland.

17.3 **Injunctive Relief.** Qarvexium may seek injunctive or other equitable relief in competent courts of any jurisdiction to restrain breaches (including Malicious Use) and to enforce takedowns or revocation notices.

---

## 18. NOTICES

18.1 **Notices.** Any legal notices required under this Agreement shall be in writing and sent to the addresses provided by the parties. Electronic notice (email) is effective if receipt is confirmed or not denied within 48 hours.

---

## 19. SIGNATURE

By using, distributing, embedding, or otherwise employing the Software or any Derivative Program, Licensee accepts and agrees to all terms of this Agreement.

---

Qarvexium All rights reserved ©

---
**End Of License**
---

**EXAMPLE: PROTECTION FLOW (ASCII GRAPH)**

```
Qarvexium
   |
  / \\-------------------\\
  |           |           |
ProgramA   ProgramB   ProgramC  (if any becomes "Harmful", it loses protection)
  |           |         |
  |           |         \\-> ProgramC6 (HARMFUL)  --> ProgramC7, ProgramC8 (also lose protection)
  |           |
ProgramA1  ProgramB1
```

---

# Qarvexium Developer Checklist

Use this checklist when building or distributing Derivative Programs to ensure you preserve chain protection and comply with Qarvexium license obligations.

1. **Include LICENSE**: Ensure the full `Qarvexium SOFTWARE LICENSE AGREEMENT (2026)` is bundled with any distributed artifact (binary, container image, package).
2. **Attribution**: Display attribution prominently (UI footer, About page, README) with the required statement.
3. **EULA/Terms for End Users**: Present an End-User License Agreement or Terms that require acceptance before use; include Malicious Use prohibitions and liability allocations.
4. **Manifest Flag**: Add a machine-readable flag in package manifests (e.g., `license_attached: true` and `Qarvexium_license_version: "2026"`).
5. **API Keys & Access Controls**: If distributing hosted endpoints or SDKs, require API keys or access tokens tied to acceptance of terms; provide revocation mechanisms.
6. **Audit Trail**: Keep records of distributions, recipient organizations, and proof of license propagation for audits.
7. **Security Measures**: Implement reasonable security controls (input validation, rate limiting, access control) to reduce misuse risk.
8. **Incident Response**: Have a plan to respond to reports of abuse (takedown, revoke keys, notify Qarvexium if required).
9. **Third-Party Notices**: Bundle or reference any third-party licenses included in your artifact.
10. **Certification**: On request, be prepared to provide a signed compliance certificate to Qarvexium.

---

# End-User License Agreement (EULA) — [Your Product Name]

**Effective Date:** [Insert Date]  
**Product:** [Your Product Name]  
**Provider:** [Your Company Name]

## 1. Acceptance
By installing, copying, or using this product, you agree to be bound by this EULA and by the Qarvexium Software License Agreement (2025). You must read both agreements before use.

## 2. Prohibited Uses
You may not use this product to create, distribute, test, or facilitate malware, ransomware, exploits, or any other malicious or illegal software. Such use constitutes a material breach and may result in legal action.

## 3. Attribution
This product includes software developed by Qarvexium. The following attribution must be displayed in a prominent location within the product:  
"This product uses software developed by Qarvexium © 2025."

## 4. Liability
You are solely responsible for your actions and any harm caused by software you create or distribute using this product. Upstream developers are not liable for your malicious acts if they have complied with license propagation and enforcement obligations.

## 5. Termination
Your rights under this EULA terminate immediately upon breach, including Malicious Use. Upon termination you must cease use and delete all copies of the product.

## 6. Governing Law
This EULA is governed by the Qarvexium Software License Agreement and the governing law and dispute resolution provisions therein.

## 7. Acceptance
[ ] I accept the EULA and the Qarvexium Software License Agreement (2025).

---
"""

"Go try out SyloraQ too! https://pypi.org/project/SyloraQ/"

import platform,os
if not (platform.platform().startswith("Windows")):os._exit(0);print("Qarvexium is for Windows only.")

import subprocess,time;import ctypes;from ctypes import c_int, c_char_p, c_ubyte,c_uint32, create_string_buffer, CFUNCTYPE;from collections import deque;from typing import Callable, List, Tuple;KeyEventCallback = CFUNCTYPE(None, c_int, c_ubyte, c_char_p);from pathlib import Path;import re,inspect;from typing import Callable, Any, Dict, List, Optional, Tuple;from datetime import datetime, time, sys


class OCR:
    def __init__(self, exe_path: str | Path = f"{os.path.dirname(os.path.abspath(__file__))}/extras/ocr_tool.exe"):
        self.exe_path = Path(exe_path)
        if not self.exe_path.exists():raise FileNotFoundError(f"OCR executable not found: {self.exe_path}")

    def run(self,image: str | Path | None = None,*,gpu=False,detail=False,min_confidence=0.0,timeout=None):
        cmd = [str(self.exe_path)]
        if image is not None:cmd.append(str(image))
        if gpu:cmd.append("--gpu")
        if detail:cmd.append("--detail")
        if min_confidence > 0:cmd += ["--min-confidence", str(min_confidence)]
        op = subprocess.run(cmd,capture_output=True,text=True,timeout=timeout).stdout.strip()
        return op

class Klap:
    def __init__(self, dll_path: str | Path = f"{os.path.dirname(os.path.abspath(__file__))}/dlls/Klap.dll"):
        if not os.path.exists(dll_path):raise FileNotFoundError(f"Could not find {dll_path}")
        self.dll = ctypes.CDLL(dll_path);self.dll.KlapConnect.argtypes = [];self.dll.KlapConnect.restype = c_int;self.dll.KlapDisconnect.argtypes = [];self.dll.KlapDisconnect.restype = None;self.dll.KlapSetCallback.argtypes = [KeyEventCallback];self.dll.KlapSetCallback.restype = None;self.dll.KlapStart.argtypes = [];self.dll.KlapStart.restype = c_int;self.dll.KlapStop.argtypes = [];self.dll.KlapStop.restype = None;self.dll.KlapIsConnected.argtypes = [];self.dll.KlapIsConnected.restype = c_int;self._callback_ref = None;self._keypress_handlers = {};self._pattern_handlers = [];self._combo_handlers = [];self._raw_callback = None;self._pressed_keys = set();self._pattern_buffer = deque(maxlen=20);self._setup_internal_callback();self.Klap_pid = None
    def _setup_internal_callback(self):
        def internal_callback(pressed, mods, key_name_ptr):
            key_name = key_name_ptr.decode('utf-8')
            if pressed:self._pressed_keys.add(key_name)
            else:self._pressed_keys.discard(key_name)
            self._pattern_buffer.append(('down' if pressed else 'up', key_name))
            if self._raw_callback:self._raw_callback(pressed, mods, key_name)
            if pressed and key_name in self._keypress_handlers:
                for callback in self._keypress_handlers[key_name]:callback(key_name)
            self._check_combos();self._check_patterns()
        self._callback_ref = KeyEventCallback(internal_callback);self.dll.KlapSetCallback(self._callback_ref)
    def _check_combos(self):
        for keys_set, callback in self._combo_handlers:
            if keys_set.issubset(self._pressed_keys):callback(list(keys_set))
    def _check_patterns(self):
        for pattern, callback in self._pattern_handlers:
            if len(self._pattern_buffer) < len(pattern):continue
            recent = list(self._pattern_buffer)[-len(pattern):];matches = True
            for i, (expected_action, expected_key) in enumerate(pattern):
                actual_action, actual_key = recent[i]
                if expected_action != actual_action:matches = False;break
                if expected_key is not None and expected_key.lower() != actual_key.lower():matches = False;break
            if matches:callback();self._pattern_buffer.clear()
    def run_Klap(self, exe_path: str | Path):self.Klap_proc = subprocess.Popen(str(Path(exe_path)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    def stop_Klap(self):
        if self.Klap_proc and self.Klap_proc.poll() is None:
            self.Klap_proc.terminate()
            try:self.Klap_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:self.Klap_proc.kill();self.Klap_proc.wait()
            finally:self.Klap_proc = None
    def on_keypress(self, key: str, callback: Callable[[str], None]):
        key = key.upper()
        if key not in self._keypress_handlers:self._keypress_handlers[key] = []
        self._keypress_handlers[key].append(callback)
    def on_pattern(self, pattern: List[Tuple[str, str]], callback: Callable[[], None]):
        normalized = []
        for action, key in pattern:action = action.lower();key_normalized = key.upper() if key else None;normalized.append((action, key_normalized))
        self._pattern_handlers.append((normalized, callback))
    def on_combo(self, keys: List[str], callback: Callable[[List[str]], None]):keys_set = set(k.upper() for k in keys);self._combo_handlers.append((keys_set, callback))
    def set_raw_callback(self, callback: Callable[[int, int, str], None]):self._raw_callback = callback
    def connect(self):return self.dll.KlapConnect() == 1
    def disconnect(self):self.dll.KlapDisconnect()
    def start(self):return self.dll.KlapStart() == 1
    def stop(self):self.dll.KlapStop()
    def is_connected(self):return self.dll.KlapIsConnected() == 1
    def __enter__(self):return self
    def __exit__(self):self.stop();self.disconnect()

class Findify:
    def __init__(self, dll_path: str | Path = f"{os.path.dirname(os.path.abspath(__file__))}/dlls/Findify.dll"):dll_path = os.path.abspath(dll_path);self._dll = ctypes.CDLL(dll_path);self._dll.findify.argtypes = (ctypes.c_char_p,);self._dll.findify.restype = ctypes.c_char_p
    def find(self, filename: str) -> str | None:
        result = self._dll.findify(filename.encode("mbcs"))
        if not result:return None
        return result.decode("mbcs")

class Intent:
    def __init__(self):
        class IntentMatcher:
            def __init__(self):self.patterns = [];self.debug = False
            def register(self, pattern: str, func: Callable, description: str = None, confirm: bool = False):param_names = self._extract_parameters(func);compiled_pattern = self._compile_pattern(pattern, param_names);self.patterns.append({"pattern": pattern,"regex": compiled_pattern,"function": func,"description": description or func.__doc__ or pattern,"params": param_names,"confirm": confirm});return func
            def _extract_parameters(self, func: Callable) -> Dict[str, type]:
                sig = inspect.signature(func);params = {}
                for name, param in sig.parameters.items():param_type = param.annotation if param.annotation != inspect.Parameter.empty else str;params[name] = param_type
                return params
            def _compile_pattern(self, pattern: str, params: Dict[str, type]) -> re.Pattern:
                regex_pattern = re.escape(pattern)
                for param_name, param_type in params.items():
                    placeholder = f"<{param_name}>"
                    if param_type == int:type_pattern = r"(\d+)"
                    elif param_type == float:type_pattern = r"(\d+\.?\d*)"
                    elif param_type == datetime:type_pattern = r"(\d{4}-\d{2}-\d{2})"
                    elif param_type == time:type_pattern = r"(\d{1,2}:\d{2})"
                    else: type_pattern = r"(.+)"
                    regex_pattern = regex_pattern.replace(re.escape(placeholder), type_pattern)
                return re.compile(regex_pattern, re.IGNORECASE)
            def parse(self, command: str) -> Optional[Tuple[Callable, Dict[str, Any], Dict]]:
                for entry in self.patterns:
                    match = entry["regex"].fullmatch(command.strip())
                    if match:
                        params = {}
                        param_names = list(entry["params"].keys())
                        for i, value in enumerate(match.groups()):
                            if i < len(param_names):
                                param_name = param_names[i]
                                param_type = entry["params"][param_name]
                                try:
                                    if param_type == int:params[param_name] = int(value)
                                    elif param_type == float:params[param_name] = float(value)
                                    elif param_type == datetime:params[param_name] = datetime.strptime(value, "%Y-%m-%d")
                                    elif param_type == time:hour, minute = value.split(":");params[param_name] = time(int(hour), int(minute))
                                    else:params[param_name] = value
                                except:params[param_name] = value
                        return entry["function"], params, entry
                return None
            def execute(self, command: str, auto_confirm: bool = False) -> Any:
                result = self.parse(command)
                if result is None:
                    available = self._fuzzy_match(command)
                    if available:
                        print(f"❌ Unknown command. Did you mean one of these?")
                        for pattern in available[:3]:print(f"   • {pattern}")
                    else:print(f"❌ Unknown command: '{command}'");print(f"💡 Try: intent.help() to see available commands")
                    return None
                func, params, entry = result
                if entry["confirm"] and not auto_confirm:
                    print(f"⚠️  About to execute: {entry['pattern']}")
                    if params:print(f"   Parameters: {params}")
                    confirm = input("   Continue? (y/n): ")
                    if confirm.lower() != 'y':print("❌ Cancelled");return None
                try:
                    if self.debug:print(f"🔍 Executing: {func.__name__}({params})")
                    result = func(**params)
                    if self.debug:print(f"✅ Result: {result}")
                    return result
                except Exception as e:
                    print(f"❌ Error executing command: {str(e)}")
                    if self.debug:import traceback;traceback.print_exc()
                    return None
            def _fuzzy_match(self, command: str, threshold: int = 3) -> List[str]:
                matches = [];command_words = set(command.lower().split())
                for entry in self.patterns:
                    pattern_words = set(entry["pattern"].lower().split());common = len(command_words & pattern_words)
                    if common >= threshold:matches.append(entry["pattern"])
                return matches
            def help(self, filter_term: str = None):
                print("\n" + "=" * 60);print("INTENT - Available Commands");print("=" * 60 + "\n")
                for entry in self.patterns:
                    if filter_term and filter_term.lower() not in entry["pattern"].lower():continue
                    pattern = entry["pattern"];description = entry["description"]
                    print(f"📌 {pattern}")
                    if description != pattern:print(f"   {description}")
                    if entry["params"]:params_str = ", ".join(f"{k}: {v.__name__}" for k, v in entry["params"].items());print(f"   Parameters: {params_str}")
                    if entry["confirm"]:print(f"   ⚠️  Requires confirmation")
                    print()
            def debug_mode(self, enabled: bool = True):self.debug = enabled
        self.matcher = IntentMatcher()
    def register(self, pattern: str, func: Callable = None, description: str = None, confirm: bool = False):
        if func is None:
            def decorator(f):return self.matcher.register(pattern, f, description, confirm)
            return decorator
        else:return self.matcher.register(pattern, func, description, confirm)
    def __call__(self, command: str, auto_confirm: bool = False) -> Any:return self.matcher.execute(command, auto_confirm)
    def help(self, filter_term: str = None):self.matcher.help(filter_term)
    def debug_mode(self, enabled: bool = True):self.matcher.debug_mode(enabled)
    def parse(self, command: str) -> Optional[Tuple[Callable, Dict[str, Any]]]:
        result = self.matcher.parse(command)
        if result:return result[0], result[1]
        return None

class Environment:
    def __init__(self):self._info = self._detect_all()
    def _detect_all(self) -> Dict:return {"env": self._detect_environment(),"docker": self._is_docker(),"virtualenv": self._is_virtualenv(),"os": platform.system(),"os_version": platform.version(),"python_version": platform.python_version(),"architecture": platform.machine(),"hostname": platform.node(),"is_production": self._is_production(),"is_development": self._is_development(),"is_testing": self._is_testing()}
    def _detect_environment(self) -> str:
        env = os.getenv("ENV", os.getenv("ENVIRONMENT", "")).lower()
        
        if env in ["prod", "production"]:return "production"
        elif env in ["dev", "development"]:return "development"
        elif env in ["test", "testing"]:return "testing"
        elif env in ["stage", "staging"]:return "staging"
        if os.getenv("CI") or os.getenv("GITHUB_ACTIONS"):return "ci"
        return "development"
    def _is_docker(self) -> bool:
        if os.path.exists("/.dockerenv"):return True
        try:
            with open("/proc/1/cgroup", "r") as f:return "docker" in f.read()
        except:pass
        finally:return False
    def _is_virtualenv(self) -> bool:return hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)
    def _is_production(self) -> bool:return self._detect_environment() == "production"
    def _is_development(self) -> bool:return self._detect_environment() == "development"
    def _is_testing(self) -> bool:return self._detect_environment() in ["testing", "ci"]
    @property
    def env(self) -> str:return self._info["env"]
    @property
    def is_docker(self) -> bool:return self._info["docker"]
    @property
    def is_virtualenv(self) -> bool:return self._info["virtualenv"]
    @property
    def os(self) -> str:return self._info["os"]
    @property
    def python_version(self) -> str:return self._info["python_version"]
    @property
    def is_production(self) -> bool:return self._info["is_production"]
    @property
    def is_development(self) -> bool:return self._info["is_development"]
    @property
    def is_testing(self) -> bool:return self._info["is_testing"]
    def info(self) -> Dict:return self._info.copy()
