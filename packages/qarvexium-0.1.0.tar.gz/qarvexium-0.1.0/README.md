━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# ❗ 𝗜𝗠𝗣𝗢𝗥𝗧𝗔𝗡𝗧 𝗡𝗢𝗧𝗜𝗖𝗘

**Your use of this Software in any form constitutes your acceptance of this Agreement.**

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

---

>>pip install Qarvexium
>>>Run this so u can use the library. 

```bash
pip install Qarvexium
```

