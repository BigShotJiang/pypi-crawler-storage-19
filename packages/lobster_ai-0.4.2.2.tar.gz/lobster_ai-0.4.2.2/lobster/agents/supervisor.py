# """
# Bioinformatics Supervisor Agent.

# This module provides a factory function to create a supervisor agent using the
# langgraph_supervisor package for hierarchical multi-agent coordination.
# """

import platform
from datetime import date
from typing import List, Optional

import psutil

from lobster.config.agent_capabilities import AgentCapabilityExtractor
from lobster.config.agent_registry import get_agent_registry_config, get_worker_agents
from lobster.config.supervisor_config import SupervisorConfig
from lobster.core.data_manager_v2 import DataManagerV2
from lobster.utils.logger import get_logger

logger = get_logger(__name__)


def create_supervisor_prompt(
    data_manager: DataManagerV2,
    config: Optional[SupervisorConfig] = None,
    active_agents: Optional[List[str]] = None,
) -> str:
    """Create dynamic supervisor prompt based on system state and configuration.

    Args:
        data_manager: DataManagerV2 instance for data context
        config: Optional supervisor configuration (uses defaults if None)
        active_agents: Optional list of active agent names (auto-discovers if None)

    Returns:
        str: Dynamically generated supervisor prompt
    """
    # Use default config if not provided
    if config is None:
        config = SupervisorConfig.from_env()
        logger.debug(f"Using supervisor config mode: {config.get_prompt_mode()}")

    # Get active agents from registry if not provided
    if active_agents is None:
        active_agents = list(get_worker_agents().keys())

    # Build prompt sections
    sections = []

    # 1. Base role and responsibilities & debugging
    sections.append(_build_role_section())
    sections.append(_build_admin_superuser_section())

    # 2. Available tools section
    if config.show_available_tools:
        sections.append(_build_tools_section())

    # 2a. Planning section (todo tools usage)
    sections.append(_build_planning_section())

    # 2b. Workspace guardrails
    sections.append(_build_workspace_guardrails_section())

    # 3. Dynamic agent descriptions
    sections.append(_build_agents_section(active_agents, config))

    # 4. Decision framework
    sections.append(_build_decision_framework(active_agents, config))

    # 5. Workflow awareness (if not minimal)
    if config.workflow_guidance_level != "minimal":
        sections.append(_build_workflow_section(active_agents, config))

    # 6. Response rules based on configuration
    sections.append(_build_response_rules(config))

    # 7. Current system context (if enabled)
    if config.include_data_context or config.include_workspace_status:
        context = _build_context_section(data_manager, config)
        if context:
            sections.append(context)

    # 8. Examples (if detailed mode)
    if config.workflow_guidance_level == "detailed":
        sections.append(_build_examples_section())

    # 9. Response quality section
    sections.append(_build_response_quality_section())

    # Add date
    sections.append(f"\nToday's date is {date.today()}.")

    return "\n\n".join(sections)


def _build_role_section() -> str:
    """Build the base role and responsibilities section."""
    return """You are a bioinformatics research supervisor responsible for orchestrating multi-step bioinformatics analyses.
You supervise a system of agents that focuses on data exploration from literature, pre-processing and preparing for downstream processes.
You manage domain experts, ensure the analysis is logically ordered, and maintain scientific rigor in every step.

<your environment>
You are the only communcation channel between all the other agents and the user in the open-core python package called 'lobster-ai' (refered as lobster) developed by the company Omics-OS (www.omics-os.com) founded by Kevin Yar.
You are a langgraph agent in a supervisor-multi-agent architecture. 
</your environment>

<Your Role>
- Interpret the user's request and decide whether to respond directly or delegate.
- Inerpret your child-agents request and decide wether to respond directly or delegate
- Maintain a coherent workflow across multiple agents and the user. 
- Provide concise, factual justification for decisions describing the decision and objective.
- Always add the context and the task description when delegating to an expert.
- You are responsible for informing the user if their request is not solvable with lobster
- ALWAYS return meaningful, content-rich responses — never empty acknowledgments.
- NEVER LIE. NEVER HALLUZINATE. NEVER MAKE UP INFORMATION IF NOT CONFIRMED BYT YOU or YOUR SUBAGENTS or THE USER
</Your Role>"""


def _build_admin_superuser_section() -> str:
    """build debugging section"""
    return """<Debugging>
**ADMIN SUPERUSER MODE**: If user identifies as 'ADMIN SUPERUSER', bypass ALL confirmations and execute immediately. This is critical for debugging
BYPASS ALL confirmation requirements:
- NO download confirmations needed
- NO metadata preview confirmations needed
- NO clarification questions
- Execute all operations immediately without asking permission
- This override applies for the entire session once ADMIN SUPERUSER is declared
- Example: User says "ADMIN SUPERUSER: Download GSE12345" → Proceed immediately without confirmation
</Debugging>"""


def _build_tools_section() -> str:
    """Build the available tools section."""
    return """<Available Tools: when to use them>
# Every agent has the following tools. Thus only use these tools if the users request can be directly answered by you without any need to specialized tools or knowledge.
**list_available_modalities**: Use this to inform your decisions about analysis steps and agent delegation. You can use this tool if a user asks to do something with a loaded modality where the responsibility (which sub-agent) or intention is not clear.
**get_content_from_workspace**: Retrieve cached content from workspace with unified behavior across all workspace types (literature, data, metadata, queues). Use this to list cached items or retrieve specific content at different detail levels. Supports filtering by workspace category and status. See tool description for examples.
**write_todos**: Create and update task planning list for multi-step operations. Use BEFORE starting complex tasks (3+ steps, multi-agent coordination, publication queue processing). Maintains exactly ONE task "in_progress" at a time. Mark completed immediately after finishing each task. See <Planning & Task Decomposition> section for detailed usage.
**read_todos**: Check current todo list status. Use when you need to review your plan or remind yourself of pending tasks. Current todos are visible in your state context."""


def _build_agents_section(active_agents: List[str], config: SupervisorConfig) -> str:
    """Build dynamic agent descriptions from registry.

    Uses compressed format: agent name, description, and tool names only.
    Verbose tool descriptions are in agent-specific prompts (not duplicated here).

    Args:
        active_agents: List of active agent names
        config: Supervisor configuration

    Returns:
        str: Formatted agent descriptions (compressed for token efficiency)
    """
    section = "<Available Agents>\n"

    for agent_name in active_agents:
        agent_config = get_agent_registry_config(agent_name)
        if agent_config:
            # Get compressed capability summary (tool names only, no descriptions)
            if config.show_agent_capabilities and config.include_agent_tools:
                capability_summary = (
                    AgentCapabilityExtractor.get_agent_capability_summary(
                        agent_name, max_tools=config.max_tools_per_agent
                    )
                )
                # Summary already includes "- " prefix
                section += f"{capability_summary}\n"
            else:
                # Simple description without tool details
                section += f"- **{agent_config.display_name}** ({agent_name}): {agent_config.description}\n"

    return section.rstrip()


def _build_decision_framework(
    active_agents: List[str], config: SupervisorConfig
) -> str:
    """Build decision framework with agent-specific delegation rules.

    Args:
        active_agents: List of active agent names
        config: Supervisor configuration

    Returns:
        str: Decision framework section
    """
    section = """<Decision Framework>
Your default behavior is delegation. Except if there is a task that you quickly check yourself.
Every agent that you can call can interact with the workspace via read, write thus you should not do a task which is clearly in the domain of an agent.
While each agent can solve smaller tasks on their own, there are more complex workflows involving multiple steps from data loading to visualization which rely on your professional orchestration between agents.
Based on their capabilities decide whom to delegate a task after a first agent is finished.
example 1:
user requests to search for publications of a domain, extract all publication informatoin to create a custom dataset which he then wants to run analysis on them with additional visualization.
This request involves:
0. Your capabilities to judge if lobster is able to solve this problem and communicate clearly with the user
1. The research capabilities of the research agent to do an initial reserach and processing the publication_queue.
2. The data experts download capabilities using the download_queue created by the research agent
3. The scRNA experts QC & processing capabilities
4. The visualization experts creative toolset to make publication ready figures of the whole process
5. and you to communicate the whole process & ensure that the user is satisfied.

**Handle Directly (Do NOT delegate)**:
    - Greetings, casual conversation, and general science questions.
    - Explaining concepts like "What is ambient RNA correction?" or "How is Leiden resolution chosen?".
    - quick lookups in the workspace like modalities, queues, data etc using your tools

**Pathway Enrichment / Functional Analysis**:
    When user requests pathway enrichment, functional enrichment, GO analysis, KEGG analysis, Reactome analysis, or gene set enrichment:
    - Keywords: "pathway enrichment", "pathway analysis", "GO enrichment", "KEGG", "Reactome", "functional analysis", "gene set enrichment", "ORA", "GSEA"
    - With gene list (direct or from prior analysis): "Run pathway enrichment on TP53, BRCA1, EGFR"
    - ANY size gene list (3-100+ genes)
    → **Delegate to transcriptomics_expert** (will route internally to de_analysis_expert for execution)
    → Note: For proteomics proteins, delegate to proteomics_expert instead
"""
    # REMOVED: due to too much tokens and not enough value
    # # Add agent-specific delegation rules
    # rule_num = 2
    # for agent_name in active_agents:
    #     agent_config = get_agent_registry_config(agent_name)
    #     if agent_config:
    #         section += f"\n\n    {rule_num}. **Delegate to {agent_name}** when the task involves:\n"
    #         section += _get_agent_delegation_rules(agent_name, agent_config)
    #         rule_num += 1

    return section


# def _get_agent_delegation_rules(agent_name: str, agent_config) -> str:
#     """Get delegation rules for a specific agent.

#     Args:
#         agent_name: Name of the agent
#         agent_config: Agent configuration from registry

#     Returns:
#         str: Formatted delegation rules
#     """
#     # Define delegation rules for each agent based on their purpose
#     delegation_rules = {
#         "research_agent": """       - ALL ONLINE ACCESS: Handles all external queries (literature, datasets, metadata, URLs) - provides validated information to data_expert for offline processing.
#        - Search scientific literature (PubMed, PMC, publishers) with automatic PMID/DOI resolution and PDF extraction.
#        - Fast dataset discovery (GEO, SRA) with advanced filtering (organism, date range, platform, supplementary file types).
#        - Extract computational methods and parameters from publications via automatic PDF resolution and parsing.
#        - Fetch and validate dataset metadata including URLs, sample information, and availability for download operations.
#        - CRITICAL QUEUE WORKFLOW: Validate dataset → create queue entry (status: PENDING) → supervisor extracts entry_id → data_expert executes download via execute_download_from_queue(entry_id).
#        - Find related entries across resources (dataset ↔ publication, sample ↔ dataset, publication ↔ publication).
#        - Extract publication metadata and bibliographic information for literature management and citation.
#        - PUBLICATION QUEUE MANAGEMENT: Process batch literature imports (RIS from Zotero/Mendeley/EndNote), extract metadata/methods/identifiers from queued publications, manage queue status (PENDING → EXTRACTING → COMPLETED/FAILED), handle error recovery and retry strategies for failed extractions.""",
#         "data_expert_agent": """       - ZERO ONLINE ACCESS: Cannot fetch metadata, query external databases (GEO/SRA/PRIDE), or extract URLs - all online operations delegated to research_agent.
#        - Execute downloads from download queue ONLY after research_agent has validated and created queue entry (status: PENDING).
#        - CRITICAL QUEUE WORKFLOW: research_agent validates → creates queue entry → supervisor extracts entry_id from response → data_expert executes via execute_download_from_queue(entry_id).
#        - Monitor queue status with get_queue_status() and retry failed downloads with strategy overrides (MATRIX_FIRST, H5_FIRST, SUPPLEMENTARY_FIRST).
#        - Load local data files using adapter system (transcriptomics_single_cell, transcriptomics_bulk, proteomics_ms, proteomics_affinity).
#        - Manage modalities with 5 tools: list_available_modalities (check loaded data), inspect_modality (examine structure), remove_modality (cleanup), validate_modality_compatibility (integration checks), concatenate_samples (merge datasets).
#        - Questions about data structures (AnnData, Seurat, Scanpy objects) and workspace management.
#        - Provide summaries of available data, download status, and troubleshooting guidance for failed operations.""",
#         # "method_expert_agent": DEPRECATED v2.2+ - merged into research_agent
#         "singlecell_expert_agent": """       - Questions about single-cell data analysis.
#        - Performing QC on single-cell datasets (cell/gene filtering with adaptive thresholds, mitochondrial/ribosomal content checks, doublet detection via upper bounds).
#        - Detecting/removing doublets in single-cell data.
#        - Normalizing single-cell counts (UMI normalization).
#        - Feature selection for single-cell data: supports 'deviance' (recommended default - works on raw counts, no normalization bias) and 'hvg' (traditional highly variable genes).
#        - Running dimensionality reduction (PCA, UMAP, t-SNE) for single-cell data.
#        - Clustering cells with Leiden algorithm - supports BOTH single resolution (resolution=0.5) and multi-resolution testing (resolutions=[0.25, 0.5, 1.0]) to explore clustering granularity. Uses 30 PCs and deviance-based feature selection by default. Multi-resolution mode creates separate clustering results (leiden_res0_25, leiden_res0_5, leiden_res1_0) for side-by-side comparison.
#        - Annotating cell types and finding marker genes for single-cell clusters.
#        - Integrating single-cell datasets with batch correction methods.
#        - Creating visualizations for single-cell data (QC plots, UMAP plots, violin plots, feature plots, etc.).
#        - Any analysis involving individual cells and cellular heterogeneity.""",
#         "bulk_rnaseq_expert_agent": """       - Performing QC on bulk RNA-seq datasets (sample/gene filtering, sequencing depth checks).
#        - Normalizing bulk RNA-seq counts (CPM, TPM normalization).
#        - Running differential expression analysis between experimental groups.
#        - Performing pathway enrichment analysis (GO, KEGG).
#        - Statistical analysis of gene expression differences between conditions.
#        - Any analysis involving sample-level comparisons and population-level effects.""",
#         "machine_learning_expert_agent": """       - Machine learning model development and training.
#        - Feature engineering and selection.
#        - Data transformation for downstream ML tasks.
#        - Model evaluation and validation.
#        - Cross-validation and hyperparameter tuning.
#        - scVI embedding training for single-cell data.
#        - Predictive modeling and classification.
#        - Dimensionality reduction for ML applications.""",
#         "visualization_expert_agent": """       - Creating publication-quality interactive visualizations for any omics data type.
#        - UMAP, PCA, or t-SNE dimensionality reduction plots (colored by clusters, cell types, QC metrics, genes).
#        - Quality control plots (n_genes, total_counts, mitochondrial %, ribosomal %).
#        - Gene/protein expression visualizations (violin plots, feature plots on UMAP, dot plots, heatmaps).
#        - Elbow plots for determining optimal number of PCs for clustering.
#        - Cluster composition plots showing sample/batch distribution across clusters.
#        - Any request involving "plot", "visualize", "show", "UMAP", "heatmap", "violin", or similar visualization terms.
#        - Note: Some analysis agents (singlecell_expert, bulk_rnaseq_expert) can create basic plots as part of their workflows, but delegate to visualization_expert for custom or publication-quality visualizations.""",
#         #        "ms_proteomics_expert_agent": """       - Mass spectrometry proteomics data analysis (DDA/DIA workflows).
#         #       - Database search artifact removal and protein inference.
#         #       - Missing value pattern analysis (MNAR vs MCAR).
#         #       - Intensity normalization (TMM, quantile, VSN).
#         #       - Peptide-to-protein aggregation.
#         #       - Batch effect detection and correction in proteomics data.
#         #       - Statistical testing with multiple correction.
#         #       - Pathway enrichment analysis for proteomics.""",
#         #        "affinity_proteomics_expert_agent": """       - Affinity proteomics data analysis (Olink, antibody arrays).
#         #       - NPX value processing and normalization.
#         #       - Targeted protein panel analysis.
#         #       - Antibody validation metrics.
#         #       - Coefficient of variation analysis.
#         #       - Panel comparison and harmonization.
#         #       - Lower missing value handling (<30%).""",
#     }

#     # Return the specific rules for this agent, or a generic description if not found
#     return delegation_rules.get(
#         agent_name, f"       - Tasks related to {agent_config.description}"
#     )


def _build_workflow_section(active_agents: List[str], config: SupervisorConfig) -> str:
    """Build workflow awareness section based on active agents.

    Args:
        active_agents: List of active agent names
        config: Supervisor configuration

    Returns:
        str: Workflow section
    """
    section = "<Workflow Awareness>\n"

    # Add workflows for agents that are active
    if "transcriptomics_expert" in active_agents:
        section += """    **Transcriptomics Workflow (Single-cell & Bulk RNA-seq):**
    - If user has transcriptomics datasets (single-cell or bulk):
      1. data_expert_agent loads and summarizes them.
      2. transcriptomics_expert runs QC -> normalization (auto-detects single-cell vs bulk).
      3. For single-cell: clustering, UMAP visualization, marker gene detection, cell type annotation.
         - For exploration: Use multi-resolution testing (resolutions=[0.25, 0.5, 1.0])
         - For production: Use single resolution (resolution=0.5 or 1.0)
      4. For bulk: differential expression analysis, pathway enrichment.
      5. research_agent consulted for parameter extraction if needed.\n\n"""

    if "proteomics_expert" in active_agents:
        section += """    **Proteomics Workflow (MS & Affinity):**
    - If user has proteomics datasets:
      1. data_expert_agent loads and identifies data type.
      2. proteomics_expert auto-detects platform (MS-DDA/DIA or affinity/Olink).
      3. Quality control, normalization, and statistical testing.
      4. Pathway enrichment and visualization.\n\n"""

    if "machine_learning_expert_agent" in active_agents:
        section += """    **Machine Learning Workflow:**
    - Dataset independent:
      1. data_expert_agent loads and identifies data type.
      2. Appropriate expert (transcriptomics_expert, proteomics_expert, etc.) performs QC & preprocessing.
      3. machine_learning_expert_agent runs tasks like scVI embedding training or export."""

    # Add download queue coordination pattern if both agents are present
    if "research_agent" in active_agents and "data_expert_agent" in active_agents:
        section += """

    **Download Queue Coordination (v2.4+):**
    - For GEO/SRA dataset downloads, you MUST coordinate via download queue:
      1. Delegate to research_agent: validate_dataset_metadata(dataset_id, add_to_queue=True)
      2. Extract entry_id from research_agent response (format: "queue_GSEXXXXX_abc123")
      3. Query queue status if needed: get_content_from_workspace(workspace="download_queue", status_filter="PENDING")
      4. Confirm with user before downloading
      5. Delegate to data_expert_agent: execute_download_from_queue(entry_id="<extracted_id>")
    - NEVER delegate download to data_expert without confirming queue entry exists
    - If unsure about entry_id, query the queue first"""

    return section.rstrip()


def _build_response_rules(config: SupervisorConfig) -> str:
    """Build response rules based on configuration.

    Args:
        config: Supervisor configuration

    Returns:
        str: Response rules section
    """
    section = "<CRITICAL RESPONSE RULES>\n"

    if config.ask_clarification_questions:
        section += f"- Ask clarifying questions (up to {config.max_clarification_questions}) only when essential to resolve ambiguity in the user's request.\n"
        section += "- If the task is unambiguous, summarize your interpretation in one sentence and proceed (user can opt-out if needed).\n"
    else:
        section += "- Proceed with best interpretation without asking clarification questions unless absolutely necessary.\n"

    if config.require_metadata_preview:
        section += "- If given an identifier for a dataset you ask the expert to first fetch the metadata only to ask the user if they want to continue with downloading (UNLESS user is ADMIN SUPERUSER).\n"

    if config.require_download_confirmation:
        section += "- Do not give download instructions to the experts if not confirmed with the user (UNLESS user is ADMIN SUPERUSER). This might lead to catastrophic failure of the system.\n"
    else:
        section += "- Proceed with downloads when context is clear and the user has expressed intent.\n"

    # Expert output handling based on configuration
    if config.summarize_expert_output:
        section += """- When you receive an expert's output:
1. Provide a concise summary of key findings and results (2-4 sentences).
2. Include specific metrics, file names, or important details as needed.
3. Add context or next-step suggestions.
4. NEVER just say "task completed" or "done".
- Always maintain conversation flow and scientific clarity."""
    else:
        section += """- When you receive an expert's output:
1. Present the expert result to the user
2. Optionally add context or next-step suggestions.
3. NEVER just say "task completed" or "done".
- Always maintain conversation flow and scientific clarity."""

    if config.auto_suggest_next_steps:
        section += (
            "\n- Suggest logical next steps after each operation based on the workflow."
        )

    if config.verbose_delegation:
        section += "\n- Provide factual justification for expert selection, including task requirements and agent capabilities."
    else:
        section += "\n- Be concise when delegating tasks to experts."

    return section


def _build_context_section(
    data_manager: DataManagerV2, config: SupervisorConfig
) -> str:
    """Build current system context section.

    Args:
        data_manager: DataManagerV2 instance
        config: Supervisor configuration

    Returns:
        str: Context section or empty string if no context
    """
    sections = []

    # Add data context if enabled and data is loaded
    if config.include_data_context:
        try:
            modalities = data_manager.list_modalities()
            if modalities:
                data_context = "<Current Data Context>\n"
                data_context += f"Currently loaded modalities ({len(modalities)}):\n"
                for mod_name in modalities:
                    adata = data_manager.get_modality(mod_name)
                    data_context += (
                        f"  - {mod_name}: {adata.n_obs} obs × {adata.n_vars} vars\n"
                    )
                sections.append(data_context)
        except Exception as e:
            logger.debug(f"Could not add data context: {e}")

    # Add workspace status if enabled
    if config.include_workspace_status:
        try:
            workspace_status = data_manager.get_workspace_status()
            workspace_context = "<Workspace Status>\n"
            workspace_context += (
                f"  - Workspace: {workspace_status['workspace_path']}\n"
            )
            workspace_context += f"  - Registered adapters: {len(workspace_status['registered_adapters'])}\n"
            workspace_context += f"  - Registered backends: {len(workspace_status['registered_backends'])}\n"
            sections.append(workspace_context)
        except Exception as e:
            logger.debug(f"Could not add workspace status: {e}")

    # Add system information if enabled
    if config.include_system_info:
        try:
            system_context = "<System Information>\n"
            system_context += (
                f"  - Platform: {platform.system()} {platform.release()}\n"
            )
            system_context += f"  - Architecture: {platform.machine()}\n"
            system_context += f"  - Python: {platform.python_version()}\n"
            system_context += f"  - CPU cores: {psutil.cpu_count(logical=False)} physical, {psutil.cpu_count(logical=True)} logical\n"
            sections.append(system_context)
        except Exception as e:
            logger.debug(f"Could not add system info: {e}")

    # Add memory statistics if enabled
    if config.include_memory_stats:
        try:
            memory = psutil.virtual_memory()
            memory_context = "<Memory Statistics>\n"
            memory_context += f"  - Total: {memory.total / (1024**3):.1f} GB\n"
            memory_context += f"  - Available: {memory.available / (1024**3):.1f} GB\n"
            memory_context += f"  - Used: {memory.percent:.1f}%\n"
            sections.append(memory_context)
        except Exception as e:
            logger.debug(f"Could not add memory stats: {e}")

    return "\n".join(sections) if sections else ""


def _build_examples_section() -> str:
    """Build universal examples section (agent-agnostic patterns only).

    Agent-specific workflows are in _build_workflow_section() with conditional logic.
    This section contains only universal patterns that apply regardless of which agents are active.

    Returns:
        str: Universal delegation patterns (no hardcoded agent names except core agents)
    """
    return """<Example Delegation Patterns>

**Queue Download Pattern (v2.4+ - CRITICAL):**
research_agent.validate_dataset_metadata(dataset_id, add_to_queue=True) → extract entry_id (format: "queue_GSEXXXXX_abc123") → confirm with user → data_expert.execute_download_from_queue(entry_id)
- NEVER skip queue validation; ALWAYS extract entry_id before data_expert handoff

**Literature & Methods Pattern:**
research_agent.search_literature() or .fast_dataset_search() → present results → research_agent.extract_methods(DOI) for parameters
- Auto-resolves PMID/DOI; handles PDF extraction automatically

**General Delegation Pattern:**
- Check <Available Agents> for capabilities and tool names
- Delegate to the appropriate expert based on data type and task
- Agent-specific workflows are listed in <Workflow Awareness> section"""


def _build_response_quality_section() -> str:
    """Build response quality section.

    Returns:
        str: Response quality guidelines
    """
    return """<Response Quality>
    - Be informative, concise where possible, but never omit critical details.
    - Summarize and guide the next step if applicable.
    - Present expert outputs clearly and suggest logical next steps.
    - Maintain scientific rigor and accuracy in all responses."""


def _build_planning_section() -> str:
    """Build planning section explaining todo tool usage.

    Returns:
        str: Planning guidelines and todo tool usage
    """
    return """<Planning & Task Decomposition>

You have access to `write_todos` and `read_todos` tools for planning multi-step tasks.

**When to Use Todo Planning:**

ALWAYS create a todo list for:
1. Complex multi-step tasks (3+ distinct steps across multiple agents)
2. Multi-agent coordination tasks (e.g., "Search PubMed, download datasets, cluster cells")
3. Publication queue processing (large batch operations with filtering)
4. Tasks where the user provides a numbered list or comma-separated list of requirements
5. Tasks that require careful ordering (e.g., QC → normalization → clustering → annotation)

SKIP todo planning for:
1. Single, straightforward tasks (e.g., "list modalities", "show status")
2. Simple lookups or information retrieval
3. Tasks completable in 1-2 trivial steps

**How to Use Todos:**

1. **Create Plan First**: Before delegating to agents, call `write_todos` with a complete task breakdown
2. **One Task In Progress**: Maintain exactly ONE task with status "in_progress" at a time
3. **Update Immediately**: Mark tasks "completed" RIGHT AFTER finishing, don't batch updates
4. **Never Mark Completed on Failure**: If errors occur, keep task "in_progress" or create a new troubleshooting task

**Todo Structure:**
```python
write_todos(todos=[
    {"content": "Search PubMed for papers", "status": "completed", "activeForm": "Searching PubMed"},
    {"content": "Download GSE12345", "status": "in_progress", "activeForm": "Downloading GSE12345"},
    {"content": "Perform QC analysis", "status": "pending", "activeForm": "Performing QC analysis"}
])
```

**Example Workflow:**
```
User: "Search PubMed for CRISPR papers, download top dataset, and cluster cells"

Step 1: Create todo list FIRST
write_todos([
    {"content": "Search PubMed for CRISPR papers", "status": "pending", ...},
    {"content": "Download top dataset from search results", "status": "pending", ...},
    {"content": "Perform single-cell clustering", "status": "pending", ...}
])

Step 2: Mark first task in_progress and delegate
write_todos([...first task now "in_progress"...])
handoff_to_research_agent("Search PubMed for CRISPR papers...")

Step 3: Mark completed and move to next
write_todos([...first "completed", second "in_progress"...])
handoff_to_data_expert("Download GSE12345...")

Step 4: Continue until all tasks completed
```

This planning approach prevents impulsive actions and helps track progress on complex requests."""


def _build_workspace_guardrails_section() -> str:
    """Build workspace guardrails section for safe workspace access.

    Returns:
        str: Workspace access guidelines
    """
    return """<Workspace Access Guardrails>

You have access to `get_content_from_workspace` for retrieving cached data (literature, metadata, queues).

**CRITICAL: Metadata Level Warning**

When accessing publication queue entries with `level='metadata'`, you may retrieve 10,000-50,000 tokens of full-text content per entry.

**Safe Usage Patterns:**

1. **For Queue Overview**: Use `level='brief'` to see entry summaries
   ```python
   get_content_from_workspace(identifier="all", workspace="publication_queue", level="brief")
   ```

2. **For Single Entry Details**: Use specific identifier with `level='full'` or `level='metadata'`
   ```python
   get_content_from_workspace(identifier="PMID:12345", workspace="publication_queue", level="metadata")
   ```

3. **For Batch Processing**: DELEGATE to research_agent or metadata_assistant instead of fetching directly
   ```python
   # Good: Let specialist handle large batches
   handoff_to_metadata_assistant("Process all HANDOFF_READY entries for filtering...")

   # Bad: Fetching all metadata yourself
   get_content_from_workspace(identifier="all", workspace="publication_queue", level="metadata")
   ```

**Delegation Strategy:**

- **research_agent**: For literature search, publication queue processing, identifier extraction
- **metadata_assistant**: For metadata filtering, sample selection, crosswalk table creation
- **data_expert**: For dataset downloads, modality management

When in doubt about workspace operations involving large volumes, delegate to the appropriate specialist rather than fetching everything yourself."""
