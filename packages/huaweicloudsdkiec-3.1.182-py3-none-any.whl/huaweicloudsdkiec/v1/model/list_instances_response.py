# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInstancesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'err_sites': 'list[str]',
        'count': 'int',
        'servers': 'list[Instance]'
    }

    attribute_map = {
        'err_sites': 'err_sites',
        'count': 'count',
        'servers': 'servers'
    }

    def __init__(self, err_sites=None, count=None, servers=None):
        r"""ListInstancesResponse

        The model defined in huaweicloud sdk

        :param err_sites: 异常站点。
        :type err_sites: list[str]
        :param count: 边缘实例列表的总数。
        :type count: int
        :param servers: 边缘实例列表。
        :type servers: list[:class:`huaweicloudsdkiec.v1.Instance`]
        """
        
        super().__init__()

        self._err_sites = None
        self._count = None
        self._servers = None
        self.discriminator = None

        if err_sites is not None:
            self.err_sites = err_sites
        if count is not None:
            self.count = count
        if servers is not None:
            self.servers = servers

    @property
    def err_sites(self):
        r"""Gets the err_sites of this ListInstancesResponse.

        异常站点。

        :return: The err_sites of this ListInstancesResponse.
        :rtype: list[str]
        """
        return self._err_sites

    @err_sites.setter
    def err_sites(self, err_sites):
        r"""Sets the err_sites of this ListInstancesResponse.

        异常站点。

        :param err_sites: The err_sites of this ListInstancesResponse.
        :type err_sites: list[str]
        """
        self._err_sites = err_sites

    @property
    def count(self):
        r"""Gets the count of this ListInstancesResponse.

        边缘实例列表的总数。

        :return: The count of this ListInstancesResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListInstancesResponse.

        边缘实例列表的总数。

        :param count: The count of this ListInstancesResponse.
        :type count: int
        """
        self._count = count

    @property
    def servers(self):
        r"""Gets the servers of this ListInstancesResponse.

        边缘实例列表。

        :return: The servers of this ListInstancesResponse.
        :rtype: list[:class:`huaweicloudsdkiec.v1.Instance`]
        """
        return self._servers

    @servers.setter
    def servers(self, servers):
        r"""Sets the servers of this ListInstancesResponse.

        边缘实例列表。

        :param servers: The servers of this ListInstancesResponse.
        :type servers: list[:class:`huaweicloudsdkiec.v1.Instance`]
        """
        self._servers = servers

    def to_dict(self):
        import warnings
        warnings.warn("ListInstancesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInstancesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
