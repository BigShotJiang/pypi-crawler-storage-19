# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RouteOption:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'type': 'str',
        'destination': 'str',
        'nexthop': 'str',
        'description': 'str'
    }

    attribute_map = {
        'type': 'type',
        'destination': 'destination',
        'nexthop': 'nexthop',
        'description': 'description'
    }

    def __init__(self, type=None, destination=None, nexthop=None, description=None):
        r"""RouteOption

        The model defined in huaweicloud sdk

        :param type: 路由的类型  取值范围：     1）ecs：弹性云服务器     2）vip：虚拟IP
        :type type: str
        :param destination: 路由的目的网段  约束：合法的CIDR格式, 目的地址不可更新
        :type destination: str
        :param nexthop: 路由下一跳对象的ID  取值范围：     1）当type为ecs时，传入ecs实例ID；     2）当type为vip时，取值为vip的ip地址；
        :type nexthop: str
        :param description: 路由的描述信息  取值范围：0-255个字符，不能包含“&lt;”和“&gt;”
        :type description: str
        """
        
        

        self._type = None
        self._destination = None
        self._nexthop = None
        self._description = None
        self.discriminator = None

        self.type = type
        self.destination = destination
        self.nexthop = nexthop
        if description is not None:
            self.description = description

    @property
    def type(self):
        r"""Gets the type of this RouteOption.

        路由的类型  取值范围：     1）ecs：弹性云服务器     2）vip：虚拟IP

        :return: The type of this RouteOption.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this RouteOption.

        路由的类型  取值范围：     1）ecs：弹性云服务器     2）vip：虚拟IP

        :param type: The type of this RouteOption.
        :type type: str
        """
        self._type = type

    @property
    def destination(self):
        r"""Gets the destination of this RouteOption.

        路由的目的网段  约束：合法的CIDR格式, 目的地址不可更新

        :return: The destination of this RouteOption.
        :rtype: str
        """
        return self._destination

    @destination.setter
    def destination(self, destination):
        r"""Sets the destination of this RouteOption.

        路由的目的网段  约束：合法的CIDR格式, 目的地址不可更新

        :param destination: The destination of this RouteOption.
        :type destination: str
        """
        self._destination = destination

    @property
    def nexthop(self):
        r"""Gets the nexthop of this RouteOption.

        路由下一跳对象的ID  取值范围：     1）当type为ecs时，传入ecs实例ID；     2）当type为vip时，取值为vip的ip地址；

        :return: The nexthop of this RouteOption.
        :rtype: str
        """
        return self._nexthop

    @nexthop.setter
    def nexthop(self, nexthop):
        r"""Sets the nexthop of this RouteOption.

        路由下一跳对象的ID  取值范围：     1）当type为ecs时，传入ecs实例ID；     2）当type为vip时，取值为vip的ip地址；

        :param nexthop: The nexthop of this RouteOption.
        :type nexthop: str
        """
        self._nexthop = nexthop

    @property
    def description(self):
        r"""Gets the description of this RouteOption.

        路由的描述信息  取值范围：0-255个字符，不能包含“<”和“>”

        :return: The description of this RouteOption.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this RouteOption.

        路由的描述信息  取值范围：0-255个字符，不能包含“<”和“>”

        :param description: The description of this RouteOption.
        :type description: str
        """
        self._description = description

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RouteOption):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
