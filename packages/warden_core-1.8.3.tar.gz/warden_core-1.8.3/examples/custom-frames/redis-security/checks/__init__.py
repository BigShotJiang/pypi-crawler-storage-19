"""Frame-specific checks."""
