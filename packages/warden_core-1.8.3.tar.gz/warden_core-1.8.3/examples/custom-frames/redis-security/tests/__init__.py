"""Frame tests."""
