"""LLM integration tests"""
