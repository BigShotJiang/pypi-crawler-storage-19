"""Orphan Frame Tests"""
