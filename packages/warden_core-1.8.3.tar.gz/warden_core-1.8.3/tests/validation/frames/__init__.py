"""Tests for validation frames."""
