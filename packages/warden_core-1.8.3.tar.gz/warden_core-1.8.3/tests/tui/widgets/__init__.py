"""TUI widgets tests."""
