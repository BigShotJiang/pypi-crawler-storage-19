"""TUI tests."""
