"""TUI modals tests."""
