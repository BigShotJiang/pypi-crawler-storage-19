"""Analysis application tests."""
