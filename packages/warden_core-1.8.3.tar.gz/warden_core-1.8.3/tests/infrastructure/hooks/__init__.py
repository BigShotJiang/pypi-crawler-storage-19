"""Tests for Git hooks."""
