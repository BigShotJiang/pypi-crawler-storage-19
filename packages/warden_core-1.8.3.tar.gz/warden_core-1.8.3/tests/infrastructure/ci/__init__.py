"""Tests for CI templates."""
