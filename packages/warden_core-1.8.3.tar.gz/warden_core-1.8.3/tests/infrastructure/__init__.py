"""Tests for infrastructure module."""
