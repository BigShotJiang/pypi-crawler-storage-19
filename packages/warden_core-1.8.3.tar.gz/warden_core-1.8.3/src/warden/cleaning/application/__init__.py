"""Cleaning application module."""
