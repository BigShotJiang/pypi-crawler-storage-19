"""Memory domain module."""
