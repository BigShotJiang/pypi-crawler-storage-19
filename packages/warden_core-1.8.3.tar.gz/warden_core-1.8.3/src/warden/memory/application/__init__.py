"""Memory application module."""
