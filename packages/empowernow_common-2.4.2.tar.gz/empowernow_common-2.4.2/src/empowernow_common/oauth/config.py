"""OAuth client configuration using Pydantic Settings.

This module provides environment-variable-driven configuration for OAuth clients,
following the AI_PYTHON_FASTAPI_EXCELLENCE_PLAYBOOK.md standards.

Environment Variables:
    OAUTH_CLIENT_ID: OAuth client ID (required)
    OAUTH_CLIENT_SECRET: OAuth client secret
    OAUTH_TOKEN_URL: Token endpoint URL (required)
    OAUTH_AUTHORIZATION_URL: Authorization endpoint URL
    OAUTH_SCOPE: Default scope
    OAUTH_TOKEN_ENDPOINT_AUTH_METHOD: Authentication method
    OAUTH_TIMEOUT_SECONDS: Request timeout
    OAUTH_MAX_RETRIES: Maximum retry attempts
    OAUTH_CIRCUIT_FAILURE_THRESHOLD: Circuit breaker threshold
    OAUTH_CIRCUIT_RESET_TIMEOUT: Circuit breaker reset timeout
    
Usage:
    # Load from environment variables
    config = OAuthSettings()
    oauth = HardenedOAuth(config.to_oauth_config())
    
    # Or with explicit values
    config = OAuthSettings(
        client_id="my-app",
        client_secret="secret",
        token_url="https://auth.example.com/oauth/token",
    )
"""

from typing import Optional, List, Set
from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from difflib import get_close_matches


class OAuthSettings(BaseSettings):
    """OAuth client configuration with environment variable support.
    
    All settings can be configured via environment variables with OAUTH_ prefix,
    or via a .env file.
    
    Example:
        # Set environment variables
        export OAUTH_CLIENT_ID=my-app
        export OAUTH_CLIENT_SECRET=secret
        export OAUTH_TOKEN_URL=https://auth.example.com/oauth/token
        
        # Create config from environment
        config = OAuthSettings()
        
        # Use with HardenedOAuth
        oauth = HardenedOAuth(config.to_oauth_config())
    """
    
    model_config = SettingsConfigDict(
        env_prefix="OAUTH_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )
    
    # Required credentials
    client_id: str = Field(
        ...,
        description="OAuth client ID",
        examples=["my-application"],
    )
    token_url: str = Field(
        ...,
        description="Token endpoint URL",
        examples=["https://auth.example.com/oauth/token"],
    )
    
    # Optional credentials
    client_secret: str = Field(
        default="",
        description="OAuth client secret (empty for public clients)",
    )
    
    # Optional endpoints
    authorization_url: str = Field(
        default="",
        description="Authorization endpoint URL",
    )
    introspection_url: Optional[str] = Field(
        default=None,
        description="Token introspection endpoint URL",
    )
    revocation_url: Optional[str] = Field(
        default=None,
        description="Token revocation endpoint URL",
    )
    par_endpoint: Optional[str] = Field(
        default=None,
        description="Pushed Authorization Request (PAR) endpoint URL",
    )
    ciba_endpoint: Optional[str] = Field(
        default=None,
        description="Client Initiated Backchannel Authentication (CIBA) endpoint URL",
    )
    
    # Authentication settings
    token_endpoint_auth_method: str = Field(
        default="client_secret_basic",
        description="Token endpoint authentication method",
    )
    scope: str = Field(
        default="",
        description="Default scope for token requests",
    )
    
    # Resilience settings
    timeout_seconds: float = Field(
        default=30.0,
        ge=1.0,
        le=300.0,
        description="Request timeout in seconds",
    )
    max_retries: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum number of retry attempts",
    )
    
    # Circuit breaker settings
    circuit_failure_threshold: int = Field(
        default=5,
        ge=1,
        le=100,
        description="Number of failures before circuit breaker opens",
    )
    circuit_reset_timeout: float = Field(
        default=30.0,
        ge=1.0,
        le=600.0,
        description="Seconds before circuit breaker resets",
    )
    
    # Token caching settings
    token_cache_buffer_seconds: int = Field(
        default=60,
        ge=0,
        le=600,
        description="Seconds before expiry to refresh token",
    )
    
    @field_validator("token_endpoint_auth_method")
    @classmethod
    def validate_auth_method(cls, v: str) -> str:
        """Validate authentication method with helpful error messages."""
        valid_methods = {
            "client_secret_basic",
            "client_secret_post",
            "private_key_jwt",
            "none",
        }
        
        v_lower = v.lower().strip()
        if v_lower not in valid_methods:
            # Find similar values for "did you mean?" suggestion
            suggestions = get_close_matches(v_lower, valid_methods, n=2, cutoff=0.5)
            
            msg = f"Invalid token_endpoint_auth_method: '{v}'"
            if suggestions:
                msg += f"\n  Did you mean: {' or '.join(repr(s) for s in suggestions)}?"
            msg += f"\n  Valid options: {', '.join(sorted(valid_methods))}"
            raise ValueError(msg)
        
        return v_lower
    
    @field_validator("token_url", "authorization_url")
    @classmethod
    def validate_url(cls, v: str, info) -> str:
        """Validate URLs are well-formed."""
        if not v:
            return v
        
        # Basic URL validation
        if not v.startswith(("http://", "https://")):
            raise ValueError(
                f"{info.field_name} must start with http:// or https://. Got: {v}"
            )
        
        return v
    
    def to_oauth_config(self):
        """Convert to SecureOAuthConfig for use with HardenedOAuth.
        
        Returns:
            SecureOAuthConfig instance
        """
        from .client import SecureOAuthConfig
        
        return SecureOAuthConfig(
            client_id=self.client_id,
            client_secret=self.client_secret,
            token_url=self.token_url,
            authorization_url=self.authorization_url,
            introspection_url=self.introspection_url,
            revocation_url=self.revocation_url,
            par_endpoint=self.par_endpoint,
            ciba_endpoint=self.ciba_endpoint,
            token_endpoint_auth_method=self.token_endpoint_auth_method,
            scope=self.scope,
        )
    
    def get_env_template(self) -> str:
        """Generate a .env template with all available settings.
        
        Returns:
            String containing .env file template with comments
        """
        return '''# OAuth Client Configuration
# Copy this to .env and customize

# Required settings
OAUTH_CLIENT_ID=your-client-id
OAUTH_CLIENT_SECRET=your-client-secret
OAUTH_TOKEN_URL=https://auth.example.com/oauth/token

# Optional endpoints
# OAUTH_AUTHORIZATION_URL=https://auth.example.com/authorize
# OAUTH_INTROSPECTION_URL=https://auth.example.com/oauth/introspect
# OAUTH_REVOCATION_URL=https://auth.example.com/oauth/revoke
# OAUTH_PAR_ENDPOINT=https://auth.example.com/oauth/par
# OAUTH_CIBA_ENDPOINT=https://auth.example.com/oauth/ciba

# Authentication method (client_secret_basic, client_secret_post, private_key_jwt, none)
OAUTH_TOKEN_ENDPOINT_AUTH_METHOD=client_secret_basic

# Default scope
# OAUTH_SCOPE=read write

# Resilience settings
OAUTH_TIMEOUT_SECONDS=30
OAUTH_MAX_RETRIES=3
OAUTH_CIRCUIT_FAILURE_THRESHOLD=5
OAUTH_CIRCUIT_RESET_TIMEOUT=30

# Token caching
OAUTH_TOKEN_CACHE_BUFFER_SECONDS=60
'''


class PrivateKeyJWTSettings(BaseSettings):
    """Settings for private_key_jwt authentication.
    
    Environment Variables:
        OAUTH_PKJWT_KEY_PATH: Path to private key PEM file
        OAUTH_PKJWT_KEY_ID: Key ID (kid) for JWT header
        OAUTH_PKJWT_ALGORITHM: Signing algorithm (RS256, ES256, etc.)
        OAUTH_PKJWT_TTL: Assertion TTL in seconds
    """
    
    model_config = SettingsConfigDict(
        env_prefix="OAUTH_PKJWT_",
        env_file=".env",
        extra="ignore",
    )
    
    key_path: Optional[str] = Field(
        default=None,
        description="Path to private key PEM file",
    )
    key_id: Optional[str] = Field(
        default=None,
        description="Key ID (kid) for JWT header",
    )
    algorithm: str = Field(
        default="RS256",
        description="Signing algorithm",
    )
    ttl: int = Field(
        default=300,
        ge=60,
        le=3600,
        description="Assertion TTL in seconds",
    )
    
    @field_validator("algorithm")
    @classmethod
    def validate_algorithm(cls, v: str) -> str:
        """Validate signing algorithm is supported."""
        valid_algorithms = {"RS256", "RS384", "RS512", "ES256", "ES384", "ES512"}
        v_upper = v.upper()
        if v_upper not in valid_algorithms:
            raise ValueError(
                f"Invalid algorithm: {v}. "
                f"Valid options: {', '.join(sorted(valid_algorithms))}"
            )
        return v_upper
    
    def load_key(self) -> bytes:
        """Load private key from file.
        
        Returns:
            Private key bytes
            
        Raises:
            FileNotFoundError: If key file doesn't exist
            ValueError: If key_path not configured
        """
        if not self.key_path:
            raise ValueError(
                "OAUTH_PKJWT_KEY_PATH not configured. "
                "Set the environment variable or provide key_path."
            )
        
        with open(self.key_path, "rb") as f:
            return f.read()
