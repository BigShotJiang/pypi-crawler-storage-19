"""
EmpowerNow OAuth – Comprehensive, Secure OAuth Implementation

This package provides enterprise-grade OAuth 2.1 support with advanced security features:
- RFC 8693: OAuth 2.0 Token Exchange
- RFC 9126: OAuth 2.0 Pushed Authorization Requests (PAR)
- RFC 9449: OAuth 2.0 Demonstrating Proof-of-Possession at the Application Layer (DPoP)
- RFC 9101: JWT Secured Authorization Response Mode for OAuth 2.0 (JARM)
- RFC 9101: JWT Secured Authorization Request (JAR)
- Rich Authorization Requests (RAR)
- Client Initiated Backchannel Authentication (CIBA)

All implementations are FIPS-compliant and production-ready.
"""

# Core OAuth client
from .client import HardenedOAuth, SecureOAuthConfig, HardenedToken, GrantManagementAction

# DPoP (Demonstrating Proof of Possession)
from .dpop import DPoPKeyPair, DPoPProofGenerator, DPoPError, generate_dpop_key_pair

# PAR (Pushed Authorization Requests)
from .par import PARRequest, PARResponse, PARError, generate_pkce_challenge

# JARM (JWT Secured Authorization Response Mode)
from .jarm import JARMConfiguration, JARMResponseProcessor, JARMError

# JAR (JWT Secured Authorization Request)
from .jar import JARConfiguration, JARRequestBuilder, JARError, generate_jar_signing_key

# Rich Authorization Requests
from .rar import (
    SecureAuthorizationDetail,
    RARError,
    RARBuilder,
    AuthZENCompatibleResource,
    AuthZENCompatibleAction,
    AuthZENCompatibleContext,
    StandardActionType,
    StandardResourceType,
    create_account_access_detail,
    create_api_access_detail,
)

# CIBA (Client Initiated Backchannel Authentication)
from .ciba import CIBARequest, CIBAResponse, CIBAError

# Security and validation
from .security import (
    FIPSValidator,
    SecurityError,
    validate_url_security,
    sanitize_string_input,
)

# Rich error classes
from .errors import (
    OAuthError,
    OAuthTokenError,
    OAuthCircuitBreakerError,
    OAuthDiscoveryError,
    OAuthConfigurationError,
)

# Metrics (optional - gracefully degrades if prometheus_client not installed)
from .metrics import is_metrics_available

# Pydantic Settings configuration
from .config import OAuthSettings, PrivateKeyJWTSettings

# Compatibility aliases
OAuth = HardenedOAuth
Token = HardenedToken
AdvancedToken = HardenedToken

__all__ = [
    # Core
    "HardenedOAuth",
    "SecureOAuthConfig",
    "HardenedToken",
    # DPoP
    "DPoPKeyPair",
    "DPoPProofGenerator",
    "DPoPError",
    "generate_dpop_key_pair",
    # PAR
    "PARRequest",
    "PARResponse",
    "PARError",
    "generate_pkce_challenge",
    # JARM
    "JARMConfiguration",
    "JARMResponseProcessor",
    "JARMError",
    # JAR
    "JARConfiguration",
    "JARRequestBuilder",
    "JARError",
    "GrantManagementAction",
    "generate_jar_signing_key",
    # RAR
    "SecureAuthorizationDetail",
    "RARError",
    "RARBuilder",
    "AuthZENCompatibleResource",
    "AuthZENCompatibleAction",
    "AuthZENCompatibleContext",
    "StandardActionType",
    "StandardResourceType",
    "create_account_access_detail",
    "create_api_access_detail",
    # CIBA
    "CIBARequest",
    "CIBAResponse",
    "CIBAError",
    # Security
    "FIPSValidator",
    "SecurityError",
    "validate_url_security",
    "sanitize_string_input",
    # Errors
    "OAuthError",
    "OAuthTokenError",
    "OAuthCircuitBreakerError",
    "OAuthDiscoveryError",
    "OAuthConfigurationError",
    # Metrics
    "is_metrics_available",
    # Configuration
    "OAuthSettings",
    "PrivateKeyJWTSettings",
    # Compatibility
    "OAuth",
    "Token",
    "AdvancedToken",
]

# Version info
__version__ = "2.1.0"
__author__ = "EmpowerNow Security Team"
__description__ = "Enterprise-grade OAuth 2.1 with advanced security features"
