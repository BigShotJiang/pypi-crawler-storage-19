"""
Telegram MCP - Thin stdio client with polling and media support.

This is a minimal MCP server that forwards requests to the Telegram API server.
It runs locally via stdio and calls the remote server for Telegram operations.
Uses polling for wait_for_reply to work around proxy timeouts.
"""

import asyncio
import logging
import os
import sys

import httpx
from mcp.server.fastmcp import FastMCP

logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger(__name__)


# Configuration
SERVER_URL = os.environ.get("TELEGRAM_SERVER_URL", "https://telegram-mcp.furkankucuk.net")
CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")
POLL_INTERVAL = 5  # seconds between polls


# MCP Server
mcp = FastMCP(
    name="Telegram MCP",
    instructions="""
Send messages to the user via Telegram with interact().
Send media with send_media().
If they prefer Telegram, use it for ALL communication.
When done with a task: interact("Done! What's next?", wait_for_reply=True)
""",
)


async def _poll_for_reply(client: httpx.AsyncClient, request_id: str) -> str:
    """Poll the server until we get a reply."""
    while True:
        response = await client.get(
            f"{SERVER_URL}/api/poll",
            headers={"X-Chat-Id": CHAT_ID},
            params={"request_id": request_id},
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"Poll error: {response.text}")
        
        data = response.json()
        
        if data.get("status") == "completed":
            return data.get("reply")
        
        # Still pending, wait and retry
        await asyncio.sleep(POLL_INTERVAL)


@mcp.tool()
async def interact(
    message: str,
    wait_for_reply: bool = False,
    choices: list[str] | None = None,
) -> dict:
    """
    Send a message to the user via Telegram.

    WHEN TO USE:
    First, ask the user (in your chat) if they'll be away or prefer Telegram.
    If yes, use Telegram for ALL communication during that session.

    KEEPING THE LOOP ALIVE:
    In Telegram mode, DON'T just end after completing a task.
    Instead: interact("Done! What's next?", wait_for_reply=True)
    Then treat their reply as your next task and keep going.

    Examples:
    - interact("Done! What's next?", wait_for_reply=True)  # Ask for next task
    - interact("Working on it...")  # Status update
    - interact("Delete?", choices=["Yes", "No"], wait_for_reply=True)  # Confirm

    Args:
        message: Text to send.
        wait_for_reply: Block until user replies.
        choices: Button labels.

    Returns:
        reply: User's response (None if not waiting).
    """
    if not CHAT_ID:
        raise RuntimeError("TELEGRAM_CHAT_ID environment variable required")

    async with httpx.AsyncClient(timeout=60) as client:
        # Send the message
        response = await client.post(
            f"{SERVER_URL}/api/interact",
            headers={"X-Chat-Id": CHAT_ID},
            json={
                "message": message,
                "wait_for_reply": wait_for_reply,
                "choices": choices,
            },
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"Server error: {response.text}")
        
        data = response.json()
        
        # If not waiting, we're done
        if not wait_for_reply:
            return {"reply": None}
        
        # If waiting, poll for the reply
        request_id = data.get("request_id")
        if not request_id:
            return {"reply": None}
        
        reply = await _poll_for_reply(client, request_id)
        return {"reply": reply}


@mcp.tool()
async def send_media(
    media_type: str,
    url: str,
    caption: str | None = None,
) -> dict:
    """
    Send media (photo, video, audio, document) to the user via Telegram.

    Args:
        media_type: Type of media - "photo", "video", "audio", or "document"
        url: URL of the media file to send
        caption: Optional caption for the media

    Returns:
        message_id: The Telegram message ID

    Examples:
    - send_media("photo", "https://example.com/image.jpg", "Look at this!")
    - send_media("video", "https://example.com/video.mp4")
    - send_media("audio", "https://example.com/audio.mp3", "Here's the recording")
    - send_media("document", "https://example.com/file.pdf", "The report")
    """
    if not CHAT_ID:
        raise RuntimeError("TELEGRAM_CHAT_ID environment variable required")

    if media_type not in ["photo", "video", "audio", "document"]:
        raise ValueError("media_type must be one of: photo, video, audio, document")

    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            f"{SERVER_URL}/api/media",
            headers={"X-Chat-Id": CHAT_ID},
            json={
                "type": media_type,
                "url": url,
                "caption": caption,
            },
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"Server error: {response.text}")
        
        return response.json()


@mcp.tool()
async def get_file_url(file_id: str) -> dict:
    """
    Get the download URL for a file from its Telegram file_id.

    When a user sends media (photo, video, audio, document), you receive
    a file_id in the reply. Use this to get the actual download URL.

    Args:
        file_id: The Telegram file_id

    Returns:
        url: The download URL for the file
    """
    if not CHAT_ID:
        raise RuntimeError("TELEGRAM_CHAT_ID environment variable required")

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            f"{SERVER_URL}/api/file",
            headers={"X-Chat-Id": CHAT_ID},
            params={"file_id": file_id},
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"Server error: {response.text}")
        
        return response.json()


@mcp.tool()
async def get_messages(limit: int = 10) -> dict:
    """
    Get recent Telegram conversation history.

    Args:
        limit: Number of messages (1-50, default 10).

    Returns:
        messages: List of recent messages.
    """
    if not CHAT_ID:
        raise RuntimeError("TELEGRAM_CHAT_ID environment variable required")

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(
            f"{SERVER_URL}/api/messages",
            headers={"X-Chat-Id": CHAT_ID},
            params={"limit": limit},
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"Server error: {response.text}")
        
        return response.json()


def main():
    """Run the MCP server."""
    if not CHAT_ID:
        logger.error("TELEGRAM_CHAT_ID environment variable required")
        sys.exit(1)
    
    logger.info(f"Starting Telegram MCP (server: {SERVER_URL}, chat_id: {CHAT_ID})")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
