import re

from setuptools import find_packages
from setuptools import setup

# Read version from package
with open("src/vaultdb/__init__.py") as fh:
    version_line = [line for line in fh.readlines() if line.startswith("__version__")]
    if version_line:
        version = re.search(r'"([\d\.]+)"', version_line[0]).group(1)
    else:
        version = "0.1"

with open("PYPI_README.md") as f:
    long_description = f.read()

# ==============================================================================
# Extension Support
# ==============================================================================
# We check if we can build C extensions, but we don't force it.
# The legacy sqlite extensions from peewee are removed as they are not in src.
ext_modules = []

# ==============================================================================
# Setup
# ==============================================================================
setup(
    name="vaultdb.core",
    version=version,
    description="Vaultdb Core platform.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Dev M Chechi",
    author_email="devmchechi@gmail.com",
    url="https://github.com/vaultdbai/vaultdb",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        "peewee>=3.17.0",
        "python-dateutil>=2.8.2",
        "pytz>=2023.3",
        "boto3>=1.34.0",
        "vaultdb>=0.10.3.dev1901",
        "pandas>=2.0.0",
    ],
    extras_require={
        "service": [
            "celery>=5.3.6",
            "redis>=5.0.1",
            "flower>=2.0.1",
        ],
        "web": [
            "fastapi>=0.109.0",
            "uvicorn[standard]>=0.27.0",
            "httpx>=0.27.0",
        ],
        "dev": [
            "ruff",
            "mypy",
            "pytest",
            "pytest-cov",
            "time-machine",
            "wheel",
            "twine",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    license="Proprietary - Free use for one year, no replication or sale permitted",
    python_requires=">=3.11",
)
