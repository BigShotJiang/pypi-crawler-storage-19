# VaultDB Core

VaultDB is a compute and application framework platform and database system designed to run jobs, Python-based UI, and compute-intensive workloads. It provides a unified interface for task execution across multiple runners (Celery, AWS Lambda, AWS Batch) and supports flexible authentication methods.

## Features

### Core Capabilities
- **Multi-Database Support**: PostgreSQL (production) and SQLite (development/testing)
- **DuckDB Integration**: High-performance analytics database with S3 integration (uses 'vaultdb' package with modified DuckDB)
- **Task Execution**: Unified interface for Celery, AWS Lambda, and AWS Batch runners
- **Task Scheduling**: Support for Celery scheduler and AWS EventBridge
- **Business Calendar**: Custom holiday configurations and business day scheduling
- **Caching**: Intermediate run checkpoints for failure recovery

### Authentication Methods
- **Basic Authentication**: Simple authentication for local development
- **AWS Cognito**: Full AWS Cognito integration for user authentication
- **OAuth 2.0**: Support for any OAuth 2.0 provider (Google, GitHub, Microsoft, custom providers)
  - Authorization code flow
  - Token refresh
  - Automatic AWS credential management
  - AWS profile creation for local development

## Installation

### Prerequisites
- Python 3.11 or higher
- pip

### Install from Source

```bash
# Clone the repository
git clone <repository-url>
cd vaultdb

# Install in development mode
pip install -e .

# Install development dependencies
pip install -r requirements.txt
```

## Quick Start

### Basic Setup

```python
from vaultdb.core import Application, AuthType

# Local development with basic authentication
Application.connect(
    database="my_app.db",
    role="vaultdb",
    auth=AuthType.BASIC
)
```

### OAuth 2.0 Authentication

```python
from vaultdb.core import Application, AuthType

# Configure OAuth 2.0 via environment variables
import os
os.environ["oauth2_client_id"] = "your-client-id"
os.environ["oauth2_client_secret"] = "your-client-secret"
os.environ["oauth2_authorization_url"] = "https://oauth.provider.com/authorize"
os.environ["oauth2_token_url"] = "https://oauth.provider.com/token"
os.environ["oauth2_redirect_uri"] = "http://localhost:8080/callback"

# Connect with OAuth 2.0
Application.connect(
    database="my_database",
    role="vaultdb",
    auth=AuthType.OAUTH2,
    oauth2_authorization_code="code-from-oauth-provider"
)
```

### AWS Cognito Authentication

```python
from vaultdb.core import Application, AuthType

Application.connect(
    database="my_database",
    role="vaultdb",
    username="user@example.com",
    password="password",
    auth=AuthType.COGNITO
)
```

## Authentication Methods

### 1. Basic Authentication

Simple authentication for local development and testing. No external dependencies required.

```python
Application.connect(
    database=":memory:",
    role="vaultdb",
    auth=AuthType.BASIC
)
```

### 2. AWS Cognito Authentication

Full integration with AWS Cognito for user authentication and AWS credential management.

**Environment Variables:**
```bash
export user_pool_id="us-east-1_XXXXXXXXX"
export user_pool_app_client_id="your-client-id"
export user_identity_pool_id="us-east-1:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
export user_bucket="your-s3-bucket"
```

**Usage:**
```python
Application.connect(
    database="my_database",
    role="vaultdb",
    username="user@example.com",
    password="password",
    auth=AuthType.COGNITO
)
```

### 3. OAuth 2.0 Authentication

Support for any OAuth 2.0 provider with automatic AWS credential management.

**Environment Variables:**
```bash
export oauth2_client_id="your-client-id"
export oauth2_client_secret="your-client-secret"
export oauth2_authorization_url="https://oauth.provider.com/authorize"
export oauth2_token_url="https://oauth.provider.com/token"
export oauth2_redirect_uri="http://localhost:8080/callback"
export oauth2_scope="openid profile email"
export oauth2_aws_profile_name="vaultdb-oauth"  # Optional
```

**Usage Options:**

**Authorization Code Flow:**
```python
from vaultdb.auth import OAuth2Authenticator

authenticator = OAuth2Authenticator(
    client_id="your-client-id",
    client_secret="your-client-secret",
    authorization_url="https://oauth.provider.com/authorize",
    token_url="https://oauth.provider.com/token",
    redirect_uri="http://localhost:8080/callback",
)

# Get authorization URL
auth_url = authenticator.get_authorization_url()
print(f"Visit: {auth_url}")

# After user authenticates
Application.connect(
    database="my_database",
    role="vaultdb",
    auth=AuthType.OAUTH2,
    oauth2_authorization_code="code-from-provider"
)
```

**Direct Token:**
```python
Application.connect(
    database="my_database",
    role="vaultdb",
    auth=AuthType.OAUTH2,
    oauth2_access_token="your-access-token",
    oauth2_refresh_token="your-refresh-token"
)
```

**Direct AWS Credentials:**
```python
Application.connect(
    database="my_database",
    role="vaultdb",
    auth=AuthType.OAUTH2,
    oauth2_aws_access_key_id="AKIAIOSFODNN7EXAMPLE",
    oauth2_aws_secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    oauth2_aws_session_token="session-token"  # Optional
)
```

**AWS Profile Management:**
When OAuth returns AWS credentials, VaultDB automatically:
- Creates an AWS profile in `~/.aws/credentials`
- Sets secure file permissions (600)
- Enables boto3 and AWS CLI to use the credentials
- Supports local-to-AWS job submission and S3 operations

## Task Execution

VaultDB provides a unified interface for task execution across multiple runners:

```python
from vaultdb import TED

# Define a task
@TED.task()
def my_task(x: int, y: int) -> int:
    """Add two numbers."""
    return x + y

# Submit task
result = my_task.apply_async(args=(5, 10))
print(f"Task ID: {result.task_id}")
print(f"Status: {result.status}")
```

## Configuration

### Environment Variables

**Database Configuration:**
- `DEBUG=True`: Use SQLite for local development
- `TESTING=True`: Use SQLite for testing
- `vaultdb_user`: Database username
- `vaultdb_password`: Database password

**AWS Configuration:**
- `AWS_DEFAULT_REGION`: AWS region (default: "us-east-1")
- `user_bucket`: S3 bucket name

**Cognito Configuration:**
- `user_pool_id`: Cognito user pool ID
- `user_pool_app_client_id`: Cognito app client ID
- `user_identity_pool_id`: Cognito identity pool ID

**OAuth 2.0 Configuration:**
- `oauth2_client_id`: OAuth 2.0 client ID
- `oauth2_client_secret`: OAuth 2.0 client secret
- `oauth2_authorization_url`: OAuth authorization endpoint
- `oauth2_token_url`: OAuth token endpoint
- `oauth2_redirect_uri`: OAuth redirect URI
- `oauth2_scope`: OAuth scopes (default: "openid profile email")
- `oauth2_aws_profile_name`: AWS profile name (default: "vaultdb-oauth")

**Task Runner Configuration:**
- `redis_broker`: Redis broker URL for Celery
- `redis_cache_url`: Redis cache URL
- `compute_lambda_function_name`: AWS Lambda function name
- `celery_broker_url`: Celery broker URL

## Documentation

- **[OAuth 2.0 Authentication Guide](docs/oauth2_authentication_guide.md)**: Complete guide for OAuth 2.0 authentication
- **[Data Module Usage Guide](docs/data_module_usage_guide.md)**: Database operations and configuration
- **[Task Runners Integration Guide](docs/task_runners_integration_guide.md)**: Task execution across different runners
- **[Task Scheduling](docs/task_scheduling.md)**: Scheduling tasks with Celery and EventBridge

## Development

### Code Quality

```bash
# Format code
ruff format .

# Lint code
ruff check .

# Type checking
mypy src/

# Fix auto-fixable issues
ruff check --fix .
```

### Testing

```bash
# Run all tests
python -m pytest

# Run with verbose output
python -m pytest -v

# Run specific test file
python -m pytest tests/auth/test_oauth2.py

# Run with coverage
python -m pytest --cov=src/vaultdb
```

### Project Structure

```
vaultdb/
├── src/vaultdb/          # Source code
│   ├── auth/            # Authentication modules
│   │   ├── base.py      # Base authenticator
│   │   ├── cognito.py   # Cognito authenticator
│   │   └── oauth2.py    # OAuth 2.0 authenticator
│   ├── compute/         # Task execution
│   ├── data/            # Database layer
│   ├── web/             # Web API
│   └── core.py          # Application core
├── tests/               # Test suite
├── docs/                # Documentation
└── README.md            # This file
```

## Architecture

### Key Components

1. **Database Layer**: Peewee ORM with VaultdbDatabase (DuckDB via 'vaultdb' package with modified DuckDB) and PostgreSQL support
2. **Task Runners**: Unified interface for Celery, AWS Lambda, and AWS Batch
3. **Authentication**: Multiple authentication methods (Basic, Cognito, OAuth 2.0)
4. **Scheduling**: Celery scheduler and AWS EventBridge integration
5. **Calendar System**: Business day scheduling with custom holiday support

### Authentication Flow

- **Local Development**: Uses Basic or OAuth 2.0 authentication
- **Cloud Deployment**: Uses IAM roles (no authentication needed)
- **Hybrid**: OAuth 2.0 can provide AWS credentials for local-to-cloud operations

## Security Considerations

- **Credentials**: Never commit secrets to version control
- **OAuth**: Always use HTTPS in production, validate redirect URIs
- **AWS Profiles**: Automatically set to 600 permissions (owner read/write only)
- **Token Storage**: Store tokens securely, implement token refresh

## Contributing

1. Follow Test-Driven Development (TDD) principles
2. Include type hints for all functions
3. Add docstrings for all modules, classes, and public functions
4. Maintain 90%+ test coverage
5. Follow PEP 8 style guidelines (160 char line length)

## License

Proprietary License - Free use for one year. Replication and sale are not permitted.

See [LICENSE](LICENSE) file for full terms and conditions.

## Support

For issues, questions, or contributions, please refer to the project documentation or open an issue in the repository.
