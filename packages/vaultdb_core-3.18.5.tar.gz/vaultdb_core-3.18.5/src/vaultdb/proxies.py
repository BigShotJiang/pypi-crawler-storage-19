__all__ = ["DuckDBPyConnection"]

try:
    # Try is used for debugging as duckdb package maynot be built yet
    from duckdb import DuckDBPyConnection
except Exception:
    print("duckdb not available")

    class DuckDBPyConnection:
        def __str__(self) -> str:
            return f"{self.__class__.__name__}"

        def __repr__(self) -> str:
            return f"{self.__class__.__name__}()"
