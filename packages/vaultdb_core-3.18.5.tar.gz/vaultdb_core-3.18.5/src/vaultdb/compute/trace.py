import logging
import sys
import traceback
import uuid
from typing import Any

from .exceptions import IgnoreError
from .exceptions import RejectError
from .exceptions import RetryError
from .task import Context
from .task import Task

logger = logging.getLogger(__name__)


class TraceInfo:
    def __init__(self, exc_info: tuple[Any, Any, Any]) -> None:
        self.exc_info = exc_info
        if exc_info and exc_info[0]:
            self.traceback = "".join(traceback.format_exception(*exc_info))
        else:
            self.traceback = None


class TaskTracer:
    def __init__(self, task: Task) -> None:
        self.task = task

    def __call__(
        self,
        *args: Any,
        task_id: str | None = None,
        **kwargs: Any,
    ) -> Any:
        # 1. Setup Request/Context
        if task_id is None:
            task_id = str(uuid.uuid4())

        # Create a new Context for this execution
        request = Context(
            id=task_id,
            args=args,
            kwargs=kwargs,
            hostname=kwargs.get("hostname"),
        )
        self.task.request = request

        # 2. Before Start
        self.task.before_start(task_id, args, kwargs)

        retval = None
        state = "FAILURE"
        einfo = None

        try:
            # 3. Execution using __call__ (which handles DB context)
            retval = self.task(*args, **kwargs)
            state = "SUCCESS"
            self.task.on_success(retval, task_id, args, kwargs)
            return retval

        except RetryError as exc:
            state = "RETRY"
            einfo = TraceInfo(sys.exc_info())
            self.task.on_retry(exc, task_id, args, kwargs, einfo)
            raise

        except IgnoreError:
            state = "IGNORED"
            # No handler for on_ignore in BaseTask
            raise

        except RejectError:
            state = "REJECTED"
            # No handler for on_reject in BaseTask
            raise

        except Exception as exc:
            state = "FAILURE"
            einfo = TraceInfo(sys.exc_info())
            self.task.on_failure(exc, task_id, args, kwargs, einfo)
            raise

        finally:
            try:
                self.task.after_return(state, retval, task_id, args, kwargs, einfo)
            except Exception as exc:
                logger.error(f"Error in after_return: {exc}", exc_info=True)
