"""
TaskStatus Peewee model for tracking task execution status.

This module defines the TaskStatus model that tracks the execution status,
arguments, results, and metadata for tasks in the VaultDB compute system.
"""

import datetime
import uuid
from typing import Any
from typing import Optional

from peewee import CharField
from peewee import DateTimeField
from peewee import FloatField
from peewee import IntegerField
from peewee import TextField

from .. import config
from ..data.vaultdb import VaultdbModel


class TaskStatus(VaultdbModel):
    """
    TaskStatus model for tracking task execution status and metadata.

    This model stores comprehensive information about task execution including:
    - Task identification and routing information
    - Execution status and timing
    - Arguments, results, and error information
    - Retry counts and worker information
    - Parent/child task relationships

    Based on the BaseTask._upsert_taskstatus method, this model captures
    all the fields used in task status tracking.
    """

    # Primary key
    # Use UUID string as primary key to avoid DuckDB auto-increment issues
    # and constraint violations when updating row with task_id as PK
    id = CharField(primary_key=True, default=lambda: str(uuid.uuid4()))

    # Task identification
    task_id = CharField(max_length=255, unique=True, help_text="Unique identifier for the task")
    name = CharField(max_length=255, help_text="Name of the task")

    # Task status and execution information
    status = CharField(max_length=50, help_text="Current status of the task (PENDING, STARTED, SUCCESS, FAILURE, RETRY, REVOKED)")

    # Task arguments and results (stored as JSON strings)
    args = TextField(null=True, help_text="Task arguments as JSON string")
    kwargs = TextField(null=True, help_text="Task keyword arguments as JSON string")
    result = TextField(null=True, help_text="Task result as JSON string")
    traceback = TextField(null=True, help_text="Error traceback if task failed")

    # Retry and worker information
    retries = IntegerField(default=0, help_text="Number of retries attempted")
    worker_id = CharField(max_length=255, null=True, help_text="ID of the worker that executed the task")

    # Task scheduling and timing
    eta = DateTimeField(null=True, help_text="Estimated time of arrival for task execution")
    expires = DateTimeField(null=True, help_text="Task expiration time")
    date_created = DateTimeField(default=datetime.datetime.now, help_text="When the task was created")
    date_done = DateTimeField(null=True, help_text="When the task completed")
    runtime = FloatField(null=True, help_text="Task execution time in seconds")

    # Task hierarchy and relationships
    parent_id = CharField(max_length=255, null=True, help_text="ID of the parent task")
    root_id = CharField(max_length=255, null=True, help_text="ID of the root task in the hierarchy")

    # Message routing information
    queue = CharField(max_length=255, null=True, help_text="Queue name for task routing")
    exchange = CharField(max_length=255, null=True, help_text="Exchange name for task routing")
    routing_key = CharField(max_length=255, null=True, help_text="Routing key for task routing")

    def save(self, *args: Any, **kwargs: Any) -> int:
        """Override save to handle DuckDB constraint errors."""
        try:
            return super().save(*args, **kwargs)
        except Exception as e:
            # Check for DuckDB Constraint Exception (Duplicate key)
            if "Constraint Error" in str(e) and "Duplicate key" in str(e):
                # Workaround: Delete and Re-insert
                try:
                    self.delete_instance()
                except Exception:
                    pass
                return super().save(force_insert=True)
            raise

    class Meta:
        database = config.vaultdb_proxy
        table_name = "task_status"
        indexes = (
            # Index on status for filtering by status
            (("status",), False),
            # Index on worker_id for worker-specific queries
            (("worker_id",), False),
            # Index on parent_id for task hierarchy queries
            (("parent_id",), False),
            # Index on root_id for root task queries
            (("root_id",), False),
            # Index on date_created for time-based queries
            (("date_created",), False),
            # Index on date_done for completion time queries
            (("date_done",), False),
            # Composite index for status and date queries
            (("status", "date_created"), False),
        )

    def __str__(self) -> str:
        """String representation of TaskStatus."""
        return f"TaskStatus(task_id={self.task_id}, status={self.status}, name={self.name})"

    def __repr__(self) -> str:
        """Detailed representation of TaskStatus."""
        return f"TaskStatus(task_id='{self.task_id}', name='{self.name}', status='{self.status}', retries={self.retries}, worker_id='{self.worker_id}')"

    @property
    def is_completed(self) -> bool:
        """Check if the task is in a completed state."""
        return self.status in {"SUCCESS", "FAILURE", "REVOKED"}

    @property
    def is_running(self) -> bool:
        """Check if the task is currently running."""
        return self.status in {"PENDING", "STARTED", "RETRY"}

    @property
    def is_successful(self) -> bool:
        """Check if the task completed successfully."""
        return self.status == "SUCCESS"

    @property
    def is_failed(self) -> bool:
        """Check if the task failed."""
        return self.status == "FAILURE"

    @property
    def is_retrying(self) -> bool:
        """Check if the task is in retry state."""
        return self.status == "RETRY"

    @property
    def execution_time(self) -> float | None:
        """Get the task execution time in seconds."""
        if self.date_done and self.date_created:
            return (self.date_done - self.date_created).total_seconds()
        return self.runtime

    @classmethod
    def get_by_task_id(cls, task_id: str) -> Optional["TaskStatus"]:
        """Get TaskStatus by task_id."""
        try:
            return cls.get(cls.task_id == task_id)
        except cls.DoesNotExist:
            return None

    @classmethod
    def get_active_tasks(cls) -> list["TaskStatus"]:
        """Get all currently active (running) tasks."""
        return list(cls.select().where(cls.status.in_(["PENDING", "STARTED", "RETRY"])))

    @classmethod
    def get_completed_tasks(cls) -> list["TaskStatus"]:
        """Get all completed tasks."""
        return list(cls.select().where(cls.status.in_(["SUCCESS", "FAILURE", "REVOKED"])))

    @classmethod
    def get_failed_tasks(cls) -> list["TaskStatus"]:
        """Get all failed tasks."""
        return list(cls.select().where(cls.status == "FAILURE"))

    @classmethod
    def get_tasks_by_worker(cls, worker_id: str) -> list["TaskStatus"]:
        """Get all tasks executed by a specific worker."""
        return list(cls.select().where(cls.worker_id == worker_id))

    @classmethod
    def get_child_tasks(cls, parent_id: str) -> list["TaskStatus"]:
        """Get all child tasks of a parent task."""
        return list(cls.select().where(cls.parent_id == parent_id))

    @classmethod
    def get_root_tasks(cls, root_id: str) -> list["TaskStatus"]:
        """Get all tasks belonging to a root task."""
        return list(cls.select().where(cls.root_id == root_id))

    def update_status(self, status: str, **kwargs: Any) -> None:
        """Update task status and related fields."""
        self.status = status

        # Update optional fields if provided
        if "result" in kwargs:
            self.result = kwargs["result"]
        if "traceback" in kwargs:
            self.traceback = kwargs["traceback"]
        if "worker_id" in kwargs:
            self.worker_id = kwargs["worker_id"]
        if "retries" in kwargs:
            self.retries = kwargs["retries"]

        # Set completion time for terminal states
        if status in {"SUCCESS", "FAILURE", "REVOKED"}:
            self.date_done = datetime.datetime.now()
            if self.date_created:
                # Ensure both datetimes are timezone-aware or both are naive
                done_dt = self.date_done if self.date_done.tzinfo is None else self.date_done.replace(tzinfo=None)
                created_dt = self.date_created if self.date_created.tzinfo is None else self.date_created.replace(tzinfo=None)
                delta = (done_dt - created_dt).total_seconds()
                self.runtime = max(delta, 0.0)

        # Update attributes directly
        if "args" in kwargs:
            self.args = kwargs["args"]
        if "kwargs" in kwargs:
            self.kwargs = kwargs["kwargs"]
        if "result" in kwargs:
            self.result = kwargs["result"]
        if "traceback" in kwargs:
            self.traceback = kwargs["traceback"]
        if "worker_id" in kwargs:
            self.worker_id = kwargs["worker_id"]
        if "retries" in kwargs:
            self.retries = kwargs["retries"]

        self.save()

    def increment_retry(self) -> None:
        """Increment the retry count."""
        self.retries = (self.retries or 0) + 1
        self.save()

    def set_worker(self, worker_id: str) -> None:
        """Set the worker ID for this task."""
        self.worker_id = worker_id
        self.save()

    def set_parent(self, parent_id: str) -> None:
        """Set the parent task ID."""
        self.parent_id = parent_id
        self.save()

    def set_root(self, root_id: str) -> None:
        """Set the root task ID."""
        self.root_id = root_id
        self.save()

    def set_routing(self, queue: str | None = None, exchange: str | None = None, routing_key: str | None = None) -> None:
        """Set routing information for the task."""
        if queue is not None:
            self.queue = queue
        if exchange is not None:
            self.exchange = exchange
        if routing_key is not None:
            self.routing_key = routing_key
        self.save()
