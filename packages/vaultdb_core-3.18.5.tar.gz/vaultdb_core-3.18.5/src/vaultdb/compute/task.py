"""Task implementation: request context and the task base class."""

import datetime
import json
from collections.abc import Iterable
from typing import Any

from .. import config
from .._state import current_app
from ..core import Application
from ..local import ClassProperty
from ..logger import get_logger
from .exceptions import MaxRetriesExceededError
from .exceptions import OperationalError
from .taskstatus import TaskStatus

# Use named logger for compute module
logger = get_logger(config.LOGGER_COMPUTE)

__all__ = ("Context", "Task")


class BaseTask:
    abstract = True
    name: str | None = None
    request: Any = None
    __name__: str = ""

    # ---- TaskStatus upsert helpers and event hooks ----
    def _json_dumps(self, value: Any) -> str | None:
        try:
            if value is None:
                return None
            return json.dumps(value, default=str)
        except Exception:
            return str(value)

    def _extract_routing(self) -> dict[str, str | None]:
        return {}

    def _upsert_taskstatus(
        self,
        *,
        task_id: str,
        status: str,
        args: tuple[Any, ...] | None = None,
        kwargs: dict[str, Any] | None = None,
        result: Any | None = None,
        traceback_text: str | None = None,
        inc_retry: bool = False,
        set_date_done: bool = False,
    ) -> None:
        now = datetime.datetime.now(datetime.UTC)
        defaults: dict[str, Any] = {
            "name": self.name or self.__name__,
            "status": status,
            "args": self._json_dumps(args),
            "kwargs": self._json_dumps(kwargs),
            "result": self._json_dumps(result),
            "traceback": traceback_text,
            "retries": getattr(self.request, "retries", 0) or 0,
            "worker_id": getattr(self.request, "hostname", None),
            "eta": getattr(self.request, "eta", None),
            "expires": getattr(self.request, "expires", None),
            "parent_id": getattr(self.request, "parent_id", None),
            "root_id": getattr(self.request, "root_id", None),
            **self._extract_routing(),
        }

        ts, created = TaskStatus.get_or_create(task_id=task_id, defaults=defaults)
        if not created:
            # Update existing record
            ts.status = status
            if args is not None:
                ts.args = defaults["args"]
            if kwargs is not None:
                ts.kwargs = defaults["kwargs"]
            if result is not None:
                ts.result = defaults["result"]
            if traceback_text is not None:
                ts.traceback = traceback_text
            ts.worker_id = defaults["worker_id"]
            ts.parent_id = defaults["parent_id"]
            ts.root_id = defaults["root_id"]
            ts.queue = defaults.get("queue")
            ts.exchange = defaults.get("exchange")
            ts.routing_key = defaults.get("routing_key")
            if inc_retry:
                ts.retries = (ts.retries or 0) + 1
            else:
                ts.retries = defaults["retries"]
        if set_date_done:
            # date_created may be None for legacy rows; ensure runtime computed safely
            ts.date_done = now
            if ts.date_created:
                # Normalize both datetimes to naive to avoid timezone mismatch
                # (SQLite stores naive datetimes, but we use UTC-aware now)
                created_dt = ts.date_created.replace(tzinfo=None) if ts.date_created.tzinfo else ts.date_created
                now_naive = now.replace(tzinfo=None) if now.tzinfo else now
                delta = (now_naive - created_dt).total_seconds()
                ts.runtime = max(delta, 0.0)
        ts.save()

    def before_start(self, task_id: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        """Handler called before the task starts."""
        logger.info(f"Task {task_id} starting: {self.name or self.__name__}")
        logger.debug(f"Task {task_id} args: {args}, kwargs: {kwargs}")
        self._upsert_taskstatus(task_id=task_id, status="STARTED", args=args, kwargs=kwargs)

    def on_success(self, retval: Any, task_id: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        """Success handler."""
        logger.info(f"Task {task_id} succeeded")
        logger.debug(f"Task {task_id} result: {retval}")
        self._upsert_taskstatus(task_id=task_id, status="SUCCESS", result=retval, set_date_done=True)

    def on_retry(self, exc: BaseException, task_id: str, args: tuple[Any, ...], kwargs: dict[str, Any], einfo: Any) -> None:
        """Retry handler."""
        logger.warning(f"Task {task_id} retrying: {exc}")
        tb_text = getattr(einfo, "traceback", None) if einfo is not None else None
        self._upsert_taskstatus(task_id=task_id, status="RETRY", traceback_text=tb_text, inc_retry=True)

    def on_failure(self, exc: BaseException, task_id: str, args: tuple[Any, ...], kwargs: dict[str, Any], einfo: Any) -> None:
        """Error handler."""
        logger.error(f"Task {task_id} failed: {exc}")
        logger.debug(f"Task {task_id} failure traceback: {einfo}")
        tb_text = getattr(einfo, "traceback", None) if einfo is not None else None
        self._upsert_taskstatus(task_id=task_id, status="FAILURE", result=str(exc), traceback_text=tb_text, set_date_done=True)

    def after_return(self, status: str, retval: Any, task_id: str, args: tuple[Any, ...], kwargs: dict[str, Any], einfo: Any) -> None:
        """Handler called after the task returns."""
        # Ensure final status/date_done/runtime are recorded regardless of path
        logger.debug(f"Task {task_id} completed with status: {status}")
        tb_text = getattr(einfo, "traceback", None) if einfo is not None else None
        set_done = status in {"SUCCESS", "FAILURE", "REVOKED"}
        self._upsert_taskstatus(task_id=task_id, status=status, result=retval if status == "SUCCESS" else None, traceback_text=tb_text, set_date_done=set_done)


def mattrgetter(*attrs: tuple[str, ...]) -> Any:
    """Get attributes, ignoring attribute errors.

    Like :func:`operator.itemgetter` but return :const:`None` on missing
    attributes instead of raising :exc:`AttributeError`.
    """
    return lambda obj: {attr: getattr(obj, attr, None) for attr in attrs}


#: extracts attributes related to publishing a message from an object.
extract_exec_options = mattrgetter(
    "queue",
    "routing_key",
    "exchange",
    "priority",
    "expires",
    "serializer",
    "delivery_mode",
    "compression",
    "time_limit",
    "soft_time_limit",
    "immediate",
    "mandatory",  # imm+man is deprecated
)

# We take __repr__ very seriously around here ;)
R_BOUND_TASK = "<class {0.__name__} of {app}{flags}>"
R_UNBOUND_TASK = "<unbound {0.__name__}{flags}>"
R_INSTANCE = "<@task: {0.name} of {app}{flags}>"

#: Here for backwards compatibility as tasks no longer use a custom meta-class.
TaskType = type


def _strflags(flags: Iterable, default: str = "") -> str:
    if flags:
        return " ({})".format(", ".join(flags))
    return default


def appstr(app: Any) -> str:
    """String used in __repr__ etc, to id app instances."""
    return f"{app.main or '__main__'} at {id(app):#x}"


def _reprtask(task: Any, fmt: Any = None, flags: Any = None) -> str:
    flags = list(flags) if flags is not None else []
    flags.append("v2 compatible") if task.__v2_compat__ else None
    if not fmt:
        fmt = R_BOUND_TASK if task._app else R_UNBOUND_TASK
    return fmt.format(
        task,
        flags=_strflags(flags),
        app=appstr(task._app) if task._app else None,
    )


class Context:
    """Task request variables (Task.request)."""

    _children: list[Any] | None = None  # see property
    _protected: int = 0
    args: tuple[Any, ...] | None = None
    callbacks: list[Any] | None = None
    called_directly: bool = True
    chain: list[Any] | None = None
    chord: Any = None
    correlation_id: str | None = None
    delivery_info: dict[str, Any] | None = None
    errbacks: list[Any] | None = None
    eta: Any = None
    expires: Any = None
    group: str | None = None
    group_index: int | None = None
    headers: dict[str, Any] | None = None
    hostname: str | None = None
    id: str | None = None
    ignore_result: bool = False
    is_eager: bool = False
    kwargs: dict[str, Any] | None = None
    logfile: str | None = None
    loglevel: int | None = None
    origin: str | None = None
    parent_id: str | None = None
    properties: dict[str, Any] | None = None
    retries: int = 0
    reply_to: str | None = None
    replaced_task_nesting: int = 0
    root_id: str | None = None
    shadow: str | None = None
    taskset: str | None = None  # compat alias to group
    timelimit: tuple[float | None, float | None] | None = None
    utc: bool | None = None
    stamped_headers: Any = None
    stamps: Any = None

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.update(*args, **kwargs)
        if self.headers is None:
            self.headers = self._get_custom_headers(*args, **kwargs)

    def _get_custom_headers(self, *args: Any, **kwargs: Any) -> dict[str, Any] | None:
        headers = {}
        headers.update(*args, **kwargs)
        service_keys = {*Context.__dict__.keys(), "lang", "task", "argsrepr", "kwargsrepr", "compression"}
        for key in service_keys:
            headers.pop(key, None)
        if not headers:
            return None
        return headers

    def update(self, *args: Any, **kwargs: Any) -> None:
        self.__dict__.update(*args, **kwargs)

    def clear(self) -> None:
        self.__dict__.clear()

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)

    def __repr__(self) -> str:
        return f"<Context: {vars(self)!r}>"

    def as_execution_options(self) -> dict:
        limit_hard, limit_soft = self.timelimit or (None, None)
        execution_options = {
            "task_id": self.id,
            "root_id": self.root_id,
            "parent_id": self.parent_id,
            "group_id": self.group,
            "group_index": self.group_index,
            "shadow": self.shadow,
            "chord": self.chord,
            "chain": self.chain,
            "link": self.callbacks,
            "link_error": self.errbacks,
            "expires": self.expires,
            "soft_time_limit": limit_soft,
            "time_limit": limit_hard,
            "headers": self.headers,
            "retries": self.retries,
            "reply_to": self.reply_to,
            "replaced_task_nesting": self.replaced_task_nesting,
            "origin": self.origin,
        }
        if hasattr(self, "stamps") and hasattr(self, "stamped_headers"):
            if self.stamps is not None and self.stamped_headers is not None:
                execution_options["stamped_headers"] = self.stamped_headers
                for k, v in self.stamps.items():
                    execution_options[k] = v
        return execution_options

    @property
    def children(self) -> list[Any]:
        # children must be an empty list for every thread
        if self._children is None:
            self._children = []
        return self._children


class Task(BaseTask):
    """Task base class.

    Note:
        When called tasks apply the :meth:`run` method.  This method must
        be defined by all tasks (that is unless the :meth:`__call__` method
        is overridden).
    """

    __trace__ = None
    __v2_compat__ = False  # set by old base in service layer (Celery)

    MaxRetriesExceededError = MaxRetriesExceededError
    OperationalError = OperationalError

    #: The application instance associated with this task class.
    _app = None

    #: Name of the task.
    name = None

    #: Enable argument checking.
    #: You can set this to false if you don't want the signature to be
    #: checked when calling the task.
    #: Defaults to :attr:`app.strict_typing <@Service.strict_typing>`.
    typing = None

    #: Maximum number of retries before giving up.  If set to :const:`None`,
    #: it will **never** stop retrying.
    max_retries = 3

    #: Default time in seconds before a retry of the task should be
    #: executed.  3 minutes by default.
    default_retry_delay = 3 * 60

    #: If enabled the worker won't store task state and return values
    #: for this task.  Defaults to the :setting:`task_ignore_result`
    #: setting.
    ignore_result = None

    #: If enabled the request will keep track of subtasks started by
    #: this task, and this information will be sent with the result
    #: (``result.children``).
    trail = True

    #: Hard time limit.
    #: Defaults to the :setting:`task_time_limit` setting.
    time_limit = None

    #: Soft time limit.
    #: Defaults to the :setting:`task_soft_time_limit` setting.
    soft_time_limit = None

    #: Tuple of expected exceptions.
    #:
    #: These are errors that are expected in normal operation
    #: and that shouldn't be regarded as a real error by the worker.
    #: Currently this means that the state will be updated to an error
    #: state, but the worker won't log the event as an error.
    throws = ()

    #: Default task priority.
    priority = None

    #: Some may expect a request to exist even if the task hasn't been
    #: called.  This should probably be deprecated.
    _default_request = None

    _exec_options = None

    @classmethod
    def _get_app(cls) -> Any:
        if cls._app is None:
            cls._app = current_app
        return cls._app

    @classmethod
    def _set_app(cls, app: Any) -> None:
        cls._app = app

    app = ClassProperty(_get_app, _set_app)

    def __call__(self, *args, **kwargs) -> Any:
        """
        Executes the task, ensuring a database connection is established
        and properly closed using the Application's context manager.

        Args:
            *args: Positional arguments passed to the task's `run` method.
            **kwargs: Keyword arguments passed to the task's `run` method,
                      potentially including `vaultdb_` prefixed connection parameters.

        Returns:
            Any: The result of the task's `run` method.
        """
        # Extract potential connection parameters from kwargs.
        # These will be popped to avoid passing them to the underlying run method
        # unless the run method itself is designed to handle them.
        _catalog: str | None = kwargs.pop("vaultdb_catalog", None)
        _role: str | None = kwargs.pop("vaultdb_role", None)
        _config: dict[str, Any] | None = kwargs.pop("vaultdb_connectionconfig", None)
        _clone: bool = kwargs.pop("vaultdb_clone", True)

        # Determine if `execute_as` is needed based on explicit credential/role/config parameters.
        use_execute_as: bool = any([_catalog, _role, _config])
        execute_as_kwargs: dict[str, Any] = {}

        if use_execute_as:
            # Prepare arguments for `execute_as`. Only pass explicitly provided values.
            if _catalog is not None:
                execute_as_kwargs["catalog"] = _catalog
            if _role is not None:
                execute_as_kwargs["role"] = _role
            if _config is not None:
                execute_as_kwargs["config"] = _config
            with Application.execute_as(**execute_as_kwargs):
                return self.run(*args, **kwargs)

        return self.run(*args, **kwargs)

    def run(self, *args, **kwargs) -> Any:
        """The body of the task executed by workers."""
        raise NotImplementedError("Tasks must define the run method.")

    def delay(self, *args, **kwargs) -> Any:
        """Star argument version of :meth:`apply_async`.

        Does not support the extra options enabled by :meth:`apply_async`.

        Arguments:
            *args (Any): Positional arguments passed on to the task.
            **kwargs (Any): Keyword arguments passed on to the task.
        Returns:
            service.result.AsyncResult: Future promise (Celery).
        """
        return self.apply_async(args, kwargs)

    def apply_async(self, args=None, kwargs=None, task_id=None, producer=None, link=None, link_error=None, shadow=None, **options) -> Any:
        """Apply tasks asynchronously by sending a message.

        Arguments:
            args (Tuple): The positional arguments to pass on to the task.

            kwargs (Dict): The keyword arguments to pass on to the task.

            countdown (float): Number of seconds into the future that the
                task should execute.  Defaults to immediate execution.

            eta (~datetime.datetime): Absolute time and date of when the task
                should be executed.  May not be specified if `countdown`
                is also supplied.

            expires (float, ~datetime.datetime): Datetime or
                seconds in the future for the task should expire.
                The task won't be executed after the expiration time.

            shadow (str): Override task name used in logs/monitoring.
                Default is retrieved from :meth:`shadow_name`.

            retry (bool): If enabled sending of the task message will be
                retried in the event of connection loss or failure.
                Default is taken from the :setting:`task_publish_retry`
                setting.  Note that you need to handle the
                producer/connection manually for this to work.

            time_limit (int): If set, overrides the default time limit.

            queue (str, kombu.Queue): The queue to route the task to.
                This must be a key present in :setting:`task_queues`, or
                :setting:`task_create_missing_queues` must be
                enabled.  See :ref:`guide-routing` for more
                information.

            routing_key (str): Custom routing key used to route the task to a
                worker server.  If in combination with a ``queue`` argument
                only used to specify custom routing keys to topic exchanges.

            priority (int): The task priority, a number between 0 and 9.
                Defaults to the :attr:`priority` attribute.

            ignore_result (bool): If set to `False` (default) the result
                of a task will be stored in the backend. If set to `True`
                the result will not be stored. This can also be set
                using the :attr:`ignore_result` in the `app.task` decorator.

            headers (Dict): Message headers to be included in the message.

        Returns:
            vaultdb.compute.result.AsyncResult: Promise of future evaluation.

        Raises:
            TypeError: If not enough arguments are passed, or too many
                arguments are passed.  Note that signature checks may
                be disabled by specifying ``@task(typing=False)``.
        """
        preopts = self._get_exec_options()
        options = dict(preopts, **options) if options else preopts
        options.setdefault("ignore_result", self.ignore_result)
        if self.priority:
            options.setdefault("priority", self.priority)

        app = options.pop("TED", self._get_app())
        return app.send_task(
            self.name,
            args,
            kwargs,
            task_id=task_id,
            producer=producer,
            link=link,
            link_error=link_error,
            result_cls=self.async_result,
            shadow=shadow,
            task_type=self,
            **options,
        )

    def async_result(self, task_id: str, backend: Any = None, task_name: str | None = None, **kwargs: Any) -> Any:
        """Get AsyncResult instance for the specified task.

        Arguments:
            task_id: Task id to get result for.
            backend: Result backend (unused, kept for compatibility).
            task_name: Task name (unused, kept for compatibility).
            **kwargs: Additional keyword arguments.

        Returns:
            AsyncResult instance for the task.
        """
        from .result import AsyncResult

        return AsyncResult(task_id, **kwargs)

    def __repr__(self) -> str:
        """``repr(task)``."""
        return _reprtask(self, R_INSTANCE)

    def _get_request(self) -> Any:
        """Get current request object."""
        # Try to get request from request_stack if it exists (Service/Celery-specific)
        req = None
        if hasattr(self, "request_stack") and self.request_stack is not None:
            req = getattr(self.request_stack, "top", None)

        if req is None:
            # task was not called, but some may still expect a request
            # to be there, perhaps that should be deprecated.
            if self._default_request is None:
                self._default_request = Context()
            return self._default_request
        return req

    @property
    def request(self) -> Any:
        """Get current request object."""
        return self._get_request()

    @request.setter
    def request(self, value: Any) -> None:
        """Set current request object (primarily for testing)."""
        self._default_request = value

    def _get_exec_options(self) -> Any:
        if self._exec_options is None:
            self._exec_options = extract_exec_options(self)
        return self._exec_options
