import numbers


class VaultdbError(Exception):
    """Base class for all Vaultdb compute errors."""


class TaskError(VaultdbError):
    """Task related errors."""


class TimeoutError(TaskError):
    """The operation timed out."""


class OperationalError(VaultdbError):
    """The operation timed out."""


class MaxRetriesExceededError(TaskError):
    """The tasks max restart limit has been exceeded."""

    def __init__(self, *args, **kwargs):
        self.task_args = kwargs.pop("task_args", [])
        self.task_kwargs = kwargs.pop("task_kwargs", dict())
        super().__init__(*args, **kwargs)


class TaskPredicateError(VaultdbError):
    """Base class for task-related semi-predicates."""


class RetryError(TaskPredicateError):
    """The task is to be retried later."""

    #: Optional message describing context of retry.
    message = None

    #: Exception (if any) that caused the retry to happen.
    exc = None

    #: Time of retry (ETA), either :class:`numbers.Real` or
    #: :class:`~datetime.datetime`.
    when = None

    def __init__(self, message=None, exc=None, when=None, is_eager=False, sig=None, **kwargs):
        from .utils import safe_repr

        self.message = message
        if isinstance(exc, str):
            self.exc, self.excs = None, exc
        else:
            self.exc, self.excs = exc, safe_repr(exc) if exc else None
        self.when = when
        self.is_eager = is_eager
        self.sig = sig
        super().__init__(self, exc, when, **kwargs)

    def humanize(self):
        if isinstance(self.when, numbers.Number):
            return f"in {self.when}s"
        return f"at {self.when}"

    def __str__(self):
        if self.message:
            return self.message
        if self.excs:
            return f"{self.__class__.__name__} {self.humanize()}: {self.excs}"
        return f"{self.__class__.__name__} {self.humanize()}"

    def __reduce__(self):
        return self.__class__, (self.message, self.exc, self.when)


class IgnoreError(TaskPredicateError):
    """A task can raise this to ignore doing state updates."""


class RejectError(TaskPredicateError):
    """A task can raise this if it wants to reject/re-queue the message."""

    def __init__(self, reason=None, requeue=False):
        self.reason = reason
        self.requeue = requeue
        super().__init__(reason, requeue)

    def __repr__(self):
        return f"reject requeue={self.requeue}: {self.reason}"
