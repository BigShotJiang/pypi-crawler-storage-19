import enum
import logging
import os
import sys
from collections.abc import Callable
from datetime import UTC
from datetime import timezone
from typing import Any

from .. import config
from .._state import _set_current_runner
from .._state import exists
from .._state import get_current_runner
from .task import Task
from .trace import TaskTracer
from .utils import CachedProperty


class RunType(enum.Enum):
    SERVICE = "service"
    FUNCTION = "function"
    BATCH = "batch"
    LOCAL = "local"


# Configure logging
logger = logging.getLogger()


def is_running_in_function() -> bool:
    """Check if code is running in Function environment (e.g. AWS Lambda)"""
    return all([os.environ.get("AWS_LAMBDA_FUNCTION_NAME"), os.environ.get("AWS_LAMBDA_FUNCTION_VERSION"), os.environ.get("AWS_LAMBDA_RUNTIME_API")])


def is_running_in_batch() -> bool:
    """Check if code is running in AWS Batch Fargate environment"""
    return all(
        [
            os.environ.get("AWS_BATCH_JOB_ID"),
            os.environ.get("AWS_BATCH_JOB_ATTEMPT"),
            os.environ.get("AWS_BATCH_JQ_NAME"),  # Job Queue Name
        ]
    )


def get_runner(runtype: RunType) -> Any:
    if exists(runtype.value):
        return get_current_runner(runtype.value)

    if runtype == RunType.LOCAL:
        if is_running_in_function():
            runtype = RunType.FUNCTION
        elif is_running_in_batch():
            runtype = RunType.BATCH

    newapp: Any = None
    match runtype:
        case RunType.SERVICE:
            from ..service import setup_service

            newapp = setup_service()
        case RunType.FUNCTION:
            # Use importlib to avoid potential keyword conflicts and allow dynamic loading
            import importlib

            function_module = importlib.import_module("..function.core", package=__package__)
            function_runner = function_module.FunctionRunner

            newapp = function_runner()
        case RunType.BATCH:
            from ..batch.core import BatchRunner

            newapp = BatchRunner()
        case _:
            # RunType.LOCAL fall here
            newapp = Runner()
    _set_current_runner(newapp)
    return newapp


def gen_task_name(name: str, module_name: str) -> str:
    """Generate task name from name/module pair."""
    module_name = module_name or "__main__"
    try:
        module = sys.modules[module_name]
    except KeyError:
        # Fix for manage.py shell_plus (Issue #366)
        module = None

    if module is not None:
        module_name = module.__name__

    return ".".join(p for p in (module_name, name) if p)


class Runner:
    task_cls = "vaultdb.compute.task:Task"
    run_type = RunType.LOCAL

    """docstring for Task."""

    def __init__(self, main: str | None = None, tasks: dict[str, Any] | None = None, **kwargs: Any) -> None:
        self.main = main
        self._tasks = tasks or {}

    def send_task(
        self,
        name: str,
        args: tuple[Any, ...] | None = None,
        kwargs: dict[str, Any] | None = None,
        countdown: float | None = None,
        eta: Any | None = None,
        task_id: str | None = None,
        producer: Any | None = None,
        connection: Any | None = None,
        router: Any | None = None,
        result_cls: Any | None = None,
        expires: Any | None = None,
        publisher: Any | None = None,
        link: Any | None = None,
        link_error: Any | None = None,
        add_to_parent: bool = True,
        group_id: str | None = None,
        group_index: int | None = None,
        retries: int = 0,
        chord: Any | None = None,
        reply_to: str | None = None,
        time_limit: int | None = None,
        soft_time_limit: int | None = None,
        root_id: str | None = None,
        parent_id: str | None = None,
        route_name: str | None = None,
        shadow: str | None = None,
        chain: Any | None = None,
        task_type: Any | None = None,
        replaced_task_nesting: int = 0,
        **options: Any,
    ) -> Any:
        """Send task by name.

        Supports the same arguments as :meth:`@-Task.apply_async`.

        Arguments:
            name (str): Name of task to call (e.g., `"tasks.add"`).
            result_cls (AsyncResult): Specify custom result class.
        """
        if config.run_type.lower() != "local":
            raise NotImplementedError(
                "this should be based on type of run for function, it should use current users credentials "
                "and invoke function. for Batch it should Invoke Batch."
            )
            # Generate task_id if not provided
        if task_id is None:
            from ..compute.utils import uuid

            task_id = uuid()

        tasktorun = self._tasks[name]
        tracer = TaskTracer(tasktorun)
        result = tracer(*args, task_id=task_id, **kwargs)
        return self.async_result(task_id, result=result)

    def clean(self) -> None:
        """Clean up resources."""
        pass

    def close(self) -> None:
        self.clean()

    def async_result(self, task_id: str, **kwargs: Any) -> Any:
        """Get AsyncResult instance for the specified task.

        Args:
            task_id: Task ID to get result for.
            **kwargs: Additional keyword arguments.

        Returns:
            AsyncResult instance for the task.
        """
        from .result import AsyncResult

        return AsyncResult(task_id, **kwargs)

    # Alias for consistency with Celery
    AsyncResult = async_result

    @CachedProperty
    def tasks(self) -> Any:
        """Task registry.

        Warning:
            Accessing this attribute will also auto-finalize the app.
        """
        return self._tasks

    def _task_from_fun(self, fun: Callable, name: str | None = None, base: type | None = None, bind: bool = False, **options: Any) -> Task:
        name = name or gen_task_name(fun.__name__, fun.__module__)
        base = base or self.task_base

        if name not in self._tasks:
            run = fun if bind else staticmethod(fun)
            task = type(
                fun.__name__,
                (base,),
                dict(
                    {
                        "_app": self,
                        "name": name,
                        "run": run,
                        "_decorated": True,
                        "__doc__": fun.__doc__,
                        "__module__": fun.__module__,
                        "__annotations__": fun.__annotations__,
                        "__wrapped__": run,
                    },
                    **options,
                ),
            )()
            # for some reason __qualname__ cannot be set in type()
            # so we have to set it here.
            try:
                task.__qualname__ = fun.__qualname__
            except AttributeError:
                pass
            self._tasks[task.name] = task
        else:
            task = self._tasks[name]
        return task

    def task(self, *args: Any, **opts: Any) -> Any:
        def inner_create_task_cls(shared: bool = True, filter: Callable | None = None, lazy: bool = True, **opts: Any) -> Callable:
            _filt = filter

            def _create_task_cls(fun: Callable) -> Task:
                ret = self._task_from_fun(fun, **opts)
                if _filt:
                    return _filt(ret)
                return ret

            return _create_task_cls

        if len(args) == 1:
            if callable(args[0]):
                return inner_create_task_cls(**opts)(*args)
            raise TypeError("argument 1 to @task() must be a callable")
        if args:
            raise TypeError(f"@task() takes exactly 1 argument ({sum([len(args), len(opts)])} given)")
        return inner_create_task_cls(**opts)

    def timezone(self) -> timezone:
        """Current timezone for this app.

        This is a cached property taking the time zone from the
        :setting:`timezone` setting.
        """
        return UTC

    def conf(self) -> Any:
        """Vaultdb App configuration."""
        pass

    @CachedProperty
    def task_base(self) -> Any:
        """Base task class for this app."""
        return self.create_task_cls()

    def create_task_cls(self) -> Any:
        """Create a base task class bound to this app."""
        import importlib

        module_name, _, cls_name = self.task_cls.rpartition(":")
        module = importlib.import_module(module_name)
        return getattr(module, cls_name) if cls_name else module


__all__ = ["get_runner", "RunType", "is_running_in_batch", "is_running_in_function", "Runner", "Task"]
