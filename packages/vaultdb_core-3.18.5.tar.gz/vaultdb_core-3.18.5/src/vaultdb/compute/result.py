import time
from typing import Any

from .taskstatus import TaskStatus


class ResultBase:
    parent = None

    def get(
        self,
        timeout: Any = None,
        propagate: bool = True,
        interval: float = 0.5,
        no_ack: bool = True,
        follow_parents: bool = True,
        callback: Any = None,
        on_message: Any = None,
        on_interval: Any = None,
        disable_sync_subtasks: bool = True,
    ) -> Any:
        raise NotImplementedError()


class AsyncResult(ResultBase):
    result: Any = None
    task_id: str = ""
    response: dict[str, str] = {}
    errors: Any = None
    task_status: TaskStatus | None = None
    _status: str = ""

    def __init__(self, task_id: str, response: dict[str, str] | None = None, parent: Any = None, result: Any = None) -> None:
        self.task_id = task_id
        self.response = response or {}
        self.parent = parent
        self.result = result
        super().__init__()

    @property
    def status(self) -> str:
        self.task_status = TaskStatus.get(task_id=self.task_id)
        if self.task_status:
            return self.task_status.status

        raise RuntimeError("Task Status not found")

    def get(
        self,
        timeout: Any = None,
        propagate: bool = True,
        interval: float = 0.5,
        no_ack: bool = True,
        follow_parents: bool = True,
        callback: Any = None,
        on_message: Any = None,
        on_interval: Any = None,
        disable_sync_subtasks: bool = True,
    ) -> Any:
        """
        Wait for task completion and return result or raise exception.

        Args:
            timeout: Maximum time to wait in seconds. If None, wait indefinitely.
            propagate: Whether to propagate exceptions from failed tasks.
            interval: Time interval between status checks in seconds.
            no_ack: Whether to acknowledge the message (unused in this implementation).
            follow_parents: Whether to follow parent tasks (unused in this implementation).
            callback: Callback function to call on completion (unused in this implementation).
            on_message: Callback function to call on message (unused in this implementation).
            on_interval: Callback function to call on each interval check (unused in this implementation).
            disable_sync_subtasks: Whether to disable sync subtasks (unused in this implementation).

        Returns:
            The task result if successful.

        Raises:
            RuntimeError: If task status cannot be retrieved.
            Exception: If task failed and propagate is True, raises the original exception.
            TimeoutError: If timeout is reached before task completion.
        """
        start_time = time.time()

        while True:
            # Get current task status
            current_status = self.status

            # Check if task is completed
            if current_status in {"SUCCESS", "FAILURE", "REVOKED"}:
                break

            # Check timeout
            if timeout is not None:
                elapsed_time = time.time() - start_time
                if elapsed_time >= timeout:
                    raise TimeoutError(f"Task {self.task_id} timed out after {timeout} seconds")

            # Wait before next check
            time.sleep(interval)

        # Handle completed task
        if current_status == "SUCCESS":
            # Return the result from task status
            if self.task_status and self.task_status.result:
                self.result = self.task_status.result
            return self.result

        elif current_status == "FAILURE":
            if propagate and self.task_status:
                # Create exception from task status data
                error_msg = f"Task {self.task_id} failed"
                if self.task_status.traceback:
                    error_msg += f"\nTraceback:\n{self.task_status.traceback}"

                # Try to create a meaningful exception
                if self.task_status.traceback:
                    # Extract exception type and message from traceback if possible
                    lines = self.task_status.traceback.strip().split("\n")
                    if lines:
                        last_line = lines[-1].strip()
                        if ":" in last_line:
                            exc_type, exc_msg = last_line.split(":", 1)
                            exc_type = exc_type.strip()
                            exc_msg = exc_msg.strip()

                            # Try to create the original exception type
                            if exc_type == "ValueError":
                                raise ValueError(exc_msg)
                            elif exc_type == "TypeError":
                                raise TypeError(exc_msg)
                            elif exc_type == "RuntimeError":
                                raise RuntimeError(exc_msg)
                            elif exc_type == "KeyError":
                                raise KeyError(exc_msg)
                            elif exc_type == "IndexError":
                                raise IndexError(exc_msg)
                            else:
                                raise RuntimeError(error_msg)

                # Fallback to generic RuntimeError
                raise RuntimeError(error_msg)
            else:
                # If not propagating, return None or some indication of failure
                return None

        elif current_status == "REVOKED":
            if propagate:
                raise RuntimeError(f"Task {self.task_id} was revoked")
            return None

        # This should not be reached, but just in case
        return None

    def revoke(self) -> None:
        """Revoke the task."""
        TaskStatus.revoke(self.task_id)
