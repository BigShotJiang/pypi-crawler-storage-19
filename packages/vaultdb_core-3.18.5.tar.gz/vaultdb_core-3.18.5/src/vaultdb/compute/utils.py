import sys
import traceback
from collections.abc import Callable
from functools import cached_property as _cached_property
from typing import Any
from typing import TypeVar
from uuid import UUID
from uuid import uuid4

_NOT_FOUND = object()
T = TypeVar("T")


class CachedProperty(_cached_property[T]):
    """Implementation of Cached property."""

    def __init__(self, fget: Callable[[Any], T] | None = None, fset: Callable[[Any, T], T] | None = None, fdel: Callable[[Any, T], None] | None = None) -> None:
        super().__init__(fget)  # type: ignore
        self.__set = fset
        self.__del = fdel

        if not hasattr(self, "attrname"):
            # This is a backport so we set this ourselves.
            self.attrname = self.func.__name__

    def __set__(self, instance: Any, value: T) -> None:
        if instance is None:
            return

        if self.__set is not None:
            value = self.__set(instance, value)

            cache = instance.__dict__
            cache[self.attrname] = value

    def __delete__(self, instance: Any) -> None:
        if instance is None:
            return

        value = instance.__dict__.pop(self.attrname, _NOT_FOUND)

        if self.__del and value is not _NOT_FOUND:
            self.__del(instance, value)

    def setter(self, fset: Callable[[Any, T], T]) -> "CachedProperty[T]":
        return self.__class__(self.func, fset, self.__del)

    def deleter(self, fdel: Callable[[Any, T], None]) -> "CachedProperty[T]":
        return self.__class__(self.func, self.__set, fdel)


def uuid(_uuid: Callable[[], UUID] = uuid4) -> str:
    """Generate unique id in UUID4 format.

    See Also
    --------
        For now this is provided by :func:`uuid.uuid4`.
    """
    return str(_uuid())


def raise_with_context(exc: BaseException) -> None:
    exc_info = sys.exc_info()
    if not exc_info:
        raise exc
    elif exc_info[1] is exc:
        raise
    raise exc from exc_info[1]


def bytes_to_str(s: Any) -> Any:
    """Convert bytes to str."""
    if isinstance(s, bytes):
        return s.decode(errors="replace")
    return s


def safe_str(s: Any, errors: str = "replace") -> str:
    """Safe form of str(), void of unicode errors."""
    s = bytes_to_str(s)
    if not isinstance(s, (str, bytes)):
        return safe_repr(s, errors)
    return _safe_str(s, errors)


def _safe_str(s: Any, errors: str = "replace", file: Any = None) -> str:
    if isinstance(s, str):
        return s
    try:
        return str(s)
    except Exception as exc:
        return "<Unrepresentable {!r}: {!r} {!r}>".format(type(s), exc, "\n".join(traceback.format_stack()))


def safe_repr(o: Any, errors: str = "replace") -> str:
    """Safe form of repr, void of Unicode errors."""
    try:
        return repr(o)
    except Exception:
        return _safe_str(o, errors)
