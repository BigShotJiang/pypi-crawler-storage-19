"""
Task handler module for VaultDB compute.

This module provides task handling functionality for the compute system.
"""

from collections.abc import Callable
from typing import Any


def task_handler(func: Callable[..., Any]) -> Callable[..., Any]:
    """
    Decorator for task handlers.

    Args:
        func: The function to decorate as a task handler.

    Returns:
        The decorated function.
    """
    # For now, just return the function as-is
    # In a full implementation, this would add task handling logic
    return func
