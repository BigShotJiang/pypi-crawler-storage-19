# Set up the logger
import os
import tempfile
import uuid
from typing import Any

import duckdb
import pandas as pd
from peewee import Model
from peewee import SqliteDatabase

from .. import auth
from .. import config
from ..logger import get_logger
from ..proxies import DuckDBPyConnection
from ..settings import commitlog_directory

# Use named logger for data module
logger = get_logger(config.LOGGER_DATA)


class VaultdbDatabase(SqliteDatabase):
    authenticator: auth.BaseAuthenticator
    role: str
    readonly: bool = False
    catalog: str = ""
    config: dict = {}
    clone: bool = False
    cloned: bool = False

    def __init__(
        self,
        catalog: str,
        *args: tuple,
        **kwargs: dict,
    ) -> None:
        self.catalog = catalog
        super().__init__(catalog, *args, **kwargs)

    def init(
        self,
        catalog: str,
        role: str = "vaultdb",  # pyright: ignore[reportUnusedParameter]
        authenticator: auth.BaseAuthenticator | None = None,  # pyright: ignore[reportUnusedParameter] # type: ignore
        config: dict = {"autoinstall_known_extensions": "true"},
        readonly: bool = False,
        clone: bool = False,
        **kwargs: dict,
    ) -> None:  # pyright: ignore[reportUnusedParameter] # type: ignore
        self.catalog = catalog
        self.role = role
        self.authenticator = authenticator
        self.readonly = readonly
        self.clone = clone
        self.config = config
        logger.debug(f"VaultdbDatabase initialized: catalog={catalog}, role={role}, readonly={readonly}, clone={clone}")
        super().init(catalog, **kwargs)

    def _connect(self) -> DuckDBPyConnection:  # pyright: ignore[reportUnusedParameter] # type: ignore
        logger.debug(f"Connecting to catalog: {self.catalog}")
        clonedpath = self._clone()
        conn = duckdb.connect(clonedpath or self.catalog, self.readonly, config=self.config, role=self.role)
        if self.authenticator:
            logger.debug(f"Creating secrets for role: {self.role}")
            self.authenticator.create_secrets(conn, self.role)
        try:
            if self._extensions:
                logger.debug(f"Loading extensions: {self._extensions}")
                self._load_extensions(conn)
        except Exception as e:
            logger.error(f"Failed to load extensions: {e}")
            conn.close()
            raise
        logger.info(f"Connected to catalog: {self.catalog}")
        return conn

    def last_insert_id(self, cursor: Any, query_type: Any = None) -> Any:
        # DuckDB does not support cursor.lastrowid
        # Since we are using explicit primary keys (task_id), we don't need this
        return cursor.fetchall()[0][0] if cursor.description else None

    def rows_affected(self, cursor: Any) -> int:
        # DuckDB does not consistently support cursor.rowcount
        try:
            return cursor.rowcount
        except AttributeError:
            return -1

    def _clone(self) -> str:
        if self.cloned or not self.clone or self.catalog == ":memory:":
            return ""

        tempfolder = os.path.join(tempfile.gettempdir(), "vaultdb")
        os.makedirs(tempfolder, exist_ok=True)
        tempfolder = os.path.join(tempfolder, str(uuid.uuid4())[:8])
        os.makedirs(tempfolder, exist_ok=True)

        source_path = os.path.join(commitlog_directory, f"{self.catalog}")
        if self.authenticator:
            # If username and password is there then clone it from remote s3 as anything running inside cloud should not have username password.
            # All runs on cloud should use aws roles.
            s3_key = f"catalogs/{self.catalog}"
            self.authenticator.download_file(s3_key, source_path)

        # If not then just clone from local folder and assume all access is granted through aws roles
        destination_path = os.path.join(tempfolder, f"{self.catalog}")
        VaultdbDatabase.clean(destination_path)
        if os.path.isfile(source_path):
            import shutil

            shutil.copy2(source_path, destination_path)
            self.cloned = True
            logger.info(f"Cloned catalog to: {destination_path}")
            return destination_path
        logger.debug(f"Using source path: {source_path}")
        return source_path

    @staticmethod
    def clean(filename: str) -> None:  # pyright: ignore[reportUnusedParameter] # type: ignore
        if os.path.isfile(filename):
            os.remove(filename)
        if os.path.isfile(filename + ".wal"):
            os.remove(filename + ".wal")

    def sync_load_and_push(self, df: pd.DataFrame, table_name: str, primary_keys: list[str], partition_by: str = "") -> None:
        """AI is creating summary for sync_and_load

        Args:
            connection (DuckDBPyConnection): [description]
            df (pd.DataFrame): [description]
            table_name (str): [description]
            primary_keys (list[str]): [description]
            partition_by (str, optional): [description]. Defaults to None.
        """
        logger.info(f"sync_load_and_push: {table_name}")
        self.sync_and_load(df, table_name, primary_keys, partition_by)
        self.push()

    def sync_load_and_merge(self, df: pd.DataFrame, table_name: str, primary_keys: list[str], partition_by: str = "") -> None:
        """AI is creating summary for sync_and_load

        Args:
            connection (DuckDBPyConnection): [description]
            df (pd.DataFrame): [description]
            table_name (str): [description]
            primary_keys (list[str]): [description]
            partition_by (str, optional): [description]. Defaults to None.
        """
        logger.info(f"sync_load_and_merge: {table_name}")
        self.sync_and_load(df, table_name, primary_keys, partition_by)
        self.merge()

    def sync_and_load(self, df: pd.DataFrame, table_name: str, primary_keys: list[str], partition_by: str = "") -> None:
        """AI is creating summary for sync_and_load

        Args:
            connection (DuckDBPyConnection): [description]
            df (pd.DataFrame): [description]
            table_name (str): [description]
            primary_keys (list[str]): [description]
            partition_by (str, optional): [description]. Defaults to None.
        """
        df = df.infer_objects()
        try:
            _connection = self.connection()
            _connection.sql("CREATE OR REPLACE TABLE temp_sql AS SELECT * FROM df")
            df_tmp_sql = _connection.sql("SHOW temp_sql;").fetchdf()
            tbl_df: pd.DataFrame = _connection.query(f"select * from information_schema.tables where table_name='{table_name}';").fetchdf()
            if tbl_df.empty:
                create_stmt = f"CREATE OR REPLACE TABLE {table_name}("
                for row in df_tmp_sql.itertuples(index=False):
                    create_stmt += f"{row.column_name.lower().replace(' ', '_')} {row.column_type}, "
                if primary_keys:
                    create_stmt += f"PRIMARY KEY({','.join(primary_keys)}))"
                else:
                    create_stmt = f"{create_stmt[:-2]})"
                _connection.query(create_stmt)
                if partition_by:
                    partition_by_stmt = f"ALTER TABLE {table_name} PARTITION BY {partition_by};"
                    _connection.query(partition_by_stmt)
            else:
                tbl_df: pd.DataFrame = _connection.query(f"SHOW {table_name};").fetchdf()
                table_cols = tbl_df["column_name"].tolist()

                for row in df_tmp_sql.itertuples(index=False):
                    if row.column_name.lower().replace(" ", "_") not in table_cols:
                        alter_stmt = f"ALTER TABLE {table_name} ADD COLUMN {row.column_name.lower().replace(' ', '_')} {row.column_type};"
                        _connection.query(alter_stmt)

            tbl_df: pd.DataFrame = _connection.query(f"SHOW {table_name};").fetchdf()
            table_col_list = tbl_df["column_name"].tolist()
            table_cols = []
            for col in df.columns.tolist():
                if col.lower().replace(" ", "_") in table_col_list:
                    table_cols.append(col.lower().replace(" ", "_"))

            _connection.query(f"INSERT INTO {table_name}({','.join(table_cols)}) SELECT * FROM df")
            logger.info(f"Loaded {len(df)} rows into {table_name}")

        except Exception as e:
            logger.error(f"Error in sync_and_load for {table_name}: {e}")
            raise
        finally:
            _connection.sql("DROP TABLE temp_sql;")

    def push(self) -> None:
        logger.info(f"Pushing database: {self.catalog}")
        _connection = self.connection()
        _connection.execute("set http_retries=3;")
        _connection.execute("set http_timeout=120000;")
        _connection.execute("PRAGMA disable_data_inheritance;")
        _connection.execute(f"PUSH DATABASE {self.catalog};")
        _connection.execute("BEGIN TRANSACTION;")
        _connection.execute(f"TRUNCATE DATABASE {self.catalog};")
        _connection.execute("COMMIT;")
        _connection.execute("VACUUM ANALYZE;")
        logger.info(f"Push completed for: {self.catalog}")

    def merge(self) -> None:
        _connection = self.connection()
        _connection.execute("PRAGMA enable_data_inheritance;")
        _connection.execute("set http_retries=3;")
        _connection.execute("set http_timeout=120000;")
        _connection.execute(f"MERGE DATABASE {self.catalog};")
        _connection.execute("PRAGMA disable_data_inheritance;")
        _connection.execute("BEGIN TRANSACTION;")
        _connection.execute(f"TRUNCATE DATABASE {self.catalog};")
        _connection.execute("COMMIT;")
        _connection.execute("VACUUM ANALYZE;")


class VaultdbModel(Model):
    @classmethod
    def get_or_create(cls, **kwargs):
        defaults = kwargs.pop("defaults", {})
        query = cls.select()
        for field, value in kwargs.items():
            query = query.where(getattr(cls, field) == value)

        try:
            return query.get(), False
        except cls.DoesNotExist:
            try:
                params = dict(kwargs)
                params.update(defaults)
                return cls.create(**params), True
            except (duckdb.CatalogException, duckdb.SequenceException):
                cls.create_table(safe=True)
                params = dict(kwargs)
                params.update(defaults)
                return cls.create(**params), True
        except (duckdb.CatalogException, duckdb.SequenceException):
            cls.create_table(safe=True)
            try:
                return query.get(), False
            except cls.DoesNotExist:
                params = dict(kwargs)
                params.update(defaults)
                return cls.create(**params), True
        except Exception as e:
            if "Catalog Error" in str(e):
                cls.create_table(safe=True)
                try:
                    return query.get(), False
                except cls.DoesNotExist:
                    params = dict(kwargs)
                    params.update(defaults)
                    return cls.create(**params), True
            raise e


if __name__ == "__main__":
    catalog_name = "finance"
    app = VaultdbDatabase(catalog_name)
    connection = app._connect()
    df = connection.execute("SELECT * FROM vaultdb_configs").fetchdf()
    print(df)
