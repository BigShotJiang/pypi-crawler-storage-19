"""Internal state.

This is an internal module containing thread state
like the ``TED``, ``current_app``, and ``current_task``.

This module shouldn't be used directly.
"""

import threading
import weakref
from typing import Any

from .local import Proxy

__all__ = (
    "set_default_task_runner",
    "get_current_runner",
    "TED",
    "current_app",
)

#: List of all runner instances (weakrefs), mustn't be used directly.
_runners: weakref.WeakSet = weakref.WeakSet()


class _TLS(threading.local):
    #: Runners with the :attr:`~vaultdb.core.Application.set_default_task_runner` attribute
    #: sets this, so it will always contain the last instantiated runner,
    #: and is the default runner returned by :func:`runner_or_default`.
    runners: dict[str, Any] = {}


_tls = _TLS()


def _exists(runtype: str) -> bool:
    return runtype in _tls.runners


def _get_current_runner(runtype: str | None = None) -> Any:
    from . import config

    runtype = (runtype or config.run_type).lower()
    if _exists(runtype):
        return _tls.runners[runtype]

    from .compute.core import RunType
    from .compute.core import get_runner

    run_type = RunType(runtype)
    return get_runner(run_type)


def _get_batch_runner() -> Any:
    return _get_current_runner("batch")


def _get_function_runner() -> Any:
    return _get_current_runner("function")


def _get_service_runner() -> Any:
    return _get_current_runner("service")


def _get_local_runner() -> Any:
    return _get_current_runner("local")


def _set_current_runner(runner: Any) -> None:
    if runner is None:
        # Clear all runners
        _tls.runners = {}
    else:
        _tls.runners[runner.run_type.value] = runner


get_current_runner = _get_current_runner
exists = _exists
set_default_task_runner = _set_current_runner

class _TEDProxy(Proxy):
    @property
    def Batch(self) -> Proxy:  # noqa: N802
        return Proxy(_get_batch_runner)

    @property
    def Function(self) -> Proxy:  # noqa: N802
        return Proxy(_get_function_runner)

    @property
    def Service(self) -> Proxy:  # noqa: N802
        return Proxy(_get_service_runner)

    @property
    def Local(self) -> Proxy:  # noqa: N802
        return Proxy(_get_local_runner)


#: Proxy to current runner.
current_app: Proxy = Proxy(get_current_runner)
TED: Proxy = _TEDProxy(get_current_runner)
