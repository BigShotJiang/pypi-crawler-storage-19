from datetime import datetime
from typing import Any

from . import config

# Logged on user details for this thread
catalog: str = ":memory:"
role: str = "vaultdb"
username: str = ""
password: str = ""
timezone: str = "UTC"
user_authenticator: Any = None
valuationdate: datetime | None = None
task_id: str = ""
commitlog_directory: str = config.commitlog_directory
# aws Credentials
aws_credentials: dict[str, Any] = {}
