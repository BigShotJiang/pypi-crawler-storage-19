"""
VaultDB Cache Core Module.

Provides Redis-based caching functionality with configurable TTL,
serialization, and integration with the service's (Celery) Redis backend.
"""

import json
import pickle
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from typing import Any

from .. import config
from ..logger import get_logger

# Use named logger for cache module
logger = get_logger(config.LOGGER_CACHE)


@dataclass
class CacheConfig:
    """Configuration for Redis cache. Uses values from config.py by default."""

    # Redis connection
    redis_url: str = ""
    database: int = 0

    # Default TTL settings
    default_ttl: int = 3600
    max_ttl: int = 86400 * 7

    # Serialization
    serializer: str = "json"

    # Key prefix for namespacing
    key_prefix: str = "vaultdb:"

    # Connection pool settings
    max_connections: int = 10
    socket_timeout: float = 5.0
    socket_connect_timeout: float = 5.0
    retry_on_timeout: bool = True

    @classmethod
    def from_config(cls) -> "CacheConfig":
        """Create configuration from centralized config.py settings."""
        cfg = cls()
        cfg.redis_url = config.redis_cache_url
        cfg.database = int(config.result_database)
        cfg.default_ttl = config.cache_default_ttl
        cfg.max_ttl = config.cache_max_ttl
        cfg.serializer = config.cache_serializer
        cfg.key_prefix = config.cache_key_prefix
        cfg.max_connections = config.cache_max_connections

        logger.debug(f"CacheConfig loaded from config: redis_url={cfg.redis_url}, prefix={cfg.key_prefix}")
        return cfg

    # Alias for backward compatibility
    @classmethod
    def from_environment(cls) -> "CacheConfig":
        """Create configuration (alias for from_config)."""
        return cls.from_config()

    def validate(self) -> None:
        """Validate configuration."""
        if not self.redis_url:
            raise ValueError("redis_url must be specified")

        if self.default_ttl <= 0:
            raise ValueError("default_ttl must be positive")

        if self.max_ttl < self.default_ttl:
            raise ValueError("max_ttl must be >= default_ttl")

        if self.serializer not in ("json", "pickle"):
            raise ValueError("serializer must be 'json' or 'pickle'")

        logger.debug("CacheConfig validated successfully")


class Cache:
    """
    Redis-based cache with serialization support.

    Features:
    - JSON or pickle serialization
    - Configurable TTL
    - Key namespacing
    - Connection pooling
    - Graceful error handling
    """

    def __init__(self, config: CacheConfig | None = None):
        """
        Initialize the cache.

        Args:
            config: Cache configuration. Uses environment config if not provided.
        """
        self.config = config or CacheConfig.from_environment()
        self._client: Any = None
        self._pool: Any = None
        logger.info(f"Cache initialized with prefix={self.config.key_prefix}")

    def _get_client(self) -> Any:
        """Get or create Redis client."""
        if self._client is None:
            try:
                import redis

                self._pool = redis.ConnectionPool.from_url(
                    self.config.redis_url,
                    db=self.config.database,
                    max_connections=self.config.max_connections,
                    socket_timeout=self.config.socket_timeout,
                    socket_connect_timeout=self.config.socket_connect_timeout,
                    retry_on_timeout=self.config.retry_on_timeout,
                )
                self._client = redis.Redis(connection_pool=self._pool)
                logger.debug(f"Redis client created for {self.config.redis_url}")
            except ImportError:
                logger.error("redis package not installed. Install with: pip install redis")
                raise ImportError("redis package required for caching")
            except Exception as e:
                logger.error(f"Failed to create Redis client: {e}")
                raise

        return self._client

    def _make_key(self, key: str) -> str:
        """Create full key with prefix."""
        return f"{self.config.key_prefix}{key}"

    def _serialize(self, value: Any) -> bytes:
        """Serialize value for storage."""
        try:
            if self.config.serializer == "json":
                return json.dumps(value, default=str).encode("utf-8")
            else:
                return pickle.dumps(value)
        except Exception as e:
            logger.error(f"Serialization failed for value: {e}")
            raise

    def _deserialize(self, data: bytes) -> Any:
        """Deserialize value from storage."""
        try:
            if self.config.serializer == "json":
                return json.loads(data.decode("utf-8"))
            else:
                return pickle.loads(data)
        except Exception as e:
            logger.error(f"Deserialization failed: {e}")
            raise

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a value from cache.

        Args:
            key: Cache key
            default: Default value if key not found

        Returns:
            Cached value or default
        """
        full_key = self._make_key(key)
        try:
            client = self._get_client()
            data = client.get(full_key)

            if data is None:
                logger.debug(f"Cache miss for key: {key}")
                return default

            value = self._deserialize(data)
            logger.debug(f"Cache hit for key: {key}")
            return value

        except Exception as e:
            logger.error(f"Cache get failed for key {key}: {e}")
            return default

    def set(
        self,
        key: str,
        value: Any,
        ttl: int | timedelta | None = None,
    ) -> bool:
        """
        Set a value in cache.

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds or timedelta. Uses default if not provided.

        Returns:
            True if successful, False otherwise
        """
        full_key = self._make_key(key)

        # Convert timedelta to seconds
        if isinstance(ttl, timedelta):
            ttl = int(ttl.total_seconds())
        elif ttl is None:
            ttl = self.config.default_ttl

        # Enforce max TTL
        ttl = min(ttl, self.config.max_ttl)

        try:
            client = self._get_client()
            data = self._serialize(value)
            result = client.setex(full_key, ttl, data)
            logger.debug(f"Cache set for key: {key}, ttl: {ttl}s")
            return bool(result)

        except Exception as e:
            logger.error(f"Cache set failed for key {key}: {e}")
            return False

    def delete(self, key: str) -> bool:
        """
        Delete a value from cache.

        Args:
            key: Cache key

        Returns:
            True if key was deleted, False otherwise
        """
        full_key = self._make_key(key)
        try:
            client = self._get_client()
            result = client.delete(full_key)
            logger.debug(f"Cache delete for key: {key}, deleted: {result}")
            return result > 0

        except Exception as e:
            logger.error(f"Cache delete failed for key {key}: {e}")
            return False

    def exists(self, key: str) -> bool:
        """
        Check if key exists in cache.

        Args:
            key: Cache key

        Returns:
            True if key exists, False otherwise
        """
        full_key = self._make_key(key)
        try:
            client = self._get_client()
            result = client.exists(full_key)
            return result > 0

        except Exception as e:
            logger.error(f"Cache exists check failed for key {key}: {e}")
            return False

    def get_ttl(self, key: str) -> int | None:
        """
        Get remaining TTL for a key.

        Args:
            key: Cache key

        Returns:
            Remaining TTL in seconds, or None if key doesn't exist
        """
        full_key = self._make_key(key)
        try:
            client = self._get_client()
            ttl = client.ttl(full_key)
            return ttl if ttl >= 0 else None

        except Exception as e:
            logger.error(f"Cache TTL check failed for key {key}: {e}")
            return None

    def set_many(self, mapping: dict[str, Any], ttl: int | None = None) -> bool:
        """
        Set multiple values at once.

        Args:
            mapping: Dictionary of key-value pairs
            ttl: TTL for all keys

        Returns:
            True if all successful
        """
        try:
            client = self._get_client()
            pipe = client.pipeline()

            ttl = ttl or self.config.default_ttl
            ttl = min(ttl, self.config.max_ttl)

            for key, value in mapping.items():
                full_key = self._make_key(key)
                data = self._serialize(value)
                pipe.setex(full_key, ttl, data)

            pipe.execute()
            logger.debug(f"Cache set_many: {len(mapping)} keys")
            return True

        except Exception as e:
            logger.error(f"Cache set_many failed: {e}")
            return False

    def get_many(self, keys: list[str]) -> dict[str, Any]:
        """
        Get multiple values at once.

        Args:
            keys: List of cache keys

        Returns:
            Dictionary of found key-value pairs
        """
        try:
            client = self._get_client()
            full_keys = [self._make_key(k) for k in keys]
            values = client.mget(full_keys)

            result = {}
            for key, value in zip(keys, values):
                if value is not None:
                    result[key] = self._deserialize(value)

            logger.debug(f"Cache get_many: {len(keys)} requested, {len(result)} found")
            return result

        except Exception as e:
            logger.error(f"Cache get_many failed: {e}")
            return {}

    def delete_pattern(self, pattern: str) -> int:
        """
        Delete all keys matching a pattern.

        Args:
            pattern: Key pattern (e.g., "user:*")

        Returns:
            Number of keys deleted
        """
        full_pattern = self._make_key(pattern)
        try:
            client = self._get_client()
            keys = client.keys(full_pattern)
            if keys:
                count = client.delete(*keys)
                logger.info(f"Cache delete_pattern '{pattern}': {count} keys deleted")
                return count
            return 0

        except Exception as e:
            logger.error(f"Cache delete_pattern failed for '{pattern}': {e}")
            return 0

    def clear(self) -> bool:
        """
        Clear all keys with this cache's prefix.

        Returns:
            True if successful
        """
        try:
            count = self.delete_pattern("*")
            logger.info(f"Cache cleared: {count} keys deleted")
            return True

        except Exception as e:
            logger.error(f"Cache clear failed: {e}")
            return False

    def cached(
        self,
        ttl: int | None = None,
        key_builder: Callable[..., str] | None = None,
    ) -> Callable:
        """
        Decorator to cache function results.

        Args:
            ttl: Cache TTL in seconds
            key_builder: Function to build cache key from args/kwargs

        Returns:
            Decorator function
        """

        def decorator(func: Callable) -> Callable:
            import functools

            @functools.wraps(func)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                # Build cache key
                if key_builder:
                    cache_key = key_builder(*args, **kwargs)
                else:
                    # Default: function name + args
                    key_parts = [func.__module__, func.__name__]
                    key_parts.extend(str(a) for a in args)
                    key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
                    cache_key = ":".join(key_parts)

                # Try to get from cache
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    logger.debug(f"Cache hit for function {func.__name__}")
                    return cached_value

                # Execute function and cache result
                result = func(*args, **kwargs)
                self.set(cache_key, result, ttl=ttl)
                logger.debug(f"Cached result for function {func.__name__}")
                return result

            return wrapper

        return decorator

    def close(self) -> None:
        """Close the cache connection."""
        if self._pool:
            self._pool.disconnect()
            logger.info("Cache connection closed")


# Global cache instance
_cache: Cache | None = None


def get_cache(config: CacheConfig | None = None) -> Cache:
    """
    Get the global cache instance.

    Args:
        config: Optional configuration (uses default if not provided)

    Returns:
        Cache instance
    """
    global _cache
    if _cache is None:
        _cache = Cache(config)
        logger.info("Global cache instance created")
    return _cache
