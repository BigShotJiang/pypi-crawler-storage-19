"""
Scheduler package for VaultDB.

This package contains scheduler implementations for Service Beat (Redis-backed)
and AWS EventBridge, as well as schedule definitions.
"""

from .aws_deploy import deploy_schedules
from .aws_schedule import AWSEventBridge
from .aws_schedule import AWSEventSchedule

try:
    from .service_beat import RedisScheduler
except ImportError:
    RedisScheduler = None  # type: ignore
from .decorators import scheduled
from .discovery import discover_tasks
from .registry import ScheduledTaskRegistry

# Export schedules
from .schedules import BusinessDaySchedule
from .schedules import EveryBusinessDay
from .schedules import FirstBusinessDayOfMonth
from .schedules import FirstBusinessDayOfQuarter
from .schedules import FirstBusinessDayOfYear
from .schedules import LastBusinessDayOfMonth
from .schedules import LastBusinessDayOfQuarter
from .schedules import LastBusinessDayOfYear
from .schedules import NthBusinessDayOfMonth
from .schedules import SpecificDayOfMonth
from .schedules import every_business_day
from .schedules import first_business_day  # Convenience functions
from .schedules import last_business_day
from .schedules import nth_business_day

__all__ = [
    "RedisScheduler",
    "deploy_schedules",
    "discover_tasks",
    "AWSEventBridge",
    "AWSEventSchedule",
    "scheduled",
    "ScheduledTaskRegistry",
    # Schedules
    "BusinessDaySchedule",
    "FirstBusinessDayOfMonth",
    "LastBusinessDayOfMonth",
    "NthBusinessDayOfMonth",
    "FirstBusinessDayOfQuarter",
    "LastBusinessDayOfQuarter",
    "FirstBusinessDayOfYear",
    "LastBusinessDayOfYear",
    "EveryBusinessDay",
    "SpecificDayOfMonth",
    "first_business_day",
    "last_business_day",
    "nth_business_day",
    "every_business_day",
]
