"""
VaultDB Business Day Schedules.

Custom schedule classes that support business day calculations using calendars.
These schedules can be used with the service beat (service layer (Celery)) and the RedisScheduler.
"""

from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta
from zoneinfo import ZoneInfo

from vaultdb.calendar import Calendar
from vaultdb.calendar import get_calendar

from ..service.celery_proxy import BaseSchedule
from ..service.celery_proxy import schedstate


class BusinessDaySchedule(BaseSchedule):
    """
    Base class for business day schedules.

    Provides common functionality for scheduling tasks based on business days.
    """

    def __init__(
        self,
        run_at: time = time(9, 0),  # Default: 9:00 AM
        calendar: str | Calendar | None = None,
        app=None,
    ):
        """
        Initialize business day schedule.

        Args:
            run_at: Time of day to run the task (default: 9:00 AM)
            calendar: Calendar to use (name or instance, default: Default)
            app: service app instance (service layer (Celery))
        """
        super().__init__(app=app)
        self.run_at = run_at

        # Resolve calendar
        if calendar is None:
            self._calendar = get_calendar()
        elif isinstance(calendar, str):
            self._calendar = get_calendar(calendar)
        else:
            self._calendar = calendar

        self.tz = ZoneInfo(self._calendar.timezone)

    @property
    def calendar(self) -> Calendar:
        """Get the calendar instance."""
        return self._calendar

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """
        Get the next scheduled run datetime.

        Must be implemented by subclasses.

        Args:
            now: Current datetime

        Returns:
            Next scheduled run datetime
        """
        raise NotImplementedError("Subclasses must implement _get_next_run_datetime")

    def remaining_estimate(self, last_run_at: datetime) -> timedelta:
        """
        Estimate time remaining until next run.

        Args:
            last_run_at: Last time task was run

        Returns:
            Time remaining until next run
        """
        now = self.now()
        next_run = self._get_next_run_datetime(now)
        remaining = next_run - now
        return max(remaining, timedelta(seconds=0))

    def is_due(self, last_run_at: datetime) -> schedstate:
        """
        Check if task is due to run.

        Args:
            last_run_at: Last time task was run

        Returns:
            schedstate with is_due and next check time
        """
        now = self.now()

        # Ensure last_run_at is aware if now is aware
        if last_run_at.tzinfo is None and now.tzinfo is not None:
            last_run_at = last_run_at.replace(tzinfo=now.tzinfo)  # Assume same TZ if naive

        # Calculate when the next run should happen relative to the last run
        next_run = self._get_next_run_datetime(last_run_at)

        if now >= next_run:
            # It's time to run
            return schedstate(is_due=True, next=self.remaining_estimate(now).total_seconds())
        else:
            # Not time yet
            remaining = next_run - now
            return schedstate(is_due=False, next=max(remaining.total_seconds(), 0))

    def now(self) -> datetime:
        """Get current datetime in calendar timezone."""
        return datetime.now(self.tz)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(run_at={self.run_at}, calendar='{self._calendar.name}')"

    def __eq__(self, other) -> bool:
        if isinstance(other, BusinessDaySchedule):
            return self.run_at == other.run_at and self._calendar.name == other._calendar.name
        return False

    def __reduce__(self):
        return (
            self.__class__,
            (self.run_at, self._calendar.name),
            None,
        )


class FirstBusinessDayOfMonth(BusinessDaySchedule):
    """
    Schedule that runs on the first business day of each month.

    Example:
        # Run on first business day at 9 AM using default calendar
        schedule = FirstBusinessDayOfMonth()

        # Run on first business day at 8:30 AM using US Federal calendar
        schedule = FirstBusinessDayOfMonth(run_at=time(8, 30), calendar="USFederal")
    """

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next first business day of month."""
        today = now.date()
        this_month_first_bd = self._calendar.first_business_day_of_month(today.year, today.month)
        this_month_run = datetime.combine(this_month_first_bd, self.run_at, self.tz)

        if now < this_month_run:
            return this_month_run

        # Move to next month
        if today.month == 12:
            next_year, next_month = today.year + 1, 1
        else:
            next_year, next_month = today.year, today.month + 1

        next_month_first_bd = self._calendar.first_business_day_of_month(next_year, next_month)
        return datetime.combine(next_month_first_bd, self.run_at, self.tz)


class LastBusinessDayOfMonth(BusinessDaySchedule):
    """
    Schedule that runs on the last business day of each month.

    Example:
        # Run on last business day at 5 PM
        schedule = LastBusinessDayOfMonth(run_at=time(17, 0))
    """

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next last business day of month."""
        today = now.date()
        this_month_last_bd = self._calendar.last_business_day_of_month(today.year, today.month)
        this_month_run = datetime.combine(this_month_last_bd, self.run_at, self.tz)

        if now < this_month_run:
            return this_month_run

        # Move to next month
        if today.month == 12:
            next_year, next_month = today.year + 1, 1
        else:
            next_year, next_month = today.year, today.month + 1

        next_month_last_bd = self._calendar.last_business_day_of_month(next_year, next_month)
        return datetime.combine(next_month_last_bd, self.run_at, self.tz)


class NthBusinessDayOfMonth(BusinessDaySchedule):
    """
    Schedule that runs on the nth business day of each month.

    Example:
        # Run on 5th business day at 10 AM
        schedule = NthBusinessDayOfMonth(n=5, run_at=time(10, 0))

        # Run on 2nd to last business day
        schedule = NthBusinessDayOfMonth(n=-2)
    """

    def __init__(
        self,
        n: int,
        run_at: time = time(9, 0),
        calendar: str | Calendar | None = None,
        app=None,
    ):
        """
        Initialize nth business day schedule.

        Args:
            n: Which business day (1-based, negative counts from end)
            run_at: Time of day to run
            calendar: Calendar to use
            app: service app (service layer (Celery))
        """
        super().__init__(run_at=run_at, calendar=calendar, app=app)
        if n == 0:
            raise ValueError("n cannot be 0")
        self.n = n

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next nth business day of month."""
        today = now.date()

        try:
            this_month_nth_bd = self._calendar.nth_business_day_of_month(today.year, today.month, self.n)
            this_month_run = datetime.combine(this_month_nth_bd, self.run_at, self.tz)

            if now < this_month_run:
                return this_month_run
        except ValueError:
            pass  # This month doesn't have enough business days

        # Move to next month
        if today.month == 12:
            next_year, next_month = today.year + 1, 1
        else:
            next_year, next_month = today.year, today.month + 1

        next_month_nth_bd = self._calendar.nth_business_day_of_month(next_year, next_month, self.n)
        return datetime.combine(next_month_nth_bd, self.run_at, self.tz)

    def __repr__(self) -> str:
        return f"NthBusinessDayOfMonth(n={self.n}, run_at={self.run_at}, calendar='{self._calendar.name}')"

    def __reduce__(self):
        return (
            self.__class__,
            (self.n, self.run_at, self._calendar.name),
            None,
        )


class FirstBusinessDayOfQuarter(BusinessDaySchedule):
    """
    Schedule that runs on the first business day of each quarter.

    Quarters: Q1 (Jan-Mar), Q2 (Apr-Jun), Q3 (Jul-Sep), Q4 (Oct-Dec)

    Example:
        schedule = FirstBusinessDayOfQuarter(run_at=time(9, 0))
    """

    def _get_current_quarter(self, month: int) -> int:
        """Get quarter number from month."""
        return (month - 1) // 3 + 1

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next first business day of quarter."""
        today = now.date()
        current_quarter = self._get_current_quarter(today.month)

        this_quarter_first_bd = self._calendar.first_business_day_of_quarter(today.year, current_quarter)
        this_quarter_run = datetime.combine(this_quarter_first_bd, self.run_at, self.tz)

        if now < this_quarter_run:
            return this_quarter_run

        # Move to next quarter
        if current_quarter == 4:
            next_year, next_quarter = today.year + 1, 1
        else:
            next_year, next_quarter = today.year, current_quarter + 1

        next_quarter_first_bd = self._calendar.first_business_day_of_quarter(next_year, next_quarter)
        return datetime.combine(next_quarter_first_bd, self.run_at, self.tz)


class LastBusinessDayOfQuarter(BusinessDaySchedule):
    """
    Schedule that runs on the last business day of each quarter.

    Example:
        schedule = LastBusinessDayOfQuarter(run_at=time(17, 0))
    """

    def _get_current_quarter(self, month: int) -> int:
        """Get quarter number from month."""
        return (month - 1) // 3 + 1

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next last business day of quarter."""
        today = now.date()
        current_quarter = self._get_current_quarter(today.month)

        this_quarter_last_bd = self._calendar.last_business_day_of_quarter(today.year, current_quarter)
        this_quarter_run = datetime.combine(this_quarter_last_bd, self.run_at, self.tz)

        if now < this_quarter_run:
            return this_quarter_run

        # Move to next quarter
        if current_quarter == 4:
            next_year, next_quarter = today.year + 1, 1
        else:
            next_year, next_quarter = today.year, current_quarter + 1

        next_quarter_last_bd = self._calendar.last_business_day_of_quarter(next_year, next_quarter)
        return datetime.combine(next_quarter_last_bd, self.run_at, self.tz)


class FirstBusinessDayOfYear(BusinessDaySchedule):
    """
    Schedule that runs on the first business day of each year.

    Example:
        schedule = FirstBusinessDayOfYear(run_at=time(9, 0))
    """

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next first business day of year."""
        today = now.date()

        this_year_first_bd = self._calendar.first_business_day_of_year(today.year)
        this_year_run = datetime.combine(this_year_first_bd, self.run_at, self.tz)

        if now < this_year_run:
            return this_year_run

        # Move to next year
        next_year_first_bd = self._calendar.first_business_day_of_year(today.year + 1)
        return datetime.combine(next_year_first_bd, self.run_at, self.tz)


class LastBusinessDayOfYear(BusinessDaySchedule):
    """
    Schedule that runs on the last business day of each year.

    Example:
        schedule = LastBusinessDayOfYear(run_at=time(17, 0))
    """

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next last business day of year."""
        today = now.date()

        this_year_last_bd = self._calendar.last_business_day_of_year(today.year)
        this_year_run = datetime.combine(this_year_last_bd, self.run_at, self.tz)

        if now < this_year_run:
            return this_year_run

        # Move to next year
        next_year_last_bd = self._calendar.last_business_day_of_year(today.year + 1)
        return datetime.combine(next_year_last_bd, self.run_at, self.tz)


class EveryBusinessDay(BusinessDaySchedule):
    """
    Schedule that runs every business day at a specific time.

    Example:
        # Run every business day at 9 AM
        schedule = EveryBusinessDay(run_at=time(9, 0))

        # Run every business day at 6 PM using US Federal calendar
        schedule = EveryBusinessDay(run_at=time(18, 0), calendar="USFederal")
    """

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next business day run time."""
        today = now.date()
        today_run = datetime.combine(today, self.run_at, self.tz)

        if self._calendar.is_business_day(today) and now < today_run:
            return today_run

        # Find next business day
        next_bd = self._calendar.next_business_day(today + timedelta(days=1))
        return datetime.combine(next_bd, self.run_at, self.tz)


class SpecificDayOfMonth(BusinessDaySchedule):
    """
    Schedule that runs on a specific day of month, adjusted to business day.

    If the specified day falls on a non-business day, it can be adjusted
    to the previous or next business day.

    Example:
        # Run on the 15th (or previous business day if 15th is not a business day)
        schedule = SpecificDayOfMonth(day=15, adjust="previous")

        # Run on the 1st (or next business day)
        schedule = SpecificDayOfMonth(day=1, adjust="next")
    """

    def __init__(
        self,
        day: int,
        run_at: time = time(9, 0),
        adjust: str = "previous",  # "previous", "next", or "exact"
        calendar: str | Calendar | None = None,
        app=None,
    ):
        """
        Initialize specific day schedule.

        Args:
            day: Day of month (1-31)
            run_at: Time of day to run
            adjust: How to adjust non-business days ("previous", "next", "exact")
            calendar: Calendar to use
            app: Celery app
        """
        super().__init__(run_at=run_at, calendar=calendar, app=app)
        if not 1 <= day <= 31:
            raise ValueError("day must be between 1 and 31")
        self.day = day
        self.adjust = adjust

    def _get_adjusted_date(self, year: int, month: int) -> date | None:
        """Get the (adjusted) date for a month."""
        import calendar as cal

        _, last_day = cal.monthrange(year, month)

        # Handle months with fewer days
        actual_day = min(self.day, last_day)
        target_date = date(year, month, actual_day)

        if self.adjust == "exact":
            return target_date if self._calendar.is_business_day(target_date) else None
        elif self.adjust == "previous":
            return self._calendar.previous_business_day(target_date)
        elif self.adjust == "next":
            return self._calendar.next_business_day(target_date)
        else:
            raise ValueError(f"Invalid adjust value: {self.adjust}")

    def _get_next_run_datetime(self, now: datetime) -> datetime:
        """Get next specific day run time."""
        today = now.date()

        # Try this month
        this_month_date = self._get_adjusted_date(today.year, today.month)
        if this_month_date:
            this_month_run = datetime.combine(this_month_date, self.run_at, self.tz)
            if now < this_month_run:
                return this_month_run

        # Try next month
        if today.month == 12:
            next_year, next_month = today.year + 1, 1
        else:
            next_year, next_month = today.year, today.month + 1

        next_month_date = self._get_adjusted_date(next_year, next_month)
        if next_month_date:
            return datetime.combine(next_month_date, self.run_at, self.tz)

        # Keep trying months (rare case of "exact" adjustment)
        for _ in range(12):
            if next_month == 12:
                next_year, next_month = next_year + 1, 1
            else:
                next_month += 1

            next_date = self._get_adjusted_date(next_year, next_month)
            if next_date:
                return datetime.combine(next_date, self.run_at, self.tz)

        raise ValueError(f"Could not find a valid date for day {self.day}")

    def __repr__(self) -> str:
        return f"SpecificDayOfMonth(day={self.day}, run_at={self.run_at}, adjust='{self.adjust}', calendar='{self._calendar.name}')"

    def __reduce__(self):
        return (
            self.__class__,
            (self.day, self.run_at, self.adjust, self._calendar.name),
            None,
        )


# =============================================================================
# Convenience functions for creating schedules
# =============================================================================


def first_business_day(
    period: str = "month",
    run_at: time = time(9, 0),
    calendar: str | None = None,
) -> BusinessDaySchedule:
    """
    Create a first business day schedule.

    Args:
        period: "month", "quarter", or "year"
        run_at: Time of day to run
        calendar: Calendar name

    Returns:
        Appropriate schedule instance
    """
    if period == "month":
        return FirstBusinessDayOfMonth(run_at=run_at, calendar=calendar)
    elif period == "quarter":
        return FirstBusinessDayOfQuarter(run_at=run_at, calendar=calendar)
    elif period == "year":
        return FirstBusinessDayOfYear(run_at=run_at, calendar=calendar)
    else:
        raise ValueError(f"Invalid period: {period}")


def last_business_day(
    period: str = "month",
    run_at: time = time(17, 0),
    calendar: str | None = None,
) -> BusinessDaySchedule:
    """
    Create a last business day schedule.

    Args:
        period: "month", "quarter", or "year"
        run_at: Time of day to run
        calendar: Calendar name

    Returns:
        Appropriate schedule instance
    """
    if period == "month":
        return LastBusinessDayOfMonth(run_at=run_at, calendar=calendar)
    elif period == "quarter":
        return LastBusinessDayOfQuarter(run_at=run_at, calendar=calendar)
    elif period == "year":
        return LastBusinessDayOfYear(run_at=run_at, calendar=calendar)
    else:
        raise ValueError(f"Invalid period: {period}")


def nth_business_day(
    n: int,
    run_at: time = time(9, 0),
    calendar: str | None = None,
) -> NthBusinessDayOfMonth:
    """
    Create an nth business day of month schedule.

    Args:
        n: Which business day (1-based, negative for counting from end)
        run_at: Time of day to run
        calendar: Calendar name

    Returns:
        NthBusinessDayOfMonth schedule
    """
    return NthBusinessDayOfMonth(n=n, run_at=run_at, calendar=calendar)


def every_business_day(
    run_at: time = time(9, 0),
    calendar: str | None = None,
) -> EveryBusinessDay:
    """
    Create an every business day schedule.

    Args:
        run_at: Time of day to run
        calendar: Calendar name

    Returns:
        EveryBusinessDay schedule
    """
    return EveryBusinessDay(run_at=run_at, calendar=calendar)
