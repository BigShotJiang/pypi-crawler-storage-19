"""
AWS EventBridge Scheduler Deployment.

This module handles the deployment of periodic tasks to AWS EventBridge.
It discovers tasks, converts schedules, and updates AWS rules.
"""

import json
import logging
from datetime import timedelta
from typing import Any

from vaultdb.scheduler.schedules import BusinessDaySchedule

from ..service.celery_proxy import crontab
from .aws_schedule import AWSEventBridge
from .aws_schedule import create_event_rule
from .discovery import autodiscover_schedules

logger = logging.getLogger(__name__)


def service_to_aws_schedule(schedule_obj: Any) -> str:
    """
    Convert a service (Celery) schedule object to an AWS EventBridge schedule expression.
    """
    if isinstance(schedule_obj, crontab):
        # Service (Celery): minute, hour, day_of_week, day_of_month, month_of_year
        # AWS: cron(Minutes Hours Day-of-month Month Day-of-week Year)

        minute = schedule_obj._orig_minute or "*"
        hour = schedule_obj._orig_hour or "*"
        day_of_month = schedule_obj._orig_day_of_month or "*"
        month = schedule_obj._orig_month_of_year or "*"
        day_of_week = schedule_obj._orig_day_of_week or "*"

        # AWS cron specific adjustments
        # If day_of_month is *, day_of_week must be ? and vice versa
        if day_of_month == "*" and day_of_week != "*":
            day_of_month = "?"
        elif day_of_month != "*" and day_of_week == "*":
            day_of_week = "?"
        elif day_of_month == "*" and day_of_week == "*":
            day_of_week = "?"

        # Map day names if necessary (Service/Celery might use 0-6, AWS uses MON-SUN or 1-7)
        # Assuming standard cron format for now.

        return f"cron({minute} {hour} {day_of_month} {month} {day_of_week} *)"

    elif isinstance(schedule_obj, timedelta):
        total_seconds = int(schedule_obj.total_seconds())
        if total_seconds % 86400 == 0:
            val = total_seconds // 86400
            unit = "day" if val == 1 else "days"
            return f"rate({val} {unit})"
        elif total_seconds % 3600 == 0:
            val = total_seconds // 3600
            unit = "hour" if val == 1 else "hours"
            return f"rate({val} {unit})"
        else:
            val = max(1, total_seconds // 60)
            unit = "minute" if val == 1 else "minutes"
            return f"rate({val} {unit})"

    elif isinstance(schedule_obj, int):
        # Assume seconds
        val = max(1, schedule_obj // 60)
        unit = "minute" if val == 1 else "minutes"
        return f"rate({val} {unit})"

    elif isinstance(schedule_obj, BusinessDaySchedule):
        # Business Day schedules rely on app-layer calendar logic and cannot be
        # converted to simple cron/rate expressions for EventBridge.
        raise ValueError("BusinessDaySchedule is not supported by AWS EventBridge. Use RedisScheduler (Service Beat) instead.")

    raise ValueError(f"Unsupported schedule type: {type(schedule_obj)}")


def deploy_schedules(prefix: str = "vaultdb-"):
    """
    Deploy discovered schedules to AWS EventBridge.

    Args:
        prefix: Prefix for rule names to manage.
    """
    print("Discovering tasks...")
    # We need a dummy app or current_app to discover schedules
    from vaultdb.service import Service

    app = Service("vaultdb_deploy")
    beat_schedule = autodiscover_schedules(app)

    if not beat_schedule:
        print("No periodic tasks found.")
        return

    eventbridge = AWSEventBridge()

    # 1. Clear existing rules
    print("Clearing existing rules...")
    try:
        # List rules (this is a simplified listing, real implementation might need pagination)
        response = eventbridge.client.list_rules(NamePrefix=prefix)
        for rule in response.get("Rules", []):
            print(f"Deleting rule: {rule['Name']}")
            eventbridge.delete_rule(rule["Name"])
    except Exception as e:
        print(f"Error listing/deleting rules: {e}")

    # 2. Create new rules
    print("Creating new rules...")
    for name, config in beat_schedule.items():
        try:
            rule_name = f"{prefix}{name.replace('.', '-').replace('_', '-')}"
            # Ensure name length limit (64 chars)
            rule_name = rule_name[:64]

            schedule_expr = service_to_aws_schedule(config["schedule"])

            # Construct target (assuming Lambda target for now, or generic bus)
            # The task arguments need to be passed.
            # For this implementation, we'll assume a generic target that dispatches the task.

            task_payload = {
                "payload": config["task"],
                "args": config.get("args", []),
                "kwargs": config.get("kwargs", {}),
            }

            # Note: You need a valid ARN for the target.
            # We'll use a placeholder or config value.
            from vaultdb import config

            target_arn = config.compute_function_name

            targets = [{"Id": "VaultDBWorker", "Arn": target_arn, "Input": json.dumps(task_payload)}]

            rule_config = create_event_rule(name=rule_name, schedule_expression=schedule_expr, description=f"Schedule for {name}", targets=targets)

            eventbridge.create_rule(rule_config)
            print(f"Created rule: {rule_name} -> {schedule_expr}")

        except ValueError as ve:
            print(f"Skipping rule for {name}: {ve}")
        except Exception as e:
            print(f"Failed to create rule for {name}: {e}")


if __name__ == "__main__":
    deploy_schedules()
