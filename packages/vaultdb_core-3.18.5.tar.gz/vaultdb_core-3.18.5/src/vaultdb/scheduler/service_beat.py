"""
Service beat scheduler (service layer (Celery)) with Redis backend and locking.

This module implements a custom service beat scheduler (service layer (Celery)) that:
1. Uses Redis for distributed locking (leader election).
2. Persists schedule state to Redis (ElastiCache).
"""

import logging
import pickle

import redis

from vaultdb.config import redis_cache_url

from ..service.celery_proxy import ScheduleEntry
from ..service.celery_proxy import Scheduler
from .discovery import autodiscover_schedules

logger = logging.getLogger(__name__)


class RedisScheduleEntry(ScheduleEntry):
    """ScheduleEntry that is picklable."""

    pass


class RedisScheduler(Scheduler):
    """
    Scheduler that stores schedule in Redis and uses a lock to ensure single execution.
    """

    Entry = RedisScheduleEntry

    def __init__(self, *args, **kwargs):
        self._redis = redis.from_url(redis_cache_url)
        self._lock_key = "vaultdb_scheduler_lock"
        self._schedule_key = "vaultdb_scheduler_data"
        self._lock_timeout = 60  # seconds
        # Use a Lua script for safe lock extension
        self._lock = self._redis.lock(self._lock_key, timeout=self._lock_timeout)
        self._is_leader = False
        super().__init__(*args, **kwargs)

    def setup_schedule(self):
        """Initialize the schedule."""
        # Discover tasks
        self.app.conf.beat_schedule = autodiscover_schedules(self.app)

        # Load persisted state from Redis if available
        saved_schedule = self._load_from_redis()

        # Merge discovered tasks with saved state (to keep last_run_at)
        self.merge_inplace(self.app.conf.beat_schedule)

        if saved_schedule:
            logger.info("Loaded schedule state from Redis")
            # Update entries with saved state (last_run_at, etc.)
            for name, entry in saved_schedule.items():
                if name in self.schedule:
                    self.schedule[name].last_run_at = entry.last_run_at
                    self.schedule[name].total_run_count = entry.total_run_count

        self.install_default_entries(self.schedule)
        self.sync()

    def _load_from_redis(self) -> dict[str, ScheduleEntry] | None:
        """Load schedule state from Redis."""
        try:
            data = self._redis.get(self._schedule_key)
            if data:
                return pickle.loads(data)
        except Exception as e:
            logger.error(f"Failed to load schedule from Redis: {e}")
        return None

    def sync(self):
        """Save schedule state to Redis."""
        if not self._is_leader:
            return

        logger.debug("Syncing schedule to Redis")
        self._save_to_redis()

    def _save_to_redis(self):
        """Save current schedule to Redis."""
        try:
            # We only need to save the state, not the definition, but saving the whole entry is easier
            # Filter out entries that shouldn't be pickled if necessary
            data = pickle.dumps(self.schedule)
            self._redis.set(self._schedule_key, data)
        except Exception as e:
            logger.error(f"Failed to save schedule to Redis: {e}")

    def tick(self, *args, **kwargs):
        """
        Run a tick of the scheduler.

        Returns:
            float: The number of seconds to sleep until the next tick.
        """
        if not self._is_leader:
            # Try to acquire lock
            try:
                # blocking=False ensures we don't wait here
                if self._lock.acquire(blocking=False):
                    self._is_leader = True
                    logger.info("Acquired scheduler leader lock")
                    # Reload state when becoming leader to ensure we have latest
                    self.setup_schedule()
                else:
                    # Not leader, sleep and retry
                    return 5.0
            except Exception as e:
                logger.error(f"Error acquiring lock: {e}")
                return 5.0
        else:
            # We are leader, extend lock
            try:
                self._lock.extend(self._lock_timeout)
            except redis.exceptions.LockError:
                self._is_leader = False
                logger.warning("Lost scheduler leader lock")
                return 1.0
            except Exception as e:
                logger.error(f"Error extending lock: {e}")
                self._is_leader = False
                return 1.0

        return super().tick(*args, **kwargs)

    def close(self):
        """Cleanup when scheduler exits."""
        if self._is_leader:
            try:
                self._lock.release()
            except Exception:
                pass
        super().close()
