import functools
from typing import Any

from .registry import ScheduledTaskRegistry


def scheduled(schedule: Any, args: tuple = (), kwargs: dict = None, **options):
    """
    Decorator to schedule a task.

    Args:
        schedule: The schedule (float for seconds, or service schedules: service layer (Celery) crontab).
        args: Positional arguments for the task.
        kwargs: Keyword arguments for the task.
        **options: Additional options for the scheduler (e.g. options passed to apply_async).
    """

    def decorator(func):
        # Register the task
        # We assume the task name is the function name or the name assigned by the service layer (service layer (Celery))
        # If it's a service task (service layer (Celery)), it might have a 'name' attribute, but often that's set later.
        # We'll try to get the name, but we might need to rely on the user ensuring the task is registered.

        # Actually, we should probably wrap the function so that when it's registered as a task,
        # we can capture the final task name. But for simplicity, let's assume the user applies
        # this decorator *before* or *after* @app.task?
        # If applied *after* @app.task (outer), func is the Task object.
        # If applied *before* @app.task (inner), func is the function.

        # Let's support both if possible, or define a convention.
        # Convention: @scheduled(...) should be above @app.task if possible, or we handle both.
        # Actually, if we use it on a function that is later decorated with @app.task,
        # we might not know the final task name yet.

        # Alternative: This decorator *is* the registration mechanism, and we assume the task name
        # will be `module.function`.

        task_name = f"{func.__module__}.{func.__name__}"

        # If it's already a service task object (service layer (Celery))
        if hasattr(func, "name") and func.name:
            task_name = func.name

        ScheduledTaskRegistry.register(task_name=task_name, schedule=schedule, args=args, kwargs=kwargs, options=options)

        @functools.wraps(func)
        def wrapper(*f_args, **f_kwargs):
            return func(*f_args, **f_kwargs)

        return wrapper

    return decorator
