from dataclasses import dataclass
from dataclasses import field
from typing import Any


@dataclass
class ScheduledTask:
    task_name: str
    schedule: Any  # crontab or float
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    options: dict = field(default_factory=dict)


class ScheduledTaskRegistry:
    _tasks: dict[str, ScheduledTask] = {}

    @classmethod
    def register(cls, task_name: str, schedule: Any, args: tuple = (), kwargs: dict | None = None, options: dict | None = None) -> None:
        if kwargs is None:
            kwargs = {}
        if options is None:
            options = {}

        cls._tasks[task_name] = ScheduledTask(task_name=task_name, schedule=schedule, args=args, kwargs=kwargs, options=options)

    @classmethod
    def get_all(cls) -> dict[str, ScheduledTask]:
        return cls._tasks

    @classmethod
    def clear(cls) -> None:
        cls._tasks = {}
