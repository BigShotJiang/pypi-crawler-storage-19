"""
Task discovery utility.

This module provides functionality to discover and register tasks from *_tasks.py files
throughout the application.
"""

import importlib
import os
from typing import Any


def discover_tasks(packages: list[str] | None = None, pattern: str = "*_tasks.py", exclude: list[str] | None = None) -> None:
    """
    Discover and import modules to register tasks.

    Args:
        packages: List of packages to search within. Defaults to ["vaultdb"].
        pattern: Glob pattern for file matching. Defaults to "*_tasks.py".
        exclude: List of directory names to exclude.
    """
    if packages is None:
        packages = ["vaultdb"]

    if exclude is None:
        exclude = []

    for package_name in packages:
        try:
            package = importlib.import_module(package_name)
        except ImportError:
            print(f"Could not import package {package_name}")
            continue

        if not hasattr(package, "__path__"):
            continue

        path = package.__path__[0]  # type: ignore

        # Walk through the directory
        for root, dirs, files in os.walk(path):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude]

            for filename in files:
                if (pattern == "*_tasks.py" and (filename.endswith("_tasks.py") or filename == "tasks.py")) or (
                    pattern != "*_tasks.py" and filename.endswith(pattern.replace("*", ""))
                ):
                    # Construct module path
                    rel_path = os.path.relpath(os.path.join(root, filename), os.path.dirname(path))
                    module_name = f"{os.path.basename(os.path.dirname(path))}.{rel_path.replace(os.path.sep, '.')[:-3]}"

                    # Fix module name if it starts with src.
                    if module_name.startswith("src."):
                        module_name = module_name[4:]

                    # Fix module name if it starts with .
                    if module_name.startswith("."):
                        module_name = module_name[1:]

                    # Import the module
                    try:
                        importlib.import_module(module_name)
                        print(f"Discovered tasks in {module_name}")
                    except ImportError as e:
                        print(f"Failed to import {module_name}: {e}")
                    except Exception as e:
                        print(f"Error importing {module_name}: {e}")


def autodiscover_schedules(app: Any = None) -> dict:
    """
    Discover tasks and return the beat schedule.

    Args:
        app: service app instance (service layer (Celery)). If None, uses current_app.

    Returns:
        dict: The beat schedule configuration.
    """
    if app is None:
        from ..service.celery_proxy import current_app

        app = current_app

    discover_tasks()

    # Register tasks from the registry to the service beat schedule (service layer (Celery))
    from .registry import ScheduledTaskRegistry

    registry = ScheduledTaskRegistry()
    for name, task in registry.get_all().items():
        app.conf.beat_schedule[name] = {"task": task.task_name, "schedule": task.schedule, "args": task.args, "kwargs": task.kwargs, **task.options}

    return app.conf.beat_schedule
