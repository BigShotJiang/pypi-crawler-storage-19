import boto3

from vaultdb import settings


class AWSEventSchedule:
    def __init__(self):
        self.cron_expressions = {
            "daily": "cron(0 0 * * ? *)",  # Run at midnight every day
            "weekdays": "cron(0 0 ? * MON-FRI *)",  # Run at midnight Monday through Friday
            "hourly": "cron(0 * * * ? *)",  # Run at the beginning of every hour
            "weekly": "cron(0 0 ? * SUN *)",  # Run at midnight every Sunday
            "monthly": "cron(0 0 1 * ? *)",  # Run at midnight on the first of every month
        }

        self.rate_expressions = {"minutes": "rate({} minutes)", "hours": "rate({} hours)", "days": "rate({} days)"}

    def create_cron_schedule(
        self, minute: str = "*", hour: str = "*", day_of_month: str = "*", month: str = "*", day_of_week: str = "?", year: str = "*"
    ) -> str:
        """
        Create a custom cron expression
        Format: cron(minute hour day-of-month month day-of-week year)
        """
        return f"cron({minute} {hour} {day_of_month} {month} {day_of_week} {year})"

    def create_rate_schedule(self, value: int, unit: str) -> str:
        """
        Create a rate expression
        Units can be: minutes, hours, days
        """
        if unit not in self.rate_expressions:
            raise ValueError(f"Invalid unit. Must be one of: {list(self.rate_expressions.keys())}")

        return self.rate_expressions[unit].format(value)

    def get_predefined_schedule(self, schedule_type: str) -> str:
        """Get a predefined cron schedule"""
        return self.cron_expressions.get(schedule_type, "")

    def validate_schedule(self, schedule: str) -> bool:
        """Basic validation of schedule expression"""
        if schedule.startswith("cron(") and schedule.endswith(")"):
            parts = schedule[5:-1].split()
            return len(parts) == 6
        elif schedule.startswith("rate(") and schedule.endswith(")"):
            return True
        return False


def create_event_rule(name: str, schedule_expression: str, description: str = "", targets: list = None) -> dict:
    """
    Create an AWS EventBridge rule configuration
    """
    rule = {"Name": name, "ScheduleExpression": schedule_expression, "State": "ENABLED"}

    if description:
        rule["Description"] = description

    if targets:
        rule["Targets"] = targets

    return rule


class AWSEventBridge:
    def __init__(self):
        self.client = boto3.client("events", **settings.aws_credentials)

    def create_rule(self, rule_config: dict) -> dict:
        """
        Create an EventBridge rule in AWS
        """
        response = self.client.put_rule(
            Name=rule_config["Name"],
            ScheduleExpression=rule_config["ScheduleExpression"],
            State=rule_config["State"],
            Description=rule_config.get("Description", ""),
        )

        # If targets are specified, add them to the rule
        if "Targets" in rule_config:
            self.client.put_targets(Rule=rule_config["Name"], Targets=rule_config["Targets"])

        return response

    def delete_rule(self, rule_name: str) -> dict:
        """
        Delete an EventBridge rule
        """
        # Remove all targets first
        self.client.remove_targets(Rule=rule_name, Force=True)

        # Delete the rule
        return self.client.delete_rule(Name=rule_name)


# Usage example with AWS
def aws_example():
    scheduler = AWSEventSchedule()
    eventbridge = AWSEventBridge()

    # Create a daily schedule
    schedule = scheduler.get_predefined_schedule("daily")

    # Create rule configuration
    rule_config = create_event_rule(
        name="DailyBackupTask",
        schedule_expression=schedule,
        description="Daily backup task",
        targets=[{"Id": "BackupLambda", "Arn": "arn:aws:lambda:region:account-id:function:backup-function", "Input": '{"key": "value"}'}],
    )

    # Create the rule in AWS
    response = eventbridge.create_rule(rule_config)
    print(f"Created rule: {response}")


if __name__ == "__main__":
    aws_example()
