"""
Service Beat Scheduler (Celery) entry point.

This script initializes the service app, discovers tasks, and starts the
service beat (Celery) service using the Redis-backed scheduler.
"""

import os
import sys

# Ensure src is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

from vaultdb.scheduler import RedisScheduler
from vaultdb.service import setup_service

# Setup the runner and app (handles task discovery)
runner = setup_service()
app = runner.service_app

if __name__ == "__main__":
    print("Starting Redis-backed Service Beat Scheduler (Celery)...")
    # Start the beat service with our custom scheduler
    beat = app.Beat(scheduler=RedisScheduler, loglevel="info")
    beat.run()
