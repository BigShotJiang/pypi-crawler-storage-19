# Standard library imports
import logging
from importlib import import_module

# Local imports
from vaultdb import auth
from vaultdb.compute.core import RunType
from vaultdb.compute.core import get_runner
from vaultdb.compute.core import is_running_in_batch
from vaultdb.compute.core import is_running_in_function
from vaultdb.compute.trace import TaskTracer
from vaultdb.core import Application
from vaultdb.scheduler.discovery import discover_tasks

# Configure logging
logger = logging.getLogger()


def task_handler(event: dict, context: dict) -> dict:
    """Function handler that processes incoming events and executes tasks.

    Args:
        event (dict): The event data containing token, catalog, payload and optional args
        context (dict): Lambda context object

    Returns:
        dict: Response containing result status and data/error message
    """
    logger.info(f"event: {event}!")

    try:
        # Determine role based on environment
        preferred_role: str = "vaultdb"
        if is_running_in_batch() or is_running_in_function():
            preferred_role = auth.get_authorized_role(event["token"])
        logger.debug(f"role: {preferred_role}")
        app = get_runner(RunType.FUNCTION)
        # List available tasks if no payload provided
        if "payload" not in event:
            discover_tasks()
            tasks = [
                {
                    "name": task.name,
                    "doc": task.__doc__,
                    "module": task.__module__,
                    "annotations": [name for name in task.run.__annotations__.keys() if hasattr(task, "run") and task.run],
                }
                for task in app.tasks.values()
            ]
            return {"result": "Success", "data": tasks}

        # Extract task parameters
        payload = event["payload"]
        payload_catalog: str = event.get("catalog", ":memory:")
        payload_args = event.get("args", [])
        payload_kwargs = event.get("kwargs", {})

        logger.debug(f"payload: {payload}")
        logger.debug(f"payload catalog: {payload_catalog}")
        logger.debug(f"args: {payload_args}")
        logger.debug(f"kwargs: {payload_kwargs}")

        # Execute task if it exists
        task = app.tasks.get(payload)
        if not task:
            try:
                # Fallback to import-based approach
                module_name = ".".join(payload.split(".")[:-1])
                job_name = payload.split(".")[-1]
                jobmodule = import_module(module_name)
                task = getattr(jobmodule, job_name)
            except Exception as ex:
                logger.error(ex)
                return {
                    "result": "Error",
                    "message": f"Invalid Payload {payload.strip()}.",
                }

        if not task:
            return {
                "result": "Error",
                "message": f"Invalid Payload {payload.strip()}.",
            }
        # Get or generate task_id
        task_id = event.get("task_id")
        if not task_id:
            from vaultdb.compute.utils import uuid

            task_id = uuid()

        with Application.execute_as(catalog=payload_catalog, role=preferred_role, clone=True):
            tracer = TaskTracer(task)
            if payload_args and payload_kwargs:
                result = tracer(*payload_args, task_id=task_id, **payload_kwargs)
            elif payload_args:
                result = tracer(*payload_args, task_id=task_id)
            elif payload_kwargs:
                result = tracer(task_id=task_id, **payload_kwargs)
            else:
                result = tracer(task_id=task_id)
            return {"result": "Success", "data": result}

        return {
            "result": "Error",
            "message": f"Invalid Payload {payload.strip()}.",
        }

    except Exception as ex:
        logger.error(ex)
        return {"result": "Error", "message": str(ex)}
    finally:
        app.close()


if __name__ == "__main__":
    token = (
        "eyJraWQiOiJSQzRnMW1mS2xPS1d1WHYrRHRzeFA5bytPSk43TVNFODBGTHd0akhkRGQwPSIsImFsZyI6IlJTMjU2In0."
        "eyJzdWIiOiI4NDE4MDQ5OC04MDcxLTBiMy1lY2MwLTU0NmI3NTM3ZTM2MiIsImNvZ25pdG86Z3JvdXBzIjpbInRlc3QtQWRtaW5pc3RyYXRvcnMiXSwiY29nbml0bzpwcmVmZ"
        "XJyZWRfcm9sZSI6ImFybjphd3M6aWFtOjo0NDA5NTUzNzYxNjQ6cm9sZVwvdGVzdC12YXVsdGRiLUFkbWluUm9sZSIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC5"
        "1cy1lYXN0LTEuYW1hem9uYXdzLmNvbVwvdXMtZWFzdC0xX3A4Y2ExQm41WiIsImNvZ25pdG86dXNlcm5hbWUiOiJ2YXVsdGRiIiwib3JpZ2luX2p0aSI6IjdjNmNhYTg0LT"
        "UzYjktNGJlMy04NjIzLWM2MTRjOTg3NTEyMCIsImNvZ25pdG86cm9sZXMiOlsiYXJuOmF3czppYW06OjQ0MDk1NTM3NjE2NDpyb2xlXC90ZXN0LXZhdWx0ZGItQWRtaW5Sb"
        "2xlIl0sImF1ZCI6IjZmaHNoamlpbDIwbTAzaW9sNGg3bnFpMW1vIiwiZXZlbnRfaWQiOiIyY2Y1ZTFiZC00MGE2LTQyZTYtOTc2OC03NmI0YjUxNjgxMWMiLCJ0b2tlbl9"
        "1c2UiOiJpZCIsImF1dGhfdGltZSI6MTczNjcyMjIxNiwibmFtZSI6InZhdWx0ZGIiLCJleHAiOjE3MzY3ODAxOTEsImlhdCI6MTczNjc3NjU5MSwianRpIjoiZTE3OWMxNDg"
        "tMGE4NS00NDJlLWIwZGMtOGRlZTNiMmQ3MTE0IiwiZW1haWwiOiJkZXZtY2hlY2hpQGdtYWlsLmNvbSJ9."
        "a23xI7mj6WgxlWAmnxB8cVfFojvTQ4FjBMjbHZMBf2jGXI6iy4m4K3ExJDwvIVkwMTm0OF_qWf04HijijxgRckPNZBlRQ4CF1Az-VzMHZPK7ZOBoeHwU-xGvRVGSms6WWg3"
        "ZrrDVhs7QjtB2ORx5OXfiAltJLZaa7plc5J80b9Kd3oobPg1DawcdTIqLE9wwMrHuLDuB3w3XyWNCwzSNaoV0hrd1iZeYDO8zYIXGzBTmXGx9hJIR4LVoEkZuRgOgZ9s4pJQ"
        "cKsRcWcFhtFuZf7UE7sX540_t49qc00_03w29UPbgqsilvE75kE7t2ZjijjElMw-r32aOVYLAq-0Gww"
    )
    event = {
        "token": token,
        "payload": "vaultdb.tasks.add",
        "args": (5, 10),
        "kwargs": {},
        "catalog": ":memory:",
        "valuationdate": "None",
        "role": "vaultdb",
        "task_id": "d2ad8a4c-73cf-414f-9897-a276d9f26afa",
    }

    context = {"identity": {"cognito_identity_id": "", "cognito_identity_pool_id": ""}}

    # Execute handler and print results
    result = task_handler(event, context)
    print(result)
