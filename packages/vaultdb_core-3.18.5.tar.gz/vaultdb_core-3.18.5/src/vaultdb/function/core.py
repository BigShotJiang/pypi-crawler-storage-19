import json
from typing import Any

import boto3

from .. import config
from .. import settings
from ..compute.core import Runner
from ..compute.core import RunType
from ..compute.result import AsyncResult


class FunctionRunner(Runner):
    task_cls = "vaultdb.function.task:FunctionTask"
    run_type = RunType.FUNCTION

    def payload(self, name: str, task_id: str | None = None, args: tuple | None = None, kwargs: dict | None = None) -> bytes:
        """Create payload for Function invocation.

        Args:
            name: Task name to execute.
            task_id: Optional task ID.
            args: Task positional arguments.
            kwargs: Task keyword arguments.

        Returns:
            JSON-encoded bytes payload for Function.
        """
        payload_dict: dict[str, Any] = {
            "payload": name,
            "args": args or [],
            "kwargs": kwargs or {},
            "catalog": settings.catalog,
            "valuationdate": str(settings.valuationdate) if hasattr(settings, "valuationdate") else None,
            "role": settings.role,
            "task_id": task_id,
        }
        return json.dumps(payload_dict).encode("utf-8")

    def getclient(self) -> Any:
        """Get boto3 Lambda client.

        Returns:
            boto3 Lambda client instance.
        """
        return boto3.client("lambda", **settings.aws_credentials)

    def send_task(
        self,
        name: str,
        args: tuple | None = None,
        kwargs: dict | None = None,
        countdown: float | None = None,
        eta: Any | None = None,
        task_id: Any | None = None,
        producer: Any | None = None,
        connection: Any | None = None,
        router: Any | None = None,
        result_cls: Any | None = None,
        expires: Any | None = None,
        publisher: Any | None = None,
        link: Any | None = None,
        link_error: Any | None = None,
        add_to_parent: Any = True,
        group_id: Any | None = None,
        group_index: Any | None = None,
        retries: Any = 0,
        chord: Any | None = None,
        reply_to: Any | None = None,
        time_limit: Any | None = None,
        soft_time_limit: Any | None = None,
        root_id: Any | None = None,
        parent_id: Any | None = None,
        route_name: Any | None = None,
        shadow: Any | None = None,
        chain: Any | None = None,
        task_type: Any | None = None,
        replaced_task_nesting: Any = 0,
        **options: Any,
    ) -> Any:
        """Send task by name.

        Supports the same arguments as :meth:`@-Task.apply_async`.

        Arguments:
            name (str): Name of task to call (e.g., `"tasks.add"`).
            result_cls (AsyncResult): Specify custom result class.
        """

        # Generate task_id if not provided
        if task_id is None:
            from ..compute.utils import uuid

            task_id = uuid()

        # Get function name from options or config
        function_name = options.get("function_name") or config.compute_function_name
        if not function_name:
            raise ValueError("Function name must be provided via options['function_name'] or config.compute_function_name")

        # Create payload
        payload_bytes = self.payload(name=name, task_id=task_id, args=args, kwargs=kwargs)

        # Invoke Function
        response = self.getclient().invoke(FunctionName=function_name, InvocationType="Event", Payload=payload_bytes)

        # Extract task_id from response
        request_id = response.get("ResponseMetadata", {}).get("RequestId", task_id)

        # Create and return AsyncResult
        result_cls = result_cls or AsyncResult
        return result_cls(task_id=request_id, response=response)
