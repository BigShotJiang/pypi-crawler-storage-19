"""VaultDB Function runner module."""

from .core import FunctionRunner

__all__ = ["FunctionRunner"]
