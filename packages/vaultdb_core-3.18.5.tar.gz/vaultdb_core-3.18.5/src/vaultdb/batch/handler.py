import logging
from importlib import import_module

from vaultdb.batch import argparser
from vaultdb.compute.trace import TaskTracer
from vaultdb.core import Application

# Configure logging
logger = logging.getLogger(__name__)


def main() -> None:
    """Main entry point for Batch job execution.

    Parses command line arguments, loads the task, and executes it
    with the provided arguments and catalog context.
    """
    try:
        # Parse arguments
        batchargs = argparser.parse_args()

        # Get task from current app
        from vaultdb.compute.core import RunType
        from vaultdb.compute.core import get_runner

        app = get_runner(runtype=RunType.BATCH)
        task = app.tasks.get(batchargs["job"])

        if not task:
            # Fallback to import-based approach
            module_name = ".".join(batchargs["job"].split(".")[:-1])
            job_name = batchargs["job"].split(".")[-1]
            jobmodule = import_module(module_name)
            job = getattr(jobmodule, job_name)
        else:
            job = task

        # Execute task with catalog context
        with Application.execute_as(catalog=batchargs["catalog"], role=batchargs["role"], clone=True):
            tracer = TaskTracer(job)
            # Get or generate task_id
            task_id = batchargs.get("task_id")
            if not task_id:
                from vaultdb.compute.utils import uuid

                task_id = uuid()
            result = tracer(*batchargs["args"], task_id=task_id, **batchargs["kwargs"])
            logger.info(f"Task {batchargs['job']} completed successfully")
            return result

    except Exception as e:
        logger.error(f"Error executing batch job: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
