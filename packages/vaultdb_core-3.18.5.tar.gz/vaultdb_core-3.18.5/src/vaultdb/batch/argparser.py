import argparse
import json
from typing import Any


def batch_argument_parser() -> argparse.ArgumentParser:
    """Create argument parser for Batch job execution.

    Returns:
        Configured ArgumentParser instance.
    """
    parser = argparse.ArgumentParser("vaultdb Batch argument parser")
    parser.add_argument("--job", type=str, required=True, help="Task name to execute")
    parser.add_argument("--args", type=str, default="[]", help="Job arguments as JSON string")
    parser.add_argument("--kwargs", type=str, default="{}", help="Job keyword arguments as JSON string")
    parser.add_argument("--valuationdate", type=str, default="", help="Valuation date")
    parser.add_argument("--catalog", type=str, default=":memory:", help="Catalog name")
    parser.add_argument("--role", type=str, default="vaultdb", help="Database execute as role")
    parser.add_argument("--task_id", type=str, default="", help="Task ID")
    parser.add_argument("--debug", action="store_true", help="Write debug logs")

    return parser


def parse_args() -> dict[str, Any]:
    """Parse command line arguments and return as dictionary.

    Returns:
        Dictionary with parsed arguments, with args and kwargs parsed from JSON.
    """
    parser = batch_argument_parser()
    args = parser.parse_args()

    # Parse JSON strings for args and kwargs
    parsed_args: list[Any] = []
    if args.args:
        try:
            parsed_args = json.loads(args.args)
            if not isinstance(parsed_args, list):
                parsed_args = [parsed_args]
        except json.JSONDecodeError:
            parsed_args = []

    parsed_kwargs: dict[str, Any] = {}
    if args.kwargs:
        try:
            parsed_kwargs = json.loads(args.kwargs)
            if not isinstance(parsed_kwargs, dict):
                parsed_kwargs = {}
        except json.JSONDecodeError:
            parsed_kwargs = {}

    return {
        "job": args.job,
        "args": parsed_args,
        "kwargs": parsed_kwargs,
        "valuationdate": args.valuationdate,
        "catalog": args.catalog,
        "role": args.role,
        "task_id": args.task_id,
        "debug": args.debug,
    }
