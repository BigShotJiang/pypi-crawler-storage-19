import time
from typing import Any

import boto3

from .. import settings
from ..compute.result import AsyncResult
from ..compute.taskstatus import TaskStatus


class AsyncBatchResult(AsyncResult):
    array_size: int = 1
    job_results: list[Any] = []
    errors: list[Any] = []
    task_status: list[TaskStatus] = []  # type: ignore[assignment]  # Override base class for batch jobs
    _log_group_name: str = ""
    _log_stream_name: str = ""
    _client: Any = None

    def __init__(
        self, task_id: str, array_size: int = 1, response: dict[str, str] | None = None, log_group_name: str | None = None, parent: Any = None
    ) -> None:
        self.array_size = array_size
        self._log_group_name = log_group_name or ""
        self.job_results = [None] * self.array_size
        self.errors = [None] * self.array_size
        super().__init__(task_id=task_id, response=response, parent=parent)

    def getclient(self) -> boto3.session.Session.client:
        self._client = boto3.client("batch", **settings.aws_credentials)
        return self._client

    @property
    def status(self) -> str:
        self._client = self.getclient()
        job_status = self._client.describe_jobs(jobs=[self.task_id])
        return job_status["jobs"][0]["status"]

    def get(
        self,
        timeout: Any = None,
        propagate: bool = True,
        interval: float = 0.5,
        no_ack: bool = True,
        follow_parents: bool = True,
        callback: Any = None,
        on_message: Any = None,
        on_interval: Any = None,
        disable_sync_subtasks: bool = True,
    ) -> Any:
        """
        Wait for AWS Batch job completion and return result or raise exception.

        Args:
            timeout: Maximum time to wait in seconds. If None, wait indefinitely.
            propagate: Whether to propagate exceptions from failed jobs.
            interval: Time interval between status checks in seconds.
            no_ack: Whether to acknowledge the message (unused in this implementation).
            follow_parents: Whether to follow parent tasks (unused in this implementation).
            callback: Callback function to call on completion (unused in this implementation).
            on_message: Callback function to call on message (unused in this implementation).
            on_interval: Callback function to call on each interval check (unused in this implementation).
            disable_sync_subtasks: Whether to disable sync subtasks (unused in this implementation).

        Returns:
            The job result if successful.

        Raises:
            RuntimeError: If job status cannot be retrieved.
            Exception: If job failed and propagate is True, raises the original exception.
            TimeoutError: If timeout is reached before job completion.
        """
        start_time = time.time()

        while True:
            # Get current job status
            current_status = self.status

            # Check if job is completed
            if current_status in {"SUCCEEDED", "FAILED"}:
                break

            # Check timeout
            if timeout is not None:
                elapsed_time = time.time() - start_time
                if elapsed_time >= timeout:
                    raise TimeoutError(f"Batch job {self.task_id} timed out after {timeout} seconds")

            # Wait before next check
            time.sleep(interval)

        # Handle completed job
        if current_status == "SUCCEEDED":
            # For batch jobs, we might want to return the job results
            # For now, return the job ID as success indicator
            return self.task_id

        elif current_status == "FAILED":
            if propagate:
                # Get detailed error information from AWS Batch
                try:
                    client = self.getclient()
                    job_details = client.describe_jobs(jobs=[self.task_id])
                    job = job_details["jobs"][0]

                    # Extract error information
                    error_msg = f"Batch job {self.task_id} failed"

                    # Check for job failure reason
                    if "statusReason" in job:
                        error_msg += f"\nStatus Reason: {job['statusReason']}"

                    # Check for container exit code and reason
                    if "attempts" in job and job["attempts"]:
                        last_attempt = job["attempts"][-1]
                        if "exitCode" in last_attempt:
                            error_msg += f"\nExit Code: {last_attempt['exitCode']}"
                        if "reason" in last_attempt:
                            error_msg += f"\nReason: {last_attempt['reason']}"
                        if "statusReason" in last_attempt:
                            error_msg += f"\nAttempt Status Reason: {last_attempt['statusReason']}"

                    # Check for stopped reason
                    if "stoppedAt" in job and job["stoppedAt"]:
                        error_msg += f"\nStopped At: {job['stoppedAt']}"

                    raise RuntimeError(error_msg)
                except Exception as e:
                    # If we can't get detailed error info, raise a generic error
                    if isinstance(e, RuntimeError):
                        raise
                    raise RuntimeError(f"Batch job {self.task_id} failed: {str(e)}")
            else:
                # If not propagating, return None or some indication of failure
                return None

        # This should not be reached, but just in case
        return None

    def revoke(self) -> None:
        """Revoke the task."""
        self._client.cancel_job(jobId=self.task_id)
        super().revoke()
