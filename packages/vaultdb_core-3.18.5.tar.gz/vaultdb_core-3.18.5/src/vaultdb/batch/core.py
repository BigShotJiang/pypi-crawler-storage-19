import json
from typing import Any

import boto3

from .. import config
from .. import settings
from ..compute.core import Runner
from ..compute.core import RunType
from ..compute.result import AsyncResult


class BatchRunner(Runner):
    task_cls = "vaultdb.batch.task:BatchTask"
    run_type = RunType.BATCH

    def command(self, name: str, task_id: str | None = None, args: tuple | None = None, kwargs: dict | None = None) -> list[str]:
        """Create command list for Batch job execution.

        Args:
            name: Task name to execute.
            task_id: Optional task ID.
            args: Task positional arguments.
            kwargs: Task keyword arguments.

        Returns:
            List of command arguments for Batch job.
        """
        cmd: list[str] = [
            "entrypoint.sh",
            "batch",
            "--job",
            name,
        ]

        if task_id:
            cmd.extend(["--task_id", task_id])

        if args:
            cmd.extend(["--args", json.dumps(args)])

        if kwargs:
            cmd.extend(["--kwargs", json.dumps(kwargs)])

        if hasattr(settings, "valuationdate") and settings.valuationdate:
            cmd.extend(["--valuationdate", str(settings.valuationdate)])

        if settings.catalog:
            cmd.extend(["--catalog", settings.catalog])

        if settings.role:
            cmd.extend(["--role", settings.role])

        if config.DEBUG:
            cmd.append("--debug")

        return cmd

    def getclient(self) -> Any:
        """Get boto3 Batch client.

        Returns:
            boto3 Batch client instance.
        """
        return boto3.client("batch", **settings.aws_credentials)

    def send_task(
        self,
        name: str,
        args: tuple | None = None,
        kwargs: dict | None = None,
        countdown: float | None = None,
        eta: Any | None = None,
        task_id: Any | None = None,
        producer: Any | None = None,
        connection: Any | None = None,
        router: Any | None = None,
        result_cls: Any | None = None,
        expires: Any | None = None,
        publisher: Any | None = None,
        link: Any | None = None,
        link_error: Any | None = None,
        add_to_parent: Any = True,
        group_id: Any | None = None,
        group_index: Any | None = None,
        retries: Any = 0,
        chord: Any | None = None,
        reply_to: Any | None = None,
        time_limit: Any | None = None,
        soft_time_limit: Any | None = None,
        root_id: Any | None = None,
        parent_id: Any | None = None,
        route_name: Any | None = None,
        shadow: Any | None = None,
        chain: Any | None = None,
        task_type: Any | None = None,
        replaced_task_nesting: Any = 0,
        **options: Any,
    ) -> Any:
        """Send task by name.

        Supports the same arguments as :meth:`@-Task.apply_async`.

        Arguments:
            name (str): Name of task to call (e.g., `"tasks.add"`).
            result_cls (AsyncResult): Specify custom result class.
        """
        # Generate task_id if not provided
        if task_id is None:
            from ..compute.utils import uuid

            task_id = uuid()

        # Prepare environment variables
        environment_variables: list[dict[str, str]] = []

        # Prepare resource requirements
        memory = options.get("memory", 1024)
        number_of_cpus = options.get("number_of_cpus", 1)
        number_of_gpus = options.get("number_of_gpus", 0)
        resource_requirements = [{"type": "MEMORY", "value": str(memory)}, {"type": "VCPU", "value": str(number_of_cpus)}]
        if number_of_gpus > 0:
            resource_requirements.append({"type": "GPU", "value": str(number_of_gpus)})

        # Prepare Batch job submission arguments
        batch_arguments: dict[str, Any] = {
            "jobName": name.replace(".", "_")[:128],  # AWS Batch job name restrictions
            "containerOverrides": {
                "command": self.command(name, task_id, args=args, kwargs=kwargs),
                "environment": environment_variables,
                "resourceRequirements": resource_requirements,
            },
        }

        # Add optional Batch-specific parameters
        if options.get("job_queue") or options.get("queue"):
            batch_arguments["jobQueue"] = options.get("job_queue") or options.get("queue")

        if options.get("job_definition"):
            batch_arguments["jobDefinition"] = options.get("job_definition")

        if options.get("share_identifier"):
            batch_arguments["shareIdentifier"] = options.get("share_identifier")

        if options.get("scheduling_priority_override"):
            batch_arguments["schedulingPriorityOverride"] = options.get("scheduling_priority_override")

        # Submit Batch job
        response = self.getclient().submit_job(**batch_arguments)

        # Extract job ID from response
        job_id = response.get("jobId", task_id)

        # Create and return AsyncResult
        result_cls = result_cls or AsyncResult
        return result_cls(task_id=job_id, response=response)
