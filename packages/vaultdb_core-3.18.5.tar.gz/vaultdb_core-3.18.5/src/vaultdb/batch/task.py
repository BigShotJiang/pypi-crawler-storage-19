from typing import Any

from ..compute.task import Task as BaseTask
from ..compute.task import mattrgetter

#: extracts attributes related to publishing a message from an object.
extract_batch_exec_options = mattrgetter(
    "job_queue",
    "job_definition",
    "share_identifier",
    "scheduling_priority_override",
    "memory",
    "number_of_cpus",
    "number_of_gpus",
    "queue",
    "routing_key",
    "exchange",
    "priority",
    "expires",
    "serializer",
    "delivery_mode",
    "compression",
    "time_limit",
    "soft_time_limit",
    "immediate",
    "mandatory",  # imm+man is deprecated
)


class BatchTask(BaseTask):
    """Batch-specific task class.

    This task class extends BaseTask with AWS Batch-specific execution options.
    Supports service layer (Celery) scheduler for task scheduling and routing.
    """

    # AWS Batch job configuration
    job_queue: str | None = None
    job_definition: str | None = None
    share_identifier: str | None = None
    scheduling_priority_override: int | None = None

    # Compute resources
    memory: int = 1024
    number_of_cpus: int = 1
    number_of_gpus: int = 0

    # Scheduler/routing configuration (for service layer (Celery) scheduler compatibility)
    queue: str | None = None
    routing_key: str | None = None
    exchange: str | None = None

    def _get_exec_options(self) -> dict[str, Any]:
        """Get execution options for Batch job submission.

        Returns:
            Dictionary of execution options.
        """
        if self._exec_options is None:
            self._exec_options = extract_batch_exec_options(self)
        return self._exec_options

    def _extract_routing(self) -> dict[str, str | None]:
        """Extract routing information for task scheduling.

        Returns:
            Dictionary containing queue, exchange, and routing_key.
        """
        delivery = getattr(self.request, "delivery_info", None) or {}
        return {
            "queue": delivery.get("routing_key") or getattr(self.request, "queue", None) or self.queue,
            "exchange": delivery.get("exchange") or self.exchange,
            "routing_key": delivery.get("routing_key") or self.routing_key,
        }
