"""
Example usage of the AC Logger package.

This module demonstrates various features and usage patterns.
"""

import os
import time
from pathlib import Path

from .config import LoggerConfig
from .core import get_logger
from .utils import setup_logging_environment


def basic_usage_example() -> None:
    """Basic logging example."""
    print("=== Basic Usage Example ===")

    # Setup environment
    os.environ["LOG_PATH"] = "logs"
    os.environ["LOG_LEVEL"] = "DEBUG"

    # Get a logger
    logger = get_logger("example.basic")

    # Basic logging
    logger.debug("This is a debug message")
    logger.info("Application started successfully")
    logger.warning("This is a warning message")
    logger.error("An error occurred")

    print(f"Current log file: {logger.get_current_log_file()}")
    print()


def nested_files_example() -> None:
    """Demonstrate nested log files functionality."""
    print("=== Nested Files Example ===")

    logger = get_logger("example.nested")

    logger.info("Starting main operation")

    # Start logging to a nested file
    logger.push_log_file("operation.log", "operations")
    logger.info("This goes to the nested file")
    logger.warning("Processing data...")

    # Go deeper with another nested file
    logger.push_log_file("sub_operation.log", "operations/sub")
    logger.info("This goes to an even more nested file")
    logger.error("Something went wrong in sub-operation")

    # Pop back to parent file
    popped = logger.pop_log_file()
    logger.info(f"Returned from {popped}")

    # Pop back to main file
    popped = logger.pop_log_file()
    logger.info(f"Returned from {popped}")

    # Show stack info
    stack_info = logger.get_log_stack_info()
    print(f"Log stack info: {stack_info}")
    print()


def context_manager_example() -> None:
    """Demonstrate context manager usage."""
    print("=== Context Manager Example ===")

    logger = get_logger("example.context")

    logger.info("Before context manager")

    # Use nested log file with context manager
    with logger.nested_log_file("temp_operation.log"):
        logger.info("This is logged to temp_operation.log")
        logger.warning("Processing temporary data")

        # Nested context manager
        with logger.nested_log_file("inner_temp.log", "temp"):
            logger.info("This goes to inner temp file")

    logger.info("Back to main log file")

    # Use operation logging context manager
    with logger.log_operation("data_processing"):
        logger.info("Processing data step 1")
        logger.info("Processing data step 2")
        time.sleep(0.1)  # Simulate work
        logger.info("Data processing completed")

    print()


def cloudwatch_example() -> None:
    """Demonstrate CloudWatch logging (requires AWS setup)."""
    print("=== CloudWatch Example ===")

    # Setup CloudWatch logging
    config = setup_logging_environment(enable_cloudwatch=True, cloudwatch_log_group="ac-calculator-logs", cloudwatch_log_stream="example-stream")

    logger = get_logger("example.cloudwatch", config)

    logger.info("This message goes to both file and CloudWatch")
    logger.warning("CloudWatch integration test")
    logger.error("Error message for CloudWatch")

    # Flush to ensure CloudWatch gets the messages
    logger.flush()

    print("CloudWatch logging example completed")
    print("(Note: Requires AWS credentials and permissions)")
    print()


def production_setup_example() -> None:
    """Example production logging setup."""
    print("=== Production Setup Example ===")

    # Production configuration
    config = LoggerConfig(
        log_level="INFO",
        log_path="/var/log/ac-calculator",
        max_file_size=50 * 1024 * 1024,  # 50MB
        backup_count=10,
        enable_cloudwatch=True,
        cloudwatch_log_group="prod-ac-calculator",
        aws_region="us-west-2",
    )

    logger = get_logger("ac.production", config)

    logger.info("Production application started")
    logger.info("Configuration loaded successfully")

    # Simulate some application work with nested logging
    with logger.log_operation("user_authentication"):
        logger.info("Validating user credentials")
        logger.info("User authenticated successfully")

    with logger.nested_log_file("calculation_audit.log", "audit"):
        logger.info("Starting calculation audit")
        logger.info("Calculation: 2.5 + 3.7 = 6.2")
        logger.info("Audit completed")

    config_info = logger.get_config_info()
    print(f"Logger configuration: {config_info}")
    print()


def error_handling_example() -> None:
    """Demonstrate error handling and exception logging."""
    print("=== Error Handling Example ===")

    logger = get_logger("example.errors")

    try:
        # Simulate an error
        10 / 0
    except ZeroDivisionError:
        logger.exception("Division by zero error occurred")

    try:
        with logger.log_operation("risky_operation"):
            logger.info("Starting risky operation")
            raise ValueError("Something went wrong!")
    except ValueError as e:
        logger.error(f"Operation failed: {e}")

    print()


def run_all_examples() -> None:
    """Run all examples."""
    print("AC Logger Package Examples")
    print("=" * 50)

    # Ensure logs directory exists
    Path("logs").mkdir(exist_ok=True)

    try:
        basic_usage_example()
        nested_files_example()
        context_manager_example()
        error_handling_example()
        production_setup_example()

        # CloudWatch example (only if AWS is configured)
        if os.getenv("AWS_ACCESS_KEY_ID") or os.path.exists(os.path.expanduser("~/.aws/credentials")):
            cloudwatch_example()
        else:
            print("=== CloudWatch Example Skipped ===")
            print("(AWS credentials not found)")
            print()

    except Exception as e:
        print(f"Example failed: {e}")
        import traceback

        traceback.print_exc()


if __name__ == "__main__":
    run_all_examples()
