"""
Core logging functionality for AC Logger package.

Main logger class that coordinates all logging operations.
"""

import logging
from contextlib import contextmanager
from typing import Any

from .config import LoggerConfig
from .handlers import CloudWatchHandler
from .handlers import FileStackHandler


class Logger:
    """
    Main logger class with support for nested files and CloudWatch.

    Features:
    - Environment-based configuration
    - Nested log file management
    - CloudWatch integration
    - Context managers for temporary log files
    - Thread-safe operations
    """

    def __init__(self, name: str, config: LoggerConfig | None = None):
        self.name = name
        self.config = config or LoggerConfig.from_environment()
        self.config.validate()

        # Create the underlying Python logger
        self._logger = logging.getLogger(name)
        self._logger.setLevel(self.config.get_logging_level())

        # Initialize handlers
        self._file_handler: FileStackHandler | None = None
        self._cloudwatch_handler: CloudWatchHandler | None = None
        self._console_handler: logging.StreamHandler | None = None

        self._setup_handlers()

    def _setup_handlers(self) -> None:
        """Setup all configured handlers."""
        # Clear existing handlers
        self._logger.handlers.clear()

        # Setup console handler (always enabled)
        self._setup_console_handler()

        # Setup file handler if enabled
        if self.config.enable_file_logging:
            self._setup_file_handler()

        # Setup CloudWatch handler if enabled
        if self.config.enable_cloudwatch:
            self._setup_cloudwatch_handler()

    def _setup_console_handler(self) -> None:
        """Setup console logging handler."""
        self._console_handler = logging.StreamHandler()
        self._console_handler.setLevel(self.config.get_logging_level())

        formatter = logging.Formatter(self.config.log_format, datefmt=self.config.date_format)
        self._console_handler.setFormatter(formatter)

        self._logger.addHandler(self._console_handler)

    def _setup_file_handler(self) -> None:
        """Setup file logging handler with stack support."""
        if not self.config.log_path:
            return

        log_dir = self.config.setup_log_directory()
        base_log_file = log_dir / f"{self.name.replace('.', '_')}.log"

        self._file_handler = FileStackHandler(
            str(base_log_file), max_file_size=self.config.max_file_size, backup_count=self.config.backup_count, max_stack_depth=self.config.max_nested_depth
        )
        self._file_handler.setLevel(self.config.get_logging_level())

        formatter = logging.Formatter(self.config.log_format, datefmt=self.config.date_format)
        self._file_handler.setFormatter(formatter)

        self._logger.addHandler(self._file_handler)

    def _setup_cloudwatch_handler(self) -> None:
        """Setup CloudWatch logging handler."""
        if not self.config.cloudwatch_log_group:
            return

        try:
            self._cloudwatch_handler = CloudWatchHandler(
                log_group=self.config.cloudwatch_log_group, log_stream=self.config.cloudwatch_log_stream, region=self.config.aws_region
            )
            self._cloudwatch_handler.setLevel(self.config.get_logging_level())

            formatter = logging.Formatter(self.config.log_format, datefmt=self.config.date_format)
            self._cloudwatch_handler.setFormatter(formatter)

            self._logger.addHandler(self._cloudwatch_handler)
        except Exception as e:
            self.warning(f"Failed to setup CloudWatch handler: {e}")

    # Logging methods
    def debug(self, message: str, *args, **kwargs) -> None:
        """Log a debug message."""
        self._logger.debug(message, *args, **kwargs)

    def info(self, message: str, *args, **kwargs) -> None:
        """Log an info message."""
        self._logger.info(message, *args, **kwargs)

    def warning(self, message: str, *args, **kwargs) -> None:
        """Log a warning message."""
        self._logger.warning(message, *args, **kwargs)

    def error(self, message: str, *args, **kwargs) -> None:
        """Log an error message."""
        self._logger.error(message, *args, **kwargs)

    def critical(self, message: str, *args, **kwargs) -> None:
        """Log a critical message."""
        self._logger.critical(message, *args, **kwargs)

    def exception(self, message: str, *args, **kwargs) -> None:
        """Log an exception with traceback."""
        self._logger.exception(message, *args, **kwargs)

    # File stack management
    def push_log_file(self, filename: str, subdirectory: str | None = None) -> str:
        """
        Start logging to a new nested file.

        Args:
            filename: Name of the new log file
            subdirectory: Optional subdirectory for organization

        Returns:
            Full path of the created log file
        """
        if not self._file_handler:
            raise RuntimeError("File logging is not enabled")

        file_path = self._file_handler.push_log_file(filename, subdirectory)
        self.info(f"Started logging to nested file: {file_path}")
        return file_path

    def pop_log_file(self) -> str | None:
        """
        Stop logging to the current nested file and return to parent.

        Returns:
            Path of the file that was popped, or None if at base level
        """
        if not self._file_handler:
            raise RuntimeError("File logging is not enabled")

        popped_file = self._file_handler.pop_log_file()
        if popped_file:
            self.info(f"Stopped logging to nested file: {popped_file}")
        else:
            self.info("Already at base log file level")

        return popped_file

    def get_current_log_file(self) -> str | None:
        """Get the path of the current log file."""
        if not self._file_handler:
            return None
        return self._file_handler.get_current_file()

    def get_log_stack_info(self) -> dict[str, Any]:
        """Get information about the current log file stack."""
        if not self._file_handler:
            return {"enabled": False}

        return {
            "enabled": True,
            "current_file": self._file_handler.get_current_file(),
            "stack_depth": self._file_handler.get_stack_depth(),
            "stack_files": self._file_handler.get_stack_info(),
        }

    # Context managers
    @contextmanager
    def nested_log_file(self, filename: str, subdirectory: str | None = None):
        """
        Context manager for temporary nested logging.

        Usage:
            with logger.nested_log_file("operation.log"):
                logger.info("This goes to operation.log")
            # Now back to original log file
        """
        file_path = self.push_log_file(filename, subdirectory)
        try:
            yield file_path
        finally:
            self.pop_log_file()

    @contextmanager
    def log_operation(self, operation_name: str, log_start: bool = True, log_end: bool = True):
        """
        Context manager that logs the start and end of an operation.

        Args:
            operation_name: Name of the operation
            log_start: Whether to log operation start
            log_end: Whether to log operation end
        """
        if log_start:
            self.info(f"Starting operation: {operation_name}")

        try:
            yield
            if log_end:
                self.info(f"Completed operation: {operation_name}")
        except Exception as e:
            self.error(f"Operation failed: {operation_name} - {e}")
            raise

    # Configuration and management
    def set_level(self, level: str | int) -> None:
        """Set the logging level."""
        if isinstance(level, str):
            level = getattr(logging, level.upper())

        self._logger.setLevel(level)

        # Update all handlers
        for handler in self._logger.handlers:
            handler.setLevel(level)

    def flush(self) -> None:
        """Flush all handlers."""
        for handler in self._logger.handlers:
            if hasattr(handler, "flush"):
                handler.flush()

    def close(self) -> None:
        """Close all handlers and cleanup resources."""
        for handler in self._logger.handlers:
            handler.close()
        self._logger.handlers.clear()

    def get_config_info(self) -> dict[str, Any]:
        """Get current configuration information."""
        return {
            "name": self.name,
            "level": self._logger.level,
            "handlers": [type(h).__name__ for h in self._logger.handlers],
            "config": self.config.to_dict(),
            "file_stack": self.get_log_stack_info(),
        }


# Global logger registry
_loggers: dict[str, Logger] = {}


def get_logger(name: str, config: LoggerConfig | None = None) -> Logger:
    """
    Get a logger instance by name.

    Args:
        name: Logger name
        config: Optional configuration (uses environment config if not provided)

    Returns:
        Logger instance
    """
    if name not in _loggers:
        _loggers[name] = Logger(name, config)
    return _loggers[name]


def cleanup_all_loggers() -> None:
    """Cleanup all logger instances."""
    for logger in _loggers.values():
        logger.close()
    _loggers.clear()
