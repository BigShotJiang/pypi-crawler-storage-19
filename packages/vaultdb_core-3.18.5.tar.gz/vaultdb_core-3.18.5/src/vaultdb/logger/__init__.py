"""
AC Logger Package

A comprehensive logging package that supports:
- Local filesystem logging with configurable paths
- CloudWatch integration for AWS environments
- Nested log file functionality with stack management
- Environment-based configuration
"""

from .config import LoggerConfig
from .core import Logger
from .core import get_logger
from .handlers import CloudWatchHandler
from .handlers import FileStackHandler
from .utils import setup_logging_environment

__all__ = ["Logger", "get_logger", "LoggerConfig", "CloudWatchHandler", "FileStackHandler", "setup_logging_environment"]

# Default logger instance
_default_logger = None


def get_default_logger() -> Logger:
    """Get the default logger instance."""
    global _default_logger
    if _default_logger is None:
        _default_logger = Logger("ac.default")
    return _default_logger
