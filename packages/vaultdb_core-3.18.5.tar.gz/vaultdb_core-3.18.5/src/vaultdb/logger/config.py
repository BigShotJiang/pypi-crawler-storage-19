"""
Logger Configuration Module

Handles configuration for the AC Logger package.
Uses centralized values from config.py.
"""

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class LoggerConfig:
    """Configuration class for AC Logger. Uses values from config.py by default."""

    # Basic configuration
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    date_format: str = "%Y-%m-%d %H:%M:%S"

    # File logging configuration
    log_path: str | None = None
    max_file_size: int = 10 * 1024 * 1024  # 10MB
    backup_count: int = 5
    enable_file_logging: bool = True

    # CloudWatch configuration
    enable_cloudwatch: bool = False
    cloudwatch_log_group: str | None = None
    cloudwatch_log_stream: str | None = None
    aws_region: str = "us-east-1"

    # Advanced features
    enable_nested_files: bool = True
    max_nested_depth: int = 10
    auto_create_directories: bool = True

    @classmethod
    def from_config(cls) -> "LoggerConfig":
        """Create configuration from centralized config.py settings."""
        # Import here to avoid circular imports
        from .. import config as app_config

        cfg = cls()

        # Basic configuration
        cfg.log_level = app_config.log_level
        cfg.log_format = app_config.log_format
        cfg.date_format = app_config.log_date_format

        # File logging
        cfg.log_path = app_config.log_path
        cfg.max_file_size = app_config.log_max_file_size
        cfg.backup_count = app_config.log_backup_count
        cfg.enable_file_logging = app_config.log_enable_file

        # CloudWatch configuration
        cfg.enable_cloudwatch = app_config.log_enable_cloudwatch
        cfg.cloudwatch_log_group = app_config.log_cloudwatch_group or None
        cfg.cloudwatch_log_stream = app_config.log_cloudwatch_stream or None
        cfg.aws_region = app_config.aws_default_region

        return cfg

    # Alias for backward compatibility
    @classmethod
    def from_environment(cls) -> "LoggerConfig":
        """Create configuration (alias for from_config)."""
        return cls.from_config()

    def validate(self) -> None:
        """Validate the configuration."""
        if self.enable_file_logging and not self.log_path:
            # Use default log path if not specified
            self.log_path = os.path.join(os.getcwd(), "logs")

        if self.enable_cloudwatch and not self.cloudwatch_log_group:
            raise ValueError("CloudWatch log group must be specified when CloudWatch is enabled")

        # Validate log level
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if self.log_level not in valid_levels:
            raise ValueError(f"Invalid log level: {self.log_level}. Must be one of {valid_levels}")

        # Validate numeric values
        if self.max_file_size <= 0:
            raise ValueError("max_file_size must be positive")

        if self.backup_count < 0:
            raise ValueError("backup_count must be non-negative")

        if self.max_nested_depth <= 0:
            raise ValueError("max_nested_depth must be positive")

    def setup_log_directory(self) -> Path:
        """Setup and return the log directory path."""
        if not self.log_path:
            raise ValueError("log_path not configured")

        log_dir = Path(self.log_path)

        if self.auto_create_directories:
            log_dir.mkdir(parents=True, exist_ok=True)

        if not log_dir.exists():
            raise FileNotFoundError(f"Log directory does not exist: {log_dir}")

        if not log_dir.is_dir():
            raise NotADirectoryError(f"Log path is not a directory: {log_dir}")

        return log_dir

    def get_logging_level(self) -> int:
        """Convert string log level to logging module constant."""
        return getattr(logging, self.log_level)

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "log_level": self.log_level,
            "log_format": self.log_format,
            "date_format": self.date_format,
            "log_path": self.log_path,
            "max_file_size": self.max_file_size,
            "backup_count": self.backup_count,
            "enable_file_logging": self.enable_file_logging,
            "enable_cloudwatch": self.enable_cloudwatch,
            "cloudwatch_log_group": self.cloudwatch_log_group,
            "cloudwatch_log_stream": self.cloudwatch_log_stream,
            "aws_region": self.aws_region,
            "enable_nested_files": self.enable_nested_files,
            "max_nested_depth": self.max_nested_depth,
            "auto_create_directories": self.auto_create_directories,
        }
