import importlib.util
import logging
import os
import sys
from typing import Any

from .config import LoggerConfig
from .core import Logger
from .core import get_logger


def setup_logging_environment(
    log_path: str | None = None, log_level: str = "INFO", enable_cloudwatch: bool = False, cloudwatch_log_group: str | None = None, **kwargs
) -> LoggerConfig:
    """
    Setup logging environment with common defaults.

    Args:
        log_path: Path for log files (uses LOG_PATH env var if not provided)
        log_level: Logging level
        enable_cloudwatch: Whether to enable CloudWatch logging
        cloudwatch_log_group: CloudWatch log group name
        **kwargs: Additional configuration options

    Returns:
        Configured LoggerConfig instance
    """
    # Set environment variables for configuration
    if log_path:
        os.environ["LOG_PATH"] = log_path
    if not os.getenv("LOG_PATH") and not log_path:
        # Default to logs directory in current working directory
        default_log_path = os.path.join(os.getcwd(), "logs")
        os.environ["LOG_PATH"] = default_log_path

    os.environ["LOG_LEVEL"] = log_level.upper()

    if enable_cloudwatch:
        os.environ["ENABLE_CLOUDWATCH"] = "true"
        if cloudwatch_log_group:
            os.environ["CLOUDWATCH_LOG_GROUP"] = cloudwatch_log_group

    # Set additional environment variables from kwargs
    env_mapping = {
        "max_file_size": "LOG_MAX_FILE_SIZE",
        "backup_count": "LOG_BACKUP_COUNT",
        "aws_region": "AWS_REGION",
        "enable_nested_files": "ENABLE_NESTED_LOG_FILES",
        "max_nested_depth": "LOG_MAX_NESTED_DEPTH",
    }

    for key, env_var in env_mapping.items():
        if key in kwargs:
            os.environ[env_var] = str(kwargs[key])

    # Create and validate configuration
    config = LoggerConfig.from_environment()
    config.validate()

    return config


def create_development_logger(name: str = "ac.dev") -> Logger:
    """
    Create a logger configured for development use.

    Features:
    - Debug level logging
    - Console and file output
    - Nested file support enabled
    """
    config = setup_logging_environment(log_level="DEBUG", enable_cloudwatch=False, enable_nested_files=True, max_nested_depth=5)

    return get_logger(name, config)


def create_production_logger(name: str = "ac.prod", cloudwatch_log_group: str | None = None) -> Logger:
    """
    Create a logger configured for production use.

    Features:
    - Info level logging
    - CloudWatch integration (if configured)
    - File rotation
    """
    config = setup_logging_environment(
        log_level="INFO",
        enable_cloudwatch=bool(cloudwatch_log_group),
        cloudwatch_log_group=cloudwatch_log_group,
        max_file_size=50 * 1024 * 1024,  # 50MB
        backup_count=10,
    )

    return get_logger(name, config)


def get_logger_stats() -> dict[str, Any]:
    """
    Get statistics about all active loggers.

    Returns:
        Dictionary with logger statistics
    """
    from .core import _loggers

    stats = {"total_loggers": len(_loggers), "loggers": {}}

    for name, logger in _loggers.items():
        stats["loggers"][name] = logger.get_config_info()

    return stats


def validate_log_environment() -> dict[str, Any]:
    """
    Validate the current logging environment setup.

    Returns:
        Validation results with any issues found
    """
    issues = []
    recommendations = []

    # Check LOG_PATH
    log_path = os.getenv("LOG_PATH")
    if not log_path:
        issues.append("LOG_PATH environment variable not set")
        recommendations.append("Set LOG_PATH to specify log file directory")
    elif not os.path.exists(log_path):
        issues.append(f"LOG_PATH directory does not exist: {log_path}")
        recommendations.append("Create the log directory or update LOG_PATH")
    elif not os.access(log_path, os.W_OK):
        issues.append(f"LOG_PATH directory is not writable: {log_path}")
        recommendations.append("Fix directory permissions")

    # Check CloudWatch configuration
    if os.getenv("ENABLE_CLOUDWATCH", "").lower() == "true":
        if not os.getenv("CLOUDWATCH_LOG_GROUP"):
            issues.append("CloudWatch enabled but CLOUDWATCH_LOG_GROUP not set")
            recommendations.append("Set CLOUDWATCH_LOG_GROUP environment variable")

        if not importlib.util.find_spec("boto3"):
            issues.append("CloudWatch enabled but boto3 not installed")
            recommendations.append("Install boto3: pip install boto3")

    # Check log level
    log_level = os.getenv("LOG_LEVEL", "INFO")
    valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
    if log_level.upper() not in valid_levels:
        issues.append(f"Invalid LOG_LEVEL: {log_level}")
        recommendations.append(f"Set LOG_LEVEL to one of: {', '.join(valid_levels)}")

    return {
        "valid": len(issues) == 0,
        "issues": issues,
        "recommendations": recommendations,
        "environment": {
            "LOG_PATH": log_path,
            "LOG_LEVEL": log_level,
            "ENABLE_CLOUDWATCH": os.getenv("ENABLE_CLOUDWATCH", "false"),
            "CLOUDWATCH_LOG_GROUP": os.getenv("CLOUDWATCH_LOG_GROUP"),
            "AWS_REGION": os.getenv("AWS_REGION", "us-east-1"),
        },
    }


def configure_root_logger(level: str = "WARNING") -> None:
    """
    Configure the root logger to avoid interference with AC loggers.

    Args:
        level: Root logger level (default: WARNING to reduce noise)
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))

    # Remove default handlers if any
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Add a simple console handler for critical messages only
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.CRITICAL)
    formatter = logging.Formatter("ROOT: %(levelname)s - %(message)s")
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)


def create_logger_from_environment() -> Logger:
    """
    Create a logger using purely environment-based configuration.

    Returns:
        Configured Logger instance
    """
    config = LoggerConfig.from_environment()
    logger_name = os.getenv("LOGGER_NAME", "ac.main")
    return get_logger(logger_name, config)
