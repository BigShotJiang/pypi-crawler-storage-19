"""
Base application class for VaultDB.

This module provides the base Application class that is used throughout
the VaultDB system for managing application state and configuration.
"""

import enum
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any

from . import config
from . import settings
from ._state import set_default_task_runner
from .auth import BaseAuthenticator
from .auth import CognitoAuthenticator
from .auth import OAuth2Authenticator
from .logger import get_logger

# Use named logger for core module
logger = get_logger(config.LOGGER_CORE)


class AuthType(enum.Enum):
    """Supported authentication types."""

    BASIC = "basic"  # Basic local authentication
    COGNITO = "cognito"  # AWS Cognito authentication
    OAUTH2 = "oauth2"  # OAuth 2.0 authentication
    IAM_ROLE = "iam_role"  # AWS IAM Role (for cloud environments)


class Application:
    """
    Base application class for VaultDB.

    This class provides the foundation for VaultDB applications,
    managing configuration, state, and core functionality.
    """

    def __init__(self, name: str = "vaultdb", **kwargs: Any) -> None:
        """
        Initialize the Application.

        Args:
            name: Name of the application
            **kwargs: Additional configuration options
        """
        self.name = name
        self.config = kwargs

    @staticmethod
    def set_default_task_runner(runner: Any) -> None:
        """Set this application as the default runner."""
        set_default_task_runner(runner)

    def __repr__(self) -> str:
        """String representation of the Application."""
        return f"Application(name='{self.name}')"

    @staticmethod
    def connect(
        catalog: str = ":memory:",
        role: str = "vaultdb",
        username: str = "",
        password: str = "",
        clone: bool = False,
        auth: AuthType = AuthType.BASIC,
        oauth2_authorization_code: str | None = None,
        oauth2_access_token: str | None = None,
        oauth2_refresh_token: str | None = None,
        oauth2_aws_access_key_id: str | None = None,
        oauth2_aws_secret_access_key: str | None = None,
        oauth2_aws_session_token: str | None = None,
    ) -> None:
        """
        Connect to VaultDB with specified authentication method.

        Args:
            catalog: Catalog path or name
            role: Role name for the connection
            username: Username for authentication (used for Cognito and catalog connection)
            password: Password for authentication (used for Cognito)
            clone: Whether to clone the catalog
            auth: Authentication type (BASIC, COGNITO, or OAUTH2)
            oauth2_authorization_code: OAuth 2.0 authorization code (for OAUTH2 auth)
            oauth2_access_token: OAuth 2.0 access token (for OAUTH2 auth, alternative to code)
            oauth2_refresh_token: OAuth 2.0 refresh token (for OAUTH2 auth)
            oauth2_aws_access_key_id: AWS access key ID from OAuth (for OAUTH2 auth)
            oauth2_aws_secret_access_key: AWS secret access key from OAuth (for OAUTH2 auth)
            oauth2_aws_session_token: AWS session token from OAuth (for OAUTH2 auth)
        """
        logger.info(f"Connecting to catalog: {catalog}, role: {role}, auth: {auth.name}")
        logger.debug(f"DEBUG mode: {config.DEBUG}, TESTING mode: {config.TESTING}")

        # Based on configuration, use a different database.
        from peewee import PostgresqlDatabase
        from peewee import SqliteDatabase

        from .data import VaultdbDatabase

        if auth == AuthType.BASIC:
            logger.debug("Using BASIC authentication")
            settings.user_authenticator = BaseAuthenticator(bucket=config.user_bucket)
        elif auth == AuthType.COGNITO:
            logger.debug(f"Using COGNITO authentication for user: {username}")
            settings.user_authenticator = CognitoAuthenticator(
                config.user_pool_id, config.user_pool_app_client_id, config.user_identity_pool_id, config.user_bucket
            )
            settings.user_authenticator.authenticate(username=username, password=password)
            logger.info("Cognito authentication successful")
        elif auth == AuthType.OAUTH2:
            logger.debug("Using OAuth2 authentication")
            if not config.oauth2_client_id or not config.oauth2_client_secret:
                logger.error("OAuth 2.0 configuration missing")
                raise RuntimeError(
                    "OAuth 2.0 configuration missing. Please set oauth2_client_id, oauth2_client_secret, "
                    "oauth2_authorization_url, oauth2_token_url, and oauth2_redirect_uri environment variables."
                )
            settings.user_authenticator = OAuth2Authenticator(
                client_id=config.oauth2_client_id,
                client_secret=config.oauth2_client_secret,
                authorization_url=config.oauth2_authorization_url,
                token_url=config.oauth2_token_url,
                redirect_uri=config.oauth2_redirect_uri,
                scope=config.oauth2_scope,
                bucket=config.user_bucket,
                aws_region=config.aws_default_region,
                aws_profile_name=config.oauth2_aws_profile_name,
            )
            settings.user_authenticator.authenticate(
                authorization_code=oauth2_authorization_code,
                access_token=oauth2_access_token,
                refresh_token=oauth2_refresh_token,
                aws_access_key_id=oauth2_aws_access_key_id,
                aws_secret_access_key=oauth2_aws_secret_access_key,
                aws_session_token=oauth2_aws_session_token,
            )

        db_obj: Any = None
        if config.DEBUG or config.run_type.lower() == "local":
            logger.debug(f"Using SQLite database in DEBUG or LOCAL mode: {catalog}")
            db_obj = SqliteDatabase(catalog)
            vaultdb_database = VaultdbDatabase(catalog, role=role, authenticator=settings.user_authenticator, clone=clone)
        elif config.TESTING or config.run_type.lower() == "testing":
            logger.debug(f"Using SQLite database in TESTING or TESTING mode: {catalog}")
            db_obj = SqliteDatabase(catalog)
            vaultdb_database = VaultdbDatabase(catalog, role=role, authenticator=settings.user_authenticator, clone=clone)
        else:
            logger.debug(f"Using PostgreSQL database in PRODUCTION mode: {catalog}")
            db_obj = PostgresqlDatabase(catalog, username=username, password=password)
            vaultdb_database = VaultdbDatabase(catalog, role=role, authenticator=settings.user_authenticator, clone=clone)

        # Configure our proxy to use the db we specified in config.
        config.postgres_proxy.initialize(db_obj)
        config.vaultdb_proxy.initialize(vaultdb_database)
        logger.info(f"Catalog connection established: {catalog}")

        settings.catalog = catalog
        settings.role = role
        settings.username = username
        settings.password = password

    @staticmethod
    @contextmanager
    def execute_as(
        catalog: str = ":memory:",
        role: str = "vaultdb",
        username: str = "",
        password: str = "",
        clone: bool = False,
    ) -> Generator[None, None, None]:
        """
        Context manager to temporarily switch the active connection settings.

        This allows executing a block of code with a different catalog, role,
        username, and password, and then automatically reverts to the original
        settings upon exiting the block.

        Args:
            catalog (str): The catalog path/name to connect to. Defaults to ":memory:".
            role (str): The role to assume for the connection. Defaults to "vaultdb".
            username (str): The username for authentication. Defaults to "".
            password (str): The password for authentication. Defaults to "".
            clone (bool): Whether to clone the catalog for this session. Defaults to False.

        Yields:
            None: The context manager yields nothing.
        """
        current_role = settings.role
        current_catalog = settings.catalog
        current_username = settings.username
        current_password = settings.password

        # Save current database objects
        current_vaultdb_db = config.vaultdb_proxy.obj
        current_postgres_db = config.postgres_proxy.obj

        try:
            Application.connect(catalog, role, username, password, clone=clone)
            yield
        finally:
            settings.catalog = current_catalog
            settings.role = current_role
            settings.username = current_username
            settings.password = current_password

            # Restore database objects
            if current_vaultdb_db:
                config.vaultdb_proxy.initialize(current_vaultdb_db)
            if current_postgres_db:
                config.postgres_proxy.initialize(current_postgres_db)
