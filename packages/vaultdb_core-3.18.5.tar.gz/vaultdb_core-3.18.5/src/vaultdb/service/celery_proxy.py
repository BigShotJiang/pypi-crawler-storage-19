"""
Celery Proxy Module.

This module provides a proxy for Celery components when Celery is not installed.
It allows the codebase to function without a direct dependency on Celery,
mocking necessary classes and functions.
"""

import logging

logger = logging.getLogger(__name__)

try:
    from celery import Celery
    from celery import Task
    from celery import current_app
    from celery.beat import ScheduleEntry
    from celery.beat import Scheduler
    from celery.schedules import BaseSchedule
    from celery.schedules import crontab
    from celery.schedules import schedstate

    _CELERY_INSTALLED = True
except ImportError:
    _CELERY_INSTALLED = False
    logger.debug("Celery not found, using proxy objects.")

    current_app = None # Placeholder, will be set to instance later or mock

    class Celery:
        """Proxy for celery.Celery."""

        def __init__(self, main: str | None = None, **kwargs):
            self.main = main
            self.conf = {}
            self.tasks = {}
            self._tasks = {}
            # Initialize beat_schedule in conf for proxy
            self.conf['beat_schedule'] = {}

        def task(self, *args, **kwargs):

            """Proxy for celery.task decorator."""
            def decorator(func):
                return func
            return decorator

        def send_task(self, name, args=None, kwargs=None, **options):
            """Proxy for send_task."""
            logger.warning(f"Mock send_task called for {name}. Celery is not installed.")
            return AsyncResultProxy()

        def autodiscover_tasks(self, packages=None, related_name="tasks", force=False):
            pass

        def start(self, argv=None):
            """Proxy for start."""
            logger.info("Mock Celery app started.")

    class Task:
        """Proxy for celery.Task."""
        pass

    class BaseSchedule:
        """Proxy for celery.schedules.BaseSchedule."""
        def __init__(self, *args, **kwargs):
            pass

    def crontab(*args, **kwargs):
        """Proxy for celery.schedules.crontab."""
        return "crontab-proxy"

    class schedstate:  # noqa: N801
        """Proxy for celery.schedules.schedstate."""
        def __init__(self, is_due, next):
            self.is_due = is_due
            self.next = next

    class Scheduler:
        """Proxy for celery.beat.Scheduler."""
        def __init__(self, *args, **kwargs):
            pass

        def tick(self, *args, **kwargs):
            return 1.0

        def close(self):
            pass

    class ScheduleEntry:
        """Proxy for celery.beat.ScheduleEntry."""
        pass

    class AsyncResultProxy:
        """Proxy for AsyncResult."""
        def __init__(self, id=None):
            self.id = id or "mock-id"
            self.state = "PENDING"

        def get(self, timeout=None, propagate=True, **kwargs):
            return None

    current_app = Celery("mock")

    # Necessary for type checking/inheritance if used in other places
    Celery = Celery
    Task = Task
    BaseSchedule = BaseSchedule
    Scheduler = Scheduler
    ScheduleEntry = ScheduleEntry
    current_app = current_app

