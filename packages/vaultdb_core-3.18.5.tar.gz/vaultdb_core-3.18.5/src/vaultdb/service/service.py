from typing import TYPE_CHECKING

from .._state import set_default_task_runner
from ..config import result_database
from ..config import service_broker_url
from ..config import timezone
from .celery_proxy import Celery as BaseCelery
from .task import Task as ServiceTask

if TYPE_CHECKING:
    from .core import ServiceRunner

__all__ = ["Service", "setup_service", "service_broker_url", "result_database", "timezone"]


class Service(BaseCelery):
    Task = ServiceTask


# Singleton instance to ensure all calls to setup_service return the same app
# This allows tasks to be registered to the same app instance during discovery
_service_app_instance = None


def setup_service(namespace: str = "vaultdb.tasks") -> "ServiceRunner":
    """
    Create and configure a VaultDB service application.

    Returns:
        ServiceRunner: Configured service runner instance.
    """
    global _service_app_instance

    if _service_app_instance is not None:
        return _service_app_instance

    app = Service(namespace)

    # Service configuration
    app.conf.update(
        broker_url=service_broker_url,
        result_backend=result_database,
        timezone=timezone,
        task_serializer="json",
        accept_content=["json"],
        result_serializer="json",
        task_track_started=True,
        task_time_limit=30 * 60,  # 30 minutes
        task_soft_time_limit=25 * 60,  # 25 minutes
        worker_prefetch_multiplier=1,
        task_acks_late=True,
        worker_disable_rate_limits=False,
        task_routes={
            f"{namespace}.*": {"queue": "vaultdb"},
        },
        task_default_queue="vaultdb",
        task_default_exchange="vaultdb",
        task_default_exchange_type="direct",
        task_default_routing_key="vaultdb",
    )

    # Import ServiceRunner here to avoid circular imports
    from .core import ServiceRunner

    runner = ServiceRunner(service_app=app)
    _service_app_instance = runner

    set_default_task_runner(runner)
    # Automatically discover tasks to register them with the app instance
    from ..scheduler.discovery import discover_tasks

    discover_tasks()

    return runner
