"""
Service worker entry point (service layer (Celery)).

This script initializes the service runner and exposes the app object
for the worker process.
"""

import sys

from vaultdb.service import setup_service

# Runner and app initialization already handles task discovery
runner = setup_service()
app = runner.service_app

if __name__ == "__main__":
    # Ensure 'worker' is the declared command to run.
    argv = sys.argv
    # service (service layer (Celery)) app.start() -> celery.main() -> click.main()
    # It appears passing ['command', ...] works better if we assume prog_name is implicit or handled separately.
    # If we pass ['service', 'worker'], it thinks 'service' is the command.
    # So let's try ['worker', ...args...]

    if "worker" not in argv:
        final_argv = ["worker"] + argv[1:]
    else:
        # If user passed "worker" explicitly...
        # If argv is ['script.py', 'worker', '--port...']
        # We want ['worker', '--port...']
        # So we just take argv[1:] basically ??
        # Or maybe keep it as is if it works?
        # But wait, argv[0] is script name.
        # If we return argv, it includes script name.
        # If script name is passed, click might say "No such command 'monitor.py'".

        # So we should probably ALWAYS strip argv[0] and prepend something valid or just rely on 'flower' being first.
        # If "flower" is in argv, find where it is.
        try:
            worker_index = argv.index("worker")
            # Keep everything from flower onwards
            final_argv = argv[worker_index:]
        except ValueError:
            # Should be caught by "if not in argv" check above, but for safety
            final_argv = ["worker"] + argv[1:]

    app.start(argv=final_argv)
