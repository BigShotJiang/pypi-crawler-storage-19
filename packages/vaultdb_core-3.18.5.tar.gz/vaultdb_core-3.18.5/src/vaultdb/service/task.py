from typing import Any

from ..compute.task import BaseTask
from .celery_proxy import Task as ServiceTaskBase


class Task(ServiceTaskBase, BaseTask):
    """
    Custom service task class (Celery) that integrates with the VaultDB Application
    to manage database connections during task execution.

    This task class inherits from both service's Task (Celery) and VaultDB's BaseTask
    classes. It ensures that a database connection is established
    and properly closed for each task execution.

    It provides a flexible mechanism to connect to VaultDB:
    - If specific connection parameters (catalog, role, config)
      are provided as `vaultdb_` prefixed keyword arguments to the task,
      it uses the `Application.execute_as` context manager to establish
      a temporary connection with those credentials.
    - Otherwise, it uses the `Application.connect` context manager,
      relying on the task instance's (which is also an Application instance)
      default connection settings or those explicitly set as class attributes.

    Tasks inheriting from Task should define their `run` method
    as usual.
    """

    abstract = True

    queue: str | None = None
    routing_key: str | None = None
    exchange: str | None = None

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return BaseTask.__call__(self, *args, **kwargs)

    def _extract_routing(self) -> dict[str, str | None]:
        delivery = getattr(self.request, "delivery_info", None) or {}
        return {
            "queue": delivery.get("routing_key") or getattr(self.request, "queue", None),
            "exchange": delivery.get("exchange"),
            "routing_key": delivery.get("routing_key"),
        }
