"""Service runner implementation (Celery-based)."""

from typing import Any

from ..compute.core import Runner
from ..compute.core import RunType
from ..compute.result import AsyncResult
from .celery_proxy import Celery as BaseCelery


class ServiceRunner(Runner):
    """Service-based task runner.

    This runner wraps the underlying service application (Celery) to provide a consistent
    interface with BatchRunner and FunctionRunner while maintaining full
    functionality for scheduling and task execution.

    The runner ensures that all tasks return VaultDB's AsyncResult type
    for consistency across all runners, while still leveraging the
    native task execution and result backend.
    """

    task_cls = "vaultdb.service.task:Task"
    run_type = RunType.SERVICE

    def __init__(self, service_app: BaseCelery | None = None, **kwargs: Any) -> None:
        """Initialize ServiceRunner with a service app instance.

        Args:
            service_app: Configured service application instance. If None, will be created on first use.
            **kwargs: Additional arguments passed to Runner.
        """
        super().__init__(**kwargs)
        self._service_app = service_app

    @property
    def service_app(self) -> BaseCelery:
        """Access to the underlying service application.

        Returns:
            The service application instance.
        """
        if self._service_app is None:
            raise RuntimeError("Service application (Celery) is not initialized in ServiceRunner.")
        return self._service_app

    def send_task(
        self,
        name: str,
        args: tuple[Any, ...] | None = None,
        kwargs: dict[str, Any] | None = None,
        countdown: float | None = None,
        eta: Any = None,
        task_id: str | None = None,
        producer: Any = None,
        connection: Any = None,
        router: Any = None,
        result_cls: type[AsyncResult] | None = None,
        expires: Any = None,
        publisher: Any = None,
        link: Any = None,
        link_error: Any = None,
        add_to_parent: bool = True,
        group_id: str | None = None,
        group_index: int | None = None,
        retries: int = 0,
        chord: Any = None,
        reply_to: str | None = None,
        time_limit: int | None = None,
        soft_time_limit: int | None = None,
        root_id: str | None = None,
        parent_id: str | None = None,
        route_name: str | None = None,
        shadow: str | None = None,
        chain: Any = None,
        task_type: Any = None,
        replaced_task_nesting: int = 0,
        **options: Any,
    ) -> AsyncResult:
        """Send task by name using the service app.

        Supports the same arguments as :meth:`@-Task.apply_async`.

        Args:
            name: Name of task to call (e.g., `"tasks.add"`).
            args: Positional arguments for the task.
            kwargs: Keyword arguments for the task.
            countdown: Delay in seconds before execution.
            eta: Estimated time of arrival (datetime).
            task_id: Optional task ID (auto-generated if not provided).
            result_cls: Custom result class (defaults to AsyncResult).
            **options: Additional service-specific options (queue, routing_key, etc.).

        Returns:
            AsyncResult instance for tracking task execution.
        """
        # Delegate to the service's send_task method
        app = self.service_app
        service_result = app.send_task(
            name,
            args=args,
            kwargs=kwargs,
            countdown=countdown,
            eta=eta,
            task_id=task_id,
            producer=producer,
            connection=connection,
            router=router,
            expires=expires,
            publisher=publisher,
            link=link,
            link_error=link_error,
            add_to_parent=add_to_parent,
            group_id=group_id,
            group_index=group_index,
            retries=retries,
            chord=chord,
            reply_to=reply_to,
            time_limit=time_limit,
            soft_time_limit=soft_time_limit,
            root_id=root_id,
            parent_id=parent_id,
            route_name=route_name,
            shadow=shadow,
            chain=chain,
            task_type=task_type,
            **options,
        )

        # Wrap the result in VaultDB's AsyncResult for consistency
        result_cls = result_cls or AsyncResult
        return result_cls(task_id=service_result.id, response={"service_result": service_result})

    def task(self, *args: Any, **opts: Any) -> Any:
        # Decorator to create tasks bound to this runner.
        return self.service_app.task(*args, **opts)

    @property
    def conf(self) -> Any:
        """Access to service configuration.

        Returns:
            Service configuration object.
        """
        return self.service_app.conf

    @property
    def tasks(self) -> dict[str, Any]:
        """Access to service task registry.

        Returns:
            Dictionary of registered tasks.
        """
        return self.service_app.tasks

    def close(self) -> None:
        """Close the service app connection."""
        if hasattr(self._service_app, "close"):
            self._service_app.close()
        super().close()
