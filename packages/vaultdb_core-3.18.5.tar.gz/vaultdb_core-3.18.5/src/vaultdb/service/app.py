"""
Service Application Entry Point (service layer (Celery)).

This module exposes the service application instance for the CLI (worker/beat).
Usage: celery -A vaultdb.service.app worker --loglevel=info
"""

from . import setup_service

# Initialize the service runner
runner = setup_service()

# Expose the underlying service app object (service layer (Celery)) as 'app' for the CLI
app = runner.service_app
