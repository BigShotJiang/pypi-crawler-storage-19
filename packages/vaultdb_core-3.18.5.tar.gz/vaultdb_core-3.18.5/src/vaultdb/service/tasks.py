"""
Example VaultDB service tasks.

This module contains example tasks that demonstrate how to use
the VaultDB service integration.
"""

from .._state import TED
from ..scheduler.decorators import scheduled
from .celery_proxy import crontab
from .task import Task


@TED.task(bind=True, base=Task)
def example_task(self, message: str, delay: int = 0) -> str:
    """
    Example task that demonstrates VaultDB integration.

    Args:
        message (str): Message to process
        delay (int): Optional delay in seconds

    Returns:
        str: Processed message
    """
    import time

    if delay > 0:
        time.sleep(delay)

    result = f"Processed: {message} (task_id: {self.request.id})"

    # Example of using VaultDB connection within the task
    # The connection is automatically managed by the Task base class
    with self.connect():
        # Here you could perform database operations
        # using self.connection
        pass

    return result


@TED.task(bind=True, base=Task)
def failing_task(self, error_message: str = "Task failed") -> None:
    """
    Example task that always fails for testing error handling.

    Args:
        error_message (str): Error message to raise

    Raises:
        RuntimeError: Always raises this exception
    """
    raise RuntimeError(error_message)


@TED.task(bind=True, base=Task)
def retry_task(self, attempt: int = 1, max_attempts: int = 3) -> str:
    """
    Example task that demonstrates retry functionality.

    Args:
        attempt (int): Current attempt number
        max_attempts (int): Maximum number of attempts

    Returns:
        str: Success message

    Raises:
        RuntimeError: If max attempts not reached
    """
    if attempt < max_attempts:
        raise RuntimeError(f"Attempt {attempt} failed, retrying...")

    return f"Success after {attempt} attempts"


@scheduled(schedule=crontab(minute="*/15"), args=("Scheduled message",), kwargs={"delay": 1})
@TED.task(bind=True, base=Task)
def scheduled_example_task(self, message: str, delay: int = 0) -> str:
    """
    Example scheduled task.
    """
    return example_task(self, message, delay)


# Export the app for external use
__all__ = ["TED", "example_task", "failing_task", "retry_task", "scheduled_example_task"]
