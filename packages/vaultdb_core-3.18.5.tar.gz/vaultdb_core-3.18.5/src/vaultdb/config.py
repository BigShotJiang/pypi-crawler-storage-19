"""
VaultDB Configuration Module.

Centralized configuration for all VaultDB components:
- Application settings
- AWS and authentication
- Cache configuration
- Logger configuration
- Compute runner configuration
"""

import os
import tempfile
from typing import Any

from peewee import DatabaseProxy

# =============================================================================
# Run Type Configuration
# =============================================================================
run_type: str = os.getenv("run_type", "local")

# =============================================================================
# Environment & Debug Settings
# =============================================================================
DEBUG: bool = os.getenv("DEBUG", "").lower() == "true"
TESTING: bool = os.getenv("TESTING", "").lower() == "true"
IS_CLOUD_ENVIRONMENT: bool = os.getenv("IS_CLOUD", "").lower() == "true"

# =============================================================================
# Database Proxies
# =============================================================================
postgres_proxy = DatabaseProxy()
vaultdb_proxy = DatabaseProxy()

# =============================================================================
# Application Runtime Configuration
# =============================================================================
application_name: str = os.getenv("application_name", "dev")
commitlog_directory: str = os.getenv("commitlog_directory", tempfile.gettempdir())
data_store: str = os.getenv("data_store", "")
timezone: str = os.getenv("TIMEZONE", "UTC")

# =============================================================================
# AWS Configuration
# =============================================================================
aws_default_region: str = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

# S3 bucket for user data
user_bucket: str = os.getenv("user_bucket", f"{application_name}-public-storage-440955376164")

# =============================================================================
# Authentication Configuration
# =============================================================================

# Default auth type: Use IAM_ROLE in cloud, BASIC locally
_default_auth = "iam_role" if IS_CLOUD_ENVIRONMENT else "basic"
auth_type: str = os.getenv("AUTH_TYPE", _default_auth)

# Cognito configuration
user_pool_id: str = os.getenv("user_pool_id", "")
user_pool_app_client_id: str = os.getenv("user_pool_app_client_id", "")
user_identity_pool_id: str = os.getenv("user_identity_pool_id", "")
cognito_aws_profile_name: str = os.getenv("cognito_aws_profile_name", "vaultdb-cognito")

# OAuth 2.0 configuration
oauth2_client_id: str = os.getenv("oauth2_client_id", "")
oauth2_client_secret: str = os.getenv("oauth2_client_secret", "")
oauth2_authorization_url: str = os.getenv("oauth2_authorization_url", "")
oauth2_token_url: str = os.getenv("oauth2_token_url", "")
oauth2_redirect_uri: str = os.getenv("oauth2_redirect_uri", "")
oauth2_scope: str = os.getenv("oauth2_scope", "openid profile email")
oauth2_aws_profile_name: str = os.getenv("oauth2_aws_profile_name", "vaultdb-oauth")

# VaultDB credentials (for local auth)
vaultdb_user: str = os.getenv("vaultdb_user", "")
vaultdb_password: str = os.getenv("vaultdb_password", "")

# Runtime authenticator instance (set during Application.connect)
user_authenticator: Any = None

# =============================================================================
# Redis & Service Configuration
# =============================================================================
service_broker_url: str = os.getenv("SERVICE_BROKER_URL", os.getenv("CELERY_BROKER_URL", os.getenv("redis_broker", "redis://redis:6379")))
redis_cache_url: str = os.getenv("REDIS_CACHE_URL", os.getenv("redis_cache_url", "redis://redis:6379"))
result_database: str = os.getenv("REDIS_DATABASE", os.getenv("redis_database", "redis://redis:6379/0"))

# =============================================================================
# Cache Configuration
# =============================================================================
cache_default_ttl: int = int(os.getenv("CACHE_DEFAULT_TTL", "3600"))  # 1 hour
cache_max_ttl: int = int(os.getenv("CACHE_MAX_TTL", str(86400 * 7)))  # 7 days
cache_serializer: str = os.getenv("CACHE_SERIALIZER", "json")  # json or pickle
cache_key_prefix: str = os.getenv("CACHE_KEY_PREFIX", "vaultdb:")
cache_max_connections: int = int(os.getenv("CACHE_MAX_CONNECTIONS", "10"))

# =============================================================================
# Logger Configuration
# =============================================================================
log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()
log_format: str = os.getenv("LOG_FORMAT", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
log_date_format: str = os.getenv("LOG_DATE_FORMAT", "%Y-%m-%d %H:%M:%S")
log_path: str = os.getenv("LOG_PATH", tempfile.gettempdir())
log_max_file_size: int = int(os.getenv("LOG_MAX_FILE_SIZE", str(10 * 1024 * 1024)))  # 10MB
log_backup_count: int = int(os.getenv("LOG_BACKUP_COUNT", "5"))
log_enable_file: bool = os.getenv("LOG_ENABLE_FILE", "true").lower() == "true"
log_enable_cloudwatch: bool = os.getenv("LOG_ENABLE_CLOUDWATCH", "false").lower() == "true"
log_cloudwatch_group: str = os.getenv("LOG_CLOUDWATCH_GROUP", "")
log_cloudwatch_stream: str = os.getenv("LOG_CLOUDWATCH_STREAM", "")

# =============================================================================
# Compute Runner Configuration
# =============================================================================
compute_function_name: str = os.getenv(
    "COMPUTE_FUNCTION_NAME",
    os.getenv("compute_function_name", "arn:aws:lambda:us-east-1:123456789012:function:vaultdb-worker"),
)
batch_job_queue: str = os.getenv("BATCH_JOB_QUEUE", "")
batch_job_definition: str = os.getenv("BATCH_JOB_DEFINITION", "")

# =============================================================================
# Named Logger Names (for service-specific loggers)
# =============================================================================
LOGGER_CORE = "vaultdb.core"
LOGGER_COMPUTE = "vaultdb.compute"
LOGGER_DATA = "vaultdb.data"
LOGGER_CACHE = "vaultdb.cache"
LOGGER_SCHEDULER = "vaultdb.scheduler"
LOGGER_BATCH = "vaultdb.batch"
LOGGER_SERVICE = "vaultdb.service"
LOGGER_FUNCTION = "vaultdb.function"
LOGGER_AUTH = "vaultdb.auth"
LOGGER_WEB = "vaultdb.web"
