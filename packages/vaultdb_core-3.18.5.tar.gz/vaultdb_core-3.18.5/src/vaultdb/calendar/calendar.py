"""
Calendar class for business day calculations.

This module provides the Calendar class that handles business day logic,
including weekend configuration and holiday management.
"""

import calendar as cal
import datetime
import logging
from zoneinfo import ZoneInfo

from .models import Calendar as CalendarModel

logger = logging.getLogger(__name__)


class Weekday:
    """Weekday constants (Monday = 0, Sunday = 6)."""

    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6


class Calendar:
    """
    Calendar class for business day calculations.

    Supports both in-memory calendars and database-backed calendars
    with holidays and configurable weekends.

    Attributes:
        name: Calendar name
        timezone: Timezone for the calendar (default: UTC)
        weekends: Set of weekday numbers that are weekends (default: {5, 6})
        use_database: Whether to use database for holidays (default: False)
    """

    def __init__(
        self,
        name: str,
        timezone: str = "UTC",
        weekends: set[int] | None = None,
        holidays: list[datetime.date] | None = None,
        description: str = "",
        use_database: bool = False,
    ) -> None:
        """
        Initialize a Calendar.

        Args:
            name: Calendar name
            timezone: Timezone string (default: "UTC")
            weekends: Set of weekday numbers for weekends (default: {5, 6})
            holidays: List of holiday dates
            description: Optional description
            use_database: Whether to use database for holidays (default: False)
        """
        self.name = name
        self.timezone = timezone
        self.description = description
        self.use_database = use_database

        if weekends is None:
            weekends = {5, 6}  # Default: Saturday and Sunday
        self.weekends = set(weekends)

        # Get timezone object
        try:
            self.tz = ZoneInfo(self.timezone)
        except Exception:
            logger.warning(f"Unknown timezone '{timezone}', defaulting to UTC")
            self.tz = ZoneInfo("UTC")
            self.timezone = "UTC"

        # In-memory holidays storage
        self._holidays: dict[str, dict] = {}

        # Add initial holidays
        if holidays:
            for h in holidays:
                self._holidays[h.isoformat()] = {}

        # Load from database if requested
        if self.use_database:
            self._load_from_database()

    def _load_from_database(self) -> None:
        """Load calendar configuration from database."""
        try:
            db_calendar = CalendarModel.get_by_name(self.name)
            if db_calendar:
                self.timezone = db_calendar.timezone
                self.weekends = db_calendar.get_weekend_days()
                self._holidays = db_calendar.get_holidays()
                try:
                    self.tz = ZoneInfo(self.timezone)
                except Exception:
                    self.tz = ZoneInfo("UTC")
            else:
                # Create in database
                db_calendar = CalendarModel.create_calendar(
                    name=self.name,
                    weekends=self.weekends,
                    timezone=self.timezone,
                    description=self.description,
                )
        except Exception as e:
            logger.debug(f"Could not load calendar from database: {e}")

    def _save_to_database(self) -> None:
        """Save calendar configuration to database."""
        if not self.use_database:
            return
        try:
            db_calendar = CalendarModel.get_by_name(self.name)
            if db_calendar:
                db_calendar.set_holidays(self._holidays)
                db_calendar.save()
        except Exception as e:
            logger.error(f"Error saving calendar to database: {e}")

    @property
    def holiday_dates(self) -> list[datetime.date]:
        """Get holidays as a list of dates."""
        return [datetime.date.fromisoformat(d) for d in self._holidays.keys()]

    def is_weekend(self, date: datetime.date) -> bool:
        """Check if a date is a weekend day."""
        return date.weekday() in self.weekends

    def is_holiday(self, date: datetime.date) -> bool:
        """Check if a date is a holiday."""
        return date.isoformat() in self._holidays

    def is_business_day(self, date: datetime.date) -> bool:
        """Check if a date is a business day."""
        return not self.is_weekend(date) and not self.is_holiday(date)

    def add_holiday(
        self,
        date: datetime.date,
        name: str | None = None,
        description: str | None = None,
    ) -> None:
        """Add a holiday to the calendar."""
        holiday_info = {}
        if name:
            holiday_info["name"] = name
        if description:
            holiday_info["description"] = description
        self._holidays[date.isoformat()] = holiday_info

        if self.use_database:
            self._save_to_database()

    def remove_holiday(self, date: datetime.date) -> bool:
        """Remove a holiday from the calendar."""
        date_str = date.isoformat()
        if date_str in self._holidays:
            del self._holidays[date_str]
            if self.use_database:
                self._save_to_database()
            return True
        return False

    def next_business_day(self, date: datetime.date) -> datetime.date:
        """Get the next business day on or after the given date."""
        while not self.is_business_day(date):
            date = date + datetime.timedelta(days=1)
        return date

    def previous_business_day(self, date: datetime.date) -> datetime.date:
        """Get the previous business day on or before the given date."""
        while not self.is_business_day(date):
            date = date - datetime.timedelta(days=1)
        return date

    def add_business_days(self, date: datetime.date, days: int) -> datetime.date:
        """Add business days to a date."""
        if days == 0:
            return self.next_business_day(date)

        direction = 1 if days > 0 else -1
        remaining = abs(days)
        current = date

        while remaining > 0:
            current = current + datetime.timedelta(days=direction)
            if self.is_business_day(current):
                remaining -= 1

        return current

    def business_days_in_month(self, year: int, month: int) -> list[datetime.date]:
        """Get all business days in a month."""
        _, last_day = cal.monthrange(year, month)
        return [datetime.date(year, month, day) for day in range(1, last_day + 1) if self.is_business_day(datetime.date(year, month, day))]

    def first_business_day_of_month(self, year: int, month: int) -> datetime.date:
        """Get the first business day of a month."""
        return self.next_business_day(datetime.date(year, month, 1))

    def last_business_day_of_month(self, year: int, month: int) -> datetime.date:
        """Get the last business day of a month."""
        _, last_day = cal.monthrange(year, month)
        return self.previous_business_day(datetime.date(year, month, last_day))

    def nth_business_day_of_month(self, year: int, month: int, n: int) -> datetime.date:
        """
        Get the nth business day of a month.

        Args:
            n: Which business day (1 = first, -1 = last, -2 = second to last)
        """
        if n == 0:
            raise ValueError("n cannot be 0")

        days = self.business_days_in_month(year, month)
        if not days:
            raise ValueError(f"No business days in {year}-{month:02d}")

        try:
            return days[n - 1] if n > 0 else days[n]
        except IndexError:
            raise ValueError(f"Month has only {len(days)} business days")

    def first_business_day_of_quarter(self, year: int, quarter: int) -> datetime.date:
        """Get the first business day of a quarter (1-4)."""
        first_month = (quarter - 1) * 3 + 1
        return self.first_business_day_of_month(year, first_month)

    def last_business_day_of_quarter(self, year: int, quarter: int) -> datetime.date:
        """Get the last business day of a quarter (1-4)."""
        last_month = quarter * 3
        return self.last_business_day_of_month(year, last_month)

    def first_business_day_of_year(self, year: int) -> datetime.date:
        """Get the first business day of a year."""
        return self.first_business_day_of_month(year, 1)

    def last_business_day_of_year(self, year: int) -> datetime.date:
        """Get the last business day of a year."""
        return self.last_business_day_of_month(year, 12)

    def business_days_between(self, start_date: datetime.date, end_date: datetime.date) -> int:
        """Count business days between two dates (inclusive)."""
        if start_date > end_date:
            return 0
        count = 0
        current = start_date
        while current <= end_date:
            if self.is_business_day(current):
                count += 1
            current += datetime.timedelta(days=1)
        return count

    def now(self) -> datetime.datetime:
        """Get current datetime in calendar timezone."""
        return datetime.datetime.now(self.tz)

    def today(self) -> datetime.date:
        """Get current date in calendar timezone."""
        return self.now().date()

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "timezone": self.timezone,
            "weekends": list(self.weekends),
            "holidays": [d.isoformat() for d in self.holiday_dates],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Calendar":
        """Create calendar from dictionary."""
        holidays = [datetime.date.fromisoformat(d) if isinstance(d, str) else d for d in data.get("holidays", [])]
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            timezone=data.get("timezone", "UTC"),
            weekends=set(data.get("weekends", [5, 6])),
            holidays=holidays,
        )

    def __str__(self) -> str:
        return f"Calendar(name='{self.name}', timezone='{self.timezone}')"

    def __repr__(self) -> str:
        return f"Calendar(name='{self.name}', timezone='{self.timezone}', weekends={self.weekends})"

    def __eq__(self, other) -> bool:
        if isinstance(other, Calendar):
            return self.name == other.name
        return False

    def __hash__(self) -> int:
        return hash(self.name)


# =============================================================================
# US Federal Holiday Helpers
# =============================================================================


def _nth_weekday_of_month(year: int, month: int, weekday: int, n: int) -> datetime.date:
    """Get the nth occurrence of a weekday in a month."""
    first = datetime.date(year, month, 1)
    days_until = (weekday - first.weekday()) % 7
    first_occurrence = first + datetime.timedelta(days=days_until)
    return first_occurrence + datetime.timedelta(weeks=n - 1)


def _last_weekday_of_month(year: int, month: int, weekday: int) -> datetime.date:
    """Get the last occurrence of a weekday in a month."""
    _, last_day = cal.monthrange(year, month)
    last = datetime.date(year, month, last_day)
    days_back = (last.weekday() - weekday) % 7
    return last - datetime.timedelta(days=days_back)


def _observed(holiday: datetime.date) -> datetime.date:
    """Get observed date (Sat->Fri, Sun->Mon)."""
    if holiday.weekday() == 5:
        return holiday - datetime.timedelta(days=1)
    elif holiday.weekday() == 6:
        return holiday + datetime.timedelta(days=1)
    return holiday


def us_federal_holidays(year: int) -> list[datetime.date]:
    """Calculate US Federal holidays for a given year."""
    holidays = []

    holidays.append(_observed(datetime.date(year, 1, 1)))  # New Year
    holidays.append(_nth_weekday_of_month(year, 1, 0, 3))  # MLK
    holidays.append(_nth_weekday_of_month(year, 2, 0, 3))  # Presidents
    holidays.append(_last_weekday_of_month(year, 5, 0))  # Memorial
    holidays.append(_observed(datetime.date(year, 6, 19)))  # Juneteenth
    holidays.append(_observed(datetime.date(year, 7, 4)))  # Independence
    holidays.append(_nth_weekday_of_month(year, 9, 0, 1))  # Labor
    holidays.append(_nth_weekday_of_month(year, 10, 0, 2))  # Columbus
    holidays.append(_observed(datetime.date(year, 11, 11)))  # Veterans
    holidays.append(_nth_weekday_of_month(year, 11, 3, 4))  # Thanksgiving
    holidays.append(_observed(datetime.date(year, 12, 25)))  # Christmas

    return sorted(holidays)


def us_federal_holidays_range(start_year: int, end_year: int) -> list[datetime.date]:
    """Get US Federal holidays for a range of years."""
    holidays = []
    for year in range(start_year, end_year + 1):
        holidays.extend(us_federal_holidays(year))
    return sorted(holidays)


# =============================================================================
# Predefined Calendars
# =============================================================================

# Default calendar - every weekday is a business day, no holidays
DEFAULT = Calendar(
    name="Default",
    description="Default calendar - weekdays are business days, no holidays",
    timezone="UTC",
    weekends={5, 6},
)

# Every day calendar - no weekends, no holidays
EVERY_DAY = Calendar(
    name="EveryDay",
    description="Every day is a business day (24/7 operations)",
    timezone="UTC",
    weekends=set(),
)

# US Federal calendar with holidays
US_FEDERAL = Calendar(
    name="USFederal",
    description="US Federal holidays",
    timezone="America/New_York",
    weekends={5, 6},
    holidays=us_federal_holidays_range(2024, 2030),
)

# Regional timezone calendars
US_EASTERN = Calendar(name="US-Eastern", timezone="America/New_York")
US_PACIFIC = Calendar(name="US-Pacific", timezone="America/Los_Angeles")
US_CENTRAL = Calendar(name="US-Central", timezone="America/Chicago")
UK_LONDON = Calendar(name="UK-London", timezone="Europe/London")
EU_BERLIN = Calendar(name="EU-Berlin", timezone="Europe/Berlin")
ASIA_TOKYO = Calendar(name="Asia-Tokyo", timezone="Asia/Tokyo")
ASIA_SINGAPORE = Calendar(name="Asia-Singapore", timezone="Asia/Singapore")


# Calendar registry
CALENDARS = {
    "Default": DEFAULT,
    "EveryDay": EVERY_DAY,
    "USFederal": US_FEDERAL,
    "US-Eastern": US_EASTERN,
    "US-Pacific": US_PACIFIC,
    "US-Central": US_CENTRAL,
    "UK-London": UK_LONDON,
    "EU-Berlin": EU_BERLIN,
    "Asia-Tokyo": ASIA_TOKYO,
    "Asia-Singapore": ASIA_SINGAPORE,
}


def get_calendar(name: str = "Default") -> Calendar:
    """Get a predefined calendar by name."""
    if name in CALENDARS:
        return CALENDARS[name]
    raise KeyError(f"Calendar '{name}' not found. Available: {list(CALENDARS.keys())}")


def get_default_calendar() -> Calendar:
    """Get the default calendar."""
    return DEFAULT


def register_calendar(calendar: Calendar) -> None:
    """Register a calendar in the global registry."""
    CALENDARS[calendar.name] = calendar


def list_calendars() -> list[str]:
    """List all available calendar names."""
    return list(CALENDARS.keys())
