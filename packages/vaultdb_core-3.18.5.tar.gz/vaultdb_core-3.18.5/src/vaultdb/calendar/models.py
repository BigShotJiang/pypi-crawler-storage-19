"""
Calendar model for VaultDB.

This module defines the Peewee model for storing calendar configurations and holidays
in the VaultdbDatabase. Holidays are stored as JSON in the calendar model itself.
"""

import datetime
import json
from typing import Optional

from peewee import AutoField
from peewee import CharField
from peewee import TextField

from .. import config
from ..data import VaultdbModel

logger = __import__("logging").getLogger()


class Calendar(VaultdbModel):
    """
    Calendar model for storing calendar configurations and holidays.

    Each calendar has a name and configuration for weekdays/weekends.
    Weekends are stored as a comma-separated string of weekday numbers (0=Monday, 6=Sunday).
    Timezone is stored as a string (e.g., "UTC", "America/New_York").
    Holidays are stored as JSON in the holidays field: {"YYYY-MM-DD": {"name": "...", "description": "..."}, ...}
    """

    # Primary key
    id = AutoField()

    # Calendar identification
    name = CharField(max_length=255, unique=True, help_text="Unique name for the calendar")

    # Weekend configuration (comma-separated weekday numbers: 0=Monday, 6=Sunday)
    # Default: "5,6" means Saturday and Sunday are weekends
    weekends = CharField(max_length=50, default="5,6", help_text="Comma-separated weekday numbers for weekends (0=Monday, 6=Sunday)")

    # Timezone configuration
    timezone = CharField(max_length=100, default="UTC", help_text="Timezone for the calendar (e.g., UTC, America/New_York)")

    # Holidays stored as JSON: {"YYYY-MM-DD": {"name": "...", "description": "..."}, ...}
    # If name/description are not provided, the value can be None or empty dict
    holidays = TextField(null=True, default="{}", help_text="JSON string storing holidays as date->info mapping")

    # Metadata
    description = TextField(null=True, help_text="Optional description of the calendar")

    class Meta:
        database = config.vaultdb_proxy
        table_name = "calendars"
        indexes = (
            (("name",), True),  # Unique index on name
        )

    def __str__(self) -> str:
        """String representation of Calendar."""
        return f"Calendar(name='{self.name}', timezone='{self.timezone}', weekends={self.weekends})"

    def __repr__(self) -> str:
        """Detailed representation of Calendar."""
        return f"Calendar(id={self.id}, name='{self.name}', timezone='{self.timezone}', weekends='{self.weekends}')"

    def get_weekend_days(self) -> set[int]:
        """
        Get weekend days as a set of integers.

        Returns:
            Set of weekday numbers (0=Monday, 6=Sunday) that are weekends.
        """
        if not self.weekends:
            return set()
        try:
            return {int(day.strip()) for day in self.weekends.split(",") if day.strip()}
        except ValueError:
            logger.warning(f"Invalid weekend configuration for calendar {self.name}: {self.weekends}")
            return {5, 6}  # Default to Saturday and Sunday

    def set_weekend_days(self, weekend_days: set[int] | list[int]) -> None:
        """
        Set weekend days from a set or list of weekday numbers.

        Args:
            weekend_days: Set or list of weekday numbers (0=Monday, 6=Sunday).
        """
        if not weekend_days:
            self.weekends = ""
        else:
            # Validate weekday numbers
            valid_days = {day for day in weekend_days if 0 <= day <= 6}
            self.weekends = ",".join(str(day) for day in sorted(valid_days))

    def get_holidays(self) -> dict[str, dict[str, str | None]]:
        """
        Get holidays as a dictionary mapping date strings to holiday info.

        Returns:
            Dictionary with date strings (YYYY-MM-DD) as keys and dict with optional
            "name" and "description" as values. Empty dict if no holidays.
        """
        if not self.holidays:
            return {}
        try:
            return json.loads(self.holidays)
        except (json.JSONDecodeError, TypeError):
            logger.warning(f"Invalid holidays JSON for calendar {self.name}: {self.holidays}")
            return {}

    def set_holidays(self, holidays: dict[str, dict[str, str | None]]) -> None:
        """
        Set holidays from a dictionary.

        Args:
            holidays: Dictionary with date strings (YYYY-MM-DD) as keys and dict with
                     optional "name" and "description" as values.
        """
        if not holidays:
            self.holidays = "{}"
        else:
            # Validate and normalize dates
            normalized = {}
            for date_str, info in holidays.items():
                try:
                    # Validate date format
                    datetime.datetime.strptime(date_str, "%Y-%m-%d")
                    # Ensure info is a dict with only name and description
                    normalized_info: dict[str, str | None] = {}
                    if isinstance(info, dict):
                        if "name" in info:
                            normalized_info["name"] = info["name"]
                        if "description" in info:
                            normalized_info["description"] = info["description"]
                    normalized[date_str] = normalized_info
                except ValueError:
                    logger.warning(f"Invalid date format '{date_str}' in holidays, skipping")
            self.holidays = json.dumps(normalized)

    def add_holiday(self, date: datetime.date, name: str | None = None, description: str | None = None) -> None:
        """
        Add a holiday to the calendar.

        Args:
            date: Holiday date.
            name: Optional holiday name.
            description: Optional holiday description.
        """
        holidays = self.get_holidays()
        date_str = date.isoformat()
        holidays[date_str] = {}
        if name:
            holidays[date_str]["name"] = name
        if description:
            holidays[date_str]["description"] = description
        self.set_holidays(holidays)
        self.save()

    def remove_holiday(self, date: datetime.date) -> bool:
        """
        Remove a holiday from the calendar.

        Args:
            date: Holiday date.

        Returns:
            True if holiday was removed, False if it didn't exist.
        """
        holidays = self.get_holidays()
        date_str = date.isoformat()
        if date_str in holidays:
            del holidays[date_str]
            self.set_holidays(holidays)
            self.save()
            return True
        return False

    def is_holiday(self, date: datetime.date) -> bool:
        """
        Check if a date is a holiday.

        Args:
            date: Date to check.

        Returns:
            True if the date is a holiday, False otherwise.
        """
        holidays = self.get_holidays()
        date_str = date.isoformat()
        return date_str in holidays

    def get_holiday_info(self, date: datetime.date) -> dict[str, str | None] | None:
        """
        Get holiday information for a date.

        Args:
            date: Date to check.

        Returns:
            Dictionary with "name" and "description" keys, or None if not a holiday.
        """
        holidays = self.get_holidays()
        date_str = date.isoformat()
        return holidays.get(date_str)

    @classmethod
    def get_by_name(cls, name: str) -> Optional["Calendar"]:
        """
        Get calendar by name.

        Args:
            name: Calendar name.

        Returns:
            Calendar instance or None if not found.
        """
        try:
            return cls.get(cls.name == name)
        except cls.DoesNotExist:
            return None

    @classmethod
    def create_calendar(cls, name: str, weekends: set[int] | list[int] | None = None, timezone: str = "UTC", description: str | None = None) -> "Calendar":
        """
        Create a new calendar.

        Args:
            name: Calendar name (must be unique).
            weekends: Set or list of weekday numbers for weekends (default: {5, 6} for Sat-Sun).
            timezone: Timezone string (default: "UTC").
            description: Optional description.

        Returns:
            Created Calendar instance.

        Raises:
            ValueError: If calendar name already exists.
        """
        if cls.get_by_name(name) is not None:
            raise ValueError(f"Calendar with name '{name}' already exists")

        calendar = cls(name=name, timezone=timezone, description=description)
        if weekends is None:
            weekends = {5, 6}  # Default: Saturday and Sunday
        calendar.set_weekend_days(weekends)
        calendar.save()
        return calendar
