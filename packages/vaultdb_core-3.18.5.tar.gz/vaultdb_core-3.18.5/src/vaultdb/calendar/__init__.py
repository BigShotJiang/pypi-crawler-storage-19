"""
Calendar module for VaultDB.

Provides calendar functionality including business day calculations,
holiday management, and weekend configuration.

Example:
    from vaultdb.calendar import DEFAULT, US_FEDERAL, get_calendar

    # Use predefined calendars
    calendar = DEFAULT
    calendar.is_business_day(date.today())

    # Get calendar by name
    us_cal = get_calendar("USFederal")
    us_cal.first_business_day_of_month(2024, 1)

    # Create custom calendar
    my_cal = Calendar(
        name="MyCompany",
        holidays=[date(2024, 12, 25)],
        timezone="America/New_York",
    )
"""

from .calendar import ASIA_SINGAPORE
from .calendar import ASIA_TOKYO
from .calendar import CALENDARS
from .calendar import DEFAULT  # Predefined calendars
from .calendar import EU_BERLIN
from .calendar import EVERY_DAY
from .calendar import UK_LONDON
from .calendar import US_CENTRAL
from .calendar import US_EASTERN
from .calendar import US_FEDERAL
from .calendar import US_PACIFIC
from .calendar import Calendar  # Main class
from .calendar import Weekday
from .calendar import get_calendar  # Functions
from .calendar import get_default_calendar
from .calendar import list_calendars
from .calendar import register_calendar
from .calendar import us_federal_holidays
from .calendar import us_federal_holidays_range
from .models import Calendar as CalendarModel

__all__ = [
    # Main class
    "Calendar",
    "CalendarModel",
    "Weekday",
    # Predefined calendars
    "DEFAULT",
    "EVERY_DAY",
    "US_FEDERAL",
    "US_EASTERN",
    "US_PACIFIC",
    "US_CENTRAL",
    "UK_LONDON",
    "EU_BERLIN",
    "ASIA_TOKYO",
    "ASIA_SINGAPORE",
    "CALENDARS",
    # Functions
    "get_calendar",
    "get_default_calendar",
    "register_calendar",
    "list_calendars",
    "us_federal_holidays",
    "us_federal_holidays_range",
]
