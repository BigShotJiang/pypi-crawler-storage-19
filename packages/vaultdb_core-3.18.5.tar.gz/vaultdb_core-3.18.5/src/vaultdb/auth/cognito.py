# Set up the logger
import logging
import os

import duckdb  # type: ignore

from .. import config
from . import utils
from .base import BaseAuthenticator

logger = logging.getLogger()


class CognitoAuthenticator(BaseAuthenticator):
    def __init__(
        self,
        pool_id: str,
        pool_app_client_id: str,
        identity_pool_id: str,
        bucket: str,
        aws_profile_name: str | None = None,
    ):
        super().__init__(bucket=bucket)
        self.user_pool_id = pool_id
        self.user_pool_app_client_id = pool_app_client_id
        self.user_identity_pool_id = identity_pool_id
        if not self.user_identity_pool_id:
            raise RuntimeError(
                "User pool information required for Cognito Authentication. "
                "Please check environment variables: user_bucket, user_pool_id, "
                "user_pool_app_client_id, user_identity_pool_id"
            )
        self.aws_region = self.user_identity_pool_id.split(":")[0]
        self.user_bucket = bucket
        self.aws_profile_name = aws_profile_name or config.cognito_aws_profile_name

    def authenticate(self, username: str, password: str) -> None:
        import boto3

        client = boto3.client("cognito-idp", region_name=self.aws_region)
        # Initiating the Authentication,
        response = client.initiate_auth(
            ClientId=self.user_pool_app_client_id,
            AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters={"USERNAME": username, "PASSWORD": password},
        )

        # From the JSON response you are accessing the AccessToken
        logger.debug(response)
        # Getting the user details.
        # access_token = response["AuthenticationResult"]["AccessToken"]
        id_token = response["AuthenticationResult"]["IdToken"]

        identity = boto3.client("cognito-identity", region_name=self.aws_region)
        response = identity.get_id(
            IdentityPoolId=self.user_identity_pool_id,
            Logins={f"cognito-idp.{self.aws_region}.amazonaws.com/{self.user_pool_id}": id_token},
        )
        logger.debug(response)
        identity_id = response["IdentityId"]

        response = identity.get_credentials_for_identity(
            IdentityId=identity_id,
            Logins={f"cognito-idp.{self.aws_region}.amazonaws.com/{self.user_pool_id}": id_token},
        )

        logger.debug(response)

        credentials = response["Credentials"]
        self.AccessKeyId = credentials["AccessKeyId"]
        self.SecretKey = credentials["SecretKey"]
        self.SessionToken = credentials["SessionToken"]

        utils.set_aws_credentials(self.AccessKeyId, self.SecretKey, self.SessionToken)
        utils.create_aws_profile(self.aws_profile_name, self.AccessKeyId, self.SecretKey, self.SessionToken, self.aws_region)

    def download_file(self, s3_key: str, local_path: str) -> None:
        """
        Downloads a file from S3 using the authenticated credentials

        Args:
            bucket_name (str): The name of the S3 bucket
            s3_key (str): The path/key of the file in S3
            local_path (str): The local path where the file should be saved
        """
        if os.path.isfile(local_path):
            os.remove(local_path)

        if os.path.isfile(local_path + ".wal"):
            os.remove(local_path + ".wal")

        # TODO: for base auth maybe just copy file from mapped drive where master copy is available for users to share.
        # Add Mount path for data file from environment variable
        import boto3

        if self.AccessKeyId:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=self.AccessKeyId,
                aws_secret_access_key=self.SecretKey,
                aws_session_token=self.SessionToken,
                region_name=self.aws_region,
            )
        else:
            # Try to use AWS profile if credentials not directly available
            try:
                session = boto3.Session(profile_name=self.aws_profile_name)
                s3_client = session.client("s3", region_name=self.aws_region)
            except Exception as e:
                logger.warning(f"Could not use AWS profile {self.aws_profile_name}: {e}. Trying default credentials.")
                s3_client = boto3.client("s3", region_name=self.aws_region)
        logger.info(f"downloading file {s3_key} at {local_path}")
        s3_client.download_file(self.user_bucket, s3_key, local_path)

    def create_secrets(self, connection: duckdb.DuckDBPyConnection, role: str) -> None:
        if self.user_bucket:
            connection.execute(f"CREATE OR REPLACE CONFIG remote_merge_path AS 's3://{self.user_bucket}';")
        if self.user_pool_id:
            connection.execute(f"CREATE OR REPLACE CONFIG user_pool_id AS '{self.user_pool_id}';")
        if self.user_pool_app_client_id:
            connection.execute(f"CREATE OR REPLACE CONFIG user_pool_client_id AS '{self.user_pool_app_client_id}';")
        if self.user_identity_pool_id:
            connection.execute(f"CREATE OR REPLACE CONFIG identity_pool_id AS '{self.user_identity_pool_id}';")

        if self.AccessKeyId:
            connection.execute(
                f"CREATE OR REPLACE SECRET {role} (TYPE S3, PROVIDER config, "
                f"KEY_ID '{self.AccessKeyId}', SECRET '{self.SecretKey}', "
                f"REGION '{self.aws_region}', SESSION_TOKEN '{self.SessionToken}')"
            )
            # duckdb_secrets = connection.execute("select * from duckdb_secrets();").fetch_df()
            # print(duckdb_secrets.head(5))


if __name__ == "__main__":
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)  # Very verbose
    auth_service = CognitoAuthenticator(
        pool_id="xxxxxxxxxxx", pool_app_client_id="xxxxxxxxxxxxxxxxxxxxx", identity_pool_id="xxxxxxxxxxxxxxxxxxxxxxxxxxxx", bucket="xxxxxxxxxxxxxxxxxxxxxxxxx"
    )
    auth_service.authenticate("vaultdb", "test123")
    # auth_service.create_secrets()
