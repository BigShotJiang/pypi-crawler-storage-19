"""
OAuth 2.0 Authenticator for VaultDB.

This module provides OAuth 2.0 authentication support, allowing users to connect
with various OAuth 2.0 providers. It also handles AWS credential management when
OAuth providers return AWS credentials.
"""

import logging
import os
import secrets
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler
from http.server import HTTPServer
from typing import Any
from urllib.parse import parse_qs
from urllib.parse import urlparse

import duckdb  # type: ignore
import requests

from .. import config
from . import utils
from .base import BaseAuthenticator

logger = logging.getLogger()


class OAuth2Authenticator(BaseAuthenticator):
    """
    OAuth 2.0 authenticator supporting authorization code flow.

    This authenticator supports standard OAuth 2.0 authorization code flow
    and can extract AWS credentials from OAuth responses to create AWS profiles
    for local development and S3 access.

    Attributes:
        client_id: OAuth 2.0 client ID
        client_secret: OAuth 2.0 client secret
        authorization_url: OAuth 2.0 authorization endpoint URL
        token_url: OAuth 2.0 token endpoint URL
        redirect_uri: OAuth 2.0 redirect URI
        scope: OAuth 2.0 scopes to request
        user_bucket: S3 bucket name for user data
        aws_region: AWS region for credentials
        access_token: OAuth access token
        refresh_token: OAuth refresh token
        token_type: OAuth token type (typically "Bearer")
        expires_in: Token expiration time in seconds
        aws_profile_name: Name of AWS profile to create if AWS credentials are returned
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        authorization_url: str,
        token_url: str,
        redirect_uri: str,
        scope: str = "openid profile email",
        bucket: str = "",
        aws_region: str = "us-east-1",
        aws_profile_name: str | None = None,
    ) -> None:
        """
        Initialize OAuth 2.0 authenticator.

        Args:
            client_id: OAuth 2.0 client ID
            client_secret: OAuth 2.0 client secret
            authorization_url: OAuth 2.0 authorization endpoint URL
            token_url: OAuth 2.0 token endpoint URL
            redirect_uri: OAuth 2.0 redirect URI (must match provider configuration)
            scope: OAuth 2.0 scopes to request (default: "openid profile email")
            bucket: S3 bucket name for user data
            aws_region: AWS region for credentials (default: "us-east-1")
            aws_profile_name: Name of AWS profile to create (default: "vaultdb-oauth")
        """
        super().__init__(bucket=bucket)
        self.client_id = client_id
        self.client_secret = client_secret
        self.authorization_url = authorization_url
        self.token_url = token_url
        self.redirect_uri = redirect_uri
        self.scope = scope
        self.aws_region = aws_region or config.aws_default_region
        self.aws_profile_name = aws_profile_name or config.oauth2_aws_profile_name

        # Token storage
        self.access_token: str | None = None
        self.refresh_token: str | None = None
        self.token_type: str = "Bearer"
        self.expires_in: int | None = None
        self.token_received_at: float = 0.0

        # AWS credentials (if returned by OAuth provider)
        self.AccessKeyId: str | None = None
        self.SecretKey: str | None = None
        self.SessionToken: str | None = None

    def _interactive_login(self) -> str:
        """
        Perform interactive login via web browser.

        This method:
        1. Starts a local HTTP server to listen for the OAuth callback.
        2. Opens the system web browser to the authorization URL.
        3. Waits for the user to authenticate and be redirected back.
        4. Returns the received authorization code.
        """
        # Parse redirect URI to get hostname, port and path
        parsed_redirect = urllib.parse.urlparse(self.redirect_uri)
        if parsed_redirect.scheme != "http":
            raise ValueError("Interactive login requires a local http redirect URI")

        hostname = parsed_redirect.hostname or "localhost"
        port = parsed_redirect.port or 80
        path = parsed_redirect.path

        # State for validation
        state = secrets.token_urlsafe(32)
        auth_code: str | None = None
        auth_error: str | None = None

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                nonlocal auth_code, auth_error

                # Check path (ignore /favicon.ico etc)
                req_url = urlparse(self.path)
                if req_url.path != path:
                    self.send_error(404, "Not Found")
                    return

                # Parse query params
                query = parse_qs(req_url.query)

                # Check state
                if query.get("state", [""])[0] != state:
                    self.send_error(400, "Invalid state parameter")
                    auth_error = "Invalid state parameter"
                    return

                # Get code
                # DuckDB's authenticator might use different query param? No standard is 'code'.
                code = query.get("code", [""])[0]
                if code:
                    auth_code = code
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<h1>Authentication successful!</h1><p>You can close this window and return to the application.</p><script>window.close()</script>"
                    )
                else:
                    self.send_error(400, "No code provided")
                    auth_error = "No code provided"

            def log_message(self, format, *args):
                # Suppress logging
                pass

        # Start server
        try:
            server = HTTPServer((hostname, port), CallbackHandler)
        except OSError as e:
            raise RuntimeError(f"Could not start local server on {hostname}:{port}. Is the port already in use?") from e

        try:
            # Get auth URL
            auth_url = self.get_authorization_url(state=state)

            # Open browser
            logger.info(f"Opening browser to: {auth_url}")
            logger.info(f"Waiting for callback on {hostname}:{port}...")
            webbrowser.open(auth_url)

            # Wait for request
            # We handle requests until we get the code
            while not auth_code and not auth_error:
                server.handle_request()

        except KeyboardInterrupt:
            logger.info("Login cancelled by user")
            raise
        finally:
            server.server_close()

        if auth_error:
            raise RuntimeError(f"Authentication failed: {auth_error}")

        if auth_code:
            logger.info("Authorization code received")
            return auth_code
        else:
            raise RuntimeError("Failed to obtain authorization code")

    def get_authorization_url(self, state: str | None = None) -> str:
        """
        Generate OAuth 2.0 authorization URL.

        Args:
            state: Optional state parameter for CSRF protection. If not provided,
                   a random state will be generated.

        Returns:
            Authorization URL that user should visit to authenticate.
        """
        if state is None:
            state = secrets.token_urlsafe(32)

        params = {
            "response_type": "code",
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": self.scope,
            "state": state,
        }

        query_string = urllib.parse.urlencode(params)
        authorization_url = f"{self.authorization_url}?{query_string}"

        logger.debug(f"Generated authorization URL: {authorization_url}")
        return authorization_url

    def _is_token_valid(self) -> bool:
        """Check if current access token is valid."""
        if not self.access_token:
            return False

        if self.expires_in:
            # Buffer of 60 seconds
            if time.time() > (self.token_received_at + self.expires_in - 60):
                return False

        return True

    def authenticate(
        self,
        authorization_code: str | None = None,
        state: str | None = None,
        access_token: str | None = None,
        refresh_token: str | None = None,
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
        aws_session_token: str | None = None,
    ) -> None:
        """
        Authenticate using OAuth 2.0.

        This method supports multiple authentication flows:
        1. Authorization code flow: Provide authorization_code
        2. Direct token: Provide access_token and optionally refresh_token
        3. AWS credentials: Provide AWS credentials directly
        4. Auto/Interactive: If no params provided, tries to use existing valid token,
           then refresh token, and finally interactive login.

        Args:
            authorization_code: Authorization code from OAuth provider
            state: State parameter (unused in auth code flow here)
            access_token: Access token (direct)
            refresh_token: Refresh token (direct)
            aws_access_key_id: AWS Access Key ID
            aws_secret_access_key: AWS Secret Access Key
            aws_session_token: AWS Session Token
        """
        # 1. AWS Credentials
        if aws_access_key_id and aws_secret_access_key:
            logger.info("Using provided AWS credentials")
            self.AccessKeyId = aws_access_key_id
            self.SecretKey = aws_secret_access_key
            self.SessionToken = aws_session_token

            utils.set_aws_credentials(aws_access_key_id, aws_secret_access_key, aws_session_token)
            utils.create_aws_profile(self.aws_profile_name, aws_access_key_id, aws_secret_access_key, aws_session_token, self.aws_region)
            return

        # 2. Direct Access Token
        if access_token:
            logger.info("Using provided access token")
            self.access_token = access_token
            if refresh_token:
                self.refresh_token = refresh_token
            # Try to extract AWS credentials from token or make API call
            self._extract_aws_credentials_from_token()
            return

        # 3. Authorization Code (Provided)
        if authorization_code:
            logger.info("Exchanging provided authorization code for access token")
            token_data = self._exchange_authorization_code(authorization_code)
            self._process_token_response(token_data)
            return

        # 4. Auto / Interactive
        if self._is_token_valid():
            logger.info("Using existing valid access token")
            return

        # Try refresh
        if self.refresh_token:
            try:
                logger.info("Attempting to refresh access token...")
                self.refresh_access_token()
                return
            except Exception as e:
                logger.warning(f"Refresh failed: {e}")

        # Interactive login
        logger.info("No valid credentials found. Starting interactive login...")
        code = self._interactive_login()
        logger.info("Exchanging authorization code for access token")
        token_data = self._exchange_authorization_code(code)
        self._process_token_response(token_data)

    def _exchange_authorization_code(self, authorization_code: str) -> dict[str, Any]:
        """
        Exchange authorization code for access token.

        Args:
            authorization_code: Authorization code from OAuth provider

        Returns:
            Token response dictionary containing access_token, refresh_token, etc.

        Raises:
            RuntimeError: If token exchange fails
        """
        data = {
            "grant_type": "authorization_code",
            "code": authorization_code,
            "redirect_uri": self.redirect_uri,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        try:
            response = requests.post(self.token_url, data=data, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to exchange authorization code: {e}")
            raise RuntimeError(f"OAuth token exchange failed: {e}") from e

    def _extract_aws_credentials_from_token_response(self, token_data: dict[str, Any]) -> None:
        """
        Extract AWS credentials from OAuth token response.

        Some OAuth providers return AWS credentials directly in the token response.
        This method looks for common field names.

        Args:
            token_data: Token response dictionary from OAuth provider
        """
        # Check for AWS credentials in token response
        aws_creds = token_data.get("aws_credentials") or token_data.get("aws") or token_data.get("credentials")

        if aws_creds:
            if isinstance(aws_creds, dict):
                access_key = aws_creds.get("access_key_id") or aws_creds.get("AccessKeyId")
                secret_key = aws_creds.get("secret_access_key") or aws_creds.get("SecretAccessKey")
                session_token = aws_creds.get("session_token") or aws_creds.get("SessionToken")

                if access_key and secret_key:
                    logger.info("Found AWS credentials in OAuth token response")
                    self.AccessKeyId = access_key
                    self.SecretKey = secret_key
                    self.SessionToken = session_token

                    utils.set_aws_credentials(access_key, secret_key, session_token)
                    utils.create_aws_profile(self.aws_profile_name, access_key, secret_key, session_token, self.aws_region)

    def _extract_aws_credentials_from_token(self) -> None:
        """
        Extract AWS credentials by making an API call with the access token.

        Some OAuth providers require an additional API call to get AWS credentials.
        This is a placeholder that can be overridden for specific providers.
        """
        # This is a placeholder - specific OAuth providers can override this
        # to make provider-specific API calls
        logger.debug("Attempting to extract AWS credentials from access token")
        # Example: Some providers might have an endpoint like:
        # GET /aws-credentials with Authorization: Bearer <access_token>

    def _process_token_response(self, token_data: dict[str, Any]) -> None:
        """
        Process token response to update authenticator state.

        Args:
            token_data: Dictionary containing token response data
        """
        self.access_token = token_data.get("access_token")
        # Only update refresh token if provided, otherwise keep existing
        if "refresh_token" in token_data:
            self.refresh_token = token_data.get("refresh_token")

        self.token_type = token_data.get("token_type", "Bearer")
        self.expires_in = token_data.get("expires_in")
        self.token_received_at = time.time()

        if not self.access_token:
            raise RuntimeError("Failed to obtain access token from OAuth provider")

        logger.debug(f"Successfully obtained access token (expires in {self.expires_in}s)")

        # Try to extract AWS credentials from token response
        self._extract_aws_credentials_from_token_response(token_data)

    def refresh_access_token(self) -> None:
        """
        Refresh the access token using the refresh token.

        Raises:
            RuntimeError: If refresh token is not available or refresh fails
        """
        if not self.refresh_token:
            raise RuntimeError("No refresh token available")

        logger.info("Refreshing access token")

        data = {
            "grant_type": "refresh_token",
            "refresh_token": self.refresh_token,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        try:
            response = requests.post(self.token_url, data=data, timeout=30)
            response.raise_for_status()
            token_data = response.json()

            logger.info("Access token refreshed successfully")
            self._process_token_response(token_data)

        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to refresh access token: {e}")
            raise RuntimeError(f"Token refresh failed: {e}") from e

    def download_file(self, s3_key: str, local_path: str) -> None:
        """
        Downloads a file from S3 using the authenticated credentials.

        Args:
            s3_key: The path/key of the file in S3
            local_path: The local path where the file should be saved
        """
        if os.path.isfile(local_path):
            os.remove(local_path)

        if os.path.isfile(local_path + ".wal"):
            os.remove(local_path + ".wal")

        import boto3

        if self.AccessKeyId:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=self.AccessKeyId,
                aws_secret_access_key=self.SecretKey,
                aws_session_token=self.SessionToken,
                region_name=self.aws_region,
            )
        else:
            # Try to use AWS profile if credentials not directly available
            try:
                session = boto3.Session(profile_name=self.aws_profile_name)
                s3_client = session.client("s3", region_name=self.aws_region)
            except Exception as e:
                logger.warning(f"Could not use AWS profile {self.aws_profile_name}: {e}. Trying default credentials.")
                s3_client = boto3.client("s3", region_name=self.aws_region)

        logger.info(f"Downloading file {s3_key} to {local_path}")
        s3_client.download_file(self.user_bucket, s3_key, local_path)

    def create_secrets(self, connection: duckdb.DuckDBPyConnection, role: str) -> None:
        """
        Create DuckDB secrets for S3 access using AWS credentials.

        Args:
            connection: DuckDB connection object
            role: Role name for the secret
        """
        if self.user_bucket:
            connection.execute(f"CREATE OR REPLACE CONFIG remote_merge_path AS 's3://{self.user_bucket}';")

        if self.AccessKeyId:
            session_token_sql = f", SESSION_TOKEN '{self.SessionToken}'" if self.SessionToken else ""
            connection.execute(
                f"CREATE OR REPLACE SECRET {role} (TYPE S3, PROVIDER config, "
                f"KEY_ID '{self.AccessKeyId}', SECRET '{self.SecretKey}', "
                f"REGION '{self.aws_region}'{session_token_sql})"
            )
            logger.debug(f"Created DuckDB secret '{role}' for S3 access")


if __name__ == "__main__":
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Example usage
    authenticator = OAuth2Authenticator(
        client_id="your-client-id",
        client_secret="your-client-secret",
        authorization_url="https://oauth.example.com/authorize",
        token_url="https://oauth.example.com/token",
        redirect_uri="http://localhost:8080/callback",
        bucket="example-bucket",
    )

    # Get authorization URL
    auth_url = authenticator.get_authorization_url()
    print(f"Visit this URL to authenticate: {auth_url}")

    # After user authenticates and redirects back with code:
    # authenticator.authenticate(authorization_code="code-from-redirect")
