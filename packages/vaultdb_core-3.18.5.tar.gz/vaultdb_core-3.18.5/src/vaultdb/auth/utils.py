"""
Common authentication utilities.

This module provides shared functionality for authentication methods,
particularly AWS credential management and profile creation.
"""

import configparser
import logging
import os
from pathlib import Path

from .. import settings

logger = logging.getLogger(__name__)


def set_aws_credentials(access_key_id: str, secret_access_key: str, session_token: str | None = None) -> None:
    """
    Set AWS credentials in settings.

    Args:
        access_key_id: AWS access key ID
        secret_access_key: AWS secret access key
        session_token: Optional AWS session token
    """
    settings.aws_credentials = {
        "aws_access_key_id": access_key_id,
        "aws_secret_access_key": secret_access_key,
    }
    if session_token:
        settings.aws_credentials["aws_session_token"] = session_token

    logger.debug("AWS credentials set in global settings")


def create_aws_profile(profile_name: str, access_key_id: str, secret_access_key: str, session_token: str | None = None, region: str | None = None) -> None:
    """
    Create AWS profile in ~/.aws/credentials file.

    This allows boto3 and AWS CLI to use the credentials.
    The profile is created with the name specified in profile_name.
    Also sets the active profile in config.py.

    Args:
        profile_name: Name of the profile to create
        access_key_id: AWS access key ID
        secret_access_key: AWS secret access key
        session_token: Optional AWS session token
        region: Optional AWS region
    """
    if not access_key_id or not secret_access_key:
        logger.warning("Cannot create AWS profile: credentials not available")
        return

    aws_dir = Path.home() / ".aws"
    credentials_file = aws_dir / "credentials"

    # Create .aws directory if it doesn't exist
    aws_dir.mkdir(mode=0o700, exist_ok=True)

    # Read existing credentials file or create new config
    config_parser = configparser.ConfigParser()
    if credentials_file.exists():
        try:
            config_parser.read(credentials_file)
        except configparser.Error:
            logger.warning(f"Could not read existing credentials file {credentials_file}, overwriting")

    # Set credentials for the profile
    if profile_name not in config_parser.sections():
        config_parser.add_section(profile_name)

    config_parser.set(profile_name, "aws_access_key_id", access_key_id)
    config_parser.set(profile_name, "aws_secret_access_key", secret_access_key)
    if session_token:
        config_parser.set(profile_name, "aws_session_token", session_token)
    if region:
        config_parser.set(profile_name, "region", region)

    # Write credentials file with restricted permissions
    try:
        with open(credentials_file, "w", encoding="utf-8") as f:
            config_parser.write(f)

        # Set file permissions to 600 (read/write for owner only)
        os.chmod(credentials_file, 0o600)
        logger.info(f"Created/Updated AWS profile '{profile_name}' in {credentials_file}")
    except Exception as e:
        logger.error(f"Failed to write AWS credentials file: {e}")
        return

    # Also set as default profile if no default exists
    if "default" not in config_parser.sections():
        logger.info("Setting profile as default AWS profile")
        config_parser.add_section("default")
        config_parser.set("default", "aws_access_key_id", access_key_id)
        config_parser.set("default", "aws_secret_access_key", secret_access_key)
        if session_token:
            config_parser.set("default", "aws_session_token", session_token)
        if region:
            config_parser.set("default", "region", region)

        try:
            with open(credentials_file, "w", encoding="utf-8") as f:
                config_parser.write(f)
            os.chmod(credentials_file, 0o600)
        except Exception as e:
            logger.error(f"Failed to update default profile: {e}")

    # Update active profile in config
    logger.info(f"Set active AWS profile to '{profile_name}'")
