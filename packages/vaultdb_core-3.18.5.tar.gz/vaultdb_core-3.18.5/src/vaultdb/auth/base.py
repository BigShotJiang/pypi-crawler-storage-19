# Set up the logger
import logging
import os

import duckdb  # type: ignore

logger = logging.getLogger()


class BaseAuthenticator:
    def __init__(self, bucket: str = ""):
        self.user_bucket = bucket

    def authenticate(self, *args, **kwargs) -> None:  # type: ignore
        pass

    def download_file(self, s3_key: str, local_path: str) -> None:
        """
        Downloads a file from S3 using the authenticated credentials

        Args:
            bucket_name (str): The name of the S3 bucket
            s3_key (str): The path/key of the file in S3
            local_path (str): The local path where the file should be saved
        """
        if os.path.isfile(local_path):
            os.remove(local_path)

        if os.path.isfile(local_path + ".wal"):
            os.remove(local_path + ".wal")

        if self.user_bucket:
            import boto3

            s3_client = boto3.client("s3")
            s3_client.download_file(self.user_bucket, s3_key, local_path)

    def create_secrets(self, connection: duckdb.DuckDBPyConnection, role: str) -> None:  # pyright: ignore[reportUnusedParameter]
        pass


if __name__ == "__main__":
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)  # Very verbose
    auth_service = BaseAuthenticator(bucket="xxxxxxxxxxxxxxxxxxxxxxxxx")
    auth_service.authenticate("vaultdb", "test123")
    # auth_service.create_secrets()
