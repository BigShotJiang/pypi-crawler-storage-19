"""
FastAPI web interface for VaultDB task submission and management.

This module provides REST API endpoints for:
- Submitting tasks to different runners (Service, Function, Batch)
- Querying task status
- Listing available tasks
"""

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI
from fastapi import HTTPException
from fastapi import status
from pydantic import BaseModel
from pydantic import Field

from ..compute.core import RunType
from ..compute.core import get_runner
from ..compute.result import AsyncResult
from ..compute.taskstatus import TaskStatus

# Configure logging
logger = logging.getLogger(__name__)


runner_map = {
    "function": RunType.FUNCTION,
    "batch": RunType.BATCH,
    "local": RunType.LOCAL,
}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager for startup and shutdown events."""
    # Startup
    try:
        from ..scheduler.discovery import discover_tasks

        logger.info("Discovering tasks...")
        discover_tasks()
    except Exception as e:
        logger.error(f"Error during task discovery: {e}", exc_info=True)

    yield
    # Shutdown logic can go here if needed


# Create FastAPI app
app = FastAPI(
    title="VaultDB Task API",
    description="API for submitting and managing tasks across service, Lambda, and Batch runners",
    version="1.0.0",
    lifespan=lifespan,
)


# Pydantic models for request/response
class TaskSubmitRequest(BaseModel):
    """Request model for task submission."""

    task_name: str = Field(..., description="Name of the task to execute")
    args: list[Any] = Field(default_factory=list, description="Positional arguments for the task")
    kwargs: dict[str, Any] = Field(default_factory=dict, description="Keyword arguments for the task")
    runner: str = Field(default="service", description="Runner type: service, function, or batch")
    task_id: str | None = Field(default=None, description="Optional task ID (auto-generated if not provided)")
    queue: str | None = Field(default=None, description="Queue name for routing")
    countdown: float | None = Field(default=None, description="Delay in seconds before execution")
    eta: str | None = Field(default=None, description="Estimated time of arrival (ISO format)")
    expires: str | None = Field(default=None, description="Expiration time (ISO format)")
    time_limit: int | None = Field(default=None, description="Hard time limit in seconds")
    soft_time_limit: int | None = Field(default=None, description="Soft time limit in seconds")
    # Batch-specific options
    memory: int | None = Field(default=None, description="Memory in MB (Batch only)")
    number_of_cpus: int | None = Field(default=None, description="Number of CPUs (Batch only)")
    number_of_gpus: int | None = Field(default=None, description="Number of GPUs (Batch only)")
    job_queue: str | None = Field(default=None, description="AWS Batch job queue (Batch only)")
    job_definition: str | None = Field(default=None, description="AWS Batch job definition (Batch only)")
    # Function-specific options
    function_name: str | None = Field(default=None, description="Function name (Function only)")


class TaskStatusResponse(BaseModel):
    """Response model for task status."""

    task_id: str
    status: str
    name: str | None = None
    result: Any | None = None
    traceback: str | None = None
    retries: int = 0
    worker_id: str | None = None
    date_created: str | None = None
    date_done: str | None = None
    runtime: float | None = None


class TaskSubmitResponse(BaseModel):
    """Response model for task submission."""

    task_id: str
    status: str
    runner: str
    message: str


class TaskListResponse(BaseModel):
    """Response model for task list."""

    tasks: list[dict[str, Any]]


class ScheduledTaskResponse(BaseModel):
    """Response model for a scheduled task."""

    name: str
    task: str
    schedule: str
    args: list[Any]
    kwargs: dict[str, Any]


class ScheduledTaskListResponse(BaseModel):
    """Response model for scheduled task list."""

    schedules: list[ScheduledTaskResponse]


def _get_runner(runner_type: str) -> Any:
    """Get runner instance based on runner type.

    Args:
        runner_type: Type of runner ('service', 'function', or 'batch').

    Returns:
        Runner instance.

    Raises:
        HTTPException: If runner type is invalid.
    """

    if runner_type.lower() not in runner_map:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid runner type: {runner_type}. Must be one of: {', '.join(runner_map.keys())}",
        )

    return get_runner(runtype=runner_map[runner_type.lower()])


@app.get("/", tags=["Health"])
async def root() -> dict[str, str]:
    """Root endpoint for health check."""
    return {"message": "VaultDB Task API", "status": "healthy"}


@app.get("/tasks", response_model=TaskListResponse, tags=["Tasks"])
async def list_tasks() -> TaskListResponse:
    """List all available tasks.

    Returns:
        List of available tasks with their metadata.
    """
    try:
        tasks = []
        for runner_type in runner_map:
            app_instance = _get_runner(runner_type.lower())
            for task_name, task in app_instance.tasks.items():
                task_info: dict[str, Any] = {
                    "runner": runner_type,
                    "name": task_name,
                    "doc": task.__doc__ or "",
                    "module": task.__module__,
                }
                if hasattr(task, "run") and task.run:
                    try:
                        task_info["annotations"] = list(task.run.__annotations__.keys())
                    except Exception:
                        task_info["annotations"] = []
                tasks.append(task_info)

        return TaskListResponse(tasks=tasks)
    except Exception as e:
        logger.error(f"Error listing tasks: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.get("/schedules", response_model=ScheduledTaskListResponse, tags=["Tasks"])
async def list_schedules() -> ScheduledTaskListResponse:
    """List all scheduled tasks.

    Returns:
        List of scheduled tasks.
    """
    try:
        from ..scheduler.registry import ScheduledTaskRegistry

        registry = ScheduledTaskRegistry()
        schedules = []

        for name, task in registry.get_all().items():
            schedules.append(
                ScheduledTaskResponse(
                    name=name,
                    task=task.task_name,
                    schedule=str(task.schedule),
                    args=list(task.args),
                    kwargs=task.kwargs,
                )
            )

        return ScheduledTaskListResponse(schedules=schedules)
    except Exception as e:
        logger.error(f"Error listing schedules: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.post("/tasks/submit", response_model=TaskSubmitResponse, tags=["Tasks"])
async def submit_task(request: TaskSubmitRequest) -> TaskSubmitResponse:
    """Submit a task for execution.

    Args:
        request: Task submission request.

    Returns:
        Task submission response with task ID and status.
    """
    try:
        # Get runner instance
        runner = _get_runner(request.runner)

        # Check if task exists
        if request.task_name not in runner.tasks:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Task '{request.task_name}' not found. Use GET /tasks to list available tasks.",
            )

        # Prepare options
        from datetime import datetime

        options: dict[str, Any] = {}
        if request.queue:
            options["queue"] = request.queue
        if request.time_limit:
            options["time_limit"] = request.time_limit
        if request.soft_time_limit:
            options["soft_time_limit"] = request.soft_time_limit
        if request.expires:
            options["expires"] = datetime.fromisoformat(request.expires.replace("Z", "+00:00"))

        # Runner-specific options
        if request.runner.lower() == "batch":
            if request.memory:
                options["memory"] = request.memory
            if request.number_of_cpus:
                options["number_of_cpus"] = request.number_of_cpus
            if request.number_of_gpus:
                options["number_of_gpus"] = request.number_of_gpus
            if request.job_queue:
                options["job_queue"] = request.job_queue
            if request.job_definition:
                options["job_definition"] = request.job_definition

        if request.runner.lower() == "function":
            if request.function_name:
                options["function_name"] = request.function_name

        # Get task and submit
        task = runner.tasks[request.task_name]

        # Convert args to tuple if needed
        args_tuple = tuple(request.args) if request.args else None

        # Handle ETA conversion
        eta_datetime = None
        if request.eta:
            eta_datetime = datetime.fromisoformat(request.eta.replace("Z", "+00:00"))

        # Submit task
        result = task.apply_async(
            args=args_tuple,
            kwargs=request.kwargs,
            task_id=request.task_id,
            countdown=request.countdown,
            eta=eta_datetime,
            **options,
        )

        return TaskSubmitResponse(
            task_id=result.task_id,
            status="PENDING",
            runner=request.runner,
            message=f"Task '{request.task_name}' submitted successfully",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error submitting task: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.get("/tasks/{task_id}/status", response_model=TaskStatusResponse, tags=["Tasks"])
async def get_task_status(task_id: str) -> TaskStatusResponse:
    """Get status of a task.

    Args:
        task_id: Task ID to query.

    Returns:
        Task status information.
    """
    try:
        task_status = TaskStatus.get_by_task_id(task_id)
        if not task_status:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Task '{task_id}' not found")

        # Parse result if it's a JSON string
        result = None
        if task_status.result:
            try:
                import json

                result = json.loads(task_status.result)
            except Exception:
                result = task_status.result

        return TaskStatusResponse(
            task_id=task_status.task_id,
            status=task_status.status,
            name=task_status.name,
            result=result,
            traceback=task_status.traceback,
            retries=task_status.retries or 0,
            worker_id=task_status.worker_id,
            date_created=task_status.date_created.isoformat() if task_status.date_created else None,
            date_done=task_status.date_done.isoformat() if task_status.date_done else None,
            runtime=task_status.runtime,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting task status: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.get("/tasks/{task_id}/result", tags=["Tasks"])
async def get_task_result(runner: str, task_id: str, timeout: float | None = None) -> dict[str, Any]:
    """Get result of a completed task (waits for completion if not done).

    Args:
        runner: Runner to use.
        task_id: Task ID to query.
        timeout: Maximum time to wait in seconds (None for indefinite).

    Returns:
        Task result.
    """
    try:
        if runner.lower() == "batch":
            from .batch import AsyncBatchResult

            result = AsyncBatchResult(task_id)
        else:
            result = AsyncResult(task_id)

        # Wait for result
        task_result = result.get(timeout=timeout, propagate=True)

        return {"task_id": task_id, "status": result.status, "result": task_result}

    except TimeoutError as e:
        raise HTTPException(status_code=status.HTTP_408_REQUEST_TIMEOUT, detail=str(e))
    except Exception as e:
        logger.error(f"Error getting task result: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@app.delete("/tasks/{task_id}", tags=["Tasks"])
async def revoke_task(runner: str, task_id: str) -> dict[str, str]:
    """Revoke a pending or running task.

    Args:
        runner: Runner to use.
        task_id: Task ID to revoke.

    Returns:
        Revocation confirmation.
    """
    try:
        # Note: Revocation support depends on runner implementation
        # For now, we'll update the status in the database
        task_status = TaskStatus.get_by_task_id(task_id)
        if not task_status:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Task '{task_id}' not found")

        if task_status.status in {"SUCCESS", "FAILURE", "REVOKED"}:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Task '{task_id}' is already in terminal state: {task_status.status}")

        if runner.lower() == "batch":
            from .batch import AsyncBatchResult

            result = AsyncBatchResult(task_id)
        else:
            result = AsyncResult(task_id)

        result.revoke()

        return {"message": f"Task '{task_id}' revoked successfully", "task_id": task_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error revoking task: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
