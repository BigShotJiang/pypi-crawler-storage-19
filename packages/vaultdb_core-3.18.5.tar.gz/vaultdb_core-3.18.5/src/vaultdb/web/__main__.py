"""Main entry point for running the FastAPI web server."""

import uvicorn

from vaultdb.web.api import app

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
