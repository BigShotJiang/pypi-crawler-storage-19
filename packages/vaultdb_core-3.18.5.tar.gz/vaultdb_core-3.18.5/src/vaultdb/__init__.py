from . import calendar
from . import config
from . import settings
from . import util
from ._state import TED
from ._state import set_default_task_runner
from .calendar import DEFAULT  # Predefined calendars
from .calendar import EVERY_DAY
from .calendar import US_FEDERAL

# Calendar - import key items for convenience
from .calendar import Calendar
from .calendar import Weekday
from .calendar import get_calendar
from .calendar import get_default_calendar
from .calendar import list_calendars
from .calendar import register_calendar
from .calendar import us_federal_holidays  # Helper functions
from .core import Application
from .core import AuthType

__version__ = "3.18.5"
__all__ = [
    "config",
    "settings",
    "util",
    "calendar",
    "TED",
    "set_default_task_runner",
    "Application",
    "AuthType",
    "Calendar",
    "Weekday",
    "get_calendar",
    "get_default_calendar",
    "register_calendar",
    "list_calendars",
    "DEFAULT",
    "EVERY_DAY",
    "US_FEDERAL",
    "us_federal_holidays",
]
