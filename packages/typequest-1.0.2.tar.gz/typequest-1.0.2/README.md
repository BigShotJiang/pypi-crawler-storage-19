# TypeQuest

Interactive CLI for learning backend development with SQL, Python, and Django.

## Installation

```bash
pip install typequest
```

## Usage

```bash
typequest
```

Or use the short alias:

```bash
tq
```

## Features

- **SQL Playground**: Practice SQL queries with real datasets
- **Python Playground**: Execute Python code interactively
- **Django Lessons**: Learn Django from basics to advanced
- **Progress Tracking**: Track your learning journey
- **Gamification**: Earn XP, achievements, and compete on leaderboards

## Commands

```bash
typequest              # Launch interactive CLI
typequest --help       # Show help
typequest --version    # Show version
typequest --diagnose   # Run diagnostics
typequest --update     # Check for updates
```

## Learning Tracks

### SQL Track
- Introduction to Databases
- SELECT Statements
- Filtering and Sorting
- JOIN Operations
- Aggregate Functions
- Subqueries
- Data Manipulation
- Database Design
- Advanced Queries
- Performance Optimization

### Python Track
- Python Basics
- Data Types
- Control Flow
- Functions
- Object-Oriented Programming
- Decorators
- And more...

### Django Track
- Django Introduction
- Models
- Views (Function & Class-Based)
- Templates
- Forms
- Authentication
- REST APIs
- Async Views

## Requirements

- Python 3.8+

## License

MIT

## Links

- Website: https://typequest.dev
- Documentation: https://docs.typequest.dev
- Issues: https://github.com/typequest-dev/typequest/issues
