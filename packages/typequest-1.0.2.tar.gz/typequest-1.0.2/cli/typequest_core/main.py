"""
Main application logic - the interactive CLI experience
"""

import os
import sys
import time
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.layout import Layout
from rich.live import Live
import inquirer
from typing import Dict, Any, Optional

# Import our modules
from .config import Config
from .auth import TypeQuestAuth
from .api_client import TypeQuestAPIClient
from .sync import ProgressSync
from .subscription import TypeQuestSubscriptionManager
from .session import SessionManager
from .utils.typewriter import TypewriterDisplay
from .utils.updater import check_for_updates_async
from .utils.platform import get_platform_info
from .utils.simple_input import SimpleInteractiveInput

console = Console()

class TypeQuestCLI:
    """Main TypeQuest application"""
    
    def __init__(self):
        """Initialize the CLI application"""
        
        # Core components
        self.config = Config()
        self.auth = TypeQuestAuth(self.config)
        self.api_client = TypeQuestAPIClient(self.auth)
        self.sync = ProgressSync(self.auth, self.config)
        self.subscription = TypeQuestSubscriptionManager(self.auth, self.config)
        self.session = SessionManager(self.config)
        self.typewriter = TypewriterDisplay()
        self.interactive_input = SimpleInteractiveInput()
        
        # Import course and user managers with the new package structure
        try:
            # Try to import from the new structure
            from ..course_manager import CourseManager
            from ..user_manager import UserManager
            self.course_manager = CourseManager()
            self.user_manager = UserManager()
        except ImportError:
            # Fallback to old structure for backwards compatibility
            try:
                sys.path.insert(0, str(Path(__file__).parent.parent))
                from course_manager import CourseManager
                from user_manager import UserManager
                self.course_manager = CourseManager()
                self.user_manager = UserManager()
            except ImportError:
                console.print("⚠️  [yellow]Warning: Could not load course/user managers[/yellow]")
                self.course_manager = None
                self.user_manager = None
        
        # State
        self.current_user = None
        self.current_org = None
        self.subscription_status = None
        
        # Set up typewriter with config
        self.typewriter._config = self.config
        
        # Initialize user context
        self._initialize_user_context()
    
    def _initialize_user_context(self):
        """Initialize user context on startup"""
        
        try:
            # Check if user is logged in
            if self.auth.is_logged_in():
                self.current_user = self.auth.get_current_user()
                self.current_org = self.auth.get_current_organization()
                self.subscription_status = self.subscription.get_subscription_status()
                
                # Set session context
                if self.current_user:
                    user_id = (self.current_user.get('sub') or 
                              self.current_user.get('id') or 
                              self.current_user.get('auth0_user_id'))
                    org_id = self.current_org.get('id') if self.current_org else None
                    self.session.set_user_context(user_id, org_id)
                
                # Start background sync if enabled
                if self.config.get_config_value("cloud_sync.enabled", True):
                    self.sync.start_background_sync()
        
        except Exception as e:
            console.print(f"[dim]Warning: Could not initialize user context: {e}[/dim]")
    
    def run(self):
        """Main application loop - like Claude Code"""
        
        try:
            # Startup checks
            self.perform_startup_checks()
            
            # Main interactive loop
            while True:
                self.clear_screen()
                self.display_banner()
                self.display_status()
                
                choice = self.show_main_menu()
                
                if not choice or self.should_exit(choice):
                    self.graceful_exit()
                    break
                
                self.handle_choice(choice)
                
        except KeyboardInterrupt:
            self.graceful_exit()
        except Exception as e:
            self.handle_error(e)
    
    def perform_startup_checks(self):
        """Perform startup checks and initialization"""
        
        # Check for updates (non-blocking)
        check_for_updates_async()
        
        # Check subscription status for feature access
        if self.current_user:
            self.subscription_status = self.subscription.get_subscription_status()
            
            # Check if subscription is expired
            if self.subscription_status.get("status") == "past_due":
                self._show_subscription_warning()
    
    def display_banner(self):
        """Display the application banner"""
        from .utils.updater import get_startup_update_message

        import pyfiglet

        try:
            banner = pyfiglet.figlet_format("TYPEQUEST", font="slant")
        except:
            banner = r"""
 _____                  ___                _
|_   _|   _ _ __   ___  / _ \ _   _  ___  ___| |_
  | || | | | '_ \ / _ \| | | | | | |/ _ \/ __| __|
  | || |_| | |_) |  __/| |_| | |_| |  __/\__ \ |_
  |_| \__, | .__/ \___| \__\_\\__,_|\___||___/\__|
      |___/|_|
"""

        panel_content = f"[bold cyan]{banner}[/bold cyan]\n"
        panel_content += "[dim]🚀 Interactive Coding Education Platform[/dim]\n"
        panel_content += f"[dim]v{self.config.get_version()} • Press Ctrl+C to exit[/dim]"

        # Check for update notification (like Claude Code)
        update_msg = get_startup_update_message()
        if update_msg:
            panel_content += f"\n{update_msg}"

        console.print(Panel(
            panel_content,
            border_style="cyan",
            padding=(1, 2)
        ))
    
    def display_status(self):
        """Display current user status"""
        
        if self.current_user:
            # Get user stats from API
            user_stats = {}
            if self.auth.is_logged_in():
                try:
                    user_stats = self.api_client.get_user_stats()
                except Exception as e:
                    console.print(f"[dim]Could not load user stats: {e}[/dim]")
            
            # Build status text
            username = self.current_user.get('display_name') or self.current_user.get('name') or self.current_user.get('username', 'User')
            level = user_stats.get('level', 1)
            total_xp = user_stats.get('total_xp', 0)
            streak = user_stats.get('streak_days', 0)
            
            status_text = f"👋 Welcome back, [bold]{username}[/bold]! "
            status_text += f"🎯 Level {level} • ⭐ {total_xp} XP • "
            status_text += f"🔥 {streak} day streak"
            
            # Add subscription status
            if self.subscription_status:
                tier = self.subscription_status.get("tier", "free").title()
                if tier != "Free":
                    status_text += f" • 💎 {tier} Plan"
            
            # Add organization info
            if self.current_org:
                org_name = self.current_org.get('name', 'Organization')
                status_text += f" • 🏢 {org_name}"
            
            console.print(status_text)
        else:
            console.print("🆕 [dim]Welcome to TypeQuest! Sign in to sync progress across devices[/dim]")
        
        console.print()
    
    def show_main_menu(self):
        """Display and handle main menu"""
        
        if self.current_user:
            choices = [
                "📚 My Courses",
                "🎯 Continue Learning",
                "🎮 SQL Playground", 
                "🐍 Python Playground",
                "🤖 AI Learning Assistant",
                "🎮 Interactive Input Demo",
                "🏆 Achievements",
                "📈 Leaderboard",
                "👤 Profile",
                "💳 Subscription",
                "⚙️  Settings",
                "🔓 Logout",
                "🚪 Exit"
            ]
        else:
            choices = [
                "📚 Browse Courses (Guest)",
                "🎮 SQL Playground",
                "🐍 Python Playground", 
                "🤖 AI Learning Assistant (Limited)",
                "🎮 Interactive Input Demo",
                "👤 Login",
                "📝 Sign Up",
                "💳 View Plans",
                "⚙️  Settings",
                "❓ About",
                "🚪 Exit"
            ]
        
        questions = [
            inquirer.List(
                'action',
                message="What would you like to do?",
                choices=choices,
                carousel=True
            )
        ]
        
        try:
            answer = inquirer.prompt(questions)
            return answer['action'] if answer else None
        except (EOFError, KeyboardInterrupt):
            return None
    
    def handle_choice(self, choice):
        """Handle user menu choice"""
        
        try:
            if "Browse Courses" in choice or "My Courses" in choice:
                self.handle_courses()
            elif "Continue Learning" in choice:
                self.handle_continue_learning()
            elif "SQL Playground" in choice:
                self.handle_sql_playground()
            elif "Python Playground" in choice:
                self.handle_python_playground()
            elif "AI Learning Assistant" in choice:
                self.handle_ai_assistant()
            elif "Interactive Input Demo" in choice:
                self.handle_interactive_input_demo()
            elif "Login" in choice:
                self.handle_login()
            elif "Sign Up" in choice:
                self.handle_signup()
            elif "Achievements" in choice:
                self.handle_achievements()
            elif "Profile" in choice:
                self.handle_profile()
            elif "Subscription" in choice or "View Plans" in choice:
                self.handle_subscription()
            elif "Settings" in choice:
                self.handle_settings()
            elif "Leaderboard" in choice:
                self.handle_leaderboard()
            elif "About" in choice:
                self.handle_about()
            elif "Logout" in choice:
                self.handle_logout()
                
        except Exception as e:
            console.print(f"❌ [red]Error: {e}[/red]")
            Prompt.ask("Press Enter to continue")
    
    def handle_login(self):
        """Handle login flow"""
        
        console.clear()
        success = self.auth.login_flow()
        
        if success:
            self.current_user = self.auth.get_current_user()
            self.current_org = self.auth.get_current_organization()
            self.subscription_status = self.subscription.get_subscription_status()
            
            # Set session context
            if self.current_user:
                user_id = (self.current_user.get('sub') or 
                          self.current_user.get('id') or 
                          self.current_user.get('auth0_user_id'))
                org_id = self.current_org.get('id') if self.current_org else None
                self.session.set_user_context(user_id, org_id)
                
                # Show welcome message
                username = self.current_user.get('display_name') or self.current_user.get('name') or 'User'
                console.print(f"🎉 [green]Welcome back, {username}![/green]")
            
            # Start sync
            if self.config.get_config_value("cloud_sync.enabled", True):
                self.sync.start_background_sync()
            
            console.print("✅ [green]Successfully logged in![/green]")
        else:
            console.print("❌ [red]Login failed. Please try again.[/red]")
        
        time.sleep(2)
    
    def handle_signup(self):
        """Handle signup flow"""
        
        console.clear()
        console.print("📝 [bold cyan]Create Your TypeQuest Account[/bold cyan]\n")
        
        console.print("Creating a TypeQuest account will let you:")
        console.print("• 📚 Track your learning progress")
        console.print("• 🏆 Earn achievements and badges")
        console.print("• 💾 Sync progress across devices")
        console.print("• 🎯 Get personalized recommendations\n")
        
        # Use Auth0 signup flow
        console.print("Click 'Sign Up' when the browser opens to create your account.")
        
        if Confirm.ask("Open signup page in browser?", default=True):
            import webbrowser
            console.print("🌐 [yellow]Opening Auth0 signup page...[/yellow]")
            
            # Use Auth0 authorize endpoint with signup mode
            signup_url = (
                "https://typequest-prod.us.auth0.com/authorize"
                "?response_type=code"
                "&client_id=zxgeSCzPiIYcnAIx9la00AOXnmVxGBMs"
                "&redirect_uri=http://localhost:8000/"
                "&scope=openid%20profile%20email"
                "&screen_hint=signup"
                "&audience=api.typquest.dev"
                "&state=signup_complete"
            )
            
            webbrowser.open(signup_url)
        
        console.print("\n💡 [dim]Once you've created an account, return here and choose 'Login' to sign in.[/dim]")
        Prompt.ask("Press Enter to continue")
    
    def handle_courses(self):
        """Handle course browsing/selection"""
        
        if not self.course_manager:
            console.print("❌ [red]Course manager not available[/red]")
            Prompt.ask("Press Enter to continue")
            return
        
        console.clear()
        console.print("📚 [bold cyan]Available Courses[/bold cyan]\n")
        
        # Get available courses
        tracks = self.course_manager.get_tracks()
        
        course_choices = []
        for track in tracks:
            track_name = track.get("name", "Unknown Track")
            track_courses = track.get("courses", [])
            
            console.print(f"🎯 [bold]{track_name}[/bold]")
            
            for course_slug in track_courses:
                course = self.course_manager.get_course(course_slug)
                if course:
                    course_name = course.get("name", course_slug)
                    difficulty = course.get("difficulty", "unknown")
                    estimated_hours = course.get("estimated_hours", 0)
                    
                    # Check if user has access
                    has_access = self._user_has_course_access(course_slug)
                    access_icon = "✅" if has_access else "🔒"
                    
                    console.print(f"  {access_icon} {course_name}")
                    console.print(f"     [dim]Difficulty: {difficulty} • ~{estimated_hours} hours[/dim]")
                    
                    if has_access:
                        course_choices.append(f"{course_name} ({course_slug})")
            
            console.print()
        
        if not course_choices:
            console.print("🔒 [yellow]No courses available with your current plan.[/yellow]")
            console.print("Upgrade to access all courses!")
            if Confirm.ask("View upgrade options?", default=True):
                self.handle_subscription()
            return
        
        # Course selection
        course_choices.append("🔙 Back")
        
        questions = [
            inquirer.List(
                'course',
                message="Choose a course to start",
                choices=course_choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if answer and "Back" not in answer['course']:
            # Extract course slug from choice
            course_slug = answer['course'].split('(')[-1].strip(')')
            self._start_course(course_slug)
    
    def handle_continue_learning(self):
        """Handle continue learning flow"""
        
        if not self.current_user or not self.course_manager or not self.user_manager:
            console.print("❌ [red]Please login to continue learning[/red]")
            Prompt.ask("Press Enter to continue")
            return
        
        console.clear()
        console.print("🎯 [bold cyan]Continue Learning[/bold cyan]\n")
        
        # Get user's progress across all courses
        user_id = self.current_user.get('id')
        if not user_id:
            console.print("❌ [red]User ID not found[/red]")
            Prompt.ask("Press Enter to continue")
            return
        
        # Find courses with progress
        tracks = self.course_manager.get_tracks()
        continue_options = []
        
        for track in tracks:
            for course_slug in track.get("courses", []):
                next_lesson = self.course_manager.get_next_lesson(user_id, course_slug)
                if next_lesson:
                    course = self.course_manager.get_course(course_slug)
                    course_name = course.get("name", course_slug)
                    lesson_name = next_lesson.get("title", "Unknown Lesson")
                    
                    continue_options.append({
                        "display": f"{course_name} - {lesson_name}",
                        "course_slug": course_slug,
                        "lesson_slug": next_lesson.get("slug")
                    })
        
        if not continue_options:
            console.print("🎉 [green]No lessons in progress![/green]")
            console.print("Start a new course from the main menu.")
            Prompt.ask("Press Enter to continue")
            return
        
        # Show options
        choices = [option["display"] for option in continue_options]
        choices.append("🔙 Back")
        
        questions = [
            inquirer.List(
                'choice',
                message="Continue where you left off",
                choices=choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if answer and "Back" not in answer['choice']:
            # Find the selected option
            for option in continue_options:
                if option["display"] == answer['choice']:
                    self._start_lesson(option["course_slug"], option["lesson_slug"])
                    break
    
    def handle_subscription(self):
        """Handle subscription management"""
        
        console.clear()
        
        if self.current_user:
            # Show current subscription status
            self.subscription.show_subscription_status()
            
            choices = [
                "💳 Upgrade Plan",
                "📊 View Usage",
                "❌ Cancel Subscription", 
                "🔙 Back"
            ]
            
            questions = [
                inquirer.List(
                    'action',
                    message="Subscription Management",
                    choices=choices,
                    carousel=True
                )
            ]
            
            answer = inquirer.prompt(questions)
            if answer:
                action = answer['action']
                
                if "Upgrade Plan" in action:
                    self.subscription.upgrade_subscription_flow()
                elif "View Usage" in action:
                    self.subscription.show_subscription_status()
                elif "Cancel Subscription" in action:
                    self.subscription.cancel_subscription()
                elif "Back" in action:
                    return
        else:
            # Show pricing for non-logged in users
            self.subscription.show_pricing_plans()
            
            if Confirm.ask("Sign up to get started?", default=True):
                self.handle_signup()
        
        if not "Back" in str(answer):
            Prompt.ask("Press Enter to continue")
    
    def handle_settings(self):
        """Handle settings management"""
        
        console.clear()
        console.print("⚙️  [bold cyan]Settings[/bold cyan]\n")
        
        settings_choices = [
            "⌨️  Typewriter Settings",
            "☁️  Cloud Sync Settings", 
            "🔔 Notification Settings",
            "🎨 Theme Settings",
            "🌐 Language Settings",
            "📊 Export Data",
            "🗑️  Clear Data",
            "🔙 Back"
        ]
        
        questions = [
            inquirer.List(
                'setting',
                message="Choose setting to configure",
                choices=settings_choices,
                carousel=True
            )
        ]
        
        answer = inquirer.prompt(questions)
        if answer:
            setting = answer['setting']
            
            if "Typewriter" in setting:
                self._handle_typewriter_settings()
            elif "Cloud Sync" in setting:
                self._handle_sync_settings()
            elif "Export Data" in setting:
                self._handle_export_data()
            elif "Clear Data" in setting:
                self._handle_clear_data()
            elif "Back" in setting:
                return
            else:
                console.print("🚧 [yellow]Setting not yet implemented[/yellow]")
                Prompt.ask("Press Enter to continue")
    
    def handle_logout(self):
        """Handle logout"""
        
        # End learning session if active
        session_stats = self.session.end_learning_session()
        if session_stats.get("duration", 0) > 0:
            self._show_session_summary(session_stats)
        
        # Stop sync
        if self.sync:
            self.sync.stop_background_sync()
        
        # Logout
        self.auth.logout()
        self.current_user = None
        self.current_org = None
        self.subscription_status = None
        
        console.print("👋 [green]Logged out successfully![/green]")
        time.sleep(1)
    
    def handle_about(self):
        """Show about information"""
        
        console.clear()
        
        about_content = f"""
[bold cyan]TypeQuest v{self.config.get_version()}[/bold cyan]

🚀 Interactive coding education platform
📚 Learn SQL, Python, Django, and more
🤖 AI-powered learning assistant
☁️  Cloud progress synchronization
🏆 Gamified learning experience

[bold]Links:[/bold]
🌐 Website: https://typequest.dev
📚 Documentation: https://docs.typequest.dev
💬 Discord: https://discord.gg/typequest
🐛 Issues: https://github.com/typequest/cli/issues

[dim]© 2024 TypeQuest Development Team[/dim]
"""
        
        console.print(Panel(about_content, border_style="cyan"))
        Prompt.ask("Press Enter to continue")
    
    def _user_has_course_access(self, course_slug: str) -> bool:
        """Check if user has access to a course"""
        
        if not self.subscription_status:
            return course_slug == "sql_basics"  # Free tier access
        
        features = self.subscription_status.get("features", {})
        courses_available = features.get("courses_available", [])
        
        return courses_available == "all" or course_slug in courses_available
    
    def _start_course(self, course_slug: str):
        """Start a course"""
        
        course = self.course_manager.get_course(course_slug)
        if not course:
            console.print("❌ [red]Course not found[/red]")
            return
        
        lessons = course.get("lessons", [])
        if not lessons:
            console.print("❌ [red]No lessons available in this course[/red]")
            return
        
        first_lesson = lessons[0]
        self._start_lesson(course_slug, first_lesson.get("slug"))
    
    def _start_lesson(self, course_slug: str, lesson_slug: str):
        """Start a lesson"""
        
        lesson = self.course_manager.get_lesson(course_slug, lesson_slug)
        if not lesson:
            console.print("❌ [red]Lesson not found[/red]")
            return
        
        # Start learning session
        self.session.start_learning_session(course_slug, lesson_slug)
        
        console.clear()
        lesson_title = lesson.get("title", "Unknown Lesson")
        console.print(f"📖 [bold cyan]{lesson_title}[/bold cyan]\n")
        
        # Display lesson content with typewriter effect
        lesson_content = lesson.get("content", "")
        if lesson_content:
            self.typewriter.type_lesson_content(lesson_content)
        
        # Handle lesson exercises if any
        exercises = lesson.get("exercises", [])
        if exercises:
            self._handle_lesson_exercises(exercises, course_slug, lesson_slug)
        
        # Mark lesson as complete
        if self.current_user and self.course_manager:
            user_id = self.current_user.get('id')
            if user_id:
                self.course_manager.mark_lesson_complete(user_id, course_slug, lesson_slug)
                self.session.record_lesson_completion(lesson_slug, 10)  # 10 XP per lesson
        
        console.print("\n✅ [green]Lesson completed![/green]")
        
        # Ask about next lesson
        if Confirm.ask("Continue to next lesson?", default=True):
            # Get next lesson
            if self.current_user and self.course_manager:
                user_id = self.current_user.get('id')
                next_lesson = self.course_manager.get_next_lesson(user_id, course_slug)
                if next_lesson:
                    self._start_lesson(course_slug, next_lesson.get("slug"))
                else:
                    console.print("🎉 [green]Course completed! Congratulations![/green]")
                    Prompt.ask("Press Enter to continue")
    
    def _handle_lesson_exercises(self, exercises: list, course_slug: str, lesson_slug: str):
        """Handle lesson exercises"""
        
        console.print("\n💻 [bold]Practice Exercises[/bold]\n")
        
        for exercise in exercises:
            exercise_title = exercise.get("title", "Exercise")
            console.print(f"🎯 [cyan]{exercise_title}[/cyan]")
            
            # Show exercise prompt
            prompt = exercise.get("prompt", "")
            if prompt:
                console.print(f"📝 {prompt}")
            
            # Get user solution
            console.print("\nEnter your solution (press Enter twice when done):")
            solution_lines = []
            while True:
                line = input()
                if line == "" and solution_lines and solution_lines[-1] == "":
                    break
                solution_lines.append(line)
            
            user_solution = "\n".join(solution_lines).strip()
            
            # Basic exercise validation (simplified)
            expected_keywords = exercise.get("expected_keywords", [])
            is_correct = all(keyword.lower() in user_solution.lower() for keyword in expected_keywords)
            
            if is_correct:
                console.print("✅ [green]Correct! Well done![/green]")
                # Record exercise completion
                if self.current_user:
                    exercise_id = f"{course_slug}:{lesson_slug}:{exercise.get('id', 'exercise')}"
                    self.session.record_exercise_completion(exercise_id, 5)  # 5 XP per exercise
            else:
                console.print("❌ [red]Not quite right. Try again or continue anyway.[/red]")
            
            console.print()
    
    def should_exit(self, choice):
        """Check if user wants to exit"""
        return choice and "Exit" in choice
    
    def graceful_exit(self):
        """Handle graceful application exit"""
        
        # End learning session if active
        session_stats = self.session.end_learning_session()
        if session_stats.get("duration", 0) > 30:  # Only show if session > 30 seconds
            self._show_session_summary(session_stats)
        
        # Stop background sync
        if self.sync:
            self.sync.stop_background_sync()
        
        console.print("\n👋 [green]Thanks for using TypeQuest! Happy coding![/green] 🚀")
    
    def clear_screen(self):
        """Clear the terminal screen"""
        console.clear()
    
    def handle_error(self, error):
        """Handle unexpected errors"""
        console.print(f"\n❌ [red]Unexpected error: {error}[/red]")
        console.print("Please report this issue at: https://github.com/typequest/cli/issues")
        
        if Confirm.ask("Would you like to restart the application?"):
            self.run()
        else:
            sys.exit(1)
    
    def _show_subscription_warning(self):
        """Show subscription warning"""
        
        warning_content = """
⚠️  [bold yellow]Subscription Past Due[/bold yellow]

Your subscription payment is past due. Please update your payment method
to continue accessing premium features.

Visit: https://typequest.dev/billing
"""
        
        console.print(Panel(warning_content, border_style="yellow"))
        Prompt.ask("Press Enter to continue")
    
    def _show_session_summary(self, session_stats: Dict[str, Any]):
        """Show learning session summary"""
        
        duration_minutes = int(session_stats.get("duration", 0) / 60)
        lessons_completed = session_stats.get("lessons_completed", 0)
        exercises_completed = session_stats.get("exercises_completed", 0)
        xp_earned = session_stats.get("xp_earned", 0)
        
        summary_content = f"""
[bold cyan]Learning Session Complete![/bold cyan]

⏰ Time spent: {duration_minutes} minutes
📖 Lessons completed: {lessons_completed}
💻 Exercises completed: {exercises_completed}
⭐ XP earned: {xp_earned}

Keep up the great work! 🚀
"""
        
        console.print(Panel(summary_content, border_style="green"))
        Prompt.ask("Press Enter to continue")
    
    # Placeholder methods for features to be implemented
    def handle_sql_playground(self):
        console.print("🚧 [yellow]SQL Playground coming soon![/yellow]")
        Prompt.ask("Press Enter to continue")
    
    def handle_python_playground(self):
        console.print("🚧 [yellow]Python Playground coming soon![/yellow]")
        Prompt.ask("Press Enter to continue")
    
    def handle_ai_assistant(self):
        console.print("🚧 [yellow]AI Assistant coming soon![/yellow]")
        Prompt.ask("Press Enter to continue")
    
    def handle_achievements(self):
        """Handle achievements display"""
        
        if not self.auth.is_logged_in():
            console.print("❌ [red]Please login to view achievements[/red]")
            Prompt.ask("Press Enter to continue")
            return
        
        self._handle_view_achievements()
        Prompt.ask("Press Enter to continue")
    
    def handle_profile(self):
        """Handle user profile display and management"""
        
        if not self.auth.is_logged_in():
            console.print("❌ [red]Please login to view your profile[/red]")
            Prompt.ask("Press Enter to continue")
            return
        
        console.clear()
        console.print("👤 [bold cyan]User Profile[/bold cyan]\n")
        
        try:
            # Get user profile from API
            user_data = self.api_client.get_user_profile()
            user_stats = self.api_client.get_user_stats()
            preferences = self.api_client.get_user_preferences()
            
            if user_data:
                # Display profile information
                table = Table(show_header=False, box=None)
                table.add_column("Field", style="cyan")
                table.add_column("Value", style="white")
                
                table.add_row("Email", user_data.get('email', 'N/A'))
                table.add_row("Display Name", user_data.get('display_name', 'N/A'))
                table.add_row("Account Created", user_data.get('account_created', 'N/A'))
                table.add_row("Last Login", user_data.get('last_login', 'N/A'))
                
                if user_stats:
                    table.add_row("", "")  # Separator
                    table.add_row("Level", str(user_stats.get('level', 1)))
                    table.add_row("Total XP", str(user_stats.get('total_xp', 0)))
                    table.add_row("Streak Days", str(user_stats.get('streak_days', 0)))
                    table.add_row("Lessons Completed", str(user_stats.get('lessons_completed', 0)))
                    table.add_row("Exercises Completed", str(user_stats.get('exercises_completed', 0)))
                
                console.print(table)
                console.print()
                
                # Profile actions
                choices = [
                    "📝 Edit Preferences",
                    "🏆 View Achievements",
                    "📊 View Detailed Stats",
                    "🔙 Back"
                ]
                
                questions = [
                    inquirer.List(
                        'action',
                        message="Profile Actions",
                        choices=choices,
                        carousel=True
                    )
                ]
                
                answer = inquirer.prompt(questions)
                if answer:
                    action = answer['action']
                    
                    if "Edit Preferences" in action:
                        self._handle_edit_preferences(preferences)
                    elif "View Achievements" in action:
                        self._handle_view_achievements()
                    elif "View Detailed Stats" in action:
                        self._handle_detailed_stats(user_stats)
            else:
                console.print("❌ [red]Could not load profile data[/red]")
                
        except Exception as e:
            console.print(f"❌ [red]Error loading profile: {e}[/red]")
        
        if not answer or "Back" not in answer.get('action', ''):
            Prompt.ask("Press Enter to continue")
    
    def _handle_edit_preferences(self, current_preferences: Dict[str, Any]):
        """Handle editing user preferences"""
        
        console.clear()
        console.print("📝 [bold cyan]Edit Preferences[/bold cyan]\n")
        
        # Show current preferences
        console.print("Current preferences:")
        for key, value in current_preferences.items():
            console.print(f"  {key}: {value}")
        console.print()
        
        # Simple preference editing
        new_preferences = {}
        
        # Display name
        current_name = current_preferences.get('display_name', '')
        console.print("[bold cyan]Update Display Name[/bold cyan]")
        new_name = self.interactive_input.show_input_box(
            prompt=f"Enter your display name (current: {current_name}):",
            placeholder="Your preferred name for the CLI..."
        )
        if new_name and new_name != current_name:
            new_preferences['display_name'] = new_name
        
        # CLI theme
        current_theme = current_preferences.get('cli_theme', 'default')
        new_theme = Prompt.ask(
            "CLI theme",
            choices=['default', 'dark', 'light', 'colorful'],
            default=current_theme
        )
        if new_theme != current_theme:
            new_preferences['cli_theme'] = new_theme
        
        # Learning level
        current_level = current_preferences.get('learning_level', 'beginner')
        new_level = Prompt.ask(
            "Learning level",
            choices=['beginner', 'intermediate', 'advanced'],
            default=current_level
        )
        if new_level != current_level:
            new_preferences['learning_level'] = new_level
        
        # Update preferences if any changes
        if new_preferences:
            if self.api_client.update_user_preferences(new_preferences):
                console.print("✅ [green]Preferences updated successfully![/green]")
            else:
                console.print("❌ [red]Failed to update preferences[/red]")
        else:
            console.print("ℹ️  No changes made")
    
    def _handle_view_achievements(self):
        """Handle viewing user achievements"""
        
        console.clear()
        console.print("🏆 [bold cyan]Your Achievements[/bold cyan]\n")
        
        try:
            achievements = self.api_client.get_achievements()
            
            if achievements:
                for achievement in achievements:
                    name = achievement.get('name', 'Unknown Achievement')
                    description = achievement.get('description', '')
                    earned_at = achievement.get('earned_at', '')
                    
                    console.print(f"🏆 [bold]{name}[/bold]")
                    if description:
                        console.print(f"   {description}")
                    if earned_at:
                        console.print(f"   [dim]Earned: {earned_at}[/dim]")
                    console.print()
            else:
                console.print("🎯 [yellow]No achievements yet. Keep learning to earn some![/yellow]")
                
        except Exception as e:
            console.print(f"❌ [red]Error loading achievements: {e}[/red]")
    
    def _handle_detailed_stats(self, user_stats: Dict[str, Any]):
        """Handle viewing detailed user statistics"""
        
        console.clear()
        console.print("📊 [bold cyan]Detailed Statistics[/bold cyan]\n")
        
        # Create a detailed stats table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")
        table.add_column("Details", style="dim")
        
        # Add various stats
        table.add_row("Level", str(user_stats.get('level', 1)), "Current learning level")
        table.add_row("Total XP", str(user_stats.get('total_xp', 0)), "Experience points earned")
        table.add_row("Streak Days", str(user_stats.get('streak_days', 0)), "Consecutive learning days")
        table.add_row("Lessons Completed", str(user_stats.get('lessons_completed', 0)), "Total lessons finished")
        table.add_row("Exercises Completed", str(user_stats.get('exercises_completed', 0)), "Programming exercises solved")
        table.add_row("Time Spent", f"{user_stats.get('total_minutes', 0)} min", "Total learning time")
        table.add_row("Average Session", f"{user_stats.get('avg_session_minutes', 0)} min", "Average learning session")
        
        console.print(table)
    
    def handle_leaderboard(self):
        console.print("🚧 [yellow]Leaderboard coming soon![/yellow]")
        Prompt.ask("Press Enter to continue")
    
    def _handle_typewriter_settings(self):
        """Handle typewriter settings"""
        
        from .utils.typewriter import show_typewriter_settings, set_typewriter_speed
        
        console.clear()
        show_typewriter_settings()
        
        speed_choice = Prompt.ask(
            "Set speed",
            choices=["slow", "normal", "fast", "instant", "back"],
            default="normal"
        )
        
        if speed_choice != "back":
            set_typewriter_speed(speed_choice)
    
    def _handle_sync_settings(self):
        """Handle cloud sync settings"""
        
        console.clear()
        console.print("☁️  [bold cyan]Cloud Sync Settings[/bold cyan]\n")
        
        sync_enabled = self.config.get_config_value("cloud_sync.enabled", True)
        auto_sync = self.config.get_config_value("cloud_sync.auto_sync", True)
        
        console.print(f"Sync enabled: {'✅' if sync_enabled else '❌'}")
        console.print(f"Auto sync: {'✅' if auto_sync else '❌'}")
        
        if sync_enabled and self.auth.is_logged_in():
            sync_status = self.sync.get_sync_status()
            last_sync = sync_status.get("last_sync")
            if last_sync:
                import datetime
                last_sync_str = datetime.datetime.fromtimestamp(last_sync).strftime("%Y-%m-%d %H:%M:%S")
                console.print(f"Last sync: {last_sync_str}")
        
        choices = ["Toggle sync", "Force sync now", "Back"]
        
        choice = Prompt.ask("Choose action", choices=choices, default="Back")
        
        if choice == "Toggle sync":
            new_value = not sync_enabled
            self.config.update_config("cloud_sync.enabled", new_value)
            console.print(f"Cloud sync {'enabled' if new_value else 'disabled'}")
        elif choice == "Force sync now" and self.auth.is_logged_in():
            self.sync.force_sync()
        
        if choice != "Back":
            Prompt.ask("Press Enter to continue")
    
    def _handle_export_data(self):
        """Handle data export"""
        
        if not self.current_user:
            console.print("❌ Please login first")
            Prompt.ask("Press Enter to continue") 
            return
        
        output_file = f"typequest_data_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        if self.session.export_session_data(output_file):
            console.print(f"✅ Data exported to: {output_file}")
        else:
            console.print("❌ Export failed")
        
        Prompt.ask("Press Enter to continue")
    
    def _handle_clear_data(self):
        """Handle data clearing"""
        
        console.print("⚠️  [bold red]Warning: This will delete ALL local data[/bold red]")
        console.print("This includes:")
        console.print("  • Session history")
        console.print("  • Local progress (if not synced)")
        console.print("  • Settings and preferences")
        console.print("  • Authentication tokens")
        
        if not Confirm.ask("Are you absolutely sure?", default=False):
            return
        
        if not Confirm.ask("This action cannot be undone. Continue?", default=False):
            return
        
        # Clear data
        try:
            # Clear session data
            self.session.cleanup_old_sessions(0)  # Delete all sessions
            
            # Clear auth tokens
            self.auth._clear_tokens()
            
            # Reset config to defaults
            self.config.init_config()
            
            console.print("✅ [green]Local data cleared successfully[/green]")
            console.print("You'll need to login again on next startup.")
            
        except Exception as e:
            console.print(f"❌ [red]Error clearing data: {e}[/red]")
        
        Prompt.ask("Press Enter to continue")
    
    def handle_interactive_input_demo(self):
        """Demonstrate the Claude Code-style interactive input system"""
        
        console.clear()
        console.print("🎮 [bold cyan]Interactive Input System Demo[/bold cyan]")
        console.print()
        
        console.print("✨ [bold]Welcome to TypeQuest's Claude Code-style input![/bold]")
        console.print()
        console.print("[dim]This demo showcases our advanced input system with:[/dim]")
        console.print("• [green]Accept/Edit modes[/green] - Switch between ready-to-submit and editing")
        console.print("• [blue]Keyboard shortcuts[/blue] - Use Shift+Tab to cycle modes")  
        console.print("• [yellow]Settings controls[/yellow] - Toggle preferences on-the-fly")
        console.print("• [magenta]Rich interface[/magenta] - Beautiful CLI with real-time updates")
        console.print()
        
        try:
            # Demo 1: Basic input
            console.print("[bold]Demo 1: Basic Question Input[/bold]")
            console.print("Try switching between Accept and Edit modes!")
            
            answer1 = self.interactive_input.show_input_box(
                prompt="What programming topic interests you most?",
                placeholder="e.g., Python, Django, JavaScript, AI, etc..."
            )
            
            if answer1:
                console.print(f"\n✅ [green]Great choice![/green] [bold]{answer1}[/bold] is an excellent topic to learn.")
                console.print()
                
                # Demo 2: Longer response
                console.print("[bold]Demo 2: Detailed Response[/bold]")
                console.print("Try the settings menu (press 'S' in any mode)")
                
                answer2 = self.interactive_input.show_input_box(
                    prompt=f"Tell us more about your interest in {answer1}:",
                    placeholder="Share your experience level, goals, or specific areas you'd like to focus on...",
                    multiline=True
                )
                
                if answer2:
                    console.print(f"\n🎯 [cyan]Your learning goals for {answer1}:[/cyan]")
                    console.print(f"[dim]{answer2}[/dim]")
                    console.print()
                    
                    # Demo 3: Quick feedback
                    console.print("[bold]Demo 3: Quick Feedback[/bold]")
                    feedback = self.interactive_input.show_input_box(
                        prompt="How was the interactive input experience? (1-5 stars)",
                        placeholder="⭐⭐⭐⭐⭐ Amazing! or describe your experience..."
                    )
                    
                    if feedback:
                        console.print(f"\n🙏 [yellow]Thank you for your feedback:[/yellow] {feedback}")
                        console.print()
        
            # Show feature summary
            console.print("🎉 [bold green]Interactive Input Demo Complete![/bold green]")
            console.print()
            console.print("🔥 [bold]Key Features You Experienced:[/bold]")
            console.print("• [green]Accept Mode[/green] - Press Enter to submit when ready")
            console.print("• [blue]Edit Mode[/blue] - Full text editing capabilities")
            console.print("• [yellow]Mode Switching[/yellow] - Use E/A or Shift+Tab to toggle")
            console.print("• [magenta]Settings Menu[/magenta] - Press 'S' to configure preferences")
            console.print("• [cyan]Visual Feedback[/cyan] - Color-coded modes and clear instructions")
            console.print()
            console.print("💡 [dim]This same system is used throughout TypeQuest for a consistent, powerful input experience.[/dim]")
            
        except KeyboardInterrupt:
            console.print("\n[yellow]Demo cancelled by user[/yellow]")
        
        console.print()
        Prompt.ask("Press Enter to return to main menu")