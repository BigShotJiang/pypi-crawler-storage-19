"""
Stripe-based subscription management for TypeQuest
Supports individual and organization billing
"""

import stripe
import requests
import json
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Union
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table
from decimal import Decimal

console = Console()

class StripeConfig:
    """Stripe configuration settings"""
    
    def __init__(self):
        import os
        # Load from environment variables
        self.publishable_key = os.getenv("STRIPE_PUBLISHABLE_KEY", "pk_test_your_stripe_publishable_key")
        self.secret_key = os.getenv("STRIPE_SECRET_KEY", "sk_test_your_stripe_secret_key")
        self.webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET", "whsec_your_webhook_secret")
        
        # Product and price configurations
        self.products = {
            "basic": {
                "monthly": {
                    "price_id": "price_basic_monthly",
                    "amount": 900,  # $9.00 in cents
                    "currency": "usd",
                    "interval": "month"
                },
                "annual": {
                    "price_id": "price_basic_annual", 
                    "amount": 9000,  # $90.00 in cents (2 months free)
                    "currency": "usd",
                    "interval": "year"
                }
            }
        }

class TypeQuestSubscriptionManager:
    """
    Subscription management for individual users and organizations
    """
    
    def __init__(self, auth=None, config=None):
        self.auth = auth
        self.config = config
        self.stripe_config = StripeConfig()
        
        # Initialize Stripe
        stripe.api_key = self.stripe_config.secret_key
        
        # Configure API base URL - support both development and production
        self.api_base = self._get_api_base_url()
        self.api_prefix = "/auth"  # Django auth app prefix
    
    def get_subscription_status(self) -> Dict[str, Any]:
        """Get current subscription status using Django service"""
        
        if not self.auth or not self.auth.is_logged_in():
            return {
                "tier": "free",
                "status": "inactive",
                "expires_at": None,
                "is_trial": False,
                "features": self._get_tier_features("free")
            }
        
        try:
            # Use Django service CLI subscription endpoint
            response = requests.get(
                f"{self.api_base}{self.api_prefix}/cli/subscription/",
                headers={'Authorization': f'Bearer {self.auth.get_auth_token()}'},
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Transform Django service response to CLI format
                subscription = data.get('subscription')
                if subscription:
                    plan_name = subscription['plan']['name']
                    tier_map = {
                        'individual': 'individual',
                        'team': 'team', 
                        'enterprise': 'enterprise'
                    }
                    
                    return {
                        "tier": tier_map.get(plan_name, "individual"),
                        "status": subscription['status'],
                        "expires_at": subscription.get('current_period_end'),
                        "is_trial": subscription.get('is_trial', False),
                        "stripe_subscription_id": subscription.get('id'),
                        "features": self._django_limits_to_features(data.get('limits', {})),
                        "usage": self._django_usage_to_cli_format(data.get('usage', {}))
                    }
                else:
                    # Free tier user
                    return {
                        "tier": "free",
                        "status": "active",
                        "expires_at": None,
                        "is_trial": False,
                        "stripe_subscription_id": None,
                        "features": self._django_limits_to_features(data.get('limits', {})),
                        "usage": self._django_usage_to_cli_format(data.get('usage', {}))
                    }
            else:
                console.print(f"[yellow]Warning: Could not fetch subscription status ({response.status_code})[/yellow]")
                return self._get_default_subscription_status()
                
        except requests.RequestException as e:
            console.print(f"[yellow]Warning: Subscription service unavailable[/yellow]")
            console.print(f"[dim]Error: {e}[/dim]")
            return self._get_default_subscription_status()
    
    def _get_organization_subscription(self, org: Dict[str, Any]) -> Dict[str, Any]:
        """Get organization subscription status"""
        
        try:
            response = requests.get(
                f"{self.api_base}/v1/organizations/{org['id']}/subscription",
                headers={'Authorization': f'Bearer {self.auth.get_auth_token()}'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return self._get_default_subscription_status()
                
        except requests.RequestException:
            return self._get_default_subscription_status()
    
    def _get_individual_subscription(self, user: Dict[str, Any]) -> Dict[str, Any]:
        """Get individual user subscription status"""
        
        try:
            response = requests.get(
                f"{self.api_base}/v1/users/{user['sub']}/subscription",
                headers={'Authorization': f'Bearer {self.auth.get_auth_token()}'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return self._get_default_subscription_status()
                
        except requests.RequestException:
            return self._get_default_subscription_status()
    
    def _get_default_subscription_status(self) -> Dict[str, Any]:
        """Get default subscription status for free tier"""
        
        return {
            "tier": "free",
            "status": "active",
            "expires_at": None,
            "is_trial": False,
            "stripe_subscription_id": None,
            "features": self._get_tier_features("free"),
            "usage": {
                "lessons_completed_this_month": 0,
                "ai_queries_this_month": 0,
                "max_lessons_per_month": 5,
                "max_ai_queries_per_month": 10
            }
        }
    
    def _get_tier_features(self, tier: str) -> Dict[str, Any]:
        """Get features available for a subscription tier"""
        
        features = {
            "free": {
                "max_lessons_per_month": 5,
                "courses_available": ["sql_basics"],
                "progress_sync": True,
                "leaderboard": False,
                "custom_datasets": False,
                "priority_support": False,
                "offline_mode": False
            },
            "basic": {
                "max_lessons_per_month": -1,  # Unlimited
                "courses_available": "all",
                "progress_sync": True,
                "leaderboard": True,
                "custom_datasets": True,
                "priority_support": True,
                "offline_mode": True
            }
        }
        
        return features.get(tier, features["free"])
    
    def _get_api_base_url(self) -> str:
        """Determine the correct API base URL for Django service"""
        
        # Check environment variable first
        import os
        env_url = os.getenv('TYPEQUEST_API_URL')
        if env_url:
            return env_url.rstrip('/')
        
        # Check config if available
        if self.config:
            api_url = self.config.get_config_value('api_url') or self.config.get_config_value('django_service_url')
            if api_url:
                return api_url.rstrip('/')
        
        # Check if Django service is running locally
        try:
            import requests
            local_url = "http://127.0.0.1:8000"
            # Test if Django is running by hitting any endpoint
            response = requests.get(f"{local_url}/auth/api/plans/", timeout=2)
            if response.status_code in [200, 401, 403]:  # 401/403 means Django is running but not authenticated
                console.print("[dim]🔧 Using local Django service[/dim]")
                return local_url
        except Exception as e:
            console.print(f"[dim]Local service check failed: {e}[/dim]")
        
        # Fallback to production URL
        console.print("[dim]🌐 Using production service[/dim]")
        return "https://typequest-service.onrender.com"
    
    def _django_limits_to_features(self, limits: Dict[str, Any]) -> Dict[str, Any]:
        """Convert Django service limits to CLI feature format"""
        return {
            "max_lessons_per_month": limits.get('max_learning_sessions', 5),
            "max_ai_queries_per_month": limits.get('max_ai_hints', 10),
            "courses_available": "all" if limits.get('max_learning_sessions', 5) > 5 else ["sql_basics"],
            "ai_assistant": limits.get('max_ai_hints', 0) > 10,
            "progress_sync": True,
            "leaderboard": limits.get('max_learning_sessions', 5) > 5,
            "custom_datasets": limits.get('max_learning_sessions', 5) > 5,
            "team_features": limits.get('max_learning_sessions', -1) == -1 and limits.get('priority_support', False),
            "priority_support": limits.get('priority_support', False),
            "offline_mode": limits.get('offline_mode', False)
        }
    
    def _django_usage_to_cli_format(self, usage: Dict[str, Any]) -> Dict[str, Any]:
        """Convert Django service usage to CLI format"""
        return {
            "lessons_completed_this_month": usage.get('learning_sessions', 0),
            "ai_queries_this_month": usage.get('ai_hints_used', 0),
            "max_lessons_per_month": usage.get('max_learning_sessions', 5),
            "max_ai_queries_per_month": usage.get('max_ai_hints', 10)
        }
    
    def show_pricing_plans(self):
        """Display pricing plans from Django service"""
        
        console.print("\n💰 [bold cyan]TypeQuest Pricing Plans[/bold cyan]\n")
        
        try:
            # Get plans from Django service
            response = requests.get(
                f"{self.api_base}{self.api_prefix}/cli/subscription/upgrade/",
                headers={'Authorization': f'Bearer {self.auth.get_auth_token()}' if self.auth and self.auth.is_logged_in() else {}},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                plans = data.get('plans', [])
                
                if plans:
                    self._display_plans_from_service(plans, data.get('current_usage'))
                    return
                    
        except requests.RequestException as e:
            console.print(f"[yellow]Warning: Could not fetch latest pricing[/yellow]")
            console.print(f"[dim]Showing default pricing... Error: {e}[/dim]")
        
        # Fallback to static pricing display
        
        # Create pricing table
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Feature", style="dim", width=30)
        table.add_column("Free", justify="center", width=20)
        table.add_column("Basic", justify="center", width=20, style="cyan")
        
        # Pricing row
        table.add_row(
            "[bold]Monthly Price[/bold]",
            "[green]$0[/green]",
            "[cyan]$9/month[/cyan]"
        )
        
        table.add_row(
            "[bold]Annual Price[/bold]", 
            "[green]$0[/green]",
            "[cyan]$90/year[/cyan]\n[dim](2 months free)[/dim]"
        )
        
        table.add_row("", "", "")  # Separator
        
        # Features - simplified to Free vs Basic only
        features_comparison = [
            ("Lessons per month", "5", "Unlimited"),
            ("All courses", "❌", "✅"), 
            ("Progress sync", "✅", "✅"),
            ("Leaderboards", "❌", "✅"),
            ("Custom datasets", "❌", "✅"),
            ("Offline mode", "❌", "✅"),
            ("Priority support", "❌", "✅"),
        ]
        
        for feature, free, basic in features_comparison:
            table.add_row(feature, free, basic)
        
        console.print(table)
        console.print()
    
    def _display_plans_from_service(self, plans: list, current_usage: dict = None):
        """Display plans retrieved from Django service"""
        
        # Create pricing table
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Feature", style="dim", width=25)
        table.add_column("Free", justify="center", width=15)
        
        # Add columns for each plan
        for plan in plans:
            table.add_column(plan['display_name'], justify="center", width=15, style="cyan")
        
        # Pricing rows
        monthly_row = ["[bold]Monthly Price[/bold]", "[green]$0[/green]"]
        annual_row = ["[bold]Annual Price[/bold]", "[green]$0[/green]"]
        
        for plan in plans:
            monthly_price = plan['pricing']['monthly']
            yearly_price = plan['pricing']['yearly']
            savings = plan['pricing']['yearly_savings']
            
            monthly_row.append(f"[cyan]${monthly_price}/month[/cyan]")
            annual_row.append(f"[cyan]${yearly_price}/year[/cyan]\n[dim](${savings} saved)[/dim]")
        
        table.add_row(*monthly_row)
        table.add_row(*annual_row)
        table.add_row(*[""] * (2 + len(plans)))  # Separator
        
        # Feature comparison
        features_to_show = [
            ("Learning sessions/month", "5", "max_learning_sessions"),
            ("AI hints/month", "10", "max_ai_hints"), 
            ("Advanced analytics", "❌", "advanced_analytics"),
            ("Priority support", "❌", "priority_support"),
            ("Offline mode", "❌", "offline_mode"),
            ("Custom themes", "❌", "custom_themes"),
        ]
        
        for feature_name, free_value, feature_key in features_to_show:
            row = [feature_name, free_value]
            
            for plan in plans:
                features = plan.get('features', {})
                value = features.get(feature_key, False)
                
                if isinstance(value, bool):
                    display_value = "✅" if value else "❌"
                elif value == 0 or value == -1:
                    display_value = "[green]Unlimited[/green]"
                else:
                    display_value = f"[cyan]{value}[/cyan]"
                
                row.append(display_value)
            
            table.add_row(*row)
        
        console.print(table)
        
        # Show current usage if available
        if current_usage:
            console.print(f"\n📊 [bold]Your Current Usage This Month[/bold]")
            console.print(f"  Learning sessions: [cyan]{current_usage.get('learning_sessions', 0)}[/cyan]")
            console.print(f"  AI hints used: [cyan]{current_usage.get('ai_hints_used', 0)}[/cyan]")
        
        console.print()
    
    def upgrade_subscription_flow(self) -> bool:
        """Handle subscription upgrade flow"""
        
        if not self.auth or not self.auth.is_logged_in():
            console.print("❌ [red]Please login first to manage subscriptions[/red]")
            return False
        
        current_status = self.get_subscription_status()
        current_tier = current_status["tier"]
        
        console.print(f"Current plan: [bold]{current_tier.title()}[/bold]")
        
        # Check if user is part of an organization
        org = self.auth.get_current_organization()
        if org and current_tier != "free":
            console.print("ℹ️  Your subscription is managed by your organization.")
            console.print("Please contact your organization admin to modify the subscription.")
            return False
        
        # Show pricing options
        self.show_pricing_plans()
        
        # Get upgrade choice
        if org:
            # Organization upgrade
            return self._handle_organization_upgrade(org)
        else:
            # Individual upgrade
            return self._handle_individual_upgrade()
    
    def _handle_individual_upgrade(self) -> bool:
        """Handle individual user subscription upgrade"""
        
        console.print("📱 [bold]Basic Plan Upgrade[/bold]")
        
        # Plan selection
        plans = ["basic", "back"]
        plan_choice = Prompt.ask(
            "Choose plan",
            choices=plans,
            default="basic"
        )
        
        if plan_choice == "back":
            return False
        
        # Billing cycle selection
        cycle_choice = Prompt.ask(
            "Billing cycle",
            choices=["monthly", "annual"],
            default="annual"
        )
        
        price_info = self.stripe_config.products[plan_choice][cycle_choice]
        amount = price_info["amount"] / 100  # Convert cents to dollars
        
        console.print(f"\n💳 [bold]Plan Summary[/bold]")
        console.print(f"Plan: [cyan]{plan_choice.title()}[/cyan]")
        console.print(f"Billing: [cyan]{cycle_choice.title()}[/cyan]")
        console.print(f"Price: [green]${amount:.2f}/{price_info['interval']}[/green]")
        
        if not Confirm.ask("\nProceed with subscription?", default=True):
            return False
        
        # Create checkout session via Django service
        return self._create_django_checkout_session(plan_choice, cycle_choice)
    
    def _handle_organization_upgrade(self, org: Dict[str, Any]) -> bool:
        """Handle organization subscription upgrade"""
        
        console.print(f"🏢 [bold]Organization Plan Upgrade: {org['name']}[/bold]")
        
        # Check if user has admin permissions
        if not self._user_can_manage_billing(org):
            console.print("❌ [red]You don't have permission to manage billing for this organization[/red]")
            return False
        
        # Plan selection
        plans = ["team", "enterprise", "back"]
        plan_choice = Prompt.ask(
            "Choose organization plan",
            choices=plans,
            default="team"
        )
        
        if plan_choice == "back":
            return False
        
        if plan_choice == "enterprise":
            console.print("🏢 [bold]Enterprise Plan[/bold]")
            console.print("Enterprise plans include custom pricing and features.")
            console.print("Please contact our sales team at enterprise@typequest.dev")
            return False
        
        # Billing cycle selection
        cycle_choice = Prompt.ask(
            "Billing cycle",
            choices=["monthly", "annual"],
            default="annual"
        )
        
        price_info = self.stripe_config.products[plan_choice][cycle_choice]
        amount = price_info["amount"] / 100
        
        console.print(f"\n💳 [bold]Organization Plan Summary[/bold]")
        console.print(f"Organization: [cyan]{org['name']}[/cyan]")
        console.print(f"Plan: [cyan]{plan_choice.title()}[/cyan]")
        console.print(f"Billing: [cyan]{cycle_choice.title()}[/cyan]")
        console.print(f"Price: [green]${amount:.2f}/{price_info['interval']}[/green]")
        
        if not Confirm.ask("\nProceed with organization subscription?", default=True):
            return False
        
        # Create checkout session via Django service  
        return self._create_django_checkout_session(plan_choice, cycle_choice)
    
    def _create_django_checkout_session(self, plan_name: str, interval: str) -> bool:
        """Create checkout session via Django service"""
        
        try:
            console.print("🔄 [yellow]Creating checkout session...[/yellow]")
            console.print(f"[dim]API URL: {self.api_base}{self.api_prefix}/api/subscriptions/[/dim]")
            
            # Prepare checkout data for Django service
            checkout_data = {
                "plan": plan_name,  # Django endpoint expects "plan", not "plan_name"
                "interval": interval
            }
            
            # Use Django service subscription management endpoint
            response = requests.post(
                f"{self.api_base}{self.api_prefix}/api/subscriptions/",
                json=checkout_data,
                headers={
                    "Authorization": f"Bearer {self.auth.get_auth_token()}",
                    "Content-Type": "application/json"
                },
                timeout=30
            )
            
            if response.status_code == 200 or response.status_code == 201:
                data = response.json()
                checkout_url = data.get("checkout_url") or data.get("url")
                
                if checkout_url:
                    console.print("🌐 [green]Opening checkout in browser...[/green]")
                    console.print(f"Checkout URL: [blue]{checkout_url}[/blue]")
                    
                    # Open browser
                    import webbrowser
                    webbrowser.open(checkout_url)
                    
                    console.print("\n✅ Complete your payment in the browser.")
                    console.print("Your subscription will be activated automatically after successful payment.")
                    console.print("\n💡 [dim]Tip: Run 'subscription status' to check your updated subscription.[/dim]")
                    
                    return True
                else:
                    console.print("❌ [red]No checkout URL received from service[/red]")
                    return False
            else:
                error_msg = f"HTTP {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get('error', error_msg)
                    # Show more detailed error info for debugging
                    console.print(f"❌ [red]Failed to create checkout session: {error_msg}[/red]")
                    console.print(f"[dim]Status: {response.status_code}, Response: {error_data}[/dim]")
                except:
                    console.print(f"❌ [red]Failed to create checkout session: {error_msg}[/red]")
                    console.print(f"[dim]Response body: {response.text[:200]}[/dim]")
                return False
                
        except requests.RequestException as e:
            console.print(f"❌ [red]Network error creating checkout session: {e}[/red]")
            return False
        except Exception as e:
            console.print(f"❌ [red]Checkout session creation failed: {e}[/red]")
            return False
    
    def cancel_subscription(self) -> bool:
        """Cancel current subscription"""
        
        if not self.auth or not self.auth.is_logged_in():
            console.print("❌ [red]Please login first[/red]")
            return False
        
        current_status = self.get_subscription_status()
        
        if current_status["tier"] == "free":
            console.print("ℹ️  You're currently on the free plan.")
            return True
        
        # Check permissions
        org = self.auth.get_current_organization()
        if org and not self._user_can_manage_billing(org):
            console.print("❌ [red]You don't have permission to manage billing for this organization[/red]")
            return False
        
        # Confirmation
        console.print(f"📋 [bold]Current Subscription[/bold]")
        console.print(f"Plan: [cyan]{current_status['tier'].title()}[/cyan]")
        console.print(f"Status: [cyan]{current_status['status'].title()}[/cyan]")
        
        if current_status.get("expires_at"):
            expires = datetime.fromisoformat(current_status["expires_at"])
            console.print(f"Expires: [cyan]{expires.strftime('%B %d, %Y')}[/cyan]")
        
        console.print("\n⚠️  [yellow]Canceling your subscription will:[/yellow]")
        console.print("  • Remove access to premium features")
        console.print("  • Revert to free plan limits")
        console.print("  • Keep your progress and data")
        
        if not Confirm.ask("\nAre you sure you want to cancel?", default=False):
            return False
        
        # Cancel via Django service
        try:
            response = requests.delete(
                f"{self.api_base}{self.api_prefix}/api/subscriptions/",
                headers={
                    "Authorization": f"Bearer {self.auth.get_auth_token()}",
                    "Content-Type": "application/json"
                },
                timeout=15
            )
            
            if response.status_code == 200 or response.status_code == 204:
                console.print("✅ [green]Subscription cancelled successfully[/green]")
                console.print("You'll retain access until the end of your current billing period.")
                console.print("\n💡 [dim]Run 'subscription status' to see your updated subscription.[/dim]")
                return True
            else:
                error_msg = response.json().get('error', 'Unknown error') if response.content else f"HTTP {response.status_code}"
                console.print(f"❌ [red]Cancellation failed: {error_msg}[/red]")
                return False
                
        except requests.RequestException as e:
            console.print(f"❌ [red]Network error during cancellation: {e}[/red]")
            return False
        except Exception as e:
            console.print(f"❌ [red]Cancellation failed: {e}[/red]")
            return False
    
    def _user_can_manage_billing(self, org: Dict[str, Any]) -> bool:
        """Check if user can manage billing for organization"""
        
        try:
            response = requests.get(
                f"{self.api_base}/v1/organizations/{org['id']}/members/me",
                headers={'Authorization': f'Bearer {self.auth.get_auth_token()}'},
                timeout=10
            )
            
            if response.status_code == 200:
                member_info = response.json()
                return member_info.get("role") in ["admin", "billing_admin", "owner"]
            else:
                return False
                
        except requests.RequestException:
            return False
    
    def open_customer_portal(self) -> bool:
        """Open Stripe customer portal for subscription management"""
        
        if not self.auth or not self.auth.is_logged_in():
            console.print("❌ [red]Please login first[/red]")
            return False
        
        try:
            console.print("🔄 [yellow]Opening customer portal...[/yellow]")
            
            response = requests.get(
                f"{self.api_base}{self.api_prefix}/cli/subscription/portal/",
                headers={
                    "Authorization": f"Bearer {self.auth.get_auth_token()}",
                    "Content-Type": "application/json"
                },
                timeout=15
            )
            
            if response.status_code == 200:
                data = response.json()
                portal_url = data.get('portal_url')
                
                if portal_url:
                    console.print("🌐 [green]Opening billing portal in browser...[/green]")
                    console.print(f"Portal URL: [blue]{portal_url}[/blue]")
                    console.print(f"\n💡 [dim]{data.get('message', 'Manage your subscription, payment methods, and billing history.')}[/dim]")
                    
                    # Open browser
                    import webbrowser
                    webbrowser.open(portal_url)
                    
                    return True
                else:
                    console.print("❌ [red]No portal URL received[/red]")
                    return False
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('error', f'HTTP {response.status_code}')
                
                if response.status_code == 400 and 'No billing account' in error_msg:
                    console.print("ℹ️  [yellow]No billing account found[/yellow]")
                    console.print("You need an active subscription to access the billing portal.")
                    
                    if Confirm.ask("\nWould you like to view upgrade options?", default=True):
                        self.show_pricing_plans()
                    
                    return False
                else:
                    console.print(f"❌ [red]Failed to open portal: {error_msg}[/red]")
                    return False
                    
        except requests.RequestException as e:
            console.print(f"❌ [red]Network error accessing portal: {e}[/red]")
            return False
        except Exception as e:
            console.print(f"❌ [red]Portal access failed: {e}[/red]")
            return False
    
    def show_subscription_status(self):
        """Display current subscription status"""
        
        status = self.get_subscription_status()
        
        console.print("\n📊 [bold cyan]Subscription Status[/bold cyan]\n")
        
        # Basic info
        info_table = Table(show_header=False, box=None)
        info_table.add_column("Label", style="dim", width=20)
        info_table.add_column("Value", width=30)
        
        info_table.add_row("Plan", f"[bold]{status['tier'].title()}[/bold]")
        info_table.add_row("Status", f"[{'green' if status['status'] == 'active' else 'red'}]{status['status'].title()}[/]")
        
        if status.get("expires_at"):
            expires = datetime.fromisoformat(status["expires_at"])
            info_table.add_row("Expires", expires.strftime('%B %d, %Y'))
        
        if status.get("is_trial"):
            info_table.add_row("Trial", "[yellow]Yes[/yellow]")
        
        console.print(info_table)
        console.print()
        
        # Features
        features = status.get("features", {})
        console.print("✨ [bold]Available Features[/bold]")
        
        feature_table = Table(show_header=False, box=None)
        feature_table.add_column("Feature", width=25)
        feature_table.add_column("Available", width=15)
        
        feature_descriptions = {
            "max_lessons_per_month": "Lessons per month",
            "max_ai_queries_per_month": "AI queries per month",
            "ai_assistant": "AI Assistant",
            "progress_sync": "Progress sync",
            "leaderboard": "Leaderboards",
            "custom_datasets": "Custom datasets",
            "team_features": "Team features",
            "priority_support": "Priority support",
            "offline_mode": "Offline mode"
        }
        
        for key, description in feature_descriptions.items():
            value = features.get(key)
            if isinstance(value, bool):
                display_value = "✅" if value else "❌"
            elif value == -1:
                display_value = "[green]Unlimited[/green]"
            elif isinstance(value, (int, float)):
                display_value = f"[cyan]{value}[/cyan]"
            elif isinstance(value, str):
                display_value = f"[cyan]{value}[/cyan]"
            else:
                display_value = str(value)
            
            feature_table.add_row(description, display_value)
        
        console.print(feature_table)
        
        # Usage info if available
        usage = status.get("usage")
        if usage:
            console.print("\n📈 [bold]Current Usage[/bold]")
            
            usage_table = Table(show_header=False, box=None)
            usage_table.add_column("Metric", width=25)
            usage_table.add_column("Usage", width=15)
            
            if "lessons_completed_this_month" in usage:
                max_lessons = usage.get("max_lessons_per_month", "Unknown")
                max_display = "Unlimited" if max_lessons == -1 else str(max_lessons)
                usage_table.add_row(
                    "Lessons this month",
                    f"[cyan]{usage['lessons_completed_this_month']}[/cyan] / [dim]{max_display}[/dim]"
                )
            
            if "ai_queries_this_month" in usage:
                max_queries = usage.get("max_ai_queries_per_month", "Unknown")
                max_display = "Unlimited" if max_queries == -1 else str(max_queries)
                usage_table.add_row(
                    "AI queries this month",
                    f"[cyan]{usage['ai_queries_this_month']}[/cyan] / [dim]{max_display}[/dim]"
                )
            
            console.print(usage_table)
        
        console.print()
    
    def _get_cli_version(self) -> str:
        """Get CLI version"""
        try:
            from . import __version__
            return __version__
        except ImportError:
            return "1.0.0"
    
    def track_feature_usage(self, feature: str) -> bool:
        """Track usage of premium features via Django service"""
        
        if not self.auth or not self.auth.is_logged_in():
            return True  # Allow usage for non-logged in users (they'll hit other limits)
        
        try:
            response = requests.post(
                f"{self.api_base}{self.api_prefix}/cli/subscription/usage/",
                json={"feature": feature},
                headers={
                    "Authorization": f"Bearer {self.auth.get_auth_token()}",
                    "Content-Type": "application/json"
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                remaining = data.get('remaining')
                limit = data.get('limit')
                
                if remaining is not None and limit is not None:
                    console.print(f"[dim]✅ {feature.replace('_', ' ').title()} used: {limit - remaining}/{limit} this month[/dim]")
                
                return True
            elif response.status_code == 400:
                # Limit exceeded
                error_data = response.json()
                feature_name = error_data.get('feature', feature).replace('_', ' ')
                current = error_data.get('current_usage', 0)
                limit = error_data.get('limit', 0)
                
                console.print(f"\n❌ [red]{feature_name.title()} limit exceeded[/red]")
                console.print(f"   Used: {current}/{limit} this month")
                
                if error_data.get('upgrade_required', False):
                    console.print(f"   💡 [yellow]Upgrade to continue using this feature[/yellow]")
                    
                    if Confirm.ask("\nWould you like to see upgrade options?", default=True):
                        self.show_pricing_plans()
                
                return False
            else:
                console.print(f"[yellow]Warning: Could not track {feature} usage[/yellow]")
                return True  # Allow usage but warn
                
        except requests.RequestException:
            # Service unavailable - allow usage but don't track
            return True
        except Exception as e:
            console.print(f"[dim]Error tracking usage: {e}[/dim]")
            return True
    
    def check_feature_access(self, feature: str) -> bool:
        """Check if user can access a premium feature"""
        
        if not self.auth or not self.auth.is_logged_in():
            return feature in ['basic_lessons', 'progress_tracking']  # Basic features for anonymous users
        
        try:
            response = requests.post(
                f"{self.api_base}{self.api_prefix}/cli/subscription/check/",
                json={"features": [feature]},
                headers={
                    "Authorization": f"Bearer {self.auth.get_auth_token()}",
                    "Content-Type": "application/json"
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                features = data.get('features', {})
                feature_data = features.get(feature, {})
                return feature_data.get('allowed', False)
            else:
                # If service is down, allow basic features
                return feature in ['basic_lessons', 'progress_tracking']
                
        except requests.RequestException:
            # Service unavailable - allow basic features
            return feature in ['basic_lessons', 'progress_tracking']
        except Exception:
            return False