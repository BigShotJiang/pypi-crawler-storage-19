"""
Cloud synchronization for CLI application
"""

import requests
import threading
import time
import json
import sqlite3
from datetime import datetime
from typing import Dict, Any, Optional, List
from rich.console import Console

console = Console()

class ProgressSync:
    """Handle syncing progress between CLI and cloud"""
    
    def __init__(self, auth_manager=None, config=None):
        self.auth = auth_manager
        self.config = config
        import os
        self.api_base = os.getenv("TYPEQUEST_API_URL", "https://typequest-service.onrender.com")
        self.sync_interval = 300  # 5 minutes
        self.last_sync = None
        self.sync_thread = None
        self.stop_sync = threading.Event()
        
        # Start background sync thread if auth is available
        if self.auth:
            self.start_background_sync()
    
    def start_background_sync(self):
        """Start background sync thread"""
        
        def sync_worker():
            """Background sync worker"""
            while not self.stop_sync.is_set():
                try:
                    if self.auth and self.auth.is_logged_in() and self.should_sync():
                        self.perform_background_sync()
                except Exception:
                    # Fail silently for background sync
                    pass
                
                # Wait for sync interval or stop event
                self.stop_sync.wait(self.sync_interval)
        
        if self.sync_thread and self.sync_thread.is_alive():
            self.stop_background_sync()
        
        self.sync_thread = threading.Thread(target=sync_worker, daemon=True)
        self.sync_thread.start()
    
    def stop_background_sync(self):
        """Stop background sync thread"""
        self.stop_sync.set()
        if self.sync_thread and self.sync_thread.is_alive():
            self.sync_thread.join(timeout=2)
    
    def should_sync(self) -> bool:
        """Check if sync is needed"""
        
        if not self.last_sync:
            return True
        
        time_since_sync = time.time() - self.last_sync
        return time_since_sync >= self.sync_interval
    
    def perform_background_sync(self):
        """Perform background sync"""
        
        try:
            if not self.config:
                return
            
            # Get local progress
            local_progress = self.get_local_progress()
            
            # Sync to cloud (non-blocking)
            success = self.sync_progress_to_cloud(local_progress, silent=True)
            
            if success:
                # Sync from cloud to get updates
                cloud_progress = self.sync_progress_from_cloud(silent=True)
                if cloud_progress:
                    merged_progress = self.merge_progress(local_progress, cloud_progress)
                    self.save_local_progress(merged_progress)
            
            # Update last sync time
            self.last_sync = time.time()
            
        except Exception:
            # Fail silently in background
            pass
    
    def get_local_progress(self) -> Dict[str, Any]:
        """Get all local progress data"""
        
        if not self.config:
            return {}
        
        try:
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            progress_data = {
                "user_progress": [],
                "exercise_submissions": [],
                "achievements": [],
                "daily_challenges": [],
                "learning_goals": [],
                "last_sync": datetime.now().isoformat()
            }
            
            # Get user progress
            cursor.execute('''
                SELECT user_id, course_slug, lesson_slug, is_completed, 
                       completed_at, time_spent, last_synced_at
                FROM user_progress
            ''')
            
            for row in cursor.fetchall():
                progress_data["user_progress"].append({
                    "user_id": row[0],
                    "course_slug": row[1],
                    "lesson_slug": row[2],
                    "is_completed": bool(row[3]),
                    "completed_at": row[4],
                    "time_spent": row[5],
                    "last_synced_at": row[6]
                })
            
            # Get exercise submissions
            cursor.execute('''
                SELECT user_id, exercise_id, code, is_correct, xp_earned,
                       submitted_at, hints_used, last_synced_at
                FROM exercise_submissions
            ''')
            
            for row in cursor.fetchall():
                progress_data["exercise_submissions"].append({
                    "user_id": row[0],
                    "exercise_id": row[1],
                    "code": row[2],
                    "is_correct": bool(row[3]),
                    "xp_earned": row[4],
                    "submitted_at": row[5],
                    "hints_used": row[6],
                    "last_synced_at": row[7]
                })
            
            # Get achievements
            cursor.execute('''
                SELECT user_id, achievement_slug, earned_at, last_synced_at
                FROM user_achievements
            ''')
            
            for row in cursor.fetchall():
                progress_data["achievements"].append({
                    "user_id": row[0],
                    "achievement_slug": row[1],
                    "earned_at": row[2],
                    "last_synced_at": row[3]
                })
            
            # Get daily challenges
            cursor.execute('''
                SELECT user_id, date, completed, completed_at, xp_earned, last_synced_at
                FROM daily_challenges
            ''')
            
            for row in cursor.fetchall():
                progress_data["daily_challenges"].append({
                    "user_id": row[0],
                    "date": row[1],
                    "completed": bool(row[2]),
                    "completed_at": row[3],
                    "xp_earned": row[4],
                    "last_synced_at": row[5]
                })
            
            # Get learning goals
            cursor.execute('''
                SELECT user_id, title, description, target_date, is_completed,
                       created_at, last_synced_at
                FROM learning_goals
            ''')
            
            for row in cursor.fetchall():
                progress_data["learning_goals"].append({
                    "user_id": row[0],
                    "title": row[1],
                    "description": row[2],
                    "target_date": row[3],
                    "is_completed": bool(row[4]),
                    "created_at": row[5],
                    "last_synced_at": row[6]
                })
            
            conn.close()
            return progress_data
            
        except Exception as e:
            console.print(f"[dim]Error getting local progress: {e}[/dim]")
            return {}
    
    def sync_progress_to_cloud(self, progress_data: Dict[str, Any], silent: bool = False) -> bool:
        """
        Upload progress to cloud
        
        Args:
            progress_data: Local progress data
            silent: If True, don't show output messages
            
        Returns:
            bool: True if sync was successful
        """
        
        if not self.auth or not self.auth.is_logged_in():
            return False
        
        token = self.auth.get_auth_token()
        if not token:
            return False
        
        try:
            if not silent:
                console.print("☁️  [dim]Syncing progress to cloud...[/dim]")
            
            response = requests.post(
                f"{self.api_base}/v1/progress/sync",
                json={
                    "progress": progress_data,
                    "timestamp": datetime.now().isoformat(),
                    "cli_version": self.get_cli_version(),
                    "device_id": self._get_device_id()
                },
                headers={
                    "Authorization": f"Bearer {token}",
                    "User-Agent": f"TypeQuest-CLI/{self.get_cli_version()}",
                    "Content-Type": "application/json"
                },
                timeout=15
            )
            
            success = response.status_code == 200
            
            if success and not silent:
                console.print("✅ [green]Progress synced to cloud[/green]")
            elif not success and not silent:
                console.print(f"⚠️  [yellow]Sync failed: {response.status_code}[/yellow]")
            
            return success
            
        except requests.RequestException as e:
            if not silent:
                console.print(f"⚠️  [yellow]Cloud sync failed: {e}[/yellow]")
            return False
    
    def sync_progress_from_cloud(self, silent: bool = False) -> Optional[Dict[str, Any]]:
        """
        Download progress from cloud
        
        Args:
            silent: If True, don't show output messages
            
        Returns:
            dict: Cloud progress data or None if failed
        """
        
        if not self.auth or not self.auth.is_logged_in():
            return None
        
        token = self.auth.get_auth_token()
        if not token:
            return None
        
        try:
            if not silent:
                console.print("☁️  [dim]Getting latest progress from cloud...[/dim]")
            
            response = requests.get(
                f"{self.api_base}/v1/progress",
                headers={
                    "Authorization": f"Bearer {token}",
                    "User-Agent": f"TypeQuest-CLI/{self.get_cli_version()}"
                },
                timeout=15
            )
            
            if response.status_code == 200:
                cloud_data = response.json().get("progress", {})
                if not silent and cloud_data:
                    console.print("✅ [green]Retrieved cloud progress[/green]")
                return cloud_data
            elif not silent:
                console.print(f"⚠️  [yellow]Could not get cloud progress: {response.status_code}[/yellow]")
                
        except requests.RequestException as e:
            if not silent:
                console.print(f"⚠️  [yellow]Cloud sync failed: {e}[/yellow]")
        
        return None
    
    def merge_progress(self, local_progress: Dict[str, Any], cloud_progress: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge local and cloud progress data
        
        Args:
            local_progress: Local progress data
            cloud_progress: Cloud progress data
            
        Returns:
            dict: Merged progress data
        """
        
        merged = local_progress.copy()
        
        # Merge each data type
        for data_type in ["user_progress", "exercise_submissions", "achievements", "daily_challenges", "learning_goals"]:
            local_items = local_progress.get(data_type, [])
            cloud_items = cloud_progress.get(data_type, [])
            
            # Create lookup for existing local items
            local_lookup = {}
            for item in local_items:
                key = self._generate_item_key(item, data_type)
                local_lookup[key] = item
            
            # Merge cloud items
            for cloud_item in cloud_items:
                key = self._generate_item_key(cloud_item, data_type)
                
                if key in local_lookup:
                    # Item exists locally - merge based on timestamps
                    local_item = local_lookup[key]
                    merged_item = self._merge_item(local_item, cloud_item, data_type)
                    local_lookup[key] = merged_item
                else:
                    # New item from cloud
                    local_lookup[key] = cloud_item
            
            # Update merged data
            merged[data_type] = list(local_lookup.values())
        
        merged["last_sync"] = datetime.now().isoformat()
        return merged
    
    def _generate_item_key(self, item: Dict[str, Any], data_type: str) -> str:
        """Generate unique key for an item based on its type"""
        
        if data_type == "user_progress":
            return f"{item['user_id']}:{item['course_slug']}:{item['lesson_slug']}"
        elif data_type == "exercise_submissions":
            return f"{item['user_id']}:{item['exercise_id']}:{item['submitted_at']}"
        elif data_type == "achievements":
            return f"{item['user_id']}:{item['achievement_slug']}"
        elif data_type == "daily_challenges":
            return f"{item['user_id']}:{item['date']}"
        elif data_type == "learning_goals":
            return f"{item['user_id']}:{item['title']}:{item.get('created_at', '')}"
        
        return str(item)
    
    def _merge_item(self, local_item: Dict[str, Any], cloud_item: Dict[str, Any], data_type: str) -> Dict[str, Any]:
        """Merge a local and cloud item, preferring more recent data"""
        
        # Get timestamps for comparison
        local_time = local_item.get("last_synced_at") or local_item.get("completed_at") or local_item.get("submitted_at") or local_item.get("earned_at") or local_item.get("created_at")
        cloud_time = cloud_item.get("last_synced_at") or cloud_item.get("completed_at") or cloud_item.get("submitted_at") or cloud_item.get("earned_at") or cloud_item.get("created_at")
        
        # If no timestamps, prefer cloud (assume it's more recent)
        if not local_time and not cloud_time:
            return cloud_item
        elif not cloud_time:
            return local_item
        elif not local_time:
            return cloud_item
        
        # Compare timestamps
        try:
            local_dt = datetime.fromisoformat(local_time.replace('Z', '+00:00'))
            cloud_dt = datetime.fromisoformat(cloud_time.replace('Z', '+00:00'))
            
            # Return the more recent item
            if cloud_dt > local_dt:
                return cloud_item
            else:
                return local_item
        except (ValueError, AttributeError):
            # If timestamp parsing fails, prefer cloud
            return cloud_item
    
    def save_local_progress(self, progress_data: Dict[str, Any]) -> bool:
        """Save merged progress data to local database"""
        
        if not self.config:
            return False
        
        try:
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            # Clear existing data and insert merged data
            # Note: In production, you'd want more sophisticated merging
            
            # Update sync timestamp for tracking
            sync_time = datetime.now().isoformat()
            
            # For each item, update or insert
            # This is a simplified version - production would need conflict resolution
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            console.print(f"[dim]Error saving progress: {e}[/dim]")
            return False
    
    def get_cli_version(self) -> str:
        """Get CLI version"""
        try:
            from . import __version__
            return __version__
        except ImportError:
            return "1.0.0"
    
    def _get_device_id(self) -> str:
        """Get unique device identifier"""
        import uuid
        import platform
        
        # Create a consistent device ID based on system info
        system_info = f"{platform.node()}-{platform.system()}-{platform.machine()}"
        device_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, system_info))
        return device_id
    
    def force_sync(self) -> bool:
        """Force immediate synchronization"""
        
        if not self.auth or not self.auth.is_logged_in():
            console.print("❌ [red]Not logged in - cannot sync[/red]")
            return False
        
        console.print("🔄 [yellow]Forcing sync with cloud...[/yellow]")
        
        # Get local progress
        local_progress = self.get_local_progress()
        
        # Upload to cloud
        upload_success = self.sync_progress_to_cloud(local_progress)
        
        if upload_success:
            # Download from cloud
            cloud_progress = self.sync_progress_from_cloud()
            
            if cloud_progress:
                # Merge and save
                merged_progress = self.merge_progress(local_progress, cloud_progress)
                save_success = self.save_local_progress(merged_progress)
                
                if save_success:
                    console.print("✅ [green]Force sync completed successfully![/green]")
                    return True
        
        console.print("❌ [red]Force sync failed[/red]")
        return False
    
    def get_sync_status(self) -> Dict[str, Any]:
        """Get current sync status"""
        
        status = {
            "logged_in": self.auth.is_logged_in() if self.auth else False,
            "last_sync": self.last_sync,
            "sync_enabled": self.config.get_config_value("cloud_sync.enabled", True) if self.config else False,
            "auto_sync": self.config.get_config_value("cloud_sync.auto_sync", True) if self.config else False,
            "sync_interval": self.sync_interval,
            "background_sync_running": self.sync_thread.is_alive() if self.sync_thread else False
        }
        
        return status