"""
Auto-update system for TypeQuest
"""

import requests
import subprocess
import sys
import threading
import time
from packaging import version
from rich.console import Console
from rich.prompt import Confirm
from rich.panel import Panel
from typing import Dict, Any, Optional
import json
from pathlib import Path

console = Console()

# Package name on PyPI
PACKAGE_NAME = "typequest"

# Cache file for update checks (avoid checking too frequently)
CACHE_FILE = Path.home() / ".typequest" / "update_cache.json"


class UpdateManager:
    """Handle CLI updates"""

    def __init__(self):
        self.pypi_url = f"https://pypi.org/pypi/{PACKAGE_NAME}/json"
        self.current_version = self.get_current_version()
        self.last_check = None
        self.check_interval = 86400  # Check once per day (in seconds)

    def get_current_version(self) -> str:
        """Get current CLI version"""
        try:
            from .. import __version__
            return __version__
        except ImportError:
            return "1.0.0"

    def _load_cache(self) -> Dict[str, Any]:
        """Load update check cache"""
        try:
            if CACHE_FILE.exists():
                with open(CACHE_FILE, 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _save_cache(self, data: Dict[str, Any]):
        """Save update check cache"""
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(CACHE_FILE, 'w') as f:
                json.dump(data, f)
        except Exception:
            pass

    def _should_check(self) -> bool:
        """Check if enough time has passed since last check"""
        cache = self._load_cache()
        last_check = cache.get('last_check', 0)
        return time.time() - last_check > self.check_interval

    def check_for_updates(self, silent: bool = False, force: bool = False) -> Dict[str, Any]:
        """
        Check for available updates on PyPI

        Args:
            silent (bool): If True, don't show any output
            force (bool): If True, bypass cache and check anyway

        Returns:
            dict: Update information
        """

        # Check cache unless forced
        if not force and not self._should_check():
            cache = self._load_cache()
            if cache.get('update_available'):
                if not silent:
                    self._show_update_notification(cache)
                return cache
            return {"update_available": False, "message": "Recently checked"}

        try:
            if not silent:
                console.print("[dim]Checking for updates...[/dim]")

            response = requests.get(
                self.pypi_url,
                headers={"User-Agent": f"TypeQuest-CLI/{self.current_version}"},
                timeout=5
            )

            if response.status_code == 200:
                data = response.json()
                latest_version = data.get("info", {}).get("version", "1.0.0")

                # Update cache
                cache_data = {
                    "last_check": time.time(),
                    "latest_version": latest_version,
                    "current_version": self.current_version,
                }

                # Compare versions
                if version.parse(latest_version) > version.parse(self.current_version):
                    # Get release info
                    releases = data.get("releases", {})
                    release_info = releases.get(latest_version, [{}])
                    upload_time = release_info[0].get("upload_time", "") if release_info else ""

                    update_info = {
                        "update_available": True,
                        "latest_version": latest_version,
                        "current_version": self.current_version,
                        "release_date": upload_time,
                        "package_url": f"https://pypi.org/project/{PACKAGE_NAME}/",
                    }

                    cache_data.update(update_info)
                    self._save_cache(cache_data)

                    if not silent:
                        self._show_update_notification(update_info)

                    return update_info
                else:
                    cache_data["update_available"] = False
                    self._save_cache(cache_data)

                    if not silent:
                        console.print("[green]You're running the latest version![/green]")

                    return {"update_available": False, "message": "Up to date"}

            elif response.status_code == 404:
                # Package not on PyPI yet
                if not silent:
                    console.print("[dim]Package not yet published to PyPI[/dim]")
                return {"update_available": False, "message": "Package not on PyPI"}

        except requests.RequestException as e:
            if not silent:
                console.print(f"[yellow]Could not check for updates: {e}[/yellow]")
            return {"update_available": False, "error": str(e)}
        except Exception as e:
            if not silent:
                console.print(f"[red]Update check failed: {e}[/red]")
            return {"update_available": False, "error": str(e)}

        return {"update_available": False}

    def _show_update_notification(self, update_info: Dict[str, Any]):
        """Show update notification to user"""

        notification = f"""
[bold cyan]Update Available![/bold cyan]

Current version: [dim]{update_info.get('current_version', self.current_version)}[/dim]
Latest version:  [bold green]{update_info['latest_version']}[/bold green]

To update, run:
  [bold]pip install --upgrade {PACKAGE_NAME}[/bold]
"""

        console.print(Panel(notification, border_style="cyan", padding=(0, 2)))

    def prompt_update(self, update_info: Dict[str, Any]) -> bool:
        """
        Prompt user to update

        Args:
            update_info (dict): Update information from check_for_updates

        Returns:
            bool: True if user wants to update
        """

        console.print(f"\n[bold cyan]Update Available![/bold cyan]")
        console.print(f"Current version: [dim]{update_info.get('current_version', self.current_version)}[/dim]")
        console.print(f"Latest version: [bold]{update_info['latest_version']}[/bold]")

        console.print()
        return Confirm.ask("Would you like to update now?", default=True)

    def perform_update(self, force: bool = False) -> bool:
        """
        Perform the update

        Args:
            force (bool): Force update even if no update is available

        Returns:
            bool: True if update was successful
        """

        try:
            console.print("[yellow]Updating TypeQuest...[/yellow]")
            console.print("[dim]This may take a moment...[/dim]")

            # Update using pip
            cmd = [sys.executable, "-m", "pip", "install", "--upgrade", PACKAGE_NAME]

            if force:
                cmd.append("--force-reinstall")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120  # 2 minute timeout
            )

            if result.returncode == 0:
                console.print("[green]Update completed successfully![/green]")

                # Show new version
                new_version = self._get_installed_version()
                if new_version and new_version != self.current_version:
                    console.print(f"Updated from [dim]{self.current_version}[/dim] to [bold]{new_version}[/bold]")

                console.print("[dim]Please restart TypeQuest to use the new version[/dim]")

                # Clear cache
                self._save_cache({"last_check": time.time(), "update_available": False})

                return True
            else:
                console.print(f"[red]Update failed![/red]")
                console.print(f"Error: {result.stderr}")

                # Suggest manual installation
                console.print("\nTry manual installation:")
                console.print(f"   pip install --upgrade {PACKAGE_NAME}")

                return False

        except subprocess.TimeoutExpired:
            console.print("[red]Update timed out. Please try again.[/red]")
            return False
        except Exception as e:
            console.print(f"[red]Update error: {e}[/red]")
            return False

    def _get_installed_version(self) -> Optional[str]:
        """Get currently installed version"""
        try:
            result = subprocess.run(
                [sys.executable, "-c", f"import importlib.metadata; print(importlib.metadata.version('{PACKAGE_NAME}'))"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except:
            pass
        return None

    def auto_update_check(self) -> Dict[str, Any]:
        """
        Perform automatic update check in background
        Only checks once per day to avoid spam

        Returns:
            dict: Update information
        """

        # Only check if enough time has passed
        if not self._should_check():
            return {"update_available": False, "message": "Recently checked"}

        return self.check_for_updates(silent=True)


# Convenience functions
def check_for_updates():
    """Check for updates synchronously and prompt user"""

    updater = UpdateManager()
    update_info = updater.check_for_updates(force=True)

    if update_info.get("update_available"):
        if updater.prompt_update(update_info):
            return updater.perform_update()

    return False


def check_for_updates_async():
    """Check for updates in background thread (non-blocking)"""

    def check_worker():
        try:
            updater = UpdateManager()
            update_info = updater.auto_update_check()

            if update_info.get("update_available"):
                # Show subtle notification after a short delay
                time.sleep(2)  # Let the main UI render first
                console.print(
                    f"\n[dim]New version {update_info['latest_version']} available. "
                    f"Run 'pip install --upgrade {PACKAGE_NAME}' to upgrade.[/dim]"
                )
        except Exception:
            # Fail silently in background
            pass

    thread = threading.Thread(target=check_worker, daemon=True)
    thread.start()


def get_startup_update_message() -> Optional[str]:
    """
    Get a startup message about updates (like Claude Code does).
    Returns None if no message needed, or a formatted string.
    """
    try:
        updater = UpdateManager()
        cache = updater._load_cache()

        # Check if there's a cached update available
        if cache.get("update_available"):
            latest = cache.get("latest_version", "unknown")
            current = cache.get("current_version", updater.current_version)
            return f"[yellow]* Update available: v{current} → v{latest} · pip install --upgrade {PACKAGE_NAME}[/yellow]"

        # Check if last update failed
        if cache.get("update_failed"):
            return f"[red]✗ Auto-update failed · Try: pip install --upgrade {PACKAGE_NAME}[/red]"

        return None
    except Exception:
        return None


def try_auto_update() -> bool:
    """
    Try to auto-update in background. Returns True if update started.
    Stores failure status in cache for startup message.
    """
    try:
        updater = UpdateManager()
        update_info = updater.check_for_updates(silent=True, force=True)

        if update_info.get("update_available"):
            # Try to update
            result = updater.perform_update()

            if not result:
                # Store failure for startup message
                cache = updater._load_cache()
                cache["update_failed"] = True
                updater._save_cache(cache)
                return False
            else:
                # Clear failure flag on success
                cache = updater._load_cache()
                cache.pop("update_failed", None)
                updater._save_cache(cache)
                return True

        return False
    except Exception:
        return False


def force_update():
    """Force update regardless of version"""

    updater = UpdateManager()
    console.print("[yellow]Forcing update...[/yellow]")
    return updater.perform_update(force=True)


def clear_update_cache():
    """Clear the update check cache"""
    try:
        if CACHE_FILE.exists():
            CACHE_FILE.unlink()
            console.print("[green]Update cache cleared[/green]")
    except Exception as e:
        console.print(f"[red]Failed to clear cache: {e}[/red]")
