"""
Typewriter Effect Display System
Provides smooth character-by-character text rendering for enhanced CLI experience
"""

import time
import sys
import os
import threading
import select
import termios
import tty
from rich.console import Console
from rich.text import Text
from rich.markdown import Markdown
from rich.syntax import Syntax
from threading import Event, Thread
from typing import Optional, Union

console = Console()

class TypewriterDisplay:
    """
    Global typewriter effect system for all text rendering in the CLI
    """
    
    def __init__(self, default_speed=0.03, fast_speed=0.01, instant_mode=False):
        """
        Initialize typewriter display
        
        Args:
            default_speed (float): Default delay between characters (seconds)
            fast_speed (float): Fast mode delay (for code blocks, etc.)
            instant_mode (bool): Skip typewriter effect entirely
        """
        self.default_speed = default_speed
        self.fast_speed = fast_speed
        self.instant_mode = instant_mode
        self.skip_event = Event()
        self._user_settings = self._load_user_settings()
        self.input_thread = None
    
    def _load_user_settings(self) -> dict:
        """Load user preferences for typewriter speed"""
        try:
            # Use the config system if available
            try:
                from ..config import Config
                config = Config()
                typewriter_config = config.get_config_value('typewriter', {})
                if typewriter_config:
                    return typewriter_config
            except ImportError:
                pass
            
            # Fallback to file-based config
            config_path = os.path.expanduser('~/.typequest/config.json')
            if os.path.exists(config_path):
                import json
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    return config.get('typewriter', {})
        except Exception:
            pass
        
        return {
            'enabled': True,
            'speed': 'normal',  # 'slow', 'normal', 'fast', 'instant'
            'skip_code_blocks': False,
            'skip_tables': True
        }
    
    def get_speed_for_content_type(self, content_type='text') -> float:
        """
        Get appropriate speed based on content type and user settings
        
        Args:
            content_type (str): 'text', 'code', 'table', 'heading'
        
        Returns:
            float: Delay in seconds between characters
        """
        if not self._user_settings.get('enabled', True):
            return 0
        
        speed_setting = self._user_settings.get('speed', 'normal')
        
        # Base speeds by setting
        speed_map = {
            'slow': 0.05,
            'normal': 0.03,
            'fast': 0.015,
            'instant': 0
        }
        
        base_speed = speed_map.get(speed_setting, 0.03)
        
        # Content type adjustments
        if content_type == 'code' and self._user_settings.get('skip_code_blocks', False):
            return 0
        elif content_type == 'table' and self._user_settings.get('skip_tables', True):
            return 0
        elif content_type == 'heading':
            return base_speed * 0.7  # Slightly faster for headings
        elif content_type == 'code':
            return base_speed * 0.5  # Faster for code
        
        return base_speed
    
    def type_text(self, text: str, speed: Optional[float] = None, 
                  content_type: str = 'text', style: Optional[str] = None, 
                  end: str = '\n'):
        """
        Display text with typewriter effect
        
        Args:
            text (str): Text to display
            speed (float): Custom speed override
            content_type (str): Type of content for speed adjustment
            style (str): Rich style string
            end (str): End character (newline by default)
        """
        if speed is None:
            speed = self.get_speed_for_content_type(content_type)
        
        if speed == 0 or self.instant_mode:
            # Instant mode
            if style:
                console.print(text, style=style, end=end)
            else:
                console.print(text, end=end)
            return
        
        # Character-by-character display
        self.skip_event.clear()
        i = 0  # Initialize i to avoid NameError
        
        try:
            for i, char in enumerate(text):
                # Check for skip event
                if self.skip_event.is_set():
                    # Print remaining text instantly
                    remaining_text = text[i:]
                    if remaining_text:
                        if style:
                            console.print(remaining_text, style=style, end=end)
                        else:
                            console.print(remaining_text, end=end)
                    break
                
                # Print character
                if style:
                    console.print(char, style=style, end='', flush=True)
                else:
                    console.print(char, end='', flush=True)
                
                # Only delay for non-whitespace or significant whitespace
                if char not in ' \t' or (char == ' ' and i % 3 == 0):
                    time.sleep(speed)
                elif char == '\n':
                    time.sleep(speed * 2)  # Slight pause at line breaks
            else:
                # Completed normally - add final newline if specified
                if end and not text.endswith(end):
                    console.print(end, end='')
                
        except KeyboardInterrupt:
            # Clear any partial input and handle Ctrl+C gracefully
            try:
                # Clear the line to avoid showing ^C
                console.print(f"\r[yellow]⚡ Skipping...[/yellow]", end='')
                remaining_text = text[i:] if i < len(text) else ""
                if remaining_text:
                    console.print()  # New line
                    if style:
                        console.print(remaining_text, style=style, end=end)
                    else:
                        console.print(remaining_text, end=end)
                else:
                    console.print()  # Just add a newline
            except:
                # Fallback - just print remaining text
                console.print(f"\n{text[i:]}" if i < len(text) else "")
        except Exception:
            # Catch any other issues and print remaining text
            remaining_text = text[i:] if i < len(text) else ""
            if remaining_text:
                console.print(remaining_text, end=end)
    
    def type_markdown_content(self, content: str):
        """
        Display markdown content with typewriter effect, handling different elements appropriately
        
        Args:
            content (str): Markdown content to display
        """
        try:
            lines = content.strip().split('\n')
            
            for line_num, line in enumerate(lines):
                line = line.rstrip()
                
                try:
                    # Detect content type and apply appropriate styling/speed
                    if line.startswith('# '):
                        # Main heading
                        self.type_text(line[2:], content_type='heading', style='bold cyan')
                    elif line.startswith('## '):
                        # Sub heading
                        console.print()  # Extra space before subheadings
                        self.type_text(line[3:], content_type='heading', style='bold white')
                    elif line.startswith('### '):
                        # Sub-sub heading
                        self.type_text(line[4:], content_type='heading', style='bold yellow')
                    elif line.startswith('**') and line.endswith('**') and len(line) > 4:
                        # Bold text
                        self.type_text(line[2:-2], style='bold')
                    elif line.startswith('- ') or line.startswith('* '):
                        # Bullet points
                        self.type_text(f"  • {line[2:]}", style='dim white')
                    elif line.startswith('```'):
                        # Code blocks - handle specially
                        continue  # Skip code block markers
                    elif line.startswith('    ') or line.startswith('\t'):
                        # Indented code
                        self.type_text(line, content_type='code', style='dim cyan')
                    elif line.startswith('|'):
                        # Table content
                        self.type_text(line, content_type='table', style='green')
                    elif line.startswith('>'):
                        # Blockquote
                        self.type_text(line[1:].strip(), style='italic dim')
                    elif line.strip() == '':
                        # Empty line
                        console.print()
                    else:
                        # Regular paragraph text
                        self.type_text(line)
                        
                except KeyboardInterrupt:
                    # If user interrupts during a line, print the rest instantly
                    console.print(f"\r[yellow]⚡ Displaying remaining content...[/yellow]")
                    remaining_lines = lines[line_num:]
                    for remaining_line in remaining_lines:
                        console.print(remaining_line.rstrip())
                    break
                    
        except KeyboardInterrupt:
            # Global interrupt - just print remaining content
            console.print(f"\n[yellow]⚡ Content skipped[/yellow]")
        except Exception as e:
            # Handle any other errors gracefully
            console.print(f"\n[red]Error displaying content: {e}[/red]")
    
    def type_lesson_content(self, lesson_content: str):
        """
        Specialized method for typing out lesson content with appropriate pacing
        
        Args:
            lesson_content (str): Full lesson content
        """
        # Check if user wants instant mode
        speed_setting = self._user_settings.get('speed', 'normal')
        if speed_setting == 'instant':
            console.print("[dim]⚡ Instant mode: Content displayed immediately[/dim]\n")
            console.print(lesson_content)
            return
        
        # Show helpful instructions and ask user preference
        console.print("[dim]💡 Typewriter mode active[/dim]")
        console.print("[dim]⚙️  Press ENTER to continue, 's' for instant mode, or 'q' to quit[/dim]")
        
        try:
            user_input = input().strip().lower()
            if user_input == 's':
                self.instant_mode = True
                self._user_settings['speed'] = 'instant'
                self._save_user_settings()
                console.print("[yellow]✅ Switched to instant mode![/yellow]\n")
                console.print(lesson_content)
                return
            elif user_input == 'q':
                console.print("[yellow]👋 Exiting lesson...[/yellow]")
                return
            else:
                console.print("[dim]🎮 Press Ctrl+C during typing to skip to end[/dim]")
                console.print("[dim]⚙️  Type 'q' anytime to quit or '/speed instant' to disable typewriter[/dim]\n")
        except KeyboardInterrupt:
            console.print("\n[yellow]👋 Exiting lesson...[/yellow]")
            return
        except:
            pass
        
        try:
            self.type_markdown_content(lesson_content)
        except KeyboardInterrupt:
            # User pressed Ctrl+C - ask what they want to do
            console.print("\n[yellow]⚡ Typewriter interrupted![/yellow]")
            console.print("[dim]Choose: (s)kip to end, (q)uit lesson, or ENTER to continue[/dim]")
            
            try:
                choice = input().strip().lower()
                if choice == 'q':
                    console.print("[yellow]👋 Exiting lesson...[/yellow]")
                    return
                elif choice == 's':
                    console.print("[yellow]⚡ Displaying remaining content instantly[/yellow]\n")
                    console.print(lesson_content)
                    return
                else:
                    # Continue with typewriter from where we left off
                    console.print("[dim]Continuing with typewriter...[/dim]\n")
                    self.type_markdown_content(lesson_content)
            except KeyboardInterrupt:
                console.print("\n[yellow]👋 Exiting lesson...[/yellow]")
                return
    
    def type_code_block(self, code: str, language: str = 'sql'):
        """
        Display code blocks with syntax highlighting and typewriter effect
        
        Args:
            code (str): Code content
            language (str): Programming language for syntax highlighting
        """
        if self.get_speed_for_content_type('code') == 0:
            # Instant mode for code
            syntax = Syntax(code, language, theme="monokai", line_numbers=True)
            console.print(syntax)
        else:
            # Type out code with syntax highlighting
            console.print(f"\n[bold]{language.upper()}:[/bold]")
            lines = code.strip().split('\n')
            
            for line in lines:
                self.type_text(line, content_type='code', style='cyan')
    
    def type_table(self, table_data: list, headers: Optional[list] = None):
        """
        Display table data with typewriter effect
        
        Args:
            table_data (list): List of rows
            headers (list): Table headers
        """
        from rich.table import Table
        
        if self.get_speed_for_content_type('table') == 0:
            # Instant mode for tables
            table = Table()
            if headers:
                for header in headers:
                    table.add_column(header, style="cyan")
            
            for row in table_data:
                table.add_row(*[str(cell) for cell in row])
            
            console.print(table)
        else:
            # Type out table content
            if headers:
                header_text = " | ".join(headers)
                self.type_text(header_text, content_type='table', style='bold cyan')
                self.type_text("-" * len(header_text), content_type='table', style='dim')
            
            for row in table_data:
                row_text = " | ".join(str(cell) for cell in row)
                self.type_text(row_text, content_type='table', style='white')
    
    def _setup_skip_monitoring(self):
        """Simplified skip monitoring - no longer needed with Ctrl+C approach"""
        pass
    
    def _cleanup_skip_monitoring(self):
        """Clean up skip monitoring - no longer needed"""
        pass
    
    def toggle_instant_mode(self):
        """Toggle between typewriter and instant display"""
        self.instant_mode = not self.instant_mode
        console.print(f"{'🚀 Instant mode ON' if self.instant_mode else '⌨️  Typewriter mode ON'}")
    
    def set_speed(self, speed_name: str):
        """
        Set typewriter speed globally
        
        Args:
            speed_name (str): 'slow', 'normal', 'fast', or 'instant'
        """
        valid_speeds = ['slow', 'normal', 'fast', 'instant']
        if speed_name not in valid_speeds:
            console.print(f"❌ Invalid speed. Choose from: {', '.join(valid_speeds)}")
            return
        
        self._user_settings['speed'] = speed_name
        if speed_name == 'instant':
            self.instant_mode = True
        else:
            self.instant_mode = False
        
        self._save_user_settings()
        console.print(f"✅ Typewriter speed set to: {speed_name}")
        
        # Show helpful info for instant mode
        if speed_name == 'instant':
            console.print("[dim]💡 All text will now display immediately[/dim]")
        else:
            console.print("[dim]💡 Press Ctrl+C during typing to skip content[/dim]")
    
    def enable_instant_mode(self):
        """Enable instant mode globally"""
        self.set_speed('instant')
    
    def disable_typewriter(self):
        """Disable typewriter effect - same as instant mode"""
        self.enable_instant_mode()
    
    def _save_user_settings(self):
        """Save user settings to config file"""
        try:
            # Use the config system if available
            try:
                from ..config import Config
                config = Config()
                config.update_config('typewriter', self._user_settings)
                return
            except ImportError:
                pass
            
            # Fallback to file-based config
            import json
            config_path = os.path.expanduser('~/.typequest/config.json')
            
            # Load existing config if it exists
            config = {}
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
            
            # Update typewriter settings
            config['typewriter'] = self._user_settings
            
            # Create directory if needed
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            
            # Save back
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2)
                
        except Exception as e:
            console.print(f"[dim]Could not save settings: {e}[/dim]")

# Global typewriter instance
typewriter = TypewriterDisplay()

# Convenience functions for easy use throughout the codebase
def type_text(text: str, speed: Optional[float] = None, style: Optional[str] = None):
    """Global function to type text with default settings"""
    typewriter.type_text(text, speed=speed, style=style)

def type_lesson(content: str):
    """Global function to display lesson content with typewriter effect"""
    typewriter.type_lesson_content(content)

def type_markdown(content: str):
    """Global function to display markdown with typewriter effect"""
    typewriter.type_markdown_content(content)

def type_code(code: str, language: str = 'sql'):
    """Global function to display code with typewriter effect"""
    typewriter.type_code_block(code, language)

def toggle_typewriter():
    """Global function to toggle typewriter mode"""
    typewriter.toggle_instant_mode()

def set_typewriter_speed(speed: str):
    """Global function to set typewriter speed"""
    typewriter.set_speed(speed)

def enable_instant_mode():
    """Global function to enable instant mode"""
    typewriter.enable_instant_mode()

def disable_typewriter():
    """Global function to disable typewriter effect"""
    typewriter.disable_typewriter()

def skip_all():
    """Global function to skip all typewriter effects"""
    typewriter.enable_instant_mode()

# Configuration helpers
def show_typewriter_settings():
    """Show current typewriter settings"""
    settings = typewriter._user_settings
    console.print("\n⌨️  [bold cyan]Typewriter Settings[/bold cyan]")
    console.print(f"📝 Enabled: {'✅' if settings.get('enabled', True) else '❌'}")
    console.print(f"🏃 Speed: {settings.get('speed', 'normal')}")
    console.print(f"💻 Skip code blocks: {'✅' if settings.get('skip_code_blocks', False) else '❌'}")
    console.print(f"📊 Skip tables: {'✅' if settings.get('skip_tables', True) else '❌'}")
    console.print(f"🚀 Instant mode: {'✅' if typewriter.instant_mode else '❌'}")
    console.print()
    console.print("💡 Commands:")
    console.print("  • /speed [slow|normal|fast|instant] - Change speed")
    console.print("  • /toggle - Toggle typewriter on/off")
    console.print("  • Press 's' at lesson start - Switch to instant mode")
    console.print("  • Press 'q' anytime - Quit current lesson")
    console.print("  • Press Ctrl+C during typing - Skip or quit options")
    console.print("  • Type 'skip_all()' in Python - Disable globally")

__all__ = [
    'TypewriterDisplay',
    'typewriter', 
    'type_text',
    'type_lesson', 
    'type_markdown',
    'type_code',
    'toggle_typewriter',
    'set_typewriter_speed',
    'enable_instant_mode',
    'disable_typewriter',
    'skip_all',
    'show_typewriter_settings'
]