"""
TypeQuest - Interactive coding education platform
"""

__version__ = "1.0.2"
__author__ = "TypeQuest Development Team"
__email__ = "hello@typequest.dev"

# Main entry point for programmatic access
from .main import TypeQuestCLI

# Export main application class
__all__ = ["TypeQuestCLI"]

def get_version():
    """Get package version"""
    return __version__

def main():
    """Main entry point for console script"""
    from .cli import main as cli_main
    return cli_main()