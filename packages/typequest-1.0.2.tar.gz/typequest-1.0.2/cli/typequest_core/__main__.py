"""
Allow running typequest as a module: python -m typequest
"""

from .cli import main

if __name__ == "__main__":
    main()