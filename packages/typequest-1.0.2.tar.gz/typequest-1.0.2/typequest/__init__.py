"""
TypeQuest - Interactive CLI for learning backend development

When user types 'typequest' in terminal, Python calls main() from here
"""

__version__ = "1.0.2"
__author__ = "TypeQuest Team"

import sys
import os

# Add the cli directory to the path so we can import from typequest_core
_cli_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cli')
if _cli_path not in sys.path:
    sys.path.insert(0, _cli_path)

# Import main from the existing CLI code
from typequest_core import main

# Export main so it can be called by the entry point
__all__ = ['main', '__version__', '__author__']
