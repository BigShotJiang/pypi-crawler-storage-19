from setuptools import setup, find_packages

setup(
    name="autodroid",
    version="1.1",
    packages=find_packages(),
    install_requires=[],
)
