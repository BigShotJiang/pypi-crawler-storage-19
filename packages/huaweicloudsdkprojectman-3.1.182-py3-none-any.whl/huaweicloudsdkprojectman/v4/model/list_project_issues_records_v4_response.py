# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListProjectIssuesRecordsV4Response(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'records': 'list[IssueAttrHistoryRecord]',
        'total': 'int'
    }

    attribute_map = {
        'records': 'records',
        'total': 'total'
    }

    def __init__(self, records=None, total=None):
        r"""ListProjectIssuesRecordsV4Response

        The model defined in huaweicloud sdk

        :param records: 历史记录
        :type records: list[:class:`huaweicloudsdkprojectman.v4.IssueAttrHistoryRecord`]
        :param total: 总数
        :type total: int
        """
        
        super().__init__()

        self._records = None
        self._total = None
        self.discriminator = None

        if records is not None:
            self.records = records
        if total is not None:
            self.total = total

    @property
    def records(self):
        r"""Gets the records of this ListProjectIssuesRecordsV4Response.

        历史记录

        :return: The records of this ListProjectIssuesRecordsV4Response.
        :rtype: list[:class:`huaweicloudsdkprojectman.v4.IssueAttrHistoryRecord`]
        """
        return self._records

    @records.setter
    def records(self, records):
        r"""Sets the records of this ListProjectIssuesRecordsV4Response.

        历史记录

        :param records: The records of this ListProjectIssuesRecordsV4Response.
        :type records: list[:class:`huaweicloudsdkprojectman.v4.IssueAttrHistoryRecord`]
        """
        self._records = records

    @property
    def total(self):
        r"""Gets the total of this ListProjectIssuesRecordsV4Response.

        总数

        :return: The total of this ListProjectIssuesRecordsV4Response.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListProjectIssuesRecordsV4Response.

        总数

        :param total: The total of this ListProjectIssuesRecordsV4Response.
        :type total: int
        """
        self._total = total

    def to_dict(self):
        import warnings
        warnings.warn("ListProjectIssuesRecordsV4Response.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListProjectIssuesRecordsV4Response):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
