"""
Manimera CLI Package.
"""
