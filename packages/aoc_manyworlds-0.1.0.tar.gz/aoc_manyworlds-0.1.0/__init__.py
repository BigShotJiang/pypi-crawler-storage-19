from ..AutoWorld import World, WebWorld
from Options import PerGameCommonOptions, FreeText
from BaseClasses import Item, Location, Region, ItemClassification, Tutorial
from dataclasses import dataclass
from ..generic.Rules import add_rule
import hashlib
from adofaipy import *
from aoc_manyworlds import get_logic

class AOCManyWorldsItem(Item):
    game: str = "Advent of Code 2019 Day 18 Part 2"

class AOCManyWorldsLocation(Location):
    game: str = "Advent of Code 2019 Day 18 Part 2"

class AOCManyWorldsSeed(FreeText):
    display_name = "Seed"
    
    def __init__(self, value: str):
        assert isinstance(value, str), "value of FreeText must be a string"
        assert int(value) >= 0, "value of gameseed must be a 64-bit unsigned integer"
        self.value = value

@dataclass
class AOCManyWorldsOptions(PerGameCommonOptions):
    gameseed: AOCManyWorldsSeed

class AOCManyWorldsWeb(WebWorld):
    tutorials = [Tutorial(
        "Multiworld Setup Guide",
        "A guide to setting up Advent of Code 2019 Day 18 Part 2 for Multiworld.",
        "English",
        "setup_en.md",
        "setup/en",
        ["M1n3c4rt"]
    )]

class AOCManyWorldsWorld(World):
    game: str = "Advent of Code 2019 Day 18 Part 2"
    topology_present = False
    web = WebWorld()

    item_id_to_name = {ord(c):c for c in "abcdefghijklmnopqrstuvwxyz"}
    location_id_to_name = {ord(c):c for c in "abcdefghijklmnopqrstuvwxyz"}
    item_name_to_id = {c:ord(c) for c in "abcdefghijklmnopqrstuvwxyz"}
    location_name_to_id = {c:ord(c) for c in "abcdefghijklmnopqrstuvwxyz"}

    options_dataclass = AOCManyWorldsOptions
    options: AOCManyWorldsOptions

    def create_regions(self):
        menu = Region("Menu",self.player,self.multiworld)
        menu.locations += [AOCManyWorldsLocation(self.player, c, self.location_name_to_id[c], menu) for c in "abcdefghijklmnopqrstuvwxyz"]
        self.multiworld.regions.append(menu)

    def set_rules(self):
        logic = aoc_manyworlds.get_logic(int(self.options.gameseed))
        for k, ks in logic.items():
            add_rule(self.multiworld.get_location(k,self.player), lambda state: all(state.has(c,self.player) for c in ks))
        self.multiworld.completion_condition[self.player] = lambda state: all(state.has(c,self.player) for c in "abcdefghijklmnopqrstuvwxyz")

    def create_item(self, name):
        return AOCManyWorldsItem(name, ItemClassification.progression, self.item_name_to_id[name], self.player)
    
    def create_items(self):
        keys = [self.create_item(name) for name in "abcdefghijklmnopqrstuvwxyz"]
        print(len(keys))
        self.multiworld.itempool += keys

