use std::collections::{HashMap, HashSet};

use pyo3::prelude::*;
use rand::{SeedableRng, seq::IndexedRandom};
use rand_chacha::ChaCha8Rng;

#[pymodule]
mod aoc_manyworlds {
    use pyo3::prelude::*;

    use crate::{Grid, Logic};

    #[pyfunction]
    fn get_logic(seed : u64) -> PyResult<Logic> {
        Ok(Grid::generate_grid(seed).1)
    }
}

#[derive(Clone, Debug, PartialEq, Copy)]
enum Cell {
    Wall,
    Empty,
    Player(i16),
    Key(char),
    Door(char),
}

struct Grid {
    cart: Vec<Vec<Cell>>,
    tree: HashMap<(i16, i16), Option<(i16, i16)>>,
}
type KeyMap = HashMap<char, (i16, i16)>;
type DoorMap = HashMap<(i16, i16), char>;
type Logic = HashMap<char, Vec<char>>;

impl Grid {
    fn generate_grid(seed : u64) -> (Grid, Logic) {
        let mut rng = ChaCha8Rng::seed_from_u64(seed);
        let mut grid: Grid = Grid {
            cart: vec![vec![Cell::Wall; 81]; 81],
            tree: HashMap::new(),
        };

        for (xs, ys) in [(41, 41), (39, 41), (41, 39), (39, 39)] {
            grid.carve(xs, ys, xs == 41, ys == 41, &mut rng);
            grid.cart[ys as usize][xs as usize] =
                Cell::Player((xs == 41) as i16 + 2 * (ys == 41) as i16);
        }

        let mut placement: (Option<(KeyMap, DoorMap, Logic)>, usize) = (None, 0);
        let mut i = 0;

        let mut nodes: Vec<&(i16, i16)> = grid
            .tree
            .keys()
            .filter(|x| ![(41, 41), (39, 41), (41, 39), (39, 39)].contains(x))
            .collect();
        nodes.sort();
        while i < 100 || placement.0.is_none() {
            let mut iseq = nodes.choose_multiple(&mut rng, 52);//.choose_multiple(&mut rng, 52).into_iter();
            let mut keymap: HashMap<char, (i16, i16)> = HashMap::new();
            let mut doormap: HashMap<(i16, i16), char> = HashMap::new();

            for c in 'a'..='z' {
                let n1 = *iseq.next().unwrap(); // ⎫
                // ⎬ unwrap justification: iseq is guaranteed to be 52 elements long, same as 2 times 'a'..='z'
                let n2 = *iseq.next().unwrap(); // ⎭

                let mut current = n1;
                let mut behind = false;
                while let Some(Some(n)) = grid.tree.get(current) {
                    if n == n2 {
                        behind = true;
                        break;
                    } else {
                        current = n
                    }
                }

                keymap.insert(c, *if behind { n2 } else { n1 });
                doormap.insert(*if behind { n1 } else { n2 }, c);
            }

            let mut logic: HashMap<char, Vec<char>> = HashMap::new();
            for (k, v) in &keymap {
                let mut pathback = Vec::new();
                let mut current = v;
                while let Some(Some(n)) = grid.tree.get(current) {
                    match doormap.get(n) {
                        None => {}
                        Some(d) => pathback.push(*d),
                    }
                    current = n;
                }
                logic.insert(*k, pathback);
            }

            fn consistent(logic: &Logic) -> bool {
                let mut finished = HashSet::new();
                loop {
                    let mut possible = false;
                    for (k, v) in logic {
                        if v.iter().all(|x| finished.contains(x)) {
                            if !finished.contains(k) {
                                possible = true
                            };
                            finished.insert(*k);
                        }
                    }
                    if !possible {
                        return false;
                    };
                    if finished.len() == 26 {
                        return true;
                    }
                }
            }

            if consistent(&logic) {
                let sum: usize = logic.values().map(|v| v.len()).sum();
                if sum > placement.1 {
                    placement = (Some((keymap, doormap, logic)), sum);
                }
            }
            i += 1;
        }

        let (keymap, doormap, logic) = placement.0.unwrap(); // unwrap justification: the above loop will not terminate with placement.0 == None
        for (c, (x, y)) in keymap {
            grid.cart[y as usize][x as usize] = Cell::Key(c)
        }
        for ((x, y), c) in doormap {
            grid.cart[y as usize][x as usize] = Cell::Door(c)
        }
        (grid, logic)
    }

    fn carve(&mut self, x: i16, y: i16, dx: bool, dy: bool, rng : &mut ChaCha8Rng) {
        self.cart[y as usize][x as usize] = Cell::Empty;
        let mut stack: Vec<(i16, i16)> = Vec::new();
        stack.push((x, y));
        self.tree.insert((x, y), None);
        loop {
            let cur = stack.pop();
            match cur {
                None => break,
                Some((xc, yc)) => {
                    let valid_neighbour = |&&(xn, yn): &&(i16, i16)| {
                        self.cart
                            .get((2 * yn - yc) as usize)
                            .and_then(|v| v.get((2 * xn - xc) as usize))
                            == Some(&Cell::Wall)
                            && (xn == xc || ((xn > x) == dx))
                            && (yn == yc || ((yn > y) == dy))
                    };
                    let candidates = [(xc + 1, yc), (xc, yc + 1), (xc - 1, yc), (xc, yc - 1)];
                    let neighbours: Vec<(i16, i16)> =
                        candidates.iter().filter(valid_neighbour).copied().collect();
                    match neighbours.choose(rng) {
                        None => continue,
                        Some(&(xn, yn)) => {
                            stack.push((xc, yc));
                            stack.push((2 * xn - xc, 2 * yn - yc));
                            self.tree.insert((xn, yn), Some((xc, yc)));
                            self.tree.insert((2 * xn - xc, 2 * yn - yc), Some((xn, yn)));
                            self.cart[yn as usize][xn as usize] = Cell::Empty;
                            self.cart[(2 * yn - yc) as usize][(2 * xn - xc) as usize] = Cell::Empty;
                        }
                    }
                }
            }
        }
    }
}