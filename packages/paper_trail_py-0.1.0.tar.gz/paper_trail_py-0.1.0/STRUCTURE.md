# 🌳 PaperTrail-Py 项目结构树

```
paper-trail-py/
│
├── 📦 src/paper_trail/              核心源码目录
│   ├── __init__.py                  公共 API 导出
│   ├── models.py                    Version 数据模型 [JSON存储]
│   ├── decorators.py                @track_versions 装饰器
│   ├── context.py                   Whodunnit + 事务分组
│   ├── query.py                     VersionQuery 查询 API
│   ├── reify.py                     版本恢复功能
│   ├── serializers.py               对象序列化器
│   ├── config.py                    全局配置管理
│   ├── async_support.py             AsyncSession 支持
│   └── performance.py               批量操作 + 性能优化
│
├── 🧪 tests/                        测试套件
│   ├── conftest.py                  Pytest 配置 + fixtures
│   ├── test_decorators.py           装饰器功能测试
│   ├── test_query.py                查询 API 测试
│   ├── test_reify.py                版本恢复测试
│   ├── test_context.py              上下文管理测试
│   └── test_performance.py          性能优化测试
│
├── 📚 examples/                     使用示例
│   └── complete_example.py          10个完整功能演示
│
├── 📖 docs/                         文档目录
│   ├── README.md                    项目主页 [必读]
│   ├── ARCHITECTURE.md              架构设计文档 [核心]
│   ├── QUICKSTART.md                5分钟快速入门
│   ├── CONTRIBUTING.md              贡献指南
│   ├── PROJECT_SUMMARY.md           项目完成总结
│   └── INDEX.md                     项目索引导航
│
├── ⚙️ 配置文件/
│   ├── pyproject.toml               uv 项目配置 + 依赖
│   ├── Makefile                     开发命令集合
│   ├── .gitignore                   Git 忽略规则
│   ├── .pre-commit-config.yaml      Pre-commit hooks
│   └── LICENSE                      MIT 许可证
│
├── 🤖 .github/workflows/            CI/CD 工作流
│   ├── ci.yml                       持续集成（测试+lint）
│   └── publish.yml                  PyPI 自动发布
│
└── 🛠️ scripts/                      工具脚本
    └── setup.sh                     快速环境设置
```

---

## 📊 模块依赖关系

```
┌─────────────────────────────────────────────────────────┐
│                   PaperTrail Public API                  │
│                    (__init__.py)                         │
└──────────────────────┬──────────────────────────────────┘
                       │
         ┌─────────────┼─────────────┐
         │             │             │
         ▼             ▼             ▼
    ┌─────────┐  ┌─────────┐  ┌──────────┐
    │ models  │  │decorators│  │  query   │
    │ Version │  │@track_   │  │ Version  │
    │         │  │versions  │  │ Query    │
    └────┬────┘  └────┬─────┘  └────┬─────┘
         │            │              │
         │            ▼              │
         │      ┌──────────┐         │
         │      │serializers│        │
         │      │  Default │         │
         │      │  Custom  │         │
         │      └────┬─────┘         │
         │           │               │
         └───────────┼───────────────┘
                     │
         ┌───────────┼───────────┐
         │           │           │
         ▼           ▼           ▼
    ┌────────┐  ┌────────┐  ┌───────────┐
    │context │  │ reify  │  │performance│
    │whodunnit  │restore │  │  batch    │
    │  tx_id │  │ diff   │  │ cleanup   │
    └────────┘  └────────┘  └───────────┘
         │
         ▼
    ┌────────┐
    │ config │
    │configure│
    └────────┘
```

---

## 🔄 数据流图

### 版本追踪流程

```
┌──────────┐
│  Model   │ Article, Post, etc.
│ @track_  │
│ versions │
└─────┬────┘
      │
      │ 1. INSERT/UPDATE/DELETE
      ▼
┌─────────────────┐
│  SQLAlchemy     │
│  Event System   │
│  - after_insert │
│  - after_update │
│  - after_delete │
└────────┬────────┘
         │
         │ 2. Trigger Event
         ▼
┌──────────────────┐
│   Decorators     │
│ _create_version_ │
│   on_insert()    │
│   on_update()    │
│   on_delete()    │
└────────┬─────────┘
         │
         │ 3. Serialize Object
         ▼
┌──────────────────┐
│   Serializers    │
│ - serialize()    │
│ - get_changes()  │
└────────┬─────────┘
         │
         │ 4. Get Context
         ▼
┌──────────────────┐
│    Context       │
│ - whodunnit      │
│ - transaction_id │
└────────┬─────────┘
         │
         │ 5. Create Version Record
         ▼
┌──────────────────┐
│   Version Model  │
│   INSERT INTO    │
│    versions      │
└──────────────────┘
```

### 查询流程

```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │
       │ 1. Build Query
       ▼
┌──────────────────┐
│  VersionQuery    │
│ .for_model()     │
│ .by_user()       │
│ .between()       │
│ .limit()         │
└────────┬─────────┘
         │
         │ 2. Execute
         ▼
┌──────────────────┐
│   SQLAlchemy     │
│   SELECT FROM    │
│    versions      │
│   WHERE ...      │
└────────┬─────────┘
         │
         │ 3. Return Results
         ▼
┌──────────────────┐
│ List[Version]    │
└──────────────────┘
```

### 恢复流程

```
┌─────────────┐
│   Version   │
│   Record    │
└──────┬──────┘
       │
       │ 1. Extract Snapshot
       ▼
┌──────────────────┐
│     Reify        │
│ reify_version()  │
└────────┬─────────┘
         │
         │ 2. Get/Create Object
         ▼
┌──────────────────┐
│  session.get()   │
│  or Model()      │
└────────┬─────────┘
         │
         │ 3. Restore Fields
         ▼
┌──────────────────┐
│  setattr(obj)    │
│  for each field  │
└────────┬─────────┘
         │
         │ 4. Commit (optional)
         ▼
┌──────────────────┐
│  session.commit()│
└──────────────────┘
```

---

## 🎯 功能模块图

```
                    ┌─────────────────────────┐
                    │   PaperTrail Core       │
                    └───────────┬─────────────┘
                                │
                ┌───────────────┼───────────────┐
                │               │               │
                ▼               ▼               ▼
        ┌──────────────┐ ┌──────────┐ ┌────────────┐
        │   Tracking   │ │  Query   │ │  Restore   │
        │              │ │          │ │            │
        │ @track_vers  │ │ Version  │ │  reify_    │
        │   ignore     │ │  Query   │ │  version   │
        │   only       │ │  filter  │ │            │
        └──────────────┘ └──────────┘ └────────────┘
                │               │               │
                └───────────────┼───────────────┘
                                │
                ┌───────────────┼───────────────┐
                │               │               │
                ▼               ▼               ▼
        ┌──────────────┐ ┌──────────┐ ┌────────────┐
        │   Context    │ │Serialize │ │Performance │
        │              │ │          │ │            │
        │  whodunnit   │ │  Default │ │  batch     │
        │  tx_group    │ │  Custom  │ │  cleanup   │
        └──────────────┘ └──────────┘ └────────────┘
                                │
                                ▼
                        ┌──────────────┐
                        │    Config    │
                        │   configure  │
                        └──────────────┘
```

---

## 📦 部署架构

```
┌─────────────────────────────────────────────┐
│            Application Layer                │
│  ┌────────────────────────────────────┐     │
│  │      Your SQLAlchemy Models        │     │
│  │  @track_versions decorated         │     │
│  └──────────────┬─────────────────────┘     │
│                 │                            │
└─────────────────┼────────────────────────────┘
                  │
┌─────────────────┼────────────────────────────┐
│                 ▼                            │
│         PaperTrail Library                   │
│  ┌─────────────────────────────────┐         │
│  │  Decorators + Event Listeners   │         │
│  └──────────────┬──────────────────┘         │
│                 │                            │
│                 ▼                            │
│  ┌─────────────────────────────────┐         │
│  │      Version Records            │         │
│  │   (JSON snapshots + changes)    │         │
│  └──────────────┬──────────────────┘         │
└─────────────────┼────────────────────────────┘
                  │
┌─────────────────┼────────────────────────────┐
│                 ▼                            │
│           Database Layer                     │
│  ┌──────────────────────────────┐            │
│  │   Your Business Tables       │            │
│  │   - articles                 │            │
│  │   - posts                    │            │
│  │   - ...                      │            │
│  └──────────────────────────────┘            │
│                                              │
│  ┌──────────────────────────────┐            │
│  │   Versions Table             │            │
│  │   - id                       │            │
│  │   - item_type, item_id       │            │
│  │   - event, whodunnit         │            │
│  │   - object, object_changes   │            │
│  │   - created_at               │            │
│  └──────────────────────────────┘            │
└─────────────────────────────────────────────┘
```

---

## 🔧 开发工具链

```
┌────────────────────────────────────────────┐
│            Source Code                     │
│         src/paper_trail/                   │
└──────────────┬─────────────────────────────┘
               │
               │ ← Format
               ▼
     ┌──────────────────┐
     │  Black + isort   │
     └──────────┬───────┘
                │
                │ ← Lint
                ▼
     ┌──────────────────┐
     │      Ruff        │
     └──────────┬───────┘
                │
                │ ← Type Check
                ▼
     ┌──────────────────┐
     │      MyPy        │
     └──────────┬───────┘
                │
                │ ← Test
                ▼
     ┌──────────────────┐
     │  Pytest + Cov    │
     └──────────┬───────┘
                │
                │ ← CI/CD
                ▼
     ┌──────────────────┐
     │ GitHub Actions   │
     └──────────┬───────┘
                │
                │ ← Build
                ▼
     ┌──────────────────┐
     │       uv         │
     └──────────┬───────┘
                │
                │ ← Publish
                ▼
     ┌──────────────────┐
     │      PyPI        │
     └──────────────────┘
```

---

**文档版本**: 1.0  
**最后更新**: 2026-01-07
