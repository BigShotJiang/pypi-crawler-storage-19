/* Capacity benchmark runner.
 * Incrementally tests capacity from RAMP_START to RAMP_END (target += 1 each step).
 * Stops when first failure occurs and reports max successful target + avg execution latency.
 */

import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';

// Minimum success rate to consider a target successful (allows some failures)
const MIN_SUCCESS_RATE = 99;

// Configuration mappings
const clusterNameToSettings = {
  'dr-small': {
    url: 'https://cap-bench-dr-small-716e6300275c5afb9979420a8f2684af.staging.langgraph.app',
    rampStartMultiplier: 1,
  },
  'dr-medium': {
    url: 'https://cap-bench-dr-medium-a7730894248e5aa081e650143f57318f.staging.langgraph.app',
    rampStartMultiplier: 2,
  },
  'dr-large': {
    url: 'https://cap-bench-dr-large-102fbff4d1d95711822e4b6c2d9796f0.staging.langgraph.app',
    rampStartMultiplier: 3,
  },
  'py-small': {
    url: 'https://cap-bench-py-runtime-small-c335b303529259e79c55fa5818911aea.staging.langgraph.app',
    rampStartMultiplier: 1,
  },
  'py-medium': {
    url: 'https://cap-bench-py-runtime-medium-5ad796530c8354eea67f82c3a482bc7b.staging.langgraph.app',
    rampStartMultiplier: 2,
  },
  'py-large': {
    url: 'https://cap-bench-py-runtime-large-7721dd6d7a9e5260b47a551e82ae5865.staging.langgraph.app',
    rampStartMultiplier: 3,
  },
};

const workloadNameToAgentParams = {
  'sequential-small': {
    expand: 1,
    steps: 10,
    dataSize: 100000, // 100KB per step × 10 steps = 1MB total
    delay: 0,
    rampStartBase: 10,
    rampEnd: 1000,
    runExecutionTimeoutSeconds: 10,
  },
  // TODO: there is a bug somewhere! this workload cannot return(but the run is successful)
  // 'sequential-medium': {
  //   expand: 1,
  //   steps: 10,
  //   dataSize: 1000000, // 1MB per step × 10 steps = 10MB total
  //   delay: 0,
  //   rampStartBase: 3,
  //   rampEnd: 1000,
  //   runExecutionTimeoutSeconds: 60,
  // },
  // 'sequential-large': {
  //   expand: 1,
  //   steps: 10,
  //   dataSize: 10000000, // 10MB per step × 10 steps = 100MB total
  //   delay: 0,
  //   rampStartBase: 1,
  //   rampEnd: 1000,
  //   runExecutionTimeoutSeconds: 10,
  // },
  'parallel-small': {
    expand: 2,
    steps: 100,
    dataSize: 10000, // 10KB per step × 100 steps = 1MB total
    delay: 0,
    rampStartBase: 2,
    rampEnd: 1000,
    runExecutionTimeoutSeconds: 30,
  },
  // 'parallel-medium': {
  //   expand: 10,
  //   steps: 500,
  //   dataSize: 100000, // 100KB per step × 500 steps = 50MB total
  //   delay: 0,
  //   rampStartBase: 5,
  //   rampEnd: 1000,
  //   runExecutionTimeoutSeconds: 10,
  // },
  // 'parallel-large': {
  //   expand: 10,
  //   steps: 500,
  //   dataSize: 1000000, // 1MB per step × 500 steps = 500MB total
  //   delay: 0,
  //   rampStartBase: 2,
  //   rampEnd: 1000,
  //   runExecutionTimeoutSeconds: 10,
  // },
};

// Environment variables
const CLUSTER_NAME = process.env.CLUSTER_NAME;
const WORKLOAD_NAME = process.env.WORKLOAD_NAME;

// Validate inputs
validateInputs();

// Get workload configuration
const workloadConfig = workloadNameToAgentParams[WORKLOAD_NAME];
const clusterSettings = clusterNameToSettings[CLUSTER_NAME];
const RAMP_START = workloadConfig.rampStartBase * clusterSettings.rampStartMultiplier;
const RAMP_END = workloadConfig.rampEnd;

console.log(`\n=== Configuration ===`);
console.log(`Cluster: ${CLUSTER_NAME} (multiplier: ${clusterSettings.rampStartMultiplier}x)`);
console.log(`URL: ${clusterSettings.url}`);
console.log(`Workload: ${WORKLOAD_NAME}`);
console.log(`  - Ramp: ${RAMP_START} (${workloadConfig.rampStartBase} × ${clusterSettings.rampStartMultiplier}) → ${workloadConfig.rampEnd}`);
console.log(`  - Timeout: ${workloadConfig.runExecutionTimeoutSeconds}s`);
console.log(`  - Expand: ${workloadConfig.expand}`);
console.log(`  - Steps: ${workloadConfig.steps}`);
console.log(`  - Data Size: ${workloadConfig.dataSize} bytes`);
console.log(`  - Delay: ${workloadConfig.delay}s`);

// Main function
async function main() {
  let currentTarget = RAMP_START;
  let lastSuccessfulTarget = null;
  let lastSuccessfulLatency = null;
  
  while (currentTarget <= RAMP_END) {
    console.log(`\n=== Testing target: ${currentTarget} ===`);
    
    // Run K6
    console.log(`Running k6 with target=${currentTarget}...`);
    const result = runK6(currentTarget);
    
    // Check if k6 command failed (capacity limit reached)
    if (result === null) {
      console.log(`❌ Failed at target ${currentTarget}`);
      break;
    }
    
    // Parse JSON output
    const metrics = JSON.parse(result.stdout);
    
    // Check if succeeded (allow some failures, but must meet minimum success rate)
    if (metrics.successRate < MIN_SUCCESS_RATE || !metrics.avgExecutionLatencySeconds) {
      console.log(`❌ Failed at target ${currentTarget} (success rate: ${metrics.successRate.toFixed(2)}%, avg latency: ${metrics.avgExecutionLatencySeconds || 'N/A'})`);
      break;
    }
    
    // Record success
    lastSuccessfulTarget = currentTarget;
    lastSuccessfulLatency = metrics.avgExecutionLatencySeconds;
    console.log(`✅ Success: ${metrics.avgExecutionLatencySeconds.toFixed(3)}s avg latency (${metrics.successRate.toFixed(2)}% success rate)`);
    
    currentTarget += 1;
  }
  
  // Validate results
  if (lastSuccessfulTarget === null) {
    throw new Error('No successful runs - RAMP_START may be too high');
  }
  
  if (currentTarget > RAMP_END) {
    throw new Error(`Reached RAMP_END (${RAMP_END}) without finding capacity limit - increase RAMP_END`);
  }
  
  // Output final results (last successful target and its latency)
  const finalResult = {
    maxSuccessfulTarget: lastSuccessfulTarget,
    avgExecutionLatencySeconds: Number(lastSuccessfulLatency.toFixed(3)),
  };
  
  console.log('\n=== Final Results ===');
  console.log(JSON.stringify(finalResult, null, 2));
  
  // Write to file
  writeFileSync('capacity_summary.json', JSON.stringify(finalResult, null, 2));
  console.log('\nResults written to capacity_summary.json');
  
  return finalResult;
}

// Helper functions (in order of usage)

function validateInputs() {
  if (!CLUSTER_NAME || !clusterNameToSettings[CLUSTER_NAME]) {
    throw new Error(`Invalid CLUSTER_NAME: "${CLUSTER_NAME}". Must be one of: ${Object.keys(clusterNameToSettings).join(', ')}`);
  }
  if (!WORKLOAD_NAME || !workloadNameToAgentParams[WORKLOAD_NAME]) {
    throw new Error(`Invalid WORKLOAD_NAME: "${WORKLOAD_NAME}". Must be one of: ${Object.keys(workloadNameToAgentParams).join(', ')}`);
  }
}

function runK6(target) {
  const baseUrl = clusterNameToSettings[CLUSTER_NAME].url;
  const agentParams = workloadNameToAgentParams[WORKLOAD_NAME];
  
  let result; 
  try {
    result = execFileSync('k6', ['run', 'capacity_k6.js'], {
      cwd: process.cwd(),
      env: {
        ...process.env,
        BASE_URL: baseUrl,
        TARGET: String(target),
        DATA_SIZE: String(agentParams.dataSize),
        DELAY: String(agentParams.delay),
        EXPAND: String(agentParams.expand),
        STEPS: String(agentParams.steps),
        RUN_EXECUTION_TIMEOUT_SECONDS: String(agentParams.runExecutionTimeoutSeconds),
      },
      encoding: 'utf-8',
      stdio: ['inherit', 'pipe', 'inherit'],  // Inherit stdin and stderr, pipe stdout
    });
    } catch (error) {
      console.log(`\n⚠️  K6 failed at target=${target}`);
      console.error(error);
      return null;
    }
    
    // Print the output to console for visibility
    console.log(result);
    
    // Find the JSON line from handleSummary output
    const lines = result.split('\n');
    const jsonLine = lines.find(line => {
      const trimmed = line.trim();
      return trimmed.startsWith('{') && trimmed.includes('"target"');
    });
    
    if (!jsonLine) {
      throw new Error(`No JSON output found in k6 results. Output: ${result.substring(0, 500)}`);
    }
    
    return { stdout: jsonLine.trim() };
 
}



// Run
main().catch((e) => {
  console.error(`\nError: ${e.message}`);
  process.exit(1);
});