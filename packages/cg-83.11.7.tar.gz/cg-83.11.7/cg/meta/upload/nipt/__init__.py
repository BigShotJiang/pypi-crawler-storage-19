from .nipt import NiptUploadAPI
