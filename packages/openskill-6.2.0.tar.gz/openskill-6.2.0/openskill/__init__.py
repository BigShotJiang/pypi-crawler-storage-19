# Public API
__all__: list[str] = ["models"]


# Metadata
__version__ = "6.2.0"
__author__ = "Vivek Joshy"
__email__ = "git@vivekjoshy.com"
__copyright__ = "Copyright 2023 - 2025, Vivek Joshy"
__credits__ = ["Philihp Busby"]
__deprecated__ = False
__license__ = "MIT"
__maintainer__ = "Vivek Joshy"
__status__ = "Production"
