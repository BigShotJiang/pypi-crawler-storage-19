"""
Command-line interface for logowatch.

Provides a user-friendly CLI with rich colored output for log analysis.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from logowatch import __version__
from logowatch.analyzer import LogAnalyzer
from logowatch.config import (
    Config,
    load_config,
    load_legacy_config,
    convert_legacy_to_yaml,
    discover_config,
    CONFIG_FILE_NAMES,
)
from logowatch.models import AnalysisResult, RuleResult, Severity


console = Console()


def severity_style(severity: Severity) -> str:
    """Get Rich style for severity level."""
    styles = {
        Severity.ERROR: "bold red",
        Severity.WARNING: "bold yellow",
        Severity.INFO: "bold cyan",
    }
    return styles.get(severity, "white")


def severity_icon(severity: Severity) -> str:
    """Get icon for severity level."""
    icons = {
        Severity.ERROR: "[red]✗[/red]",
        Severity.WARNING: "[yellow]⚠[/yellow]",
        Severity.INFO: "[cyan]ℹ[/cyan]",
    }
    return icons.get(severity, "•")


def print_header() -> None:
    """Print the application header."""
    console.print()
    console.print(
        Panel(
            "[bold blue]LOGOWATCH[/bold blue] - Autonomous Log Analysis",
            subtitle=f"v{__version__}",
            box=box.DOUBLE,
        )
    )
    console.print()


def print_summary(result: AnalysisResult) -> None:
    """Print analysis summary."""
    table = Table(title="Analysis Summary", box=box.ROUNDED)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    table.add_row("Sources", ", ".join(result.sources_analyzed))
    table.add_row("Total Lines", f"{result.total_lines:,}")
    table.add_row("[red]Errors[/red]", f"[red]{result.total_errors:,}[/red]")
    table.add_row("[yellow]Warnings[/yellow]", f"[yellow]{result.total_warnings:,}[/yellow]")
    table.add_row("[cyan]Info[/cyan]", f"[cyan]{result.total_info:,}[/cyan]")

    if result.incremental:
        mode_text = "[green]INCREMENTAL[/green] (new errors only)"
    else:
        mode_text = "[dim]FULL[/dim] (all errors)"
    table.add_row("Mode", mode_text)

    if result.last_check:
        table.add_row("Last Check", result.last_check.strftime("%Y-%m-%d %H:%M:%S"))

    console.print(table)
    console.print()


def print_rule_result(rule_result: RuleResult, max_examples: int = 5) -> None:
    """Print results for a single rule."""
    rule = rule_result.rule
    icon = severity_icon(rule.severity)
    style = severity_style(rule.severity)

    # Header
    console.print(f"{icon} [{style}]{rule.description}[/{style}]: {rule_result.total_count}")

    # Show examples
    for match in rule_result.matches[:max_examples]:
        console.print(f"   [dim]│[/dim] {match.content[:120]}")

        # Show context before
        for ctx_line in match.context_before:
            console.print(f"   [dim]│  {ctx_line[:100]}[/dim]")

        # Show extracted values
        for name, value in match.extracted_values.items():
            console.print(f"   [dim]├─[/dim] [green]{name}:[/green] {value}")

        # Show context after
        for ctx_line in match.context_after:
            console.print(f"   [dim]│  {ctx_line[:100]}[/dim]")

    # Show remaining count
    remaining = rule_result.total_count - min(len(rule_result.matches), max_examples)
    if remaining > 0:
        console.print(f"   [dim]│[/dim] [cyan]... and {remaining} more[/cyan]")

    # Show aggregations
    if rule_result.aggregations:
        console.print(f"   [dim]├─[/dim] [bold]Distribution:[/bold]")
        for value, count in list(rule_result.aggregations.items())[:10]:
            console.print(f"   [dim]│[/dim]   {value}: {count}")

    # Show related patterns
    if rule_result.related_patterns:
        console.print(f"   [dim]├─[/dim] [bold]Related:[/bold]")
        for related in rule_result.related_patterns[:5]:
            console.print(f"   [dim]│[/dim]   {related[:80]}")

    console.print()


def print_results(result: AnalysisResult, max_examples: int = 5) -> None:
    """Print all results grouped by severity."""
    # Errors first
    errors = result.get_results_by_severity(Severity.ERROR)
    if errors:
        console.print("[bold red]─── ERRORS ───[/bold red]")
        console.print()
        for rule_result in errors:
            print_rule_result(rule_result, max_examples)

    # Warnings
    warnings = result.get_results_by_severity(Severity.WARNING)
    if warnings:
        console.print("[bold yellow]─── WARNINGS ───[/bold yellow]")
        console.print()
        for rule_result in warnings:
            print_rule_result(rule_result, max_examples)

    # Info
    infos = result.get_results_by_severity(Severity.INFO)
    if infos:
        console.print("[bold cyan]─── INFO ───[/bold cyan]")
        console.print()
        for rule_result in infos:
            print_rule_result(rule_result, max_examples)


def print_final_status(result: AnalysisResult) -> None:
    """Print final status message."""
    if result.total_errors == 0:
        console.print(
            Panel(
                "[bold green]✓ No critical errors found![/bold green]",
                box=box.ROUNDED,
            )
        )
    elif result.total_errors <= 10:
        console.print(
            Panel(
                f"[bold yellow]⚠ Found {result.total_errors} errors - review recommended[/bold yellow]",
                box=box.ROUNDED,
            )
        )
    else:
        console.print(
            Panel(
                f"[bold red]✗ Found {result.total_errors} errors - urgent attention needed![/bold red]",
                box=box.ROUNDED,
            )
        )


@click.group()
@click.version_option(version=__version__)
def main() -> None:
    """Logowatch - Autonomous log analysis with configurable pattern rules."""
    pass


@main.command()
@click.argument("config_path", type=click.Path(exists=True))
@click.option(
    "--limit", "-l",
    default=5,
    help="Max examples per rule (default: 5)",
)
@click.option(
    "--no-incremental",
    is_flag=True,
    help="Disable incremental mode (show all errors)",
)
@click.option(
    "--source", "-s",
    multiple=True,
    help="Analyze specific source(s) only",
)
@click.option(
    "--json", "output_json",
    is_flag=True,
    help="Output as JSON instead of rich text",
)
@click.option(
    "--cache-path", "-c",
    type=click.Path(),
    help="Custom path for cache file",
)
def analyze(
    config_path: str,
    limit: int,
    no_incremental: bool,
    source: tuple[str, ...],
    output_json: bool,
    cache_path: Optional[str],
) -> None:
    """Analyze logs using configuration file."""
    config = load_config(config_path)
    cache = Path(cache_path) if cache_path else None

    analyzer = LogAnalyzer(
        config,
        cache_path=cache,
        incremental=not no_incremental,
    )

    sources = list(source) if source else None
    result = analyzer.analyze(source_names=sources, max_examples=limit)

    if output_json:
        import json
        click.echo(json.dumps(result.model_dump(mode="json"), indent=2, default=str))
    else:
        print_header()
        print_summary(result)
        print_results(result, max_examples=limit)
        print_final_status(result)


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option(
    "--pattern", "-p",
    multiple=True,
    help="Pattern(s) to search for",
)
@click.option(
    "--limit", "-l",
    default=10,
    help="Max matches to show (default: 10)",
)
@click.option(
    "--config", "-c",
    type=click.Path(),
    help="Config file (auto-discovers .logowatch.yaml if not specified)",
)
def scan(
    file_path: str,
    pattern: tuple[str, ...],
    limit: int,
    config: Optional[str],
) -> None:
    """Quick scan of a single log file for patterns.

    Auto-discovers .logowatch.yaml in the log file's directory or parent dirs.
    """
    from logowatch.models import Rule, LogSource

    # Try to auto-discover config adjacent to the log file
    config_obj: Config | None = None
    config_path: Path | None = None

    if config:
        config_path = Path(config)
        config_obj = load_config(config_path)
        console.print(f"[dim]Using config:[/dim] {config_path}")
    else:
        # Auto-discover config near the log file
        config_path = discover_config(start_path=file_path)
        if config_path:
            config_obj = load_config(config_path)
            console.print(f"[dim]Auto-discovered config:[/dim] {config_path}")

    # Determine rules to use
    if pattern:
        # User specified patterns - use those
        rules = [
            Rule(pattern=p, description=f"Pattern: {p}", severity=Severity.INFO)
            for p in pattern
        ]
    elif config_obj and config_obj.rules:
        # Use rules from discovered/specified config
        rules = config_obj.rules
    else:
        # Default patterns
        rules = [
            Rule(pattern=r"ERROR", description="Errors", severity=Severity.ERROR),
            Rule(pattern=r"WARNING", description="Warnings", severity=Severity.WARNING),
            Rule(pattern=r"Exception|Traceback", description="Exceptions", severity=Severity.ERROR),
        ]

    # Create config if not loaded
    if config_obj is None:
        config_obj = Config(rules=rules)

    analyzer = LogAnalyzer(config_obj, incremental=False)
    result = analyzer.analyze_file(file_path, rules)

    print_header()
    print_summary(result)
    print_results(result, max_examples=limit)


@main.command()
@click.option(
    "--limit", "-l",
    default=5,
    help="Max examples per rule (default: 5)",
)
@click.option(
    "--no-incremental",
    is_flag=True,
    help="Disable incremental mode (show all errors)",
)
@click.option(
    "--json", "output_json",
    is_flag=True,
    help="Output as JSON instead of rich text",
)
def run(
    limit: int,
    no_incremental: bool,
    output_json: bool,
) -> None:
    """Run analysis with auto-discovered config.

    Searches for .logowatch.yaml in current directory and parent dirs.
    """
    config_path = discover_config()

    if not config_path:
        console.print(f"[red]Error:[/red] No config file found.")
        console.print(f"[dim]Searched for:[/dim] {', '.join(CONFIG_FILE_NAMES)}")
        console.print()
        console.print("Create one with: [bold]logowatch init[/bold]")
        raise SystemExit(1)

    console.print(f"[dim]Using config:[/dim] {config_path}")

    config = load_config(config_path)
    cache_dir = config.cache_dir or config_path.parent
    cache_file = cache_dir / ".logowatch_cache.json"

    analyzer = LogAnalyzer(
        config,
        cache_path=cache_file,
        incremental=not no_incremental,
    )

    result = analyzer.analyze(max_examples=limit)

    if output_json:
        import json
        click.echo(json.dumps(result.model_dump(mode="json"), indent=2, default=str))
    else:
        print_header()
        print_summary(result)
        print_results(result, max_examples=limit)
        print_final_status(result)


@main.command()
@click.argument("rules_path", type=click.Path(exists=True))
@click.option(
    "--output", "-o",
    type=click.Path(),
    help="Output YAML file path",
)
def convert(
    rules_path: str,
    output: Optional[str],
) -> None:
    """Convert legacy pipe-delimited config to YAML."""
    yaml_content = convert_legacy_to_yaml(rules_path, output_path=output)

    if output:
        console.print(f"[green]✓[/green] Converted to: {output}")
    else:
        console.print(yaml_content)


@main.command()
def init() -> None:
    """Create a sample configuration file."""
    sample_config = """# Logowatch Configuration
# See: https://github.com/lifeaitools/logowatch

sources:
  - name: app
    path: /var/log/app.log
    type: file

  - name: errors
    path: /var/log/app/errors/
    type: directory
    pattern: "*.log"

rules:
  # Critical errors
  - pattern: "ERROR|CRITICAL"
    description: "Application errors"
    severity: error
    source: app
    options:
      context:
        after: 3

  # Warnings
  - pattern: "WARNING"
    description: "Warnings"
    severity: warning
    source: app

  # Exceptions with traceback
  - pattern: "Traceback"
    description: "Python exceptions"
    severity: error
    source: app
    options:
      context:
        after: 10

  # Connection issues
  - pattern: "Connection|Timeout|refused"
    description: "Connection issues"
    severity: warning
    source: app
    case_insensitive: true

  # Extract IDs from errors
  - pattern: "user_id=\\\\d+"
    description: "Errors with user IDs"
    severity: error
    source: app
    options:
      extract:
        pattern: "user_id=(\\\\d+)"
        name: "user_id"
      aggregate:
        by: "(\\\\d+)"
        format: count
"""

    output_path = Path("logowatch.yaml")
    if output_path.exists():
        if not click.confirm(f"{output_path} exists. Overwrite?"):
            return

    output_path.write_text(sample_config)
    console.print(f"[green]✓[/green] Created: {output_path}")
    console.print()
    console.print("Edit the file to configure your log sources and rules.")
    console.print("Then run: [bold]logowatch analyze logowatch.yaml[/bold]")


if __name__ == "__main__":
    main()
