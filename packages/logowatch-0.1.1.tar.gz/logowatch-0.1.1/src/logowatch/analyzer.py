"""
Core log analysis engine for logowatch.

The LogAnalyzer class provides pattern-based log analysis with:
- Regex pattern matching
- Context extraction (lines before/after)
- Value extraction from matches
- Aggregation by extracted values
- Incremental detection (new errors only)
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Iterator

from logowatch.config import Config
from logowatch.models import (
    AnalysisCache,
    AnalysisResult,
    LogSource,
    Match,
    Rule,
    RuleResult,
    Severity,
)


class LogAnalyzer:
    """
    Main log analysis engine.

    Analyzes log files based on configured rules and produces structured results.
    Supports incremental analysis to show only new errors since last check.
    """

    def __init__(
        self,
        config: Config,
        cache_path: Path | None = None,
        incremental: bool = True,
    ) -> None:
        """
        Initialize the analyzer.

        Args:
            config: Configuration with sources and rules
            cache_path: Path to store incremental cache (default: .logowatch_cache.json)
            incremental: Enable incremental mode (only show new errors)
        """
        self.config = config
        self.cache_path = cache_path or Path(".logowatch_cache.json")
        self.incremental = incremental
        self._cache: AnalysisCache | None = None

    @property
    def cache(self) -> AnalysisCache:
        """Get or load the cache."""
        if self._cache is None:
            self._cache = self._load_cache()
        return self._cache

    def _load_cache(self) -> AnalysisCache:
        """Load cache from file or create new one."""
        if self.cache_path.exists():
            try:
                data = json.loads(self.cache_path.read_text())
                return AnalysisCache.model_validate(data)
            except (json.JSONDecodeError, ValueError):
                pass
        return AnalysisCache()

    def _save_cache(self) -> None:
        """Save cache to file."""
        if self._cache:
            self.cache_path.write_text(
                json.dumps(self._cache.model_dump(mode="json"), indent=2, default=str)
            )

    def _get_file_hash(self, path: Path) -> str:
        """Get file hash for change detection (uses mtime + size)."""
        if not path.exists():
            return "missing"
        stat = path.stat()
        return f"{stat.st_mtime}_{stat.st_size}_{stat.st_ino}"

    def _get_files_for_source(self, source: LogSource) -> Iterator[Path]:
        """Get all files for a log source."""
        path = Path(source.path)

        if source.type == "file":
            if path.exists():
                yield path
        elif source.type == "directory":
            if path.is_dir():
                pattern = source.pattern or "*.log"
                yield from sorted(path.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
        elif source.type == "glob":
            if source.pattern:
                yield from sorted(Path().glob(source.pattern), key=lambda p: p.stat().st_mtime, reverse=True)

    def _read_file_lines(
        self,
        path: Path,
        start_line: int = 0,
        encoding: str = "utf-8",
    ) -> list[str]:
        """Read file lines, optionally starting from a specific line."""
        try:
            with open(path, encoding=encoding, errors="replace") as f:
                lines = f.readlines()
            if start_line > 0:
                return lines[start_line:]
            return lines
        except OSError:
            return []

    def _match_pattern(
        self,
        pattern: str,
        line: str,
        case_insensitive: bool = False,
    ) -> re.Match[str] | None:
        """Match a pattern against a line."""
        flags = re.IGNORECASE if case_insensitive else 0
        try:
            return re.search(pattern, line, flags)
        except re.error:
            return None

    def _extract_value(self, pattern: str, line: str) -> str | None:
        """Extract value using regex with capture group."""
        try:
            match = re.search(pattern, line)
            if match:
                # Return first capture group if exists, else full match
                groups = match.groups()
                return groups[0] if groups else match.group(0)
        except re.error:
            pass
        return None

    def _get_context(
        self,
        all_lines: list[str],
        line_idx: int,
        before: int = 0,
        after: int = 0,
    ) -> tuple[list[str], list[str]]:
        """Get context lines before and after a match."""
        start = max(0, line_idx - before)
        end = min(len(all_lines), line_idx + after + 1)

        context_before = [l.rstrip() for l in all_lines[start:line_idx]]
        context_after = [l.rstrip() for l in all_lines[line_idx + 1:end]]

        return context_before, context_after

    def _find_related(
        self,
        all_lines: list[str],
        line_idx: int,
        pattern: str,
        lines: int = 3,
        direction: str = "after",
    ) -> list[str]:
        """Find related patterns near a match."""
        related: list[str] = []

        if direction in ("before", "both"):
            start = max(0, line_idx - lines)
            for i in range(start, line_idx):
                if re.search(pattern, all_lines[i]):
                    related.append(all_lines[i].rstrip())

        if direction in ("after", "both"):
            end = min(len(all_lines), line_idx + lines + 1)
            for i in range(line_idx + 1, end):
                if re.search(pattern, all_lines[i]):
                    related.append(all_lines[i].rstrip())

        return related

    def _analyze_rule(
        self,
        rule: Rule,
        source: LogSource,
        all_lines: list[str],
        file_path: Path,
        start_line: int = 0,
    ) -> RuleResult:
        """Analyze a single rule against file lines."""
        matches: list[Match] = []
        aggregations: Counter[str] = Counter()
        related_patterns: list[str] = []
        total_count = 0

        # Options
        options = rule.options
        context_before = options.context.before if options and options.context else 0
        context_after = options.context.after if options and options.context else 0

        for idx, line in enumerate(all_lines):
            if not self._match_pattern(rule.pattern, line, rule.case_insensitive):
                continue

            total_count += 1
            actual_line_num = start_line + idx + 1

            # Limit matches stored in memory
            if len(matches) < 100:
                ctx_before, ctx_after = self._get_context(
                    all_lines, idx, context_before, context_after
                )

                # Extract values if configured
                extracted: dict[str, str] = {}
                if options and options.extract:
                    value = self._extract_value(options.extract.pattern, line)
                    if value:
                        extracted[options.extract.name] = value

                # Find related patterns
                if options and options.find_related:
                    related = self._find_related(
                        all_lines,
                        idx,
                        options.find_related.pattern,
                        options.find_related.lines,
                        options.find_related.direction,
                    )
                    related_patterns.extend(related)

                matches.append(
                    Match(
                        rule_id=rule.id,
                        line_number=actual_line_num,
                        content=line.rstrip(),
                        source_file=file_path,
                        context_before=ctx_before,
                        context_after=ctx_after,
                        extracted_values=extracted,
                    )
                )

            # Aggregate if configured
            if options and options.aggregate:
                agg_value = self._extract_value(options.aggregate.by, line)
                if agg_value:
                    aggregations[agg_value] += 1

        return RuleResult(
            rule=rule,
            total_count=total_count,
            new_count=total_count,  # All are "new" relative to start_line
            matches=matches,
            aggregations=dict(aggregations.most_common(50)),
            related_patterns=list(set(related_patterns))[:20],
        )

    def analyze(
        self,
        source_names: list[str] | None = None,
        max_examples: int = 20,
    ) -> AnalysisResult:
        """
        Run the analysis.

        Args:
            source_names: Specific sources to analyze (None = all)
            max_examples: Maximum examples to include per rule

        Returns:
            AnalysisResult with all findings
        """
        result = AnalysisResult(
            timestamp=datetime.now(),
            incremental=self.incremental,
            last_check=self.cache.last_check,
        )

        # Determine which sources to analyze
        sources = self.config.sources
        if source_names:
            sources = [s for s in sources if s.name in source_names]

        for source in sources:
            result.sources_analyzed.append(source.name)
            rules = self.config.get_rules_for_source(source.name)

            for file_path in self._get_files_for_source(source):
                file_hash = self._get_file_hash(file_path)
                cached_lines = 0

                if self.incremental:
                    cached_lines = self.cache.get_cached_line_count(str(file_path), file_hash)

                # Read all lines for context
                all_lines = self._read_file_lines(file_path, encoding=source.encoding)
                result.total_lines += len(all_lines)

                # For incremental, only analyze new lines
                lines_to_analyze = all_lines[cached_lines:] if cached_lines > 0 else all_lines
                start_line = cached_lines

                for rule in rules:
                    rule_result = self._analyze_rule(
                        rule, source, lines_to_analyze, file_path, start_line
                    )

                    if rule_result.total_count > 0:
                        # Limit examples
                        rule_result.matches = rule_result.matches[:max_examples]

                        # Update severity counts
                        if rule.severity == Severity.ERROR:
                            result.total_errors += rule_result.total_count
                        elif rule.severity == Severity.WARNING:
                            result.total_warnings += rule_result.total_count
                        else:
                            result.total_info += rule_result.total_count

                        result.rule_results.append(rule_result)

                # Update cache
                if self.incremental:
                    self.cache.update_entry(str(file_path), len(all_lines), file_hash)

        # Save cache
        if self.incremental:
            self._save_cache()

        return result

    def analyze_file(
        self,
        file_path: Path | str,
        rules: list[Rule] | None = None,
    ) -> AnalysisResult:
        """
        Analyze a single file with specified rules.

        Args:
            file_path: Path to the log file
            rules: Rules to apply (default: all rules)

        Returns:
            AnalysisResult with findings
        """
        file_path = Path(file_path)
        rules = rules or self.config.rules

        result = AnalysisResult(
            timestamp=datetime.now(),
            sources_analyzed=[str(file_path)],
        )

        all_lines = self._read_file_lines(file_path)
        result.total_lines = len(all_lines)

        dummy_source = LogSource(name="direct", path=file_path, type="file")

        for rule in rules:
            rule_result = self._analyze_rule(rule, dummy_source, all_lines, file_path)

            if rule_result.total_count > 0:
                if rule.severity == Severity.ERROR:
                    result.total_errors += rule_result.total_count
                elif rule.severity == Severity.WARNING:
                    result.total_warnings += rule_result.total_count
                else:
                    result.total_info += rule_result.total_count

                result.rule_results.append(rule_result)

        return result
