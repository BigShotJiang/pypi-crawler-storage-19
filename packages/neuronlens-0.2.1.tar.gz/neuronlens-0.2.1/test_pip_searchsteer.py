"""Test neuronlens search_features and steer_features functions."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Search & Steer ===\n")

# Test search_features
features = engine.search_features("financial analysis", k=3, layer=16)
print(f"✓ Search: {len(features)} features found")
if features:
    print(f"✓ Top feature: {features[0].get('label', 'N/A')[:40]}")

# Test steer_features
if features:
    result = engine.steer_features("What is inflation?", [{"id": features[0]["id"], "magnitude": 0.5}], model="meta-llama/Llama-2-7b-hf")
    print(f"✓ Steer: has_steering={result.get('has_steering', False)}")

engine.unload_all_models()
print("\n=== Search & Steer test passed ===")
