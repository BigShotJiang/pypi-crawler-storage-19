"""Test neuronlens analyze_reasoning function."""
import os
import sys
from pathlib import Path
import neuronlens

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

engine = neuronlens.Engine(api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY"))

print("=== Testing NeuronLens Reasoning Analysis ===\n")

result = engine.analyze_reasoning("What is 2+2? Show your reasoning.")
faithfulness = result.get('faithfulness', {})
print(f"✓ Faithfulness: {faithfulness.get('score', 0):.3f} ({faithfulness.get('level', 'N/A')})")

engine.unload_all_models()
print("\n=== Reasoning test passed ===")
