"""MichelangeloCC test suite."""
