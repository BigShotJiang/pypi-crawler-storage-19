"""Core Texting package."""
