"""
Base Middleware Class - Foundation for all middleware.
"""

from typing import Callable
import logging

logger = logging.getLogger(__name__)


class BaseMiddleware:
    """
    Base class for all middleware.
    
    Middleware process requests and responses in the ASGI application.
    They can modify requests before they reach the application and
    modify responses before they are sent to the client.
    """

    async def __call__(self, scope: dict, receive: Callable, send: Callable, app: Callable):
        """
        Process request through middleware.
        
        Args:
            scope: ASGI scope dictionary
            receive: ASGI receive callable
            send: ASGI send callable
            app: Next application/middleware in chain
        """
        # Default implementation: pass through to next middleware/app
        await app(scope, receive, send)

    def __repr__(self) -> str:
        """String representation of middleware."""
        return f"<{self.__class__.__name__}>"


# Legacy classes for backwards compatibility
class Middleware(BaseMiddleware):
    """Legacy middleware class (deprecated, use BaseMiddleware)."""

    async def process(self, request, call_next):
        """Process request (legacy method)."""
        return await call_next(request)


class MiddlewareStack:
    """
    Legacy middleware stack (deprecated, use MiddlewareChain).
    
    Kept for backwards compatibility.
    """

    def __init__(self):
        self.middlewares = []
        logger.info("Initialized MiddlewareStack (legacy)")

    def add(self, middleware):
        """Add middleware to stack."""
        self.middlewares.append(middleware)

    def add_function(self, func, middleware_type="http"):
        """Add middleware function."""
        self.middlewares.append(func)

    async def __call__(self, scope, receive, send, app):
        """Execute middleware stack."""
        return await app(scope, receive, send)
