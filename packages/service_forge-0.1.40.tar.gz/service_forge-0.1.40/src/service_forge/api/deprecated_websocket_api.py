from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import replace
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from loguru import logger
from opentelemetry import context as otel_context_api
from opentelemetry import propagate, trace

from service_forge.execution_context import (
    ExecutionContext,
    reset_current_context,
    set_current_context,
)

from .websocket_manager import websocket_manager

router = APIRouter(prefix="/ws", tags=["websocket"])
tracer = trace.get_tracer("service_forge.api.websocket")


@router.websocket("/connect")
async def websocket_endpoint(
    websocket: WebSocket, client_id: Optional[str] = Query(None)
):
    """WebSocket连接端点，支持指定客户端ID"""
    try:
        parent_context = propagate.extract(dict(websocket.headers))
    except Exception:
        parent_context = otel_context_api.get_current()
    if parent_context is None:
        parent_context = otel_context_api.get_current()

    span_name = f"WS {websocket.url.path}"
    with tracer.start_as_current_span(
        span_name,
        context=parent_context,
        kind=trace.SpanKind.SERVER,
    ) as span:
        if websocket.client:
            span.set_attribute("net.peer.ip", websocket.client.host)
        span.set_attribute("net.protocol.name", "websocket")
        span.set_attribute("net.host.port", websocket.url.port or 80)

        base_context = ExecutionContext(
            trace_context=otel_context_api.get_current(),
            span=span,
            logger=logger.bind(entrypoint="websocket"),
            metadata={
                "entrypoint": "websocket",
                "path": websocket.url.path,
            },
        )
        token = set_current_context(base_context)

        client_id = await websocket_manager.connect(websocket, client_id)
        span.set_attribute("client.id", client_id)

        execution_context = replace(
            base_context,
            metadata={**base_context.metadata, "client_id": client_id},
        )
        websocket_manager.set_context(client_id, execution_context)

        reset_current_context(token)
        token = set_current_context(execution_context)

        try:
            while True:
                data = await websocket.receive_text()
                try:
                    message = json.loads(data)
                    await handle_client_message(client_id, message)
                except json.JSONDecodeError:
                    logger.error(f"从客户端 {client_id} 收到无效JSON消息: {data}")
                    await websocket_manager.send_personal_message(
                        json.dumps({"error": "Invalid JSON format"}), client_id
                    )
        except WebSocketDisconnect:
            websocket_manager.disconnect(client_id)
        except Exception as e:
            logger.error(f"WebSocket连接处理异常: {e}")
            websocket_manager.disconnect(client_id)
        finally:
            reset_current_context(token)
            websocket_manager.clear_context(client_id)


async def handle_client_message(client_id: str, message: Dict[str, Any]):
    """处理来自客户端的消息"""
    message_type = message.get("type")

    if message_type == "subscribe":
        # 客户端订阅任务
        task_id_str = message.get("task_id")
        if not task_id_str:
            await websocket_manager.send_personal_message(
                json.dumps({"error": "Missing task_id in subscribe message"}), client_id
            )
            return

        try:
            task_id = uuid.UUID(task_id_str)
            success = await websocket_manager.subscribe_to_task(client_id, task_id)
            response = {"success": success}
            await websocket_manager.send_personal_message(
                json.dumps(response), client_id
            )
        except ValueError:
            await websocket_manager.send_personal_message(
                json.dumps({"error": "Invalid task_id format"}), client_id
            )

    elif message_type == "unsubscribe":
        # 客户端取消订阅任务
        task_id_str = message.get("task_id")
        if not task_id_str:
            await websocket_manager.send_personal_message(
                json.dumps({"error": "Missing task_id in unsubscribe message"}),
                client_id,
            )
            return

        try:
            task_id = uuid.UUID(task_id_str)
            success = await websocket_manager.unsubscribe_from_task(client_id, task_id)
            response = {"success": success}
            await websocket_manager.send_personal_message(
                json.dumps(response), client_id
            )
        except ValueError:
            await websocket_manager.send_personal_message(
                json.dumps({"error": "Invalid task_id format"}), client_id
            )

    else:
        await websocket_manager.send_personal_message(
            json.dumps({"error": f"Unknown message type: {message_type}"}), client_id
        )
