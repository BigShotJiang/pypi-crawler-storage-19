class BaseSensitivityAnalyzer:
    pass