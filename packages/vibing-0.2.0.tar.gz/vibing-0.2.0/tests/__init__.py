"""Tests for vibing package."""
