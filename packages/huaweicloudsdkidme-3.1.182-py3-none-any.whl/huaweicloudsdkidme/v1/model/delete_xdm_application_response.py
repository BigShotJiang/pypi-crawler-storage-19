# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteXdmApplicationResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'result': 'str',
        'error_msg': 'str'
    }

    attribute_map = {
        'result': 'result',
        'error_msg': 'error_msg'
    }

    def __init__(self, result=None, error_msg=None):
        r"""DeleteXdmApplicationResponse

        The model defined in huaweicloud sdk

        :param result: 返回结果。
        :type result: str
        :param error_msg: 错误信息。
        :type error_msg: str
        """
        
        super().__init__()

        self._result = None
        self._error_msg = None
        self.discriminator = None

        if result is not None:
            self.result = result
        if error_msg is not None:
            self.error_msg = error_msg

    @property
    def result(self):
        r"""Gets the result of this DeleteXdmApplicationResponse.

        返回结果。

        :return: The result of this DeleteXdmApplicationResponse.
        :rtype: str
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this DeleteXdmApplicationResponse.

        返回结果。

        :param result: The result of this DeleteXdmApplicationResponse.
        :type result: str
        """
        self._result = result

    @property
    def error_msg(self):
        r"""Gets the error_msg of this DeleteXdmApplicationResponse.

        错误信息。

        :return: The error_msg of this DeleteXdmApplicationResponse.
        :rtype: str
        """
        return self._error_msg

    @error_msg.setter
    def error_msg(self, error_msg):
        r"""Sets the error_msg of this DeleteXdmApplicationResponse.

        错误信息。

        :param error_msg: The error_msg of this DeleteXdmApplicationResponse.
        :type error_msg: str
        """
        self._error_msg = error_msg

    def to_dict(self):
        import warnings
        warnings.warn("DeleteXdmApplicationResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteXdmApplicationResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
