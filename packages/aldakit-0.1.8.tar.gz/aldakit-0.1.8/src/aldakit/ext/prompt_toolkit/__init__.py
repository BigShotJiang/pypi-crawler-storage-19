"""
prompt_toolkit
==============

Author: Jonathan Slenders

Description: prompt_toolkit is a Library for building powerful interactive
             command lines in Python.  It can be a replacement for GNU
             Readline, but it can be much more than that.

See the examples directory to learn about the usage.

Probably, to get started, you might also want to have a look at
`prompt_toolkit.shortcuts.prompt`.
"""

from __future__ import annotations

from .application import Application
from .formatted_text import ANSI, HTML
from .shortcuts import PromptSession, choice, print_formatted_text, prompt

# Vendored version - hardcoded
__version__ = "3.0.52"

# Version tuple.
VERSION = tuple(int(v.rstrip("abrc")) for v in __version__.split(".")[:3])


__all__ = [
    # Application.
    "Application",
    # Shortcuts.
    "prompt",
    "choice",
    "PromptSession",
    "print_formatted_text",
    # Formatted text.
    "HTML",
    "ANSI",
    # Version info.
    "__version__",
    "VERSION",
]
