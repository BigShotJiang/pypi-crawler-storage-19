// Copyright (c) Facebook, Inc. and its affiliates.
#pragma once

#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/stl_bind.h>

#include <vector>

#include "types.h"

namespace py = pybind11;

namespace coco_eval {

namespace COCOeval {

// Forward declaration
class LightweightDataset;

// Stores intermediate results for evaluating detection results for a single
// image that has D detected instances and G ground truth instances. This stores
// matches between detected and ground truth instances
struct ImageEvaluation {
        // For each of the D detected instances, the id of the matched ground
        // truth instance, or 0 if unmatched
        std::vector<int64_t> detection_matches;

        std::vector<int64_t> ground_truth_matches;
        // The detection score of each of the D detected instances
        std::vector<double> detection_scores;

        // Marks whether or not each of G instances was ignored from evaluation
        // (e.g., because it's outside area_range)
        std::vector<bool> ground_truth_ignores;

        // Marks whether or not each of D instances was ignored from evaluation
        // (e.g., because it's outside aRng)
        std::vector<bool> detection_ignores;

        std::vector<MatchedAnnotation> matched_annotations;
};

template <class T>
using ImageCategoryInstances = std::vector<std::vector<std::vector<T>>>;

// C++ implementation of COCO API cocoeval.py::COCOeval.evaluateImg().  For each
// combination of image, category, area range settings, and IOU thresholds to
// evaluate, it matches detected instances to ground truth instances and stores
// the results into a vector of ImageEvaluation results, which will be
// interpreted by the COCOeval::Accumulate() function to produce precion-recall
// curves.  The parameters of nested vectors have the following semantics:
//   image_category_ious[i][c][d][g] is the intersection over union of the d'th
//     detected instance and g'th ground truth instance of
//     category category_ids[c] in image image_ids[i]
//   image_category_ground_truth_instances[i][c] is a vector of ground truth
//     instances in image image_ids[i] of category category_ids[c]
//   image_category_detection_instances[i][c] is a vector of detected
//     instances in image image_ids[i] of category category_ids[c]
std::vector<ImageEvaluation> EvaluateImages(
    const std::vector<std::array<double, 2>>&
        area_ranges,  // vector of 2-tuples
    int max_detections, const std::vector<double>& iou_thresholds,
    const ImageCategoryInstances<std::vector<double>>& image_category_ious,
    const LightweightDataset& gt_dataset, const LightweightDataset& dt_dataset,
    const std::vector<double>& img_ids, const std::vector<double>& cat_ids,
    bool useCats);

// C++ implementation of COCOeval.accumulate(), which generates precision
// recall curves for each set of category, IOU threshold, detection area range,
// and max number of detections parameters.  It is assumed that the parameter
// evaluations is the return value of the functon COCOeval::EvaluateImages(),
// which was called with the same parameter settings params
py::dict Accumulate(const py::object& params,
                    const std::vector<ImageEvaluation>& evalutations);

py::dict EvaluateAccumulate(
    const py::object& params,
    const ImageCategoryInstances<std::vector<double>>& image_category_ious,
    const LightweightDataset& gt_dataset, const LightweightDataset& dt_dataset,
    const std::vector<double>& img_ids, const std::vector<double>& cat_ids,
    bool useCats);

long double calc_auc(const std::vector<long double>& recall_list,
                     const std::vector<long double>& precision_list);
}  // namespace COCOeval
}  // namespace coco_eval
