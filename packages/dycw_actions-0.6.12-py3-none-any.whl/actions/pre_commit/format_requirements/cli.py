from __future__ import annotations

from typing import TYPE_CHECKING

from utilities.logging import basic_config
from utilities.os import is_pytest
from utilities.text import strip_and_dedent

from actions import __version__
from actions.logging import LOGGER
from actions.pre_commit.click import path_argument
from actions.pre_commit.format_requirements.lib import format_requirements

if TYPE_CHECKING:
    from pathlib import Path


@path_argument
def format_requirements_sub_cmd(*, paths: tuple[Path, ...]) -> None:
    if is_pytest():
        return
    basic_config(obj=LOGGER)
    LOGGER.info(
        strip_and_dedent("""
            Running '%s' (version %s) with settings:
             - paths = %s
        """),
        format_requirements.__name__,
        __version__,
        paths,
    )
    format_requirements(*paths)


__all__ = ["format_requirements_sub_cmd"]
