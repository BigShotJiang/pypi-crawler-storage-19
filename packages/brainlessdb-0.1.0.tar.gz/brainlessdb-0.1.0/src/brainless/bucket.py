"""NATS JetStream KV bucket wrapper."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from nats.js.errors import BucketNotFoundError

if TYPE_CHECKING:
    from nats.js.kv import KeyValue

_log = logging.getLogger(__name__)


class Bucket:
    """Wrapper around NATS JetStream KV bucket

    Provides simple get/put/delete operations with JSON serialization.
    """

    def __init__(self, name: str, kv: KeyValue) -> None:
        self._name = name
        self._kv = kv

    @property
    def name(self) -> str:
        return self._name

    @classmethod
    async def create(
        cls,
        js: Any,
        name: str,
        ttl: float | None = None,
        max_bytes: int | None = None,
    ) -> Bucket:
        """Create or get existing KV bucket

        @param js: JetStream context
        @param name: Bucket name
        @param ttl: Time-to-live in seconds (optional)
        @param max_bytes: Max bucket size in bytes (optional)
        @return: Bucket instance
        """
        from nats.js.api import KeyValueConfig

        config = KeyValueConfig(bucket=name)
        if ttl is not None:
            config.ttl = ttl
        if max_bytes is not None:
            config.max_bytes = max_bytes

        try:
            kv = await js.key_value(name)
            _log.debug("Using existing bucket: %s", name)
        except BucketNotFoundError:
            kv = await js.create_key_value(config)
            _log.info("Created bucket: %s", name)

        return cls(name, kv)

    async def get(self, key: str) -> dict[str, Any] | None:
        """Get value by key

        @param key: Key to retrieve
        @return: Deserialized value or None if not found
        """
        try:
            entry = await self._kv.get(key)
            if entry is None or entry.value is None:
                return None
            envelope = json.loads(entry.value.decode())
            return envelope["data"]
        except Exception as e:
            if "not found" in str(e).lower():
                return None
            raise

    async def put(self, key: str, value: dict[str, Any]) -> None:
        """Store value by key

        @param key: Key to store
        @param value: Value to serialize and store
        """
        envelope = {"version": "1", "data": value}
        data = json.dumps(envelope).encode()
        await self._kv.put(key, data)

    async def delete(self, key: str) -> bool:
        """Delete key

        @param key: Key to delete
        @return: True if deleted, False if not found
        """
        try:
            await self._kv.delete(key)
            return True
        except Exception as e:
            if "not found" in str(e).lower():
                return False
            raise

    async def keys(self) -> list[str]:
        """Get all keys in bucket

        @return: List of keys
        """
        try:
            return await self._kv.keys()
        except Exception as e:
            if "no keys" in str(e).lower():
                return []
            raise

    async def all(self) -> dict[str, dict[str, Any]]:
        """Get all key-value pairs

        @return: Dictionary of all entries
        """
        result = {}
        for key in await self.keys():
            value = await self.get(key)
            if value is not None:
                result[key] = value
        return result
