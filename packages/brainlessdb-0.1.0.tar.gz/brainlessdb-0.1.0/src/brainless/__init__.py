"""Brainless - Schema-first async persistence for NATS JetStream KV."""

from __future__ import annotations

from typing import Any

from brainless.client import Brainless
from brainless.collection import Collection
from brainless.entity import Entity

__all__ = ["Brainless", "Collection", "Entity", "setup", "stop", "flush"]

_instance: Brainless | None = None


async def setup(
    nats: Any = None,
    namespace: str = "default",
    location: str = "local",
    flush_interval: float = 0.5,
) -> Brainless:
    """Initialize and start the global Brainless instance

    @param nats: Connected NATS client (optional for in-memory only mode)
    @param namespace: Bucket prefix for isolation
    @param location: Name of this site/node for UUID prefixes
    @param flush_interval: Background flush interval in seconds
    @return: The Brainless instance
    """
    global _instance
    if _instance is not None:
        await _instance.stop()
    _instance = Brainless(nats, namespace, location, flush_interval)
    await _instance.start()
    return _instance


async def stop() -> None:
    """Stop the global Brainless instance."""
    global _instance
    if _instance is not None:
        await _instance.stop()
        _instance = None


async def flush() -> int:
    """Flush all dirty entities in the global instance."""
    if _instance is None:
        raise RuntimeError("Call brainless.setup() first")
    return await _instance.flush()


def __getattr__(name: str) -> Any:
    """Proxy attribute access to global instance for collection access."""
    if _instance is None:
        raise RuntimeError("Call brainless.setup() first")
    return getattr(_instance, name)
