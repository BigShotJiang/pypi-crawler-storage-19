INSTALLATION_TYPE = "community"
