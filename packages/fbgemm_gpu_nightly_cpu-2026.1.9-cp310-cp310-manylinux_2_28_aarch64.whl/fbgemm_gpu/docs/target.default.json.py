
{
    "version": "2026.1.9",
    "target": "default",
    "variant": "cpu"
}
