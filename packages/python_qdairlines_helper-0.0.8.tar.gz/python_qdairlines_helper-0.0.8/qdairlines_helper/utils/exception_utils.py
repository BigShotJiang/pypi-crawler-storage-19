# -*- coding: utf-8 -*-
"""
# ---------------------------------------------------------------------------------------------------------
# ProjectName:  python-qdairlines-helper
# FileName:     exception_utils.py
# Description:  异常工具模块
# Author:       ASUS
# CreateDate:   2026/01/07
# Copyright ©2011-2026. Hunan xxxxxxx Company limited. All rights reserved.
# ---------------------------------------------------------------------------------------------------------
"""


class DuplicatePaymentError(Exception):
    def __init__(self, order_id: int):
        self.order_id = order_id
        super().__init__(f"订单<{order_id}>重复支付错误")

class IPBlockError(Exception):

    def __init__(self, message: str):
        super().__init__(message)