"""Tests for MLX Boosting."""
