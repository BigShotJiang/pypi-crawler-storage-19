# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeletePolicyTemplateRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'policy_template_id': 'str'
    }

    attribute_map = {
        'policy_template_id': 'policy_template_id'
    }

    def __init__(self, policy_template_id=None):
        r"""DeletePolicyTemplateRequest

        The model defined in huaweicloud sdk

        :param policy_template_id: 策略模板id。
        :type policy_template_id: str
        """
        
        

        self._policy_template_id = None
        self.discriminator = None

        self.policy_template_id = policy_template_id

    @property
    def policy_template_id(self):
        r"""Gets the policy_template_id of this DeletePolicyTemplateRequest.

        策略模板id。

        :return: The policy_template_id of this DeletePolicyTemplateRequest.
        :rtype: str
        """
        return self._policy_template_id

    @policy_template_id.setter
    def policy_template_id(self, policy_template_id):
        r"""Sets the policy_template_id of this DeletePolicyTemplateRequest.

        策略模板id。

        :param policy_template_id: The policy_template_id of this DeletePolicyTemplateRequest.
        :type policy_template_id: str
        """
        self._policy_template_id = policy_template_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeletePolicyTemplateRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
