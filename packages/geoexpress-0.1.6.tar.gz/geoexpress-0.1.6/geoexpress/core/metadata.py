# geoexpress/core/metadata.py

from geoexpress.core.base import GeoExpressCommand

_meta = GeoExpressCommand("mrsidgeometa")

def set_metadata(image: str, key: str, value: str):
    """
    Set metadata key=value on a MrSID image
    """
    return _meta.run([
        "-i", image,
        "-set", f"{key}={value}"
    ])


def get_metadata(image: str):
    """
    Get metadata from a MrSID image
    """
    return _meta.run([
        "-i", image,
        "-get"
    ])
