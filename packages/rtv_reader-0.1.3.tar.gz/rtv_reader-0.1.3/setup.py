# -*- coding: utf-8 -*-
"""
Created on Thu Jan  8 13:58:07 2026

@author: Ronny JMD
"""

from setuptools import setup

setup()
