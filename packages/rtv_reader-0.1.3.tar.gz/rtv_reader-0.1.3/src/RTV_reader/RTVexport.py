# -*- coding: utf-8 -*-
"""
Created on Sun Dec 28 15:20:09 2025

@author: Ronny JMD
"""

import json
import napari
import numpy as np
from typing import Optional, Iterable
import tifffile as tiff

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.colors import Normalize

def video(frames: Iterable,
          fps: int = 10,
          Imin: Optional[float]= None, Imax: Optional[float]= None,
          Norm: Optional = None, 
          cmap: Optional[str] = 'turbo',
          dt: Optional[float] = 1,
          t_offset: Optional[float] = 0,
          tunit: Optional[str] = "ns"):
    
    """
    Build a video from all of the frames, using pyplot.imshow module
    
    Args:
        frames: np.ndarray contening the frames composing the futur video
        fps: Fix the frame per second of the video
        Imin: Fix lowest value of the color scale intensity
        Imax: Fix highest value of the color scale intensity
        Norm: To set the intensity into a log scale, use setnorm function from traitement RTV
        cmap: Choose color of the map, default is turbo
https://matplotlib.org/stable/users/explain/colors/colormaps.html
        dt: Time step _ Optionnel in case you want it to be displayed
        t_offset : Set the time offset to display. Default is 0
        tunit: Optionnel, in case you want it to be displayed. Default is "ns"
    """
    
    fig, ax = plt.subplots()
    ax.axis("off")  # Deleting the axes
    
    nf = len(frames)
    im = iter(frames) # Transform into an iterator that FuncAnim can use, 1D object

    """
    🔹 Valeur par défaut locale
    """
    if Imin is None:
        Imin = np.min(frames)
    
    if Imax is None:
        Imax = np.max(frames)
        
    if None not in (Imin, Imax) and Imin > Imax:
        print("Imin > Imax")

    """
    🔹 Set a linear scale by default
    """
    if Norm is None:
        first = next(im)
        Norm = Normalize(vmin=Imin, vmax=Imax)
        f = ax.imshow(first, cmap=cmap, norm=Norm)
        
    else:
        first = next(im)
        f = ax.imshow(first, cmap=cmap, norm=Norm)
        
    title = ax.text(0.5, 0.95, f"t = {t_offset + dt:.2f} {tunit}", transform=ax.transAxes, ha="center", va="top", color="white")

    """
    🔹 Colorbar fixe
    """
    cbar = fig.colorbar(f, ax=ax)
    cbar.set_label("Intensity")

    """
    🔹 Update appelée à chaque frame
    """
    def update(frame):
        f.set_data(frame)
        idx = int(update.idx)
        title.set_text(f"t = {t_offset + idx*dt:.2f} {tunit}")
        update.idx += 1
        return f, title

    update.idx = 1  # First image (index = 0) already shown
    
    ani = FuncAnimation( # Much more quicker than AnimArtist and less memory consuming
        fig,
        update,
        frames=im,
        interval=1000/fps, # Time between each frames (ms)
        blit=True,
        save_count=nf, # Number of frames to save need to be specified with iterator
        cache_frame_data=True) 
    
    return ani

def saveTiff(frames: Iterable,
            tiffname: str, 
            compression = None,
            metadata = None,
            dt = None,
            t_offset: float = 0,
            t_unit: str = 's'):

    """
    To export all the frames in a tiff file
    Arg:
        frames: Iterable containing data to be exported
        tiffname: Name of the .tiff to export
        compression: (Opt.) None | 'zlib' | 'lzma' _ Zero loss compressing system proposed, from no compression to higher compression rate
        dt: (Opt.) None | float _ Only if you want to specify the time between two frames.
        t_offset: (Opt.) Time offset. Default is 0
        t_unit: (Opt.) Time unit. Default is seconde
    """
    with tiff.TiffWriter(tiffname, bigtiff=True) as tif:
        for _, img in enumerate(frames):
            frame_metadata = metadata.copy() if metadata else {}

            """
            🔹 Index temporel
            """
            if dt is not None:
                frame_metadata["tstep"] = dt
                frame_metadata["time"] = t_offset + _*dt
                frame_metadata["time_unit"] = t_unit

            tif.write(img,
                compression=compression,
                metadata=frame_metadata or None,
                photometric="minisblack") # Set the color settings. minisblack = grayscale with min in black
            
def seeTiff(tiffname: str):
    
    """
    To visualize heavy tiff file
    Arg:
        tiffname: Name of the .tiff to read
    """   
    with tiff.TiffFile(tiffname) as tif:
        # stack = np.stack([page.asarray() for page in tif.pages])
        
        frames = np.stack([page.asarray() for page in tif.pages])
        
        meta_raw = tif.pages[0].tags["ImageDescription"].value
        if meta_raw:
            meta = json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw.value
        else:
            meta = {}
            
    """
    Initialise time displaying feature
    """
    viewer = napari.Viewer()
    def time_overlay(viewer, dt, t_offset, t_unit):
        init = {"string": [" "],
                "anchor": "upper_left",
                "translation": [100, 25],
                "size": 8,    # Text font
                "color": "white"}
        text = viewer.add_points([[0, 0]],
                                 size = 0,
                                 face_color = "transparent",
                                 name = "time_text",
                                 text = init)
    
        def update(event):
            i = viewer.dims.current_step[0]
            t = t_offset + i * dt
            text.text.values = [f"t = {t:.2f} {t_unit}"]

        viewer.dims.events.current_step.connect(update)
        update(None)
        
    def time_bar(viewer, dt, t_offset, t_unit):
        def update(event=None):
            i = viewer.dims.current_step[0]
            t = t_offset + i * dt
            viewer.status = f"t = {t:.3f} {t_unit}   (frame {i})"
    
        viewer.dims.events.current_step.connect(update)
        update()

    """
    Display time scale only if metadata exist
    """    
    if meta:
        dt = meta.get("tstep")
        t_offset = meta.get("time")
        t_unit = meta.get("time_unit")
  
        viewer.add_image(frames,
                         name=tiffname,
                         scale=(dt, 1, 1), # Δt
                         translate=(t_offset, 0, 0),
                         axis_labels=(f"time ({t_unit})", "y", "x"),
                         metadata=meta)   # Saved in napari
            
        time_overlay(viewer, dt, t_offset, t_unit)
        time_bar(viewer, dt, t_offset, t_unit)
            
    else:
        viewer.add_image(frames)

    napari.run()
    
"""============================================================================
                                PANNEAU DE TEST
============================================================================"""

if __name__ == "__main__":
    import os
    from concatenate_frames import concatenateRTV
    
    os.chdir(os.path.join(os.pardir, 'Example'))
    # test = concatenateRTV(("Test.rtv","Test2.rtv","Test3.rtv"), 40, 48)

# # Test de la commande video
#     ani = video(test)
#     plt.show()
#     ani.save("output_10fps.mp4", writer="ffmpeg", dpi=150)
    
# Test de la commande export image tiffimg
    # saveTiff(test, "output.tiff", compression="zlib", metadata={"source": "RTV"}, dt=1, t_offset=85, t_unit="ns")
    seeTiff("output.tiff")


