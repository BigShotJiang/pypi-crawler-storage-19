# -*- coding: utf-8 -*-
"""
Created on Tue Jan  6 17:05:16 2026

@author: Ronny JMD
"""

import json
import struct
import numpy as np
import inspect
from pathlib import Path
from types import GeneratorType
from typing import Optional, Generator, Union, Tuple, Iterator
import tifffile as tiff
from tqdm import tqdm

def decodeheader(file:str, ) -> dict:
    
    """
    Read the header of an .rtv
    All the header info are retrieved in a dict variable
    Args:
        file: Path or filename .rtv
    """
    bytedata = bytes(0)
    header = {}
    
    with open(file, "rb") as f:
        # Lecture du fichier byte dans variable
        
        bytedata = f.read()
        
    header["HEAD"] = bytedata[0:4].hex()
    header["signext"] = bytedata[4:14].hex()
    header["info"] = bytedata[14:198].split(b'\x00', 1)[0].decode('ascii')
    header["originalfilename"] = bytedata[290:542].split(b'\x00', 1)[0].decode('ascii')
    header["nrow_offset"] =  int.from_bytes(bytedata[214:216], 'little', signed=True)
    header["ncol_offset"] =  int.from_bytes(bytedata[216:218], 'little', signed=True)
    header["nrow"] =  int.from_bytes(bytedata[218:220], 'little', signed=True)
    header["ncol"] =  int.from_bytes(bytedata[220:222], 'little', signed=True)
    header["nrow_grpsize"] =  int.from_bytes(bytedata[222:224], 'little', signed=True)
    header["ncol_grpsize"] =  int.from_bytes(bytedata[224:226], 'little', signed=True)
    header["fieldformat"] = int.from_bytes(bytedata[258:262], 'little', signed=True)
    header["bytesperpix"] = int.from_bytes(bytedata[262:266], 'little', signed=True)
    header["xsize"] = int.from_bytes(bytedata[266:270], 'little', signed=True)
    header["ysize"] = int.from_bytes(bytedata[270:274], 'little', signed=True)
    header["framesize"] = int.from_bytes(bytedata[274:278], 'little', signed=True)
    header["nframe"] = int.from_bytes(bytedata[278:282], 'little', signed=True)
    
    """
    Filling parsing only. Uncomment if you need information from its
    """
    # header["framesperfrag"] = int.from_bytes(bytedata[282:286], 'little', signed=True)
    # header["nfrag"] = int.from_bytes(bytedata[286:290], 'little', signed=True)
    # header["zero"] = bytedata[21:199].hex()
    # header["zerofill"] = bytedata[199:202].hex()
    # header["infoext_1"] = bytedata[202:210].decode("utf-8")
    # header["zeroext_1"] = bytedata[210:211].hex()
    # header["zerofillext_1"] = bytedata[211:214].hex()
    # header["dummy"] =  bytedata[226:230].hex()
    # header["infoext_2"] = bytedata[230:256].decode("utf-8")
    # header["zeroext_2"] = bytedata[256:257].hex()
    # header["onefill"] = bytedata[257:258].hex()
    # header["dummy2"] = int.from_bytes(bytedata[295:4096], 'little', signed=True)
        
    return header

def getframe(file:str, framepos:int = None)  -> np.ndarray:
    
    """
    Retrieve a specified frame (framepos) from an RTV file
    Args:
        file: Path or filename .rtv
        framepos: Index of frame you want to retrieve
    """
    dh = decodeheader 
    with open(file, "rb") as f:
        # Lecture du fichier byte dans variable
        
        bytedata = f.read()

    info = dh(file) #Get RTV file info
    
    """
    Restrict the frame position to retrieve
    """
    if framepos is not None and framepos < 0 or framepos >= info['nframe']:
        raise ValueError(f" framepos must range between 0 and {info['nframe'] - 1}")
    else:
        
        """
        Get the position of the frame to be read
        """
        bytestartposition = 8192 + framepos * info['framesize']
        byteendposition = bytestartposition + 2 * info['nrow'] * info['ncol']
        
        """
        Convert bytes data in 2D ASCII format
        """
        frame = np.empty((info['ysize'], info['xsize']))
        frame = np.array(struct.unpack(str(info['nrow']*info['ncol'])+"h", bytedata[bytestartposition:byteendposition])).reshape((info['nrow'], info['ncol']))
        
        return frame
    
def getallframes(file:str, start: Optional[int] = None, end: Optional[int] = None)  -> Generator:
       
    """
    Retrieve a group of frames from the same file
    Frame extracted from position start to position end
    Args:
        file: Path or filename .rtv
        start: Starting index (inclusive) _ Optionnal
        end: Ending index (exclusive) _ Optionnal
    If no index specified, retrieve all the frames
    """
    dh = decodeheader
    gf = getframe
    
    info = dh(file) #Get RTV file info
    
    """
    Get and check the position of the frame to be read
    """
    
    if start is not None and start < 0:
        raise ValueError("start >= 0")
        
    if end is not None and end < 0:
        raise ValueError(f" 0 <= end <= {info['nframe']-1}")
        
    if end is not None and end > info['nframe']:
        raise ValueError(f" 0 <= end <= {info['nframe']}")
        
    if start is not None and end is not None and start > end:
        raise ValueError("start > end")
  
    for _ in range(info['nframe']):
        if start is not None and _ < start:
            continue
        if end is not None and _ >= end:
            break
        print("DEBUG: retrieving image", _)
                      
        yield gf(file,_)
        
def normalize_files(files):
    
    """
    Normalize the input 'files' into a list of file paths.
    Args:
        files (str | Path | list | tuple):
            A single file path or a list/tuple of paths.
    Returns:
        list[str]: A list of file paths as strings.

    Raises:
        TypeError: If 'files' is not a valid type or contains invalid elements.

    Examples:
        >>> normalize_files("input.rtv")
        ['input.rtv']

        >>> normalize_files(["a.rtv", "b.rtv"])
        ['a.rtv', 'b.rtv']
    """
    
    # Case 1: A unique file (string ou Path)
    if isinstance(files, (str, Path)):
        return [str(files)]

    # Case 2: list or tuple
    if isinstance(files, (list, tuple)):
        normalized = []
        for i, item in enumerate(files):
            if not isinstance(item, (str, Path)):
                raise TypeError(
                    f"Item at index {i} must be a string or Path. "
                    f"Got {type(item).__name__}: {item!r}"
                )
            normalized.append(str(item))
        return normalized

    # Case 3: wrong type
    raise TypeError(
        f"'files' must be a string, Path, list or tuple of strings/Paths "
        f"(got {type(files).__name__})"
    )
        
def importRTV(files: Tuple[str, ...], start: Optional[int] = None, end: Optional[int] = None, dtype: Union[np.dtype, type] = np.float16)  -> np.ndarray:
       
    """
    From multiple RTV file, concatenate all the frames from getallframes into an numpy array
    WARNING : Each file need to contain the same number of frames
    Frame extracted from position start to position end
    Args:
        files: tuples of all the file name
        start: Starting index (inclusive) _ Optionnal
        end: Ending index (exclusive) _ Optionnal
        dtype: If more precision is needed, np.float16 -> np.float32 or 64, at the cost of memory allocation
    """
    dh = decodeheader
    ga = getallframes
    
    """
    🔹 Checking the input files type
    """
    normalize_files(files)

    """
    🔹 Checking the number of frames of each file and their size are strictly the same
    """
    for _ in files:
        
        nframes = None
        xsize = None
        ysize = None
        
        nf = dh(_)["nframe"] #Get RTV files info
        x = dh(_)["xsize"] #Get RTV files info
        y = dh(_)["ysize"] #Get RTV files info
                
        if nframes is None:
            nframes = nf
        elif nf != nframes:
            raise ValueError(f"{_} has {nf} frames, expected {nframes}")
            
        if xsize is None:
            xsize = nf
        elif x != xsize:
            raise ValueError(f"{_} has {x} frames, expected {xsize}")
        
        if ysize is None:
            ysize = nf
        elif y != ysize:
            raise ValueError(f"{_} has {y} frames, expected {ysize}")
        
    """
    🔹 Assign default value
    """
    if start is None:
        start = 0
    if end is None:
        end = nf
            
    """
    🔹 Pre-allocate the space for each image
    """
    
    frames = np.empty((len(files)*(end-start), y, x), dtype=dtype)
    i = 0
    
    for file in files:
        print("DEBUG: From file", file)
        for _, img in enumerate(ga(file, start, end)):
            frames[i] = img
            i += 1
    
    return frames

def readTiff(tiffname: str, read_metadata: bool = None) -> Iterator:
    
    """
    To read heavy tiff file
    Arg:
        tiffname: Name of the .tiff to read
        read_metadata: If None or False, only retrieve the frames from the .tiff
    """    
    
    with tiff.TiffFile(tiffname) as tif:
        
        for _ in tif.pages:
            
            frames = _.asarray()
            
            """
            🔹 Conditional metadata extraction
            """
            if read_metadata:
                meta_raw = _.tags["ImageDescription"].value
                if meta_raw is not None:
                    meta = json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw.value
                else:
                    meta = {}
                yield frames, meta
            else:
                yield frames
                
def peek_and_check_gen(gen, check_shapes=True, show_progress=True):
    
    """
    Analize and check the coherence of a generator variable
    
    Arg:
        check_shapes : Check the shape coherence over all the frames
        show_progress : display a progression axes (tqdm)
    
    Return:
        gen: The generator itself that has been regenerated
        nframes : total number of frames (only if show_progress=True)
        shape : shape of the frames

    Pros:
        Generator is regenerated
        Free RAM consuming
    """
    if not isinstance(gen, GeneratorType):
        raise TypeError("The input is not a generator type")
    
    """
    🔹 Retrieve the shape of the first image
    """
    try:
        first = next(gen)
    except StopIteration:
        raise ValueError("The generator is empty, no frame to read")

    first = np.asarray(first)
    shape = first.shape

    """
    🔹 Regenerate the generator and check the coherence of the shape off all frames
    """
    # --- 1) Créer un générateur qui commence par la 1ère frame
    def validated_gen():
        
        yield first  # Put the first image back
        index = 1

        # tqdm if on
        iterable = gen
        if show_progress:
            iterable = tqdm(iterable, desc="Parsing frames", unit="frame") # Pour connaître n_frames sans consommer validated_gen, il faut un wrapper

        for frame in iterable:
            frame_arr = np.asarray(frame)

            # --- 2) Shape coherence checking
            if check_shapes and frame_arr.shape != shape:
                raise ValueError(
                    f"Incoherence detected for frame {index} : "
                    f"expected shape {shape}, current shape {frame_arr.shape}"
                )

            yield frame_arr
            index += 1

    """
    🔹 Counting the total number of frames (show_progess need to be set as 'True')
    """
    n_frames = None
    if show_progress:
        # On compte "virtuellement" en itérant validated_gen jusqu'au bout
        # mais en recréant un second générateur pour l'itération finale
        # Mémoire minimale : uniquement une frame à la fois en RAM

        # Regenaration of the generator
        def temp_gen():
            yield first
            for frame in gen:
                yield frame

        # comptage
        n_frames = sum(1 for _ in temp_gen())

    return validated_gen(), shape, n_frames

def gen_to_arr(gen):
    
    """
    Convert a generator containing array of frames
    Automatically checking for shape coherence
    """
    """
    🔹 Check the entry validity
    """
    if not inspect.isgenerator(gen):
        raise TypeError("Input must be a generator")

    """
    🔹 Peek the first frame
    """
    try:
        first = next(gen)
    except StopIteration:
        raise ValueError("Generator is empty")

    if not isinstance(first, np.ndarray):
        raise TypeError("Generator must yield numpy arrays")

    frame_shape = first.shape
    dtype = first.dtype

    frames = [first]

    """
    🔹 Check consistency over all the frames
    """
    for frame in gen:
        if frame.shape != frame_shape:
            raise ValueError(f"Inconsistent frame shape: expected {frame_shape}, got {frame.shape}")
        if frame.dtype != dtype:
            raise ValueError(f"Inconsistent frame dtype: expected {dtype}, got {frame.dtype}")
        frames.append(frame)

    """
    🔹 Return a numpy array
    """
    return np.stack(frames, axis=0)
