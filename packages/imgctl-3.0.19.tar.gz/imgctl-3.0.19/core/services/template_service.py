"""
Сервис для работы с шаблонами стека
"""
from typing import Dict, Optional, Any

from core.api_client import ImagenariumAPIClient

# Импорт для callback прогресса
try:
    from core.progress import ProgressCallback
except ImportError:
    ProgressCallback = Any


class TemplateService:
    """Сервис для работы с шаблонами стека"""

    def __init__(self, api_client: ImagenariumAPIClient):
        """
        Инициализация сервиса шаблонов

        Args:
            api_client: API клиент для работы с imagenarium (обязателен)
        """
        if not api_client:
            raise ValueError("API клиент обязателен для TemplateService")
        
        self.api_client = api_client

    def get_template_by_component(
            self,
            component_name: str,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Optional[str]:
        """
        Получает шаблон по имени компонента

        Args:
            component_name: Имя компонента
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Содержимое шаблона или None если не найден
        """
        # Получаем информацию о компоненте
        from core.services.components_service import ComponentsService

        components_service = ComponentsService(api_client=self.api_client)
        component = components_service.get(component_name, no_cache=no_cache, progress=progress)

        if not component:
            return None

        # Извлекаем информацию о стеке
        stack = component.get("stack", "")
        if not stack or "@" not in stack:
            return None

        stack_id, namespace = stack.split("@", 1)
        repo = component.get("repo", "")
        commit = component.get("commit", "")

        if not repo or not commit:
            return None

        # Получаем версию стека (по умолчанию latest)
        version = component.get("stack_version", "latest")

        return self.get_template_by_repo(repo, stack_id, version, commit, no_cache, progress)

    def get_template_by_stack(
            self,
            stack_id: str,
            namespace: str,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Optional[str]:
        """
        Получает шаблон по имени развернутого или неразвернутого стека

        Args:
            stack_id: ID стека
            namespace: Namespace стека
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Содержимое шаблона или None если не найден
        """
        # Получаем информацию о стеке
        from core.services.stacks_service import StacksService

        stacks_service = StacksService(api_client=self.api_client)
        stack = stacks_service.get(f"{stack_id}@{namespace}", no_cache=no_cache, progress=progress)

        if not stack:
            return None

        repo = stack.get("repo", "")
        commit = stack.get("commit", "")
        version = stack.get("version", "latest")

        if not repo or not commit:
            return None

        return self.get_template_by_repo(repo, stack_id, version, commit, no_cache, progress)

    def get_template_by_repo(
            self,
            repository: str,
            stack_id: str,
            version: str,
            git_ref: str,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Optional[str]:
        """
        Получает шаблон по имени стека из конкретного репозитория

        Args:
            repository: Имя репозитория
            stack_id: ID стека
            version: Версия стека
            git_ref: Git ref (commit, tag, branch)
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Содержимое шаблона или None если не найден
        """
        return self.api_client.get_template(
            repository, stack_id, version, git_ref, no_cache, progress
        )

    def get_template_by_tag(
            self,
            repository: str,
            stack_id: str,
            version: str,
            tag: str,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Optional[str]:
        """
        Получает шаблон по тегу

        Args:
            repository: Имя репозитория
            stack_id: ID стека
            version: Версия стека
            tag: Тег
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Содержимое шаблона или None если не найден
        """
        # Извлекаем commit из тега через API клиент
        git_ref = self.api_client.extract_commit_from_tag(tag)

        return self.get_template_by_repo(repository, stack_id, version, git_ref, no_cache, progress)

    def compare_templates(
            self,
            template1: str,
            template2: str,
    ) -> Dict[str, Any]:
        """
        Сравнивает два шаблона

        Args:
            template1: Первый шаблон
            template2: Второй шаблон

        Returns:
            Словарь с информацией о сравнении:
            - equals: равны ли шаблоны
        """
        equals = template1.strip() == template2.strip()
        return {
            "equals": equals,
        }

    def diff_templates(
            self,
            repository: str,
            stack_id: str,
            version: str,
            git_ref1: str,
            git_ref2: str,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Dict[str, Any]:
        """
        Сравнивает шаблоны двух ревизий

        Args:
            repository: Имя репозитория
            stack_id: ID стека
            version: Версия стека
            git_ref1: Первая ревизия (commit, tag, branch)
            git_ref2: Вторая ревизия (commit, tag, branch)
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Словарь с информацией о сравнении:
            - equals: равны ли шаблоны
            - oldTemplate: содержимое первого шаблона
            - newTemplate: содержимое второго шаблона
        """
        template1 = self.get_template_by_repo(
            repository, stack_id, version, git_ref1, no_cache, progress
        )
        template2 = self.get_template_by_repo(
            repository, stack_id, version, git_ref2, no_cache, progress
        )

        if not template1 or not template2:
            return {
                "equals": False,
                "error": "Один из шаблонов не найден",
                "oldTemplate": template1 or "",
                "newTemplate": template2 or "",
            }

        result = self.compare_templates(template1, template2)
        result["oldTemplate"] = template1
        result["newTemplate"] = template2
        return result

    def extract_commit_from_tag(self, tag: str) -> str:
        """
        Извлекает commit hash из тега (через API клиент)

        Args:
            tag: Тег в формате dev__2025_08_05_10_17-6ca3d9f

        Returns:
            Commit hash
        """
        return self.api_client.extract_commit_from_tag(tag)
