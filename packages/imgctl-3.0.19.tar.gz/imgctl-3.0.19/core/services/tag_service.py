"""
Сервис для работы с тегами репозитория
"""
from typing import List, Optional, Dict, Any

from core.api_client import ImagenariumAPIClient

# Импорт для callback прогресса
try:
    from core.progress import ProgressCallback
except ImportError:
    ProgressCallback = Any


class TagService:
    """Сервис для работы с тегами репозитория"""

    def __init__(self, api_client: ImagenariumAPIClient):
        """
        Инициализация сервиса тегов

        Args:
            api_client: API клиент для работы с imagenarium (обязателен)
        """
        if not api_client:
            raise ValueError("API клиент обязателен для TagService")
        
        self.api_client = api_client

    def get_tags(
            self,
            repository: str,
            image: str = "",
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> List[Dict[str, Any]]:
        """
        Получает список тегов для репозитория

        Args:
            repository: Имя репозитория
            image: Образ для поиска (для API fallback и фильтрации)
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Список тегов в формате [{"name": str, "current": bool, "source": str}]
        """
        # URL репозитория всегда получается из API внутри get_tags
        tags = self.api_client.get_tags(
            repository, image=image, no_cache=no_cache, progress=progress
        )
        
        # Нормализуем формат: все теги должны иметь поля name, current, source
        normalized_tags = []
        for tag in tags:
            if isinstance(tag, dict):
                normalized_tag = {
                    "name": tag.get("name", tag.get("tag", "")),
                    "current": tag.get("current", False),
                    "source": tag.get("source", "API")
                }
            else:
                # Если тег - строка
                normalized_tag = {
                    "name": str(tag),
                    "current": False,
                    "source": "git"
                }
            normalized_tags.append(normalized_tag)
        
        # Если image указан в формате ":prefix__", фильтруем по префиксу
        # (это нужно для git тегов, так как API уже фильтрует на своей стороне)
        if image.startswith(":") and "__" in image:
            prefix = image.replace(":", "")
            normalized_tags = [tag for tag in normalized_tags if tag["name"].startswith(prefix)]
        
        return normalized_tags

    def get_last_tag(
            self,
            repository: str,
            image: str = "",
            exclude_prefix: Optional[str] = None,
            no_cache: bool = False,
            progress: Optional[ProgressCallback] = None,
    ) -> Optional[str]:
        """
        Получает последний доступный тег для репозитория

        Args:
            repository: Имя репозитория
            image: Образ для поиска (для API fallback и фильтрации)
            exclude_prefix: Префикс тега для исключения (например, "dev__")
            no_cache: Не использовать кеш
            progress: Callback для отображения прогресса

        Returns:
            Имя последнего тега или None если не найден
        """
        tags = self.get_tags(repository, image=image, no_cache=no_cache, progress=progress)
        
        if not tags:
            return None
        
        # Исключаем префикс если указан
        for tag in tags:
            tag_name = tag.get("name", "")
            if exclude_prefix and tag_name == exclude_prefix:
                continue
            return tag_name
        
        return None

    def extract_commit_from_tag(self, tag: str) -> str:
        """
        Извлекает commit hash из тега (через API клиент)

        Args:
            tag: Тег в формате dev__2025_08_05_10_17-6ca3d9f

        Returns:
            Commit hash
        """
        return self.api_client.extract_commit_from_tag(tag)
