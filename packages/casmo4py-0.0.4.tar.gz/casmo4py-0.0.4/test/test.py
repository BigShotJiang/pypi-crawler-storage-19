from Map import Map
from DataSelection import DataSelection
from Setup import Setup

reg = ["NF", "TF", "SS", "TS", "NS", "U", "DIR",'PP','MAG']
typ = ["FMS", "FMF", "OC", "GFI", "GVA", "BO", "DIF", "HF", "PP", "MAG", "DIR"]
qual = ["A", "B", "C", "D", "DIR", 'PP','MAG']
x = (3,15)
y=(57,63)

s = Setup(x,y,reg,typ,qual)

s.set_input_path("/home/tim/casmo/data/WSM_Database_2025.csv")
s.set_output_path("/home/tim/casmo/test")


ds = DataSelection(
    x,
    y,
    qual,
    reg,
    typ,
    path_wsm=s.get_input_path(),
    path_mean="",
    own_data="",
)

ds.read_data()
own_data = """60, 10, 0, PP, 0, PP, PP
59, 10, 0, PP, 0, PP, PP
60, 10, 0, MAG, 0, MAG, MAG
59, 10, 0, MAG, 0, MAG, MAG
59, 11, 0, DIR, 0, DIR, DIR
59, 12, 0, DIR, 0, DIR, DIR"""
ds.set_own_data(own_data)
ds.prepare_own_data()
df_o = ds.get_df_own()

df = ds.get_df_wsm()
grid = "/home/tim/casmo_ap/gmt_files_casmo/ETOPO1_Bed_g_gmt4.grd"
m = Map(x,y,qual,reg,typ)
m.create_base()
m.hillshade(grid)
m.plot_coastline(grid)
m.plot_stress_data(df)
m.plot_stress_data(df_o)
m.convert("test", "g")
