#! /usr/bin/env python3

""" """
import pandas as pd
from Utils import vec_len

class DataSelection:
    def __init__(
        self,
        lon,
        lat,
        quality,
        regime,
        typ,
        wsm=True,
        path_wsm="wsm2025.csv",
        path_mean="",
        own_data="",
        upper=0,
        lower=75,
    ):
        """
        Args:
            bla (test.type): does blub
        """
        self.cols = ["LAT", "LON", "AZI", "TYPE", "DEPTH", "QUALITY", "REGIME"]
        self.type = typ
        self.regime = regime
        self.quality = quality

        #self.x1, self.x2, self.y1, self.y2 = x1, x2, y1, y2
        self.region = [lon[0], lon[1], lat[0], lat[1]]
        self.upper, self.lower = upper, lower

        self.plot_wsm_data = wsm
        self.path_wsm = path_wsm
        self.path_mean = path_mean
        self.own_data = own_data

        self.df_wsm = pd.DataFrame(columns=self.cols)
        self.df_mean = pd.DataFrame(columns=self.cols)
        self.df_own = pd.DataFrame(columns=self.cols)

    def set_coordinates(self, lon, lat):
        #self.x1, self.x2, self.y1, self.y2 = x1, x2, y1, y2
        self.region = [lon[0], lon[1], lat[0], lat[1]]

    def get_coordinates(self):
        return self.region
    def set_type(self, typ):
        self.type = typ

    def get_type(self):
        return self.type

    def set_regime(self, regime):
        self.regime = regime

    def get_regime(self):
        return self.regime

    def set_quality(self, quality):
        self.quality = quality

    def get_quality(self):
        return self.quality

    def set_columns(self, columns):
        self.cols = columns

    def get_columns(self):
        return self.cols

    def set_plot_wsm_data(self, boolean):
        self.plot_wsm_data = boolean

    def get_plot_wsm_data(self):
        return self.plot_wsm_data

    def set_path_wsm(self, name):
        self.path_wsm = name

    def get_path_wsm(self):
        return self.path_wsm

    def get_df_wsm(self, raw=False):
        df = self.crop_data(self.df_wsm, raw)
        return df

    def set_path_mean(self, name):
        self.path_mean = name

    def get_path_mean(self):
        return self.path_mean

    def get_df_mean(self, raw=False):
        df = self.crop_data(self.df_mean, raw)
        return df

    def set_own_data(self, own_data):
        self.own_data = own_data

    def get_own_data(self):
        return self.own_data

    def get_df_own(self, raw=False):
        self.prepare_own_data()
        df = self.crop_data(self.df_own, raw)
        return df

    def read_data(self):
        if self.plot_wsm_data:
            self.df_wsm = pd.read_csv(self.path_wsm, low_memory=False)
        if self.path_mean != "":
            self.df_mean = pd.read_csv(self.path_mean)
            self.regime.append("DIR")
            self.type.append("DIR")
            self.quality.append("DIR")

    def prepare_own_data(self):
        if len(self.own_data) > 0:
            data = []
            if "\n" in self.own_data:
                od = self.own_data.replace(" ", "")
                od = od.split("\n")
                for d in od:
                    tmp = d.split(",")
                    data.append(tmp)
            else:
                tmp = od.split("\n")
                data.append(tmp)
            self.df_own = pd.DataFrame.from_records(data, columns=self.cols)

    def crop_data(self, df, raw=False):
        df = df.astype({"LAT": "float64", "LON": "float64", "DEPTH": "float64"})
        df = df[
            (df.LON >= self.region[0])
            & (df.LON <= self.region[1])
            & (df.LAT >= self.region[2])
            & (df.LAT <= self.region[3])
            & (df.DEPTH >= self.upper)
            & (df.DEPTH <= self.lower)
        ]
        df = df[
            (df.REGIME.isin(self.regime))
            & (df.TYPE.isin(self.type))
            & (df.QUALITY.isin(self.quality))
        ]
        if raw: 
            return df
        else:
            df=df[self.cols]
            df['LEN'] = df.apply(vec_len, axis=1)
            return df


if __name__ == "__main__":
    typ = ["GI", "OC"]
    quality = ["A", "B", "C"]
    regime = ["NF", "NS", "SS", "TF", "TS", "U"]

    x1 = 5
    x2 = 16
    y1 = 45
    y2 = 50

    ds = DataSelection((x1, x2), (y1, y2), quality, regime, typ)

    print(ds.get_coordinates())
    ds.set_path_wsm("~/casmo/data/wsm2025.csv")
    ds.read_data()
    df = ds.get_df_own()
    print(df)
    own_data = """61.376, 18.171, 138, HF, 0.32, A, TF
59.376, 18.171, 138, GI, 0.32, B, NF
60.376, 17.171, 138, OC, 0.32, C, SS
61.376, 19.171, 138, OC, 0.32, D, TF"""

    ds.set_own_data(own_data)

    df = ds.get_df_own()
    print(df)
    ds.set_path_mean("~/casmo/data/mean_SHmax_r250_02.csv")

    df = ds.get_df_wsm()
    print(df.info())
