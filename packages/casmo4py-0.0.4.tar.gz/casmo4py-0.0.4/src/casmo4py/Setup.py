#! /usr/bin/env python3

""" """


class Setup:
    vec_len_qual = {
        "A": 0.7,
        "B": 0.55,
        "C": 0.4,
        "D": 0.3,
        "DIR": 0.25,
    }
    colors = {
        "TF": "51/102/153",
        "TS": "51/102/153",
        "SS": "0/153/51",
        "NF": "204/0/0",
        "NS": "204/0/0",
        "DIR": "153/153/153",
        "PP": "102/204/255",
        "MAG": "255/255/51",
        "U": "0/0/0",
    }
    def __init__(self, lon=(0,0), lat=(0,0), qual=[], reg=[], typ=[]):
        """
        Args:
            bla (test.type): does blub
        """

        self.path_input = "/home/tim/casmo_ap/gmt_files_casmo/"
        self.path_output = "/home/tim/casmo_ap/static/output/"
        self.path_plate_boundary = self.path_input + "BIRD_plate_boundaries.dat"

        self.region = [lon[0], lon[1], lat[0], lat[1]]
        self.regime = reg
        self.typ = typ
        self.quality = qual

        self.pen = {}

        self.vec_len_qual = {
            "A": 0.7,
            "B": 0.55,
            "C": 0.4,
            "D": 0.3,
            "DIR": 0.25,
        }

    def set_input_path(self, path):
        self.path_input = path

    def get_input_path(self):
        return self.path_input

    def set_output_path(self, path):
        self.path_output = path

    def get_output_path(self):
        return self.path_output

    def set_plate_bound_path(self, path):
        self.path_plate_boundary = path

    def get_plate_bound_path(self):
        return self.path_plate_boundary

    def set_colors(self, key, col):
        if key in self.colors.keys():
            self.colors[key] = col
        else:
            print("No such item")

    def get_colors(self):
        return self.colors

    def set_vec_len(self, key, len):
        if key in self.vec_len_qual.keys():
            self.vec_len_qual[key] = len
        else:
            print("No such item")

    def get_vec_len(self):
        return self.vec_len_qual


if __name__ == "__main__":
    s = Setup()
    print(s.get_colors())

    s.set_colors("lake", "blue")

    print(s.get_colors())
    v = s.get_vec_len()
    print(v)
    s.set_vec_len('A', 22)
    
    v = s.get_vec_len()
    print(v)

