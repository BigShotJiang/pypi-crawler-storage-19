# Test PyTorch implementations
