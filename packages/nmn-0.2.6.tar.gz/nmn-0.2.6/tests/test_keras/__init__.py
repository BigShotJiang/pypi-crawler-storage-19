# Test Keras implementations
