class DatafoldSDKException(Exception):
    pass
