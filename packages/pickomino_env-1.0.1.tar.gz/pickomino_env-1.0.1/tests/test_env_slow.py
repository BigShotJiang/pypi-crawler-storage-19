"""Slow environment tests for continuous integration (CI)."""

from __future__ import annotations

import os
import time
import pytest
import gymnasium as gym
import matplotlib.pyplot as plt
from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.results_plotter import load_results, ts2xy
from stable_baselines3.common.vec_env import DummyVecEnv

# For later
# from stable_baselines3 import SAC # Soft Actor-Critic (SAC) is suitable for continuous action spaces.

# side-effect import, required for environment registration.
import pickomino_env  # type: ignore[import-not-found] # noqa:F401
from pickomino_env.modules.bot import Bot  # type: ignore[import-not-found]

# Create an environment to test.
env = gym.make("Pickomino-v0", render_mode=None, number_of_bots=2)  # base environment


@pytest.fixture(scope="session")
def ppo_setup(tmp_path_factory):
    """Fixture for creating a Proximal Policy Optimization (PPO) model from Stable Baselines3."""
    log_dir = tmp_path_factory.mktemp("ppo_logs")

    def make_env(rank):
        """Create environment with function for testing PPO."""

        def _init():
            ppo_env = gym.make("Pickomino-v0", render_mode=None, number_of_bots=6)
            ppo_env = Monitor(ppo_env, filename=f"{log_dir}/{rank}")
            return ppo_env

        return _init

    # More advanced, hence for later.
    # from stable_baselines3.common.vec_env import SubprocVecEnv
    # par_env = SubprocVecEnv([make_env for _ in range(8)])  # 8 parallel envs.

    # Vectorize environment for PPO for parallel environments
    par_env = DummyVecEnv([make_env(i) for i in range(8)])  # 8 sequential environments.
    model = PPO("MultiInputPolicy", par_env)  # Add ', verbose=1' as necessary

    start_time = time.time()
    # 1 step = one action, not an episode.
    model.learn(
        total_timesteps=10_000
    )  # Real training. At 10_000_000, real learning was seen.
    ppo_run_time = time.time() - start_time
    assert ppo_run_time < 120, f"PPO training took too long: {ppo_run_time:.0f} seconds"
    return model, log_dir, ppo_run_time


@pytest.mark.slow
def test_ppo_run(ppo_setup):
    """Test PPO trains with full timesteps and produces data."""
    model, log_dir, ppo_run_time = ppo_setup
    x, y = ts2xy(load_results(str(log_dir)), "timesteps")

    # Simple validation: no crash and x, y are arrays
    assert x is not None
    assert len(x) > 0, "No training data produced."
    assert y is not None


@pytest.mark.slow
def test_ppo_plotting(ppo_setup):
    """Test PPO result plotting (non-interactive)."""
    model, log_dir, ppo_run_time = ppo_setup
    x, y = ts2xy(load_results(str(log_dir)), "timesteps")

    # Simple validation: no crash and x, y are arrays
    assert x is not None
    assert len(x) > 0, "No training data found in monitor logs."
    assert y is not None

    # Plot (non-blocking)
    plt.figure()
    plt.plot(x, y)
    plt.xlabel("Timesteps")
    plt.ylabel("Rewards")
    plt.title(f"Learning Curve in {ppo_run_time:.0f} seconds")
    plt.grid(True)
    os.makedirs("tests/plots", exist_ok=True)
    plt.savefig("tests/plots/PPO_learning_curve.png")
    plt.close()


if __name__ == "__main__":
    print("This file should be called with pytest.")
