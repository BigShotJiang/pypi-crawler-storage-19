"""Test the Pickomino environment can be pickled and unpickled."""

import pickle
import gymnasium
import pickomino_env  # type: ignore[import-not-found] # noqa:F401


def test_pickomino_serialization() -> None:
    """Test the Pickomino environment can be pickled and unpickled."""
    env = gymnasium.make("Pickomino-v0", number_of_bots=1)
    pickled: bytes = pickle.dumps(env)
    env2 = pickle.loads(pickled)  # type: ignore[arg-type]
    assert env2 is not None
