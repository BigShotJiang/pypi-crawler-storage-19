"""Test rendering."""

from __future__ import annotations

import time
import pytest
import warnings

import pickomino_env  # noqa: F401
from pickomino_env.pickomino_gym_env import PickominoEnv  # type: ignore[import-not-found]

# pygame internally uses deprecated pkg_resources
# See: https://setuptools.pypa.io/en/latest/pkg_resources.html
warnings.filterwarnings("ignore", category=UserWarning, module="pygame.pkgdata")


@pytest.mark.slow
def test_render_human_mode():
    """Test rendering in the human mode during environment steps."""
    env = PickominoEnv(render_mode="human", number_of_bots=4)
    _, _ = env.reset()

    terminated = False
    while not terminated:
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        env.render()
        time.sleep(0.05)  # Time between steps in seconds.

    env.close()


if __name__ == "__main__":
    print("This file should be called with pytest.")
