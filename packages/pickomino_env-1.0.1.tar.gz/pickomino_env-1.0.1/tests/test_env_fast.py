"""Fast environment tests for pre-commit."""

from __future__ import annotations

import time
from typing import Any
import numpy as np
import pytest
import gymnasium as gym
from gymnasium.utils.env_checker import check_env
from stable_baselines3 import PPO
from stable_baselines3.common.env_checker import check_env as sb3_check_env
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.results_plotter import load_results, ts2xy
from stable_baselines3.common.vec_env import DummyVecEnv


# side-effect import, required for environment registration.
import pickomino_env  # type: ignore[import-not-found] # noqa:F401
from pickomino_env.modules.bot import Bot  # type: ignore[import-not-found]
from pickomino_env.modules.constants import MAX_BOTS
from pickomino_env.pickomino_gym_env import PickominoEnv

# Create an environment to test.
env = gym.make("Pickomino-v0", render_mode=None, number_of_bots=2)  # base environment


def test_env():
    """Gymnasium standard test."""
    check_env(env.unwrapped)


@pytest.mark.parametrize("number_of_bots", [0, MAX_BOTS + 1])
def test_init_number_of_bots_invalid(number_of_bots: int) -> None:
    """Test __init__ raises ValueError on invalid number_of_bots."""
    with pytest.raises(ValueError):
        PickominoEnv(number_of_bots=number_of_bots)


@pytest.mark.parametrize("number_of_bots", [1, MAX_BOTS])
def test_init_number_of_bots_valid(number_of_bots: int) -> None:
    """Test __init__ accepts a valid number_of_bots."""
    valid_env = PickominoEnv(number_of_bots=number_of_bots)
    assert valid_env is not None


@pytest.mark.parametrize("render_mode", ["invalid", "matplotlib", 42])
def test_init_render_mode_invalid(render_mode: str) -> None:
    """Test __init__ raises ValueError on invalid render_mode."""
    with pytest.raises(ValueError):
        PickominoEnv(number_of_bots=1, render_mode=render_mode)


@pytest.mark.parametrize("render_mode", [None, "human", "rgb_array"])
def test_init_render_mode_valid(render_mode: str | None) -> None:
    """Test that __init__ accepts valid render_mode."""
    valid_env = PickominoEnv(number_of_bots=1, render_mode=render_mode)
    assert valid_env is not None


def test_render_raises_when_render_mode_none():
    """Test render raises ValueError when render mode is None."""
    render_non_env = PickominoEnv(number_of_bots=1)  # render_mode defaults to None
    render_non_env.reset()
    with pytest.raises(ValueError):
        render_non_env.render()


@pytest.mark.parametrize("seed", [3.14, -1])
def test_reset_invalid_seed(seed: Any) -> None:
    """Test reset raises ValueError on an invalid seed."""
    seed_test_env = PickominoEnv(number_of_bots=1)
    with pytest.raises(ValueError):
        seed_test_env.reset(seed=seed)  # noqa, float, not int.


def test_reset_invalid_options_type():
    """Test reset raises ValueError on invalid options type."""
    options_test_env = PickominoEnv(number_of_bots=1)
    with pytest.raises(ValueError):
        options_test_env.reset(options="invalid")  # noqa, str, not dict.


@pytest.mark.parametrize("seed", [None, 0, 42, 999999])
def test_reset_valid_seed(seed: int | None) -> None:
    """Test reset accepts valid seed values."""
    seed_env = PickominoEnv(number_of_bots=1)
    obs, info = seed_env.reset(seed=seed)
    assert obs is not None
    assert info is not None


@pytest.mark.parametrize("options", [None, {}])
def test_reset_valid_options(options: dict[str, Any] | None) -> None:
    """Test reset accepts valid options values."""
    options_env = PickominoEnv(number_of_bots=1)
    obs, info = options_env.reset(options=options)
    assert obs is not None
    assert info is not None


@pytest.mark.parametrize("action", [0, [0, 0], {0, 1}, (0,), (0, 0, 1)])
def test_step_invalid_action_type_or_length(action: Any) -> None:
    """Test step raises ValueError on an invalid action type/length."""
    action_env = PickominoEnv(number_of_bots=1)
    action_env.reset()
    with pytest.raises(ValueError):
        action_env.step(action)


@pytest.mark.parametrize("dice_index,roll_action", [(3.14, 0), ("0", 0), (None, 0)])
def test_step_invalid_action_dice_index_type(dice_index: Any, roll_action: int) -> None:
    """Test step raises TypeError on an invalid dice index type."""
    dice_index_env = PickominoEnv(number_of_bots=1)
    dice_index_env.reset()
    with pytest.raises(TypeError):
        dice_index_env.step((dice_index, roll_action))


@pytest.mark.parametrize("dice_index,roll_action", [(0, 3.14), (0, "0"), (0, None)])
def test_step_invalid_action_roll_action_type(
    dice_index: int, roll_action: Any
) -> None:
    """Test step raises TypeError on an invalid roll action type."""
    roll_action_env = PickominoEnv(number_of_bots=1)
    roll_action_env.reset()
    with pytest.raises(TypeError):
        roll_action_env.step((dice_index, roll_action))


@pytest.mark.parametrize("dice_index,roll_action", [(-1, 0), (6, 0), (0, -1), (0, 2)])
def test_step_invalid_action_values(dice_index: int, roll_action: int) -> None:
    """Test step raises ValueError on invalid action values."""
    invalid_action_env = PickominoEnv(number_of_bots=1)
    invalid_action_env.reset()
    with pytest.raises(ValueError):
        invalid_action_env.step((dice_index, roll_action))


@pytest.mark.parametrize(
    "dice_index,roll_action", [(0, 0), (0, 1), (5, 0), (5, 1), (2, 1)]
)
def test_step_valid_action(dice_index: int, roll_action: int) -> None:
    """Test step accepts valid actions."""
    valid_action_env = PickominoEnv(number_of_bots=1)
    valid_action_env.reset()
    obs, reward, terminated, truncated, info = valid_action_env.step(
        (dice_index, roll_action)
    )
    assert obs is not None


def test_reset():
    """Test reset function."""
    observation, info = env.reset()
    assert np.array_equal(observation["dice_collected"], np.array([0, 0, 0, 0, 0, 0]))
    assert sum(observation["dice_rolled"]) == 8
    assert np.all(
        observation["tiles_table"] == 1
    )  # Initially [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    assert np.all(observation["tile_players"] == 0)  # Initially [0, 0, 0]


def test_step():
    """Test step function state invariants."""
    observation, info = env.reset()
    die_face_to_collect = np.argmax(observation["dice_rolled"])
    action = (die_face_to_collect, 0)  # Collect and keep rolling.
    observation, reward, terminated, truncated, info = env.step(action)

    # State invariant: total dice always 8.
    assert sum(observation["dice_collected"]) + sum(observation["dice_rolled"]) == 8
    # Initial action should not reward or set terminated.
    assert reward == 0
    assert not terminated
    assert not truncated
    assert info["player_stack"] == [0]  # Zero indicates the initial empty stack.


def test_multiple_actions():
    """Test multiple actions.

    Is a bit like play automated without printouts.
    """
    obs, info = env.reset()
    bot = Bot()
    total_reward = 0

    for step in range(100):
        selection, stop = bot.policy(
            obs["dice_rolled"], obs["dice_collected"], int(str(info["smallest_tile"]))
        )
        obs, reward, terminated, truncated, info = env.step((selection, stop))
        total_reward += reward
        if terminated:
            break


def test_dice_str():
    """Test dice string representation."""
    from pickomino_env.modules.dice import Dice

    dice = Dice()
    dice.roll()
    dice.collect(0)

    # Trigger __str__
    result = str(dice)

    assert isinstance(result, str)
    assert len(result) > 0


def test_stable_baselines3():
    """Test environment works correctly with Stable Baselines3."""
    sb3_check_env(env)


@pytest.fixture(scope="session")
def ppo_setup_fast(tmp_path_factory):
    """Fixture for creating a Proximal Policy Optimization (PPO) model from Stable Baselines3."""
    log_dir = tmp_path_factory.mktemp("ppo_fast_logs")

    def make_env(rank):
        """Create environment with function for testing PPO."""

        def _init():
            ppo_env = gym.make("Pickomino-v0", render_mode=None, number_of_bots=6)
            ppo_env = Monitor(ppo_env, filename=f"{log_dir}/{rank}")
            return ppo_env

        return _init

    # Vectorize environment for PPO for parallel environments
    par_env = DummyVecEnv(
        [make_env(i) for i in range(2)]
    )  # 2 sequential envs for debugging.
    model = PPO("MultiInputPolicy", par_env)  # Add ', verbose=1' as necessary

    start_time = time.time()
    # 1 step = one action, not an episode.
    model.learn(total_timesteps=10)  # Run fast
    ppo_run_time = time.time() - start_time
    assert ppo_run_time < 30, f"PPO training took too long: {ppo_run_time:.0f} seconds"
    return model, log_dir, ppo_run_time


def test_ppo_run(ppo_setup_fast):
    """Test PPO model trains and produces data."""
    model, log_dir, ppo_run_time = ppo_setup_fast
    x, y = ts2xy(load_results(str(log_dir)), "timesteps")

    # Simple validation: no crash and x, y are arrays
    assert x is not None
    assert len(x) > 0, "No training data produced."
    assert y is not None


if __name__ == "__main__":
    print("This file should be called with pytest.")
