"""Tests for Polecat."""
