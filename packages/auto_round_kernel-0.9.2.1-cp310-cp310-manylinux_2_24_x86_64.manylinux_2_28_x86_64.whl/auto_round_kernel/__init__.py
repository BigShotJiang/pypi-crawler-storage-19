# Copyright (c) 2025 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import torch


class ARK_DT:
    float64 = 64
    float32 = 32
    float16 = 16
    bfloat16 = 65552
    int2 = 258
    int3 = 259
    int4 = 260
    int5 = 261
    int6 = 262
    int7 = 263
    int8 = 264
    int32 = 288
    float8_e4m3 = 8
    float8_e5m2 = 65544
    float8_e8m0 = 196616
    undef = 0


def cvt_dtype(dtype):
    if dtype == torch.float32:
        return ARK_DT.float32
    if dtype == torch.float16:
        return ARK_DT.float16
    if dtype == torch.bfloat16:
        return ARK_DT.bfloat16
    if dtype == torch.float8_e4m3fn:
        return ARK_DT.float8_e4m3
    if dtype == torch.float8_e5m2:
        return ARK_DT.float8_e5m2
    if dtype == torch.int8:
        return ARK_DT.int8
    if dtype == torch.int32:
        return ARK_DT.int32
    return ARK_DT.undef


def cvtstr_dtype(dtype):
    if dtype == "fp32":
        return ARK_DT.float32
    if dtype == "fp16":
        return ARK_DT.float16
    if dtype == "bf16":
        return ARK_DT.bfloat16
    if dtype == "fp8_e4m3":
        return ARK_DT.float8_e4m3
    if dtype == "fp8_e5m2":
        return ARK_DT.float8_e5m2
    if dtype == "fp8_e8m0":
        return ARK_DT.float8_e8m0
    if dtype == "int8":
        return ARK_DT.int8
    if dtype == "int4":
        return ARK_DT.int4
    if dtype == "int2":
        return ARK_DT.int2
    if dtype == "int3":
        return ARK_DT.int3
    if dtype == "int5":
        return ARK_DT.int5
    if dtype == "int6":
        return ARK_DT.int6
    if dtype == "int7":
        return ARK_DT.int7
    if dtype == "int32":
        return ARK_DT.int32
    return ARK_DT.undef


def get_stream(A: torch.Tensor) -> int:
    if A.device.type == "cpu":
        return 0
    if A.device.type == "xpu":
        return torch.xpu.current_stream().sycl_queue


def singleton(cls):
    """
    一个简单的单例模式装饰器
    """
    instances = {}  # 存储类与实例的映射关系

    def get_instance(*args, **kwargs):
        # 如果类不在字典中，则创建一个并存入
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        # 如果已经在字典中，直接返回之前创建的那个
        return instances[cls]

    return get_instance


@singleton
class ARK:
    cpu_lib = None
    xpu_lib = None

    def __init__(self):
        try:
            from . import auto_round_kernel_cpu

            self.cpu_lib = auto_round_kernel_cpu
        except ImportError as e:
            print(f"ARK is unable to load CPU lib: {e}")
            self.cpu_lib = None

        try:
            from . import auto_round_kernel_xpu

            self.xpu_lib = auto_round_kernel_xpu
        except ImportError as e:
            print(f"ARK is unable to load XPU lib: {e}")
            self.xpu_lib = None

    def get_lib(self, A: torch.Tensor):
        lib = None
        if A.device.type == "xpu":
            lib = self.xpu_lib
        if A.device.type == "cpu":
            lib = self.cpu_lib
        if lib is None:
            raise NotImplementedError(f"Current device {A.device} is not supported")
        return lib

    # A: mxk,  B: nxk, bias: n
    def matmul(self, A: torch.Tensor, B: torch.Tensor, bias: torch.Tensor):
        m = A.shape[0]
        n = B.shape[0]
        k = B.shape[1]
        lib = self.get_lib(A)
        ctype = A.dtype
        if A.device.type == "cpu":
            ctype = torch.float32
        C = torch.zeros(m, n, dtype=ctype, device=A.device)
        stream = get_stream(A)
        lib.matmul(
            stream,
            m,
            n,
            k,
            A.contiguous().data_ptr(),
            cvt_dtype(A.dtype),
            B.contiguous().data_ptr(),
            cvt_dtype(B.dtype),
            C.contiguous().data_ptr(),
            cvt_dtype(C.dtype),
            bias.to(C.dtype).contiguous().data_ptr(),
            True,
        )
        return C

    # A: mxk:s8,  B: nxk:s8, return: mxn:s32
    def igemm_s8s8s32(self, A: torch.Tensor, B: torch.Tensor):
        m = A.shape[0]
        n = B.shape[0]
        k = B.shape[1]
        lib = self.get_lib(A)
        if lib is None:
            raise NotImplementedError(f"Current device {A.device} is not supported")
        C = torch.zeros(m, n, dtype=torch.int32, device=A.device)
        stream = get_stream(A)
        lib.matmul(
            stream,
            m,
            n,
            k,
            A.contiguous().data_ptr(),
            cvt_dtype(A.dtype),
            B.contiguous().data_ptr(),
            cvt_dtype(B.dtype),
            C.contiguous().data_ptr(),
            cvt_dtype(C.dtype),
            0,
            True,
        )
        return C

    # A: mxk:DT,  B: nxk:s8, scaleB: n:DT
    # return: mxn:DT
    def woqgemm_s8(self, A: torch.Tensor, B: torch.Tensor, scaleB: torch.Tensor, bias: torch.Tensor):
        m = A.shape[0]
        n = B.shape[0]
        k = B.shape[1]
        lib = self.get_lib(A)

        C = torch.zeros(m, n, dtype=A.dtype, device=A.device)
        stream = get_stream(A)
        lib.woqgemm_s8(
            stream,
            m,
            n,
            k,
            A.contiguous().data_ptr(),
            cvt_dtype(A.dtype),
            B.contiguous().data_ptr(),
            C.contiguous().data_ptr(),
            bias.contiguous().data_ptr(),
            True,
            scaleB.contiguous().data_ptr(),
        )
        return C

    # A: mxk:DT,  B: BS:s8, bias: n:DT
    # return: C: mxn:DT
    def woqgemm(
        self,
        A: torch.Tensor,
        B: torch.Tensor,
        bias: torch.Tensor,
        n,
        k,
        groupsize,
        compute_type,
        weight_type,
        scale_type,
        asym,
    ):
        m = A.shape[0]
        lib = self.get_lib(A)
        ct = cvtstr_dtype(compute_type)
        wt = cvtstr_dtype(weight_type)
        st = cvtstr_dtype(scale_type)
        C = torch.zeros(m, n, dtype=A.dtype, device=A.device)
        stream = get_stream(A)
        lib.woqgemm(
            stream,
            m,
            n,
            k,
            A.contiguous().data_ptr(),
            cvt_dtype(A.dtype),
            B.contiguous().data_ptr(),
            C.contiguous().data_ptr(),
            bias.contiguous().data_ptr(),
            groupsize,
            ct,
            wt,
            st,
            asym,
        )
        return C

    # QB: k*n:int8,  scaleB: k/blocksize*n:DT
    # return: blob:BS:int8
    def repack_quantized_weight(
        self,
        QB: torch.Tensor,
        scaleB: torch.Tensor,
        zp: torch.Tensor,
        groupsize,
        compute_type,
        weight_type,
        scale_type,
        asym,
    ):
        k = QB.shape[0]
        n = QB.shape[1]
        lib = self.get_lib(QB)
        stream = get_stream(QB)
        ct = cvtstr_dtype(compute_type)
        wt = cvtstr_dtype(weight_type)
        st = cvtstr_dtype(scale_type)
        BS = lib.packed_weight_size(stream, n, k, groupsize, ct, wt, st, asym)
        blob = torch.zeros(BS, dtype=torch.int8, device=QB.device)
        lib.repack_quantized_weight(
            stream,
            QB.contiguous().data_ptr(),
            zp.contiguous().data_ptr(),
            scaleB.contiguous().data_ptr(),
            blob.data_ptr(),
            n,
            k,
            groupsize,
            ct,
            wt,
            st,
            asym,
        )
        return blob

    # QB: blob:BS:int8
    # return: out:nxk:out_dtype
    def unpack_weight(
        self,
        blob: torch.Tensor,
        out_dtype: torch.dtype,
        n,
        k,
        groupsize,
        compute_type,
        weight_type,
        scale_type,
        asym,
    ):
        lib = self.get_lib(blob)
        stream = get_stream(blob)
        ct = cvtstr_dtype(compute_type)
        wt = cvtstr_dtype(weight_type)

        st = cvtstr_dtype(scale_type)
        oshape = (n, k) if blob.device.type == "xpu" else (k, n)
        out = torch.zeros(oshape, dtype=out_dtype, device=blob.device)
        lib.unpack_weight(
            stream,
            blob.data_ptr(),
            out.data_ptr(),
            cvt_dtype(out_dtype),
            n,
            k,
            groupsize,
            ct,
            wt,
            st,
            asym,
        )
        if blob.device.type == "cpu":
            return out.T
        return out


if __name__ == "__main__":
    ark = ARK()
    print(ark.cpu_lib is None, ark.xpu_lib is None)

    def matmul():
        m = n = k = 128
        dt = torch.int8
        device = "cpu"
        has_bias = False
        if dt == torch.int8:
            A = torch.randint(-128, 127, (m, k), dtype=dt, device=device)
            B = torch.randint(-128, 127, (n, k), dtype=dt, device=device)
            C = ark.igemm_s8s8s32(A, B)
            print(C)
        else:
            A = torch.rand(m, k, dtype=dt, device=device) - 0.5
            B = torch.rand(k, n, dtype=dt, device=device) - 0.5
            bias = torch.rand(1, n, dtype=dt, device=device) if has_bias else torch.empty(0)
            C = ark.matmul(A, B, bias)
        ref = torch.matmul(A, B.T)
        if has_bias:
            ref = ref + bias
        dff = abs(C - ref)
        if dt != torch.int8:
            print(dff.max(), dff.mean())
            print(torch.allclose(ref, C, 0.01, 0.1))

    def woq():
        m = n = k = 128
        dt = torch.float32
        device = "cpu"
        A = torch.rand(m, k, dtype=dt, device=device) - 0.5
        bias = torch.rand(1, n, dtype=dt, device=device) + 1000
        B = torch.randint(-128, 127, (n, k), dtype=torch.int8, device=device)
        scaleB = torch.rand(n, 1, dtype=dt, device=device)
        C = ark.woqgemm_s8(A, B, scaleB, bias)
        print(C)
        DB = B.to(dt) * scaleB
        ref = torch.matmul(A, DB.T) + bias
        print(ref)
        dff = abs(C - ref)
        print(dff.max(), dff.mean())

    def pack_unpack():
        m = n = k = 128
        groupsize = 32
        dt = torch.float32
        device = "xpu"
        B = torch.randint(-8, 7, (k, n), dtype=torch.int8, device=device)
        zp = torch.randint(-8, 7, (k // groupsize, n), dtype=torch.int8, device=device)
        scaleB = torch.rand(k // groupsize, n, dtype=dt, device=device) / 100
        blob = ark.repack_quantized_weight(B, scaleB, zp, groupsize, "fp32", "int4", "fp32", False)
        dq = ark.unpack_weight(blob, dt, n, k, groupsize, "fp32", "int4", "fp32", False)
        print(blob, dq)
        scale_re = scaleB.repeat_interleave(repeats=groupsize, dim=0).to(dt)

        DB = B.to(dt) * scale_re
        dff = abs(DB.T - dq)
        print(dff.max(), dff.mean())

    pack_unpack()


__all__ = ["ARK"]
