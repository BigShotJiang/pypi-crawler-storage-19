"""MACE Inference test suite"""
