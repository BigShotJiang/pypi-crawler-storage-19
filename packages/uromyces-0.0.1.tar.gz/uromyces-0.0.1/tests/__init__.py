"""Python tests for uromyces."""
