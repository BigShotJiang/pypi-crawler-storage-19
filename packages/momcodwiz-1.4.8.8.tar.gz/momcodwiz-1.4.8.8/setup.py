from setuptools import setup,find_packages
setup(
    name="momcodwiz",
    version="1.4.8.8",
    packages=find_packages(),
    python_requires=">=3.8",
)
