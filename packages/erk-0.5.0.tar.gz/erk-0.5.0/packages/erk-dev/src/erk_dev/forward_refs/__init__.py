"""Forward reference detection utilities."""
