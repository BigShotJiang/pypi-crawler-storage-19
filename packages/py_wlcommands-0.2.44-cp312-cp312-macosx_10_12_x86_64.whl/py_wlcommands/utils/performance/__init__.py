"""Performance monitoring utilities package."""
