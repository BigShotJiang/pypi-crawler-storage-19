"""
AWS-specific stub configuration for dataclass_dsl.

Provides AWS_STUB_CONFIG for generating .pyi stub files that work
with wetwire-aws imports. The stub generator uses this to expand
star imports and re-export all service modules.
"""

from dataclass_dsl import StubConfig, get_package_modules

# All names exported from wetwire_aws that should be available
# via `from . import *` in resource packages.
AWS_CORE_EXPORTS = [
    # Decorator
    "wetwire_aws",
    # Base classes
    "CloudFormationResource",
    "PropertyType",
    # Policy helpers
    "PolicyStatement",
    "DenyStatement",
    "PolicyDocument",
    # Template and components
    "CloudFormationTemplate",
    "Parameter",
    "Output",
    "Mapping",
    "TemplateCondition",
    # Reference types from dataclass-dsl
    "Ref",
    "RefList",
    "RefDict",
    # Reference helpers
    "ref",
    "get_att",
    "ARN",
    # Intrinsic functions (CF intrinsics)
    "GetAtt",
    "Sub",
    "Join",
    "Select",
    "Split",
    "If",
    "Equals",
    "And",
    "Or",
    "Not",
    "Base64",
    "GetAZs",
    "ImportValue",
    "FindInMap",
    "Transform",
    "Cidr",
    "Condition",
    # Parameter type constants
    "STRING",
    "NUMBER",
    "LIST_NUMBER",
    "COMMA_DELIMITED_LIST",
    "SSM_PARAMETER_STRING",
    "SSM_PARAMETER_STRING_LIST",
    "AVAILABILITY_ZONE",
    "LIST_AVAILABILITY_ZONE",
    "AMI_ID",
    "INSTANCE_ID",
    "KEY_PAIR",
    "SECURITY_GROUP_ID",
    "LIST_SECURITY_GROUP_ID",
    "SUBNET_ID",
    "LIST_SUBNET_ID",
    "VPC_ID",
    "VOLUME_ID",
    "HOSTED_ZONE_ID",
    # Pseudo-parameters
    "AWS_ACCOUNT_ID",
    "AWS_NOTIFICATION_ARNS",
    "AWS_NO_VALUE",
    "AWS_PARTITION",
    "AWS_REGION",
    "AWS_STACK_ID",
    "AWS_STACK_NAME",
    "AWS_URL_SUFFIX",
]

# Service modules dynamically discovered from wetwire_aws.resources
# This replaces the previous 260+ line static list
AWS_SERVICE_MODULES = get_package_modules("wetwire_aws.resources")

# Build extra header lines that include core wetwire_aws imports
# These are needed because setup_params() and setup_resources() inject
# names dynamically, but the IDE can't see that from static analysis
_CORE_IMPORT_LINES = [
    "# Core exports injected by setup_params() and setup_resources()",
    "from wetwire_aws import (",
    "    # Decorator",
    "    wetwire_aws,",
    "    # Base classes",
    "    CloudFormationResource,",
    "    PropertyType,",
    "    # Policy helpers",
    "    PolicyStatement,",
    "    DenyStatement,",
    "    PolicyDocument,",
    "    # Template components",
    "    CloudFormationTemplate,",
    "    Parameter,",
    "    Output,",
    "    Mapping,",
    "    TemplateCondition,",
    "    # Reference types (from dataclass-dsl)",
    "    Ref,",
    "    RefList,",
    "    RefDict,",
    "    # Reference helpers",
    "    ref,",
    "    get_att,",
    "    ARN,",
    "    # Intrinsic functions",
    "    GetAtt,",
    "    Sub,",
    "    Join,",
    "    Select,",
    "    Split,",
    "    If,",
    "    Equals,",
    "    And,",
    "    Or,",
    "    Not,",
    "    Base64,",
    "    GetAZs,",
    "    ImportValue,",
    "    FindInMap,",
    "    Transform,",
    "    Cidr,",
    "    Condition,",
    "    # Parameter type constants",
    "    STRING,",
    "    NUMBER,",
    "    LIST_NUMBER,",
    "    COMMA_DELIMITED_LIST,",
    "    SSM_PARAMETER_STRING,",
    "    SSM_PARAMETER_STRING_LIST,",
    "    # AWS-specific parameter types",
    "    AVAILABILITY_ZONE,",
    "    LIST_AVAILABILITY_ZONE,",
    "    AMI_ID,",
    "    INSTANCE_ID,",
    "    KEY_PAIR,",
    "    SECURITY_GROUP_ID,",
    "    LIST_SECURITY_GROUP_ID,",
    "    SUBNET_ID,",
    "    LIST_SUBNET_ID,",
    "    VPC_ID,",
    "    VOLUME_ID,",
    "    HOSTED_ZONE_ID,",
    "    # Pseudo-parameters",
    "    AWS_ACCOUNT_ID,",
    "    AWS_NOTIFICATION_ARNS,",
    "    AWS_NO_VALUE,",
    "    AWS_PARTITION,",
    "    AWS_REGION,",
    "    AWS_STACK_ID,",
    "    AWS_STACK_NAME,",
    "    AWS_URL_SUFFIX,",
    ")",
    "from wetwire_aws.resources import (",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[:30]) + ",",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[30:60]) + ",",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[60:90]) + ",",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[90:120]) + ",",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[120:150]) + ",",
    "    " + ",\n    ".join(AWS_SERVICE_MODULES[150:]) + ",",
    ")",
]

AWS_STUB_CONFIG = StubConfig(
    package_name="wetwire_aws",
    core_imports=AWS_CORE_EXPORTS + AWS_SERVICE_MODULES,
    expand_star_imports={
        "wetwire_aws": AWS_CORE_EXPORTS + AWS_SERVICE_MODULES,
    },
    extra_header_lines=_CORE_IMPORT_LINES,
)
