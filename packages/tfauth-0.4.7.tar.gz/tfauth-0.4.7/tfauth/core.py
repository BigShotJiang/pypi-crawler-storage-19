import os
import requests
from dotenv import load_dotenv

load_dotenv()

class TFAuth:
    def __init__(self):
        # Настройки API
        self.TAPI = None
        self.GAPI = os.getenv("GOOGLE_CLIENT_ID", "")
        self.FAPI = os.getenv("FACEBOOK_APP_ID", "")
        
        # Настройки дизайна
        self.color1 = "#ff416c"
        self.color2 = "#4b6cb7"
        
        # Ссылки и База данных
        self.db = "database.txt" # Файл, куда в будущем полетят данные
        self.forgotpassword = "forgotpassword.html"
        self.successlogin = "successl.html"
        self.sucessregister = "successr.html"
        
        self.GITHUB_KEYS_URL = "https://raw.githubusercontent.com/TLETIFORMAT/apifs/main/APIKEYS.json"

    def _check_access(self):
        if not self.TAPI: return False
        try:
            res = requests.get(self.GITHUB_KEYS_URL, timeout=5)
            return self.TAPI in res.json() if res.status_code == 200 else False
        except: return False

    def generate_html(self):
        if not self._check_access():
            return "<h1>403 Forbidden: Invalid TAPI</h1>"

        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, {self.color1} 0%, {self.color2} 100%);
            height: 100vh; display: flex; align-items: center; justify-content: center;
        }}
        .card {{
            background: #fff; width: 380px; padding: 40px; border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2); text-align: center;
        }}
        .input-group {{ text-align: left; margin-bottom: 15px; border-bottom: 2px solid #eee; }}
        .input-group label {{ font-size: 11px; color: #888; font-weight: 600; }}
        .field {{ display: flex; align-items: center; padding: 8px 0; }}
        .field i {{ color: {self.color2}; margin-right: 10px; }}
        .field input {{ border: none; outline: none; width: 100%; font-size: 14px; }}
        .btn {{
            width: 100%; padding: 12px; border: none; border-radius: 25px;
            background: linear-gradient(to right, {self.color1}, {self.color2});
            color: white; font-weight: bold; cursor: pointer; margin-top: 15px;
        }}
        .hidden {{ display: none; }}
        .toggle {{ font-size: 12px; color: #666; cursor: pointer; margin-top: 15px; }}
        .toggle b {{ color: {self.color1}; }}
    </style>
</head>
<body>
    <div class="card">
        <div id="login-box">
            <h2>Login</h2>
            <div class="input-group"><label>Username</label><div class="field"><i class="fa fa-user"></i><input type="text" id="l-user"></div></div>
            <div class="input-group"><label>Password</label><div class="field"><i class="fa fa-lock"></i><input type="password" id="l-pass"></div></div>
            <button class="btn" onclick="handleLogin()">LOGIN</button>
            <p class="toggle" onclick="toggle()">New here? <b>Sign Up</b></p>
        </div>

        <div id="reg-box" class="hidden">
            <h2>Register</h2>
            <div class="input-group"><label>Email</label><div class="field"><i class="fa fa-envelope"></i><input type="email" id="r-email"></div></div>
            <div class="input-group"><label>Username</label><div class="field"><i class="fa fa-user"></i><input type="text" id="r-user"></div></div>
            <div class="input-group"><label>Password</label><div class="field"><i class="fa fa-lock"></i><input type="password" id="r-pass"></div></div>
            <button class="btn" onclick="handleRegister()">SIGN UP</button>
            <p class="toggle" onclick="toggle()">Back to <b>Login</b></p>
        </div>
    </div>

    <script>
        function toggle() {{
            document.getElementById('login-box').classList.toggle('hidden');
            document.getElementById('reg-box').classList.toggle('hidden');
        }}

        function handleRegister() {{
            const data = {{
                email: document.getElementById('r-email').value,
                user: document.getElementById('r-user').value,
                pass: document.getElementById('r-pass').value
            }};
            // Сохраняем в браузере (чтобы не пропадало после перезагрузки)
            localStorage.setItem('saved_user', JSON.stringify(data));
            alert('Registered! Data saved to LocalStorage. Redirecting...');
            location.href = '{self.sucessregister}';
        }}

        function handleLogin() {{
            const saved = JSON.parse(localStorage.getItem('saved_user'));
            const user = document.getElementById('l-user').value;
            const pass = document.getElementById('l-pass').value;

            if(saved && user === saved.user && pass === saved.pass) {{
                location.href = '{self.successlogin}';
            }} else {{
                alert('Invalid login or user not found!');
            }}
        }}
    </script>
</body>
</html>
        """