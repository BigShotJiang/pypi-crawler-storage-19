class PaginationResetRequiredException(Exception):
    pass
