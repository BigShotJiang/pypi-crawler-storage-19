"""Utilities function."""
