"""Git integration for Consensys."""
