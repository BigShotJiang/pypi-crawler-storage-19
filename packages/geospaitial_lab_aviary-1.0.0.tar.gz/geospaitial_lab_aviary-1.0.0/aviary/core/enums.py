#  Copyright (C) 2024-2025 Marius Maryniak
#
#  This file is part of aviary.
#
#  aviary is free software: you can redistribute it and/or modify it under the terms of the
#  GNU General Public License as published by the Free Software Foundation,
#  either version 3 of the License, or (at your option) any later version.
#
#  aviary is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
#  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with aviary.
#  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from enum import Enum as BaseEnum
from typing import (
    TYPE_CHECKING,
    overload,
)

import rasterio as rio

if TYPE_CHECKING:
    from aviary.core.type_aliases import ChannelNameSet


class Enum(BaseEnum):  # noqa: D101

    def __str__(self) -> str:
        """Returns the string representation.

        Returns:
            String representation
        """
        return self.value


class ChannelName(Enum):
    """
    Attributes:
        B: Blue channel
        G: Green channel
        NIR: Near-infrared channel
        R: Red channel
    """
    B = 'b'
    G = 'g'
    NIR = 'nir'
    R = 'r'


_built_in_channel_names = frozenset(channel_name.value for channel_name in ChannelName)


@overload
def _coerce_channel_name(
    channel_name: ChannelName,
) -> ChannelName:
    ...


@overload
def _coerce_channel_name(
    channel_name: str,
) -> ChannelName | str:
    ...


@overload
def _coerce_channel_name(
    channel_name: None,
) -> None:
    ...


def _coerce_channel_name(
    channel_name: ChannelName | str | None,
) -> ChannelName | str | None:
    """Coerces `channel_name` to `ChannelName`.

    Parameters:
        channel_name: Channel name

    Returns:
        Channel name
    """
    if channel_name is None:
        return None

    if isinstance(channel_name, str) and channel_name in _built_in_channel_names:
        return ChannelName(channel_name)

    return channel_name


def _coerce_channel_names(
    channel_names:
        ChannelName | str |
        ChannelNameSet |
        bool |
        None,
) -> ChannelNameSet | bool:
    """Coerces `channel_names` to `ChannelNameSet`.

    Parameters:
        channel_names: Channel name, channel names, no channels (False or None), or all channels (True)

    Returns:
        Channel names or all channels (True)
    """
    if channel_names is True:
        return True

    if channel_names is False or channel_names is None:
        return set()

    if isinstance(channel_names, (ChannelName | str)):
        return {_coerce_channel_name(channel_name=channel_names)}

    return {
        _coerce_channel_name(channel_name=channel_name)
        for channel_name in channel_names
    }


def _coerce_layer_names(
    layer_names: str | set[str] | bool | None,
) -> set[str] | bool:
    """Coerces `layer_names` to `set[str]`.

    Parameters:
        layer_names: Layer name, layer names, no layers (False or None), or all layers (True)

    Returns:
        Layer names or all layers (True)
    """
    if layer_names is True:
        return True

    if layer_names is False or layer_names is None:
        return set()

    if isinstance(layer_names, str):
        return {layer_names}

    return layer_names


class GeospatialFilterMode(Enum):
    """
    Attributes:
        DIFFERENCE: Difference mode
        INTERSECTION: Intersection mode
    """
    DIFFERENCE = 'difference'
    INTERSECTION = 'intersection'


class InterpolationMode(Enum):
    """
    Attributes:
        BILINEAR: Bilinear mode
        NEAREST: Nearest mode
    """
    BILINEAR = 'bilinear'
    NEAREST = 'nearest'

    def to_rio(self) -> rio.enums.Resampling:
        """Converts the interpolation mode to the rasterio resampling mode.

        Returns:
            Rasterio resampling mode
        """
        mapping = {
            InterpolationMode.BILINEAR: rio.enums.Resampling.bilinear,
            InterpolationMode.NEAREST: rio.enums.Resampling.nearest,
        }
        return mapping[self]


class SetFilterMode(Enum):
    """
    Attributes:
        DIFFERENCE: Difference mode
        INTERSECTION: Intersection mode
        UNION: Union mode
    """
    DIFFERENCE = 'difference'
    INTERSECTION = 'intersection'
    UNION = 'union'


class WMSVersion(Enum):
    """
    Attributes:
        V1_1_1: Version 1.1.1
        V1_3_0: Version 1.3.0
    """
    V1_1_1 = '1.1.1'
    V1_3_0 = '1.3.0'
