"""Razer Control Center tests."""
