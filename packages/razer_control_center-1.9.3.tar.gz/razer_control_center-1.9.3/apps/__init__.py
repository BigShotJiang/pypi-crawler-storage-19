"""Razer Control Center applications."""
