from __future__ import annotations
import typing
from . import actions
from . import chunk_store
from . import data
from . import nodes
from . import redis
from . import service
from . import webrtc
from . import websockets
__all__: list[str] = ['GlobalSettings', 'actions', 'chunk_store', 'data', 'get_global_settings', 'nodes', 'redis', 'run_threadsafe_if_coroutine', 'save_first_encountered_event_loop', 'service', 'webrtc', 'websockets']
class GlobalSettings:
    readers_deserialise_automatically: bool
    readers_read_in_order: bool
    readers_remove_read_chunks: bool
    @property
    def readers_buffer_size(self) -> int:
        ...
    @readers_buffer_size.setter
    def readers_buffer_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def readers_timeout(self) -> float:
        ...
    @readers_timeout.setter
    def readers_timeout(self, arg1: typing.SupportsFloat) -> None:
        ...
def get_global_settings() -> GlobalSettings:
    ...
def run_threadsafe_if_coroutine(function_call_result: typing.Any, loop: typing.Any = None, return_future: bool = False) -> typing.Any:
    ...
def save_first_encountered_event_loop() -> None:
    """
    Saves the first encountered event loop globally for later use.
    """
