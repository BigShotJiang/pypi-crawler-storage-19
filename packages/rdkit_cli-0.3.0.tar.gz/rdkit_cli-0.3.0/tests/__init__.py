"""Tests for rdkit-cli."""
