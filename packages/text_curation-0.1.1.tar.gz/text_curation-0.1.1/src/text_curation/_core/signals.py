class Signal:
    def __init__(self, name: str, value):
        self.name = name
        self.value = value