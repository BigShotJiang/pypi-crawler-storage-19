import pytest
from . import CodebergPackageDownloader, KnownPackages, PackageDescription


@pytest.mark.skip("Makes requests to codeberg")
def test_has_a_version():
    pd = PackageDescription(KnownPackages.connect, "0.1.3")
    downloader = CodebergPackageDownloader(pd)

    assert downloader.has_a_version("hollo", "0.6.19")
    assert not downloader.has_a_version("hollo", "0.6.20")
