# Changes

## 0.1.1

* Add docs [results#2](https://codeberg.org/funfedidev/funfedi_results/issues/2)
* Add ability to upload zip files to codeberg [results#3](https://codeberg.org/funfedidev/funfedi_results/issues/3)

## 0.1.0

* Initial release