# riyadhai-plugin-noise-cancellation

Meta-package that installs noise-cancellation runtime dependencies for the RiyadhAI SDK.
