"""Noise cancellation plugin for `riyadhai`.

This package currently provides the public import surface for noise cancellation,
but the implementation is not yet included.
"""

from __future__ import annotations

from typing import Any, NoReturn


def _not_available(*_: Any, **__: Any) -> NoReturn:
    raise NotImplementedError(
        "Noise cancellation is not yet available in the RiyadhAI plugin set. "
        "This distribution currently ships the import surface only."
    )


NC = _not_available
BVC = _not_available
BVCTelephony = _not_available
load = _not_available

__all__ = ["NC", "BVC", "BVCTelephony", "load"]
