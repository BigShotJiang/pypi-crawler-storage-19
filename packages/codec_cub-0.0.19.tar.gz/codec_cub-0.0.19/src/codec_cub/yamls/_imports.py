from typing import Any, Final

from yaml import YAMLError, __with_libyaml__, dump, load as yaml_load

HAS_LIB_YAML: Final[bool] = __with_libyaml__


class FlowDict(dict[str, Any]):
    """Dict subclass that renders in YAML flow style {key: value}."""


YamlData = dict[str, Any]


if HAS_LIB_YAML:
    from yaml import CDumper as Dumper, CFullLoader as FullLoader, CSafeDumper as SafeDumper, CSafeLoader as SafeLoader

    class CustomDumper(SafeDumper):  # type: ignore[misc]
        """Custom YAML dumper with specific formatting options.

        Primarily to allow you to have non-flow style for the majority
        of the YAML, but flow style for specific elements.
        """

    CustomDumper.add_representer(
        FlowDict,
        lambda dumper, data: dumper.represent_mapping(
            "tag:yaml.org,2002:map",
            data,
            flow_style=True,
        ),
    )

else:
    from yaml import Dumper, FullLoader, SafeDumper, SafeLoader

    class CustomDumper(SafeDumper):  # type: ignore[misc]
        """Custom YAML dumper with specific formatting options.

        Primarily to allow you to have non-flow style for the majority
        of the YAML, but flow style for specific elements.
        """

    CustomDumper.add_representer(
        FlowDict,
        lambda dumper, data: dumper.represent_mapping(
            "tag:yaml.org,2002:map",
            data,
            flow_style=True,
        ),
    )


__all__ = [
    "HAS_LIB_YAML",
    "CustomDumper",
    "Dumper",
    "FlowDict",
    "FullLoader",
    "SafeDumper",
    "SafeLoader",
    "YAMLError",
    "YamlData",
    "dump",
    "yaml_load",
]
