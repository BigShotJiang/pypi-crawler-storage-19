"""JSON Lines serialization utilities."""

from __future__ import annotations

from typing import IO, Any

from frozen_cub.dispatcher import Dispatcher

from codec_cub.general._orjson_helper import DecodeError, json_dumps, json_loads
from codec_cub.general.file_lock import LockShared
from funcy_bear.api import is_bytes, is_list, is_str

serialize = Dispatcher("data")
deserial = Dispatcher("data")


def to_lines(raw: str) -> list[str]:
    """Return a list of non-empty, stripped lines from the raw data.

    Args:
        raw: The raw string data to be processed.

    Returns:
        A list of non-empty, stripped lines.
    """
    return [line for line in raw.strip().splitlines() if line.strip()]


@serialize.dispatcher()
def jsonl_serialize(data: Any) -> list[bytes]:
    """Serialize an object to a JSON Lines format.

    Args:
        data: The object to serialize.

    Returns:
        A list of json bytes representing the serialized object.

    Raises:
        TypeError: If the object type is not supported for serialization.
    """
    raise TypeError(f"Object of type {type(data).__name__} is not JSON serializable")


@serialize.register(is_list)
def _(data: list) -> list[bytes]:
    return [json_dumps(record) for record in data]


@serialize.register(is_str)
def _(data: str) -> list[bytes]:
    return [line.encode("utf-8") for line in to_lines(data)]


@serialize.register(is_bytes)
def _(data: bytes) -> list[bytes]:
    return [line for line in data.split(b"\n") if line.strip()]


@deserial.dispatcher()
def deserialize_me(data: Any) -> dict[Any, Any]:
    """Deserialize dispatch for JSONL data."""
    raise TypeError(f"Cannot deserialize data of type {type(data).__name__} from JSONL format")


@deserial.register(is_str)
def _(data: str) -> dict[Any, Any]:
    return json_loads(data.encode("utf-8"))


@deserial.register(is_bytes)
def _(data: bytes) -> dict[Any, Any]:
    return json_loads(data)


def deserialize_line(i: int, line: bytes | str) -> dict[Any, Any]:
    """Deserialize a single line of JSONL data and append it to the data list.

    Args:
        i: The index of the line being processed (for error reporting).
        line: The line of JSONL data to deserialize.


    Raises:
        ValueError: If there is an error decoding the JSONL data.
        TypeError: If the decoded line is not a JSON object.
    """
    try:
        record: dict[Any, Any] = deserialize_me(line)
        if not isinstance(record, dict):
            raise TypeError(f"Line {i + 1} is not a JSON object: {line}")
        return record
    except DecodeError as e:
        raise ValueError(f"Error decoding JSONL data on line {i + 1}: {e}") from e


def deserialize(handle: IO[Any], n: int = -1) -> list[Any]:
    """Read JSON Lines data from a file handle and deserialize it into a list of dictionaries.

    Args:
        handle: The file handle to read from.
        n: The maximum number of characters to read (default: -1, read all).

    Returns:
        A list of dictionaries read from the JSON Lines file.
    """
    data: list[Any] = []
    with LockShared(handle):
        handle.seek(0)
        raw: str = handle.read(n)
        if not raw.strip():
            return data
        for index_line in enumerate(to_lines(raw)):
            data.append(deserialize_line(*index_line))
        return data
