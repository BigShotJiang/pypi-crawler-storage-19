"""Tests for JSONLFileHandler."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from codec_cub.jsonl.file_handler import JSONLFileHandler

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def jsonl_file(tmp_path: Path) -> Path:
    """Create a temporary JSONL file."""
    return tmp_path / "test.jsonl"


@pytest.fixture
def sample_records() -> list[dict[str, int | str]]:
    """Sample records for testing."""
    return [
        {"id": 1, "name": "Alice", "age": 30},
        {"id": 2, "name": "Bob", "age": 25},
        {"id": 3, "name": "Charlie", "age": 35},
    ]


class TestJSONLFileHandlerBasics:
    """Test basic read/write operations."""

    def test_write_and_read_records(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test writing and reading records."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        handler.write(sample_records)

        result = handler.read()
        assert result is not None
        assert len(result) == 3
        assert result[0]["name"] == "Alice"
        assert result[1]["age"] == 25
        handler.close()

    def test_read_empty_file(self, jsonl_file: Path) -> None:
        """Test reading an empty file returns None."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        result = handler.read()
        assert result is None
        handler.close()

    def test_write_replaces_content(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test that write() replaces existing content."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        handler.write(sample_records)

        new_records = [{"id": 99, "name": "New"}]
        handler.write(new_records)

        result = handler.read()
        assert result is not None
        assert len(result) == 1
        assert result[0]["id"] == 99
        handler.close()


class TestJSONLFileHandlerAppend:
    """Test append functionality."""

    def test_append_records(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test appending records to existing file."""
        handler = JSONLFileHandler(file=jsonl_file, mode="a+b", touch=True)
        handler.write(sample_records[:2])

        handler.append_records([sample_records[2]])

        result = handler.read()
        assert result is not None
        assert len(result) == 3
        assert result[2]["name"] == "Charlie"
        handler.close()

    def test_append_multiple_records(self, jsonl_file: Path) -> None:
        """Test appending multiple records at once."""
        handler = JSONLFileHandler(file=jsonl_file, mode="a+b", touch=True)
        handler.write([{"id": 1}])

        handler.append_records([{"id": 2}, {"id": 3}, {"id": 4}])

        result = handler.read()
        assert result is not None
        assert len(result) == 4
        assert [r["id"] for r in result] == [1, 2, 3, 4]
        handler.close()


class TestJSONLFileHandlerStreaming:
    """Test streaming functionality."""

    def test_iter_records(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test iterating over records."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        handler.write(sample_records)

        records = list(handler.iter_records())
        assert len(records) == 3
        assert records[0]["name"] == "Alice"
        handler.close()

    def test_iter_records_empty_file(self, jsonl_file: Path) -> None:
        """Test iterating over empty file."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        records = list(handler.iter_records())
        assert len(records) == 0
        handler.close()


class TestJSONLFileHandlerToLines:
    """Test string representation functionality."""

    def test_to_lines(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test converting records to JSON strings."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        handler.write(sample_records)

        lines = handler.to_lines()
        assert len(lines) == 3
        assert all(isinstance(line, str) for line in lines)
        assert '"Alice"' in lines[0]
        assert '"Bob"' in lines[1]
        handler.close()

    def test_to_lines_empty_file(self, jsonl_file: Path) -> None:
        """Test to_lines on empty file."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        lines = handler.to_lines()
        assert lines == []
        handler.close()


class TestJSONLFileHandlerDataTypes:
    """Test handling different data types."""

    def test_write_mixed_dict_values(self, jsonl_file: Path) -> None:
        """Test writing dicts with various value types."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        records = [
            {"string": "hello", "number": 42, "float": 3.14},
            {"bool": True, "null": None, "list": [1, 2, 3]},
            {"nested": {"key": "value"}},
        ]
        handler.write(records)

        result = handler.read()
        assert result is not None
        assert len(result) == 3
        assert result[0]["number"] == 42
        assert result[1]["bool"] is True
        assert result[2]["nested"]["key"] == "value"
        handler.close()


class TestJSONLFileHandlerRawLines:
    """Test raw line writing (for pre-formatted JSON strings)."""

    def test_write_raw_lines(self, jsonl_file: Path) -> None:
        """Test writing raw JSON strings without re-serialization."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        raw_lines = [
            '{"id": 1, "name": "Alice"}',
            '{"id": 2, "name": "Bob"}',
            '{"id": 3, "name": "Charlie"}',
        ]
        handler.write_raw_lines(raw_lines)

        result = handler.read()
        assert result is not None
        assert len(result) == 3
        assert result[0]["name"] == "Alice"
        assert result[1]["id"] == 2
        handler.close()

    def test_write_raw_lines_no_double_encoding(self, jsonl_file: Path) -> None:
        """Test that raw lines don't get double-encoded."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        raw_line = '{"message": "Hello \\"World\\""}'  # Already has escaped quotes
        handler.write_raw_lines([raw_line])

        result = handler.read()
        assert result is not None
        assert result[0]["message"] == 'Hello "World"'
        handler.close()


class TestJSONLFileHandlerEdgeCases:
    """Test edge cases and error handling."""

    def test_context_manager(self, jsonl_file: Path, sample_records: list[dict[str, int | str]]) -> None:
        """Test using handler as context manager."""
        with JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True) as handler:
            handler.write(sample_records)
            result = handler.read()
            assert result is not None
            assert len(result) == 3

    def test_large_number_of_records(self, jsonl_file: Path) -> None:
        """Test handling many records."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        large_dataset = [{"id": i, "value": f"record_{i}"} for i in range(1000)]
        handler.write(large_dataset)

        result = handler.read()
        assert result is not None
        assert len(result) == 1000
        assert result[999]["id"] == 999
        handler.close()

    def test_unicode_handling(self, jsonl_file: Path) -> None:
        """Test handling Unicode characters."""
        handler = JSONLFileHandler(file=jsonl_file, mode="w+b", touch=True)
        unicode_records = [
            {"text": "Hello 🐢"},
            {"text": "Turtoo 💙"},
            {"text": "日本語"},
        ]
        handler.write(unicode_records)

        result = handler.read()
        assert result is not None
        assert result[0]["text"] == "Hello 🐢"
        assert result[1]["text"] == "Turtoo 💙"
        handler.close()
