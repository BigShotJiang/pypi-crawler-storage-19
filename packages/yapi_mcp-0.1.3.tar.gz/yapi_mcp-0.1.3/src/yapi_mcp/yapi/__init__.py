"""YApi API client module."""
