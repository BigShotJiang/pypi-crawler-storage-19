"""MCP tools implementation."""
