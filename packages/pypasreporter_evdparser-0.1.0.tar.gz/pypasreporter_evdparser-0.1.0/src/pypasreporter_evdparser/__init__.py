"""
pyPASreporter-EVDparser: EVD (Export Vault Data) parser for CyberArk PAM.

Part of the pyPASreporter ecosystem.
"""

__version__ = "0.1.0"
__author__ = "itpamltd"
__email__ = "itpamltd@proton.me"

from .parser import parse_evd, EVDParser

__all__ = ["parse_evd", "EVDParser", "__version__"]
