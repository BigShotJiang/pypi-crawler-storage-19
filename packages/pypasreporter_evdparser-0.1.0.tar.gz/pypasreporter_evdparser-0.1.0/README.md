# pyPASreporter-EVDparser

EVD (Export Vault Data) parser for CyberArk PAM - part of the pyPASreporter ecosystem.

## Installation

```bash
pip install pyPASreporter-EVDparser
```

Or with uv:

```bash
uv add pyPASreporter-EVDparser
```

## Usage

```python
from pypasreporter_evdparser import parse_evd

# Parse EVD export files
data = parse_evd("/path/to/evd/exports")
```

## Features

- Parse CyberArk EVD CSV exports
- Support for all standard EVD export types:
  - UsersList.csv
  - SafesList.csv
  - GroupsList.csv
  - OwnersList.csv
  - and more...

## Part of pyPASreporter Ecosystem

- [pyPASreporter](https://pypi.org/project/pyPASreporter/) - Main reporting package
- [pyPASreporter-EVDparser](https://pypi.org/project/pyPASreporter-EVDparser/) - EVD parser (this package)
- [pyPASreporter-PACLIparser](https://pypi.org/project/pyPASreporter-PACLIparser/) - PACLI config parser

## License

MIT
