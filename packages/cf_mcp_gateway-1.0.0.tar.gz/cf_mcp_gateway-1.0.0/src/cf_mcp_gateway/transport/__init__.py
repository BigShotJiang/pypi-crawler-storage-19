"""Transport runners for the MCP gateway."""

from .stdio import run_stdio

__all__ = [
    "run_stdio",
]
