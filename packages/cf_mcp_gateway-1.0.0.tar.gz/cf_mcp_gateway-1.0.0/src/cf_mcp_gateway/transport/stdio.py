"""Stdio transport runner."""

import logging
from typing import Awaitable, Callable

from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server

from ..server import get_initialization_options

logger = logging.getLogger(__name__)


async def run_stdio(
    mcp: Server,
    shutdown_callback: Callable[[], Awaitable[None]],
) -> None:
    """Run the gateway with stdio transport.

    Args:
        mcp: MCP server instance.
        shutdown_callback: Async function to call on shutdown.
    """
    logger.info("Starting gateway with stdio transport")

    try:
        async with stdio_server() as (read_stream, write_stream):
            await mcp.run(
                read_stream,
                write_stream,
                get_initialization_options(),
            )
    except Exception as e:
        logger.error(f"Stdio transport error: {e}")
        raise
    finally:
        await shutdown_callback()
