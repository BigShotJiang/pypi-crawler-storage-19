"""
Efficient datastructures for FO(·) interpretations.
"""

from .set import Set as Set
