"""
Web Hacker data models.
"""

