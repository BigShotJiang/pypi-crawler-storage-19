"""EmDash CLI - Command-line interface for code intelligence."""

__version__ = "0.1.3"
