class EdgeReachedException(StopIteration):
    pass
