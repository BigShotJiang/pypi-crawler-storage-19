"""Utility files for Datadoc."""
