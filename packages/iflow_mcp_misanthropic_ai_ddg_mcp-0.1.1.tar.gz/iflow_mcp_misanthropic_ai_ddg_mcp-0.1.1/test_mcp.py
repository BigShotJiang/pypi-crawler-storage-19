#!/usr/bin/env python3
import asyncio
import json
import sys
import os

async def read_json_response(process):
    """读取JSON响应，跳过空行和调试信息"""
    max_attempts = 10
    for _ in range(max_attempts):
        response_line = await asyncio.wait_for(process.stdout.readline(), timeout=30)
        
        if not response_line:
            return None
        
        line_content = response_line.decode().strip()
        
        # 跳过空行
        if not line_content:
            continue
        
        # 跳过调试信息
        if not line_content.startswith('{'):
            print(f"跳过非JSON行: {line_content[:100]}")
            continue
        
        # 尝试解析JSON
        try:
            return json.loads(line_content)
        except json.JSONDecodeError:
            print(f"JSON解析失败: {line_content[:100]}")
            continue
    
    return None

async def test_mcp():
    """测试MCP服务器"""
    # 启动服务器
    process = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "ddg_mcp",
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    # 等待服务器启动
    await asyncio.sleep(2)
    
    # 检查进程是否还在运行
    if process.returncode is not None:
        stderr_output = await process.stderr.read()
        print(f"❌ 服务器启动失败，返回码: {process.returncode}")
        print(f"错误输出: {stderr_output.decode()}")
        return None
    
    # 发送初始化请求
    init_request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "clientInfo": {"name": "test-client", "version": "1.0.0"}
        }
    }
    
    request_json = json.dumps(init_request) + '\n'
    process.stdin.write(request_json.encode())
    await process.stdin.drain()
    
    # 读取响应
    response = await read_json_response(process)
    print(f"初始化响应: {response}")
    
    if not response:
        print("❌ 未能获取初始化响应")
        process.terminate()
        await process.wait()
        return None
    
    # 发送list_tools请求
    tools_request = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/list",
        "params": {}
    }
    
    tools_json = json.dumps(tools_request) + '\n'
    process.stdin.write(tools_json.encode())
    await process.stdin.drain()
    
    # 读取响应
    tools_data = await read_json_response(process)
    print(f"工具列表响应: {json.dumps(tools_data, indent=2)}")
    
    # 清理
    process.terminate()
    await process.wait()
    
    return tools_data

if __name__ == "__main__":
    result = asyncio.run(test_mcp())
    if result:
        tools = result.get('result', {}).get('tools', [])
        print(f"\n✅ 测试完成，工具数量: {len(tools)}")
        for i, tool in enumerate(tools, 1):
            print(f"  {i}. {tool.get('name', 'unknown')}: {tool.get('description', 'no description')}")
    else:
        print("\n❌ 测试失败")
