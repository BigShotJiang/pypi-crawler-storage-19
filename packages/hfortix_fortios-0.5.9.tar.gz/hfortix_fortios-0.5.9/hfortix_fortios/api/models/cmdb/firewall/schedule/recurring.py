"""
Pydantic Models for CMDB - firewall/schedule/recurring

Runtime validation models for firewall/schedule/recurring configuration.
Generated from FortiOS schema version unknown.

Example Usage:
    >>> from hfortix_fortios.models.cmdb.firewall.schedule.recurring import 
    >>>
    >>> # Create with validation
    >>> obj = (
    ...     name=1,
    ...     name="example",
    ... )
    >>>
    >>> # Validation happens automatically
    >>> # ValidationError raised if constraints violated
"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
from typing import Any, Literal, Optional
from enum import Enum
from uuid import UUID

# ============================================================================
# Enum Definitions (for fields with 4+ allowed values)
# ============================================================================

class RecurringDayEnum(str, Enum):
    """Allowed values for day field."""
    SUNDAY = "sunday"    MONDAY = "monday"    TUESDAY = "tuesday"    WEDNESDAY = "wednesday"    THURSDAY = "thursday"    FRIDAY = "friday"    SATURDAY = "saturday"    NONE = "none"
class RecurringLabel_dayEnum(str, Enum):
    """Allowed values for label_day field."""
    NONE = "none"    OVER_NIGHT = "over-night"    EARLY_MORNING = "early-morning"    MORNING = "morning"    MIDDAY = "midday"    AFTERNOON = "afternoon"    EVENING = "evening"    NIGHT = "night"    LATE_NIGHT = "late-night"

# ============================================================================
# Main Model
# ============================================================================

class RecurringModel(BaseModel):
    """
    Pydantic model for firewall/schedule/recurring configuration.
    
    Recurring schedule configuration.
    
    Validation Rules:        - name: max_length=31 pattern=        - uuid: pattern=        - start: pattern=        - end: pattern=        - day: pattern=        - label_day: pattern=        - color: min=0 max=32 pattern=        - fabric_object: pattern=    """
    
    class Config:
        """Pydantic model configuration."""
        extra = "allow"  # Allow additional fields from API
        str_strip_whitespace = True
        validate_assignment = True  # Validate on attribute assignment
        use_enum_values = True  # Use enum values instead of names
    
    # ========================================================================
    # Model Fields
    # ========================================================================
    
    name: str = Field(max_length=31, default="", description="Recurring schedule name.")    
    uuid: str | None = Field(default="00000000-0000-0000-0000-000000000000", description="Universally Unique Identifier (UUID; automatically assigned but can be manually reset).")    
    start: str = Field(default="", description="Time of day to start the schedule, format hh:mm.")    
    end: str = Field(default="", description="Time of day to end the schedule, format hh:mm.")    
    day: list[Day] = Field(default="none", description="One or more days of the week on which the schedule is valid. Separate the names of the days with a space.")    
    label_day: LabelDayEnum | None = Field(default="none", description="Configure a window during the time of day in which the schedule job is executed.")    
    color: int | None = Field(ge=0, le=32, default=0, description="Color of icon on the GUI.")    
    fabric_object: Literal["enable", "disable"] | None = Field(default="disable", description="Security Fabric global object setting.")    
    # ========================================================================
    # Custom Validators
    # ========================================================================
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    def to_fortios_dict(self) -> dict[str, Any]:
        """
        Convert model to FortiOS API payload format.
        
        Returns:
            Dict suitable for POST/PUT operations
        """
        # Export with exclude_none to avoid sending null values
        return self.model_dump(exclude_none=True, by_alias=True)
    
    @classmethod
    def from_fortios_response(cls, data: dict[str, Any]) -> "":
        """
        Create model instance from FortiOS API response.
        
        Args:
            data: Response data from API
            
        Returns:
            Validated model instance
        """
        return cls(**data)

# ============================================================================
# Type Aliases for Convenience
# ============================================================================

Dict = dict[str, Any]  # For backward compatibility

# ============================================================================
# Module Exports
# ============================================================================

__all__ = [
    "RecurringModel",]


# ============================================================================
# Generated by hfortix generator v0.6.0
# Schema: 1.7.0
# Generated: 2026-01-07T08:39:55.907299Z
# ============================================================================