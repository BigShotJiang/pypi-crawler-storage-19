"""SurrealDB Django Example Project."""
