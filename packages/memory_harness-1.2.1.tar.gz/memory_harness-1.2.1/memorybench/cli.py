#!/usr/bin/env python3
"""Memory Harness CLI - Benchmark AI memory systems"""
import argparse
import json
import os
import sys
import time
import urllib.request
import urllib.error
import getpass

__version__ = "1.2.0"

API_URL = os.getenv("MEMORYBENCH_API_URL", "https://memory-harness-api-production.up.railway.app")
CONFIG_PATH = os.path.expanduser("~/.memorybench/config.json")


def api_request(method, path, data=None, token=None):
    url = f"{API_URL}{path}"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        try:
            error = json.loads(error_body)
            raise Exception(error.get("detail", str(e)))
        except json.JSONDecodeError:
            raise Exception(f"HTTP {e.code}: {error_body}")


def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return {}


def save_config(config):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(config, f)


def compute_score(r):
    return round(
        35 * r.get("accuracy_at_1", 0) +
        15 * r.get("accuracy_at_k", 0) +
        25 * (1 - r.get("cross_tenant_error_rate", 0)) +
        10 * (1 - r.get("collision_rate", 0)) +
        15 * r.get("confidence_rate", 0)
    , 1)


def grade(score):
    if score >= 90: return "A"
    if score >= 80: return "B"
    if score >= 70: return "C"
    if score >= 60: return "D"
    return "F"


def cmd_login(args):
    password = args.password or getpass.getpass("Password: ")
    result = api_request("POST", "/auth/login", {"email": args.email, "password": password})
    token = result.get("access_token") or result.get("token")
    if not token:
        print("Login failed")
        return 1
    save_config({"token": token, "email": args.email})
    print(f"Logged in as {args.email}")
    return 0


def cmd_run(args):
    config = load_config()
    token = config.get("token")
    if not token:
        print("Not logged in. Run: memorybench login -e EMAIL")
        return 1
    
    providers = api_request("GET", "/providers", token=token)
    if not providers:
        print("No providers configured.")
        return 1
    
    provider = providers[0]
    print(f"Provider: {provider['name']}")
    print("Running audit...")
    
    run = api_request("POST", "/audits/run", {"provider_id": provider["id"], "seeds": args.seeds}, token=token)
    run_id = run["id"]
    
    while run["status"] in ("pending", "running"):
        time.sleep(2)
        run = api_request("GET", f"/audits/{run_id}", token=token)
    
    if run["status"] == "failed":
        print("FAILED")
        return 1
    
    results = run.get("results", [])
    passed = sum(1 for r in results if r["passed"])
    score = (passed / len(results) * 100) if results else 0
    
    print("=" * 50)
    for r in results:
        s = "PASS" if r["passed"] else "FAIL"
        print(f" {s}  {r['test_id']:25} {r['score']:.3f}")
    print("=" * 50)
    print(f" Score: {score:.0f}/100 ({passed}/{len(results)})")
    
    with open(args.output, "w") as f:
        json.dump({"version": __version__, "score": score, "tests": results}, f, indent=2)
    print(f"Report: {args.output}")
    
    return 0 if passed == len(results) else 1


def cmd_validate(args):
    from .dataset_schema import validate_dataset
    
    is_valid, errors, stats = validate_dataset(args.dataset)
    
    print(f"\nDataset: {args.dataset}")
    print(f"  Store: {stats['store_count']}  Query: {stats['query_count']}  Tenants: {', '.join(stats['tenants'])}")
    
    if is_valid:
        print("Valid")
        return 0
    else:
        print(f"Invalid ({len(errors)} errors)")
        for e in errors[:3]:
            print(f"  Line {e.line}: {e.message}")
        return 1


def cmd_dataset(args):
    from .dataset_runner import run_dataset_benchmark
    from .adapters import get_adapter
    from .dataset_schema import validate_dataset
    import httpx
    
    is_valid, errors, stats = validate_dataset(args.dataset)
    if not is_valid:
        print(f"Dataset invalid ({len(errors)} errors)")
        for e in errors[:3]:
            print(f"  {e.message}")
        return 1
    
    # Get endpoint URL
    if args.provider_endpoint:
        endpoint_url = args.provider_endpoint
        provider_name = "direct"
    else:
        config = load_config()
        token = config.get("token")
        if not token:
            print("Not logged in. Run: memorybench login -e EMAIL")
            print("Or use: --provider-endpoint URL")
            return 1
        
        providers = api_request("GET", "/providers", token=token)
        if not providers:
            print("No providers. Use --provider-endpoint URL")
            return 1
        
        endpoint_url = providers[0].get("config", {}).get("endpoint_url", "")
        provider_name = providers[0]["name"]
        if not endpoint_url:
            print("Provider has no endpoint. Use --provider-endpoint URL")
            return 1
    
    print(f"Provider:   {provider_name}")
    print(f"Endpoint:   {endpoint_url}")
    print(f"Dataset:    {args.dataset} ({stats['store_count']} store, {stats['query_count']} query)")
    print(f"Adapter:    {args.adapter}")
    print(f"Dimensions: {args.n_probe}x{args.n_probe}")
    print()
    
    class HTTPProvider:
        def __init__(self, url):
            self.url = url.rstrip('/')
            self.client = httpx.Client(timeout=15.0)
        
        def reset(self, seed):
            self.client.post(f"{self.url}/reset", json={"seed": seed})
        
        def store(self, pattern, cue, steps=50):
            self.client.post(f"{self.url}/store", json={"pattern": pattern, "cue": cue, "learn_steps": steps})
        
        def recall(self, cue, steps=30):
            r = self.client.post(f"{self.url}/recall", json={"cue": cue, "steps": steps})
            return r.json().get("pattern", [])
    
    provider = HTTPProvider(endpoint_url)
    adapter = get_adapter(args.adapter, n_probe=args.n_probe, n_bridge=args.n_bridge)
    
    print("Running...")
    result = run_dataset_benchmark(
        provider, args.dataset, adapter,
        k=args.k, seed=args.seed,
        confidence_threshold=args.confidence_threshold
    )
    
    metrics = {
        "accuracy_at_1": result.accuracy_at_1,
        "accuracy_at_k": result.accuracy_at_k,
        "cross_tenant_error_rate": result.cross_tenant_error_rate,
        "collision_rate": result.collision_rate,
        "confidence_rate": result.confidence_rate,
    }
    score = compute_score(metrics)
    g = grade(score)
    
    print(f"\n{'='*50}")
    print(f" MEMORY BENCHMARK REPORT")
    print(f"{'='*50}")
    print(f" Accuracy@1:     {result.accuracy_at_1:6.1%}  {'pass' if result.accuracy_at_1 >= 0.7 else 'FAIL'}")
    print(f" Accuracy@{args.k}:     {result.accuracy_at_k:6.1%}  {'pass' if result.accuracy_at_k >= 0.9 else 'warn'}")
    print(f" Cross-tenant:   {result.cross_tenant_error_rate:6.1%}  {'pass' if result.cross_tenant_error_rate < 0.05 else 'FAIL'}")
    print(f" Collision:      {result.collision_rate:6.1%}  {'pass' if result.collision_rate < 0.2 else 'warn'}")
    print(f" Confidence:     {result.confidence_rate:6.1%}  {'pass' if result.confidence_rate >= 0.8 else 'warn'}")
    print(f"{'='*50}")
    print(f" SCORE: {score}/100  GRADE: {g}")
    print(f"{'='*50}")
    print()
    print(" Forgetting:")
    for n, acc in result.forgetting_curve:
        bar = "#" * int(acc * 20) + "." * (20 - int(acc * 20))
        print(f"   {n:3d}: [{bar}] {acc:.0%}")
    print()
    
    report = {
        "version": __version__,
        "score": score,
        "grade": g,
        "metrics": metrics,
        "forgetting_curve": result.forgetting_curve,
        "config": {"dataset": args.dataset, "adapter": args.adapter, "n_probe": args.n_probe},
    }
    
    with open(args.output, "w") as f:
        json.dump(report, f, indent=2)
    
    md_path = args.output.replace(".json", ".md")
    with open(md_path, "w") as f:
        f.write(f"# Memory Benchmark\n\n**Score: {score}/100 (Grade {g})**\n\n")
        f.write(f"| Metric | Value |\n|--------|-------|\n")
        f.write(f"| Accuracy@1 | {result.accuracy_at_1:.1%} |\n")
        f.write(f"| Accuracy@{args.k} | {result.accuracy_at_k:.1%} |\n")
        f.write(f"| Cross-tenant | {result.cross_tenant_error_rate:.1%} |\n")
        f.write(f"| Collision | {result.collision_rate:.1%} |\n")
        f.write(f"| Confidence | {result.confidence_rate:.1%} |\n")
    
    print(f"Reports: {args.output}, {md_path}")
    
    passed = score >= args.pass_threshold
    print(f"\n{'PASS' if passed else 'FAIL'} (threshold: {args.pass_threshold})")
    return 0 if passed else 1


def main():
    p = argparse.ArgumentParser(prog="memorybench", description="Memory Harness CLI")
    p.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    
    sub = p.add_subparsers(dest="cmd", required=True)
    
    s = sub.add_parser("login", help="Authenticate")
    s.add_argument("-e", "--email", required=True)
    s.add_argument("-p", "--password")
    
    s = sub.add_parser("run", help="Run 7-test audit")
    s.add_argument("-o", "--output", default="report.json")
    s.add_argument("-s", "--seeds", type=int, nargs="+", default=[0, 1, 2])
    
    s = sub.add_parser("validate", help="Validate dataset")
    s.add_argument("-d", "--dataset", required=True)
    
    s = sub.add_parser("dataset", help="Benchmark dataset")
    s.add_argument("-d", "--dataset", required=True)
    s.add_argument("-a", "--adapter", default="text", choices=["hash", "text", "ngram", "embedding"])
    s.add_argument("-o", "--output", default="dataset_report.json")
    s.add_argument("-k", type=int, default=3)
    s.add_argument("--seed", type=int, default=42)
    s.add_argument("--n-probe", type=int, default=16)
    s.add_argument("--n-bridge", type=int, default=16)
    s.add_argument("--confidence-threshold", type=float, default=0.1)
    s.add_argument("--pass-threshold", type=int, default=70, help="Minimum score to pass")
    s.add_argument("--provider-endpoint", help="Direct provider URL (bypass dashboard)")
    
    args = p.parse_args()
    
    cmds = {"login": cmd_login, "run": cmd_run, "validate": cmd_validate, "dataset": cmd_dataset}
    return cmds[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
