# randstadenterprise_edao_libraries/__init__.py

# 1. Base Modules (Independent - Load First)
from . import logs
from . import objects
from . import http

# 2. Helper Modules (Depend on logs/objects/http)
from . import helpers

# 3. Logic Modules (Depend on helpers)
# Load in order of dependency complexity
from . import groups   # Groups usually have few dependencies
from . import users    # Users might depend on roles/groups
from . import roles    # Roles might depend on users
from . import assets   # Assets depend on owners (users/groups)
from . import datasets # Datasets depend on owners
from . import sandbox  # Sandbox depends on everything

__all__ = ['objects', 'logs', 'http', 'helpers', 'groups', 'roles', 'assets', 'sandbox', 'users']
__version__ = "0.1.21"

# In Terminal RUN in library_root
# cd library_root
# rm -rf dist
# pyhon -m build
# python -m twine upload dist/*

