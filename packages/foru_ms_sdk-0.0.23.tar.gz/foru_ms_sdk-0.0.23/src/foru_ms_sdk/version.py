from importlib import metadata

__version__ = metadata.version("foru-ms-sdk")
