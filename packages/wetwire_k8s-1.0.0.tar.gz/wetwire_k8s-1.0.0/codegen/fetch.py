"""Schema fetching utilities for Kubernetes OpenAPI specifications."""

import json
from pathlib import Path

import requests


def get_schema_url(version: str) -> str:
    """
    Get the URL for downloading the OpenAPI schema for a specific K8s version.

    Args:
        version: Kubernetes version (e.g., 'v1.28.0', 'v1.29.0')

    Returns:
        URL to the swagger.json file for the specified version
    """
    # Use the official Kubernetes repository
    # For specific versions, use the tagged release
    # For latest, use master branch
    base_url = "https://raw.githubusercontent.com/kubernetes/kubernetes"

    if version == "master" or version == "latest":
        return f"{base_url}/master/api/openapi-spec/swagger.json"
    else:
        # Remove 'v' prefix if present for consistency
        version_clean = version.lstrip("v")
        return f"{base_url}/v{version_clean}/api/openapi-spec/swagger.json"


def fetch_schema(version: str, output_path: str | Path) -> None:
    """
    Download the Kubernetes OpenAPI schema for a specific version.

    Args:
        version: Kubernetes version (e.g., 'v1.28.0', 'v1.29.0')
        output_path: Path where the schema should be saved

    Raises:
        Exception: If the download fails or the response is not valid JSON
    """
    output_path = Path(output_path)

    # Create parent directories if they don't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Get the schema URL
    url = get_schema_url(version)

    # Download the schema
    response = requests.get(url, timeout=30)
    response.raise_for_status()

    # Parse as JSON to validate
    schema_data = response.json()

    # Save to file
    with open(output_path, "w") as f:
        json.dump(schema_data, f, indent=2)

    print(f"Successfully downloaded schema for {version} to {output_path}")


def main():
    """Main entry point for schema fetching script."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Fetch Kubernetes OpenAPI schemas"
    )
    parser.add_argument(
        "--version",
        default="v1.30.0",
        help="Kubernetes version to fetch (e.g., v1.28.0, v1.29.0, v1.30.0)",
    )
    parser.add_argument(
        "--output",
        default="codegen/schemas/swagger.json",
        help="Output path for the schema file",
    )

    args = parser.parse_args()

    fetch_schema(args.version, args.output)


if __name__ == "__main__":
    main()
