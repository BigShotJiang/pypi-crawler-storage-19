"""Code generation utilities for wetwire-k8s."""
