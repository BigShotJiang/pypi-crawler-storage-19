"""Code generation utilities for Kubernetes resource dataclasses."""

import json
import re
from pathlib import Path
from typing import Any

from jinja2 import Template


def parse_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """
    Parse OpenAPI schema and extract definitions.

    Args:
        schema: The OpenAPI/Swagger schema dictionary

    Returns:
        Dictionary of definitions from the schema
    """
    return schema.get("definitions", {})


def parse_definition_name(definition_name: str) -> dict[str, str]:
    """
    Parse a Kubernetes definition name into its components.

    Args:
        definition_name: Full definition name (e.g., 'io.k8s.api.core.v1.Pod')

    Returns:
        Dictionary with 'group', 'version', and 'kind' keys
    """
    # Pattern: io.k8s.api.<group>.<version>.<Kind>
    # or: io.k8s.apimachinery.pkg.apis.<group>.<version>.<Kind>

    parts = definition_name.split(".")

    if "apimachinery" in parts:
        # io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta
        # Find the version (starts with 'v')
        version_idx = None
        for i, part in enumerate(parts):
            if part.startswith("v") and len(part) > 1 and part[1].isdigit():
                version_idx = i
                break

        if version_idx and version_idx > 0:
            group = parts[version_idx - 1]
            version = parts[version_idx]
            kind = ".".join(parts[version_idx + 1:])
        else:
            # Fallback
            group = "meta"
            version = "v1"
            kind = parts[-1]
    else:
        # io.k8s.api.core.v1.Pod
        # Find the version (starts with 'v')
        version_idx = None
        for i, part in enumerate(parts):
            if part.startswith("v") and len(part) > 1 and part[1].isdigit():
                version_idx = i
                break

        if version_idx and version_idx > 0:
            group = parts[version_idx - 1]
            version = parts[version_idx]
            kind = ".".join(parts[version_idx + 1:])
        else:
            # Fallback
            group = "core"
            version = "v1"
            kind = parts[-1]

    return {"group": group, "version": version, "kind": kind}


def get_python_type(prop_schema: dict[str, Any], definitions: dict[str, Any] | None = None) -> str:
    """
    Convert OpenAPI type to Python type annotation.

    Args:
        prop_schema: Property schema from OpenAPI
        definitions: All definitions for resolving references

    Returns:
        Python type annotation as a string
    """
    if "$ref" in prop_schema:
        # Reference to another type
        ref = prop_schema["$ref"]
        # Extract the type name from the reference
        type_name = ref.split("/")[-1].split(".")[-1]
        return type_name

    prop_type = prop_schema.get("type", "object")

    if prop_type == "string":
        return "str"
    elif prop_type == "integer":
        return "int"
    elif prop_type == "number":
        return "float"
    elif prop_type == "boolean":
        return "bool"
    elif prop_type == "array":
        items_schema = prop_schema.get("items", {})
        item_type = get_python_type(items_schema, definitions)
        return f"list[{item_type}]"
    elif prop_type == "object":
        # Generic dict for objects without specific schema
        return "dict[str, Any]"
    else:
        return "Any"


def should_generate_resource(definition_name: str) -> bool:
    """
    Determine if a resource should be generated.

    Args:
        definition_name: Full definition name

    Returns:
        True if the resource should be generated
    """
    # Generate all io.k8s.api.* resources
    if definition_name.startswith("io.k8s.api."):
        return True

    # Also generate some common apimachinery types
    if definition_name.startswith("io.k8s.apimachinery."):
        return True

    return False


def _is_python_keyword(name: str) -> bool:
    """Check if a name is a Python keyword."""
    import keyword
    return keyword.iskeyword(name)


def _safe_field_name(name: str) -> str:
    """Convert a field name to a safe Python identifier."""
    if _is_python_keyword(name):
        # Append underscore to keywords
        return f"{name}_"
    return name


def generate_dataclass(class_name: str, definition: dict[str, Any], definitions: dict[str, Any] | None = None) -> str:
    """
    Generate Python dataclass code from an OpenAPI definition.

    Args:
        class_name: Name of the class to generate
        definition: OpenAPI definition schema
        definitions: All definitions for resolving references

    Returns:
        Generated Python code as a string
    """
    properties = definition.get("properties", {})

    # Generate field definitions
    fields = []
    for prop_name, prop_schema in properties.items():
        python_type = get_python_type(prop_schema, definitions)

        # Handle Python keywords by appending underscore
        safe_name = _safe_field_name(prop_name)

        # K8s resources typically have all fields optional
        # Use Optional[type] with default None
        if safe_name != prop_name:
            # If we renamed it, add a comment about the original name
            field_def = f"    {safe_name}: Optional[{python_type}] = None  # Original: '{prop_name}'"
        else:
            field_def = f"    {safe_name}: Optional[{python_type}] = None"
        fields.append(field_def)

    fields_code = "\n".join(fields) if fields else "    pass"

    template = Template("""
@dataclass
class {{ class_name }}:
    \"\"\"{{ description }}\"\"\"
{{ fields }}
""".strip())

    description = definition.get("description", f"Kubernetes {class_name}")

    code = template.render(
        class_name=class_name,
        description=description,
        fields=fields_code
    )

    return code


def generate_module(class_name: str, definition: dict[str, Any], output_path: Path, definitions: dict[str, Any] | None = None, all_definitions: dict[str, dict[str, Any]] | None = None) -> None:
    """
    Generate a complete Python module file for a resource.

    Args:
        class_name: Name of the class to generate
        definition: OpenAPI definition schema
        output_path: Path where the module should be saved
        definitions: All definitions for resolving references
        all_definitions: Mapping of all definition names to their info for cross-module imports
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Collect referenced types with their full definition names
    referenced_types = _collect_referenced_types_with_refs(definition)

    dataclass_code = generate_dataclass(class_name, definition, definitions)

    # Generate imports for referenced types
    type_imports = []
    if referenced_types and all_definitions:
        for type_name, ref_path in referenced_types.items():
            if type_name != class_name:  # Don't import self
                # Find where this type is defined
                if ref_path in all_definitions:
                    type_info = all_definitions[ref_path]
                    type_group = type_info["group"]
                    type_version = type_info["version"]

                    # Get current module's group/version from path
                    current_group = output_path.parent.parent.name
                    current_version = output_path.parent.name

                    # Determine import path
                    module_name = _to_snake_case(type_name)
                    if type_group == current_group and type_version == current_version:
                        # Same directory - relative import
                        type_imports.append(f"from .{module_name} import {type_name}")
                    else:
                        # Different directory - absolute import from resources
                        type_imports.append(f"from wetwire_k8s.resources.{type_group}.{type_version}.{module_name} import {type_name}")

    imports_code = "\n".join(sorted(type_imports))
    if imports_code:
        imports_code = "\n" + imports_code

    module_template = Template("""'''{{ class_name }} resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional{{ imports_code }}


{{ dataclass_code }}


__all__ = ["{{ class_name }}"]
""".strip() + "\n")

    module_code = module_template.render(
        class_name=class_name,
        dataclass_code=dataclass_code,
        imports_code=imports_code
    )

    output_path.write_text(module_code)


def generate_init_file(directory: Path, class_names: list[str]) -> None:
    """
    Generate __init__.py file for a resource directory.

    Args:
        directory: Directory where __init__.py should be created
        class_names: List of class names to export
    """
    init_path = directory / "__init__.py"

    # Generate imports
    imports = []
    for class_name in sorted(class_names):
        module_name = _to_snake_case(class_name)
        imports.append(f"from .{module_name} import {class_name}")

    imports_code = "\n".join(imports)
    all_list = ", ".join(f'"{name}"' for name in sorted(class_names))

    init_template = Template("""'''Kubernetes {{ group }}/{{ version }} resources.'''

{{ imports }}

__all__ = [{{ all_list }}]
""".strip() + "\n")

    # Extract group and version from directory path
    parts = directory.parts
    version = parts[-1] if parts else "v1"
    group = parts[-2] if len(parts) > 1 else "core"

    init_code = init_template.render(
        group=group,
        version=version,
        imports=imports_code,
        all_list=all_list
    )

    init_path.write_text(init_code)


def _to_snake_case(name: str) -> str:
    """Convert CamelCase to snake_case."""
    # Insert underscore before uppercase letters
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    s2 = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1)
    return s2.lower()


def _collect_referenced_types(definition: dict[str, Any]) -> set[str]:
    """
    Collect all referenced type names from a definition.

    Args:
        definition: OpenAPI definition schema

    Returns:
        Set of referenced type names
    """
    referenced_types = set()
    properties = definition.get("properties", {})

    for prop_schema in properties.values():
        if "$ref" in prop_schema:
            # Extract type name from reference
            ref = prop_schema["$ref"]
            type_name = ref.split("/")[-1].split(".")[-1]
            referenced_types.add(type_name)
        elif prop_schema.get("type") == "array" and "items" in prop_schema:
            items = prop_schema["items"]
            if "$ref" in items:
                ref = items["$ref"]
                type_name = ref.split("/")[-1].split(".")[-1]
                referenced_types.add(type_name)

    return referenced_types


def _collect_referenced_types_with_refs(definition: dict[str, Any]) -> dict[str, str]:
    """
    Collect all referenced type names with their full reference paths.

    Args:
        definition: OpenAPI definition schema

    Returns:
        Dictionary mapping type names to their full reference paths
    """
    referenced_types = {}
    properties = definition.get("properties", {})

    for prop_schema in properties.values():
        if "$ref" in prop_schema:
            # Extract type name and full ref path
            ref = prop_schema["$ref"]
            full_name = ref.split("/")[-1]  # e.g., io.k8s.apimachinery.pkg.apis.meta.v1.ObjectMeta
            type_name = full_name.split(".")[-1]  # e.g., ObjectMeta
            referenced_types[type_name] = full_name
        elif prop_schema.get("type") == "array" and "items" in prop_schema:
            items = prop_schema["items"]
            if "$ref" in items:
                ref = items["$ref"]
                full_name = ref.split("/")[-1]
                type_name = full_name.split(".")[-1]
                referenced_types[type_name] = full_name

    return referenced_types


def generate_all_resources(schema: dict[str, Any], output_dir: Path) -> None:
    """
    Generate all resource dataclasses from a schema.

    Args:
        schema: The complete OpenAPI schema
        output_dir: Base directory where resources should be generated
    """
    definitions = parse_schema(schema)

    # Build a mapping of all definition names to their group/version/kind info
    all_definitions_map: dict[str, dict[str, str]] = {}

    for def_name in definitions.keys():
        if should_generate_resource(def_name):
            parsed = parse_definition_name(def_name)
            kind = parsed["kind"]
            if "." not in kind:  # Skip nested types
                all_definitions_map[def_name] = parsed

    # Group resources by API group and version
    resources_by_path: dict[tuple[str, str], list[tuple[str, dict[str, Any]]]] = {}

    for def_name, definition in definitions.items():
        if not should_generate_resource(def_name):
            continue

        parsed = parse_definition_name(def_name)
        group = parsed["group"]
        version = parsed["version"]
        kind = parsed["kind"]

        # Skip nested types (containing dots in kind)
        if "." in kind:
            continue

        key = (group, version)
        if key not in resources_by_path:
            resources_by_path[key] = []

        resources_by_path[key].append((kind, definition))

    # Generate files for each group/version
    for (group, version), resources in resources_by_path.items():
        group_dir = output_dir / group / version
        group_dir.mkdir(parents=True, exist_ok=True)

        class_names = []

        for kind, definition in resources:
            # Generate module file
            module_name = _to_snake_case(kind)
            module_path = group_dir / f"{module_name}.py"
            generate_module(kind, definition, module_path, definitions, all_definitions_map)
            class_names.append(kind)

        # Generate __init__.py
        if class_names:
            generate_init_file(group_dir, class_names)

    # Generate top-level __init__.py for resources
    resources_init = output_dir / "__init__.py"
    resources_init.write_text('"""Kubernetes resource definitions."""\n')

    # Generate __init__.py for each group
    for group in set(g for g, _ in resources_by_path.keys()):
        group_init = output_dir / group / "__init__.py"
        group_init.parent.mkdir(parents=True, exist_ok=True)
        group_init.write_text(f'"""Kubernetes {group} resources."""\n')


def generate_from_schema_file(schema_file: Path, output_dir: Path) -> None:
    """
    Generate resources from a schema file.

    Args:
        schema_file: Path to the OpenAPI schema JSON file
        output_dir: Directory where resources should be generated
    """
    with open(schema_file) as f:
        schema = json.load(f)

    generate_all_resources(schema, output_dir)


def main():
    """Main entry point for code generation script."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Generate Kubernetes resource dataclasses from OpenAPI schema"
    )
    parser.add_argument(
        "--schema",
        default="codegen/schemas/swagger.json",
        help="Path to the OpenAPI schema file",
    )
    parser.add_argument(
        "--output",
        default="src/wetwire_k8s/resources",
        help="Output directory for generated resources",
    )

    args = parser.parse_args()

    schema_file = Path(args.schema)
    output_dir = Path(args.output)

    if not schema_file.exists():
        print(f"Error: Schema file not found: {schema_file}")
        print("Run 'python -m codegen.fetch' first to download the schema")
        return 1

    print(f"Generating resources from {schema_file}")
    generate_from_schema_file(schema_file, output_dir)
    print(f"Resources generated in {output_dir}")

    return 0


if __name__ == "__main__":
    exit(main())
