"""Template builder and build pipeline for Kubernetes resources.

This module implements the build pipeline per Wetwire Spec Section 8.4:
DISCOVER → VALIDATE → EXTRACT → ORDER → SERIALIZE → EMIT

The pipeline processes Kubernetes resources defined in Python and outputs
YAML manifests in dependency order.
"""

from collections import defaultdict, deque
from pathlib import Path
from typing import Any

import yaml

from wetwire_k8s.loader import DiscoveredResource, discover_resources


class CircularDependencyError(Exception):
    """Raised when a circular dependency is detected."""

    pass


class MissingReferenceError(Exception):
    """Raised when a resource references another resource that doesn't exist."""

    pass


def validate_references(resources: list[DiscoveredResource]) -> None:
    """Validate that all resource references exist.

    Args:
        resources: List of discovered resources

    Raises:
        MissingReferenceError: If any resource references a non-existent resource
    """
    # Build set of all resource names
    resource_names = {r.name for r in resources}

    # Check each resource's dependencies
    missing_refs: dict[str, list[str]] = {}

    for resource in resources:
        for dep in resource.dependencies:
            if dep not in resource_names:
                if resource.name not in missing_refs:
                    missing_refs[resource.name] = []
                missing_refs[resource.name].append(dep)

    if missing_refs:
        # Format error message
        error_parts = []
        for resource_name, deps in missing_refs.items():
            deps_str = ", ".join(f"'{d}'" for d in deps)
            error_parts.append(f"Resource '{resource_name}' references: {deps_str}")

        error_msg = "Missing references detected:\n  " + "\n  ".join(error_parts)
        raise MissingReferenceError(error_msg)


def detect_cycles(resources: list[DiscoveredResource]) -> None:
    """Detect circular dependencies using DFS.

    Args:
        resources: List of discovered resources

    Raises:
        CircularDependencyError: If a circular dependency is detected
    """
    # Build adjacency list
    graph: dict[str, list[str]] = {r.name: r.dependencies for r in resources}

    # Track visited nodes and nodes in current path
    visited: set[str] = set()
    rec_stack: set[str] = set()

    def dfs(node: str, path: list[str]) -> bool:
        """DFS helper that returns True if cycle is detected."""
        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        # Visit all neighbors
        if node in graph:
            for neighbor in graph[node]:
                if neighbor not in visited:
                    if dfs(neighbor, path):
                        return True
                elif neighbor in rec_stack:
                    # Found a cycle
                    # Build cycle path
                    cycle_start = path.index(neighbor)
                    cycle = path[cycle_start:] + [neighbor]
                    cycle_str = " -> ".join(cycle)
                    raise CircularDependencyError(
                        f"Circular dependency detected: {cycle_str}"
                    )

        path.pop()
        rec_stack.remove(node)
        return False

    # Check each node
    for resource in resources:
        if resource.name not in visited:
            dfs(resource.name, [])


def topological_sort(resources: list[DiscoveredResource]) -> list[DiscoveredResource]:
    """Sort resources in dependency order using Kahn's algorithm.

    This implements Kahn's algorithm for topological sorting as specified
    in Wetwire Spec Section 8.2.

    Args:
        resources: List of discovered resources

    Returns:
        Resources sorted in topological order (dependencies first)

    Raises:
        CircularDependencyError: If a circular dependency is detected
    """
    if not resources:
        return []

    # Build resource lookup
    resource_map = {r.name: r for r in resources}

    # Calculate in-degree for each node
    in_degree: dict[str, int] = {r.name: 0 for r in resources}
    for resource in resources:
        for dep in resource.dependencies:
            if dep in in_degree:
                in_degree[dep] = in_degree.get(dep, 0)

    # Count dependencies properly
    for resource in resources:
        for dep in resource.dependencies:
            if dep in in_degree:
                in_degree[resource.name] += 1

    # Queue of nodes with no dependencies
    queue: deque[str] = deque()
    for name, degree in in_degree.items():
        if degree == 0:
            queue.append(name)

    # Process nodes in topological order
    sorted_names: list[str] = []
    while queue:
        # Remove a node with no incoming edges
        name = queue.popleft()
        sorted_names.append(name)

        # For each resource that depends on this one
        for resource in resources:
            if name in resource.dependencies:
                in_degree[resource.name] -= 1
                if in_degree[resource.name] == 0:
                    queue.append(resource.name)

    # If we couldn't sort all nodes, there's a cycle
    if len(sorted_names) != len(resources):
        raise CircularDependencyError(
            "Circular dependency detected during topological sort"
        )

    # Return resources in sorted order
    return [resource_map[name] for name in sorted_names]


def extract_values(resources: list[DiscoveredResource]) -> dict[str, Any]:
    """Execute Python code to extract runtime values of resources.

    This function executes the Python files to get the actual resource objects.

    Args:
        resources: List of discovered resources

    Returns:
        Dictionary mapping resource names to their values

    Raises:
        FileNotFoundError: If a resource file doesn't exist
        Exception: If execution fails
    """
    if not resources:
        return {}

    # Group resources by file
    resources_by_file: dict[str, list[DiscoveredResource]] = defaultdict(list)
    for resource in resources:
        resources_by_file[resource.file].append(resource)

    # Execute each file and extract values
    values: dict[str, Any] = {}

    for file_path, file_resources in resources_by_file.items():
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Resource file not found: {file_path}")

        # Read and execute the file
        code = path.read_text(encoding="utf-8")

        # Create execution namespace
        namespace: dict[str, Any] = {}

        # Execute the code
        exec(code, namespace)

        # Extract the resource values
        for resource in file_resources:
            if resource.name in namespace:
                values[resource.name] = namespace[resource.name]

    return values


def serialize_resources(values: dict[str, Any]) -> list[dict[str, Any]]:
    """Serialize resource objects to dictionaries.

    Args:
        values: Dictionary of resource values

    Returns:
        List of serialized resources as dictionaries
    """
    serialized = []

    for name, value in values.items():
        # Try to convert to dict
        if hasattr(value, "to_dict"):
            serialized.append(value.to_dict())
        elif hasattr(value, "__dict__"):
            # Fallback: use object's __dict__
            resource_dict = {}

            # Try to get common Kubernetes fields
            if hasattr(value, "metadata"):
                resource_dict["metadata"] = _serialize_field(value.metadata)
            if hasattr(value, "spec"):
                resource_dict["spec"] = _serialize_field(value.spec)
            if hasattr(value, "data"):
                resource_dict["data"] = _serialize_field(value.data)

            # Add kind and apiVersion if available
            if hasattr(value, "kind"):
                resource_dict["kind"] = value.kind
            elif hasattr(value, "__class__"):
                resource_dict["kind"] = value.__class__.__name__

            if hasattr(value, "api_version"):
                resource_dict["apiVersion"] = value.api_version
            elif hasattr(value, "apiVersion"):
                resource_dict["apiVersion"] = value.apiVersion

            serialized.append(resource_dict)
        elif isinstance(value, dict):
            serialized.append(value)
        else:
            # Last resort: try to convert to string representation
            serialized.append({"value": str(value)})

    return serialized


def _serialize_field(field: Any) -> Any:
    """Helper to serialize a field value.

    Args:
        field: Field value to serialize

    Returns:
        Serialized field value
    """
    if isinstance(field, (str, int, float, bool, type(None))):
        return field
    elif isinstance(field, (list, tuple)):
        return [_serialize_field(item) for item in field]
    elif isinstance(field, dict):
        return {k: _serialize_field(v) for k, v in field.items()}
    elif hasattr(field, "to_dict"):
        return field.to_dict()
    elif hasattr(field, "__dict__"):
        return {k: _serialize_field(v) for k, v in field.__dict__.items()}
    else:
        return str(field)


def emit_yaml(serialized: list[dict[str, Any]], output_path: Path) -> None:
    """Emit YAML manifest to output file.

    Args:
        serialized: List of serialized resources
        output_path: Directory where output file will be written
    """
    output_path.mkdir(parents=True, exist_ok=True)

    output_file = output_path / "manifest.yaml"

    if not serialized:
        # Write empty file or minimal content
        output_file.write_text("", encoding="utf-8")
        return

    # Convert to YAML
    yaml_parts = []
    for resource in serialized:
        yaml_str = yaml.dump(resource, default_flow_style=False, sort_keys=False)
        yaml_parts.append(yaml_str)

    # Join with YAML document separator
    yaml_content = "---\n".join(yaml_parts)

    # Write to file
    output_file.write_text(yaml_content, encoding="utf-8")


def build(package_path: Path, output_path: Path) -> None:
    """Main build function implementing the full pipeline.

    Pipeline stages:
    1. DISCOVER - Find all resources in the package
    2. VALIDATE - Check all references exist
    3. DETECT CYCLES - Check for circular dependencies
    4. ORDER - Sort resources in dependency order
    5. EXTRACT - Execute Python to get runtime values
    6. SERIALIZE - Convert resources to dictionaries
    7. EMIT - Write YAML manifest

    Args:
        package_path: Path to the package or file containing resources
        output_path: Path to the output directory

    Raises:
        FileNotFoundError: If package_path doesn't exist
        MissingReferenceError: If resources reference non-existent resources
        CircularDependencyError: If circular dependencies are detected
    """
    # Stage 1: DISCOVER
    resources = discover_resources(package_path)

    if not resources:
        # No resources found, create empty output
        emit_yaml([], output_path)
        return

    # Stage 2: VALIDATE
    validate_references(resources)

    # Stage 3: DETECT CYCLES
    detect_cycles(resources)

    # Stage 4: ORDER
    sorted_resources = topological_sort(resources)

    # Stage 5: EXTRACT
    values = extract_values(sorted_resources)

    # Stage 6: SERIALIZE
    serialized = serialize_resources(values)

    # Stage 7: EMIT
    emit_yaml(serialized, output_path)
