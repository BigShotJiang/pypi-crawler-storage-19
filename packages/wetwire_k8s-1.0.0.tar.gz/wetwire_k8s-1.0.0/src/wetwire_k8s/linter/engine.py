"""Linting engine for running lint rules.

This module provides the main linting engine that orchestrates
running all registered lint rules against discovered resources.
"""

from pathlib import Path

from wetwire_k8s.linter.base import LintIssue, LintRule
from wetwire_k8s.linter.rules import (
    ArtifactSecurityRule,
    CircularDependenciesRule,
    DuplicateResourceNamesRule,
    FileSizeLimitsRule,
    HardcodedSecretsRule,
    ImageLatestTagRule,
    InlineContainerSpecsRule,
    MissingImagePullPolicyRule,
    PrivilegedContainerRule,
    RBACPermissionScopeRule,
    TypedContainerPortsRule,
)


class LintEngine:
    """Engine for running lint rules against resources.

    The engine maintains a collection of lint rules and runs them
    against discovered resources.
    """

    def __init__(self):
        """Initialize the linting engine with default rules."""
        self.rules: list[LintRule] = [
            TypedContainerPortsRule(),
            InlineContainerSpecsRule(),
            DuplicateResourceNamesRule(),
            CircularDependenciesRule(),
            HardcodedSecretsRule(),
            ImageLatestTagRule(),
            MissingImagePullPolicyRule(),
            ArtifactSecurityRule(),
            RBACPermissionScopeRule(),
            PrivilegedContainerRule(),
            FileSizeLimitsRule(),
        ]

    def add_rule(self, rule: LintRule) -> None:
        """Add a custom rule to the engine.

        Args:
            rule: LintRule instance to add
        """
        self.rules.append(rule)

    def lint(self, resources: list, files: list[Path]) -> list[LintIssue]:
        """Run all lint rules against the given resources.

        Args:
            resources: List of DiscoveredResource objects
            files: List of file paths to read for content analysis

        Returns:
            List of all LintIssue objects found by all rules
        """
        # Load file contents
        file_contents = {}
        for file_path in files:
            try:
                file_contents[str(file_path)] = file_path.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                # Skip files that can't be read
                continue

        # Run all rules
        all_issues = []
        for rule in self.rules:
            issues = rule.check(resources, file_contents)
            all_issues.extend(issues)

        # Sort issues by file, then line
        all_issues.sort(key=lambda x: (x.file, x.line))

        return all_issues

    def get_rules(self) -> list[LintRule]:
        """Get all registered rules.

        Returns:
            List of LintRule objects
        """
        return self.rules.copy()
