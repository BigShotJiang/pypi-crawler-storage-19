"""Lint rules for Kubernetes resource definitions.

This module implements specific lint rules according to the Wetwire Spec.
Each rule has a WK8xxx identifier.
"""

import ast
import re
from collections import defaultdict

from wetwire_k8s.linter.base import LintIssue, LintRule, Severity


class TypedContainerPortsRule(LintRule):
    """WK8001: Use typed constants for container ports.

    This rule encourages using named constants for container ports
    instead of hardcoded integer literals.
    """

    @property
    def rule_id(self) -> str:
        return "WK8001"

    @property
    def description(self) -> str:
        return "Use typed constants for container ports"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for hardcoded port numbers in container specs."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Look for patterns like "containerPort": 8080 or 'containerPort': 8080
            # This regex finds containerPort with a numeric literal
            pattern = r'["\']containerPort["\']\s*:\s*(\d+)'
            matches = re.finditer(pattern, content)

            for match in matches:
                port_number = match.group(1)
                # Find the line number
                line_num = content[: match.start()].count("\n") + 1

                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message=f"Hardcoded port number {port_number}. Consider using a typed constant.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

        return issues


class InlineContainerSpecsRule(LintRule):
    """WK8002: Extract inline container specs.

    This rule encourages extracting container specifications into
    separate variables for better reusability and readability.
    """

    @property
    def rule_id(self) -> str:
        return "WK8002"

    @property
    def description(self) -> str:
        return "Extract inline container specs to separate variables"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for inline container specifications."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            try:
                tree = ast.parse(content)
            except SyntaxError:
                continue

            # Look for assignments with container specs
            for node in ast.walk(tree):
                if isinstance(node, ast.AnnAssign):
                    # Check if this is the resource assignment
                    if (
                        isinstance(node.target, ast.Name)
                        and node.target.id == resource.name
                    ):
                        # Look for inline container dicts with "name" and "image" keys
                        if node.value and self._has_inline_container(node.value):
                            issues.append(
                                LintIssue(
                                    rule=self.rule_id,
                                    message="Inline container spec detected. Consider extracting to a separate variable.",
                                    file=resource.file,
                                    line=resource.line,
                                    severity=self.severity,
                                )
                            )
                            break

        return issues

    def _has_inline_container(self, node: ast.AST) -> bool:
        """Check if an AST node contains an inline container definition."""
        for child in ast.walk(node):
            if isinstance(child, ast.Dict):
                # Check if this dict has both "name" and "image" keys
                # which would indicate it's a container spec
                keys = []
                for key in child.keys:
                    if isinstance(key, ast.Constant):
                        keys.append(key.value)

                # If we find a dict with both "name" and "image", it's likely a container
                if "name" in keys and "image" in keys:
                    return True

        return False


class DuplicateResourceNamesRule(LintRule):
    """WK8003: Flag duplicate resource names.

    This rule detects when multiple resources have the same variable name,
    which can cause confusion and conflicts.
    """

    @property
    def rule_id(self) -> str:
        return "WK8003"

    @property
    def description(self) -> str:
        return "Flag duplicate resource names"

    @property
    def severity(self) -> str:
        return Severity.ERROR

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for duplicate resource names."""
        issues = []

        # Group resources by name
        name_map = defaultdict(list)
        for resource in resources:
            name_map[resource.name].append(resource)

        # Find duplicates
        for name, res_list in name_map.items():
            if len(res_list) > 1:
                # Report an issue for each duplicate
                for resource in res_list:
                    other_locations = [
                        f"{r.file}:{r.line}"
                        for r in res_list
                        if r.file != resource.file or r.line != resource.line
                    ]
                    issues.append(
                        LintIssue(
                            rule=self.rule_id,
                            message=f"Duplicate resource name '{name}'. Also defined at: {', '.join(other_locations)}",
                            file=resource.file,
                            line=resource.line,
                            severity=self.severity,
                        )
                    )

        return issues


class CircularDependenciesRule(LintRule):
    """WK8004: Flag circular dependencies.

    This rule detects circular dependencies between resources,
    including self-references.
    """

    @property
    def rule_id(self) -> str:
        return "WK8004"

    @property
    def description(self) -> str:
        return "Flag circular dependencies between resources"

    @property
    def severity(self) -> str:
        return Severity.ERROR

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for circular dependencies."""
        issues = []
        reported_resources = set()

        # Build a dependency graph
        resource_map = {r.name: r for r in resources}

        # Check for self-references
        for resource in resources:
            if resource.name in resource.dependencies:
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message=f"Resource '{resource.name}' references itself",
                        file=resource.file,
                        line=resource.line,
                        severity=self.severity,
                    )
                )
                reported_resources.add(resource.name)

        # Check for circular dependencies using DFS
        for resource in resources:
            # Skip if we already reported this resource
            if resource.name in reported_resources:
                continue

            cycle = self._find_cycle(resource.name, resource_map, set(), [])
            if cycle:
                cycle_str = " -> ".join(cycle)
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message=f"Circular dependency detected: {cycle_str}",
                        file=resource.file,
                        line=resource.line,
                        severity=self.severity,
                    )
                )

        return issues

    def _find_cycle(
        self,
        current: str,
        resource_map: dict,
        visited: set,
        path: list,
    ) -> list[str] | None:
        """Find a cycle in the dependency graph using DFS."""
        if current in path:
            # Found a cycle
            cycle_start = path.index(current)
            return path[cycle_start:] + [current]

        if current in visited:
            return None

        if current not in resource_map:
            return None

        visited.add(current)
        path.append(current)

        resource = resource_map[current]
        for dep in resource.dependencies:
            cycle = self._find_cycle(dep, resource_map, visited, path[:])
            if cycle:
                return cycle

        return None


class HardcodedSecretsRule(LintRule):
    """WK8005: Flag hardcoded secrets in env vars.

    This rule detects environment variables that appear to contain
    hardcoded secrets (passwords, keys, tokens, etc.).
    """

    @property
    def rule_id(self) -> str:
        return "WK8005"

    @property
    def description(self) -> str:
        return "Flag hardcoded secrets in environment variables"

    @property
    def severity(self) -> str:
        return Severity.ERROR

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for hardcoded secrets in environment variables."""
        issues = []

        # Keywords that suggest a secret
        secret_keywords = [
            "password",
            "secret",
            "key",
            "token",
            "credential",
            "auth",
            "api_key",
            "apikey",
        ]

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Look for env var patterns with "value" (not "valueFrom")
            # Pattern: {"name": "SOME_SECRET", "value": "hardcoded"}
            # We want to match env vars with suspicious names and direct values

            try:
                tree = ast.parse(content)
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                if isinstance(node, ast.Dict):
                    # Check if this is an env var dict
                    env_name = None
                    has_direct_value = False

                    for i, key in enumerate(node.keys):
                        if (
                            isinstance(key, ast.Constant)
                            and key.value == "name"
                            and i < len(node.values)
                        ):
                            value = node.values[i]
                            if isinstance(value, ast.Constant) and isinstance(
                                value.value, str
                            ):
                                env_name = value.value

                        if isinstance(key, ast.Constant) and key.value == "value":
                            has_direct_value = True

                    # Check if env_name contains secret keywords and has a direct value
                    if env_name and has_direct_value and isinstance(env_name, str):
                        env_name_lower = env_name.lower()
                        if any(keyword in env_name_lower for keyword in secret_keywords):
                            line_num = node.lineno
                            issues.append(
                                LintIssue(
                                    rule=self.rule_id,
                                    message=f"Hardcoded secret in environment variable '{env_name}'. Use secretKeyRef instead.",
                                    file=resource.file,
                                    line=line_num,
                                    severity=self.severity,
                                )
                            )

        return issues


class ImageLatestTagRule(LintRule):
    """WK8006: Flag :latest image tags.

    This rule detects container images using the :latest tag or no tag
    (which defaults to :latest), which is not recommended for production.
    """

    @property
    def rule_id(self) -> str:
        return "WK8006"

    @property
    def description(self) -> str:
        return "Flag :latest image tags or missing tags"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for :latest or missing image tags."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Look for image patterns
            # Pattern 1: "image": "nginx:latest"
            # Pattern 2: "image": "nginx" (no tag)
            pattern = r'["\']image["\']\s*:\s*["\']([^"\']+)["\']'
            matches = re.finditer(pattern, content)

            for match in matches:
                image = match.group(1)
                line_num = content[: match.start()].count("\n") + 1

                # Check if image has :latest or no tag
                if ":latest" in image or ":" not in image:
                    issues.append(
                        LintIssue(
                            rule=self.rule_id,
                            message=f"Image '{image}' uses :latest or missing tag. Specify an explicit version.",
                            file=resource.file,
                            line=line_num,
                            severity=self.severity,
                        )
                    )

        return issues


class MissingImagePullPolicyRule(LintRule):
    """WK8007: Flag missing image pull policies.

    This rule detects containers without an explicit imagePullPolicy,
    which can lead to inconsistent behavior.
    """

    @property
    def rule_id(self) -> str:
        return "WK8007"

    @property
    def description(self) -> str:
        return "Flag missing imagePullPolicy in container specs"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    @property
    def can_fix(self) -> bool:
        """This rule supports auto-fixing."""
        return True

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for missing imagePullPolicy."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            try:
                tree = ast.parse(content)
            except SyntaxError:
                continue

            # Find container dicts with "image" but no "imagePullPolicy"
            for node in ast.walk(tree):
                if isinstance(node, ast.Dict):
                    has_image = False
                    has_pull_policy = False

                    for key in node.keys:
                        if isinstance(key, ast.Constant):
                            if key.value == "image":
                                has_image = True
                            if key.value == "imagePullPolicy":
                                has_pull_policy = True

                    if has_image and not has_pull_policy:
                        issues.append(
                            LintIssue(
                                rule=self.rule_id,
                                message="Container missing imagePullPolicy. Consider setting to 'Always', 'IfNotPresent', or 'Never'.",
                                file=resource.file,
                                line=node.lineno,
                                severity=self.severity,
                            )
                        )

        return issues

    def fix(self, issue: LintIssue, file_content: str) -> str | None:
        """Fix missing imagePullPolicy by adding 'IfNotPresent'.

        Args:
            issue: The LintIssue to fix
            file_content: Current content of the file

        Returns:
            Fixed file content with imagePullPolicy added
        """
        try:
            tree = ast.parse(file_content)
        except SyntaxError:
            return None

        lines = file_content.splitlines(keepends=True)

        # Find the container dict at the issue line
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict) and node.lineno == issue.line:
                # Check if this is a container dict (has "image" key)
                has_image = False
                for key in node.keys:
                    if isinstance(key, ast.Constant) and key.value == "image":
                        has_image = True
                        break

                if not has_image:
                    continue

                # Find the end of the dict to insert imagePullPolicy
                # Determine indentation from the dict line
                dict_line = lines[node.lineno - 1]
                # Find indentation by looking at the dict content
                indent = ""
                for i, char in enumerate(dict_line):
                    if char in (' ', '\t'):
                        indent += char
                    else:
                        break

                # Look for additional indentation inside the dict
                # Check the first key line to determine indent
                if node.keys:
                    first_key_line = lines[node.keys[0].lineno - 1]
                    key_indent = ""
                    for char in first_key_line:
                        if char in (' ', '\t'):
                            key_indent += char
                        else:
                            break
                    # Use the same indentation as other keys
                    indent = key_indent
                else:
                    # Default to adding 4 spaces to base indent
                    indent = indent + "    "

                # Find where to insert: look for the last key-value pair
                if node.keys:
                    last_key = node.keys[-1]
                    insert_line = last_key.end_lineno  # Insert after last key

                    # Check if the previous line ends with a comma
                    prev_line = lines[insert_line - 1]
                    if not prev_line.rstrip().endswith(','):
                        # Add comma to the previous line
                        lines[insert_line - 1] = prev_line.rstrip() + ',\n'

                    # Add imagePullPolicy after the last key
                    new_line = f'{indent}"imagePullPolicy": "IfNotPresent",\n'
                    lines.insert(insert_line, new_line)

                    return ''.join(lines)

        return None


class ArtifactSecurityRule(LintRule):
    """WK8008: Flag sensitive file paths in volume mounts.

    This rule detects sensitive files that may be accidentally exposed
    through volume mounts, hostPath volumes, or configMap file references.
    """

    # Patterns for sensitive files
    SENSITIVE_PATTERNS = [
        r"\.env$",  # .env files
        r"\.pem$",  # PEM certificates/keys
        r"\.key$",  # Private key files
        r"credentials\.json$",  # GCP/service account credentials
        r"id_rsa$",  # SSH RSA private key
        r"id_ed25519$",  # SSH Ed25519 private key
        r"id_dsa$",  # SSH DSA private key
        r"id_ecdsa$",  # SSH ECDSA private key
    ]

    @property
    def rule_id(self) -> str:
        return "WK8008"

    @property
    def description(self) -> str:
        return "Flag sensitive file paths in volume mounts"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for sensitive file paths in volume mounts."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Look for mountPath patterns
            mount_path_pattern = r'["\']mountPath["\']\s*:\s*["\']([^"\']+)["\']'
            matches = re.finditer(mount_path_pattern, content)

            for match in matches:
                path = match.group(1)
                line_num = content[: match.start()].count("\n") + 1

                for pattern in self.SENSITIVE_PATTERNS:
                    if re.search(pattern, path):
                        sensitive_file = re.search(pattern, path).group(0)
                        issues.append(
                            LintIssue(
                                rule=self.rule_id,
                                message=f"Sensitive file '{sensitive_file}' in volume mount path '{path}'. Consider using Kubernetes Secrets instead.",
                                file=resource.file,
                                line=line_num,
                                severity=self.severity,
                            )
                        )
                        break

            # Look for hostPath patterns
            host_path_pattern = r'["\']hostPath["\']\s*:\s*\{[^}]*["\']path["\']\s*:\s*["\']([^"\']+)["\']'
            matches = re.finditer(host_path_pattern, content)

            for match in matches:
                path = match.group(1)
                line_num = content[: match.start()].count("\n") + 1

                for pattern in self.SENSITIVE_PATTERNS:
                    if re.search(pattern, path):
                        sensitive_file = re.search(pattern, path).group(0)
                        issues.append(
                            LintIssue(
                                rule=self.rule_id,
                                message=f"Sensitive file '{sensitive_file}' in hostPath volume '{path}'. Consider using Kubernetes Secrets instead.",
                                file=resource.file,
                                line=line_num,
                                severity=self.severity,
                            )
                        )
                        break

        return issues


class RBACPermissionScopeRule(LintRule):
    """WK8009: Flag overly broad RBAC permissions.

    This rule detects RBAC configurations with overly permissive settings
    like cluster-admin bindings, wildcard verbs, resources, or apiGroups.
    """

    @property
    def rule_id(self) -> str:
        return "WK8009"

    @property
    def description(self) -> str:
        return "Flag overly broad RBAC permissions"

    @property
    def severity(self) -> str:
        return Severity.ERROR

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for overly broad RBAC permissions."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Check for cluster-admin role binding
            # Look for roleRef with cluster-admin name, using DOTALL to match across newlines
            cluster_admin_pattern = r'roleRef\s*=\s*\{[\s\S]*?["\']name["\']\s*:\s*["\']cluster-admin["\']'
            matches = re.finditer(cluster_admin_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="ClusterRoleBinding references 'cluster-admin' role. This grants full cluster access.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for wildcard verbs in rules
            wildcard_verbs_pattern = r'["\']verbs["\']\s*:\s*\[[^\]]*["\']\*["\'][^\]]*\]'
            matches = re.finditer(wildcard_verbs_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="RBAC rule uses wildcard (*) verbs. Specify explicit verbs for least privilege.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for wildcard resources in rules
            wildcard_resources_pattern = (
                r'["\']resources["\']\s*:\s*\[[^\]]*["\']\*["\'][^\]]*\]'
            )
            matches = re.finditer(wildcard_resources_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="RBAC rule uses wildcard (*) resources. Specify explicit resources for least privilege.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for wildcard apiGroups in rules
            wildcard_apigroups_pattern = (
                r'["\']apiGroups["\']\s*:\s*\[[^\]]*["\']\*["\'][^\]]*\]'
            )
            matches = re.finditer(wildcard_apigroups_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="RBAC rule uses wildcard (*) apiGroups. Specify explicit apiGroups for least privilege.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

        return issues


class PrivilegedContainerRule(LintRule):
    """WK8010: Flag privileged containers or host access.

    This rule detects containers running with privileged mode or
    host namespace access (hostNetwork, hostPID, hostIPC).
    """

    @property
    def rule_id(self) -> str:
        return "WK8010"

    @property
    def description(self) -> str:
        return "Flag privileged containers or host access"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for privileged containers or host access."""
        issues = []

        for resource in resources:
            if resource.file not in file_contents:
                continue

            content = file_contents[resource.file]

            # Check for privileged: True in securityContext
            privileged_pattern = r'["\']privileged["\']\s*:\s*True'
            matches = re.finditer(privileged_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="Container runs in privileged mode. This grants full host access and is a security risk.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for hostNetwork: True
            host_network_pattern = r'["\']hostNetwork["\']\s*:\s*True'
            matches = re.finditer(host_network_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="Pod uses hostNetwork: True. This shares the host's network namespace and is a security risk.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for hostPID: True
            host_pid_pattern = r'["\']hostPID["\']\s*:\s*True'
            matches = re.finditer(host_pid_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="Pod uses hostPID: True. This shares the host's PID namespace and is a security risk.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

            # Check for hostIPC: True
            host_ipc_pattern = r'["\']hostIPC["\']\s*:\s*True'
            matches = re.finditer(host_ipc_pattern, content)

            for match in matches:
                line_num = content[: match.start()].count("\n") + 1
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message="Pod uses hostIPC: True. This shares the host's IPC namespace and is a security risk.",
                        file=resource.file,
                        line=line_num,
                        severity=self.severity,
                    )
                )

        return issues


class FileSizeLimitsRule(LintRule):
    """WK8011: Flag files exceeding size limits.

    This rule detects files that exceed recommended limits:
    - Files over 500 lines
    - Files with more than 20 resources
    """

    # Thresholds from wetwire spec
    MAX_LINES = 500
    MAX_RESOURCES = 20

    @property
    def rule_id(self) -> str:
        return "WK8011"

    @property
    def description(self) -> str:
        return "Flag files exceeding size limits"

    @property
    def severity(self) -> str:
        return Severity.WARNING

    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check for files exceeding size limits."""
        issues = []

        # Group resources by file
        file_resources = defaultdict(list)
        for resource in resources:
            file_resources[resource.file].append(resource)

        # Check each file
        for file_path, file_resources_list in file_resources.items():
            if file_path not in file_contents:
                continue

            content = file_contents[file_path]
            line_count = content.count("\n") + 1
            resource_count = len(file_resources_list)

            # Check line count
            if line_count > self.MAX_LINES:
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message=f"File has {line_count} lines (exceeds {self.MAX_LINES} line limit). Consider splitting by concern (e.g., separate files for different resource types or environments).",
                        file=file_path,
                        line=1,
                        severity=self.severity,
                    )
                )

            # Check resource count
            if resource_count > self.MAX_RESOURCES:
                issues.append(
                    LintIssue(
                        rule=self.rule_id,
                        message=f"File contains {resource_count} resources (exceeds {self.MAX_RESOURCES} resource limit). Consider splitting by resource type or deployment environment.",
                        file=file_path,
                        line=1,
                        severity=self.severity,
                    )
                )

        return issues
