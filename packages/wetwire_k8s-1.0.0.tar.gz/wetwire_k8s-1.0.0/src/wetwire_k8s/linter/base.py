"""Base classes for lint rules.

This module defines the core interfaces and data structures for the linter.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass


class Severity:
    """Severity levels for lint issues."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LintIssue:
    """A lint issue found in a resource definition.

    Attributes:
        rule: Rule ID (e.g., "WK8001")
        message: Human-readable description of the issue
        file: Path to the file containing the issue
        line: Line number where the issue occurs
        severity: Severity level (error, warning, info)
        suggested_fix: Optional suggested fix content (for auto-fix)
    """

    rule: str
    message: str
    file: str
    line: int
    severity: str
    suggested_fix: str | None = None


class LintRule(ABC):
    """Base class for lint rules.

    Each lint rule checks for a specific pattern or issue in Kubernetes
    resource definitions.
    """

    @property
    @abstractmethod
    def rule_id(self) -> str:
        """Return the rule ID (e.g., "WK8001")."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Return a human-readable description of the rule."""
        pass

    @property
    @abstractmethod
    def severity(self) -> str:
        """Return the severity level for this rule."""
        pass

    @property
    def can_fix(self) -> bool:
        """Return whether this rule supports auto-fixing.

        Returns:
            True if the rule can automatically fix issues, False otherwise
        """
        return False

    @abstractmethod
    def check(
        self, resources: list, file_contents: dict[str, str]
    ) -> list[LintIssue]:
        """Check resources for issues.

        Args:
            resources: List of DiscoveredResource objects to check
            file_contents: Dictionary mapping file paths to their contents

        Returns:
            List of LintIssue objects found
        """
        pass

    def fix(self, issue: LintIssue, file_content: str) -> str | None:
        """Fix a lint issue by modifying file content.

        Args:
            issue: The LintIssue to fix
            file_content: Current content of the file

        Returns:
            Fixed file content, or None if the fix cannot be applied
        """
        return None
