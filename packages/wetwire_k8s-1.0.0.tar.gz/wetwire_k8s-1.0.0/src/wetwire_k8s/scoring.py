"""Scoring for persona-based tests.

This module re-exports from wetwire_core.agent for convenience,
and provides wetwire-k8s specific scoring functions.
"""

from dataclasses import dataclass
from typing import Any

# Re-export from wetwire-core for convenience
from wetwire_core.agent import ResultsWriter
from wetwire_core.agent.scoring import Rating, calculate_score
from wetwire_core.agent.scoring import Score as CoreScore

# Orchestrator features will be available when wetwire-core publishes v1.2.0+
# For now, these are placeholders that will be properly imported once available
ORCHESTRATOR_AVAILABLE = False
MaxLintCyclesExceeded: type | None = None
MaxTurnsExceeded: type | None = None
Orchestrator: type | None = None
OrchestratorError: type | None = None
Session: type | None = None
SessionConfig: type | None = None


@dataclass
class Score:
    """Score for a persona-based test session.

    Each dimension is scored 0-3 points, for a maximum total of 15.

    Attributes:
        completeness: All required resources generated? (0-3)
        lint_quality: Lint cycles needed (3=first try, 2=2 cycles, 1=3+, 0=never)
        code_quality: Idiomatic patterns used? (0-3)
        output_validity: Output validates with kubeconform? (0-3)
        question_efficiency: Appropriate number of clarifying questions? (0-3)
    """

    completeness: int
    lint_quality: int
    code_quality: int
    output_validity: int
    question_efficiency: int

    @property
    def total(self) -> int:
        """Calculate total score (max 15)."""
        return sum(
            [
                self.completeness,
                self.lint_quality,
                self.code_quality,
                self.output_validity,
                self.question_efficiency,
            ]
        )

    def to_dict(self) -> dict[str, int]:
        """Convert score to dictionary.

        Returns:
            Dictionary with all dimension scores and total
        """
        return {
            "completeness": self.completeness,
            "lint_quality": self.lint_quality,
            "code_quality": self.code_quality,
            "output_validity": self.output_validity,
            "question_efficiency": self.question_efficiency,
            "total": self.total,
        }


def calculate_lint_score(lint_cycles: int) -> int:
    """Calculate lint quality score based on cycles needed.

    Args:
        lint_cycles: Number of lint cycles before passing (0=never passed)

    Returns:
        Score from 0-3 based on cycles
    """
    if lint_cycles <= 0:
        return 0  # Never passed
    elif lint_cycles == 1:
        return 3  # First try
    elif lint_cycles == 2:
        return 2  # Second try
    else:
        return 1  # 3+ cycles


def _calculate_completeness(session: dict[str, Any]) -> int:
    """Calculate completeness score.

    Args:
        session: Session data dictionary

    Returns:
        Score from 0-3
    """
    requested = session.get("resources_requested", [])
    generated = session.get("resources_generated", [])

    if not requested:
        return 0

    # Calculate percentage of requested resources that were generated
    generated_set = set(generated)
    matched = sum(1 for r in requested if r in generated_set)
    percentage = matched / len(requested)

    if percentage >= 1.0:
        return 3
    elif percentage >= 0.66:
        return 2
    elif percentage >= 0.33:
        return 1
    else:
        return 0


def _calculate_output_validity(session: dict[str, Any]) -> int:
    """Calculate output validity score.

    Args:
        session: Session data dictionary

    Returns:
        Score from 0-3
    """
    build_success = session.get("build_success", False)
    validation_passed = session.get("validation_passed", False)
    manifest = session.get("manifest", "")

    if not build_success or not manifest:
        return 0

    if validation_passed:
        return 3
    elif manifest:
        # Manifest exists but validation status unknown
        return 2

    return 0


def _calculate_question_efficiency(session: dict[str, Any]) -> int:
    """Calculate question efficiency score.

    Args:
        session: Session data dictionary

    Returns:
        Score from 0-3
    """
    questions = session.get("questions_asked", 0)
    complexity = session.get("scenario_complexity", "medium")

    # Define expected question ranges based on complexity
    expected_ranges = {
        "simple": (0, 2),   # 0-2 questions for simple tasks
        "medium": (1, 4),   # 1-4 questions for medium tasks
        "complex": (2, 6),  # 2-6 questions for complex tasks
    }

    min_q, max_q = expected_ranges.get(complexity, (1, 4))

    if min_q <= questions <= max_q:
        return 3  # Perfect range
    elif questions < min_q:
        # Too few questions - might miss requirements
        diff = min_q - questions
        if diff <= 1:
            return 2
        else:
            return 1
    else:
        # Too many questions - inefficient
        diff = questions - max_q
        if diff <= 2:
            return 2
        elif diff <= 4:
            return 1
        else:
            return 0


def _calculate_code_quality(session: dict[str, Any]) -> int:
    """Calculate code quality score based on best practices.

    Args:
        session: Session data dictionary

    Returns:
        Score from 0-3
    """
    manifest = session.get("manifest", "")

    if not manifest:
        return 0

    quality_indicators = 0
    total_checks = 4

    # Check for explicit image tags (not :latest)
    if "image:" in manifest:
        # Has image specification
        if ":latest" not in manifest and ":" in manifest.split("image:")[-1].split("\n")[0]:
            quality_indicators += 1

    # Check for resource limits
    if "resources:" in manifest and "limits:" in manifest:
        quality_indicators += 1

    # Check for imagePullPolicy
    if "imagePullPolicy:" in manifest:
        quality_indicators += 1

    # Check for proper metadata (labels/annotations)
    if "labels:" in manifest or "annotations:" in manifest:
        quality_indicators += 1

    # Calculate score based on indicators present
    percentage = quality_indicators / total_checks

    if percentage >= 0.75:
        return 3
    elif percentage >= 0.5:
        return 2
    elif percentage >= 0.25:
        return 1
    else:
        return 0


def evaluate_session(session: dict[str, Any]) -> Score:
    """Evaluate a test session and return scores.

    Args:
        session: Dictionary containing session data with keys:
            - lint_cycles: int - Number of lint cycles needed
            - build_success: bool - Whether build succeeded
            - manifest: str - Generated YAML manifest
            - questions_asked: int - Number of clarifying questions
            - resources_requested: list - Resources that should be generated
            - resources_generated: list - Resources that were generated
            - validation_passed: bool - Whether kubeconform validation passed
            - scenario_complexity: str - "simple", "medium", or "complex"

    Returns:
        Score object with all dimension scores
    """
    if not session:
        return Score(
            completeness=0,
            lint_quality=0,
            code_quality=0,
            output_validity=0,
            question_efficiency=0,
        )

    lint_cycles = session.get("lint_cycles", 0)

    return Score(
        completeness=_calculate_completeness(session),
        lint_quality=calculate_lint_score(lint_cycles),
        code_quality=_calculate_code_quality(session),
        output_validity=_calculate_output_validity(session),
        question_efficiency=_calculate_question_efficiency(session),
    )


__all__ = [
    # Re-exports from wetwire-core
    "CoreScore",
    "MaxLintCyclesExceeded",
    "MaxTurnsExceeded",
    "ORCHESTRATOR_AVAILABLE",
    "Orchestrator",
    "OrchestratorError",
    "Rating",
    "ResultsWriter",
    "Session",
    "SessionConfig",
    "calculate_score",
    # Local implementations
    "Score",
    "calculate_lint_score",
    "evaluate_session",
]
