"""Kubernetes YAML validator using kubeconform."""

import json
import subprocess
from dataclasses import dataclass
from typing import Any

import yaml


class KubeconformNotInstalledError(Exception):
    """Raised when kubeconform is not installed."""

    def __init__(self) -> None:
        super().__init__(
            "kubeconform is not installed. "
            "Install it from https://github.com/yannh/kubeconform"
        )


class ValidationError(Exception):
    """Raised when validation fails."""

    pass


@dataclass
class ValidationResult:
    """Result of validating a single Kubernetes resource."""

    filename: str
    kind: str
    name: str
    version: str
    status: str
    message: str

    @property
    def is_valid(self) -> bool:
        """Check if the resource is valid."""
        return self.status in ("statusValid", "statusSkipped")

    @property
    def is_error(self) -> bool:
        """Check if there was an error during validation."""
        return self.status == "statusError"


def check_kubeconform_installed() -> bool:
    """Check if kubeconform is installed and available.

    Returns:
        True if kubeconform is installed, False otherwise.
    """
    try:
        subprocess.run(
            ["kubeconform", "-v"],
            capture_output=True,
            check=False,
        )
        return True
    except FileNotFoundError:
        return False


def parse_kubeconform_output(output: str) -> list[ValidationResult]:
    """Parse kubeconform JSON output into ValidationResult objects.

    Args:
        output: The JSON output from kubeconform (one JSON object per line).

    Returns:
        List of ValidationResult objects.
    """
    results = []

    for line in output.strip().split("\n"):
        if not line:
            continue

        try:
            data = json.loads(line)
            result = ValidationResult(
                filename=data.get("filename", ""),
                kind=data.get("kind", ""),
                name=data.get("name", ""),
                version=data.get("version", ""),
                status=data.get("status", ""),
                message=data.get("msg", ""),
            )
            results.append(result)
        except json.JSONDecodeError:
            # Skip invalid JSON lines
            continue

    return results


def run_kubeconform(
    file_path: str | None = None,
    stdin_content: str | None = None,
    kubernetes_version: str | None = None,
) -> list[ValidationResult]:
    """Run kubeconform on a file or stdin content.

    Args:
        file_path: Path to YAML file to validate.
        stdin_content: YAML content to validate via stdin.
        kubernetes_version: Kubernetes version to validate against (e.g., "1.29").

    Returns:
        List of ValidationResult objects.

    Raises:
        KubeconformNotInstalledError: If kubeconform is not installed.
        ValueError: If neither file_path nor stdin_content is provided.
    """
    if file_path is None and stdin_content is None:
        raise ValueError("Either file_path or stdin_content must be provided")

    cmd = ["kubeconform", "-output", "json"]

    if kubernetes_version:
        cmd.extend(["-kubernetes-version", kubernetes_version])

    if file_path:
        cmd.append(file_path)

    try:
        if stdin_content:
            result = subprocess.run(
                cmd,
                input=stdin_content,
                capture_output=True,
                text=True,
                check=False,
            )
        else:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False,
            )
    except FileNotFoundError:
        raise KubeconformNotInstalledError()

    return parse_kubeconform_output(result.stdout)


def validate_yaml(
    file_path: str | None = None,
    stdin_content: str | None = None,
    kubernetes_version: str | None = None,
) -> tuple[bool, list[ValidationResult]]:
    """Validate Kubernetes YAML file or content.

    Args:
        file_path: Path to YAML file to validate.
        stdin_content: YAML content to validate via stdin.
        kubernetes_version: Kubernetes version to validate against.

    Returns:
        Tuple of (is_valid, results) where is_valid is True if all resources
        are valid, and results is a list of ValidationResult objects.

    Raises:
        KubeconformNotInstalledError: If kubeconform is not installed.
    """
    results = run_kubeconform(
        file_path=file_path,
        stdin_content=stdin_content,
        kubernetes_version=kubernetes_version,
    )

    is_valid = all(result.is_valid for result in results)

    return is_valid, results


def validate_resource(
    resource: dict[str, Any],
    kubernetes_version: str | None = None,
) -> list[str]:
    """Validate a single Kubernetes resource dict.

    Args:
        resource: A parsed Kubernetes resource as a dictionary.
        kubernetes_version: Kubernetes version to validate against (e.g., "1.29").

    Returns:
        List of error messages. Empty list if validation passes.

    Raises:
        KubeconformNotInstalledError: If kubeconform is not installed.
    """
    yaml_content = yaml.dump(resource)
    results = run_kubeconform(
        stdin_content=yaml_content,
        kubernetes_version=kubernetes_version,
    )

    errors = []
    for result in results:
        if result.is_error or not result.is_valid:
            msg = result.message or f"Invalid {result.kind}/{result.name}"
            errors.append(msg)

    return errors
