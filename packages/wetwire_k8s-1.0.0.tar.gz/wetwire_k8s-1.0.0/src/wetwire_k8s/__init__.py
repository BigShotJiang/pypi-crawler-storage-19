"""wetwire-k8s - Kubernetes manifest synthesis for wetwire."""

from wetwire_k8s.serialize import to_dict, to_json, to_multi_yaml, to_yaml

__version__ = "0.1.0"

__all__ = ["to_dict", "to_yaml", "to_json", "to_multi_yaml", "__version__"]
