"""MCP server for wetwire-k8s.

This module provides an MCP (Model Context Protocol) server that exposes
wetwire-k8s tools for Claude Code integration.

Tools exposed via wetwire-core infrastructure:
- wetwire_init: Initialize a new wetwire-k8s project
- wetwire_build: Run wetwire-k8s build on a package path
- wetwire_lint: Run wetwire-k8s lint on a package path
- wetwire_validate: Validate generated Kubernetes manifests
- wetwire_import: Run wetwire-k8s import on a YAML file
- wetwire_list: List discovered resources
- wetwire_graph: Visualize resource dependencies
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

# Use wetwire-core MCP utilities
from wetwire_core.mcp import (
    DEBUG,
    MCP_AVAILABLE,
    StandardToolHandlers,
    ToolResult,
    get_standard_tools_for_mcp,
    run_server,
)
from wetwire_core.mcp import (
    create_server as core_create_server,
)

# Check if mcp is installed (for typing)
if MCP_AVAILABLE:
    import mcp.types as types


# Configure logging based on environment variable
def _setup_logging() -> logging.Logger:
    """Set up logging for MCP server."""
    logger = logging.getLogger("wetwire-k8s-mcp")

    if DEBUG or os.environ.get("WETWIRE_MCP_DEBUG") == "1":
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        ))
        logger.addHandler(handler)
    else:
        logger.setLevel(logging.WARNING)

    return logger


logger = _setup_logging()


# ============================================================================
# Internal helper functions (used by handlers)
# ============================================================================


def _run_build(package_path: str | None, output_format: str = "yaml") -> str:
    """Run the build command and return the output.

    Args:
        package_path: Path to the package (default: current directory)
        output_format: Output format (yaml or json)

    Returns:
        Generated YAML/JSON content or error message
    """
    from wetwire_k8s.loader import discover_resources
    from wetwire_k8s.serialize import to_multi_yaml
    from wetwire_k8s.template import (
        CircularDependencyError,
        MissingReferenceError,
        detect_cycles,
        extract_values,
        serialize_resources,
        topological_sort,
        validate_references,
    )

    # Get package path
    if package_path:
        path = Path(package_path)
    else:
        path = Path.cwd()

    # Check if path exists
    if not path.exists():
        return f"Error: Package path does not exist: {path}"

    try:
        # Discover resources
        resources = discover_resources(path)

        if resources:
            # Validate and process
            validate_references(resources)
            detect_cycles(resources)
            sorted_resources = topological_sort(resources)
            values = extract_values(sorted_resources)
            serialized = serialize_resources(values)
        else:
            serialized = []

        # Format output
        if output_format == "json":
            return json.dumps(serialized, indent=2)
        else:
            return to_multi_yaml(serialized) if serialized else ""

    except (FileNotFoundError, MissingReferenceError, CircularDependencyError) as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def _run_lint(package_path: str | None) -> str:
    """Run the lint command and return the output.

    Args:
        package_path: Path to the package (default: current directory)

    Returns:
        Lint violations or "No issues found"
    """
    from wetwire_k8s.linter.engine import LintEngine
    from wetwire_k8s.loader import discover_resources

    # Get package path
    if package_path:
        path = Path(package_path)
    else:
        path = Path.cwd()

    # Check if path exists
    if not path.exists():
        return f"Error: Package path does not exist: {path}"

    try:
        # Discover resources
        resources = discover_resources(path)

        if not resources:
            return "No issues found (no resources discovered)"

        # Get Python files for content analysis
        if path.is_file():
            files = [path]
        else:
            files = list(path.rglob("*.py"))

        # Run linter
        engine = LintEngine()
        issues = engine.lint(resources, files)

        if not issues:
            return "No issues found"

        # Format output
        lines = []
        for issue in issues:
            lines.append(f"{issue.file}:{issue.line}: [{issue.rule}] {issue.message}")
        lines.append(f"\nTotal: {len(issues)} issue(s) found")

        return "\n".join(lines)

    except Exception as e:
        return f"Error: {e}"


def _run_import(file_path: str | None) -> str:
    """Run the import command and return the output.

    Args:
        file_path: Path to the YAML file to import

    Returns:
        Generated Python code or error message
    """
    from wetwire_k8s.importer import import_yaml_file

    if not file_path:
        return "Error: file_path is required"

    path = Path(file_path)
    if not path.exists():
        return f"Error: File not found: {file_path}"

    try:
        return import_yaml_file(str(path))
    except Exception as e:
        return f"Error: {e}"


# ============================================================================
# Tool Handlers - Return ToolResult for wetwire-core integration
# ============================================================================


def handle_init(
    name: str | None = None,
    output: str | None = None,
    **kwargs: Any,
) -> ToolResult:
    """Initialize a new wetwire-k8s project.

    Args:
        name: Project name
        output: Output directory (default: current directory)

    Returns:
        ToolResult with success status and message
    """
    try:
        output_dir = Path(output) if output else Path.cwd()
        project_name = name or output_dir.name or "my-k8s-project"

        # Create directory if it doesn't exist
        output_dir.mkdir(parents=True, exist_ok=True)

        # Create pyproject.toml
        pyproject_path = output_dir / "pyproject.toml"
        if not pyproject_path.exists():
            pyproject_content = f'''[project]
name = "{project_name}"
version = "0.1.0"
description = "Kubernetes resources defined in Python"
requires-python = ">=3.10"
dependencies = [
    "wetwire-k8s",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
'''
            pyproject_path.write_text(pyproject_content)

        # Create infra.py
        infra_path = output_dir / "infra.py"
        if not infra_path.exists():
            infra_content = '''"""Kubernetes infrastructure resources."""

from wetwire_k8s.resources.core.v1.config_map import ConfigMap
from wetwire_k8s.resources.apps.v1.deployment import Deployment
from wetwire_k8s.resources.core.v1.service import Service

# Example ConfigMap
app_config: ConfigMap = ConfigMap(
    metadata={"name": "app-config", "namespace": "default"},
    data={"APP_ENV": "production"},
)

# Example Deployment
app_deployment: Deployment = Deployment(
    metadata={"name": "app", "namespace": "default"},
    spec={
        "replicas": 1,
        "selector": {"matchLabels": {"app": "app"}},
        "template": {
            "metadata": {"labels": {"app": "app"}},
            "spec": {
                "containers": [{
                    "name": "app",
                    "image": "nginx:1.21",
                    "ports": [{"containerPort": 80}],
                }]
            },
        },
    },
)

# Example Service
app_service: Service = Service(
    metadata={"name": "app", "namespace": "default"},
    spec={
        "selector": {"app": "app"},
        "ports": [{"port": 80, "targetPort": 80}],
    },
)
'''
            infra_path.write_text(infra_content)

        return ToolResult(
            success=True,
            message=f"Initialized wetwire-k8s project '{project_name}' in {output_dir}",
        )
    except Exception as e:
        return ToolResult(success=False, message=f"Error initializing project: {e}")


def handle_build(
    package: str | None = None,
    output: str | None = None,
    format: str = "yaml",
    **kwargs: Any,
) -> ToolResult:
    """Build Kubernetes manifests from Python resources.

    Args:
        package: Path to the package (default: current directory)
        output: Output file path (default: stdout)
        format: Output format (yaml or json)

    Returns:
        ToolResult with success status and generated content
    """
    result = _run_build(package, format)
    if result.startswith("Error:"):
        return ToolResult(success=False, message=result)
    return ToolResult(success=True, message=result)


def handle_lint(
    package: str | None = None,
    fix: bool = False,
    format: str = "text",
    **kwargs: Any,
) -> ToolResult:
    """Run lint checks on Kubernetes resources.

    Args:
        package: Path to the package (default: current directory)
        fix: Auto-fix issues where possible (not yet implemented)
        format: Output format (text or json)

    Returns:
        ToolResult with success status and lint results
    """
    result = _run_lint(package)
    # Determine success based on presence of issues
    is_success = "no issues" in result.lower() or result.strip() == ""
    return ToolResult(success=is_success, message=result)


def handle_validate(
    files: list[str] | None = None,
    format: str = "text",
    **kwargs: Any,
) -> ToolResult:
    """Validate generated Kubernetes manifests.

    Args:
        files: List of files to validate
        format: Output format (text or json)

    Returns:
        ToolResult with validation results
    """
    from wetwire_k8s.validator import validate_resource

    if not files:
        return ToolResult(success=False, message="Error: No files specified for validation")

    all_errors = []
    for file_path in files:
        path = Path(file_path)
        if not path.exists():
            all_errors.append(f"{file_path}: File not found")
            continue

        try:
            import yaml
            with open(path) as f:
                for doc in yaml.safe_load_all(f):
                    if doc:
                        errors = validate_resource(doc)
                        if errors:
                            all_errors.extend(f"{file_path}: {e}" for e in errors)
        except Exception as e:
            all_errors.append(f"{file_path}: {e}")

    if all_errors:
        return ToolResult(success=False, message="\n".join(all_errors))
    return ToolResult(success=True, message="All files validated successfully")


def handle_import(
    files: list[str] | None = None,
    output: str | None = None,
    single_file: bool = False,
    **kwargs: Any,
) -> ToolResult:
    """Import Kubernetes YAML and generate Python code.

    Args:
        files: List of YAML files to import
        output: Output directory (default: current directory)
        single_file: Combine all resources into a single file

    Returns:
        ToolResult with generated Python code
    """
    if not files:
        return ToolResult(success=False, message="Error: file_path is required")

    results = []
    for file_path in files:
        result = _run_import(file_path)
        if result.startswith("Error:"):
            return ToolResult(success=False, message=result)
        results.append(f"# From {file_path}\n{result}")

    return ToolResult(success=True, message="\n\n".join(results))


def handle_list(
    package: str | None = None,
    format: str = "text",
    **kwargs: Any,
) -> ToolResult:
    """List discovered resources.

    Args:
        package: Path to the package (default: current directory)
        format: Output format (text or json)

    Returns:
        ToolResult with list of resources
    """
    from wetwire_k8s.loader import discover_resources

    path = Path(package) if package else Path.cwd()

    if not path.exists():
        return ToolResult(success=False, message=f"Error: Package path does not exist: {path}")

    try:
        # discover_resources returns a list of DiscoveredResource objects
        resources = discover_resources(path)

        if not resources:
            return ToolResult(success=True, message="No resources discovered")

        if format == "json":
            items = [
                {"name": res.name, "kind": res.type, "file": res.file, "line": res.line}
                for res in resources
            ]
            return ToolResult(success=True, message=json.dumps(items, indent=2))

        lines = [f"Discovered {len(resources)} resource(s):"]
        for res in resources:
            lines.append(f"  - {res.name}: {res.type} ({res.file}:{res.line})")
        return ToolResult(success=True, message="\n".join(lines))

    except Exception as e:
        return ToolResult(success=False, message=f"Error: {e}")


def handle_graph(
    package: str | None = None,
    format: str = "dot",
    output: str | None = None,
    **kwargs: Any,
) -> ToolResult:
    """Visualize resource dependencies.

    Args:
        package: Path to the package (default: current directory)
        format: Output format (dot or mermaid)
        output: Output file path

    Returns:
        ToolResult with dependency graph
    """
    from wetwire_k8s.loader import discover_resources

    path = Path(package) if package else Path.cwd()

    if not path.exists():
        return ToolResult(success=False, message=f"Error: Package path does not exist: {path}")

    try:
        # discover_resources returns a list of DiscoveredResource objects
        resources = discover_resources(path)

        if not resources:
            return ToolResult(success=True, message="No resources to graph")

        # Build edges from dependencies
        edges = []
        resource_names = {res.name for res in resources}
        for res in resources:
            for dep in res.dependencies:
                if dep in resource_names:
                    edges.append((res.name, dep))

        if format == "mermaid":
            lines = ["graph TD"]
            for src, dst in edges:
                lines.append(f"    {src} --> {dst}")
            if not edges:
                for res in resources:
                    lines.append(f"    {res.name}")
            return ToolResult(success=True, message="\n".join(lines))

        # Default to DOT format
        lines = ["digraph G {"]
        for src, dst in edges:
            lines.append(f'    "{src}" -> "{dst}";')
        if not edges:
            for res in resources:
                lines.append(f'    "{res.name}";')
        lines.append("}")
        return ToolResult(success=True, message="\n".join(lines))

    except Exception as e:
        return ToolResult(success=False, message=f"Error: {e}")


# ============================================================================
# Server creation and registration
# ============================================================================


def create_server() -> Any:
    """Create and configure the MCP server using wetwire-core infrastructure.

    Returns:
        Configured MCP Server instance

    Raises:
        ImportError: If mcp is not installed
    """
    if not MCP_AVAILABLE:
        raise ImportError(
            "mcp is not installed. Install with: pip install wetwire-k8s[mcp]"
        )

    # Create server using wetwire-core
    server = core_create_server("wetwire-k8s")

    # Set up handlers for standard tools
    handlers = StandardToolHandlers(
        init=handle_init,
        build=handle_build,
        lint=handle_lint,
        validate=handle_validate,
        import_=handle_import,
        list_=handle_list,
        graph=handle_graph,
    )

    # Get standard tools with our handlers
    tools = get_standard_tools_for_mcp("k8s", handlers)

    # Register list_tools handler
    @server.list_tools()
    async def handle_list_tools() -> list[types.Tool]:
        """Return list of available tools."""
        return [
            types.Tool(
                name=tool["name"],
                description=tool["description"],
                inputSchema=tool["inputSchema"],
            )
            for tool in tools
        ]

    # Register call_tool handler
    @server.call_tool()
    async def handle_call_tool(
        name: str, arguments: dict[str, Any] | None
    ) -> list[types.TextContent]:
        """Handle tool calls."""
        logger.debug(f"Tool called: {name} with arguments: {arguments}")

        if arguments is None:
            arguments = {}

        # Find the tool and call its handler
        for tool in tools:
            if tool["name"] == name:
                handler = tool["handler"]
                result = handler(**arguments)
                return [types.TextContent(type="text", text=result.message)]

        return [
            types.TextContent(
                type="text",
                text=f"Error: Unknown tool '{name}'",
            )
        ]

    return server


async def amain() -> None:
    """Async main entry point for MCP server."""
    if not MCP_AVAILABLE:
        print(
            "Error: mcp is not installed. Install with: pip install wetwire-k8s[mcp]",
            file=sys.stderr,
        )
        sys.exit(1)

    server = create_server()
    run_server(server)


def main() -> int:
    """Main entry point for MCP server."""
    if not MCP_AVAILABLE:
        print(
            "Error: mcp is not installed. Install with: pip install wetwire-k8s[mcp]",
            file=sys.stderr,
        )
        return 1

    asyncio.run(amain())
    return 0


if __name__ == "__main__":
    sys.exit(main())
