"""AST-based resource discovery for Kubernetes resources.

This module implements resource discovery per Wetwire Spec Section 8.1.
Resources are discovered via AST parsing without code execution.
"""

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DiscoveredResource:
    """A discovered Kubernetes resource.

    Attributes:
        name: Variable name of the resource
        type: Kubernetes resource type (e.g., "Deployment", "Service")
        file: Source file path where the resource is defined
        line: Line number where the resource is defined
        dependencies: List of other resource names this resource references
    """

    name: str
    type: str
    file: str
    line: int
    dependencies: list[str] = field(default_factory=list)


def discover_resources(package_path: Path) -> list[DiscoveredResource]:
    """Discover all Kubernetes resources in a package or file.

    Args:
        package_path: Path to a Python file or package directory

    Returns:
        List of discovered resources

    Raises:
        FileNotFoundError: If the path does not exist
    """
    if not package_path.exists():
        raise FileNotFoundError(f"Path does not exist: {package_path}")

    resources: list[DiscoveredResource] = []

    if package_path.is_file():
        # Single file
        if package_path.suffix == ".py":
            resources.extend(parse_file(package_path))
    else:
        # Directory - recursively find all Python files
        for py_file in package_path.rglob("*.py"):
            resources.extend(parse_file(py_file))

    return resources


def parse_file(file_path: Path) -> list[DiscoveredResource]:
    """Parse a single Python file and extract Kubernetes resources.

    Only top-level variable assignments with type annotations are considered.
    The type annotation must be a known Kubernetes resource type.

    Args:
        file_path: Path to the Python file

    Returns:
        List of discovered resources in the file

    Raises:
        FileNotFoundError: If the file does not exist
    """
    if not file_path.exists():
        raise FileNotFoundError(f"File does not exist: {file_path}")

    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(file_path))
    except SyntaxError:
        # Invalid Python syntax - return empty list
        return []

    resources: list[DiscoveredResource] = []

    # Only look at top-level assignments
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            # This is an annotated assignment: name: Type = value
            var_name = node.target.id
            type_name = _extract_type_name(node.annotation)

            # Check if this looks like a Kubernetes resource type
            if type_name and _is_k8s_resource_type(type_name):
                line_number = node.lineno

                # Extract dependencies from the initializer
                dependencies = []
                if node.value:
                    dependencies = extract_dependencies(node.value)

                resource = DiscoveredResource(
                    name=var_name,
                    type=type_name,
                    file=str(file_path),
                    line=line_number,
                    dependencies=dependencies,
                )
                resources.append(resource)

    return resources


def extract_dependencies(node: ast.AST) -> list[str]:
    """Extract resource dependencies from an AST node.

    This function walks the AST tree and finds all Name nodes that could
    reference other resources.

    Args:
        node: AST node to analyze (typically the value of an assignment)

    Returns:
        List of variable names that are referenced
    """
    dependencies: set[str] = set()

    for child in ast.walk(node):
        if isinstance(child, ast.Name):
            # Found a reference to a variable
            dependencies.add(child.id)

    # Filter out built-in names, keywords, and K8s resource type names
    filtered = {
        dep
        for dep in dependencies
        if not _is_builtin_or_keyword(dep) and not _is_k8s_resource_type(dep)
    }

    return sorted(filtered)


def _extract_type_name(annotation: ast.AST) -> str | None:
    """Extract the type name from a type annotation.

    Args:
        annotation: AST node representing the type annotation

    Returns:
        The type name as a string, or None if it cannot be extracted
    """
    if isinstance(annotation, ast.Name):
        # Simple type: MyType
        return annotation.id
    elif isinstance(annotation, ast.Attribute):
        # Qualified type: module.MyType
        return annotation.attr
    elif isinstance(annotation, ast.Subscript):
        # Generic type: Optional[MyType], list[MyType]
        # Extract the base type
        return _extract_type_name(annotation.value)

    return None


def _is_k8s_resource_type(type_name: str) -> bool:
    """Check if a type name is a known Kubernetes resource type.

    This is a heuristic check. We consider capitalized names that are
    common Kubernetes resource types or follow the naming pattern.

    Args:
        type_name: The type name to check

    Returns:
        True if this appears to be a Kubernetes resource type
    """
    # Common Kubernetes resource types
    known_types = {
        "Pod",
        "Deployment",
        "Service",
        "ConfigMap",
        "Secret",
        "Namespace",
        "PersistentVolume",
        "PersistentVolumeClaim",
        "StatefulSet",
        "DaemonSet",
        "Job",
        "CronJob",
        "Ingress",
        "ServiceAccount",
        "Role",
        "RoleBinding",
        "ClusterRole",
        "ClusterRoleBinding",
        "NetworkPolicy",
        "ResourceQuota",
        "LimitRange",
        "HorizontalPodAutoscaler",
        "VerticalPodAutoscaler",
        "PodDisruptionBudget",
        "StorageClass",
        "VolumeAttachment",
        "CSIDriver",
        "CSINode",
        "CustomResourceDefinition",
        "APIService",
        "MutatingWebhookConfiguration",
        "ValidatingWebhookConfiguration",
        "Endpoints",
        "EndpointSlice",
        "Event",
        "Lease",
        "Node",
        "PriorityClass",
        "RuntimeClass",
        "PodTemplate",
        "ReplicationController",
        "ReplicaSet",
        "ComponentStatus",
        "Binding",
        "ControllerRevision",
        "TokenReview",
        "CertificateSigningRequest",
        "SubjectAccessReview",
        "SelfSubjectAccessReview",
        "LocalSubjectAccessReview",
        "SelfSubjectRulesReview",
    }

    return type_name in known_types


def _is_builtin_or_keyword(name: str) -> bool:
    """Check if a name is a Python builtin or keyword.

    Args:
        name: The name to check

    Returns:
        True if this is a builtin or keyword that should be filtered out
    """
    import builtins
    import keyword

    # Common builtin functions and constants
    if name in dir(builtins):
        return True

    # Python keywords
    if keyword.iskeyword(name):
        return True

    # Common non-resource names that appear in Kubernetes manifests
    common_non_resources = {
        "metadata",
        "spec",
        "data",
        "status",
        "kind",
        "apiVersion",
        "items",
        "string",
        "int",
        "bool",
        "list",
        "dict",
        "set",
        "tuple",
        "str",
        "bytes",
    }

    return name in common_non_resources
