"""Persona loading and configuration.

This module re-exports from wetwire_core.personas for convenience.
"""

from wetwire_core.personas import (
    BEGINNER,
    EXPERT,
    INTERMEDIATE,
    PERSONAS,
    TERSE,
    VERBOSE,
    Persona,
    all_personas,
    get_persona,
    load_persona,
    persona_names,
)

__all__ = [
    "BEGINNER",
    "EXPERT",
    "INTERMEDIATE",
    "PERSONAS",
    "TERSE",
    "VERBOSE",
    "Persona",
    "all_personas",
    "get_persona",
    "load_persona",
    "persona_names",
]
