"""AI agent for infrastructure generation.

This module provides the design agent that uses AI to generate
Kubernetes infrastructure code from natural language prompts.
"""

import json
from pathlib import Path
from typing import Any

# Tool implementations


def init_package(directory: str) -> str:
    """Initialize a new package directory.

    Args:
        directory: Path to the directory to create

    Returns:
        Success message with directory path
    """
    path = Path(directory)
    path.mkdir(parents=True, exist_ok=True)
    return f"Created directory: {directory}"


def write_file(path: str, content: str) -> str:
    """Write content to a file.

    Args:
        path: Path to the file to write
        content: Content to write to the file

    Returns:
        Success message with bytes written
    """
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content)
    return f"Wrote {len(content)} bytes to {path}"


def read_file(path: str) -> str:
    """Read content from a file.

    Args:
        path: Path to the file to read

    Returns:
        File content as string

    Raises:
        FileNotFoundError: If the file does not exist
    """
    return Path(path).read_text()


def run_lint(package_path: str) -> dict[str, Any]:
    """Run linter on package.

    Args:
        package_path: Path to the package directory

    Returns:
        Dictionary with 'passed' boolean and 'violations' list
    """
    from wetwire_k8s.linter.engine import LintEngine
    from wetwire_k8s.loader import discover_resources

    path = Path(package_path)
    resources = discover_resources(path)

    # Collect source files
    source_files = []
    if path.is_file():
        source_files = [path]
    else:
        source_files = list(path.rglob("*.py"))

    engine = LintEngine()
    issues = engine.lint(resources, source_files)

    return {
        "passed": len(issues) == 0,
        "violations": [
            f"{issue.rule}: {issue.message} ({issue.file}:{issue.line})"
            for issue in issues
        ],
    }


def run_build(package_path: str) -> dict[str, Any]:
    """Build manifest from package.

    Args:
        package_path: Path to the package directory

    Returns:
        Dictionary with 'success' boolean and 'manifest' content
    """
    from wetwire_k8s.loader import discover_resources
    from wetwire_k8s.serialize import to_multi_yaml
    from wetwire_k8s.template import (
        detect_cycles,
        extract_values,
        serialize_resources,
        topological_sort,
        validate_references,
    )

    try:
        path = Path(package_path)
        resources = discover_resources(path)

        if resources:
            validate_references(resources)
            detect_cycles(resources)
            sorted_resources = topological_sort(resources)
            values = extract_values(sorted_resources)
            serialized = serialize_resources(values)
            manifest = to_multi_yaml(serialized) if serialized else ""
        else:
            manifest = ""

        return {"success": True, "manifest": manifest}
    except Exception as e:
        return {"success": False, "error": str(e)}


def ask_developer(question: str) -> str:
    """Query user for clarification.

    Args:
        question: Question to ask the user

    Returns:
        User's response
    """
    return input(f"\n[Agent Question] {question}\n> ")


def handle_tool_call(tool_name: str, tool_input: dict[str, Any]) -> str:
    """Handle a tool call from the AI agent.

    Args:
        tool_name: Name of the tool to call
        tool_input: Input parameters for the tool

    Returns:
        Result of the tool call as a string
    """
    if tool_name == "init_package":
        return init_package(tool_input["directory"])
    elif tool_name == "write_file":
        return write_file(tool_input["path"], tool_input["content"])
    elif tool_name == "read_file":
        return read_file(tool_input["path"])
    elif tool_name == "run_lint":
        result = run_lint(tool_input["package_path"])
        return json.dumps(result)
    elif tool_name == "run_build":
        result = run_build(tool_input["package_path"])
        return json.dumps(result)
    elif tool_name == "ask_developer":
        return ask_developer(tool_input["question"])
    else:
        return f"Error: Unknown tool '{tool_name}'"


# Tool definitions for the Anthropic API
TOOLS = [
    {
        "name": "init_package",
        "description": "Create a new package directory structure for Kubernetes resources",
        "input_schema": {
            "type": "object",
            "properties": {
                "directory": {
                    "type": "string",
                    "description": "Path to the directory to create",
                }
            },
            "required": ["directory"],
        },
    },
    {
        "name": "write_file",
        "description": "Write content to a source file. After writing, you MUST call run_lint to validate the code.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file",
                },
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "read_file",
        "description": "Read content from an existing file",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read",
                }
            },
            "required": ["path"],
        },
    },
    {
        "name": "run_lint",
        "description": "Run the linter on the package to check for issues. Returns passed status and list of violations.",
        "input_schema": {
            "type": "object",
            "properties": {
                "package_path": {
                    "type": "string",
                    "description": "Path to the package directory to lint",
                }
            },
            "required": ["package_path"],
        },
    },
    {
        "name": "run_build",
        "description": "Build the Kubernetes manifest from the package. Returns success status and the generated YAML manifest.",
        "input_schema": {
            "type": "object",
            "properties": {
                "package_path": {
                    "type": "string",
                    "description": "Path to the package directory to build",
                }
            },
            "required": ["package_path"],
        },
    },
    {
        "name": "ask_developer",
        "description": "Ask the developer a clarifying question when you need more information to proceed",
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The question to ask the developer",
                }
            },
            "required": ["question"],
        },
    },
]

SYSTEM_PROMPT = """You are a Kubernetes infrastructure expert that generates Python code for wetwire-k8s.

Your task is to create Kubernetes resources as Python code using the wetwire-k8s library based on the user's requirements.

## Available Resources
Use imports like:
- from wetwire_k8s.resources.core.v1 import ConfigMap, Secret, Service, Pod, Namespace, PersistentVolumeClaim
- from wetwire_k8s.resources.apps.v1 import Deployment, StatefulSet, DaemonSet
- from wetwire_k8s.resources.networking.v1 import Ingress, NetworkPolicy

## Resource Definition Pattern
Define resources as typed module-level variables:

```python
from wetwire_k8s.resources.core.v1 import ConfigMap

my_config: ConfigMap = ConfigMap(
    apiVersion="v1",
    kind="ConfigMap",
    metadata={"name": "my-config", "namespace": "default"},
    data={"KEY": "value"}
)
```

## CRITICAL RULES - You MUST follow these:

1. **Lint After Write**: After calling write_file, you MUST call run_lint on the package. Never skip this step.

2. **Pass Before Done**: You cannot complete the task until run_lint returns passed=True. If there are violations, fix them and re-run lint.

3. **Build to Verify**: After lint passes, call run_build to generate and verify the manifest.

4. **Best Practices**:
   - Always specify explicit image tags (never use :latest)
   - Always set imagePullPolicy
   - Use secretKeyRef for sensitive values instead of hardcoding
   - Extract container specs into variables for reusability
   - Use typed constants for port numbers

## Workflow
1. Create the package directory with init_package
2. Write resource files with write_file
3. Run lint with run_lint (REQUIRED after every write)
4. Fix any violations and re-lint until passed
5. Build the manifest with run_build to verify
6. Report completion to the user

If you need clarification from the user, use ask_developer.
"""


def run_design_agent(prompt: str, output_dir: str, provider: str = "anthropic") -> dict[str, Any]:
    """Run the design agent with the given prompt.

    Args:
        prompt: The user's design prompt
        output_dir: Directory for output files
        provider: The AI provider to use (default: "anthropic")

    Returns:
        Dictionary with success status and output_dir, or error message
    """
    try:
        import wetwire_core.providers
    except ImportError:
        return {
            "error": "anthropic library not installed. Run: pip install wetwire-k8s[agent]"
        }

    # Get the provider
    try:
        provider_instance = wetwire_core.providers.get_provider(provider)
    except Exception as e:
        return {
            "error": f"Failed to initialize provider '{provider}': {e}"
        }

    # Enhance prompt with output directory context
    enhanced_prompt = f"""Please create Kubernetes infrastructure for the following request:

{prompt}

Output directory: {output_dir}

Create the resources in Python files within the output directory.
"""

    messages: list[dict[str, Any]] = [{"role": "user", "content": enhanced_prompt}]

    try:
        while True:
            response = provider_instance.create_message(
                messages=messages,
                system=SYSTEM_PROMPT,
                tools=TOOLS,
                max_tokens=4096,
            )

            # Handle tool calls
            stop_reason = response.get("stop_reason")
            content = response.get("content", [])

            if stop_reason == "tool_use":
                # Process tool calls
                tool_results = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        try:
                            result = handle_tool_call(block["name"], block["input"])
                        except Exception as e:
                            result = f"Error: {e}"
                        tool_results.append(
                            {
                                "type": "tool_result",
                                "tool_use_id": block["id"],
                                "content": result,
                            }
                        )
                    elif hasattr(block, 'type') and block.type == "tool_use":
                        # Handle object-based response format
                        try:
                            result = handle_tool_call(block.name, block.input)
                        except Exception as e:
                            result = f"Error: {e}"
                        tool_results.append(
                            {
                                "type": "tool_result",
                                "tool_use_id": block.id,
                                "content": result,
                            }
                        )

                # Add assistant response and tool results to messages
                messages.append({"role": "assistant", "content": content})
                messages.append({"role": "user", "content": tool_results})
            else:
                # Agent finished
                break

        return {"success": True, "output_dir": output_dir}

    except Exception as e:
        return {"error": str(e)}
