"""Test runner for persona-based testing.

This module provides functionality to run automated persona-based tests
to evaluate AI agent performance.
"""

import json
from pathlib import Path
from typing import Any

from wetwire_k8s.agent import run_design_agent
from wetwire_k8s.personas import PERSONAS, Persona, get_persona
from wetwire_k8s.scoring import Score, evaluate_session


def create_persona_prompt(scenario: str, persona: Persona) -> str:
    """Create a prompt based on persona style.

    Args:
        scenario: Test scenario description
        persona: Persona to use for prompt generation

    Returns:
        Prompt string incorporating persona characteristics
    """
    # Generate different prompt styles based on persona
    if persona.name == "beginner":
        return (
            f"I need help with {scenario}. I'm not really sure what I need exactly, "
            f"but can you help me set something up? I've heard about Kubernetes "
            f"but I'm new to all this."
        )
    elif persona.name == "expert":
        return (
            f"Please create the infrastructure for: {scenario}. "
            f"I expect proper resource limits, security contexts, and idiomatic patterns. "
            f"Use specific image tags, not :latest."
        )
    elif persona.name == "terse":
        return f"{scenario}. K8s."
    elif persona.name == "verbose":
        return (
            f"Hi there! I'm working on this project and we have a {scenario} that we "
            f"need to deploy to Kubernetes. Let me give you some background - we've been "
            f"developing this application for a few months now, and we're finally ready "
            f"to containerize it. We've tried a few different approaches before, but "
            f"we're hoping to get this right this time. The basic requirement is {scenario}. "
            f"Any questions, just let me know - I'm happy to provide more details!"
        )
    else:  # intermediate
        return (
            f"I need to deploy a {scenario} to Kubernetes. "
            f"Please create the necessary resources."
        )


def run_test(scenario: str, persona_name: str, output_dir: Path, provider: str = "anthropic") -> dict[str, Any]:
    """Run a single test with a persona.

    Args:
        scenario: Test scenario description
        persona_name: Name of the persona to use
        output_dir: Directory for output files
        provider: AI provider to use (default: "anthropic")

    Returns:
        Dictionary with test results including persona, scenario, score, and session
    """
    persona = get_persona(persona_name)

    # Create prompt based on persona style
    prompt = create_persona_prompt(scenario, persona)

    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)

    # Run the design agent
    result = run_design_agent(prompt, str(output_dir), provider=provider)

    # Handle agent errors
    if "error" in result:
        return {
            "persona": persona_name,
            "scenario": scenario,
            "score": Score(
                completeness=0,
                lint_quality=0,
                code_quality=0,
                output_validity=0,
                question_efficiency=0,
            ),
            "session": {"error": result["error"]},
            "error": result["error"],
        }

    # Build session data for scoring
    session = {
        "lint_cycles": result.get("lint_cycles", 0),
        "build_success": result.get("build_success", result.get("success", False)),
        "manifest": result.get("manifest", ""),
        "questions_asked": result.get("questions_asked", 0),
        "resources_requested": result.get("resources_requested", []),
        "resources_generated": result.get("resources_generated", []),
        "validation_passed": result.get("validation_passed", False),
        "scenario_complexity": _estimate_complexity(scenario),
        "messages": result.get("messages", []),
    }

    # Evaluate and score
    score = evaluate_session(session)

    return {
        "persona": persona_name,
        "scenario": scenario,
        "score": score,
        "session": session,
    }


def _estimate_complexity(scenario: str) -> str:
    """Estimate scenario complexity based on description.

    Args:
        scenario: Scenario description

    Returns:
        Complexity level: "simple", "medium", or "complex"
    """
    scenario_lower = scenario.lower()

    # Complex indicators
    complex_terms = [
        "database",
        "stateful",
        "persistent",
        "rbac",
        "network policy",
        "ingress",
        "tls",
        "ssl",
        "multi-container",
        "sidecar",
        "init container",
    ]

    # Simple indicators
    simple_terms = [
        "configmap",
        "secret",
        "simple",
        "basic",
        "hello world",
    ]

    # Count matches
    complex_count = sum(1 for term in complex_terms if term in scenario_lower)
    simple_count = sum(1 for term in simple_terms if term in scenario_lower)

    if complex_count >= 2:
        return "complex"
    elif simple_count >= 1 or len(scenario) < 20:
        return "simple"
    else:
        return "medium"


def run_all_personas(scenario: str, output_dir: Path, provider: str = "anthropic") -> list[dict[str, Any]]:
    """Run test with all personas.

    Args:
        scenario: Test scenario description
        output_dir: Base directory for output files
        provider: AI provider to use (default: "anthropic")

    Returns:
        List of test results for each persona
    """
    results = []

    for name in PERSONAS:
        # Create subdirectory for each persona
        persona_output_dir = output_dir / name
        persona_output_dir.mkdir(parents=True, exist_ok=True)

        result = run_test(scenario, name, persona_output_dir, provider=provider)
        results.append(result)

    return results


def write_results(results: list[dict[str, Any]], output_dir: Path) -> None:
    """Write test results to files.

    Creates:
        - RESULTS.md: Human-readable summary
        - session.json: Full conversation log
        - score.json: Scoring breakdown

    Args:
        results: List of test results from run_test or run_all_personas
        output_dir: Directory to write output files
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Extract scenario from first result
    scenario = results[0]["scenario"] if results else "Unknown scenario"

    # Write RESULTS.md
    _write_results_md(results, output_dir, scenario)

    # Write session.json
    _write_session_json(results, output_dir)

    # Write score.json
    _write_score_json(results, output_dir)


def _write_results_md(
    results: list[dict[str, Any]], output_dir: Path, scenario: str
) -> None:
    """Write RESULTS.md file.

    Args:
        results: List of test results
        output_dir: Output directory
        scenario: Scenario description
    """
    lines = [
        "# Test Results",
        "",
        f"## Scenario: {scenario}",
        "",
        "## Summary",
        "",
        "| Persona | Total | Completeness | Lint | Code Quality | Validity | Questions |",
        "|---------|-------|--------------|------|--------------|----------|-----------|",
    ]

    for result in results:
        score = result["score"]
        lines.append(
            f"| {result['persona']} | {score.total}/15 | {score.completeness} | "
            f"{score.lint_quality} | {score.code_quality} | {score.output_validity} | "
            f"{score.question_efficiency} |"
        )

    lines.extend(
        [
            "",
            "## Scoring Guide",
            "",
            "- **Completeness** (0-3): Were all required resources generated?",
            "- **Lint** (0-3): Lint cycles needed (3=first try, 2=2 cycles, 1=3+, 0=never)",
            "- **Code Quality** (0-3): Idiomatic patterns used?",
            "- **Validity** (0-3): Output validates with kubeconform?",
            "- **Questions** (0-3): Appropriate number of clarifying questions?",
            "",
        ]
    )

    results_file = output_dir / "RESULTS.md"
    results_file.write_text("\n".join(lines))


def _write_session_json(results: list[dict[str, Any]], output_dir: Path) -> None:
    """Write session.json file.

    Args:
        results: List of test results
        output_dir: Output directory
    """
    sessions = []
    for result in results:
        sessions.append(
            {
                "persona": result["persona"],
                "scenario": result["scenario"],
                "session": result.get("session", {}),
            }
        )

    session_file = output_dir / "session.json"
    session_file.write_text(json.dumps(sessions, indent=2))


def _write_score_json(results: list[dict[str, Any]], output_dir: Path) -> None:
    """Write score.json file.

    Args:
        results: List of test results
        output_dir: Output directory
    """
    scores = []
    for result in results:
        score = result["score"]
        scores.append(
            {
                "persona": result["persona"],
                "scenario": result["scenario"],
                **score.to_dict(),
            }
        )

    score_file = output_dir / "score.json"
    score_file.write_text(json.dumps(scores, indent=2))
