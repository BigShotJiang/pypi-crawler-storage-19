"""CLI entry point for wetwire-k8s."""

import argparse
import difflib
import json
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import yaml

from wetwire_k8s.importer import import_yaml_file
from wetwire_k8s.loader import discover_resources
from wetwire_k8s.serialize import to_json, to_multi_yaml, to_yaml
from wetwire_k8s.template import (
    CircularDependencyError,
    MissingReferenceError,
    detect_cycles,
    extract_values,
    serialize_resources,
    topological_sort,
    validate_references,
)
from wetwire_k8s.validator import KubeconformNotInstalledError, validate_yaml

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
RESET = "\033[0m"


def normalize_dict(d: Any) -> Any:
    """Recursively normalize a dictionary for comparison.

    - Sorts dict keys
    - Recursively normalizes nested dicts and lists
    - Handles None values consistently

    Args:
        d: Value to normalize (dict, list, or primitive)

    Returns:
        Normalized value suitable for comparison
    """
    if d is None:
        return None
    elif isinstance(d, dict):
        # Sort keys and recursively normalize values
        return {k: normalize_dict(v) for k, v in sorted(d.items())}
    elif isinstance(d, list):
        # Recursively normalize list items (preserve order)
        return [normalize_dict(item) for item in d]
    else:
        return d


def generate_semantic_diff(
    expected: Any, actual: Any, path: str = ""
) -> list[str]:
    """Generate a human-readable diff between two values.

    Args:
        expected: Expected value (from existing manifest)
        actual: Actual value (from generated)
        path: Current path in the structure

    Returns:
        List of diff lines
    """
    diffs = []

    if not isinstance(expected, type(actual)) and not isinstance(actual, type(expected)):
        diffs.append(f"  {path}: type mismatch - expected {type(expected).__name__}, got {type(actual).__name__}")
        return diffs

    if isinstance(expected, dict):
        all_keys = set(expected.keys()) | set(actual.keys())
        for key in sorted(all_keys):
            new_path = f"{path}.{key}" if path else key
            if key not in expected:
                diffs.append(f"  + {new_path}: {actual[key]!r}")
            elif key not in actual:
                diffs.append(f"  - {new_path}: {expected[key]!r}")
            elif expected[key] != actual[key]:
                sub_diffs = generate_semantic_diff(expected[key], actual[key], new_path)
                diffs.extend(sub_diffs)
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            diffs.append(
                f"  {path}: list length mismatch - expected {len(expected)}, got {len(actual)}"
            )
        else:
            for i, (exp_item, act_item) in enumerate(zip(expected, actual)):
                if exp_item != act_item:
                    sub_diffs = generate_semantic_diff(exp_item, act_item, f"{path}[{i}]")
                    diffs.extend(sub_diffs)
    else:
        if expected != actual:
            diffs.append(f"  {path}: expected {expected!r}, got {actual!r}")

    return diffs


def build_command(args: argparse.Namespace) -> int:
    """Execute the build command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=build error, 2=invalid arguments)
    """
    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Validate arguments
    if args.split and not args.output:
        print("Error: --split requires -o/--output flag", file=sys.stderr)
        return 2

    if args.format not in ("yaml", "json"):
        print(f"Error: Invalid format '{args.format}'", file=sys.stderr)
        return 2

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Package path does not exist: {package_path}", file=sys.stderr)
        return 1

    try:
        # DISCOVER stage
        resources = discover_resources(package_path)

        # VALIDATE stage
        if resources:
            validate_references(resources)

            # DETECT CYCLES stage
            detect_cycles(resources)

            # ORDER stage
            sorted_resources = topological_sort(resources)

            # EXTRACT stage
            values = extract_values(sorted_resources)

            # SERIALIZE stage
            serialized = serialize_resources(values)
        else:
            # No resources found
            serialized = []

        # FORMAT stage - convert to requested format
        if args.split:
            # Split mode - write one file per resource
            output_path = Path(args.output)
            output_path.mkdir(parents=True, exist_ok=True)

            for i, resource in enumerate(serialized):
                # Try to get resource name for filename
                resource_name = None
                if "metadata" in resource and isinstance(resource["metadata"], dict):
                    resource_name = resource["metadata"].get("name")

                if not resource_name:
                    resource_name = f"resource-{i}"

                # Generate filename
                if args.format == "yaml":
                    filename = f"{resource_name}.yaml"
                    content = to_yaml(resource)
                else:
                    filename = f"{resource_name}.json"
                    content = to_json(resource)

                file_path = output_path / filename
                file_path.write_text(content)

        elif args.output:
            # Output to file or directory
            output_path = Path(args.output)

            # Check if output is a directory
            if output_path.is_dir():
                # Write to manifest file in directory
                if args.format == "yaml":
                    output_file = output_path / "manifest.yaml"
                    content = to_multi_yaml(serialized) if serialized else ""
                else:
                    output_file = output_path / "manifest.json"
                    content = json.dumps(serialized, indent=2)

                output_file.write_text(content)
            else:
                # Write to specific file
                if args.format == "yaml":
                    content = to_multi_yaml(serialized) if serialized else ""
                else:
                    content = json.dumps(serialized, indent=2)

                # Ensure parent directory exists
                output_path.parent.mkdir(parents=True, exist_ok=True)
                output_path.write_text(content)

        else:
            # Output to stdout
            if args.format == "yaml":
                content = to_multi_yaml(serialized) if serialized else ""
            else:
                content = json.dumps(serialized, indent=2)

            print(content)

        return 0

    except (FileNotFoundError, MissingReferenceError, CircularDependencyError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def import_command(args: argparse.Namespace) -> int:
    """Execute the import command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    # Check if file exists
    file_path = Path(args.file)
    if not file_path.exists():
        print(f"Error: File not found: {file_path}", file=sys.stderr)
        return 1

    try:
        # Import YAML and generate Python code
        code = import_yaml_file(str(file_path))

        # Output to file or stdout
        if args.output:
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(code)
        else:
            print(code)

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def lint_command(args: argparse.Namespace) -> int:
    """Execute the lint command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=no issues, 1=issues found, 2=error)
    """
    from wetwire_k8s.linter.engine import LintEngine

    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Path does not exist: {package_path}", file=sys.stderr)
        return 2

    try:
        # Discover resources
        resources = discover_resources(package_path)

        # Collect all Python files
        if package_path.is_file():
            files = [package_path]
        else:
            files = list(package_path.rglob("*.py"))

        # Run linter
        engine = LintEngine()
        issues = engine.lint(resources, files)

        if not issues:
            print("No linting issues found.")
            return 0

        # If --fix flag is provided, attempt to fix issues
        if args.fix:
            fixed_files = set()
            fix_count = 0

            # Keep fixing until no more fixable issues remain
            max_iterations = 10  # Prevent infinite loops
            iteration = 0

            while issues and iteration < max_iterations:
                iteration += 1
                fixes_applied = False

                # Group issues by file
                issues_by_file = {}
                for issue in issues:
                    if issue.file not in issues_by_file:
                        issues_by_file[issue.file] = []
                    issues_by_file[issue.file].append(issue)

                # Process each file
                for file_path, file_issues in issues_by_file.items():
                    file_path_obj = Path(file_path)
                    if not file_path_obj.exists():
                        continue

                    file_content = file_path_obj.read_text()
                    modified_content = file_content

                    # Try to fix each issue for this file (one at a time)
                    for issue in file_issues:
                        # Find the rule that generated this issue
                        rule = None
                        for r in engine.rules:
                            if r.rule_id == issue.rule:
                                rule = r
                                break

                        if rule and rule.can_fix:
                            fixed_content = rule.fix(issue, modified_content)
                            if fixed_content and fixed_content != modified_content:
                                modified_content = fixed_content
                                fix_count += 1
                                fixed_files.add(file_path)
                                fixes_applied = True
                                # Only fix one issue at a time to avoid line number conflicts
                                break

                    # Write back fixed content if changes were made
                    if modified_content != file_content:
                        file_path_obj.write_text(modified_content)

                # Re-run linter to find remaining issues
                issues = engine.lint(resources, files)

                # Break if no fixes were applied in this iteration
                if not fixes_applied:
                    break

            print(f"Fixed {fix_count} issue(s) in {len(fixed_files)} file(s).")

        # Report remaining issues
        if issues:
            print(f"\nFound {len(issues)} linting issue(s):\n")

            current_file = None
            for issue in issues:
                if issue.file != current_file:
                    current_file = issue.file
                    print(f"\n{current_file}:")

                severity_color = ""
                if issue.severity == "error":
                    severity_color = RED
                elif issue.severity == "warning":
                    severity_color = "\033[93m"  # Yellow

                print(
                    f"  Line {issue.line}: {severity_color}{issue.severity.upper()}{RESET} [{issue.rule}] {issue.message}"
                )

            return 1

        return 0

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def graph_command(args: argparse.Namespace) -> int:
    """Execute the graph command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Path does not exist: {package_path}", file=sys.stderr)
        return 1

    try:
        # Discover resources
        resources = discover_resources(package_path)

        # Build resource name set for filtering dependencies
        resource_names = {r.name for r in resources}

        # Generate graph output
        if args.format == "mermaid":
            output = generate_mermaid(resources, resource_names)
        else:
            # Default to DOT format
            output = generate_dot(resources, resource_names)

        # Output to file or stdout
        if args.output:
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(output)
        else:
            print(output)

        return 0

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def generate_dot(
    resources: list, resource_names: set[str]
) -> str:
    """Generate DOT format graph.

    Args:
        resources: List of discovered resources
        resource_names: Set of resource names for filtering

    Returns:
        DOT format string
    """
    lines = ["digraph resources {"]

    # Add nodes with labels
    for r in resources:
        lines.append(f'    "{r.name}" [label="{r.name}\\n({r.type})"];')

    # Add edges for dependencies
    for r in resources:
        for dep in r.dependencies:
            if dep in resource_names:
                lines.append(f'    "{r.name}" -> "{dep}";')

    lines.append("}")
    return "\n".join(lines)


def generate_mermaid(
    resources: list, resource_names: set[str]
) -> str:
    """Generate Mermaid format graph.

    Args:
        resources: List of discovered resources
        resource_names: Set of resource names for filtering

    Returns:
        Mermaid format string
    """
    lines = ["graph TD"]

    # Add nodes with labels
    for r in resources:
        lines.append(f'    {r.name}["{r.name}<br/>({r.type})"]')

    # Add edges for dependencies
    for r in resources:
        for dep in r.dependencies:
            if dep in resource_names:
                lines.append(f"    {r.name} --> {dep}")

    return "\n".join(lines)


def init_command(args: argparse.Namespace) -> int:
    """Execute the init command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    # Get directory (default to current directory)
    directory = Path(args.directory) if args.directory else Path.cwd()

    # Create directory if it doesn't exist
    directory.mkdir(parents=True, exist_ok=True)

    try:
        # Create pyproject.toml
        pyproject_path = directory / "pyproject.toml"
        if pyproject_path.exists():
            print(f"Skipping {pyproject_path} (already exists)")
        else:
            pyproject_content = '''[project]
name = "my-k8s-resources"
version = "0.1.0"
description = "Kubernetes resources defined in Python"
requires-python = ">=3.10"
dependencies = [
    "wetwire-k8s",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
'''
            pyproject_path.write_text(pyproject_content)
            print(f"Created {pyproject_path}")

        # Create resources.py
        resources_path = directory / "resources.py"
        if resources_path.exists():
            print(f"Skipping {resources_path} (already exists)")
        else:
            resources_content = '''"""Example Kubernetes resources defined in Python.

Run `wetwire-k8s build` to generate Kubernetes YAML manifests.
Run `wetwire-k8s list` to see discovered resources.
"""

from wetwire_k8s.resources.core.v1 import ConfigMap

# Example ConfigMap resource
app_config: ConfigMap = ConfigMap(
    apiVersion="v1",
    kind="ConfigMap",
    metadata={
        "name": "app-config",
        "labels": {
            "app": "my-app",
        },
    },
    data={
        "APP_ENV": "development",
        "LOG_LEVEL": "info",
    },
)
'''
            resources_path.write_text(resources_content)
            print(f"Created {resources_path}")

        # Create .gitignore
        gitignore_path = directory / ".gitignore"
        if gitignore_path.exists():
            print(f"Skipping {gitignore_path} (already exists)")
        else:
            gitignore_content = '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual environments
.venv/
venv/
ENV/

# IDE
.idea/
.vscode/
*.swp
*.swo

# wetwire-k8s output
output/
*.generated.yaml
'''
            gitignore_path.write_text(gitignore_content)
            print(f"Created {gitignore_path}")

        print(f"\nInitialized wetwire-k8s project in {directory}")
        print("\nNext steps:")
        print("  1. Edit resources.py to define your Kubernetes resources")
        print("  2. Run `wetwire-k8s list` to see discovered resources")
        print("  3. Run `wetwire-k8s build` to generate YAML manifests")

        return 0

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def list_command(args: argparse.Namespace) -> int:
    """Execute the list command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Path does not exist: {package_path}", file=sys.stderr)
        return 1

    try:
        # Discover resources
        resources = discover_resources(package_path)

        if args.format == "json":
            # JSON output format
            output_data = [
                {
                    "name": r.name,
                    "kind": r.type,
                    "file": r.file,
                    "line": r.line,
                }
                for r in resources
            ]
            print(json.dumps(output_data, indent=2))
        else:
            # Table output format
            print(f"{'NAME':<30} {'KIND':<20} {'FILE':<40} {'LINE':<6}")
            print("-" * 96)
            for r in resources:
                # Truncate file path if too long
                file_display = r.file if len(r.file) <= 40 else "..." + r.file[-37:]
                print(f"{r.name:<30} {r.type:<20} {file_display:<40} {r.line:<6}")

        return 0

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def validate_command(args: argparse.Namespace) -> int:
    """Execute the validate command.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=valid, 1=invalid, 2=error)
    """
    file_path = args.file if args.file else None
    kubernetes_version = args.kubernetes_version if hasattr(args, "kubernetes_version") else None

    # Check if file exists (if provided)
    if file_path:
        if not Path(file_path).exists():
            print(f"Error: File not found: {file_path}", file=sys.stderr)
            return 2

    try:
        # Read from stdin if no file provided
        if file_path:
            is_valid, results = validate_yaml(
                file_path=file_path,
                kubernetes_version=kubernetes_version,
            )
        else:
            stdin_content = sys.stdin.read()
            is_valid, results = validate_yaml(
                stdin_content=stdin_content,
                kubernetes_version=kubernetes_version,
            )

        # Report results
        if is_valid:
            valid_count = len([r for r in results if r.is_valid])
            print(f"Validation OK: {valid_count} resource(s) valid")
            return 0
        else:
            # Print errors for invalid resources
            for result in results:
                if not result.is_valid:
                    resource_id = f"{result.kind}/{result.name}" if result.name else result.kind
                    print(
                        f"Error: {result.filename}: {resource_id}: {result.message}",
                        file=sys.stderr,
                    )

            invalid_count = len([r for r in results if not r.is_valid])
            print(f"Validation failed: {invalid_count} error(s) found", file=sys.stderr)
            return 1

    except KubeconformNotInstalledError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2


def diff_command(args: argparse.Namespace) -> int:
    """Execute the diff command.

    Compare generated manifests against an existing manifest file.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=no differences, 1=differences found, 2=error)
    """
    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Package path does not exist: {package_path}", file=sys.stderr)
        return 1

    # Check if against file exists
    against_path = Path(args.against)
    if not against_path.exists():
        print(f"Error: File not found: {against_path}", file=sys.stderr)
        return 2

    # Determine color mode
    use_color = args.color if hasattr(args, "color") and args.color else False
    if hasattr(args, "no_color") and args.no_color:
        use_color = False

    try:
        # Build from package-path (reuse build logic)
        resources = discover_resources(package_path)

        if resources:
            validate_references(resources)
            detect_cycles(resources)
            sorted_resources = topological_sort(resources)
            values = extract_values(sorted_resources)
            serialized = serialize_resources(values)
        else:
            serialized = []

        # Generate YAML from serialized resources
        generated_yaml = to_multi_yaml(serialized) if serialized else ""

        # Read existing manifest
        existing_yaml = against_path.read_text()

        # Compare based on mode
        if args.semantic:
            # Semantic diff mode - parse YAML and compare normalized
            generated_docs = list(yaml.safe_load_all(generated_yaml))
            generated_docs = [d for d in generated_docs if d is not None]

            existing_docs = list(yaml.safe_load_all(existing_yaml))
            existing_docs = [d for d in existing_docs if d is not None]

            # Normalize both
            generated_normalized = [normalize_dict(d) for d in generated_docs]
            existing_normalized = [normalize_dict(d) for d in existing_docs]

            # Check if semantically equal
            if generated_normalized == existing_normalized:
                print("No semantic differences found.")
                return 0

            # Generate semantic diff output
            print("Semantic differences found:")

            # Check document count
            if len(generated_docs) != len(existing_docs):
                print(f"  Document count: expected {len(existing_docs)}, got {len(generated_docs)}")

            # Compare each document
            for i in range(min(len(existing_docs), len(generated_docs))):
                diff_lines = generate_semantic_diff(
                    existing_normalized[i], generated_normalized[i], f"doc[{i}]"
                )
                for line in diff_lines:
                    print(line)

            return 1
        else:
            # Text diff mode - line-by-line comparison
            generated_lines = generated_yaml.splitlines(keepends=True)
            existing_lines = existing_yaml.splitlines(keepends=True)

            diff = list(difflib.unified_diff(
                existing_lines,
                generated_lines,
                fromfile=str(against_path),
                tofile="generated",
                lineterm=""
            ))

            if not diff:
                # No differences
                return 0

            # Output diff
            for line in diff:
                if use_color:
                    if line.startswith("+") and not line.startswith("+++"):
                        print(f"{GREEN}{line}{RESET}", end="")
                    elif line.startswith("-") and not line.startswith("---"):
                        print(f"{RED}{line}{RESET}", end="")
                    elif line.startswith("@@"):
                        print(f"{CYAN}{line}{RESET}", end="")
                    else:
                        print(line, end="")
                else:
                    print(line, end="")

            # Ensure newline at end
            if diff and not diff[-1].endswith("\n"):
                print()

            return 1

    except (FileNotFoundError, MissingReferenceError, CircularDependencyError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def watch_loop(
    package_path: Path,
    output_path: Path | None,
    debounce_ms: int,
    build_func: Callable[[], None],
) -> None:
    """File watching loop with polling fallback.

    Monitors source files for changes and triggers rebuilds.

    Args:
        package_path: Path to watch for changes
        output_path: Output path for builds
        debounce_ms: Debounce interval in milliseconds
        build_func: Function to call for building
    """
    # Try to use watchdog if available
    try:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        class RebuildHandler(FileSystemEventHandler):
            def __init__(self) -> None:
                self.last_build = 0.0
                self.debounce_seconds = debounce_ms / 1000.0

            def on_modified(self, event) -> None:
                if event.is_directory:
                    return
                if not event.src_path.endswith(".py"):
                    return

                now = time.time()
                if now - self.last_build < self.debounce_seconds:
                    return

                self.last_build = now
                print(f"\nFile changed: {event.src_path}")
                try:
                    build_func()
                    print("Build successful.")
                except Exception as e:
                    print(f"Build error: {e}", file=sys.stderr)

        handler = RebuildHandler()
        observer = Observer()
        observer.schedule(handler, str(package_path), recursive=True)
        observer.start()

        print(f"Watching {package_path} for changes... (Ctrl+C to stop)")
        # Initial build
        try:
            build_func()
            print("Initial build successful.")
        except Exception as e:
            print(f"Initial build error: {e}", file=sys.stderr)

        try:
            while True:
                time.sleep(0.1)
        except KeyboardInterrupt:
            observer.stop()
        observer.join()

    except ImportError:
        # Fallback to polling
        print("watchdog not installed, using polling fallback...")
        print(f"Watching {package_path} for changes... (Ctrl+C to stop)")

        # Track file modification times
        mtimes: dict[str, float] = {}
        debounce_seconds = debounce_ms / 1000.0
        last_build = 0.0

        def get_py_files() -> list[Path]:
            """Get all Python files in the package path."""
            if package_path.is_file():
                return [package_path] if package_path.suffix == ".py" else []
            return list(package_path.rglob("*.py"))

        # Initial scan and build
        for py_file in get_py_files():
            mtimes[str(py_file)] = py_file.stat().st_mtime

        try:
            build_func()
            print("Initial build successful.")
            last_build = time.time()
        except Exception as e:
            print(f"Initial build error: {e}", file=sys.stderr)

        try:
            while True:
                time.sleep(0.1)
                now = time.time()

                # Check for changes
                changed = False
                for py_file in get_py_files():
                    path_str = str(py_file)
                    try:
                        current_mtime = py_file.stat().st_mtime
                    except FileNotFoundError:
                        continue

                    if path_str not in mtimes:
                        mtimes[path_str] = current_mtime
                        changed = True
                    elif mtimes[path_str] != current_mtime:
                        mtimes[path_str] = current_mtime
                        changed = True

                # Debounce and rebuild if changed
                if changed and (now - last_build) >= debounce_seconds:
                    print("\nFile changed, rebuilding...")
                    try:
                        build_func()
                        print("Build successful.")
                    except Exception as e:
                        print(f"Build error: {e}", file=sys.stderr)
                    last_build = now

        except KeyboardInterrupt:
            pass

    print("\nWatch stopped.")


def design_command(args: argparse.Namespace) -> int:
    """Execute the design command.

    Use AI to generate Kubernetes infrastructure from a prompt.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error, 2=missing dependencies)
    """
    from wetwire_k8s.agent import run_design_agent

    # Get output directory (default to current directory)
    output_dir = args.output_dir if args.output_dir else str(Path.cwd())

    # Get provider (default to anthropic)
    provider = args.provider if hasattr(args, 'provider') else "anthropic"

    print(f"Generating infrastructure for: {args.prompt}")
    print(f"Output directory: {output_dir}")
    print()

    result = run_design_agent(args.prompt, output_dir, provider=provider)

    if "error" in result:
        print(f"Error: {result['error']}", file=sys.stderr)
        return 2

    print(f"\nInfrastructure generated successfully in: {result['output_dir']}")
    return 0


def test_command(args: argparse.Namespace) -> int:
    """Execute the test command.

    Run automated persona-based testing to evaluate AI agent performance.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    from wetwire_k8s.test_runner import run_all_personas, run_test, write_results

    # Get output directory (default to test-results)
    output_dir = Path(args.output_dir) if args.output_dir else Path.cwd() / "test-results"
    output_dir.mkdir(parents=True, exist_ok=True)

    # Get provider (default to anthropic)
    provider = args.provider if hasattr(args, 'provider') else "anthropic"

    print(f"Running test for scenario: {args.scenario}")
    print(f"Output directory: {output_dir}")
    print()

    if args.all_personas:
        print("Testing with all personas...")
        results = run_all_personas(args.scenario, output_dir, provider=provider)
    else:
        persona = args.persona if args.persona else "intermediate"
        print(f"Testing with persona: {persona}")
        result = run_test(args.scenario, persona, output_dir, provider=provider)
        results = [result]

    write_results(results, output_dir)

    # Print summary
    print("\n" + "=" * 50)
    print("Results Summary")
    print("=" * 50)
    for r in results:
        score = r["score"]
        print(f"{r['persona']}: {score.total}/15")

    print(f"\nResults written to: {output_dir}")
    return 0


def watch_command(args: argparse.Namespace) -> int:
    """Execute the watch command.

    Monitor source files and rebuild on changes.

    Args:
        args: Parsed command line arguments

    Returns:
        Exit code (0=success, 1=error)
    """
    # Get package path (default to current directory)
    package_path = Path(args.package_path) if args.package_path else Path.cwd()

    # Check if package path exists
    if not package_path.exists():
        print(f"Error: Package path does not exist: {package_path}", file=sys.stderr)
        return 1

    # Get output path
    output_path = Path(args.output) if args.output else None

    # Get debounce (default 300ms)
    debounce_ms = 300

    def do_build() -> None:
        """Perform a build."""
        # Discover resources
        resources = discover_resources(package_path)

        if resources:
            validate_references(resources)
            detect_cycles(resources)
            sorted_resources = topological_sort(resources)
            values = extract_values(sorted_resources)
            serialized = serialize_resources(values)
        else:
            serialized = []

        # Output
        content = to_multi_yaml(serialized) if serialized else ""

        if output_path:
            # Ensure output directory exists
            if output_path.is_dir() or not output_path.suffix:
                output_path.mkdir(parents=True, exist_ok=True)
                manifest_file = output_path / "manifest.yaml"
            else:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                manifest_file = output_path

            manifest_file.write_text(content)
        else:
            # Just validate build works, don't print to stdout during watch
            pass

    try:
        watch_loop(package_path, output_path, debounce_ms, do_build)
        return 0
    except KeyboardInterrupt:
        print("\nWatch stopped.")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog="wetwire-k8s",
        description="Kubernetes manifest synthesis for wetwire",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Build command
    build_parser = subparsers.add_parser(
        "build",
        help="Build Kubernetes manifests from Python resources",
    )
    build_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    build_parser.add_argument(
        "-o",
        "--output",
        help="Output file or directory",
    )
    build_parser.add_argument(
        "--format",
        choices=["yaml", "json"],
        default="yaml",
        help="Output format (default: yaml)",
    )
    build_parser.add_argument(
        "--split",
        action="store_true",
        help="Split into separate files per resource (requires -o)",
    )

    # Lint command
    lint_parser = subparsers.add_parser(
        "lint",
        help="Lint Kubernetes definitions for best practices",
    )
    lint_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    lint_parser.add_argument(
        "--fix",
        action="store_true",
        help="Auto-fix issues where possible",
    )

    # Import command
    import_parser = subparsers.add_parser(
        "import",
        help="Import Kubernetes YAML and generate Python code",
    )
    import_parser.add_argument(
        "file",
        help="Path to YAML file to import",
    )
    import_parser.add_argument(
        "-o",
        "--output",
        help="Output file (default: stdout)",
    )

    # Validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate Kubernetes YAML against schemas",
    )
    validate_parser.add_argument(
        "file",
        nargs="?",
        default=None,
        help="Path to YAML file to validate (default: stdin)",
    )
    validate_parser.add_argument(
        "--kubernetes-version",
        help="Kubernetes version to validate against (e.g., 1.29)",
    )

    # List command
    list_parser = subparsers.add_parser(
        "list",
        help="List discovered Kubernetes resources",
    )
    list_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    list_parser.add_argument(
        "--format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # Init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize a new wetwire-k8s project",
    )
    init_parser.add_argument(
        "directory",
        nargs="?",
        default=None,
        help="Directory to initialize (default: current directory)",
    )

    # Graph command
    graph_parser = subparsers.add_parser(
        "graph",
        help="Generate dependency graph of resources",
    )
    graph_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    graph_parser.add_argument(
        "--format",
        choices=["dot", "mermaid"],
        default="dot",
        help="Output format (default: dot)",
    )
    graph_parser.add_argument(
        "-o",
        "--output",
        help="Output file (default: stdout)",
    )

    # Diff command
    diff_parser = subparsers.add_parser(
        "diff",
        help="Compare generated manifests against existing manifest",
    )
    diff_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    diff_parser.add_argument(
        "--against",
        required=True,
        help="Existing manifest file to compare against",
    )
    diff_parser.add_argument(
        "--semantic",
        action="store_true",
        help="Use semantic diff (ignore formatting, key order)",
    )
    diff_parser.add_argument(
        "--color",
        action="store_true",
        help="Colorize output",
    )
    diff_parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colorized output",
    )

    # Watch command
    watch_parser = subparsers.add_parser(
        "watch",
        help="Watch source files and rebuild on changes",
    )
    watch_parser.add_argument(
        "package_path",
        nargs="?",
        default=None,
        help="Path to package or file containing resources (default: current directory)",
    )
    watch_parser.add_argument(
        "-o",
        "--output",
        help="Output directory for generated manifests",
    )

    # Design command
    design_parser = subparsers.add_parser(
        "design",
        help="Generate Kubernetes infrastructure from a prompt using AI",
    )
    design_parser.add_argument(
        "prompt",
        help="Description of the infrastructure to generate",
    )
    design_parser.add_argument(
        "--output-dir",
        help="Output directory for generated files (default: current directory)",
    )
    design_parser.add_argument(
        "--provider",
        default="anthropic",
        help="AI provider to use (default: anthropic)",
    )

    # Test command
    test_parser = subparsers.add_parser(
        "test",
        help="Run automated persona-based testing to evaluate AI agent performance",
    )
    test_parser.add_argument(
        "scenario",
        help="Test scenario description (e.g., 'web app', 'database setup')",
    )
    test_parser.add_argument(
        "--persona",
        help="Persona to use for testing (default: intermediate)",
    )
    test_parser.add_argument(
        "--all-personas",
        action="store_true",
        help="Run test with all personas",
    )
    test_parser.add_argument(
        "--output-dir",
        help="Output directory for results (default: test-results)",
    )
    test_parser.add_argument(
        "--provider",
        default="anthropic",
        help="AI provider to use (default: anthropic)",
    )

    # Parse arguments
    args = parser.parse_args()

    # Execute command
    if args.command == "build":
        return build_command(args)
    elif args.command == "lint":
        return lint_command(args)
    elif args.command == "import":
        return import_command(args)
    elif args.command == "validate":
        return validate_command(args)
    elif args.command == "list":
        return list_command(args)
    elif args.command == "init":
        return init_command(args)
    elif args.command == "graph":
        return graph_command(args)
    elif args.command == "diff":
        return diff_command(args)
    elif args.command == "watch":
        return watch_command(args)
    elif args.command == "design":
        return design_command(args)
    elif args.command == "test":
        return test_command(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
