"""Serialization of Kubernetes resources to YAML/JSON.

This module implements resource serialization per Wetwire Spec Section 8.3.
Dataclasses are converted to dictionaries, YAML, or JSON format following
Kubernetes conventions.
"""

import json
from dataclasses import is_dataclass
from typing import Any

import yaml


def to_dict(resource: Any) -> Any:
    """Convert a dataclass resource to a dictionary.

    This function recursively converts dataclasses to dictionaries, following
    Kubernetes conventions:
    - None values are omitted
    - Empty collections (lists, dicts) are preserved
    - Nested dataclasses are recursively converted
    - Field names are preserved as-is (already in camelCase from codegen)

    Args:
        resource: The dataclass instance to convert

    Returns:
        Dictionary representation of the resource, or None if input is None

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class Service:
        ...     apiVersion: str
        ...     kind: str
        >>> svc = Service(apiVersion="v1", kind="Service")
        >>> to_dict(svc)
        {'apiVersion': 'v1', 'kind': 'Service'}
    """
    if resource is None:
        return None

    if not is_dataclass(resource):
        # Not a dataclass - return as-is or raise error
        # For primitive types, collections, etc., just return them
        if isinstance(resource, (str, int, float, bool)):
            return resource
        if isinstance(resource, dict):
            # Recursively process dict values
            return {k: to_dict(v) for k, v in resource.items()}
        if isinstance(resource, (list, tuple)):
            # Recursively process list items
            return [to_dict(item) for item in resource]
        # For other types, try to return as-is or raise
        raise TypeError(f"Expected dataclass, got {type(resource).__name__}")

    result = {}

    # Import dataclasses module to access fields
    from dataclasses import fields

    for field in fields(resource):
        value = getattr(resource, field.name)

        # Skip None values (Kubernetes convention)
        if value is None:
            continue

        # Recursively convert nested dataclasses
        if is_dataclass(value):
            result[field.name] = to_dict(value)
        elif isinstance(value, list):
            # Handle lists (may contain dataclasses)
            result[field.name] = [
                to_dict(item) if is_dataclass(item) else item
                for item in value
            ]
        elif isinstance(value, dict):
            # Handle dicts (may contain dataclasses as values)
            result[field.name] = {
                k: to_dict(v) if is_dataclass(v) else v
                for k, v in value.items()
            }
        else:
            # Primitive value - include as-is
            result[field.name] = value

    return result


def to_yaml(resource: Any) -> str:
    """Convert a dataclass resource to YAML string.

    The resource is first converted to a dictionary using to_dict(), then
    serialized to YAML format. The output follows standard YAML conventions
    and is human-readable.

    Args:
        resource: The dataclass instance to convert

    Returns:
        YAML string representation of the resource

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class Service:
        ...     apiVersion: str
        ...     kind: str
        >>> svc = Service(apiVersion="v1", kind="Service")
        >>> print(to_yaml(svc))
        apiVersion: v1
        kind: Service
    """
    if resource is None:
        return yaml.dump(None, default_flow_style=False)

    resource_dict = to_dict(resource)

    # Use safe_dump with default settings for clean YAML output
    return yaml.dump(
        resource_dict,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
    )


def to_json(resource: Any) -> str:
    """Convert a dataclass resource to JSON string.

    The resource is first converted to a dictionary using to_dict(), then
    serialized to JSON format with indentation for readability.

    Args:
        resource: The dataclass instance to convert

    Returns:
        JSON string representation of the resource with 2-space indentation

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class Service:
        ...     apiVersion: str
        ...     kind: str
        >>> svc = Service(apiVersion="v1", kind="Service")
        >>> print(to_json(svc))
        {
          "apiVersion": "v1",
          "kind": "Service"
        }
    """
    if resource is None:
        return json.dumps(None)

    resource_dict = to_dict(resource)

    # Use indent=2 for pretty-printed JSON
    return json.dumps(resource_dict, indent=2, ensure_ascii=False)


def to_multi_yaml(resources: list[Any]) -> str:
    """Convert multiple dataclass resources to multi-document YAML.

    Multiple resources are serialized as a YAML stream with document
    separators (---). This is the standard format for kubectl and other
    Kubernetes tools when applying multiple resources at once.

    Args:
        resources: List of dataclass instances to convert

    Returns:
        Multi-document YAML string with resources separated by ---

    Examples:
        >>> from dataclasses import dataclass
        >>> @dataclass
        ... class Service:
        ...     apiVersion: str
        ...     kind: str
        ...     name: str
        >>> svc1 = Service(apiVersion="v1", kind="Service", name="svc1")
        >>> svc2 = Service(apiVersion="v1", kind="Service", name="svc2")
        >>> print(to_multi_yaml([svc1, svc2]))
        ---
        apiVersion: v1
        kind: Service
        name: svc1
        ---
        apiVersion: v1
        kind: Service
        name: svc2
    """
    if not resources:
        return ""

    # Convert each resource to dict
    resource_dicts = [to_dict(resource) for resource in resources]

    # Use yaml.dump_all to create multi-document YAML
    return yaml.dump_all(
        resource_dicts,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        explicit_start=True,  # Add --- before each document
    )


__all__ = ["to_dict", "to_yaml", "to_json", "to_multi_yaml"]
