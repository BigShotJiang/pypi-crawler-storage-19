"""YAML to Python code converter for Kubernetes resources."""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass
class ImportConfig:
    """Configuration for import generation."""

    include_type_annotation: bool = True
    variable_name: str | None = None
    indent: int = 4


def convert_to_snake_case(name: str) -> str:
    """Convert a name to snake_case.

    Args:
        name: Name to convert (may contain hyphens, dots, or be CamelCase)

    Returns:
        snake_case version of the name
    """
    # Insert underscore before uppercase letters (CamelCase to snake_case)
    name = re.sub(r"(?<!^)(?=[A-Z])", "_", name)

    # Replace hyphens and dots with underscores
    name = name.replace("-", "_").replace(".", "_")

    # Convert to lowercase
    name = name.lower()

    # Remove consecutive underscores
    name = re.sub(r"_+", "_", name)

    return name


def api_version_to_module_path(api_version: str) -> str:
    """Convert API version to module import path.

    Args:
        api_version: Kubernetes API version (e.g., "v1", "apps/v1", "networking.k8s.io/v1")

    Returns:
        Module path (e.g., "core.v1", "apps.v1", "networking.v1")
    """
    # Handle core resources (no group)
    if "/" not in api_version:
        return f"core.{api_version}"

    # Handle grouped resources
    parts = api_version.split("/")
    if len(parts) == 2:
        group, version = parts

        # Remove .k8s.io suffix from group name
        if ".k8s.io" in group:
            group = group.replace(".k8s.io", "")

        # Handle special cases for RBAC
        if group == "rbac.authorization":
            group = "rbac"

        return f"{group}.{version}"

    # Fallback
    return api_version.replace("/", ".").replace(".k8s.io", "")


def format_python_value(value: Any, indent: int = 0) -> str:
    """Format a Python value as code string.

    Args:
        value: Value to format
        indent: Current indentation level

    Returns:
        Python code string representation
    """
    if value is None:
        return "None"
    elif isinstance(value, bool):
        return str(value)
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        # Check if string contains special characters that need escaping
        # Use repr() for strings with newlines, carriage returns, or backslashes
        if "\n" in value or "\r" in value or "\\" in value:
            return repr(value)
        # Use double quotes by default, single quotes if string contains double quotes
        if '"' in value and "'" not in value:
            return f"'{value}'"
        return f'"{value}"'
    elif isinstance(value, list):
        if not value:
            return "[]"
        # Format list items
        items = [format_python_value(item, indent) for item in value]
        return "[" + ", ".join(items) + "]"
    elif isinstance(value, dict):
        if not value:
            return "{}"
        # For simple dicts, use inline format
        # For complex dicts, use multiline format
        items = []
        for key, val in value.items():
            formatted_key = format_python_value(key, indent)
            formatted_val = format_python_value(val, indent + 4)
            items.append(f"{formatted_key}: {formatted_val}")

        # If indent > 0, format multiline
        if indent > 0:
            indent_str = " " * indent
            items_str = (",\n" + indent_str + "    ").join(items)
            return "{\n" + indent_str + "    " + items_str + "\n" + indent_str + "}"
        else:
            return "{" + ", ".join(items) + "}"
    else:
        return repr(value)


def generate_import_statement(api_version: str, kind: str) -> str:
    """Generate import statement for a resource.

    Args:
        api_version: Kubernetes API version
        kind: Resource kind

    Returns:
        Python import statement
    """
    module_path = api_version_to_module_path(api_version)
    return f"from wetwire_k8s.resources.{module_path} import {kind}"


def generate_python_code(
    resource: dict[str, Any], config: ImportConfig | None = None
) -> str:
    """Generate Python code for a Kubernetes resource.

    Args:
        resource: Kubernetes resource dictionary
        config: Optional configuration for code generation

    Returns:
        Generated Python code
    """
    if config is None:
        config = ImportConfig()

    # Extract resource information
    api_version = resource.get("apiVersion", "")
    kind = resource.get("kind", "")
    metadata = resource.get("metadata", {})
    resource_name = metadata.get("name", "resource")

    # Generate import statement
    import_stmt = generate_import_statement(api_version, kind)

    # Determine variable name
    if config.variable_name:
        var_name = config.variable_name
    else:
        var_name = convert_to_snake_case(resource_name)

    # Generate variable declaration
    if config.include_type_annotation:
        var_declaration = f"{var_name}: {kind} = {kind}("
    else:
        var_declaration = f"{var_name} = {kind}("

    # Generate field assignments
    fields = []
    indent_str = " " * config.indent

    for key, value in resource.items():
        formatted_value = format_python_value(value, config.indent)
        fields.append(f"{indent_str}{key}={formatted_value},")

    # Combine everything
    code_parts = [
        import_stmt,
        "",
        var_declaration,
    ]
    code_parts.extend(fields)
    code_parts.append(")")

    return "\n".join(code_parts)


def parse_yaml_documents(yaml_content: str) -> list[dict[str, Any]]:
    """Parse YAML content into list of documents.

    Args:
        yaml_content: YAML content string

    Returns:
        List of parsed YAML documents (filters out None/empty documents)
    """
    documents = list(yaml.safe_load_all(yaml_content))
    # Filter out None and empty documents
    return [doc for doc in documents if doc is not None]


def import_yaml_file(
    file_path: str, config: ImportConfig | None = None
) -> str:
    """Import a YAML file and generate Python code.

    Args:
        file_path: Path to YAML file
        config: Optional configuration for code generation

    Returns:
        Generated Python code for all resources in the file

    Raises:
        FileNotFoundError: If file does not exist
    """
    if config is None:
        config = ImportConfig()

    # Read file
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    yaml_content = path.read_text()

    # Parse YAML documents
    documents = parse_yaml_documents(yaml_content)

    # Generate code for each document
    code_sections = []
    imports = set()

    for doc in documents:
        if not doc:
            continue

        # Get API version and kind for import
        api_version = doc.get("apiVersion", "")
        kind = doc.get("kind", "")

        if api_version and kind:
            import_stmt = generate_import_statement(api_version, kind)
            imports.add(import_stmt)

        # Generate code for this resource
        # Use default config for each resource (no custom variable name)
        resource_config = ImportConfig(
            include_type_annotation=config.include_type_annotation,
            variable_name=None,  # Let it auto-generate from metadata.name
            indent=config.indent,
        )
        code = generate_python_code(doc, resource_config)

        # Extract just the variable declaration and fields (skip the import)
        code_lines = code.split("\n")
        # Skip the first line (import) and the empty line
        code_without_import = "\n".join(code_lines[2:])
        code_sections.append(code_without_import)

    # Combine imports and code sections
    result_parts = []

    # Add all unique imports
    result_parts.extend(sorted(imports))

    # Add blank line after imports
    if imports:
        result_parts.append("")

    # Add all code sections with blank lines between them
    for i, section in enumerate(code_sections):
        result_parts.append(section)
        if i < len(code_sections) - 1:
            result_parts.append("")

    return "\n".join(result_parts)
