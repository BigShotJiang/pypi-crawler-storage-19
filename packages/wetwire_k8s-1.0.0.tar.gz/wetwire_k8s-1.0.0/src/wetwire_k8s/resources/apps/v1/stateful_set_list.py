'''StatefulSetList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .stateful_set import StatefulSet
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class StatefulSetList:
    """StatefulSetList is a collection of StatefulSets."""
    apiVersion: Optional[str] = None
    items: Optional[list[StatefulSet]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["StatefulSetList"]