'''Deployment resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .deployment_spec import DeploymentSpec
from .deployment_status import DeploymentStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Deployment:
    """Deployment enables declarative updates for Pods and ReplicaSets."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[DeploymentSpec] = None
    status: Optional[DeploymentStatus] = None


__all__ = ["Deployment"]