'''DaemonSetSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .daemon_set_update_strategy import DaemonSetUpdateStrategy
from wetwire_k8s.resources.core.v1.pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class DaemonSetSpec:
    """DaemonSetSpec is the specification of a daemon set."""
    minReadySeconds: Optional[int] = None
    revisionHistoryLimit: Optional[int] = None
    selector: Optional[LabelSelector] = None
    template: Optional[PodTemplateSpec] = None
    updateStrategy: Optional[DaemonSetUpdateStrategy] = None


__all__ = ["DaemonSetSpec"]