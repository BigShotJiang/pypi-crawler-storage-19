'''DaemonSetStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .daemon_set_condition import DaemonSetCondition


@dataclass
class DaemonSetStatus:
    """DaemonSetStatus represents the current status of a daemon set."""
    collisionCount: Optional[int] = None
    conditions: Optional[list[DaemonSetCondition]] = None
    currentNumberScheduled: Optional[int] = None
    desiredNumberScheduled: Optional[int] = None
    numberAvailable: Optional[int] = None
    numberMisscheduled: Optional[int] = None
    numberReady: Optional[int] = None
    numberUnavailable: Optional[int] = None
    observedGeneration: Optional[int] = None
    updatedNumberScheduled: Optional[int] = None


__all__ = ["DaemonSetStatus"]