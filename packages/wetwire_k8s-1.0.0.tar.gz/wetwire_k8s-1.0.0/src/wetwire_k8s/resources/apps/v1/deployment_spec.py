'''DeploymentSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .deployment_strategy import DeploymentStrategy
from wetwire_k8s.resources.core.v1.pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class DeploymentSpec:
    """DeploymentSpec is the specification of the desired behavior of the Deployment."""
    minReadySeconds: Optional[int] = None
    paused: Optional[bool] = None
    progressDeadlineSeconds: Optional[int] = None
    replicas: Optional[int] = None
    revisionHistoryLimit: Optional[int] = None
    selector: Optional[LabelSelector] = None
    strategy: Optional[DeploymentStrategy] = None
    template: Optional[PodTemplateSpec] = None


__all__ = ["DeploymentSpec"]