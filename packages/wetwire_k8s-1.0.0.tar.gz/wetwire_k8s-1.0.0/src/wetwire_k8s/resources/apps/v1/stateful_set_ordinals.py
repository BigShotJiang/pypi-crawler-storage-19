'''StatefulSetOrdinals resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class StatefulSetOrdinals:
    """StatefulSetOrdinals describes the policy used for replica ordinal assignment in this StatefulSet."""
    start: Optional[int] = None


__all__ = ["StatefulSetOrdinals"]