'''ControllerRevision resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta
from wetwire_k8s.resources.meta.v1.raw_extension import RawExtension


@dataclass
class ControllerRevision:
    """ControllerRevision implements an immutable snapshot of state data. Clients are responsible for serializing and deserializing the objects that contain their internal state. Once a ControllerRevision has been successfully created, it can not be updated. The API Server will fail validation of all requests that attempt to mutate the Data field. ControllerRevisions may, however, be deleted. Note that, due to its use by both the DaemonSet and StatefulSet controllers for update and rollback, this object is beta. However, it may be subject to name and representation changes in future releases, and clients should not depend on its stability. It is primarily for internal use by controllers."""
    apiVersion: Optional[str] = None
    data: Optional[RawExtension] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    revision: Optional[int] = None


__all__ = ["ControllerRevision"]