'''DeploymentStrategy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .rolling_update_deployment import RollingUpdateDeployment


@dataclass
class DeploymentStrategy:
    """DeploymentStrategy describes how to replace existing pods with new ones."""
    rollingUpdate: Optional[RollingUpdateDeployment] = None
    type: Optional[str] = None


__all__ = ["DeploymentStrategy"]