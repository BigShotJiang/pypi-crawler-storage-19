'''ReplicaSetList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replica_set import ReplicaSet
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ReplicaSetList:
    """ReplicaSetList is a collection of ReplicaSets."""
    apiVersion: Optional[str] = None
    items: Optional[list[ReplicaSet]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ReplicaSetList"]