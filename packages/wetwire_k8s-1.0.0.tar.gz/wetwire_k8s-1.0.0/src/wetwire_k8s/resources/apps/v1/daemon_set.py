'''DaemonSet resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .daemon_set_spec import DaemonSetSpec
from .daemon_set_status import DaemonSetStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class DaemonSet:
    """DaemonSet represents the configuration of a daemon set."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[DaemonSetSpec] = None
    status: Optional[DaemonSetStatus] = None


__all__ = ["DaemonSet"]