'''ReplicaSet resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replica_set_spec import ReplicaSetSpec
from .replica_set_status import ReplicaSetStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ReplicaSet:
    """ReplicaSet ensures that a specified number of pod replicas are running at any given time."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ReplicaSetSpec] = None
    status: Optional[ReplicaSetStatus] = None


__all__ = ["ReplicaSet"]