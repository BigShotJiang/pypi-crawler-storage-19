'''DaemonSetUpdateStrategy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .rolling_update_daemon_set import RollingUpdateDaemonSet


@dataclass
class DaemonSetUpdateStrategy:
    """DaemonSetUpdateStrategy is a struct used to control the update strategy for a DaemonSet."""
    rollingUpdate: Optional[RollingUpdateDaemonSet] = None
    type: Optional[str] = None


__all__ = ["DaemonSetUpdateStrategy"]