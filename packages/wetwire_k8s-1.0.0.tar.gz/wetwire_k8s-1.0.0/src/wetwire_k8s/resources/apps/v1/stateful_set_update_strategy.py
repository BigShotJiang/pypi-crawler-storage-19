'''StatefulSetUpdateStrategy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .rolling_update_stateful_set_strategy import RollingUpdateStatefulSetStrategy


@dataclass
class StatefulSetUpdateStrategy:
    """StatefulSetUpdateStrategy indicates the strategy that the StatefulSet controller will use to perform updates. It includes any additional parameters necessary to perform the update for the indicated strategy."""
    rollingUpdate: Optional[RollingUpdateStatefulSetStrategy] = None
    type: Optional[str] = None


__all__ = ["StatefulSetUpdateStrategy"]