'''RollingUpdateStatefulSetStrategy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.int_or_string import IntOrString


@dataclass
class RollingUpdateStatefulSetStrategy:
    """RollingUpdateStatefulSetStrategy is used to communicate parameter for RollingUpdateStatefulSetStrategyType."""
    maxUnavailable: Optional[IntOrString] = None
    partition: Optional[int] = None


__all__ = ["RollingUpdateStatefulSetStrategy"]