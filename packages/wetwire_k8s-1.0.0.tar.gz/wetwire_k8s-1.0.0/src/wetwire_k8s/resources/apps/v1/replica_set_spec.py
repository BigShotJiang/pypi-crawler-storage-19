'''ReplicaSetSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.core.v1.pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class ReplicaSetSpec:
    """ReplicaSetSpec is the specification of a ReplicaSet."""
    minReadySeconds: Optional[int] = None
    replicas: Optional[int] = None
    selector: Optional[LabelSelector] = None
    template: Optional[PodTemplateSpec] = None


__all__ = ["ReplicaSetSpec"]