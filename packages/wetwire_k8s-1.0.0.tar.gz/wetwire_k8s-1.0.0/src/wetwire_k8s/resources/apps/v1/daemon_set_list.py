'''DaemonSetList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .daemon_set import DaemonSet
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class DaemonSetList:
    """DaemonSetList is a collection of daemon sets."""
    apiVersion: Optional[str] = None
    items: Optional[list[DaemonSet]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["DaemonSetList"]