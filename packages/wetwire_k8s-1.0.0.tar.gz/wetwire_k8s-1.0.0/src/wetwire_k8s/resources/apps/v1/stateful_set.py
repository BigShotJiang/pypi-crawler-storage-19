'''StatefulSet resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .stateful_set_spec import StatefulSetSpec
from .stateful_set_status import StatefulSetStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class StatefulSet:
    """StatefulSet represents a set of pods with consistent identities. Identities are defined as:
  - Network: A single stable DNS and hostname.
  - Storage: As many VolumeClaims as requested.

The StatefulSet guarantees that a given network identity will always map to the same storage identity."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[StatefulSetSpec] = None
    status: Optional[StatefulSetStatus] = None


__all__ = ["StatefulSet"]