'''DeploymentCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class DeploymentCondition:
    """DeploymentCondition describes the state of a deployment at a certain point."""
    lastTransitionTime: Optional[Time] = None
    lastUpdateTime: Optional[Time] = None
    message: Optional[str] = None
    reason: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["DeploymentCondition"]