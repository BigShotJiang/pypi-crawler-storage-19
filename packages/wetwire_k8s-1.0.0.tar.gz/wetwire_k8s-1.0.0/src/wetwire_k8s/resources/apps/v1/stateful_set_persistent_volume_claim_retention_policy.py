'''StatefulSetPersistentVolumeClaimRetentionPolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class StatefulSetPersistentVolumeClaimRetentionPolicy:
    """StatefulSetPersistentVolumeClaimRetentionPolicy describes the policy used for PVCs created from the StatefulSet VolumeClaimTemplates."""
    whenDeleted: Optional[str] = None
    whenScaled: Optional[str] = None


__all__ = ["StatefulSetPersistentVolumeClaimRetentionPolicy"]