'''ControllerRevisionList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .controller_revision import ControllerRevision
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ControllerRevisionList:
    """ControllerRevisionList is a resource containing a list of ControllerRevision objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[ControllerRevision]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ControllerRevisionList"]