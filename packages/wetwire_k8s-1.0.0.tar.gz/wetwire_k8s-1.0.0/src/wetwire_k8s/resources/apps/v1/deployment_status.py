'''DeploymentStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .deployment_condition import DeploymentCondition


@dataclass
class DeploymentStatus:
    """DeploymentStatus is the most recently observed status of the Deployment."""
    availableReplicas: Optional[int] = None
    collisionCount: Optional[int] = None
    conditions: Optional[list[DeploymentCondition]] = None
    observedGeneration: Optional[int] = None
    readyReplicas: Optional[int] = None
    replicas: Optional[int] = None
    unavailableReplicas: Optional[int] = None
    updatedReplicas: Optional[int] = None


__all__ = ["DeploymentStatus"]