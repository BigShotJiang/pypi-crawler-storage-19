'''ReplicaSetStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replica_set_condition import ReplicaSetCondition


@dataclass
class ReplicaSetStatus:
    """ReplicaSetStatus represents the current status of a ReplicaSet."""
    availableReplicas: Optional[int] = None
    conditions: Optional[list[ReplicaSetCondition]] = None
    fullyLabeledReplicas: Optional[int] = None
    observedGeneration: Optional[int] = None
    readyReplicas: Optional[int] = None
    replicas: Optional[int] = None


__all__ = ["ReplicaSetStatus"]