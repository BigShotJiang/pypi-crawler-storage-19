'''StatefulSetStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .stateful_set_condition import StatefulSetCondition


@dataclass
class StatefulSetStatus:
    """StatefulSetStatus represents the current state of a StatefulSet."""
    availableReplicas: Optional[int] = None
    collisionCount: Optional[int] = None
    conditions: Optional[list[StatefulSetCondition]] = None
    currentReplicas: Optional[int] = None
    currentRevision: Optional[str] = None
    observedGeneration: Optional[int] = None
    readyReplicas: Optional[int] = None
    replicas: Optional[int] = None
    updateRevision: Optional[str] = None
    updatedReplicas: Optional[int] = None


__all__ = ["StatefulSetStatus"]