'''StatefulSetSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .stateful_set_ordinals import StatefulSetOrdinals
from .stateful_set_persistent_volume_claim_retention_policy import StatefulSetPersistentVolumeClaimRetentionPolicy
from .stateful_set_update_strategy import StatefulSetUpdateStrategy
from wetwire_k8s.resources.core.v1.persistent_volume_claim import PersistentVolumeClaim
from wetwire_k8s.resources.core.v1.pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class StatefulSetSpec:
    """A StatefulSetSpec is the specification of a StatefulSet."""
    minReadySeconds: Optional[int] = None
    ordinals: Optional[StatefulSetOrdinals] = None
    persistentVolumeClaimRetentionPolicy: Optional[StatefulSetPersistentVolumeClaimRetentionPolicy] = None
    podManagementPolicy: Optional[str] = None
    replicas: Optional[int] = None
    revisionHistoryLimit: Optional[int] = None
    selector: Optional[LabelSelector] = None
    serviceName: Optional[str] = None
    template: Optional[PodTemplateSpec] = None
    updateStrategy: Optional[StatefulSetUpdateStrategy] = None
    volumeClaimTemplates: Optional[list[PersistentVolumeClaim]] = None


__all__ = ["StatefulSetSpec"]