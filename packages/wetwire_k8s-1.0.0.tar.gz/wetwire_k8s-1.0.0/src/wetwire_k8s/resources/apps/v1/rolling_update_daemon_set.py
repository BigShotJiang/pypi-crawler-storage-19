'''RollingUpdateDaemonSet resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.int_or_string import IntOrString


@dataclass
class RollingUpdateDaemonSet:
    """Spec to control the desired behavior of daemon set rolling update."""
    maxSurge: Optional[IntOrString] = None
    maxUnavailable: Optional[IntOrString] = None


__all__ = ["RollingUpdateDaemonSet"]