'''DeploymentList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .deployment import Deployment
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class DeploymentList:
    """DeploymentList is a list of Deployments."""
    apiVersion: Optional[str] = None
    items: Optional[list[Deployment]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["DeploymentList"]