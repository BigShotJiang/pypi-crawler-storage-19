"""Kubernetes apps resources."""
