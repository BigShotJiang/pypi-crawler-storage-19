"""Kubernetes events resources."""
