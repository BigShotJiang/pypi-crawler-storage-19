'''EventSeries resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.micro_time import MicroTime


@dataclass
class EventSeries:
    """EventSeries contain information on series of events, i.e. thing that was/is happening continuously for some time. How often to update the EventSeries is up to the event reporters. The default event reporter in "k8s.io/client-go/tools/events/event_broadcaster.go" shows how this struct is updated on heartbeats and can guide customized reporter implementations."""
    count: Optional[int] = None
    lastObservedTime: Optional[MicroTime] = None


__all__ = ["EventSeries"]