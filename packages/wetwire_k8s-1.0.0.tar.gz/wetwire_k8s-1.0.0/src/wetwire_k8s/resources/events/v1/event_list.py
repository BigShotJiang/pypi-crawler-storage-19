'''EventList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .event import Event
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class EventList:
    """EventList is a list of Event objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[Event]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["EventList"]