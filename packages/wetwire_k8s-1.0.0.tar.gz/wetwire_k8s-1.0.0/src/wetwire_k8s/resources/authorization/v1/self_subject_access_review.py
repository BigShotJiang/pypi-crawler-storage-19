'''SelfSubjectAccessReview resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .self_subject_access_review_spec import SelfSubjectAccessReviewSpec
from .subject_access_review_status import SubjectAccessReviewStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class SelfSubjectAccessReview:
    """SelfSubjectAccessReview checks whether or the current user can perform an action.  Not filling in a spec.namespace means "in all namespaces".  Self is a special case, because users should always be able to check whether they can perform an action"""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[SelfSubjectAccessReviewSpec] = None
    status: Optional[SubjectAccessReviewStatus] = None


__all__ = ["SelfSubjectAccessReview"]