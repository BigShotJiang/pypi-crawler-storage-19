'''SelfSubjectRulesReview resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .self_subject_rules_review_spec import SelfSubjectRulesReviewSpec
from .subject_rules_review_status import SubjectRulesReviewStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class SelfSubjectRulesReview:
    """SelfSubjectRulesReview enumerates the set of actions the current user can perform within a namespace. The returned list of actions may be incomplete depending on the server's authorization mode, and any errors experienced during the evaluation. SelfSubjectRulesReview should be used by UIs to show/hide actions, or to quickly let an end user reason about their permissions. It should NOT Be used by external systems to drive authorization decisions as this raises confused deputy, cache lifetime/revocation, and correctness concerns. SubjectAccessReview, and LocalAccessReview are the correct way to defer authorization decisions to the API server."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[SelfSubjectRulesReviewSpec] = None
    status: Optional[SubjectRulesReviewStatus] = None


__all__ = ["SelfSubjectRulesReview"]