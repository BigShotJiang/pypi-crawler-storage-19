'''SubjectAccessReview resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .subject_access_review_spec import SubjectAccessReviewSpec
from .subject_access_review_status import SubjectAccessReviewStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class SubjectAccessReview:
    """SubjectAccessReview checks whether or not a user or group can perform an action."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[SubjectAccessReviewSpec] = None
    status: Optional[SubjectAccessReviewStatus] = None


__all__ = ["SubjectAccessReview"]