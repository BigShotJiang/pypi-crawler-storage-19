'''NonResourceAttributes resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NonResourceAttributes:
    """NonResourceAttributes includes the authorization attributes available for non-resource requests to the Authorizer interface"""
    path: Optional[str] = None
    verb: Optional[str] = None


__all__ = ["NonResourceAttributes"]