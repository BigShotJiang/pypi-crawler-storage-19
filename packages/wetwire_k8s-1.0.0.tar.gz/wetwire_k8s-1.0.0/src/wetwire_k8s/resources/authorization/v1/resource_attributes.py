'''ResourceAttributes resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ResourceAttributes:
    """ResourceAttributes includes the authorization attributes available for resource requests to the Authorizer interface"""
    group: Optional[str] = None
    name: Optional[str] = None
    namespace: Optional[str] = None
    resource: Optional[str] = None
    subresource: Optional[str] = None
    verb: Optional[str] = None
    version: Optional[str] = None


__all__ = ["ResourceAttributes"]