'''SubjectAccessReviewStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SubjectAccessReviewStatus:
    """SubjectAccessReviewStatus"""
    allowed: Optional[bool] = None
    denied: Optional[bool] = None
    evaluationError: Optional[str] = None
    reason: Optional[str] = None


__all__ = ["SubjectAccessReviewStatus"]