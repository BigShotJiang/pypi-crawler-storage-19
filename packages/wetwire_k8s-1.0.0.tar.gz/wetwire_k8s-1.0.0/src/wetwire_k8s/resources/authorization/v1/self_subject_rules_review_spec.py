'''SelfSubjectRulesReviewSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SelfSubjectRulesReviewSpec:
    """SelfSubjectRulesReviewSpec defines the specification for SelfSubjectRulesReview."""
    namespace: Optional[str] = None


__all__ = ["SelfSubjectRulesReviewSpec"]