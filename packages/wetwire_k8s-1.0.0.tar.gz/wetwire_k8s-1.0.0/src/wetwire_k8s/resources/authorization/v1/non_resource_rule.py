'''NonResourceRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NonResourceRule:
    """NonResourceRule holds information that describes a rule for the non-resource"""
    nonResourceURLs: Optional[list[str]] = None
    verbs: Optional[list[str]] = None


__all__ = ["NonResourceRule"]