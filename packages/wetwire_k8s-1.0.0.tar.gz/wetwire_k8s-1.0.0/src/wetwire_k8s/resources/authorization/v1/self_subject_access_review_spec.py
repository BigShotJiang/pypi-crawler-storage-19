'''SelfSubjectAccessReviewSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .non_resource_attributes import NonResourceAttributes
from .resource_attributes import ResourceAttributes


@dataclass
class SelfSubjectAccessReviewSpec:
    """SelfSubjectAccessReviewSpec is a description of the access request.  Exactly one of ResourceAuthorizationAttributes and NonResourceAuthorizationAttributes must be set"""
    nonResourceAttributes: Optional[NonResourceAttributes] = None
    resourceAttributes: Optional[ResourceAttributes] = None


__all__ = ["SelfSubjectAccessReviewSpec"]