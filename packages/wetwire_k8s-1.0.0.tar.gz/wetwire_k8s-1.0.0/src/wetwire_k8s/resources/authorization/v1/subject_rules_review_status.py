'''SubjectRulesReviewStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .non_resource_rule import NonResourceRule
from .resource_rule import ResourceRule


@dataclass
class SubjectRulesReviewStatus:
    """SubjectRulesReviewStatus contains the result of a rules check. This check can be incomplete depending on the set of authorizers the server is configured with and any errors experienced during evaluation. Because authorization rules are additive, if a rule appears in a list it's safe to assume the subject has that permission, even if that list is incomplete."""
    evaluationError: Optional[str] = None
    incomplete: Optional[bool] = None
    nonResourceRules: Optional[list[NonResourceRule]] = None
    resourceRules: Optional[list[ResourceRule]] = None


__all__ = ["SubjectRulesReviewStatus"]