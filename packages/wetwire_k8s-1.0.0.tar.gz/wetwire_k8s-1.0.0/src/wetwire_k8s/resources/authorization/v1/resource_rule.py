'''ResourceRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ResourceRule:
    """ResourceRule is the list of actions the subject is allowed to perform on resources. The list ordering isn't significant, may contain duplicates, and possibly be incomplete."""
    apiGroups: Optional[list[str]] = None
    resourceNames: Optional[list[str]] = None
    resources: Optional[list[str]] = None
    verbs: Optional[list[str]] = None


__all__ = ["ResourceRule"]