'''Kubernetes authorization/v1 resources.'''

from .local_subject_access_review import LocalSubjectAccessReview
from .non_resource_attributes import NonResourceAttributes
from .non_resource_rule import NonResourceRule
from .resource_attributes import ResourceAttributes
from .resource_rule import ResourceRule
from .self_subject_access_review import SelfSubjectAccessReview
from .self_subject_access_review_spec import SelfSubjectAccessReviewSpec
from .self_subject_rules_review import SelfSubjectRulesReview
from .self_subject_rules_review_spec import SelfSubjectRulesReviewSpec
from .subject_access_review import SubjectAccessReview
from .subject_access_review_spec import SubjectAccessReviewSpec
from .subject_access_review_status import SubjectAccessReviewStatus
from .subject_rules_review_status import SubjectRulesReviewStatus

__all__ = ["LocalSubjectAccessReview", "NonResourceAttributes", "NonResourceRule", "ResourceAttributes", "ResourceRule", "SelfSubjectAccessReview", "SelfSubjectAccessReviewSpec", "SelfSubjectRulesReview", "SelfSubjectRulesReviewSpec", "SubjectAccessReview", "SubjectAccessReviewSpec", "SubjectAccessReviewStatus", "SubjectRulesReviewStatus"]