'''SubjectAccessReviewSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .non_resource_attributes import NonResourceAttributes
from .resource_attributes import ResourceAttributes


@dataclass
class SubjectAccessReviewSpec:
    """SubjectAccessReviewSpec is a description of the access request.  Exactly one of ResourceAuthorizationAttributes and NonResourceAuthorizationAttributes must be set"""
    extra: Optional[dict[str, Any]] = None
    groups: Optional[list[str]] = None
    nonResourceAttributes: Optional[NonResourceAttributes] = None
    resourceAttributes: Optional[ResourceAttributes] = None
    uid: Optional[str] = None
    user: Optional[str] = None


__all__ = ["SubjectAccessReviewSpec"]