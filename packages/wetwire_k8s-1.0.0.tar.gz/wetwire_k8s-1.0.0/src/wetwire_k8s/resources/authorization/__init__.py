"""Kubernetes authorization resources."""
