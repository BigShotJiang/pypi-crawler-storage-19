"""Kubernetes meta resources."""
