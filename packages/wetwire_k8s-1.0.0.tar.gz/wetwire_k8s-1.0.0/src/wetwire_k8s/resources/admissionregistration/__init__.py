"""Kubernetes admissionregistration resources."""
