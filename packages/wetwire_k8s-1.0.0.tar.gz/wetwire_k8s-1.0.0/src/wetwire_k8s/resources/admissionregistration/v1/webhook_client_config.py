'''WebhookClientConfig resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .service_reference import ServiceReference


@dataclass
class WebhookClientConfig:
    """WebhookClientConfig contains the information to make a TLS connection with the webhook"""
    caBundle: Optional[str] = None
    service: Optional[ServiceReference] = None
    url: Optional[str] = None


__all__ = ["WebhookClientConfig"]