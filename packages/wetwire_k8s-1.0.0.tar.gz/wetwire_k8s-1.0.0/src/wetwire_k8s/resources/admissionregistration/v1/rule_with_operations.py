'''RuleWithOperations resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class RuleWithOperations:
    """RuleWithOperations is a tuple of Operations and Resources. It is recommended to make sure that all the tuple expansions are valid."""
    apiGroups: Optional[list[str]] = None
    apiVersions: Optional[list[str]] = None
    operations: Optional[list[str]] = None
    resources: Optional[list[str]] = None
    scope: Optional[str] = None


__all__ = ["RuleWithOperations"]