'''ValidatingAdmissionPolicyBinding resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_admission_policy_binding_spec import ValidatingAdmissionPolicyBindingSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ValidatingAdmissionPolicyBinding:
    """ValidatingAdmissionPolicyBinding binds the ValidatingAdmissionPolicy with paramerized resources. ValidatingAdmissionPolicyBinding and parameter CRDs together define how cluster administrators configure policies for clusters.

For a given admission request, each binding will cause its policy to be evaluated N times, where N is 1 for policies/bindings that don't use params, otherwise N is the number of parameters selected by the binding.

The CEL expressions of a policy must have a computed CEL cost below the maximum CEL budget. Each evaluation of the policy is given an independent CEL cost budget. Adding/removing policies, bindings, or params can not affect whether a given (policy, binding, param) combination is within its own CEL budget."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ValidatingAdmissionPolicyBindingSpec] = None


__all__ = ["ValidatingAdmissionPolicyBinding"]