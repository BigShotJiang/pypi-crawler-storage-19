'''MutatingWebhookConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .mutating_webhook import MutatingWebhook
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class MutatingWebhookConfiguration:
    """MutatingWebhookConfiguration describes the configuration of and admission webhook that accept or reject and may change the object."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    webhooks: Optional[list[MutatingWebhook]] = None


__all__ = ["MutatingWebhookConfiguration"]