'''NamedRuleWithOperations resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NamedRuleWithOperations:
    """NamedRuleWithOperations is a tuple of Operations and Resources with ResourceNames."""
    apiGroups: Optional[list[str]] = None
    apiVersions: Optional[list[str]] = None
    operations: Optional[list[str]] = None
    resourceNames: Optional[list[str]] = None
    resources: Optional[list[str]] = None
    scope: Optional[str] = None


__all__ = ["NamedRuleWithOperations"]