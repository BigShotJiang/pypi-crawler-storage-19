'''ValidatingWebhookConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_webhook import ValidatingWebhook
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ValidatingWebhookConfiguration:
    """ValidatingWebhookConfiguration describes the configuration of and admission webhook that accept or reject and object without changing it."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    webhooks: Optional[list[ValidatingWebhook]] = None


__all__ = ["ValidatingWebhookConfiguration"]