'''ExpressionWarning resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ExpressionWarning:
    """ExpressionWarning is a warning information that targets a specific expression."""
    fieldRef: Optional[str] = None
    warning: Optional[str] = None


__all__ = ["ExpressionWarning"]