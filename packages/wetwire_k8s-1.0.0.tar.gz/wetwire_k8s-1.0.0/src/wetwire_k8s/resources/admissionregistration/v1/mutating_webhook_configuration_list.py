'''MutatingWebhookConfigurationList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .mutating_webhook_configuration import MutatingWebhookConfiguration
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class MutatingWebhookConfigurationList:
    """MutatingWebhookConfigurationList is a list of MutatingWebhookConfiguration."""
    apiVersion: Optional[str] = None
    items: Optional[list[MutatingWebhookConfiguration]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["MutatingWebhookConfigurationList"]