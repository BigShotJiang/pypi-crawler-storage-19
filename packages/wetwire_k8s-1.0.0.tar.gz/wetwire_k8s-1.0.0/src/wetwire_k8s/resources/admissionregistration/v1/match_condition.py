'''MatchCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class MatchCondition:
    """MatchCondition represents a condition which must by fulfilled for a request to be sent to a webhook."""
    expression: Optional[str] = None
    name: Optional[str] = None


__all__ = ["MatchCondition"]