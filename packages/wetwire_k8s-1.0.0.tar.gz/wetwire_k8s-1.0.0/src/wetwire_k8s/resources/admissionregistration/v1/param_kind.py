'''ParamKind resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ParamKind:
    """ParamKind is a tuple of Group Kind and Version."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None


__all__ = ["ParamKind"]