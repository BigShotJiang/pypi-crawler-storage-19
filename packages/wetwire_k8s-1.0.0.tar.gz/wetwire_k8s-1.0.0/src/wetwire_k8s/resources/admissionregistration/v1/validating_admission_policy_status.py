'''ValidatingAdmissionPolicyStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .type_checking import TypeChecking
from wetwire_k8s.resources.meta.v1.condition import Condition


@dataclass
class ValidatingAdmissionPolicyStatus:
    """ValidatingAdmissionPolicyStatus represents the status of an admission validation policy."""
    conditions: Optional[list[Condition]] = None
    observedGeneration: Optional[int] = None
    typeChecking: Optional[TypeChecking] = None


__all__ = ["ValidatingAdmissionPolicyStatus"]