'''AuditAnnotation resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AuditAnnotation:
    """AuditAnnotation describes how to produce an audit annotation for an API request."""
    key: Optional[str] = None
    valueExpression: Optional[str] = None


__all__ = ["AuditAnnotation"]