'''ParamRef resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class ParamRef:
    """ParamRef describes how to locate the params to be used as input to expressions of rules applied by a policy binding."""
    name: Optional[str] = None
    namespace: Optional[str] = None
    parameterNotFoundAction: Optional[str] = None
    selector: Optional[LabelSelector] = None


__all__ = ["ParamRef"]