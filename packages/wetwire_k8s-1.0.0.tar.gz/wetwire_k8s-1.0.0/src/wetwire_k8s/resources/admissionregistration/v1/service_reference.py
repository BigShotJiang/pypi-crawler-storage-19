'''ServiceReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ServiceReference:
    """ServiceReference holds a reference to Service.legacy.k8s.io"""
    name: Optional[str] = None
    namespace: Optional[str] = None
    path: Optional[str] = None
    port: Optional[int] = None


__all__ = ["ServiceReference"]