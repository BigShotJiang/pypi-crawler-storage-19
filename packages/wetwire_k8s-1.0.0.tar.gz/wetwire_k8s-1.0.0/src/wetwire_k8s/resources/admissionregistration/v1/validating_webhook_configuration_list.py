'''ValidatingWebhookConfigurationList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_webhook_configuration import ValidatingWebhookConfiguration
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ValidatingWebhookConfigurationList:
    """ValidatingWebhookConfigurationList is a list of ValidatingWebhookConfiguration."""
    apiVersion: Optional[str] = None
    items: Optional[list[ValidatingWebhookConfiguration]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ValidatingWebhookConfigurationList"]