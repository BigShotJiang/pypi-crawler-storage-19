'''MutatingWebhook resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .match_condition import MatchCondition
from .rule_with_operations import RuleWithOperations
from .webhook_client_config import WebhookClientConfig
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class MutatingWebhook:
    """MutatingWebhook describes an admission webhook and the resources and operations it applies to."""
    admissionReviewVersions: Optional[list[str]] = None
    clientConfig: Optional[WebhookClientConfig] = None
    failurePolicy: Optional[str] = None
    matchConditions: Optional[list[MatchCondition]] = None
    matchPolicy: Optional[str] = None
    name: Optional[str] = None
    namespaceSelector: Optional[LabelSelector] = None
    objectSelector: Optional[LabelSelector] = None
    reinvocationPolicy: Optional[str] = None
    rules: Optional[list[RuleWithOperations]] = None
    sideEffects: Optional[str] = None
    timeoutSeconds: Optional[int] = None


__all__ = ["MutatingWebhook"]