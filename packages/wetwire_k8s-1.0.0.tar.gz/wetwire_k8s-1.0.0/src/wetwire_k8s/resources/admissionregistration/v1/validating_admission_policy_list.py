'''ValidatingAdmissionPolicyList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_admission_policy import ValidatingAdmissionPolicy
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ValidatingAdmissionPolicyList:
    """ValidatingAdmissionPolicyList is a list of ValidatingAdmissionPolicy."""
    apiVersion: Optional[str] = None
    items: Optional[list[ValidatingAdmissionPolicy]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ValidatingAdmissionPolicyList"]