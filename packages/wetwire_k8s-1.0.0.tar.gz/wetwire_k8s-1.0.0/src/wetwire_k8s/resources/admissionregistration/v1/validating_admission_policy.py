'''ValidatingAdmissionPolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_admission_policy_spec import ValidatingAdmissionPolicySpec
from .validating_admission_policy_status import ValidatingAdmissionPolicyStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ValidatingAdmissionPolicy:
    """ValidatingAdmissionPolicy describes the definition of an admission validation policy that accepts or rejects an object without changing it."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ValidatingAdmissionPolicySpec] = None
    status: Optional[ValidatingAdmissionPolicyStatus] = None


__all__ = ["ValidatingAdmissionPolicy"]