'''Validation resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Validation:
    """Validation specifies the CEL expression which is used to apply the validation."""
    expression: Optional[str] = None
    message: Optional[str] = None
    messageExpression: Optional[str] = None
    reason: Optional[str] = None


__all__ = ["Validation"]