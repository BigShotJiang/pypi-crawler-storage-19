'''TypeChecking resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .expression_warning import ExpressionWarning


@dataclass
class TypeChecking:
    """TypeChecking contains results of type checking the expressions in the ValidatingAdmissionPolicy"""
    expressionWarnings: Optional[list[ExpressionWarning]] = None


__all__ = ["TypeChecking"]