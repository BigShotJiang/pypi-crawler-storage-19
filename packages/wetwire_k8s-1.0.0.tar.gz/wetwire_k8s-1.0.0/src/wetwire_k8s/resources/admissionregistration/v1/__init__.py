'''Kubernetes admissionregistration/v1 resources.'''

from .audit_annotation import AuditAnnotation
from .expression_warning import ExpressionWarning
from .match_condition import MatchCondition
from .match_resources import MatchResources
from .mutating_webhook import MutatingWebhook
from .mutating_webhook_configuration import MutatingWebhookConfiguration
from .mutating_webhook_configuration_list import MutatingWebhookConfigurationList
from .named_rule_with_operations import NamedRuleWithOperations
from .param_kind import ParamKind
from .param_ref import ParamRef
from .rule_with_operations import RuleWithOperations
from .service_reference import ServiceReference
from .type_checking import TypeChecking
from .validating_admission_policy import ValidatingAdmissionPolicy
from .validating_admission_policy_binding import ValidatingAdmissionPolicyBinding
from .validating_admission_policy_binding_list import ValidatingAdmissionPolicyBindingList
from .validating_admission_policy_binding_spec import ValidatingAdmissionPolicyBindingSpec
from .validating_admission_policy_list import ValidatingAdmissionPolicyList
from .validating_admission_policy_spec import ValidatingAdmissionPolicySpec
from .validating_admission_policy_status import ValidatingAdmissionPolicyStatus
from .validating_webhook import ValidatingWebhook
from .validating_webhook_configuration import ValidatingWebhookConfiguration
from .validating_webhook_configuration_list import ValidatingWebhookConfigurationList
from .validation import Validation
from .variable import Variable
from .webhook_client_config import WebhookClientConfig

__all__ = ["AuditAnnotation", "ExpressionWarning", "MatchCondition", "MatchResources", "MutatingWebhook", "MutatingWebhookConfiguration", "MutatingWebhookConfigurationList", "NamedRuleWithOperations", "ParamKind", "ParamRef", "RuleWithOperations", "ServiceReference", "TypeChecking", "ValidatingAdmissionPolicy", "ValidatingAdmissionPolicyBinding", "ValidatingAdmissionPolicyBindingList", "ValidatingAdmissionPolicyBindingSpec", "ValidatingAdmissionPolicyList", "ValidatingAdmissionPolicySpec", "ValidatingAdmissionPolicyStatus", "ValidatingWebhook", "ValidatingWebhookConfiguration", "ValidatingWebhookConfigurationList", "Validation", "Variable", "WebhookClientConfig"]