'''ValidatingAdmissionPolicyBindingList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .validating_admission_policy_binding import ValidatingAdmissionPolicyBinding
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ValidatingAdmissionPolicyBindingList:
    """ValidatingAdmissionPolicyBindingList is a list of ValidatingAdmissionPolicyBinding."""
    apiVersion: Optional[str] = None
    items: Optional[list[ValidatingAdmissionPolicyBinding]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ValidatingAdmissionPolicyBindingList"]