'''ValidatingAdmissionPolicySpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .audit_annotation import AuditAnnotation
from .match_condition import MatchCondition
from .match_resources import MatchResources
from .param_kind import ParamKind
from .validation import Validation
from .variable import Variable


@dataclass
class ValidatingAdmissionPolicySpec:
    """ValidatingAdmissionPolicySpec is the specification of the desired behavior of the AdmissionPolicy."""
    auditAnnotations: Optional[list[AuditAnnotation]] = None
    failurePolicy: Optional[str] = None
    matchConditions: Optional[list[MatchCondition]] = None
    matchConstraints: Optional[MatchResources] = None
    paramKind: Optional[ParamKind] = None
    validations: Optional[list[Validation]] = None
    variables: Optional[list[Variable]] = None


__all__ = ["ValidatingAdmissionPolicySpec"]