'''MatchResources resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .named_rule_with_operations import NamedRuleWithOperations
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class MatchResources:
    """MatchResources decides whether to run the admission control policy on an object based on whether it meets the match criteria. The exclude rules take precedence over include rules (if a resource matches both, it is excluded)"""
    excludeResourceRules: Optional[list[NamedRuleWithOperations]] = None
    matchPolicy: Optional[str] = None
    namespaceSelector: Optional[LabelSelector] = None
    objectSelector: Optional[LabelSelector] = None
    resourceRules: Optional[list[NamedRuleWithOperations]] = None


__all__ = ["MatchResources"]