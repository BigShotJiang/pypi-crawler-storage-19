'''ValidatingAdmissionPolicyBindingSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .match_resources import MatchResources
from .param_ref import ParamRef


@dataclass
class ValidatingAdmissionPolicyBindingSpec:
    """ValidatingAdmissionPolicyBindingSpec is the specification of the ValidatingAdmissionPolicyBinding."""
    matchResources: Optional[MatchResources] = None
    paramRef: Optional[ParamRef] = None
    policyName: Optional[str] = None
    validationActions: Optional[list[str]] = None


__all__ = ["ValidatingAdmissionPolicyBindingSpec"]