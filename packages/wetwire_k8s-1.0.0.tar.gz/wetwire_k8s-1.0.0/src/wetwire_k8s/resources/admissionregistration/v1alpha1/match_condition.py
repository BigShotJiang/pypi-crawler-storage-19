'''MatchCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class MatchCondition:
    """Kubernetes MatchCondition"""
    expression: Optional[str] = None
    name: Optional[str] = None


__all__ = ["MatchCondition"]