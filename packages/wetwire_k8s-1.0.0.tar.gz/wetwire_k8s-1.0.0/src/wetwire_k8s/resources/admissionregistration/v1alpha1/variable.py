'''Variable resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Variable:
    """Variable is the definition of a variable that is used for composition."""
    expression: Optional[str] = None
    name: Optional[str] = None


__all__ = ["Variable"]