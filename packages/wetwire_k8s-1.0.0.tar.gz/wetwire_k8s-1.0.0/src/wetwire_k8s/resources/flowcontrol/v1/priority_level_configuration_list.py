'''PriorityLevelConfigurationList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .priority_level_configuration import PriorityLevelConfiguration
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class PriorityLevelConfigurationList:
    """PriorityLevelConfigurationList is a list of PriorityLevelConfiguration objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[PriorityLevelConfiguration]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["PriorityLevelConfigurationList"]