'''QueuingConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class QueuingConfiguration:
    """QueuingConfiguration holds the configuration parameters for queuing"""
    handSize: Optional[int] = None
    queueLengthLimit: Optional[int] = None
    queues: Optional[int] = None


__all__ = ["QueuingConfiguration"]