'''NonResourcePolicyRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NonResourcePolicyRule:
    """NonResourcePolicyRule is a predicate that matches non-resource requests according to their verb and the target non-resource URL. A NonResourcePolicyRule matches a request if and only if both (a) at least one member of verbs matches the request and (b) at least one member of nonResourceURLs matches the request."""
    nonResourceURLs: Optional[list[str]] = None
    verbs: Optional[list[str]] = None


__all__ = ["NonResourcePolicyRule"]