'''ResourcePolicyRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ResourcePolicyRule:
    """ResourcePolicyRule is a predicate that matches some resource requests, testing the request's verb and the target resource. A ResourcePolicyRule matches a resource request if and only if: (a) at least one member of verbs matches the request, (b) at least one member of apiGroups matches the request, (c) at least one member of resources matches the request, and (d) either (d1) the request does not specify a namespace (i.e., `Namespace==""`) and clusterScope is true or (d2) the request specifies a namespace and least one member of namespaces matches the request's namespace."""
    apiGroups: Optional[list[str]] = None
    clusterScope: Optional[bool] = None
    namespaces: Optional[list[str]] = None
    resources: Optional[list[str]] = None
    verbs: Optional[list[str]] = None


__all__ = ["ResourcePolicyRule"]