'''PolicyRulesWithSubjects resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .non_resource_policy_rule import NonResourcePolicyRule
from .resource_policy_rule import ResourcePolicyRule
from .subject import Subject


@dataclass
class PolicyRulesWithSubjects:
    """PolicyRulesWithSubjects prescribes a test that applies to a request to an apiserver. The test considers the subject making the request, the verb being requested, and the resource to be acted upon. This PolicyRulesWithSubjects matches a request if and only if both (a) at least one member of subjects matches the request and (b) at least one member of resourceRules or nonResourceRules matches the request."""
    nonResourceRules: Optional[list[NonResourcePolicyRule]] = None
    resourceRules: Optional[list[ResourcePolicyRule]] = None
    subjects: Optional[list[Subject]] = None


__all__ = ["PolicyRulesWithSubjects"]