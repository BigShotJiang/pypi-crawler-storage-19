'''PriorityLevelConfigurationStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .priority_level_configuration_condition import PriorityLevelConfigurationCondition


@dataclass
class PriorityLevelConfigurationStatus:
    """PriorityLevelConfigurationStatus represents the current state of a "request-priority"."""
    conditions: Optional[list[PriorityLevelConfigurationCondition]] = None


__all__ = ["PriorityLevelConfigurationStatus"]