'''FlowDistinguisherMethod resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class FlowDistinguisherMethod:
    """FlowDistinguisherMethod specifies the method of a flow distinguisher."""
    type: Optional[str] = None


__all__ = ["FlowDistinguisherMethod"]