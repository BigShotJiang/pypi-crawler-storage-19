'''LimitResponse resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .queuing_configuration import QueuingConfiguration


@dataclass
class LimitResponse:
    """LimitResponse defines how to handle requests that can not be executed right now."""
    queuing: Optional[QueuingConfiguration] = None
    type: Optional[str] = None


__all__ = ["LimitResponse"]