'''PriorityLevelConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .priority_level_configuration_spec import PriorityLevelConfigurationSpec
from .priority_level_configuration_status import PriorityLevelConfigurationStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PriorityLevelConfiguration:
    """PriorityLevelConfiguration represents the configuration of a priority level."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PriorityLevelConfigurationSpec] = None
    status: Optional[PriorityLevelConfigurationStatus] = None


__all__ = ["PriorityLevelConfiguration"]