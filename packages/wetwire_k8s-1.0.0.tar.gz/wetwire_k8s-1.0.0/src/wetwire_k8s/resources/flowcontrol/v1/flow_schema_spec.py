'''FlowSchemaSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .flow_distinguisher_method import FlowDistinguisherMethod
from .policy_rules_with_subjects import PolicyRulesWithSubjects
from .priority_level_configuration_reference import PriorityLevelConfigurationReference


@dataclass
class FlowSchemaSpec:
    """FlowSchemaSpec describes how the FlowSchema's specification looks like."""
    distinguisherMethod: Optional[FlowDistinguisherMethod] = None
    matchingPrecedence: Optional[int] = None
    priorityLevelConfiguration: Optional[PriorityLevelConfigurationReference] = None
    rules: Optional[list[PolicyRulesWithSubjects]] = None


__all__ = ["FlowSchemaSpec"]