'''GroupSubject resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class GroupSubject:
    """GroupSubject holds detailed information for group-kind subject."""
    name: Optional[str] = None


__all__ = ["GroupSubject"]