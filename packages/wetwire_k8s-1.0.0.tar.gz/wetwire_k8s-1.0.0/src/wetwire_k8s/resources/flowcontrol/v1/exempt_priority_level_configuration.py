'''ExemptPriorityLevelConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ExemptPriorityLevelConfiguration:
    """ExemptPriorityLevelConfiguration describes the configurable aspects of the handling of exempt requests. In the mandatory exempt configuration object the values in the fields here can be modified by authorized users, unlike the rest of the `spec`."""
    lendablePercent: Optional[int] = None
    nominalConcurrencyShares: Optional[int] = None


__all__ = ["ExemptPriorityLevelConfiguration"]