'''FlowSchemaStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .flow_schema_condition import FlowSchemaCondition


@dataclass
class FlowSchemaStatus:
    """FlowSchemaStatus represents the current state of a FlowSchema."""
    conditions: Optional[list[FlowSchemaCondition]] = None


__all__ = ["FlowSchemaStatus"]