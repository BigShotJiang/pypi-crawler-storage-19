'''UserSubject resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class UserSubject:
    """UserSubject holds detailed information for user-kind subject."""
    name: Optional[str] = None


__all__ = ["UserSubject"]