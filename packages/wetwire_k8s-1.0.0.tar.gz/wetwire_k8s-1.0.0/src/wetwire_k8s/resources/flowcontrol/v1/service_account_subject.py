'''ServiceAccountSubject resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ServiceAccountSubject:
    """ServiceAccountSubject holds detailed information for service-account-kind subject."""
    name: Optional[str] = None
    namespace: Optional[str] = None


__all__ = ["ServiceAccountSubject"]