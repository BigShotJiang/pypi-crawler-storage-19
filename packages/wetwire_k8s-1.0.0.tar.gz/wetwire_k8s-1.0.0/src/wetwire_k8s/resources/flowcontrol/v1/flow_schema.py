'''FlowSchema resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .flow_schema_spec import FlowSchemaSpec
from .flow_schema_status import FlowSchemaStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class FlowSchema:
    """FlowSchema defines the schema of a group of flows. Note that a flow is made up of a set of inbound API requests with similar attributes and is identified by a pair of strings: the name of the FlowSchema and a "flow distinguisher"."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[FlowSchemaSpec] = None
    status: Optional[FlowSchemaStatus] = None


__all__ = ["FlowSchema"]