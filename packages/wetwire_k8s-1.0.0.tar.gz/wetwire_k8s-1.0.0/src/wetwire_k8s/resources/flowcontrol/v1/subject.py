'''Subject resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .group_subject import GroupSubject
from .service_account_subject import ServiceAccountSubject
from .user_subject import UserSubject


@dataclass
class Subject:
    """Subject matches the originator of a request, as identified by the request authentication system. There are three ways of matching an originator; by user, group, or service account."""
    group: Optional[GroupSubject] = None
    kind: Optional[str] = None
    serviceAccount: Optional[ServiceAccountSubject] = None
    user: Optional[UserSubject] = None


__all__ = ["Subject"]