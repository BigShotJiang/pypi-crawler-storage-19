'''FlowSchemaList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .flow_schema import FlowSchema
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class FlowSchemaList:
    """FlowSchemaList is a list of FlowSchema objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[FlowSchema]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["FlowSchemaList"]