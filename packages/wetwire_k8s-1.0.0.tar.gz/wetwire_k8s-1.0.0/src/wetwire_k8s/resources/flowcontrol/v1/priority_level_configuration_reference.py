'''PriorityLevelConfigurationReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PriorityLevelConfigurationReference:
    """PriorityLevelConfigurationReference contains information that points to the "request-priority" being used."""
    name: Optional[str] = None


__all__ = ["PriorityLevelConfigurationReference"]