'''LimitedPriorityLevelConfiguration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .limit_response import LimitResponse


@dataclass
class LimitedPriorityLevelConfiguration:
    """LimitedPriorityLevelConfiguration specifies how to handle requests that are subject to limits. It addresses two issues:
  - How are requests for this priority level limited?
  - What should be done with requests that exceed the limit?"""
    borrowingLimitPercent: Optional[int] = None
    lendablePercent: Optional[int] = None
    limitResponse: Optional[LimitResponse] = None
    nominalConcurrencyShares: Optional[int] = None


__all__ = ["LimitedPriorityLevelConfiguration"]