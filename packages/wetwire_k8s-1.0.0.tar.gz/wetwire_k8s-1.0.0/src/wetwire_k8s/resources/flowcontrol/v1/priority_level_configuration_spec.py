'''PriorityLevelConfigurationSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .exempt_priority_level_configuration import ExemptPriorityLevelConfiguration
from .limited_priority_level_configuration import LimitedPriorityLevelConfiguration


@dataclass
class PriorityLevelConfigurationSpec:
    """PriorityLevelConfigurationSpec specifies the configuration of a priority level."""
    exempt: Optional[ExemptPriorityLevelConfiguration] = None
    limited: Optional[LimitedPriorityLevelConfiguration] = None
    type: Optional[str] = None


__all__ = ["PriorityLevelConfigurationSpec"]