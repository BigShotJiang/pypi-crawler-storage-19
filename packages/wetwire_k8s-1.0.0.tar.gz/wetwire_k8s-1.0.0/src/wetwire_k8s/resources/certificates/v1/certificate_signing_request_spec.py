'''CertificateSigningRequestSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class CertificateSigningRequestSpec:
    """CertificateSigningRequestSpec contains the certificate request."""
    expirationSeconds: Optional[int] = None
    extra: Optional[dict[str, Any]] = None
    groups: Optional[list[str]] = None
    request: Optional[str] = None
    signerName: Optional[str] = None
    uid: Optional[str] = None
    usages: Optional[list[str]] = None
    username: Optional[str] = None


__all__ = ["CertificateSigningRequestSpec"]