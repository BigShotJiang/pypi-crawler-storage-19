'''CertificateSigningRequestList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .certificate_signing_request import CertificateSigningRequest
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class CertificateSigningRequestList:
    """CertificateSigningRequestList is a collection of CertificateSigningRequest objects"""
    apiVersion: Optional[str] = None
    items: Optional[list[CertificateSigningRequest]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["CertificateSigningRequestList"]