'''CertificateSigningRequestCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class CertificateSigningRequestCondition:
    """CertificateSigningRequestCondition describes a condition of a CertificateSigningRequest object"""
    lastTransitionTime: Optional[Time] = None
    lastUpdateTime: Optional[Time] = None
    message: Optional[str] = None
    reason: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["CertificateSigningRequestCondition"]