'''CertificateSigningRequestStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .certificate_signing_request_condition import CertificateSigningRequestCondition


@dataclass
class CertificateSigningRequestStatus:
    """CertificateSigningRequestStatus contains conditions used to indicate approved/denied/failed status of the request, and the issued certificate."""
    certificate: Optional[str] = None
    conditions: Optional[list[CertificateSigningRequestCondition]] = None


__all__ = ["CertificateSigningRequestStatus"]