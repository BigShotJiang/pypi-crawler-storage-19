'''CertificateSigningRequest resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .certificate_signing_request_spec import CertificateSigningRequestSpec
from .certificate_signing_request_status import CertificateSigningRequestStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class CertificateSigningRequest:
    """CertificateSigningRequest objects provide a mechanism to obtain x509 certificates by submitting a certificate signing request, and having it asynchronously approved and issued.

Kubelets use this API to obtain:
 1. client certificates to authenticate to kube-apiserver (with the "kubernetes.io/kube-apiserver-client-kubelet" signerName).
 2. serving certificates for TLS endpoints kube-apiserver can connect to securely (with the "kubernetes.io/kubelet-serving" signerName).

This API can be used to request client certificates to authenticate to kube-apiserver (with the "kubernetes.io/kube-apiserver-client" signerName), or to obtain certificates from custom non-Kubernetes signers."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[CertificateSigningRequestSpec] = None
    status: Optional[CertificateSigningRequestStatus] = None


__all__ = ["CertificateSigningRequest"]