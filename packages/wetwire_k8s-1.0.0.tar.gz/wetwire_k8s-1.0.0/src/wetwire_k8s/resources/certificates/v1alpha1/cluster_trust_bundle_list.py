'''ClusterTrustBundleList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cluster_trust_bundle import ClusterTrustBundle
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ClusterTrustBundleList:
    """ClusterTrustBundleList is a collection of ClusterTrustBundle objects"""
    apiVersion: Optional[str] = None
    items: Optional[list[ClusterTrustBundle]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ClusterTrustBundleList"]