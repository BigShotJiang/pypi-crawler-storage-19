'''ClusterTrustBundleSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ClusterTrustBundleSpec:
    """ClusterTrustBundleSpec contains the signer and trust anchors."""
    signerName: Optional[str] = None
    trustBundle: Optional[str] = None


__all__ = ["ClusterTrustBundleSpec"]