"""Kubernetes autoscaling resources."""
