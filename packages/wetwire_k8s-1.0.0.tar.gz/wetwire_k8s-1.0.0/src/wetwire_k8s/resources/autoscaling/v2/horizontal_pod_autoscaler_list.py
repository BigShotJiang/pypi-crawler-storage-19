'''HorizontalPodAutoscalerList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .horizontal_pod_autoscaler import HorizontalPodAutoscaler
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class HorizontalPodAutoscalerList:
    """HorizontalPodAutoscalerList is a list of horizontal pod autoscaler objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[HorizontalPodAutoscaler]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["HorizontalPodAutoscalerList"]