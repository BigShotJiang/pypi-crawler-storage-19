'''HorizontalPodAutoscalerStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .horizontal_pod_autoscaler_condition import HorizontalPodAutoscalerCondition
from .metric_status import MetricStatus
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class HorizontalPodAutoscalerStatus:
    """HorizontalPodAutoscalerStatus describes the current status of a horizontal pod autoscaler."""
    conditions: Optional[list[HorizontalPodAutoscalerCondition]] = None
    currentMetrics: Optional[list[MetricStatus]] = None
    currentReplicas: Optional[int] = None
    desiredReplicas: Optional[int] = None
    lastScaleTime: Optional[Time] = None
    observedGeneration: Optional[int] = None


__all__ = ["HorizontalPodAutoscalerStatus"]