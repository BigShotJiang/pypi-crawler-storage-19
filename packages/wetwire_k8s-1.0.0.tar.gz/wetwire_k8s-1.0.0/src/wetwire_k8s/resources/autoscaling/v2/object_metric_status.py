'''ObjectMetricStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cross_version_object_reference import CrossVersionObjectReference
from .metric_identifier import MetricIdentifier
from .metric_value_status import MetricValueStatus


@dataclass
class ObjectMetricStatus:
    """ObjectMetricStatus indicates the current value of a metric describing a kubernetes object (for example, hits-per-second on an Ingress object)."""
    current: Optional[MetricValueStatus] = None
    describedObject: Optional[CrossVersionObjectReference] = None
    metric: Optional[MetricIdentifier] = None


__all__ = ["ObjectMetricStatus"]