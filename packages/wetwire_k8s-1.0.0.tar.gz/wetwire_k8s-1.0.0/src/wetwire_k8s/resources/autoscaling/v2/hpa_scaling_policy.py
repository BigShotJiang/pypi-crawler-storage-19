'''HPAScalingPolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HPAScalingPolicy:
    """HPAScalingPolicy is a single policy which must hold true for a specified past interval."""
    periodSeconds: Optional[int] = None
    type: Optional[str] = None
    value: Optional[int] = None


__all__ = ["HPAScalingPolicy"]