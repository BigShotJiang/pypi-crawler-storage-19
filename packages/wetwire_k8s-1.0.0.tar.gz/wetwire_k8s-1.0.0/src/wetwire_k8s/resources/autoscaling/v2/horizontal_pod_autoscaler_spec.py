'''HorizontalPodAutoscalerSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cross_version_object_reference import CrossVersionObjectReference
from .horizontal_pod_autoscaler_behavior import HorizontalPodAutoscalerBehavior
from .metric_spec import MetricSpec


@dataclass
class HorizontalPodAutoscalerSpec:
    """HorizontalPodAutoscalerSpec describes the desired functionality of the HorizontalPodAutoscaler."""
    behavior: Optional[HorizontalPodAutoscalerBehavior] = None
    maxReplicas: Optional[int] = None
    metrics: Optional[list[MetricSpec]] = None
    minReplicas: Optional[int] = None
    scaleTargetRef: Optional[CrossVersionObjectReference] = None


__all__ = ["HorizontalPodAutoscalerSpec"]