'''HPAScalingRules resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .hpa_scaling_policy import HPAScalingPolicy


@dataclass
class HPAScalingRules:
    """HPAScalingRules configures the scaling behavior for one direction. These Rules are applied after calculating DesiredReplicas from metrics for the HPA. They can limit the scaling velocity by specifying scaling policies. They can prevent flapping by specifying the stabilization window, so that the number of replicas is not set instantly, instead, the safest value from the stabilization window is chosen."""
    policies: Optional[list[HPAScalingPolicy]] = None
    selectPolicy: Optional[str] = None
    stabilizationWindowSeconds: Optional[int] = None


__all__ = ["HPAScalingRules"]