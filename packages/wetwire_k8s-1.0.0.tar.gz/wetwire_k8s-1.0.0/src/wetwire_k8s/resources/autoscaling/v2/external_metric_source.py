'''ExternalMetricSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .metric_identifier import MetricIdentifier
from .metric_target import MetricTarget


@dataclass
class ExternalMetricSource:
    """ExternalMetricSource indicates how to scale on a metric not associated with any Kubernetes object (for example length of queue in cloud messaging service, or QPS from loadbalancer running outside of cluster)."""
    metric: Optional[MetricIdentifier] = None
    target: Optional[MetricTarget] = None


__all__ = ["ExternalMetricSource"]