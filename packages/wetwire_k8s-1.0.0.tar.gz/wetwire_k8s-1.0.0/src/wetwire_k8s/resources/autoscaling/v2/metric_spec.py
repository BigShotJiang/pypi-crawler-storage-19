'''MetricSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_resource_metric_source import ContainerResourceMetricSource
from .external_metric_source import ExternalMetricSource
from .object_metric_source import ObjectMetricSource
from .pods_metric_source import PodsMetricSource
from .resource_metric_source import ResourceMetricSource


@dataclass
class MetricSpec:
    """MetricSpec specifies how to scale based on a single metric (only `type` and one other matching field should be set at once)."""
    containerResource: Optional[ContainerResourceMetricSource] = None
    external: Optional[ExternalMetricSource] = None
    object: Optional[ObjectMetricSource] = None
    pods: Optional[PodsMetricSource] = None
    resource: Optional[ResourceMetricSource] = None
    type: Optional[str] = None


__all__ = ["MetricSpec"]