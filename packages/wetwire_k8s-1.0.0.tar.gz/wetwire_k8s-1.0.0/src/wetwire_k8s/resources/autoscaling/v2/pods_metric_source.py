'''PodsMetricSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .metric_identifier import MetricIdentifier
from .metric_target import MetricTarget


@dataclass
class PodsMetricSource:
    """PodsMetricSource indicates how to scale on a metric describing each pod in the current scale target (for example, transactions-processed-per-second). The values will be averaged together before being compared to the target value."""
    metric: Optional[MetricIdentifier] = None
    target: Optional[MetricTarget] = None


__all__ = ["PodsMetricSource"]