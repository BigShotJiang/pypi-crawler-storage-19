'''MetricStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_resource_metric_status import ContainerResourceMetricStatus
from .external_metric_status import ExternalMetricStatus
from .object_metric_status import ObjectMetricStatus
from .pods_metric_status import PodsMetricStatus
from .resource_metric_status import ResourceMetricStatus


@dataclass
class MetricStatus:
    """MetricStatus describes the last-read state of a single metric."""
    containerResource: Optional[ContainerResourceMetricStatus] = None
    external: Optional[ExternalMetricStatus] = None
    object: Optional[ObjectMetricStatus] = None
    pods: Optional[PodsMetricStatus] = None
    resource: Optional[ResourceMetricStatus] = None
    type: Optional[str] = None


__all__ = ["MetricStatus"]