'''HorizontalPodAutoscalerBehavior resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .hpa_scaling_rules import HPAScalingRules


@dataclass
class HorizontalPodAutoscalerBehavior:
    """HorizontalPodAutoscalerBehavior configures the scaling behavior of the target in both Up and Down directions (scaleUp and scaleDown fields respectively)."""
    scaleDown: Optional[HPAScalingRules] = None
    scaleUp: Optional[HPAScalingRules] = None


__all__ = ["HorizontalPodAutoscalerBehavior"]