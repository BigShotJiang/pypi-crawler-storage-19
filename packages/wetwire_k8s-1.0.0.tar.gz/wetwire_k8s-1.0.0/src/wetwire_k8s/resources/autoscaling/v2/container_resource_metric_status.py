'''ContainerResourceMetricStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .metric_value_status import MetricValueStatus


@dataclass
class ContainerResourceMetricStatus:
    """ContainerResourceMetricStatus indicates the current value of a resource metric known to Kubernetes, as specified in requests and limits, describing a single container in each pod in the current scale target (e.g. CPU or memory).  Such metrics are built in to Kubernetes, and have special scaling options on top of those available to normal per-pod metrics using the "pods" source."""
    container: Optional[str] = None
    current: Optional[MetricValueStatus] = None
    name: Optional[str] = None


__all__ = ["ContainerResourceMetricStatus"]