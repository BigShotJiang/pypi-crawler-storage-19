'''MetricValueStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.quantity import Quantity


@dataclass
class MetricValueStatus:
    """MetricValueStatus holds the current value for a metric"""
    averageUtilization: Optional[int] = None
    averageValue: Optional[Quantity] = None
    value: Optional[Quantity] = None


__all__ = ["MetricValueStatus"]