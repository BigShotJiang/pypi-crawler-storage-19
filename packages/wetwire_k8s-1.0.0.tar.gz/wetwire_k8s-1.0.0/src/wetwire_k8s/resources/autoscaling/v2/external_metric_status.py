'''ExternalMetricStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .metric_identifier import MetricIdentifier
from .metric_value_status import MetricValueStatus


@dataclass
class ExternalMetricStatus:
    """ExternalMetricStatus indicates the current value of a global metric not associated with any Kubernetes object."""
    current: Optional[MetricValueStatus] = None
    metric: Optional[MetricIdentifier] = None


__all__ = ["ExternalMetricStatus"]