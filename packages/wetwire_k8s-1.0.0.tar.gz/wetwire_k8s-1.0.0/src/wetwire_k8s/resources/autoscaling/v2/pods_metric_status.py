'''PodsMetricStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .metric_identifier import MetricIdentifier
from .metric_value_status import MetricValueStatus


@dataclass
class PodsMetricStatus:
    """PodsMetricStatus indicates the current value of a metric describing each pod in the current scale target (for example, transactions-processed-per-second)."""
    current: Optional[MetricValueStatus] = None
    metric: Optional[MetricIdentifier] = None


__all__ = ["PodsMetricStatus"]