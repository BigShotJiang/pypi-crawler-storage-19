'''MetricTarget resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.quantity import Quantity


@dataclass
class MetricTarget:
    """MetricTarget defines the target value, average value, or average utilization of a specific metric"""
    averageUtilization: Optional[int] = None
    averageValue: Optional[Quantity] = None
    type: Optional[str] = None
    value: Optional[Quantity] = None


__all__ = ["MetricTarget"]