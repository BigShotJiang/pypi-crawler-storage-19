'''ObjectMetricSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cross_version_object_reference import CrossVersionObjectReference
from .metric_identifier import MetricIdentifier
from .metric_target import MetricTarget


@dataclass
class ObjectMetricSource:
    """ObjectMetricSource indicates how to scale on a metric describing a kubernetes object (for example, hits-per-second on an Ingress object)."""
    describedObject: Optional[CrossVersionObjectReference] = None
    metric: Optional[MetricIdentifier] = None
    target: Optional[MetricTarget] = None


__all__ = ["ObjectMetricSource"]