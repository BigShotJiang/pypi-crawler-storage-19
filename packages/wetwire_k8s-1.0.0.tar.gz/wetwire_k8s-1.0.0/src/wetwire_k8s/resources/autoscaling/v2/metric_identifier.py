'''MetricIdentifier resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class MetricIdentifier:
    """MetricIdentifier defines the name and optionally selector for a metric"""
    name: Optional[str] = None
    selector: Optional[LabelSelector] = None


__all__ = ["MetricIdentifier"]