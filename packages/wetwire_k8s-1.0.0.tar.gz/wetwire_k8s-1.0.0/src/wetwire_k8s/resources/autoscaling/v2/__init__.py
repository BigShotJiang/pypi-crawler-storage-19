'''Kubernetes autoscaling/v2 resources.'''

from .container_resource_metric_source import ContainerResourceMetricSource
from .container_resource_metric_status import ContainerResourceMetricStatus
from .cross_version_object_reference import CrossVersionObjectReference
from .external_metric_source import ExternalMetricSource
from .external_metric_status import ExternalMetricStatus
from .hpa_scaling_policy import HPAScalingPolicy
from .hpa_scaling_rules import HPAScalingRules
from .horizontal_pod_autoscaler import HorizontalPodAutoscaler
from .horizontal_pod_autoscaler_behavior import HorizontalPodAutoscalerBehavior
from .horizontal_pod_autoscaler_condition import HorizontalPodAutoscalerCondition
from .horizontal_pod_autoscaler_list import HorizontalPodAutoscalerList
from .horizontal_pod_autoscaler_spec import HorizontalPodAutoscalerSpec
from .horizontal_pod_autoscaler_status import HorizontalPodAutoscalerStatus
from .metric_identifier import MetricIdentifier
from .metric_spec import MetricSpec
from .metric_status import MetricStatus
from .metric_target import MetricTarget
from .metric_value_status import MetricValueStatus
from .object_metric_source import ObjectMetricSource
from .object_metric_status import ObjectMetricStatus
from .pods_metric_source import PodsMetricSource
from .pods_metric_status import PodsMetricStatus
from .resource_metric_source import ResourceMetricSource
from .resource_metric_status import ResourceMetricStatus

__all__ = ["ContainerResourceMetricSource", "ContainerResourceMetricStatus", "CrossVersionObjectReference", "ExternalMetricSource", "ExternalMetricStatus", "HPAScalingPolicy", "HPAScalingRules", "HorizontalPodAutoscaler", "HorizontalPodAutoscalerBehavior", "HorizontalPodAutoscalerCondition", "HorizontalPodAutoscalerList", "HorizontalPodAutoscalerSpec", "HorizontalPodAutoscalerStatus", "MetricIdentifier", "MetricSpec", "MetricStatus", "MetricTarget", "MetricValueStatus", "ObjectMetricSource", "ObjectMetricStatus", "PodsMetricSource", "PodsMetricStatus", "ResourceMetricSource", "ResourceMetricStatus"]