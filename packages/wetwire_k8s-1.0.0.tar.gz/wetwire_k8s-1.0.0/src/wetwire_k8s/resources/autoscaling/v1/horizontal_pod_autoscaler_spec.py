'''HorizontalPodAutoscalerSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cross_version_object_reference import CrossVersionObjectReference


@dataclass
class HorizontalPodAutoscalerSpec:
    """specification of a horizontal pod autoscaler."""
    maxReplicas: Optional[int] = None
    minReplicas: Optional[int] = None
    scaleTargetRef: Optional[CrossVersionObjectReference] = None
    targetCPUUtilizationPercentage: Optional[int] = None


__all__ = ["HorizontalPodAutoscalerSpec"]