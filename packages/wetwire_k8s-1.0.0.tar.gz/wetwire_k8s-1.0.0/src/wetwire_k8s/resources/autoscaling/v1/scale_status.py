'''ScaleStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ScaleStatus:
    """ScaleStatus represents the current status of a scale subresource."""
    replicas: Optional[int] = None
    selector: Optional[str] = None


__all__ = ["ScaleStatus"]