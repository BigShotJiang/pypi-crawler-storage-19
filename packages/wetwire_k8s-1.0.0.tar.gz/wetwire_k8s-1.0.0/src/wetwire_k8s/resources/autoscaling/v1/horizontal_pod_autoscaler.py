'''HorizontalPodAutoscaler resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .horizontal_pod_autoscaler_spec import HorizontalPodAutoscalerSpec
from .horizontal_pod_autoscaler_status import HorizontalPodAutoscalerStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class HorizontalPodAutoscaler:
    """configuration of a horizontal pod autoscaler."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[HorizontalPodAutoscalerSpec] = None
    status: Optional[HorizontalPodAutoscalerStatus] = None


__all__ = ["HorizontalPodAutoscaler"]