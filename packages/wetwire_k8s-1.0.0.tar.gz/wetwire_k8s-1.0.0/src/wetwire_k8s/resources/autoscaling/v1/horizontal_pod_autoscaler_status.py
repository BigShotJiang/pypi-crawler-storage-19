'''HorizontalPodAutoscalerStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class HorizontalPodAutoscalerStatus:
    """current status of a horizontal pod autoscaler"""
    currentCPUUtilizationPercentage: Optional[int] = None
    currentReplicas: Optional[int] = None
    desiredReplicas: Optional[int] = None
    lastScaleTime: Optional[Time] = None
    observedGeneration: Optional[int] = None


__all__ = ["HorizontalPodAutoscalerStatus"]