'''CrossVersionObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class CrossVersionObjectReference:
    """CrossVersionObjectReference contains enough information to let you identify the referred resource."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    name: Optional[str] = None


__all__ = ["CrossVersionObjectReference"]