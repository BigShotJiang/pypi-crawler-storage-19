'''ScaleSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ScaleSpec:
    """ScaleSpec describes the attributes of a scale subresource."""
    replicas: Optional[int] = None


__all__ = ["ScaleSpec"]