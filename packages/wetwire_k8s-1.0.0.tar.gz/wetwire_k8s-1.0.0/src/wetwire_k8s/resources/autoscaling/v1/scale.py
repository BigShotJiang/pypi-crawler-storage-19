'''Scale resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .scale_spec import ScaleSpec
from .scale_status import ScaleStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Scale:
    """Scale represents a scaling request for a resource."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ScaleSpec] = None
    status: Optional[ScaleStatus] = None


__all__ = ["Scale"]