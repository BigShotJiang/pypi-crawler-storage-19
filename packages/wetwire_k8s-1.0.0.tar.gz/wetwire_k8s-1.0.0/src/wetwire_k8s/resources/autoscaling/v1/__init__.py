'''Kubernetes autoscaling/v1 resources.'''

from .cross_version_object_reference import CrossVersionObjectReference
from .horizontal_pod_autoscaler import HorizontalPodAutoscaler
from .horizontal_pod_autoscaler_list import HorizontalPodAutoscalerList
from .horizontal_pod_autoscaler_spec import HorizontalPodAutoscalerSpec
from .horizontal_pod_autoscaler_status import HorizontalPodAutoscalerStatus
from .scale import Scale
from .scale_spec import ScaleSpec
from .scale_status import ScaleStatus

__all__ = ["CrossVersionObjectReference", "HorizontalPodAutoscaler", "HorizontalPodAutoscalerList", "HorizontalPodAutoscalerSpec", "HorizontalPodAutoscalerStatus", "Scale", "ScaleSpec", "ScaleStatus"]