"""Kubernetes resource definitions."""
