'''ForZone resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ForZone:
    """ForZone provides information about which zones should consume this endpoint."""
    name: Optional[str] = None


__all__ = ["ForZone"]