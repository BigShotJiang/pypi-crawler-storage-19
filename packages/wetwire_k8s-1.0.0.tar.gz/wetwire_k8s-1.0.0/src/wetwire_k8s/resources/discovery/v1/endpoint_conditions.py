'''EndpointConditions resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class EndpointConditions:
    """EndpointConditions represents the current condition of an endpoint."""
    ready: Optional[bool] = None
    serving: Optional[bool] = None
    terminating: Optional[bool] = None


__all__ = ["EndpointConditions"]