'''EndpointPort resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class EndpointPort:
    """EndpointPort represents a Port used by an EndpointSlice"""
    appProtocol: Optional[str] = None
    name: Optional[str] = None
    port: Optional[int] = None
    protocol: Optional[str] = None


__all__ = ["EndpointPort"]