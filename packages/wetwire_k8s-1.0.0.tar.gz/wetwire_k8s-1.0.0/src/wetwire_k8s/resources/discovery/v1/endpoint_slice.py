'''EndpointSlice resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoint import Endpoint
from .endpoint_port import EndpointPort
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class EndpointSlice:
    """EndpointSlice represents a subset of the endpoints that implement a service. For a given service there may be multiple EndpointSlice objects, selected by labels, which must be joined to produce the full set of endpoints."""
    addressType: Optional[str] = None
    apiVersion: Optional[str] = None
    endpoints: Optional[list[Endpoint]] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    ports: Optional[list[EndpointPort]] = None


__all__ = ["EndpointSlice"]