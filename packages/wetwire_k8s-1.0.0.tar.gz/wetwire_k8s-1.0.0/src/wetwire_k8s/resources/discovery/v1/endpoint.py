'''Endpoint resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoint_conditions import EndpointConditions
from .endpoint_hints import EndpointHints
from wetwire_k8s.resources.core.v1.object_reference import ObjectReference


@dataclass
class Endpoint:
    """Endpoint represents a single logical "backend" implementing a service."""
    addresses: Optional[list[str]] = None
    conditions: Optional[EndpointConditions] = None
    deprecatedTopology: Optional[dict[str, Any]] = None
    hints: Optional[EndpointHints] = None
    hostname: Optional[str] = None
    nodeName: Optional[str] = None
    targetRef: Optional[ObjectReference] = None
    zone: Optional[str] = None


__all__ = ["Endpoint"]