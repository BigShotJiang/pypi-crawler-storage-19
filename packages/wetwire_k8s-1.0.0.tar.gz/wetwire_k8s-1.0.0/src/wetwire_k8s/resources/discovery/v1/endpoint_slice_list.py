'''EndpointSliceList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoint_slice import EndpointSlice
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class EndpointSliceList:
    """EndpointSliceList represents a list of endpoint slices"""
    apiVersion: Optional[str] = None
    items: Optional[list[EndpointSlice]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["EndpointSliceList"]