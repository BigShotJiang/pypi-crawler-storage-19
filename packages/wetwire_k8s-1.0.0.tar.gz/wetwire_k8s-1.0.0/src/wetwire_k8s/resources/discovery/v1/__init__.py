'''Kubernetes discovery/v1 resources.'''

from .endpoint import Endpoint
from .endpoint_conditions import EndpointConditions
from .endpoint_hints import EndpointHints
from .endpoint_port import EndpointPort
from .endpoint_slice import EndpointSlice
from .endpoint_slice_list import EndpointSliceList
from .for_zone import ForZone

__all__ = ["Endpoint", "EndpointConditions", "EndpointHints", "EndpointPort", "EndpointSlice", "EndpointSliceList", "ForZone"]