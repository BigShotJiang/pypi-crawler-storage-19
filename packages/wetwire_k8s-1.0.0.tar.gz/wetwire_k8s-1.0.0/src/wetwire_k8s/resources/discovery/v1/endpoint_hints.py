'''EndpointHints resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .for_zone import ForZone


@dataclass
class EndpointHints:
    """EndpointHints provides hints describing how an endpoint should be consumed."""
    forZones: Optional[list[ForZone]] = None


__all__ = ["EndpointHints"]