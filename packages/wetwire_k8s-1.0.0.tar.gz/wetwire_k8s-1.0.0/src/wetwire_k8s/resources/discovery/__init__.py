"""Kubernetes discovery resources."""
