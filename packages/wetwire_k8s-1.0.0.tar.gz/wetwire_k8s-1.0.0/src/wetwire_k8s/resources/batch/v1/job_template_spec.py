'''JobTemplateSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .job_spec import JobSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class JobTemplateSpec:
    """JobTemplateSpec describes the data a Job should have when created from a template"""
    metadata: Optional[ObjectMeta] = None
    spec: Optional[JobSpec] = None


__all__ = ["JobTemplateSpec"]