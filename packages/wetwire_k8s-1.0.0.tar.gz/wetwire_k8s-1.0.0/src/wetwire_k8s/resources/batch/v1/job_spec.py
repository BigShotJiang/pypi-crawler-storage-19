'''JobSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_failure_policy import PodFailurePolicy
from .success_policy import SuccessPolicy
from wetwire_k8s.resources.core.v1.pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class JobSpec:
    """JobSpec describes how the job execution will look like."""
    activeDeadlineSeconds: Optional[int] = None
    backoffLimit: Optional[int] = None
    backoffLimitPerIndex: Optional[int] = None
    completionMode: Optional[str] = None
    completions: Optional[int] = None
    managedBy: Optional[str] = None
    manualSelector: Optional[bool] = None
    maxFailedIndexes: Optional[int] = None
    parallelism: Optional[int] = None
    podFailurePolicy: Optional[PodFailurePolicy] = None
    podReplacementPolicy: Optional[str] = None
    selector: Optional[LabelSelector] = None
    successPolicy: Optional[SuccessPolicy] = None
    suspend: Optional[bool] = None
    template: Optional[PodTemplateSpec] = None
    ttlSecondsAfterFinished: Optional[int] = None


__all__ = ["JobSpec"]