'''CronJobSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .job_template_spec import JobTemplateSpec


@dataclass
class CronJobSpec:
    """CronJobSpec describes how the job execution will look like and when it will actually run."""
    concurrencyPolicy: Optional[str] = None
    failedJobsHistoryLimit: Optional[int] = None
    jobTemplate: Optional[JobTemplateSpec] = None
    schedule: Optional[str] = None
    startingDeadlineSeconds: Optional[int] = None
    successfulJobsHistoryLimit: Optional[int] = None
    suspend: Optional[bool] = None
    timeZone: Optional[str] = None


__all__ = ["CronJobSpec"]