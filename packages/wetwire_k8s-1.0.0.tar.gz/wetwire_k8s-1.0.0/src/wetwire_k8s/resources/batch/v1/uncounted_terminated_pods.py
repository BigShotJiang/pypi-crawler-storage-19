'''UncountedTerminatedPods resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class UncountedTerminatedPods:
    """UncountedTerminatedPods holds UIDs of Pods that have terminated but haven't been accounted in Job status counters."""
    failed: Optional[list[str]] = None
    succeeded: Optional[list[str]] = None


__all__ = ["UncountedTerminatedPods"]