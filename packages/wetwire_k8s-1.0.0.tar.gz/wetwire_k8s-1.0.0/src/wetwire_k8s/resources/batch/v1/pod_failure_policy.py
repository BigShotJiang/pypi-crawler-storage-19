'''PodFailurePolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_failure_policy_rule import PodFailurePolicyRule


@dataclass
class PodFailurePolicy:
    """PodFailurePolicy describes how failed pods influence the backoffLimit."""
    rules: Optional[list[PodFailurePolicyRule]] = None


__all__ = ["PodFailurePolicy"]