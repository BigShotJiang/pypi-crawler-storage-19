'''SuccessPolicyRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SuccessPolicyRule:
    """SuccessPolicyRule describes rule for declaring a Job as succeeded. Each rule must have at least one of the "succeededIndexes" or "succeededCount" specified."""
    succeededCount: Optional[int] = None
    succeededIndexes: Optional[str] = None


__all__ = ["SuccessPolicyRule"]