'''PodFailurePolicyOnPodConditionsPattern resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodFailurePolicyOnPodConditionsPattern:
    """PodFailurePolicyOnPodConditionsPattern describes a pattern for matching an actual pod condition type."""
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["PodFailurePolicyOnPodConditionsPattern"]