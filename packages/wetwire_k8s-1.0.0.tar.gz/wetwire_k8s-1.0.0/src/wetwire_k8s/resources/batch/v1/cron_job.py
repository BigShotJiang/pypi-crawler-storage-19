'''CronJob resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cron_job_spec import CronJobSpec
from .cron_job_status import CronJobStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class CronJob:
    """CronJob represents the configuration of a single cron job."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[CronJobSpec] = None
    status: Optional[CronJobStatus] = None


__all__ = ["CronJob"]