'''JobStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .job_condition import JobCondition
from .uncounted_terminated_pods import UncountedTerminatedPods
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class JobStatus:
    """JobStatus represents the current state of a Job."""
    active: Optional[int] = None
    completedIndexes: Optional[str] = None
    completionTime: Optional[Time] = None
    conditions: Optional[list[JobCondition]] = None
    failed: Optional[int] = None
    failedIndexes: Optional[str] = None
    ready: Optional[int] = None
    startTime: Optional[Time] = None
    succeeded: Optional[int] = None
    terminating: Optional[int] = None
    uncountedTerminatedPods: Optional[UncountedTerminatedPods] = None


__all__ = ["JobStatus"]