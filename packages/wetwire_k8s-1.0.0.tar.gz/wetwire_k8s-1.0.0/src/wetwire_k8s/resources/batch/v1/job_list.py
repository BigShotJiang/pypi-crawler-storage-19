'''JobList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .job import Job
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class JobList:
    """JobList is a collection of jobs."""
    apiVersion: Optional[str] = None
    items: Optional[list[Job]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["JobList"]