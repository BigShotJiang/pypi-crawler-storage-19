'''CronJobList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cron_job import CronJob
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class CronJobList:
    """CronJobList is a collection of cron jobs."""
    apiVersion: Optional[str] = None
    items: Optional[list[CronJob]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["CronJobList"]