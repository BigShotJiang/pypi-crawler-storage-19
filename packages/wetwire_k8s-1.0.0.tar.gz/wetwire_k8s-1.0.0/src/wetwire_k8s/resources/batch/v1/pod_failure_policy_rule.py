'''PodFailurePolicyRule resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_failure_policy_on_exit_codes_requirement import PodFailurePolicyOnExitCodesRequirement
from .pod_failure_policy_on_pod_conditions_pattern import PodFailurePolicyOnPodConditionsPattern


@dataclass
class PodFailurePolicyRule:
    """PodFailurePolicyRule describes how a pod failure is handled when the requirements are met. One of onExitCodes and onPodConditions, but not both, can be used in each rule."""
    action: Optional[str] = None
    onExitCodes: Optional[PodFailurePolicyOnExitCodesRequirement] = None
    onPodConditions: Optional[list[PodFailurePolicyOnPodConditionsPattern]] = None


__all__ = ["PodFailurePolicyRule"]