'''Job resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .job_spec import JobSpec
from .job_status import JobStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Job:
    """Job represents the configuration of a single job."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[JobSpec] = None
    status: Optional[JobStatus] = None


__all__ = ["Job"]