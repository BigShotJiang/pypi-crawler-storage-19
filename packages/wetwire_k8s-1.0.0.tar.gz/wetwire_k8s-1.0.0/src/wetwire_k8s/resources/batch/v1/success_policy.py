'''SuccessPolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .success_policy_rule import SuccessPolicyRule


@dataclass
class SuccessPolicy:
    """SuccessPolicy describes when a Job can be declared as succeeded based on the success of some indexes."""
    rules: Optional[list[SuccessPolicyRule]] = None


__all__ = ["SuccessPolicy"]