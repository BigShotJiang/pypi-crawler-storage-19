'''CronJobStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.core.v1.object_reference import ObjectReference
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class CronJobStatus:
    """CronJobStatus represents the current state of a cron job."""
    active: Optional[list[ObjectReference]] = None
    lastScheduleTime: Optional[Time] = None
    lastSuccessfulTime: Optional[Time] = None


__all__ = ["CronJobStatus"]