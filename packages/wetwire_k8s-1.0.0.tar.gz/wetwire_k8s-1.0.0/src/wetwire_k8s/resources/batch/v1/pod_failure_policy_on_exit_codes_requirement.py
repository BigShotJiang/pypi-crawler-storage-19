'''PodFailurePolicyOnExitCodesRequirement resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodFailurePolicyOnExitCodesRequirement:
    """PodFailurePolicyOnExitCodesRequirement describes the requirement for handling a failed pod based on its container exit codes. In particular, it lookups the .state.terminated.exitCode for each app container and init container status, represented by the .status.containerStatuses and .status.initContainerStatuses fields in the Pod status, respectively. Containers completed with success (exit code 0) are excluded from the requirement check."""
    containerName: Optional[str] = None
    operator: Optional[str] = None
    values: Optional[list[int]] = None


__all__ = ["PodFailurePolicyOnExitCodesRequirement"]