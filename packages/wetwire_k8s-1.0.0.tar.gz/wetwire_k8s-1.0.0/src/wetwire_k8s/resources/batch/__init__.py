"""Kubernetes batch resources."""
