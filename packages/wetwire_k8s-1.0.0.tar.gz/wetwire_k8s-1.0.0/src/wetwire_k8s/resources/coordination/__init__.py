"""Kubernetes coordination resources."""
