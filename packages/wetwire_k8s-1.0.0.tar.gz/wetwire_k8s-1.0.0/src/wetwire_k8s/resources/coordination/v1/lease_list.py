'''LeaseList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .lease import Lease
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class LeaseList:
    """LeaseList is a list of Lease objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[Lease]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["LeaseList"]