'''Kubernetes coordination/v1 resources.'''

from .lease import Lease
from .lease_list import LeaseList
from .lease_spec import LeaseSpec

__all__ = ["Lease", "LeaseList", "LeaseSpec"]