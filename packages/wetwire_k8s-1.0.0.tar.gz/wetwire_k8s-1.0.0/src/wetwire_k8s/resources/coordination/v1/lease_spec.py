'''LeaseSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.micro_time import MicroTime


@dataclass
class LeaseSpec:
    """LeaseSpec is a specification of a Lease."""
    acquireTime: Optional[MicroTime] = None
    holderIdentity: Optional[str] = None
    leaseDurationSeconds: Optional[int] = None
    leaseTransitions: Optional[int] = None
    renewTime: Optional[MicroTime] = None


__all__ = ["LeaseSpec"]