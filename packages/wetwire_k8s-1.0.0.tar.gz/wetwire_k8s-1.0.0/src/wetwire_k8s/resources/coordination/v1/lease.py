'''Lease resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .lease_spec import LeaseSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Lease:
    """Lease defines a lease concept."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[LeaseSpec] = None


__all__ = ["Lease"]