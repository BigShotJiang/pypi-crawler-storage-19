"""Kubernetes core resources."""
