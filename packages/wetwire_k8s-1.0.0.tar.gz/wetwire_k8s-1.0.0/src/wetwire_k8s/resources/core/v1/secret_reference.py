'''SecretReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SecretReference:
    """SecretReference represents a Secret Reference. It has enough information to retrieve secret in any namespace"""
    name: Optional[str] = None
    namespace: Optional[str] = None


__all__ = ["SecretReference"]