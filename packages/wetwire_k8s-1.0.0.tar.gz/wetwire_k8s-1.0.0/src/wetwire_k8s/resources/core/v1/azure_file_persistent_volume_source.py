'''AzureFilePersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AzureFilePersistentVolumeSource:
    """AzureFile represents an Azure File Service mount on the host and bind mount to the pod."""
    readOnly: Optional[bool] = None
    secretName: Optional[str] = None
    secretNamespace: Optional[str] = None
    shareName: Optional[str] = None


__all__ = ["AzureFilePersistentVolumeSource"]