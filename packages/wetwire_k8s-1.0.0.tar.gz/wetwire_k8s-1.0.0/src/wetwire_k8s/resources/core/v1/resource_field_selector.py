'''ResourceFieldSelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.quantity import Quantity


@dataclass
class ResourceFieldSelector:
    """ResourceFieldSelector represents container resources (cpu, memory) and their output format"""
    containerName: Optional[str] = None
    divisor: Optional[Quantity] = None
    resource: Optional[str] = None


__all__ = ["ResourceFieldSelector"]