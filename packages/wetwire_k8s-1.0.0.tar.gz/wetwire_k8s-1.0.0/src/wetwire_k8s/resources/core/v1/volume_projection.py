'''VolumeProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .cluster_trust_bundle_projection import ClusterTrustBundleProjection
from .config_map_projection import ConfigMapProjection
from .downward_api_projection import DownwardAPIProjection
from .secret_projection import SecretProjection
from .service_account_token_projection import ServiceAccountTokenProjection


@dataclass
class VolumeProjection:
    """Projection that may be projected along with other supported volume types"""
    clusterTrustBundle: Optional[ClusterTrustBundleProjection] = None
    configMap: Optional[ConfigMapProjection] = None
    downwardAPI: Optional[DownwardAPIProjection] = None
    secret: Optional[SecretProjection] = None
    serviceAccountToken: Optional[ServiceAccountTokenProjection] = None


__all__ = ["VolumeProjection"]