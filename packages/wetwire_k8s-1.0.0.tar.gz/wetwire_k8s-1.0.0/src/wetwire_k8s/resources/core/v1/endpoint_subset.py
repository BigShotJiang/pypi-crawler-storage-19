'''EndpointSubset resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoint_address import EndpointAddress
from .endpoint_port import EndpointPort


@dataclass
class EndpointSubset:
    """EndpointSubset is a group of addresses with a common set of ports. The expanded set of endpoints is the Cartesian product of Addresses x Ports. For example, given:

	{
	  Addresses: [{"ip": "10.10.1.1"}, {"ip": "10.10.2.2"}],
	  Ports:     [{"name": "a", "port": 8675}, {"name": "b", "port": 309}]
	}

The resulting set of endpoints can be viewed as:

	a: [ 10.10.1.1:8675, 10.10.2.2:8675 ],
	b: [ 10.10.1.1:309, 10.10.2.2:309 ]"""
    addresses: Optional[list[EndpointAddress]] = None
    notReadyAddresses: Optional[list[EndpointAddress]] = None
    ports: Optional[list[EndpointPort]] = None


__all__ = ["EndpointSubset"]