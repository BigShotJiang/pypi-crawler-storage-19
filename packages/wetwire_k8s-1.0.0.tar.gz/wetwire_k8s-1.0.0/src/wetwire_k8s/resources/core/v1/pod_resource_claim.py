'''PodResourceClaim resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .claim_source import ClaimSource


@dataclass
class PodResourceClaim:
    """PodResourceClaim references exactly one ResourceClaim through a ClaimSource. It adds a name to it that uniquely identifies the ResourceClaim inside the Pod. Containers that need access to the ResourceClaim reference it with this name."""
    name: Optional[str] = None
    source: Optional[ClaimSource] = None


__all__ = ["PodResourceClaim"]