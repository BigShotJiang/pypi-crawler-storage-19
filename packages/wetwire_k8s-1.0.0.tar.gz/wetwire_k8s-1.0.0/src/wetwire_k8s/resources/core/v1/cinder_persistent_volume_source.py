'''CinderPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret_reference import SecretReference


@dataclass
class CinderPersistentVolumeSource:
    """Represents a cinder volume resource in Openstack. A Cinder volume must exist before mounting to a container. The volume must also be in the same region as the kubelet. Cinder volumes support ownership management and SELinux relabeling."""
    fsType: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[SecretReference] = None
    volumeID: Optional[str] = None


__all__ = ["CinderPersistentVolumeSource"]