'''NodeList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node import Node
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class NodeList:
    """NodeList is the whole list of all Nodes which have been registered with master."""
    apiVersion: Optional[str] = None
    items: Optional[list[Node]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["NodeList"]