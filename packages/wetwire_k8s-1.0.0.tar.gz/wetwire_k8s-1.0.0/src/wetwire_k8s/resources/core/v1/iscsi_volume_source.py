'''ISCSIVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class ISCSIVolumeSource:
    """Represents an ISCSI disk. ISCSI volumes can only be mounted as read/write once. ISCSI volumes support ownership management and SELinux relabeling."""
    chapAuthDiscovery: Optional[bool] = None
    chapAuthSession: Optional[bool] = None
    fsType: Optional[str] = None
    initiatorName: Optional[str] = None
    iqn: Optional[str] = None
    iscsiInterface: Optional[str] = None
    lun: Optional[int] = None
    portals: Optional[list[str]] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[LocalObjectReference] = None
    targetPortal: Optional[str] = None


__all__ = ["ISCSIVolumeSource"]