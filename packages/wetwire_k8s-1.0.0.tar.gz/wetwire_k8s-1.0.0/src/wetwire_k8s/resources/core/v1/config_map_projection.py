'''ConfigMapProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .key_to_path import KeyToPath


@dataclass
class ConfigMapProjection:
    """Adapts a ConfigMap into a projected volume.

The contents of the target ConfigMap's Data field will be presented in a projected volume as files using the keys in the Data field as the file names, unless the items element is populated with specific mappings of keys to paths. Note that this is identical to a configmap volume source without the default mode."""
    items: Optional[list[KeyToPath]] = None
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["ConfigMapProjection"]