'''TopologySpreadConstraint resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class TopologySpreadConstraint:
    """TopologySpreadConstraint specifies how to spread matching pods among the given topology."""
    labelSelector: Optional[LabelSelector] = None
    matchLabelKeys: Optional[list[str]] = None
    maxSkew: Optional[int] = None
    minDomains: Optional[int] = None
    nodeAffinityPolicy: Optional[str] = None
    nodeTaintsPolicy: Optional[str] = None
    topologyKey: Optional[str] = None
    whenUnsatisfiable: Optional[str] = None


__all__ = ["TopologySpreadConstraint"]