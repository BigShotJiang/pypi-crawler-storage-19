'''PhotonPersistentDiskVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PhotonPersistentDiskVolumeSource:
    """Represents a Photon Controller persistent disk resource."""
    fsType: Optional[str] = None
    pdID: Optional[str] = None


__all__ = ["PhotonPersistentDiskVolumeSource"]