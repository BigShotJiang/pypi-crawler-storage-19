'''NodeSelectorTerm resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_selector_requirement import NodeSelectorRequirement


@dataclass
class NodeSelectorTerm:
    """A null or empty node selector term matches no objects. The requirements of them are ANDed. The TopologySelectorTerm type implements a subset of the NodeSelectorTerm."""
    matchExpressions: Optional[list[NodeSelectorRequirement]] = None
    matchFields: Optional[list[NodeSelectorRequirement]] = None


__all__ = ["NodeSelectorTerm"]