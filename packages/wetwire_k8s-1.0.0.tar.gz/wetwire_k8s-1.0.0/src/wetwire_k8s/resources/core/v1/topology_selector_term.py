'''TopologySelectorTerm resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .topology_selector_label_requirement import TopologySelectorLabelRequirement


@dataclass
class TopologySelectorTerm:
    """A topology selector term represents the result of label queries. A null or empty topology selector term matches no objects. The requirements of them are ANDed. It provides a subset of functionality as NodeSelectorTerm. This is an alpha feature and may change in the future."""
    matchLabelExpressions: Optional[list[TopologySelectorLabelRequirement]] = None


__all__ = ["TopologySelectorTerm"]