'''VolumeMount resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class VolumeMount:
    """VolumeMount describes a mounting of a Volume within a container."""
    mountPath: Optional[str] = None
    mountPropagation: Optional[str] = None
    name: Optional[str] = None
    readOnly: Optional[bool] = None
    recursiveReadOnly: Optional[str] = None
    subPath: Optional[str] = None
    subPathExpr: Optional[str] = None


__all__ = ["VolumeMount"]