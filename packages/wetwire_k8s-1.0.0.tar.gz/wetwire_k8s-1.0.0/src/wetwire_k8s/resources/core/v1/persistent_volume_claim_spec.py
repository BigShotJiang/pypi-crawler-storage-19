'''PersistentVolumeClaimSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .typed_local_object_reference import TypedLocalObjectReference
from .typed_object_reference import TypedObjectReference
from .volume_resource_requirements import VolumeResourceRequirements
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class PersistentVolumeClaimSpec:
    """PersistentVolumeClaimSpec describes the common attributes of storage devices and allows a Source for provider-specific attributes"""
    accessModes: Optional[list[str]] = None
    dataSource: Optional[TypedLocalObjectReference] = None
    dataSourceRef: Optional[TypedObjectReference] = None
    resources: Optional[VolumeResourceRequirements] = None
    selector: Optional[LabelSelector] = None
    storageClassName: Optional[str] = None
    volumeAttributesClassName: Optional[str] = None
    volumeMode: Optional[str] = None
    volumeName: Optional[str] = None


__all__ = ["PersistentVolumeClaimSpec"]