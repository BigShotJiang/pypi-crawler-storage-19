'''PodList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod import Pod
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class PodList:
    """PodList is a list of Pods."""
    apiVersion: Optional[str] = None
    items: Optional[list[Pod]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["PodList"]