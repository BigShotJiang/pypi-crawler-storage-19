'''FlexPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret_reference import SecretReference


@dataclass
class FlexPersistentVolumeSource:
    """FlexPersistentVolumeSource represents a generic persistent volume resource that is provisioned/attached using an exec based plugin."""
    driver: Optional[str] = None
    fsType: Optional[str] = None
    options: Optional[dict[str, Any]] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[SecretReference] = None


__all__ = ["FlexPersistentVolumeSource"]