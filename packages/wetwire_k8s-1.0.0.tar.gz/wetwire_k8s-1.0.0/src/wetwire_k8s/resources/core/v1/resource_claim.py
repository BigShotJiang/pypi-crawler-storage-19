'''ResourceClaim resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ResourceClaim:
    """ResourceClaim references one entry in PodSpec.ResourceClaims."""
    name: Optional[str] = None


__all__ = ["ResourceClaim"]