'''ComponentCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ComponentCondition:
    """Information about the condition of a component."""
    error: Optional[str] = None
    message: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["ComponentCondition"]