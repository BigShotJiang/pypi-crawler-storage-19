'''SecretVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .key_to_path import KeyToPath


@dataclass
class SecretVolumeSource:
    """Adapts a Secret into a volume.

The contents of the target Secret's Data field will be presented in a volume as files using the keys in the Data field as the file names. Secret volumes support ownership management and SELinux relabeling."""
    defaultMode: Optional[int] = None
    items: Optional[list[KeyToPath]] = None
    optional: Optional[bool] = None
    secretName: Optional[str] = None


__all__ = ["SecretVolumeSource"]