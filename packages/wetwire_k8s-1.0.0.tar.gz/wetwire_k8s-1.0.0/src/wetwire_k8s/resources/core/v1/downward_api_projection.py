'''DownwardAPIProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .downward_api_volume_file import DownwardAPIVolumeFile


@dataclass
class DownwardAPIProjection:
    """Represents downward API info for projecting into a projected volume. Note that this is identical to a downwardAPI volume source without the default mode."""
    items: Optional[list[DownwardAPIVolumeFile]] = None


__all__ = ["DownwardAPIProjection"]