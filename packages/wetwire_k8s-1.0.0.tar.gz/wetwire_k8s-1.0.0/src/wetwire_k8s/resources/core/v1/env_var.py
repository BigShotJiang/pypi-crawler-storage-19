'''EnvVar resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .env_var_source import EnvVarSource


@dataclass
class EnvVar:
    """EnvVar represents an environment variable present in a Container."""
    name: Optional[str] = None
    value: Optional[str] = None
    valueFrom: Optional[EnvVarSource] = None


__all__ = ["EnvVar"]