'''Binding resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .object_reference import ObjectReference
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Binding:
    """Binding ties one object to another; for example, a pod is bound to a node by a scheduler. Deprecated in 1.7, please use the bindings subresource of pods instead."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    target: Optional[ObjectReference] = None


__all__ = ["Binding"]