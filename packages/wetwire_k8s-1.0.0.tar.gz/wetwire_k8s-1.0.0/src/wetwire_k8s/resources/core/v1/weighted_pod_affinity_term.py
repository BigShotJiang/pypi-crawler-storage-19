'''WeightedPodAffinityTerm resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_affinity_term import PodAffinityTerm


@dataclass
class WeightedPodAffinityTerm:
    """The weights of all of the matched WeightedPodAffinityTerm fields are added per-node to find the most preferred node(s)"""
    podAffinityTerm: Optional[PodAffinityTerm] = None
    weight: Optional[int] = None


__all__ = ["WeightedPodAffinityTerm"]