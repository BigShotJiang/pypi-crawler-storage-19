'''EphemeralVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume_claim_template import PersistentVolumeClaimTemplate


@dataclass
class EphemeralVolumeSource:
    """Represents an ephemeral volume that is handled by a normal storage driver."""
    volumeClaimTemplate: Optional[PersistentVolumeClaimTemplate] = None


__all__ = ["EphemeralVolumeSource"]