'''ProjectedVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .volume_projection import VolumeProjection


@dataclass
class ProjectedVolumeSource:
    """Represents a projected volume source"""
    defaultMode: Optional[int] = None
    sources: Optional[list[VolumeProjection]] = None


__all__ = ["ProjectedVolumeSource"]