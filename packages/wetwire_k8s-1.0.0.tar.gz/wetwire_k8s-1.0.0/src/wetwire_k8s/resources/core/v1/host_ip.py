'''HostIP resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HostIP:
    """HostIP represents a single IP address allocated to the host."""
    ip: Optional[str] = None


__all__ = ["HostIP"]