'''RBDPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret_reference import SecretReference


@dataclass
class RBDPersistentVolumeSource:
    """Represents a Rados Block Device mount that lasts the lifetime of a pod. RBD volumes support ownership management and SELinux relabeling."""
    fsType: Optional[str] = None
    image: Optional[str] = None
    keyring: Optional[str] = None
    monitors: Optional[list[str]] = None
    pool: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[SecretReference] = None
    user: Optional[str] = None


__all__ = ["RBDPersistentVolumeSource"]