'''DownwardAPIVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .downward_api_volume_file import DownwardAPIVolumeFile


@dataclass
class DownwardAPIVolumeSource:
    """DownwardAPIVolumeSource represents a volume containing downward API info. Downward API volumes support ownership management and SELinux relabeling."""
    defaultMode: Optional[int] = None
    items: Optional[list[DownwardAPIVolumeFile]] = None


__all__ = ["DownwardAPIVolumeSource"]