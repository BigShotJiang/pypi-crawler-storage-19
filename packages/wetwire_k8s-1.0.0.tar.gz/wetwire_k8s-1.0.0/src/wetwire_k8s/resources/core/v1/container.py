'''Container resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_port import ContainerPort
from .container_resize_policy import ContainerResizePolicy
from .env_from_source import EnvFromSource
from .env_var import EnvVar
from .lifecycle import Lifecycle
from .probe import Probe
from .resource_requirements import ResourceRequirements
from .security_context import SecurityContext
from .volume_device import VolumeDevice
from .volume_mount import VolumeMount


@dataclass
class Container:
    """A single application container that you want to run within a pod."""
    args: Optional[list[str]] = None
    command: Optional[list[str]] = None
    env: Optional[list[EnvVar]] = None
    envFrom: Optional[list[EnvFromSource]] = None
    image: Optional[str] = None
    imagePullPolicy: Optional[str] = None
    lifecycle: Optional[Lifecycle] = None
    livenessProbe: Optional[Probe] = None
    name: Optional[str] = None
    ports: Optional[list[ContainerPort]] = None
    readinessProbe: Optional[Probe] = None
    resizePolicy: Optional[list[ContainerResizePolicy]] = None
    resources: Optional[ResourceRequirements] = None
    restartPolicy: Optional[str] = None
    securityContext: Optional[SecurityContext] = None
    startupProbe: Optional[Probe] = None
    stdin: Optional[bool] = None
    stdinOnce: Optional[bool] = None
    terminationMessagePath: Optional[str] = None
    terminationMessagePolicy: Optional[str] = None
    tty: Optional[bool] = None
    volumeDevices: Optional[list[VolumeDevice]] = None
    volumeMounts: Optional[list[VolumeMount]] = None
    workingDir: Optional[str] = None


__all__ = ["Container"]