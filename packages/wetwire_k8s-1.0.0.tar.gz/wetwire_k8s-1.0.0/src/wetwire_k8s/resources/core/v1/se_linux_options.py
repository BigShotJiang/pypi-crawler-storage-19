'''SELinuxOptions resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SELinuxOptions:
    """SELinuxOptions are the labels to be applied to the container"""
    level: Optional[str] = None
    role: Optional[str] = None
    type: Optional[str] = None
    user: Optional[str] = None


__all__ = ["SELinuxOptions"]