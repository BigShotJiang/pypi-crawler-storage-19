'''ResourceRequirements resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .resource_claim import ResourceClaim


@dataclass
class ResourceRequirements:
    """ResourceRequirements describes the compute resource requirements."""
    claims: Optional[list[ResourceClaim]] = None
    limits: Optional[dict[str, Any]] = None
    requests: Optional[dict[str, Any]] = None


__all__ = ["ResourceRequirements"]