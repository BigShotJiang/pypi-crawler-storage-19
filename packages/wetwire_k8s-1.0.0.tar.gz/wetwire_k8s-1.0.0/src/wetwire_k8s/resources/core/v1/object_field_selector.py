'''ObjectFieldSelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ObjectFieldSelector:
    """ObjectFieldSelector selects an APIVersioned field of an object."""
    apiVersion: Optional[str] = None
    fieldPath: Optional[str] = None


__all__ = ["ObjectFieldSelector"]