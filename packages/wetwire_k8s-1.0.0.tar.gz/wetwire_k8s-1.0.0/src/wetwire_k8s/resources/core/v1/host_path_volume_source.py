'''HostPathVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HostPathVolumeSource:
    """Represents a host path mapped into a pod. Host path volumes do not support ownership management or SELinux relabeling."""
    path: Optional[str] = None
    type: Optional[str] = None


__all__ = ["HostPathVolumeSource"]