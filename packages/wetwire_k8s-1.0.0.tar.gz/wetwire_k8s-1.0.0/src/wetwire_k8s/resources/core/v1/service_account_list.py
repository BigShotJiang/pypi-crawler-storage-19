'''ServiceAccountList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .service_account import ServiceAccount
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ServiceAccountList:
    """ServiceAccountList is a list of ServiceAccount objects"""
    apiVersion: Optional[str] = None
    items: Optional[list[ServiceAccount]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ServiceAccountList"]