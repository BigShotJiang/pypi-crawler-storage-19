'''PersistentVolumeClaimList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume_claim import PersistentVolumeClaim
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class PersistentVolumeClaimList:
    """PersistentVolumeClaimList is a list of PersistentVolumeClaim items."""
    apiVersion: Optional[str] = None
    items: Optional[list[PersistentVolumeClaim]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["PersistentVolumeClaimList"]