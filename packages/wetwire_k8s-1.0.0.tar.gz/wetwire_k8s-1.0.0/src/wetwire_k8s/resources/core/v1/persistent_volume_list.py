'''PersistentVolumeList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume import PersistentVolume
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class PersistentVolumeList:
    """PersistentVolumeList is a list of PersistentVolume items."""
    apiVersion: Optional[str] = None
    items: Optional[list[PersistentVolume]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["PersistentVolumeList"]