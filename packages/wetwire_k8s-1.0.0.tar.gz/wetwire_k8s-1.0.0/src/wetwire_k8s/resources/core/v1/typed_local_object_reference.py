'''TypedLocalObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TypedLocalObjectReference:
    """TypedLocalObjectReference contains enough information to let you locate the typed referenced object inside the same namespace."""
    apiGroup: Optional[str] = None
    kind: Optional[str] = None
    name: Optional[str] = None


__all__ = ["TypedLocalObjectReference"]