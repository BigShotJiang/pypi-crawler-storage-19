'''ExecAction resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ExecAction:
    """ExecAction describes a "run in container" action."""
    command: Optional[list[str]] = None


__all__ = ["ExecAction"]