'''ObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ObjectReference:
    """ObjectReference contains enough information to let you inspect or modify the referred object."""
    apiVersion: Optional[str] = None
    fieldPath: Optional[str] = None
    kind: Optional[str] = None
    name: Optional[str] = None
    namespace: Optional[str] = None
    resourceVersion: Optional[str] = None
    uid: Optional[str] = None


__all__ = ["ObjectReference"]