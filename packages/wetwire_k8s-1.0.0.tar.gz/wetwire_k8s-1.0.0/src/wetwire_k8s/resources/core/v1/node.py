'''Node resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_spec import NodeSpec
from .node_status import NodeStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Node:
    """Node is a worker node in Kubernetes. Each node will have a unique identifier in the cache (i.e. in etcd)."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[NodeSpec] = None
    status: Optional[NodeStatus] = None


__all__ = ["Node"]