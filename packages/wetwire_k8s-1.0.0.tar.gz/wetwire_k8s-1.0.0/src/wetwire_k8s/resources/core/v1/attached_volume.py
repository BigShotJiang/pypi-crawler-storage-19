'''AttachedVolume resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AttachedVolume:
    """AttachedVolume describes a volume attached to a node"""
    devicePath: Optional[str] = None
    name: Optional[str] = None


__all__ = ["AttachedVolume"]