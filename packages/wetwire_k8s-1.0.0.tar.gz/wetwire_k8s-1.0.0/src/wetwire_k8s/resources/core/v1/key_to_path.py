'''KeyToPath resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class KeyToPath:
    """Maps a string key to a path within a volume."""
    key: Optional[str] = None
    mode: Optional[int] = None
    path: Optional[str] = None


__all__ = ["KeyToPath"]