'''Taint resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class Taint:
    """The node this Taint is attached to has the "effect" on any pod that does not tolerate the Taint."""
    effect: Optional[str] = None
    key: Optional[str] = None
    timeAdded: Optional[Time] = None
    value: Optional[str] = None


__all__ = ["Taint"]