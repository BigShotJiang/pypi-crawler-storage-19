'''ContainerStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_state import ContainerState
from .resource_requirements import ResourceRequirements
from .volume_mount_status import VolumeMountStatus


@dataclass
class ContainerStatus:
    """ContainerStatus contains details for the current status of this container."""
    allocatedResources: Optional[dict[str, Any]] = None
    containerID: Optional[str] = None
    image: Optional[str] = None
    imageID: Optional[str] = None
    lastState: Optional[ContainerState] = None
    name: Optional[str] = None
    ready: Optional[bool] = None
    resources: Optional[ResourceRequirements] = None
    restartCount: Optional[int] = None
    started: Optional[bool] = None
    state: Optional[ContainerState] = None
    volumeMounts: Optional[list[VolumeMountStatus]] = None


__all__ = ["ContainerStatus"]