'''PodIP resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodIP:
    """PodIP represents a single IP address allocated to the pod."""
    ip: Optional[str] = None


__all__ = ["PodIP"]