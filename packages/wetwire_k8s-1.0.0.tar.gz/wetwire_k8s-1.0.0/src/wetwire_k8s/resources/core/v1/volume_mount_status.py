'''VolumeMountStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class VolumeMountStatus:
    """VolumeMountStatus shows status of volume mounts."""
    mountPath: Optional[str] = None
    name: Optional[str] = None
    readOnly: Optional[bool] = None
    recursiveReadOnly: Optional[str] = None


__all__ = ["VolumeMountStatus"]