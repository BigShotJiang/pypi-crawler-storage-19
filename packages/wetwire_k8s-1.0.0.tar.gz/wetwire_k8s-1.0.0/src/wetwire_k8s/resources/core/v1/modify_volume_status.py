'''ModifyVolumeStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ModifyVolumeStatus:
    """ModifyVolumeStatus represents the status object of ControllerModifyVolume operation"""
    status: Optional[str] = None
    targetVolumeAttributesClassName: Optional[str] = None


__all__ = ["ModifyVolumeStatus"]