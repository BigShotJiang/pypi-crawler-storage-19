'''PodDNSConfig resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_dns_config_option import PodDNSConfigOption


@dataclass
class PodDNSConfig:
    """PodDNSConfig defines the DNS parameters of a pod in addition to those generated from DNSPolicy."""
    nameservers: Optional[list[str]] = None
    options: Optional[list[PodDNSConfigOption]] = None
    searches: Optional[list[str]] = None


__all__ = ["PodDNSConfig"]