'''Endpoints resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoint_subset import EndpointSubset
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Endpoints:
    """Endpoints is a collection of endpoints that implement the actual service. Example:

	 Name: "mysvc",
	 Subsets: [
	   {
	     Addresses: [{"ip": "10.10.1.1"}, {"ip": "10.10.2.2"}],
	     Ports: [{"name": "a", "port": 8675}, {"name": "b", "port": 309}]
	   },
	   {
	     Addresses: [{"ip": "10.10.3.3"}],
	     Ports: [{"name": "a", "port": 93}, {"name": "b", "port": 76}]
	   },
	]"""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    subsets: Optional[list[EndpointSubset]] = None


__all__ = ["Endpoints"]