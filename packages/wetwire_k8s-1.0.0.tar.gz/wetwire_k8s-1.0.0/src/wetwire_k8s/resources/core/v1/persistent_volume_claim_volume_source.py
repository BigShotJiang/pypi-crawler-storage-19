'''PersistentVolumeClaimVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PersistentVolumeClaimVolumeSource:
    """PersistentVolumeClaimVolumeSource references the user's PVC in the same namespace. This volume finds the bound PV and mounts that volume for the pod. A PersistentVolumeClaimVolumeSource is, essentially, a wrapper around another type of volume that is owned by someone else (the system)."""
    claimName: Optional[str] = None
    readOnly: Optional[bool] = None


__all__ = ["PersistentVolumeClaimVolumeSource"]