'''PodAntiAffinity resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_affinity_term import PodAffinityTerm
from .weighted_pod_affinity_term import WeightedPodAffinityTerm


@dataclass
class PodAntiAffinity:
    """Pod anti affinity is a group of inter pod anti affinity scheduling rules."""
    preferredDuringSchedulingIgnoredDuringExecution: Optional[list[WeightedPodAffinityTerm]] = None
    requiredDuringSchedulingIgnoredDuringExecution: Optional[list[PodAffinityTerm]] = None


__all__ = ["PodAntiAffinity"]