'''NodeConfigStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_config_source import NodeConfigSource


@dataclass
class NodeConfigStatus:
    """NodeConfigStatus describes the status of the config assigned by Node.Spec.ConfigSource."""
    active: Optional[NodeConfigSource] = None
    assigned: Optional[NodeConfigSource] = None
    error: Optional[str] = None
    lastKnownGood: Optional[NodeConfigSource] = None


__all__ = ["NodeConfigStatus"]