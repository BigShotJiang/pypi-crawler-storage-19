'''PodTemplate resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_template_spec import PodTemplateSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PodTemplate:
    """PodTemplate describes a template for creating copies of a predefined pod."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    template: Optional[PodTemplateSpec] = None


__all__ = ["PodTemplate"]