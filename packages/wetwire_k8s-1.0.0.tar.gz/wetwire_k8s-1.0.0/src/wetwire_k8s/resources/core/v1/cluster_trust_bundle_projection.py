'''ClusterTrustBundleProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class ClusterTrustBundleProjection:
    """ClusterTrustBundleProjection describes how to select a set of ClusterTrustBundle objects and project their contents into the pod filesystem."""
    labelSelector: Optional[LabelSelector] = None
    name: Optional[str] = None
    optional: Optional[bool] = None
    path: Optional[str] = None
    signerName: Optional[str] = None


__all__ = ["ClusterTrustBundleProjection"]