'''WindowsSecurityContextOptions resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class WindowsSecurityContextOptions:
    """WindowsSecurityContextOptions contain Windows-specific options and credentials."""
    gmsaCredentialSpec: Optional[str] = None
    gmsaCredentialSpecName: Optional[str] = None
    hostProcess: Optional[bool] = None
    runAsUserName: Optional[str] = None


__all__ = ["WindowsSecurityContextOptions"]