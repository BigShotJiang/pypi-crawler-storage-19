'''NodeSelectorRequirement resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NodeSelectorRequirement:
    """A node selector requirement is a selector that contains values, a key, and an operator that relates the key and values."""
    key: Optional[str] = None
    operator: Optional[str] = None
    values: Optional[list[str]] = None


__all__ = ["NodeSelectorRequirement"]