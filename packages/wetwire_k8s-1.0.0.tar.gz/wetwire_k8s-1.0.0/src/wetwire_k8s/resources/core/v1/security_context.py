'''SecurityContext resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .app_armor_profile import AppArmorProfile
from .capabilities import Capabilities
from .se_linux_options import SELinuxOptions
from .seccomp_profile import SeccompProfile
from .windows_security_context_options import WindowsSecurityContextOptions


@dataclass
class SecurityContext:
    """SecurityContext holds security configuration that will be applied to a container. Some fields are present in both SecurityContext and PodSecurityContext.  When both are set, the values in SecurityContext take precedence."""
    allowPrivilegeEscalation: Optional[bool] = None
    appArmorProfile: Optional[AppArmorProfile] = None
    capabilities: Optional[Capabilities] = None
    privileged: Optional[bool] = None
    procMount: Optional[str] = None
    readOnlyRootFilesystem: Optional[bool] = None
    runAsGroup: Optional[int] = None
    runAsNonRoot: Optional[bool] = None
    runAsUser: Optional[int] = None
    seLinuxOptions: Optional[SELinuxOptions] = None
    seccompProfile: Optional[SeccompProfile] = None
    windowsOptions: Optional[WindowsSecurityContextOptions] = None


__all__ = ["SecurityContext"]