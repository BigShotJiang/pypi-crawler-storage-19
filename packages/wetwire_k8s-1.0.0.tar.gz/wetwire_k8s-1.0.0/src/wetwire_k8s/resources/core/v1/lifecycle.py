'''Lifecycle resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .lifecycle_handler import LifecycleHandler


@dataclass
class Lifecycle:
    """Lifecycle describes actions that the management system should take in response to container lifecycle events. For the PostStart and PreStop lifecycle handlers, management of the container blocks until the action is complete, unless the container process fails, in which case the handler is aborted."""
    postStart: Optional[LifecycleHandler] = None
    preStop: Optional[LifecycleHandler] = None


__all__ = ["Lifecycle"]