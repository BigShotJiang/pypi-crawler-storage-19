'''ServicePort resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.int_or_string import IntOrString


@dataclass
class ServicePort:
    """ServicePort contains information on service's port."""
    appProtocol: Optional[str] = None
    name: Optional[str] = None
    nodePort: Optional[int] = None
    port: Optional[int] = None
    protocol: Optional[str] = None
    targetPort: Optional[IntOrString] = None


__all__ = ["ServicePort"]