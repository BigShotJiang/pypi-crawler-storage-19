'''PersistentVolumeClaimStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .modify_volume_status import ModifyVolumeStatus
from .persistent_volume_claim_condition import PersistentVolumeClaimCondition


@dataclass
class PersistentVolumeClaimStatus:
    """PersistentVolumeClaimStatus is the current status of a persistent volume claim."""
    accessModes: Optional[list[str]] = None
    allocatedResourceStatuses: Optional[dict[str, Any]] = None
    allocatedResources: Optional[dict[str, Any]] = None
    capacity: Optional[dict[str, Any]] = None
    conditions: Optional[list[PersistentVolumeClaimCondition]] = None
    currentVolumeAttributesClassName: Optional[str] = None
    modifyVolumeStatus: Optional[ModifyVolumeStatus] = None
    phase: Optional[str] = None


__all__ = ["PersistentVolumeClaimStatus"]