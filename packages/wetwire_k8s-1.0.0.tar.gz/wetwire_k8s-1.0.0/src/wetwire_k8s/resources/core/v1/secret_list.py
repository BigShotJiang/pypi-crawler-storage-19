'''SecretList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret import Secret
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class SecretList:
    """SecretList is a list of Secret."""
    apiVersion: Optional[str] = None
    items: Optional[list[Secret]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["SecretList"]