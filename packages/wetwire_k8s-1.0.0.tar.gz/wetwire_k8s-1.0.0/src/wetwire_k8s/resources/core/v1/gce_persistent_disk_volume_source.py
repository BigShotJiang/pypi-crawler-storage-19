'''GCEPersistentDiskVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class GCEPersistentDiskVolumeSource:
    """Represents a Persistent Disk resource in Google Compute Engine.

A GCE PD must exist before mounting to a container. The disk must also be in the same GCE project and zone as the kubelet. A GCE PD can only be mounted as read/write once or read-only many times. GCE PDs support ownership management and SELinux relabeling."""
    fsType: Optional[str] = None
    partition: Optional[int] = None
    pdName: Optional[str] = None
    readOnly: Optional[bool] = None


__all__ = ["GCEPersistentDiskVolumeSource"]