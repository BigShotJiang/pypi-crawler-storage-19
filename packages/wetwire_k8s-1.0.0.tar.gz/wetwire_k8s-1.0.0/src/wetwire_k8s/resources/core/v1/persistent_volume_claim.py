'''PersistentVolumeClaim resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume_claim_spec import PersistentVolumeClaimSpec
from .persistent_volume_claim_status import PersistentVolumeClaimStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PersistentVolumeClaim:
    """PersistentVolumeClaim is a user's request for and claim to a persistent volume"""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PersistentVolumeClaimSpec] = None
    status: Optional[PersistentVolumeClaimStatus] = None


__all__ = ["PersistentVolumeClaim"]