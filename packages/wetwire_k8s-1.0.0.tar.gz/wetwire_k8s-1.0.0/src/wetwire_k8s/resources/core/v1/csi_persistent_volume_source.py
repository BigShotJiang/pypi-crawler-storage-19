'''CSIPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret_reference import SecretReference


@dataclass
class CSIPersistentVolumeSource:
    """Represents storage that is managed by an external CSI volume driver (Beta feature)"""
    controllerExpandSecretRef: Optional[SecretReference] = None
    controllerPublishSecretRef: Optional[SecretReference] = None
    driver: Optional[str] = None
    fsType: Optional[str] = None
    nodeExpandSecretRef: Optional[SecretReference] = None
    nodePublishSecretRef: Optional[SecretReference] = None
    nodeStageSecretRef: Optional[SecretReference] = None
    readOnly: Optional[bool] = None
    volumeAttributes: Optional[dict[str, Any]] = None
    volumeHandle: Optional[str] = None


__all__ = ["CSIPersistentVolumeSource"]