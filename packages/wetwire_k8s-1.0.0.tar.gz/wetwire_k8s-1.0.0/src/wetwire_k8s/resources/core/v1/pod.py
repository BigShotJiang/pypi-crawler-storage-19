'''Pod resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_spec import PodSpec
from .pod_status import PodStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Pod:
    """Pod is a collection of containers that can run on a host. This resource is created by clients and scheduled onto hosts."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PodSpec] = None
    status: Optional[PodStatus] = None


__all__ = ["Pod"]