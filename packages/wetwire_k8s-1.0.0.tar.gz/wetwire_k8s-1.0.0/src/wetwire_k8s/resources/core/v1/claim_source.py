'''ClaimSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ClaimSource:
    """ClaimSource describes a reference to a ResourceClaim.

Exactly one of these fields should be set.  Consumers of this type must treat an empty object as if it has an unknown value."""
    resourceClaimName: Optional[str] = None
    resourceClaimTemplateName: Optional[str] = None


__all__ = ["ClaimSource"]