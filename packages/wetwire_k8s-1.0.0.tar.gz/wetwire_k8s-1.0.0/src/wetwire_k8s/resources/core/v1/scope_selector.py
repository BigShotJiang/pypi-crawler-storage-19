'''ScopeSelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .scoped_resource_selector_requirement import ScopedResourceSelectorRequirement


@dataclass
class ScopeSelector:
    """A scope selector represents the AND of the selectors represented by the scoped-resource selector requirements."""
    matchExpressions: Optional[list[ScopedResourceSelectorRequirement]] = None


__all__ = ["ScopeSelector"]