'''LimitRangeItem resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class LimitRangeItem:
    """LimitRangeItem defines a min/max usage limit for any resource that matches on kind."""
    default: Optional[dict[str, Any]] = None
    defaultRequest: Optional[dict[str, Any]] = None
    max: Optional[dict[str, Any]] = None
    maxLimitRequestRatio: Optional[dict[str, Any]] = None
    min: Optional[dict[str, Any]] = None
    type: Optional[str] = None


__all__ = ["LimitRangeItem"]