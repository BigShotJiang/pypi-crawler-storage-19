'''ContainerResizePolicy resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ContainerResizePolicy:
    """ContainerResizePolicy represents resource resize policy for the container."""
    resourceName: Optional[str] = None
    restartPolicy: Optional[str] = None


__all__ = ["ContainerResizePolicy"]