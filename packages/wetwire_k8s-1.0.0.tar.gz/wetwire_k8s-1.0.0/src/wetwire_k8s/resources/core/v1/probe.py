'''Probe resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .exec_action import ExecAction
from .grpc_action import GRPCAction
from .http_get_action import HTTPGetAction
from .tcp_socket_action import TCPSocketAction


@dataclass
class Probe:
    """Probe describes a health check to be performed against a container to determine whether it is alive or ready to receive traffic."""
    exec: Optional[ExecAction] = None
    failureThreshold: Optional[int] = None
    grpc: Optional[GRPCAction] = None
    httpGet: Optional[HTTPGetAction] = None
    initialDelaySeconds: Optional[int] = None
    periodSeconds: Optional[int] = None
    successThreshold: Optional[int] = None
    tcpSocket: Optional[TCPSocketAction] = None
    terminationGracePeriodSeconds: Optional[int] = None
    timeoutSeconds: Optional[int] = None


__all__ = ["Probe"]