'''Sysctl resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Sysctl:
    """Sysctl defines a kernel parameter to be set"""
    name: Optional[str] = None
    value: Optional[str] = None


__all__ = ["Sysctl"]