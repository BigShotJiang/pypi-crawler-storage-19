'''CephFSVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class CephFSVolumeSource:
    """Represents a Ceph Filesystem mount that lasts the lifetime of a pod Cephfs volumes do not support ownership management or SELinux relabeling."""
    monitors: Optional[list[str]] = None
    path: Optional[str] = None
    readOnly: Optional[bool] = None
    secretFile: Optional[str] = None
    secretRef: Optional[LocalObjectReference] = None
    user: Optional[str] = None


__all__ = ["CephFSVolumeSource"]