'''NodeSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_config_source import NodeConfigSource
from .taint import Taint


@dataclass
class NodeSpec:
    """NodeSpec describes the attributes that a node is created with."""
    configSource: Optional[NodeConfigSource] = None
    externalID: Optional[str] = None
    podCIDR: Optional[str] = None
    podCIDRs: Optional[list[str]] = None
    providerID: Optional[str] = None
    taints: Optional[list[Taint]] = None
    unschedulable: Optional[bool] = None


__all__ = ["NodeSpec"]