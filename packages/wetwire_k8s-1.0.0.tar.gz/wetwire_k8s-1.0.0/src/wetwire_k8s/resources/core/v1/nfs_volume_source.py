'''NFSVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NFSVolumeSource:
    """Represents an NFS mount that lasts the lifetime of a pod. NFS volumes do not support ownership management or SELinux relabeling."""
    path: Optional[str] = None
    readOnly: Optional[bool] = None
    server: Optional[str] = None


__all__ = ["NFSVolumeSource"]