'''LifecycleHandler resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .exec_action import ExecAction
from .http_get_action import HTTPGetAction
from .sleep_action import SleepAction
from .tcp_socket_action import TCPSocketAction


@dataclass
class LifecycleHandler:
    """LifecycleHandler defines a specific action that should be taken in a lifecycle hook. One and only one of the fields, except TCPSocket must be specified."""
    exec: Optional[ExecAction] = None
    httpGet: Optional[HTTPGetAction] = None
    sleep: Optional[SleepAction] = None
    tcpSocket: Optional[TCPSocketAction] = None


__all__ = ["LifecycleHandler"]