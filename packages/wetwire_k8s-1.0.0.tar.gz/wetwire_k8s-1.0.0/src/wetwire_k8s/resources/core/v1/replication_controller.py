'''ReplicationController resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replication_controller_spec import ReplicationControllerSpec
from .replication_controller_status import ReplicationControllerStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ReplicationController:
    """ReplicationController represents the configuration of a replication controller."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ReplicationControllerSpec] = None
    status: Optional[ReplicationControllerStatus] = None


__all__ = ["ReplicationController"]