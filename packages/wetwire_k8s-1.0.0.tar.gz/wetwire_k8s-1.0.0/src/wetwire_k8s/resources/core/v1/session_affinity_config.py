'''SessionAffinityConfig resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .client_ip_config import ClientIPConfig


@dataclass
class SessionAffinityConfig:
    """SessionAffinityConfig represents the configurations of session affinity."""
    clientIP: Optional[ClientIPConfig] = None


__all__ = ["SessionAffinityConfig"]