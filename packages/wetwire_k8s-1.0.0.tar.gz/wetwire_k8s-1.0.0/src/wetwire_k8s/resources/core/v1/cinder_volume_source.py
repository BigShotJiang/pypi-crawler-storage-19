'''CinderVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class CinderVolumeSource:
    """Represents a cinder volume resource in Openstack. A Cinder volume must exist before mounting to a container. The volume must also be in the same region as the kubelet. Cinder volumes support ownership management and SELinux relabeling."""
    fsType: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[LocalObjectReference] = None
    volumeID: Optional[str] = None


__all__ = ["CinderVolumeSource"]