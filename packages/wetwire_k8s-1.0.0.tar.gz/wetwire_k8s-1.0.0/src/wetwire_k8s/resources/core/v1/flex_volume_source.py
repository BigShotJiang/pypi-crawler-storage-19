'''FlexVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class FlexVolumeSource:
    """FlexVolume represents a generic volume resource that is provisioned/attached using an exec based plugin."""
    driver: Optional[str] = None
    fsType: Optional[str] = None
    options: Optional[dict[str, Any]] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[LocalObjectReference] = None


__all__ = ["FlexVolumeSource"]