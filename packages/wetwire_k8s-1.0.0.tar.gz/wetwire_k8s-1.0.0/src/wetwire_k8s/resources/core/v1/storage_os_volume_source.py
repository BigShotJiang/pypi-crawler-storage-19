'''StorageOSVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class StorageOSVolumeSource:
    """Represents a StorageOS persistent volume resource."""
    fsType: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[LocalObjectReference] = None
    volumeName: Optional[str] = None
    volumeNamespace: Optional[str] = None


__all__ = ["StorageOSVolumeSource"]