'''PodTemplateSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_spec import PodSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PodTemplateSpec:
    """PodTemplateSpec describes the data a pod should have when created from a template"""
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PodSpec] = None


__all__ = ["PodTemplateSpec"]