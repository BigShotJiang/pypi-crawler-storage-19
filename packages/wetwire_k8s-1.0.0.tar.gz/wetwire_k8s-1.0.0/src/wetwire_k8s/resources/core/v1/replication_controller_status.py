'''ReplicationControllerStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replication_controller_condition import ReplicationControllerCondition


@dataclass
class ReplicationControllerStatus:
    """ReplicationControllerStatus represents the current status of a replication controller."""
    availableReplicas: Optional[int] = None
    conditions: Optional[list[ReplicationControllerCondition]] = None
    fullyLabeledReplicas: Optional[int] = None
    observedGeneration: Optional[int] = None
    readyReplicas: Optional[int] = None
    replicas: Optional[int] = None


__all__ = ["ReplicationControllerStatus"]