'''PersistentVolumeSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .aws_elastic_block_store_volume_source import AWSElasticBlockStoreVolumeSource
from .azure_disk_volume_source import AzureDiskVolumeSource
from .azure_file_persistent_volume_source import AzureFilePersistentVolumeSource
from .ceph_fs_persistent_volume_source import CephFSPersistentVolumeSource
from .cinder_persistent_volume_source import CinderPersistentVolumeSource
from .csi_persistent_volume_source import CSIPersistentVolumeSource
from .fc_volume_source import FCVolumeSource
from .flex_persistent_volume_source import FlexPersistentVolumeSource
from .flocker_volume_source import FlockerVolumeSource
from .gce_persistent_disk_volume_source import GCEPersistentDiskVolumeSource
from .glusterfs_persistent_volume_source import GlusterfsPersistentVolumeSource
from .host_path_volume_source import HostPathVolumeSource
from .iscsi_persistent_volume_source import ISCSIPersistentVolumeSource
from .local_volume_source import LocalVolumeSource
from .nfs_volume_source import NFSVolumeSource
from .object_reference import ObjectReference
from .photon_persistent_disk_volume_source import PhotonPersistentDiskVolumeSource
from .portworx_volume_source import PortworxVolumeSource
from .quobyte_volume_source import QuobyteVolumeSource
from .rbd_persistent_volume_source import RBDPersistentVolumeSource
from .scale_io_persistent_volume_source import ScaleIOPersistentVolumeSource
from .storage_os_persistent_volume_source import StorageOSPersistentVolumeSource
from .volume_node_affinity import VolumeNodeAffinity
from .vsphere_virtual_disk_volume_source import VsphereVirtualDiskVolumeSource


@dataclass
class PersistentVolumeSpec:
    """PersistentVolumeSpec is the specification of a persistent volume."""
    accessModes: Optional[list[str]] = None
    awsElasticBlockStore: Optional[AWSElasticBlockStoreVolumeSource] = None
    azureDisk: Optional[AzureDiskVolumeSource] = None
    azureFile: Optional[AzureFilePersistentVolumeSource] = None
    capacity: Optional[dict[str, Any]] = None
    cephfs: Optional[CephFSPersistentVolumeSource] = None
    cinder: Optional[CinderPersistentVolumeSource] = None
    claimRef: Optional[ObjectReference] = None
    csi: Optional[CSIPersistentVolumeSource] = None
    fc: Optional[FCVolumeSource] = None
    flexVolume: Optional[FlexPersistentVolumeSource] = None
    flocker: Optional[FlockerVolumeSource] = None
    gcePersistentDisk: Optional[GCEPersistentDiskVolumeSource] = None
    glusterfs: Optional[GlusterfsPersistentVolumeSource] = None
    hostPath: Optional[HostPathVolumeSource] = None
    iscsi: Optional[ISCSIPersistentVolumeSource] = None
    local: Optional[LocalVolumeSource] = None
    mountOptions: Optional[list[str]] = None
    nfs: Optional[NFSVolumeSource] = None
    nodeAffinity: Optional[VolumeNodeAffinity] = None
    persistentVolumeReclaimPolicy: Optional[str] = None
    photonPersistentDisk: Optional[PhotonPersistentDiskVolumeSource] = None
    portworxVolume: Optional[PortworxVolumeSource] = None
    quobyte: Optional[QuobyteVolumeSource] = None
    rbd: Optional[RBDPersistentVolumeSource] = None
    scaleIO: Optional[ScaleIOPersistentVolumeSource] = None
    storageClassName: Optional[str] = None
    storageos: Optional[StorageOSPersistentVolumeSource] = None
    volumeAttributesClassName: Optional[str] = None
    volumeMode: Optional[str] = None
    vsphereVolume: Optional[VsphereVirtualDiskVolumeSource] = None


__all__ = ["PersistentVolumeSpec"]