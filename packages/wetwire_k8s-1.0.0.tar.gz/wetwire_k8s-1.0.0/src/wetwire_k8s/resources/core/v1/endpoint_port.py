'''EndpointPort resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class EndpointPort:
    """EndpointPort is a tuple that describes a single port."""
    appProtocol: Optional[str] = None
    name: Optional[str] = None
    port: Optional[int] = None
    protocol: Optional[str] = None


__all__ = ["EndpointPort"]