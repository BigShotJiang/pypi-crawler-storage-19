'''Event resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .event_series import EventSeries
from .event_source import EventSource
from .object_reference import ObjectReference
from wetwire_k8s.resources.meta.v1.micro_time import MicroTime
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class Event:
    """Event is a report of an event somewhere in the cluster.  Events have a limited retention time and triggers and messages may evolve with time.  Event consumers should not rely on the timing of an event with a given Reason reflecting a consistent underlying trigger, or the continued existence of events with that Reason.  Events should be treated as informative, best-effort, supplemental data."""
    action: Optional[str] = None
    apiVersion: Optional[str] = None
    count: Optional[int] = None
    eventTime: Optional[MicroTime] = None
    firstTimestamp: Optional[Time] = None
    involvedObject: Optional[ObjectReference] = None
    kind: Optional[str] = None
    lastTimestamp: Optional[Time] = None
    message: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    reason: Optional[str] = None
    related: Optional[ObjectReference] = None
    reportingComponent: Optional[str] = None
    reportingInstance: Optional[str] = None
    series: Optional[EventSeries] = None
    source: Optional[EventSource] = None
    type: Optional[str] = None


__all__ = ["Event"]