'''LoadBalancerIngress resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .port_status import PortStatus


@dataclass
class LoadBalancerIngress:
    """LoadBalancerIngress represents the status of a load-balancer ingress point: traffic intended for the service should be sent to an ingress point."""
    hostname: Optional[str] = None
    ip: Optional[str] = None
    ipMode: Optional[str] = None
    ports: Optional[list[PortStatus]] = None


__all__ = ["LoadBalancerIngress"]