'''GRPCAction resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class GRPCAction:
    """Kubernetes GRPCAction"""
    port: Optional[int] = None
    service: Optional[str] = None


__all__ = ["GRPCAction"]