'''Secret resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Secret:
    """Secret holds secret data of a certain type. The total bytes of the values in the Data field must be less than MaxSecretSize bytes."""
    apiVersion: Optional[str] = None
    data: Optional[dict[str, Any]] = None
    immutable: Optional[bool] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    stringData: Optional[dict[str, Any]] = None
    type: Optional[str] = None


__all__ = ["Secret"]