'''EventSeries resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.micro_time import MicroTime


@dataclass
class EventSeries:
    """EventSeries contain information on series of events, i.e. thing that was/is happening continuously for some time."""
    count: Optional[int] = None
    lastObservedTime: Optional[MicroTime] = None


__all__ = ["EventSeries"]