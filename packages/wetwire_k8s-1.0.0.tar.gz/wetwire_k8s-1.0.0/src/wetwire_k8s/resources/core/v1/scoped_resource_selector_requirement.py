'''ScopedResourceSelectorRequirement resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ScopedResourceSelectorRequirement:
    """A scoped-resource selector requirement is a selector that contains values, a scope name, and an operator that relates the scope name and values."""
    operator: Optional[str] = None
    scopeName: Optional[str] = None
    values: Optional[list[str]] = None


__all__ = ["ScopedResourceSelectorRequirement"]