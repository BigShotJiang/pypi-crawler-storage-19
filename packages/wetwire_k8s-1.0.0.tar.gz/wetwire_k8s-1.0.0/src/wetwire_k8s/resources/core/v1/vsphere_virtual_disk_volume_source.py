'''VsphereVirtualDiskVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class VsphereVirtualDiskVolumeSource:
    """Represents a vSphere volume resource."""
    fsType: Optional[str] = None
    storagePolicyID: Optional[str] = None
    storagePolicyName: Optional[str] = None
    volumePath: Optional[str] = None


__all__ = ["VsphereVirtualDiskVolumeSource"]