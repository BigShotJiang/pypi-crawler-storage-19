'''LoadBalancerStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .load_balancer_ingress import LoadBalancerIngress


@dataclass
class LoadBalancerStatus:
    """LoadBalancerStatus represents the status of a load-balancer."""
    ingress: Optional[list[LoadBalancerIngress]] = None


__all__ = ["LoadBalancerStatus"]