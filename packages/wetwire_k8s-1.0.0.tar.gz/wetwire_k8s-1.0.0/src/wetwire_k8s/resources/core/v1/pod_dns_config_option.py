'''PodDNSConfigOption resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodDNSConfigOption:
    """PodDNSConfigOption defines DNS resolver options of a pod."""
    name: Optional[str] = None
    value: Optional[str] = None


__all__ = ["PodDNSConfigOption"]