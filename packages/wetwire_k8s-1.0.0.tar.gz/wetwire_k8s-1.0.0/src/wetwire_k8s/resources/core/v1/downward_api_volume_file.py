'''DownwardAPIVolumeFile resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .object_field_selector import ObjectFieldSelector
from .resource_field_selector import ResourceFieldSelector


@dataclass
class DownwardAPIVolumeFile:
    """DownwardAPIVolumeFile represents information to create the file containing the pod field"""
    fieldRef: Optional[ObjectFieldSelector] = None
    mode: Optional[int] = None
    path: Optional[str] = None
    resourceFieldRef: Optional[ResourceFieldSelector] = None


__all__ = ["DownwardAPIVolumeFile"]