'''StorageOSPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .object_reference import ObjectReference


@dataclass
class StorageOSPersistentVolumeSource:
    """Represents a StorageOS persistent volume resource."""
    fsType: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[ObjectReference] = None
    volumeName: Optional[str] = None
    volumeNamespace: Optional[str] = None


__all__ = ["StorageOSPersistentVolumeSource"]