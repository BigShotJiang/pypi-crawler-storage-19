'''SleepAction resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SleepAction:
    """SleepAction describes a "sleep" action."""
    seconds: Optional[int] = None


__all__ = ["SleepAction"]