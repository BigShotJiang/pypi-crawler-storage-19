'''ResourceQuotaStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ResourceQuotaStatus:
    """ResourceQuotaStatus defines the enforced hard limits and observed use."""
    hard: Optional[dict[str, Any]] = None
    used: Optional[dict[str, Any]] = None


__all__ = ["ResourceQuotaStatus"]