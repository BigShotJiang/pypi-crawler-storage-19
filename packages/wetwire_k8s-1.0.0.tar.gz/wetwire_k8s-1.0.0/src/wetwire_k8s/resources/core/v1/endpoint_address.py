'''EndpointAddress resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .object_reference import ObjectReference


@dataclass
class EndpointAddress:
    """EndpointAddress is a tuple that describes single IP address."""
    hostname: Optional[str] = None
    ip: Optional[str] = None
    nodeName: Optional[str] = None
    targetRef: Optional[ObjectReference] = None


__all__ = ["EndpointAddress"]