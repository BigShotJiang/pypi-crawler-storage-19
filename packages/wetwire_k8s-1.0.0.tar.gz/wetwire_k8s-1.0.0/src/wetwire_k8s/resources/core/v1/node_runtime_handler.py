'''NodeRuntimeHandler resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_runtime_handler_features import NodeRuntimeHandlerFeatures


@dataclass
class NodeRuntimeHandler:
    """NodeRuntimeHandler is a set of runtime handler information."""
    features: Optional[NodeRuntimeHandlerFeatures] = None
    name: Optional[str] = None


__all__ = ["NodeRuntimeHandler"]