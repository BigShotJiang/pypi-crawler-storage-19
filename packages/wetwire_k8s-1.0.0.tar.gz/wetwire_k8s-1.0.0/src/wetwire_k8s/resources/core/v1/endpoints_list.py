'''EndpointsList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .endpoints import Endpoints
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class EndpointsList:
    """EndpointsList is a list of endpoints."""
    apiVersion: Optional[str] = None
    items: Optional[list[Endpoints]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["EndpointsList"]