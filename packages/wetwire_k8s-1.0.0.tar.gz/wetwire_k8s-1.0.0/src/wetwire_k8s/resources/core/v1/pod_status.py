'''PodStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_status import ContainerStatus
from .host_ip import HostIP
from .pod_condition import PodCondition
from .pod_ip import PodIP
from .pod_resource_claim_status import PodResourceClaimStatus
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class PodStatus:
    """PodStatus represents information about the status of a pod. Status may trail the actual state of a system, especially if the node that hosts the pod cannot contact the control plane."""
    conditions: Optional[list[PodCondition]] = None
    containerStatuses: Optional[list[ContainerStatus]] = None
    ephemeralContainerStatuses: Optional[list[ContainerStatus]] = None
    hostIP: Optional[str] = None
    hostIPs: Optional[list[HostIP]] = None
    initContainerStatuses: Optional[list[ContainerStatus]] = None
    message: Optional[str] = None
    nominatedNodeName: Optional[str] = None
    phase: Optional[str] = None
    podIP: Optional[str] = None
    podIPs: Optional[list[PodIP]] = None
    qosClass: Optional[str] = None
    reason: Optional[str] = None
    resize: Optional[str] = None
    resourceClaimStatuses: Optional[list[PodResourceClaimStatus]] = None
    startTime: Optional[Time] = None


__all__ = ["PodStatus"]