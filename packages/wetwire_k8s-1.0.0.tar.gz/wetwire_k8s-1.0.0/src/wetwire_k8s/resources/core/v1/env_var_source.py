'''EnvVarSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .config_map_key_selector import ConfigMapKeySelector
from .object_field_selector import ObjectFieldSelector
from .resource_field_selector import ResourceFieldSelector
from .secret_key_selector import SecretKeySelector


@dataclass
class EnvVarSource:
    """EnvVarSource represents a source for the value of an EnvVar."""
    configMapKeyRef: Optional[ConfigMapKeySelector] = None
    fieldRef: Optional[ObjectFieldSelector] = None
    resourceFieldRef: Optional[ResourceFieldSelector] = None
    secretKeyRef: Optional[SecretKeySelector] = None


__all__ = ["EnvVarSource"]