'''NodeAddress resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NodeAddress:
    """NodeAddress contains information for the node's address."""
    address: Optional[str] = None
    type: Optional[str] = None


__all__ = ["NodeAddress"]