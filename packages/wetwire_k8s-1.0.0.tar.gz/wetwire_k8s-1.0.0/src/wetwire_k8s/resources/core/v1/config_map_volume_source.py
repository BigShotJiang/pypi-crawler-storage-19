'''ConfigMapVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .key_to_path import KeyToPath


@dataclass
class ConfigMapVolumeSource:
    """Adapts a ConfigMap into a volume.

The contents of the target ConfigMap's Data field will be presented in a volume as files using the keys in the Data field as the file names, unless the items element is populated with specific mappings of keys to paths. ConfigMap volumes support ownership management and SELinux relabeling."""
    defaultMode: Optional[int] = None
    items: Optional[list[KeyToPath]] = None
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["ConfigMapVolumeSource"]