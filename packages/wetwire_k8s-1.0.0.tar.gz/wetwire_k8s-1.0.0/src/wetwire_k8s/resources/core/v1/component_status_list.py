'''ComponentStatusList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .component_status import ComponentStatus
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ComponentStatusList:
    """Status of all the conditions for the component as a list of ComponentStatus objects. Deprecated: This API is deprecated in v1.19+"""
    apiVersion: Optional[str] = None
    items: Optional[list[ComponentStatus]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ComponentStatusList"]