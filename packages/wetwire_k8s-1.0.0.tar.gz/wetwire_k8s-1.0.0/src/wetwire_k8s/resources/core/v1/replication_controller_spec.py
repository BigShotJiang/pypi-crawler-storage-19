'''ReplicationControllerSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_template_spec import PodTemplateSpec


@dataclass
class ReplicationControllerSpec:
    """ReplicationControllerSpec is the specification of a replication controller."""
    minReadySeconds: Optional[int] = None
    replicas: Optional[int] = None
    selector: Optional[dict[str, Any]] = None
    template: Optional[PodTemplateSpec] = None


__all__ = ["ReplicationControllerSpec"]