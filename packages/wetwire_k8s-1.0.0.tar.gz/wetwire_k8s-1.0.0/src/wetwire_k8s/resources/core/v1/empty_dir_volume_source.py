'''EmptyDirVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.quantity import Quantity


@dataclass
class EmptyDirVolumeSource:
    """Represents an empty directory for a pod. Empty directory volumes support ownership management and SELinux relabeling."""
    medium: Optional[str] = None
    sizeLimit: Optional[Quantity] = None


__all__ = ["EmptyDirVolumeSource"]