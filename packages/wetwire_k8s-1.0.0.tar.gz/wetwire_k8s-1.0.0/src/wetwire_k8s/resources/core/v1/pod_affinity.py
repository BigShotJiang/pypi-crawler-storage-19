'''PodAffinity resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_affinity_term import PodAffinityTerm
from .weighted_pod_affinity_term import WeightedPodAffinityTerm


@dataclass
class PodAffinity:
    """Pod affinity is a group of inter pod affinity scheduling rules."""
    preferredDuringSchedulingIgnoredDuringExecution: Optional[list[WeightedPodAffinityTerm]] = None
    requiredDuringSchedulingIgnoredDuringExecution: Optional[list[PodAffinityTerm]] = None


__all__ = ["PodAffinity"]