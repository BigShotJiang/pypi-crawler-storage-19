'''PodSecurityContext resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .app_armor_profile import AppArmorProfile
from .se_linux_options import SELinuxOptions
from .seccomp_profile import SeccompProfile
from .sysctl import Sysctl
from .windows_security_context_options import WindowsSecurityContextOptions


@dataclass
class PodSecurityContext:
    """PodSecurityContext holds pod-level security attributes and common container settings. Some fields are also present in container.securityContext.  Field values of container.securityContext take precedence over field values of PodSecurityContext."""
    appArmorProfile: Optional[AppArmorProfile] = None
    fsGroup: Optional[int] = None
    fsGroupChangePolicy: Optional[str] = None
    runAsGroup: Optional[int] = None
    runAsNonRoot: Optional[bool] = None
    runAsUser: Optional[int] = None
    seLinuxOptions: Optional[SELinuxOptions] = None
    seccompProfile: Optional[SeccompProfile] = None
    supplementalGroups: Optional[list[int]] = None
    sysctls: Optional[list[Sysctl]] = None
    windowsOptions: Optional[WindowsSecurityContextOptions] = None


__all__ = ["PodSecurityContext"]