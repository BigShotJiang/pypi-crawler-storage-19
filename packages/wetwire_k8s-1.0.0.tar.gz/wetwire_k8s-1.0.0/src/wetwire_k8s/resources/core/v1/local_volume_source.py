'''LocalVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class LocalVolumeSource:
    """Local represents directly-attached storage with node affinity (Beta feature)"""
    fsType: Optional[str] = None
    path: Optional[str] = None


__all__ = ["LocalVolumeSource"]