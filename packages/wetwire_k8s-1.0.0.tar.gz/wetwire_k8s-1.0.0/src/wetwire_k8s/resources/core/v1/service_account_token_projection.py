'''ServiceAccountTokenProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ServiceAccountTokenProjection:
    """ServiceAccountTokenProjection represents a projected service account token volume. This projection can be used to insert a service account token into the pods runtime filesystem for use against APIs (Kubernetes API Server or otherwise)."""
    audience: Optional[str] = None
    expirationSeconds: Optional[int] = None
    path: Optional[str] = None


__all__ = ["ServiceAccountTokenProjection"]