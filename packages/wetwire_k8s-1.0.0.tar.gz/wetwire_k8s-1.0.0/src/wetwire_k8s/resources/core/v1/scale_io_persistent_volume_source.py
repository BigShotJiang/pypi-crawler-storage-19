'''ScaleIOPersistentVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .secret_reference import SecretReference


@dataclass
class ScaleIOPersistentVolumeSource:
    """ScaleIOPersistentVolumeSource represents a persistent ScaleIO volume"""
    fsType: Optional[str] = None
    gateway: Optional[str] = None
    protectionDomain: Optional[str] = None
    readOnly: Optional[bool] = None
    secretRef: Optional[SecretReference] = None
    sslEnabled: Optional[bool] = None
    storageMode: Optional[str] = None
    storagePool: Optional[str] = None
    system: Optional[str] = None
    volumeName: Optional[str] = None


__all__ = ["ScaleIOPersistentVolumeSource"]