'''SeccompProfile resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SeccompProfile:
    """SeccompProfile defines a pod/container's seccomp profile settings. Only one profile source may be set."""
    localhostProfile: Optional[str] = None
    type: Optional[str] = None


__all__ = ["SeccompProfile"]