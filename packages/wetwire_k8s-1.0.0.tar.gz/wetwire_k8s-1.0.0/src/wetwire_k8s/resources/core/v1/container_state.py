'''ContainerState resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_state_running import ContainerStateRunning
from .container_state_terminated import ContainerStateTerminated
from .container_state_waiting import ContainerStateWaiting


@dataclass
class ContainerState:
    """ContainerState holds a possible state of container. Only one of its members may be specified. If none of them is specified, the default one is ContainerStateWaiting."""
    running: Optional[ContainerStateRunning] = None
    terminated: Optional[ContainerStateTerminated] = None
    waiting: Optional[ContainerStateWaiting] = None


__all__ = ["ContainerState"]