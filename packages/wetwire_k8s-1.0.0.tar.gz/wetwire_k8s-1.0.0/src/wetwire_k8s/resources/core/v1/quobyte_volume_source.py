'''QuobyteVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class QuobyteVolumeSource:
    """Represents a Quobyte mount that lasts the lifetime of a pod. Quobyte volumes do not support ownership management or SELinux relabeling."""
    group: Optional[str] = None
    readOnly: Optional[bool] = None
    registry: Optional[str] = None
    tenant: Optional[str] = None
    user: Optional[str] = None
    volume: Optional[str] = None


__all__ = ["QuobyteVolumeSource"]