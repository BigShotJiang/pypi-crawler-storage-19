'''ContainerPort resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ContainerPort:
    """ContainerPort represents a network port in a single container."""
    containerPort: Optional[int] = None
    hostIP: Optional[str] = None
    hostPort: Optional[int] = None
    name: Optional[str] = None
    protocol: Optional[str] = None


__all__ = ["ContainerPort"]