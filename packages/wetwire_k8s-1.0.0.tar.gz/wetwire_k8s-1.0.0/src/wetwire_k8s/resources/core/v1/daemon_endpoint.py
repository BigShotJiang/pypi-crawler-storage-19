'''DaemonEndpoint resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class DaemonEndpoint:
    """DaemonEndpoint contains information about a single Daemon endpoint."""
    Port: Optional[int] = None


__all__ = ["DaemonEndpoint"]