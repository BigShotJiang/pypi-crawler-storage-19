'''ContainerStateRunning resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class ContainerStateRunning:
    """ContainerStateRunning is a running state of a container."""
    startedAt: Optional[Time] = None


__all__ = ["ContainerStateRunning"]