'''NodeRuntimeHandlerFeatures resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NodeRuntimeHandlerFeatures:
    """NodeRuntimeHandlerFeatures is a set of runtime features."""
    recursiveReadOnlyMounts: Optional[bool] = None


__all__ = ["NodeRuntimeHandlerFeatures"]