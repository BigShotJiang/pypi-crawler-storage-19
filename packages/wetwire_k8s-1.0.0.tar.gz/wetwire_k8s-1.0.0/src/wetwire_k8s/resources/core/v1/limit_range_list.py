'''LimitRangeList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .limit_range import LimitRange
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class LimitRangeList:
    """LimitRangeList is a list of LimitRange items."""
    apiVersion: Optional[str] = None
    items: Optional[list[LimitRange]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["LimitRangeList"]