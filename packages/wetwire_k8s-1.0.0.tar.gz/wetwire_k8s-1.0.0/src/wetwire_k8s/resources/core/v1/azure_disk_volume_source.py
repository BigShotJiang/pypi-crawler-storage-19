'''AzureDiskVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AzureDiskVolumeSource:
    """AzureDisk represents an Azure Data Disk mount on the host and bind mount to the pod."""
    cachingMode: Optional[str] = None
    diskName: Optional[str] = None
    diskURI: Optional[str] = None
    fsType: Optional[str] = None
    kind: Optional[str] = None
    readOnly: Optional[bool] = None


__all__ = ["AzureDiskVolumeSource"]