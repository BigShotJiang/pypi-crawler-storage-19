'''EphemeralContainer resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .container_port import ContainerPort
from .container_resize_policy import ContainerResizePolicy
from .env_from_source import EnvFromSource
from .env_var import EnvVar
from .lifecycle import Lifecycle
from .probe import Probe
from .resource_requirements import ResourceRequirements
from .security_context import SecurityContext
from .volume_device import VolumeDevice
from .volume_mount import VolumeMount


@dataclass
class EphemeralContainer:
    """An EphemeralContainer is a temporary container that you may add to an existing Pod for user-initiated activities such as debugging. Ephemeral containers have no resource or scheduling guarantees, and they will not be restarted when they exit or when a Pod is removed or restarted. The kubelet may evict a Pod if an ephemeral container causes the Pod to exceed its resource allocation.

To add an ephemeral container, use the ephemeralcontainers subresource of an existing Pod. Ephemeral containers may not be removed or restarted."""
    args: Optional[list[str]] = None
    command: Optional[list[str]] = None
    env: Optional[list[EnvVar]] = None
    envFrom: Optional[list[EnvFromSource]] = None
    image: Optional[str] = None
    imagePullPolicy: Optional[str] = None
    lifecycle: Optional[Lifecycle] = None
    livenessProbe: Optional[Probe] = None
    name: Optional[str] = None
    ports: Optional[list[ContainerPort]] = None
    readinessProbe: Optional[Probe] = None
    resizePolicy: Optional[list[ContainerResizePolicy]] = None
    resources: Optional[ResourceRequirements] = None
    restartPolicy: Optional[str] = None
    securityContext: Optional[SecurityContext] = None
    startupProbe: Optional[Probe] = None
    stdin: Optional[bool] = None
    stdinOnce: Optional[bool] = None
    targetContainerName: Optional[str] = None
    terminationMessagePath: Optional[str] = None
    terminationMessagePolicy: Optional[str] = None
    tty: Optional[bool] = None
    volumeDevices: Optional[list[VolumeDevice]] = None
    volumeMounts: Optional[list[VolumeMount]] = None
    workingDir: Optional[str] = None


__all__ = ["EphemeralContainer"]