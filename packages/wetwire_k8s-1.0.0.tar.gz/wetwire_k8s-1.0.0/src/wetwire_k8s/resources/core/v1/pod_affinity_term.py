'''PodAffinityTerm resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.label_selector import LabelSelector


@dataclass
class PodAffinityTerm:
    """Defines a set of pods (namely those matching the labelSelector relative to the given namespace(s)) that this pod should be co-located (affinity) or not co-located (anti-affinity) with, where co-located is defined as running on a node whose value of the label with key <topologyKey> matches that of any node on which a pod of the set of pods is running"""
    labelSelector: Optional[LabelSelector] = None
    matchLabelKeys: Optional[list[str]] = None
    mismatchLabelKeys: Optional[list[str]] = None
    namespaceSelector: Optional[LabelSelector] = None
    namespaces: Optional[list[str]] = None
    topologyKey: Optional[str] = None


__all__ = ["PodAffinityTerm"]