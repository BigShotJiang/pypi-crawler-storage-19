'''ConfigMapNodeConfigSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ConfigMapNodeConfigSource:
    """ConfigMapNodeConfigSource contains the information to reference a ConfigMap as a config source for the Node. This API is deprecated since 1.22: https://git.k8s.io/enhancements/keps/sig-node/281-dynamic-kubelet-configuration"""
    kubeletConfigKey: Optional[str] = None
    name: Optional[str] = None
    namespace: Optional[str] = None
    resourceVersion: Optional[str] = None
    uid: Optional[str] = None


__all__ = ["ConfigMapNodeConfigSource"]