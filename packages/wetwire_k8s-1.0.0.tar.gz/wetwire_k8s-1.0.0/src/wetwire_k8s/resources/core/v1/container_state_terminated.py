'''ContainerStateTerminated resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class ContainerStateTerminated:
    """ContainerStateTerminated is a terminated state of a container."""
    containerID: Optional[str] = None
    exitCode: Optional[int] = None
    finishedAt: Optional[Time] = None
    message: Optional[str] = None
    reason: Optional[str] = None
    signal: Optional[int] = None
    startedAt: Optional[Time] = None


__all__ = ["ContainerStateTerminated"]