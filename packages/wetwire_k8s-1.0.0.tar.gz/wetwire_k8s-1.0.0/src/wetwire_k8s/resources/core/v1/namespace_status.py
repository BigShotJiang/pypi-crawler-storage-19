'''NamespaceStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .namespace_condition import NamespaceCondition


@dataclass
class NamespaceStatus:
    """NamespaceStatus is information about the current status of a Namespace."""
    conditions: Optional[list[NamespaceCondition]] = None
    phase: Optional[str] = None


__all__ = ["NamespaceStatus"]