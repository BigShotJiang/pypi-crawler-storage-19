'''NodeCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class NodeCondition:
    """NodeCondition contains condition information for a node."""
    lastHeartbeatTime: Optional[Time] = None
    lastTransitionTime: Optional[Time] = None
    message: Optional[str] = None
    reason: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["NodeCondition"]