'''EventSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class EventSource:
    """EventSource contains information for an event."""
    component: Optional[str] = None
    host: Optional[str] = None


__all__ = ["EventSource"]