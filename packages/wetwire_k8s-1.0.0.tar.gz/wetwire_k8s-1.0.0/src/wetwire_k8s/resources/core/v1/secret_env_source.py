'''SecretEnvSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SecretEnvSource:
    """SecretEnvSource selects a Secret to populate the environment variables with.

The contents of the target Secret's Data field will represent the key-value pairs as environment variables."""
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["SecretEnvSource"]