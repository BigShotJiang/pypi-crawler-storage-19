'''PortStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PortStatus:
    """Kubernetes PortStatus"""
    error: Optional[str] = None
    port: Optional[int] = None
    protocol: Optional[str] = None


__all__ = ["PortStatus"]