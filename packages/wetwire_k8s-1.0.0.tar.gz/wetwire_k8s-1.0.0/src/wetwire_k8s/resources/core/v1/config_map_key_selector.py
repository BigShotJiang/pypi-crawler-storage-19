'''ConfigMapKeySelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ConfigMapKeySelector:
    """Selects a key from a ConfigMap."""
    key: Optional[str] = None
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["ConfigMapKeySelector"]