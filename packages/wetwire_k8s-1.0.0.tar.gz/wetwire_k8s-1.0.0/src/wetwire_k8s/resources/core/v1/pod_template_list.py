'''PodTemplateList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .pod_template import PodTemplate
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class PodTemplateList:
    """PodTemplateList is a list of PodTemplates."""
    apiVersion: Optional[str] = None
    items: Optional[list[PodTemplate]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["PodTemplateList"]