'''Namespace resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .namespace_spec import NamespaceSpec
from .namespace_status import NamespaceStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Namespace:
    """Namespace provides a scope for Names. Use of multiple namespaces is optional."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[NamespaceSpec] = None
    status: Optional[NamespaceStatus] = None


__all__ = ["Namespace"]