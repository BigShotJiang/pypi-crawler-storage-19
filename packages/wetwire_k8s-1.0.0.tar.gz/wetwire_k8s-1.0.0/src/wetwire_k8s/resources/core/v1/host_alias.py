'''HostAlias resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HostAlias:
    """HostAlias holds the mapping between IP and hostnames that will be injected as an entry in the pod's hosts file."""
    hostnames: Optional[list[str]] = None
    ip: Optional[str] = None


__all__ = ["HostAlias"]