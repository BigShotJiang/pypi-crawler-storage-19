'''PreferredSchedulingTerm resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_selector_term import NodeSelectorTerm


@dataclass
class PreferredSchedulingTerm:
    """An empty preferred scheduling term matches all objects with implicit weight 0 (i.e. it's a no-op). A null preferred scheduling term matches no objects (i.e. is also a no-op)."""
    preference: Optional[NodeSelectorTerm] = None
    weight: Optional[int] = None


__all__ = ["PreferredSchedulingTerm"]