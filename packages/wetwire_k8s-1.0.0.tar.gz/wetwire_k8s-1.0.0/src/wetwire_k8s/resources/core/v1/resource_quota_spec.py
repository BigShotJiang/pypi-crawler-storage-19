'''ResourceQuotaSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .scope_selector import ScopeSelector


@dataclass
class ResourceQuotaSpec:
    """ResourceQuotaSpec defines the desired hard limits to enforce for Quota."""
    hard: Optional[dict[str, Any]] = None
    scopeSelector: Optional[ScopeSelector] = None
    scopes: Optional[list[str]] = None


__all__ = ["ResourceQuotaSpec"]