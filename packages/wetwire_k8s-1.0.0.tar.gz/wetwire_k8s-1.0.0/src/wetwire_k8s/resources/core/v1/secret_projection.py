'''SecretProjection resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .key_to_path import KeyToPath


@dataclass
class SecretProjection:
    """Adapts a secret into a projected volume.

The contents of the target Secret's Data field will be presented in a projected volume as files using the keys in the Data field as the file names. Note that this is identical to a secret volume source without the default mode."""
    items: Optional[list[KeyToPath]] = None
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["SecretProjection"]