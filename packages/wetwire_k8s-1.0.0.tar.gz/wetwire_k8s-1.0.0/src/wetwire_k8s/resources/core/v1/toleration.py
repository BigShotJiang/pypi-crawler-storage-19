'''Toleration resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Toleration:
    """The pod this Toleration is attached to tolerates any taint that matches the triple <key,value,effect> using the matching operator <operator>."""
    effect: Optional[str] = None
    key: Optional[str] = None
    operator: Optional[str] = None
    tolerationSeconds: Optional[int] = None
    value: Optional[str] = None


__all__ = ["Toleration"]