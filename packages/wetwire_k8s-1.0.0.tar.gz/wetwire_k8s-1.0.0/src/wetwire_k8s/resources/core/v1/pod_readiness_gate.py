'''PodReadinessGate resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodReadinessGate:
    """PodReadinessGate contains the reference to a pod condition"""
    conditionType: Optional[str] = None


__all__ = ["PodReadinessGate"]