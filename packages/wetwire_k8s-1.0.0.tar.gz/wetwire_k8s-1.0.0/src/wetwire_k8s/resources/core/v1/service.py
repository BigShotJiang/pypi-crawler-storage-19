'''Service resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .service_spec import ServiceSpec
from .service_status import ServiceStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class Service:
    """Service is a named abstraction of software service (for example, mysql) consisting of local port (for example 3306) that the proxy listens on, and the selector that determines which pods will answer requests sent through the proxy."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ServiceSpec] = None
    status: Optional[ServiceStatus] = None


__all__ = ["Service"]