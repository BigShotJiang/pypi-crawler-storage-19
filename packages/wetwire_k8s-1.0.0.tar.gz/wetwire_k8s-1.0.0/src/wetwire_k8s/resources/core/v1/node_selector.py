'''NodeSelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_selector_term import NodeSelectorTerm


@dataclass
class NodeSelector:
    """A node selector represents the union of the results of one or more label queries over a set of nodes; that is, it represents the OR of the selectors represented by the node selector terms."""
    nodeSelectorTerms: Optional[list[NodeSelectorTerm]] = None


__all__ = ["NodeSelector"]