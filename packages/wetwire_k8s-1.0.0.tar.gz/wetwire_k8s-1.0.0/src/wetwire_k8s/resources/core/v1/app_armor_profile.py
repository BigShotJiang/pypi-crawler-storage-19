'''AppArmorProfile resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class AppArmorProfile:
    """AppArmorProfile defines a pod or container's AppArmor settings."""
    localhostProfile: Optional[str] = None
    type: Optional[str] = None


__all__ = ["AppArmorProfile"]