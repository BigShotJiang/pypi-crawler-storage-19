'''HTTPGetAction resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .http_header import HTTPHeader
from wetwire_k8s.resources.meta.v1.int_or_string import IntOrString


@dataclass
class HTTPGetAction:
    """HTTPGetAction describes an action based on HTTP Get requests."""
    host: Optional[str] = None
    httpHeaders: Optional[list[HTTPHeader]] = None
    path: Optional[str] = None
    port: Optional[IntOrString] = None
    scheme: Optional[str] = None


__all__ = ["HTTPGetAction"]