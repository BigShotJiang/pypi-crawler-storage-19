'''PersistentVolume resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume_spec import PersistentVolumeSpec
from .persistent_volume_status import PersistentVolumeStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PersistentVolume:
    """PersistentVolume (PV) is a storage resource provisioned by an administrator. It is analogous to a node. More info: https://kubernetes.io/docs/concepts/storage/persistent-volumes"""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PersistentVolumeSpec] = None
    status: Optional[PersistentVolumeStatus] = None


__all__ = ["PersistentVolume"]