'''TopologySelectorLabelRequirement resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TopologySelectorLabelRequirement:
    """A topology selector requirement is a selector that matches given label. This is an alpha feature and may change in the future."""
    key: Optional[str] = None
    values: Optional[list[str]] = None


__all__ = ["TopologySelectorLabelRequirement"]