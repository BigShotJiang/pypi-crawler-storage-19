'''NodeSystemInfo resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NodeSystemInfo:
    """NodeSystemInfo is a set of ids/uuids to uniquely identify the node."""
    architecture: Optional[str] = None
    bootID: Optional[str] = None
    containerRuntimeVersion: Optional[str] = None
    kernelVersion: Optional[str] = None
    kubeProxyVersion: Optional[str] = None
    kubeletVersion: Optional[str] = None
    machineID: Optional[str] = None
    operatingSystem: Optional[str] = None
    osImage: Optional[str] = None
    systemUUID: Optional[str] = None


__all__ = ["NodeSystemInfo"]