'''ServiceAccount resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference
from .object_reference import ObjectReference
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ServiceAccount:
    """ServiceAccount binds together: * a name, understood by users, and perhaps by peripheral systems, for an identity * a principal that can be authenticated and authorized * a set of secrets"""
    apiVersion: Optional[str] = None
    automountServiceAccountToken: Optional[bool] = None
    imagePullSecrets: Optional[list[LocalObjectReference]] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    secrets: Optional[list[ObjectReference]] = None


__all__ = ["ServiceAccount"]