'''PodSchedulingGate resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodSchedulingGate:
    """PodSchedulingGate is associated to a Pod to guard its scheduling."""
    name: Optional[str] = None


__all__ = ["PodSchedulingGate"]