'''ConfigMapList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .config_map import ConfigMap
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ConfigMapList:
    """ConfigMapList is a resource containing a list of ConfigMap objects."""
    apiVersion: Optional[str] = None
    items: Optional[list[ConfigMap]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ConfigMapList"]