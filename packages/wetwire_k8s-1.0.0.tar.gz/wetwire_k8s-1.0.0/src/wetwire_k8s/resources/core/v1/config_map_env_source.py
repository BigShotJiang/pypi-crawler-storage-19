'''ConfigMapEnvSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ConfigMapEnvSource:
    """ConfigMapEnvSource selects a ConfigMap to populate the environment variables with.

The contents of the target ConfigMap's Data field will represent the key-value pairs as environment variables."""
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["ConfigMapEnvSource"]