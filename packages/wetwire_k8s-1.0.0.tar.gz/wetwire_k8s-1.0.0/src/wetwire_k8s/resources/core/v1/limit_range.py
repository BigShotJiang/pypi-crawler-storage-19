'''LimitRange resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .limit_range_spec import LimitRangeSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class LimitRange:
    """LimitRange sets resource usage limits for each kind of resource in a Namespace."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[LimitRangeSpec] = None


__all__ = ["LimitRange"]