'''ServiceStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .load_balancer_status import LoadBalancerStatus
from wetwire_k8s.resources.meta.v1.condition import Condition


@dataclass
class ServiceStatus:
    """ServiceStatus represents the current status of a service."""
    conditions: Optional[list[Condition]] = None
    loadBalancer: Optional[LoadBalancerStatus] = None


__all__ = ["ServiceStatus"]