'''PodOS resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodOS:
    """PodOS defines the OS parameters of a pod."""
    name: Optional[str] = None


__all__ = ["PodOS"]