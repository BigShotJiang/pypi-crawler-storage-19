'''LimitRangeSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .limit_range_item import LimitRangeItem


@dataclass
class LimitRangeSpec:
    """LimitRangeSpec defines a min/max usage limit for resources that match on kind."""
    limits: Optional[list[LimitRangeItem]] = None


__all__ = ["LimitRangeSpec"]