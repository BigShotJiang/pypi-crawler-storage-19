'''ServiceList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .service import Service
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ServiceList:
    """ServiceList holds a list of services."""
    apiVersion: Optional[str] = None
    items: Optional[list[Service]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ServiceList"]