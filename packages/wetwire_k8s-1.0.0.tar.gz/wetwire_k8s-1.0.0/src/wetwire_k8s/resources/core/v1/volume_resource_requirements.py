'''VolumeResourceRequirements resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class VolumeResourceRequirements:
    """VolumeResourceRequirements describes the storage resource requirements for a volume."""
    limits: Optional[dict[str, Any]] = None
    requests: Optional[dict[str, Any]] = None


__all__ = ["VolumeResourceRequirements"]