'''ReplicationControllerList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .replication_controller import ReplicationController
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ReplicationControllerList:
    """ReplicationControllerList is a collection of replication controllers."""
    apiVersion: Optional[str] = None
    items: Optional[list[ReplicationController]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ReplicationControllerList"]