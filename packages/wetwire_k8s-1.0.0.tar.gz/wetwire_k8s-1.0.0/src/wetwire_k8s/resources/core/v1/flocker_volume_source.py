'''FlockerVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class FlockerVolumeSource:
    """Represents a Flocker volume mounted by the Flocker agent. One and only one of datasetName and datasetUUID should be set. Flocker volumes do not support ownership management or SELinux relabeling."""
    datasetName: Optional[str] = None
    datasetUUID: Optional[str] = None


__all__ = ["FlockerVolumeSource"]