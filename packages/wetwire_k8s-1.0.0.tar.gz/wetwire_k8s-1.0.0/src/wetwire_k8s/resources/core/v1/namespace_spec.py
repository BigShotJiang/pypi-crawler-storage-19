'''NamespaceSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class NamespaceSpec:
    """NamespaceSpec describes the attributes on a Namespace."""
    finalizers: Optional[list[str]] = None


__all__ = ["NamespaceSpec"]