'''SecretKeySelector resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SecretKeySelector:
    """SecretKeySelector selects a key of a Secret."""
    key: Optional[str] = None
    name: Optional[str] = None
    optional: Optional[bool] = None


__all__ = ["SecretKeySelector"]