'''Volume resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .aws_elastic_block_store_volume_source import AWSElasticBlockStoreVolumeSource
from .azure_disk_volume_source import AzureDiskVolumeSource
from .azure_file_volume_source import AzureFileVolumeSource
from .ceph_fs_volume_source import CephFSVolumeSource
from .cinder_volume_source import CinderVolumeSource
from .config_map_volume_source import ConfigMapVolumeSource
from .csi_volume_source import CSIVolumeSource
from .downward_api_volume_source import DownwardAPIVolumeSource
from .empty_dir_volume_source import EmptyDirVolumeSource
from .ephemeral_volume_source import EphemeralVolumeSource
from .fc_volume_source import FCVolumeSource
from .flex_volume_source import FlexVolumeSource
from .flocker_volume_source import FlockerVolumeSource
from .gce_persistent_disk_volume_source import GCEPersistentDiskVolumeSource
from .git_repo_volume_source import GitRepoVolumeSource
from .glusterfs_volume_source import GlusterfsVolumeSource
from .host_path_volume_source import HostPathVolumeSource
from .iscsi_volume_source import ISCSIVolumeSource
from .nfs_volume_source import NFSVolumeSource
from .persistent_volume_claim_volume_source import PersistentVolumeClaimVolumeSource
from .photon_persistent_disk_volume_source import PhotonPersistentDiskVolumeSource
from .portworx_volume_source import PortworxVolumeSource
from .projected_volume_source import ProjectedVolumeSource
from .quobyte_volume_source import QuobyteVolumeSource
from .rbd_volume_source import RBDVolumeSource
from .scale_io_volume_source import ScaleIOVolumeSource
from .secret_volume_source import SecretVolumeSource
from .storage_os_volume_source import StorageOSVolumeSource
from .vsphere_virtual_disk_volume_source import VsphereVirtualDiskVolumeSource


@dataclass
class Volume:
    """Volume represents a named volume in a pod that may be accessed by any container in the pod."""
    awsElasticBlockStore: Optional[AWSElasticBlockStoreVolumeSource] = None
    azureDisk: Optional[AzureDiskVolumeSource] = None
    azureFile: Optional[AzureFileVolumeSource] = None
    cephfs: Optional[CephFSVolumeSource] = None
    cinder: Optional[CinderVolumeSource] = None
    configMap: Optional[ConfigMapVolumeSource] = None
    csi: Optional[CSIVolumeSource] = None
    downwardAPI: Optional[DownwardAPIVolumeSource] = None
    emptyDir: Optional[EmptyDirVolumeSource] = None
    ephemeral: Optional[EphemeralVolumeSource] = None
    fc: Optional[FCVolumeSource] = None
    flexVolume: Optional[FlexVolumeSource] = None
    flocker: Optional[FlockerVolumeSource] = None
    gcePersistentDisk: Optional[GCEPersistentDiskVolumeSource] = None
    gitRepo: Optional[GitRepoVolumeSource] = None
    glusterfs: Optional[GlusterfsVolumeSource] = None
    hostPath: Optional[HostPathVolumeSource] = None
    iscsi: Optional[ISCSIVolumeSource] = None
    name: Optional[str] = None
    nfs: Optional[NFSVolumeSource] = None
    persistentVolumeClaim: Optional[PersistentVolumeClaimVolumeSource] = None
    photonPersistentDisk: Optional[PhotonPersistentDiskVolumeSource] = None
    portworxVolume: Optional[PortworxVolumeSource] = None
    projected: Optional[ProjectedVolumeSource] = None
    quobyte: Optional[QuobyteVolumeSource] = None
    rbd: Optional[RBDVolumeSource] = None
    scaleIO: Optional[ScaleIOVolumeSource] = None
    secret: Optional[SecretVolumeSource] = None
    storageos: Optional[StorageOSVolumeSource] = None
    vsphereVolume: Optional[VsphereVirtualDiskVolumeSource] = None


__all__ = ["Volume"]