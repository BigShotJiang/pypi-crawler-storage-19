'''Affinity resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_affinity import NodeAffinity
from .pod_affinity import PodAffinity
from .pod_anti_affinity import PodAntiAffinity


@dataclass
class Affinity:
    """Affinity is a group of affinity scheduling rules."""
    nodeAffinity: Optional[NodeAffinity] = None
    podAffinity: Optional[PodAffinity] = None
    podAntiAffinity: Optional[PodAntiAffinity] = None


__all__ = ["Affinity"]