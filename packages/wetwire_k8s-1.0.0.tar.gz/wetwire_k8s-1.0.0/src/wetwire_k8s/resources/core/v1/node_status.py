'''NodeStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .attached_volume import AttachedVolume
from .container_image import ContainerImage
from .node_address import NodeAddress
from .node_condition import NodeCondition
from .node_config_status import NodeConfigStatus
from .node_daemon_endpoints import NodeDaemonEndpoints
from .node_runtime_handler import NodeRuntimeHandler
from .node_system_info import NodeSystemInfo


@dataclass
class NodeStatus:
    """NodeStatus is information about the current status of a node."""
    addresses: Optional[list[NodeAddress]] = None
    allocatable: Optional[dict[str, Any]] = None
    capacity: Optional[dict[str, Any]] = None
    conditions: Optional[list[NodeCondition]] = None
    config: Optional[NodeConfigStatus] = None
    daemonEndpoints: Optional[NodeDaemonEndpoints] = None
    images: Optional[list[ContainerImage]] = None
    nodeInfo: Optional[NodeSystemInfo] = None
    phase: Optional[str] = None
    runtimeHandlers: Optional[list[NodeRuntimeHandler]] = None
    volumesAttached: Optional[list[AttachedVolume]] = None
    volumesInUse: Optional[list[str]] = None


__all__ = ["NodeStatus"]