'''GlusterfsVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class GlusterfsVolumeSource:
    """Represents a Glusterfs mount that lasts the lifetime of a pod. Glusterfs volumes do not support ownership management or SELinux relabeling."""
    endpoints: Optional[str] = None
    path: Optional[str] = None
    readOnly: Optional[bool] = None


__all__ = ["GlusterfsVolumeSource"]