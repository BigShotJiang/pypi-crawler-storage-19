'''ClientIPConfig resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ClientIPConfig:
    """ClientIPConfig represents the configurations of Client IP based session affinity."""
    timeoutSeconds: Optional[int] = None


__all__ = ["ClientIPConfig"]