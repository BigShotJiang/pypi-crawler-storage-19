'''PersistentVolumeClaimTemplate resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .persistent_volume_claim_spec import PersistentVolumeClaimSpec
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class PersistentVolumeClaimTemplate:
    """PersistentVolumeClaimTemplate is used to produce PersistentVolumeClaim objects as part of an EphemeralVolumeSource."""
    metadata: Optional[ObjectMeta] = None
    spec: Optional[PersistentVolumeClaimSpec] = None


__all__ = ["PersistentVolumeClaimTemplate"]