'''ServiceSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .service_port import ServicePort
from .session_affinity_config import SessionAffinityConfig


@dataclass
class ServiceSpec:
    """ServiceSpec describes the attributes that a user creates on a service."""
    allocateLoadBalancerNodePorts: Optional[bool] = None
    clusterIP: Optional[str] = None
    clusterIPs: Optional[list[str]] = None
    externalIPs: Optional[list[str]] = None
    externalName: Optional[str] = None
    externalTrafficPolicy: Optional[str] = None
    healthCheckNodePort: Optional[int] = None
    internalTrafficPolicy: Optional[str] = None
    ipFamilies: Optional[list[str]] = None
    ipFamilyPolicy: Optional[str] = None
    loadBalancerClass: Optional[str] = None
    loadBalancerIP: Optional[str] = None
    loadBalancerSourceRanges: Optional[list[str]] = None
    ports: Optional[list[ServicePort]] = None
    publishNotReadyAddresses: Optional[bool] = None
    selector: Optional[dict[str, Any]] = None
    sessionAffinity: Optional[str] = None
    sessionAffinityConfig: Optional[SessionAffinityConfig] = None
    trafficDistribution: Optional[str] = None
    type: Optional[str] = None


__all__ = ["ServiceSpec"]