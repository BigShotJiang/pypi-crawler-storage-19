'''VolumeNodeAffinity resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_selector import NodeSelector


@dataclass
class VolumeNodeAffinity:
    """VolumeNodeAffinity defines constraints that limit what nodes this volume can be accessed from."""
    required: Optional[NodeSelector] = None


__all__ = ["VolumeNodeAffinity"]