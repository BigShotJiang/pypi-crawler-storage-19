'''TypedObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TypedObjectReference:
    """Kubernetes TypedObjectReference"""
    apiGroup: Optional[str] = None
    kind: Optional[str] = None
    name: Optional[str] = None
    namespace: Optional[str] = None


__all__ = ["TypedObjectReference"]