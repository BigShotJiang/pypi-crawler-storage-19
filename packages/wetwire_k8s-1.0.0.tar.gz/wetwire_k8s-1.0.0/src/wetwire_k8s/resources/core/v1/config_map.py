'''ConfigMap resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ConfigMap:
    """ConfigMap holds configuration data for pods to consume."""
    apiVersion: Optional[str] = None
    binaryData: Optional[dict[str, Any]] = None
    data: Optional[dict[str, Any]] = None
    immutable: Optional[bool] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None


__all__ = ["ConfigMap"]