'''NamespaceList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .namespace import Namespace
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class NamespaceList:
    """NamespaceList is a list of Namespaces."""
    apiVersion: Optional[str] = None
    items: Optional[list[Namespace]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["NamespaceList"]