'''LocalObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class LocalObjectReference:
    """LocalObjectReference contains enough information to let you locate the referenced object inside the same namespace."""
    name: Optional[str] = None


__all__ = ["LocalObjectReference"]