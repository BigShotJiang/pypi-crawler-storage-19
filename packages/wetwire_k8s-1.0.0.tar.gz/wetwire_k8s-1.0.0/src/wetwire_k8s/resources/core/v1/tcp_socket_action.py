'''TCPSocketAction resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.int_or_string import IntOrString


@dataclass
class TCPSocketAction:
    """TCPSocketAction describes an action based on opening a socket"""
    host: Optional[str] = None
    port: Optional[IntOrString] = None


__all__ = ["TCPSocketAction"]