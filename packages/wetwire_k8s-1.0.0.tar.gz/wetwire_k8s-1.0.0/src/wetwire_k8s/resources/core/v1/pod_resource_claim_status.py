'''PodResourceClaimStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PodResourceClaimStatus:
    """PodResourceClaimStatus is stored in the PodStatus for each PodResourceClaim which references a ResourceClaimTemplate. It stores the generated name for the corresponding ResourceClaim."""
    name: Optional[str] = None
    resourceClaimName: Optional[str] = None


__all__ = ["PodResourceClaimStatus"]