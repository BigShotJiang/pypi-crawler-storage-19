'''PodSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .affinity import Affinity
from .container import Container
from .ephemeral_container import EphemeralContainer
from .host_alias import HostAlias
from .local_object_reference import LocalObjectReference
from .pod_dns_config import PodDNSConfig
from .pod_os import PodOS
from .pod_readiness_gate import PodReadinessGate
from .pod_resource_claim import PodResourceClaim
from .pod_scheduling_gate import PodSchedulingGate
from .pod_security_context import PodSecurityContext
from .toleration import Toleration
from .topology_spread_constraint import TopologySpreadConstraint
from .volume import Volume


@dataclass
class PodSpec:
    """PodSpec is a description of a pod."""
    activeDeadlineSeconds: Optional[int] = None
    affinity: Optional[Affinity] = None
    automountServiceAccountToken: Optional[bool] = None
    containers: Optional[list[Container]] = None
    dnsConfig: Optional[PodDNSConfig] = None
    dnsPolicy: Optional[str] = None
    enableServiceLinks: Optional[bool] = None
    ephemeralContainers: Optional[list[EphemeralContainer]] = None
    hostAliases: Optional[list[HostAlias]] = None
    hostIPC: Optional[bool] = None
    hostNetwork: Optional[bool] = None
    hostPID: Optional[bool] = None
    hostUsers: Optional[bool] = None
    hostname: Optional[str] = None
    imagePullSecrets: Optional[list[LocalObjectReference]] = None
    initContainers: Optional[list[Container]] = None
    nodeName: Optional[str] = None
    nodeSelector: Optional[dict[str, Any]] = None
    os: Optional[PodOS] = None
    overhead: Optional[dict[str, Any]] = None
    preemptionPolicy: Optional[str] = None
    priority: Optional[int] = None
    priorityClassName: Optional[str] = None
    readinessGates: Optional[list[PodReadinessGate]] = None
    resourceClaims: Optional[list[PodResourceClaim]] = None
    restartPolicy: Optional[str] = None
    runtimeClassName: Optional[str] = None
    schedulerName: Optional[str] = None
    schedulingGates: Optional[list[PodSchedulingGate]] = None
    securityContext: Optional[PodSecurityContext] = None
    serviceAccount: Optional[str] = None
    serviceAccountName: Optional[str] = None
    setHostnameAsFQDN: Optional[bool] = None
    shareProcessNamespace: Optional[bool] = None
    subdomain: Optional[str] = None
    terminationGracePeriodSeconds: Optional[int] = None
    tolerations: Optional[list[Toleration]] = None
    topologySpreadConstraints: Optional[list[TopologySpreadConstraint]] = None
    volumes: Optional[list[Volume]] = None


__all__ = ["PodSpec"]