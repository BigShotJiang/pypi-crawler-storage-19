'''NodeAffinity resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .node_selector import NodeSelector
from .preferred_scheduling_term import PreferredSchedulingTerm


@dataclass
class NodeAffinity:
    """Node affinity is a group of node affinity scheduling rules."""
    preferredDuringSchedulingIgnoredDuringExecution: Optional[list[PreferredSchedulingTerm]] = None
    requiredDuringSchedulingIgnoredDuringExecution: Optional[NodeSelector] = None


__all__ = ["NodeAffinity"]