'''ContainerStateWaiting resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ContainerStateWaiting:
    """ContainerStateWaiting is a waiting state of a container."""
    message: Optional[str] = None
    reason: Optional[str] = None


__all__ = ["ContainerStateWaiting"]