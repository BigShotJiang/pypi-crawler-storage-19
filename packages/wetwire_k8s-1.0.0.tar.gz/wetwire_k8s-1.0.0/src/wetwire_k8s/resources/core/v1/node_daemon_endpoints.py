'''NodeDaemonEndpoints resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .daemon_endpoint import DaemonEndpoint


@dataclass
class NodeDaemonEndpoints:
    """NodeDaemonEndpoints lists ports opened by daemons running on the Node."""
    kubeletEndpoint: Optional[DaemonEndpoint] = None


__all__ = ["NodeDaemonEndpoints"]