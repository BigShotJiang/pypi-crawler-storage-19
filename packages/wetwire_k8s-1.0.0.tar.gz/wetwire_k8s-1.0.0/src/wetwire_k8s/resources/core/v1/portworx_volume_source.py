'''PortworxVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class PortworxVolumeSource:
    """PortworxVolumeSource represents a Portworx volume resource."""
    fsType: Optional[str] = None
    readOnly: Optional[bool] = None
    volumeID: Optional[str] = None


__all__ = ["PortworxVolumeSource"]