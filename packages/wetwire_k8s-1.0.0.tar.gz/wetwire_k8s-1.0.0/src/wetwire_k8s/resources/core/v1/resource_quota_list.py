'''ResourceQuotaList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .resource_quota import ResourceQuota
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class ResourceQuotaList:
    """ResourceQuotaList is a list of ResourceQuota items."""
    apiVersion: Optional[str] = None
    items: Optional[list[ResourceQuota]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["ResourceQuotaList"]