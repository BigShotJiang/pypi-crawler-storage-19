'''ComponentStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .component_condition import ComponentCondition
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ComponentStatus:
    """ComponentStatus (and ComponentStatusList) holds the cluster validation info. Deprecated: This API is deprecated in v1.19+"""
    apiVersion: Optional[str] = None
    conditions: Optional[list[ComponentCondition]] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None


__all__ = ["ComponentStatus"]