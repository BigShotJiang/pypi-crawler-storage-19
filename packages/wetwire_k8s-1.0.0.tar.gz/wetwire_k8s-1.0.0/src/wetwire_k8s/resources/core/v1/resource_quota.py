'''ResourceQuota resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .resource_quota_spec import ResourceQuotaSpec
from .resource_quota_status import ResourceQuotaStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class ResourceQuota:
    """ResourceQuota sets aggregate quota restrictions enforced per namespace"""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[ResourceQuotaSpec] = None
    status: Optional[ResourceQuotaStatus] = None


__all__ = ["ResourceQuota"]