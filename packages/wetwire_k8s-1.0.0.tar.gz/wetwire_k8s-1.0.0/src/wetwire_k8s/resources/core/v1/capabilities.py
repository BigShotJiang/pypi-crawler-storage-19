'''Capabilities resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class Capabilities:
    """Adds and removes POSIX capabilities from running containers."""
    add: Optional[list[str]] = None
    drop: Optional[list[str]] = None


__all__ = ["Capabilities"]