'''ContainerImage resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ContainerImage:
    """Describe a container image"""
    names: Optional[list[str]] = None
    sizeBytes: Optional[int] = None


__all__ = ["ContainerImage"]