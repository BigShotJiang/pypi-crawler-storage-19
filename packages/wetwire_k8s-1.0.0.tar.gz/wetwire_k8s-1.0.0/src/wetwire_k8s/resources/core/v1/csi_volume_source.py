'''CSIVolumeSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .local_object_reference import LocalObjectReference


@dataclass
class CSIVolumeSource:
    """Represents a source location of a volume to mount, managed by an external CSI driver"""
    driver: Optional[str] = None
    fsType: Optional[str] = None
    nodePublishSecretRef: Optional[LocalObjectReference] = None
    readOnly: Optional[bool] = None
    volumeAttributes: Optional[dict[str, Any]] = None


__all__ = ["CSIVolumeSource"]