'''HTTPHeader resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HTTPHeader:
    """HTTPHeader describes a custom header to be used in HTTP probes"""
    name: Optional[str] = None
    value: Optional[str] = None


__all__ = ["HTTPHeader"]