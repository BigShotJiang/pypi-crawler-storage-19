'''PersistentVolumeStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class PersistentVolumeStatus:
    """PersistentVolumeStatus is the current status of a persistent volume."""
    lastPhaseTransitionTime: Optional[Time] = None
    message: Optional[str] = None
    phase: Optional[str] = None
    reason: Optional[str] = None


__all__ = ["PersistentVolumeStatus"]