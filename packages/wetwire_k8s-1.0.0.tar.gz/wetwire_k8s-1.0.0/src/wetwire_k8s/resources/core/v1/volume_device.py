'''VolumeDevice resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class VolumeDevice:
    """volumeDevice describes a mapping of a raw block device within a container."""
    devicePath: Optional[str] = None
    name: Optional[str] = None


__all__ = ["VolumeDevice"]