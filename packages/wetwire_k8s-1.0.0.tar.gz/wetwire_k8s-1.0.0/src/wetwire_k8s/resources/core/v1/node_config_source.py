'''NodeConfigSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .config_map_node_config_source import ConfigMapNodeConfigSource


@dataclass
class NodeConfigSource:
    """NodeConfigSource specifies a source of node configuration. Exactly one subfield (excluding metadata) must be non-nil. This API is deprecated since 1.22"""
    configMap: Optional[ConfigMapNodeConfigSource] = None


__all__ = ["NodeConfigSource"]