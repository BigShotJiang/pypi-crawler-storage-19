'''EnvFromSource resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .config_map_env_source import ConfigMapEnvSource
from .secret_env_source import SecretEnvSource


@dataclass
class EnvFromSource:
    """EnvFromSource represents the source of a set of ConfigMaps"""
    configMapRef: Optional[ConfigMapEnvSource] = None
    prefix: Optional[str] = None
    secretRef: Optional[SecretEnvSource] = None


__all__ = ["EnvFromSource"]