'''Kubernetes authentication/v1beta1 resources.'''

from .self_subject_review import SelfSubjectReview
from .self_subject_review_status import SelfSubjectReviewStatus

__all__ = ["SelfSubjectReview", "SelfSubjectReviewStatus"]