"""Kubernetes authentication resources."""
