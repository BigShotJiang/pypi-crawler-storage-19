'''BoundObjectReference resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class BoundObjectReference:
    """BoundObjectReference is a reference to an object that a token is bound to."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    name: Optional[str] = None
    uid: Optional[str] = None


__all__ = ["BoundObjectReference"]