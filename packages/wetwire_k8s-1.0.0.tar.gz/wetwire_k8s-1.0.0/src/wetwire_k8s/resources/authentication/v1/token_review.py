'''TokenReview resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .token_review_spec import TokenReviewSpec
from .token_review_status import TokenReviewStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class TokenReview:
    """TokenReview attempts to authenticate a token to a known user. Note: TokenReview requests may be cached by the webhook token authenticator plugin in the kube-apiserver."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[TokenReviewSpec] = None
    status: Optional[TokenReviewStatus] = None


__all__ = ["TokenReview"]