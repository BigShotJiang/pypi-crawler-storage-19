'''UserInfo resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class UserInfo:
    """UserInfo holds the information about the user needed to implement the user.Info interface."""
    extra: Optional[dict[str, Any]] = None
    groups: Optional[list[str]] = None
    uid: Optional[str] = None
    username: Optional[str] = None


__all__ = ["UserInfo"]