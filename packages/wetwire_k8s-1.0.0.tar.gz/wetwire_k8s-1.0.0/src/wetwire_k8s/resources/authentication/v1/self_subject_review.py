'''SelfSubjectReview resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .self_subject_review_status import SelfSubjectReviewStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class SelfSubjectReview:
    """SelfSubjectReview contains the user information that the kube-apiserver has about the user making this request. When using impersonation, users will receive the user info of the user being impersonated.  If impersonation or request header authentication is used, any extra keys will have their case ignored and returned as lowercase."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    status: Optional[SelfSubjectReviewStatus] = None


__all__ = ["SelfSubjectReview"]