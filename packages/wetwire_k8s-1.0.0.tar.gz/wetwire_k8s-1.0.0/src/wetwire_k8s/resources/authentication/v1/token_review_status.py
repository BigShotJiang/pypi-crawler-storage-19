'''TokenReviewStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .user_info import UserInfo


@dataclass
class TokenReviewStatus:
    """TokenReviewStatus is the result of the token authentication request."""
    audiences: Optional[list[str]] = None
    authenticated: Optional[bool] = None
    error: Optional[str] = None
    user: Optional[UserInfo] = None


__all__ = ["TokenReviewStatus"]