'''TokenRequestSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .bound_object_reference import BoundObjectReference


@dataclass
class TokenRequestSpec:
    """TokenRequestSpec contains client provided parameters of a token request."""
    audiences: Optional[list[str]] = None
    boundObjectRef: Optional[BoundObjectReference] = None
    expirationSeconds: Optional[int] = None


__all__ = ["TokenRequestSpec"]