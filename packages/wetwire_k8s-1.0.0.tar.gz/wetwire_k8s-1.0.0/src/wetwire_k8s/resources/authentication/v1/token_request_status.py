'''TokenRequestStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class TokenRequestStatus:
    """TokenRequestStatus is the result of a token request."""
    expirationTimestamp: Optional[Time] = None
    token: Optional[str] = None


__all__ = ["TokenRequestStatus"]