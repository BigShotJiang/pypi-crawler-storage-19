'''TokenReviewSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class TokenReviewSpec:
    """TokenReviewSpec is a description of the token authentication request."""
    audiences: Optional[list[str]] = None
    token: Optional[str] = None


__all__ = ["TokenReviewSpec"]