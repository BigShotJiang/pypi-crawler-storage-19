'''SelfSubjectReviewStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .user_info import UserInfo


@dataclass
class SelfSubjectReviewStatus:
    """SelfSubjectReviewStatus is filled by the kube-apiserver and sent back to a user."""
    userInfo: Optional[UserInfo] = None


__all__ = ["SelfSubjectReviewStatus"]