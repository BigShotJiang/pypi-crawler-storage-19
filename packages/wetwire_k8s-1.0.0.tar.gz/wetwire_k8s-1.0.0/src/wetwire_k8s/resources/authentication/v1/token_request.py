'''TokenRequest resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .token_request_spec import TokenRequestSpec
from .token_request_status import TokenRequestStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class TokenRequest:
    """TokenRequest requests a token for a given service account."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[TokenRequestSpec] = None
    status: Optional[TokenRequestStatus] = None


__all__ = ["TokenRequest"]