'''StorageVersionCondition resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from wetwire_k8s.resources.meta.v1.time import Time


@dataclass
class StorageVersionCondition:
    """Describes the state of the storageVersion at a certain point."""
    lastTransitionTime: Optional[Time] = None
    message: Optional[str] = None
    observedGeneration: Optional[int] = None
    reason: Optional[str] = None
    status: Optional[str] = None
    type: Optional[str] = None


__all__ = ["StorageVersionCondition"]