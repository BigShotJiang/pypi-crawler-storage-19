'''StorageVersionList resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .storage_version import StorageVersion
from wetwire_k8s.resources.meta.v1.list_meta import ListMeta


@dataclass
class StorageVersionList:
    """A list of StorageVersions."""
    apiVersion: Optional[str] = None
    items: Optional[list[StorageVersion]] = None
    kind: Optional[str] = None
    metadata: Optional[ListMeta] = None


__all__ = ["StorageVersionList"]