'''StorageVersionStatus resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .server_storage_version import ServerStorageVersion
from .storage_version_condition import StorageVersionCondition


@dataclass
class StorageVersionStatus:
    """API server instances report the versions they can decode and the version they encode objects to when persisting objects in the backend."""
    commonEncodingVersion: Optional[str] = None
    conditions: Optional[list[StorageVersionCondition]] = None
    storageVersions: Optional[list[ServerStorageVersion]] = None


__all__ = ["StorageVersionStatus"]