'''ServerStorageVersion resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class ServerStorageVersion:
    """An API server instance reports the version it can decode and the version it encodes objects to when persisting objects in the backend."""
    apiServerID: Optional[str] = None
    decodableVersions: Optional[list[str]] = None
    encodingVersion: Optional[str] = None
    servedVersions: Optional[list[str]] = None


__all__ = ["ServerStorageVersion"]