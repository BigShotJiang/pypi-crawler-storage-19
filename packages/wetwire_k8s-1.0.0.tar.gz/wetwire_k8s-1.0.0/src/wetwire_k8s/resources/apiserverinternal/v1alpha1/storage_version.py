'''StorageVersion resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional
from .storage_version_spec import StorageVersionSpec
from .storage_version_status import StorageVersionStatus
from wetwire_k8s.resources.meta.v1.object_meta import ObjectMeta


@dataclass
class StorageVersion:
    """Storage version of a specific resource."""
    apiVersion: Optional[str] = None
    kind: Optional[str] = None
    metadata: Optional[ObjectMeta] = None
    spec: Optional[StorageVersionSpec] = None
    status: Optional[StorageVersionStatus] = None


__all__ = ["StorageVersion"]