'''StorageVersionSpec resource for Kubernetes.'''

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class StorageVersionSpec:
    """StorageVersionSpec is an empty spec."""
    pass


__all__ = ["StorageVersionSpec"]