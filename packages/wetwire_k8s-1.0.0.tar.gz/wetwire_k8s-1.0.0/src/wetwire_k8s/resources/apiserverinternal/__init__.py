"""Kubernetes apiserverinternal resources."""
