import re
import traceback
import json
import uuid
import asyncio
import aiohttp

import os
import PyPDF2
import numpy as np
from pathlib import Path
from aiohttp import FormData
from docx import Document

from himile_log import logger


def compare(remaining_ids_before_list, remaining_ids_after_list):
    """
        @brief: 对比两个列表的差异，并返回不同元素组成的list。
        @param: remaining_ids_before_list : 第一个list，表示操作前的状态
        @param: remaining_ids_after_list : 第二个list，表示操作后的状态
        @return: differences (list): 包含两个list中不同元素的list
        @Author: 贾松晴20232256
        @Time: 20240807
    """
    # 备注：方法多次调用，不添加函数入口日志
    # 对比两个列表的不同，使用set差集原理找出只在其中一个列表中存在的元素
    differences = [i for i in remaining_ids_before_list + remaining_ids_after_list
                   if i not in remaining_ids_after_list or i not in remaining_ids_before_list]
    return differences


def deduplicate_documents(documents):
    """
    对按相关度排序的文档列表进行去重，保留每个文档名称中相关度最高的记录

    Args:
        documents: list[dict] - 文档列表，每个文档是包含'文档名称'和'文档内容'等字段的字典，
                    且列表已按相关度从高到低排序

    Returns:
        list[dict] - 去重后的文档列表，保留每个文档名称的第一条记录(即相关度最高的)

    Raises:
        ValueError: 如果输入不是列表或文档缺少必要字段
        TypeError: 如果文档不是字典类型
    """
    # 配置日志
    logger.info("开始文档去重处理，输入文档数量: %d", len(documents))

    # 参数校验
    if not isinstance(documents, list):
        error_msg = "输入参数documents必须是列表类型"
        logger.error(error_msg)
        raise ValueError(error_msg)

    seen = set()  # 用于记录已处理的文档名称
    result = []  # 存储去重后的结果

    try:
        for idx, doc in enumerate(documents):
            # 文档类型校验
            if not isinstance(doc, dict):
                error_msg = f"文档记录必须是字典类型，第{idx}条记录类型为{type(doc)}"
                logger.error(error_msg)
                raise TypeError(error_msg)

            # 检查必要字段
            if 'id' not in doc:
                error_msg = f"文档缺少'id'字段，第{idx}条记录"
                logger.error(error_msg)
                raise ValueError(error_msg)

            doc_id = doc['id']

            # 检查ID长度是否足够
            if len(doc_id) <= 6:
                error_msg = f"文档ID长度不足，至少需要7位，第{idx}条记录ID为{doc_id}"
                logger.error(error_msg)
                raise ValueError(error_msg)

            # 获取文档ID前缀（去除最后6位）
            doc_prefix = doc_id[:-6]

            if doc_prefix not in seen:
                seen.add(doc_prefix)
                result.append(doc)
                logger.debug(f"添加文档: ID={doc_id} (前缀={doc_prefix})")

    except Exception as e:
        error_traceback = traceback.format_exc()
        logger.error(f"文档去重处理过程中发生异常: {error_traceback}", )
        raise  # 重新抛出异常

    logger.info(f"文档去重完成，输出文档数量: {len(result)}", )
    return result


def rmWWW(txt: str) -> str:
    """
    移除文本中的疑问词、停用词和常见功能词（中英文）

    功能描述：
    1. 移除中文疑问词和停用词（如"什么样的"、"吗"、"呢"等）
    2. 移除英文疑问词（如"what"、"who"、"how"等）
    3. 移除英文常见功能词和停用词（如"is"、"are"、"the"、"a"等）
    4. 如果处理结果为空字符串，则返回原始文本

    参数:
        txt (str): 需要处理的原始文本字符串

    返回:
        str: 处理后的文本字符串，移除了指定的词语

    异常:
        TypeError: 如果输入参数不是字符串类型
        Exception: 处理过程中可能出现的其他异常
    """
    try:
        # 入口日志
        logger.info(f"Function rmWWW started. Input text: '{txt[:50]}...'"
                     if len(txt) > 50 else f"Function started. Input text: '{txt}'")

        # 参数类型检查
        if not isinstance(txt, str):
            raise TypeError("Input must be a string")

        # 保存原始文本以备回退
        original_txt = txt

        # 定义要移除的模式列表
        patterns = [
            # 中文疑问词和停用词
            (
                r"是*(什么样的|哪家|一下|那家|请问|啥样|咋样了|什么时候|何时|何地|何人|是否|是不是|多少|哪里|怎么|哪儿|怎么样|如何|哪些|是啥|啥是|啊|吗|呢|吧|咋|什么|有没有|呀|谁|哪位|哪个)是*",
                "",
            ),
            # 英文基本疑问词
            (r"(^| )(what|who|how|which|where|why)('re|'s)? ", " "),
            # 英文常见功能词和停用词
            (
                r"(^| )('s|'re|is|are|were|was|do|does|did|don't|doesn't|didn't|has|have|be|there|you|me|your|my|mine|just|please|may|i|should|would|wouldn't|will|won't|done|go|for|with|so|the|a|an|by|i'm|it's|he's|she's|they|they're|you're|as|by|on|in|at|up|out|down|of|to|or|and|if) ",
                " "
            )
        ]

        # 应用所有替换模式
        for pattern, replacement in patterns:
            txt = re.sub(pattern, replacement, txt, flags=re.IGNORECASE)

        # 处理结果为空时回退到原始文本
        if not txt.strip():
            txt = original_txt
            logger.warning("Processing resulted in empty string, reverting to original")

        # 出口日志
        logger.info(f"Function completed. Output text: '{txt[:50]}...'"
                     if len(txt) > 50 else f"Function completed. Output text: '{txt}'")

        return txt
    except Exception as e:
        error_traceback = traceback.format_exc()
        logger.error(f"Unexpected error in rmWWW: {str(e)}, {error_traceback}")
        raise


def add_space_between_eng_zh(txt: str) -> str:
    """
    在中英文/中英文数字之间添加空格

    功能描述：
    1. 处理英文数字组合与中文之间的情况（如 "abc123中文" → "abc123 中文"）
    2. 处理纯英文与中文之间的情况（如 "abc中文" → "abc 中文"）
    3. 处理中文与英文数字组合之间的情况（如 "中文abc123" → "中文 abc123"）
    4. 处理中文与纯英文之间的情况（如 "中文abc" → "中文 abc"）

    参数:
        txt (str): 需要处理的原始文本字符串

    返回:
        str: 处理后的文本字符串，中英文之间添加了空格

    异常:
        TypeError: 如果输入参数不是字符串类型
        Exception: 处理过程中可能出现的其他异常
    """
    try:
        # 入口日志
        logger.info(f"Function started. Input text length: {len(txt)}")

        # 参数类型检查
        if not isinstance(txt, str):
            raise TypeError("Input must be a string")

        # (ENG/ENG+NUM) + ZH
        txt = re.sub(r'([A-Za-z]+[0-9]+)([\u4e00-\u9fa5]+)', r'\1 \2', txt)
        # ENG + ZH
        txt = re.sub(r'([A-Za-z])([\u4e00-\u9fa5]+)', r'\1 \2', txt)
        # ZH + (ENG/ENG+NUM)
        txt = re.sub(r'([\u4e00-\u9fa5]+)([A-Za-z]+[0-9]+)', r'\1 \2', txt)
        txt = re.sub(r'([\u4e00-\u9fa5]+)([A-Za-z])', r'\1 \2', txt)

        # 出口日志
        logger.info(f"Function completed successfully. Output text length: {len(txt)}")
        return txt

    except Exception as e:
        error_traceback = traceback.format_exc()
        logger.error(f"Unexpected error occurred: {str(e)}, {error_traceback}")
        raise


def append_to_json_list(filename, new_item):
    """
    将新项追加到JSON文件的列表中
    :param filename: JSON文件路径
    :param new_item: 要追加的新项
    """
    file_path = Path(filename)

    # 读取现有数据或创建新列表
    if file_path.exists():
        try:
            with file_path.open('r', encoding='utf-8') as f:
                data = json.load(f)
        except json.JSONDecodeError:
            data = []
    else:
        data = []

    # 追加新项目
    data.append(new_item)

    # 写回文件
    with file_path.open('w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


async def calculate_similarity(vector1, vector2):
    # 计算两个向量的点积
    dot_product = np.dot(vector1, vector2)
    # 计算两个向量的模长
    magnitude1 = np.linalg.norm(vector1)
    magnitude2 = np.linalg.norm(vector2)
    # 计算余弦相似度
    similarity = dot_product / (magnitude1 * magnitude2)
    return similarity


