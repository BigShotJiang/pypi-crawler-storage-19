from .embeddings_text import Embeddings

__all__ = ['Embeddings']