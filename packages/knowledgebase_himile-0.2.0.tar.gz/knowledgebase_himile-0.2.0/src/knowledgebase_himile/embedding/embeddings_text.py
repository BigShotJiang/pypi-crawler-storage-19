import asyncio
import os
from typing import List, Dict, Any

import aiohttp
import yaml
from aiohttp import ClientTimeout


class Embeddings:
    """
    向量化服务
    """

    def __init__(self, logger, embedding_config: Dict[str, Any] = None):
        """
        Args:
            logger: 日志记录器
            embedding_config: 向量配置字典
              -url 向量模型地址
              -model_name 向量模型名称
              -timeout 模型响应超时时间（默认600s）
        """
        self.logger = logger
        if embedding_config is None:
            config_path = os.path.expanduser('~/.knowledgebase_himile/config.yaml')
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                embedding_config = config.get('embedding', {})
                logger.info(f"Loaded embedding configs: {list(embedding_config.keys())}")
            except (FileNotFoundError, yaml.YAMLError, Exception) as e:
                logger.warning(f"Failed to load embedding config from {config_path}: {e}")
                embedding_config = {}

        # 设置属性
        self.url = embedding_config.get('url', '')
        self.model = embedding_config.get('model_name', '')
        self.timeout = embedding_config.get('timeout', 600)

    async def embedding_text(self, text_content: List[str]):
        """
        向量化文本
        :param text_content: 文本列表
        :return: embedding_content: 向量化列表
        """
        embedding_content = []
        for text in text_content:
            try:
                # 调用向量化服务
                async with aiohttp.ClientSession() as session:
                    async with session.post(url=self.url,
                                            json={'input': text, 'model': self.model},
                                            timeout=ClientTimeout(total=600)) as response:
                        # 检查响应状态
                        if response.status != 200:
                            error_detail = await response.text()
                            self.logger.error(f"向量化服务返回错误: HTTP {response.status}, {error_detail}")
                            response.raise_for_status()
                        embedding_result = await response.json()
            except asyncio.TimeoutError:
                self.logger.error(f"向量化服务调用超时: {self.url}")
                raise
            except Exception as e:
                self.logger.error(f"向量化服务调用失败: {str(e)}")
                raise
            embedding_content.append(embedding_result["data"][0]["embedding"])
        return embedding_content
