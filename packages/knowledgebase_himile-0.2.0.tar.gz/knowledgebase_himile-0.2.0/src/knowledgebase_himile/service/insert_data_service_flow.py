import traceback

from ..chunks.text_splitter import split_content
from ..chunks.chunk_utils import obtain_chunk_list
from ..utils import append_to_json_list

from himile_log import logger


class InsertDataService:
    """
    文档内容插入全文索引和切片索引

    使用说明：
         -文档内容插入
         insert_flag = await insert.async_insert(guid="nuinufusidszasd",
                                            index_name="chunk_test_index",
                                            doc_name="测试文件",
                                            content=text,
                                            full_content_index_name="full_test_index")
    """

    def __init__(self, embedding, splitter, es_manager, batch_size=1000):
        """
        初始化插入数据服务
        :param embedding: 向量化模型
        :param splitter: 文本切片类
        :param es_manager: 异步es操作类
        :param batch_size: int ES批量处理大小
        """
        self.embeddings = embedding
        self.splitter = splitter
        self.es_manager = es_manager
        self.batch_size = batch_size

    async def async_insert(self,
                           guid: str,
                           index_name: str,
                           doc_name: str,
                           content: str,
                           full_content_index_name: str
                           ) -> int:
        """
        文档插入的异步方法(切片索引和全文索引共同插入)

        Args:
            guid: str 文档id
            index_name: str 切片索引名称
            doc_name: str 文档标题
            content: str 文档内容
            full_content_index_name: str 全文索引名称

        Returns:
            int:  ES中数据是否插入成功, 0代表插入失败， 1代表插入成功， 2代表数据量不足
        """
        logger.info(f"将ID为{guid}的文档信息插入至ES的{full_content_index_name}和{index_name}索引中")
        insert_flag = 0

        try:
            chunk_len = 0
            if content is None or len(content) < 50:
                logger.warning(f"文档ID：{guid} 在ES中对应内容为空或长度小于50，不进行切片处理")
                insert_flag = 2
                return insert_flag
            else:
                # 基于中文文本的递归方式进行切片处理
                chunk_list = split_content(content, self.splitter)
                chunk_len = len(chunk_list)
                if chunk_len <= 0:
                    logger.warning(f"文档ID：{guid} 在ES中对应内容切片为0，无法进行插入")
                    insert_flag = 2
                    return insert_flag

                # 生成chunk_ids信息
                chunk_index_list = [index for index in range(len(chunk_list))]
                chunk_ids = obtain_chunk_list(guid, chunk_index_list)

                # 设置步长进行ES信息插入
                for i in range(0, len(chunk_ids), self.batch_size):
                    # 获取当前批次切片
                    batch_ids = chunk_ids[i: i + self.batch_size]
                    batch_list = chunk_list[i: i + self.batch_size]
                    logger.info(f"ES插入向量化数据批次：{(i / self.batch_size) + 1}, 包含ID数：\
                        {len(batch_ids)}")
                    # 文本向量化
                    vector_list = await self.embeddings.embedding_text(batch_list)
                    # 使用批量插入代替逐个插入
                    logger.info(f"{guid}文本的切片数据批量插入")
                    es_insert_flag, _ = await self.es_manager.es_insert_chunk_info(
                        batch_ids, batch_list, vector_list, index_name)
                    if not es_insert_flag:
                        logger.error(f"{guid}文本切片插入失败")
                        append_to_json_list("failed_data.json", guid)
                        return insert_flag

            # 插入全文索引
            logger.info(f"{guid}文本插入全文索引")
            full_insert_flag = await self.es_manager.full_content_insert([guid], index_name, [doc_name], [content],
                                                                   [chunk_len], full_content_index_name)
            if not full_insert_flag:
                logger.error(f"{guid}文本全文插入失败")
                append_to_json_list("failed_data.json", guid)
            else:
                insert_flag = 1
            return insert_flag

        except Exception as e:
            error_traceback = traceback.format_exc()
            logger.error(f"数据插入过程中发生错误：{e} 具体报错信息：{error_traceback}")
            return insert_flag
