import re
from datetime import datetime
import traceback
from typing import List, Dict, Tuple, Any

import aiohttp
from ..chunks.chunk_utils import obtain_unique_doc_ids

from ..prompt.qa_result import qa_prompt, qa_prompt_llm, abstract_article_prompt
from ..utils import add_space_between_eng_zh, rmWWW


class QueryService:
    """
    查询服务类
    全文检索/知识问答

    使用说明：
        -全文检索
        guid_list = await full_content_search(query="测试问题", full_content_index_name="全文索引名称")
        -知识问答
        prompt, relevant_docs, extend_query, content_list, graph_result = await query.async_kb_search_flow_result(query="测试问题",
        index_list=["切片索引列表"],
        full_content_index_name="全文索引",
        matching_rate=0.8,
        rerank_url="http://0.0.0.0:8093/rerank",
        top_rerank_chunk=5)
    """

    def __init__(self, logger, embedding, question_extension, es_manager):
        self.logger = logger
        self.embeddings = embedding
        self.query_optimization = question_extension
        self.es_manager = es_manager

    def joint_context(self,
                      prompt_template: str,
                      question: str,
                      relevant_chunks: List[Dict],
                      relevant_docs: List[str],
                      index_names: List[str],
                      joint_type: str) -> Tuple[str, List[Dict[str, Any]]]:
        """
        提示词拼接代码

        Args:
            prompt_template (str): 提示词模板
            question (str): 问题
            relevant_chunks (Dict[str, Any]): 相关切片列表
            relevant_docs (List[Dict[str, Any]]): 相关文档列表
            index_names (List[str]): 索引列表

        Returns:
            Tuple[str, List[Dict[str, Any]]]: 拼接好的提示词和相关文档列表
        """
        # 已知信息数量
        try:
            # 用于记录信息数目
            i = 1
            contents = ''

            for item in relevant_chunks:
                contents = contents + item.get("content", "") + f"————《{item.get('doc_name', '')}》" + "\n"

            if question == '在知识库中没有检索到相关信息，希望及时更新相关内容信息':
                '''以下是模型生成内容'''
                prompt = '在知识库中没有检索到相关信息，希望及时更新相关内容信息'
            elif contents:
                if joint_type == 'qa':
                    current_date = datetime.now().strftime('%Y-%m-%d')
                    prompt = prompt_template.format(
                        daytime=current_date,
                        question=question,
                        content=contents)
                else:
                    prompt = prompt_template.format(
                        no_output_str="没有检索到信息",
                        question=question,
                        context=contents)
            else:
                prompt = prompt_template.format(
                    no_info='在知识库中没有检索到相关信息，希望及时更新相关内容信息。以下内容由ai生成：',
                    question=question
                )
        # 抓取异常信息并打印到日志
        except Exception as e:
            # 获取异常的详细堆栈跟踪信息
            error_traceback = traceback.format_exc()
            # 使用日志记录异常信息
            self.logger.error(f"提示词拼接过程中发生错误：{e} 具体报错信息：{error_traceback}")
        finally:
            return prompt, relevant_docs

    async def async_kb_search_flow_base(self,
                                        query: str,
                                        index_list: List[str],
                                        full_content_index_name,
                                        matching_rate: float,
                                        rerank_url: str,
                                        top_rerank_chunk: int
                                        ) -> Tuple[List[str], List[str], Dict[str, Any], List[Dict[str, Any]]]:
        """
        查询流程

        Args:
            query (str): 查询的问题
            index_list (List[str]): 索引名称的列表
            full_content_index_name (str): 全文索引名称
            matching_rate (float): 匹配度
            rerank_url (str): 重排序url
            top_rerank_chunk (int): 重排序选取的切片数量

        Returns:
            Tuple[List[str], List[str], Dict[str, Any], List[Dict[str, Any]]]:
            拓展问题列表，存在的索引列表，相关切片的信息，相关文档的信息
        """
        content_list = []
        graph_results = []

        # 获取扩展问题
        extend_query = await self.query_optimization.async_query_extend(query)

        index_names = index_list
        # 检查索引是否存在
        exist_indexes = await self.es_manager.examine_indexes(index_names)

        # 如果没有索引存在，则默认使用所有索引
        if not exist_indexes:
            raise Exception(f"{index_names}索引不存在")

        if exist_indexes:
            query = rmWWW(re.sub(
                r"[ :|\r\n\t,，。？?/`!！&^%%()\[\]{}<>]+",
                " ",
                add_space_between_eng_zh(query),
            ).strip())
            # 搜索匹配信息
            chunk_match_list = await self.async_search(
                query,
                exist_indexes,
                full_content_index_name
            )
            # 搜索文档匹配信息
            doc_match_list = await self.es_manager.search_full_content_chunk(index_name="full_content_index", query_str=query)

            # 混合两次召回
            combine_match_list = []
            combine_match_list.extend(chunk_match_list)
            combine_match_list.extend(doc_match_list)
            async with aiohttp.ClientSession() as session:
                async with session.post(rerank_url, json={
                    'query': query,
                    'chunk_match_list': combine_match_list,
                    'matching_rate': matching_rate,
                    'matching_flag': 1,
                    'top_k': top_rerank_chunk
                }) as response:
                    rerank_results = await response.json()
            sorted_rerank_results = sorted(rerank_results, key=lambda result: result["score"], reverse=True)

            doc_unique_list = obtain_unique_doc_ids(sorted_rerank_results)
        return extend_query, exist_indexes, sorted_rerank_results, doc_unique_list, content_list, graph_results

    async def async_kb_search_flow_result(self,
                                          query: str,
                                          index_list: List[str],
                                          full_content_index_name: str,
                                          matching_rate: float,
                                          rerank_url: str,
                                          top_rerank_chunk: int,
                                          index_mapping: Dict[str, str] = None
                                          ) -> Tuple[str, List[Dict[str, Any]], List[str]]:
        """
        AI问答查询流程

        Args:
            query (str): 查询的问题
            index_list (List[str]): 索引名称的列表
            full_content_index_name: str 全文索引名称
            matching_rate (float): 匹配度
            index_mapping (Dict[str, str]): 分类映射关系字典，默认为None

        Returns:
            Tuple[str, List[Dict[str, Any]], List[str]]:
            prompt，相关文件列表，问题列表
        """
        # 将分类映射成索引名称
        chunk_index_id = []
        if index_list:
            if index_mapping:
                for id in index_list:
                    if index_mapping.get(id, ""):
                        index_id = index_mapping[id] + "_chunk_index"
                        chunk_index_id.append(index_id)
                self.logger.info(f"从{chunk_index_id}类别中进行全文检索")
            else:
                chunk_index_id = index_list

        extend_query, exist_indexes, relevant_chunks, relevant_docs, content_list, graph_results = await self.async_kb_search_flow_base(
            query,
            chunk_index_id,
            full_content_index_name,
            matching_rate,
            rerank_url,
            top_rerank_chunk
        )
        if exist_indexes:
            if relevant_chunks == {}:
                prompt, relevant_docs = self.joint_context(
                    qa_prompt_llm,
                    query,
                    relevant_chunks,
                    relevant_docs,
                    exist_indexes,
                    'qa'
                )
            else:
                prompt, relevant_docs = self.joint_context(
                    qa_prompt,
                    query,
                    relevant_chunks,
                    relevant_docs,
                    exist_indexes,
                    'qa'
                )
        else:
            self.logger.warning("未查询到相关信息，检查索引是否正确配置")
            prompt = '未查询到相关信息，检查是否正确配置知识库'
            relevant_docs = []
            content_list = []
        return prompt, relevant_docs, extend_query, content_list, graph_results

    async def full_content_search(self,
                                  query: str,
                                  full_content_index_name: str,
                                  index_mapping: Dict[str, str] = None,
                                  knowledge_id: List[str] = None):
        """
        全文检索
        :param query: 查询语句
        :param full_content_index_name: 全文索引名称
        :param index_mapping: 索引映射表
        :param knowledge_id: 切片列表索引
        :return: guid列表
        """
        guid_list = []
        chunk_index_id = []
        # 分类信息转换成切片索引名称
        if knowledge_id:
            if index_mapping:
                for id in knowledge_id:
                    if index_mapping.get(id, ""):
                        index_id = index_mapping[id] + "_chunk_index"
                        chunk_index_id.append(index_id)
                self.logger.info(f"从{chunk_index_id}类别中进行全文检索")
            else:
                chunk_index_id = knowledge_id
                self.logger.info(f"从{chunk_index_id}类别中进行全文检索")
        results = await self.es_manager.search_with_boost(index_name=full_content_index_name, query_str=query,
                                                    knowledge_id=chunk_index_id)
        for result in results:
            guid_list.append(result["id"])
        guid_list = list(set(guid_list))
        return guid_list

    async def async_search(self,
                           query: str,
                           index_names: List[str],
                           full_content_index_name: str,
                           top_embed: int = 50) -> List[Dict[str, Any]]:
        """
        内容查询的异步方法

        Args:
            query (str): 待查询内容
            index_names (List[str]): 索引的名称列表
            full_content_index_name (str): 全文索引名称
            top_embed (int): 向量化检索前n条

        Returns:
            List[Dict[str, Any]]: 查询的结果列表，包含id、content
        """
        self.logger.info(f"检索切片信息")
        # 向量搜索
        self.logger.info(f'向量化检索开始{query}')
        embedding = (await self.embeddings.embedding_text([query]))[0]
        embed_flag, embed_results = await self.es_manager.search_embed(
            query,
            top_embed,
            index_names,
            embedding
        )
        if embed_flag:
            # formatted_results = [f"{item['id']}:{item['score']}" for item in embed_results]
            self.logger.info(f'向量化检索成功')
        else:
            self.logger.error(f"向量检索失败")
        # 追加检索结果至最终列表
        chunk_final_result = embed_results

        doc_ids = [item["id"][:-6] for item in chunk_final_result]
        doc_ids = list(set(doc_ids))

        doc_mapping = await self.es_manager.query_by_guid_list(doc_ids, full_content_index_name)

        for result in chunk_final_result:
            # 使用 doc_id 获取对应的 doc_name 和 chunk_len
            if doc_mapping.get(result["id"][:-6], {}):
                doc_name = doc_mapping[result["id"][:-6]].get("doc_name", "")
                chunk_len = doc_mapping[result["id"][:-6]].get("chunk_len", "")
            else:
                chunk_len = ""
                doc_name = ""
            # 判断是否查找到对应数据的切片长度
            if chunk_len:
                # 若查找到对应文件名称，对文件名及内容进行拼接
                if doc_name:
                    result["doc_name"] = doc_name
                    result["content"] = f"{doc_name}_{result['content']}"
                # 添加 chunk_len 信息
                result["chunk_len"] = chunk_len
            else:
                result["chunk_len"] = 0

        return chunk_final_result

    async def article_content_summary(self, guid: str, full_content_index_name: str):
        """
        文章内容摘要
        :param guid: 文章guid
        :param full_content_index_name: 索引名称
        """
        result = await self.es_manager.query_by_guid_list([guid], full_content_index_name)
        if result:
            article_content = result.get(guid, {}).get("content", "")
            self.logger.info(f"获取到{guid}文件内容，准备进行摘要生成")
            prompt = abstract_article_prompt.format(content=article_content)
        else:
            prompt = "请输出‘未获取到对应文件内容’"
            self.logger.warning(f"未获取到{guid}文件内容，无法生成摘要")
        return prompt
