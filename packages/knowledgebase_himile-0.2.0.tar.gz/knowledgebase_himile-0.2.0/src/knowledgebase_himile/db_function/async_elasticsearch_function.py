"""
ES作为向量库的异步方法操作类
对外提供的公共方法：
    create_es_index  创建es索引（全文/切片）
    es_insert_chunk_info  向es中插入切片
    es_search  在es中搜索doc
    ...

使用方法：
    from db.db_factory import DatabaseFactory, DatabaseType

    # 通过工厂类获取异步ES客户端
    es_config = {
        "hosts": conf.ELASTICSEARCH_HOST,
        "user": conf.ELASTICSEARCH_USER,
        "password": conf.ELASTICSEARCH_PASSWD
    }
    async_es_client = DatabaseFactory.get_database(DatabaseType.ELASTICSEARCH_ASYNC, es_config)

    # 初始化工具类
    async_es_manager = AsyncElasticsearchManager(logger, async_es_client)

    # 原有调用方式保持不变
    await async_es_manager.create_es_index(index_name)
"""
import asyncio
from typing import List, Tuple, Callable, Any, Dict
from datetime import datetime

from himile_log import logger
from ..db.database_factory import DatabaseFactory, DatabaseType
from ..db.db_abstract import BaseDBAsync
from ..utils import compare, calculate_similarity

import traceback
from ..embedding.embeddings_text import Embeddings


class AsyncElasticsearchManager:
    """
    ES作为向量库的异步操作类
    """

    def __init__(
            self,
            embeddings: Embeddings,
            es_client: BaseDBAsync = None,
            es_config: Dict = None
    ):
        """
        初始化ES
        :param embeddings 向量化模型
        :param es_client: 已初始化的异步ES客户端（来自工厂类）
        :param es_config: ES配置字典（优先级低于已传入的es_client）
                          格式: {"hosts": [...], "user": "...", "password": "..."}
        """
        self.logger = logger
        self.es_client = es_client
        self.embeddings = embeddings

        # 如果未传入客户端，则通过工厂类创建
        if not self.es_client:
            self.es_client = DatabaseFactory.get_database(
                DatabaseType.ELASTICSEARCH_ASYNC,
                es_config
            )

        if not self.es_client:
            raise ValueError("必须提供es_client或es_config初始化ES客户端")

    async def create_full_text_index(self, index_name: str) -> int:
        """
        全文索引创建
        :param index_name: 索引名称
        :return: 创建标志位（0失败/1成功/2已存在）
        """
        create_flag = 0
        try:
            create_flag = await self.retry_async(self._create_full_text_index, 3, index_name)
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES全文索引创建失败: {e} 详情: {error_traceback}")
        finally:
            return create_flag

    async def create_chunk_index(self, index_name: str) -> int:
        """
        切片索引创建
        :param index_name: 索引名称
        :return: 创建标志位（0失败/1成功/2已存在）
        """
        create_flag = 0
        try:
            create_flag = await self.retry_async(self._create_chunk_index, 3, index_name)
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES切片索引创建失败: {e} 详情: {error_traceback}")
        finally:
            return create_flag

    async def delete_index(self, index_name: str) -> int:
        """
        删除指定索引
        :param index_name: 索引名称
        :return: 删除标志位（0失败/1成功/2不存在）
        """
        delete_flag = 0
        try:
            delete_flag = await self.retry_async(self._delete_index, 3, index_name)
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES索引删除失败: {e} 详情: {error_traceback}")
        finally:
            return delete_flag

    async def full_content_insert(self,
                                  guid: List[str],
                                  knowledge_id: str,
                                  doc_name: List[str],
                                  content: List[str],
                                  chunk_len: List[int],
                                  index_name: str) -> Tuple[int, List[str]]:
        """
        向全文索引批量插入文件内容
        :param guid: 文件唯一标识列表
        :param knowledge_id: 切片索引名称
        :param doc_name: 文件名列表
        :param content: 内容列表
        :param chunk_len: 分块长度列表
        :param index_name: 索引名称
        """
        es_add_ids = []
        es_insert_flag = 0
        try:
            es_insert_flag, es_add_ids = await self.retry_async(
                self._full_content_insert,
                3,
                guid, knowledge_id, doc_name, content, chunk_len, index_name
            )
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES全文内容插入失败: {e} 详情: {error_traceback}")
        finally:
            return es_insert_flag, es_add_ids

    async def es_insert_chunk_info(
            self,
            chunk_ids: List[str],
            chunk_list: List[str],
            embedding_list: List[List[float]],
            index_name: str
    ) -> Tuple[int, List[str]]:
        """
        将切片插入到Elasticsearch中。

        Args:
            chunk_ids (List[str]): 切片ID列表
            chunk_list (List[str]): 文本切片列表
            embedding_list (List[List[float]]): 向量化文本列表
            index_name: 索引名称

        Returns:
            int: 插入结果标志位(0代表插入失败,1代表插入成功,2代表索引不存在)
            List[str]: ES插入信息的ID列表
        """
        es_add_ids = []
        es_insert_flag = 0
        try:
            es_insert_flag, es_add_ids = await self.retry_async(
                self._es_insert_chunk_info,
                3,
                chunk_ids, chunk_list, embedding_list, index_name
            )
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES切片插入失败: {e} 详情: {error_traceback}")
        finally:
            return es_insert_flag, es_add_ids

    async def search_by_chunk_id(self, chunk_ids: List[str], index_name):
        """
        根据chunk_id列表获取对应的切片
        """
        result = []
        try:
            result = await self.retry_async(
                self._search_by_chunk_id,
                3,
                chunk_ids,
                index_name
            )
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES根据id查找切片内容失败: {e} 详情: {error_traceback}")
        finally:
            return result

    async def search_with_boost(
            self,
            index_name: str,
            query_str: str,
            knowledge_id: List[str] = None
    ) -> List[Dict]:
        """
        全文检索（带权重提升）
        :param index_name: 索引名称
        :param query_str: 搜索关键词
        :param knowledge_id: 切片索引列表
        """
        result = []
        try:
            result = await self.retry_async(
                self._search_with_boost,
                3,
                index_name, query_str, knowledge_id
            )
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES全文检索失败: {e} 详情: {error_traceback}")
        finally:
            return result

    async def search_full_content_chunk(self,
                                        index_name: str,
                                        query_str: str,
                                        knowledge_id: List[str] = None):
        """
        获取全文检索后相似度最高的三个切片数据
        :param index_name: 索引名称
        :param query_str: 搜索关键词
        :param knowledge_id: 切片索引列表
        """
        es_full_content_result = []
        query_embedding = (await self.embeddings.embedding_text([query_str]))[0]
        result = await self.search_with_boost(index_name, query_str, knowledge_id)
        for item in result:
            chunk_ids = []
            doc_result = []
            for chunk_len_id in range(item["chunk_len"]):
                chunk_len_str = str(chunk_len_id).zfill(6)
                chunk_id = item["id"] + chunk_len_str
                chunk_ids.append(chunk_id)
            doc_list = await self.search_by_chunk_id(chunk_ids, item["knowledge_id"])
            for doc_elem in doc_list:
                chunk_id = doc_elem.get('_id', '')
                chunk_embedding = doc_elem["_source"]["embedding"]
                cos = await calculate_similarity(query_embedding, chunk_embedding)
                content = doc_elem["_source"]["chunk_content"]
                doc_name = item["doc_name"]
                chunk_len = item["chunk_len"]
                doc_result.append({
                    "id": chunk_id,
                    "score": cos,
                    "content": content,
                    "doc_name": doc_name,
                    "chunk_len": chunk_len
                })
            sorted_result = sorted(doc_result, key=lambda x:x['score'], reverse=True)
            es_full_content_result.extend(sorted_result[:2])
        return es_full_content_result

    async def query_by_guid_list(self, guid_list: List[str], index_name: str) -> Dict[str, Any]:
        """
        根据guid列表查询文档

        Args:
            guid_list: guid列表，如 ['guid1', 'guid2', 'guid3']
            index_name: str 全文索引名称

        Returns:
            查询结果列表
        """
        result = {}
        try:
            result = await self.retry_async(
                self._query_by_guid_list,
                3,
                guid_list,
                      index_name
            )
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES全文检索失败: {e} 详情: {error_traceback}")
        finally:
            return result

    async def examine_indexes(self, index_names: List[str]) -> List[str]:
        """
        检查索引是否存在
        """
        exist_indexes = []
        try:
            for index_name in index_names:
                if await self._index_exist(index_name):
                    exist_indexes.append(index_name)
                else:
                    self.logger.warning(f"ES索引 '{index_name}' 不存在")
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES索引检查失败: {e} 详情: {error_traceback}")
        finally:
            return exist_indexes

    async def search_embed(
            self,
            query: str,
            top_k: int,
            index_names: List[str],
            embeddings: List[float]
    ) -> Tuple[int, List[Dict[str, Any]]]:
        """
        向量相似度搜索（兼容原有接口）
        """
        results = []
        flag = 0
        try:
            results = await self.retry_async(
                self._search_embed,
                3,
                query, top_k, ",".join(index_names), embeddings
            )
            flag = 1
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"ES向量搜索失败: {e} 详情: {error_traceback}")
        finally:
            return flag, results

    # -------------------------- 内部实现方法 --------------------------
    async def _create_full_text_index(self, index_name: str) -> int:
        """
        创建全文索引
        :param index_name: 索引名
        """
        try:
            mappings = {
                "properties": {
                    "guid": {
                        "type": "keyword",
                        "doc_values": True
                    },
                    "doc_name": {
                        "type": "text",
                        "analyzer": "ik_max_word",
                        "search_analyzer": "ik_smart",
                        "fields": {
                            "keyword": {
                                "type": "keyword"
                            }
                        }
                    },
                    "knowledge_id": {
                        "type": "keyword",
                        "doc_values": True
                    },
                    "content": {
                        "type": "text",
                        "analyzer": "ik_max_word",
                        "search_analyzer": "ik_smart",
                        "index_options": "positions"
                    },
                    "create_time": {
                        "type": "date",
                        "format": "strict_date_optional_time||epoch_millis||yyyy-MM-dd HH:mm:ss",
                        "doc_values": True
                    },
                    "chunk_len": {
                        "type": "integer",
                        "doc_values": True
                    }
                }
            }

            settings = {
                "index": {
                    "number_of_shards": 3,
                    "number_of_replicas": 1,
                    # 分析器配置
                    "analysis": {
                        "analyzer": {
                            "ik_max_word": {
                                "type": "ik_max_word"
                            },
                            "ik_smart": {
                                "type": "ik_smart"
                            }
                        }
                    }
                }
            }
            body = {
                "settings": settings,
                "mappings": mappings
            }
            return await self.es_client.create_index(body=body, index_name=index_name)
        except Exception as e:
            self.logger.error(f"创建全文索引失败: {e}")
            return False

    async def _create_chunk_index(self, index_name: str) -> int:
        """
        创建切片索引
        :param index_name: 索引名称
        """
        try:
            settings = {
                "index": {
                    "number_of_shards": 3,
                    "number_of_replicas": 1,
                    # 分析器配置
                    "analysis": {
                        "analyzer": {
                            "ik_max_word": {
                                "type": "ik_max_word"
                            },
                            "ik_smart": {
                                "type": "ik_smart"
                            }
                        }
                    }
                }
            }
            mappings = {
                "properties": {
                    "chunk_id": {
                        "type": "keyword",
                        "doc_values": True
                    },
                    "chunk_content": {
                        "type": "text",
                        "analyzer": "ik_max_word",
                        "search_analyzer": "ik_smart"

                    },
                    "embedding": {
                        "type": "dense_vector",
                        "dims": 1024,
                        "index": True,
                        "similarity": "cosine",
                        "index_options": {
                            "type": "hnsw",
                            "m": 100,
                            "ef_construction": 3200
                        }
                    }
                }
            }
            body = {
                "settings": settings,
                "mappings": mappings
            }
            return await self.es_client.create_index(body=body, index_name=index_name)
        except Exception as e:
            self.logger.error(f"创建切片索引失败: {e}")
            return False

    async def _delete_index(self, index_name: str) -> int:
        """
        删除索引
        :param index_name: 索引名称
        """
        try:
            return await self.es_client.delete_index(index_name=index_name)
        except Exception as e:
            self.logger.error(f"删除索引失败: {e}")
            return False

    async def _full_content_insert(
            self,
            guid: List[str],
            knowledge_id: str,
            doc_name: List[str],
            content: List[str],
            chunk_len: List[int],
            index_name: str
    ) -> Tuple[int, List[str]]:
        """
        将文章插入到全文索引中。

        Args:
            :param guid: 文件id
            :param knowledge_id: 对应切片索引名称
            :param doc_name: 文章标题
            :param content: 文章内容
            :param chunk_len: 切片长度
            :param index_name: 索引名称
            :return:

        Returns:
            int: 插入结果标志位(0代表插入失败,1代表插入成功,2代表索引不存在)
            List[str]: ES插入信息的ID列表
        """
        actions = []
        for i, guid_item in enumerate(guid):
            # 构建bulk操作的action
            action = {"index": {"_index": index_name, "_id": guid_item}}
            data = {
                "guid": guid_item,
                "knowledge_id": knowledge_id,
                "doc_name": doc_name[i],
                "content": content[i],
                "chunk_len": chunk_len[i],
                "create_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            actions.append(action)
            actions.append(data)

        query = {
            "action": "bulk",
            "body": actions
        }

        # 调用抽象类的execute方法执行bulk操作
        response = await self.es_client.execute(query=query)

        # 处理结果
        es_add_ids = []
        for item in response["items"]:
            if item.get("index", {}).get("result") in ["updated", "created"]:
                es_add_ids.append(item["index"]["_id"])
            else:
                self.logger.error(f"全文内容插入失败: {item}")

        # 校验插入结果
        diff_id = compare(guid, es_add_ids)
        if not diff_id:
            self.logger.info("全文内容插入成功")
            return 1, es_add_ids
        else:
            self.logger.error(f"全文内容插入不完整，缺失ID: {diff_id}")
            return 0, es_add_ids

    async def _es_insert_chunk_info(
            self,
            chunk_ids: List[str],
            chunk_list: List[str],
            embedding_list: List[List[float]],
            index_name: str
    ) -> Tuple[int, List[str]]:
        """
        将切片插入到Elasticsearch中。

        Args:
            chunk_ids (List[str]): 切片ID列表
            chunk_list (List[str]): 文本切片列表
            embedding_list (List[List[float]]): 向量化文本列表
            index_name: 索引名称

        Returns:
            int: 插入结果标志位(0代表插入失败,1代表插入成功,2代表索引不存在)
            List[str]: ES插入信息的ID列表
        """
        actions = []
        for i, chunk_id in enumerate(chunk_ids):
            action = {"index": {"_index": index_name, "_id": chunk_id}}
            data = {
                "chunk_id": chunk_id,
                "chunk_content": chunk_list[i],
                "embedding": embedding_list[i]
            }
            actions.append(action)
            actions.append(data)

        query = {
            "action": "bulk",
            "body": actions
        }

        # 执行bulk操作
        response = await self.es_client.execute(query=query)

        # 处理结果
        es_add_ids = []
        for item in response["items"]:
            if item.get("index", {}).get("result") in ["updated", "created"]:
                es_add_ids.append(item["index"]["_id"])
            else:
                self.logger.error(f"切片插入失败: {item}")

        # 校验结果
        diff_ids = compare(chunk_ids, es_add_ids)
        if not diff_ids:
            self.logger.info("切片数据插入成功")
            return 1, es_add_ids
        else:
            self.logger.error(f"切片插入不完整，缺失ID: {diff_ids}")
            return 0, es_add_ids

    async def _index_exist(self, index_name: str) -> bool:
        """检查索引是否存在"""
        try:
            query = {
                "action": "exist",
                "index": index_name
            }
            return await self.es_client.execute(query=query)
        except Exception:
            return False

    async def _search_with_boost(self, index_name: str, query_str: str, knowledge_id: List[str] = None, title_boost=3.0, content_boost=1.0, size=10,
                                 from_=0) -> List[Dict]:
        """
        执行全文检索，title字段权重更高
        :param index_name: 索引名称
        :param query_str: 查询字符串
        :param knowledge_id: 切片索引列表
        :param title_boost: title字段权重，默认3.0
        :param content_boost: content字段权重，默认1.0
        :param size: 返回结果数量
        :param from_: 起始位置
        :return: 搜索结果
        """
        query = {
            "index": index_name,
            "body": {
                "query": {
                    "bool": {
                        "should": [
                            {
                                "multi_match": {
                                    "query": query_str,
                                    "fields": [f"doc_name^{title_boost}", "content"],
                                    "type": "best_fields",
                                    "tie_breaker": 0.3,
                                    "minimum_should_match": "30%"
                                }
                            },
                            {
                                "match": {
                                    "doc_name": {"query": query_str, "boost": title_boost * 1.5}
                                }
                            }
                        ]
                    }
                },
                "highlight": {
                    "pre_tags": ["<em>"],
                    "post_tags": ["</em>"],
                    "fields": {
                        "doc_name": {"number_of_fragments": 0},
                        "content": {"fragment_size": 150, "number_of_fragments": 3}
                    }
                },
                "sort": [{"_score": {"order": "desc"}}],
                "size": size,
                "from": from_
            }
        }

        # 添加knowledge_id筛选条件
        if knowledge_id:
            query["body"]["query"]["bool"].setdefault("filter", [])
            query["body"]["query"]["bool"]["filter"].append({
                "terms": {
                    "knowledge_id": knowledge_id
                }
            })

        hits = await self.es_client.fetch_all(query=query)
        return self._process_results({"hits": {"hits": hits}})

    async def _query_by_guid_list(self, guid_list: List[str], index_name: str) -> Dict[str, Any]:
        """
        根据GUID列表查询文档
        """
        try:
            query = {
                "index": index_name,
                "body": {
                    "query": {
                        "terms": {"guid": guid_list}
                    },
                    "_source": ["guid", "doc_name", "content", "create_time", "chunk_len", "knowledge_id"],
                    "size": len(guid_list)
                }
            }
            hits = await self.es_client.fetch_all(query)

            results = {}
            for hit in hits:
                doc = hit['_source']
                doc['_score'] = hit['_score']
                results[hit["_id"]] = doc
            return results
        except Exception as e:
            self.logger.error(f"ES按GUID查询失败: {e}")
            return {}

    async def _search_by_chunk_id(self,
                                  chunk_ids: List[str],
                                  index_name: str):
        """
        在某个切片索引中查询某个文件id的所有切片数据
        """
        try:
            query = {
                "index": index_name,
                "body": {
                    "query": {
                        "ids": {
                            "values": chunk_ids
                        }
                    },
                    "size": 5000
                }
            }
            hits = await self.es_client.fetch_all(query)
            return hits
        except Exception as e:
            self.logger.error(f"ES按chunk_id查询失败: {e}")
            return []

    async def _search_embed(
            self,
            query: str,
            top_k: int,
            index_names: str,
            embeddings: List[float]
    ) -> List[Dict[str, Any]]:
        """
        使用 Elasticsearch 进行向量相似度搜索（异步）。

        Args:
            query (str): 用户提出的问题
            top_k (int): 返回的最相似切片数量
            index_names (str): 查询的索引名字
            embeddings (List[float]): 向量化列表

        Returns:
            Tuple[bool, List[Dict[str, Any]]]: 成功与否的标志和包含向量相似
            度查询结果的列表，每个元素包含id、content和score。
        """
        query = {
            "index": index_names,
            "body": {
                "retriever": {
                    "rrf": {
                        "retrievers": [
                            {
                                "standard": {
                                    "query": {"match": {"chunk_content": query}}
                                }
                            },
                            {
                                "knn": {
                                    "field": "embedding",
                                    "query_vector": embeddings,
                                    "k": top_k,
                                    "num_candidates": 1000
                                }
                            }
                        ],
                        "rank_window_size": 200,
                        "rank_constant": 20
                    }
                },
                "size": top_k
            }
        }

        hits = await self.es_client.fetch_all(query)
        results = []
        for hit in hits:
            source = hit.get('_source', {})
            results.append({
                "id": hit.get("_id"),
                "score": hit.get("_score"),
                "content": source.get('chunk_content', '')
            })
        return results

    # -------------------------- 通用工具方法 --------------------------
    def _process_results(self, response: Dict) -> List[Dict]:
        """处理搜索结果格式化"""
        results = []
        if response and 'hits' in response and 'hits' in response['hits']:
            for hit in response['hits']['hits']:
                source = hit.get('_source', {})
                result = {
                    'id': hit['_id'],
                    'score': hit['_score'],
                    'doc_name': source.get('doc_name', ''),
                    'chunk_len': source.get('chunk_len', ''),
                    'content': (source.get('content', '')) if source.get('content') else '',
                    'knowledge_id': source.get('knowledge_id', '')
                }
                results.append(result)
        return results

    @staticmethod
    async def retry_async(
            func: Callable[..., Any],
            retries: int = 3,
            *args: Any,
            **kwargs: Any
    ) -> Any:
        """异步重试装饰器（保留原有逻辑）"""
        attempt = 0
        while attempt < retries:
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                attempt += 1
                if attempt >= retries:
                    raise e
                await asyncio.sleep(2)
