"""
这是一个关于LLM的代码，可以向LLM发送问题，支持同步和异步，同时对于支持流式返
回内容,simple_chat方法可以和LLM通讯,async_simple_chat支持异步的和LLM通讯
sse_generator会回答问题，并将内容流式返回

下面是代码使用的一些简单示例:
    llm_server = LLMServer()
    data = llm_server.simple_chat(message=message)

    # 异步请求
    llm_result = asyncio.run(llm_server.async_simple_chat(message=message))
    或者
    llm_result = await llm_server.async_simple_chat(message=message)

    # 流式返回
    asyncGen_llm_result = await llm_server.sse_generator(message, 
        link_docs, extend_query)
"""

__all__ = ['LLMServer']

import json
import os
from typing import AsyncGenerator, Dict, Optional, Union, List, Any

import yaml
from openai import AsyncOpenAI, AsyncStream, OpenAI
from openai.types.chat import ChatCompletionChunk, ChatCompletion
from himile_log import logger


class LLMServer:
    """
        LLM服务类
    """

    def __init__(self, logger, llm_config: Dict[str, Any] = None):
        """
        Args:
            logger: 日志记录器
            llm_config: LLM配置字典
                -api_key: API密钥
                -openai_endpoint: 模型访问地址
                -model_name: 模型名称
                -temperature: 温度参数
                -top_p: top_p参数
        """
        self.logger = logger
        if llm_config is None:
            config_path = os.path.expanduser('~/.knowledgebase_himile/config.yaml')
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                llm_config = config.get('llm', {})
                logger.info(f"Loaded llm configs: {list(llm_config.keys())}")
            except (FileNotFoundError, yaml.YAMLError, Exception) as e:
                logger.warning(f"Failed to load llm config from {config_path}: {e}")
                llm_config = {}

        self.client = OpenAI(api_key=llm_config.get('api_key', ''), base_url=llm_config.get('openai_endpoint', ''))
        self.async_client = AsyncOpenAI(api_key=llm_config.get('api_key', ''), base_url=llm_config.get('openai_endpoint', ''))
        self.model_path = llm_config.get('model_name')
        self.temperature = llm_config.get('temperature', 0.2)
        self.top_p = llm_config.get('top_p', 0.3)
        self.api_key = llm_config.get('api_key', '')

    def simple_chat(self, message: str) -> Optional[str]:
        """
        与聊天机器人进行简单的对话。同步方法

        Args:
            message (str): 用户的输入消息。

        Returns:
            str: LLM返回的响应内容
        """
        # 构建对话消息列表，包括系统消息和用户消息
        messages: List[Dict[str, str]] = [
            {
                "role": "system",
                "content": "你是一位能给人类带来帮助的人工智能助手",
            },
            {
                "role": "user",
                "content": message
            }
        ]

        # 发起聊天请求，根据配置参数获取响应
        response: Union[ChatCompletion, ChatCompletionChunk] \
            = self.client.chat.completions.create(
            model=self.model_path,
            messages=messages,
            stream=False,
            # max_tokens=self.max_tokens,
            temperature=self.temperature,
            top_p=self.top_p,
            extra_headers={"X-API-KEY": self.api_key},
        )

        # 处理响应结果
        if response:
            content: str = response.choices[0].message.content
            self.logger.info(content)
            return content
        # 如果响应为空或发生错误，记录错误信息
        else:
            self.logger.error(
                f"发生了一个未知错误：{getattr(response, 'status_code', 'Unknown error')}")
            return None

    async def async_simple_chat(self, message: str) -> str:
        """
        与聊天机器人进行简单的对话。异步方法

        Args:
            message (str): 用户的输入消息。

        Returns:
            str: LLM返回的响应内容
        """
        # 构建对话消息列表，包括系统消息和用户消息
        messages: List[Dict[str, str]] = [
            {
                "role": "system",
                "content": "你是一位能给人类带来帮助的人工智能助手",
            },
            {
                "role": "user",
                "content": message
            }
        ]

        # 发起聊天请求，根据配置参数获取响应
        response: Union[ChatCompletion, AsyncGenerator[ChatCompletionChunk, None]] \
            = await self.async_client.chat.completions.create(
            model=self.model_path,
            messages=messages,
            stream=False,
            # max_tokens=self.max_tokens,
            temperature=self.temperature,
            top_p=self.top_p,
            extra_headers={"X-API-KEY": self.api_key}
        )

        # 处理响应结果
        if response:
            content: str = response.choices[0].message.content
            return content
        # 如果响应为空或发生错误，记录错误信息
        else:
            self.logger.error(
                f"发生了一个未知错误：{getattr(response, 'status_code', 'Unknown error')}")
            return None

    async def sse_generator(self, prompt: str, link_docs=None,
                            extend_query=None) -> AsyncGenerator[str, None]:
        """
        生成流式返回内容

        Args:
            prompt (str): 提示词
            link_docs (List[Dict[str, Any]]): 链接的文档列表
            extend_query (List[Dict[str, str]]): 扩展查询的文档列表
        
        Returns:
            AsyncGenerator[str, None]: 生成的SSE格式的数据流
        """
        # 如果有链接文档，则发送额外信息
        if link_docs:
            logger.info(f"linkDocs: {link_docs}")
            additional_info = {
                "linkDocs": link_docs,
                "extendQuery": extend_query
            }
            chunk_data = {
                "content": additional_info,
                "type": '0'
            }
            yield f"data: {json.dumps(chunk_data, ensure_ascii=False)}\n\n"
        if prompt == '在知识库中没有检索到相关信息，希望及时更新相关内容信息':
            data = {
                "content": prompt,
                "type": '1'
            }
            yield f'data: {json.dumps(data, ensure_ascii=False)}\n\n'
        else:
            messages: List[Dict[str, str]] = [
                {
                    "role": "user",
                    "content": prompt
                }
            ]

            # 发起聊天请求，根据配置参数获取响应
            response: AsyncStream[ChatCompletionChunk] \
                = await self.async_client.chat.completions.create(
                model=self.model_path,
                messages=messages,
                stream=True,
                # max_tokens=self.max_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                extra_headers={"X-API-KEY": self.api_key}
            )

            try:
                async for chunk in response:
                    if len(chunk.choices) > 0:
                        delta = chunk.choices[0].delta
                        data = {}
                        if delta.role:
                            data["role"] = delta.role
                        if delta.content:
                            data["content"] = delta.content
                        data['type'] = '1'
                        yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
            except Exception as e:
                yield f"data: {{\"error\": \"{str(e)}\"}}\n\n"
        yield "data:[DONE]\n\n"