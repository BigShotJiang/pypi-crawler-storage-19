"""
问题拓展类
"""

import ast
import traceback
from string import Template
from typing import List


class QueryOptimazation:
    """
        问题拓展类
    """

    def __init__(self, logger, llm_server):
        """
            @brief: 初始化模型实例
            @Author: 郝俊飞20232468
            @Time: 20240722
        """
        self.logger = logger
        self.llm = llm_server

        # 定义示例输入和期望的输出，用于指导模型学习如何生成相关问题
        self.query_extend_examples = [
            {
                "input": "国家土地税税率是多少",
                "output": ["政府在什么情况下调整土地使用税税率", "国家土地税税率的计算方式"],
            },
            {
                "input": "带薪年休假",
                "output": ["带薪年休假政策是什么", "带薪年休假政策有哪些变化",
                    "使用带薪年休假有哪些注意事项"],
            },
            {
                "input": "能源折标系数是什么",
                "output": ["为什么使用能源折标系数", "能源折标系数的计算方式",
                    "电力的能源折标系数标准是什么？"],
            },
            {
                "input": "离职后大学生档案怎么转移",
                "output": ["离职后具体的档案转移流程", "离职后暂时未找到工作，档案应该如何处理",
                    "档案对我的个人权益有哪些影响"],
            },
            {
                "input": "弹簧气孔套",
                "output": ["弹簧气孔套的材料选择有什么特殊要求", "弹簧气孔套的具体结构是怎样的",
                    "弹簧气孔套使用过程中需要注意哪些维护事项"],
            },
        ]

    async def async_query_extend(self, question: str) -> List[str]:
        """
        用户问题拓展
        Args:
            question: 用户输入的问题
        """
        extend_question = [question]
        try:
            query_extend_prompt = '''
                你是一个知识库，你的任务是根据输入的问题创建3个或更少的关联问题，要求不修改原问题的关键字且不改变核心内容，但可以引导用户进行更深层次或更广泛的提问，确保这些问题清晰且易于理解。
                这里有一些例子供你学习:(input为用户输入，output是模型输出)
                ${example}
                请你在学习完上面例子之后，根据用户输入的问题生成关联问题
                用户问题: ${question}
                输出格式: 以python列表的形式返回，不要包含其他任何内容
            '''
            prompt = Template(query_extend_prompt).substitute(example=self.query_extend_examples, question=question)
            result = await self.llm.async_simple_chat(prompt)
            extend_question = ast.literal_eval(result)
        except Exception as e:
            error_traceback = traceback.format_exc()
            self.logger.error(f"问题扩展过程中发生错误:{e}, 具体报错信息为:{error_traceback}")
        finally:
            return extend_question

