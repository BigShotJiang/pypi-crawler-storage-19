# src/knowledgebase_himile/cli.py
import sys


def main():
    """主函数 - 命令行工具的入口点"""
    # 检查命令行参数
    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == "version":
            print(f"knowledgebase_himile v1.0")

        else:
            print_help()
    else:
        print_help()


def print_help():
    """打印帮助信息"""
    help_text = """
KnowledgeBase_himile 命令行工具

使用方法:
    knowledgebase_himile init     [--force]    # 初始化配置
    knowledgebase_himile version              # 显示版本
    knowledgebase_himile help                 # 显示帮助

示例:
    knowledgebase_himile init --force
    knowledgebase_himile version
    """
    print(help_text)


if __name__ == "__main__":
    main()