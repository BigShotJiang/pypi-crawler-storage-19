# 插入内容
from .service.insert_data_service_flow import InsertDataService

# 查询方法-全文检索/AI问答
from .service.query_service_flow import QueryService

__all__ = ['InsertDataService', 'QueryService']

from pathlib import Path
import shutil


def init_config():
    config_dir = Path.home() / ".knowledgebase_himile"
    config_file = config_dir / "config.yaml"

    if not config_file.exists():
        config_dir.mkdir(exist_ok=True)
        # 从包内复制模板文件
        template_path = Path(__file__).parent / "config_template.yaml"
        shutil.copy(template_path, config_file)


def cli_main():
    from .cli import main
    main()


init_config()
