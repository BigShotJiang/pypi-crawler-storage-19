"""
文本切片
"""

from .text_splitter import split_content, RecursiveCharacterTextSplitter

__all__ = ['split_content', 'RecursiveCharacterTextSplitter']
