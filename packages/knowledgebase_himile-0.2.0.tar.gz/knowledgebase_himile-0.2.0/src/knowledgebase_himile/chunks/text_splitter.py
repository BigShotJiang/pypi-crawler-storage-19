"""
不依赖 LangChain 的文本分割器实现
使用示例:
chunks = split_content(test_text, RecursiveCharacterTextSplitter)
"""

import re
from typing import List, Optional, Any, Callable
import traceback
from himile_log import logger


class RecursiveCharacterTextSplitter:
    """
    递归字符文本分割器
    不依赖 LangChain，实现相同的递归分割功能
    """

    def __init__(
            self,
            chunk_size: int = 500,
            chunk_overlap: int = 20,
            separators: Optional[List[str]] = None,
            keep_separator: bool = True,
            length_function: Callable[[str], int] = len,
            is_separator_regex: bool = True,
    ) -> None:
        """
        初始化文本分割器

        Args:
            chunk_size: 每个块的最大字符数
            chunk_overlap: 块之间的重叠字符数
            separators: 分隔符列表，优先级从高到低
            keep_separator: 是否保留分隔符
            length_function: 计算文本长度的函数
            is_separator_regex: 分隔符是否为正则表达式

        package_use_Example:
            from knowledgebase_himile.chunks import RecursiveCharacterTextSplitter
            splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
        """

        # 参数验证
        if not isinstance(chunk_size, int) or not isinstance(chunk_overlap,
                                                             int) or chunk_size <= 0 or chunk_overlap < 0:
            logger.error("切片长度与重叠长度必须为整数")
            raise ValueError("切片长度与重叠长度必须为整数")

        if chunk_overlap >= chunk_size:
            logger.error("重叠长度不能大于或等于切片长度")
            raise ValueError(f"chunk_overlap ({chunk_overlap}) 不能大于 chunk_size ({chunk_size})")

        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or ["\n\n", "\n", "。", "，", " ", ""]
        self.keep_separator = keep_separator
        self.length_function = length_function
        self.is_separator_regex = is_separator_regex
        self._good_splits = []

    def split_text(self, text: str) -> List[str]:
        """
        对外接口：分割文本

        Args:
            text: 要分割的文本

        Returns:
            分割后的文本块列表
        """
        if not text:
            return []

        self._good_splits = []  # 重置
        chunks = self._split_text_recursive(text, self.separators.copy())

        # 清理最终文本块
        cleaned_chunks = []
        for chunk in chunks:
            if chunk.strip():
                # 去除多余的空格和换行符
                cleaned = re.sub(r'\s+', ' ', chunk.strip())
                cleaned_chunks.append(cleaned)

        return cleaned_chunks

    def _split_text_recursive(self, text: str, separators: List[str]) -> List[str]:
        """
        递归分割文本

        Args:
            text: 要分割的文本
            separators: 当前可用的分隔符列表

        Returns:
            分割后的文本块列表
        """
        # 如果文本长度小于等于块大小，直接返回
        if self.length_function(text) <= self.chunk_size:
            return [text]

        # 如果没有更多分隔符，按字符分割
        if not separators:
            return self._split_by_chunk_size(text)

        # 选择合适的分隔符
        separator, remaining_separators = self._select_separator(text, separators)

        if separator == "":
            # 如果分隔符为空字符串，按字符分割
            return self._split_by_chunk_size(text)

        # 分割文本
        splits = self._split_by_separator(text, separator)

        # 处理分割结果
        final_chunks = []
        for split in splits:
            split_length = self.length_function(split)

            if split_length <= self.chunk_size:
                final_chunks.append(split)
            elif remaining_separators:
                # 递归分割
                sub_chunks = self._split_text_recursive(split, remaining_separators)
                final_chunks.extend(sub_chunks)
            else:
                # 按字符分割
                sub_chunks = self._split_by_chunk_size(split)
                final_chunks.extend(sub_chunks)

        return final_chunks

    def _select_separator(self, text: str, separators: List[str]) -> tuple[str, List[str]]:
        """
        选择合适的分隔符

        Args:
            text: 文本
            separators: 分隔符列表

        Returns:
            (选中的分隔符, 剩余的分隔符列表)
        """
        for i, sep in enumerate(separators):
            if sep == "":
                # 空字符串始终可用
                return "", separators[i + 1:]

            _sep = sep if self.is_separator_regex else re.escape(sep)
            if re.search(_sep, text):
                return sep, separators[i + 1:]

        # 没有找到合适的分隔符，使用空字符串
        return "", []

    def _split_by_separator(self, text: str, separator: str) -> List[str]:
        """
        使用分隔符分割文本

        Args:
            text: 文本
            separator: 分隔符

        Returns:
            分割后的文本列表
        """
        if not separator:
            return [text]

        # 转义分隔符（如果不是正则表达式）
        pattern = separator if self.is_separator_regex else re.escape(separator)

        if self.keep_separator:
            # 保留分隔符
            splits = re.split(f'({pattern})', text)

            # 合并分隔符和其后的内容
            result = []
            i = 0
            while i < len(splits):
                if i + 1 < len(splits) and re.fullmatch(pattern, splits[i + 1]):
                    # 当前是内容，下一个是分隔符
                    result.append(splits[i] + splits[i + 1])
                    i += 2
                else:
                    if splits[i]:  # 跳过空字符串
                        result.append(splits[i])
                    i += 1
            return result
        else:
            # 不保留分隔符
            return [s for s in re.split(pattern, text) if s]

    def _split_by_chunk_size(self, text: str) -> List[str]:
        """
        按块大小分割文本（最后的手段）

        Args:
            text: 文本

        Returns:
            分割后的文本块列表
        """
        chunks = []
        start = 0
        text_length = self.length_function(text)

        while start < text_length:
            end = min(start + self.chunk_size, text_length)

            # 尝试在完整的分句处结束
            if end < text_length:
                # 查找合适的分割点
                chunk_text = text[start:end]

                # 尝试在标点符号处分割
                for separator in [". ", "! ", "? ", "。", "！", "？", "\n", " "]:
                    last_pos = chunk_text.rfind(separator)
                    if last_pos > 0 and last_pos > self.chunk_size // 2:
                        end = start + last_pos + len(separator)
                        break

            chunks.append(text[start:end])
            start = end - self.chunk_overlap

            # 确保不会无限循环
            if start >= text_length:
                break
            if start <= chunks[-1].rfind("\n") and len(chunks) > 1:
                break

        return chunks

    def _merge_splits(self, splits: List[str], separator: str = "") -> List[str]:
        """
        合并分割片段，考虑块大小和重叠

        Args:
            splits: 分割片段列表
            separator: 连接分隔符

        Returns:
            合并后的文本块列表
        """
        if not splits:
            return []

        # 计算每个片段的长度
        chunk_lengths = [self.length_function(s) for s in splits]

        merged_chunks = []
        current_chunk = ""
        current_length = 0

        for i, (split, split_length) in enumerate(zip(splits, chunk_lengths)):
            # 如果当前块加上新片段超过大小，保存当前块并开始新块
            if current_length + split_length + (len(separator) if current_chunk else 0) > self.chunk_size:
                if current_chunk:
                    merged_chunks.append(current_chunk)

                    # 为下一个块设置重叠
                    if self.chunk_overlap > 0:
                        # 从当前块的末尾取重叠部分
                        overlap_start = max(0, current_length - self.chunk_overlap)
                        overlap_text = current_chunk[overlap_start:] if isinstance(current_chunk, str) else ""
                        current_chunk = overlap_text + separator + split if overlap_text else split
                        current_length = self.length_function(current_chunk)
                    else:
                        current_chunk = split
                        current_length = split_length
                else:
                    current_chunk = split
                    current_length = split_length
            else:
                # 添加到当前块
                if current_chunk:
                    current_chunk += separator + split
                    current_length += len(separator) + split_length
                else:
                    current_chunk = split
                    current_length = split_length

        # 添加最后一个块
        if current_chunk:
            merged_chunks.append(current_chunk)

        return merged_chunks

    def good_splits_merge(self, chunks: List[str], separator: str = "") -> List[str]:
        """
        对切分的文本进行合并处理

        Args:
            chunks: 临时切分的文本信息
            separator: 合并过程中用于连接的分隔符

        Returns:
            经过合并后的切分文本
        """
        return self._merge_splits(chunks, separator)


def split_content(
        doc_content: str,
        text_splitter: RecursiveCharacterTextSplitter
) -> List[str]:
    """
    设定字符数对文本进行切片处理

    Args:
        doc_content: 文本内容
        text_splitter: 用于文本切分的类
    Returns:
        切片文本段落列表
    """
    try:
        # 分割文本
        chunks = text_splitter.split_text(doc_content)

        # 合并拆分片段（如果需要）
        if hasattr(text_splitter, 'good_splits_merge'):
            chunk_list = text_splitter.good_splits_merge(chunks)
        else:
            chunk_list = chunks

        logger.info(f"当前文档内容被切分为{len(chunk_list)}片")
        return chunk_list

    except Exception as e:
        # 获取异常的详细堆栈跟踪信息
        error_traceback = traceback.format_exc()
        # 使用日志记录异常信息
        logger.error(f"文本切片过程中发生错误：{e} 具体报错信息：{error_traceback}")
        raise e