from typing import List, Any, Dict

import re
from himile_log import logger

def _split_text_with_regex_from_end(
    text: str,
    separator: str,
    keep_separator: bool
    ) -> List[str]:
    """
       @brief: 使用正则表达式从后向前分割给定的文本字符串
       @param: text 需要被切分的文本信息
       @param: separator 用于分割字符串的分隔符
       @param: keep_separator 布尔值，指示是否将分隔符保留在结果中
       @return: splits 切片后的文本列表
       @Author: 郝俊飞20232468
       @Time: 20240716
    """
    # 判断分隔符是否为空，若分隔符不为空，则开始分割文本
    if separator:
        # 该参数若为True，则保留分隔符；反之，不保留分隔符
        if keep_separator:
            # 模式中的括号确保结果中保留了分隔符
            _splits = re.split(f"({separator})", text)
            # 将分隔符与文本重新组合成子字符串列表
            splits = ["".join(i) for i in zip(_splits[0::2], _splits[1::2])]
            # 处理奇数个分隔符的情况
            if len(_splits) % 2 == 1:
                splits += _splits[-1:]
        else:
            # 直接使用分隔符进行分割
            splits = re.split(separator, text)
    else:
        # 若没有分隔符，将文本转换为字符列表
        splits = list(text)
    # 过滤空字符
    return [s for s in splits if s != ""]


def obtain_chunk_list(doc_id: str, chunk_index_list: List[int]) -> List[str]:
    """
        @brief:拼接文档ID和索引，确保索引长度为6位。
        @param doc_id: 文档ID。
        @param chunk_index_list: 切片下标列表。
        @return: 拼接后的字符串列表，格式为：doc_id + 6位index。
        @Author: 贾松晴20232256
        @Time: 20240803
    """
    chunk_ids = []
    for index in chunk_index_list:
        # 将索引转换为字符串并确保长度为6位
        index_str = str(index).zfill(6)
        # 拼接doc_id和index
        chunk_id = str(f"{doc_id}{index_str}")
        # 默认int类型超出固定长度限制
        chunk_ids.append(chunk_id)
    logger.info(f"根据文档ID:{doc_id}和下标生成切片下标列表")
    return chunk_ids


def obtain_unique_doc_ids(rerank_result: List[Dict[Any, Any]]) -> List[str]:
    """
        @brief:获取去重后的doc_id列表
        @param rerank_result: 重排序结果
        @return: doc_id
        @Author: 贾松晴20232256
        @Time: 20240803
    """
    # logger.info(f"对文档ID列表进行去重，当前列表中ID数量为{len(rerank_result)}")
    # 用于存储文档ID
    docs_ids = []
    # 根据切片ID提取文档ID
    for rerank_text in rerank_result:
        docs_ids.append(str(rerank_text["id"])[:-6])
    # 将提取到的文档ID去重并返回结果
    unique_doc_ids = list(dict.fromkeys(docs_ids))
    # logger.info(f"原列表数量：{len(rerank_result)}，去重之后的列表数量：{len(unique_doc_ids)}")
    return list(unique_doc_ids)
