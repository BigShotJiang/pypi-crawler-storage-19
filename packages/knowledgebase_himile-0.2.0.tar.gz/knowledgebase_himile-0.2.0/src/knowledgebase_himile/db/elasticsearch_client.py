from elasticsearch import Elasticsearch, AsyncElasticsearch
from .db_abstract import BaseDBSync, BaseDBAsync
from himile_log import logger


class ElasticsearchSync(BaseDBSync):
    """
    同步 Elasticsearch 客户端
    """

    def __init__(self, cfg: dict):
        self.hosts = cfg.get("hosts", ["http://127.0.0.1:9200"])
        self.username = cfg.get("user")
        self.password = cfg.get("password")

        self.client = None

    def connect(self):
        """初始化 ES 客户端"""
        if self.client:
            return self.client

        try:
            http_auth = None
            if self.username and self.password:
                http_auth = (self.username, self.password)

            # 1. 创建连接
            if http_auth:
                es_client = Elasticsearch(
                    self.hosts,
                    basic_auth=http_auth
                )
            else:
                es_client = Elasticsearch(self.hosts)

            # 2. 健康检查
            if not es_client.ping():
                logger.error("Elasticsearch ping failed.")
                raise RuntimeError("Elasticsearch ping failed.")

            self.client = es_client
            return self.client
        except Exception as e:
            logger.error(f"Failed to connect Elasticsearch: hosts={self.hosts}, err={e}")
            raise RuntimeError(f"ESSync connect failed: {e}")

    def close(self):
        """关闭连接"""
        if self.client:
            self.client.close()
            self.client = None

    def execute(self, query: dict, params=None):
        """
        写操作（index/update/delete/bulk）
        query 必须包含 action 字段，例如：
        {
            "action": "index",
            "index": "my_index",
            "id": "123",
            "body": {...}
        }
        :arg query: 查询字典
        :arg params: 参数
        :return: 操作结果
        """
        self.connect()
        try:
            action = query.get("action")
            if action == "index":
                return self.client.index(index=query["index"], id=query.get("id"), body=query["body"])
            elif action == "update":
                return self.client.update(index=query["index"], id=query["id"], body=query["body"])
            elif action == "delete":
                return self.client.delete(index=query["index"], id=query["id"])
            elif action == "bulk":
                return self.client.bulk(body=query["body"])
            else:
                raise ValueError(f"Unknown ES action: {action}")

        except Exception as e:
            logger.error(f"ElasticsearchSync execute failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchSync execute failed. query={query}, err={e}")

    def fetch_one(self, query: dict, params=None):
        """
        查询一条数据
        支持：
        1. get: {"action": "get", "index": "...", "id": "..."}
        2. search: {"action": "search", "index": "...", "body": {...}}
        :arg query: 查询字典
        :arg params: 参数
        :return: 操作结果
        """
        self.connect()
        try:
            action = query.get("action")
            if action == "get":
                return self.client.get(index=query["index"], id=query["id"])

            elif action == "search":
                resp = self.client.search(
                    index=query["index"],
                    body=query.get("body", {}),
                    size=1
                )
                hits = resp.get("hits", {}).get("hits", [])
                return hits[0] if hits else None

            else:
                raise ValueError(f"Unknown ES action for fetch_one: {action}")

        except Exception as e:
            logger.error(f"ElasticsearchSync fetch_one failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchSync fetch_one failed. query={query}, err={e}")

    def fetch_all(self, query: dict, params=None):
        """
        查询多条数据
        :arg query: 查询字典，格式如：{"index": "...", "body": {...}, "size": 1000}
        :arg params: 参数
        :return: 操作结果
        """
        self.connect()
        try:
            resp = self.client.search(
                index=query["index"],
                body=query.get("body", {}),
                size=query.get("size", 1000)
            )
            return resp.get("hits", {}).get("hits", [])

        except Exception as e:
            logger.error(f"ElasticsearchSync fetch_all failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchSync fetch_all failed. query={query}, err={e}")


class ElasticsearchAsync(BaseDBAsync):
    """
    异步 Elasticsearch 客户端
    """

    def __init__(self, cfg: dict):
        """
        初始化 ES 异步客户端
        :param cfg: 配置字典
        """
        self.client = None
        self.hosts = cfg.get("hosts")

        # 身份认证信息
        self.username = cfg.get("user")
        self.password = cfg.get("password")

    async def connect(self):
        """
        连接 ES
        :return: ES 客户端
        """
        if not self.client:
            try:
                http_auth = None
                if self.username and self.password:
                    http_auth = (self.username, self.password)
                if http_auth:
                    # 创建异步 ES 客户端
                    self.client = AsyncElasticsearch(
                        self.hosts,
                        basic_auth=http_auth
                    )
                else:
                    self.client = AsyncElasticsearch(self.hosts)

                # 健康检查（async）
                resp = await self.client.ping()
                if not resp:
                    raise RuntimeError("Elasticsearch ping failed.")

                return self.client

            except Exception as e:
                logger.error(f"ESAsync connect failed. hosts={self.hosts}, err={e}")
                raise RuntimeError(f"ESAsync connect failed: {e}")

    async def close(self):
        """
        关闭 ES 客户端
        """
        if self.client:
            await self.client.close()
            self.client = None

    async def execute(self, query: dict, params=None):
        """
        执行操作
        :param query: 执行字典
        :param params: 参数
        :return: 操作结果
        """
        await self.connect()
        try:
            action = query.get("action")
            if action == "index":
                return await self.client.index(index=query["index"], id=query.get("id"), body=query["body"])
            elif action == "update":
                return await self.client.update(index=query["index"], id=query["id"], body=query["body"])
            elif action == "delete":
                return await self.client.delete(index=query["index"], id=query["id"])
            elif action == "bulk":
                return await self.client.bulk(body=query["body"])
            elif action == "exist":
                return await self.client.indices.exists(index=query["index"])
            else:
                raise ValueError(f"Unknown ES action: {action}")

        except Exception as e:
            logger.error(f"ElasticsearchAsync execute failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchAsync execute failed. query={query}, err={e}")

    async def fetch_one(self, query: dict, params=None):
        """
        查询一条数据
        :param query: 查询字典
        :param params: 参数
        :return: 操作结果
        """
        await self.connect()
        try:
            action = query.get("action")
            if action == "get":
                return await self.client.get(index=query["index"], id=query["id"])

            elif action == "search":
                resp = await self.client.search(
                    index=query["index"],
                    body=query.get("body", {}),
                    size=1
                )
                hits = resp.get("hits", {}).get("hits", [])
                return hits[0] if hits else None

            else:
                raise ValueError(f"Unknown ES action for fetch_one: {action}")

        except Exception as e:
            logger.error(f"ElasticsearchAsync fetch_one failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchAsync fetch_one failed. query={query}, err={e}")

    async def fetch_all(self, query: dict, params=None):
        """
        查询数据
        :param query: 查询字典
        :param params: 参数
        :return: 操作结果
        """
        await self.connect()
        try:
            resp = await self.client.search(
                index=query["index"],
                body=query.get("body", {})
            )
            return resp.get("hits", {}).get("hits", [])

        except Exception as e:
            logger.error(f"ElasticsearchAsync fetch_all failed. query={query}, err={e}")
            raise RuntimeError(f"ElasticsearchAsync fetch_all failed. query={query}, err={e}")

    async def scroll_fetch_all(self, query: dict):
        """
        适合超大数据集滚动查询（需多次请求）
        :param query: 查询字典
        """

        scroll_id = None
        all_hits = []

        try:
            # 初始搜索
            resp = await self.client.search(
                index=query['index'],
                body=query.get("body", {}),
                scroll="2m"
            )

            scroll_id = resp.get("_scroll_id")
            hits = resp["hits"]["hits"]
            all_hits.extend(hits)

            # 继续滚动直到没有数据
            while hits:
                resp = await self.client.scroll(
                    scroll_id=scroll_id,
                    scroll="2m"
                )

                scroll_id = resp.get("_scroll_id")
                hits = resp["hits"]["hits"]
                if not hits:
                    break
                all_hits.extend(hits)

            return all_hits

        except Exception as e:
            raise e
        finally:
            if scroll_id:
                try:
                    await self.client.clear_scroll(scroll_id=scroll_id)
                except Exception:
                    pass

    async def create_index(self, body: dict, index_name: str = None):
        """
        创建索引
        :param body: 索引结构体
        :param index_name: 索引名称
        """
        await self.connect()
        try:
            if index_name:
                if not await self.client.indices.exists(index=index_name):
                    return (await self.client.indices.create(index=index_name, body=body)).get("acknowledged", False)
                else:
                    logger.info(f"ES索引已存在：{index_name}")
                    return True
            else:
                logger.warning("未提供索引名称，无法创建索引")
        except Exception as e:
            logger.error(f"创建ES索引失败: {e}")
            raise RuntimeError(f"创建ES索引失败: {e}")

    async def delete_index(self, index_name: str = None):
        """
        删除索引
        :param index_name: 索引名称
        """
        await self.connect()
        try:
            if index_name:
                if await self.client.indices.exists(index=index_name):
                    return (await self.client.indices.delete(index=index_name)).get("acknowledged", False)
                else:
                    logger.info(f"ES索引不存在：{index_name}")
                    return True
            else:
                logger.warning("未提供索引名称，无法删除索引")
        except Exception as e:
            logger.error(f"删除ES索引失败: {e}")
            raise RuntimeError(f"删除ES索引失败: {e}")