from abc import ABC, abstractmethod


class BaseDBSync(ABC):

    @abstractmethod
    def connect(self):
        """初始化连接（可能是连接池或客户端）"""
        pass

    @abstractmethod
    def close(self):
        """关闭连接或连接池"""
        pass

    @abstractmethod
    def execute(self, query: str, params=None):
        """执行写入类 SQL"""
        pass

    @abstractmethod
    def fetch_one(self, query: str, params=None):
        """执行读取类 SQL"""
        pass

    @abstractmethod
    def fetch_all(self, query: str, params=None):
        """执行读取类 SQL"""
        pass


class BaseDBAsync(ABC):

    @abstractmethod
    async def connect(self):
        """初始化连接（可能是连接池或客户端）"""
        pass

    @abstractmethod
    async def close(self):
        """关闭连接或连接池"""
        pass

    @abstractmethod
    async def execute(self, query: str, params=None):
        """执行写入类 SQL"""
        pass

    @abstractmethod
    async def fetch_one(self, query: str, params=None):
        """执行读取类 SQL"""
        pass

    @abstractmethod
    async def fetch_all(self, query: str, params=None):
        """执行读取类 SQL"""
        pass
