import os
import yaml
from typing import Dict, Any, Union, Optional
from enum import Enum
from himile_log import logger

from .db_abstract import BaseDBSync, BaseDBAsync
from .elasticsearch_client import ElasticsearchSync, ElasticsearchAsync


class DatabaseType(Enum):
    """数据库类型枚举"""
    ELASTICSEARCH_SYNC = "elasticsearch_sync"
    ELASTICSEARCH_ASYNC = "elasticsearch_async"


class DatabaseFactory:
    """
    数据库工厂类

    使用示例：
        self.es_client = DatabaseFactory.get_database(
                DatabaseType.ELASTICSEARCH_ASYNC,
                es_config
            )
        若不传递配置，则从用户目录下.knowledgebase_himile/config.yaml中读取
    """

    _instances = {}  # 单例模式缓存
    _configs = {}  # 配置缓存

    @classmethod
    def load_config(cls, config_path: str = "config.yaml"):
        """加载配置文件"""
        try:
            # config_path = os.path.join(os.path.dirname(__file__), '../config.yaml')
            config_path = os.path.expanduser('~/.knowledgebase_himile/config.yaml')
            if not os.path.exists(config_path):
                raise FileNotFoundError(f"Config file not found: {config_path}")
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                cls._configs = config.get('databases', {})
                logger.info(f"Loaded database configs: {list(cls._configs.keys())}")
        except Exception as e:
            logger.error(f"Failed to load config file: {e}")
            raise

    @classmethod
    def get_database(cls,
                     db_type: Union[str, DatabaseType],
                     config: Optional[Dict[str, Any]] = None) -> Union[BaseDBSync, BaseDBAsync]:
        """
        获取数据库客户端实例

        Args:
            db_type: 数据库类型，可以是字符串或DatabaseType枚举
            config: 可选配置，如果为None则使用配置文件中的配置

        Returns:
            数据库客户端实例
        """
        # 转换数据库类型
        if isinstance(db_type, str):
            db_type = DatabaseType(db_type.lower())

        # 获取配置
        if config is None:
            if not cls._configs:
                cls.load_config()
            config_key = db_type.value
            if config_key not in cls._configs:
                raise ValueError(f"Database config not found: {config_key}")
            config = cls._configs[config_key]

        # 检查是否已有实例
        cache_key = f"{db_type.value}_{hash(str(config))}"
        if cache_key in cls._instances:
            return cls._instances[cache_key]

        # 创建新实例
        instance = cls._create_database(db_type, config)
        cls._instances[cache_key] = instance
        return instance

    @classmethod
    def _create_database(cls, db_type: DatabaseType, config: Dict[str, Any]) -> Union[BaseDBSync, BaseDBAsync]:
        """创建数据库实例"""
        if db_type == DatabaseType.ELASTICSEARCH_SYNC:
            return ElasticsearchSync(config)
        elif db_type == DatabaseType.ELASTICSEARCH_ASYNC:
            return ElasticsearchAsync(config)
        else:
            raise ValueError(f"Unsupported database type: {db_type}")

    @classmethod
    def close_all(cls):
        """关闭所有数据库连接"""
        for key, instance in list(cls._instances.items()):
            try:
                if isinstance(instance, BaseDBSync):
                    instance.close()
                elif isinstance(instance, BaseDBAsync):
                    # 注意：异步关闭需要在异步环境中调用
                    logger.warning(f"Async instance {key} needs to be closed in async context")
            except Exception as e:
                logger.error(f"Error closing database {key}: {e}")
        cls._instances.clear()


# 为了方便使用，提供快捷函数
def get_sync_db(db_type: str, config: Optional[Dict[str, Any]] = None) -> BaseDBSync:
    """获取同步数据库客户端"""
    return DatabaseFactory.get_database(db_type, config)


def get_async_db(db_type: str, config: Optional[Dict[str, Any]] = None) -> BaseDBAsync:
    """获取异步数据库客户端"""
    return DatabaseFactory.get_database(db_type, config)