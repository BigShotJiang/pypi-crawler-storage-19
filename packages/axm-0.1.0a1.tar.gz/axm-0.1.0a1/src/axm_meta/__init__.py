"""AXM Meta-package — The Swiss Clock for Data Pipelines."""

__version__ = "0.1.0a1"
