# hello-pkg

A minimal Python package example.