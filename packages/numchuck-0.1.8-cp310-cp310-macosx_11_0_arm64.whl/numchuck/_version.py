"""Version information for numchuck."""

__version__ = "0.1.8"
__version_info__ = tuple(int(x) for x in __version__.split("."))
