"""PaddleOCR-MCP: PaddleOCR MCP server and CLI tool."""

__version__ = "0.2.8"
__name__ = "PaddleOCR-MCP"
