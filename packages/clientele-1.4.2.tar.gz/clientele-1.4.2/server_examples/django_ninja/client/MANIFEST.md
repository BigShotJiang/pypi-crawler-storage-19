# Manifest

Generated with [https://github.com/phalt/clientele](https://github.com/phalt/clientele)

Install with pipx:

```sh
pipx install clientele
```

Or with uv:

```sh
uv tool install clientele
```

API VERSION: 1.0.0
OPENAPI VERSION: 3.1.0
CLIENTELE VERSION: 1.4.2

Regenerate using this command:

```sh
clientele scaffold-api -f server_examples/django_ninja/openapi.json -o server_examples/django_ninja/client/  --regen
```

Explore this API interactively:

```sh
clientele explore -c .
```
