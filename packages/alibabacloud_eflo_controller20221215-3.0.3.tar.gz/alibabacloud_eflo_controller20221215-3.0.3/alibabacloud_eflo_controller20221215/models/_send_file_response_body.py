# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class SendFileResponseBody(DaraModel):
    def __init__(
        self,
        invoke_id: str = None,
        request_id: str = None,
    ):
        # The ID of the execution.
        self.invoke_id = invoke_id
        # Id of the request
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.invoke_id is not None:
            result['InvokeId'] = self.invoke_id

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('InvokeId') is not None:
            self.invoke_id = m.get('InvokeId')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

