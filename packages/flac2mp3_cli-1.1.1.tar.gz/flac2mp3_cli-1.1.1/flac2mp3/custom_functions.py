
# Command line arguments
import argparse, os, subprocess
from mutagen.flac import FLAC   # Metadata

def collect_args():
    parser = argparse.ArgumentParser(description='This script converts .flac files to .mp3 files, It provides functionality to convert a single FLAC file or all FLAC files within a directory and its subdirectories.')
    parser.add_argument('input_path', type=str, nargs='?', default=os.getcwd(), help='The path to the directory containing the files to process. Default is the current directory.')
    parser.add_argument('--num_threads', '-t', type=int, default=1, help='The number of threads to use. Default is 1.')
    parser.add_argument('--output_path', '-o', type=str, default=None, help='The path to the directory where the output files will be saved. Default is the same directory as the input file.')
    parser.add_argument('--bitrate', '-b', type=int, default=5, help='The bitrare of the mp3 file, from 1 to 5. Default is 5. 1: 96k, 2: 128k, 3: 192k, 4: 255k, 5: 320k.')
    parser.add_argument('--overwrite', '-ow', action='store_true', help='Overwrite the output file if it already exists.')

    args = parser.parse_args()
    
    #Is a path
    if not os.path.exists(args.input_path):
        parser.error("The file_path %s does not exist!" % args.input_path)

    # check if the number of threads is an integer
    if not isinstance(args.num_threads, int):
        parser.error("The number of threads must be an integer")
        
    if args.num_threads < 1:
        parser.error("The number of threads must be at least 1")
   
    bitrate = '320k'
    if args.bitrate not in (1,2,3,4,5):
        parser.error("Bitrate must be an int between 1 and 5, use flac2mp3 --help for more informations")
    else:
        bitrate_dict = {1:"96k", 2:'128k', 3:'192k', 4:'255k', 5:'320k'}
        bitrate = bitrate_dict[args.bitrate]

    if args.output_path is None: 
        # if the output_path is not specified

        if os.path.isfile(args.input_path): 
            # if the input_path is a file, the output_path is the directory of the input_path
            args.output_path = os.path.dirname(args.input_path) 
        
        else: 
            # if the input_path is a directory, the output_path is the input_path + "_converted"
            args.output_path = args.input_path + "_converted" 

    if os.path.isfile(args.output_path):
        parser.error("The output_path %s is not a directory!" % args.output_path)
    
    return args.input_path, args.num_threads, args.output_path, bitrate, args.overwrite
  
    
def dir_scan(input_dir, overwrite):
    '''
    Funcion that scans a given directory and return the number of files, and a list of the file_paths to the files
    '''

    flac_count = 0
    flac_list = []
    file_count = 0
    file_list = []

    for elem in os.listdir(input_dir):
        elem_path = os.path.join(input_dir, elem)

        # if file is a directory, call the function recursively
        if os.path.isdir(elem_path):
            recursive_flac_count, recursive_flac_list, recursive_file_count, recursive_file_list = dir_scan(elem_path, overwrite)
            
            flac_count += recursive_flac_count
            flac_list.extend(recursive_flac_list)
            
            file_count += recursive_file_count
            file_list.extend(recursive_file_list)
            
        elif elem.endswith(".flac"):
            flac_count += 1
            flac_list.append(elem_path)
        
        else:
            file_count += 1
            file_list.append(elem_path)
            
    return flac_count, flac_list, file_count, file_list


def replace_extension(file, new_extension):
    # replace file extension
    return os.path.splitext(file)[0] + new_extension


def get_metadata(file):
    '''input: flac file, output: dictionary with metadata from flac file''' 


    metadata = FLAC(file) #Get metadata from flac
    tags = {}
    for data in metadata:
       #Save flac metatada in tags 
        tags[data] = metadata[data][0] 
    return tags


def flac_mp3(input_file_path, output_file_path, bitrate):
    """
    Converts flac to mp3 using ffmpeg directly via subprocess.
    Requires ffmpeg to be installed on the system (which pydub required anyway).
    """
    # cmd: ffmpeg -i input.flac -ab 320k -map_metadata 0 -id3v2_version 3 output.mp3
    command = [
        'ffmpeg',
        '-y',                  # Overwrite output without asking (logic handled in main)
        '-v', 'quiet',         # Suppress ffmpeg logs
        '-i', input_file_path, # Input file
        '-ab', bitrate,        # Bitrate (e.g., "320k")
        '-map_metadata', '0',  # Copy metadata from input to output
        '-id3v2_version', '3', # Ensure MP3 metadata is widely compatible
        output_file_path
    ]

    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error converting {input_file_path}: {e}")
    except FileNotFoundError:
        print("Error: ffmpeg is not installed or not in PATH.")
        exit(1)