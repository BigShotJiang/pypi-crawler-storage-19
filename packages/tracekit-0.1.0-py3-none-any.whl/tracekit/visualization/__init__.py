"""Visualization module for TraceKit.

Provides plotting functions for waveforms, spectra, and other signal data,
plus optimization utilities, style presets, and intelligent rendering.

Requirements addressed:
- VIS-001: Time-Domain Waveform Plotting
- VIS-002: Multi-Channel Plotting
- VIS-003: Frequency Spectrum Plotting
- VIS-004: Spectrogram Visualization
- VIS-005: Digital Timing Diagram
- VIS-006: Eye Diagram
- VIS-007: Interactive Zoom and Pan
- VIS-008: Measurement Cursors
- VIS-009: Phase Plot
- VIS-010: Bode Plot
- VIS-011: Waterfall Plot
- VIS-012: Histogram Plot
- VIS-013: Auto Y-Axis Range Optimization
- VIS-014: Adaptive X-Axis Time Window
- VIS-015: Multi-Channel Stack Optimization
- VIS-016: Annotation Placement Intelligence
- VIS-017: DPI-Aware Rendering
- VIS-018: Thumbnail Mode
- VIS-019: Grid Auto-Spacing
- VIS-020: Zoom to Interesting Regions
- VIS-021: Eye Diagram Auto-Centering
- VIS-022: Spectrum dB Range Optimization
- VIS-023: Data-Driven Color Palette
- VIS-024: Plot Style Presets
- VIS-025: Histogram Bin Optimization
- ACC-001: Colorblind-Safe Visualization Palette
- ACC-002: Text Alternatives for Visualizations
- ACC-003: Keyboard Navigation for Interactive Plots

Example:
    >>> from tracekit.visualization import plot_waveform, plot_spectrum
    >>> from tracekit.visualization import plot_timing, plot_eye
    >>> from tracekit.visualization import plot_bode, plot_histogram
    >>> from tracekit.visualization import apply_style_preset
    >>> import matplotlib.pyplot as plt
    >>> with apply_style_preset("publication"):
    ...     plot_waveform(trace, time_unit="us")
    ...     plt.savefig("figure.pdf")
"""

# Import plot module as namespace for DSL compatibility
from tracekit.visualization import plot
from tracekit.visualization.accessibility import (
    FAIL_SYMBOL,
    LINE_STYLES,
    PASS_SYMBOL,
    KeyboardHandler,
    add_plot_aria_attributes,
    format_pass_fail,
    generate_alt_text,
    get_colorblind_palette,
    get_multi_line_styles,
)

# Phase 30 enhancements
from tracekit.visualization.annotations import (
    Annotation as EnhancedAnnotation,
)
from tracekit.visualization.annotations import (
    PlacedAnnotation as EnhancedPlacedAnnotation,
)
from tracekit.visualization.annotations import (
    create_priority_annotation,
    filter_by_zoom_level,
    place_annotations,
)
from tracekit.visualization.axis_scaling import (
    calculate_axis_limits,
    calculate_multi_channel_limits,
    suggest_tick_spacing,
)
from tracekit.visualization.colors import (
    COLORBLIND_SAFE_QUALITATIVE,
    DIVERGING_COOLWARM,
    SEQUENTIAL_VIRIDIS,
    select_optimal_palette,
)
from tracekit.visualization.digital import (
    plot_logic_analyzer,
    plot_timing,
)
from tracekit.visualization.eye import (
    plot_bathtub,
    plot_eye,
)
from tracekit.visualization.histogram import (
    calculate_bin_edges,
    calculate_optimal_bins,
)
from tracekit.visualization.interactive import (
    CursorMeasurement,
    ZoomState,
    add_measurement_cursors,
    enable_zoom_pan,
    plot_bode,
    plot_histogram,
    plot_phase,
    plot_waterfall,
    plot_with_cursors,
)
from tracekit.visualization.layout import (
    Annotation,
    ChannelLayout,
    PlacedAnnotation,
    layout_stacked_channels,
    optimize_annotation_placement,
)
from tracekit.visualization.optimization import (
    InterestingRegion,
    calculate_grid_spacing,
    calculate_optimal_x_window,
    calculate_optimal_y_range,
    decimate_for_display,
    detect_interesting_regions,
    optimize_db_range,
)
from tracekit.visualization.presets import (
    DARK_THEME_PRESET,
    IEEE_DOUBLE_COLUMN_PRESET,
    IEEE_PUBLICATION_PRESET,
    VisualizationPreset,
    apply_preset,
    get_preset_colors,
)
from tracekit.visualization.presets import (
    create_custom_preset as create_custom_visualization_preset,
)
from tracekit.visualization.presets import (
    list_presets as list_visualization_presets,
)
from tracekit.visualization.render import (
    RenderPreset,
    apply_rendering_config,
    configure_dpi_rendering,
)
from tracekit.visualization.rendering import (
    StreamingRenderer,
    downsample_for_memory,
    estimate_memory_usage,
    progressive_render,
    render_with_lod,
)
from tracekit.visualization.specialized import (
    ProtocolSignal,
    StateTransition,
    plot_protocol_timing,
    plot_state_machine,
)
from tracekit.visualization.spectral import (
    plot_fft,
    plot_psd,
    plot_spectrogram,
    plot_spectrum,
)
from tracekit.visualization.styles import (
    PRESENTATION_PRESET,
    PRINT_PRESET,
    PUBLICATION_PRESET,
    SCREEN_PRESET,
    StylePreset,
    apply_style_preset,
    create_custom_preset,
)
from tracekit.visualization.thumbnails import (
    render_thumbnail,
    render_thumbnail_multichannel,
)
from tracekit.visualization.time_axis import (
    TimeUnit,
    calculate_major_ticks,
    convert_time_values,
    create_relative_time,
    format_cursor_readout,
    format_time_labels,
    select_time_unit,
)
from tracekit.visualization.waveform import (
    plot_multi_channel,
    plot_waveform,
    plot_xy,
)

__all__ = [
    "COLORBLIND_SAFE_QUALITATIVE",
    "DARK_THEME_PRESET",
    "DIVERGING_COOLWARM",
    "FAIL_SYMBOL",
    "IEEE_DOUBLE_COLUMN_PRESET",
    "IEEE_PUBLICATION_PRESET",
    "LINE_STYLES",
    "PASS_SYMBOL",
    "PRESENTATION_PRESET",
    "PRINT_PRESET",
    "PUBLICATION_PRESET",
    "SCREEN_PRESET",
    "SEQUENTIAL_VIRIDIS",
    "Annotation",
    # Layout functions (VIS-015, VIS-016)
    "ChannelLayout",
    # Interactive (VIS-008)
    "CursorMeasurement",
    # Phase 30: Enhanced modules
    "EnhancedAnnotation",
    "EnhancedPlacedAnnotation",
    "InterestingRegion",
    "KeyboardHandler",
    "PlacedAnnotation",
    "ProtocolSignal",
    "RenderPreset",
    "StateTransition",
    "StreamingRenderer",
    "StylePreset",
    "TimeUnit",
    "VisualizationPreset",
    # Interactive (VIS-007)
    "ZoomState",
    # Interactive (VIS-008)
    "add_measurement_cursors",
    "add_plot_aria_attributes",
    "apply_preset",
    "apply_rendering_config",
    # Styles
    "apply_style_preset",
    "calculate_axis_limits",
    "calculate_bin_edges",
    "calculate_grid_spacing",
    "calculate_major_ticks",
    "calculate_multi_channel_limits",
    # Histogram
    "calculate_optimal_bins",
    "calculate_optimal_x_window",
    # Optimization functions (VIS-013, VIS-014, VIS-019, VIS-020, VIS-022)
    "calculate_optimal_y_range",
    # Rendering functions (VIS-017)
    "configure_dpi_rendering",
    "convert_time_values",
    "create_custom_preset",
    "create_custom_visualization_preset",
    "create_priority_annotation",
    "create_relative_time",
    "decimate_for_display",
    "detect_interesting_regions",
    "downsample_for_memory",
    # Interactive (VIS-007)
    "enable_zoom_pan",
    "estimate_memory_usage",
    "filter_by_zoom_level",
    "format_cursor_readout",
    "format_pass_fail",
    "format_time_labels",
    "generate_alt_text",
    # Accessibility (ACC-001, ACC-002, ACC-003)
    "get_colorblind_palette",
    "get_multi_line_styles",
    "get_preset_colors",
    "layout_stacked_channels",
    "list_visualization_presets",
    "optimize_annotation_placement",
    "optimize_db_range",
    "place_annotations",
    "plot",
    # Eye diagram (VIS-006)
    "plot_bathtub",
    # Interactive (VIS-010)
    "plot_bode",
    "plot_eye",
    # Spectral plotting
    "plot_fft",
    # Interactive (VIS-012)
    "plot_histogram",
    # Digital visualization (VIS-005)
    "plot_logic_analyzer",
    "plot_multi_channel",
    # Interactive (VIS-009)
    "plot_phase",
    "plot_protocol_timing",
    "plot_psd",
    "plot_spectrogram",
    "plot_spectrum",
    "plot_state_machine",
    "plot_timing",
    # Interactive (VIS-011)
    "plot_waterfall",
    # Waveform plotting
    "plot_waveform",
    # Interactive (VIS-008)
    "plot_with_cursors",
    "plot_xy",
    "progressive_render",
    # Thumbnails
    "render_thumbnail",
    "render_thumbnail_multichannel",
    "render_with_lod",
    # Colors
    "select_optimal_palette",
    "select_time_unit",
    "suggest_tick_spacing",
]
