"""Auto-inference and smart defaults for TraceKit.

This module provides automatic parameter detection and intelligent defaults
for common analysis tasks.

Requirements addressed:
- INF-001: Logic Family Auto-Detection
- INF-002: Protocol Type Auto-Detection
- INF-003: Spectral Method Auto-Selection
- INF-004: Smart Defaults Configuration
- INF-005: Signal Type Classification
- INF-006: Signal Quality Assessment
- INF-007: Measurement Suitability Checker
- INF-008: Smart Measurement Suggestions
- PSI-001: Message Format Inference
- PSI-002: Passive State Machine Inference
- PSI-003: Sequence Alignment for Message Comparison
- PSI-004: Protocol Definition Language
- PSI-005: Bayesian Inference for Protocol Characteristics
- RE-SEQ-002: Sequence Pattern Detection
- RE-SEQ-003: Request-Response Correlation
- RE-STR-001: UDP Stream Reconstruction
- RE-STR-002: TCP Stream Reassembly
- RE-STR-003: Message Framing and Segmentation
- RE-BIN-001: Magic Byte Detection
- RE-BIN-002: Structure Alignment Detection
- RE-BIN-003: Binary Parser DSL
- RE-DSL-003: Protocol Format Library
"""

# PSI-003: Sequence Alignment
# INF-004: Smart Defaults Configuration (Adaptive Parameter Tuning)
from tracekit.inference.adaptive_tuning import (
    AdaptiveParameterTuner,
    TunedParameters,
    get_adaptive_parameters,
)
from tracekit.inference.alignment import (
    AlignmentResult,
    align_global,
    align_local,
    align_multiple,
    compute_similarity,
    find_conserved_regions,
    find_variable_regions,
)

# PSI-005: Bayesian Inference for Protocol Characteristics
from tracekit.inference.bayesian import (
    BayesianInference,
    Posterior,
    Prior,
    SequentialBayesian,
    infer_with_uncertainty,
)

# RE-BIN-001, RE-BIN-002, RE-BIN-003: Binary Format Inference
from tracekit.inference.binary import (
    KNOWN_MAGIC_BYTES,
    AlignmentDetector,
    BinaryParserGenerator,
    MagicByteDetector,
    MagicByteResult,
    ParserDefinition,
    ParserField,
    detect_alignment,
    detect_magic_bytes,
    find_all_magic_bytes,
    generate_parser,
    parser_to_python,
    parser_to_yaml,
)
from tracekit.inference.binary import (
    AlignmentResult as BinaryAlignmentResult,
)
from tracekit.inference.logic import detect_logic_family

# PSI-001: Message Format Inference
from tracekit.inference.message_format import (
    InferredField,
    MessageFormatInferrer,
    MessageSchema,
    detect_field_types,
    find_dependencies,
    infer_format,
)
from tracekit.inference.protocol import detect_protocol

# PSI-004: Protocol Definition Language
from tracekit.inference.protocol_dsl import (
    DecodedMessage,
    FieldDefinition,
    ProtocolDecoder,
    ProtocolDefinition,
    ProtocolEncoder,
    decode_message,
    load_protocol,
)

# RE-DSL-003: Protocol Format Library
from tracekit.inference.protocol_library import (
    ProtocolInfo,
    ProtocolLibrary,
    get_decoder,
    get_library,
    get_protocol,
    list_protocols,
)

# RE-SEQ-002, RE-SEQ-003: Sequence Pattern Detection and Correlation
from tracekit.inference.sequences import (
    CommunicationFlow,
    RequestResponseCorrelator,
    RequestResponsePair,
    SequencePattern,
    SequencePatternDetector,
    calculate_latency_stats,
    correlate_requests,
    detect_sequence_patterns,
    find_message_dependencies,
)
from tracekit.inference.signal_intelligence import (
    AnalysisRecommendation,
    assess_signal_quality,
    check_measurement_suitability,
    classify_signal,
    get_optimal_domain_order,
    recommend_analyses,
    suggest_measurements,
)
from tracekit.inference.spectral import auto_spectral_config

# PSI-002: State Machine Inference
from tracekit.inference.state_machine import (
    FiniteAutomaton,
    State,
    StateMachineInferrer,
    Transition,
    infer_rpni,
    minimize_dfa,
    to_dot,
    to_networkx,
)

# RE-STR-001, RE-STR-002, RE-STR-003: Stream Reassembly
from tracekit.inference.stream import (
    FramingResult,
    MessageFrame,
    MessageFramer,
    ReassembledStream,
    StreamSegment,
    TCPStreamReassembler,
    UDPStreamReassembler,
    detect_message_framing,
    extract_messages,
    reassemble_tcp_stream,
    reassemble_udp_stream,
)

__all__ = [
    "KNOWN_MAGIC_BYTES",
    # INF-004: Smart Defaults Configuration (Adaptive Parameter Tuning)
    "AdaptiveParameterTuner",
    # RE-BIN-001, RE-BIN-002, RE-BIN-003: Binary Format Inference
    "AlignmentDetector",
    # PSI-003: Sequence Alignment
    "AlignmentResult",
    # INF-009: Smart Analysis Selection
    "AnalysisRecommendation",
    # PSI-005: Bayesian Inference
    "BayesianInference",
    "BinaryAlignmentResult",
    "BinaryParserGenerator",
    # RE-SEQ-002, RE-SEQ-003: Sequence Patterns and Correlation
    "CommunicationFlow",
    # PSI-004: Protocol Definition Language
    "DecodedMessage",
    "FieldDefinition",
    # PSI-002: State Machine Inference
    "FiniteAutomaton",
    # RE-STR-001, RE-STR-002, RE-STR-003: Stream Reassembly
    "FramingResult",
    # PSI-001: Message Format Inference
    "InferredField",
    "MagicByteDetector",
    "MagicByteResult",
    "MessageFormatInferrer",
    "MessageFrame",
    "MessageFramer",
    "MessageSchema",
    "ParserDefinition",
    "ParserField",
    "Posterior",
    "Prior",
    "ProtocolDecoder",
    "ProtocolDefinition",
    "ProtocolEncoder",
    # RE-DSL-003: Protocol Format Library
    "ProtocolInfo",
    "ProtocolLibrary",
    "ReassembledStream",
    "RequestResponseCorrelator",
    "RequestResponsePair",
    "SequencePattern",
    "SequencePatternDetector",
    "SequentialBayesian",
    "State",
    "StateMachineInferrer",
    "StreamSegment",
    "TCPStreamReassembler",
    "Transition",
    "TunedParameters",
    "UDPStreamReassembler",
    "align_global",
    "align_local",
    "align_multiple",
    # Original exports
    "assess_signal_quality",
    "auto_spectral_config",
    "calculate_latency_stats",
    "check_measurement_suitability",
    "classify_signal",
    "compute_similarity",
    "correlate_requests",
    "decode_message",
    "detect_alignment",
    "detect_field_types",
    "detect_logic_family",
    "detect_magic_bytes",
    "detect_message_framing",
    "detect_protocol",
    "detect_sequence_patterns",
    "extract_messages",
    "find_all_magic_bytes",
    "find_conserved_regions",
    "find_dependencies",
    "find_message_dependencies",
    "find_variable_regions",
    "generate_parser",
    "get_adaptive_parameters",
    "get_decoder",
    "get_library",
    "get_optimal_domain_order",
    "get_protocol",
    "infer_format",
    "infer_rpni",
    "infer_with_uncertainty",
    "list_protocols",
    "load_protocol",
    "minimize_dfa",
    "parser_to_python",
    "parser_to_yaml",
    "reassemble_tcp_stream",
    "reassemble_udp_stream",
    "recommend_analyses",
    "suggest_measurements",
    "to_dot",
    "to_networkx",
]
