"""TraceKit utilities package.

Provides utility functions for memory management, windowing, and progressive analysis.

Requirements addressed:
- MEM-001 to MEM-003: Memory estimation and checking
- MEM-009 to MEM-015: Memory limits and monitoring
- MEM-013: Progressive resolution analysis
- MEM-014: Quality vs memory trade-off presets
- MEM-020: Garbage collection controls
- MEM-023: WSL swap awareness
- MEM-025: Memory usage logging
- MEM-028: Adaptive measurement selection
- MEM-030: Cache invalidation strategies
- MEM-031: Disk-based persistent cache
- MEM-032: Backpressure control
- MEM-033: Multi-channel memory management
"""

from tracekit.utils.memory import (
    MemoryCheck,
    MemoryCheckError,
    MemoryConfig,
    MemoryEstimate,
    MemoryMonitor,
    check_memory_available,
    configure_memory,
    detect_wsl,
    estimate_memory,
    get_available_memory,
    get_max_memory,
    get_memory_config,
    get_memory_info,
    get_memory_pressure,
    get_swap_available,
    get_total_memory,
    require_memory,
    set_max_memory,
    suggest_downsampling,
)
from tracekit.utils.memory_advanced import (
    AdaptiveMeasurementSelector,
    BackpressureController,
    CacheEntry,
    CacheInvalidationStrategy,
    DiskCache,
    GCController,
    MemoryLogEntry,
    MemoryLogger,
    MultiChannelMemoryManager,
    QualityMode,
    QualityModeConfig,
    WSLSwapChecker,
    gc_aggressive,
    get_quality_config,
    get_wsl_memory_limits,
)
from tracekit.utils.progressive import (
    PreviewResult,
    ROISelection,
    analyze_roi,
    create_preview,
    estimate_optimal_preview_factor,
    progressive_analysis,
    select_roi,
)

__all__ = [
    # Advanced memory management (MEM-014, 020, 023, 025, 028, 030-033)
    "AdaptiveMeasurementSelector",
    "BackpressureController",
    "CacheEntry",
    "CacheInvalidationStrategy",
    "DiskCache",
    "GCController",
    # Memory management
    "MemoryCheck",
    "MemoryCheckError",
    "MemoryConfig",
    "MemoryEstimate",
    "MemoryLogEntry",
    "MemoryLogger",
    "MemoryMonitor",
    "MultiChannelMemoryManager",
    # Progressive analysis
    "PreviewResult",
    "QualityMode",
    "QualityModeConfig",
    "ROISelection",
    "WSLSwapChecker",
    "analyze_roi",
    "check_memory_available",
    "configure_memory",
    "create_preview",
    "detect_wsl",
    "estimate_memory",
    "estimate_optimal_preview_factor",
    "gc_aggressive",
    "get_available_memory",
    "get_max_memory",
    "get_memory_config",
    "get_memory_info",
    "get_memory_pressure",
    "get_quality_config",
    "get_swap_available",
    "get_total_memory",
    "get_wsl_memory_limits",
    "progressive_analysis",
    "require_memory",
    "select_roi",
    "set_max_memory",
    "suggest_downsampling",
]
