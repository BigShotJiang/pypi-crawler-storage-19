"""Workflow execution and DAG-based analysis.

This module provides directed acyclic graph (DAG) execution for complex
multi-step analysis workflows with automatic dependency resolution and
parallel execution.

Requirements addressed:
- API-013: DAG Execution for Complex Workflows
"""

from tracekit.workflow.dag import TaskNode, WorkflowDAG

__all__ = [
    "TaskNode",
    "WorkflowDAG",
]
