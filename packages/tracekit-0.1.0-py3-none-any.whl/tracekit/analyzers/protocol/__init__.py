"""Protocol decoding module.

This module re-exports protocol decoders from the protocols package
for convenient access.

Requirements addressed:
- PRO-001 through PRO-005: Protocol decoders
"""

from tracekit.analyzers.protocols import (
    CAN_BITRATES,
    Annotation,
    AnnotationLevel,
    AsyncDecoder,
    CANDecoder,
    CANFrame,
    CANFrameType,
    ChannelDef,
    DecoderState,
    I2CDecoder,
    OptionDef,
    ProtocolDecoder,
    SPIDecoder,
    SyncDecoder,
    UARTDecoder,
    decode_can,
    decode_i2c,
    decode_spi,
    decode_uart,
)

__all__ = [
    "CAN_BITRATES",
    "Annotation",
    "AnnotationLevel",
    "AsyncDecoder",
    # CAN
    "CANDecoder",
    "CANFrame",
    "CANFrameType",
    "ChannelDef",
    "DecoderState",
    # I2C
    "I2CDecoder",
    "OptionDef",
    # Base
    "ProtocolDecoder",
    # SPI
    "SPIDecoder",
    "SyncDecoder",
    # UART
    "UARTDecoder",
    "decode_can",
    "decode_i2c",
    "decode_spi",
    "decode_uart",
]
