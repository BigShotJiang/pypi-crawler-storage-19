"""Onboarding and help system for TraceKit.

This package provides interactive tutorials, context-sensitive help,
and guided analysis features for new users.

Requirements addressed:
- ONB-001: First-Run Tutorial
- ONB-002: Context-Sensitive Help
- ONB-003: Command Suggestions
- DISC-006: Interactive Analysis Wizard
- DISC-012: Plain English Help
"""

from tracekit.onboarding.help import (
    explain_result,
    get_example,
    get_help,
    suggest_commands,
)
from tracekit.onboarding.tutorials import (
    Tutorial,
    TutorialStep,
    get_tutorial,
    list_tutorials,
    run_tutorial,
)
from tracekit.onboarding.wizard import (
    AnalysisWizard,
    WizardStep,
    run_wizard,
)

__all__ = [
    "AnalysisWizard",
    "Tutorial",
    "TutorialStep",
    "WizardStep",
    "explain_result",
    "get_example",
    "get_help",
    "get_tutorial",
    "list_tutorials",
    "run_tutorial",
    "run_wizard",
    "suggest_commands",
]
