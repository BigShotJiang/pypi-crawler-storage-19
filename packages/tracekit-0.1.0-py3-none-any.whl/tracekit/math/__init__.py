"""Math and arithmetic operations module for TraceKit.

This module provides waveform math operations including arithmetic,
interpolation, and mathematical transformations.

Requirements addressed:
- ARITH-001: Trace Addition
- ARITH-002: Trace Subtraction
- ARITH-003: Trace Multiplication
- ARITH-004: Trace Division
- ARITH-005: Trace Differentiation
- ARITH-006: Trace Integration
"""

from tracekit.math.arithmetic import (
    absolute,
    add,
    differentiate,
    divide,
    integrate,
    invert,
    math_expression,
    multiply,
    offset,
    scale,
    subtract,
)
from tracekit.math.interpolation import (
    align_traces,
    downsample,
    interpolate,
    resample,
)

__all__ = [
    "absolute",
    # Arithmetic operations
    "add",
    "align_traces",
    "differentiate",
    "divide",
    "downsample",
    "integrate",
    # Interpolation
    "interpolate",
    "invert",
    "math_expression",
    "multiply",
    "offset",
    "resample",
    "scale",
    "subtract",
]
