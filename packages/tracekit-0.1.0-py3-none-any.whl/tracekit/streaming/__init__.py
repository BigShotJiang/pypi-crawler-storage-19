"""Streaming APIs for memory-efficient large file processing.

This package provides chunk-by-chunk processing capabilities for huge
waveform files that don't fit in memory, plus real-time streaming APIs.

Requirements addressed:
- API-003: Streaming/Generator API for Large Files
- API-004: Real-time Streaming API for DAQ Integration
- MEM-004: Chunked Spectrogram
- MEM-006: Chunked FFT for Very Long Signals
"""

from .chunked import (
    StreamingAnalyzer,
    chunked_fft,
    chunked_spectrogram,
    load_trace_chunks,
)
from .progressive import (
    ProgressiveAnalyzer,
    StreamingConfig,
    StreamingProgress,
    create_progressive_analyzer,
)
from .realtime import (
    RealtimeAnalyzer,
    RealtimeBuffer,
    RealtimeConfig,
    RealtimeSource,
    RealtimeStream,
)

__all__ = [
    "ProgressiveAnalyzer",
    "RealtimeAnalyzer",
    "RealtimeBuffer",
    "RealtimeConfig",
    "RealtimeSource",
    "RealtimeStream",
    "StreamingAnalyzer",
    "StreamingConfig",
    "StreamingProgress",
    "chunked_fft",
    "chunked_spectrogram",
    "create_progressive_analyzer",
    "load_trace_chunks",
]
