"""Parameter optimization and search algorithms.

This module provides grid search and randomized search for finding optimal
analysis parameters.

Requirements addressed:
- API-014: Grid Search / Parameter Optimization
"""

from tracekit.optimization.search import (
    GridSearchCV,
    RandomizedSearchCV,
    ScoringFunction,
    SearchResult,
)

__all__ = [
    "GridSearchCV",
    "RandomizedSearchCV",
    "ScoringFunction",
    "SearchResult",
]
