"""TraceKit Command-Line Interface.

This module provides command-line tools for signal analysis workflows.

Requirements addressed:
- CLI-001: Core CLI Framework
- CLI-002: Characterize Command
- CLI-003: Decode Command
- CLI-004: Batch Command
- CLI-005: Compare Command

Example:
    $ tracekit --help
    $ tracekit characterize signal.wfm
    $ tracekit decode uart.wfm --protocol uart
"""

from tracekit.cli.main import cli

__all__ = ["cli"]
