"""Component analysis module for TraceKit.

This module provides TDR-based impedance extraction, capacitance/inductance
measurement, parasitic extraction, and transmission line analysis.

Requirements addressed:
- COMP-001: TDR Impedance Extraction
- COMP-002: Capacitance Measurement
- COMP-003: Inductance Measurement
- COMP-004: Parasitic Extraction
- SI-001: Transmission Line Analysis
"""

from tracekit.component.impedance import (
    discontinuity_analysis,
    extract_impedance,
    impedance_profile,
)
from tracekit.component.reactive import (
    extract_parasitics,
    measure_capacitance,
    measure_inductance,
)
from tracekit.component.transmission_line import (
    characteristic_impedance,
    propagation_delay,
    transmission_line_analysis,
    velocity_factor,
)

__all__ = [
    "characteristic_impedance",
    "discontinuity_analysis",
    # Impedance
    "extract_impedance",
    "extract_parasitics",
    "impedance_profile",
    # Reactive
    "measure_capacitance",
    "measure_inductance",
    "propagation_delay",
    # Transmission line
    "transmission_line_analysis",
    "velocity_factor",
]
