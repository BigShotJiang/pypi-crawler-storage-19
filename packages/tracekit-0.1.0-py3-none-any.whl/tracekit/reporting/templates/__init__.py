"""Template system for reports.

Requirements addressed:
- REPORT-007: Template Definition Format
"""

from tracekit.reporting.templates.definition import (
    TemplateDefinition,
    list_builtin_templates,
    load_template,
    validate_template,
)

__all__ = [
    "TemplateDefinition",
    "list_builtin_templates",
    "load_template",
    "validate_template",
]
