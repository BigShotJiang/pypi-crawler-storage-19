"""TraceKit guidance module.

Provides guided analysis workflows and recommendations.

Requirements addressed:
- DISC-006: Interactive Analysis Wizard
- DISC-008: Recommendation Engine
"""

from tracekit.guidance.recommender import (
    AnalysisHistory,
    Recommendation,
    suggest_next_steps,
)
from tracekit.guidance.wizard import (
    AnalysisWizard,
    WizardResult,
    WizardStep,
)

__all__ = [
    "AnalysisHistory",
    "AnalysisWizard",
    "Recommendation",
    "WizardResult",
    "WizardStep",
    "suggest_next_steps",
]
