"""TraceKit configuration and schema validation system.

This package provides:
- JSON Schema-based configuration validation
- YAML/JSON configuration loading
- Protocol definition loading
- Threshold configuration management
- Pipeline configuration
- User preferences

Requirements addressed:
- CFG-001: Protocol Definition Schema
- CFG-002: Protocol Definition Loader
- CFG-003: Protocol Definition Registry
- CFG-004: Protocol Inheritance
- CFG-005: Logic Family Config Files
- CFG-006: Threshold Override
- CFG-007: Custom Logic Family Definitions
- CFG-008: Threshold Profiles
- CFG-009: Pipeline Definition Files
- CFG-010: Pipeline Loader
- CFG-011: Pipeline Templates
- CFG-012: Pipeline Composition
- CFG-013: Conditional Pipeline Steps
- CFG-014: JSON Schema Registry
- CFG-015: Config Validation
- CFG-016: Schema Migration
- CFG-017: Default Value Injection
- CFG-018: Preferences Persistence
- CFG-019: Application Settings Management
- CFG-020: Feature Flags
- CFG-021: Runtime Configuration

Example:
    >>> from tracekit.config import load_config, validate_config
    >>> config = load_config("pipeline.yaml")
    >>> validate_config(config, schema="pipeline")
"""

from tracekit.config.defaults import (
    DEFAULT_CONFIG,
    get_effective_config,
    inject_defaults,
)
from tracekit.config.loader import (
    get_config_value,
    load_config,
    load_config_file,
    save_config,
)
from tracekit.config.memory import (
    MemoryConfiguration,
    configure_from_environment,
    enable_auto_degrade,
    get_memory_config,
    reset_to_defaults,
    set_memory_limit,
    set_memory_reserve,
    set_memory_thresholds,
)
from tracekit.config.migration import (
    Migration,
    MigrationFunction,
    SchemaMigration,
    get_config_version,  # noqa: F401
    get_migration_registry,
    list_migrations,
    migrate_config,
    register_migration,
)
from tracekit.config.pipeline import (
    Pipeline,
    PipelineDefinition,
    PipelineExecutionError,
    PipelineResult,
    PipelineStep,
    PipelineTemplate,
    PipelineValidationError,
    load_pipeline,
    resolve_includes,
)
from tracekit.config.preferences import (
    DefaultsPreferences,
    EditorPreferences,
    ExportPreferences,
    LoggingPreferences,
    PreferencesManager,
    UserPreferences,
    VisualizationPreferences,
    get_preferences,
    get_preferences_manager,
    save_preferences,
)
from tracekit.config.protocol import (
    ProtocolCapabilities,
    ProtocolDefinition,
    ProtocolRegistry,
    ProtocolWatcher,
    get_protocol_registry,
    load_protocol,
    resolve_inheritance,
)
from tracekit.config.schema import (
    ConfigSchema,
    SchemaRegistry,
    ValidationError,
    get_schema_registry,
    register_schema,
    validate_against_schema,
)
from tracekit.config.settings import (
    AnalysisSettings,
    CLIDefaults,
    OutputSettings,
    Settings,
    get_settings,
    load_settings,
    reset_settings,
    save_settings,
    set_settings,
)
from tracekit.config.thresholds import (
    LogicFamily,
    ThresholdProfile,
    ThresholdRegistry,
    get_threshold_registry,
    get_user_logic_families_dir,
    load_logic_family,
    load_user_logic_families,
)

__all__ = [
    "DEFAULT_CONFIG",
    # Settings
    "AnalysisSettings",
    "CLIDefaults",
    # Schema
    "ConfigSchema",
    # Preferences
    "DefaultsPreferences",
    "EditorPreferences",
    "ExportPreferences",
    "LoggingPreferences",
    # Thresholds
    "LogicFamily",
    # Memory configuration
    "MemoryConfiguration",
    # Migration (CFG-016)
    "Migration",
    "MigrationFunction",
    "OutputSettings",
    # Pipeline
    "Pipeline",
    "PipelineDefinition",
    "PipelineExecutionError",
    "PipelineResult",
    "PipelineStep",
    "PipelineTemplate",
    "PipelineValidationError",
    "PreferencesManager",
    # Protocol
    "ProtocolCapabilities",
    "ProtocolDefinition",
    "ProtocolRegistry",
    "ProtocolWatcher",
    "SchemaMigration",
    "SchemaRegistry",
    "Settings",
    "ThresholdProfile",
    "ThresholdRegistry",
    "UserPreferences",
    "ValidationError",
    "VisualizationPreferences",
    "configure_from_environment",
    "enable_auto_degrade",
    "get_config_value",
    "get_effective_config",
    "get_memory_config",
    "get_migration_registry",
    "get_preferences",
    "get_preferences_manager",
    "get_protocol_registry",
    "get_schema_registry",
    "get_settings",
    "get_threshold_registry",
    "get_user_logic_families_dir",
    # Defaults
    "inject_defaults",
    "list_migrations",
    # Loading
    "load_config",
    "load_config_file",
    "load_logic_family",
    "load_pipeline",
    "load_protocol",
    "load_settings",
    "load_user_logic_families",
    "migrate_config",
    "register_migration",
    "register_schema",
    "reset_settings",
    "reset_to_defaults",
    "resolve_includes",
    "resolve_inheritance",
    "save_config",
    "save_preferences",
    "save_settings",
    "set_memory_limit",
    "set_memory_reserve",
    "set_memory_thresholds",
    "set_settings",
    "validate_against_schema",
]
