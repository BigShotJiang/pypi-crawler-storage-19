import os
from agents import Agent
from agents.tool import function_tool
import sqlite3
from autobus.util.load_config import config
from importlib import resources as impresources
from autobus import prolog_template

LLM = "gpt-5.2"
AGENT_NAME = "core_agent"


@function_tool
async def get_prolog_template(template_name:str) -> str:
    """
    Given a template name, return the Prolog template.
    """

    template = impresources.read_text(prolog_template, template_name)
    return template

@function_tool
async def get_db_schema(db_path:str=config['directory']['db_file_path']) -> str:
    """
    Return the schema of the database as DDL statements (CREATE TABLE/INDEX/etc.).
    The result is a single string containing all DDL statements separated by blank lines.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Get all user-defined schema objects (tables, indexes, views, triggers),
    # skipping SQLite's internal tables
    cursor.execute("""
        SELECT type, name, sql
        FROM sqlite_master
        WHERE name NOT LIKE 'sqlite_%'
          AND sql IS NOT NULL
        ORDER BY type, name
    """)

    statements = []
    for obj_type, name, sql in cursor.fetchall():
        # Ensure each statement ends with a semicolon
        sql = sql.strip()
        if not sql.endswith(";"):
            sql += ";"
        statements.append(sql)

    conn.close()

    return "\n\n".join(statements)

@function_tool
async def save_text_to_file(text:str, filepath:str, encoding:str="utf-8") -> None:
    """
    Save the given text to a file.

    :param text: The text content to write.
    :param filepath: Path to the file to write.
    :param encoding: Text encoding (default: 'utf-8').
    """
    with open(filepath, "w", encoding=encoding) as f:
        f.write(text)


core_agent = Agent(
    name=AGENT_NAME,
    instructions=f"""
    You are an expert in logic programming in SWI-Prolog. Generate prolog programs with facts and 
    foundational rules based on the database schema and task specific rules from the user prompt.
    Use the Prolog template 'facts_tools_rules_actions.pl'. Do not place string in multiple lines.
    Get the Task ID from the user prompt and save the program to a file with path {config['directory']['generated_dir']+'/<Task ID>_logic.pl'}.
    If you fail to get the prolog template or the database schema, stop and output error message.
    """,
    tools=[get_db_schema, get_prolog_template, save_text_to_file],
    model = LLM,
)