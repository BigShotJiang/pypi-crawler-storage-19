# ipatool
苹果商店搜索下载历史版本工具

> 参考 [majd/ipatool](https://github.com/majd/ipatool) 项目，使用 Python 重新实现。

## 功能
- Apple ID 认证登录
- 搜索 iOS 应用
- 查看应用历史版本
- 下载指定版本的 IPA 文件
- 通过 Bundle ID 查询应用信息

## 安装
### 通过 pip 安装
```bash
# 从源码安装
pip install -e .

# 从 PyPI 安装
pip install pyipatool
```

## 配置
复制配置文件示例并根据需要修改：
```bash
cp data/config.json.example data/config.json
```

配置文件说明：
- `auth`: Apple ID 认证信息
- `paths`: 存储路径设置
- `urls`: API 接口地址
- `download`: 下载设置
- `http`: HTTP 请求设置

## 用法

### 1. 认证相关命令

#### 登录 Apple ID
```bash
ipatool auth login -e your_email@example.com -p your_password
```

#### 撤销凭证
```bash
ipatool auth revoke
```

#### 查看当前登录信息
```bash
ipatool auth info
```

### 2. 搜索应用
```bash
ipatool search "微信" --limit 10
```

### 3. 列出应用版本
通过 App ID 列出版本：
```bash
ipatool list-versions -i 123456789
```

通过 Bundle ID 列出版本：
```bash
ipatool list-versions -b com.tencent.xin
```

### 4. 下载应用
下载最新版本：
```bash
ipatool download -b com.tencent.xin --output ./downloads
```

下载指定版本：
```bash
ipatool download -b com.tencent.xin --version-id 123456789 --output ./downloads
```

### 5. 查询应用信息
```bash
ipatool lookup -b com.tencent.xin
```

## 更新说明
- **v1.0.0** (2026-01-07): 为 lookup、search、listversion、download 命令添加对于 5002 错误的重试机制