"""
Tests for llcuda package.
"""
