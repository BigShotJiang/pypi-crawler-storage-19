# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateUpdateSecretRespSecret:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'description': 'str',
        'project_id': 'str',
        'created_at': 'str',
        'updated_at': 'str',
        'secrets': 'list[Secret]',
        'tags': 'list[Tag]'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'description': 'description',
        'project_id': 'project_id',
        'created_at': 'created_at',
        'updated_at': 'updated_at',
        'secrets': 'secrets',
        'tags': 'tags'
    }

    def __init__(self, id=None, name=None, description=None, project_id=None, created_at=None, updated_at=None, secrets=None, tags=None):
        r"""CreateUpdateSecretRespSecret

        The model defined in huaweicloud sdk

        :param id: 密钥ID
        :type id: str
        :param name: 密钥名称
        :type name: str
        :param description: 密钥描述
        :type description: str
        :param project_id: 项目ID
        :type project_id: str
        :param created_at: 密钥创建时间
        :type created_at: str
        :param updated_at: 密钥更新时间
        :type updated_at: str
        :param secrets: 密钥列表
        :type secrets: list[:class:`huaweicloudsdkhilens.v3.Secret`]
        :param tags: 标签列表
        :type tags: list[:class:`huaweicloudsdkhilens.v3.Tag`]
        """
        
        

        self._id = None
        self._name = None
        self._description = None
        self._project_id = None
        self._created_at = None
        self._updated_at = None
        self._secrets = None
        self._tags = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if description is not None:
            self.description = description
        if project_id is not None:
            self.project_id = project_id
        if created_at is not None:
            self.created_at = created_at
        if updated_at is not None:
            self.updated_at = updated_at
        if secrets is not None:
            self.secrets = secrets
        if tags is not None:
            self.tags = tags

    @property
    def id(self):
        r"""Gets the id of this CreateUpdateSecretRespSecret.

        密钥ID

        :return: The id of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CreateUpdateSecretRespSecret.

        密钥ID

        :param id: The id of this CreateUpdateSecretRespSecret.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this CreateUpdateSecretRespSecret.

        密钥名称

        :return: The name of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateUpdateSecretRespSecret.

        密钥名称

        :param name: The name of this CreateUpdateSecretRespSecret.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this CreateUpdateSecretRespSecret.

        密钥描述

        :return: The description of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this CreateUpdateSecretRespSecret.

        密钥描述

        :param description: The description of this CreateUpdateSecretRespSecret.
        :type description: str
        """
        self._description = description

    @property
    def project_id(self):
        r"""Gets the project_id of this CreateUpdateSecretRespSecret.

        项目ID

        :return: The project_id of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._project_id

    @project_id.setter
    def project_id(self, project_id):
        r"""Sets the project_id of this CreateUpdateSecretRespSecret.

        项目ID

        :param project_id: The project_id of this CreateUpdateSecretRespSecret.
        :type project_id: str
        """
        self._project_id = project_id

    @property
    def created_at(self):
        r"""Gets the created_at of this CreateUpdateSecretRespSecret.

        密钥创建时间

        :return: The created_at of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._created_at

    @created_at.setter
    def created_at(self, created_at):
        r"""Sets the created_at of this CreateUpdateSecretRespSecret.

        密钥创建时间

        :param created_at: The created_at of this CreateUpdateSecretRespSecret.
        :type created_at: str
        """
        self._created_at = created_at

    @property
    def updated_at(self):
        r"""Gets the updated_at of this CreateUpdateSecretRespSecret.

        密钥更新时间

        :return: The updated_at of this CreateUpdateSecretRespSecret.
        :rtype: str
        """
        return self._updated_at

    @updated_at.setter
    def updated_at(self, updated_at):
        r"""Sets the updated_at of this CreateUpdateSecretRespSecret.

        密钥更新时间

        :param updated_at: The updated_at of this CreateUpdateSecretRespSecret.
        :type updated_at: str
        """
        self._updated_at = updated_at

    @property
    def secrets(self):
        r"""Gets the secrets of this CreateUpdateSecretRespSecret.

        密钥列表

        :return: The secrets of this CreateUpdateSecretRespSecret.
        :rtype: list[:class:`huaweicloudsdkhilens.v3.Secret`]
        """
        return self._secrets

    @secrets.setter
    def secrets(self, secrets):
        r"""Sets the secrets of this CreateUpdateSecretRespSecret.

        密钥列表

        :param secrets: The secrets of this CreateUpdateSecretRespSecret.
        :type secrets: list[:class:`huaweicloudsdkhilens.v3.Secret`]
        """
        self._secrets = secrets

    @property
    def tags(self):
        r"""Gets the tags of this CreateUpdateSecretRespSecret.

        标签列表

        :return: The tags of this CreateUpdateSecretRespSecret.
        :rtype: list[:class:`huaweicloudsdkhilens.v3.Tag`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this CreateUpdateSecretRespSecret.

        标签列表

        :param tags: The tags of this CreateUpdateSecretRespSecret.
        :type tags: list[:class:`huaweicloudsdkhilens.v3.Tag`]
        """
        self._tags = tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateUpdateSecretRespSecret):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
