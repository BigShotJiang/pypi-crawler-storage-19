# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class ListIngressesRequest(DaraModel):
    def __init__(
        self,
        app_id: str = None,
        current_page: int = None,
        namespace_id: str = None,
        page_size: int = None,
    ):
        # The ID of an application.
        self.app_id = app_id
        self.current_page = current_page
        # The ID of a namespace.
        # 
        # This parameter is required.
        self.namespace_id = namespace_id
        self.page_size = page_size

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.app_id is not None:
            result['AppId'] = self.app_id

        if self.current_page is not None:
            result['CurrentPage'] = self.current_page

        if self.namespace_id is not None:
            result['NamespaceId'] = self.namespace_id

        if self.page_size is not None:
            result['PageSize'] = self.page_size

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AppId') is not None:
            self.app_id = m.get('AppId')

        if m.get('CurrentPage') is not None:
            self.current_page = m.get('CurrentPage')

        if m.get('NamespaceId') is not None:
            self.namespace_id = m.get('NamespaceId')

        if m.get('PageSize') is not None:
            self.page_size = m.get('PageSize')

        return self

