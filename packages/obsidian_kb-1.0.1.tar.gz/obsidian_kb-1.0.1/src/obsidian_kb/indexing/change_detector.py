"""Детектор изменений в документах для инкрементальной индексации."""

import asyncio
import hashlib
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from obsidian_kb.storage.document_repository import DocumentRepository

logger = logging.getLogger(__name__)


@dataclass
class ChangeSet:
    """Набор изменений в vault'е."""
    
    new_files: list[Path]  # Новые файлы
    modified_files: list[Path]  # Изменённые файлы
    deleted_files: list[str]  # Удалённые файлы (file_path как строка)
    
    def __len__(self) -> int:
        """Общее количество изменений."""
        return len(self.new_files) + len(self.modified_files) + len(self.deleted_files)
    
    def is_empty(self) -> bool:
        """Проверка, есть ли изменения."""
        return len(self) == 0


class ChangeDetector:
    """Детектор изменений в документах.
    
    Определяет новые, изменённые и удалённые файлы путём сравнения
    хешей содержимого с сохранёнными в базе данных.
    """
    
    def __init__(
        self,
        document_repository: "DocumentRepository | None" = None,
    ) -> None:
        """Инициализация детектора изменений.
        
        Args:
            document_repository: Репозиторий документов для получения хешей
        """
        self._document_repository = document_repository
    
    async def detect_changes(
        self,
        vault_path: Path,
        vault_name: str,
        indexed_files: dict[str, str] | None = None,
    ) -> ChangeSet:
        """Определяет изменения в vault'е.
        
        Args:
            vault_path: Путь к vault'у
            vault_name: Имя vault'а
            indexed_files: Словарь {file_path: content_hash} уже проиндексированных файлов.
                          Если None, загружается из репозитория.
        
        Returns:
            ChangeSet с обнаруженными изменениями
        """
        vault_path = Path(vault_path).resolve()
        
        if not vault_path.exists():
            logger.warning(f"Vault path does not exist: {vault_path}")
            return ChangeSet(new_files=[], modified_files=[], deleted_files=[])
        
        # Загружаем индексированные файлы, если не предоставлены
        if indexed_files is None:
            indexed_files = await self._load_indexed_files(vault_name)
        
        # Сканируем файлы в vault'е
        current_files = self._scan_vault_files(vault_path)
        
        # Определяем изменения
        new_files = []
        modified_files = []
        deleted_files = []
        
        # Создаём словарь текущих файлов с хешами
        current_files_with_hashes: dict[str, tuple[Path, str]] = {}
        
        for file_path in current_files:
            try:
                content_hash = self._compute_file_hash(file_path)
                relative_path = str(file_path.relative_to(vault_path))
                current_files_with_hashes[relative_path] = (file_path, content_hash)
            except Exception as e:
                logger.warning(f"Failed to compute hash for {file_path}: {e}")
                continue
        
        # Определяем новые и изменённые файлы
        for relative_path, (file_path, content_hash) in current_files_with_hashes.items():
            if relative_path not in indexed_files:
                # Новый файл
                new_files.append(file_path)
            elif indexed_files[relative_path] != content_hash:
                # Изменённый файл
                modified_files.append(file_path)
        
        # Определяем удалённые файлы
        for relative_path in indexed_files:
            if relative_path not in current_files_with_hashes:
                deleted_files.append(relative_path)
        
        logger.info(
            f"Change detection for vault '{vault_name}': "
            f"{len(new_files)} new, {len(modified_files)} modified, {len(deleted_files)} deleted"
        )
        
        return ChangeSet(
            new_files=new_files,
            modified_files=modified_files,
            deleted_files=deleted_files,
        )
    
    async def _load_indexed_files(self, vault_name: str) -> dict[str, str]:
        """Загрузка индексированных файлов из репозитория.
        
        Args:
            vault_name: Имя vault'а
            
        Returns:
            Словарь {file_path: content_hash}
        """
        if not self._document_repository:
            logger.warning("DocumentRepository not provided, cannot load indexed files")
            return {}
        
        try:
            # Получаем все document_ids из vault'а
            document_ids = await self._document_repository.get_all_document_ids(vault_name)
            
            if not document_ids:
                return {}
            
            # Получаем content_hash напрямую из таблицы documents
            db_manager = self._document_repository._db_manager
            documents_table = await db_manager._ensure_table(vault_name, "documents")
            
            def _load_hashes() -> dict[str, str]:
                try:
                    arrow_table = documents_table.to_arrow()
                    if arrow_table.num_rows == 0:
                        return {}
                    
                    # Получаем file_path и content_hash
                    file_paths = arrow_table["file_path"].to_pylist()
                    content_hashes = arrow_table["content_hash"].to_pylist() if "content_hash" in arrow_table.column_names else [""] * len(file_paths)
                    
                    # Создаём словарь {file_path: content_hash}
                    indexed_files = {}
                    for file_path, content_hash in zip(file_paths, content_hashes):
                        if file_path:
                            indexed_files[file_path] = content_hash or ""
                    
                    return indexed_files
                except Exception as e:
                    logger.error(f"Error loading indexed files: {e}")
                    return {}
            
            return await asyncio.to_thread(_load_hashes)
        except Exception as e:
            logger.error(f"Failed to load indexed files: {e}")
            return {}
    
    def _scan_vault_files(self, vault_path: Path) -> list[Path]:
        """Сканирование файлов в vault'е.
        
        Args:
            vault_path: Путь к vault'у
            
        Returns:
            Список путей к markdown файлам
        """
        markdown_files = []
        
        # Рекурсивно сканируем директорию
        for file_path in vault_path.rglob("*.md"):
            # Пропускаем скрытые файлы и директории
            if any(part.startswith(".") for part in file_path.parts):
                continue
            
            markdown_files.append(file_path)
        
        return markdown_files
    
    def _compute_file_hash(self, file_path: Path) -> str:
        """Вычисление SHA256 хеша содержимого файла.
        
        Args:
            file_path: Путь к файлу
            
        Returns:
            SHA256 хеш в hex формате
        """
        sha256 = hashlib.sha256()
        
        with open(file_path, "rb") as f:
            # Читаем файл блоками для эффективности
            while chunk := f.read(8192):
                sha256.update(chunk)
        
        return sha256.hexdigest()

