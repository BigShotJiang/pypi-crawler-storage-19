"""Indexing Layer - сервисы индексирования данных."""

from obsidian_kb.storage.indexing.indexing_service import IndexingService

__all__ = ["IndexingService"]
