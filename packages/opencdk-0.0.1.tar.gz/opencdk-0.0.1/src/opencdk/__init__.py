"""OpenCDK placeholder."""
