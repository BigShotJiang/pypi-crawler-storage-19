# DevOpsMind package
__version__ = "1.0.4post6"
