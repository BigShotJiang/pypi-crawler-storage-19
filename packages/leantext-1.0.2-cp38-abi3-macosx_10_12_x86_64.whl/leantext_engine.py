from typing import List, Dict, Any, Optional, Tuple
import leantext, json

class LeanTextEngine:
    """
    A high-level Python wrapper for the LeanText search engine.
    Handles automatic JSON serialization for metadata and filters.
    """
    
    def __init__(self, storage_path: str):
        """
        Initializes or loads the LeanText database at the given path.
        """
        self._db = leantext.LeanText(storage_path)

    def add(self, doc_id: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Adds a document to the index.
        
        :param doc_id: A unique string identifier for the document.
        :param content: The text body to be indexed.
        :param metadata: A dictionary of attributes for filtering (strings, bools, or numbers).
        """
        meta_json = json.dumps(metadata) if metadata is not None else None
        self._db.add(doc_id, content, meta_json)

    def search(
        self, 
        query: str = "", 
        filter: Optional[Dict[str, Any]] = None, 
        limit: int = 10, 
        fuzzy_dist: int = 0, 
        title_boost: float = 1.0, 
        body_boost: float = 1.0
    ) -> List[Tuple[str, float]]:
        """
        Searches the index and returns a list of (doc_id, score) tuples.
        
        :param query: The search terms.
        :param filter: A MongoDB-style filter dictionary (e.g., {"price": {"$gt": 10}}).
        :param limit: Maximum number of results to return.
        :param fuzzy_dist: Max Levenshtein distance for fuzzy matching (0 for exact).
        :param title_boost: Multiplier for matches found in the ID/Title.
        :param body_boost: Multiplier for matches found in the document body.
        """
        filter_json = json.dumps(filter) if filter is not None else None
        return self._db.search(
            query, 
            filter_json, 
            limit, 
            fuzzy_dist, 
            title_boost, 
            body_boost
        )

    def get_content(self, doc_id: str) -> Optional[str]:
        """Retrieves the original text content of a document by its ID."""
        return self._db.get_content(doc_id)

    def delete(self, doc_id: str) -> None:
        """Marks a document as deleted."""
        self._db.delete(doc_id)
    
    def delete_by_metadata(self, metadata: Dict[str, Any]) -> None:
        """Deletes all documents with the given metadata."""
        if not metadata:
            return
        self._db.delete_by_filter(json.dumps(metadata))

    def persist(self) -> None:
        """Flushes the Write-Ahead Log and creates a fresh snapshot on disk."""
        self._db.persist()

    def vacuum(self) -> None:
        """
        Physically removes deleted documents from disk and defragments the index.
        Note: This can be an expensive operation on large databases.
        """
        self._db.vacuum()

    def count(self) -> int:
        """Returns the total number of active documents in the index."""
        return self._db.count()

    def __len__(self) -> int:
        return self.count()
