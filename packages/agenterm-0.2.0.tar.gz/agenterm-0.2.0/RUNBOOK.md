# Trace Correlation Runbook

## Goal

Trace a user-visible issue to a `trace_id`, then locate the associated sessions,
runs, and artifacts in the local store.

## Preconditions

- Tracing is enabled (`run.trace_enabled: true` or `--trace on`).
- To correlate local store rows, set a `trace_id` explicitly (`--trace <id>` or
  `run.trace_id`). If it is unset, local `trace_id` columns remain null.
- Trace export uses the Agents SDK exporter and requires `OPENAI_API_KEY`; when
  it is missing, trace upload is skipped.

## Capture the trace_id

Choose one of the following sources:

1. **CLI JSON envelope**
   - Use JSON output to surface `trace_id` deterministically:
     ```bash
    uv run agenterm run --format json --trace TRACE_ID "..."
     ```
   - Read `trace_id` from the JSON envelope.

2. **CLI trace lookup**
   - Run:
     ```bash
    uv run agenterm trace show
     ```
   - Read `trace_id` from the output (or use `--format json`). This reflects
     config state only (not auto-generated trace ids).

3. **REPL**
   - Run `/trace show` and copy the `trace_id`.

4. **Session metadata**
   - Run:
     ```bash
    uv run agenterm session show SESSION_ID
     ```
   - Read `Trace ID` from the output.

## Locate sessions and runs

1. Identify the session:
   ```bash
  uv run agenterm session list
   ```

2. Inspect the session:
   ```bash
  uv run agenterm session show SESSION_ID
   ```

3. Review runs (status + tools + tokens):
   ```bash
  uv run agenterm session runs SESSION_ID
   ```

4. For direct trace_id lookups, query the local store (read-only):
   ```bash
  sqlite3 ~/.agenterm/store.sqlite3 \
    "select session_id, trace_id, group_id, model, updated_at from agenterm_sessions where trace_id = 'TRACE_ID';"

  sqlite3 ~/.agenterm/store.sqlite3 \
    "select run_id, session_id, branch_id, run_number, status, response_id, updated_at from agenterm_runs where trace_id = 'TRACE_ID';"
   ```

## Locate artifacts

1. CLI list/show:
   ```bash
  uv run agenterm artifacts list
  uv run agenterm artifacts list --session-id SESSION_ID
  uv run agenterm artifacts list --trace-id TRACE_ID
  uv run agenterm artifacts show ARTIFACT_ID
   ```

2. Query by session_id:
   ```bash
  sqlite3 ~/.agenterm/store.sqlite3 \
    "select artifact_id, path, kind, mime, size_bytes, created_at, source_type, source_id from agenterm_artifacts where session_id = 'SESSION_ID';"
   ```

3. Artifact files live under:
   ```
  ~/.agenterm/artifacts/
   ```

## Background responses

If you have a `response_id` from a background run:

```bash
uv run agenterm inspect response RESPONSE_ID
```

## Gateway assumptions (LiteLLM in-process)

- `gateway/<route>/<model>` ids resolve via `providers.gateway.routes`.
- Missing or unset `api_key_env` values fail fast; check the environment for the
  route key.
- Trace export still targets the OpenAI traces endpoint; set `OPENAI_API_KEY`
  even when running non-OpenAI models if you want uploads.

## Notes

- For human output, use `agenterm trace show` (or REPL `/trace show`) when you need
  the configured trace id; most other CLI commands omit it unless
  `--format json` is used.
- Treat the SQLite store as read-only for diagnostics.
