# PLAN.md

Tracks remaining work items. Completed items are deleted; only outstanding work appears here.

## 1. Outstanding Work

- Refine `.local/lifecycle.md` lifecycle spec and drive the next initiative to align runtime and ARCH contracts.
- Use `.local/tool_report.md` as the source for the next tool UX/contract hardening initiatives.

## 2. Future Enhancements

Reserved for user-approved feature work. Items are added only after explicit approval in VISION.md.
