## 1. agenterm Specification

### 1.1 Table of Contents

1. agenterm Specification
    1.1 Table of Contents
    1.2 Introduction & Scope
    1.3 External Dependencies & Contracts
    1.4 Architecture Overview
    1.5 Layers
     1.5.1 Edge Layer (CLI / REPL)
     1.5.2 Workflows & Services Layer
     1.5.3 Engine Layer
     1.5.4 External SDKs & Providers
    1.6 Configuration Model
     1.6.1 AppConfig Overview
     1.6.2 AgentConfig
     1.6.3 ModelConfig & ModelSettings Mapping
     1.6.4 Fixed Response Includes
	    1.6.5 ToolsConfig
    1.6.6 McpConfig
    1.6.7 RetriesConfig
    1.6.8 StewardConfig
    1.6.9 RunDefaults & GuardrailsConfig
    1.6.10 Config Loading & Overrides
    1.6.11 Canonical Choice Sets (`core.choices`)
    1.6.12 Config Template Generation
    1.6.13 ProvidersConfig (OpenAI + Gateway)
    1.6.14 Canonical JSON Validation & Response Item Serialization
	    1.7 Tools, MCP, Guardrails & Tracing
		     1.7.1 Tool Taxonomy
		     1.7.2 Tool Selection, Bundles & Gates
		     1.7.3 Shell Sandbox (macOS Seatbelt)
	     1.7.4 Apply Patch Editor (Workspace-scoped)
	     1.7.5 MCP Server Construction & MCP CLI
	     1.7.6 Guardrails Integration
	     1.7.7 Tracing
	     1.7.8 Local Tool Contracts
	     1.7.8.1 Tool Description Contract
    1.8 Sessions & Persistence
     1.8.1 Agents Session & SQLite Store
     1.8.2 Run Status Ledger (`agenterm_runs`)
     1.8.3 `agenterm_sessions` Metadata Table
     1.8.4 Session Store (`store.session.*`)
     1.8.5 Session Lifecycle & Branching
    1.8.6 Instruction Forks (agenterm‑owned)
    1.8.7 Per‑Request Token Ledger (agenterm‑owned)
    1.8.8 Artifacts Vault (agenterm‑owned)
    1.8.9 Run Event Ledger (agenterm‑owned)
    1.8.10 Turn Attempt Ledger (agenterm‑owned)
    1.8.11 History Packing & Summaries (agenterm‑owned)
    1.8.12 Agent Run Lifecycle Specification (`.local/lifecycle.md`)
    1.9 Execution Model & Store Semantics
     1.9.1 RunConfig Construction
     1.9.2 Execution Modes: `run_streamed` vs `run_once`
     1.9.3 Store Flag & Response IDs (no remote continuity)
    1.10 SessionState, REPL & CLI Workflows
     1.10.1 SessionState Structure
     1.10.2 Slash Commands & Command Router
     1.10.3 REPL Runner Lifecycle
     1.10.4 Sessions CLI
     1.10.5 Output Layout & Presentation Modes
     1.10.6 REPL Keybindings & Prompt UX
     1.10.7 Representative Session Lifecycles
     1.10.8 CLI Run Flow
     1.10.9 Canonical Run Execution (`workflow.run`)
     1.10.10 CLI Output Contract (Human + JSON)
    1.11 Approvals & Tool Safety
     1.11.1 Approvals Queue
     1.11.2 REPL Approval Flow
     1.11.3 CLI `run` Approval Flow
    1.12 Error Handling & Observability
     1.12.1 Error Taxonomy & Exit Codes
     1.12.2 Usage Accounting
     1.12.3 Local Validation & Gate
    1.13 Alignment with Vision & Plan
    1.14 Glossary
2. Issue Register & Notes
    2.1 Conflicts (C‑xxx)
    2.2 Ambiguities / Missing Information (A‑xxx)

------

### 1.2 Introduction & Scope

- This document specifies the **target architecture** of **agenterm**, a greenfield agentic coding command‑line interface.
- It describes the desired end‑state technical shape, not necessarily the current implementation.
- The architecture is layered:
  - Edge (CLI / REPL)
  - Workflows & Services (application layer)
  - Engine (adapters on top of the Agents SDK)
  - External SDKs and providers (Agents, OpenAI client, MCP SDK, SQLite)
- agenterm is a thin but structured layer on top of the Agents SDK, OpenAI Responses API, MCP SDK, and SQLite‑backed session storage.

### 1.3 External Dependencies & Contracts

agenterm's behavior is constrained by specific versions of external libraries and their public contracts:

- **Agents SDK (`openai-agents`) 0.6.4**
  - Pinned by `uv.lock:1153-1168` (source of truth for the repo).
  - `agents.model_settings.ModelSettings`
    - Defines model configuration surface (sampling parameters, store flag, prompt caching, `response_include`, etc.).
  - `agents.result.RunResultStreaming`
    - Streaming result handle with:
      - `stream_events()`
      - `cancel(mode)`
  - `agents.agent.Agent` and built‑in tool classes:
    - `FileSearchTool`
    - `WebSearchTool`
    - `ImageGenerationTool`
    - `ShellTool`
    - `ApplyPatchTool`
    - `HostedMCPTool`
  - MCP server types:
    - `MCPServerStdio`
    - `MCPServerSse`
    - `MCPServerStreamableHttp`
  - Sessions:
    - `agents.extensions.memory.AdvancedSQLiteSession`
      - SQLite‑backed conversation transcripts and usage tables.
- **OpenAI client (`openai`) 2.14.0**
  - Pinned by `uv.lock:1134-1150`.
  - Provides the Responses API input/output shapes and `include` semantics that the Agents SDK builds on.
- **MCP (`mcp`) 1.25.0**
  - Pinned by `uv.lock:985-1007`.
  - Defines connector/client types used by the MCP server factories.
- **Typer (`typer`) 0.21.0**
  - Pinned by `uv.lock:1892-1904`.
  - CLI framework; `Typer` is the app container and defaults to auto-completions plus rich/pretty exception handling unless disabled. `.venv:lib/python3.14/site-packages/typer/main.py:58-173`
- **CLI tool dependencies (local binaries)**
  - `ripgrep` 14.1.1 — `rg` tool ordering (`--sort=path`) and count mode semantics (`--count-matches`, `-H`). `vendor:ripgrep:14.1.1:rg --help`
  - `fd` 10.3.0 — depth control (`--max-depth`). `vendor:fd:10.3.0:fd --help`
  - `tree` 2.2.1 — pattern glob (`-P`), directory matching (`--matchdirs`), and report suppression (`--noreport`). `vendor:tree:2.2.1:tree --help`
- **Runtime citations (.venv)**
  - `.venv:lib/python3.14/site-packages/typer/__init__.py:1-33` — Typer version + public exports and Click re-exports.
  - `.venv:lib/python3.14/site-packages/typer/main.py:58-173` — Typer exception hook (env-controlled) and `Typer` defaults (`add_completion`, `suggest_commands`, pretty exception settings).
  - `.venv:lib/python3.14/site-packages/agents/tracing/processors.py:157-209` — Agents uses a queue + background worker + batching knobs to decouple exports from foreground execution.
  - `.venv/lib/python3.14/site-packages/agents/result.py:40-220` — `RunResultBase`/`RunResult`/`RunResultStreaming` structure.
  - `.venv/lib/python3.14/site-packages/agents/run.py:321-345` — Runner loop definition and `turn` semantics (one AI invocation).
  - `.venv/lib/python3.14/site-packages/agents/result.py:254-278` — `RunResultStreaming.cancel` semantics + requirement to keep consuming `stream_events()` after cancel.
  - `.venv/lib/python3.14/site-packages/agents/result.py:254-347` — `RunResultStreaming.cancel` + `stream_events()` await the internal queue without a built-in idle timeout.
  - `.venv/lib/python3.14/site-packages/agents/stream_events.py:12-62` — streaming event taxonomy consumed by the CLI.
  - `.venv/lib/python3.14/site-packages/agents/stream_events.py:12-27` — `RawResponsesStreamEvent` carries only `data` (no raw provider payload).
  - `.venv/lib/python3.14/site-packages/agents/run.py:1447-1454` — raw Responses stream events are enqueued as `RawResponsesStreamEvent`.
  - `.venv/lib/python3.14/site-packages/agents/agent.py:114-121` — MCP server lifecycle contract (`connect()` before attach; `cleanup()` after).
  - `.venv/lib/python3.14/site-packages/agents/agent.py:133-163` — agent `instructions` become the system prompt and accept `str | callable | None`.
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:46-65` — MCP servers remain connected until `cleanup()`.
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:243-249` — MCP servers implement async context manager (`__aenter__`/`__aexit__`).
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:293-301` — `list_tools()` hard-requires `connect()`.
  - `.venv/lib/python3.14/site-packages/agents/mcp/util.py:154-179` — MCP tool → FunctionTool conversion uses MCP `inputSchema`.
  - `.venv/lib/python3.14/site-packages/agents/mcp/util.py:213-216` — MCP tool invocation prefers `structuredContent` when `use_structured_content` is true.
  - `.venv/lib/python3.14/site-packages/mcp/server/fastmcp/server.py:78-143` — FastMCP settings and lifespan async context manager contract.
  - `.venv/lib/python3.14/site-packages/mcp/server/fastmcp/server.py:343-346` — FastMCP `call_tool` returns `Sequence[ContentBlock] | dict[str, Any]` and delegates to the tool manager.
  - `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:460-466` — lowlevel server error results use `CallToolResult(..., isError=True)` with a text content payload.
  - `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:485-560` — lowlevel `call_tool` validates inputs against `tool.inputSchema` when `validate_input=True`.
  - `.venv/lib/python3.14/site-packages/agents/run.py:600-603` — Runner enumerates `agent.get_all_tools()` each turn.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1953-1991` — Session input callback merges history + new input and is required for list inputs when session memory is enabled.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016` — Each completed turn is persisted as `input_list + new_items_as_input` via `session.add_items` (original input, not callback output).
  - `.venv/lib/python3.14/site-packages/agents/run.py:183-193` — Agents `RunConfig` defaults `model_provider` to `MultiProvider`.
  - `.venv/lib/python3.14/site-packages/agents/items.py:134-142` — `RunItemBase.to_input_item` converts output items into input items via `model_dump`.
  - `.venv/lib/python3.14/site-packages/agents/model_settings.py:99-100` — `ModelSettings.max_tokens` is the maximum output token budget.
  - `.venv/lib/python3.14/site-packages/agents/model_settings.py:58-105` — `ModelSettings.reasoning` is optional and intended for reasoning models.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_responses.py:318-342` — OpenAI Responses calls include `reasoning` when provided.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_chatcompletions.py:301-326` — Chat Completions calls include `reasoning_effort` when configured.
  - `.venv/lib/python3.14/site-packages/agents/models/default_models.py:13-57` — GPT-5 defaults supply reasoning settings; non-GPT-5 defaults use generic settings.
  - `.venv/lib/python3.14/site-packages/agents/agent.py:319-338` — Agents reset model settings when default GPT-5 settings are incompatible.
  - `.venv/lib/python3.14/site-packages/agents/models/multi_provider.py:54-117` — `MultiProvider` routes by model prefix with default `openai/` and `litellm/` mappings and a LitellmProvider fallback.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:281-295` — ChatCompletions conversion accepts `input_image` only when `image_url` is supplied.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:322-333` — ChatCompletions conversion accepts `input_file` only when `file_data` is supplied.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:57-77` — ChatCompletions rejects `MCPToolChoice`; tool choice must be a function tool or built-in enum.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_provider.py:9-19` — `LitellmProvider` expects provider configuration via LiteLLM environment variables.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:71-79` — `LitellmModel` accepts `base_url` and `api_key` overrides.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:179-183` — LiteLLM responses omit `response_id`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:374-377` — LiteLLM streaming sets `stream_options.include_usage` when configured.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:559-560` — LiteLLM merges default headers with `extra_headers` and overrides.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:393-437` — `LitellmModel` calls `litellm.acompletion(...)` and adapts results into Responses-shaped data.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:56-63` — LiteLLM messages carry `reasoning_content` and `thinking_blocks` fields.
  - `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:563-617` — LiteLLM converts provider thinking blocks into internal message fields for downstream conversion.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:96-130` — ChatCompletions conversion maps reasoning content + thinking blocks into `ResponseReasoningItem` with `encrypted_content` signatures.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:557-583` — ChatCompletions conversion reconstructs thinking blocks from reasoning item content + encrypted signatures when preserving tool-call semantics.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:593-608` — ChatCompletions tool conversion accepts `FunctionTool` only and rejects hosted tool types.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_responses.py:367-417` — Responses tool choice mapping supports `MCPToolChoice` via `type="mcp"` with `server_label` and `name`.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_chatcompletions.py:137-140` — ChatCompletions model responses omit `response_id`.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_helpers.py:30-49` — ChatCompletions derives `store` and `stream_options.include_usage` defaults for OpenAI.
  - `.venv/lib/python3.14/site-packages/agents/tool.py:485-499` — hosted MCP approvals via `HostedMCPTool.on_approval_request`.
  - `.venv/lib/python3.14/site-packages/agents/tool.py:448-459` — Agents `ShellTool` has fixed `type="shell"` (no “named shell variants”).
  - `.venv/lib/python3.14/site-packages/agents/apply_diff.py:110-136` — `apply_diff` raises `ValueError("Invalid Context ...")` when V4A diff context cannot be matched.
  - `.venv/lib/python3.14/site-packages/agents/_run_impl.py:1825-1853` — apply_patch action catches editor exceptions and emits `apply_patch_call_output` with `status="failed"` and error text.
  - `.venv/lib/python3.14/site-packages/agents/_run_impl.py:348-355` — approval callbacks are executed during the run step.
  - `.venv/lib/python3.14/site-packages/agents/_run_impl.py:1312-1343` — approval callback result becomes `mcp_approval_response`.
  - `.venv/lib/python3.14/site-packages/agents/mcp/util.py:66-79` — `tool_filter` types (static allow/block or callable).
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:148-228` — server tool_filter application.
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:32-45` — `use_structured_content` semantics.
  - `.venv/lib/python3.14/site-packages/agents/mcp/server.py:592-593` — Streamable HTTP `httpx_client_factory` support.
  - `.venv/lib/python3.14/site-packages/agents/mcp/util.py:160-178` — `convert_schemas_to_strict` rewrites MCP input schemas via `ensure_strict_json_schema` and marks `strict_json_schema`.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1439-1458` — streaming usage accumulation into `context_wrapper.usage`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:236-252` — usage persistence uses `result.context_wrapper.usage`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:45-109` — `message_structure` + `turn_usage` tables include `branch_id` and branch turn numbering.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:254-298` — `user_turn_number` vs `branch_turn_number` increment semantics per branch.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:127-180` — `get_items(..., branch_id=...)` reads branch-scoped history ordered by `sequence_number`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:474-540` — message classification + user-message detection uses `role="user"`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:542-606` — `create_branch_from_turn` validates `branch_turn_number`, copies messages before the turn, and switches the current branch.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:631-662` — `switch_to_branch` validates branch existence via `message_structure`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:664-742` — `delete_branch` protects `main`, supports forced current-branch deletion, and deletes `turn_usage` + `message_structure`.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:744-790` — `list_branches` returns branch counts, user turns, and creation timestamps.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:792-874` — `_copy_messages_to_new_branch` copies messages where `branch_turn_number < from_turn_number`, reusing `message_id` values.
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:876-900` — `get_conversation_turns` enumerates user turns using `branch_turn_number`.
  - `.venv/lib/python3.14/site-packages/agents/__init__.py:172-185` — public API key setter `set_default_openai_key`.
  - `.venv/lib/python3.14/site-packages/agents/__init__.py:187-197` — public client setter `set_default_openai_client`.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_provider.py:19-25` — shared HTTP client rationale (connection pooling).
  - `.venv/lib/python3.14/site-packages/agents/models/openai_provider.py:71-81` — provider uses a default OpenAI client or creates one with the shared HTTP client.
  - `.venv/lib/python3.14/site-packages/agents/version.py:1-7` — SDK version is derived via importlib metadata.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response.py:52-200` — Responses output envelope.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_usage.py:21-35` — token usage fields.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:85-90` — `instructions` are not carried over when `previous_response_id` is used.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_compact_params.py:119-124` — compaction calls also do not carry prior `instructions` when `previous_response_id` is supplied.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_compact_params.py:13-133` — compaction params include `model`, `input`, `instructions`, and optional `previous_response_id` (no `store` field).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_item_param.py:504-531` — input item union includes messages, tool calls/outputs, reasoning, compaction, and MCP items.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_image_param.py:11-33` — image inputs accept `file_id` or `image_url` (including data URLs).
  - `.venv/lib/python3.14/site-packages/openai/types/file_purpose.py:1-7` — file upload purposes include `user_data`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_web_search_param.py:1-83` — `web_search_call` action types (`search|open_page|find`) and required fields (`query`/`url`/`pattern`).
  - `.venv/lib/python3.14/site-packages/agents/strict_schema.py:18-120` — strict schema normalization forces `additionalProperties: false` on objects.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_message_item.py:8-32` — input messages allow `role` values `user|system|developer`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_message_param.py:15-33` — output messages are `role="assistant"` items and can be replayed as input items.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_stream_event.py:1-88` — Responses stream event union (type-discriminated event taxonomy).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_item.py:34-52` — image generation output items embed base64 `result` payloads.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_image_gen_call_partial_image_event.py:1-32` — partial image stream events embed base64 `partial_image_b64`.
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:337-432` — Chat Completions conversion maps input messages (`user|system|developer`) and response output messages (`assistant`) into chat messages.
  - `.venv/lib/python3.14/site-packages/agents/models/fake_id.py:1-4` — gateway Responses events may use the `__fake_id__` placeholder response ID.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_shell_tool_call.py:23-46` — shell tool call items are fixed-shape with `type="shell_call"` (no tool-name field).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_shell_tool_call_output.py:1-46` — shell tool call output includes `call_id`, `max_output_length`, and output entries.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_shell_call_output_content.py:1-31` — shell output entries include `stdout`, `stderr`, and `outcome` (`exit`/`timeout`).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_apply_patch_tool_call_output.py:1-36` — apply_patch outputs include `status` and optional `output` text.
  - `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:494-568` — MCP servers normalize tool returns into `content` + `structuredContent` (validates `outputSchema` when present).
  - `.venv/lib/python3.14/site-packages/mcp/types.py:1306-1338` — MCP tool definitions include optional `outputSchema`.
  - `.venv/lib/python3.14/site-packages/mcp/types.py:1123-1143` — MCP `ToolResultContent` carries optional `structuredContent`.
  - `.venv/lib/python3.14/site-packages/openai/resources/responses/input_tokens.py:1-120` — Responses input token counting endpoint (`client.responses.input_tokens.count`).
  - `.venv/lib/python3.14/site-packages/openai/resources/responses/responses.py:1526-1715` — Responses compaction endpoint (`client.responses.compact`).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/compacted_response.py:8-31` — compaction output shape (`response.compaction`).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/compacted_response.py:13-27` — compaction output includes all user messages followed by a compaction item.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_compaction_item_param_param.py:11-19` — compaction items use `type="compaction"`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/input_token_count_params.py:25-103` — input token count requests accept Responses input items plus `previous_response_id` or `conversation` (mutually exclusive).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:43-136` — Responses create supports `input`, `conversation`, and `previous_response_id` (mutually exclusive with `conversation`).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:36-40` — `background` mode parameter for Responses create.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:194-195` — Responses `store` flag for server-side persistence.
  - `.venv/lib/python3.14/site-packages/openai/_exceptions.py:35-130` — OpenAI error taxonomy and payload fields (`APIError.body`/`code`/`param`/`type`, `APIStatusError.status_code`/`request_id`).
  - `.venv/lib/python3.14/site-packages/openai/_base_client.py:692-779` — Retry-After parsing and retryable status codes (408/409/429/5xx).
  - `.venv/lib/python3.14/site-packages/openai/resources/models.py:77-98` — OpenAI `/models` list endpoint for model registry refresh.
  - `.venv/lib/python3.14/site-packages/openai/types/model.py:10-23` — `Model.id` field used to validate model identifiers.
  - `vendor:openai:responses-create:https://platform.openai.com/docs/api-reference/responses/create` — `truncation=auto|disabled` semantics and 400 on oversized input when disabled.
  - `vendor:openai:responses-compact:https://platform.openai.com/docs/api-reference/responses/compact` — compaction endpoint reference (`/responses/compact`).
  - `vendor:openai:responses-input-tokens:https://platform.openai.com/docs/api-reference/responses/input-tokens` — input token counting endpoint (`/responses/input_tokens`).
  - `vendor:openai:background:https://platform.openai.com/docs/guides/background` — background mode stores response data for ~10 minutes and is not ZDR compatible.
  - `vendor:openai:file-inputs:https://platform.openai.com/docs/guides/pdf-files` — `input_file` supports `file_url`, `file_id`, or `file_data` (base64 data URL) and PDF size limits.
  - `vendor:openai:images-vision:https://platform.openai.com/docs/guides/images-vision` — image inputs support URL, base64 data URL, or file ID; size limits and supported formats.
  - `vendor:litellm:json-schema:https://docs.litellm.ai/docs/completion/json_mode` — LiteLLM supports `response_format=json_schema` and exposes model support checks.
  - `vendor:litellm:providers:https://docs.litellm.ai/docs/providers` — LiteLLM provider registry and naming surface.
  - `vendor:litellm:vision:https://docs.litellm.ai/docs/completion/vision` — `supports_vision` model capability check and image URL/base64 input spec.
  - `vendor:litellm:pdf-input:https://docs.litellm.ai/docs/completion/document_understanding` — PDF inputs accept `file_data` or `file_id`; `supports_pdf_input` checks provider support; Mistral requires `file_id`.
  - `vendor:litellm:token-usage:https://docs.litellm.ai/docs/completion/token_usage` — LiteLLM tokenization helpers (`encode`/`decode`) and cost helpers.
  - `vendor:openrouter:api-reference:https://openrouter.ai/docs/api-reference/overview` — OpenRouter OpenAI-compatible base URL and chat completions endpoint.
  - `vendor:openrouter:multimodal:https://openrouter.ai/docs/guides/overview/multimodal/overview` — image/PDF inputs accept URL or base64; OpenRouter parses PDFs for models without native file input.
  - `vendor:openrouter:images:https://openrouter.ai/docs/features/multimodal/images` — image inputs accept URL or base64 in `image_url`.
  - `vendor:ollama:openai-compat:https://docs.ollama.com/api/openai-compatibility` — Ollama OpenAI-compatible endpoints.
  - `vendor:vllm:openai-compat:https://docs.vllm.ai/en/latest/serving/openai_compatible_server.html` — vLLM OpenAI-compatible server base URL.
  - `vendor:ripgrep:14.1.1:https://github.com/BurntSushi/ripgrep` — rg JSON output (`--json`) and search flag surface.
  - `vendor:fd:10.3.0:https://github.com/sharkdp/fd` — fd file discovery flags (`--glob`, `--type`, `--max-results`, `--hidden`).
  - `vendor:bat:0.26.1:https://github.com/sharkdp/bat` — bat line-range and numbering flags (`--line-range`, `--number`).
  - `vendor:tree:2.2.1:https://github.com/Old-Man-Programmer/tree` — tree CLI flags (`-L`, `-a`, `-d`, `-P`, `--gitignore`, `--charset`, `-n`).
  - `vendor:stat:bsd:https://man.freebsd.org/cgi/man.cgi?stat` — BSD stat format (`-f` with `%HT/%z/%m/%p`).
  - `vendor:stat:gnu:https://man7.org/linux/man-pages/man1/stat.1.html` — GNU stat format (`--printf` with `%F/%s/%Y/%a`).
  - `.venv/lib/python3.14/site-packages/aiosqlite/core.py:150-214` — async connection/context manager behavior.
  - `.venv/lib/python3.14/site-packages/aiosqlite/core.py:443-467` — `aiosqlite.connect` uses sqlite3 under the hood.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response.py:115-120` — Responses temperature range (0–2).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:247-250` — `top_logprobs` range (0–20).
  - `.venv/lib/python3.14/site-packages/openai/types/chat/completion_create_params.py:64-69` — `frequency_penalty` range (-2.0–2.0).
  - `.venv/lib/python3.14/site-packages/openai/types/chat/completion_create_params.py:174-179` — `presence_penalty` range (-2.0–2.0).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/file_search_tool_param.py:64-68` — file search `max_num_results` range (1–50).
  - `.venv/lib/python3.14/site-packages/openai/types/image_generate_params.py:53-72` — image generation `output_compression` (0–100) and `partial_images` (0–3).
  - `.venv/lib/python3.14/site-packages/agents/exceptions.py:36-75` — Agents exception taxonomy (AgentsException, MaxTurnsExceeded, UserError).
  - `.venv/lib/python3.14/site-packages/mcp/shared/exceptions.py:8-18` — MCP error wrapper (`McpError` carries `ErrorData`).
  - `.venv/lib/python3.14/site-packages/agenterm-0.1.0.dist-info/METADATA:723-748` — tool selection is structural; default bundles apply unless CLI overrides (`--tools-bundle`/`--tool`) are provided.
  - `.venv/lib/python3.14/site-packages/typer/params.py:40-74` — Typer options support `rich_help_panel` grouping.
  - `.venv/lib/python3.14/site-packages/typer/__init__.py:5-39` — Typer re-exports Click’s `Exit`/`BadParameter` used for edge exits and validations.
  - `.venv/lib/python3.14/site-packages/typer/main.py:540-556` — Typer treats `click.Context` callback params specially (not CLI options).
  - `.venv/lib/python3.14/site-packages/click/core.py:169-190` — Click `Context.obj` is the canonical place for arbitrary user data/state.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:105-139` — prompt_toolkit `Application` is the full-screen UI entrypoint.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/controls.py:63-165` — `UIControl`/`UIContent` shape for custom transcript controls.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:234-520` — `HSplit`/`VSplit` for stable vertical/horizontal layouts.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:735-1097` — `FloatContainer`/`Float` for modal overlays.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:1385-1659` — `Window` sizing and `dont_extend_height` behavior for transcript/composer/status regions.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:2596-2624` — `ConditionalContainer` for toggled panels.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/margins.py:161-199` — `ScrollbarMargin` for scrollable transcript window.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/menus.py:261-289` — `CompletionsMenu` uses a scrollable window + scrollbar margin.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/renderer.py:342-625` — `mouse_support` toggles enable/disable terminal mouse reporting.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:2008-2015` — `[ZeroWidthEscape]` fragments are recorded as `zero_width_escapes` at the current cell column without emitting a visible character.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/renderer.py:195-223` — `zero_width_escapes` are written only when a cell at that column is drawn during screen diff rendering.
  - `vendor:iterm2:imgcat:https://iterm2.com/utilities/imgcat` — `imgcat` prints a single newline after emitting an inline image escape; it does not emit extra blank rows.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/input/base.py:109-139` — `DummyInput` for headless TUI tests.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/output/base.py:223-259` — `DummyOutput` for headless TUI tests.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/completion/base.py:26-66` — Completion insertion uses `start_position` relative to cursor (`<= 0`).
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/enums.py:6-9` — `EditingMode` enum defines `VI` and `EMACS`.
  - `.venv/lib/python3.14/site-packages/prompt_toolkit/widgets/base.py:8-13` — widgets are explicitly unstable; avoid.
  - `.venv/lib/python3.14/site-packages/ruamel/yaml/main.py:437-468` — `YAML.load(stream)` accepts `Path | StreamTextType` and returns `Any`, requiring caller-side validation; `YAML(typ="safe")` uses `SafeConstructor` for untrusted inputs.
  - `.venv/lib/python3.14/site-packages/ruamel/yaml/main.py:820-874` — `YAML.indent` property setter stores the provided value on `old_indent` for later use by emitters; `block_seq_indent` is likewise exposed as a property.
  - `.venv/lib/python3.14/site-packages/ruamel/yaml/comments.py:308-323` — `yaml_set_start_comment` emits multi-line, pre-document comments without requiring `#` prefixes.
  - `.venv/lib/python3.14/site-packages/ruamel/yaml/comments.py:300-356` — `yaml_set_comment_before_after_key` accepts multi-line comments (without `#`) for map keys, enabling programmatic template commentary.
  - `.venv/lib/python3.14/site-packages/ruamel/yaml/comments.py:360-405` — `yaml_add_eol_comment` supports inline key/value comments with column control.
  - `.venv/lib/python3.14/site-packages/openai/_models.py:163-188` — OpenAI `BaseModel.to_json` returns a JSON string for model payloads (used to serialize `Reasoning` configs before parsing).
  - `.venv/lib/python3.14/site-packages/openai/types/shared/comparison_filter.py:1-34` — `ComparisonFilter` model expects `key: str`, `type: Literal["eq","ne","gt","gte","lt","lte"]`, and `value: str | float | bool | list[str | float]`.

External citations (official docs):

- `vendor:openai:responses-api:https://platform.openai.com/docs/api-reference/responses` — Responses API request fields document `input`, `conversation`, and `previous_response_id` for conversation state.
- `vendor:openai:responses-compact:https://platform.openai.com/docs/api-reference/responses/compact` — Responses compaction endpoint documentation.
- `vendor:openai:responses-input-tokens:https://platform.openai.com/docs/api-reference/responses/input-tokens` — Responses input token counting endpoint and request shape.
- `vendor:openai:conversation-state:https://platform.openai.com/docs/guides/conversation-state` — `previous_response_id` is the mechanism for multi-turn conversation state.
- `vendor:openai:function-calling:https://platform.openai.com/docs/guides/function-calling` — function tool definitions support `strict` schema adherence.
- `vendor:openai:mcp-connectors:https://platform.openai.com/docs/guides/tools-connectors-mcp` — MCP servers use `server_url` and tool calls require approval by default with configurable `require_approval`.
- `vendor:litellm:stream-usage:https://docs.litellm.ai/docs/completion/stream` — `stream_options.include_usage` support for streaming usage metrics.
- `vendor:mcp:tools-spec:https://modelcontextprotocol.io/specification/2025-06-18/server/tools` — MCP tool definitions use `name`, `description`, and JSON Schema `inputSchema`.
- `vendor:mcp:schema-dialect:https://modelcontextprotocol.io/specification/2025-11-25/basic/schema` — MCP schemas follow JSON Schema 2020-12.
agenterm is designed against these contracts; changes in those external libraries may require coordinated updates in this architecture.

### 1.4 Architecture Overview

High‑level flow:

- **CLI / REPL** (user‑facing edge)
  → computes **AppConfig** and **SessionState**
  → passes to **Engine** (Agents + agenterm adapters)
  → Engine invokes **Agents SDK / MCP / OpenAI client** and persists state via SQLite.

Conceptual pipeline:

```mermaid
flowchart LR
    U[User] --> E1[CLI / REPL\n(Edge Layer)]
    E1 --> A1[Workflows & Services\n(AppConfig + SessionState builders)]
    A1 --> EN[Engine Layer\n(Agents adapters)]
    EN --> AG[Agents SDK]
    AG --> OA[OpenAI Responses API]
    EN --> MCP[MCP Servers]
    EN --> DB[(SQLite\nAdvancedSQLiteSession + agenterm_sessions + agenterm_branch_meta)]
```

Execution planes (single UX, two backends):

- **OpenAI plane**: Agents OpenAI provider calling the Responses API. OpenAI hosted tools and hosted MCP connectors are eligible for selection on this plane.
- **Gateway plane**: LiteLLM-backed routes (in-process, no external proxy runtime) using Chat Completions semantics; **FunctionTools only** (hosted tool types are not available).
- Plane boundaries do not fork transcripts or storage; history packing, persistence, and UI remain unified across both planes.

Architectural constraints:

- Edge layer never calls the Agents runner or SQLite directly.
- All session and configuration handling go through the workflows/services layer, then the engine, then external SDKs.

### 1.5 Layers

#### 1.5.1 Edge Layer (CLI / REPL)

Responsibilities:

- Parse command‑line flags and arguments (Typer).
- Manage terminal interaction:
  - stdout/stderr printing
  - prompts
  - keybindings
- Map user actions (subcommands, REPL input, slash commands) into calls to application workflows/services.

Evidence (terminal prompts):

- Rich prompt loops support choices/defaults and read input through `Console.input`, which we use for interactive config save selection. (.venv|lib/python3.14/site-packages/rich/prompt.py:30-211)
- Typer exposes Click termui prompt/confirm helpers via `typer.prompt` and `typer.confirm`, confirming the baseline CLI prompt idioms. (.venv|lib/python3.14/site-packages/typer/__init__.py:10-20)

Components:

- **Typer application** `agenterm` with subcommands:
  - `run` – one-shot run (prompt args, `--file`, or piped stdin).
  - `repl` – interactive prompt-toolkit REPL session.
  - `inspect` – local + provider inspection (`response|turn|events`).
  - `config` – configuration save/show/path (baseline + project overrides).
  - `agents` – agent list/show/path/save (bundled + local/global overrides).
  - `artifacts` – browse durable artifacts produced by the agent.
  - `trace` – show effective trace configuration (non‑REPL).
  - `session` – session store introspection and management.
  - `branch` – branch management for sessions.
  - `mcp` – MCP diagnostics and inspection.
- **Entry behavior**:
  - `agenterm` (no args) → prints help and exits (no implicit REPL start).
  - `agenterm repl` → interactive REPL; if no config is found, prompts to save local/global or continue with defaults.
  - `agenterm run …` → one-shot run (no prompts; emits config source note on stderr).
- **REPL UI**:
  - Full-screen prompt_toolkit `Application` with a scrollable transcript window.
  - Composer buffer with history and an adaptive completion panel between transcript and composer.
  - Status bar and HUD rendered from a single typed view model.

Constraint:

- This layer never instantiates Agents sessions or calls the Agents runner, SQLite, or MCP directly. All such work is delegated to the workflows/services and engine layers.

##### 1.5.1.1 Entrypoint Manifest (canonical)

This manifest is the authoritative list of public entrypoints that must be preserved
or explicitly retired during refactors. Each entrypoint declares its handler and the
state it mutates.

CLI entrypoints:

- `agenterm` (root): Typer app; prints help/version; no state mutation.
- `agenterm repl`: `agenterm.cli.__init__.repl_cmd` → `agenterm.ui.repl.run_repl`.
  - Reads config/agent files, may prompt to save baseline.
  - Creates or attaches a session; writes run status, SDK turn items, run events, usage, and artifacts; updates branch metadata.
  - Executes model runs via the workflow/engine pipeline (runs may include multiple SDK turns).
- `agenterm run`: `agenterm.cli.__init__.run_cmd` → `agenterm.commands.run.run_command_with_args`.
  - Reads config/agent files; may create or attach session/branch.
  - Writes run/event/usage/artifact records; background runs persist `response_id` for provider inspection.
- `agenterm inspect response|run|run-events|turn|agent-run`: `agenterm.commands.inspect.inspect_app`.
  - `response` fetches provider response by id; read‑only with respect to local store.
  - `run`/`run-events`/`turn`/`agent-run` read local store only (no provider calls).
- `agenterm config show|path`: read‑only config inspection.
- `agenterm config save`: writes baseline config files (global/local).
- `agenterm agents list|show|path`: read‑only agent file inspection.
- `agenterm agents save`: writes baseline agent files (global/local).
- `agenterm artifacts list|show|agent-run`: read‑only artifact inspection (store + filesystem).
- `agenterm artifacts open`: opens an artifact file (macOS only); no store mutation.
- `agenterm trace show`: read‑only trace configuration.
- `agenterm mcp servers|tools|status|validate|inspect`: connects to MCP servers to list/validate tooling.
  - `inspect --out` writes a JSON export file; otherwise read‑only.
- `agenterm session list|show|runs`: read‑only local store queries.
- `agenterm session delete`: deletes session metadata in the local store.
- `agenterm branch list|runs`: read‑only local store queries.
- `agenterm branch use|new|fork|delete`: mutates branch metadata/head pointers in the local store.

REPL slash commands:

- The canonical slash‑command surface is defined in `agenterm.commands.slash_manifest` and
  registered by `agenterm.commands.router`.
- Handlers in `agenterm.commands.handlers.*` mutate `SessionState` and, when needed, the
  same local store layer used by CLI commands.
- The only slash command that writes to disk is `/config key`, which saves the API
  key to `~/.agenterm/.env` and updates the in‑memory key for the active session.

Evidence (entrypoints & handlers):

- CLI wiring + top-level commands: `src/agenterm/cli/__init__.py:82-443`.
- One‑shot run handler: `src/agenterm/commands/run.py:1-199`.
- Inspect command group: `src/agenterm/commands/inspect.py:1-220`.
- CLI command groups: `src/agenterm/commands/config.py:37-220`, `src/agenterm/commands/agents.py:35-176`,
  `src/agenterm/commands/artifacts.py:27-202`, `src/agenterm/commands/trace.py:19-59`,
  `src/agenterm/commands/mcp.py:37-380`, `src/agenterm/commands/session.py:40-318`,
  `src/agenterm/commands/branch.py:46-420`.
- REPL entrypoint: `src/agenterm/ui/repl/runner.py:1-51`.
- Slash manifest + router: `src/agenterm/commands/slash_manifest.py:1-140`,
  `src/agenterm/commands/router.py:1-90`.
- `/config key` persistence: `src/agenterm/commands/handlers/session_config.py:180-199`.

##### 1.5.1.2 Inspect Command Contract (local-first)

`inspect` is the canonical **diagnostic** surface for run-level details and
provider background responses. It emits the standard JSON envelopes in
`--format json` mode and never mixes human output into JSON.

Subcommands (CLI):

- `agenterm inspect response <response_id> [--stream|--from-seq N] [--format human|json]`
  - OpenAI Responses-only. Requires `OPENAI_API_KEY`.
  - `--stream/--from-seq` are **human-only**; JSON mode is rejected.
  - JSON payload (`inspect.response`) includes:
    - `response_id`, `model`, `status`, `background`,
    - `usage` (input/output/total tokens when present),
    - `text` (output_text summary).
- `agenterm inspect run <session_id> <run_number> [--branch <id>] [--format human|json]`
  - Local store inspection (no provider calls).
  - JSON payload (`inspect.run`) includes:
    - run metadata (`session_id`, `branch_id`, `run_number`, `status`, `response_id`, `trace_id`),
    - usage summary (aggregate per-request totals when available),
    - `events_count`,
    - `items` (SDK turn input items covered by the run, JSON-safe),
    - `artifacts` (ArtifactSummaryPayload list).
- `agenterm inspect run-events <session_id> <run_number> [--branch <id>] [--limit N] [--format human|json]`
  - Returns the run event ledger as stored (Responses-shaped events; `raw_provider_payload`
    is currently null).
  - JSON payload (`inspect.run-events`) includes `session_id`, `branch_id`, `run_number`,
    and a list of RunEventEnvelope entries.
- `agenterm inspect turn <session_id> <turn_number> [--branch <id>] [--format human|json]`
  - Returns SDK turn items for the selected branch turn (Agents session tables).
  - JSON payload (`inspect.turn`) includes `session_id`, `branch_id`, `turn_number`,
    `items`, and any resolved `artifacts`.
- `agenterm inspect agent-run <report_id> [--format human|json]`
  - Returns a persisted `agent_run` report from the artifact vault (summary in human mode; full JSON in `--format json`).

Artifact traversal:

- Run inspection includes artifact references (`artifact_id`, `kind`, `mime`, `path`, `source_type`, `source_id`).
- Users resolve artifact details via `agenterm artifacts show <artifact_id>`, inspect
  agent_run reports via `agenterm artifacts agent-run <artifact_id>` or `agenterm inspect agent-run <report_id>`,
  and open via `agenterm artifacts open <artifact_id>` (macOS only).
- Inspect never inlines large binary payloads; event entries reference artifact ids
  when payloads are stored out-of-band (see 1.8.9 Run Event Ledger).

Error policy:

- Missing session/branch/run yields `not_found`.
- Missing OpenAI key for `inspect response` yields `auth_error`.
- Unsupported combinations (e.g., `--format json` + `--stream`) yield `usage_error`.
- All errors emit the canonical error envelope in JSON mode.

Evidence (current CLI surfaces):

- Inspect command group + streaming flags: `src/agenterm/commands/inspect.py:1-220`.
- JSON envelope emission: `src/agenterm/cli/json_output.py:1-41` and `src/agenterm/core/envelope.py:1-88`.
- Artifact list payloads: `src/agenterm/commands/artifacts.py:77-167` and
  `src/agenterm/core/cli_payloads_artifacts.py:1-76`.

#### 1.5.2 Workflows & Services Layer

Responsibilities:

- Translate CLI flags and config file into:
  - Effective `AppConfig` instance.
  - Initial `SessionState`.
  - Tool and MCP selections.
- Coordinate:
  - Session creation vs. attachment.
  - Store semantics for provider persistence and response id tracking (`model.store`, `last_response_id`).
- Choose execution strategy:
  - Foreground runs use streaming execution (`run_streamed`).
  - Background submissions use one‑shot execution (`run_once`).

Edge-facing entrypoints (CLI surfaces, not typed return values):

- See 1.5.1.1 Entrypoint Manifest for the canonical list and state effects.

Implementation notes:

- Configuration and tool assembly is handled by workflow modules:
- `workflow/shared/config_files.py` loads config‑scoped files (agent files, text format).
  - `workflow/shared/overrides.py` applies CLI overrides onto `AppConfig`.
- `core/tool_selection.py` defines the canonical tool catalog and selection
  resolution pipeline.
- `workflow/shared/tools.py` assembles the ToolCatalog from config and applies
  selection/resolution for run + REPL builders.
  - `workflow/run/build_state.py` constructs the run bundle (config + tools + selection + background).
  - `workflow/repl/build_state.py` constructs `SessionState` for REPL startup.
- REPL session lifecycle orchestration is centralized in `app/services/repl_session.py`, which maps between:
  - `SessionState` (application view of the session) and
  - `AgentermSQLiteSession` (Agents persistence; agenterm wrapper around `AdvancedSQLiteSession`),
    using the metadata table managed by the session store.

Streaming cancellation:

- REPL supports ESC to cancel the current run:
  - Requests `RunResultStreaming.cancel(mode="immediate")` on the active stream and
    records a user‑initiated cancellation reason for downstream handling.
    Evidence: `.venv/lib/python3.14/site-packages/agents/result.py:254-292`.
  - Cancelling a run is explicit and awaits task completion so background work does
    not linger after user interruption.
    Evidence: `.venv/lib/python3.14/site-packages/agents/run.py:842-867`.
  - Continues draining `stream_events()` after requesting cancellation to honor the
    SDK contract that cancellation completes once the stream is drained.
    Evidence: `.venv/lib/python3.14/site-packages/agents/result.py:300-347`.
  - `stream_events()` awaits the internal run task during cleanup, so a stuck
    run can stall cancellation if we wait indefinitely.
    Evidence: `.venv/lib/python3.14/site-packages/agents/result.py:340-347`.
  - The stream consumer checks a cancellation signal so we do not block on the
    internal event queue after a user cancel request (the SDK queue await has no
    built‑in wake‑up). Evidence:
    `.venv/lib/python3.14/site-packages/agents/result.py:300-347`.
  - agenterm propagates a shared `CancellationScope/CancelToken` from `RunRef` into
    `ToolRuntimeContext` so approvals, subprocess helpers, and tool boundaries can
    fail fast when the run is cancelled.
  - Model streaming only finalizes the current turn once a `ResponseCompletedEvent`
    is received; missing completion events leave the turn open until cancellation.
    Evidence: `.venv/lib/python3.14/site-packages/agents/models/openai_responses.py:158-199`,
    `.venv/lib/python3.14/site-packages/agents/run.py:1435-1516`.
  - Session input merging concatenates prior history with new input items, so
    reintroducing an item `id` already present in history yields a provider
    rejection (duplicate ids are invalid). To prevent resume replay from
    duplicating completed turn items, agenterm filters new input items whose
    `id` already exists in the session history before packing the combined
    history. Evidence: `.venv/lib/python3.14/site-packages/agents/run.py:1954-1991`.
  - If the run does not stop promptly, the REPL escalates to a hard cancel of the
    run task and the run pipeline persists the cancellation (run status `cancelled`,
    turn attempt marked `cancelled`) so the next run can resume with turn‑attempt
    items (see 1.8.10).
  - Forced cancellation persistence is bounded by `RUN_FORCE_CANCEL_PERSIST_TIMEOUT_SECONDS`;
    if persistence stalls, agenterm emits a warning and still abandons in‑memory
    run state so the UI unblocks.
  - Hard cancel treats `cancelled` as terminal in the run ledger so late task
    completions cannot overwrite the cancellation outcome.
  - Postprocess persistence (usage ledger, branch metadata, run status update) is
    bounded by `RUN_POSTPROCESS_TIMEOUT_SECONDS`; timeouts emit warnings and return
    a minimal postprocess result (usage omitted) rather than blocking the REPL.
    Evidence: `.venv/lib/python3.14/site-packages/agents/memory/sqlite_session.py:21-207`,
    `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:236-251`.
  - Run execution relies on the SDK's per‑turn persistence: each completed turn is
    committed via `session.add_items(input_list + new_items_as_input)` so cancellations
    preserve prior completed turns.
    Evidence: `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016`.
  - In‑flight turn outputs are captured in the turn‑attempt ledger and are always
    prepended to the next run input (no filtering, no tool replay; see 1.8.10).
- On user cancellation:
  - Run status is recorded as `cancelled`.
  - The next prompt uses local session turn history plus the cancelled turn‑attempt items;
    no remote chaining is ever attempted.
- Max‑turns errors are caught at the REPL edge and rendered as concise messages without corrupting `SessionState` or session metadata.

#### 1.5.3 Engine Layer

Responsibilities:

- Given `AppConfig` and `SessionState`, construct:
  - Agents `Agent`.
  - Agents `RunConfig`.
  - Agents `Session` (always SQLite-backed; agenterm uses `AgentermSQLiteSession`).
- Wrap the Agents runner:
  - `run_streamed` is the default path for CLI‑initiated runs.
  - `run_once` is reserved for background submissions where completion is handled server‑side.
- Attach tools and MCP servers configured in `AppConfig`.
- Handle:
  - Mapping from `AppConfig.model` into `ModelSettings` (including fixed `response_include`).
  - Session input callbacks for local session turn history replay.
  - Mapping SDK‑level errors into agenterm's smaller error vocabulary.

Logical engine modules:

- `engine.agent_factory`
  Builds Agents `Agent` from `AppConfig`, selected tools, MCP servers, and session.
- `engine.run`
  Implements `run_streamed` and `run_once`, controlling `RunConfig` construction and error mapping.
- `engine.history_packing`
  Builds per-run session input callbacks that rehydrate, pack, and trim session turn history within context budgets.
- `store.session.*`
  Provides session models, metadata repo, factories, and usage persistence on top of `AgentermSQLiteSession` (Agents `AdvancedSQLiteSession`); imported by engine/workflows.
- `engine.input_payload` / `engine.input_parts`
  Convert prompts/messages/attachments into Agents input items.
- `engine.result_summary`
  Summarizes `RunResult` / `RunResultStreaming` into concise tool and usage summaries.
- `engine.function_tool_wrappers`
  Exposes shell/apply_patch as FunctionTools with strict schemas for the gateway plane.
- `engine.mcp_factory`
  Creates MCP server instances (`MCPServerStdio`, `MCPServerSse`, `MCPServerStreamableHttp`) based on config.
- `engine.mcp_bridge`
  Wraps MCP servers as FunctionTools, enforces approvals, and normalizes output envelopes.
- `engine.mcp_diagnostics`
  Diagnostics/discovery helpers for MCP servers (connect, list tools, status snapshots) shared by CLI and REPL.
- `engine.mcp_pool`
  Owns MCP server lifecycle pooling for run execution.
- `engine.shell_executor`
  Executes shell commands in macOS Seatbelt sandbox (workspace-confined).
- `engine.subprocess_runner`
  Centralizes cancel‑aware subprocess execution for local tools and shell, including
  process‑group termination on cancel.
- `engine.apply_patch_editor`
  Applies patches to files, with summaries suitable for REPL and CLI output.

#### 1.5.4 External SDKs & Providers

External systems used by the engine:

- OpenAI client + Responses API:
  - Primary agent run execution uses the Agents SDK (Runner + OpenAIProvider).
  - Certain operations (compaction and background inspection) call the OpenAI client directly.
  - **Single-path contract:** agenterm registers one shared `AsyncOpenAI` instance into Agents via `agents.set_default_openai_client`
    and uses that same client for all direct OpenAI calls (shared connection pool, consistent auth, consistent tracing).
- Agents SDK (model, session, tool, and run abstractions).
- MCP SDK (MCP server and tool exposure).
- SQLite:
  - Used by `AdvancedSQLiteSession` for conversation and usage storage.
  - Used by agenterm's own metadata table (`agenterm_sessions`).

------

### 1.6 Configuration Model

#### 1.6.1 AppConfig Overview

`AppConfig` is the canonical in‑process configuration object for agenterm. High‑level structure:

```python
class AppConfig:
    agent: AgentConfig
    model: ModelConfig      # maps to Agents ModelSettings
    providers: ProvidersConfig
    retries: RetriesConfig
    compression: CompressionConfig
    attachments: AttachmentsConfig
    tools: ToolsConfig
    mcp: McpConfig
    steward: StewardConfig
    run: RunDefaults
    repl: ReplConfig
    guardrails: GuardrailsConfig
```

- Loaded from `config.yaml` via `config.loader`.
- CLI flags apply per‑run overrides on top of the loaded `AppConfig`.

#### 1.6.2 AgentConfig

Fields:

- `model: str`
  - Model identifier with an explicit provider prefix (see Model Registry below):
    - `openai/<model>` → OpenAI Responses plane.
    - `gateway/<route>/<model>` → LiteLLM gateway plane (in‑process).
      - `<route>` names a configured gateway route (see ProvidersConfig).
      - `<model>` is the provider/aggregator model id.
  - Gateway routes are in‑process; no external proxy runtime exists in this design.
  - Bare model ids are invalid; model identifiers must include the prefix.
  - `gateway/` is user‑facing; internally we resolve it via a GatewayProvider that
    constructs a LiteLLM-backed model using the route’s provider/base_url/key. Users never see a `litellm/` prefix.
  - `core.model_id.model_plane(...)` is the canonical plane resolver used for tool gating and packing logic.
- `name: str`
  - Agent name (instruction file name; defaults to `default`).
- `instructions: str | None`
  - Resolved developer/system prompt contents (runtime-only; not set in config).
- `path: Path | None`
  - Resolved source path for the active agent file (runtime-only; not set in config).
- `source: str | None`
  - Resolved agent source label (`local`, `global`, `bundled`; runtime-only).
- `explicit: bool`
  - True when the agent was explicitly overridden (CLI `--agent` or REPL `/agent`).
- `max_turns: int`
  - Maximum SDK turns allowed per run (bounded range; REPL defaults derive from this and can be overridden).

There is no separate agent display name; the agent name is used everywhere
(status bar, traces, and session metadata).

Config‑level file handling:

- `config.runtime.load_app_config(...)` resolves agent instructions in order:
  1) `./.agenterm/agents/<name>.md` (project-local override) when present
  2) `~/.agenterm/agents/<name>.md` (global override) when present
  3) bundled `src/agenterm/data/agents/<name>.md`
- `config.agent_files.resolve_agent(...)` returns a `ResolvedAgent`
  with `source.location` (`local`, `global`, `bundled`) and an `explicit` flag
  that populates `source` and `explicit`.
- CLI `--agent` overrides the config agent (see 1.6.10).
- REPL `/agent <NAME>` overrides the agent for the active session (see 4.6).
- When `text_format_file` is provided, `config.runtime.load_app_config(...)` reads it (256KB cap) and builds a `TextFormat` via `text.format_builder.from_schema_file`.

#### 1.6.3 ModelConfig & ModelSettings Mapping

`ModelConfig` captures all parameters that map onto `agents.model_settings.ModelSettings`.

Categories and fields:

- **Sampling**
  - `temperature: float | None`
  - `top_p: float | None`
  - `frequency_penalty: float | None`
  - `presence_penalty: float | None`
- **Tools and truncation**
  - `tool_choice: ToolChoice | None`
  - `parallel_tool_calls: bool | None`
  - `truncation: Literal["auto", "disabled"] | None`
  - `max_output_tokens: int | None`
- **Reasoning & verbosity**
  - `reasoning: Reasoning | None`
  - `verbosity: Literal["low", "medium", "high"] | None`
- **Metadata & text format**
  - `metadata: dict[str, str] | None`
  - `text_format: TextFormat | None`
  - `text_format_file: Path | None`
- **Store & caching**
  - `store: bool | None`
- `context_window: int | None` (local-only; used for packing + UI context percent and as the default reference for percent-based compression thresholds)
  - `prompt_cache_retention: Literal["in_memory", "24h"] | None`
  - `include_usage: bool | None`
- **Advanced / transport**
  - `top_logprobs: int | None`
  - `extra_query: dict[str, JSONValue] | None`
  - `extra_body: dict[str, JSONValue] | None`
  - `extra_headers: dict[str, str] | None`
- Reasoning settings are **model‑gated**:
  - `reasoning` is optional in `ModelSettings` and intended only for reasoning models. `.venv/lib/python3.14/site-packages/agents/model_settings.py:102-105`
  - GPT‑5 defaults include reasoning settings; non‑GPT‑5 defaults do not. `.venv/lib/python3.14/site-packages/agents/models/default_models.py:13-57`
  - agenterm defaults `model.reasoning.effort` to `medium` for GPT‑5 configs; non‑GPT‑5 models must set `model.reasoning: null` (explicit reasoning settings are rejected).
- Model ids are validated against provider-specific registries when building run/REPL configs and when processing `/model` and `--model` overrides.
- When `context_window` is unset, agenterm uses a conservative default of **128k tokens** (≈ **450k characters**) for packing budgets (see `constants.limits.CONTEXT_WINDOW_DEFAULT_TOKENS`).
- Sampling bounds are enforced during validation:
  - `temperature` ∈ [0, 2]
  - `top_p` ∈ [0, 1]
  - `frequency_penalty` / `presence_penalty` ∈ [-2.0, 2.0]
  - `top_logprobs` ∈ [0, 20]
- Structured output schemas are always normalized to OpenAI strict JSON schema rules before requests are sent:
  - `additionalProperties: false` is enforced on all object nodes and required fields are derived from properties.
  - The configured `text_format.strict` flag only controls `response_format.format.strict`; schema normalization still runs to satisfy OpenAI’s Structured Outputs requirements.
  - The Agents OpenAI Responses adapter always forwards the output schema as `response_format.format.schema` under the name `final_output`, so non‑strict schemas fail at request time (`.venv/lib/python3.14/site-packages/agents/models/openai_responses.py:418-436`).
  - Normalization uses the Agents strict-schema helper (`.venv/lib/python3.14/site-packages/agents/strict_schema.py:18-146`).

##### Model Registry (remote validation + cache)

agenterm validates model identifiers against **provider-specific** registries:

- **OpenAI registry** (prefix `openai/`):
  - Populated via the OpenAI `/models` endpoint and cached in the local store
    (see runtime citations for `openai.resources.models` and
    `openai.types.model.Model.id`).
- **Gateway registry** (prefix `gateway/`):
  - `gateway/<route>/<model>`:
    - `<route>` must exist in `providers.gateway.routes`.
    - Validation uses the route’s configured allowlist unless `allow_any_model=true`.
    - No remote model discovery is used (no external runtimes).

Registry behavior:

- OpenAI registry is cached and considered stale after `MODEL_REGISTRY_TTL_SECONDS`;
  it must be refreshed before validation.
- If the OpenAI cache is missing or stale and refresh fails, config build fails
  fast with `ConfigError`.
- Gateway registry is derived from config (route allowlists); refresh re-reads
  config and revalidates, with no remote discovery.
- `/model list <provider>[/<route-prefix>]` and `/model refresh <provider>[/<route-prefix>]`
  are scoped by the provider prefix and use the corresponding registry; CLI
  `--model` and REPL `/model` validate through the registry implied by the prefix.
- Gateway registry failures are **hard** failures:
  - Validation fails if a gateway route is missing.
  - If `allow_any_model` is false and the route allowlist is empty, list/refresh/validation fails.

`AppConfig.to_model_settings()`:

- Produces a `ModelSettings` instance where:
  - All fields above map 1:1 to `ModelSettings` properties.
  - `context_window` is UI-only and is **not** forwarded to the provider.
  - `reasoning` is forwarded only for GPT‑5 OpenAI models; non‑GPT‑5 models require `model.reasoning: null` (explicit reasoning settings are rejected).
  - `response_include` is always set to a **fixed include set** (see 1.6.4), not configurable by users.
  - `extra_args` is reserved for internal flags; e.g. `background=true` is set for background runs.

#### 1.6.4 Fixed Response Includes

agenterm always sets `ModelSettings.response_include` to the following include set:

- `file_search_call.results`
- `web_search_call.results`
- `web_search_call.action.sources`
- `reasoning.encrypted_content`

Implications:

- Tool and web search results are requested up-front so downstream UX can surface them deterministically
  (without additional API calls).
- Attachment references are persisted locally; response includes are not used to rehydrate attachments.
- Reasoning content (when supported by the model) is included in an encrypted form.
  - This is load-bearing for **local‑stateful replay**:
    - The OpenAI SDK documents that `reasoning.encrypted_content` enables reasoning items to be used in multi-turn
      conversations when using the Responses API statelessly (e.g. `store=false` or ZDR). Evidence:
      `.venv/lib/python3.14/site-packages/openai/resources/responses/responses.py:155-172`.
    - The `ResponseReasoningItem` type docstring explicitly instructs callers to re-send reasoning items in subsequent
      requests when manually managing context. Evidence:
      `.venv/lib/python3.14/site-packages/openai/types/responses/response_reasoning_item.py:31-56`.
  - agenterm relies on the Agents session replay mechanism to persist and re-send these items on every turn.

User‑facing behavior:

- The CLI and REPL decode these included sections into labeled output blocks (e.g., `[reasoning]`, `[tool output]`).
- In `--live` and REPL transcript rendering, `file_search` and `web_search` tool call blocks include a bounded
  `results:` section (count + previews) when present.
- Users **never** configure `response_include` directly; it is fixed at the engine layer.

#### 1.6.5 ToolsConfig

`ToolsConfig` models **tool-family configuration** and **selection bundles**.

It does **not** model “where something runs” (provider vs local harness), and it
does not directly represent MCP servers or MCP connectors. Execution-plane and
MCP are modeled separately (see 1.6.6 and 1.7).

Fields:

- Output envelope clamp (single budget):
  - `output_max_chars: int`
    - Hard cap (chars) for serialized FunctionTool and MCP bridge output envelopes.
    - Applied before writing tool outputs into session history or returning them to the model.
    - Line/entry limits in the transcript remain UI‑only and do not change tool outputs.
- Built-in tool families:
  - `file_search: FileSearchToolConfig | None`
  - `web_search: WebSearchToolConfig | None`
  - `image_generation: ImageGenerationToolConfig | None`
  - `shell: ShellToolConfig | None`
  - `apply_patch: ApplyPatchToolConfig | None`
  - `update_plan: UpdatePlanToolConfig | None`
  - `get_plan: GetPlanToolConfig | None`
  - `rg: RgToolConfig | None`
  - `fd: FdToolConfig | None`
  - `bat: BatToolConfig | None`
  - `tree: TreeToolConfig | None`
  - `stat: StatToolConfig | None`
  - `agent_run: AgentRunToolConfig | None`
    - Includes `bundle: str` (delegate-scope bundle name; default `research`).
  - `agent_run_report: AgentRunReportToolConfig | None`
- Function tools (user-defined Python tools declared in config):
  - `function_tools: list[FunctionToolConfig]`
- Dangerous overrides (policy hook):
  - `dangerous: DangerousToolsConfig`
- Selection bundles (user-facing):
  - `bundles: dict[str, ToolBundleConfig]`
    - Declarative bundles of **tool keys** with composition and scope.
    - Each bundle definition includes:
      - `bundles: list[str]` (bundle references, same scope)
      - `tools: list[str]` (explicit tool keys)
      - `selectors: list[str]` (prefix selectors like `mcp:*`, `hosted:mcp:*`, `fn:user:*`)
      - `scope: "main" | "delegate"` (main selection vs delegate-only)
    - Bundles are resolved into concrete tool keys before selection; selectors may
      expand to zero tools (e.g., no MCP servers configured).
  - `default_bundles: list[str]`
    - Main-scope bundles selected by default when no CLI selection is provided.

Tool-family config dataclasses with fields (`FileSearchToolConfig`, `WebSearchToolConfig`,
`ShellToolConfig`, `ApplyPatchToolConfig`, `ImageGenerationToolConfig`, and
`FunctionToolConfig`) live in `agenterm.config.tool_models`. Zero‑field enable/disable
toggles (`UpdatePlanToolConfig`, `GetPlanToolConfig`, `RgToolConfig`,
`FdToolConfig`, `BatToolConfig`, `TreeToolConfig`, `StatToolConfig`, `AgentRunToolConfig`,
`AgentRunReportToolConfig`) live in `agenterm.config.tools_policy`.
Both are imported into `agenterm.config.model` to keep the primary model under size limits.

Note: Shell sandbox configuration remains inside `ShellToolConfig` (`shell.sandbox.network`). Tool approvals are controlled by the session approval mode (`repl.approvals.mode` and `/approvals`) and by CLI `run`’s auto‑approval policy (see 1.11).

Two concepts are intentionally separate:

- **Declaration (available tools):**
  - A tool family is **available** when its config block exists (is not `null`).
  - Setting a tool family block to `null` removes that tool from the catalog entirely (it cannot be selected via bundles/keys).
- **Selection (plugged tools):**
  - Bundles/keys decide which available tools are exposed to the model for a given run/session.

Default alignment (agenterm policy):

- `ImageGenerationToolConfig.model` defaults to `gpt-image-1.5`.
- Set `tools.image_generation.model: null` to omit the `model` field and let the platform select a default.
- `ImageGenerationToolConfig` defaults for hosted images:
  - `input_fidelity: high`
  - `moderation: low`
  - `output_format: png`
  - `quality: high`
- `tools.output_max_chars` defaults to `20000` (chars).

Default bundles (agenterm policy):

- `inspect`: `fn:rg`, `fn:fd`, `fn:bat`, `fn:tree`, `fn:stat`
- `plan`: `fn:update_plan`, `fn:get_plan`
- `delegate`: `fn:agent_run`, `fn:agent_run_report`
- `steward`: `fn:steward`
- `edit`: `fn:apply_patch`
- `shell`: `fn:shell`
- `integrations`: selectors `mcp:*`, `hosted:mcp:*`
- `extensions`: selector `fn:user:*`
- `research` (delegate-only): `hosted:openai:web_search`, `hosted:openai:file_search`,
  `hosted:openai:image_generation`
- Default selection: `inspect` + `plan` + `delegate` + `steward`.
- Shipped bundles are **disjoint** by policy; no tool key appears in more than one
  shipped bundle.

Tool limits (validated in `config.validate`):

- `tools.file_search.max_num_results`: 1–50 (vendor constraint).
- `tools.image_generation.output_compression`: 0–100 (vendor constraint).
- `tools.image_generation.partial_images`: 0–3 (vendor constraint).
- `tools.shell.timeout_ms`: bounded positive range (agenterm policy).
- `tools.shell.max_output_length`: bounded positive range (agenterm policy).

#### 1.6.6 McpConfig

`McpConfig` models **all MCP integration surfaces**, split by execution plane:

- `servers: list[McpServerConfig]`
  - Client-managed MCP servers (stdio/SSE/streamable HTTP) whose tools are
    discovered and attached by the local `agenterm` harness.
- `connectors: list[McpConnectorConfig]`
  - Provider-hosted MCP connectors exposed to the model as the single hosted
    tool `hosted_mcp` (Agents `HostedMCPTool`).
- `convert_schemas_to_strict: bool`
  - Maps to Agents `Agent(mcp_config={"convert_schemas_to_strict": ...})` and
    controls best-effort strict-schema conversion for **client-managed**
    MCP servers.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/agent.py:66-108`
- `bridge: McpBridgeConfig`
  - Controls in-process MCP‑as‑FunctionTools behavior (naming + output limits).

`McpServerConfig` (per entry):

- `key: str`
  - Stable identifier used by selection and UI (for example, `files`, `linear`, `github`).
- `kind: "stdio" | "sse" | "streamable_http"`
  - Selects which Agents MCP server class is constructed.
- `name: str | None`
  - Optional readable server name override.
  - Maps to the Agents MCP server constructors’ `name=` parameter.
  - If omitted, Agents synthesizes a name from command/URL (`.venv/lib/python3.14/site-packages/agents/mcp/server.py:418-423`).
- `use_structured_content: bool`
  - Maps to Agents MCP `use_structured_content=` (defaults to `False` to avoid duplicate content; `.venv/lib/python3.14/site-packages/agents/mcp/server.py:35-45`).
- `tool_filter: McpToolFilterConfig | None`
  - Controls server-level tool filtering.
  - This is the canonical mechanism for allowing/denying specific MCP tools without changing the server selection itself.
  - Maps to Agents MCP `tool_filter=` (`.venv/lib/python3.14/site-packages/agents/mcp/util.py:66-79` and `.venv/lib/python3.14/site-packages/agents/mcp/server.py:148-228`).
- `message_handler_key: str | None`
  - Optional registry key used to select a session `message_handler` callback.
  - Maps to Agents MCP `message_handler=` (`.venv/lib/python3.14/site-packages/agents/mcp/server.py:99-149`).
- Transport config (exactly one based on `kind`):
  - `stdio: McpServerStdioConfig | None`
  - `sse: McpServerSseConfig | None`
  - `streamable_http: McpServerStreamableHttpConfig | None`
    - Additionally supports `httpx_client_factory_key: str | None` for Streamable HTTP.
      - The registry-resolved callable is passed as `params["httpx_client_factory"]` to the Agents server constructor (`.venv/lib/python3.14/site-packages/agents/mcp/server.py:574-691`).
- `runtime: McpServerRuntimeConfig`
  - Maps to Agents MCP runtime parameters:
    - `cache_tools_list`
    - `client_session_timeout_seconds`
  - Retry policy is configured globally via `RetriesConfig.mcp` (see 1.6.7); agenterm disables
    SDK retries and applies the configured policy in the MCP adapter layer.
  - Default alignment:
    - Agents defaults `cache_tools_list=False` (`.venv/lib/python3.14/site-packages/agents/mcp/server.py:393-399`).
    - agenterm targets the same default; enable caching only when a server’s tool list is known to be stable.

`McpToolFilterConfig`:

- `allowed_tool_names: list[str] | None`
- `blocked_tool_names: list[str] | None`
- `callable_key: str | None`
  - Optional registry key for a dynamic tool filter function.
  - Mutually exclusive with the static allow/block lists.

`McpBridgeConfig`:

- `max_content_items: int`
  - Hard cap for structured content items returned by MCP tools.
  - Serialized output size is capped by `tools.output_max_chars` (shared with FunctionTools).

`McpExposeConfig` (FastMCP server exposure):

- `enabled: bool`
  - When true, `agenterm mcp serve` exposes local FunctionTools via FastMCP.
- `transport: "stdio" | "sse" | "streamable_http"`
  - Transport used by FastMCP (`streamable_http` maps to FastMCP `streamable-http`).
- `host: str`
  - HTTP bind host (SSE / streamable HTTP only).
- `port: int`
  - HTTP bind port (SSE / streamable HTTP only).
- `allow_dangerous: bool`
  - When false, dangerous tools are **not** exposed via MCP.
- `bundles: list[str] | None`
  - Optional bundle override for MCP server exposure; when unset, uses `tools.default_bundles`.
- `tools: list[str] | None`
  - Optional tool-key override (same semantics as `--tool`); when set, overrides bundles.

Defaults:

- `max_content_items=50`
- `mcp.expose.enabled=false`
- `mcp.expose.transport="stdio"`
- `mcp.expose.host="127.0.0.1"`
- `mcp.expose.port=8000`
- `mcp.expose.allow_dangerous=false`

Registries:

- `core.mcp_registry` is the canonical place to register:
  - dynamic `tool_filter` functions (by `callable_key`)
  - MCP `message_handler` functions (by `message_handler_key`)
  - Streamable HTTP `httpx_client_factory` functions (by `httpx_client_factory_key`)

#### 1.6.7 RetriesConfig

`RetriesConfig` is the **single** retry policy surface across agenterm. It replaces ad‑hoc loops
and disables SDK‑internal retries so behavior is deterministic and centrally configured.

Structure:

- `provider: RetryPolicyConfig`
  - Applies to OpenAI/gateway model calls (streamed, background, agent_run).
  - Retries only transient transport/provider failures with bounded exponential backoff + jitter.
  - Honors Retry‑After headers when present, capped by `retry_after_max_seconds`.
  - SDK retries are disabled; agenterm owns the retry loop.
  - Evidence (OpenAI SDK defaults + semantics):
    - `DEFAULT_MAX_RETRIES`, `INITIAL_RETRY_DELAY`, `MAX_RETRY_DELAY` defaults (`.venv/lib/python3.14/site-packages/openai/_constants.py:10-14`).
    - Retry‑After parsing and retryable status codes (408/409/429/5xx) (`.venv/lib/python3.14/site-packages/openai/_base_client.py:692-770`).
  - Evidence (LiteLLM defaults; disabled by agenterm):
    - LiteLLM default max retries and backoff constants (`.venv/lib/python3.14/site-packages/litellm/constants.py:30-31`, `225-227`).

- `mcp: RetryPolicyConfig`
  - Applies to MCP `list_tools` / `call_tool` retries in the adapter layer.
  - SDK retries are disabled (Agents MCP `max_retry_attempts=0`); agenterm applies the configured policy.
  - Infinite retries are **not** allowed; `max_retries` must be finite.
  - Evidence: Agents MCP retry knobs and infinite `-1` semantics (`.venv/lib/python3.14/site-packages/agents/mcp/server.py:99-142`, `254-264`).

- `store: RetryPolicyConfig`
  - Applies to SQLite `SQLITE_BUSY` handling in `AsyncStore` (WAL + busy_timeout + bounded retry).

`RetryPolicyConfig` fields (all required, no implicit defaults at runtime):

- `max_retries: int` — non‑negative; 0 disables retries.
- `base_backoff_seconds: float` — positive base for exponential backoff.
- `max_backoff_seconds: float` — positive cap for exponential backoff.
- `jitter_ratio: float` — 0.0–1.0; jitter applied as `1 - jitter_ratio * rand()`.
- `retry_after_max_seconds: float | None` — provider‑only cap for Retry‑After; ignored for MCP/store.

#### 1.6.8 StewardConfig

`StewardConfig` defines the **Steward subsystem**: its agent identity and task orchestration.
Compression policy is owned by `CompressionConfig` (see §1.6.9).

Fields (contract):

- `agent: StewardAgentConfig`
  - Defines the dedicated Steward agent (model + instructions) used for `steward.snapshot`.
- `tasks: StewardTasksConfig`
  - Controls queue limits for Steward tasks.

`StewardAgentConfig` (Steward‑only agent identity):

- `name: str`
  - Defaults to `"steward"`; used for tool naming + trace labels.
- `model: str | None`
  - Optional override for the Steward model; defaults to `AppConfig.agent.model`.
- `instructions: str | None`
  - Inline instructions for the Steward agent (mutually exclusive with `path`/`source`).
- `path: Path | None`
  - Optional agent file path; resolved like the main agent file.
- `source: str | None`
  - Optional agent file name to resolve via local/global/bundled lookup.
  - Defaults to `steward.agent.name` when unset.

Rules:

- The Steward agent runs with **no tools** and `max_turns=1` (single‑run task execution).
- `model` must be a valid model id for the selected plane (OpenAI or gateway).
- `instructions`/`path`/`source` are mutually exclusive.
- When all are `null`, agenterm resolves the Steward agent from the bundled/local/global
  agent files using `steward.agent.name`.

`StewardTasksConfig` (task orchestration):

- `max_pending: int`
  - Max queued tasks per session/branch (default `1`).

#### 1.6.9 CompressionConfig

`CompressionConfig` defines the **pre‑run compression policy** for long-running sessions.

Fields (contract):

- `strategy: Literal["snapshot", "compaction_if_supported", "both_if_supported"]`
- `trigger: Literal["ask", "auto"]`
- `threshold_percent: float`
- `primary_branch: Literal["snapshot", "compaction"]`
- `drop_policy: Literal["ask", "deny", "allow"]`

Rules:

- Compression is a **pre‑run** step that operates on history **before** the current user input.
- Thresholds are **percent‑based** only; `threshold_percent` applies to `model.context_window`
  (defaults to 128k when unset).
- `snapshot` runs `steward.snapshot`.
- `compaction_if_supported` runs compaction only when provider capabilities explicitly allow it;
  otherwise falls back to snapshot.
- `both_if_supported` runs both snapshot + compaction on the original branch; the active branch is
  selected via `primary_branch`.
- `trigger="ask"` prompts only when interactive; non‑interactive runs treat `ask` as `deny`.
- `drop_policy` controls last‑resort truncation of oldest turns; `ask` requires explicit approval.

#### 1.6.10 AttachmentsConfig

`AttachmentsConfig` defines **attachment ingestion policy** (local files + URLs).

Fields (contract):

- `image_input_mode: Literal["file_id_or_url_only", "allow_inline_data_url"]`
- `allow_inline_data_url: bool`
- `max_inline_bytes: int`

Rules:

- Inline data URLs are **forbidden** by default; only explicit user attachments can enable
  inline data URLs when `allow_inline_data_url=true`.
- Local images/PDFs are uploaded to provider storage when `supports_file_id` is true; otherwise
  they must be supplied as URLs (or be rejected if inline is disallowed).
- Text attachments are embedded as `input_text` and never base64‑encoded.

#### 1.6.11 RunDefaults & GuardrailsConfig

`RunDefaults`:

- `background: bool`
  - Whether runs are backgrounded by default.
- `timeout_seconds: float | None`
  - Stream idle timeout (seconds) for streamed runs; idle = no stream events/model bytes; `null` disables it.
  - The timer resets on any stream event (text delta, tool call, etc.).
- `live: bool`
  - Default streaming presentation for one-shot runs; `True` shows live events, `False` emits only the final answer and footer.
- `json_output: bool`
  - When `True`, emit the JSON envelope described in 1.10.5 and suppress text panels.
- `trace_enabled: bool`
  - Master switch for tracing; when `False`, agenterm disables tracing for the run.
- `trace_id: str | None`
  - Agents trace ids default to `trace_<uuid>` when omitted; use `util.gen_trace_id()` to keep formats aligned.
  - Evidence: `.venv|lib/python3.14/site-packages/agents/tracing/provider.py:210-238` and `.venv|lib/python3.14/site-packages/agents/tracing/create.py:28-69`
- `group_id: str | None`
  - Optional grouping id to link related traces; the Agents provider can generate `group_<uuid>` ids.
  - Evidence: `.venv|lib/python3.14/site-packages/agents/tracing/provider.py:218-245` and `.venv|lib/python3.14/site-packages/agents/tracing/create.py:28-69`
- `trace_metadata: dict[str, str] | None`
  - Optional metadata dictionary attached to traces.
  - Evidence: `.venv|lib/python3.14/site-packages/agents/tracing/create.py:28-69`
- `trace_include_sensitive_data: bool`
  - When false, Agents switches to the "enabled without data" tracing mode to avoid uploading sensitive payloads.
  - Evidence: `.venv|lib/python3.14/site-packages/agents/_run_impl.py:264-272`

`GuardrailsConfig`:

- `load_modules: list[str]`
  - Optional Python modules to import during config initialization so their
    `register_input_guardrail(...)` / `register_output_guardrail(...)` calls run.
- `input: list[str]`
- `output: list[str]`

Each list element names a guardrail implementation registered in `core.guardrails_registry` (see 1.7.6).

#### 1.6.10 Config Loading & Overrides

Config discovery follows a simple two‑path model (Linux and macOS only):

1. **Project‑local override**: `.agenterm/config.yaml` in the current working directory (when present).
2. **Global baseline**: `~/.agenterm/config.yaml`.

An explicit `--config PATH` always overrides discovery.

The global baseline is the “nothing left behind” configuration: it contains every configurable key at its code default and is heavily commented so first‑time users can succeed without hunting for docs.

The baseline also includes representative, commented MCP server examples for the two primary local transports we expect users to run day‑to‑day:

- `kind: stdio` (local process)
- `kind: streamable_http` (HTTP Streamable transport)

The `sse` transport is supported by the engine, but the baseline template intentionally does not ship an SSE example block.

The config workflow is a single path:

- `agenterm config save` writes the complete, commented baseline config generated from the live schema:
  - Source: `AppConfig` dataclasses + schema docs registry (`config.template` + `config.template_docs.*`).
  - Target path: `~/.agenterm/config.yaml` (global) or `.agenterm/config.yaml` (local).
  - Local saves prefer seeding from the current global config when present; otherwise they use the schema-derived template.
  - Every config field is required to have a corresponding doc entry so the rendered template stays fully annotated.

Agents workflow mirrors config:

- `agenterm agents save` writes baseline agent files:
  - Global target directory: `~/.agenterm/agents/`
  - Local target directory: `./.agenterm/agents/`
  - Save operations copy **all** bundled agents from `src/agenterm/data/agents/`.
  - Local saves prefer copying existing global agents when present; otherwise they use the bundled defaults.
- `agenterm agents show` prints the full effective agent file text:
  - Human output renders Markdown by default; `--plain` prints raw text.
  - JSON output emits a single envelope containing source, path, sha256, size, and text.
- `agenterm agents path` reports the effective source location and path for an agent file.
- `agenterm config save` and `agenterm agents save` are independent; config save does not create or modify agent files.

First-run onboarding is non-interactive by default, except where explicitly requested:

- Edges load a fully-typed default `AppConfig` when no config file exists and do not block on prompts.
- `agenterm repl` offers a one-time prompt to save a baseline config (local/global) when no config is found; choosing “skip” continues with defaults.
- `agenterm repl` similarly offers a one-time prompt to save agent files when the active agent is bundled and no local/global agent file exists.
- `agenterm run` never prompts and emits short stderr notes indicating the effective config and agent sources.

Config loading follows a single, layered pipeline; each stage lives in its own module under `config/`:

1) **Decode (`config.decode`)** – Resolve the effective config path (explicit or discovered) and load YAML/JSON with `ruamel` in safe mode into a raw object. Returns `None` when the file is absent; raises `ConfigError` on parse/IO errors.
2) **Schema validation (`config.schema_validation`)** – Validate JSON algebra and shape before normalization:
   - Root must be an object with string keys.
   - Values must be JSON‑compatible (no implicit coercion).
   - Known sections must be objects when provided.
   - Errors include field‑path context (`config.<section>.<field>`).
3) **Schema (`config.schema`)** – Convert the validated mapping into the typed `RawConfig` envelope and reject unknown top‑level sections (only `agent`, `model`, `providers`, `retries`, `steward`, `compression`, `attachments`, `tools`, `mcp`, `run`, `repl`, `guardrails` are accepted). This keeps config strict and prevents silent typos at the root.
4) **Normalize (`config.normalize`)** – Overlay per‑section values onto base
defaults, validate types **strictly** (no coercion), and resolve mutually
exclusive options (`text_format` vs `text_format_file`). Normalizers reject
unknown keys within each section to catch typos early. Output is a
`NormalizedConfig` with concrete types ready for validation.
5) **Validate (`config.validate`)** – Perform cross‑field checks and bounded range validation (e.g., uniqueness of MCP server keys, tool_filter exclusivity, compaction policy constraints, model/tool numeric limits, tool bundle references). Model ids are validated by the ModelRegistry during config build.
6) **Runtime (`config.runtime`)** – Convert the normalized model into the runtime `AppConfig` (defined in `config.model`) and expose the single entrypoint `load_app_config(path | None)`, which runs steps 1–5 and returns defaults when no file is present.

CLI/REPL overrides are applied **after** runtime config construction via pure editors in `config/editors/*` (model, tools, mcp, run_defaults, reasoning). Editors return new `AppConfig` instances and never mutate in place. The `--agent` override is applied during config load so the effective agent is resolved before session metadata is created. File references (structured schema) are resolved at the edge layer using config-relative paths before editors are applied.

Greenfield reset behavior:

- Any config load/validation error is treated as fatal.
- Errors instruct the operator to delete the config + agent files (global and/or local) and retry, rather than attempting migration or compatibility shims.

#### 1.6.11 Canonical Choice Sets (`core.choices`)

agenterm exposes several **enumerated string-token options** (e.g., `repl.ux.verbosity`, `model.truncation`, `model.reasoning.effort`).
These values appear in multiple layers:

- `config.model` dataclasses (typed configuration surface)
- `config.normalize.*` loaders/normalizers (YAML → typed config)
- `config.editors.*` (runtime overrides)
- CLI/REPL parsers + completion (`commands.parsers.*`)
- UI policy objects (`ui.*`) and session state (`core.types.SessionState`)

To prevent drift, every shared choice set is defined **exactly once**, in `agenterm.core.choices.*`.
Other layers **import** these types/value tuples and must not re-declare the same choice sets as local `Literal[...]` unions, `_VALS` tuples, or duplicated string lists.

Rules:

- **Single source of truth:** All shared choice sets live in `agenterm.core.choices.*`.
- **No parallel definitions:** If a value set is used by both config and UI (or config and parsing), it is not redefined elsewhere.
- **Edge-only sentinels:** Interactive surfaces may accept `unset` to map to `None`, but `unset` is not part of the underlying value type.
- **Change discipline:** Adding/removing a token updates `agenterm.core.choices.*`, then updates config normalization, command parsing, UI rendering, and tests in the same change set.

Canonical choice sets (selected):

- **REPL UX toggles** (`agenterm.core.choices.repl`)
  - `ReplVerbosity`: `quiet|normal|debug`
  - `ReplStreamMode`: `final|live`
  - `ReplReasoningMode`: `off|summary`
  - `ReplDiffsMode`: `off|summary`
- **REPL UI controls** (`agenterm.core.choices.repl_ui`)
  - `ReplTheme`: `dark|light`
  - `ReplColorDepth`: `auto|mono|ansi|default|truecolor`
  - `ReplCompletionMode`: `off|commands|full`
  - `ReplEditingMode`: `emacs|vi`
- **Model settings** (`agenterm.core.choices.model`)
  - `ModelTruncation`: `auto|disabled`
  - `ModelVerbosity`: `low|medium|high`
  - `PromptCacheRetention`: `in_memory|24h`
  - `ReasoningEffort`: `none|minimal|low|medium|high|xhigh`
  - `ReasoningSummary`: `auto|concise|detailed`
- **Tools** (`agenterm.core.choices.tools`)
  - `SearchContextSize`: `low|medium|high`

#### 1.6.12 Config Template Generation

agenterm generates the commented `config.yaml` template from the live `AppConfig` schema at runtime:

- `agenterm.config.template.render_config_template` walks the `AppConfig` dataclasses, renders defaults into a `CommentedMap`, and attaches:
  - section headers,
  - per-field comments, and
  - example blocks for complex structures.
- Comment text lives in a schema-adjacent registry (`agenterm.config.template_docs.*`) so every field has a single canonical explanation.
- The generator uses `ruamel.yaml` comment APIs (`yaml_set_start_comment`, `yaml_set_comment_before_after_key`, `yaml_add_eol_comment`) to emit the full in-file documentation while preserving YAML validity.
- `agenterm config save` renders the template from schema and applies the `--model` override by updating `agent.model` before serialization.

This keeps the distributed template and the typed schema in lockstep without manual edits.
  - `SandboxNetwork`: `allow|deny`
- **Approvals** (`agenterm.core.choices.approvals`)
  - `ApprovalMode`: `prompt|auto`
- **MCP** (`agenterm.core.choices.mcp`)
  - `McpServerKind`: `stdio|sse|streamable_http`
  - `EncodingErrorHandler`: `strict|ignore|replace`
- **Image generation** (`agenterm.core.choices.image_generation`)
  - `ImageBackground`: `transparent|opaque|auto`
  - `ImageInputFidelity`: `high|low`
  - `ImageModeration`: `auto|low`
  - `ImageOutputFormat`: `png|webp|jpeg`
  - `ImageQuality`: `low|medium|high|auto`
  - `ImageSize`: `1024x1024|1024x1536|1536x1024|auto`

#### 1.6.13 ProvidersConfig (OpenAI + Gateway)

`ProvidersConfig` defines endpoint and credential settings for the two supported planes.

Structure:

```python
class ProvidersConfig:
    openai: OpenAIProviderConfig
    gateway: GatewayProviderConfig

class OpenAIProviderConfig:
    base_url: str | None

class GatewayProviderConfig:
    routes: Mapping[str, GatewayRouteConfig]

class GatewayRouteConfig:
    provider: str
    base_url: str | None
    api_key_env: str | None
    headers: Mapping[str, str] | None
    model_allowlist: list[str] | None
    allow_any_model: bool
```

Rules:

- Gateway routes are **in‑process** LiteLLM calls; no external runtime is required.
- `openai/<model>` requires an OpenAI API key; `base_url` is an optional override
  (for Azure/OpenAI‑compatible endpoints) and supersedes `OPENAI_BASE_URL` when set.
- `gateway/<route>/<model>` resolves the route config:
  - `provider` is the LiteLLM provider id (or `openai` for OpenAI‑compatible servers).
  - `base_url` overrides the provider endpoint when needed (vLLM/Triton/Ollama or Azure).
  - `api_key_env` names the environment variable that stores the key; if `None`,
    no key is passed (local endpoints).
  - `headers` are optional non‑secret static headers (e.g., metadata).
  - `model_allowlist` enforces explicit model validation unless `allow_any_model=true`.
  - `allow_any_model` defaults to `false`; setting it to `true` explicitly disables validation.
- Aggregators (OpenRouter, etc.) are **routes** like any other; no special proxy path.
- Credential precedence is **request context → environment** (config does not carry secrets).
- Missing required endpoint/key is a hard failure with a typed `ConfigError`.
- **Secret policy:** API keys are sourced **only** from environment (inline env or `.env`).
  - Config validation fails if raw keys are set in config files.
  - `headers` in config are for non‑secret static headers only.
  - Evidence: Agents `LitellmModel` passes `api_key` and `base_url` directly to
    `litellm.acompletion`, so route config maps onto those fields.
    `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:393-412`

External citations (vendor/runtime):

- Agents `ModelSettings` defines `truncation`, `verbosity`, and `prompt_cache_retention` as enumerated literals:
  - `.venv/lib/python3.14/site-packages/agents/model_settings.py:93`
  - `.venv/lib/python3.14/site-packages/agents/model_settings.py:107`
  - `.venv/lib/python3.14/site-packages/agents/model_settings.py:119`
- OpenAI `Reasoning` defines supported effort and summary values:
  - `.venv/lib/python3.14/site-packages/openai/types/shared/reasoning.py:19`
  - `.venv/lib/python3.14/site-packages/openai/types/shared/reasoning.py:36`
- OpenAI web search tool param defines `search_context_size` values:
  - `.venv/lib/python3.14/site-packages/openai/types/responses/web_search_tool_param.py:67`
- OpenAI tool param defines image generation option enums:
  - `.venv/lib/python3.14/site-packages/openai/types/responses/tool_param.py:223`
  - `.venv/lib/python3.14/site-packages/openai/types/responses/tool_param.py:229`

#### 1.6.14 Canonical JSON Validation & Response Item Serialization

agenterm defines **one** validation surface for JSONValue and **one** serialization path for
Responses input items. This keeps JSON handling deterministic and removes ad‑hoc conversions.

JSON validation rules:

- `core.json_codec` owns the JSONValue algebra, strict validators, and the canonical JSON
  dump/size helpers.
- Strict readers (`as_*`) accept already‑typed JSON values only; runtime serialization does **not**
  coerce or stringify unexpected objects.
- JSON objects/lists are validated through `require_json_object` / `require_json_value`; YAML/CLI
  inputs must already be JSON‑compatible and are rejected otherwise.
- Modules do **not** implement local coercers; they call the validators and then apply
  domain‑specific validation.
- JSON envelope emission (tool outputs + error envelopes) validates payloads and error details;
  invalid values raise `ValidationError` and fail fast (no fallback stringification).
- Canonical JSON dumps:
  - `dumps_compact` emits compact JSON (no extra whitespace, ASCII‑escaped) for storage,
    tool envelopes, MCP payloads, and size accounting, and validates inputs.
  - `dumps_pretty` is reserved for human‑facing JSON exports and validates inputs.
  - `json_size` computes size using `dumps_compact` to keep budgeting consistent.

Response item serialization:

- `core.response_items` is the canonical serializer for `TResponseInputItem`.
- It converts items with `TypeAdapter.dump_python(..., mode="json")`, then performs stable
  JSON dumps for size accounting and envelope emission (via `core.json_codec`).
- This serializer is used by inspect, history packing, and REPL snapshot/compaction renderers.

Response input items and attachments:

- Responses input message content accepts `input_text`, `input_image`, and `input_file`
  items; agenterm builds these for prompt text and attachments.
- Image attachments map to `input_image` with `detail="auto"` and one of:
  - `file_id` (preferred when supported),
  - `image_url` when the user supplies a URL, or
  - inline data URLs only when policy explicitly allows it.
- PDF attachments map to `input_file` with `filename` and one of:
  - `file_id` (preferred when supported),
  - `file_url` when the user supplies a URL, or
  - inline `file_data` only when policy explicitly allows it.

Store JSON/row codecs:

- `store.codec` centralizes JSON encode/decode for SQLite payload columns with
  `DatabaseError` context and enforces JSONValue/object expectations.
- Row field validation (`require_text`, `optional_text`, `require_int`) lives in the same module;
  store repositories import these helpers instead of defining per‑file variants.

External citations (vendor/runtime):

- Pydantic `TypeAdapter.dump_python` supports JSON‑mode serialization:
  - `.venv/lib/python3.14/site-packages/pydantic/type_adapter.py:561-579`
- OpenAI `BaseModel.to_dict` uses `model_dump(mode="json")` to emit JSON‑serializable payloads:
  - `.venv/lib/python3.14/site-packages/openai/_models.py:138-188`
- Agents `AdvancedSQLiteSession.list_branches` returns JSON‑safe dicts for branch listings:
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:744-787`
- OpenAI JSON‑safe normalization mirrors `model_dump(mode="json")` semantics and ISO‑formats
  `date`/`datetime` values:
  - `.venv/lib/python3.14/site-packages/openai/_utils/_utils.py:412-425`
- Agents memory sessions serialize items with compact JSON separators and decode with
  `json.loads`, establishing a compact JSON convention for persistence:
  - `.venv/lib/python3.14/site-packages/agents/extensions/memory/redis_session.py:103-109`
- Agents output validation uses `TypeAdapter.validate_json` to enforce JSON correctness:
  - `.venv/lib/python3.14/site-packages/agents/util/_json.py:16-32`
- OpenAI Responses input message content list allows `input_text`, `input_image`,
  and `input_file` items:
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_message_content_list_param.py:8-16`
- OpenAI `input_image` supports `image_url`/`file_id` and requires `detail`:
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_image_param.py:10-32`
- OpenAI `input_file` supports `file_data`/`file_url`/`file_id`/`filename`:
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_file_param.py:11-25`

------

### 1.7 Tools, MCP, Guardrails & Tracing

#### 1.7.1 Tool Taxonomy

agenterm classifies tools by **capability family** (selection keys) and resolves
**plane adapters** at runtime.

Capability families (tool keys):

- **Built‑in FunctionTools**: `fn:<name>` (`fn:shell`, `fn:apply_patch`, `fn:update_plan`, `fn:get_plan`, `fn:steward`,
  `fn:rg`, `fn:fd`, `fn:bat`, `fn:tree`, `fn:stat`, `fn:agent_run`, `fn:agent_run_report`)
- **User FunctionTools**: `fn:user:<name>` (registered in code; enabled via config)
- **OpenAI hosted tools**: `hosted:openai:<tool>` (`file_search`, `web_search`, `image_generation`)
- **OpenAI hosted MCP connectors**: `hosted:mcp:<connector>` (provider-hosted MCP; optional)
- **Client MCP servers**: `mcp:<server_key>` (stdio/SSE/streamable HTTP; each server exposes many tools)

Execution plane (what background mode cares about):

- **hosted**: runs on provider infrastructure; compatible with background runs.
- **client**: requires the local `agenterm` harness process; incompatible with background runs.

Adapter resolution (what is actually attached to the agent):

- **OpenAI plane**: hosted tools use native OpenAI tool types; `shell`/`apply_patch`
  use native tool types; FunctionTools are attached as FunctionTools.
- **Gateway plane**: **FunctionTools only** (Chat Completions constraint);
  `shell`/`apply_patch` use FunctionTool wrappers.
- **Client MCP servers**: converted to FunctionTools via Agents MCPUtil (inputSchema‑driven),
  with agenterm wrappers enforcing approvals and output envelopes.

Tool replacement contract (agenterm policy):

- When an OpenAI‑hosted tool is replaced with a local implementation, agenterm ships all three layers:
  1) tool executor (implementation),
  2) tool I/O contract (strict schema + output envelope),
  3) transcript UX (labels, previews, artifact handling).
- Local tool implementations are single‑source‑of‑truth: the same executor powers in‑process FunctionTools
  and MCP exposure (no divergent code paths).

Function-tool schema citations (vendor/runtime):

- Agents `function_tool` builds tool schemas by calling `get_type_hints(..., include_extras=True)` on the wrapped function, which evaluates the function’s annotations at registration time:
  - `.venv/lib/python3.14/site-packages/agents/function_schema.py:252`
  - `.venv/lib/python3.14/site-packages/agents/tool.py:569-577`
- Implication: any types referenced in function-tool signatures (including `return` annotations) must be importable at runtime (not TYPE_CHECKING-only), even if agenterm does not use return types in its own domain logic.
- Agents `FunctionTool` defaults to `strict_json_schema=True` and invokes `ensure_strict_json_schema` at construction time.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/tool.py:173-191`
- Agents `ensure_strict_json_schema` maps an empty schema `{}` to a strict object schema with `additionalProperties: false` and no properties; no-argument tools should pass `{}` as the params schema.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/strict_schema.py:10-26`
- Agents `openai_responses` conversion propagates `strict_json_schema` into the OpenAI `tools[*].strict` field.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/models/openai_responses.py:455-470`
- Chat Completions conversion accepts `FunctionTool` only; hosted tool types raise `UserError`.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:593-608`
- Agents `MCPUtil` converts MCP tools to FunctionTools using the MCP `inputSchema`
  (and optionally strict-mode normalization).
  - Evidence: `.venv/lib/python3.14/site-packages/agents/mcp/util.py:154-179`
- MCP tool invocation uses `structuredContent` when `server.use_structured_content` is true,
  enabling agenterm’s structured output envelope for deterministic replay.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/mcp/util.py:213-216`

Tool schema strictness (agenterm policy):

- All tool schemas are **strict**. agenterm does not expose a relaxed schema mode.
- Local function tools are registered with `strict_json_schema=True` and normalized via `ensure_strict_json_schema`.
- MCP tools are normalized via `convert_schemas_to_strict=True` before exposure as FunctionTools.
- Tool argument validation failures produce typed tool error outputs (persisted as tool facts) rather than silent coercion.

Plan tooling (local harness):

- `update_plan` validates the payload, enforces a single `in_progress` step, writes a plan snapshot into the local store, and returns a FunctionTool output envelope with the plan payload.
- `update_plan` rejects empty `steps` unless `allow_empty: true` is set (explicit clear).
- `get_plan` returns the latest persisted plan snapshot for the current session as a FunctionTool output envelope.
  - Payload fields: `plan_state`, `steps`, `explanation`, `revision`, `plan_created_at`, `plan_updated_at` (RFC3339).
- Transcript rendering detects update_plan tool outputs by `tool_call_id` and renders the stored plan snapshot without relying on in-memory state.

Dangerous tool set:

Danger is modeled as a **label** with **policy defaults** and **config overrides**.

Base default policy:

- A tool is considered **dangerous** when it can cause local side effects or
  call arbitrary remote tools without a human in the loop.
- Dangerous exposure rules:
  - **CLI `run`**: dangerous tools are dropped unless `--allow-dangerous` is provided.
  - **REPL**: dangerous tools are allowed (session is interactive), but approvals still apply to tool families that require them (shell/apply_patch/hosted MCP connector).
- Default dangerous set (tool refs):
  - `fn:shell`, `fn:apply_patch`, `fn:user:*`, `mcp:*`, `hosted:mcp:*`
  - `update_plan`, `get_plan`, `agent_run_report`, safe read‑only tools (`rg`, `fd`, `bat`, `tree`, `stat`),
    and `agent_run` are **client‑plane but safe by default** (no side effects).

Config overrides (`tools.dangerous`):

- `add`: tool refs to force‑mark as dangerous (even if hosted).
- `remove`: tool refs to force‑mark as safe (even if client‑plane).
- Overrides apply after the base defaults. Unknown tool refs are ignored.
  - Tool ref grammar:
    - tool keys (e.g., `hosted:openai:web_search`, `fn:shell`, `mcp:files`)
    - built-in names (`file_search`, `web_search`, `image_generation`, `shell`, `apply_patch`, `update_plan`,
      `get_plan`, `agent_run_report`, `steward`, `rg`, `fd`, `bat`, `tree`, `stat`, `agent_run`)
    - `fn:user:<name>` or `fn:user:*`
    - `hosted:mcp:<name>` or `hosted:mcp:*`
    - `mcp:<key>` or `mcp:*`

#### 1.7.1.1 Tool Portability Map (plane matrix)

Each tool capability is classified by plane and execution locality. This map is
authoritative for design and implementation.

Hosted tools (provider plane):

- `hosted:openai:file_search`, `hosted:openai:web_search`, `hosted:openai:image_generation`:
  - OpenAI plane: available as hosted tool types.
  - Gateway plane: **not available** (FunctionTools only).
  - Background runs: allowed **only** on OpenAI plane.

Built‑in FunctionTools (client plane):

- `fn:shell`, `fn:apply_patch`, `fn:update_plan`, `fn:get_plan`, `fn:agent_run_report`, `fn:steward`,
  `fn:rg`, `fn:fd`, `fn:bat`, `fn:tree`, `fn:stat`, `fn:agent_run`:
  - OpenAI plane: `shell`/`apply_patch` use native tool types; others are FunctionTools.
  - Gateway plane: available as FunctionTool wrappers only.
  - Background runs: **never** (client-plane tools are dropped).

User FunctionTools:

- `fn:user:<name>`:
  - OpenAI plane: available (FunctionTool).
  - Gateway plane: available (FunctionTool).
  - Background runs: **never**.

MCP connectors (provider-hosted):

- `hosted:mcp:<connector>`:
  - OpenAI plane: available when selected.
  - Gateway plane: **not available**.
  - Background runs: allowed **only** on OpenAI plane.

Client MCP servers:

- `mcp:<server_key>`:
  - OpenAI plane: available via MCP‑as‑FunctionTools bridge.
  - Gateway plane: available via MCP‑as‑FunctionTools bridge.
  - Background runs: **never**.

Tool bundles are plane‑agnostic declarations. Selection is filtered at runtime
by plane viability (hosted vs client) and background mode.

#### 1.7.1.2 FunctionTool portability wrappers (shell/apply_patch)

Gateway models use Chat Completions semantics; only FunctionTools are accepted.
To keep `shell` and `apply_patch` available on the gateway plane, agenterm wraps the
same local executors in FunctionTools with explicit JSON schemas and a stable
output envelope.

Vendor constraints:

- Function tool outputs are stringified unless they are explicit `input_text` /
  `input_image` / `input_file` structured outputs. agenterm therefore encodes tool
  results as JSON strings **after strict JSON validation** and rejects non‑JSON
  structured outputs for portability.
  - `.venv/lib/python3.14/site-packages/agents/items.py:430-470`
- FunctionTool implementations may return a structured tool output or a string
  representation; agenterm treats built-in tool outputs as JSON strings for
  stable parsing and truncation.
  - `.venv/lib/python3.14/site-packages/agents/tool.py:194-219`
- Function tool output items do **not** include the tool name (only `call_id`
  + `output`), so agenterm embeds the tool name inside its output envelope for
  transcript labeling.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_tool_call_output_item.py:19-33`
- Function tool call items do include the tool name (`name`) plus JSON args,
  which agenterm uses to label tool calls and render bounded details.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_tool_call.py:11-28`

Portable tool schemas (gateway plane):

- `shell` FunctionTool input:
  - `commands: list[str]` (required; non-empty)
  - `timeout_ms: int | None`
  - `max_output_length: int | None`
  - `cwd: str | None` (workspace‑relative override)
  - `description: str | None` (approval/audit label)
- `apply_patch` FunctionTool input:
  - `operation: {type: "create_file|update_file|delete_file", path: str, diff?: str}`
  - `diff` required for `create_file` / `update_file`.
  - `description: str | None` (approval/audit label)

Tool output envelope (function tools):

```json
{
  "schema_version": 1,
  "tool": "shell|apply_patch|update_plan|get_plan|rg|fd|bat|tree|stat|agent_run|agent_run_report",
  "ok": true,
  "truncated": false,
  "payload": {},
  "error": { "kind": "string", "message": "string", "details": {} }
}
```

- When `ok=true`, `error` is omitted and `payload` contains the tool result.
- When `ok=false`, `error` is required and `payload` may be empty.
- `truncated=true` indicates the tool output was clamped to `tools.output_max_chars`
  by the unified ToolOutputClamp stage at the tool boundary.
  - When clamped, `payload` is replaced with `{ "preview": "string" }`, where
    `preview` is a compact JSON string of the original payload truncated to fit.
- Pagination signals for tool result sets live in payload fields (for example,
  `has_more` + `next_offset`/`next_line`). Envelope `truncated` is reserved for
  output clamping only.

Tool output clamping (unified):

- A single ToolOutputClamp stage is applied to all FunctionTool outputs and MCP outputs.
- The clamp runs **once** at the tool boundary before outputs are stored or returned to the model.
- Tool-specific bounds (rg/fd/bat/tree/stat/shell) shape payloads but do not replace the global clamp.
- Implementation: `agenterm.engine.tool_output_clamp.ToolOutputClamp`.

Shell payload:

```json
{
  "commands": ["..."],
  "outputs": [
    {
      "command": "string",
      "stdout": "string",
      "stderr": "string",
      "outcome": { "type": "exit|timeout", "exit_code": 0 },
      "truncated": false
    }
  ],
  "max_output_length": 20000,
  "working_directory": "/abs/path"
}
```

Apply‑patch payload:

```json
{
  "operation": { "type": "create_file|update_file|delete_file", "path": "path" },
  "status": "completed|failed|null",
  "output": "string|null"
}
```

Transcript UX:

- Function tool **calls** are labeled by `ResponseFunctionToolCall.name`.
- Function tool **outputs** attempt to parse the output envelope; when present,
  the label is `tool`, and bounded details are rendered from the payload.

#### 1.7.1.3 Local CLI FunctionTools (rg / fd / bat / tree / stat)

agenterm ships a **local CLI** toolset that wraps external binaries and returns
structured JSON envelopes. These tools are bounded, non‑interactive, and
workspace‑confined. Missing binaries are treated as configuration errors with
an explicit install hint (brew install).

Tool keys:

- `fn:rg` (ripgrep search, safe)
- `fn:fd` (file discovery, safe)
- `fn:bat` (file read/preview, safe)
- `fn:tree` (directory tree, safe)
- `fn:stat` (file/directory stats, safe)

Input schemas (strict JSON):

`rg`:

```json
{
  "pattern": "string",
  "paths": ["string", "..."],
  "literal": false,
  "case_sensitive": false,
  "smart_case": false,
  "before": 0,
  "after": 0,
  "context": 0,
  "include_hidden": false,
  "no_ignore": false,
  "glob": ["string", "..."],
  "result_mode": "matches|files|count",
  "offset": 0,
  "limit": 200,
  "max_line_chars": 500
}
```

`fd`:

```json
{
  "pattern": "string|null",
  "paths": ["string", "..."],
  "max_depth": "int|null",
  "mode": "regex|glob|fixed",
  "type": "file|dir|symlink|any",
  "include_hidden": false,
  "no_ignore": false,
  "exclude": ["string", "..."],
  "offset": 0,
  "limit": 200
}
```

`bat`:

```json
{
  "path": "string",
  "start_line": 1,
  "limit_lines": 200,
  "max_bytes": 20000
}
```

`tree`:

```json
{
  "path": "string",
  "depth": 3,
  "pattern_glob": "string|null",
  "match_dirs": false,
  "include_hidden": false,
  "dirs_only": false,
  "gitignore": true
}
```

`stat`:

```json
{
  "paths": ["string", "..."],
  "include_lines": true
}
```

Output envelope (FunctionTool results):

```json
{
  "schema_version": 1,
  "tool": "rg|fd|bat|tree|stat",
  "ok": true,
  "payload": {},
  "error": { "kind": "string", "message": "string", "details": {} }
}
```

Payload shapes:

- `rg`:
  - `pattern: str`
  - `result_mode: str`
  - `matches: list[{path: str, line: int, column: int, text: str, context_before?: str, context_after?: str}]`
  - `files: list[str]` (files mode)
  - `counts: list[{path: str, count: int}]` (count mode)
  - `count_total: int` (count mode)
  - `page: {cursor_kind: str, cursor: int, limit: int, returned: int, has_more: bool, next_cursor: int|null}`
  - `coverage: {files_searched: int|null, files_matched: int, stats_complete: bool, stats_partial_reason: str|null}`
- `fd`:
  - `pattern: str|null`
  - `matches: list[str]` (workspace‑relative)
  - `page: {cursor_kind: str, cursor: int, limit: int, returned: int, has_more: bool, next_cursor: int|null}`
  - `coverage: {stats_complete: bool, stats_partial_reason: str|null}`
- `bat`:
  - `path: str` (workspace‑relative)
  - `lines: list[{line: int, text: str}]`
  - `bytes: int`
  - `total_lines: int`
  - `page: {cursor_kind: str, cursor: int, limit: int, returned: int, has_more: bool, next_cursor: int|null}`
- `tree`:
  - `root: str`
  - `nodes: list[{path: str, type: "file"|"dir", depth: int}]`
  - `tree: str`
  - `stats: {directories: int, files: int}`
- `stat`:
  - `results: list[{path: str, type: str|null, lines?: int, bytes?: int, modified?: str, mode?: str, entries?: int, files?: int, dirs?: int, total_lines?: int, total_bytes?: int}]`
  - `type` is the raw `stat` type label (OS-specific).

Behavior rules:

- Paths resolve against the workspace root; escapes and symlink paths are rejected.
- External CLI tools run without follow flags; directory traversal skips symlink entries.
- Output is bounded; paged payloads include a `page` object with cursor metadata.
- Missing paths return `error.kind=not_found` for the CLI tools (including `stat`).
- Tool outputs are stored as deterministic tool facts for replay.

#### 1.7.1.4 `agent_run` (ephemeral agent‑as‑tool)

`fn:agent_run` runs a **single‑run** (max_turns = `cfg.agent.max_turns`), **ephemeral** agent for delegation:

- Inputs are explicit and required: `model`, `instructions`, `input`.
- Runs with `max_turns=cfg.agent.max_turns` (tool-using delegation supported) and
  **no session turn history**.
- Uses the **delegate bundle** (`tools.agent_run.bundle`, default `research`),
  which is **delegate‑scope only** and not selectable by the main session.
  The default `research` bundle contains hosted `web_search`, `file_search`,
  and `image_generation` for targeted external retrieval and synthesis.
- Delegate bundles are validated to contain **hosted-only** tool keys.
- Hosted tools are **stripped** automatically when the model is non‑OpenAI.

Output contract:

- Returns a **summary envelope** to the caller (high‑signal only).
- Summary and report include `truncated: true` when any delegate tool output was
  paged (`has_more`) or clamped by the tool output clamp.
- Unsupported include values are dropped for delegated runs and recorded in
  `warnings` so the caller knows what changed.
- Persists the **full report** (inputs, outputs, usage, tool counts, response ids)
  to the artifacts vault and returns `report_id`.
- When exposed via MCP, the server returns the full report as structured output
  plus a minimal text summary to keep model noise low.

Summary envelope payload (FunctionTool output):

```json
{
  "schema_version": 1,
  "tool": "agent_run",
  "ok": true,
  "payload": {
    "summary": "string",
    "report_id": "string",
    "response_id": "string|null",
    "tool_counts": { "tool": 1 },
    "truncated": false,
    "warnings": ["string", "..."]
  },
  "error": { "kind": "string", "message": "string", "details": {} }
}
```

Persisted report payload (artifact JSON):

```json
{
  "schema_version": 1,
  "tool_call_id": "string",
  "trace_id": "string|null",
  "created_at": "RFC3339",
  "model": "string",
  "instructions": "string",
  "input": "string",
  "input_items": [{ "...": "..." }],
  "output_text": "string|null",
  "output_items": [{ "...": "..." }],
  "tools_available": ["fn:rg", "hosted:openai:web_search"],
  "tools_used": ["function:rg"],
  "tool_counts": { "tool": 1 },
  "truncated": false,
  "warnings": ["string", "..."],
  "usage": {
    "requests": 1,
    "input_tokens": 0,
    "input_cached_tokens": 0,
    "output_tokens": 0,
    "output_reasoning_tokens": 0,
    "total_tokens": 0
  },
  "response_id": "string|null",
  "response_ids": ["string"]
}
```

- `input_items` and `output_items` are serialized Responses input items derived from
  `ItemHelpers.input_to_new_input_list(...)` and `RunItem.to_input_item()`.
  Evidence: `.venv/lib/python3.14/site-packages/agents/items.py:134-143` and
  `.venv/lib/python3.14/site-packages/agents/items.py:397-408`.
- `tools_available` lists the tool keys resolved for the delegated agent after
  safety and plane filtering (delegate bundle only).
- `tools_used` lists the tool labels observed during the run (same keys as
  `tool_counts`, for quick glance without counts).
- `warnings` captures runtime adjustments (for example, dropped include values).
- `response_id` and `response_ids` come from the Agents run result responses.
  Evidence: `.venv/lib/python3.14/site-packages/agents/result.py:125-138` and
  `.venv/lib/python3.14/site-packages/agents/items.py:345-372`.
- `usage` is aggregated on the run context (`RunContextWrapper.usage`) and updated
  during execution via `context_wrapper.usage.add(...)`.
  Evidence: `.venv/lib/python3.14/site-packages/agents/run_context.py:9-25` and
  `.venv/lib/python3.14/site-packages/agents/run.py:1454-1468`.

#### 1.7.2 Tool Selection, Bundles & Gates

Tool exposure is a **selection-only plugging model**:

- agenterm ships a superset of tools (hosted tools + local tools + MCP).
- The config declares tool parameters and tool *availability*.
- The session/run selection (“plugging”) decides which tools are exposed to the model.

Build‑time tool spec:

`config.tools_catalog.build_tool_catalog_from_config(cfg)` returns:

- `tools_map: dict[str, ToolSpec]`
  - Keys encode capability families:
    - OpenAI hosted tools:
      - `hosted:openai:file_search`
      - `hosted:openai:web_search`
      - `hosted:openai:image_generation`
    - OpenAI hosted MCP connectors:
      - `hosted:mcp:<name>`
    - Built‑in FunctionTools:
      - `fn:shell` (macOS-only)
      - `fn:apply_patch`
      - `fn:update_plan`
      - `fn:get_plan`
      - `fn:agent_run_report`
      - `fn:steward` (agent‑as‑tool; snapshot/compaction delegation)
      - `fn:rg`
      - `fn:fd`
      - `fn:bat`
      - `fn:tree`
      - `fn:stat`
      - `fn:agent_run`
    - User FunctionTools:
      - `fn:user:<name>`
    - Client MCP servers:
      - `mcp:<server_key>`
- `bundles_map: dict[str, list[str]]`
  - Bundle name to resolved tool keys (composition + selectors applied).
  - Scope-filtered: main selection only sees `scope="main"` bundles.
- `default_bundles: list[str]`
  - Bundle names selected by default.
  - When empty, selection starts empty unless CLI flags explicitly provide bundles/keys.

CLI selection overrides (`agenterm run`):

- `--tools-bundle NAME...` and `--tool KEY...` (repeatable) explicitly set selection.
- If either flag is provided, default bundles are ignored and selection is **only**
  the specified bundles/keys.
- REPL does not accept these flags; it starts from config defaults and uses `/tools`
  to adjust selection.

MCP connector selection contract (provider-hosted):

- Each `AppConfig.mcp.connectors[*]` entry represents one provider-hosted MCP connector.
- Each entry is selectable via a tool key:
  - `hosted:mcp:<name>`
  - `<name>` is the `AppConfig.mcp.connectors[*].name` value.
- MCP connectors are **not** auto-selected from configuration; they are attached only when selected via:
  - `tools.bundles` / `tools.default_bundles`,
  - REPL `/tools add tool hosted:mcp:<name>`.

Vendor citations:

- Agents `HostedMCPTool` is a hosted tool surface with `name == "hosted_mcp"` and a typed `tool_config: Mcp` field:
  - `.venv/lib/python3.14/site-packages/agents/tool.py:301-320`
- OpenAI Responses `Mcp` tool config (remote MCP) requires `type: "mcp"` plus `server_label`.
  - Contract: **exactly one** of `server_url` (custom MCP server) or `connector_id` (service connector) must be provided.
  - Supported `connector_id` values (SDK-typed):
    - `connector_dropbox`
    - `connector_gmail`
    - `connector_googlecalendar`
    - `connector_googledrive`
    - `connector_microsoftteams`
    - `connector_outlookcalendar`
    - `connector_outlookemail`
    - `connector_sharepoint`
  - Other supported fields include: `authorization`, `headers`, `allowed_tools`, `require_approval`, `server_description`.
  - `allowed_tools` shape:
    - list of tool names, or
    - filter object `{read_only?: bool, tool_names?: list[str]}`
  - `require_approval` shape:
    - `"always" | "never"`, or
    - `{always?: {read_only?: bool, tool_names?: list[str]},
        never?: {read_only?: bool, tool_names?: list[str]}}`
  - `.venv/lib/python3.14/site-packages/openai/types/responses/tool_param.py:42-121`

MCP server selection (client-managed):

- MCP servers are selected via tool keys:
  - `mcp:<server_key>`
- Selecting an MCP server attaches it to `Agent(mcp_servers=[...])` and the agent
  will include discovered MCP tools each run (Agents contract; lifecycle managed
  by agenterm).
- MCP tools are exposed to the model as **function tools**, so their names must be valid OpenAI function names:
  - allowed characters: `a-z`, `A-Z`, `0-9`, `_`, `-`
  - max length: 64
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/shared_params/function_definition.py:14-19`
- The Agents SDK also requires MCP tool names to be **globally unique across selected servers** (it raises `UserError` on duplicates): `.venv/lib/python3.14/site-packages/agents/mcp/util.py:112-134`

MCP tool naming contract (agenterm):

- agenterm wraps each local MCP server after construction and rewrites tool names at the boundary so the model never sees duplicate or invalid names.
- Model-visible MCP tool names always begin with `mcp__`.
- Preferred readable form (used when it is already OpenAI-valid and within 64 chars):
  - `mcp__{server_key}__{tool_name}`
- Fallback (used when characters/length would violate the OpenAI function-name contract):
  - `mcp__{server_slug}_{server_hash}__{tool_slug}_{tool_hash}` (slugs truncated as needed to fit).
- Tool invocation is preserved:
  - The wrapper maps the rewritten name back to the original server-provided tool name before calling `call_tool`.
  - Server-side filtering (`tool_filter`) still operates on the server-provided names because filtering is applied inside the underlying Agents MCP server before the agenterm wrapper rewrites names.

MCP‑as‑FunctionTools bridge (agenterm):

- For each selected client-managed MCP server, agenterm builds a bridge that:
  - Calls `list_tools()` after connect (or from cache when enabled).
  - Emits one FunctionTool per MCP tool with:
    - name = rewritten MCP name (see naming contract above),
    - description = MCP tool description prefixed with the server key,
    - params schema = MCP `inputSchema` converted to strict JSON schema.
  - Invokes `call_tool` with the **original** MCP tool name and validated args.
- MCP `CallToolResult` returns a `content` list plus optional `structuredContent`, with `isError`
  indicating failures; agenterm preserves `structuredContent` inside its output envelope when present.
  - `.venv/lib/python3.14/site-packages/mcp/types.py:1363-1369`
- MCP tool outputs are serialized to a canonical JSON object string:

```json
{
  "schema_version": 1,
  "ok": true,
  "server_key": "string",
  "tool_name": "string",
  "truncated": false,
  "content": { "text": "string", "data": {} }
}
```

Error output:

```json
{
  "schema_version": 1,
  "ok": false,
  "server_key": "string",
  "tool_name": "string",
  "truncated": false,
  "error": { "kind": "string", "message": "string", "details": {} }
}
```

Output rules:

- `content.text` is always present on success; `content.data` is optional structured output (`JSONValue`).
- Outputs are truncated to `tools.output_max_chars` by the unified ToolOutputClamp stage; truncation
  sets `truncated=true` and preserves schema validity.
- Non‑JSON MCP structured content is rejected with a validation error; `content.data` must be JSONValue.
- Approvals are enforced using the same approval manager as other dangerous tools; rejected approvals return `ok=false` with `error.kind="approval_rejected"`.

`ToolSelection`:

```python
ToolSelection(
    selected_bundles: tuple[str, ...],
    selected_keys: tuple[str, ...],
    explicit_override: bool,
)
```

- Represents the **canonical** selection state (bundles + individual tool keys) for a session.

Resolving selection:

- `ToolCatalog` packages `tools_map`, `bundles_map`, and `default_bundles`.
- `ToolSelection` (bundles + keys + explicit_override) is interpreted against
  the catalog to produce the resolved list of `ToolSpec` entries.
- Delegate-only bundles are resolved separately for `agent_run` and are not part
  of the main `ToolCatalog` or `/tools` selection.
- Plane viability is validated before filtering:
  - Gateway plane (`gateway/...`) rejects any selection containing hosted tools.
- Runtime filters are then applied:
  - `hosted_mode` drops all client-plane tools (`fn:*`, `fn:user:*`, `mcp:*`).
  - `--allow-dangerous` (or equivalent) gates the dangerous set (see 1.7.1).

Runtime tool attachment:

- The engine attaches tools and MCP servers from the **resolved selection**:
  - Hosted tools are attached when selected (subject to viability; see below).
  - Local tools are attached when selected (subject to platform; `shell` is macOS-only).
  - Hosted MCP connectors are attached when their tool key is selected.
  - Client-managed MCP servers are connected/attached when their tool key is selected.
  - Function tools are attached when selected and registered in the local runtime.

Selection is **not applied by mutating config**. `AppConfig` remains declarative tool parameters; selection is the single knob that controls exposure.

Viability guardrails:

- Some selected tools may be **misconfigured** and therefore not attachable:
  - `file_search` requires a non-empty `tools.file_search.vector_store_ids`.
- Misconfigurations are surfaced in `/tools` and `/status` so users can correct config without guessing why a tool isn’t attached.

Session‑level tools gate:

- `tools_enabled` (persisted in `agenterm_sessions`, mirrored by `SessionState.tools.enabled`) is a separate gate:
  - If `SessionState.tools.enabled` is `False`:
    - The model sees **no tools**, regardless of selection.
  - If `SessionState.tools.enabled` is `True`:
    - Tool exposure follows the resolved selection (bundles + keys) after applying hosted/dangerous filters.

Dangerous tools and CLI vs REPL:

- Dangerous is a tool-policy (see 1.7.1); exposure requirements:
- **CLI `run`**:
  - Drops dangerous tools unless `--allow-dangerous` is provided.
  - With `--allow-dangerous`, dangerous tools are exposed; approvals are auto‑resolved (CLI `run` never prompts; see 1.11.3).
- **REPL**:
  - If a dangerous tool is selected (via bundles/keys) and `SessionState.tools.enabled` is `True`, it is exposed to the model (with inline approval prompts in `prompt` mode for tools that require approvals).
  - In REPL, `--approvals` only sets the initial approval mode; it does **not** add tools or bypass `ToolSelection` and the tools gate.

Background runs (`--background` or `run.background: true`):

- Background runs are provider-hosted; agenterm must not expose any **client-plane** tools.
- In background mode, the selected tool keys are filtered to:
  - `hosted:*` tools (OpenAI hosted tools and hosted MCP connectors)
  - and still subject to dangerous gating (`--allow-dangerous`) when a hosted connector is marked dangerous.
- In background mode, client-managed MCP servers are not attached.

#### 1.7.3 Shell Sandbox (macOS Seatbelt)

The shell tool runs commands inside a macOS Seatbelt sandbox enforced at OS level via `sandbox-exec`. This provides hard security guarantees that cannot be bypassed by command structure.

Availability:

- The shell tool is **macOS-only** because Seatbelt enforcement uses `sandbox-exec`.
- On non-macOS platforms, agenterm does **not** expose `fn:shell` in the tool catalog or default bundles.
  - Tool-catalog gating: `config.tools_catalog` uses `core.platform.is_macos()` to omit `fn:shell`.
  - Bundle gating: bundle expansion strips `fn:shell` on non-macOS so selection cannot fail due to an unsupported key.
  - Runtime gating: `engine.tool_builders.build_shell_tool(...)` returns `None` on non-macOS so `sandbox-exec` is never invoked.

**Security properties:**

| Property | Guarantee |
| --- | --- |
| Filesystem writes | ONLY under workspace root (cwd where `agenterm` launched) |
| Filesystem reads | Allowed everywhere (needed for binaries, libs, etc.) |
| Temp directories | Allowed (`/tmp`, `/private/var/folders`, `/private/tmp`) |
| Network | Configurable: `allow` or `deny` via `tools.shell.sandbox.network` |
| Process spawning | Allowed (child processes inherit sandbox) |
| Shell features | Full: pipes, redirection, chaining, subshells all work |
| Workspace escape | **Impossible** — enforced at OS level |

**Configuration:**

| Key | Type | Default | Semantics |
| --- | --- | --- | --- |
| `tools.shell.timeout_ms` | int | `60000` | Per-command timeout |
| `tools.shell.max_output_length` | int | `20000` | Output truncation limit |
| `tools.shell.env` | `Mapping[str, str]` \| `null` | `null` | Custom env vars merged with safe defaults |
| `tools.shell.sandbox.network` | `"allow"` \| `"deny"` | `"allow"` | Network access for sandboxed commands |

Shell invocations always register approvals for auditability; see 1.11 for how approvals are resolved in REPL (`prompt|auto`) and in CLI `run` (auto‑resolved, non‑interactive).

Shell execution (via `engine.shell_executor.run_shell_sandboxed`) generates a Seatbelt policy file at runtime with workspace confinement and executes via `sandbox-exec -f policy.sb sh -c "cmd"`.

Cancellation:

- Shell execution uses the shared cancellation token and subprocess runner to
  terminate the sandboxed process group when a run is cancelled so hard-cancels
  do not stall on long-running commands.

**Environment handling:**

Commands run with a filtered safe environment by default (not an empty environment). This mirrors the MCP SDK pattern (`.venv/lib/python3.14/site-packages/mcp/client/stdio/__init__.py:28-45,127`):

- **Safe defaults** (Unix): `HOME`, `LOGNAME`, `PATH`, `SHELL`, `TERM`, `USER`
- **Safe defaults** (Windows): `APPDATA`, `HOMEDRIVE`, `HOMEPATH`, `LOCALAPPDATA`, `PATH`, `PATHEXT`, `PROCESSOR_ARCHITECTURE`, `SYSTEMDRIVE`, `SYSTEMROOT`, `TEMP`, `USERNAME`, `USERPROFILE`

When `tools.shell.env` is:
- `null` (default): Uses safe defaults only
- `{...}` (mapping): Merges custom vars with safe defaults (`{**safe_defaults, **custom_env}`)

Shell functions (values starting with `()`) are filtered out as a security measure.

**Output truncation (coherence + cost):**

- The Agents SDK shell contract includes a max output length hint:
  - `ShellActionRequest.max_output_length` (`.venv/lib/python3.14/site-packages/agents/tool.py:417-424`)
  - `ShellResult.max_output_length` (`.venv/lib/python3.14/site-packages/agents/tool.py:409-415`)
- agenterm enforces output truncation in the host executor so that:
  - shell outputs remain bounded even when the model requests large output, and
- tool-heavy runs do not flood the Responses store and cause automatic truncation to drop conversational context in subsequent runs.
- The effective truncation budget is:
  - the per-call `ShellActionRequest.max_output_length` when provided, otherwise
  - `tools.shell.max_output_length` from config (`config.model.ShellToolConfig.max_output_length`, `src/agenterm/config/model.py:168-184`).

#### 1.7.4 Apply Patch Editor (Workspace-scoped)

The Agents SDK treats `apply_patch` as a host-defined editor surface:

- The tool holds an `ApplyPatchEditor` protocol and calls one of:
  - `create_file`
  - `update_file`
  - `delete_file`
  (`.venv/lib/python3.14/site-packages/agents/editor.py:33-47`)
- The tool itself is a thin wrapper around that editor:
  (`.venv/lib/python3.14/site-packages/agents/tool.py:461-470`)

agenterm implements `ApplyPatchEditor` with a single concrete editor:

- `engine.apply_patch_editor.WorkspaceEditor`:
  - Rooted at the workspace directory (`Path.cwd()` at process start).
  - Refuses any operation whose target path resolves outside that root (including symlink escapes).
  - Applies V4A diffs via the SDK helper and writes the resulting content to disk.
  - On diff parse or filesystem failures, returns `ApplyPatchResult(status="failed")` with a reason + hint and performs no partial writes.
  - Registers an approval before any mutation.

**Security properties:**

| Property | Guarantee |
| --- | --- |
| Filesystem writes | ONLY under workspace root; operations outside root raise `RuntimeError` |
| Symlink escapes | Blocked (paths are resolved before enforcing `relative_to`) |
| Platform | Cross-platform (Linux + macOS); no OS sandbox required |

**Approvals:**
- REPL: `apply_patch` operations always register approvals; default is `prompt` unless `/approvals auto` is set.
- CLI `run`: `apply_patch` is dangerous by default (overrideable) and is only exposed when `--allow-dangerous` is provided (see 1.11.3 for auto‑approval behavior).

**Config surface:**

- `tools.apply_patch` is an enable/disable mapping with no tunables; set it to `null` to disable the tool.
- REPL approval requests render the **full proposed diff** (with line numbers and add/remove styling)
  before approval when `repl.ux.verbosity != quiet`. This rendering is **unbounded** for the approval
  request event; it is intentionally suppressed in `quiet` mode.
- `apply_patch` tool outputs no longer append diff excerpts; approvals + `/last diff` are the audit surface.

#### 1.7.5 MCP Server Construction & MCP CLI

MCP server construction:

- MCP server objects are constructed from config by `engine.mcp_factory`, but lifecycle is owned by agenterm:
  - The Agents SDK requires callers to `connect()` MCP servers before attaching them to an Agent and to `cleanup()` them when finished (`.venv/lib/python3.14/site-packages/agents/agent.py:114-121`).
  - MCP servers are long-lived connections (they “remain connected until cleanup”): `.venv/lib/python3.14/site-packages/agents/mcp/server.py:46-65`.
  - Servers implement an async context manager that calls `connect()`/`cleanup()` (`__aenter__`/`__aexit__`): `.venv/lib/python3.14/site-packages/agents/mcp/server.py:243-249`.
  - `list_tools()` hard-fails if not connected: `.venv/lib/python3.14/site-packages/agents/mcp/server.py:293-301`.
  - `connect()` for client-session servers creates a `ClientSession(...)` and calls `session.initialize()` before exposing the session:
    `.venv/lib/python3.14/site-packages/agents/mcp/server.py:266-287`.
  - `list_tools()` delegates to `session.list_tools()` and reads `result.tools` (optionally via a cache):
    `.venv/lib/python3.14/site-packages/agents/mcp/server.py:304-318`.
  - The underlying MCP tool model (`mcp.types.Tool`) carries `description`, `inputSchema`, and optional `outputSchema`:
    `.venv/lib/python3.14/site-packages/mcp/types.py:1315-1346`.
  - MCP tool call results (`CallToolResult`) include `content: list[ContentBlock]`, optional `structuredContent`,
    and `isError`:
    `.venv/lib/python3.14/site-packages/mcp/types.py:1363-1370`.
  - `ContentBlock` variants include text blocks with `{type: "text", text: "..."}`:
    `.venv/lib/python3.14/site-packages/mcp/types.py:1026-1034`.

Canonical construction + lifecycle (single path):

- `engine.mcp_factory.build_mcp_servers(cfg)` (pure):
  - Reads `AppConfig.mcp.servers`.
  - For each configured server, constructs one of:
    - `MCPServerStdio`
    - `MCPServerSse`
    - `MCPServerStreamableHttp`
- `engine.mcp_pool.McpServerPool` (side-effectful):
  - Owns the lifecycle of the built MCP servers.
  - Connects all selected servers before the agent run begins.
  - Cleans up all servers when the run/session ends.
  - Supplies the connected server list to the agent (typically via `Agent.clone(mcp_servers=...)`).

MCP‑focused CLI subcommands (`agenterm mcp`):

- `status`
  - Show MCP connection status summary (shared snapshot builder with REPL `/mcp status`).
  - `--format json` emits the canonical success/error envelope with `resource: "mcp.status"`.
  - REPL `/mcp status` probes configured servers from `cfg.mcp.servers` and emits
    a text table (server, transport, status, tool counts, error preview) plus totals.
- `servers`
  - List configured MCP servers (type, key, transport).
- `tools`
  - List discovered tools grouped by server.
- `validate`
  - Validate connectivity and configuration for each MCP server.
- `inspect`
  - Dump MCP tools and metadata to JSON for inspection.
- `serve`
  - Run agenterm as an MCP server to expose local FunctionTools (FastMCP).

#### 1.7.5.1 MCP Server Exposure (FastMCP)

agenterm can act as an MCP server to expose **local FunctionTools** to external MCP clients.
We build the server on **FastMCP** and use its async lifespan hook to manage
config, tool selection, and approvals.

Server scope:

- Exposes **only** FunctionTools (`fn:*` and `fn:user:*`).
- Hosted tools (`hosted:*`) and client MCP servers (`mcp:*`) are **never** exposed.
- `fn:steward` is excluded because it requires an active session context.

Lifecycle + transport:

- FastMCP uses a lifespan async context manager; agenterm supplies one to construct
  server state (config, tool registry, approvals, workspace root) and to cleanup
  any resources at shutdown.
  - `.venv/lib/python3.14/site-packages/mcp/server/fastmcp/server.py:78-143`
- The CLI drives FastMCP’s run loop using the configured transport (`stdio`, `sse`,
  or `streamable_http`), so server startup remains explicit and operator‑controlled.
  - `.venv/lib/python3.14/site-packages/mcp/server/fastmcp/server.py:747-771`
- MCP exposure is **opt‑in**: `mcp.expose.enabled=true` is required, and the
  server only starts when `agenterm mcp serve` is invoked.
- FastMCP provides **no built‑in auth**; non‑stdio transports must be protected
  by network binding or an external reverse‑proxy/auth layer.

Selection + safety:

- Tool selection is resolved via the canonical bundle/keys system, then filtered
  to `fn:*`/`fn:user:*` only.
- Dangerous tools are dropped unless `mcp.expose.allow_dangerous=true`; when
  allowed, approvals are auto‑resolved and still audited.

Tool execution contract:

- FastMCP `call_tool` handlers return **unstructured** content, **structured** content, or
  **both** (tuple). The lowlevel server maps this into `CallToolResult` with optional
  `structuredContent`.
  `.venv/lib/python3.14/site-packages/mcp/server/fastmcp/server.py:336-346`,
  `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:493-568`.
- The MCP exposure server returns a minimal `TextContent` summary plus structured
  output for **all** tools (required when `outputSchema` is defined).
- For standard tools, the structured output is the `FunctionToolOutputEnvelope`
  object; for `agent_run`, structured output is the full report with a minimal
  text summary to keep model noise low while exposing full details to MCP clients.
- Validation is enabled at the lowlevel server (`validate_input=True`), so malformed tool
  arguments are rejected before dispatch based on each tool’s `inputSchema`:
  `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:485-525`.
- Tool failures (unknown tool, tool exceptions, or envelopes with `ok=false`) are mapped to
  `isError=True` by raising a FastMCP `ToolError` with the envelope text, which the lowlevel
  server converts into an error `CallToolResult` containing a `TextContent` payload:
  `.venv/lib/python3.14/site-packages/mcp/server/lowlevel/server.py:460-466`.

#### 1.7.5.2 MCP-as-FunctionTools bridge (gateway plane)

Gateway models cannot use hosted tool types, so MCP servers must be bridged into
**FunctionTools** at run time using the Agents SDK MCP utilities.

Canonical path (single, explicit):

1) Build connected MCP servers via `McpServerPool` (namespaced, then wrapped).
2) Wrap servers with `BridgeMcpServer` to enforce approvals and output envelopes.
3) Convert MCP tool definitions into FunctionTools using `MCPUtil.get_all_function_tools(...)`.
4) Merge the resulting FunctionTools into the agent’s tool list and clear `mcp_servers`
   so ChatCompletions only sees FunctionTools.

Evidence + constraints:

- `MCPUtil.get_all_function_tools(...)` enumerates per-server tools and rejects duplicate
  tool names across servers. `.venv/lib/python3.14/site-packages/agents/mcp/util.py:113-135`.
- MCP tools are converted into FunctionTools with JSON schema derived from `inputSchema`
  (and optional strict-schema conversion). `.venv/lib/python3.14/site-packages/agents/mcp/util.py:155-179`.
- MCP tool invocation prefers structured content when `use_structured_content` is true, which
  is how the bridge returns the MCP output envelope. `.venv/lib/python3.14/site-packages/agents/mcp/util.py:213-216`.

#### 1.7.6 Guardrails Integration

Guardrails are configured via `AppConfig.guardrails`:

- `guardrails.load_modules: list[str]` (optional)
- `guardrails.input: list[str]`
- `guardrails.output: list[str]`

Integration:

- `core.guardrails_loader`:
  - Imports built-in guardrails shipped with agenterm.
  - Imports modules listed in `guardrails.load_modules` so their registration runs at import time.
  - Raises `ConfigError` on import failures (fail fast before any model calls).
- `core.guardrails_registry` maps guardrail names to implementations.
- `engine.run.build_run_config`:
  - Ensures guardrails are loaded (built-ins + configured modules).
  - Resolves configured names via `core.guardrails_registry`.
  - Attaches input and output guardrails to the `RunConfig` so that Agents enforces them per run.

Built-in guardrails:

- `no_secrets_input` (input guardrail): blocks obvious credential-like strings in user input.

External citations (vendor/runtime):

- Agents guardrails are functions wrapped into `InputGuardrail` / `OutputGuardrail` objects:
  - `.venv/lib/python3.14/site-packages/agents/guardrail.py:71-131`
- When an input guardrail trips (`tripwire_triggered=True`), the engine raises `InputGuardrailTripwireTriggered`:
  - `.venv/lib/python3.14/site-packages/agents/exceptions.py:78-89`

#### 1.7.7 Tracing

Tracing configuration (in `AppConfig.run`):

- `trace_enabled`
- `trace_id`
- `group_id`
- `trace_metadata`
- `trace_include_sensitive_data`

CLI and REPL control:

- CLI flag:
  - `--trace on|off` — master tracing toggle (overrides config for this run)
  - `--trace ID:GROUP:key=val,...` — consolidated trace configuration (also enables tracing)
- REPL command:
  - `/trace [show|clear|on|off]`

The engine propagates tracing metadata into `RunConfig` and disables tracing when `trace_enabled` is `False`.

Evidence (vendor/runtime):

- Agents `RunConfig.tracing_disabled` controls per-run tracing:
  - `.venv/lib/python3.14/site-packages/agents/run.py:183-235`

#### 1.7.8 Local Tool Contracts

##### 1.7.8.1 Tool Description Contract

FunctionTool descriptions and input schemas are shown directly to models and
must carry the usage guidance for each tool.

Requirements:

- The tool description states what the tool does and when to use it.
  - `.venv/lib/python3.14/site-packages/agents/agent.py:405-434`
- The description summarizes required inputs, defaults, output shape, and
  error kinds in concise text so the tool is usable without extra prompt
  scaffolding.
- Input schemas include a root description plus per-field descriptions.
  Optional fields document defaults; path fields say workspace-relative;
  approval labels are called out for shell/apply_patch.
- Tool text and schemas match runtime behavior; update them in the same change
  set as behavior changes.

Evidence:

- FunctionTool description + JSON schema are the LLM-facing definition and are
  normalized under strict schema rules.
  - `.venv/lib/python3.14/site-packages/agents/tool.py:194-224`

Local FunctionTools emit **typed payloads** inside the standard FunctionTool envelope.
Payloads are JSON-safe and deterministic; pagination never advertises continuation without
a cursor.

Shared pagination shape (bounded list tools):

- `page.cursor_kind`: `"offset"` (list paging) or `"line"` (line paging).
- `page.cursor`: starting offset or start line.
- `page.limit`: requested limit.
- `page.returned`: number of items returned in the payload list.
- `page.has_more`: `true` **only** when `page.next_cursor` is non‑null.
- `page.next_cursor`: cursor for the next page (`offset` or `line`), else `null`.

`rg` (search):

- Ordered deterministically by file path (`--sort=path`) and then by line/column.
  `vendor:ripgrep:14.1.1:rg --help`
- `result_mode`:
  - `"matches"` → `matches: [{path, line, column, text, context_before?, context_after?}]`
  - `"files"` → `files: [path, ...]`
  - `"count"` → `counts: [{path, count}]` plus `count_total`
- `coverage` object:
  - `files_searched: int | null` (from `rg` stats when available).
  - `files_matched: int` (may be partial when `stats_complete=false`).
  - `stats_complete: bool`
  - `stats_partial_reason: str | null` (e.g., `result_cap`, `files_mode_no_stats`, `count_mode_no_stats`, `stats_unavailable`).
- Count mode uses `--count-matches` with `-H` (with filename). `vendor:ripgrep:14.1.1:rg --help`

`fd` (discovery):

- Supports `max_depth` (maps to `fd --max-depth`). `vendor:fd:10.3.0:fd --help`
- `matches: [path, ...]` with `page` metadata.
- `coverage.stats_complete=false` with `stats_partial_reason="result_cap"` when results hit
  the cap.

`bat` (preview):

- `total_lines` is always reported for disambiguation.
- `start_line` beyond EOF is an `invalid_input` error (`reason="out_of_range"`).

`tree` (directory inspection):

- `pattern_glob` is a glob applied via `tree -P`; `match_dirs` enables `--matchdirs`.
  `vendor:tree:2.2.1:tree --help`
- `nodes: [{path, type: "file"|"dir", depth}]` plus `stats` derived from nodes (no summary
  parsing).
- `tree` contains the human-readable tree rendering with `--noreport`.

`stat`:

- Missing paths return `ok=false` with `kind="not_found"` (no `exists=false` rows).

`update_plan` / `get_plan`:

- Payload fields:
  - `plan_state: "missing" | "active" | "cleared"`
  - `steps`, `explanation`, `revision`
  - `plan_created_at`, `plan_updated_at` (RFC3339)
- `plan_state` is `"missing"` when no snapshots exist, `"cleared"` when the latest
  snapshot has zero steps, otherwise `"active"`.
- `plan_created_at` is the first snapshot timestamp in the current active series
  (or the clear timestamp when state is `"cleared"`). `plan_updated_at` is the
  latest snapshot timestamp.
- `update_plan` enforces a single `in_progress` step and supports explicit clearing with
  `steps: []` + `allow_empty: true`.

`agent_run_report`:

- Input: `report_id`.
- Output: `report_id` + `report` (schema `AGENT_RUN_REPORT_SCHEMA`).

------

### 1.8 Sessions & Persistence

#### 1.8.1 Agents Session & SQLite Store

Every `run` or REPL session uses an Agents `Session`:

- Implementation:
  - Always `AgentermSQLiteSession` (agenterm wrapper around Agents `AdvancedSQLiteSession`) in this architecture.
- Storage:
  - Backed by a single SQLite file located at `config.paths.store_path()`.
- Store schema policy:
  - agenterm owns a schema version table (`agenterm_schema`) inside the same SQLite file.
  - If the stored schema version differs from the expected version, agenterm fails
    fast with a `ConfigError` that instructs the operator to delete the local
    store file (and WAL/SHM companions) before retrying. agenterm does not delete
    or migrate stores automatically.
- Features:
  - Full session turn history (stored in Agents tables).
  - Conversation branching via `branch_id`:
    - Current branch default: `"main"`.
  - Per‑turn usage and tool usage tables (for token counts and tool call counts).
  - agenterm‑owned per‑request token ledger (for full usage breakdown, including compaction requests).

agenterm uses the Agents session as the canonical record of SDK turns; the CLI metadata tables augment it with agenterm‑specific metadata. The Agents runner persists **each completed turn** by calling `session.add_items(input_list + new_items_as_input)`; agenterm relies on that per‑turn commit behavior so completed turns survive even if a later turn in the same run is cancelled. In‑flight turn outputs are captured separately in the turn‑attempt ledger and always replayed into the next run input (see §1.8.10).

#### 1.8.2 Run Status Ledger (`agenterm_runs`)

agenterm records a per‑run status row for diagnostics and crash recovery.

Schema (agenterm‑owned; meta store only):

```sql
CREATE TABLE IF NOT EXISTS agenterm_runs (
    run_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    run_number INTEGER NOT NULL,
    status TEXT NOT NULL
        CHECK (status IN ('running', 'completed', 'failed', 'cancelled', 'timeout')),
    trace_id TEXT,
    response_id TEXT,
    error_json TEXT,
    branch_turn_start INTEGER,
    branch_turn_end INTEGER,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(session_id, branch_id, run_number),
    FOREIGN KEY (session_id, branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE
);
```

Column semantics:

- `run_id`:
  - Unique identifier for a **run attempt** (UUID string).
- `session_id` / `branch_id`:
  - Scope for the run (branch defaults to `"main"`).
- `run_number`:
  - Monotonic counter per `(session_id, branch_id)` independent of SDK turn numbers.
  - Every run attempt consumes a number, even if it fails or is cancelled.
- `status`:
  - `running` → `completed` on success.
  - `running` → `failed` on terminal errors.
  - `running` → `timeout` when the stream idle timeout fires.
  - `running` → `cancelled` when a user cancellation is observed (response id recorded only if available).
- `trace_id`:
  - Correlation id for tracing/diagnostics.
- `response_id`:
  - Last provider `response_id` for successful runs (if available).
- `error_json`:
  - JSON‑encoded `ErrorEnvelope` for failed/timeout runs.
  - `null` for successful and cancelled runs.
- `branch_turn_start` / `branch_turn_end`:
  - SDK `branch_turn_number` range committed by the run.
  - Recorded after completion; `null` when no new turns were committed.
- `started_at` / `updated_at`:
  - Timestamp for run start and last status update.

Behavior:

- Insert a `running` row before executing a run.
- Update to a terminal status after the run completes or fails.
- Once a run is `cancelled`, later status updates are ignored so cancellation
  remains terminal.
- Record `branch_turn_start/end` after commit so the run can be mapped back to SDK turns.
- If the process crashes or is interrupted, the row remains `running` and provides a post‑mortem breadcrumb.

#### 1.8.3 `agenterm_sessions` Metadata Table

In addition to the Agents tables, agenterm maintains a small metadata table in the same SQLite database:

```sql
CREATE TABLE IF NOT EXISTS agenterm_sessions (
    session_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    cwd TEXT NOT NULL,
    config_path TEXT,
    model TEXT NOT NULL,
    tools_enabled INTEGER NOT NULL,
    trace_id TEXT,
    group_id TEXT,
    head_branch_id TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

Column semantics:

- `session_id`:
  - Logical identifier for the session (used by CLI and REPL).
  - Format: UUID (v4) string.
- `kind`:
  - Session kind. Allowed values:
    - `run` — foreground one-shot runs.
    - `background` — runs submitted with `--background` (server-side execution) or when `run.background` default is true.
    - `repl` — interactive REPL sessions.
- `cwd`:
  - Working directory from which the session was created.
- `config_path`:
  - Path to the `config.yaml` used, if any.
- `model`:
  - Effective model identifier for the session.
- `tools_enabled`:
  - Integer representation of whether tools are enabled (treated as boolean).
- `trace_id` / `group_id`:
  - Tracing identifiers for the session.
- `head_branch_id`:
  - The active branch for this session.
  - Used as the default branch for CLI/REPL attaches when no explicit branch id is provided.
  - `created_at` / `updated_at`:
  - Timestamps for session creation and last update.

Branch metadata table (`agenterm_branch_meta`):

```sql
CREATE TABLE IF NOT EXISTS agenterm_branch_meta (
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('main', 'fork', 'agent', 'compaction', 'snapshot')),
    title TEXT,
    pinned INTEGER NOT NULL CHECK (pinned IN (0, 1)),
    created_reason TEXT,
    parent_branch_id TEXT,
    fork_run_number INTEGER,
    agent_name TEXT NOT NULL,
    agent_path TEXT,
    agent_sha256 TEXT,
    store_enabled INTEGER NOT NULL CHECK (store_enabled IN (0, 1)),
    last_response_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, branch_id),
    FOREIGN KEY (session_id) REFERENCES agenterm_sessions(session_id) ON DELETE CASCADE
);
```

- `kind` captures why the branch exists (main, fork from run, agent switch, compaction snapshot, summary snapshot).
- `created_reason` carries a short freeform string for UI/tooling (e.g., `agent_switch`, `manual_compaction`).
- `parent_branch_id` / `fork_run_number` define lineage when a branch is created from another branch.
- `agent_name` / `agent_path` / `agent_sha256` capture the effective agent on that branch.
- `store_enabled` is the branch-scoped provider persistence preference (does not affect local replay).
- `last_response_id` tracks the most recent provider response id for optional compaction/inspection.

Plan snapshots table (`agenterm_plan_snapshots`):

```sql
CREATE TABLE IF NOT EXISTS agenterm_plan_snapshots (
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    steps_json TEXT NOT NULL,
    explanation TEXT,
    trace_id TEXT,
    tool_call_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, branch_id, revision),
    FOREIGN KEY (session_id, branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE
);
```

- Each call to `update_plan` appends a new snapshot row with `revision` incremented per session.
- `steps_json` is a JSON-encoded array of `{step, status}` items.

#### 1.8.4 Session Store (`store.session.*`)

The `store.session` package owns session persistence and metadata; engine/workflow layers import from here (no persistence logic remains in `engine`):

- Modules:
  - `store/session/models.py` — dataclasses and callbacks (`SessionMetadata`, `DEFAULT_SESSION_INPUT_CALLBACK`).
  - `store/schema.py` — store schema versioning, table creation, and fail-fast-on-mismatch.
- `store/session/repo.py` — session metadata CRUD (`list_session_metadata`, `get_session_metadata_row`, `update_session_head`, `delete_session_metadata`).
- `store/branch/repo.py` — branch metadata CRUD and provider settings updates (`get_branch_meta`, `list_branch_meta`, `update_branch_store`, `update_branch_agent`).
- `store/branch/service.py` — branch lifecycle helpers (create from head/turn, snapshot/compaction branch creation, delete + ledger cleanup).
- `store/session/factory.py` — unified session factory for run/repl/background that binds an `AgentermSQLiteSession` and resolves the active branch; also exposes `session_db_path`.
  - `store/session/agenterm_session.py` — `AgentermSQLiteSession` wrapper that persists large artifacts to disk and scrubs base64 from session writes.
  - `store/session/usage.py` — usage persistence (`store_run_usage`); persistence failures are surfaced as warnings (never silently swallowed).
  - `store/plan/repo.py` — plan snapshot persistence (`insert_plan_snapshot`, `get_latest_plan_snapshot`, `get_plan_snapshot_by_call_id`).
- Responsibilities:
  - Single path to create/attach sessions for run and REPL surfaces.
- Maintain `agenterm_sessions` + `agenterm_branch_meta` alongside Agents tables with branch‑scoped provider settings.
  - Provide a single stateless session input callback for RunConfig wiring.

#### 1.8.5 Session Lifecycle & Branching

Branching support:

- **Head = (session_id, branch_id)**; the head branch is persisted in `agenterm_sessions.head_branch_id`.
- `AdvancedSQLiteSession` stores conversation structure with `branch_id` and per-branch turn numbers.
- agenterm exposes branch operations (CLI + REPL) backed by SDK branching primitives and `agenterm_branch_meta`.
- Branch metadata is authoritative for:
  - agent identity (instructions),
  - provider persistence settings (`store_enabled`) and last response id, and
  - lineage (`parent_branch_id`, `fork_run_number`).
- Switching branches updates `head_branch_id`, switches the SDK session branch, and rehydrates config/provider settings from branch metadata.
- Branch creation rules (single policy):
  - create‑from‑head inherits the parent branch provider settings and last response id.
  - create‑from‑run rewinds `last_response_id` to the last response id of the prior run (when available).
  - compaction branches set `last_response_id` to the compaction response id when provider storage
    is enabled (OpenAI plane only).
  - snapshot branches set `last_response_id` to the Steward task response id when provider storage
    is enabled and a response id is available.
  - If the current branch has no `message_structure` rows yet, agenterm does **not** create a new branch (SDK branch existence is validated against `message_structure`). Agent/instructions changes mutate the current branch metadata in place until history exists.
- Token ledger rules:
  - create‑from‑head and create‑from‑run clone `agenterm_request_usage` rows for inherited runs so per‑branch token totals remain accurate.
- snapshot/compaction branches do **not** clone prior ledger rows; they only persist the snapshot task
    request under the new branch.

#### 1.8.6 Agent Branches (agenterm‑owned)

agenterm treats the effective **agent instructions** as a branch invariant.

Rationale:

- Session coherence depends on stable instruction framing.
- OpenAI compaction is instruction‑sensitive; compaction calls must use the same effective agent instructions as normal Responses turns.
- Responses instructions are not carried forward when `previous_response_id` is used, so agenterm supplies the effective instructions on every request and stores agent identity per branch.

When the active agent changes (e.g. REPL `/agent <NAME>`):

- agenterm creates a **new branch** from the current head (copying conversation structure) and switches head to it.
- The new branch inherits the parent branch’s `last_response_id` for optional compaction/inspection workflows.
- The branch metadata is updated with the new agent identity (name/path/sha256) so instructions are always sent explicitly.

This avoids resending full history at the switch moment and preserves the parent branch intact.

#### 1.8.7 Per‑Request Token Ledger (agenterm‑owned)

The Agents SDK and Responses API expose token usage **per request**:

- Responses usage fields:
  - `usage.input_tokens`
  - `usage.input_tokens_details.cached_tokens`
  - `usage.output_tokens`
  - `usage.output_tokens_details.reasoning_tokens`
- `usage.total_tokens`

agenterm persists these per‑request records in an agenterm‑owned SQLite table so that:

- REPL status bars can show local context percent (when `model.context_window` is set) without parsing transcripts.
- `agenterm session runs` can show run totals derived from underlying request entries.
- Compaction requests (`/responses/compact`) are tracked alongside normal responses.

The token ledger is intentionally limited to **provider‑returned** categories (no local tokenization,
no per‑item heuristics).

Token counting policy (budgeting + packing):

- Always prefer **provider‑returned usage** for each request (OpenAI Responses usage, gateway usage objects).
- For streaming runs, enable `stream_options.include_usage=true` on providers that require it to return usage.
- Preflight input token counting uses provider endpoints when available:
  - OpenAI: `client.responses.input_tokens.count` (Responses input token counting endpoint).
- When token counts are unavailable, agenterm falls back to conservative, local **character budgets**:
  - Default context window = **128k tokens** (≈ **450k characters**).
  - Character budget is enforced for packing; no local tokenizer is used.

Missing usage behavior:

- Agents `ModelResponse` requires a `Usage` object; usage fields default to 0.
  - `.venv/lib/python3.14/site-packages/agents/items.py:344-350`
- `Usage` normalizes missing token detail fields (cached/reasoning) to 0.
  - `.venv/lib/python3.14/site-packages/agents/usage.py:12-107`
- Streaming runs construct `Usage()` when a response lacks usage.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1453-1464`
- agenterm persists the resulting zero-valued usage entries and treats them as
  **unknown** for packing, relying on the configured budget policy instead.

Definitions (avoid “integral vs differential” confusion):

- **Request**: one provider API call (one “response” object returned by the Responses API).
- **Turn**: one AI invocation inside a run (SDK definition). Turns map 1:1 to requests.
- **Run**: one user prompt processed by agenterm; runs may include multiple turns/requests.
- **Aggregated usage** (cost signal): sums tokens across all requests in a run/session.
- **Per-request usage** (context-window signal): preserves input token peaks; the most useful scalar is typically:
  - `input_tokens` of the **last request** in the last completed run (best available signal for “current context size”),
  - and/or the **max** `input_tokens` across requests in that run.

Evidence (Agents supports per-request breakdown in multiple ways):

- The aggregated `agents.usage.Usage` carries `request_usage_entries` for request-by-request breakdown. Evidence:
  `.venv/lib/python3.14/site-packages/agents/usage.py:34-89`.
- The Agents run result also exposes per-request `raw_responses` where each entry has its own `usage`. Evidence:
  `.venv/lib/python3.14/site-packages/agents/result.py:40-55`.

Schema (owned by agenterm; distinct from Agents tables):

```sql
CREATE TABLE IF NOT EXISTS agenterm_request_usage (
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN ('response', 'compaction', 'steward')),
    run_number INTEGER NOT NULL,
    request_index INTEGER NOT NULL,
    model TEXT NOT NULL,
    previous_response_id TEXT,
    response_id TEXT,
    requests INTEGER NOT NULL,
    input_tokens INTEGER NOT NULL,
    input_cached_tokens INTEGER NOT NULL,
    output_tokens INTEGER NOT NULL,
    output_reasoning_tokens INTEGER NOT NULL,
    total_tokens INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, branch_id, kind, run_number, request_index),
    FOREIGN KEY (session_id, branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE
);
```

Run numbers and request indexing:

- `run_number` is assigned per `(session_id, branch_id)` before execution and never reused.
- For normal runs (`kind="response"`), `request_index` matches the index of the corresponding
  `RunResultBase.raw_responses` entry for that run.
- For compactions (`kind="compaction"`) and Steward tasks (`kind="steward"`), `request_index` increments
  within the same `run_number` so multiple requests remain uniquely addressable.
- Request-usage persistence is idempotent: writes to the same `(session_id, branch_id, kind, run_number, request_index)`
  update the existing row with the latest usage values instead of failing.

#### 1.8.8 Artifacts Vault (agenterm‑owned)

Some Responses item types can embed large binary payloads (base64). The primary
example for agenterm is hosted image generation:

- The Responses output item `ImageGenerationCall.result` is a base64-encoded
  image payload.
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_item.py:34-47`
- The Agents runner persists *all* turn items to the session store as:
  `input_list + new_items_as_input`, and does not account for any
  `session_input_callback` transformations.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/run.py:1979-2002`
- `ImageGenerationCall` is included in `ToolCallItemTypes`, so it is persisted
  into the Agents session tables by default.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/items.py:224-233`

Problem:

- If agenterm naively stores `image_generation_call.result` base64 inside the Agents
  SQLite session tables, `history.sqlite3` becomes a binary blob store.
- This creates:
  - poor disk locality and slow session operations, and
  - unacceptable UX for local turn history replay where session turn history is replayed.

Design:

- Artifacts are first-class objects:
  - They are **always** persisted to disk when produced.
  - They outlive sessions/threads (deleting a thread does not delete artifacts).
  - Content hashing deduplicates on-disk storage; multiple sources may point to the
    same artifact file when bytes match.
- Storage:
  - Single per-user root directory (same root as config + data):
    - `~/.agenterm/`
  - Artifact files live under:
    - `~/.agenterm/artifacts/`
  - Artifact metadata is indexed in the meta store:
    - `~/.agenterm/store.sqlite3`
- Session hygiene (keep the session DB small):
  - agenterm intercepts session writes and strips large base64 payloads:
    - When persisting an `image_generation_call` item with a base64 `result`,
      agenterm writes decoded bytes to the artifact vault and replaces `result` with
      `null` before calling into `AdvancedSQLiteSession.add_items(...)`.
    - If persistence is skipped (invalid base64 or unknown format), agenterm keeps the
      base64 in SQLite rather than dropping data.
  - Concurrency safety:
    - Persistence is idempotent by `(source_type, source_id)`.
    - If multiple writers race, the loser discards its temporary on-disk file
      and returns the existing record.
    - If a matching `content_hash` already exists, agenterm reuses the existing
      artifact file path instead of writing duplicate bytes.
- Local session turn history replay (keep images visible in UI only):
  - agenterm rehydrates image bytes from the artifact vault **only** for UI
    rendering (REPL transcript, artifact commands, inspection).
  - Model input never re‑injects base64 payloads; history packing and compression
    operate on the stored `result=null` items.
    - The rehydrated base64 is never persisted back into SQLite.

Schema (agenterm-owned; meta store `store.sqlite3`):

```sql
CREATE TABLE IF NOT EXISTS agenterm_artifacts (
    artifact_id TEXT PRIMARY KEY,          -- uuid4
    kind TEXT NOT NULL,                    -- "image" (extensible)
    mime TEXT NOT NULL,                    -- "image/png" | "image/jpeg" | "image/webp"
    path TEXT NOT NULL,                    -- absolute path into ~/.agenterm/artifacts
    size_bytes INTEGER NOT NULL,
    content_hash TEXT NOT NULL,            -- sha256 of artifact bytes
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_type TEXT NOT NULL,             -- "image_generation_call" (extensible)
    source_id TEXT NOT NULL,               -- image_generation_call.id
    session_id TEXT,                       -- attribution only (no FK)
    UNIQUE(source_type, source_id)
);
```

UX surfacing:

- The REPL transcript treats artifacts as first-class UI objects:
  - Images render as Image Cards with metadata + durable path and inline previews
    in iTerm2, bounded to a configured max width/height.
    - Image cards are resolved from `image_generation_call.id` → `agenterm_artifacts` after the turn completes, so they still render even when streamed items omit base64 `result` (session hygiene strips blobs at write time).
  - `/artifacts` and `/last` allow navigation and retrieval.
- CLI:
- `agenterm artifacts list|show|open|agent-run` exposes artifact metadata and retrieval.
  - `agenterm artifacts list` supports `--session-id` (filters `agenterm_artifacts.session_id`) and `--trace-id` (joins `agenterm_sessions` on session id).
- Non-interactive CLI (`agenterm run`) surfaces artifacts in JSON mode so scripts can
  capture them deterministically without parsing human output.

------

#### 1.8.9 Run Event Ledger (agenterm‑owned)

agenterm persists **every Responses stream event** emitted by the Agents runner so
we retain maximum expressivity across providers.

Principles:

- The event ledger is append‑only and preserves the exact event sequence.
- Run event persistence is queued and flushed in batches (`RunEventBatcher`) to
  avoid blocking the stream consumption loop; batching honors
  `RUN_EVENT_BATCH_MAX_SIZE` and preserves order.
- Events are persisted for **every request** in a run (SDK turns map 1:1 to requests).
- For non‑streaming responses, agenterm records a synthetic `response.completed`
  event with the final output payload.
- Unknown event types are preserved with their original `type` string; no remapping.
- `raw_provider_payload` is always null because Agents stream events expose only the
  Responses‑shaped event objects.
- Large binary payloads are moved to the artifact vault and replaced with
  artifact references in the event payload.
- `event_seq` is agenterm’s per‑request monotonic index; provider
  `sequence_number` remains in the payload for provenance.
- Gateway Responses events may include a placeholder `response_id="__fake_id__"`;
  it is preserved as received.

Event envelope (JSON‑safe, stored in SQLite):

```json
{
  "schema_version": 1,
  "trace_id": "uuid",
  "ts": "RFC3339",
  "event": {
    "type": "response.output_text.delta",
    "plane": "openai|gateway",
    "model": "openai/gpt-4.1",
    "response_id": "resp_123",
    "request_index": 0,
    "payload": {},
    "raw_provider_payload": null
  }
}
```

Schema (agenterm‑owned; meta store `store.sqlite3`):

```sql
CREATE TABLE IF NOT EXISTS agenterm_run_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    run_number INTEGER NOT NULL,
    request_index INTEGER NOT NULL,
    event_seq INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    response_id TEXT,
    model TEXT NOT NULL,
    event_json TEXT NOT NULL,              -- JSON-encoded RunEventEnvelope
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(session_id, branch_id, run_number, request_index, event_seq)
);
```

Artifact reference shape (stored in event payloads wherever base64 blobs would appear):

```json
{
  "artifact_id": "uuid",
  "kind": "image",
  "mime": "image/png",
  "path": "/abs/path",
  "size_bytes": 12345,
  "source_type": "image_generation_call|image_generation_partial",
  "source_id": "call_id[:partial_index]",
  "session_id": "uuid|null"
}
```

Uses:

- `inspect` reads the event ledger for full‑fidelity replay and debug.
- History packing can rebuild input items from stored events without losing
  tool call detail, reasoning deltas, or streaming structure.

------

#### 1.8.9 Run Event Durability & Spool

Run event persistence is **durable** even when the SQLite meta store is locked:

- Every observed stream event is queued for persistence via `RunEventBatcher`.
- If the DB write fails, agenterm writes a spool file under
  `~/.agenterm/artifacts/run_spool/` and marks the run status with:
  - `recovery_state="needs_replay"`
  - `recovery_spool_path=<spool file>`
- The replay tool ingests the spool and sets `recovery_state="replayed"`.

Spool files are JSON objects with a schema version, run identity, and the
serialized event envelopes (same shape as `agenterm_run_events.event_json`).

#### 1.8.10 Turn Attempt Ledger (agenterm‑owned)

agenterm records **in‑flight turn output items** while a run is still executing so it can
replay them after a cancellation or crash. This is separate from:

- **Session history** (canonical, completed turns only).
- **Run event ledger** (raw streaming events, full fidelity but not structured for reuse).

Turn attempt goals:

- Capture tool calls, tool outputs, reasoning items (including encrypted/signature fields),
  and message output items **as input‑compatible items**.
- Mark them as **unseen_by_model** because the next turn never received them.
- Clear them automatically once a turn is fully committed.
- If persistence fails (DB lock), write a spool file and mark the run as
  `recovery_state="needs_replay"` so the attempt can be restored later.

Sources:

- Per‑turn persistence uses `session.add_items(input_list + new_items_as_input)`:
  `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016`
- LiteLLM adapters emit reasoning content and thinking blocks that are converted into
  Responses reasoning items with `encrypted_content` signatures:
  `.venv/lib/python3.14/site-packages/agents/extensions/models/litellm_model.py:563-617`
  `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:96-130`
- Reasoning items can be re‑interpreted into thinking blocks during input conversion:
  `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:557-583`

Schema (agenterm‑owned; meta store `store.sqlite3`):

```sql
CREATE TABLE IF NOT EXISTS agenterm_turn_attempts (
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    run_number INTEGER NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'cancelled')),
    cancel_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, branch_id, run_number),
    FOREIGN KEY (session_id, branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS agenterm_turn_attempt_items (
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    run_number INTEGER NOT NULL,
    item_seq INTEGER NOT NULL,
    item_type TEXT NOT NULL,
    item_json TEXT NOT NULL,
    seen_by_model INTEGER NOT NULL CHECK (seen_by_model IN (0, 1)),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, branch_id, run_number, item_seq),
    FOREIGN KEY (session_id, branch_id, run_number)
        REFERENCES agenterm_turn_attempts(session_id, branch_id, run_number)
        ON DELETE CASCADE
);
```

Behavior:

- Attempt rows are created on the first event of a run and reset whenever a **new turn** begins.
- Items are appended in stream order (`item_seq` monotonic per attempt).
- When a **new turn** begins, the prior attempt is cleared (its items are already persisted
  in the session history).
- When a run is **cancelled**, the active attempt is marked `cancelled` and retained.
- Cancelled attempts are consumed and replayed on the next run, then deleted after use.

#### 1.8.11 History Packing & Compression (agenterm‑owned)

agenterm builds every model input from local session turn history items plus the new input.
History packing enforces deterministic ordering, context budgets, and optional compression
while preserving tool call coherence.

Canonical item shape:

- The packing pipeline operates on `ResponseInputItemParam` items (messages,
  tool calls, tool outputs, reasoning items, compaction items, MCP items, etc.).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_item_param.py:504-531`
- Model output items are convertible to input items via `RunItemBase.to_input_item`
  (Pydantic `model_dump`), so replaying output items is valid history.
  - `.venv/lib/python3.14/site-packages/agents/items.py:134-142`

Pipeline (single canonical flow):

1) **Load history items + turn structure** for the active branch:
   - Source of truth: `agent_messages` joined with `message_structure`.
   - Turn boundaries use `message_structure.branch_turn_number`.
2) **Compose candidate input** as `history_items + new_input_items`.
3) **Compute budget**:
   - `context_window` comes from config; when unset, default is **128k tokens**
     (≈ **450k characters**).
   - If `model.max_tokens` is set, agenterm reserves that output budget from the
     input budget.
     - `.venv/lib/python3.14/site-packages/agents/model_settings.py:99-100`
   - Prefer provider token counting endpoints when available; otherwise fall
     back to character budgets (no local tokenizer).
   - OpenAI Responses `truncation` defaults to disabled; agenterm defaults to
     `truncation="disabled"` and hard-fails on oversized input when truncation
     is disabled rather than silently truncating server-side.
     - vendor:openai:responses-create:https://platform.openai.com/docs/api-reference/responses/create
4) **Evaluate compression** before dropping:
   - Compute a **percent‑based** compression threshold from `model.context_window`
     (default 128k) and `compression.threshold_percent`.
   - If the candidate window exceeds the threshold **or** the input budget,
     evaluate compression per `compression.trigger` (ask/auto).
   - Compression operates on **history before the current input** and creates
     snapshot/compaction branches per `compression.strategy`.
5) **Drop** only when explicitly allowed:
   - If compression is unavailable/declined and `compression.drop_policy` allows,
     drop **whole turns** from oldest → newest until the window fits.
   - Prefix items (`branch_turn_number <= 0`) are treated as pinned and are
     not split or reordered.
6) **Hard fail** when the window still exceeds budget and dropping is disallowed
   (or insufficient). The error includes model id, budget, and computed size.

Implementation contract:

- Packing is implemented as a per‑run `SessionInputCallback` built by
  `engine.history_packing.build_session_input_callback(...)` and injected into
  `RunConfig.session_input_callback` when a session is present.
- The callback:
  - Does **not** rehydrate artifact-backed payloads for model input.
  - Groups history by vendor `message_structure.branch_turn_number` and treats
    items with `branch_turn_number <= 0` (non-user items before the first user
    message) as a pinned prefix.
  - Does **not** use JSON heuristics for turn boundaries or prefix detection.
  - Evaluates compression **before** dropping and runs the configured compression
    policy inline when approved.
  - Emits `info>` lines when compression starts/finishes (when a run emit hook is
    present) and aborts compression immediately when a cancellation token is set.
  - Drops whole turns only when `compression.drop_policy` allows (or approvals grant it).
- Token budgeting:
  - OpenAI plane prefers `responses.input_tokens.count` with the candidate
    input items + resolved agent instructions.
    - `.venv/lib/python3.14/site-packages/openai/resources/responses/input_tokens.py:126-148`
  - Gateway plane (or input-token failures) falls back to conservative character
    budgets using JSON-serialized item length + instructions length.

Attachments in history:

- Input items reference **file IDs or URLs only** by default; inline data URLs are forbidden unless
  explicitly enabled by attachment policy.
- Image inputs accept `file_id` or `image_url` (data URLs only when explicitly allowed).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_image_param.py:11-33`
- File inputs accept `file_id` or `file_url`; `file_data` is only permitted when
  inline data URLs are explicitly enabled by policy.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_file_param.py:11-25`
- Local images/PDFs are uploaded to provider storage when `supports_file_id` is true;
  otherwise they must be supplied as URLs or inline data URLs (if allowed).
- Gateway (LiteLLM) lanes convert Responses inputs to Chat Completions, which require:
  - `input_image.image_url` (file IDs rejected), and
  - `input_file.file_data` (file URLs/IDs rejected).
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:281-295`
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:322-333`
- Packing validates attachment sizes before sending; oversized attachments hard‑fail
  with a typed error that cites the limit and offending artifact.

Artifact rehydration policy (packing):

- Packing never rehydrates artifact payloads.
- UI and inspection surfaces may rehydrate for display, but never for model input.

Steward task contracts (agent + strict JSON schema):

- The Steward agent is exposed to the primary agent via `Agent.as_tool(...)`,
  producing a FunctionTool that runs the Steward agent as a tool call.
  - Evidence: `.venv:.venv/lib/python3.14/site-packages/agents/agent.py:405-515`
- The tool input is a single JSON string (`input`) passed to the Steward agent.
  - Evidence: `.venv:.venv/lib/python3.14/site-packages/agents/agent.py:405-455`
- FunctionTools default to strict JSON schema generation from the function
  signature; for `Agent.as_tool`, this is a strict **string** schema.
  - Evidence: `.venv:.venv/lib/python3.14/site-packages/agents/tool.py:710-761`
- Agents accept `AgentOutputSchemaBase` directly; when `agent.output_type` is a
  custom schema object, the runner uses it verbatim instead of wrapping.
  - Evidence: `.venv:.venv/lib/python3.14/site-packages/agents/run.py:1904-1910`
- Steward task payloads are parsed from that string and validated against the
  task input schemas (below) before execution.

Steward snapshot contracts (summary + compaction):

- Steward always emits strict JSON schema payloads; no downgrade to
  `json_object` or free‑form text is allowed.
- Steward snapshot schemas are normalized with strict JSON rules so every
  object has `additionalProperties: false` before being sent to the provider.
  - Evidence: `.venv/lib/python3.14/site-packages/agents/strict_schema.py:18-120`
- OpenAI Steward models (`openai/...`) use Responses `text.format` with
  `type="json_schema"` and `strict=true`.
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_text_config_param.py:13-36`
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_format_text_json_schema_config_param.py:11-46`
- Gateway Steward models (`gateway/...`) use LiteLLM `response_format` with
  `type="json_schema"` and `strict=true`.
  - Evidence: vendor:litellm:json-schema:https://docs.litellm.ai/docs/completion/json_mode
- agenterm does not preflight model support for JSON schema; provider errors are
  surfaced and recorded in the Steward task ledger.
- Strict JSON schema mode only supports a subset of JSON Schema, so Steward
  schemas stay within the supported core types.
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_format_text_json_schema_config_param.py:40-46`
  - Evidence: vendor:google:gemini-structured-output:https://ai.google.dev/gemini-api/docs/structured-output
- Ollama uses `format` to request JSON or JSON schema; LiteLLM maps
  `response_format` into the provider-specific format.
  - Evidence: vendor:ollama:structured-outputs:https://ollama.com/blog/structured-outputs

Summary snapshot schema (agenterm‑owned):

Summary payload (`MemorySnapshotV1`) — strict JSON schema, all fields required
and `additionalProperties: false` enforced at every object level:

```json
{
  "schema_version": 1,
  "summary": "string",
  "decisions": ["string"],
  "constraints": ["string"],
  "open_items": ["string"],
  "files": [
    { "path": "string", "note": "string" }
  ]
}
```

Compaction snapshot schema (agenterm‑owned):

Compaction payload (`CompactionSnapshotV1`) — strict JSON schema, all fields required:

```json
{
  "schema_version": 1,
  "items": []
}
```

Rules:

- `items` is a list of Responses‑style input items (`ResponseInputItemParam`).
- Compaction input items are validated against the OpenAI input item union;
  invalid `web_search_call` entries (missing required action fields) are
  dropped before persistence and compaction execution.
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_item_param.py:504-531`
  - Evidence: `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_web_search_param.py:1-83`
- Empty `items` is invalid; compaction must return at least the compaction item.

Steward task input schemas (agenterm‑owned):

Snapshot task input (`StewardSnapshotTaskInputV1`):

```json
{
  "schema_version": 1,
  "session_id": "string",
  "branch_id": "string",
  "turn_range": { "start": 1, "end": 10 },
  "model": "string|null"
}
```

- `turn_range` is optional or null; when omitted/null, summarize the full branch history.
- `model` overrides the Steward model for this task only.

Compaction task input (`StewardCompactionTaskInputV1`):

```json
{
  "schema_version": 1,
  "session_id": "string",
  "branch_id": "string",
  "model": "string",
  "instructions": "string|null",
  "input_items": []
}
```

- `input_items` is a list of Responses‑style input items (`ResponseInputItemParam`).

Steward task storage (agenterm‑owned):

```sql
CREATE TABLE IF NOT EXISTS agenterm_steward_tasks (
    task_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,            -- source branch id
    snapshot_branch_id TEXT,            -- populated on completion
    kind TEXT NOT NULL CHECK (kind IN ('snapshot', 'compaction')),
    trigger TEXT NOT NULL CHECK (trigger IN ('auto', 'manual', 'tool')),
    status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'completed', 'failed', 'cancelled')),
    model TEXT NOT NULL,
    input_json TEXT NOT NULL,
    trace_id TEXT,
    response_id TEXT,
    error_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (session_id, branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE,
    FOREIGN KEY (session_id, snapshot_branch_id)
        REFERENCES agenterm_branch_meta(session_id, branch_id)
        ON DELETE CASCADE
);
```

Storage rules:

- `input_json` is canonical JSON (sorted keys, no extra whitespace) validated
  against the task input schema on insert.
- `snapshot_branch_id` is set when the task completes successfully.
- The Steward task creates a **new branch** (`kind="snapshot"` or `kind="compaction"`) seeded with
  the snapshot items; head switches to the new branch.
- Only the most recent snapshot branch (head) is used for packing; older branches remain for
  inspection and auditability.

Snapshot rendering (canonical):

- **Summary snapshots** render into a single `ResponseOutputMessageParam` item with role `assistant`,
  which is valid input history for both Responses and Chat Completions conversion.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_message_param.py:15-33`
  - `.venv/lib/python3.14/site-packages/agents/models/chatcmpl_converter.py:337-432`
  - The output message `id` uses the Responses `msg_` prefix so provider validation accepts it.
  - Content is one `output_text` part containing:
    - `memory_snapshot_json:` prefix on its own line.
    - The canonical JSON string of `MemorySnapshotV1` (via `core.json_codec.dumps_compact`,
      `sort_keys=True`) on the next line.
- **Compaction snapshots** are replayed verbatim as their stored `items` list.

Character‑budget heuristic (when token counts are unavailable):

- Convert each input item to canonical JSON using:
  - `core.json_codec.dumps_compact(item, sort_keys=True)`
- `item_chars = len(canonical_json)`; `turn_chars = sum(item_chars for items in turn)`.
- `context_chars = floor(context_window_tokens * 3.5)`; when `context_window` is unset,
  use **450_000** chars (128k tokens × 3.5).
- If `model.max_tokens` is set, reserve `max_tokens * 3.5` chars from the budget.
- Data URLs (images/PDFs) are counted at full length; no compression or truncation is applied
  during budgeting.

Artifact rehydration policy (packing):

- Packing never rehydrates artifact payloads; it only replays stored input items.
- UI and inspection surfaces may rehydrate artifacts for display, but never for model input.
- Attachment shape validation happens at ingest (before packing) and fails fast if the
  active provider lane cannot accept the resolved input form.

History packing is **local-stateful** and never relies on provider truncation.

------

#### 1.8.12 Agent Run Lifecycle Specification (`.local/lifecycle.md`)

agenterm defines a single lifecycle contract for runs and turns across main and
tool runs. The full specification is in `.local/lifecycle.md`.

Lifecycle invariants:

- trace_id and group_id are opaque strings; the lifecycle never parses or
  normalizes their formats.
- When tracing is disabled, the SDK uses NoOpTrace with trace_id "no-op".
- A trace is created only when no current trace exists; nested runs share the
  existing trace.
- trace_metadata is stored in the meta DB and must be JSON-safe.
- RunError is the canonical error envelope; run_error_summary_ref points to a
  sanitized error artifact.
- response_id_kind captures placeholder response ids like "__fake_id__".
- REPL diagnostics use prompt_toolkit run_in_terminal or patch_stdout and never
  emit raw print output.

Vendor grounding (citations):

- .venv/lib/python3.14/site-packages/agents/run.py:225
- .venv/lib/python3.14/site-packages/agents/run.py:343
- .venv/lib/python3.14/site-packages/agents/run.py:702
- .venv/lib/python3.14/site-packages/agents/_run_impl.py:1500
- .venv/lib/python3.14/site-packages/agents/tracing/traces.py:128
- .venv/lib/python3.14/site-packages/agents/tracing/traces.py:170
- .venv/lib/python3.14/site-packages/agents/tracing/traces.py:215
- .venv/lib/python3.14/site-packages/agents/tracing/processor_interface.py:1
- .venv/lib/python3.14/site-packages/agents/exceptions.py:20
- .venv/lib/python3.14/site-packages/agents/result.py:361
- .venv/lib/python3.14/site-packages/openai/_exceptions.py:80
- .venv/lib/python3.14/site-packages/litellm/exceptions.py:20
- .venv/lib/python3.14/site-packages/agents/models/fake_id.py:1
- .venv/lib/python3.14/site-packages/agents/models/multi_provider.py:54
- .venv/lib/python3.14/site-packages/prompt_toolkit/application/run_in_terminal.py:23
- .venv/lib/python3.14/site-packages/prompt_toolkit/patch_stdout.py:200

------

### 1.9 Execution Model & Store Semantics

#### 1.9.0 Store Backend (async, multi‑process safe)

- agenterm uses **two SQLite files**:
  - `~/.agenterm/history.sqlite3` — vendor session tables (`agent_sessions`,
    `agent_messages`, `message_structure`, `turn_usage`) used by Agents.
  - `~/.agenterm/store.sqlite3` — agenterm metadata tables (`agenterm_*` only).
- All agenterm‑owned tables are accessed through async `aiosqlite` connections via the
  `store.async_db.AsyncStore` facade (meta DB only).
- The agenterm meta store uses a **single** connection per `(event loop, db path)`:
  - One `aiosqlite.Connection` and worker thread per loop/path; no per‑operation
    open/close churn.
  - Store operations are serialized behind an op lock to prevent cross‑op
    interleaving on a shared connection.
  - Schema initialization is invoked explicitly via `store.schema.ensure_store_schema`
    (repo ops gate on it) and executes on the same single connection.
  - Evidence: each `aiosqlite.Connection` owns a worker thread and queues ops
    (`.venv/lib/python3.14/site-packages/aiosqlite/core.py:34-138`,
    `.venv/lib/python3.14/site-packages/aiosqlite/core.py:443-462`).
- `AsyncStore` configures WAL mode, `busy_timeout`, and bounded retry/backoff (from
  `RetriesConfig.store`) so multiple CLI processes can share the meta DB safely.
- The agenterm store schema includes:
  - `agenterm_schema` (schema version),
  - `agenterm_sessions` (session metadata),
  - `agenterm_runs` (per-run status ledger),
  - `agenterm_run_events` (per-request Responses event ledger),
  - `agenterm_turn_attempts` / `agenterm_turn_attempt_items` (in-flight turn recovery ledger),
  - `agenterm_request_usage` (per‑request usage ledger),
  - `agenterm_steward_tasks` (Steward task ledger),
  - `agenterm_plan_snapshots` (plan tool snapshots),
  - `agenterm_artifacts` (artifact registry),
  - `agenterm_model_registry` (provider‑scoped model registry cache for model validation).

#### 1.9.1 RunConfig Construction

The engine builds a `RunConfig` via:

```python
engine.run.build_run_config(
    cfg: AppConfig,
    *,
    workflow_name: str,
    model_id: str | None = None,
) -> RunConfig
```

Inputs:

- `cfg`:
  - Effective `AppConfig` for this invocation.
- `workflow_name`:
  - Logical name of the workflow (e.g. `"run"`, `"repl"`) for tracing and analytics.
- `model_id`:
  - Optional model override used when running Steward tasks or agent‑as‑tool
    invocations. When set, the engine uses this model for route resolution and
    sets `RunConfig.model` to override the agent’s model.
  - Evidence: `.venv:.venv/lib/python3.14/site-packages/agents/run.py:183-190`

RunConfig contents:

- `model_settings`
  - Derived from `cfg.to_model_settings()`, including fixed `response_include`.
- Guardrails:
  - Input/output guardrails resolved from `cfg.guardrails` using `core.guardrails_registry`.
- Tracing:
  - `trace_enabled`, `trace_id`, `group_id`, `trace_metadata`, `trace_include_sensitive_data` from `cfg.run`.
- Session behavior (local‑stateful only):
  - agenterm always supplies a `session_input_callback` when session memory is enabled
    (Agents requires it for list inputs).
    - `.venv/lib/python3.14/site-packages/agents/run.py:1953-1991`
  - The callback is responsible for packing/replaying session turn history within budgets
    (see §1.8.11).
  - Edges never send `previous_response_id` for normal runs.
  - Provider `store` does **not** affect local replay; it only controls server‑side persistence for retrieval/inspection.
  - Session persistence uses the original input, not the callback output.
    - `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016`
  - Turn‑attempt items from cancelled runs are always injected **before** the new user input
    and the attempt ledger is cleared after consumption.

Local continuity:

- agenterm always replays local session turn history (bounded by packing) and preserves encrypted reasoning/compaction items for every provider plane.

#### 1.9.2 Execution Modes: `run_streamed` vs `run_once`

Engine execution APIs:

- `def run_streamed(agent, input_items, *, opts: RunExecOptions) -> RunResultStreaming`
  - Default path for CLI and REPL runs.
  - Behavior:
    - Uses Agents streaming execution.
    - Returns a `RunResultStreaming` handle.
    - Events are consumed by REPL/CLI with live accessory labels (depending on render mode), and final output is rendered once complete.
- `async def run_once(agent, input_items, *, opts: RunExecOptions) -> RunResult`
  - Reserved for background submissions:
    - Sets `background=True` in `ModelSettings.extra_args` when `opts.background` is True.
    - Forces provider-side persistence (`store=True`) so results can be inspected later, without changing local continuity or packing behavior.

`RunExecOptions` dataclass:

```python
@dataclass(frozen=True)
class RunExecOptions:
    cfg: AppConfig
    workflow_name: str = "agenterm run"
    session: Session | None = None
    background: bool = False
    model_id: str | None = None
    max_turns: int | None = None
```

Common behavior:

- Both `run_streamed` and `run_once`:

  - `max_turns` uses `opts.max_turns` when provided; otherwise it falls back to
    `cfg.agent.max_turns`.

  - Streaming runs enforce `cfg.run.timeout_seconds` as a **stream idle** timeout:
    - The timer resets on any stream event.
    - On idle timeout, agenterm cancels the streaming run and records a `timeout` run status.
  - Background (non‑streaming) runs do not enforce a client‑side timeout.

  - Map underlying errors:

    - `APIError`
    - `APIConnectionError`
    - `APITimeoutError`
    - `AgentsException`

    into agenterm error types:

    - `PipelineError` / `AgentermError`

  - This allows the edge layer to render concise, user‑facing error messages.

Evidence (vendor/runtime):

- Agents `RunResultStreaming.cancel` supports immediate vs graceful cancellation, and callers are expected to continue draining `stream_events()` after cancellation:
  `.venv/lib/python3.14/site-packages/agents/result.py:254-339`.
- Agents `RunResultStreaming.stream_events()` awaits an internal event queue until completion or cancellation (no built‑in timeout):
  `.venv/lib/python3.14/site-packages/agents/result.py:300-339`.

OpenAI client ownership (single shared client):

- agenterm configures Agents to use a single shared OpenAI client via `agents.set_default_openai_client`
  and reuses that same `AsyncOpenAI` instance for all direct OpenAI calls (compaction and background inspection).
- The shared client uses a shared async HTTP client (connection pooling), matching the Agents OpenAIProvider idiom.
  - `.venv/lib/python3.14/site-packages/agents/models/openai_provider.py:19-25`
  - `.venv/lib/python3.14/site-packages/agents/models/openai_provider.py:71-81`
- When `/config key` updates `OPENAI_API_KEY`, agenterm resets the shared OpenAI client so subsequent runs use the new credentials.

#### 1.9.3 Store Flag & Response IDs (no remote continuity)

`ModelConfig.store` controls **provider persistence only**; it does **not** control
continuity. agenterm is **local‑stateful only** and never uses `previous_response_id`
for normal runs.

Policy:

- **Edges (CLI and REPL)**:
  - `--store/--no-store` overrides `model.store` for the invocation and is
    persisted to `agenterm_branch_meta.store_enabled` when a session is attached.
  - There is no `/continuity` command in the target UX.
- **Engine**:
  - Always builds inputs from local session turn history (bounded by packing).
  - Never sends `previous_response_id` on standard runs.
  - Preserves `reasoning.encrypted_content` and compaction items in local session turn history
    and resends them on subsequent runs (local‑stateful replay).

Compaction and retrieval:

- **OpenAI plane**:
  - Compaction is **stateless**: send explicit `input` items to
    `/responses/compact` and persist the compacted window locally.
- **Gateway plane**:
  - Compaction is **stateless** when the selected route explicitly supports it
    (`supports_compaction=true`) and provides the required base URL + API key;
    otherwise compaction is unavailable.

Branch metadata:

- `store_enabled` persists the operator’s preference for provider storage.
- `last_response_id` records the most recent response id for **inspection/compaction**
  only (not used to build the next run).

Rationale:

- Providers are treated as **stateless executors**; all continuity is local.
- Encrypted reasoning/compaction items are the only provider‑specific state, and
  agenterm persists and replays them explicitly.

Schema repair:

- agenterm performs **explicit migrations** for known schema changes (including the history/meta DB split).
- If the on-disk schema does not match any known migration path, agenterm fails fast with a
  typed error that explains how to recover.
- Migration records are stored in the meta DB so the split is applied exactly once.

#### 1.9.4 Compaction (`/responses/compact`) and Compression

OpenAI provides a native compaction endpoint for Responses:

- `client.responses.compact(input=..., instructions=<agent_instructions>, model=...)`
  - agenterm never uses `previous_response_id`; compaction is always stateless.
  - Compaction params include `model`, `input`, `instructions`, and optional `previous_response_id`;
    there is no `store` flag.
    - `.venv/lib/python3.14/site-packages/openai/types/responses/response_compact_params.py:13-133`
  - The OpenAI compaction endpoint expects a **native** model name (e.g., `gpt-5.2`), not the
    `openai/<model>` namespace used in agenterm config. agenterm must strip the `openai/` prefix
    before calling `/responses/compact`.
    - `.venv/lib/python3.14/site-packages/openai/resources/responses/responses.py:1526-1715`
  - Compaction is gated by provider capabilities; non‑supporting routes must refuse compaction.
  - Provider persistence (`store`) is defined on Responses create calls, not compaction.
    - `.venv/lib/python3.14/site-packages/openai/types/responses/response_create_params.py:194-195`

**Important:** the compaction result is a `response.compaction` object (not a normal `response`) but it still has a
stable `id`. agenterm treats the compaction `id` as an **inspection/ledger** identifier only; it does **not** chain
continuity via `previous_response_id` in the local‑stateful design. The compacted `output` is persisted locally and
replayed as explicit `input` for subsequent runs.

- The compaction call returns a `CompactedResponse` with `object="response.compaction"` and its own `id`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/compacted_response.py:13-33`
  - vendor:openai:responses-compact-object:https://platform.openai.com/docs/api-reference/responses/compacted-object
- A normal Responses response has `object="response"` and its `id` is the value accepted by `previous_response_id`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response.py:59-103`
  - vendor:openai:responses-compact:https://platform.openai.com/docs/api-reference/responses/compact
- The compaction response includes an `output` list that ends with a single compaction item.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/compacted_response.py:23-27`
- The compaction item contains `encrypted_content` and has `type="compaction"`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_compaction_item.py:11-23`
- The API reference examples show passing `compacted_response.output` as the next `input`
  (stateless replay), but do not explicitly mention chaining via `previous_response_id`.
  - vendor:openai:responses-compact-object:https://platform.openai.com/docs/api-reference/responses/compacted-object

History snapshot item schema (post-compaction replay):

- The compaction `output` list is typed as `ResponseOutputItem`, which includes `ResponseOutputMessage` (assistant message)
  plus the terminal `ResponseCompactionItem`.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_item.py:183-201`
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_message.py:16-36`
- When replaying snapshot history into the next turn, items must conform to `ResponseInputItemParam`
  (this is what Agents session memory persists and what is sent back as `input=[...]` on the next request).
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_item_param.py:504-531`
- **Assistant messages** in `input=[...]` must use the `ResponseOutputMessageParam` shape:
  - Their `content[]` entries must have `type in {"output_text", "refusal"}`.
  - It is invalid to place `{"type":"input_text", ...}` inside an assistant message; the API rejects it.
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_message_param.py:13-36`
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_text_param.py:117-129`
  - `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_refusal_param.py:10-17`
- Agents merges session turn history with new input by default when no callback is provided,
  but agenterm always supplies a `session_input_callback` for packing.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1953-1986`
- Agents raises a user error when list inputs are used with session memory but no
  `session_input_callback` is supplied.
  - `.venv/lib/python3.14/site-packages/agents/run.py:1964-1971`

SDK parsing caveat (load-bearing for compaction correctness):

- The OpenAI Python SDK defaults to **non-strict response parsing**. Unless `strict_response_validation` is enabled,
  responses are parsed via a “loose construction” path.
  - `.venv/lib/python3.14/site-packages/openai/_base_client.py:607-632`
- In this mode, discriminated unions are resolved opportunistically:
  - If the discriminator is missing/unknown, the SDK attempts to construct each union variant and returns the first
    one that does not error during construction.
  - Construction does not validate required fields; missing required fields become `None`.
  - `.venv/lib/python3.14/site-packages/openai/_models.py:494-569`
  - `.venv/lib/python3.14/site-packages/openai/_compat.py:93-105`
- Practical implication (inferred from the above SDK behavior + the compaction output item type union):
  - `CompactedResponse.output` is typed as `ResponseOutputItem` and includes a single `"message"` variant
    (`ResponseOutputMessage`), even though a compaction snapshot fundamentally needs to represent **user** messages
    containing `input_*` parts.
  - When the server returns `"message"` items whose `content[]` contains `{"type":"input_text", ...}` (and/or other
    `input_*` parts), the SDK can construct those content entries as `ResponseOutputText` instances with
    `type="input_text"` and `annotations=None`.
  - Downstream code must therefore **not** branch solely on Python class (`isinstance`) or assume that “required”
    SDK fields are non-`None`; it must branch on the `type`/`role` strings and defensively normalize optional/missing
    lists.

Correctness constraint (agent instructions):

- When agent instructions are supplied for normal Responses turns, the **same effective agent instructions** must be supplied to compaction calls.
  - Otherwise, compaction may produce a state that does not reflect the policy and behavior expected for subsequent turns.

agenterm supports Steward snapshots in three modes:

- Manual:
  - REPL `/compress` triggers a compression run for the current branch history.
  - OpenAI plane: compaction is allowed when the provider supports it; otherwise snapshot.
  - Gateway plane: snapshot unless the route explicitly supports compaction.
- Inspection:
  - REPL `/compress show` prints the most recent Steward snapshot derived from local session turn history.
  - UI‑only output: no model call and no new session items.
- Automatic (pre‑run compression):
  - Controlled by `AppConfig.compression` (strategy/trigger/threshold/primary_branch/drop_policy).
  - Compression operates on **history before the current input**; the new input is appended afterward.
  - `both_if_supported` runs both snapshot + compaction on the original branch; the active branch
    is selected via `primary_branch`.
  - `trigger="ask"` prompts in the REPL only; non‑REPL runs treat `ask` as `deny`.
  - If compression is unavailable or declined, the run hard‑fails unless `drop_policy`
    allows dropping turns.
- Run attribution:
  - When invoked inside a run (auto or tool-driven), compression records request usage under the
    **current run_number** and the originating branch.
  - Manual `/compress` creates a dedicated run record in the current branch and records usage
    under that run number.

After a Steward snapshot (single canonical post‑snapshot contract):

- agenterm creates a new snapshot branch (`kind="snapshot"` or `kind="compaction"`) seeded with the
  snapshot items and switches head to it; the prior branch remains intact for inspection.
- Prefix items (`branch_turn_number <= 0`) are treated as a **pinned prefix** for packing.
- `agenterm_branch_meta.last_response_id` updates only when provider storage is enabled and a response id is returned.
- Subsequent runs replay local session turn history with the latest snapshot (no remote chaining).
- agenterm records the task request in the per‑request token ledger:
  - `kind="compaction"` for provider compaction,
  - `kind="steward"` for summary snapshots.

------

### 1.10 SessionState, REPL & CLI Workflows

#### 1.10.1 SessionState Structure

`SessionState` (defined in `core.types`) is the shared session state used by REPL and services. It is **immutable**; mutations occur via `with_*` helpers and configuration editors.

Logical fields (nested sub‑states):

- **Configuration**
  - `cfg: AppConfig`
  - `config_path: Path | None`
- **Session identifiers**
  - `session_id: str | None`
  - `branch_id: str | None` (active branch; defaults to `"main"` when a session exists)
- **Approvals (`ApprovalsContext`)**
  - `mode: "prompt" | "auto"`
  - `shell`, `patch`, `mcp`, `compress` approval managers
  - audit log + subscription registry
- **Tools (`SessionToolsState`)**
  - `enabled: bool`
  - `selection: ToolSelection`
  - `tools_map: Mapping[str, ToolSpec] | None`
  - `bundles_map: Mapping[str, list[str]] | None`
  - `default_bundles: list[str] | None`
  - `include_base: tuple[str, ...]`
  - `startup_selection: ToolSelection`
- **MCP (`SessionMcpState`)**
  - `tool_names: tuple[str, ...]`
  - `refresh_pending: bool`
  - `discovery_status: "unknown" | "ok" | "error"`
  - `discovery_error: str | None`
- **Attachments (`SessionAttachmentsState`)**
  - `pending: tuple[str, ...]`
  - `last_used: tuple[str, ...]`
  - `next_send_use_last: bool`
- **Caches (`SessionCachesState`)**
  - `session_ids: tuple[str, ...]`
  - `branch_ids: tuple[str, ...]`
  - `artifact_ids: tuple[str, ...]`
- **UI / UX (`SessionUiState`)**
  - `render_markdown: bool`
  - `verbosity: "quiet" | "normal" | "debug"`
  - `stream_mode: "final" | "live"`
  - `reasoning_mode: "off" | "summary"`
  - `reasoning_summary_max_chars: int`
  - `diffs_mode: "off" | "summary"`
  - `theme: "dark" | "light"`
  - `color_depth: "auto" | "mono" | "ansi" | "default" | "truecolor"`
  - `editing_mode: "emacs" | "vi"`
  - `mouse: bool`
  - `completion: "off" | "commands" | "full"`
  - `cfg.repl.ui.max_transcript_entries` (config-only bound)
    - Caps the in-memory TUI transcript entry count and injects a truncation marker when exceeded.
  - `cfg.repl.transcript.*` (config-only bounds)
    - Transcript caps for tool output lines, detail lines/chars, shell previews,
      MCP args previews, and attachment list/path previews.
    - Controls prompt_toolkit `color_depth` via `Application(color_depth=...)`
      (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:110-118`).
  - `ui.mouse: bool`
    - Controls prompt_toolkit `mouse_support` via `Application(mouse_support=...)`
      (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:147-196`).
  - `ui.completion: "off" | "commands" | "full"`
    - Controls whether completion is disabled, slash-only, or slash+history
      suggestions (auto-suggest).
  - `ui.editing_mode: "emacs" | "vi"`
    - Controls prompt_toolkit editing mode (`EditingMode.EMACS|VI`).
  - Inline image previews for artifacts are emitted automatically when iTerm2
    is detected; there is no per-session UI toggle.

Defaults and overrides:

- Startup defaults for prompt UI controls come from `cfg.repl.ui` (config file `repl.ui.*`).
- Startup defaults for UX toggles come from `cfg.repl.ux` (config file `repl.ux.*`).
- `/repl` updates prompt UI controls for the current session only.
- `/ux` updates UX toggles for the current session only.
- Neither command rewrites config files.

Immutability:

- `SessionState` itself is frozen; most mutations are expressed as “with” operations:
  - e.g. `state = state.with_cfg(new_cfg)`
- `ApprovalsContext` is session‑scoped and mutable; approval mode and audit log
  updates occur via `state.approvals.set_mode(...)` / `state.approvals.*`.
- Config editors are used to mutate embedded `AppConfig` (models, tools, store flag, etc.).

#### 1.10.2 Slash Commands & Command Router

Slash commands are parsed into strongly‑typed command objects (e.g. `ModelCmd`, `StoreCmd`, `ToolsAddBundleCmd`, `SessionsUseCmd`).

- The command surface is manifest-driven: a single registry defines display order, usage strings, parsers, and optional completers so `/help`, tab completions, and parsing cannot drift.
- Help is tiered by default: `/help` shows the essentials; `/help all` prints the full command tree.

Top‑level commands (21 total):

- `/help [topic]` — tiered help; overview or per‑command details (use `/help all` for the full list).
- `/status` — session snapshot (model, tools, config, IDs).
- `/model [ID]` — show or set model; `/model list <provider>[/<route>]` and
  `/model refresh <provider>[/<route>]` manage the provider‑scoped registries
  (`openai` or `gateway/<route>`). Gateway list/refresh hard‑fails when its registry
  is unavailable (see Model Registry).
- `/agent [sub]` — show, list, or switch the active agent.
- `/tools [sub]` — manage tool bundles and selection.
- `/config [sub]` — consolidated settings: `key`, `verbosity`, `reasoning`.
- `/ux [sub]` — REPL UX controls: `markdown`, `reasoning`, `diffs`, `stream`, `verbosity`.
- `/repl [sub]` — prompt UI controls: `theme`, `color-depth`, `mouse`, `completion`, `edit-mode`.
- `/approvals [sub]` — manage pending tool approvals (`prompt`, `auto`, `list`, `show`, `approve`, `reject`).
- `/trace [sub]` — tracing controls: `show`, `clear`, `on`, `off`.
- `/attach [sub]` — manage staged attachments: `list`, `remove`, `clear`, or add a path/URL.
- `/session [sub]` — consolidated session management: `new`, `list`, `use`, `runs`.
- `/branch [sub]` — branch management: `list`, `use`, `new`, `fork`, `delete`, `runs`.
- `/compress` — run a compression step and branch onto the resulting snapshot (compaction on supporting providers, summary otherwise).
- `/last [sub]` — show the most recent bounded artifacts (`diff`, `tools`, `approvals`).
- `/artifacts` — browse durable artifacts (list/show/open/agent-run).
- `/mcp [sub]` — MCP server tools: `refresh`, `status`.
- `/again` — re-run the last prompt; forks from the last run when it has a turn range, otherwise retries in place (store required).
- `/edit` — edit the last prompt; forks from the last run when it has a turn range, otherwise edits in place (store required).
- `/quit` — exit REPL.
- Cancel: ESC cancels the current run.

Central router:

```python
async def apply(state: SessionState, cmd: Command) -> tuple[SessionState, ReplAction | str | None]
```

Behavior:

- Applies the command to `SessionState`, potentially producing a `ReplAction` to guide structural REPL behavior.

Config editors used by the router:

- `set_model`
- `set_model_store`
- `set_model_verbosity`
- `set_tools_from_selection`
- `set_agent`
- `set_mcp_servers`

Router responsibilities:

- Update `AppConfig` according to commands (model, verbosity, store flag, agent, MCP servers).
- Update:
  - `tools.selection`
  - `mcp.refresh_pending`
  - UX/UI toggles (e.g. `ui.render_markdown`, `ui.theme`, `approvals.mode`).
- Manage anchors and attachments for commands:
  - `/again`
  - `/edit`
  - `/session new`
  - `/attach`

`ReplAction`:

- Returned when the REPL loop must take structural steps:
  - `ReplActionExit`
  - `ReplActionNewSession`
  - `ReplActionAttachSession(session_id)`
  - `ReplActionSessionRuns(limit)`
  - `ReplActionBranchList`
  - `ReplActionBranchUse(branch_id)`
  - `ReplActionBranchNew(branch_id | None)`
  - `ReplActionBranchFork(run_number, branch_id | None)`
  - `ReplActionBranchDelete(branch_id, force)`
  - `ReplActionBranchRuns(limit, branch_id | None)`
  - `ReplActionSendAgain`
  - `ReplActionEditLast`
  - `ReplActionLastArtifact(kind, mode)`

Typed protocol:

- This design replaces sentinel strings, making the router <-> UI protocol typed and more robust.

#### 1.10.3 REPL Runner Lifecycle

The REPL runner owns:

- A prompt_toolkit `Application` with:
  - Transcript window (custom `UIControl`).
  - Composer buffer and floating completion menu.
  - Status bar and HUD derived from a typed view model.
  - Modal overlay for approvals.
- A TUI state store for transcript entries, streaming text, and modal state.
- Current `SessionState`.
- Current `Agent` (stable across runs).
- Current `McpServerPool` (connected across runs when MCP is enabled).
- Current Agents `Session` (`AgentermSQLiteSession`, subclass of `AdvancedSQLiteSession`) for the active `session_id`.
- A small `ReplPhaseState` used by the status/HUD renderer (phase + usage counters).
- A reference to the active `RunResultStreaming` handle so that ESC can invoke `cancel(...)`.

Owned module split (implementation detail):

- `agenterm.ui.repl.runner`:
  - REPL edge entrypoint (`run_repl(...)`) used by the CLI.
  - Delegates all orchestration to the loop module.
- `agenterm.ui.repl.loop`:
  - Orchestrates the interactive read/evaluate loop and background run lifecycle.
  - Owns in-memory REPL state (`SessionState`, current `Agent`, MCP pool, session handle).
  - Applies slash commands and dispatches resulting `ReplAction`s.
- `agenterm.ui.tui`:
  - Owns the prompt_toolkit `Application`, layout, controls, and styles.
  - Uses a single typed view model derived from:
    - `SessionState` (model/tools/MCP/attachments/store posture),
    - approvals snapshot (pending counts + approval mode),
    - `ReplPhaseState` (phase + HUD notice + usage total tokens).
  - Hosts completion helpers (command completer + word ring) so UI behavior has one canonical home.

Startup:

- Builds initial `SessionState` from `AppConfig` and CLI flags via the workflows/services layer.
- Creates a new `AgentermSQLiteSession` via the unified session factory
  (`make_session`), unless attaching to an existing `session_id` (e.g. via CLI flags).

Main loop:

1. Integrate any completed background runs before prompting, and again after input returns (to cover runs that finish while the TUI input queue is waiting).
2. If `mcp.refresh_pending` is set, refresh MCP tool discovery via `engine.mcp_diagnostics`, updating `mcp.tool_names` plus `mcp.discovery_status` and `mcp.discovery_error`.
3. Prompt the user:
   - If input starts with `/`:
     - Interpret as a slash command.
     - Route through the command router (`apply`).
     - Execute any resulting `ReplAction`:
       - Create new session.
       - Attach to existing session.
       - Show recent runs.
       - Stop in‑flight run.
   - Otherwise (normal prompt):
     - Build input items from:
       - Prompt text.
       - Attachments from `SessionState` (pending and reuse flags).
     - Use the current stable Agent for the session.
       - The Agent (and MCP pool) are rebuilt only when config changes occur (via slash commands), not per run.
       - When MCP server selection changes, agenterm rebuilds and reconnects the `McpServerPool`.
       - When the engine returns an updated Agent (handoffs), agenterm attaches the existing pool’s connected MCP servers via `Agent.clone(mcp_servers=...)` so MCP tools remain available.
     - Start the run as a **background task** using `run_streamed`.
     - While a run is running:
       - Accept only `/approvals` commands.
       - ESC cancels the current run immediately.
       - Reject normal prompts with a concise "run in progress" message.
    - Provider retries use `RetriesConfig.provider` across streamed/background/agent_run calls (SDK retries disabled), with exponential backoff + jitter and a bounded Retry‑After cap; non‑retryable failures surface as structured errors without crashing the REPL.

Run execution behavior:

- Consumes `RunResultStreaming.stream_events()`:
  - Prints accessory labels:
    - `[reasoning]` when reasoning items are seen (summary-only; no full chain-of-thought dumps).
    - `[tool call] {label}` when tool calls occur (with bounded, tool-specific details where available).
    - `[tool output] {label}` when tool outputs arrive; for `shell`/`apply_patch`, prints concise structured summaries.
      `apply_patch` diffs are rendered at approval time and available via `/last diff`.
  - Labels always print; detail lines are suppressed in `ui.verbosity=quiet`.
  - Text deltas stream only when `ui.stream_mode=live`; final text renders when
    `ui.stream_mode=final` (or when no deltas were seen).
  - Raw event types and reasoning summary deltas are emitted only when
    `ui.verbosity=debug` (and only when text deltas are streamed).
- Error handling:
  - Catches `MaxTurnsExceeded` and `AgentsException`.
  - Renders concise error messages.
  - OpenAI 4xx/5xx errors surface status + provider message when available, and
    persist `request_id`, `code`, `param`, and `type` in the error envelope for
    debugging.
- If a run ends with an error or user cancellation, REPL records the cancelled/failed status.
  - Completed SDK turns are already persisted by the session store.
  - In-flight items are retained in the turn-attempt ledger and always reused on
    the next run (no filtering, no tool replay).
- State updates:
  - Updates attachments state on `SessionState` (e.g. clearing `attachments.pending`, setting `attachments.last_used`).
  - Persists `last_response_id` on successful runs when a response id is present.
  - Persists per‑request usage into SQLite only for successful runs (cancelled/failed runs skip usage persistence).
- Footer:
  - Prints a compact footer including:
    - Tools summary (per tool family counts).
    - Usage summary (input/output/total tokens).
    - Response/session identifiers (`resp`, `sess`) when available (debugging + session coherence visibility).

#### 1.10.4 Session CLI

The `agenterm session` subcommands provide inspection and management of the session store.

Subcommands:

- `session list`:
  - Ensures metadata schema is valid; if the store schema is incompatible, the command fails fast and instructs deleting the local store file.
  - Prints one line per session including:
    - `session_id`
    - `kind`
    - `cwd`
    - `config_path`
    - `model`
    - `head_branch_id`
    - `store` (on/off; derived from branch metadata for the head branch)
    - `last_response_id` (head branch)
    - `last_message_role` / `last_message_snippet` (latest `user`/`assistant` message on the head branch; message types are derived from item roles in the Agents session tables: `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:48-108`, `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:474-505`)
    - timestamps
- `session show <id>`:
  - Prints detailed metadata for a single session, including:
    - trace identifiers (`trace_id`, `group_id`)
    - whether tools were enabled (`tools_enabled` flag)
    - head branch id + provider settings for the head branch (`store_enabled`, `last_response_id`)
    - any other relevant metadata fields
- `session runs <id>`:
  - Uses agenterm’s run ledger to show per‑run information for a branch:
    - Timestamps and usage (input/output/total tokens).
    - Response ids, status, and run numbers.
  - Accepts `--branch <ID>` (defaults to the session head branch).
  - JSON payload is run‑labeled:
    - `session.runs`
    - `session.usage_by_run`
- `session delete <id> [--force]`:
  - Deletes a session from the local SQLite store.
  - Prompts for confirmation unless `--force` is provided.

Branch CLI (`agenterm branch`):

- `branch list <SESSION_ID>`:
  - Lists branches for the session using SDK `list_branches()` plus agenterm metadata.
  - Includes `last_message_role` / `last_message_snippet` for the most recent `user`/`assistant` message on each branch (same source tables as session list).
- `branch use <SESSION_ID> <BRANCH_ID>`:
  - Switches the session head to the specified branch.
- `branch new <SESSION_ID> [--name <BRANCH_ID>]`:
  - Creates a new branch from the current head and switches to it.
- `branch fork <SESSION_ID> <RUN_NUMBER> [--name <BRANCH_ID>]`:
  - Creates a new branch from the selected run (exclusive) and switches to it.
- `branch delete <SESSION_ID> <BRANCH_ID> [--force]`:
  - Deletes a branch (never `main`); deleting the current branch requires `--force` and switches to `main` first.
- `branch runs <SESSION_ID> [--branch <BRANCH_ID>]`:
  - Shows run history for the requested branch (defaults to head).

#### 1.10.5 Output Layout & Presentation Modes

Shared transcript model (REPL + one-shot):

- Streamed run items are mapped to typed transcript blocks before rendering:
  - `ReasoningBlock`, `ToolCallBlock`, `ToolOutputBlock`, `ImageArtifactBlock`.
  - Approval events use `ApprovalTranscriptBlock`.
- Boundedness is enforced by `TranscriptPolicy` on both surfaces.
- REPL transcript rehydration replaces the in-memory transcript when a session or
  branch is attached/switched:
  - Reloads branch-scoped history via `AdvancedSQLiteSession.get_items(..., branch_id=...)`
    and reflects the stored Responses input items for that branch. `.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:127-180`
  - Stored items mirror each turn’s original input plus new items as persisted by
    the Agents runner. `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016`
  - Rebuilds transcript blocks from stored input item types (messages, tool calls,
    tool outputs, reasoning, compaction, MCP) bounded by the active transcript policy. `.venv/lib/python3.14/site-packages/openai/types/responses/response_input_item_param.py:504-531`

REPL TUI ordering (per run):

1. **Run separator** and **attachment echo** (system entries).
2. **User prompt entry** (the submitted input line).
3. **Streaming accessories** as they arrive:
   - `[reasoning]`
   - `[tool call] <label>`
   - `[tool output] <label>`
4. **Assistant output text**:
   - `ui.stream_mode=live` streams deltas into the transcript.
   - `ui.stream_mode=final` renders only the final text.
5. **Image artifacts** after post‑process (path + size; inline previews emitted in iTerm2 when supported).

Block spacing (REPL TUI):

- Transcript blocks are separated by one blank line.
- Streamed text deltas are treated as one block (opened on first delta and closed on finalize).
- The TUI renderer owns spacing; Rich padding is CLI‑only.

Presentation modes (one-shot runs):

- One-shot runs default to **quiet** mode (`live=False`):
  - Streams internally but renders only:
    - Final answer (no mid‑stream panels).
    - Attachment echo (if any).
    - Calm footer (no rich formatting beyond essential text).
  - Intended to keep CI output deterministic and non‑interactive.
- One-shot runs with `--live` (`live=True`):
  - Prints accessory labels (`[reasoning]`, `[tool call]`, `[tool output]`) during streaming.
  - Renders the final answer with rich Markdown.
  - Prints attachment echo and footer after completion.

REPL TUI rendering notes:

- `ui.render_markdown` enables Rich Markdown rendering for final agent text
  in the TUI transcript; live stream deltas remain plain text.
- `ui.verbosity=debug` adds raw event types + reasoning summary deltas; `quiet|normal` suppress those extras.
- Role labels are visual only (styling); no literal `user`/`agent` prefixes are printed in the transcript body.
- Background runs are non‑streaming from the client’s perspective.

Command output blocks (REPL):

- Slash-command responses render as labeled system transcript blocks (not Rich panels).
- Commands that already emit specialized transcript blocks (e.g. `/last diff`)
  keep their dedicated renderers and spacing rules.

Tool labels and tool output summaries (single canonical mapping):

- Both the REPL transcript renderer and `agenterm run --live` map raw Responses item `type` values
  into a stable human label using one shared module:
  - `ui.tool_events.label_for_tool_type(...)` (canonical).
- Both surfaces also summarize structured tool outputs using the same shared module:
  - `ui.tool_events.tool_output_summary_lines(...)` (canonical).
- FunctionTool/MCP output envelopes are parsed once per transcript block in
  `ui.transcript.tool_output_envelope`, which then delegates to the canonical
  summary helpers above.
- This prevents tool taxonomy drift between surfaces (e.g., `shell_call` vs `shell`, `apply_patch_call_output`
  vs `apply_patch`) and keeps the diff/command preview posture consistent across REPL and `run --live`.

Transcript blocks + last artifacts (REPL):

- The transcript is rendered from a typed **block model**:
  - Streamed run items map into `TranscriptBlock` / `ApprovalTranscriptBlock`.
  - User/agent/system text uses a TUI-only `TranscriptTextEntry`.
- Search tool calls (`file_search`, `web_search`) render result previews in their tool-call blocks:
  - Keep the call intent lines (query/action).
  - Add a bounded `results:` section (count + previews) when the include data is present.
- The REPL maintains a small in‑memory **artifact index** populated from these blocks (and their typed artifacts),
  so `/last` commands can render “last diff” without parsing printed output.
- `/last diff` prints the most recent `apply_patch` diff with numbered lines and add/remove markers.
  - Preview is line‑bounded by the transcript detail line budget (UI policy).
  - `/last diff full` prints the full diff (unbounded).

Vendor citations (diff artifacts and bounded rendering):

- File search call results are typed as `ResponseFileSearchToolCall.results` (with `filename`, `score`, `text` on each
  result): `.venv/lib/python3.14/site-packages/openai/types/responses/response_file_search_tool_call.py:34`.
- Web search call models are permissive for extra included fields (OpenAI SDK BaseModel uses `extra="allow"`):
  `.venv/lib/python3.14/site-packages/openai/_models.py:104`.
- Web search call output item model currently does not declare a typed `results` field (only `id/action/status/type`):
  `.venv/lib/python3.14/site-packages/openai/types/responses/response_function_web_search.py:61`.
- The OpenAI Responses `apply_patch_call` carries the diff in the operation model (`OperationCreateFile.diff` /
  `OperationUpdateFile.diff`): `.venv/lib/python3.14/site-packages/openai/types/responses/response_apply_patch_tool_call.py:18`.
- Rich provides `Console.capture()` for deterministic render capture when we need to test or snapshot transcript output:
  `.venv/lib/python3.14/site-packages/rich/console.py:1102`.

JSON output (canonical envelopes; used by CLI diagnostics too):

- Command option `--format json` (opt-in per command):
  - Examples: `agenterm run --format json "..."`, `agenterm mcp status --format json`, `agenterm session list --format json`.
  - Emits a single JSON document to stdout using the shared success/error envelopes defined in `core.envelope`.
  - Human formatting (Rich tables/panels) is never mixed into JSON output.
  - JSON mode emits exactly one document; streaming accessories are suppressed even when `--live` is set.
  - JSON mode is incompatible with the interactive REPL (`agenterm repl` is always human output).
  - Envelopes include `schema_version` to make contract evolution explicit.
  - Envelope (success; non‑stream):

  ```json
  {
    "schema_version": 1,
    "trace_id": "string|null",
    "ts": "RFC3339",
    "result": {
      "resource": "string",           // e.g. "run", "mcp.status"
      "payload": {}                   // typed per resource; JSONValue-only
    }
  }
  ```

- Payload container invariants (owned, enforced):
  - Payload dataclasses are `frozen=True` and store containers as `tuple[...]` / `Mapping[...]` (not `list[...]` / `dict[...]`).
- Mapping fields are constructed as `MappingProxyType(dict(...))` so payloads are immutable at runtime; `to_json()` renders concrete `dict` / `list` for `core.json_codec.dumps_compact`.

- `resource: "run"` payload:

  ```json
  {
    "mode": "live|quiet",
    "background": true|false,
    "text": "string",
    "attachments": ["string"],
    "artifacts": [
      {
        "artifact_id": "string",
        "kind": "string",
        "mime": "string",
        "path": "string",
        "size_bytes": int,
        "created_at": "RFC3339|null",
        "source_type": "string",
        "source_id": "string",
        "session_id": "string|null"
      }
    ],
    "tools": { "name": count },
    "response_id": "string|null",
    "session_id": "string|null",
    "usage": {
      "input_tokens": int,
      "output_tokens": int,
      "total_tokens": int
    } | null
  }
  ```

- `resource: "mcp.status"` payload:

  ```json
  {
    "servers": [
      {
        "key": "string",
        "kind": "stdio|sse|streamable_http",
        "connected": true|false,
        "tool_count": int,
        "error": "string|null"
      }
    ],
    "total_tools": int
  }
  ```

- `resource: "trace.show"` payload:

  ```json
  {
    "trace_enabled": true|false,
    "trace_id": "string|null",
    "group_id": "string|null",
    "trace_metadata": { "string": "string" } | null,
    "trace_include_sensitive_data": true|false
  }
  ```

- Envelope (error):

  ```json
  {
    "schema_version": 1,
    "kind": "config_error|usage_error|not_found|provider_error|agents_error|mcp_error|tool_error|runtime_error",
    "message": "string",
    "trace_id": "string|null",
    "ts": "RFC3339",
    "details": { "string": JSONValue }
  }
  ```

- Accessory streams (`[reasoning]`, `[tool call]`, `[tool output]`) are not emitted separately in JSON mode; their effects are summarized in `result.tools` and the final `text`.

Label semantics:

- `reasoning`:
  - Always prints a header line when reasoning content is present, even if the payload is empty or elided.
- Tool labels:
  - Map tool types to user‑friendly names:
    - `web_search`
    - `file_search`
    - `tool_call` (for other tool types).
- Shell / apply_patch:
  - `[tool output]` lines include additional structured summaries (e.g. command exit codes, patch statistics).

#### 1.10.6 REPL Keybindings & Prompt UX

Keybindings:

- `Enter`:
  - If a completion is active, accept the completion.
  - Otherwise: submit the current input.
- `Ctrl+J`:
  - Insert a newline for non-command input.
- `Tab`:
  - No-op on empty input.
  - When input starts with `/`, opens slash-command completions and cycles
    through candidates on subsequent presses.
  - Otherwise accepts the current history suggestion when present.
- `Esc`:
  - When a run is running, a single tap cancels the in-flight run.
- `Ctrl+C`:
  - Clear the current input buffer if non-empty.
  - No effect on running runs.
- `Shift+Enter`:
  - Not bound by default; prompt_toolkit does not define a dedicated Shift+Enter key.
  - Some terminals (including macOS iTerm2) send Shift+Enter as plain Enter, so it
    cannot be distinguished without terminal-specific remapping.
- `Ctrl+D` / EOF:
  - Exit the REPL.
- Multi‑line input:
  - Ctrl+J inserts a newline (Shift+Enter only when the terminal reports a distinct key).
  - Pasting multi-line content does not auto-submit; Enter submits.
- Editing mode:
  - `/repl edit-mode emacs|vi` switches prompt_toolkit editing mode.
  - Default editing mode is **vi** (config default).
- Color depth:
  - Default `repl.ui.color_depth=auto` picks the highest supported depth, preferring
    truecolor when the terminal advertises it (e.g., `COLORTERM=truecolor`, macOS Terminal/iTerm2).
  - Explicit `truecolor` forces 24‑bit; other values map directly to prompt_toolkit
    `ColorDepth` enums.

Implementation note:

- Keybindings and TUI layout live in `agenterm.ui.tui` to keep the REPL loop orchestration small and focused.

Vendor citations (prompt_toolkit TUI surfaces + editing modes):

- `Application` exposes `color_depth` and `mouse_support` parameters
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:110-196`).
- `Application.color_depth` falls back to `output.get_default_color_depth()` when unset
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:363-390`).
- `Vt100_Output.get_default_color_depth()` defaults to 8‑bit unless overridden by env
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/output/vt100.py:738-760`).
- `Renderer` enables/disables terminal mouse reporting based on `mouse_support`
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/renderer.py:342-625`).
- `Window` uses `dont_extend_height` to cap a region to the content’s preferred
  height (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:1394-1659`).
- `EditingMode` enum provides `VI`/`EMACS` tokens (`.venv/lib/python3.14/site-packages/prompt_toolkit/enums.py:6-9`).
- `Buffer` supports multiline input where `Enter` normally inserts a newline
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/buffer.py:210-213`).
- prompt_toolkit key names include `c-j` for newline (`ControlJ`) and do not define
  a dedicated Shift+Enter key
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/keys.py:1-120`).
- `Application.ttimeoutlen` and `timeoutlen` control escape-key disambiguation delays
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:286-301`).
- Auto-suggest derives history-based suggestions from the prompt history
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/auto_suggest.py:121-140`).
- Rich can export styled output as ANSI when `record=True`
  (`.venv/lib/python3.14/site-packages/rich/console.py:2173-2203`).
- prompt_toolkit `ANSI` parses ANSI escape sequences into formatted text fragments
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/formatted_text/ansi.py:17-79`).
- Output width is available via `Output.get_size()` (`.venv/lib/python3.14/site-packages/prompt_toolkit/output/base.py:160-186`) and is used to apply deterministic status layout under narrow terminals.

Bottom toolbar (minimal status line):

- Refreshes every ~0.2 seconds.
- Shows `agent: <name>[model] | effort: <value> | tools: <bundle> | context: <percent>%`.
  - `<value>` is the configured reasoning effort (or `unset` when no reasoning config is applied).
  - `<bundle>` is the first selected tool bundle (or default bundle) with `+N` when multiple are selected; `off` when tools are disabled; `none` when no bundles are resolved.
  - `<percent>` uses provider-reported input tokens for the last request of the most recent
    completed turn, normalized by `model.context_window` when configured.
  - When `model.context_window` is unset, the toolbar shows the raw token count instead.
- `AUTO` appears when approvals mode is auto; it is right-aligned when the terminal
  width permits, otherwise appended to the list.
  - The `AUTO` badge is styled in bold danger red to make the policy explicit.
- Phase and MCP posture are surfaced via `/status` and HUD notices, not the persistent line.

Evidence (tokens + context window):

- Responses usage exposes `input_tokens` and `total_tokens` for the last request (`.venv/lib/python3.14/site-packages/openai/types/responses/response_usage.py:25-44`).
- OpenAI provides an input token counting endpoint for Responses (`client.responses.input_tokens.count`).
  Evidence: `.venv/lib/python3.14/site-packages/openai/resources/responses/input_tokens.py:46-148` and
  vendor:openai:responses-input-tokens:https://platform.openai.com/docs/api-reference/responses/input-tokens.
- The OpenAI Models API object does not expose context window metadata (vendor:openai:models-api:https://platform.openai.com/docs/api-reference/models/object).
- Context window sizes are documented in the OpenAI model reference (vendor:openai:models-docs:https://platform.openai.com/docs/models).
- LiteLLM documents local tokenization helpers (`encode`/`decode`) and cost helpers for
  non-OpenAI paths (vendor:litellm:token-usage:https://docs.litellm.ai/docs/completion/token_usage).

Status/HUD single-source-of-truth:

- The REPL maintains one small mutable `ReplPhaseState` object:
  - phase (`idle|running|compressing`)
  - HUD notice text + level
  - last request input tokens + request count (for toolbar `in:` segment)
  - usage total tokens (for session totals)
- `prompt_toolkit` render callables build a frozen status view model snapshot from:
  - `SessionState`
  - approvals snapshot (pending counts and auto‑approve posture)
  - `ReplPhaseState`
- Rendering functions return prompt_toolkit “formatted text” fragments (a list of `(style, text)` tuples) instead of ad-hoc string concatenation, so both styling and tests are deterministic (`.venv/lib/python3.14/site-packages/prompt_toolkit/formatted_text/base.py:28-60`).

Prompt posture:

- The left prompt is a fixed chevron (`> `). Approvals posture appears in the placeholder/HUD.
- Mouse support is enabled by default so scroll gestures are routed to the TUI
  transcript (toggle via `/repl mouse on|off`).

Prompt layout (full-screen TUI):

- Transcript window occupies the top region with internal scrollback.
- Transcript follows the newest line while idle; mouse-wheel scrolling moves the
  transcript cursor and disables follow mode until the viewport returns to the
  bottom.
- Image artifacts render as metadata lines with file paths in the transcript.
  Inline previews are disabled in the full-screen prompt_toolkit REPL because
  `patch_stdout` routes writes through `run_in_terminal`, which erases the UI,
  leaves the alternate screen, and redraws afterwards. Emitting OSC-1337
  sequences in that path causes visible flicker and leaves the image in the main
  screen buffer. The transcript never embeds OSC-1337 sequences; use
  `/artifacts open <ID>` to view the file instead.
- Completion panel renders between transcript and composer using a
  `CompletionsMenuControl` window that does not extend height, so it collapses
  to the number of completions (capped) and never pads out empty rows.
- Composer buffer sizes to its content and expands up to the composer cap for
  multi-line input.
- Transcript and composer include left/right padding margins so text does not
  touch the terminal edge.
- Transcript rendering omits scrollbars; scrolling is via mouse wheel and
  keyboard navigation only.
- Spacer lines separate transcript/completion from the composer and status bar
  to prevent visual crowding.

Redraw policy:

- TUI redraws are event-driven (UI store updates + explicit invalidations); no
  periodic refresh loop is enabled.
- Rendering is configured to avoid postponing redraws under load to keep scroll
  interactions responsive.

Vendor citations (completion events):

- Default completion keybindings cycle with `complete_next()` when completions
  already exist and otherwise `start_completion(select_first=True)`
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/key_binding/bindings/completion.py:40-46`,
  `.venv/lib/python3.14/site-packages/prompt_toolkit/key_binding/bindings/vi.py:524-532`).
- Buffers skip `start_completion` when a completion state already exists
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/buffer.py:1704-1710`).
- `CompletionsMenuControl.preferred_height` reports `len(completions)` so a
  non-extending `Window` collapses to the actual list size
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/menus.py:77-88`).
- `Window.dont_extend_height` prevents a window from stretching beyond its
  preferred height (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:1390-1397`).
- `CompletionsMenu` wraps the control in a scrollable `Window` with a scrollbar
  margin by default (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/menus.py:261-289`).
- `ConditionalContainer` collapses to zero height when its filter is false, which
  keeps the completion panel out of the layout when unused
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/containers.py:2596-2642`).

Vendor citations (redraw controls):

- `Application.min_redraw_interval` throttles redraws; `None` schedules every
  invalidation immediately (default) (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:122-131`).
- `Application.max_render_postpone_time` can postpone rendering; `0` disables
  postponement (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:133-135`).
- `Application.refresh_interval` enables periodic invalidation; `None` disables
  it (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/application.py:137-139`).

Vendor citations (inline images):

- `ANSI` treats content between `\001` and `\002` as zero-width fragments
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/formatted_text/ansi.py:26-75`).
- `patch_stdout` routes writes through `run_in_terminal` when an application
  loop exists (`.venv/lib/python3.14/site-packages/prompt_toolkit/patch_stdout.py:198-224`).
- `run_in_terminal` erases the interface before running the callable and redraws
  afterwards (`.venv/lib/python3.14/site-packages/prompt_toolkit/application/run_in_terminal.py:92-112`).
- `Renderer.erase` calls `reset(... leave_alternate_screen=True)`, and `reset`
  quits the alternate screen when that flag is true
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/renderer.py:382-411`,
  `.venv/lib/python3.14/site-packages/prompt_toolkit/renderer.py:734-753`).
- iTerm2 inline image parameters accept width/height units and preserve aspect
  ratio when both are supplied (`vendor:iterm2:3.5:https://iterm2.com/documentation-images.html`).
- Transcript scroll input is handled via `UIControl.mouse_handler` and mouse
  event types (`SCROLL_UP`/`SCROLL_DOWN`) from prompt_toolkit
  (`.venv/lib/python3.14/site-packages/prompt_toolkit/layout/controls.py:94-131`,
  `.venv/lib/python3.14/site-packages/prompt_toolkit/mouse_events.py:22-60`).

Completion contract (slash commands):

- Slash command completion is **token-slot aware**:
  - The input after the command head is interpreted as whitespace-separated tokens.
  - A trailing space means “the current token is complete; complete the **next** slot”.
- Completions operate on the current input line (not the entire buffer) to avoid
  multi-line inputs disabling command completion (`.venv/lib/python3.14/site-packages/prompt_toolkit/document.py:170-187`).
- Completers must never suggest a token that is already complete when the cursor is positioned in a new token slot.
  - This avoids the “TAB inserts the same token forever” loop when a subcommand has only one matching candidate.
- Multi-value slots (e.g. `/tools add bundle <NAME>...`) must filter out already-selected values, so the next completion always advances the user.
- Completers are allowed to be context-aware (e.g. `/tools` needs current bundles/tools; `/approvals` needs pending approval ids) but must remain deterministic and bounded.
- Top-level completions include `display_meta` from the command manifest summary to render a two-column completion menu when supported.

Vendor citations (completion semantics):

- `Completion.start_position` must be <= 0 and is relative to the cursor; when a token prefix is empty (cursor after a trailing space), `start_position=0` inserts at the cursor (`.venv/lib/python3.14/site-packages/prompt_toolkit/completion/base.py:26-66`).
  - This is why trailing-space completion bugs manifest as infinite repeated insertions if the candidate is the already-completed token.
- `NestedCompleter` treats “space after a term” as a transition into the next completion level by slicing after the first term and `lstrip()`-ing the remainder (`.venv/lib/python3.14/site-packages/prompt_toolkit/completion/nested.py:76-109`).
- `Completion.display_meta` renders a meta column when any completion provides it (`.venv/lib/python3.14/site-packages/prompt_toolkit/completion/base.py:26-48`, `.venv/lib/python3.14/site-packages/prompt_toolkit/layout/menus.py:127-175`).

Status bar contract (status vs transcript):

- The status bar is the **primary** feedback surface for “what is happening now”:
  - minimal status line (agent + model + effort + tools bundle + input % + AUTO)
  - HUD notices for running-phase guidance
- The transcript should not repeatedly re-state status facts (e.g. “run running”, “press ESC”, “approvals pending”) after every ignored input.
  - Running-phase guidance is shown in the composer placeholder/HUD instead of emitting redundant transcript lines.
  - Approval requests open a modal overlay; the transcript emits bounded approval request/decision blocks (id + summary), while full inspection remains on-demand via `/approvals list`, `/approvals show <ID>`, and `/last approvals`.

#### 1.10.7 Representative Session Lifecycles

Examples illustrate how store and session behavior combine.

1. **One‑shot run (local‑stateful)**
   - `agenterm run "..."`:
     - Uses local session turn history replay only.
  - `session_input_callback` packs session turn history + new input within budgets (see §1.8.11).
   - Edges never send `previous_response_id`.
2. **Run with explicit session id**
   - `agenterm run --session <UUID> [--branch <BRANCH_ID>] "..."`:
     - Attaches to the existing session id (fail-fast if unknown).
     - Uses the session head branch when `--branch` is omitted.
     - Replays local session turn history for that branch; no remote chaining.
3. **REPL fresh session**
   - `agenterm` (REPL):
     - Creates a new `AgentermSQLiteSession` (Agents `AdvancedSQLiteSession`).
     - Inserts a metadata row into `agenterm_sessions` and a `main` row in `agenterm_branch_meta`.
   - `/session new`:
     - Starts another new session **without leaving the REPL**.
     - New `session_id`, `AgentermSQLiteSession`, and metadata rows.
4. **Attach REPL to a run session**
   - `/session use <ID>`:
     - Rehydrates store flag and `last_response_id` from **branch** metadata.
     - Binds a new `AgentermSQLiteSession` object to the existing `session_id`.
     - Uses the head branch; `/branch use <BRANCH_ID>` switches branches.
5. **Runs**
   - `/session runs [N]`:
     - Reads run status + usage from the agenterm run ledger.
     - Defaults to 10 runs when N is omitted (avoids unbounded history reads).
     - List is filtered to the current branch.
   - `/branch runs [N]`:
     - Reads runs for the active branch (or a specified branch).
6. **Branching**
   - Agents `AdvancedSQLiteSession` supports multiple branches.
   - agenterm exposes branching via CLI `agenterm branch` and REPL `/branch`:
     - `new` creates a branch from head.
     - `fork` creates a branch from a selected run (exclusive).
     - `use` switches the session head branch.
  - Agent switches, compaction, and replay (/again, /edit) are modeled as branch
    creation + head switch when the last run produced a turn range; if the last
    run has no turn range (e.g., API error before any SDK turns), replay falls
    back to retrying in place to avoid hard failure.
7. **Store / `response_id` semantics**
   - `store=True`:
     - Provider stores responses for retrieval/inspection.
     - `last_response_id` is persisted **per branch** after each successful run.
   - `store=False`:
     - Provider does not store responses; retrieval by id is unavailable.
     - `last_response_id` is not persisted.
   - Continuity is always local; `previous_response_id` is never used for normal runs.

#### 1.10.8 CLI Run Flow

One‑shot CLI runs follow a linear, composable pipeline:

- **Preflight**: `run_command` builds `RunConfigFlags` from CLI args (including `--tools-bundle`/`--tool` selection overrides, `--store/--no-store`, and `--branch`), validates presence of `OPENAI_API_KEY`, and normalizes config overrides. Exit codes are produced via `typer.Exit` (re‑export of Click’s `Exit`, `.venv/lib/python3.14/site-packages/typer/__init__.py:5-39`).
- **Async hygiene**: all async work (context prep, run execution, payload assembly) runs inside a single event loop (one `asyncio.run` per invocation; no nested loops).
- **Source resolution**: `resolve_source` enforces exactly one input source (prompts | file | stdin) and rejects empty input unless attachments exist.
- **Mode resolution**: output format is `human|json` (CLI `--format` or `cfg.run.json_output`), and `--live` toggles live vs quiet **human** rendering. JSON output emits a single envelope and suppresses streaming accessories even if `--live` is set.
- **Config note**: CLI `run` emits a short stderr note indicating whether config came from an explicit path, project‑local, global, or defaults.
- **Execution split**:
  - Streaming path wraps `RunResultStreaming.stream_events()` and consumes the Agents event taxonomy (`RawResponsesStreamEvent`, `RunItemStreamEvent`, `AgentUpdatedStreamEvent`) defined in `.venv/lib/python3.14/site-packages/agents/stream_events.py:12-62`, using the same detection patterns as the Agents SDK’s own demo loop (`.venv/lib/python3.14/site-packages/agents/repl.py:45-66`) and text-delta helper (`.venv/lib/python3.14/site-packages/agents/voice/workflow.py:44-54`).
  - Background path uses `run_once` and persists usage plus `last_response_id` for the active branch when store is enabled.
- **Approvals**: CLI `run` creates an ephemeral approvals context in `auto`
  mode and auto‑resolves tool approvals without clobbering callbacks (see 1.11.3).
  - Hosted MCP approvals are routed via the Agents `HostedMCPTool(on_approval_request=...)` callback contract (`.venv/lib/python3.14/site-packages/agents/tool.py:485-499`).
- **Rendering**: CLI surfaces construct typed payloads and delegate output to a single dispatcher; JSON always uses the canonical envelope (`emit_json_success`), and human output always flows through the shared Rich renderer (see 1.10.10). Commands do not print directly.
- **Error handling**: `ConfigError`/`PipelineError`/`AgentermError` map to the CLI error vocabulary, classifying OpenAI failures via the client taxonomy (`.venv/lib/python3.14/site-packages/openai/_exceptions.py:35-130`) and exiting with code 2.

------

#### 1.10.9 Canonical Run Execution (`workflow.run`)

agenterm treats a **run** as the canonical unit of work across the CLI `run` surface and the REPL. A run may contain
multiple SDK turns; the CLI/REPL surfaces always reference runs, while SDK turn items remain available for inspection.
Greenfield posture: there is exactly one shared execution pipeline for streamed runs and one for background runs;
surfaces differ only in **rendering policy**, not in orchestration, persistence, or compaction semantics.

Single-path pipeline (streamed runs):

`edge (run|repl) → workflow.run.execute_streamed → engine.run.run_streamed → stream_events → workflow.run.postprocess`

Responsibilities (owned, single place):

- **Event consumption and normalization**:
  - Consumes `RunResultStreaming.stream_events()` and distinguishes:
    - raw Responses events (`RawResponsesStreamEvent`) for optional agent output deltas,
      including reasoning summary deltas (`response.reasoning_summary_text.delta`) in live mode. Evidence:
      `.venv/lib/python3.14/site-packages/openai/types/responses/response_reasoning_summary_text_delta_event.py:10-29`.
    - semantic run items (`RunItemStreamEvent`) for tool calls / tool outputs / reasoning,
    - agent updates (`AgentUpdatedStreamEvent`) for handoffs and agent switching.
  - Cancellation:
    - After requesting cancellation, the consumer continues draining `stream_events()` so SDK cleanup completes (`.venv/lib/python3.14/site-packages/agents/result.py:300-347`).
    - SDK turns are persisted per turn (`session.add_items(input_list + new_items_as_input)`), so cancellations preserve all completed turns while the in‑flight turn is captured in the turn‑attempt ledger for automatic replay. Evidence:
      `.venv/lib/python3.14/site-packages/agents/run.py:1994-2016`.

- **MCP server attachment**:
  - Run execution leases connected MCP servers via a single context-managed path (MCP client/session idiom is `async with ...: await session.initialize()`; `.venv/lib/python3.14/site-packages/mcp/client/__main__.py:41-64`).
  - Server lifecycle is managed outside the agent loop and injected at run time (no ad-hoc per-surface server wiring).

- **Postprocessing (end-of-run invariants)**:
  - Persist usage (Agents session usage + agenterm request ledger).
  - Update branch metadata (`last_response_id`) when store is enabled.
- Pre-run packing triggers compression when configured and switches head to the selected snapshot/compaction branch (1.9.4).

Rendering posture (surface-specific, not an execution fork):

- REPL:
  - Uses a full-screen prompt_toolkit `Application` with a scrollable transcript window and modal overlays.
  - Verbosity controls streaming: `debug` streams deltas + raw events; `quiet`/`normal` render final text with labels only.
  - Each run starts with a header plus a bounded attachments-used block (pending vs last-used counts) before tool calls.
  - Approval requests open a modal overlay and still emit bounded transcript blocks for auditability.
  - Tool output blocks surface MCP call failures with server/tool/error summaries when `mcp_call` output items include `error`/`status=failed`. Evidence:
    `.venv/lib/python3.14/site-packages/openai/types/responses/response_output_item.py:91-123`.
  - Web search tool detail lines are defensive: missing or non-string action fields render placeholders instead of crashing the transcript renderer.
- CLI `run`:
  - In `--live` mode, prints reasoning/tool events during streaming and prints agent output once at completion (keeps non-interactive use deterministic).
  - In quiet mode, suppresses mid-stream transcript output and prints only the final output and footer.
- Theme tokens:
  - REPL UI merges prompt_toolkit `default_ui_style()` with amber theme tokens for transcript, status bar, composer, completion menu, scrollbars, search/selection, and modal overlays; class names align with prompt_toolkit defaults. Evidence:
    `.venv/lib/python3.14/site-packages/prompt_toolkit/styles/defaults.py:18-160` and `.venv/lib/python3.14/site-packages/prompt_toolkit/styles/defaults.py:217-228`.
  - prompt_toolkit styles accept class name/style tuples (or dicts via `Style.from_dict`) with Pygments-like style strings and later rules overriding earlier ones. Evidence:
    `.venv/lib/python3.14/site-packages/prompt_toolkit/styles/style.py:211-271`.
  - CLI output uses Rich `Theme` to map style names to `Style.parse` definitions (inherit defaults unless overridden). Evidence:
    `.venv/lib/python3.14/site-packages/rich/theme.py:8-28`.
  - Palette sources are `agenterm.ui.color_tokens` (shared semantic tokens) and `agenterm.ui.tui.theme` (prompt-toolkit-specific tokens); the reference swatch sheet lives at `docs/ref/palette.html` and is the visual check for updates.
  - Runtime renderers must use semantic style names (e.g., `good`, `warn`, `error`, `dim`) instead of raw color names to keep palette control centralized.

#### 1.10.10 CLI Output Contract (Human + JSON)

The CLI has one renderer per output format:

- **Human output**:
  - All commands return typed payloads and delegate rendering to a single Rich-based renderer.
  - Human errors are rendered as a Rich `Panel` with a clear title and border (Typer’s Rich error handler renders errors in a `Panel`; `.venv/lib/python3.14/site-packages/typer/rich_utils.py:694-724`).
  - Human errors are rendered from a single structured error report (operation, resource, recovery hint, optional rate‑limit metadata) so all surfaces show consistent semantics.
  - Lists and detail views render as Rich `Table` or `Panel` blocks for structured legibility (Typer’s help panels wrap `Table` inside a `Panel`; `.venv/lib/python3.14/site-packages/typer/rich_utils.py:440-473`).
  - A single `Console` configuration owns theme/highlighter settings (Typer configures a themed `Console` via `Theme` + `RegexHighlighter`; `.venv/lib/python3.14/site-packages/typer/rich_utils.py:132-150`).
  - Commands do not call `typer.echo` / `typer.secho` directly; all human output flows through the renderer to keep formatting consistent and testable.
  - Global output controls (`--quiet`, `--verbose`) only affect auxiliary notices and error detail verbosity; core result payloads always render.

- **JSON output**:
  - The CLI emits exactly one JSON envelope per command via `emit_json_success` / `emit_json_error` (see 6.1).
  - Typed payloads are shared between human and JSON output; JSON is not a separate data path.
  - Error envelopes always include `details.operation`, `details.resource`, `details.recovery_hint`, and `details.rate_limit` (when available).

Renderer invariants:

- Stable ordering of keys/rows for deterministic output.
- Bounded previews and explicit truncation markers for stdout/tool summaries; apply_patch approvals render full diffs unless `repl.ux.verbosity=quiet`.
- A consistent footer for metadata (trace/session/usage/tools) in human output.

### 1.11 Approvals & Tool Safety

#### 1.11.1 Approvals Queue

Shell, apply_patch, and hosted MCP connector calls are guarded by approvals:

- `core.approvals.ApprovalsContext`:
  - Per‑session object stored on `SessionState.approvals`.
  - Owns the approval managers (`shell`, `patch`, `mcp`), audit log, and approval mode.
  - Exposes `subscribe(...) -> token` / `unsubscribe(token)` so multiple UI listeners can observe approval events without callback clobbering.
- Every shell / patch / hosted MCP connector invocation:
  - Registers an approval request (with tool family, summary, etc.).
  - Waits for resolution; the session approval mode controls whether the host prompts (`prompt`) or auto‑resolves (`auto`).

Hosted MCP connector approvals:

- Hosted MCP connectors are provider-hosted; the model can issue tool calls without a “round trip” back to agenterm.
- The Agents SDK exposes approvals via a callback:
  - `HostedMCPTool(on_approval_request=...)` (`.venv/lib/python3.14/site-packages/agents/tool.py:485-499`)
  - When an approval is requested, the runner executes the callback and emits an approval response item (`.venv/lib/python3.14/site-packages/agents/_run_impl.py:348-355` and `.venv/lib/python3.14/site-packages/agents/_run_impl.py:1312-1343`).
  - The approval callback returns `{"approve": bool, "reason"?: str}`; `reason` is only used on rejection (`.venv/lib/python3.14/site-packages/agents/tool.py:274-298` and `.venv/lib/python3.14/site-packages/agents/_run_impl.py:1295-1323`).
- agenterm implements this callback by:
  - registering a hosted MCP connector approval item in the session approvals
    context, then
  - awaiting user resolution (REPL) or auto‑approving (CLI `run`), with event
    notifications dispatched by the session’s approvals subscription registry.

#### 1.11.2 REPL Approval Flow

REPL provides interactive control via the session approvals context and `/approvals`:

- `/approvals` shows the current mode (`prompt` vs `auto`).
- `/approvals auto`:
  - Enables auto-resolve for the session, and
  - Immediately approves any currently pending approvals so the run can continue.
- `/approvals prompt` disables auto-resolve (manual approvals).

While a run is running:

- Approvals are **modal-first**:
  - REPL subscribes to `state.approvals` events and opens a modal overlay when approvals are pending in `prompt` mode.
  - REPL emits transcript blocks for shell/apply_patch approvals:
    - `[approval requested]` when a request is registered.
    - `[approved]` / `[rejected]` when the decision resolves.
  - For `apply_patch` approval **requests**, the transcript includes the **full proposed diff** with numbered
    lines and add/remove styling when `repl.ux.verbosity != quiet`. This diff rendering is intentionally
    unbounded for the request event.
  - Detailed inspection remains on-demand via `/approvals` and `/last approvals`.
- Type `y`/`n` to approve/reject the next pending approval (shell, apply_patch, hosted MCP).
- Type `n <reason...>` to reject with a user-provided reason (forwarded to the model so it can follow up).
- `/approvals reject <ID> <reason...>` is the explicit rejection-with-reason surface (works for all approval families).
- Use `/approvals list` and `/approvals show <ID>` to inspect details on demand (explicit transcript output).
- `/approvals` commands remain available (mode changes, list/show/approve/reject); other commands and prompts are rejected to avoid state drift mid-run.
- ESC cancels the active run.

Approval audit trail:

- agenterm records a bounded in-process audit trail of approval **requests** and **decisions**.
- The audit trail exists for operator debuggability and post-hoc inspection; it is not part of the model input by default.
- `/last approvals [preview|full]` renders the most recent approvals (pending + resolved) with bounded formatting.
  - `preview` prints one-line summaries (id + family + state + short summary + rejection reason when present).
  - `full` prints bounded details (cwd/commands, diff summary, MCP args) plus the final decision and rejection reason.
- The REPL clears the audit trail when starting or attaching a new session so `/last approvals` remains “this session” scoped, mirroring the `/last diff|tools` posture.

Approval mode in REPL:

- Can be toggled via `/approvals prompt|auto`.
- Can be set at session start via CLI `--approvals prompt|auto` (sets approval mode; does **not** select tools or bypass the tools gate).
- Can be set by default via `repl.approvals.mode: auto` in config (REPL only).
- Even with auto‑approval on, sandboxing still enforces workspace confinement.

#### 1.11.3 CLI `run` Approval Flow

For CLI `run`, approvals are always auto‑resolved; the command is intentionally non‑interactive:

- `agenterm run` never prompts; it creates an ephemeral approvals context in `auto`
  mode for the run and approvals resolve immediately as approved.
- Dangerous tools are **dropped** unless `--allow-dangerous` is provided.
- With `--allow-dangerous`, dangerous tools are exposed and auto‑resolved.
- Seatbelt sandbox still enforces workspace confinement for all shell invocations.
  - Hosted MCP approvals are resolved via the Agents callback mechanism (see 1.11.1).

------

### 1.12 Error Handling & Observability

#### 1.12.1 Error Taxonomy & Exit Codes

Engine‑level errors are mapped to a constrained vocabulary:

- `config_error`
  - Invalid YAML, invalid types in config, or incompatible flag combinations.
- `validation_error`
  - Invalid values with field‑path context (schema validation, numeric bounds, or per‑surface validation).
- `usage_error`
  - Invalid CLI invocation (unsupported flag combinations, incompatible modes such as `--format json` with streaming, or
    missing required confirmation flags in non-interactive mode).
  - Usage errors map to `usage_error` via `UsageError` in `core.error_report`, and CLI usage failures emit
    `usage_error` reports via `build_message_report`.
- `not_found`
  - Requested local resource does not exist (session id, artifact id, local store not yet created).
- `filesystem_error`
  - File/dir I/O failures (config/agent/artifacts paths, store/history directories).
- `database_error`
  - SQLite store/schema errors or invalid persisted rows.
- `auth_error`
  - Missing or invalid authentication (e.g., OPENAI_API_KEY).
- `rate_limit_error`
  - Provider rate limits (includes `retry_after` and rate‑limit headers in `details.rate_limit`).
- `timeout_error`
  - Request or tool execution timeouts (local or provider).
- `provider_error`
  - Provider client / HTTP errors (OpenAI or gateway) not covered by rate‑limit or timeout categories.
  - Error details include provider label when known plus status/code/param/type/request_id fields when available.
  - Gateway errors also include `llm_provider` and `model` when surfaced by LiteLLM exceptions.
- `agents_error`
  - Agents runtime errors not covered by other categories.
  - Message includes a bounded exception detail when available (no tracebacks).
- `mcp_error`
  - MCP connectivity or protocol errors.
- `tool_error`
  - Local tool executor failures (shell, apply_patch, custom tools).
- `runtime_error`
  - Unexpected exceptions (programming errors, unanticipated conditions).
- Runtime fallback messaging:
  - When an exception does not match a specific mapping, the error message includes the exception class name and a bounded exception message (no tracebacks) to aid debugging without leaking stacks.
- Error classification aligns with provider SDK taxonomy (OpenAI `APIError`/`APIStatusError` for the OpenAI plane and LiteLLM exception types for gateway routes). Retry metadata follows the SDK’s Retry‑After parsing rules (`openai/_base_client.py:692-779`) while SDK retries remain disabled in favor of `RetriesConfig`.
- LiteLLM exceptions expose `llm_provider`, `model`, and status metadata used in gateway error details (`.venv/lib/python3.14/site-packages/litellm/exceptions.py:13-760`).
- JSON error envelopes use only this vocabulary; surface-specific conditions (platform limitations, required confirmations,
  missing files/rows) map into these kinds via stable `message` and typed `details` fields (`operation`, `resource`,
  `recovery_hint`, and optional `rate_limit`).

Edge‑level behavior (CLI / REPL):

- Renders concise, human‑readable messages on stderr.
- Exits with **code 2** for these error categories.
- Full stack traces are reserved for debugging (e.g. verbose or debug mode), not for normal user runs.

#### 1.12.2 Usage Accounting

Usage information is obtained from Agents `Usage` structures attached to run results.

Summarization:

- `engine.result_summary.summarize_usage(result) -> str`:
  - Produces compact summaries, e.g.:
    - `in=123 out=456 total=579 tokens`

Important nuance: one run can contain multiple turns/requests.

- When tools are used, the agent frequently performs multiple provider requests inside one run:
  - request 1: decide + request tool calls
  - request 2+: incorporate tool outputs and continue until termination
- This is why aggregated usage surfaces a `requests` count and why per-request breakdown matters for context window
  management (peaks are hidden by totals).

Visibility:

- One-shot runs and REPL show this summary in footers when `ModelSettings.include_usage` resolves truthy.
- `include_usage` is controlled via `ModelConfig.include_usage` and the mapping to `ModelSettings` (see 1.6.3).

Persistence:

- When the session is an Agents SQLite session (`AgentermSQLiteSession`, subclass of `AdvancedSQLiteSession`), agenterm persists turn usage into the session store after each successful run.
- Agents’ `AdvancedSQLiteSession.store_run_usage` expects a `RunResult` and reads `result.context_wrapper.usage` (`.venv/lib/python3.14/site-packages/agents/extensions/memory/advanced_sqlite_session.py:236-252`).
- For streamed runs (`RunResultStreaming`), agenterm materializes an equivalent `RunResult` snapshot at completion so the same persistence API can be used without touching private session internals.

Context-window signal (operator UX):

- Aggregated usage is a cost/integral metric; it answers “how much did this run/session cost”.
- For “how large is my current prompt context” (what will dominate the next request), agenterm surfaces **per-request input
  tokens** derived from the last provider request of the last completed run (and, where useful, the peak within the run).
  This is derived from provider-reported usage (no local tokenization). See 1.8.7.

#### 1.12.3 Local Validation & Gate

Canonical command: `uv run devtools/gate.py [--no-tests]` from the repository root; any non‑zero exit code blocks delivery.

Toolchain (versions from `uv.lock`):

- Ruff **0.14.10** for formatting and linting (roots: `src`, `devtools`). Evidence: `uv.lock:1737-1739`.
- Basedpyright **1.36.2** in strict mode targeting Python 3.12 with `extraPaths=["src"]` and `venv=.venv`. Evidence: `uv.lock:198-200`.
- Pytest **9.0.2** for unit/smoke coverage. Evidence: `uv.lock:1422-1424`.

 Gate stages (executed in order):

1. `uv run ruff check --fix src devtools` — lints the owned Python sources using the repo’s Ruff configuration in `pyproject.toml`.
2. `uv run ruff format src devtools` — applies formatting fixes across owned Python sources.
3. `uv run basedpyright .` — strict type check scoped to `src`/`devtools` via `pyproject.toml` include (excludes `.uv-cache`/`.worktrees`).
4. `uv run python -m compileall src devtools` — syntax gate across owned modules.
5. `uv run pytest -q` — functional/unit tests (skipped when `--no-tests` is provided; exit code 5 for “no tests collected” is tolerated).
6. `uv run agenterm --help` — CLI wiring smoke test (ensures Typer/entrypoint viability).
7. Policy ripgrep checks over `src`/`devtools` (excludes `.venv`, `node_modules`, `dist`, `__pycache__`):
   - forbid `# type: ignore` / `# pyright: ignore`
   - forbid `# noqa`
   - forbid reflection (`getattr`/`hasattr`/`setattr`)
   - forbid silent swallows (`except ...: pass`)
   - forbid `eval`/`exec`
   - forbid `subprocess.*(shell=True)` or `os.system`
   - forbid empty definitions (`def/class ...: pass`)
   - forbid `typing.Any` / `typing.cast`
   - forbid broad `object` annotations for mappings/lists
8. `uv run python -m devtools.policy_dict_params` — policy gate forbidding `dict[...]` in function parameter annotations (use `Mapping` / `MutableMapping` for variance-correct boundaries; reserve `dict[...]` for owned state and returns).
9. `uv run python -m devtools.file_size_check` — enforces ≤500 lines and ≤18 kB per file under `src` and `devtools` (skips `.venv`, `node_modules`, `dist`, docs).
10. `uv lock --check` — dependency/lock integrity.

Output policy:

- Steps marked advisory continue the gate but still emit findings.
- Missing executables/configuration are treated as hard failures, not skips.

------

### 1.13 Alignment with Vision & Plan

agenterm documentation is structured as:

- `VISION.md`
  - Describes the **finished product** and user workflows.
- `ARCH.md` (this architecture)
  - Describes the **target technical shape** that realizes the vision.
- `PLAN.md`
  - Tracks:
    - Vision ↔ Architecture gaps:
      - Places where workflows are not fully specified or supported.
    - Architecture ↔ Code gaps:
      - Places where the current implementation does not yet match this architecture.

Change management expectations:

- New work must treat VISION and ARCH as the **specification**.
- Structural changes to the system must be mirrored by updates to ARCH.
- When new gaps are identified or closed:
  - PLAN should be updated to add or remove items accordingly.

### 1.14 Glossary

- **agenterm**
  The overall command‑line application described by this architecture (Typer app, REPL, and supporting services).
- **Run**
  One Agents SDK `Runner.run` / `run_streamed` invocation for a single user input. Runs may contain multiple turns.
- **Turn**
  One AI invocation inside a run (SDK definition). Turns align with session `branch_turn_number` and with
  provider requests.
- **Request**
  One provider API call that yields a Responses object. Requests align 1:1 with turns.
- **Edge layer**
  CLI and REPL surfaces, responsible for argument parsing, TTY I/O, keybindings, and mapping user actions into services.
- **AppConfig**
  Canonical in‑process configuration object containing agent, model, tools, MCP, run defaults, and guardrails.
- **SessionState**
  Immutable REPL/workflow state grouped into nested sub‑states (tools, MCP,
  attachments, caches, UI, approvals) plus core configuration.
- **Local store**
  agenterm‑owned SQLite (sessions/branches/runs/usage) plus the artifacts vault on disk; the canonical continuity record.
- **Agents session (`AdvancedSQLiteSession`)**
  Agents SDK session implementation used by agenterm, backed by SQLite, storing messages, branches, and usage.
- **Provider store**
  Provider‑side Responses persistence controlled by `ModelConfig.store`; used for retrieval/inspection only and never for continuity.
- **Tools gate (`tools_enabled`)**
  Session‑level flag persisted in metadata and mirrored by `SessionState.tools.enabled` indicating whether any tools
  (including MCP) are exposed to the model, independent of selection.
- **Dangerous tools**
  Tools marked `dangerous=True` after applying `tools.dangerous` overrides. CLI `run` requires `--allow-dangerous` to expose them. Approvals apply to a narrower subset (shell/apply_patch/hosted MCP connector tool calls).
- **Shell Sandbox (Seatbelt)**
  macOS Seatbelt sandbox constraining shell execution to workspace root; configured via `tools.shell.sandbox.network` (approvals are controlled via `repl.approvals.mode` and `/approvals`).
- **Store flag (`ModelConfig.store` / `store_enabled`)**
  Controls provider‑side response persistence for retrieval/inspection; persisted per branch in
  `agenterm_branch_meta.store_enabled`.
- **Response id (`response_id`)**
  Provider response identifier recorded in ledgers and branch metadata for inspection/ledger use.

------

## 2. Issue Register & Notes

No open conflicts or ambiguities. Previously tracked items A‑001…A‑005 are now resolved in the main text:

- Edge return types are not exposed as typed objects; CLI/REPL print directly.
- Shell sandbox configuration is fully specified (1.7.3).
- Session `kind` values are enumerated (`run`, `background`, `repl`) in 1.8.3.
- Approvals precedence is clarified (1.7.2, 1.11.2–1.11.3); `--allow-dangerous` controls dangerous tool exposure, CLI `run` auto‑approves non‑interactively, and `--approvals` sets the initial approval mode for REPL sessions.
- JSON output mode is specified in 1.10.5.
