# HANDOFF.md

## Open Items

- `.local/lifecycle.md` refinement is active; next action: expand lifecycle schemas/events and align ARCH/runtime to the spec.
- `.local/tool_report.md` is the source for upcoming tool UX/contract initiatives; next action: convert each prioritized item into scoped design+implementation tasks.

## Gates

- Last gate run: `uv run devtools/gate.py` passed (pytest: 320 passed; litellm deprecation warnings emitted).

## State Notes

- Defaults/doc alignment landed: README canonical defaults now mirror AppConfig; AGENTS/CLAUDE refreshed for tool envelopes/retries/commands; ARCH updated for tool output schema + toolchain versions.
- Use `rg -n` for search and `rg -u` for `.venv` vendor scans per charter; record citations in `ARCH.md`.
