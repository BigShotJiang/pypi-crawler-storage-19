"""Contract tests for canonical choice sets across parsers and config."""

from __future__ import annotations

from agenterm.commands.model import ReasoningEffortCmd
from agenterm.commands.parsers.config import complete_config, parse_config
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.choices.model import REASONING_EFFORTS


def test_config_parser_accepts_all_reasoning_effort_tokens() -> None:
    for effort in REASONING_EFFORTS:
        cmd = parse_config(["reasoning", "effort", effort])
        assert cmd == ReasoningEffortCmd(effort=effort)

    unset_cmd = parse_config(["reasoning", "effort", UNSET_MARKER])
    assert unset_cmd == ReasoningEffortCmd(effort=None)


def test_config_completions_include_all_reasoning_effort_tokens() -> None:
    suggestions = complete_config("reasoning effort ", None)
    for effort in REASONING_EFFORTS:
        assert effort in suggestions
    assert UNSET_MARKER in suggestions
