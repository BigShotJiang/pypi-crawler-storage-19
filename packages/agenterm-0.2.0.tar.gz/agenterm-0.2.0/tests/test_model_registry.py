"""Contract tests for the OpenAI model registry cache."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from agenterm.app.services.model_registry import (
    load_model_registry,
    refresh_model_registry,
    require_model_registry,
    validate_model_id_with_registry,
)
from agenterm.config.model import ProvidersConfig
from agenterm.core.errors import ValidationError
from agenterm.store.async_db import AsyncStore


class _Client:
    def __init__(self, ids: list[str]) -> None:
        self._ids = ids

    async def list_model_ids(self) -> list[str]:
        return list(self._ids)


def _store(tmp_path: Path) -> AsyncStore:
    return AsyncStore(tmp_path / "agenterm.db")


def test_model_registry_refresh_and_load(tmp_path: Path) -> None:
    store = _store(tmp_path)
    client = _Client(["gpt-5.2", "gpt-4.1"])
    registry = asyncio.run(
        refresh_model_registry(
            store=store,
            client=client,
            now=123,
        ),
    )
    assert registry.fetched_at == 123
    assert registry.models == frozenset({"openai/gpt-5.2", "openai/gpt-4.1"})

    loaded = asyncio.run(load_model_registry(store=store))
    assert loaded is not None
    assert loaded.fetched_at == 123
    assert "openai/gpt-5.2" in loaded.models


def test_model_registry_require_uses_fresh_cache(tmp_path: Path) -> None:
    store = _store(tmp_path)
    client = _Client(["gpt-5.2"])
    _ = asyncio.run(
        refresh_model_registry(
            store=store,
            client=client,
            now=1000,
        ),
    )
    cached = asyncio.run(require_model_registry(store=store, now=1000))
    assert cached is not None
    assert "openai/gpt-5.2" in cached.models


def test_model_registry_validation_rejects_unknown(tmp_path: Path) -> None:
    store = _store(tmp_path)
    client = _Client(["gpt-5.2"])
    _ = asyncio.run(refresh_model_registry(store=store, client=client, now=55))

    with pytest.raises(ValidationError):
        asyncio.run(
            validate_model_id_with_registry(
                "openai/gpt-unknown",
                store=store,
                providers=ProvidersConfig(),
                client=client,
            ),
        )
