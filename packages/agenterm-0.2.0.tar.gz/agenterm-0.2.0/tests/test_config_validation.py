"""Contract tests for cross-field config validation."""

from __future__ import annotations

import pytest

from agenterm.config.normalize import normalize_config
from agenterm.config.schema import to_raw_config
from agenterm.config.validate import validate_config
from agenterm.constants.limits import AGENT_MAX_TURNS_MAX
from agenterm.core.errors import ConfigError
from agenterm.core.json_types import JSONValue


def _validate(raw: dict[str, JSONValue]) -> None:
    normalized = normalize_config(to_raw_config(raw))
    validate_config(normalized)


def test_validate_config_allows_unknown_model_id() -> None:
    _validate({"agent": {"model": "openai/gpt-unknown"}})


def test_validate_config_rejects_agent_max_turns_out_of_range() -> None:
    with pytest.raises(ConfigError, match="agent.max_turns must be between"):
        _validate({"agent": {"max_turns": AGENT_MAX_TURNS_MAX + 1}})


def test_validate_config_rejects_gateway_route_without_allowlist() -> None:
    with pytest.raises(ConfigError, match="providers.gateway.routes.openrouter"):
        _validate(
            {
                "providers": {
                    "gateway": {
                        "routes": {
                            "openrouter": {
                                "provider": "openrouter",
                            }
                        }
                    }
                }
            }
        )


def test_validate_config_allows_gateway_route_with_allow_any_model() -> None:
    _validate(
        {
            "providers": {
                "gateway": {
                    "routes": {
                        "openrouter": {
                            "provider": "openrouter",
                            "allow_any_model": True,
                        }
                    }
                }
            }
        }
    )


def test_validate_config_rejects_delegate_bundle_as_default() -> None:
    with pytest.raises(ConfigError, match="default_bundles"):
        _validate({"tools": {"default_bundles": ["research"]}})


def test_validate_config_rejects_agent_run_bundle_main_scope() -> None:
    with pytest.raises(ConfigError, match="agent_run\\.bundle"):
        _validate({"tools": {"agent_run": {"bundle": "inspect"}}})


def test_validate_config_rejects_empty_bundle_definition() -> None:
    with pytest.raises(ConfigError, match="tools\\.bundles\\.empty"):
        _validate({"tools": {"bundles": {"empty": {}}}})
