"""Contract tests for MCP-as-FunctionTools bridging."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
from agents.agent import Agent, AgentBase
from agents.mcp import MCPServer
from agents.run_context import RunContextWrapper
from agents.tool import FunctionTool
from agents.tool_context import ToolContext
from mcp import types as mtypes

from agenterm.config.mcp_models import McpBridgeConfig
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import ValidationError
from agenterm.core.json_types import JSONValue
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import parse_mcp_tool_output_envelope
from agenterm.engine.mcp_function_tools import (
    build_mcp_function_tools,
    merge_mcp_function_tools,
)
from agenterm.engine.mcp_namespacing import NamespacedMcpServer, namespace_mcp_tool_name
from agenterm.engine.tool_output_clamp import ToolOutputClamp


class _StubServer(MCPServer):
    def __init__(self) -> None:
        super().__init__(use_structured_content=False)

    @property
    def name(self) -> str:
        return "stub"

    async def connect(self) -> None:  # noqa: D401 - test stub
        return None

    async def cleanup(self) -> None:  # noqa: D401 - test stub
        return None

    async def list_tools(
        self,
        run_context: RunContextWrapper | None = None,
        agent: AgentBase | None = None,
    ) -> list[mtypes.Tool]:
        return [
            mtypes.Tool(
                name="bat",
                description="read",
                inputSchema={"type": "object"},
            )
        ]

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, JSONValue] | None,
    ) -> mtypes.CallToolResult:
        return mtypes.CallToolResult(
            content=[mtypes.TextContent(type="text", text="ok")],
            structuredContent={"answer": 1},
            isError=False,
        )

    async def list_prompts(self) -> mtypes.ListPromptsResult:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, JSONValue] | None = None,
    ) -> mtypes.GetPromptResult:
        msg = "not used in tests"
        raise RuntimeError(msg)


def test_build_mcp_function_tools_returns_envelopes() -> None:
    approvals = ApprovalsContext(mode="auto")
    servers = [NamespacedMcpServer(server_key="files", inner=_StubServer())]
    bridge_cfg = McpBridgeConfig(max_content_items=10)
    agent = Agent(name="test")
    tool_context = ToolRuntimeContext(
        db_path=Path("db.sqlite"),
        session_id=None,
        branch_id=None,
        run_number=None,
        trace_id=None,
        plan_cache={},
        cancel_token=None,
    )

    async def _run() -> str:
        tools = await build_mcp_function_tools(
            servers=servers,
            approvals=approvals.mcp,
            bridge_cfg=bridge_cfg,
            output_clamp=ToolOutputClamp(10_000),
            convert_schemas_to_strict=False,
            run_context=tool_context,
            agent=agent,
        )
        assert len(tools) == 1
        tool = tools[0]
        assert isinstance(tool, FunctionTool)
        expected_name = namespace_mcp_tool_name(
            server_key="files",
            tool_name="bat",
        )
        assert tool.name == expected_name
        assert "properties" in tool.params_json_schema

        payload = json.dumps({"path": "a"}, ensure_ascii=True)
        ctx = ToolContext(
            context=tool_context,
            tool_name=tool.name,
            tool_call_id="call",
            tool_arguments=payload,
            tool_call=None,
        )
        output = await tool.on_invoke_tool(ctx, payload)
        assert isinstance(output, str)
        return output

    output = asyncio.run(_run())
    env = parse_mcp_tool_output_envelope(output)
    assert env is not None
    assert env.ok is True
    assert env.server_key == "files"
    assert env.tool_name == "bat"


def test_merge_mcp_function_tools_rejects_name_collision() -> None:
    async def _noop(_ctx: ToolContext, _payload: str) -> str:
        return "ok"

    base = [
        FunctionTool(
            name="mcp__files__bat",
            description="base",
            params_json_schema={"type": "object", "properties": {}},
            on_invoke_tool=_noop,
        )
    ]
    mcp = [
        FunctionTool(
            name="mcp__files__bat",
            description="mcp",
            params_json_schema={"type": "object", "properties": {}},
            on_invoke_tool=_noop,
        )
    ]

    with pytest.raises(ValidationError, match="collide"):
        merge_mcp_function_tools(existing_tools=base, mcp_tools=mcp)
