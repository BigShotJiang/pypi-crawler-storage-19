"""Contract tests for iTerm2 OSC-1337 inline image formatting."""

from __future__ import annotations

from agenterm.ui.iterm2 import iterm2_inline_image_sequence


def test_iterm2_inline_image_sequence_small_is_single_sequence() -> None:
    seq = iterm2_inline_image_sequence(b"abc", name="x.png", width=None)
    assert "MultipartFile=" not in seq
    assert "FilePart=" not in seq
    assert "FileEnd" not in seq
    assert "]1337;File=" in seq


def test_iterm2_inline_image_sequence_large_is_multipart_and_bounded() -> None:
    data = b"a" * 900_000
    seq = iterm2_inline_image_sequence(data, name="x.png", width=None)

    assert "]1337;MultipartFile=" in seq
    assert "]1337;FilePart=" in seq
    assert "]1337;FileEnd" in seq

    segments = [s for s in seq.split("\a") if s]
    assert segments
    for s in segments:
        assert len(s) + 1 <= 1_048_576
