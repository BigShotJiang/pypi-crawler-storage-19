"""Contract tests for MCP server lifecycle management."""

from __future__ import annotations

import asyncio

from agents.mcp import MCPServer
from mcp.types import CallToolResult, GetPromptResult, ListPromptsResult, Tool as MCPTool

from agenterm.core.errors import McpConnectError
from agenterm.engine.mcp_pool import McpServerPool


class FakeMcpServer(MCPServer):
    """Test double for verifying connect/cleanup ordering."""

    def __init__(
        self,
        name: str,
        calls: list[str],
        *,
        fail_connect: bool = False,
        fail_cleanup: bool = False,
    ) -> None:
        super().__init__(use_structured_content=False)
        self._name = name
        self._calls = calls
        self._fail_connect = fail_connect
        self._fail_cleanup = fail_cleanup

    @property
    def name(self) -> str:
        return self._name

    async def connect(self) -> None:
        self._calls.append(f"connect:{self._name}")
        if self._fail_connect:
            msg = f"boom: {self._name}"
            raise RuntimeError(msg)

    async def cleanup(self) -> None:
        self._calls.append(f"cleanup:{self._name}")
        if self._fail_cleanup:
            msg = f"cleanup boom: {self._name}"
            raise RuntimeError(msg)

    async def list_tools(
        self,
        run_context: object | None = None,
        agent: object | None = None,
    ) -> list[MCPTool]:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def call_tool(
        self,
        tool_name: str,
        arguments: object | None,
    ) -> CallToolResult:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def list_prompts(self) -> ListPromptsResult:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def get_prompt(
        self,
        name: str,
        arguments: object | None = None,
    ) -> GetPromptResult:
        msg = "not used in tests"
        raise RuntimeError(msg)


def test_mcp_pool_connects_then_cleans_up_in_order() -> None:
    calls: list[str] = []
    pool = McpServerPool(
        [
            FakeMcpServer("a", calls),
            FakeMcpServer("b", calls),
            FakeMcpServer("c", calls),
        ],
    )

    async def _run() -> None:
        await pool.connect()
        await pool.cleanup()

    asyncio.run(_run())

    assert calls == [
        "connect:a",
        "connect:b",
        "connect:c",
        "cleanup:c",
        "cleanup:b",
        "cleanup:a",
    ]


def test_mcp_pool_cleans_up_on_partial_connect_failure() -> None:
    calls: list[str] = []
    pool = McpServerPool(
        [
            FakeMcpServer("a", calls),
            FakeMcpServer("b", calls, fail_connect=True),
            FakeMcpServer("c", calls),
        ],
    )

    async def _run() -> None:
        try:
            await pool.connect()
        except McpConnectError:
            return
        raise RuntimeError("expected connect() to fail")

    asyncio.run(_run())

    assert calls == [
        "connect:a",
        "connect:b",
        "cleanup:a",
    ]


def test_mcp_pool_async_context_cleans_up_on_exception() -> None:
    calls: list[str] = []
    pool = McpServerPool([FakeMcpServer("a", calls)])

    async def _run() -> None:
        try:
            async with pool:
                raise ValueError("boom")
        except ValueError:
            return
        raise RuntimeError("expected exception to propagate")

    asyncio.run(_run())

    assert calls == [
        "connect:a",
        "cleanup:a",
    ]


def test_mcp_pool_cleanup_raises_on_failure() -> None:
    calls: list[str] = []
    pool = McpServerPool([FakeMcpServer("a", calls, fail_cleanup=True)])

    async def _run() -> None:
        await pool.connect()
        await pool.cleanup()

    try:
        asyncio.run(_run())
    except McpConnectError:
        pass
    else:
        raise RuntimeError("expected cleanup() to fail")

    assert calls == [
        "connect:a",
        "cleanup:a",
    ]
