"""Contract tests for branch lifecycle services."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from openai.types.responses.response_input_item_param import Message as InputMessageParam
from openai.types.responses.response_input_text_param import ResponseInputTextParam
from openai.types.responses.response_output_message_param import ResponseOutputMessageParam
from openai.types.responses.response_output_text_param import ResponseOutputTextParam

from agenterm.core.errors import ConfigError
from agenterm.core.token_usage import TokenUsage
from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import BranchMetaUpsert, get_branch_meta, upsert_branch_meta
from agenterm.store.branch.service import (
    create_branch_from_head,
    create_branch_from_run,
    delete_branch,
)
from agenterm.store.runs.repo import insert_run_start, update_run_status
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.repo import SessionMetadataUpsert, update_session_head
from agenterm.store.session.repo import upsert_session_metadata
from agenterm.store.session.request_usage import RequestUsageRecord, insert_request_usage


def _seed_session(store: AsyncStore, *, session_id: str, cwd: Path) -> None:
    asyncio.run(
        upsert_session_metadata(
            store=store,
            payload=SessionMetadataUpsert(
                session_id=session_id,
                kind="repl",
                cwd=cwd,
                config_path=None,
                model="openai/gpt-5.2",
                tools_enabled=True,
                trace_id=None,
                group_id=None,
                head_branch_id="main",
            ),
        ),
    )
    asyncio.run(
        upsert_branch_meta(
            store=store,
            payload=BranchMetaUpsert(
                session_id=session_id,
                branch_id="main",
                kind="main",
                title=None,
                pinned=True,
                created_reason=None,
                parent_branch_id=None,
                fork_run_number=None,
                agent_name="default",
                agent_path=None,
                agent_sha256=None,
                store_enabled=True,
                last_response_id="resp_1",
            ),
        ),
    )


def _add_turn(session: AgentermSQLiteSession, *, user_text: str, assistant_text: str) -> None:
    user_part: ResponseInputTextParam = {"type": "input_text", "text": user_text}
    user_msg: InputMessageParam = {
        "type": "message",
        "role": "user",
        "content": [user_part],
    }
    assistant_part: ResponseOutputTextParam = {
        "type": "output_text",
        "text": assistant_text,
        "annotations": [],
    }
    assistant_msg: ResponseOutputMessageParam = {
        "id": f"msg_{user_text}",
        "type": "message",
        "role": "assistant",
        "status": "completed",
        "content": [assistant_part],
    }
    asyncio.run(session.add_items([user_msg, assistant_msg]))


def _turn_count(session: AgentermSQLiteSession, *, branch_id: str) -> int:
    return len(asyncio.run(session.get_conversation_turns(branch_id=branch_id)))


def test_create_branch_from_head_copies_conversation(tmp_path: Path) -> None:
    meta_path = tmp_path / "store.sqlite3"
    history_path = tmp_path / "history.sqlite3"
    asyncio.run(ensure_store_schema(meta_path))
    store = AsyncStore(meta_path)
    session_id = "sess-1"
    _seed_session(store, session_id=session_id, cwd=tmp_path)

    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_path),
        create_tables=True,
    )
    _add_turn(session, user_text="hello", assistant_text="hi")
    _add_turn(session, user_text="next", assistant_text="ok")

    meta = asyncio.run(
        create_branch_from_head(
            session=session,
            store=store,
            session_id=session_id,
            branch_id="branch-head",
            kind="fork",
            created_reason="manual",
            agent_name="default",
            agent_path=None,
            agent_sha256=None,
        ),
    )
    assert meta.branch_id == "branch-head"
    assert session.current_branch_id == "branch-head"
    assert _turn_count(session, branch_id="main") == 2
    assert _turn_count(session, branch_id="branch-head") == 2


def test_create_branch_from_run_is_exclusive_and_sets_anchor(tmp_path: Path) -> None:
    meta_path = tmp_path / "store.sqlite3"
    history_path = tmp_path / "history.sqlite3"
    asyncio.run(ensure_store_schema(meta_path))
    store = AsyncStore(meta_path)
    session_id = "sess-1"
    _seed_session(store, session_id=session_id, cwd=tmp_path)

    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_path),
        create_tables=True,
    )
    _add_turn(session, user_text="hello", assistant_text="hi")
    _add_turn(session, user_text="second", assistant_text="ok")

    run1 = asyncio.run(
        insert_run_start(
            store=store,
            session_id=session_id,
            branch_id="main",
            run_number=1,
            trace_id=None,
        ),
    )
    asyncio.run(
        update_run_status(
            store=store,
            run_id=run1.run_id,
            status="completed",
            response_id="resp_turn1",
            error_json=None,
            branch_turn_start=1,
            branch_turn_end=1,
        ),
    )
    run2 = asyncio.run(
        insert_run_start(
            store=store,
            session_id=session_id,
            branch_id="main",
            run_number=2,
            trace_id=None,
        ),
    )
    asyncio.run(
        update_run_status(
            store=store,
            run_id=run2.run_id,
            status="completed",
            response_id="resp_turn2",
            error_json=None,
            branch_turn_start=2,
            branch_turn_end=2,
        ),
    )

    asyncio.run(
        insert_request_usage(
            store=store,
            records=[
                RequestUsageRecord(
                    session_id=session_id,
                    branch_id="main",
                    kind="response",
                    run_number=1,
                    request_index=0,
                    model="openai/gpt-5.2",
                    previous_response_id=None,
                    response_id="resp_turn1",
                    usage=TokenUsage(
                        requests=1,
                        input_tokens=1,
                        input_cached_tokens=0,
                        output_tokens=1,
                        output_reasoning_tokens=0,
                        total_tokens=2,
                    ),
                )
            ],
        ),
    )

    meta = asyncio.run(
        create_branch_from_run(
            session=session,
            store=store,
            session_id=session_id,
            run_number=2,
            branch_id="branch-run",
            agent_name="default",
            agent_path=None,
            agent_sha256=None,
        ),
    )
    assert meta.branch_id == "branch-run"
    assert meta.parent_branch_id == "main"
    assert meta.fork_run_number == 2
    assert meta.last_response_id == "resp_turn1"
    assert _turn_count(session, branch_id="main") == 2
    assert _turn_count(session, branch_id="branch-run") == 1


def test_delete_branch_enforces_main_and_force(tmp_path: Path) -> None:
    meta_path = tmp_path / "store.sqlite3"
    history_path = tmp_path / "history.sqlite3"
    asyncio.run(ensure_store_schema(meta_path))
    store = AsyncStore(meta_path)
    session_id = "sess-1"
    _seed_session(store, session_id=session_id, cwd=tmp_path)

    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_path),
        create_tables=True,
    )
    _add_turn(session, user_text="hello", assistant_text="hi")

    asyncio.run(
        create_branch_from_head(
            session=session,
            store=store,
            session_id=session_id,
            branch_id="branch-del",
            kind="fork",
            created_reason=None,
            agent_name="default",
            agent_path=None,
            agent_sha256=None,
        ),
    )
    asyncio.run(
        upsert_branch_meta(
            store=store,
            payload=BranchMetaUpsert(
                session_id=session_id,
                branch_id="branch-del",
                kind="fork",
                title=None,
                pinned=False,
                created_reason=None,
                parent_branch_id="main",
                fork_run_number=None,
                agent_name="default",
                agent_path=None,
                agent_sha256=None,
                store_enabled=True,
                last_response_id="resp_1",
            ),
        ),
    )
    asyncio.run(
        update_session_head(
            store=store,
            session_id=session_id,
            head_branch_id="branch-del",
        ),
    )

    with pytest.raises(ConfigError, match="Cannot delete the 'main' branch"):
        asyncio.run(
            delete_branch(
                session=session,
                store=store,
                session_id=session_id,
                branch_id="main",
                force=False,
            ),
        )

    with pytest.raises(ConfigError, match="Cannot delete current branch"):
        asyncio.run(
            delete_branch(
                session=session,
                store=store,
                session_id=session_id,
                branch_id="branch-del",
                force=False,
            ),
        )

    deleted = asyncio.run(
        delete_branch(
            session=session,
            store=store,
            session_id=session_id,
            branch_id="branch-del",
            force=True,
        ),
    )
    assert deleted is True
    assert session.current_branch_id == "main"
    assert asyncio.run(get_branch_meta(store, session_id, "branch-del")) is None
