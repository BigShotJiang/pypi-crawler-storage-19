"""Contract tests for approvals context subscription fan-out."""

from __future__ import annotations

import asyncio
from agenterm.core.approvals import ApprovalEvent, ApprovalsContext


def test_hub_subscribe_and_unsubscribe() -> None:
    async def _run() -> list[ApprovalEvent]:
        hub = ApprovalsContext()
        events: list[ApprovalEvent] = []

        token = hub.subscribe(on_register=events.append)
        _ = hub.shell.register(["echo hi"], cwd=".")
        hub.unsubscribe(token)
        _ = hub.shell.register(["echo again"], cwd=".")
        return events

    events = asyncio.run(_run())
    assert len(events) == 1
    assert events[0].family == "shell"


def test_hub_emits_resolve_events() -> None:
    async def _run() -> list[ApprovalEvent]:
        hub = ApprovalsContext()
        resolved: list[ApprovalEvent] = []

        token = hub.subscribe(on_resolve=resolved.append)
        item = hub.shell.register(["pwd"], cwd=".")
        waiter = asyncio.create_task(hub.shell.wait(item.id))
        await asyncio.sleep(0)
        hub.shell.resolve(item.id, approved=True)
        await waiter
        hub.unsubscribe(token)
        return resolved

    resolved = asyncio.run(_run())
    assert len(resolved) == 1
    assert resolved[0].decision is not None
    assert resolved[0].decision.approved is True
