"""Contract tests for built-in guardrails shipped with agenterm."""

from __future__ import annotations

import asyncio

from agents.agent import Agent
from agents.run_context import RunContextWrapper

from agenterm.config.model import GuardrailsConfig
from agenterm.core.guardrails_loader import prime_guardrails
from agenterm.core.guardrails_registry import resolve_input_guardrails


def test_builtin_guardrail_is_registered_and_resolves() -> None:
    prime_guardrails(GuardrailsConfig(input=["no_secrets_input"]))
    guardrails = resolve_input_guardrails(["no_secrets_input"])
    assert len(guardrails) == 1
    assert guardrails[0].get_name() == "no_secrets_input"


def test_no_secrets_input_trips_on_key_like_string() -> None:
    prime_guardrails(GuardrailsConfig(input=["no_secrets_input"]))
    guardrail = resolve_input_guardrails(["no_secrets_input"])[0]

    agent = Agent(name="test")
    ctx = RunContextWrapper(context=object())

    result = asyncio.run(
        guardrail.run(
            agent=agent,
            input="sk-" + ("a" * 24),
            context=ctx,
        ),
    )
    assert result.output.tripwire_triggered is True


def test_no_secrets_input_allows_normal_text() -> None:
    prime_guardrails(GuardrailsConfig(input=["no_secrets_input"]))
    guardrail = resolve_input_guardrails(["no_secrets_input"])[0]

    agent = Agent(name="test")
    ctx = RunContextWrapper(context=object())

    result = asyncio.run(
        guardrail.run(
            agent=agent,
            input="Please refactor this function safely.",
            context=ctx,
        ),
    )
    assert result.output.tripwire_triggered is False
