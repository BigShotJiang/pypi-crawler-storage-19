"""Contract tests for inspect CLI JSON payloads."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
from agents.extensions.memory import AdvancedSQLiteSession
from openai.types.responses.response_input_item_param import Message as InputMessageParam
from openai.types.responses.response_input_text_param import ResponseInputTextParam
from openai.types.responses.response_output_message_param import ResponseOutputMessageParam
from openai.types.responses.response_output_text_param import ResponseOutputTextParam
from typer.testing import CliRunner

from agenterm.cli import app
from agenterm.config.paths import history_db_path, meta_store_path
from agenterm.core.envelope import iso_timestamp
from agenterm.core.token_usage import TokenUsage
from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import BranchMetaUpsert, upsert_branch_meta
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.repo import SessionMetadataUpsert, upsert_session_metadata
from agenterm.store.session.request_usage import RequestUsageRecord, insert_request_usage
from agenterm.store.run_events import RunEventEnvelope, RunEventPayload, insert_run_event
from agenterm.store.runs.repo import insert_run_start, update_run_status


def _add_turn(session: AdvancedSQLiteSession, *, user_text: str, assistant_text: str) -> None:
    user_part: ResponseInputTextParam = {"type": "input_text", "text": user_text}
    user_msg: InputMessageParam = {
        "type": "message",
        "role": "user",
        "content": [user_part],
    }
    assistant_part: ResponseOutputTextParam = {
        "type": "output_text",
        "text": assistant_text,
        "annotations": [],
    }
    assistant_msg: ResponseOutputMessageParam = {
        "id": "msg_1",
        "type": "message",
        "role": "assistant",
        "status": "completed",
        "content": [assistant_part],
    }
    asyncio.run(session.add_items([user_msg, assistant_msg]))


def test_inspect_run_and_events_json(monkeypatch: pytest.MonkeyPatch) -> None:
    runner = CliRunner()
    with runner.isolated_filesystem():
        home = Path.cwd() / "home"
        home.mkdir(parents=True, exist_ok=True)
        monkeypatch.setenv("HOME", str(home))
        meta_path = meta_store_path()
        history_path = history_db_path()
        asyncio.run(ensure_store_schema(meta_path))
        store = AsyncStore(meta_path)
        session_id = "sess-1"

        asyncio.run(
            upsert_session_metadata(
                store=store,
                payload=SessionMetadataUpsert(
                    session_id=session_id,
                    kind="run",
                    cwd=Path.cwd(),
                    config_path=None,
                    model="openai/gpt-5.2",
                    tools_enabled=True,
                    trace_id="trace-1",
                    group_id=None,
                    head_branch_id="main",
                ),
            ),
        )
        asyncio.run(
            upsert_branch_meta(
                store=store,
                payload=BranchMetaUpsert(
                    session_id=session_id,
                    branch_id="main",
                    kind="main",
                    title=None,
                    pinned=True,
                    created_reason=None,
                    parent_branch_id=None,
                    fork_run_number=None,
                    agent_name="default",
                    agent_path=None,
                    agent_sha256=None,
                    store_enabled=True,
                    last_response_id=None,
                ),
            ),
        )

        session = AdvancedSQLiteSession(
            session_id=session_id,
            db_path=str(history_path),
            create_tables=True,
        )
        _add_turn(session, user_text="hello", assistant_text="hi")

        record = asyncio.run(
            insert_run_start(
                store=store,
                session_id=session_id,
                branch_id="main",
                run_number=1,
                trace_id="trace-1",
            ),
        )
        asyncio.run(
            update_run_status(
                store=store,
                run_id=record.run_id,
                status="completed",
                response_id="resp_1",
                error_json=None,
                branch_turn_start=1,
                branch_turn_end=1,
            ),
        )
        asyncio.run(
            insert_request_usage(
                store=store,
                records=[
                    RequestUsageRecord(
                        session_id=session_id,
                        branch_id="main",
                        kind="response",
                        run_number=1,
                        request_index=0,
                        model="openai/gpt-5.2",
                        previous_response_id=None,
                        response_id="resp_1",
                        usage=TokenUsage(
                            requests=1,
                            input_tokens=2,
                            input_cached_tokens=0,
                            output_tokens=3,
                            output_reasoning_tokens=1,
                            total_tokens=5,
                        ),
                    )
                ],
            ),
        )
        envelope = RunEventEnvelope(
            schema_version=1,
            trace_id="trace-1",
            ts=iso_timestamp(),
            event=RunEventPayload(
                type="response.created",
                plane="openai",
                model="openai/gpt-5.2",
                response_id="resp_1",
                request_index=0,
                payload={"note": "ok"},
                raw_provider_payload=None,
            ),
        )
        asyncio.run(
            insert_run_event(
                store=store,
                session_id=session_id,
                branch_id="main",
                run_number=1,
                request_index=0,
                event_seq=0,
                event_type="response.created",
                response_id="resp_1",
                model="openai/gpt-5.2",
                envelope=envelope,
            ),
        )

        env = {"HOME": str(home)}
        result = runner.invoke(
            app,
            ["inspect", "run", session_id, "1", "--format", "json"],
            env=env,
        )
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert payload["result"]["resource"] == "inspect.run"
        body = payload["result"]["payload"]
        assert body["run_number"] == 1
        assert body["status"] == "completed"
        assert body["response_id"] == "resp_1"
        assert body["events_count"] == 1
        assert len(body["items"]) == 2
        assert body["usage"]["total_tokens"] == 5

        events = runner.invoke(
            app,
            ["inspect", "run-events", session_id, "1", "--format", "json"],
            env=env,
        )
        assert events.exit_code == 0, events.output
        events_payload = json.loads(events.output)
        assert events_payload["result"]["resource"] == "inspect.run-events"
        events_body = events_payload["result"]["payload"]
        assert len(events_body["events"]) == 1
        assert events_body["events"][0]["event"]["payload"]["note"] == "ok"
