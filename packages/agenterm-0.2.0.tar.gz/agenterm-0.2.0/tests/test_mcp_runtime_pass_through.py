"""Contract tests for MCP runtime configuration pass-through."""

from __future__ import annotations

import pytest
from agents.mcp import ToolFilter
from mcp.client.session import MessageHandlerFnT

from agenterm.config.model import (
    AppConfig,
    McpConfig,
    McpServerConfig,
    McpServerRuntimeConfig,
    McpServerSseConfig,
    McpServerStdioConfig,
    McpServerStreamableHttpConfig,
    RetriesConfig,
    RetryPolicyConfig,
)
from agenterm.engine.mcp_factory import build_mcp_servers
from agenterm.engine.mcp_namespacing import NamespacedMcpServer
from agenterm.core.json_types import JSONMapping


class _DummyServer:
    def __init__(
        self,
        *,
        params: JSONMapping,
        cache_tools_list: bool,
        name: str | None,
        client_session_timeout_seconds: float | None,
        tool_filter: ToolFilter | None,
        use_structured_content: bool,
        max_retry_attempts: int,
        retry_backoff_seconds_base: float,
        message_handler: MessageHandlerFnT | None,
    ) -> None:
        self.params = params
        self.cache_tools_list = cache_tools_list
        self.client_session_timeout_seconds = client_session_timeout_seconds
        self.max_retry_attempts = max_retry_attempts
        self.retry_backoff_seconds_base = retry_backoff_seconds_base
        self.use_structured_content = use_structured_content
        self.name = name or "dummy"


def test_mcp_runtime_values_passed_to_constructors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captures: list[_DummyServer] = []

    def _stdio(
        *,
        params: JSONMapping,
        cache_tools_list: bool,
        name: str | None,
        client_session_timeout_seconds: float | None,
        tool_filter: ToolFilter | None,
        use_structured_content: bool,
        max_retry_attempts: int,
        retry_backoff_seconds_base: float,
        message_handler: MessageHandlerFnT | None,
    ) -> _DummyServer:
        server = _DummyServer(
            params=params,
            cache_tools_list=cache_tools_list,
            name=name,
            client_session_timeout_seconds=client_session_timeout_seconds,
            tool_filter=tool_filter,
            use_structured_content=use_structured_content,
            max_retry_attempts=max_retry_attempts,
            retry_backoff_seconds_base=retry_backoff_seconds_base,
            message_handler=message_handler,
        )
        captures.append(server)
        return server

    def _sse(
        *,
        params: JSONMapping,
        cache_tools_list: bool,
        name: str | None,
        client_session_timeout_seconds: float | None,
        tool_filter: ToolFilter | None,
        use_structured_content: bool,
        max_retry_attempts: int,
        retry_backoff_seconds_base: float,
        message_handler: MessageHandlerFnT | None,
    ) -> _DummyServer:
        server = _DummyServer(
            params=params,
            cache_tools_list=cache_tools_list,
            name=name,
            client_session_timeout_seconds=client_session_timeout_seconds,
            tool_filter=tool_filter,
            use_structured_content=use_structured_content,
            max_retry_attempts=max_retry_attempts,
            retry_backoff_seconds_base=retry_backoff_seconds_base,
            message_handler=message_handler,
        )
        captures.append(server)
        return server

    def _streamable(
        *,
        params: JSONMapping,
        cache_tools_list: bool,
        name: str | None,
        client_session_timeout_seconds: float | None,
        tool_filter: ToolFilter | None,
        use_structured_content: bool,
        max_retry_attempts: int,
        retry_backoff_seconds_base: float,
        message_handler: MessageHandlerFnT | None,
    ) -> _DummyServer:
        server = _DummyServer(
            params=params,
            cache_tools_list=cache_tools_list,
            name=name,
            client_session_timeout_seconds=client_session_timeout_seconds,
            tool_filter=tool_filter,
            use_structured_content=use_structured_content,
            max_retry_attempts=max_retry_attempts,
            retry_backoff_seconds_base=retry_backoff_seconds_base,
            message_handler=message_handler,
        )
        captures.append(server)
        return server

    monkeypatch.setattr("agenterm.engine.mcp_factory.MCPServerStdio", _stdio)
    monkeypatch.setattr("agenterm.engine.mcp_factory.MCPServerSse", _sse)
    monkeypatch.setattr("agenterm.engine.mcp_factory.MCPServerStreamableHttp", _streamable)

    runtime = McpServerRuntimeConfig(
        cache_tools=True,
        session_timeout=7.5,
    )
    retries = RetriesConfig(
        mcp=RetryPolicyConfig(
            max_retries=3,
            base_backoff_seconds=1.25,
            max_backoff_seconds=5.0,
            jitter_ratio=0.1,
            retry_after_max_seconds=None,
        ),
        provider=AppConfig().retries.provider,
        store=AppConfig().retries.store,
    )
    cfg = AppConfig(
        retries=retries,
        mcp=McpConfig(
            servers=[
                McpServerConfig(
                    key="stdio",
                    kind="stdio",
                    name="stdio",
                    stdio=McpServerStdioConfig(command="echo"),
                    runtime=runtime,
                ),
                McpServerConfig(
                    key="sse",
                    kind="sse",
                    name="sse",
                    sse=McpServerSseConfig(url="https://example.com"),
                    runtime=runtime,
                ),
                McpServerConfig(
                    key="stream",
                    kind="streamable_http",
                    name="stream",
                    streamable_http=McpServerStreamableHttpConfig(
                        url="https://example.com",
                    ),
                    runtime=runtime,
                ),
            ]
        )
    )

    servers = build_mcp_servers(cfg)
    assert len(servers) == 3
    assert len(captures) == 3
    for server in captures:
        assert server.cache_tools_list is True
        assert server.client_session_timeout_seconds == 7.5
        assert server.max_retry_attempts == 0
        assert server.retry_backoff_seconds_base == 1.0

    for server in servers:
        assert isinstance(server, NamespacedMcpServer)
        policy = server.retry_policy
        assert policy is not None
        assert policy.max_retries == 3
        assert policy.base_backoff_seconds == 1.25
        assert policy.max_backoff_seconds == 5.0
        assert policy.jitter_ratio == 0.1
