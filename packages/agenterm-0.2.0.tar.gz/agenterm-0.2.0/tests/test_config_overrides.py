"""Contract tests for config overrides and validation edges."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from agenterm.config.runtime import load_app_config
from agenterm.core.errors import ConfigError
from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import BranchMetaUpsert, get_branch_meta, upsert_branch_meta
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.factory import SessionFactoryConfig, make_session
from agenterm.store.session.repo import SessionMetadataUpsert, upsert_session_metadata


def _seed_session(store: AsyncStore, *, session_id: str, cwd: Path) -> None:
    asyncio.run(
        upsert_session_metadata(
            store=store,
            payload=SessionMetadataUpsert(
                session_id=session_id,
                kind="run",
                cwd=cwd,
                config_path=None,
                model="openai/gpt-5.2",
                tools_enabled=True,
                trace_id=None,
                group_id=None,
                head_branch_id="main",
            ),
        ),
    )
    asyncio.run(
        upsert_branch_meta(
            store=store,
            payload=BranchMetaUpsert(
                session_id=session_id,
                branch_id="main",
                kind="main",
                title=None,
                pinned=True,
                created_reason=None,
                parent_branch_id=None,
                fork_run_number=None,
                agent_name="default",
                agent_path=None,
                agent_sha256=None,
                store_enabled=True,
                last_response_id="resp_123",
            ),
        ),
    )


def test_store_override_clears_last_response_id(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db_path))
    store = AsyncStore(db_path)
    _seed_session(store, session_id="sess-1", cwd=tmp_path)

    monkeypatch.setattr(
        "agenterm.store.session.factory.session_store",
        lambda: AsyncStore(db_path),
    )

    cfg = SessionFactoryConfig(
        mode="run",
        cwd=tmp_path,
        config_path=None,
        model="openai/gpt-5.2",
        tools_enabled=True,
        trace_id=None,
        group_id=None,
        session_id="sess-1",
        branch_id=None,
        store_enabled=True,
        store_override=False,
        agent_name="default",
        agent_path=None,
        agent_sha256=None,
    )
    result = asyncio.run(make_session(cfg))
    assert result.branch_meta is not None
    assert result.branch_meta.store_enabled is False
    assert result.branch_meta.last_response_id is None

    meta = asyncio.run(get_branch_meta(store, "sess-1", "main"))
    assert meta is not None
    assert meta.store_enabled is False
    assert meta.last_response_id is None


def test_text_format_and_file_are_mutually_exclusive(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "model:\n"
        "  text_format:\n"
        "    type: json_schema\n"
        "    name: answer\n"
        "    schema:\n"
        "      type: object\n"
        "    strict: true\n"
        "  text_format_file: schema.json\n",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="text_format.*text_format_file"):
        load_app_config(None)


@pytest.mark.parametrize(
    "retries_block, match_text",
    [
        ("provider:\n    max_retries: -1\n", "retries.provider.max_retries"),
        ("mcp:\n    base_backoff_seconds: 0\n", "retries.mcp.base_backoff_seconds"),
        ("store:\n    jitter_ratio: 2\n", "retries.store.jitter_ratio"),
    ],
)
def test_retries_validation_rejects_invalid_values(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    retries_block: str,
    match_text: str,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "retries:\n"
        f"  {retries_block}",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match=match_text):
        load_app_config(None)


def test_mcp_runtime_rejects_invalid_session_timeout(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "mcp:\n"
        "  servers:\n"
        "    - key: test\n"
        "      kind: stdio\n"
        "      stdio:\n"
        "        command: echo\n"
        "      runtime:\n"
        "        session_timeout: 0\n",
        encoding="utf-8",
    )
    with pytest.raises(ConfigError, match="runtime.session_timeout"):
        load_app_config(None)
