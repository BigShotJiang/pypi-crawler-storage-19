"""Contract tests for agent resolution and CLI commands."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from agenterm.cli import app
from agenterm.config.runtime import load_app_config


def _write_agent_file(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_agent_resolution_prefers_local_over_global(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    local_path = tmp_path / ".agenterm" / "agents" / "default.md"
    global_path = home / ".agenterm" / "agents" / "default.md"
    _write_agent_file(local_path, "local agent")
    _write_agent_file(global_path, "global agent")

    cfg = load_app_config(None)
    assert cfg.agent.instructions == "local agent"
    assert cfg.agent.path == local_path
    assert cfg.agent.source == "local"


def test_agent_resolution_global_fallback(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    global_path = home / ".agenterm" / "agents" / "default.md"
    _write_agent_file(global_path, "global agent")

    cfg = load_app_config(None)
    assert cfg.agent.instructions == "global agent"
    assert cfg.agent.path == global_path
    assert cfg.agent.source == "global"


def test_agent_resolution_bundled_fallback(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg = load_app_config(None)
    assert cfg.agent.name == "default"
    assert cfg.agent.source == "bundled"
    assert cfg.agent.path is None
    assert cfg.agent.instructions


def test_agent_override_sets_explicit_flag(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg = load_app_config(None, agent_name="coding_agent")
    assert cfg.agent.name == "coding_agent"
    assert cfg.agent.explicit is True


def test_cli_agents_subcommands_are_reachable() -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["agents", "--help"])
    assert result.exit_code == 0
    assert "list" in result.output
    assert "show" in result.output
    assert "path" in result.output
    assert "save" in result.output


def test_cli_agents_show_plain_and_json() -> None:
    runner = CliRunner()
    with runner.isolated_filesystem():
        agent_path = Path.cwd() / ".agenterm" / "agents" / "default.md"
        _write_agent_file(agent_path, "cli agent")

        plain = runner.invoke(app, ["agents", "show", "--plain"])
        assert plain.exit_code == 0, plain.output
        assert "cli agent" in plain.output

        result = runner.invoke(app, ["agents", "show", "--format", "json"])
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert payload["result"]["payload"]["text"] == "cli agent"
        assert payload["result"]["payload"]["source"] == "local"


def test_cli_agents_save_global() -> None:
    runner = CliRunner()
    with runner.isolated_filesystem():
        home = Path.cwd() / "home"
        home.mkdir(parents=True, exist_ok=True)

        result = runner.invoke(
            app,
            ["agents", "save", "--scope", "global"],
            env={"HOME": str(home)},
        )
        assert result.exit_code == 0, result.output

        default_path = home / ".agenterm" / "agents" / "default.md"
        coding_path = home / ".agenterm" / "agents" / "coding_agent.md"
        assert default_path.is_file()
        assert coding_path.is_file()


def test_cli_agents_save_local(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    runner = CliRunner()
    result = runner.invoke(app, ["agents", "save", "--scope", "local"])
    assert result.exit_code == 0, result.output

    default_path = tmp_path / ".agenterm" / "agents" / "default.md"
    coding_path = tmp_path / ".agenterm" / "agents" / "coding_agent.md"
    assert default_path.is_file()
    assert coding_path.is_file()


def test_agents_save_rejects_overwrite_without_force(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    agent_path = home / ".agenterm" / "agents" / "coding_agent.md"
    _write_agent_file(agent_path, "existing agent\n")

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["agents", "save", "--scope", "global"],
        env={"HOME": str(home)},
    )
    assert result.exit_code != 0
    assert "exist" in result.output.lower() or "error" in result.output.lower()


def test_agents_save_allows_overwrite_with_force(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    agent_path = home / ".agenterm" / "agents" / "coding_agent.md"
    _write_agent_file(agent_path, "existing agent\n")

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["agents", "save", "--scope", "global", "--force"],
        env={"HOME": str(home)},
    )
    assert result.exit_code == 0, result.output
    assert agent_path.is_file()
    content = agent_path.read_text(encoding="utf-8")
    assert "existing agent" not in content
