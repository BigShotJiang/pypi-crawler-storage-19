"""Contract tests for agent_run MCP exposure."""

from __future__ import annotations

import asyncio
from pathlib import Path
from types import MappingProxyType

from agents.tool import FunctionTool
from agents.tool_context import ToolContext
from mcp import types as mtypes
from pytest import MonkeyPatch

from agenterm.artifacts.agent_run import persist_agent_run_report
from agenterm.config.model import AppConfig
from agenterm.config.paths import meta_store_path
from agenterm.core.json_types import JSONValue
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import FunctionToolOutputEnvelope
from agenterm.engine.mcp_expose import McpExposeServer, McpExposeState
from agenterm.store.async_db import AsyncStore


def _stub_tool(name: str, envelope: str) -> FunctionTool:
    async def _invoke(
        _ctx: ToolContext[ToolRuntimeContext | None],
        _raw: str,
    ) -> str:
        return envelope

    return FunctionTool(
        name=name,
        description=f"stub {name}",
        params_json_schema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


def test_agent_run_mcp_expose_returns_structured_report(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    db_path = meta_store_path()
    store = AsyncStore(db_path)
    payload: dict[str, JSONValue] = {
        "schema_version": 2,
        "tool_call_id": "call-1",
        "trace_id": None,
        "created_at": "2026-01-02T00:00:00Z",
        "model": "openai/gpt-5.2-pro",
        "instructions": "do it",
        "input": "hello",
        "input_items": [],
        "output_text": "done",
        "output_items": [],
        "tools_available": [],
        "tools_used": [],
        "tool_counts": {},
        "truncated": False,
        "warnings": [],
        "usage": {
            "requests": 1,
            "input_tokens": 0,
            "input_cached_tokens": 0,
            "output_tokens": 0,
            "output_reasoning_tokens": 0,
            "total_tokens": 0,
        },
        "response_id": None,
        "response_ids": [],
    }
    record = asyncio.run(
        persist_agent_run_report(
            store=store,
            session_id=None,
            source_id="call-1",
            payload=payload,
        )
    )
    envelope = FunctionToolOutputEnvelope(
        tool="agent_run",
        ok=True,
        payload={
            "summary": "done",
            "report_id": record.artifact_id,
            "response_id": None,
            "tool_counts": {},
            "truncated": False,
            "warnings": [],
        },
    ).to_json_string()
    tool = _stub_tool("agent_run", envelope)
    state = McpExposeState(
        tools=MappingProxyType({"agent_run": tool}),
        tool_defs=(),
        tool_context=ToolRuntimeContext(
            db_path=db_path,
            session_id=None,
            branch_id=None,
            run_number=None,
            trace_id="trace-1",
            plan_cache={},
            cancel_token=None,
        ),
    )
    server = McpExposeServer(AppConfig(), workspace_root=tmp_path)

    out = asyncio.run(server.call_tool_with_state("agent_run", {}, state=state))
    assert isinstance(out, tuple)
    blocks = out[0]
    structured = out[1]
    assert isinstance(blocks, list)
    assert blocks
    first = blocks[0]
    assert isinstance(first, mtypes.TextContent)
    assert first.text == "done"
    assert structured == payload


def test_mcp_expose_returns_structured_envelope_for_tools(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    db_path = meta_store_path()
    envelope = FunctionToolOutputEnvelope(
        tool="bat",
        ok=True,
        payload={
            "path": "README.md",
            "page": {
                "cursor_kind": "line",
                "cursor": 1,
                "limit": 1,
                "returned": 1,
                "has_more": True,
                "next_cursor": 2,
            },
        },
    ).to_json_string()
    tool = _stub_tool("bat", envelope)
    state = McpExposeState(
        tools=MappingProxyType({"bat": tool}),
        tool_defs=(),
        tool_context=ToolRuntimeContext(
            db_path=db_path,
            session_id=None,
            branch_id=None,
            run_number=None,
            trace_id="trace-1",
            plan_cache={},
            cancel_token=None,
        ),
    )
    server = McpExposeServer(AppConfig(), workspace_root=tmp_path)

    out = asyncio.run(server.call_tool_with_state("bat", {}, state=state))
    assert isinstance(out, tuple)
    blocks = out[0]
    structured = out[1]
    assert isinstance(blocks, list)
    assert blocks
    first = blocks[0]
    assert isinstance(first, mtypes.TextContent)
    assert first.text
    assert isinstance(structured, dict)
    assert structured.get("tool") == "bat"
    payload = structured.get("payload")
    assert isinstance(payload, dict)
    assert payload.get("path") == "README.md"
