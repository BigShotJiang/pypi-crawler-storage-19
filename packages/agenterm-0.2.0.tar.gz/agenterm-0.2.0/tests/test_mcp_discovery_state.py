from __future__ import annotations

import asyncio
from dataclasses import replace

import pytest
from mcp import types as mtypes

import agenterm.app.services.mcp_refresh as mcp_refresh_mod
from agenterm.app.services.mcp_refresh import maybe_refresh_mcp
from agenterm.commands.handlers.tools.listing import tools_list
from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.config.model import AppConfig, McpConfig, McpServerConfig
from agenterm.core.error_report import ErrorReport
from agenterm.core.tool_selection import ToolSelection
from agenterm.core.types import (
    McpDiscoveryStatus,
    SessionMcpState,
    SessionState,
    SessionToolsState,
)
from agenterm.engine.mcp_diagnostics import McpServerStatus, McpStatusSnapshot

_MCP_FILES_KEY = "mcp:files"


def _config_with_one_mcp_server() -> AppConfig:
    return AppConfig(
        mcp=McpConfig(servers=[McpServerConfig(key="files", kind="stdio")]),
    )


def _state_with_selected_mcp(
    *,
    discovery_status: McpDiscoveryStatus,
    tool_names: tuple[str, ...],
    refresh_pending: bool = False,
    discovery_error: str | None = None,
) -> SessionState:
    cfg = _config_with_one_mcp_server()
    tools_map, bundles_map, defaults = build_tool_catalog_from_config(cfg)
    selection = ToolSelection(selected_keys=(_MCP_FILES_KEY,))
    return SessionState(
        cfg=cfg,
        tools=SessionToolsState(
            enabled=True,
            tools_map=tools_map,
            bundles_map=bundles_map,
            default_bundles=list(defaults),
            selection=selection,
            startup_selection=selection,
        ),
        mcp=SessionMcpState(
            refresh_pending=refresh_pending,
            discovery_status=discovery_status,
            discovery_error=discovery_error,
            tool_names=tool_names,
        ),
    )


def test_tools_list_mcp_lines_reflect_discovery_state() -> None:
    unknown = _state_with_selected_mcp(discovery_status="unknown", tool_names=())
    _, text_unknown = tools_list(unknown)
    assert text_unknown is not None
    assert (
        "MCP tools (discovered):\n(pending; use '/mcp refresh' to update)"
        in text_unknown
    )

    ok_empty = replace(
        unknown,
        mcp=replace(unknown.mcp, discovery_status="ok"),
    )
    _, text_ok_empty = tools_list(ok_empty)
    assert text_ok_empty is not None
    assert "MCP tools (discovered):\n(none)" in text_ok_empty

    err = replace(
        unknown,
        mcp=replace(
            unknown.mcp,
            discovery_status="error",
            discovery_error="files: boom",
        ),
    )
    _, text_err = tools_list(err)
    assert text_err is not None
    assert "MCP tools (discovered):\n(error:" in text_err
    assert "files: boom" in text_err


def test_mcp_refresh_clears_pending_when_tools_gate_off() -> None:
    state = SessionState(
        cfg=_config_with_one_mcp_server(),
        mcp=SessionMcpState(refresh_pending=True),
        tools=SessionToolsState(enabled=True),
    )
    state = replace(state, tools=replace(state.tools, enabled=False))
    new_state, msg = asyncio.run(maybe_refresh_mcp(state))
    assert new_state.mcp.refresh_pending is False
    assert msg is None


def test_mcp_refresh_records_ok_state_and_names(monkeypatch: pytest.MonkeyPatch) -> None:
    state = _state_with_selected_mcp(
        discovery_status="unknown",
        tool_names=(),
        refresh_pending=True,
    )

    async def _fake_diagnose(_cfg: tuple[McpServerConfig, ...]) -> tuple[
        McpStatusSnapshot, dict[str, dict[str, mtypes.Tool]]
    ]:
        snapshot = McpStatusSnapshot(
            servers=(
                McpServerStatus(
                    key="files",
                    kind="stdio",
                    connected=True,
                    tool_count=1,
                    error=None,
                ),
            ),
            total_tools=1,
        )
        tool = mtypes.Tool(name="mcp__files__bat", inputSchema={})
        return snapshot, {"files": {"mcp__files__bat": tool}}

    monkeypatch.setattr(mcp_refresh_mod, "diagnose_mcp_servers", _fake_diagnose)

    new_state, msg = asyncio.run(maybe_refresh_mcp(state))
    assert new_state.mcp.refresh_pending is False
    assert new_state.mcp.discovery_status == "ok"
    assert new_state.mcp.discovery_error is None
    assert new_state.mcp.tool_names == ("mcp__files__bat",)
    assert isinstance(msg, str) and "discovered 1 tool(s)" in msg


def test_mcp_refresh_records_error_state(monkeypatch: pytest.MonkeyPatch) -> None:
    state = _state_with_selected_mcp(
        discovery_status="unknown",
        tool_names=(),
        refresh_pending=True,
    )

    async def _fake_diagnose(_cfg: tuple[McpServerConfig, ...]) -> tuple[
        McpStatusSnapshot, dict[str, dict[str, mtypes.Tool]]
    ]:
        snapshot = McpStatusSnapshot(
            servers=(
                McpServerStatus(
                    key="files",
                    kind="stdio",
                    connected=False,
                    tool_count=0,
                    error="boom",
                ),
            ),
            total_tools=0,
        )
        tool = mtypes.Tool(name="mcp__files__bat", inputSchema={})
        return snapshot, {"files": {"mcp__files__bat": tool}}

    monkeypatch.setattr(mcp_refresh_mod, "diagnose_mcp_servers", _fake_diagnose)

    new_state, msg = asyncio.run(maybe_refresh_mcp(state))
    assert new_state.mcp.refresh_pending is False
    assert new_state.mcp.discovery_status == "error"
    assert new_state.mcp.discovery_error is not None
    assert "files: boom" in new_state.mcp.discovery_error
    assert new_state.mcp.tool_names == ("mcp__files__bat",)
    assert isinstance(msg, ErrorReport)
    assert msg.kind == "mcp_error"
    assert msg.message.startswith("MCP discovery error:")
