"""Contract tests for CLI tool path resolution."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from agenterm.engine.cli_tools.shared import resolve_path_checked


def _skip_symlink_if_unsupported() -> None:
    if os.name == "nt":
        pytest.skip("Symlink behavior is platform-specific on Windows.")


def test_resolve_path_checked_rejects_symlink_paths(tmp_path: Path) -> None:
    _skip_symlink_if_unsupported()
    target = tmp_path / "target.txt"
    target.write_text("ok", encoding="utf-8")
    link = tmp_path / "link.txt"
    link.symlink_to(target)

    resolved, reason = resolve_path_checked(tmp_path, "link.txt", expect="file")

    assert resolved is None
    assert reason == "symlink_path"


def test_resolve_path_checked_accepts_regular_paths(tmp_path: Path) -> None:
    path = tmp_path / "regular.txt"
    path.write_text("ok", encoding="utf-8")

    resolved, reason = resolve_path_checked(tmp_path, "regular.txt", expect="file")

    assert reason is None
    assert resolved is not None
