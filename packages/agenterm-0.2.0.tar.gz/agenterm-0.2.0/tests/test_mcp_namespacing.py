"""Contract tests for MCP tool name namespacing."""

from __future__ import annotations

import asyncio
import re

from agents.mcp import MCPServer
from mcp.types import CallToolResult, GetPromptResult, ListPromptsResult, Tool as MCPTool

from agenterm.core.json_types import JSONValue
from agenterm.engine.mcp_namespacing import NamespacedMcpServer, namespace_mcp_tool_name


_OPENAI_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def test_namespace_mcp_tool_name_prefers_readable_form_when_valid() -> None:
    name = namespace_mcp_tool_name(server_key="files", tool_name="bat")
    assert name == "mcp__files__bat"


def test_namespace_mcp_tool_name_always_returns_openai_valid_name() -> None:
    name = namespace_mcp_tool_name(
        server_key="server key with spaces and / slashes",
        tool_name="tool:name with spaces and emojis? nope",
    )
    assert name.startswith("mcp__")
    assert _OPENAI_NAME_RE.match(name) is not None


def test_namespace_mcp_tool_name_enforces_max_len() -> None:
    name = namespace_mcp_tool_name(server_key="s" * 50, tool_name="t" * 50)
    assert name.startswith("mcp__")
    assert len(name) <= 64
    assert _OPENAI_NAME_RE.match(name) is not None


class _FakeServer(MCPServer):
    def __init__(self) -> None:
        super().__init__(use_structured_content=False)
        self.last_called: tuple[str, dict[str, JSONValue] | None] | None = None

    @property
    def name(self) -> str:
        return "fake"

    async def connect(self) -> None:  # noqa: D401 - test stub
        return None

    async def cleanup(self) -> None:  # noqa: D401 - test stub
        return None

    async def list_tools(
        self,
        run_context: object | None = None,
        agent: object | None = None,
    ) -> list[MCPTool]:
        return [
            MCPTool(
                name="bat",
                description="read",
                inputSchema={"type": "object", "properties": {}},
            ),
        ]

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, JSONValue] | None,
    ) -> CallToolResult:
        self.last_called = (tool_name, arguments)
        return CallToolResult(content=[], isError=False)

    async def list_prompts(self) -> ListPromptsResult:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, JSONValue] | None = None,
    ) -> GetPromptResult:
        msg = "not used in tests"
        raise RuntimeError(msg)


def test_namespaced_mcp_server_maps_names_back_on_call_tool() -> None:
    inner = _FakeServer()
    server = NamespacedMcpServer(server_key="files", inner=inner)

    async def _run() -> None:
        tools = await server.list_tools()
        assert len(tools) == 1
        tool = tools[0]
        expected = namespace_mcp_tool_name(server_key="files", tool_name="bat")
        assert tool.name == expected

        await server.call_tool(tool.name, {"x": 1})

    asyncio.run(_run())

    assert inner.last_called == ("bat", {"x": 1})
