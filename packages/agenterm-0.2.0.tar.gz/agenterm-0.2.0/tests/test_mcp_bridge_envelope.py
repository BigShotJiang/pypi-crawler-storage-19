"""Contract tests for MCP bridge envelopes and approvals."""

from __future__ import annotations

import asyncio
import json

from agents.agent import AgentBase
from agents.mcp import MCPServer
from agents.run_context import RunContextWrapper
from mcp import types as mtypes

from agenterm.core.approvals import ApprovalEvent, ApprovalsContext
from agenterm.core.json_types import JSONValue
from agenterm.core.tool_output_envelope import (
    McpToolOutputEnvelope,
    parse_mcp_tool_output_envelope,
)
from agenterm.engine.mcp_bridge import BridgeMcpServer
from agenterm.engine.tool_output_clamp import ToolOutputClamp


class _StubServer(MCPServer):
    def __init__(self, *, result: mtypes.CallToolResult) -> None:
        super().__init__(use_structured_content=False)
        self._result = result
        self.last_called: tuple[str, dict[str, JSONValue] | None] | None = None

    @property
    def name(self) -> str:
        return "stub"

    async def connect(self) -> None:  # noqa: D401 - test stub
        return None

    async def cleanup(self) -> None:  # noqa: D401 - test stub
        return None

    async def list_tools(
        self,
        run_context: RunContextWrapper | None = None,
        agent: AgentBase | None = None,
    ) -> list[mtypes.Tool]:
        return [
            mtypes.Tool(
                name="bat",
                description="read",
                inputSchema={"type": "object", "properties": {}},
            )
        ]

    async def call_tool(
        self,
        tool_name: str,
        arguments: dict[str, JSONValue] | None,
    ) -> mtypes.CallToolResult:
        self.last_called = (tool_name, arguments)
        return self._result

    async def list_prompts(self) -> mtypes.ListPromptsResult:
        msg = "not used in tests"
        raise RuntimeError(msg)

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, object] | None = None,
    ) -> mtypes.GetPromptResult:
        msg = "not used in tests"
        raise RuntimeError(msg)


def _parse_structured(result: mtypes.CallToolResult) -> McpToolOutputEnvelope:
    data = result.structuredContent
    assert data is not None
    payload = json.dumps(data, ensure_ascii=True)
    parsed = parse_mcp_tool_output_envelope(payload)
    assert parsed is not None
    return parsed


def test_mcp_bridge_wraps_ok_output() -> None:
    result = mtypes.CallToolResult(
        content=[mtypes.TextContent(type="text", text="hello")],
        structuredContent={"answer": 1},
        isError=False,
    )
    approvals = ApprovalsContext(mode="auto")
    server = BridgeMcpServer(
        server_key="files",
        inner=_StubServer(result=result),
        approvals=approvals.mcp,
        output_clamp=ToolOutputClamp(10_000),
        max_content_items=10,
    )

    out = asyncio.run(server.call_tool("bat", {"path": "a"}))
    env = _parse_structured(out)

    assert out.isError is False
    assert env.ok is True
    assert env.server_key == "files"
    assert env.tool_name == "bat"
    assert env.content is not None
    assert env.content.text == "hello"
    assert env.content.data == {"answer": 1}


def test_mcp_bridge_rejects_on_approval_denied() -> None:
    result = mtypes.CallToolResult(
        content=[mtypes.TextContent(type="text", text="ignored")],
        isError=False,
    )
    approvals = ApprovalsContext(mode="prompt")

    def _reject(event: ApprovalEvent) -> None:
        approvals.mcp.resolve(event.item.id, approved=False, reason="nope")

    approvals.subscribe(on_register=_reject)

    server = BridgeMcpServer(
        server_key="files",
        inner=_StubServer(result=result),
        approvals=approvals.mcp,
        output_clamp=ToolOutputClamp(10_000),
        max_content_items=10,
    )

    out = asyncio.run(server.call_tool("bat", {"path": "a"}))
    env = _parse_structured(out)

    assert out.isError is True
    assert env.ok is False
    assert env.error is not None
    assert env.error.kind == "approval_rejected"


def test_mcp_bridge_truncates_by_max_content_items() -> None:
    result = mtypes.CallToolResult(
        content=[
            mtypes.TextContent(type="text", text="one"),
            mtypes.TextContent(type="text", text="two"),
        ],
        isError=False,
    )
    approvals = ApprovalsContext(mode="auto")
    server = BridgeMcpServer(
        server_key="files",
        inner=_StubServer(result=result),
        approvals=approvals.mcp,
        output_clamp=ToolOutputClamp(10_000),
        max_content_items=1,
    )

    out = asyncio.run(server.call_tool("bat", {"path": "a"}))
    env = _parse_structured(out)

    assert env.ok is True
    assert env.truncated is True
    assert env.content is not None
    assert env.content.text == "one"
