"""Contract tests for hosted MCP approvals queue."""

from __future__ import annotations

import asyncio

import pytest

from agenterm.core.approvals import McpApprovalManager
from agenterm.core.cancellation import CancellationScope
from agenterm.core.errors import OperationCancelledError


def test_mcp_approval_manager_round_trip() -> None:
    async def _run() -> None:
        mgr = McpApprovalManager()
        item = mgr.register(
            server_label="s",
            tool_name="t",
            arguments_json="{}",
        )
        assert mgr.pending() == (item,)

        task = asyncio.create_task(mgr.wait(item.id))
        await asyncio.sleep(0)
        mgr.resolve(item.id, approved=True)
        decision = await task
        assert decision.approved is True
        assert decision.reason is None
        assert mgr.pending() == ()

    asyncio.run(_run())


def test_mcp_approval_manager_reason_is_preserved() -> None:
    async def _run() -> None:
        mgr = McpApprovalManager()
        item = mgr.register(
            server_label="s",
            tool_name="t",
            arguments_json="{}",
        )
        task = asyncio.create_task(mgr.wait(item.id))
        await asyncio.sleep(0)
        mgr.resolve(item.id, approved=False, reason="nope")
        decision = await task
        assert decision.approved is False
        assert decision.reason == "nope"

    asyncio.run(_run())


def test_mcp_approval_wait_cancelled() -> None:
    async def _run() -> None:
        mgr = McpApprovalManager()
        item = mgr.register(
            server_label="s",
            tool_name="t",
            arguments_json="{}",
        )
        scope = CancellationScope()
        task = asyncio.create_task(mgr.wait(item.id, cancel_token=scope.token))
        await asyncio.sleep(0)
        scope.cancel()
        with pytest.raises(OperationCancelledError):
            await task
        assert mgr.pending() == ()

    asyncio.run(_run())
