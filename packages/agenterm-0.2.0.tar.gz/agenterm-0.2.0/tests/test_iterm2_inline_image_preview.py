"""Contract test for iTerm2 inline image emission."""

from __future__ import annotations

from pathlib import Path

import pytest

from agenterm.ui.render_artifacts import render_image_artifact


def test_render_image_artifact_emits_inline_image_sequence(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("TERM_PROGRAM", "iTerm.app")
    monkeypatch.delenv("ITERM_SESSION_ID", raising=False)

    def _fake_seq(_p: Path) -> str:
        return "<INLINE_IMAGE_SEQ>"

    monkeypatch.setattr(
        "agenterm.ui.render_artifacts.iterm2_inline_image_sequence_from_path",
        _fake_seq,
    )

    render_image_artifact(
        artifact_id="test",
        path="/tmp/fake.png",
        mime="image/png",
        size_bytes=123,
        inline_preview=True,
    )

    out = capsys.readouterr().out
    assert "<INLINE_IMAGE_SEQ>" in out
