# CLAUDE.md

Operational guidance for Claude Code working in this repository.

## Commands

```bash
# Gate (required before delivery)
uv run devtools/gate.py              # Full gate: lint, typecheck, tests, policies
uv run devtools/gate.py --no-tests   # Fast feedback (local-only edits)

# Run CLI
uv run agenterm --help
uv run agenterm repl                 # Interactive REPL
uv run agenterm run "prompt"         # One-shot run
uv run agenterm config save --scope global   # Write baseline config
uv run agenterm agents save --scope global   # Write bundled agent files

# Inspection
uv run agenterm inspect response <id>      # Background response
uv run agenterm inspect run <session_id> <run_number>           # Run status
uv run agenterm inspect run-events <session_id> <run_number>    # Run event ledger
uv run agenterm inspect agent-run <id>     # Delegated agent_run report

# MCP
uv run agenterm mcp status           # Server connection status
uv run agenterm mcp tools            # List available MCP tools
uv run agenterm mcp validate         # Validate MCP config

# Run single test
uv run pytest tests/test_name.py -v

# Vendor research (required before external integrations)
rg -n "pattern" src              # Search owned code
rg -un "pattern" .venv           # Search vendor code (runtime source of truth)
```

## Release Process

```bash
# 1. Ensure gate is green
uv run devtools/gate.py

# 2. Bump version in pyproject.toml

# 3. Commit and push
git add -A && git commit -m "chore: Bump to X.Y.Z"
git push agenterm main

# 4. Build and publish to PyPI (token in ~/.pypirc)
rm -rf dist/ && uv build
TOKEN=$(awk -F'= ' '/password/ {print $2; exit}' ~/.pypirc) && uv publish --token "$TOKEN"

# 5. Tag and push
git tag -a vX.Y.Z -m "Release X.Y.Z: <summary>"
git push agenterm vX.Y.Z

# 6. Update Homebrew tap (~/Code/homebrew-agenterm)
# Get URL and SHA256 from PyPI:
curl -s "https://pypi.org/pypi/agenterm/X.Y.Z/json" | python3 -c "
import sys, json; d = json.load(sys.stdin)
for u in d['urls']:
    if u['filename'].endswith('.tar.gz'):
        print('URL:', u['url']); print('SHA256:', u['digests']['sha256'])
"
# Update Formula/agenterm.rb with new url + sha256, then:
cd ~/Code/homebrew-agenterm
git add -A && git commit -m "chore: Bump agenterm to X.Y.Z" && git push origin main
```

**Distribution:** PyPI (active), Homebrew tap `tiziano-ai/agenterm` (active), GitHub (`agenterm` remote)

## Architecture

```
src/agenterm/
├── cli/              # Typer entrypoint
├── commands/         # CLI + REPL slash commands
│   ├── handlers/     # Slash command handlers
│   ├── parsers/      # Parsers + completers
│   └── slash_manifest.py  # Single source for help + completion
├── config/           # AppConfig model, loaders, editors
│   ├── editors/      # Pure functions returning new instances
│   ├── normalize/    # YAML → Schema → Normalize → Validate → Runtime
│   └── tool_bundles.py  # Bundle definitions (inspect/plan/delegate/steward/edit/shell/integrations/extensions/research)
├── core/             # Types, errors, approvals, retry, registries
├── engine/           # Agents SDK, tool builders, MCP factory
├── workflow/run/     # Run execution pipeline
├── store/            # SQLite persistence
│   ├── branch/       # Branch metadata + lifecycle
│   ├── runs/         # Run status ledger
│   ├── run_events/   # Run event ledger
│   └── turn_attempts/  # Cancelled run recovery
├── ui/repl/          # REPL orchestration (run_runner, run_callbacks)
└── data/             # Bundled agents, config template
```

**Key flows:**
- `run`: `cli/` → `workflow/run/execute_streamed.py` → `engine/run.py`
- `repl`: `ui/repl/runner.py` → `ui/repl/loop.py` → `workflow/run/execute_streamed.py`
- Config: `.agenterm/config.yaml` (local) or `~/.agenterm/config.yaml` (global)

## Critical Contracts

**Immutability:** `AppConfig`, `SessionState`, `ToolSelection` are frozen dataclasses. All mutations via `dataclasses.replace()` or `with_*()` methods only.

**Session continuity is always local:** CLI replays local history on every request. `previous_response_id` is never used. `model.store` (server persistence) is orthogonal to continuity mode.

**Agent instructions resent per-branch:** Responses API doesn't carry instructions forward. Agent instructions must be stored per-branch and resent on every request.

**MCP lifecycle:** `connect()` before `attach()`, `cleanup()` after. `list_tools()` requires `connect()` first.

**Tool output envelope contracts — two distinct shapes:**
1. **Local FunctionTools** (`shell`, `apply_patch`, `update_plan`, `get_plan`, `rg`, `fd`, `bat`, `tree`, `stat`, `agent_run`, `agent_run_report`): JSON envelope `{schema_version, tool, ok, truncated, payload, error}`
2. **MCP tools**: MCP envelope `{schema_version, server_key, tool_name, ok, truncated, content|error}`

**Tool output truncation:** Both envelope types set `truncated: true` when output exceeds `tools.output_max_chars` (default 20000). FunctionTool success outputs replace `payload` with a compact `preview` string; FunctionTool errors drop `details` then trim `message`. MCP success outputs drop `content.data` then trim `content.text`; MCP errors drop `details` then trim `message`.

**Artifact vault:** Large base64 payloads stripped at write, rehydrated at read. Artifacts outlive sessions.

**Single event loop:** One `asyncio.run` per invocation. Drain `stream_events()` after cancellation.

## Key Patterns

**Config pipeline:** Decode (YAML) → Schema (Raw* dataclasses) → Normalize → Validate → Runtime (AppConfig)

**Run execution:** `workflow/run/execute_streamed.py` wraps SDK calls with retry, status tracking, and postprocessing. UI never duplicates orchestration.

**Retry infrastructure:** Three surfaces with bounded exponential backoff + jitter:
- `retries.provider`: 10 retries (429, 5xx, timeouts)
- `retries.mcp`: 3 retries
- `retries.store`: 5 retries (SQLITE_BUSY)

**Tool gates:** `tools_enabled` gates all tools. `ToolSelection` (bundles + keys) is structural. Dangerous tools (`fn:shell`, `fn:apply_patch`, `fn:user:*`, `mcp:*`, `hosted:mcp:*`) require approvals.

**Tool planes:**
- **OpenAI plane**: Hosted + local function tools (all types)
- **Gateway plane**: FunctionTools only (Chat Completions); hosted tools stripped

**Branching:** Agent switch creates new branch, copies conversation. Only mutates metadata when no history exists.

## Charter Constraints

**Quality Loop:** Research → Design → Documentation → Implementation → Validation. No skipping.

**Strict typing:** Zero errors. No `Any`, `cast`, `type: ignore`, `# noqa`.

**File limits:** ≤500 lines, ≤18 kB. Treat limit hits as design signals.

**Imports:** Absolute only. Heavy/third-party under `TYPE_CHECKING`.

**Edge contracts:** Typed envelopes at boundaries. No raw `dict[str, object]`.

**Documentation first:** Update `ARCH.md` before implementing new contracts.

**Forbidden patterns (hard gate failures):**
- `typing.Any`, `typing.cast`, legacy aliases (`Optional`, `List`, `Dict`)
- `getattr`/`hasattr`/`setattr` for control flow
- `assert` for validation or type narrowing
- Bare `except:` or silent exception swallows
- `eval()`, `exec()`, `shell=True`
- Empty definitions (`def/class ...: pass`)
- Positional booleans at callable boundaries (use keyword-only or enums)
- Mutable default arguments
- Dead code, implicit globals, nondeterminism
- Blocking I/O in event loops
- Raw tracebacks in error envelopes

## Known Gotchas

- **`agent_run` max_turns:** Uses `cfg.agent.max_turns`; set ≥2 if delegated tool use is expected.
- **Workspace confinement:** `resolve_path` rejects absolute paths and symlinks that resolve outside the workspace.
- **`rg` stats:** `stats_partial: true` when rg is truncated or summary data is missing.

## Spec Documents

- `VISION.md` — Product vision (user-led changes only)
- `ARCH.md` — Architecture, contracts, citations (update BEFORE implementing)
- `CHARTER.md` — Engineering constraints (authoritative source)
- `PLAN.md` — Current work items (3-6 items; delete completed)
