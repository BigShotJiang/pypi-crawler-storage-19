"""Steward task schemas and validation helpers."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import is_json_object, is_json_value, parse_json_object

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

type StewardTaskKind = Literal["snapshot", "compaction"]

_MEMORY_SNAPSHOT_ALLOWED_KEYS: set[str] = {
    "schema_version",
    "summary",
    "decisions",
    "constraints",
    "open_items",
    "files",
}

_SNAPSHOT_TASK_ALLOWED_KEYS: set[str] = {
    "schema_version",
    "session_id",
    "branch_id",
    "turn_range",
    "model",
}

_COMPACTION_TASK_ALLOWED_KEYS: set[str] = {
    "schema_version",
    "session_id",
    "branch_id",
    "model",
    "instructions",
    "input_items",
}

_TOOL_REQUEST_ALLOWED_KEYS: set[str] = {
    "schema_version",
    "task",
    "turn_range",
    "model",
    "instructions",
}


@dataclass(frozen=True)
class TurnRange:
    """Inclusive turn bounds for steward snapshot tasks."""

    start: int
    end: int


@dataclass(frozen=True)
class MemorySnapshotFile:
    """Structured file note inside a memory snapshot."""

    path: str
    note: str


@dataclass(frozen=True)
class MemorySnapshot:
    """Parsed MemorySnapshotV1 payload."""

    summary: str
    decisions: tuple[str, ...]
    constraints: tuple[str, ...]
    open_items: tuple[str, ...]
    files: tuple[MemorySnapshotFile, ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe snapshot payload."""
        return {
            "schema_version": 1,
            "summary": self.summary,
            "decisions": list(self.decisions),
            "constraints": list(self.constraints),
            "open_items": list(self.open_items),
            "files": [{"path": item.path, "note": item.note} for item in self.files],
        }


@dataclass(frozen=True)
class StewardSnapshotTaskInput:
    """Validated steward.snapshot task input."""

    session_id: str
    branch_id: str
    turn_range: TurnRange | None
    model: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe task payload."""
        return {
            "schema_version": 1,
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "turn_range": (
                {"start": self.turn_range.start, "end": self.turn_range.end}
                if self.turn_range is not None
                else None
            ),
            "model": self.model,
        }


@dataclass(frozen=True)
class StewardCompactionTaskInput:
    """Validated steward.compaction task input."""

    session_id: str
    branch_id: str
    model: str
    instructions: str | None
    input_items: tuple[dict[str, JSONValue], ...]

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe task payload."""
        return {
            "schema_version": 1,
            "session_id": self.session_id,
            "branch_id": self.branch_id,
            "model": self.model,
            "instructions": self.instructions,
            "input_items": [dict(item) for item in self.input_items],
        }


@dataclass(frozen=True)
class StewardToolRequest:
    """Parsed steward tool request (agent-as-tool)."""

    task: StewardTaskKind
    turn_range: TurnRange | None
    model: str | None
    instructions: str | None


MEMORY_SNAPSHOT_SCHEMA_V1: dict[str, JSONValue] = {
    "name": "MemorySnapshotV1",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "schema_version": {"type": "integer"},
            "summary": {"type": "string"},
            "decisions": {"type": "array", "items": {"type": "string"}},
            "constraints": {"type": "array", "items": {"type": "string"}},
            "open_items": {"type": "array", "items": {"type": "string"}},
            "files": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "path": {"type": "string"},
                        "note": {"type": "string"},
                    },
                    "required": ["path", "note"],
                },
            },
        },
        "required": [
            "schema_version",
            "summary",
            "decisions",
            "constraints",
            "open_items",
            "files",
        ],
    },
    "strict": True,
}


def parse_memory_snapshot(payload: Mapping[str, JSONValue]) -> MemorySnapshot:
    """Validate and parse a MemorySnapshotV1 payload."""
    _require_allowed_keys(payload, allowed=_MEMORY_SNAPSHOT_ALLOWED_KEYS)
    _require_schema_version(payload, context="memory_snapshot.schema_version")
    summary = _require_str(payload.get("summary"), context="memory_snapshot.summary")
    decisions = _require_str_list(
        payload.get("decisions"),
        context="memory_snapshot.decisions",
    )
    constraints = _require_str_list(
        payload.get("constraints"),
        context="memory_snapshot.constraints",
    )
    open_items = _require_str_list(
        payload.get("open_items"),
        context="memory_snapshot.open_items",
    )
    files = _require_files(payload.get("files"))
    return MemorySnapshot(
        summary=summary,
        decisions=decisions,
        constraints=constraints,
        open_items=open_items,
        files=files,
    )


def parse_snapshot_task_input(
    payload: Mapping[str, JSONValue],
) -> StewardSnapshotTaskInput:
    """Validate and parse steward.snapshot task input."""
    _require_allowed_keys(payload, allowed=_SNAPSHOT_TASK_ALLOWED_KEYS)
    _require_schema_version(payload, context="steward.snapshot.schema_version")
    session_id = _require_str(payload.get("session_id"), context="snapshot.session_id")
    branch_id = _require_str(payload.get("branch_id"), context="snapshot.branch_id")
    turn_range = _parse_turn_range(payload.get("turn_range"))
    model = _optional_str(payload.get("model"), context="snapshot.model")
    return StewardSnapshotTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        turn_range=turn_range,
        model=model,
    )


def parse_compaction_task_input(
    payload: Mapping[str, JSONValue],
) -> StewardCompactionTaskInput:
    """Validate and parse steward.compaction task input."""
    _require_allowed_keys(payload, allowed=_COMPACTION_TASK_ALLOWED_KEYS)
    _require_schema_version(payload, context="steward.compaction.schema_version")
    session_id = _require_str(
        payload.get("session_id"),
        context="compaction.session_id",
    )
    branch_id = _require_str(
        payload.get("branch_id"),
        context="compaction.branch_id",
    )
    model = _require_str(payload.get("model"), context="compaction.model")
    instructions = _optional_str(
        payload.get("instructions"),
        context="compaction.instructions",
    )
    input_items = _require_input_items(payload.get("input_items"))
    return StewardCompactionTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        model=model,
        instructions=instructions,
        input_items=input_items,
    )


def parse_tool_request(text: str) -> StewardToolRequest:
    """Parse the JSON string passed to the steward tool."""
    parsed = parse_json_object(text)
    if parsed is None:
        msg = "steward tool input must be a JSON object string"
        raise ConfigError(msg)
    _require_allowed_keys(parsed, allowed=_TOOL_REQUEST_ALLOWED_KEYS)
    if "schema_version" in parsed:
        _require_schema_version(parsed, context="steward.tool.schema_version")
    task_val = parsed.get("task")
    task = _require_task(task_val)
    turn_range = _parse_turn_range(parsed.get("turn_range"))
    model = _optional_str(parsed.get("model"), context="steward.tool.model")
    instructions = _optional_str(
        parsed.get("instructions"),
        context="steward.tool.instructions",
    )
    return StewardToolRequest(
        task=task,
        turn_range=turn_range,
        model=model,
        instructions=instructions,
    )


def _require_task(value: JSONValue | None) -> StewardTaskKind:
    if value == "snapshot":
        return "snapshot"
    if value == "compaction":
        return "compaction"
    msg = "steward.tool.task must be 'snapshot' or 'compaction'"
    raise ConfigError(msg)


def _parse_turn_range(value: JSONValue | None) -> TurnRange | None:
    if value is None:
        return None
    if not isinstance(value, Mapping):
        msg = "turn_range must be an object with start/end"
        raise ConfigError(msg)
    raw: dict[str, JSONValue] = {str(k): v for k, v in value.items()}
    _require_allowed_keys(raw, allowed={"start", "end"})
    start = _require_int(raw.get("start"), context="turn_range.start")
    end = _require_int(raw.get("end"), context="turn_range.end")
    if start <= 0 or end <= 0:
        msg = "turn_range.start/end must be positive integers"
        raise ConfigError(msg)
    if end < start:
        msg = "turn_range.end must be >= turn_range.start"
        raise ConfigError(msg)
    return TurnRange(start=start, end=end)


def _require_allowed_keys(
    payload: Mapping[str, JSONValue],
    *,
    allowed: set[str],
) -> None:
    unknown = {str(k) for k in payload if str(k) not in allowed}
    if unknown:
        msg = f"Unknown keys: {', '.join(sorted(unknown))}"
        raise ConfigError(msg)


def _require_schema_version(payload: Mapping[str, JSONValue], *, context: str) -> None:
    version = payload.get("schema_version")
    if not isinstance(version, int) or version != 1:
        msg = f"{context} must be 1"
        raise ConfigError(msg)


def _require_str(value: JSONValue | None, *, context: str) -> str:
    if not isinstance(value, str) or not value.strip():
        msg = f"{context} must be a non-empty string"
        raise ConfigError(msg)
    return value


def _optional_str(value: JSONValue | None, *, context: str) -> str | None:
    if value is None:
        return None
    if isinstance(value, str) and value.strip():
        return value
    msg = f"{context} must be a non-empty string or null"
    raise ConfigError(msg)


def _require_int(value: JSONValue | None, *, context: str) -> int:
    if isinstance(value, bool):
        msg = f"{context} must be an integer"
        raise ConfigError(msg)
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    msg = f"{context} must be an integer"
    raise ConfigError(msg)


def _require_str_list(value: JSONValue | None, *, context: str) -> tuple[str, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        msg = f"{context} must be a list of strings"
        raise ConfigError(msg)
    items: list[str] = []
    for item in value:
        if not isinstance(item, str):
            msg = f"{context} entries must be strings"
            raise ConfigError(msg)
        items.append(item)
    return tuple(items)


def _require_files(value: JSONValue | None) -> tuple[MemorySnapshotFile, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        msg = "memory_snapshot.files must be a list"
        raise ConfigError(msg)
    out: list[MemorySnapshotFile] = []
    for item in value:
        if not isinstance(item, Mapping):
            msg = "memory_snapshot.files entries must be objects"
            raise ConfigError(msg)
        raw: dict[str, JSONValue] = {str(k): v for k, v in item.items()}
        _require_allowed_keys(raw, allowed={"path", "note"})
        path = _require_str(raw.get("path"), context="memory_snapshot.files.path")
        note = _require_str(raw.get("note"), context="memory_snapshot.files.note")
        out.append(MemorySnapshotFile(path=path, note=note))
    return tuple(out)


def _require_input_items(
    value: JSONValue | None,
) -> tuple[dict[str, JSONValue], ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        msg = "steward.compaction.input_items must be a list"
        raise ConfigError(msg)
    items: list[dict[str, JSONValue]] = []
    for item in value:
        if not isinstance(item, Mapping):
            msg = "steward.compaction.input_items entries must be objects"
            raise ConfigError(msg)
        obj: dict[str, JSONValue] = {}
        for key, val in item.items():
            if not is_json_value(value=val):
                msg = "steward.compaction.input_items contains non-JSON values"
                raise ConfigError(msg)
            obj[str(key)] = val
        if not is_json_object(value=obj):
            msg = "steward.compaction.input_items entries must be JSON objects"
            raise ConfigError(msg)
        item_type = obj.get("type")
        if not isinstance(item_type, str) or not item_type:
            msg = "steward.compaction.input_items entries must have a type string"
            raise ConfigError(msg)
        items.append(obj)
    if not items:
        msg = "steward.compaction.input_items must not be empty"
        raise ConfigError(msg)
    return tuple(items)


__all__ = (
    "MEMORY_SNAPSHOT_SCHEMA_V1",
    "MemorySnapshot",
    "StewardCompactionTaskInput",
    "StewardSnapshotTaskInput",
    "StewardTaskKind",
    "StewardToolRequest",
    "TurnRange",
    "parse_compaction_task_input",
    "parse_memory_snapshot",
    "parse_snapshot_task_input",
    "parse_tool_request",
)
