"""Steward tool construction (agent-as-tool integration)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.paths import history_db_path
from agenterm.core.errors import AgentermError, ConfigError
from agenterm.core.json_codec import dumps_compact, is_json_value
from agenterm.core.plan import ToolRuntimeContext
from agenterm.engine.run_config import build_run_config
from agenterm.steward.agent import build_steward_agent, resolve_steward_agent
from agenterm.steward.schema import StewardToolRequest, parse_tool_request
from agenterm.steward.tasks import (
    StewardTaskResult,
    run_compaction_task,
    run_snapshot_task,
)
from agenterm.store.async_db import AsyncStore
from agenterm.store.session.agenterm_session import AgentermSQLiteSession

if TYPE_CHECKING:
    from agents.result import RunResultBase
    from agents.tool import Tool

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue


def build_steward_tool(cfg: AppConfig) -> Tool:
    """Return the Steward agent wrapped as a FunctionTool."""
    resolved = resolve_steward_agent(cfg)
    steward_agent = build_steward_agent(cfg, resolved=resolved)
    run_config = build_run_config(
        cfg,
        workflow_name="agenterm steward tool",
        model_id=resolved.model,
    )

    async def _extract(run_result: RunResultBase) -> str:
        input_value = run_result.input
        if not isinstance(input_value, str):
            msg = "steward tool input must be a JSON string"
            raise ConfigError(msg)
        request = parse_tool_request(input_value)
        tool_ctx = _require_tool_context(run_result.context_wrapper.context)
        session_id = tool_ctx.session_id
        branch_id = tool_ctx.branch_id or "main"
        if not isinstance(session_id, str) or not session_id:
            msg = "steward tool requires an active session"
            raise ConfigError(msg)
        store = AsyncStore(tool_ctx.db_path)
        session = await _open_session(
            session_id=session_id,
            branch_id=branch_id,
        )
        result = await _run_tool_task(
            cfg=cfg,
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            request=request,
            run_number=tool_ctx.run_number,
            cancel_token=tool_ctx.cancel_token,
        )
        return _tool_output_json(result)

    return steward_agent.as_tool(
        tool_name=None,
        tool_description=(
            "Create a Steward snapshot or compaction branch for the current session.\n"
            "Input: JSON string object with task ('snapshot'|'compaction'), optional "
            "turn_range {start,end}, optional model, optional instructions, optional "
            "schema_version=1.\n"
            "Outputs: task metadata (schema_version, task_id, kind, session_id, "
            "branch_id, snapshot_branch_id, response_id, model, status).\n"
            "Errors: invalid payload or missing session context."
        ),
        custom_output_extractor=_extract,
        run_config=run_config,
        max_turns=1,
    )


def _require_tool_context(ctx: ToolRuntimeContext | None) -> ToolRuntimeContext:
    if not isinstance(ctx, ToolRuntimeContext):
        msg = "steward tool requires ToolRuntimeContext"
        raise ConfigError(msg)
    return ctx


async def _open_session(
    *,
    session_id: str,
    branch_id: str,
) -> AgentermSQLiteSession:
    session = AgentermSQLiteSession(
        session_id=session_id,
        db_path=str(history_db_path()),
        create_tables=True,
    )
    if branch_id != "main":
        await session.switch_to_branch(branch_id)
    return session


async def _run_tool_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    request: StewardToolRequest,
    run_number: int | None,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    if request.task == "snapshot":
        return await run_snapshot_task(
            cfg=cfg,
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            trigger="tool",
            turn_range=request.turn_range,
            model_override=request.model,
            emit_line=None,
            run_number=run_number,
            origin_branch_id=branch_id,
            cancel_token=cancel_token,
        )
    try:
        return await run_compaction_task(
            cfg=cfg,
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            trigger="tool",
            model_override=request.model,
            instructions_override=request.instructions,
            emit_line=None,
            run_number=run_number,
            origin_branch_id=branch_id,
            cancel_token=cancel_token,
        )
    except AgentermError:
        return await run_snapshot_task(
            cfg=cfg,
            session=session,
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            trigger="tool",
            turn_range=request.turn_range,
            model_override=request.model,
            emit_line=None,
            run_number=run_number,
            origin_branch_id=branch_id,
            cancel_token=cancel_token,
        )


def _tool_output_json(result: StewardTaskResult) -> str:
    payload = _tool_payload(result)
    if not is_json_value(value=payload):
        msg = "steward tool output is not JSON-safe"
        raise ConfigError(msg)
    return dumps_compact(
        payload,
        sort_keys=True,
        ensure_ascii=True,
        context="steward.tool.output",
    )


def _tool_payload(result: StewardTaskResult) -> dict[str, JSONValue]:
    task = result.task
    return {
        "schema_version": 1,
        "task_id": task.task_id,
        "kind": task.kind,
        "session_id": task.session_id,
        "branch_id": task.branch_id,
        "snapshot_branch_id": result.branch_meta.branch_id,
        "response_id": task.response_id,
        "model": task.model,
        "status": task.status,
    }


__all__ = ("build_steward_tool",)
