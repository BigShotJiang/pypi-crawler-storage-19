"""Steward summary snapshot execution and helpers."""

from __future__ import annotations

import uuid
from collections.abc import Mapping
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException
from agents.run import Runner
from openai import APIError

from agenterm.core.errors import ConfigError, PipelineError
from agenterm.core.json_codec import dumps_compact, is_json_value, parse_json_object
from agenterm.core.model_id import is_openai_model_id, model_plane
from agenterm.core.openai_client import get_openai_client
from agenterm.core.response_items import parse_input_item, parse_input_item_json
from agenterm.core.token_usage import TokenUsage
from agenterm.engine.result_summary import extract_final_text
from agenterm.engine.run_config import build_run_config
from agenterm.engine.run_errors import format_agents_error, format_provider_error
from agenterm.steward.agent import (
    ResolvedStewardAgent,
    build_steward_agent,
    resolve_steward_agent,
)
from agenterm.steward.schema import (
    MemorySnapshot,
    StewardSnapshotTaskInput,
    TurnRange,
    parse_memory_snapshot,
)
from agenterm.store.history import history_store

if TYPE_CHECKING:
    import aiosqlite
    from agents.agent import Agent
    from agents.items import TResponseInputItem
    from agents.result import RunResultBase
    from openai.types.responses.response_output_message_param import (
        ResponseOutputMessageParam,
    )
    from openai.types.responses.response_output_text_param import (
        ResponseOutputTextParam,
    )

    from agenterm.config.model import AppConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


_AUTO_PROMPT = "Summarize the conversation into MemorySnapshotV1 JSON."


async def _run_steward_once(
    *,
    cfg: AppConfig,
    model_id: str,
    agent: Agent,
    input_items: list[TResponseInputItem],
) -> RunResultBase:
    if is_openai_model_id(model_id):
        get_openai_client()
    provider_label = model_plane(model_id)
    run_config = build_run_config(
        cfg,
        workflow_name="agenterm steward snapshot",
        model_id=model_id,
    )
    try:
        return await Runner.run(
            starting_agent=agent,
            input=input_items,
            max_turns=1,
            previous_response_id=None,
            auto_previous_response_id=False,
            conversation_id=None,
            run_config=run_config,
            session=None,
            context=None,
        )
    except APIError as exc:
        raise PipelineError(
            format_provider_error(exc, provider_label=provider_label)
        ) from exc
    except AgentsException as exc:
        raise PipelineError(format_agents_error(exc)) from exc


async def run_summary_agent(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    task_input: StewardSnapshotTaskInput,
    model_id: str,
) -> tuple[MemorySnapshot, TokenUsage | None, str | None]:
    """Run the Steward summarizer and return snapshot + usage + response id."""
    resolved = resolve_steward_agent(cfg)
    if resolved.model != model_id:
        resolved = ResolvedStewardAgent(
            name=resolved.name,
            model=model_id,
            instructions=resolved.instructions,
            path=resolved.path,
            source=resolved.source,
        )
    steward_agent = build_steward_agent(cfg, resolved=resolved)
    input_items = await summary_input_items(
        session=session,
        branch_id=task_input.branch_id,
        turn_range=task_input.turn_range,
    )
    result = await _run_steward_once(
        cfg=cfg,
        model_id=model_id,
        agent=steward_agent,
        input_items=input_items,
    )
    snapshot = extract_snapshot(result)
    usage = TokenUsage.from_agents_usage(result.context_wrapper.usage)
    response_id = result.last_response_id
    return snapshot, usage, response_id


async def summary_input_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
    turn_range: TurnRange | None,
) -> list[TResponseInputItem]:
    """Build the input list for the Steward summary agent."""
    history = await load_history_items(
        session=session,
        branch_id=branch_id,
        turn_range=turn_range,
    )
    if not history:
        msg = "Steward snapshot requires at least one history item"
        raise ConfigError(msg)
    return [*history, *_prompt_items(_AUTO_PROMPT)]


async def load_history_items(
    *,
    session: AgentermSQLiteSession,
    branch_id: str,
    turn_range: TurnRange | None,
) -> list[TResponseInputItem]:
    """Load history items for the steward snapshot."""
    if turn_range is None:
        history = await session.get_items(branch_id=branch_id)
        return list(history)
    return await items_for_turn_range(
        session_id=session.session_id,
        branch_id=session.current_branch_id,
        turn_range=turn_range,
    )


async def items_for_turn_range(
    *,
    session_id: str,
    branch_id: str,
    turn_range: TurnRange,
) -> list[TResponseInputItem]:
    """Load and rehydrate items for a bounded turn range."""
    store = history_store()

    async def _op(conn: aiosqlite.Connection) -> list[tuple[str]]:
        cur = await conn.execute(
            """
            SELECT m.message_data
            FROM agent_messages m
            JOIN message_structure s ON m.id = s.message_id
            WHERE m.session_id = ? AND s.branch_id = ?
              AND s.branch_turn_number BETWEEN ? AND ?
            ORDER BY s.sequence_number ASC
            """,
            (
                str(session_id),
                str(branch_id),
                int(turn_range.start),
                int(turn_range.end),
            ),
        )
        return [(str(row[0]),) for row in await cur.fetchall()]

    rows = await store.run(_op)
    items: list[TResponseInputItem] = []
    for (raw,) in rows:
        parsed = parse_input_item_json(raw, context="steward.snapshot.history_item")
        if parsed is None:
            msg = "Steward snapshot history item is not valid JSON"
            raise ConfigError(msg)
        items.append(parsed)
    return items


def _prompt_items(text: str) -> list[TResponseInputItem]:
    payload: dict[str, JSONValue] = {
        "type": "message",
        "role": "user",
        "content": [{"type": "input_text", "text": text}],
    }
    return [parse_input_item(payload, context="steward.snapshot.prompt")]


def extract_snapshot(result: RunResultBase) -> MemorySnapshot:
    """Extract a MemorySnapshot from a Steward run result."""
    final = result.final_output
    payload: dict[str, JSONValue] | None = None
    if is_json_value(value=final) and isinstance(final, Mapping):
        try:
            json_str = dumps_compact(
                final,
                ensure_ascii=True,
                context="steward.snapshot.final_output",
            )
        except (TypeError, ValueError):
            json_str = None
        if json_str is not None:
            payload = parse_json_object(json_str)
    if payload is None and isinstance(final, str):
        payload = parse_json_object(final)
    if payload is None:
        text = extract_final_text(result)
        if isinstance(text, str):
            payload = parse_json_object(text)
    if payload is None:
        msg = "Steward snapshot output is not valid JSON"
        raise ConfigError(msg)
    return parse_memory_snapshot(payload)


def snapshot_message_item(snapshot: MemorySnapshot) -> ResponseOutputMessageParam:
    """Return a Responses output message item for the snapshot."""
    payload = snapshot.to_json()
    if not is_json_value(value=payload):
        msg = "MemorySnapshot payload is not JSON-safe"
        raise ConfigError(msg)
    try:
        json_str = dumps_compact(
            payload,
            sort_keys=True,
            ensure_ascii=True,
            context="steward.snapshot.message_item",
        )
    except (TypeError, ValueError) as exc:
        msg = f"Failed to encode MemorySnapshot JSON: {exc}"
        raise ConfigError(msg) from exc
    text = f"memory_snapshot_json:\n{json_str}"
    content: ResponseOutputTextParam = {
        "type": "output_text",
        "text": text,
        "annotations": [],
    }
    message: ResponseOutputMessageParam = {
        "type": "message",
        "id": f"msg_{uuid.uuid4().hex}",
        "role": "assistant",
        "status": "completed",
        "content": [content],
    }
    return message


__all__ = ("items_for_turn_range", "run_summary_agent", "snapshot_message_item")
