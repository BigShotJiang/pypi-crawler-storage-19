"""Inspect command group for background responses and local session data."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Annotated

import typer

from agenterm.cli.options import BranchOption, FormatOption
from agenterm.cli.output import emit_error as emit_cli_error
from agenterm.cli.output import emit_result as emit_cli_result
from agenterm.cli.output_format import OutputFormat
from agenterm.commands.inspect_payloads import (
    inspect_agent_run_payload,
    inspect_run_events_payload,
    inspect_run_payload,
    inspect_turn_payload,
)
from agenterm.core.cli_payloads import (
    InspectResponsePayload,
    InspectRunSpoolPayload,
)
from agenterm.core.env import has_openai_api_key
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import (
    AgentermError,
    AuthError,
    ConfigError,
    DatabaseError,
    FilesystemError,
    ValidationError,
)
from agenterm.engine.background_inspect import (
    render_stream_event,
    retrieve_response,
    retrieve_response_stream,
)
from agenterm.store.session.service import session_store
from agenterm.ui.renderer import render_plain_fragment
from agenterm.workflow.run.spool import replay_spool_file

inspect_app = typer.Typer(
    name="inspect",
    help="Inspect background responses and local session data.",
    no_args_is_help=True,
)


def _context(resource: str) -> ErrorContext:
    return ErrorContext(operation=resource, resource=resource, trace_id=None)


def _exit_usage_error(
    *,
    output_format: OutputFormat,
    resource: str,
    message: str,
) -> None:
    report = build_message_report(
        kind="usage_error",
        message=message,
        context=_context(resource),
    )
    emit_cli_error(output_format=output_format, report=report)
    raise typer.Exit(2)


def _exit_not_found(
    *,
    output_format: OutputFormat,
    resource: str,
    message: str,
) -> None:
    report = build_message_report(
        kind="not_found",
        message=message,
        context=_context(resource),
    )
    emit_cli_error(output_format=output_format, report=report)
    raise typer.Exit(1)


def _require_api_key(*, output_format: OutputFormat, resource: str) -> None:
    if has_openai_api_key():
        return
    report = build_error_report(
        AuthError("OPENAI_API_KEY is not set."),
        context=ErrorContext(
            operation=resource,
            resource=resource,
            trace_id=None,
            recovery_hint=(
                "Set it in your environment or save it to ~/.agenterm/.env "
                "before running agenterm inspect."
            ),
        ),
    )
    emit_cli_error(output_format=output_format, report=report)
    raise typer.Exit(2)


def _use_streaming(*, stream: bool, from_seq: int | None, no_stream: bool) -> bool:
    if no_stream:
        return False
    return stream or from_seq is not None


async def _inspect_streaming(response_id: str, from_seq: int | None) -> None:
    async for event in retrieve_response_stream(response_id, from_seq):
        output = render_stream_event(event)
        if output is not None:
            render_plain_fragment(output)
    render_plain_fragment("\n")


async def _inspect_response_snapshot(
    response_id: str,
) -> InspectResponsePayload:
    resp = await retrieve_response(response_id)
    usage_obj = resp.usage
    usage: dict[str, int] | None
    if usage_obj is None:
        usage = None
    else:
        usage = {
            "requests": 1,
            "input_tokens": int(usage_obj.input_tokens),
            "input_cached_tokens": int(usage_obj.input_tokens_details.cached_tokens),
            "output_tokens": int(usage_obj.output_tokens),
            "output_reasoning_tokens": int(
                usage_obj.output_tokens_details.reasoning_tokens
            ),
            "total_tokens": int(usage_obj.total_tokens),
        }
    return InspectResponsePayload(
        response_id=resp.id,
        model=str(resp.model),
        status=str(resp.status) if resp.status is not None else None,
        background=resp.background,
        usage=dict(usage) if usage is not None else None,
        text=resp.output_text or "",
    )


@inspect_app.command("response")
def inspect_response(
    response_id: Annotated[str, typer.Argument(help="Response ID")],
    *,
    output_format: FormatOption = OutputFormat.human,
    stream: Annotated[
        bool,
        typer.Option("--stream", "-s", help="Stream events in real-time"),
    ] = False,
    from_seq: Annotated[
        int | None,
        typer.Option("--from-seq", help="Resume stream after this sequence number"),
    ] = None,
    no_stream: Annotated[
        bool,
        typer.Option("--no-stream", help="Force non-streaming fetch (default)"),
    ] = False,
) -> None:
    """Fetch and display a single Responses object by id."""
    resource = "inspect.response"
    if output_format is OutputFormat.json and (stream or from_seq is not None):
        _exit_usage_error(
            output_format=output_format,
            resource=resource,
            message="--format json is not compatible with --stream/--from-seq.",
        )
    _require_api_key(output_format=output_format, resource=resource)
    use_stream = _use_streaming(stream=stream, from_seq=from_seq, no_stream=no_stream)

    try:
        if use_stream:
            asyncio.run(_inspect_streaming(response_id, from_seq))
        else:
            payload = asyncio.run(_inspect_response_snapshot(response_id))
            emit_cli_result(
                output_format=output_format,
                resource=resource,
                payload=payload,
                trace_id=None,
            )
    except (AgentermError, OSError, RuntimeError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc
    raise typer.Exit(0)


@inspect_app.command("run")
def inspect_run(
    session_id: Annotated[str, typer.Argument(help="Session ID")],
    run_number: Annotated[int, typer.Argument(help="Run number")],
    *,
    output_format: FormatOption = OutputFormat.human,
    branch_id: BranchOption = None,
) -> None:
    """Inspect a local run summary in the session store."""
    resource = "inspect.run"
    try:
        payload = asyncio.run(
            inspect_run_payload(
                session_id,
                run_number,
                branch_id=branch_id,
            )
        )
    except (ConfigError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc
    if payload is None:
        suffix = f" branch {branch_id!r}" if branch_id is not None else ""
        _exit_not_found(
            output_format=output_format,
            resource=resource,
            message=f"No run {run_number} for session {session_id!r}{suffix}.",
        )
        return
    emit_cli_result(
        output_format=output_format,
        resource=resource,
        payload=payload,
        trace_id=None,
    )


@inspect_app.command("run-events")
def inspect_run_events(
    session_id: Annotated[str, typer.Argument(help="Session ID")],
    run_number: Annotated[int, typer.Argument(help="Run number")],
    *,
    output_format: FormatOption = OutputFormat.human,
    branch_id: BranchOption = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", help="Max events to return"),
    ] = None,
) -> None:
    """Inspect the Responses-shaped event ledger for a local run."""
    resource = "inspect.run-events"
    try:
        payload = asyncio.run(
            inspect_run_events_payload(
                session_id,
                run_number,
                branch_id=branch_id,
                limit=limit,
            )
        )
    except DatabaseError as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc
    if payload is None:
        suffix = f" branch {branch_id!r}" if branch_id is not None else ""
        _exit_not_found(
            output_format=output_format,
            resource=resource,
            message=f"No run {run_number} for session {session_id!r}{suffix}.",
        )
        return
    emit_cli_result(
        output_format=output_format,
        resource=resource,
        payload=payload,
        trace_id=None,
    )


@inspect_app.command("run-spool")
def inspect_run_spool(
    spool_path: Annotated[Path, typer.Argument(help="Run spool file path")],
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Replay a run spool file into the local meta store."""
    resource = "inspect.run-spool"
    try:
        result = asyncio.run(
            replay_spool_file(
                store=session_store(),
                path=spool_path,
            )
        )
    except (ConfigError, DatabaseError, FilesystemError, ValidationError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc

    payload = InspectRunSpoolPayload(
        kind=result.kind,
        session_id=result.session_id,
        branch_id=result.branch_id,
        run_number=result.run_number,
        run_id=result.run_id,
        events=result.events,
        items=result.items,
        spool_path=result.spool_path,
    )
    if output_format is OutputFormat.json:
        emit_cli_result(
            output_format=output_format,
            resource=resource,
            payload=payload,
            trace_id=None,
        )
        raise typer.Exit(0)

    lines = [
        f"Replayed spool: {payload.spool_path}",
        f"kind={payload.kind} session={payload.session_id} branch={payload.branch_id} "
        f"run={payload.run_number} events={payload.events} items={payload.items}",
    ]
    render_plain_fragment("\n".join(lines) + "\n")
    raise typer.Exit(0)


@inspect_app.command("turn")
def inspect_turn(
    session_id: Annotated[str, typer.Argument(help="Session ID")],
    turn_number: Annotated[int, typer.Argument(help="Branch turn number")],
    *,
    output_format: FormatOption = OutputFormat.human,
    branch_id: BranchOption = None,
) -> None:
    """Inspect a single SDK turn in the session store."""
    resource = "inspect.turn"
    try:
        payload = asyncio.run(
            inspect_turn_payload(
                session_id,
                turn_number,
                branch_id=branch_id,
            )
        )
    except (ConfigError, DatabaseError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc
    if payload is None:
        suffix = f" branch {branch_id!r}" if branch_id is not None else ""
        _exit_not_found(
            output_format=output_format,
            resource=resource,
            message=(f"No turn {turn_number} for session {session_id!r}{suffix}."),
        )
        return
    emit_cli_result(
        output_format=output_format,
        resource=resource,
        payload=payload,
        trace_id=None,
    )


@inspect_app.command("agent-run")
def inspect_agent_run(
    report_id: Annotated[str, typer.Argument(help="agent_run report id")],
    *,
    output_format: FormatOption = OutputFormat.human,
) -> None:
    """Inspect a persisted agent_run report."""
    resource = "inspect.agent-run"
    try:
        payload = asyncio.run(inspect_agent_run_payload(report_id))
    except (DatabaseError, FilesystemError, ValidationError) as exc:
        report = build_error_report(exc, context=_context(resource))
        emit_cli_error(output_format=output_format, report=report)
        raise typer.Exit(2) from exc
    if payload is None:
        _exit_not_found(
            output_format=output_format,
            resource=resource,
            message=f"No agent_run report with id {report_id!r}.",
        )
        return
    emit_cli_result(
        output_format=output_format,
        resource=resource,
        payload=payload,
        trace_id=None,
    )


__all__ = ("inspect_app",)
