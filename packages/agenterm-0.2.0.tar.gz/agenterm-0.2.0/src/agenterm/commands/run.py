"""One-shot execution for `agenterm run`.

This module is intentionally narrow: parse inputs, prepare the run context, invoke
the canonical run workflow, and render results. The shared execution pipeline
lives in `agenterm.workflow.run`.
"""

from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING, NoReturn

import typer
from agents.exceptions import MaxTurnsExceeded

from agenterm.app.services import RunConfigFlags, RunRequest, prepare_run_context
from agenterm.cli.output_format import OutputFormat, is_json
from agenterm.commands.run_support import (
    RunInputBundle,
    RunModes,
    build_payload,
    emit_error,
    render_success,
    resolve_source,
)
from agenterm.config.paths import meta_store_path, resolve_config_source
from agenterm.core.env import has_openai_api_key
from agenterm.core.error_report import (
    ErrorContext,
    build_error_report,
    build_message_report,
)
from agenterm.core.errors import AgentermError, AuthError, ConfigError, PipelineError
from agenterm.core.model_id import model_plane
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_selection import selected_mcp_server_configs
from agenterm.engine.input_payload import build_input_or_prompt
from agenterm.store.async_db import close_store_registry
from agenterm.ui.cli_renderer import render_error_report, render_notice
from agenterm.ui.renderer import status_spinner
from agenterm.ui.transcript.policy import transcript_policy_from_config
from agenterm.ui.transcript.render import render_run_item
from agenterm.workflow.run.execute_background import execute_background_run
from agenterm.workflow.run.execute_streamed import execute_streamed_run
from agenterm.workflow.run.model import (
    RunExecutionContext,
    StreamedRunRequest,
    StreamEventCallbacks,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.items import RunItem, TResponseInputItem
    from agents.result import RunResultBase

    from agenterm.app.services import RunContext
    from agenterm.commands.cli_args import RunCliArgs
    from agenterm.config.model import AppConfig, RunDefaults
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import PlanSnapshot
    from agenterm.ui.transcript.render import PlanSnapshotLoader


def _exit(code: int) -> NoReturn:
    raise typer.Exit(code)


def _require_api_key(model_id: str) -> None:
    """Ensure OPENAI_API_KEY is present when using openai/... models."""
    if not model_id.lower().startswith("openai/"):
        return
    if has_openai_api_key():
        return
    msg = "auth: OPENAI_API_KEY not set"
    raise AuthError(msg)


def _build_flags(opts: RunCliArgs) -> RunConfigFlags:
    return RunConfigFlags(
        config=opts.config,
        agent_name=opts.agent_name,
        model=opts.model,
        trace_enabled=opts.trace_enabled,
        trace_id=opts.trace_id,
        trace_group=opts.trace_group,
        trace_metadata=opts.trace_metadata,
        no_tools=opts.no_tools,
        tool_select=opts.tool_select,
        store_override=opts.store_override,
        allow_dangerous=bool(opts.allow_dangerous),
        hosted_mode=bool(opts.background) if opts.background is not None else False,
        background_flag=bool(opts.background) if opts.background is not None else None,
    )


def _resolve_modes(opts: RunCliArgs, cfg_run: RunDefaults) -> RunModes:
    # --live flag overrides config; if neither specified, default is False (quiet)
    live = opts.live if opts.live is not None else cfg_run.live
    output_format = (
        opts.format_override
        if opts.format_override is not None
        else (OutputFormat.json if cfg_run.json_output else OutputFormat.human)
    )
    return RunModes(live=live, output_format=output_format)


_NO_INPUT_MESSAGE = "no input (pass PROMPT or pipe stdin)"
_MULTI_INPUT_MESSAGE = "Choose a single input source: PROMPTs | --file FILE | stdin."


def _exit_usage_error(
    *,
    message: str,
    output_format: OutputFormat,
) -> NoReturn:
    report = build_message_report(
        kind="usage_error",
        message=message,
        context=ErrorContext(operation="run", resource="run", trace_id=None),
    )
    emit_error(output_format=output_format, report=report)
    _exit(2)


def _prompt_and_attachments_from_opts_or_exit(
    opts_parsed: RunCliArgs,
    *,
    output_format: OutputFormat,
) -> tuple[str, tuple[str, ...]]:
    source = resolve_source(
        prompts=list(opts_parsed.prompts) if opts_parsed.prompts is not None else None,
        file=opts_parsed.file,
    )
    if source is None:
        _exit_usage_error(
            output_format=output_format,
            message=_NO_INPUT_MESSAGE,
        )
    source_kind, source_value = source
    if source_kind == "error":
        _exit_usage_error(
            output_format=output_format,
            message=_MULTI_INPUT_MESSAGE,
        )
    prompt = "\n".join(_read_prompt_lines(source_kind, source_value)).strip()
    attachments_tuple = tuple(opts_parsed.attachments or ())
    if not prompt and not attachments_tuple:
        _exit_usage_error(
            output_format=output_format,
            message=_NO_INPUT_MESSAGE,
        )
    return prompt, attachments_tuple


def _read_prompt_lines(kind: str, value: str | list[str] | Path | None) -> list[str]:
    if kind == "prompts":
        if not isinstance(value, list):
            msg = "Internal error: invalid PROMPTS value."
            raise ConfigError(msg)
        return [str(item) for item in value]
    if kind == "file":
        if not isinstance(value, Path):
            msg = "Internal error: invalid --file value."
            raise ConfigError(msg)
        try:
            return value.read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            msg = f"Failed to read --file: {exc}"
            raise ConfigError(msg) from exc
    return sys.stdin.read().splitlines()


async def _build_input_bundle(
    *,
    cfg: AppConfig,
    model_id: str,
    prompt: str,
    attachments: tuple[str, ...],
) -> RunInputBundle:
    input_prompt, payload = await build_input_or_prompt(
        cfg=cfg,
        model_id=model_id,
        prompt=prompt,
        attachments=list(attachments),
        max_text_bytes=None,
    )
    input_items_raw = payload if payload is not None else input_prompt
    if input_items_raw is None:
        input_items: str | list[TResponseInputItem] = prompt
    elif isinstance(input_items_raw, list):
        input_items = list(input_items_raw)
    else:
        input_items = input_items_raw
    return RunInputBundle(
        prompt=prompt,
        attachments=attachments,
        input_items=input_items,
    )


@dataclass(frozen=True)
class _OneShotRunResult:
    """Outputs from executing a single one-shot agent run."""

    result: RunResultBase
    final_response_id: str | None
    run_ctx: RunExecutionContext


def _postprocess_emit_line_from_modes(
    modes: RunModes,
    *,
    context: ErrorContext,
) -> Callable[[str], None] | None:
    if is_json(modes.output_format):
        return None

    def _emit(msg: str) -> None:
        # Keep CLI output stable: postprocess emits both info and warn lines.
        # For one-shot runs we surface warnings/errors only.
        if msg.startswith("warn>"):
            text = msg[len("warn>") :].strip()
            render_notice(title="Warning", message=text, style="warn")
        elif msg.startswith("error>"):
            text = msg[len("error>") :].strip()
            report = build_message_report(
                kind="runtime_error",
                message=text,
                context=context,
            )
            render_error_report(report)

    return _emit


def _render_config_source_note(
    *,
    explicit: Path | None,
    resolved: Path | None,
) -> None:
    info = resolve_config_source(explicit=explicit, resolved=resolved)
    if info.location == "default":
        message = "Using defaults (no config.yaml found)."
    elif info.location == "local":
        message = f"Using local config: {info.path}"
    elif info.location == "global":
        message = f"Using global config: {info.path}"
    elif info.location == "explicit":
        message = f"Using explicit config: {info.path}"
    else:
        message = f"Using config: {info.path}"
    render_notice(title="Config", message=message, style="accent", stderr=True)


def _render_agent_source_note(*, cfg: AppConfig) -> None:
    name = cfg.agent.name
    location = cfg.agent.source or "unknown"
    path = cfg.agent.path
    if cfg.agent.explicit:
        if path is not None:
            message = f"Using explicit agent {name}: {path}"
        else:
            message = f"Using explicit agent {name}."
    elif location == "local":
        message = f"Using local agent {name}: {path}"
    elif location == "global":
        message = f"Using global agent {name}: {path}"
    elif location == "bundled":
        message = f"Using bundled agent {name}."
    else:
        message = f"Using agent {name}."
    render_notice(title="Agent", message=message, style="accent", stderr=True)


async def _execute_one_shot_run(
    ctx: RunContext,
    *,
    bundle: RunInputBundle,
    modes: RunModes,
    emit_line: Callable[[str], None] | None,
) -> _OneShotRunResult:
    selected_caps = ctx.cfg_bundle.selected_tools if ctx.tools_enabled else None
    selected_servers = (
        selected_mcp_server_configs(selected_caps) if selected_caps else ()
    )
    cfg_for_run = (
        replace(ctx.cfg, mcp=replace(ctx.cfg.mcp, servers=list(selected_servers)))
        if selected_servers != tuple(ctx.cfg.mcp.servers or ())
        else ctx.cfg
    )
    db_path = meta_store_path()
    plan_cache: dict[str, PlanSnapshot] = {}
    tool_context = ToolRuntimeContext(
        db_path=db_path,
        session_id=ctx.session_id if isinstance(ctx.session_id, str) else None,
        branch_id=ctx.branch_id,
        run_number=None,
        trace_id=cfg_for_run.run.trace_id,
        plan_cache=plan_cache,
        cancel_token=None,
    )
    plan_snapshot_loader: PlanSnapshotLoader | None = None
    session_id = ctx.session_id
    if isinstance(session_id, str) and session_id:

        def _load_snapshot(call_id: str) -> PlanSnapshot | None:
            return plan_cache.get(call_id)

        plan_snapshot_loader = _load_snapshot
    run_ctx_base = RunExecutionContext(
        cfg=cfg_for_run,
        agent=ctx.agent,
        session=ctx.session,
        session_id=ctx.session_id if isinstance(ctx.session_id, str) else None,
        branch_id=ctx.branch_id,
        store_enabled=ctx.agenterm_store,
        interactive=False,
        workflow_name="agenterm run",
        approvals=ctx.approvals,
        mcp_pool=None,
        tool_context=tool_context,
    )

    if ctx.background:
        run_ctx = replace(run_ctx_base, workflow_name="agenterm run (background)")
        with status_spinner("Running in background..."):
            bg = await execute_background_run(
                run_ctx,
                input_items=bundle.input_items,
                emit_line=emit_line,
            )
        return _OneShotRunResult(
            result=bg.result,
            final_response_id=bg.post.response_id,
            run_ctx=run_ctx,
        )

    run_ctx = run_ctx_base
    reasoning_summary_max = ctx.cfg.repl.ux.reasoning_summary_max_chars
    policy = transcript_policy_from_config(
        verbosity="normal",
        reasoning_mode="summary",
        diffs_mode="summary",
        reasoning_summary_max_chars=reasoning_summary_max,
        transcript_cfg=ctx.cfg.repl.transcript,
    )

    def _on_run_item(item: RunItem) -> None:
        render_run_item(
            item,
            policy=policy,
            plan_snapshot_loader=plan_snapshot_loader,
        )

    callbacks = (
        StreamEventCallbacks(on_run_item=_on_run_item)
        if modes.live and emit_line is not None
        else StreamEventCallbacks()
    )
    streamed = await execute_streamed_run(
        run_ctx,
        StreamedRunRequest(
            input_items=bundle.input_items,
            callbacks=callbacks,
            stream_mode="final",
            retry_policy=run_ctx.cfg.retries.provider,
            postprocess_emit_line=emit_line,
            retry_emit_line=emit_line,
        ),
    )
    return _OneShotRunResult(
        result=streamed.streaming,
        final_response_id=streamed.post.response_id,
        run_ctx=run_ctx,
    )


async def _run_command_with_args(opts_parsed: RunCliArgs) -> None:
    """Execute a one-shot prompt with pre-parsed arguments."""
    trace_id_effective: str | None = None
    provider_label: str | None = None
    modes = RunModes(
        live=False,
        output_format=(
            opts_parsed.format_override
            if opts_parsed.format_override is not None
            else OutputFormat.human
        ),
    )

    try:
        # Usage errors are JSON only when explicitly requested via --format json.
        output_fmt_usage = (
            OutputFormat.json
            if opts_parsed.format_override is OutputFormat.json
            else OutputFormat.human
        )
        flags = _build_flags(opts_parsed)
        prompt, attachments_tuple = _prompt_and_attachments_from_opts_or_exit(
            opts_parsed,
            output_format=output_fmt_usage,
        )

        ctx = await prepare_run_context(
            RunRequest(
                flags=flags,
                session_id=opts_parsed.session_id,
                branch_id=opts_parsed.branch_id,
            ),
        )
        provider_label = model_plane(ctx.cfg.agent.model)
        trace_id_effective = ctx.cfg.run.trace_id
        modes = _resolve_modes(opts_parsed, ctx.cfg.run)
        _render_config_source_note(
            explicit=opts_parsed.config,
            resolved=ctx.cfg_bundle.config_path,
        )
        _render_agent_source_note(cfg=ctx.cfg)

        _require_api_key(ctx.cfg.agent.model)
        bundle = await _build_input_bundle(
            cfg=ctx.cfg,
            model_id=ctx.cfg.agent.model,
            prompt=prompt,
            attachments=attachments_tuple,
        )

        run_context = ErrorContext(
            operation="run",
            resource="run",
            trace_id=trace_id_effective,
        )
        emit_line = _postprocess_emit_line_from_modes(
            modes,
            context=run_context,
        )
        executed = await _execute_one_shot_run(
            ctx,
            bundle=bundle,
            modes=modes,
            emit_line=emit_line,
        )

        payload_raw = await build_payload(
            executed.result,
            attachments=attachments_tuple,
            session_id=executed.run_ctx.session_id,
            mode=("quiet" if ctx.background else ("live" if modes.live else "quiet")),
            background=bool(ctx.background),
        )
        if isinstance(executed.final_response_id, str) and executed.final_response_id:
            payload_raw = replace(payload_raw, response_id=executed.final_response_id)

        exit_code = render_success(
            payload=payload_raw,
            modes=modes,
            trace_id=trace_id_effective,
        )
        _exit(exit_code)
    except (ConfigError, PipelineError, AgentermError, MaxTurnsExceeded) as exc:
        extra: dict[str, JSONValue] | None = None
        if provider_label is not None:
            extra = {"provider": provider_label}
        report = build_error_report(
            exc,
            context=ErrorContext(
                operation="run",
                resource="run",
                trace_id=trace_id_effective,
            ),
            extra_details=extra,
        )
        emit_error(output_format=modes.output_format, report=report)
        _exit(2)
    finally:
        try:
            await close_store_registry()
        except AgentermError as exc:
            report = build_error_report(
                exc,
                context=ErrorContext(
                    operation="run.store.cleanup",
                    resource="run.store.cleanup",
                    trace_id=trace_id_effective,
                ),
            )
            render_error_report(report)


def run_command_with_args(opts_parsed: RunCliArgs) -> None:
    """Execute a one-shot prompt with pre-parsed arguments."""
    asyncio.run(_run_command_with_args(opts_parsed))


__all__ = ("run_command_with_args",)
