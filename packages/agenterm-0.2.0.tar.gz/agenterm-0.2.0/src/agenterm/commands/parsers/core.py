"""Core parsers for common REPL slash commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from agenterm.commands.model import (
    AgentCmd,
    AgentListCmd,
    AgentShowCmd,
    AttachCmd,
    AttachmentsShowCmd,
    ClearCmd,
    Command,
    CompressCmd,
    CompressShowCmd,
    DetachAllCmd,
    DetachPathCmd,
    ModelCmd,
    ModelListCmd,
    ModelRefreshCmd,
    ModelShowCmd,
)
from agenterm.commands.parsers.base import ordered

if TYPE_CHECKING:
    from agenterm.core.types import SessionState

_MODEL_LIST_MIN_ARGS: Final[int] = 2
_MODEL_LIST_MAX_ARGS: Final[int] = 3
_MODEL_REFRESH_ARG_COUNT: Final[int] = 2
_ATTACH_REMOVE_ARG_COUNT: Final[int] = 2


def _parse_model_scope(raw: str) -> tuple[str, str | None] | None:
    token = raw.strip()
    if not token:
        return None
    head, _, tail = token.partition("/")
    head = head.lower()
    if head == "openai":
        return ("openai", None) if not tail else None
    if head == "gateway":
        if not tail:
            return ("gateway", None)
        if "/" in tail:
            return None
        return ("gateway", tail)
    return None


def _parse_model_list(args: list[str]) -> ModelListCmd | None:
    if len(args) < _MODEL_LIST_MIN_ARGS or len(args) > _MODEL_LIST_MAX_ARGS:
        return None
    scope = _parse_model_scope(args[1])
    if scope is None:
        return None
    provider, route = scope
    filter_text = args[2] if len(args) == _MODEL_LIST_MAX_ARGS else None
    return ModelListCmd(provider=provider, route=route, filter_text=filter_text)


def _parse_model_refresh(args: list[str]) -> ModelRefreshCmd | None:
    if len(args) != _MODEL_REFRESH_ARG_COUNT:
        return None
    scope = _parse_model_scope(args[1])
    if scope is None:
        return None
    provider, route = scope
    return ModelRefreshCmd(provider=provider, route=route)


def parse_model(args: list[str]) -> Command | None:
    """Parse '/model' arguments into a Command.

    Args:
      args: Remaining tokens after the head.

    Returns:
      ModelShowCmd on no args; ModelCmd on a single token; list/refresh variants
      when specified; otherwise None.

    """
    if len(args) == 0:
        return ModelShowCmd()
    head = args[0].lower()
    if head == "list":
        return _parse_model_list(args)
    if head == "refresh":
        return _parse_model_refresh(args)
    if len(args) == 1:
        return ModelCmd(args[0])
    return None


def complete_model(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /model."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    model_name = state.cfg.agent.model if state is not None else ""
    candidates: list[str] = []
    if not parts:
        candidates.extend(["list ", "refresh"])
        if model_name:
            candidates.append(model_name)
        return ordered(candidates)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        if "list".startswith(prefix):
            candidates.append("list ")
        if "refresh".startswith(prefix):
            candidates.append("refresh")
        if model_name and model_name.lower().startswith(prefix):
            candidates.append(model_name)
        return ordered(candidates)
    head = parts[0].lower()
    if head in {"list", "refresh"}:
        return []
    return []


def parse_agent(args: list[str]) -> Command | None:
    """Parse '/agent' commands (show/list/switch).

    Args:
      args: Remaining tokens after the head.

    Returns:
      AgentShowCmd on no args or `show`, AgentListCmd on `list`, AgentCmd on a
      single name argument; else None.

    """
    if not args:
        return AgentShowCmd()
    head = args[0].lower()
    if head == "show":
        return AgentShowCmd() if len(args) == 1 else None
    if head == "list":
        return AgentListCmd() if len(args) == 1 else None
    return AgentCmd(name=args[0]) if len(args) == 1 else None


def complete_agent(rest: str, state: SessionState | None = None) -> list[str]:
    """Return completion candidates for /agent."""
    parts = (rest or "").split()
    trailing_space = rest.endswith(" ")
    agent_name = state.cfg.agent.name if state is not None else ""
    candidates: list[str] = []
    if not parts:
        candidates.extend(["show ", "list "])
        if agent_name:
            candidates.append(agent_name)
        return ordered(candidates)
    if len(parts) == 1 and not trailing_space:
        prefix = parts[0].lower()
        if "show".startswith(prefix):
            candidates.append("show ")
        if "list".startswith(prefix):
            candidates.append("list ")
        if agent_name and agent_name.lower().startswith(prefix):
            candidates.append(agent_name)
        return ordered(candidates)
    return []


def parse_attach(args: list[str]) -> Command | None:
    """Parse '/attach' commands.

    Args:
      args: Remaining tokens after the head.

    Returns:
      AttachmentsShowCmd on no args or `list`, ClearCmd on `clear`, DetachAllCmd
      / DetachPathCmd on `remove`, or AttachCmd on a single path/URL.

    """
    if not args:
        return AttachmentsShowCmd()
    head = args[0].lower()
    if head == "list":
        return AttachmentsShowCmd() if len(args) == 1 else None
    if head == "clear":
        return ClearCmd() if len(args) == 1 else None
    if head == "remove":
        if len(args) != _ATTACH_REMOVE_ARG_COUNT:
            return None
        tok = args[1]
        return DetachAllCmd() if tok.lower() == "all" else DetachPathCmd(path=tok)
    return AttachCmd(path=args[0]) if len(args) == 1 else None


def parse_compress(args: list[str]) -> Command | None:
    """Parse '/compress' into a CompressCmd or CompressShowCmd."""
    if len(args) == 0:
        return CompressCmd()
    if len(args) == 1 and args[0].lower() == "show":
        return CompressShowCmd()
    return None


__all__ = (
    "complete_agent",
    "complete_model",
    "parse_agent",
    "parse_attach",
    "parse_compress",
    "parse_model",
)
