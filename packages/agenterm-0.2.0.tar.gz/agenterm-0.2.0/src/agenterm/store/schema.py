"""Store schema versioning and validation for agenterm-owned SQLite tables."""

from __future__ import annotations

import asyncio
import hashlib
import sqlite3
from pathlib import Path
from typing import TYPE_CHECKING, Final

import aiosqlite
from agents.extensions.memory import AdvancedSQLiteSession

from agenterm.config.paths import history_db_path
from agenterm.core.errors import ConfigError
from agenterm.store.async_db import AsyncStore
from agenterm.store.history import HISTORY_TABLES
from agenterm.store.schema_specs import TABLE_SPECS

if TYPE_CHECKING:
    from agenterm.store.schema_spec_types import TableSpec

_SCHEMA_VERSION_11: Final[int] = 11
_SCHEMA_VERSION_12: Final[int] = 12
_SCHEMA_VERSION_13: Final[int] = 13
_STORE_SCHEMA_VERSION: Final[int] = _SCHEMA_VERSION_13

_SCHEMA_TABLE_SQL: Final[str] = """
CREATE TABLE IF NOT EXISTS agenterm_schema (
    schema_version INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
"""

_HISTORY_COUNT_SQL: Final[dict[str, str]] = {
    "agent_sessions": "SELECT COUNT(*) FROM agent_sessions",
    "agent_messages": "SELECT COUNT(*) FROM agent_messages",
    "message_structure": "SELECT COUNT(*) FROM message_structure",
    "turn_usage": "SELECT COUNT(*) FROM turn_usage",
}

_HISTORY_COPY_SQL: Final[dict[str, str]] = {
    "agent_sessions": (
        "INSERT INTO history.agent_sessions (session_id, created_at, updated_at) "
        "SELECT session_id, created_at, updated_at FROM main.agent_sessions"
    ),
    "agent_messages": (
        "INSERT INTO history.agent_messages (id, session_id, message_data, created_at) "
        "SELECT id, session_id, message_data, created_at FROM main.agent_messages"
    ),
    "message_structure": (
        "INSERT INTO history.message_structure ("
        "id, session_id, message_id, branch_id, message_type, sequence_number, "
        "user_turn_number, branch_turn_number, tool_name, created_at"
        ") "
        "SELECT id, session_id, message_id, branch_id, message_type, sequence_number, "
        "user_turn_number, branch_turn_number, tool_name, created_at "
        "FROM main.message_structure"
    ),
    "turn_usage": (
        "INSERT INTO history.turn_usage ("
        "id, session_id, branch_id, user_turn_number, requests, input_tokens, "
        "output_tokens, total_tokens, input_tokens_details, output_tokens_details, "
        "created_at"
        ") "
        "SELECT id, session_id, branch_id, user_turn_number, requests, input_tokens, "
        "output_tokens, total_tokens, input_tokens_details, output_tokens_details, "
        "created_at "
        "FROM main.turn_usage"
    ),
}

_HISTORY_DROP_SQL: Final[dict[str, str]] = {
    "agent_sessions": "DROP TABLE IF EXISTS agent_sessions",
    "agent_messages": "DROP TABLE IF EXISTS agent_messages",
    "message_structure": "DROP TABLE IF EXISTS message_structure",
    "turn_usage": "DROP TABLE IF EXISTS turn_usage",
}

_COLUMN_ADD_SQL: Final[dict[tuple[str, str], str]] = {
    ("agenterm_runs", "recovery_state"): (
        "ALTER TABLE agenterm_runs ADD COLUMN recovery_state TEXT"
    ),
    ("agenterm_runs", "recovery_spool_path"): (
        "ALTER TABLE agenterm_runs ADD COLUMN recovery_spool_path TEXT"
    ),
    ("agenterm_artifacts", "content_hash"): (
        "ALTER TABLE agenterm_artifacts "
        "ADD COLUMN content_hash TEXT NOT NULL DEFAULT ''"
    ),
}


async def _read_schema_version(conn: aiosqlite.Connection) -> int | None:
    try:
        async with conn.execute(
            "SELECT schema_version FROM agenterm_schema LIMIT 1",
        ) as cur:
            row = await cur.fetchone()
    except sqlite3.Error:
        return None
    if row is None:
        return None
    version = row[0]
    return int(version) if isinstance(version, int) else None


async def _write_schema_version(conn: aiosqlite.Connection, version: int) -> None:
    await conn.execute(_SCHEMA_TABLE_SQL)
    await conn.execute("DELETE FROM agenterm_schema")
    await conn.execute(
        "INSERT INTO agenterm_schema (schema_version) VALUES (?)",
        (int(version),),
    )


async def _table_columns(
    conn: aiosqlite.Connection,
    *,
    table: str,
) -> tuple[set[str], set[str]]:
    async with conn.execute(
        'SELECT name, "notnull" FROM pragma_table_info(?)',
        (str(table),),
    ) as cur:
        rows = await cur.fetchall()
    cols = {str(row[0]) for row in rows}
    notnull = {str(row[0]) for row in rows if bool(row[1])}
    return cols, notnull


async def _table_exists(conn: aiosqlite.Connection, *, table: str) -> bool:
    async with conn.execute(
        """
        SELECT name
        FROM sqlite_master
        WHERE type = 'table' AND name = ?
        """,
        (str(table),),
    ) as cur:
        row = await cur.fetchone()
    return row is not None


async def _validate_table_schema(
    conn: aiosqlite.Connection,
    spec: TableSpec,
) -> bool:
    cols, notnull = await _table_columns(conn, table=spec.name)
    expected = set(spec.expected_cols)
    if cols != expected:
        return False
    required_notnull = set(spec.notnull_cols)
    return required_notnull.issubset(notnull)


async def _init_store(conn: aiosqlite.Connection) -> None:
    await _write_schema_version(conn, _STORE_SCHEMA_VERSION)
    for spec in TABLE_SPECS:
        await conn.execute(spec.create_sql)
    for spec in TABLE_SPECS:
        if not await _validate_table_schema(conn, spec):
            msg = f"Failed to initialize store schema: {spec.name}"
            raise ConfigError(msg)
    await conn.commit()


async def _history_has_rows(
    *,
    history_path: Path,
    tables: list[str],
) -> bool:
    async with aiosqlite.connect(str(history_path)) as hconn:
        for table in tables:
            sql = _HISTORY_COUNT_SQL.get(table)
            if sql is None:
                msg = f"Unsupported history table for migration: {table}"
                raise ConfigError(msg)
            cur = await hconn.execute(sql)
            row = await cur.fetchone()
            if row is not None and int(row[0] or 0) > 0:
                return True
    return False


async def _split_history_tables(conn: aiosqlite.Connection) -> None:
    source_tables = [
        name for name in HISTORY_TABLES if await _table_exists(conn, table=name)
    ]
    if not source_tables:
        return

    history_path = history_db_path()
    if not await asyncio.to_thread(history_path.exists):
        await asyncio.to_thread(
            AdvancedSQLiteSession,
            session_id="bootstrap",
            db_path=str(history_path),
            create_tables=True,
        )

    if await _history_has_rows(history_path=history_path, tables=source_tables):
        msg = (
            "History store already contains data while meta store still "
            "has vendor tables. Resolve manually before continuing."
        )
        raise ConfigError(msg)

    await conn.execute("ATTACH DATABASE ? AS history", (str(history_path),))
    try:
        for table in source_tables:
            sql = _HISTORY_COPY_SQL.get(table)
            if sql is None:
                msg = f"Unsupported history table for migration: {table}"
                raise ConfigError(msg)
            await conn.execute(sql)
        for table in source_tables:
            sql = _HISTORY_DROP_SQL.get(table)
            if sql is None:
                msg = f"Unsupported history table for migration: {table}"
                raise ConfigError(msg)
            await conn.execute(sql)
    finally:
        await conn.execute("DETACH DATABASE history")


async def _add_column_if_missing(
    conn: aiosqlite.Connection,
    *,
    table: str,
    column: str,
) -> None:
    cols, _ = await _table_columns(conn, table=table)
    if column in cols:
        return
    sql = _COLUMN_ADD_SQL.get((table, column))
    if sql is None:
        msg = f"No migration SQL for column {table}.{column}"
        raise ConfigError(msg)
    await conn.execute(sql)


async def _migrate_11_to_12(conn: aiosqlite.Connection) -> None:
    await _split_history_tables(conn)
    await _add_column_if_missing(
        conn,
        table="agenterm_runs",
        column="recovery_state",
    )
    await _add_column_if_missing(
        conn,
        table="agenterm_runs",
        column="recovery_spool_path",
    )

    await conn.execute(
        "ALTER TABLE agenterm_branch_meta RENAME TO agenterm_branch_meta_old",
    )
    await conn.execute(TABLE_SPECS[1].create_sql)
    await conn.execute(
        """
        INSERT INTO agenterm_branch_meta (
            session_id,
            branch_id,
            kind,
            title,
            pinned,
            created_reason,
            parent_branch_id,
            fork_run_number,
            agent_name,
            agent_path,
            agent_sha256,
            store_enabled,
            last_response_id,
            created_at,
            updated_at
        )
        SELECT
            session_id,
            branch_id,
            CASE
                WHEN kind = 'compact' THEN 'compaction'
                ELSE kind
            END,
            title,
            pinned,
            created_reason,
            parent_branch_id,
            fork_run_number,
            agent_name,
            agent_path,
            agent_sha256,
            store_enabled,
            last_response_id,
            created_at,
            updated_at
        FROM agenterm_branch_meta_old
        """,
    )
    await conn.execute("DROP TABLE agenterm_branch_meta_old")

    await conn.execute(
        "ALTER TABLE agenterm_request_usage RENAME TO agenterm_request_usage_old",
    )
    await conn.execute(TABLE_SPECS[8].create_sql)
    await conn.execute(
        """
        INSERT INTO agenterm_request_usage (
            session_id,
            branch_id,
            kind,
            run_number,
            request_index,
            model,
            previous_response_id,
            response_id,
            requests,
            input_tokens,
            input_cached_tokens,
            output_tokens,
            output_reasoning_tokens,
            total_tokens,
            created_at
        )
        SELECT
            session_id,
            branch_id,
            CASE
                WHEN kind = 'compact' THEN 'compaction'
                ELSE kind
            END,
            run_number,
            request_index,
            model,
            previous_response_id,
            response_id,
            requests,
            input_tokens,
            input_cached_tokens,
            output_tokens,
            output_reasoning_tokens,
            total_tokens,
            created_at
        FROM agenterm_request_usage_old
        """,
    )
    await conn.execute("DROP TABLE agenterm_request_usage_old")

    await conn.execute(
        "ALTER TABLE agenterm_steward_tasks RENAME TO agenterm_steward_tasks_old",
    )
    await conn.execute(TABLE_SPECS[9].create_sql)
    await conn.execute(
        """
        INSERT INTO agenterm_steward_tasks (
            task_id,
            session_id,
            branch_id,
            snapshot_branch_id,
            kind,
            trigger,
            status,
            model,
            input_json,
            trace_id,
            response_id,
            error_json,
            created_at,
            started_at,
            completed_at
        )
        SELECT
            task_id,
            session_id,
            branch_id,
            snapshot_branch_id,
            CASE
                WHEN kind = 'compact' THEN 'compaction'
                ELSE kind
            END,
            trigger,
            status,
            model,
            input_json,
            trace_id,
            response_id,
            error_json,
            created_at,
            started_at,
            completed_at
        FROM agenterm_steward_tasks_old
        """,
    )
    await conn.execute("DROP TABLE agenterm_steward_tasks_old")

    await _write_schema_version(conn, _STORE_SCHEMA_VERSION)
    await conn.commit()


async def _migrate_12_to_13(conn: aiosqlite.Connection) -> None:
    await _add_column_if_missing(
        conn,
        table="agenterm_artifacts",
        column="content_hash",
    )
    cur = await conn.execute(
        """
        SELECT artifact_id, path, content_hash
        FROM agenterm_artifacts
        """,
    )
    rows = await cur.fetchall()
    for row in rows:
        artifact_id = str(row[0])
        raw_path = str(row[1])
        content_hash = str(row[2] or "")
        if content_hash:
            continue
        digest = await asyncio.to_thread(
            _hash_artifact_path,
            Path(raw_path),
        )
        if digest is None:
            continue
        await conn.execute(
            """
            UPDATE agenterm_artifacts
            SET content_hash = ?
            WHERE artifact_id = ?
            """,
            (str(digest), str(artifact_id)),
        )

    await _write_schema_version(conn, _STORE_SCHEMA_VERSION)
    await conn.commit()


async def _validate_store(conn: aiosqlite.Connection) -> bool:
    version = await _read_schema_version(conn)
    if version != _STORE_SCHEMA_VERSION:
        return False
    for spec in TABLE_SPECS:
        await conn.execute(spec.create_sql)
        if not await _validate_table_schema(conn, spec):
            return False
    return True


def _hash_artifact_path(path: Path) -> str | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    return hashlib.sha256(data).hexdigest()


async def ensure_store_schema(
    db_path: Path,
) -> None:
    """Ensure the agenterm-owned store schema exists and matches expectations.

    Raises ConfigError when the on-disk schema does not match the expected
    version so operators can delete the store explicitly.
    """
    store = AsyncStore(db_path)

    async def _ensure(conn: aiosqlite.Connection) -> None:
        version = await _read_schema_version(conn)
        if version == _STORE_SCHEMA_VERSION and await _validate_store(conn):
            return
        if version is None:
            await _init_store(conn)
            return
        if version == _SCHEMA_VERSION_11:
            await _migrate_11_to_12(conn)
            return
        if version == _SCHEMA_VERSION_12:
            await _migrate_12_to_13(conn)
            return
        msg = (
            "Store schema mismatch. Back up or move aside the local store file "
            f"and retry: {db_path}"
        )
        raise ConfigError(msg)

    await store.run(_ensure)


__all__ = ("ensure_store_schema",)
