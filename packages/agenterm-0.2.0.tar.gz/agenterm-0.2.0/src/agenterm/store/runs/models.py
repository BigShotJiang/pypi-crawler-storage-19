"""Run status models for the agenterm run ledger."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

type RunStatus = Literal["running", "completed", "failed", "cancelled", "timeout"]
type RunRecoveryState = Literal["needs_replay", "replayed"]


@dataclass(frozen=True)
class RunStatusRecord:
    """Persisted status record for a single run attempt."""

    run_id: str
    session_id: str
    branch_id: str
    run_number: int
    status: RunStatus
    trace_id: str | None
    response_id: str | None
    error_json: dict[str, JSONValue] | None
    branch_turn_start: int | None
    branch_turn_end: int | None
    recovery_state: RunRecoveryState | None
    recovery_spool_path: str | None
    started_at: str | None
    updated_at: str | None


__all__ = ("RunRecoveryState", "RunStatus", "RunStatusRecord")
