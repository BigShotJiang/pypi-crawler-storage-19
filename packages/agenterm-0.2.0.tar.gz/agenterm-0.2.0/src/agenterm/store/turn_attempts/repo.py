"""SQLite repository for turn attempt ledger entries."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import DatabaseError
from agenterm.store.codec import (
    decode_json_object,
    encode_json_object,
    optional_text,
    require_int,
    require_text,
)
from agenterm.store.schema import ensure_store_schema
from agenterm.store.turn_attempts.models import (
    TurnAttemptItemRecord,
    TurnAttemptRecord,
    TurnAttemptStatus,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    import aiosqlite

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore


def _row_to_attempt(
    row: tuple[str | int | float | bytes | None, ...],
) -> TurnAttemptRecord:
    (
        session_id,
        branch_id,
        run_number,
        status,
        cancel_reason,
        created_at,
        updated_at,
    ) = row
    session_id = require_text(session_id, field="agenterm_turn_attempts.session_id")
    branch_id = require_text(branch_id, field="agenterm_turn_attempts.branch_id")
    run_number_int = require_int(
        run_number,
        field="agenterm_turn_attempts.run_number",
    )
    status_val = require_text(status, field="agenterm_turn_attempts.status")
    if status_val not in {"active", "cancelled"}:
        msg = "agenterm_turn_attempts.status expected active|cancelled"
        raise DatabaseError(msg)
    status_norm: TurnAttemptStatus = "active" if status_val == "active" else "cancelled"
    return TurnAttemptRecord(
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number_int,
        status=status_norm,
        cancel_reason=optional_text(
            cancel_reason,
            field="agenterm_turn_attempts.cancel_reason",
        ),
        created_at=optional_text(
            created_at,
            field="agenterm_turn_attempts.created_at",
        ),
        updated_at=optional_text(
            updated_at,
            field="agenterm_turn_attempts.updated_at",
        ),
    )


def _row_to_item(
    row: tuple[str | int | float | bytes | None, ...],
) -> TurnAttemptItemRecord:
    (
        session_id,
        branch_id,
        run_number,
        item_seq,
        item_type,
        item_json,
        seen_by_model,
        created_at,
    ) = row
    session_id = require_text(
        session_id,
        field="agenterm_turn_attempt_items.session_id",
    )
    branch_id = require_text(
        branch_id,
        field="agenterm_turn_attempt_items.branch_id",
    )
    run_number_int = require_int(
        run_number,
        field="agenterm_turn_attempt_items.run_number",
    )
    item_seq_int = require_int(
        item_seq,
        field="agenterm_turn_attempt_items.item_seq",
    )
    item_type = require_text(
        item_type,
        field="agenterm_turn_attempt_items.item_type",
    )
    item_json_text = require_text(
        item_json,
        field="agenterm_turn_attempt_items.item_json",
    )
    seen = require_int(
        seen_by_model,
        field="agenterm_turn_attempt_items.seen_by_model",
    )
    return TurnAttemptItemRecord(
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number_int,
        item_seq=item_seq_int,
        item_type=item_type,
        item=decode_json_object(
            item_json_text,
            context="agenterm_turn_attempt_items.item_json",
        ),
        seen_by_model=bool(seen),
        created_at=optional_text(
            created_at,
            field="agenterm_turn_attempt_items.created_at",
        ),
    )


async def start_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Insert or reset a turn attempt to active status."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_turn_attempts (
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason
            )
            VALUES (?, ?, ?, 'active', NULL)
            ON CONFLICT(session_id, branch_id, run_number)
            DO UPDATE SET
                status='active',
                cancel_reason=NULL,
                updated_at=CURRENT_TIMESTAMP
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def insert_turn_attempt_item(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    item_seq: int,
    item_type: str,
    item: Mapping[str, JSONValue],
    seen_by_model: bool,
) -> None:
    """Insert a new turn attempt item."""
    await ensure_store_schema(store.db_path)
    item_json = encode_json_object(
        dict(item),
        context="agenterm_turn_attempt_items.item_json",
        sort_keys=True,
        ensure_ascii=True,
    )

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            INSERT INTO agenterm_turn_attempt_items (
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(session_id),
                str(branch_id),
                int(run_number),
                int(item_seq),
                str(item_type),
                item_json,
                1 if seen_by_model else 0,
            ),
        )
        await conn.commit()

    await store.run(_op)


async def mark_turn_attempt_items_seen(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Mark all items for this attempt as seen by the model."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_turn_attempt_items
            SET seen_by_model = 1
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.execute(
            """
            UPDATE agenterm_turn_attempts
            SET updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def mark_turn_attempt_cancelled(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    cancel_reason: str | None,
) -> None:
    """Mark a turn attempt as cancelled."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            UPDATE agenterm_turn_attempts
            SET status = 'cancelled',
                cancel_reason = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (
                str(cancel_reason) if cancel_reason else None,
                str(session_id),
                str(branch_id),
                int(run_number),
            ),
        )
        await conn.commit()

    await store.run(_op)


async def clear_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
) -> None:
    """Delete a turn attempt and its items."""
    await ensure_store_schema(store.db_path)

    async def _op(conn: aiosqlite.Connection) -> None:
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()

    await store.run(_op)


async def list_turn_attempt_items(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    seen_by_model: bool | None = None,
) -> tuple[TurnAttemptItemRecord, ...]:
    """Return ordered attempt items (optionally filtered by seen flag)."""
    await ensure_store_schema(store.db_path)
    seen_val = None if seen_by_model is None else (1 if seen_by_model else 0)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[str | int | float | bytes | None, ...]]:
        query = """
            SELECT
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model,
                created_at
            FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
        """
        params: list[str | int] = [
            str(session_id),
            str(branch_id),
            int(run_number),
        ]
        if seen_val is not None:
            query = query + " AND seen_by_model = ?"
            params.append(seen_val)
        query = query + " ORDER BY item_seq ASC"
        cur = await conn.execute(query, tuple(params))
        rows = await cur.fetchall()
        return [tuple(row) for row in rows]

    rows = await store.run(_op)
    return tuple(_row_to_item(row) for row in rows)


async def latest_cancelled_turn_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> TurnAttemptRecord | None:
    """Return the most recent cancelled attempt, if any."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[str | int | float | bytes | None, ...] | None:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason,
                created_at,
                updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            ORDER BY run_number DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        return tuple(row) if row is not None else None

    row = await store.run(_op)
    if row is None:
        return None
    return _row_to_attempt(row)


async def consume_latest_cancelled_attempt(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> tuple[TurnAttemptRecord, tuple[TurnAttemptItemRecord, ...]] | None:
    """Return and delete the most recent cancelled attempt and its unseen items."""
    await ensure_store_schema(store.db_path)

    async def _op(
        conn: aiosqlite.Connection,
    ) -> tuple[
        tuple[str | int | float | bytes | None, ...] | None,
        list[tuple[str | int | float | bytes | None, ...]],
    ]:
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                status,
                cancel_reason,
                created_at,
                updated_at
            FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND status = 'cancelled'
            ORDER BY run_number DESC
            LIMIT 1
            """,
            (str(session_id), str(branch_id)),
        )
        row = await cur.fetchone()
        if row is None:
            return None, []
        attempt_row = tuple(row)
        run_number = row[2]
        cur = await conn.execute(
            """
            SELECT
                session_id,
                branch_id,
                run_number,
                item_seq,
                item_type,
                item_json,
                seen_by_model,
                created_at
            FROM agenterm_turn_attempt_items
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
              AND seen_by_model = 0
            ORDER BY item_seq ASC
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        rows = await cur.fetchall()
        await conn.execute(
            """
            DELETE FROM agenterm_turn_attempts
            WHERE session_id = ? AND branch_id = ? AND run_number = ?
            """,
            (str(session_id), str(branch_id), int(run_number)),
        )
        await conn.commit()
        return attempt_row, [tuple(row) for row in rows]

    attempt_row, item_rows = await store.run(_op)
    if attempt_row is None:
        return None
    attempt = _row_to_attempt(attempt_row)
    items = tuple(_row_to_item(row) for row in item_rows)
    return attempt, items


__all__ = (
    "clear_turn_attempt",
    "consume_latest_cancelled_attempt",
    "insert_turn_attempt_item",
    "latest_cancelled_turn_attempt",
    "list_turn_attempt_items",
    "mark_turn_attempt_cancelled",
    "mark_turn_attempt_items_seen",
    "start_turn_attempt",
)
