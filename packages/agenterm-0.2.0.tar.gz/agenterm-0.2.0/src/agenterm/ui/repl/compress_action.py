"""REPL action handler: `/compress`."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.core.error_report import ErrorContext, ErrorReport, build_error_report
from agenterm.core.errors import (
    AgentermError,
    ConfigError,
    DatabaseError,
    OperationCancelledError,
)
from agenterm.steward.tasks import run_compress_policy
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import session_store, session_usage_totals
from agenterm.workflow.run.status import (
    start_compression_status,
    update_run_status_record,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.types import SessionState
    from agenterm.store.session.service import Session
    from agenterm.ui.repl.phase_state import ReplPhaseState


def _warn(warnings: list[str], msg: str, exc: Exception) -> None:
    warnings.append(f"warn> {msg}: {exc}")


async def _compression_preflight(
    state: SessionState,
    session: Session | None,
) -> tuple[AgentermSQLiteSession, str] | str:
    if session is None:
        return "No session memory available; cannot apply compression."
    if not isinstance(session, AgentermSQLiteSession):
        return "Compression requires an SQLite-backed session."
    session_id = state.session_id
    if not isinstance(session_id, str):
        return "Compression requires a stored session."
    history = await session.get_items()
    if not history:
        return "Nothing to compress (no session history items)."
    return session, session_id


async def run_manual_compression(
    *,
    state: SessionState,
    phase_state: ReplPhaseState,
    session: Session | None,
    ui_invalidate: Callable[[], None] | None = None,
    cancel_token: CancelToken | None = None,
    emit_line: Callable[[str], None] | None = None,
) -> tuple[SessionState, str | ErrorReport]:
    """Run a manual compression and return (updated_state, user_message)."""
    preflight = await _compression_preflight(state, session)
    if isinstance(preflight, str):
        return state, preflight
    session_sql, session_id = preflight
    phase_state.phase = "compressing"
    if ui_invalidate is not None:
        ui_invalidate()
    origin_branch_id = session_sql.current_branch_id
    run_handle = await start_compression_status(
        session_id=session_id,
        branch_id=origin_branch_id,
        trace_id=state.cfg.run.trace_id,
    )
    try:
        result = await run_compress_policy(
            cfg=state.cfg,
            session=session_sql,
            store=session_store(),
            session_id=session_id,
            branch_id=origin_branch_id,
            trigger="manual",
            turn_range=None,
            emit_line=emit_line,
            run_number=run_handle.run_number,
            origin_branch_id=origin_branch_id,
            cancel_token=cancel_token,
        )
    except OperationCancelledError:
        await update_run_status_record(
            run_handle,
            status="cancelled",
            response_id=None,
            error_json=None,
            branch_turn_start=None,
            branch_turn_end=None,
        )
        return state, "Compression cancelled."
    except AgentermError as exc:
        report = build_error_report(
            exc,
            context=ErrorContext(
                operation="repl.compress",
                resource="repl.compress",
                trace_id=state.cfg.run.trace_id,
            ),
        )
        await update_run_status_record(
            run_handle,
            status="failed",
            response_id=None,
            error_json=report.to_envelope().to_json(),
            branch_turn_start=None,
            branch_turn_end=None,
        )
        return state, report
    finally:
        phase_state.phase = "idle"
        if ui_invalidate is not None:
            ui_invalidate()

    await update_run_status_record(
        run_handle,
        status="completed",
        response_id=result.task.response_id,
        error_json=None,
        branch_turn_start=None,
        branch_turn_end=None,
    )

    store = session_store()
    branch_meta = result.branch_meta

    new_state = replace(
        state,
        branch_id=branch_meta.branch_id,
        prompt=replace(state.prompt, last_user_prompt=None),
        caches=replace(
            state.caches,
            branch_ids=tuple({*(state.caches.branch_ids or ()), branch_meta.branch_id}),
        ),
    )

    warnings: list[str] = []
    try:
        totals = await session_usage_totals(
            store=store,
            session_id=session_id,
            branch_id=branch_meta.branch_id,
        )
        phase_state.usage_total_tokens = (
            totals.total_tokens if totals is not None else None
        )
    except (ConfigError, OSError, DatabaseError) as exc:
        _warn(warnings, "Failed to read usage totals", exc)

    msg = (
        "Compression complete. New "
        f"{branch_meta.kind} branch created and switched "
        f"(branch: {branch_meta.branch_id}, response_id: "
        f"{result.task.response_id})."
    )
    return new_state, "\n".join([msg, *warnings]) if warnings else msg


__all__ = ("run_manual_compression",)
