"""Compaction snapshot summarization for `/compress show`.

This module is UI-only:
- It operates on a list of session items returned by the Agents session store.
- It locates the most recent compaction item and summarizes the snapshot
  (items up to and including that compaction record).
- It never mutates session state, writes items, or contacts the model.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING
from urllib.parse import urlparse

from agenterm.core.errors import ConfigError
from agenterm.core.hashing import sha256_text
from agenterm.core.json_codec import as_json_list, as_json_object, as_str
from agenterm.core.response_items import serialize_input_item

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, MutableMapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONMapping, JSONValue


_MAX_TEXT_CHARS = 0  # 0 = no limit
_MAX_GROUP_ITEMS = 0  # 0 = no limit


@dataclass(frozen=True)
class _SnapshotSlice:
    snapshot: list[JSONMapping]
    compaction_item: Mapping[str, JSONValue]


@dataclass(frozen=True)
class _CitationGroups:
    container_file: Mapping[str, Mapping[str, int]]
    file_citation: Mapping[str, int]
    file_path: Mapping[str, int]
    url_citation: Mapping[str, int]

    def any(self) -> bool:
        if self.container_file:
            return True
        if self.file_citation:
            return True
        if self.file_path:
            return True
        return bool(self.url_citation)


def _as_dict(value: JSONValue | None) -> dict[str, JSONValue] | None:
    return as_json_object(value)


def _as_list(value: JSONValue | None) -> list[JSONValue] | None:
    return as_json_list(value)


def _as_str(value: JSONValue | None) -> str | None:
    return as_str(value)


def _domain(url: str) -> str | None:
    parsed = urlparse(url)
    if parsed.scheme and parsed.netloc:
        return parsed.netloc
    return None


def _redact_text(text: str) -> tuple[list[str], int]:
    total = len(text)
    if _MAX_TEXT_CHARS <= 0 or total <= _MAX_TEXT_CHARS:
        return text.splitlines() or [""], total
    head = text[:_MAX_TEXT_CHARS]
    lines = head.splitlines() or [""]
    return [*lines, f"… (+{total - _MAX_TEXT_CHARS} chars)"], total


def _redact_blob(value: str) -> str:
    if not value.startswith("data:"):
        digest = sha256_text(value)[:12]
        return f"<inline_data len={len(value)} sha256={digest}…>"
    head, sep, tail = value.partition(",")
    if not sep:
        digest = sha256_text(value)[:12]
        return f"<data_url len={len(value)} sha256={digest}…>"
    # data:<mime>;base64,<payload>
    mime = head[5:]
    if ";" in mime:
        mime = mime.split(";", 1)[0]
    b64_chars = len(tail)
    approx_bytes = (b64_chars * 3) // 4
    digest = sha256_text(value)[:12]
    mime_label = mime or "unknown"
    return f"<data_url mime={mime_label} bytes≈{approx_bytes} sha256={digest}…>"


def _to_json_object(item: TResponseInputItem) -> dict[str, JSONValue] | None:
    try:
        return serialize_input_item(item, context="compress_snapshot.item")
    except ConfigError:
        return None


def _find_last_compaction_snapshot(
    items: list[dict[str, JSONValue]],
) -> _SnapshotSlice | None:
    for i in range(len(items) - 1, -1, -1):
        if items[i].get("type") == "compaction":
            return _SnapshotSlice(
                snapshot=list(items[: i + 1]),
                compaction_item=items[i],
            )
    return None


def _message_header(msg: Mapping[str, JSONValue], *, idx: int) -> str:
    role = as_str(msg.get("role")) or "unknown"
    status = as_str(msg.get("status"))
    header = f"- [{idx}] {role}/message"
    if role == "assistant" and status is not None:
        header += f" (status={status})"
    return header


def _message_parts(msg: Mapping[str, JSONValue]) -> list[dict[str, JSONValue]]:
    parts_obj = as_json_list(msg.get("content"))
    if parts_obj is None:
        return []
    out: list[dict[str, JSONValue]] = []
    for raw in parts_obj:
        m = as_json_object(raw)
        if m is not None:
            out.append(m)
    return out


def _summarize_text_part(
    part: Mapping[str, JSONValue],
    *,
    kind: str,
) -> list[str]:
    text_obj = _as_str(part.get("text")) or ""
    snippet_lines, total_len = _redact_text(text_obj)
    ann_count = 0
    if kind == "output_text":
        anns_obj = _as_list(part.get("annotations"))
        ann_count = len(anns_obj) if anns_obj is not None else 0

    meta = f"  - {kind} (len={total_len}"
    if kind == "output_text":
        meta += f", annotations={ann_count}"
    meta += "):"
    return [meta, *[f"      {ln}" if ln else "      " for ln in snippet_lines]]


def _summarize_refusal_part(part: Mapping[str, JSONValue]) -> list[str]:
    refusal = _as_str(part.get("refusal")) or ""
    snippet_lines, total_len = _redact_text(refusal)
    return [
        f"  - refusal (len={total_len}):",
        *[f"      {ln}" if ln else "      " for ln in snippet_lines],
    ]


def _summarize_input_image_part(part: Mapping[str, JSONValue]) -> list[str]:
    detail = _as_str(part.get("detail")) or "auto"
    file_id = _as_str(part.get("file_id"))
    image_url = _as_str(part.get("image_url"))
    label = f"  - input_image (detail={detail})"
    if file_id is not None:
        label += f" file_id={file_id}"
    if image_url is not None:
        label += (
            f" image_url={_redact_blob(image_url)}"
            if image_url.startswith("data:")
            else f" image_url={image_url}"
        )
    return [label]


def _summarize_input_file_part(part: Mapping[str, JSONValue]) -> list[str]:
    file_id = _as_str(part.get("file_id"))
    file_url = _as_str(part.get("file_url"))
    filename = _as_str(part.get("filename"))
    file_data = _as_str(part.get("file_data"))
    label = "  - input_file"
    if filename is not None:
        label += f" filename={filename}"
    if file_id is not None:
        label += f" file_id={file_id}"
    if file_url is not None:
        label += f" file_url={file_url}"
    if file_data is not None:
        label += f" file_data={_redact_blob(file_data)}"
    return [label]


def _summarize_unknown_part(ptype: str) -> list[str]:
    return [f"  - {ptype}"]


def _summarize_message(msg: Mapping[str, JSONValue], *, idx: int) -> list[str]:
    lines: list[str] = [_message_header(msg, idx=idx)]
    parts = _message_parts(msg)
    if not parts:
        return [*lines, "  (no content)"]

    for part in parts:
        ptype = _as_str(part.get("type")) or "unknown"
        if ptype == "input_text":
            lines.extend(_summarize_text_part(part, kind="input_text"))
            continue
        if ptype == "output_text":
            lines.extend(_summarize_text_part(part, kind="output_text"))
            continue
        if ptype == "refusal":
            lines.extend(_summarize_refusal_part(part))
            continue
        if ptype == "input_image":
            lines.extend(_summarize_input_image_part(part))
            continue
        if ptype == "input_file":
            lines.extend(_summarize_input_file_part(part))
            continue
        lines.extend(_summarize_unknown_part(ptype))
    return lines


def _collect_role_counts(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    role_counts = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        role = _as_str(item.get("role")) or "unknown"
        role_counts[role] = role_counts.get(role, 0) + 1
    return role_counts


def _collect_part_counts(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    part_counts = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in _message_parts(item):
            ptype = _as_str(part.get("type")) or "unknown"
            part_counts[ptype] = part_counts.get(ptype, 0) + 1
    return part_counts


def _collect_file_groups(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    groups = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in _message_parts(item):
            if part.get("type") != "input_file":
                continue
            file_id = _as_str(part.get("file_id"))
            file_url = _as_str(part.get("file_url"))
            filename = _as_str(part.get("filename"))
            file_data = _as_str(part.get("file_data"))
            if file_id is not None:
                key = f"file_id:{file_id}"
            elif file_url is not None:
                key = f"file_url:{file_url}"
            elif file_data is not None:
                digest = sha256_text(file_data)[:12]
                key = f"file_data:{digest}…"
            elif filename is not None:
                key = f"filename:{filename}"
            else:
                key = "file:<unknown>"
            groups[key] = groups.get(key, 0) + 1
    return groups


def _collect_image_groups(snapshot: Sequence[JSONMapping]) -> dict[str, int]:
    groups = dict[str, int]()
    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in _message_parts(item):
            if part.get("type") != "input_image":
                continue
            file_id = _as_str(part.get("file_id"))
            image_url = _as_str(part.get("image_url"))
            if file_id is not None:
                key = f"file_id:{file_id}"
            elif image_url is not None and image_url.startswith("data:"):
                digest = sha256_text(image_url)[:12]
                key = f"data_url:{digest}…"
            elif image_url is not None:
                key = f"url:{image_url}"
            else:
                key = "image:<unknown>"
            groups[key] = groups.get(key, 0) + 1
    return groups


def _track_container_file_citation(
    groups: MutableMapping[str, dict[str, int]],
    ann: Mapping[str, JSONValue],
) -> None:
    container_id = _as_str(ann.get("container_id")) or "<unknown>"
    file_id = _as_str(ann.get("file_id")) or "<unknown>"
    by_container = groups.get(container_id)
    if by_container is None:
        by_container = dict[str, int]()
        groups[container_id] = by_container
    by_container[file_id] = by_container.get(file_id, 0) + 1


def _track_simple_file_citation(
    groups: MutableMapping[str, int],
    ann: Mapping[str, JSONValue],
) -> None:
    file_id = _as_str(ann.get("file_id")) or "<unknown>"
    groups[file_id] = groups.get(file_id, 0) + 1


def _track_url_citation(
    groups: MutableMapping[str, int],
    ann: Mapping[str, JSONValue],
) -> None:
    url = _as_str(ann.get("url")) or ""
    key = _domain(url) or url or "<unknown>"
    groups[key] = groups.get(key, 0) + 1


def _collect_citations(snapshot: Sequence[JSONMapping]) -> _CitationGroups:
    container_file = dict[str, dict[str, int]]()
    file_citation = dict[str, int]()
    file_path = dict[str, int]()
    url_citation = dict[str, int]()

    handlers: Mapping[str, Callable[[Mapping[str, JSONValue]], None]] = {
        "container_file_citation": lambda ann: _track_container_file_citation(
            container_file,
            ann,
        ),
        "file_citation": lambda ann: _track_simple_file_citation(file_citation, ann),
        "file_path": lambda ann: _track_simple_file_citation(file_path, ann),
        "url_citation": lambda ann: _track_url_citation(url_citation, ann),
    }

    for item in snapshot:
        if item.get("type") != "message":
            continue
        for part in _message_parts(item):
            if part.get("type") != "output_text":
                continue
            anns_obj = _as_list(part.get("annotations")) or []
            for ann_raw in anns_obj:
                ann = _as_dict(ann_raw)
                if ann is None:
                    continue
                handler = handlers.get(_as_str(ann.get("type")) or "")
                if handler is not None:
                    handler(ann)
    return _CitationGroups(
        container_file=container_file,
        file_citation=file_citation,
        file_path=file_path,
        url_citation=url_citation,
    )


def _render_kv_counts(label: str, counts: Mapping[str, int]) -> str:
    if not counts:
        return f"- {label}: none"
    parts = " ".join(f"{k}={counts[k]}" for k in sorted(counts))
    return f"- {label}: {parts}"


def _render_flat_groups(title: str, groups: Mapping[str, int]) -> list[str]:
    if not groups:
        return []
    keys = sorted(groups)[: (_MAX_GROUP_ITEMS or None)]
    lines = [title, *[f"- {k} (n={groups[k]})" for k in keys]]
    extra = len(groups) - len(keys)
    if extra > 0:
        lines.append(f"- … ({extra} more)")
    return lines


def _render_container_citations(groups: Mapping[str, Mapping[str, int]]) -> list[str]:
    if not groups:
        return []
    lines: list[str] = ["- container_file_citation:"]
    containers = sorted(groups)[: (_MAX_GROUP_ITEMS or None)]
    for container_id in containers:
        lines.append(f"  - container_id={container_id}:")
        by_file = groups[container_id]
        file_ids = sorted(by_file)[: (_MAX_GROUP_ITEMS or None)]
        lines.extend(
            [f"    - file_id={fid} (n={by_file[fid]})" for fid in file_ids],
        )
        extra_files = len(by_file) - len(file_ids)
        if extra_files > 0:
            lines.append(f"    - … ({extra_files} more files)")
    extra_containers = len(groups) - len(containers)
    if extra_containers > 0:
        lines.append(f"  - … ({extra_containers} more containers)")
    return lines


def _render_citations(groups: _CitationGroups) -> list[str]:
    if not groups.any():
        return []
    lines: list[str] = ["Citations:"]
    lines.extend(_render_container_citations(groups.container_file))
    lines.extend(_render_flat_groups("- file_citation:", groups.file_citation))
    lines.extend(_render_flat_groups("- file_path:", groups.file_path))
    lines.extend(_render_flat_groups("- url_citation:", groups.url_citation))
    return lines


def _format_snapshot_lines(slice_: _SnapshotSlice) -> list[str]:
    comp_id = _as_str(slice_.compaction_item.get("id"))
    enc = _as_str(slice_.compaction_item.get("encrypted_content")) or ""
    header = "compaction> last snapshot"
    if comp_id is not None:
        header += f" (compaction_item_id={comp_id})"

    role_counts = _collect_role_counts(slice_.snapshot)
    part_counts = _collect_part_counts(slice_.snapshot)
    file_groups = _collect_file_groups(slice_.snapshot)
    image_groups = _collect_image_groups(slice_.snapshot)
    citations = _collect_citations(slice_.snapshot)

    lines: list[str] = [
        header,
        f"- snapshot_items: {len(slice_.snapshot)}",
        f"- compaction.encrypted_content: {_redact_blob(enc)}",
        _render_kv_counts("roles", role_counts),
        _render_kv_counts("parts", part_counts),
    ]

    grouped: list[str] = []
    grouped.extend(_render_flat_groups("Files:", file_groups))
    grouped.extend(_render_flat_groups("Images:", image_groups))
    grouped.extend(_render_citations(citations))

    if grouped:
        lines.append("")
        lines.extend(grouped)

    lines.append("")
    lines.append("Messages:")
    msg_idx = 0
    for item in slice_.snapshot:
        if item.get("type") != "message":
            continue
        msg_idx += 1
        lines.extend(_summarize_message(item, idx=msg_idx))
    if msg_idx == 0:
        lines.append("(no messages in snapshot)")
    return lines


def format_last_compaction_snapshot_lines(
    raw_items: Sequence[TResponseInputItem],
) -> list[str] | None:
    """Return summary lines for the most recent compaction snapshot, if any."""
    items: list[dict[str, JSONValue]] = []
    for raw in raw_items:
        obj = _to_json_object(raw)
        if obj is not None:
            items.append(obj)

    slice_ = _find_last_compaction_snapshot(items)
    if slice_ is None:
        return None
    return _format_snapshot_lines(slice_)


__all__ = ("format_last_compaction_snapshot_lines",)
