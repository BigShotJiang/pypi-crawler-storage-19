"""Action handlers for `agenterm ui repl loop`.

The REPL loop owns input handling and run lifecycle. These handlers implement
the side-effecting action outcomes (new session, attach session, compression,
editor integration, etc.) and are kept in a separate module to maintain the
repo's per-file size budget.
"""

from __future__ import annotations

import sqlite3
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from agenterm.app.services.approvals import wire_repl_approvals
from agenterm.commands.actions import (
    ReplAction,
    ReplActionAttachSession,
    ReplActionCompress,
    ReplActionCompressShow,
    ReplActionEditLast,
    ReplActionExit,
    ReplActionLastArtifact,
    ReplActionNewSession,
    ReplActionSendAgain,
    ReplActionSessionRuns,
)
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.error_report import build_error_report
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.hashing import sha256_text_or_none
from agenterm.core.store_policy import store_is_enabled
from agenterm.store.branch.service import create_branch_from_run
from agenterm.store.runs import list_runs
from agenterm.store.session.service import (
    SessionFactoryConfig,
    make_session,
    session_store,
    usage_totals_by_run,
)
from agenterm.ui.repl.branch_actions import handle_branch_action
from agenterm.ui.repl.branch_state import (
    apply_branch_meta,
    branch_error_context,
    refresh_branch_cache,
    refresh_usage_totals,
    require_session,
)
from agenterm.ui.repl.compress_handlers import handle_compression_action
from agenterm.ui.repl.last_artifacts import handle_last_artifact
from agenterm.ui.repl.transcript_reload import reload_repl_transcript

if TYPE_CHECKING:
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.branch.models import BranchMeta
    from agenterm.store.runs.models import RunStatusRecord
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession
    from agenterm.ui.repl.loop import ReplLoop


async def _handle_session_runs(loop: ReplLoop, outcome: ReplActionSessionRuns) -> bool:
    if loop.state.session_id is None:
        loop.emit_command("No active session; /session runs unavailable.")
        return True
    session_id = loop.state.session_id
    branch_id = loop.state.branch_id or "main"
    store = session_store()
    try:
        runs = await list_runs(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            limit=outcome.limit,
        )
        usage_by_run = await usage_totals_by_run(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        report = build_error_report(
            DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
            context=branch_error_context(loop.state, "session.runs"),
        )
        loop.emit(report)
        return True
    lines: list[str] = [f"Runs ({session_id}, {branch_id}):"]
    if not runs:
        lines.append("No runs recorded.")
    else:
        for run in runs:
            usage = usage_by_run.get(run.run_number)
            if usage is None:
                tokens = "-"
            else:
                tokens = (
                    f"{usage.input_tokens}({usage.input_cached_tokens})"
                    f"->{usage.output_tokens}"
                    f"({usage.output_reasoning_tokens})"
                    f"={usage.total_tokens}"
                )
            status = run.status or "-"
            response_id = run.response_id or "-"
            lines.append(
                f"- {run.run_number}: {status}  tokens={tokens}  response={response_id}"
            )
    loop.emit_command_lines(lines)
    return True


type ReplayDecision = Literal["none", "in_place", "fork"]


def replay_decision_for_run(run: RunStatusRecord | None) -> ReplayDecision:
    """Decide replay strategy for /again or /edit based on the last run."""
    if run is None:
        return "none"
    if run.branch_turn_start is None:
        return "in_place"
    return "fork"


async def _create_replay_branch(
    loop: ReplLoop,
    *,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    last_run: RunStatusRecord,
    operation: str,
) -> BranchMeta | None:
    try:
        return await create_branch_from_run(
            session=session,
            store=store,
            session_id=session_id,
            run_number=last_run.run_number,
            branch_id=None,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(
                loop.state.cfg.agent.instructions,
            ),
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        report = build_error_report(
            DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
            context=branch_error_context(loop.state, operation),
        )
        loop.emit(report)
    return None


async def _fork_from_last_run(loop: ReplLoop, *, operation: str) -> bool:
    session = require_session(loop)
    if session is None:
        return False
    session_id = (
        loop.state.session_id if isinstance(loop.state.session_id, str) else None
    )
    if session_id is None:
        loop.emit_command("Replay requires a stored session.")
        return False
    store = session_store()
    branch_id = loop.state.branch_id or "main"
    meta = None
    try:
        runs = await list_runs(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            limit=1,
        )
    except (ConfigError, sqlite3.Error, OSError, DatabaseError) as exc:
        report = build_error_report(
            DatabaseError(str(exc)) if isinstance(exc, sqlite3.Error) else exc,
            context=branch_error_context(loop.state, operation),
        )
        loop.emit(report)
    else:
        last_run = runs[0] if runs else None
        decision = replay_decision_for_run(last_run)
        if decision == "none":
            loop.emit_command("No previous run to replay.")
        elif decision == "in_place":
            loop.emit_command("Last run has no turn range; retrying in place.")
            return True
        elif decision == "fork" and last_run is not None:
            meta = await _create_replay_branch(
                loop,
                session=session,
                store=store,
                session_id=session_id,
                last_run=last_run,
                operation=operation,
            )

    if meta is None:
        return False

    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.state = apply_branch_meta(loop.state, meta)
    try:
        branch_cache = await refresh_branch_cache(
            session_id=session_id,
            store=store,
        )
        loop.state = replace(
            loop.state,
            caches=replace(loop.state.caches, branch_ids=branch_cache),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    await refresh_usage_totals(
        loop=loop,
        store=store,
        session_id=session_id,
        branch_id=meta.branch_id,
    )
    await reload_repl_transcript(loop, branch_id=meta.branch_id)
    loop.tui.invalidate()
    return True


async def _handle_send_again(loop: ReplLoop, _outcome: ReplActionSendAgain) -> bool:
    if loop.run_running():
        loop.emit_command("Run running; wait before /again.")
        return True
    prompt = loop.state.prompt.last_user_prompt or ""
    if not prompt:
        loop.emit_command("Nothing to send again.")
        return True
    if not await _fork_from_last_run(loop, operation="repl.again"):
        return True
    loop.emit_user(prompt)
    loop.start_run(
        prompt,
        use_last=True,
    )
    return True


async def _handle_edit_last(loop: ReplLoop) -> bool:
    if loop.run_running():
        loop.emit_command("Run running; wait before /edit.")
        return True
    prompt = loop.state.prompt.last_user_prompt or ""
    if not prompt:
        loop.emit_command("Nothing to edit.")
        return True
    if not await _fork_from_last_run(loop, operation="repl.edit"):
        return True
    loop.state = loop.state.with_next_send_use_last(on=True)
    loop.tui.set_buffer_text(prompt)
    return True


async def _handle_new_session(loop: ReplLoop, outcome: ReplActionNewSession) -> bool:
    if outcome.notice:
        loop.emit_command(outcome.notice)
    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.approvals_cleanup()

    session_result = await make_session(
        SessionFactoryConfig(
            mode="repl",
            cwd=Path.cwd(),
            config_path=loop.state.config_path,
            model=loop.state.cfg.agent.model,
            tools_enabled=loop.state.tools.enabled,
            trace_id=loop.state.cfg.run.trace_id,
            group_id=loop.state.cfg.run.group_id,
            session_id=None,
            branch_id=None,
            store_enabled=store_is_enabled(store=loop.state.cfg.model.store),
            store_override=None,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        ),
    )
    mem_session_local = session_result.session
    sess_id2 = session_result.session_id

    loop.mem_session = mem_session_local
    state = loop.state
    if session_result.branch_meta is not None:
        state = apply_branch_meta(
            state,
            session_result.branch_meta,
        )
    cache = loop.state.caches.session_ids or ()
    if isinstance(sess_id2, str) and sess_id2:
        cache = tuple({*cache, sess_id2})
    branch_cache: tuple[str, ...] = ()
    if isinstance(session_result.branch_id, str) and session_result.branch_id:
        branch_cache = (session_result.branch_id,)
    loop.state = replace(
        state,
        session_id=(sess_id2 if isinstance(sess_id2, str) else None),
        prompt=replace(state.prompt, last_user_prompt=None),
        attachments=replace(
            state.attachments,
            pending=(),
            last_used=(),
            next_send_use_last=False,
        ),
        caches=replace(state.caches, session_ids=cache, branch_ids=branch_cache),
        approvals=ApprovalsContext(mode=loop.state.approvals.mode),
    )
    loop.state, loop.approvals_cleanup = wire_repl_approvals(
        loop.state,
        notify=loop.notify_approval,
        emit_event=loop.emit_approval_event,
    )
    await reload_repl_transcript(loop, branch_id=loop.state.branch_id)
    if isinstance(sess_id2, str):
        loop.emit_command(f"New session started: {sess_id2}")
    else:
        loop.emit_command("New session started.")
    return True


async def _handle_attach_session(
    loop: ReplLoop,
    outcome: ReplActionAttachSession,
) -> bool:
    session_result = await make_session(
        SessionFactoryConfig(
            mode="repl",
            cwd=Path.cwd(),
            config_path=loop.state.config_path,
            model=loop.state.cfg.agent.model,
            tools_enabled=loop.state.tools.enabled,
            trace_id=loop.state.cfg.run.trace_id,
            group_id=loop.state.cfg.run.group_id,
            session_id=outcome.session_id,
            branch_id=None,
            store_enabled=store_is_enabled(store=loop.state.cfg.model.store),
            store_override=None,
            agent_name=loop.state.cfg.agent.name,
            agent_path=loop.state.cfg.agent.path,
            agent_sha256=sha256_text_or_none(loop.state.cfg.agent.instructions),
        ),
    )
    loop.mem_session = session_result.session
    state = loop.state
    if session_result.branch_meta is not None:
        state = apply_branch_meta(
            state,
            session_result.branch_meta,
        )
    cache = loop.state.caches.session_ids or ()
    cache = tuple({*cache, outcome.session_id})
    branch_cache = loop.state.caches.branch_ids or ()
    try:
        branch_cache = await refresh_branch_cache(
            session_id=outcome.session_id,
            store=session_store(),
        )
    except (ConfigError, OSError, sqlite3.Error, DatabaseError) as exc:
        loop.emit_command(f"warn> Failed to refresh branches: {exc}")
    loop.state = replace(
        state,
        session_id=outcome.session_id,
        branch_id=session_result.branch_id,
        prompt=replace(state.prompt, last_user_prompt=None),
        caches=replace(state.caches, session_ids=cache, branch_ids=branch_cache),
        approvals=ApprovalsContext(mode=loop.state.approvals.mode),
    )
    loop.phase_state.phase = "idle"
    loop.phase_state.reset_usage()
    loop.artifacts.clear()
    loop.approvals_cleanup()
    loop.state, loop.approvals_cleanup = wire_repl_approvals(
        loop.state,
        notify=loop.notify_approval,
        emit_event=loop.emit_approval_event,
    )
    await reload_repl_transcript(loop, branch_id=loop.state.branch_id)
    loop.emit_command(f"Attached to session: {outcome.session_id}")
    if isinstance(loop.state.branch_id, str):
        await refresh_usage_totals(
            loop=loop,
            store=session_store(),
            session_id=outcome.session_id,
            branch_id=loop.state.branch_id,
        )
    return True


def _handle_last_artifact(loop: ReplLoop, outcome: ReplActionLastArtifact) -> bool:
    return handle_last_artifact(
        outcome=outcome,
        state=loop.state,
        artifacts=loop.artifacts,
        emit_command=loop.emit_command,
    )


async def _handle_primary_action(
    loop: ReplLoop,
    outcome: ReplAction,
) -> bool | None:
    result: bool | None = None
    if isinstance(outcome, ReplActionExit):
        result = False
    elif isinstance(outcome, ReplActionSendAgain):
        result = await _handle_send_again(loop, outcome)
    elif isinstance(outcome, ReplActionEditLast):
        result = await _handle_edit_last(loop)
    elif isinstance(outcome, ReplActionNewSession):
        result = await _handle_new_session(loop, outcome)
    elif isinstance(outcome, ReplActionAttachSession):
        result = await _handle_attach_session(loop, outcome)
    elif isinstance(outcome, ReplActionSessionRuns):
        result = await _handle_session_runs(loop, outcome)
    return result


async def _handle_secondary_action(
    loop: ReplLoop,
    outcome: ReplAction,
) -> bool | None:
    result: bool | None = None
    if isinstance(outcome, (ReplActionCompress, ReplActionCompressShow)):
        result = await handle_compression_action(loop, outcome)
    elif isinstance(outcome, ReplActionLastArtifact):
        result = _handle_last_artifact(loop, outcome)
    return result


async def handle_action(loop: ReplLoop, outcome: ReplAction) -> bool:
    """Apply an action outcome to the live REPL loop."""
    result = await _handle_primary_action(loop, outcome)
    if result is not None:
        return result
    result = await _handle_secondary_action(loop, outcome)
    if result is not None:
        return result
    branch_result = await handle_branch_action(loop, outcome)
    if branch_result is not None:
        return branch_result
    return True


__all__ = ("handle_action",)
