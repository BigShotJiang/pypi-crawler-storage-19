"""Typed UI state and reducer for the REPL TUI."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Literal

from prompt_toolkit.utils import Event

from agenterm.constants.display import REPL_UI_MAX_TRANSCRIPT_ENTRIES_DEFAULT
from agenterm.ui.transcript.approvals import ApprovalTranscriptBlock
from agenterm.ui.transcript.blocks import TranscriptBlock

TranscriptRole = Literal["user", "assistant", "system"]
UiModal = Literal["none", "approvals"]


@dataclass(frozen=True)
class TranscriptTextEntry:
    """Role-tagged text line(s) rendered in the transcript."""

    role: TranscriptRole
    text: str


@dataclass(frozen=True)
class TranscriptSeparatorEntry:
    """Run separator entry in the transcript."""

    label: str | None


type TranscriptEntry = (
    TranscriptBlock
    | ApprovalTranscriptBlock
    | TranscriptTextEntry
    | TranscriptSeparatorEntry
)


@dataclass(frozen=True)
class UiState:
    """Immutable TUI state snapshot."""

    transcript: tuple[TranscriptEntry, ...]
    streaming_block_id: str | None
    streaming_text: str
    modal: UiModal


@dataclass(frozen=True)
class TextDeltaEvent:
    """Streaming text delta for the current assistant response."""

    text: str
    block_id: str


@dataclass(frozen=True)
class TextFinalizedEvent:
    """Final assistant text for the current response."""

    block_id: str
    final_text: str | None


@dataclass(frozen=True)
class TranscriptEntryAddedEvent:
    """Append a transcript entry."""

    entry: TranscriptEntry


@dataclass(frozen=True)
class ModalChangedEvent:
    """Update the active modal."""

    modal: UiModal


type UiEvent = (
    TextDeltaEvent | TextFinalizedEvent | TranscriptEntryAddedEvent | ModalChangedEvent
)


_DEFAULT_MAX_TRANSCRIPT_ENTRIES = REPL_UI_MAX_TRANSCRIPT_ENTRIES_DEFAULT
_TRUNCATION_ENTRY = TranscriptTextEntry(
    role="system",
    text="... transcript truncated ...",
)


def initial_ui_state() -> UiState:
    """Return the initial empty UI state."""
    return UiState(
        transcript=(),
        streaming_block_id=None,
        streaming_text="",
        modal="none",
    )


def _bounded_transcript(
    entries: tuple[TranscriptEntry, ...],
    *,
    max_entries: int,
) -> tuple[TranscriptEntry, ...]:
    if max_entries <= 0:
        return (_TRUNCATION_ENTRY,)
    if len(entries) <= max_entries:
        return entries
    keep = max(1, max_entries - 1)
    return (_TRUNCATION_ENTRY, *entries[-keep:])


def reduce_state(
    state: UiState,
    event: UiEvent,
    *,
    max_entries: int,
) -> UiState:
    """Apply a UI event to the current state."""
    if isinstance(event, TranscriptEntryAddedEvent):
        updated = (*state.transcript, event.entry)
        return replace(
            state,
            transcript=_bounded_transcript(updated, max_entries=max_entries),
        )
    if isinstance(event, TextDeltaEvent):
        if event.block_id != state.streaming_block_id:
            return replace(
                state,
                streaming_block_id=event.block_id,
                streaming_text=event.text,
            )
        return replace(
            state,
            streaming_block_id=event.block_id,
            streaming_text=state.streaming_text + event.text,
        )
    if isinstance(event, TextFinalizedEvent):
        text = state.streaming_text if event.final_text is None else event.final_text
        updated = state.transcript
        if text:
            updated = _bounded_transcript(
                (*updated, TranscriptTextEntry(role="assistant", text=text)),
                max_entries=max_entries,
            )
        return replace(
            state,
            transcript=updated,
            streaming_block_id=None,
            streaming_text="",
        )
    return replace(state, modal=event.modal)


class UiStore:
    """Mutable UI store that emits invalidation events."""

    def __init__(
        self,
        *,
        initial_state: UiState | None = None,
        max_transcript_entries: int = _DEFAULT_MAX_TRANSCRIPT_ENTRIES,
    ) -> None:
        """Initialize the UI store and bounded transcript settings."""
        self._state = initial_state or initial_ui_state()
        self._max_transcript_entries = max(0, max_transcript_entries)
        self.on_change: Event[UiStore] = Event(self)

    @property
    def state(self) -> UiState:
        """Return the current UI state snapshot."""
        return self._state

    def dispatch(self, event: UiEvent) -> None:
        """Apply an event and notify subscribers."""
        self._state = reduce_state(
            self._state,
            event,
            max_entries=self._max_transcript_entries,
        )
        self.on_change()

    def set_max_transcript_entries(self, value: int) -> None:
        """Update the transcript entry cap and trim existing entries if needed."""
        next_value = max(0, value)
        if next_value == self._max_transcript_entries:
            return
        self._max_transcript_entries = next_value
        self._state = replace(
            self._state,
            transcript=_bounded_transcript(
                self._state.transcript,
                max_entries=self._max_transcript_entries,
            ),
        )
        self.on_change()

    def replace_transcript(self, entries: tuple[TranscriptEntry, ...]) -> None:
        """Replace the transcript entries and reset streaming state."""
        bounded = _bounded_transcript(
            entries,
            max_entries=self._max_transcript_entries,
        )
        self._state = UiState(
            transcript=bounded,
            streaming_block_id=None,
            streaming_text="",
            modal="none",
        )
        self.on_change()


__all__ = (
    "ModalChangedEvent",
    "TextDeltaEvent",
    "TextFinalizedEvent",
    "TranscriptEntry",
    "TranscriptEntryAddedEvent",
    "TranscriptRole",
    "TranscriptSeparatorEntry",
    "TranscriptTextEntry",
    "UiEvent",
    "UiModal",
    "UiState",
    "UiStore",
    "initial_ui_state",
)
