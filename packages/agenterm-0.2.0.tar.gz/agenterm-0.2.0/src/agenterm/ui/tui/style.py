"""Prompt-toolkit Style for the REPL TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.styles import BaseStyle, DynamicStyle

from agenterm.ui.tui.theme import tui_style_for_theme

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.types import SessionState


def tui_style(state_provider: Callable[[], SessionState]) -> BaseStyle:
    """Return the prompt-toolkit style used by the TUI."""

    def _get_style() -> BaseStyle:
        return tui_style_for_theme(state_provider().ui.theme)

    return DynamicStyle(_get_style)


__all__ = ("tui_style",)
