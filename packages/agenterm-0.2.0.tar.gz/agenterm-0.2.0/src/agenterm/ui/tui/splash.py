"""Psychedelic ASCII splash screen for REPL startup.

CRT-style materialization: text emerges from static with scan lines and flicker.
"""

from __future__ import annotations

import asyncio
import colorsys
import math
import shutil
import time
from contextlib import suppress
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from prompt_toolkit.application import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import UIContent, UIControl
from prompt_toolkit.output.color_depth import ColorDepth

if TYPE_CHECKING:
    from collections.abc import Callable

    from prompt_toolkit.formatted_text import StyleAndTextTuples
    from prompt_toolkit.key_binding.key_processor import KeyPressEvent


# ============= Constants =============

_HALF: Final[float] = 0.5
_TUNE_IN_DURATION: Final[float] = 0.35  # Fraction of duration for tune-in phase
_MIN_TERMINAL_WIDTH: Final[int] = 82
_MIN_TERMINAL_HEIGHT: Final[int] = 16

# Static/noise characters (by density)
_STATIC_CHARS: Final[tuple[str, ...]] = ("░", "▒", "▓", "█", "▄", "▀", "▌", "▐")


# ============= Configuration =============


@dataclass(frozen=True, slots=True)
class SplashConfig:
    """Immutable splash animation configuration."""

    duration_seconds: float = 2.8
    fps: int = 60
    scan_line_speed: float = 3.5  # Scan lines per second
    pulse_speed: float = 2.0  # Breathing pulses per second
    flicker_intensity: float = 0.15  # Max flicker amplitude
    shimmer_speed: float = 45.0  # Rainbow hue rotation speed


# ============= AGENTERM Typography =============

_AGENTERM_ROWS: Final[tuple[str, ...]] = (
    "                                          ██                                  ",
    "                                          ██                                  ",
    " ▒████▓    ▒███▒██   ░████▒   ██░████   ███████    ░████▒    ██░████  ██▓█▒██▒",
    " ██████▓  ░███████  ░██████▒  ███████▓  ███████   ░██████▒   ███████  ████████",
    " █▒  ▒██  ███  ███  ██▒  ▒██  ███  ▒██    ██      ██▒  ▒██   ███░     ██░██░██",
    "  ▒█████  ██░  ░██  ████████  ██    ██    ██      ████████   ██       ██ ██ ██",
    "░███████  ██    ██  ████████  ██    ██    ██      ████████   ██       ██ ██ ██",
    "██▓░  ██  ██░  ░██  ██        ██    ██    ██      ██         ██       ██ ██ ██",
    "██▒  ███  ███  ███  ███░  ▒█  ██    ██    ██░     ███░  ▒█   ██       ██ ██ ██",
    "████████  ░███████  ░███████  ██    ██    █████   ░███████   ██       ██ ██ ██",
    " ▓███░██   ▒███▒██   ░█████▒  ██    ██    ░████    ░█████▒   ██       ██ ██ ██",
    "           █░  ▒██                                                            ",
    "           ██████▓                                                            ",
    "           ▒████▒                                                             ",
)


# ============= Helper Functions =============


def _hue_to_hex(hue: float, saturation: float = 0.95, lightness: float = 0.6) -> str:
    """Convert HSL to #rrggbb hex. Hue in degrees (0-360)."""
    h = (hue % 360.0) / 360.0
    r, g, b = colorsys.hls_to_rgb(h, lightness, saturation)
    return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"


def _noise(seed: int) -> float:
    """Fast deterministic noise, returns 0.0 to 1.0."""
    x = ((seed * 1103515245 + 12345) >> 16) & 0x7FFF
    return x / 32767.0


def _signed_noise(seed: int) -> float:
    """Fast deterministic noise, returns -0.5 to +0.5."""
    return _noise(seed) - _HALF


# ============= CRT Effects =============


def _scan_line_boost(row_norm: float, scan_pos: float) -> float:
    """Calculate brightness boost from scan line passing over row."""
    # Distance from scan line (with wrap-around)
    dist = abs(row_norm - scan_pos)
    dist = min(dist, 1.0 - dist)  # Handle wrap-around

    # Sharp falloff - bright band
    boost = max(0.0, 1.0 - dist * 12.0)
    return boost * 0.35


def _char_flicker(row: int, col: int, frame: int, intensity: float) -> float:
    """Per-character brightness flicker."""
    seed = (row * 73 + col * 37 + frame * 11) * 1103515245
    return _signed_noise(seed) * intensity


def _global_pulse(elapsed: float, speed: float) -> float:
    """Global breathing pulse effect."""
    return _HALF + _HALF * math.sin(elapsed * math.pi * speed)


def _tune_in_visibility(
    row: int,
    col: int,
    tune_progress: float,
    frame: int,
) -> tuple[bool, str | None]:
    """Determine if character is visible during tune-in phase.

    Returns (is_real_char, static_char_or_none).
    During tune-in, characters randomly appear from static.
    """
    if tune_progress >= 1.0:
        return True, None

    # Each character has a threshold based on its position
    char_hash = (row * 127 + col * 31) % 100

    # Add temporal variation - characters flicker in and out
    temporal_noise = _noise((row * 53 + col * 97 + frame * 7) * 12345) * 30
    threshold = tune_progress * 100 + temporal_noise

    if char_hash < threshold:
        # Show real character (possibly with extra noise)
        return True, None

    # Show static instead
    static_idx = int(
        _noise((row * 41 + col * 67 + frame * 13) * 54321) * len(_STATIC_CHARS)
    )
    return False, _STATIC_CHARS[static_idx % len(_STATIC_CHARS)]


# ============= Rendering =============


def _render_crt_frame(
    config: SplashConfig,
    elapsed: float,
    width: int,
    height: int,
) -> list[StyleAndTextTuples]:
    """Render CRT-style animation frame."""
    progress = min(1.0, elapsed / config.duration_seconds)
    frame = int(elapsed * config.fps)

    # Tune-in progress (0 = static, 1 = fully tuned)
    tune_progress = min(1.0, progress / _TUNE_IN_DURATION)

    # Scan line position (0-1, wraps around)
    scan_pos = (elapsed * config.scan_line_speed) % 1.0

    # Global pulse
    pulse = _global_pulse(elapsed, config.pulse_speed)

    # Calculate text positioning (centered)
    text_height = len(_AGENTERM_ROWS)
    text_width = max(len(row) for row in _AGENTERM_ROWS)
    offset_y = (height - text_height) // 2
    offset_x = (width - text_width) // 2

    # Initialize grid
    grid: list[list[tuple[str, str]]] = [
        [("", " ") for _ in range(width)] for _ in range(height)
    ]

    # Render each character
    for row_idx, row in enumerate(_AGENTERM_ROWS):
        screen_y = offset_y + row_idx
        if screen_y < 0 or screen_y >= height:
            continue

        # Normalized row position for scan line
        row_norm = row_idx / max(text_height - 1, 1)

        for col_idx, real_char in enumerate(row):
            if real_char == " ":
                continue

            screen_x = offset_x + col_idx
            if screen_x < 0 or screen_x >= width:
                continue

            # Check tune-in state
            is_real, static_char = _tune_in_visibility(
                row_idx, col_idx, tune_progress, frame
            )

            char = real_char if is_real else (static_char or real_char)

            # Normalized x position for rainbow
            x_norm = col_idx / max(text_width - 1, 1)

            # === Calculate CRT effects ===

            # Base brightness
            base_light = 0.50

            # Scan line boost
            scan_boost = _scan_line_boost(row_norm, scan_pos)

            # Per-character flicker
            flicker = _char_flicker(row_idx, col_idx, frame, config.flicker_intensity)

            # Global pulse effect (subtle)
            pulse_effect = (pulse - _HALF) * 0.12

            # During tune-in: extra instability
            tune_in_noise = 0.0
            if tune_progress < 1.0:
                tune_in_noise = (
                    _signed_noise((row_idx * 83 + col_idx * 59 + frame * 17) * 777)
                    * (1.0 - tune_progress)
                    * 0.25
                )

            # Combined brightness
            lightness = base_light + scan_boost + flicker + pulse_effect + tune_in_noise
            lightness = max(0.25, min(0.75, lightness))

            # Saturation (slightly reduced during scan line for "glow" effect)
            saturation = 0.88 - scan_boost * 0.3

            # === Rainbow hue ===
            base_hue = x_norm * 300  # Spread across spectrum
            shimmer = elapsed * config.shimmer_speed
            hue = base_hue + shimmer

            # Static characters get desaturated, random hue
            if not is_real:
                hue = _noise((row_idx * 29 + col_idx * 43 + frame * 3) * 999) * 360
                saturation = 0.3 + _noise(frame * 7 + row_idx + col_idx) * 0.4
                lightness = 0.35 + _noise(frame * 11 + col_idx) * 0.25

            color = _hue_to_hex(hue, saturation, lightness)
            style = f"fg:{color}"
            grid[screen_y][screen_x] = (style, char)

    return [list(row) for row in grid]


# ============= UIControl =============


class SplashControl(UIControl):
    """UIControl for the CRT splash animation."""

    def __init__(
        self,
        config: SplashConfig,
        *,
        start_time_provider: Callable[[], float],
    ) -> None:
        self._config = config
        self._start_time_provider = start_time_provider

    def create_content(self, width: int, height: int) -> UIContent:
        """Render the current animation frame."""
        start_time = self._start_time_provider()
        elapsed = time.time() - start_time

        grid = _render_crt_frame(self._config, elapsed, width, height)

        def get_line(line_number: int) -> StyleAndTextTuples:
            if line_number < len(grid):
                return grid[line_number]
            return []

        return UIContent(get_line=get_line, line_count=height)


# ============= Key Bindings =============


def _build_splash_key_bindings(
    *,
    skip_callback: Callable[[], None],
) -> KeyBindings:
    """Build key bindings that skip splash on any keypress."""
    kb = KeyBindings()

    def _on_any_key(_event: KeyPressEvent) -> None:
        skip_callback()

    kb.add("<any>")(_on_any_key)
    return kb


# ============= Color Depth =============


def _prompt_color_depth(depth: str) -> ColorDepth | None:
    """Convert config color depth string to prompt_toolkit ColorDepth."""
    if depth == "mono":
        return ColorDepth.DEPTH_1_BIT
    if depth == "ansi":
        return ColorDepth.DEPTH_4_BIT
    if depth == "default":
        return ColorDepth.DEPTH_8_BIT
    if depth == "truecolor":
        return ColorDepth.DEPTH_24_BIT
    return None


# ============= Entry Point =============


async def run_splash(
    *,
    config: SplashConfig | None = None,
    color_depth: str = "auto",
) -> bool:
    """Run the CRT-style splash animation.

    Returns True if completed normally, False if skipped by keypress.
    """
    cfg = config or SplashConfig()
    skipped = False
    start_time = time.time()

    def _start_time_provider() -> float:
        return start_time

    def _skip() -> None:
        nonlocal skipped
        skipped = True
        if app.is_running:
            app.exit()

    control = SplashControl(cfg, start_time_provider=_start_time_provider)
    layout = Layout(Window(control))

    app: Application[None] = Application(
        layout=layout,
        key_bindings=_build_splash_key_bindings(skip_callback=_skip),
        full_screen=True,
        mouse_support=False,
        color_depth=_prompt_color_depth(color_depth),
    )

    async def _animate() -> None:
        """Animation loop coroutine."""
        interval = 1.0 / cfg.fps

        while True:
            elapsed = time.time() - start_time
            if elapsed >= cfg.duration_seconds:
                break

            app.invalidate()
            await asyncio.sleep(interval)

        if app.is_running:
            app.exit()

    size = shutil.get_terminal_size((80, 24))
    if size.columns < _MIN_TERMINAL_WIDTH or size.lines < _MIN_TERMINAL_HEIGHT:
        return True

    animation_task = asyncio.create_task(_animate())

    try:
        await app.run_async()
    finally:
        animation_task.cancel()
        with suppress(asyncio.CancelledError):
            await animation_task

    return not skipped


__all__ = ("SplashConfig", "run_splash")
