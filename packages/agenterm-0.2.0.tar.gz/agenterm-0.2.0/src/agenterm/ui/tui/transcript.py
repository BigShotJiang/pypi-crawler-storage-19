"""Transcript UIControl for the REPL TUI."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import TYPE_CHECKING, Literal

from prompt_toolkit.application.current import get_app
from prompt_toolkit.data_structures import Point
from prompt_toolkit.formatted_text import ANSI, FormattedText, to_formatted_text
from prompt_toolkit.formatted_text.utils import split_lines
from prompt_toolkit.layout.controls import UIContent, UIControl
from prompt_toolkit.mouse_events import MouseEvent, MouseEventType
from rich.console import Console
from rich.markdown import Markdown

from agenterm.ui.transcript.approvals import ApprovalTranscriptBlock
from agenterm.ui.transcript.blocks import (
    ImageArtifactBlock,
    ReasoningBlock,
    ToolCallBlock,
    ToolOutputBlock,
)
from agenterm.ui.transcript.diffs import parse_numbered_diff_line
from agenterm.ui.tui.state import (
    TranscriptEntry,
    TranscriptSeparatorEntry,
    TranscriptTextEntry,
    UiStore,
)
from agenterm.ui.tui.text_wrap import wrap_fragments

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from prompt_toolkit.formatted_text import StyleAndTextTuples
    from prompt_toolkit.key_binding.key_bindings import NotImplementedOrNone
    from prompt_toolkit.layout.containers import Window


# Rich Console color_system accepts these literals
type RichColorSystem = Literal["auto", "standard", "256", "truecolor", "windows"]


def _rich_color_system(depth: str) -> RichColorSystem:
    """Map ReplColorDepth to Rich Console color_system."""
    _mapping: Mapping[str, RichColorSystem] = {
        "auto": "auto",
        "mono": "standard",
        "ansi": "standard",
        "default": "256",
        "truecolor": "truecolor",
    }
    return _mapping.get(depth, "auto")


type Fragments = StyleAndTextTuples
_SCROLL_STEP = 1
_MARKDOWN_WIDTH_DEFAULT = 80
_DIFF_STYLE_CLASSES: dict[str, str] = {
    "add": "class:transcript.diff.add",
    "remove": "class:transcript.diff.remove",
    "hunk": "class:transcript.diff.hunk",
    "header": "class:transcript.diff.header",
    "context": "class:transcript.diff.context",
}


@dataclass(frozen=True)
class _Line:
    fragments: Fragments


def _wrap_lines(lines: list[_Line], *, width: int) -> list[_Line]:
    if width <= 0:
        return lines
    wrapped: list[_Line] = []
    for line in lines:
        wrapped.extend(
            _Line(fragments=fragments)
            for fragments in wrap_fragments(line.fragments, width=width)
        )
    if not wrapped:
        return [_Line([("", "")])]
    return wrapped


def _role_text_lines(*, text: str, text_style: str) -> list[_Line]:
    lines = text.splitlines() if text else [""]
    if not lines:
        return []
    return [_Line([(text_style, line)]) for line in lines]


def _merge_style(base: str, style: str) -> str:
    if style == "[ZeroWidthEscape]":
        return style
    if not style:
        return base
    return f"{base} {style}"


def _apply_base_style(fragments: Fragments, *, base_style: str) -> Fragments:
    merged: Fragments = []
    for frag in fragments:
        style, text, *rest = frag
        merged_style = _merge_style(base_style, style)
        if rest:
            merged.append((merged_style, text, rest[0]))
        else:
            merged.append((merged_style, text))
    return merged


def _markdown_width(width: int | None) -> int:
    if isinstance(width, int) and width > 0:
        return width
    return _MARKDOWN_WIDTH_DEFAULT


@lru_cache(maxsize=256)
def _render_markdown_ansi(text: str, width: int, color_system: RichColorSystem) -> str:
    console = Console(
        record=True,
        width=_markdown_width(width),
        color_system=color_system,
        force_terminal=True,
    )
    console.print(Markdown(text))
    return console.export_text(styles=True).rstrip("\n")


def _markdown_lines(
    *,
    text: str,
    width: int | None,
    base_style: str,
    color_system: RichColorSystem,
) -> list[_Line]:
    if not text:
        return [_Line([(base_style, "")])]
    ansi_text = _render_markdown_ansi(text, _markdown_width(width), color_system)
    if not ansi_text:
        return [_Line([(base_style, "")])]
    fragments = to_formatted_text(ANSI(ansi_text))
    styled = _apply_base_style(fragments, base_style=base_style)
    return [_Line(list(line)) for line in split_lines(styled)]


def _header_line(
    *,
    label: str,
    suffix: str | None = None,
    style: str = "class:transcript.label",
) -> _Line:
    text = label if suffix is None else f"{label}{suffix}"
    return _Line([(style, text)])


def _detail_lines(lines: tuple[str, ...]) -> list[_Line]:
    rendered: list[_Line] = []
    for line in lines:
        style = "class:transcript.meta"
        parsed = parse_numbered_diff_line(line)
        if parsed is not None:
            _prefix, _content, kind = parsed
            style = _DIFF_STYLE_CLASSES.get(kind, style)
        rendered.append(_Line([(style, f"  {line}")]))
    return rendered


def _tool_block_lines(
    *,
    event_type: str,
    label: str,
    detail_lines: tuple[str, ...],
    success: bool | None = None,
) -> list[_Line]:
    suffix = ""
    if success is True:
        suffix = " (ok)"
    elif success is False:
        suffix = " (fail)"
    header = _header_line(label=f"[{event_type}] {label}", suffix=suffix)
    rendered = [header]
    rendered.extend(_detail_lines(detail_lines))
    return rendered


def _reasoning_lines(block: ReasoningBlock) -> list[_Line]:
    header = _header_line(label="[reasoning]")
    rendered = [header]
    summary = block.summary or ""
    if summary:
        rendered.extend(
            _Line([("class:transcript.meta", line)]) for line in summary.splitlines()
        )
    return rendered


def _image_artifact_lines(
    block: ImageArtifactBlock,
) -> list[_Line]:
    return [
        _header_line(label=f"[artifact] image {block.artifact_id}"),
        _Line([("class:transcript.meta", f"  saved: {block.path}")]),
        _Line(
            [
                (
                    "class:transcript.meta",
                    f"  meta: {block.mime} ({block.size_bytes} bytes)",
                ),
            ],
        ),
        _Line(
            [
                (
                    "class:transcript.meta",
                    f"  open: /artifacts open {block.artifact_id}",
                )
            ]
        ),
    ]


def _separator_line(label: str | None, *, width: int | None) -> _Line:
    if not label:
        if isinstance(width, int) and width > 0:
            return _Line([("class:transcript.separator", "-" * width)])
        return _Line([("class:transcript.separator", "----")])
    base = f"-- {label} "
    if isinstance(width, int) and width > len(base):
        base = base + "-" * (width - len(base))
    return _Line([("class:transcript.separator", base)])


def _entry_lines(
    entry: TranscriptEntry,
    *,
    width: int | None,
    render_markdown: bool,
    color_system: RichColorSystem,
) -> list[_Line]:
    if isinstance(entry, TranscriptTextEntry):
        role_style = f"class:transcript.{entry.role}"
        if render_markdown and entry.role == "assistant":
            lines = _markdown_lines(
                text=entry.text,
                width=width,
                base_style=role_style,
                color_system=color_system,
            )
        else:
            lines = _role_text_lines(text=entry.text, text_style=role_style)
    elif isinstance(entry, TranscriptSeparatorEntry):
        lines = [_separator_line(entry.label, width=width)]
    elif isinstance(entry, ApprovalTranscriptBlock):
        lines = _tool_block_lines(
            event_type=entry.event_type,
            label=entry.label,
            detail_lines=entry.detail_lines,
            success=entry.success,
        )
    elif isinstance(entry, ReasoningBlock):
        lines = _reasoning_lines(entry)
    elif isinstance(entry, ToolCallBlock):
        lines = _tool_block_lines(
            event_type="tool call",
            label=entry.label,
            detail_lines=entry.detail_lines,
            success=None,
        )
    elif isinstance(entry, ToolOutputBlock):
        lines = _tool_block_lines(
            event_type="tool output",
            label=entry.label,
            detail_lines=entry.detail_lines,
            success=entry.success,
        )
    else:
        lines = _image_artifact_lines(entry)
    return lines


def _entry_lines_with_spacing(
    entry: TranscriptEntry,
    *,
    width: int | None,
    render_markdown: bool,
    color_system: RichColorSystem,
) -> list[_Line]:
    rendered = _entry_lines(
        entry,
        width=width,
        render_markdown=render_markdown,
        color_system=color_system,
    )
    if rendered:
        rendered.append(_Line([("", "")]))
    return rendered


def build_transcript_lines(
    store: UiStore,
    *,
    width: int | None,
    render_markdown: bool,
    color_system: RichColorSystem,
) -> list[_Line]:
    state = store.state
    entries = list(state.transcript)

    lines: list[_Line] = []
    for entry in entries:
        lines.extend(
            _entry_lines_with_spacing(
                entry,
                width=width,
                render_markdown=render_markdown,
                color_system=color_system,
            ),
        )
    if state.streaming_text:
        lines.extend(
            _entry_lines_with_spacing(
                TranscriptTextEntry(role="assistant", text=state.streaming_text),
                width=width,
                render_markdown=False,
                color_system=color_system,
            ),
        )
    if not lines:
        return [_Line([("", "")])]
    return lines


class TranscriptControl(UIControl):
    """UIControl that renders transcript entries from the UiStore."""

    def __init__(
        self,
        store: UiStore,
        *,
        render_config: Callable[[], tuple[bool, str]],
    ) -> None:
        """Store the UI state provider used for transcript rendering."""
        self._store = store
        self._render_config = render_config
        self._scroll_top = 0
        self._follow_tail = True
        self._line_count = 0
        self._last_height = 0
        self._cached_lines: list[_Line] | None = None
        self._cached_width: int | None = None
        self._cached_render_markdown: bool | None = None
        self._cached_color_system: str | None = None
        self._cached_state_id: int | None = None

    def get_vertical_scroll(self, _window: Window) -> int:
        """Return the desired topmost visible transcript line.

        This is wired into Window(get_vertical_scroll=...) so scrolling can be
        driven directly, rather than indirectly via cursor visibility.
        """
        return self._scroll_top

    def _max_scroll_top(self) -> int:
        height = max(1, self._last_height)
        if self._line_count <= 0:
            return 0
        return max(self._line_count - height, 0)

    def _clamp_scroll_top(self) -> None:
        if self._line_count <= 0:
            self._scroll_top = 0
            return
        self._scroll_top = max(0, min(self._scroll_top, self._max_scroll_top()))

    def _scroll(self, delta: int) -> None:
        if self._line_count <= 0 or delta == 0:
            return
        self._follow_tail = False
        self._scroll_top += delta
        self._clamp_scroll_top()
        if self._scroll_top >= self._max_scroll_top():
            self._follow_tail = True

    def _build_cached_lines(
        self,
        *,
        width: int,
        render_markdown: bool,
        color_system: RichColorSystem,
    ) -> list[_Line]:
        state_id = id(self._store.state)
        if (
            self._cached_lines is not None
            and self._cached_width == width
            and self._cached_render_markdown == render_markdown
            and self._cached_color_system == color_system
            and self._cached_state_id == state_id
        ):
            return self._cached_lines
        base_lines = build_transcript_lines(
            self._store,
            width=width,
            render_markdown=render_markdown,
            color_system=color_system,
        )
        lines = _wrap_lines(base_lines, width=width)
        self._cached_lines = lines
        self._cached_width = width
        self._cached_render_markdown = render_markdown
        self._cached_color_system = color_system
        self._cached_state_id = state_id
        return lines

    def create_content(self, width: int, height: int) -> UIContent:
        """Build UIContent for the transcript view."""
        self._last_height = max(0, int(height))
        render_markdown, color_depth = self._render_config()
        lines = self._build_cached_lines(
            width=width,
            render_markdown=render_markdown,
            color_system=_rich_color_system(color_depth),
        )
        line_count = len(lines)
        self._line_count = line_count
        if self._follow_tail:
            self._scroll_top = self._max_scroll_top()
        self._clamp_scroll_top()
        cursor = Point(x=0, y=self._scroll_top)

        def _get_line(i: int) -> StyleAndTextTuples:
            return lines[i].fragments

        return UIContent(
            get_line=_get_line,
            line_count=line_count,
            cursor_position=cursor,
            show_cursor=False,
        )

    def mouse_handler(self, mouse_event: MouseEvent) -> NotImplementedOrNone:
        """Handle scroll events to navigate transcript history."""
        if mouse_event.event_type == MouseEventType.SCROLL_UP:
            self._scroll(-_SCROLL_STEP)
            get_app().invalidate()
            return None
        if mouse_event.event_type == MouseEventType.SCROLL_DOWN:
            self._scroll(_SCROLL_STEP)
            get_app().invalidate()
            return None
        return NotImplemented

    def is_focusable(self) -> bool:
        """Return False; transcript window is not focusable."""
        return False


def transcript_formatted_lines(
    store: UiStore,
    *,
    render_markdown: bool = False,
    color_depth: str = "auto",
) -> FormattedText:
    """Return transcript content as FormattedText (primarily for tests)."""
    lines = build_transcript_lines(
        store,
        width=None,
        render_markdown=render_markdown,
        color_system=_rich_color_system(color_depth),
    )
    fragments: Fragments = []
    for line in lines:
        fragments.extend(line.fragments)
        fragments.append(("", "\n"))
    return FormattedText(fragments)


__all__ = ("TranscriptControl", "transcript_formatted_lines")
