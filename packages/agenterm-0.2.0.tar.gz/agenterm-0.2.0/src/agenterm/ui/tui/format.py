"""Deterministic formatted-text builders for the REPL TUI."""

from __future__ import annotations

import colorsys
import math
import time
from typing import TYPE_CHECKING

from prompt_toolkit.formatted_text import FormattedText

if TYPE_CHECKING:
    from agenterm.ui.tui.model import ReplTuiModel

type Fragments = list[tuple[str, str]]

# Psychedelic waveform: THICK braille bands (2 rows) + noise for chaos
# Much more visible than single dots, with random jitter for trippy effect
_WAVEFORM_MIN_BARS: int = 12
_EVENT_SECTION_WIDTH: int = 14  # Fits longest: " compressing..." or " in_progress"
_WAVEFORM_CHARS: tuple[str, ...] = (
    "\u28e4",  # ⣤ index 0: strong negative - thick bottom band (dots 3,6,7,8)
    "\u28c0",  # ⣀ index 1: slight negative - bottom row (dots 7,8)
    "\u2836",  # ⠶ index 2: center - middle band (dots 2,3,5,6)
    "\u2809",  # ⠉ index 3: slight positive - top row (dots 1,4)
    "\u281b",  # ⠛ index 4: strong positive - thick top band (dots 1,2,4,5)
)
# Thresholds for 5-level waveform
_WAVEFORM_THRESHOLDS: tuple[float, ...] = (-0.4, -0.1, 0.1, 0.4)
_IDLE_CHAR: str = "\u2836"  # ⠶ center band for idle state


def _hue_to_hex(hue: float, saturation: float = 0.95, lightness: float = 0.6) -> str:
    """Convert HSL to #rrggbb hex. Hue in degrees (0-360)."""
    h = (hue % 360.0) / 360.0
    r, g, b = colorsys.hls_to_rgb(h, lightness, saturation)
    return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"


def _amplitude_to_char_index(amplitude: float) -> int:
    """Map amplitude (-1 to +1) to character index (0-4)."""
    for i, threshold in enumerate(_WAVEFORM_THRESHOLDS):
        if amplitude < threshold:
            return i
    return len(_WAVEFORM_THRESHOLDS)  # 4 = strong positive


def _noise(seed: int) -> float:
    """Fast deterministic noise from seed, returns -0.5 to +0.5."""
    # Simple hash-based noise
    x = ((seed * 1103515245 + 12345) >> 16) & 0x7FFF
    return (x / 32767.0) - 0.5


def _generate_waveform_char(
    t: float, bar_index: int, bar_count: int
) -> tuple[str, str]:
    """Generate one waveform character with psychedelic rainbow + noise.

    Combines sine waves with random noise for chaotic, trippy effect.
    Returns (style_string, character).
    """
    # Frame-based seed for deterministic but chaotic noise
    frame = int(t * 90)  # 90 noise updates per second (faster chaos)
    seed = frame * 31 + bar_index * 17

    # Normalize position across waveform (0.0 to 1.0)
    pos = bar_index / max(bar_count - 1, 1)

    # Base sine waves with position-based phase (faster frequencies)
    phase = pos * 4.0  # Full 4 cycles across width
    wave1 = math.sin(t * 7.0 + phase * math.pi * 2) * 0.25  # 2x faster base
    wave2 = math.sin(t * 16.0 + phase * math.pi * 3) * 0.2  # 2x faster medium

    # NOISE: the psychedelic secret sauce
    amplitude_noise = _noise(seed) * 0.7  # Strong random component
    amplitude = wave1 + wave2 + amplitude_noise
    amplitude = max(-1.0, min(1.0, amplitude))

    char = _WAVEFORM_CHARS[_amplitude_to_char_index(amplitude)]

    # Rainbow with hue spread across full width + fast rotation
    base_hue = (pos * 360.0) + (t * 440.0)  # Full spectrum + 2x faster rotation
    hue_jitter = _noise(seed * 7) * 40.0  # ±20° random jitter
    hue = base_hue + hue_jitter

    # Random brightness pulses
    lightness = 0.55 + _noise(seed * 13) * 0.2  # 0.45-0.65 range
    saturation = 0.9 + _noise(seed * 19) * 0.1  # 0.85-0.95 range

    color = _hue_to_hex(hue, saturation, lightness)

    return (f"fg:{color}", char)


def _agent_model_group(vm: ReplTuiModel) -> Fragments:
    parts: Fragments = []
    if vm.agent_name or vm.model:
        parts.append(("class:toolbar.key", "agent: "))
    if vm.agent_name:
        parts.append(("class:toolbar.agent", vm.agent_name))
    if vm.model:
        parts.append(("class:toolbar.model", f"[{vm.model}]"))
    return parts


def format_prompt_message(_vm: ReplTuiModel) -> FormattedText:
    """Format the left prompt message (chevron only)."""
    parts: Fragments = [("class:prompt.chevron", "> ")]
    return FormattedText(parts)


def format_placeholder(vm: ReplTuiModel) -> FormattedText:
    """Format placeholder guidance shown only when the input buffer is empty."""
    if vm.hud_notice:
        style = (
            "class:placeholder.warn"
            if vm.hud_notice_level == "warn"
            else "class:placeholder"
        )
        return FormattedText([(style, vm.hud_notice)])
    if vm.phase == "running":
        if vm.approvals.total_pending > 0:
            msg = "Approval pending - review modal or /approvals list."
        else:
            msg = "Run running - ESC cancels."
    elif vm.phase == "compressing":
        msg = "Compressing..."
    else:
        msg = (
            "Enter sends. Ctrl+J inserts newline. Ctrl+C clears input. "
            "/attach <PATH|URL> adds context."
        )
    return FormattedText([("class:placeholder", msg)])


def _auto_group(vm: ReplTuiModel) -> Fragments:
    if vm.approvals.mode != "auto":
        return []
    return [("class:toolbar.auto", "AUTO")]


def _kv_group(label: str, value: str) -> Fragments:
    return [
        ("class:toolbar.key", f"{label}: "),
        ("class:toolbar.value", value),
    ]


def _effort_group(vm: ReplTuiModel) -> Fragments:
    value = vm.reasoning_effort or "unset"
    return _kv_group("effort", value)


def _context_group(vm: ReplTuiModel) -> Fragments:
    tokens = vm.last_request_input_tokens
    context_window = vm.context_window
    if not isinstance(tokens, int):
        value = "--"
    elif isinstance(context_window, int) and context_window > 0:
        percent = round((tokens / context_window) * 100)
        value = f"{percent}%"
    else:
        value = str(tokens)
    return _kv_group("context", value)


def _tools_group(vm: ReplTuiModel) -> Fragments:
    label = vm.tools_bundle_label or "none"
    return _kv_group("tools", label)


def _toolbar_length(parts: Fragments) -> int:
    return sum(len(text) for _, text in parts)


def _build_toolbar_left(vm: ReplTuiModel) -> Fragments:
    left: Fragments = []
    left.extend(_agent_model_group(vm))
    for group in (_effort_group(vm), _tools_group(vm), _context_group(vm)):
        if group:
            if left:
                left.append(("class:toolbar.sep", " | "))
            left.extend(group)
    return left


def format_bottom_toolbar(
    vm: ReplTuiModel,
    *,
    width: int | None = None,
) -> FormattedText:
    """Format the bottom toolbar (single-line, deterministic)."""
    left = _build_toolbar_left(vm)
    auto_group = _auto_group(vm)
    if isinstance(width, int) and width > 0 and auto_group:
        left_len = _toolbar_length(left)
        right_len = _toolbar_length(auto_group)
        if left_len + right_len <= width:
            padding = width - left_len - right_len
            pad = [("class:toolbar.pad", " " * padding)] if padding > 0 else []
            return FormattedText(left + pad + auto_group)

    if auto_group:
        if left:
            left.append(("class:toolbar.sep", " | "))
        left.extend(auto_group)
    return FormattedText(left)


def format_activity_indicator(
    vm: ReplTuiModel,
    *,
    width: int | None = None,
) -> FormattedText:
    """Format the live activity indicator based on verbosity.

    Verbosity modes:
    - quiet: Empty line (no waveform)
    - normal: Full-width waveform, no event hints
    - debug: Waveform + event hint section

    Phase states:
    - idle: Dim flat line
    - compressing: Solid bars + message (debug only)
    - running: Animated rainbow waveform
    """
    effective_width = width if isinstance(width, int) and width > 0 else 80

    # Quiet mode: empty line
    if vm.verbosity == "quiet":
        return FormattedText([("class:indicator.idle", "")])

    # Debug mode reserves space for event hints; normal uses full width
    show_events = vm.verbosity == "debug"
    if show_events and effective_width > _EVENT_SECTION_WIDTH + _WAVEFORM_MIN_BARS:
        bar_count = effective_width - _EVENT_SECTION_WIDTH
    else:
        bar_count = max(effective_width, _WAVEFORM_MIN_BARS)

    parts: Fragments = []

    if vm.phase == "idle":
        # Idle: dim flat line spanning waveform area
        parts.append(("class:indicator.idle", _IDLE_CHAR * bar_count))
        if show_events:
            parts.append(("class:indicator.hint", " " * _EVENT_SECTION_WIDTH))
    elif vm.phase == "compressing":
        # Compressing: full bars + right-aligned message (debug only)
        parts.append(("class:indicator.active", "\u2588" * bar_count))
        if show_events:
            hint = " compressing..."
            padding = _EVENT_SECTION_WIDTH - len(hint)
            parts.append(("class:indicator.hint", " " * padding + hint))
    else:
        # Running: psychedelic rainbow waveform
        t = time.time()
        for i in range(bar_count):
            style, char = _generate_waveform_char(t, i, bar_count)
            parts.append((style, char))

        if show_events:
            # Fixed-width event section (right-aligned hint)
            hint = f" {vm.last_event_hint}" if vm.last_event_hint else ""
            if len(hint) > _EVENT_SECTION_WIDTH:
                hint = hint[: _EVENT_SECTION_WIDTH - 1] + "…"
            padding = _EVENT_SECTION_WIDTH - len(hint)
            parts.append(("class:indicator.hint", " " * padding + hint))

    return FormattedText(parts)


__all__ = (
    "format_activity_indicator",
    "format_bottom_toolbar",
    "format_placeholder",
    "format_prompt_message",
)
