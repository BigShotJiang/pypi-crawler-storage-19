"""Theme tokens for the REPL TUI (prompt + transcript + modals)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from prompt_toolkit.styles import BaseStyle, Style, default_ui_style, merge_styles

from agenterm.ui.color_tokens import COLOR_TOKENS_DARK, COLOR_TOKENS_LIGHT

if TYPE_CHECKING:
    from agenterm.core.choices.repl_ui import ReplTheme


@dataclass(frozen=True, slots=True)
class _TuiTokens:
    toolbar_bg: str
    toolbar_fg: str
    dim: str
    brand: str
    phase: str
    model: str
    key: str
    value: str
    sep: str
    good: str
    warn: str
    error: str
    surface_bg: str
    surface_fg: str
    surface_alt_bg: str
    surface_alt_fg: str
    surface_meta_bg: str
    surface_meta_fg: str
    surface_meta_alt_bg: str
    surface_meta_alt_fg: str
    scrollbar_bg: str
    scrollbar_button: str
    search_bg: str
    search_fg: str
    selection_bg: str
    selection_fg: str
    cursor_line_bg: str
    cursor_column_bg: str
    bracket_bg: str
    bracket_fg: str
    input_bg: str
    input_fg: str
    menu_bg: str
    menu_fg: str
    menu_alt_bg: str
    menu_alt_fg: str
    menu_meta_fg: str


_TOKENS_DARK: Final[_TuiTokens] = _TuiTokens(
    # Zone backgrounds — warm amber hierarchy
    toolbar_bg="#1c1610",  # Status chrome — elevated warm brown
    toolbar_fg="#d4c4a8",  # Warm cream
    dim="#786048",  # Placeholder/muted — amber-brown
    brand="#e4a840",  # Bright amber signature
    phase="#d89820",
    model="#f0e0c0",
    key="#d49818",  # Rich amber labels
    value="#e8dcc4",
    sep="#443420",  # Visible separator — warm brown
    good=COLOR_TOKENS_DARK.good,
    warn=COLOR_TOKENS_DARK.warn,
    error=COLOR_TOKENS_DARK.error,
    surface_bg="#080604",  # Transcript — deep warm black
    surface_fg="#f0e4d0",  # Warm cream text
    surface_alt_bg="#2c2014",  # Selected/hover — warm brown
    surface_alt_fg="#f8f0dc",
    surface_meta_bg="#181410",  # Meta surfaces — warm
    surface_meta_fg="#a89070",
    surface_meta_alt_bg="#2c2014",
    surface_meta_alt_fg="#d4c4a4",
    scrollbar_bg="#1c1810",
    scrollbar_button="#604828",
    search_bg="#402c18",
    search_fg="#f8f0dc",
    selection_bg="#382818",
    selection_fg="#f8f0dc",
    cursor_line_bg="#0c0a06",
    cursor_column_bg="#0e0c08",
    bracket_bg="#402c18",
    bracket_fg="#f8f0dc",
    input_bg="#1a1410",  # Input — lighter warm brown, contrasts with transcript
    input_fg="#f0e4d0",  # Warm cream input text
    menu_bg="#282014",  # Completion popup — elevated, distinct from transcript
    menu_fg="#f0e4d0",  # Warm cream
    menu_alt_bg="#3c2c18",  # Selected item — amber highlight
    menu_alt_fg="#fcf4e4",  # Bright cream
    menu_meta_fg="#a89070",  # Meta/description text
)

_TOKENS_LIGHT: Final[_TuiTokens] = _TuiTokens(
    # Zone backgrounds — warm amber hierarchy
    toolbar_bg="#e8dcc8",  # Status chrome — warm tan
    toolbar_fg="#2c2014",  # Dark warm text
    dim="#907860",  # Placeholder/muted — amber-brown
    brand="#b45c08",  # Rich amber signature
    phase="#944c08",
    model="#1c1408",
    key="#a45010",  # Rich amber labels
    value="#2c2014",
    sep="#c8b8a4",  # Visible separator — warm
    good=COLOR_TOKENS_LIGHT.good,
    warn=COLOR_TOKENS_LIGHT.warn,
    error=COLOR_TOKENS_LIGHT.error,
    surface_bg="#fcfaf4",  # Transcript — warm white
    surface_fg="#181008",  # Near black text
    surface_alt_bg="#dcccc0",  # Selected/hover — warm
    surface_alt_fg="#140c04",
    surface_meta_bg="#f4ecd8",  # Meta surfaces — warm
    surface_meta_fg="#584838",  # Medium warm brown
    surface_meta_alt_bg="#d8c8b8",
    surface_meta_alt_fg="#241810",
    scrollbar_bg="#e4d4c4",
    scrollbar_button="#685848",
    search_bg="#e0ccc0",
    search_fg="#181008",
    selection_bg="#d0c0b0",
    selection_fg="#140c04",
    cursor_line_bg="#fefcf8",
    cursor_column_bg="#fcf8f0",
    bracket_bg="#e0ccc0",
    bracket_fg="#181008",
    input_bg="#ffffff",  # Input — pure white, focused
    input_fg="#181008",  # Dark warm text
    menu_bg="#f0e4d4",  # Completion popup — warm tan, distinct from transcript
    menu_fg="#181008",  # Dark text
    menu_alt_bg="#dcc8b8",  # Selected item — warm highlight
    menu_alt_fg="#100804",  # Near black
    menu_meta_fg="#685848",  # Meta/description text
)


def _style_for_tokens(tokens: _TuiTokens) -> BaseStyle:
    dim_style = tokens.dim  # Just color, no 'dim' class (breaks light theme contrast)
    overrides = Style.from_dict(
        {
            # Default style — fills any unstyled areas with content zone bg
            "": f"bg:{tokens.surface_bg} {tokens.surface_fg}",
            # prompt_toolkit container classes (opaque backgrounds, override "reverse")
            "bottom-toolbar": f"noreverse bg:{tokens.toolbar_bg} {tokens.toolbar_fg}",
            "bottom-toolbar.text": (
                f"noreverse bg:{tokens.toolbar_bg} {tokens.toolbar_fg}"
            ),
            # input buffer area (elevated background + explicit text color)
            "input-area": f"bg:{tokens.input_bg} {tokens.input_fg}",
            "prompt": tokens.brand,
            "prompt.spacer": f"bg:{tokens.input_bg}",
            # prompt fragments
            "prompt.chevron": f"bold {tokens.brand}",
            "placeholder": f"italic {tokens.dim}",
            "placeholder.warn": f"italic bold {tokens.warn}",
            # toolbar fragments — inherit bg from parent (transcript/surface_bg)
            "toolbar.agent": f"bold {tokens.value}",
            "toolbar.model": f"bold {tokens.model}",
            "toolbar.sep": tokens.sep,
            "toolbar.key": f"bold {tokens.key}",
            "toolbar.value": tokens.value,
            "toolbar.pad": dim_style,
            "toolbar.dim": dim_style,
            "toolbar.phase": f"bold {tokens.phase}",
            "toolbar.good": f"bold {tokens.good}",
            "toolbar.warn": f"bold {tokens.warn}",
            "toolbar.auto": f"bold {tokens.error}",
            # transcript
            "transcript": f"bg:{tokens.surface_bg}",
            "transcript.user": f"bold {tokens.key}",
            "transcript.assistant": tokens.surface_fg,
            "transcript.system": dim_style,
            "transcript.label": f"bold {tokens.key}",
            "transcript.meta": dim_style,
            "transcript.separator": dim_style,
            "transcript.diff.add": f"bold {tokens.good}",
            "transcript.diff.remove": f"bold {tokens.error}",
            "transcript.diff.hunk": f"bold {tokens.warn}",
            "transcript.diff.header": dim_style,
            "transcript.diff.context": dim_style,
            # completion menu — elevated popup surface
            "completion-menu": f"bg:{tokens.menu_bg} {tokens.menu_fg}",
            "completion-menu.completion": f"bg:{tokens.menu_bg} {tokens.menu_fg}",
            "completion-menu.completion.current": (
                f"bg:{tokens.menu_alt_bg} {tokens.menu_alt_fg} bold"
            ),
            "completion-menu.meta.completion": (
                f"bg:{tokens.menu_bg} {tokens.menu_meta_fg}"
            ),
            "completion-menu.meta.completion.current": (
                f"bg:{tokens.menu_alt_bg} {tokens.menu_alt_fg} bold"
            ),
            # modal overlays
            "modal": f"bg:{tokens.surface_meta_bg} {tokens.surface_meta_fg}",
            "modal.title": f"bold {tokens.brand}",
            "modal.border": tokens.sep,
            "modal.warn": f"bold {tokens.warn}",
            "modal.key": f"bold {tokens.key}",
            "modal.dim": dim_style,
            # activity indicator line (above input box, transcript background)
            "indicator": f"bg:{tokens.surface_bg}",
            "indicator.idle": f"bg:{tokens.surface_bg} {dim_style}",
            "indicator.active": f"bg:{tokens.surface_bg} bold {tokens.phase}",
            "indicator.pulse": f"bg:{tokens.surface_bg}",  # fg color set dynamically
            "indicator.hint": f"bg:{tokens.surface_bg} {dim_style}",
            # search + selection
            "search": f"bg:{tokens.search_bg} {tokens.search_fg}",
            "search.current": f"bg:{tokens.search_bg} {tokens.search_fg} bold",
            "incsearch": f"bg:{tokens.search_bg} {tokens.search_fg}",
            "incsearch.current": f"bg:{tokens.search_bg} {tokens.search_fg} bold",
            "selected": f"bg:{tokens.selection_bg} {tokens.selection_fg}",
            # cursor + brackets
            "cursor-line": f"bg:{tokens.cursor_line_bg}",
            "cursor-column": f"bg:{tokens.cursor_column_bg}",
            "matching-bracket": f"bg:{tokens.bracket_bg} {tokens.bracket_fg}",
            "matching-bracket.other": f"bg:{tokens.bracket_bg} {tokens.bracket_fg}",
            "matching-bracket.cursor": (
                f"bg:{tokens.bracket_bg} {tokens.bracket_fg} bold"
            ),
            # scrollbars
            "scrollbar.background": f"bg:{tokens.scrollbar_bg}",
            "scrollbar.button": f"bg:{tokens.scrollbar_button}",
            "scrollbar.arrow": f"{tokens.surface_fg} bold",
            # suggestions + whitespace
            "auto-suggestion": dim_style,
            "line-number": dim_style,
            "line-number.current": f"bold {tokens.key}",
            "trailing-whitespace": dim_style,
            "tab": dim_style,
        },
    )
    return merge_styles([default_ui_style(), overrides])


_STYLE_DARK: Final[BaseStyle] = _style_for_tokens(_TOKENS_DARK)
_STYLE_LIGHT: Final[BaseStyle] = _style_for_tokens(_TOKENS_LIGHT)


def tui_style_for_theme(theme: ReplTheme) -> BaseStyle:
    """Return the prompt-toolkit style used by the TUI for a theme."""
    return _STYLE_LIGHT if theme == "light" else _STYLE_DARK


__all__ = ("tui_style_for_theme",)
