"""SSE event type to display hint mapping for the activity indicator.

Maps full OpenAI Responses API streaming event types to compact hints
for display in the activity indicator line.
"""

from __future__ import annotations

# Complete mapping from full event type to compact hint
_EVENT_HINTS: dict[str, str] = {
    # Lifecycle events
    "response.queued": "queued",
    "response.created": "created",
    "response.in_progress": "in_progress",
    "response.completed": "completed",
    "response.incomplete": "incomplete",
    "response.failed": "failed",
    "response.error": "error",
    # Output structure events
    "response.output_item.added": "item+",
    "response.output_item.done": "item✓",
    "response.content_part.added": "part+",
    "response.content_part.done": "part✓",
    # Text output events
    "response.output_text.delta": "txt.δ",
    "response.output_text.done": "txt✓",
    "response.output_text.annotation.added": "annot+",
    # Reasoning events (o-series models)
    "response.reasoning.text.delta": "rsn.δ",
    "response.reasoning.text.done": "rsn✓",
    "response.reasoning_summary.part.added": "sum+",
    "response.reasoning_summary.part.done": "sum✓",
    "response.reasoning_summary.text.delta": "sum.δ",
    "response.reasoning_summary.text.done": "sum✓",
    # Function/tool call events
    "response.function_call_arguments.delta": "fn.δ",
    "response.function_call_arguments.done": "fn✓",
    "response.custom_tool_call_input.delta": "tool.δ",
    "response.custom_tool_call_input.done": "tool✓",
    # Web search events
    "response.web_search_call.in_progress": "web…",
    "response.web_search_call.searching": "web🔍",
    "response.web_search_call.completed": "web✓",
    # File search events
    "response.file_search_call.in_progress": "file…",
    "response.file_search_call.searching": "file🔍",
    "response.file_search_call.completed": "file✓",
    # Code interpreter events
    "response.code_interpreter_call.in_progress": "code…",
    "response.code_interpreter_call.interpreting": "code⚙",
    "response.code_interpreter_call.code.delta": "code.δ",
    "response.code_interpreter_call.code.done": "code✓",
    "response.code_interpreter_call.completed": "exec✓",
    # Image generation events
    "response.image_gen_call.in_progress": "img…",
    "response.image_gen_call.generating": "img⚙",
    "response.image_gen_call.partial_image": "img◐",
    "response.image_gen_call.completed": "img✓",
    # MCP (Model Context Protocol) events
    "response.mcp_list_tools.in_progress": "mcp…",
    "response.mcp_list_tools.completed": "mcp✓",
    "response.mcp_list_tools.failed": "mcp✗",
    "response.mcp_call.in_progress": "mcp…",
    "response.mcp_call.arguments.delta": "mcp.δ",
    "response.mcp_call.arguments.done": "mcp.args",
    "response.mcp_call.completed": "mcp✓",
    "response.mcp_call.failed": "mcp✗",
    # Audio events
    "response.audio.delta": "aud.δ",
    "response.audio.done": "aud✓",
    "response.audio_transcript.delta": "trs.δ",
    "response.audio_transcript.done": "trs✓",
    # Refusal events
    "response.refusal.delta": "ref.δ",
    "response.refusal.done": "ref✓",
}


def event_type_to_hint(event_type: str) -> str:
    """Convert full SSE event type to compact display hint.

    Args:
        event_type: Full event type string, e.g., "response.output_text.delta"

    Returns:
        Compact hint for display, e.g., "txt.δ"

    """
    if event_type in _EVENT_HINTS:
        return _EVENT_HINTS[event_type]
    # Fallback: extract last segment for unknown event types
    return event_type.rsplit(".", 1)[-1] if event_type else ""


__all__ = ("event_type_to_hint",)
