"""Tool-specific output line builders for transcript rendering."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_int, as_json_object, as_str
from agenterm.ui.tool_events import BoundedLineWriter, shorten_line

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue
    from agenterm.ui.transcript.model import TranscriptPolicy


def _append_kv(
    writer: BoundedLineWriter,
    *,
    key: str,
    value: str,
    max_chars: int,
) -> None:
    line = f"- {key}: {shorten_line(value, limit=max_chars)}"
    writer.append(line)


def _append_page(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> None:
    page_obj = as_json_object(payload.get("page"))
    if page_obj is None or page_obj.get("has_more") is not True:
        return
    writer.append("- has_more: true")
    next_cursor = as_int(page_obj.get("next_cursor"))
    if next_cursor is not None:
        _append_kv(
            writer,
            key="next_cursor",
            value=str(next_cursor),
            max_chars=policy.tool_detail_max_chars,
        )


def _page_returned(payload: Mapping[str, JSONValue]) -> int | None:
    page_obj = as_json_object(payload.get("page"))
    if page_obj is None:
        return None
    return as_int(page_obj.get("returned"))


def fd_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for fd outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    pattern = as_str(payload.get("pattern"))
    if pattern:
        _append_kv(
            writer,
            key="pattern",
            value=pattern,
            max_chars=policy.tool_detail_max_chars,
        )
    matches = payload.get("matches")
    if isinstance(matches, list):
        _append_kv(
            writer,
            key="matches",
            value=str(len(matches)),
            max_chars=policy.tool_detail_max_chars,
        )
    _append_page(writer, payload, policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def bat_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for bat outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    path = as_str(payload.get("path"))
    if path:
        _append_kv(
            writer,
            key="path",
            value=path,
            max_chars=policy.tool_detail_max_chars,
        )
    line_count = _page_returned(payload)
    if line_count is not None:
        _append_kv(
            writer,
            key="lines",
            value=str(line_count),
            max_chars=policy.tool_detail_max_chars,
        )
    bytes_read = as_int(payload.get("bytes"))
    if bytes_read is not None:
        _append_kv(
            writer,
            key="bytes",
            value=str(bytes_read),
            max_chars=policy.tool_detail_max_chars,
        )
    total_lines = as_int(payload.get("total_lines"))
    if total_lines is not None:
        _append_kv(
            writer,
            key="total_lines",
            value=str(total_lines),
            max_chars=policy.tool_detail_max_chars,
        )
    _append_page(writer, payload, policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def tree_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for tree outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    root = as_str(payload.get("root"))
    if root:
        _append_kv(
            writer,
            key="root",
            value=root,
            max_chars=policy.tool_detail_max_chars,
        )
    stats_obj = payload.get("stats")
    if isinstance(stats_obj, Mapping):
        dirs = as_int(stats_obj.get("directories"))
        files = as_int(stats_obj.get("files"))
        if dirs is not None or files is not None:
            parts: list[str] = []
            if dirs is not None:
                parts.append(f"dirs={dirs}")
            if files is not None:
                parts.append(f"files={files}")
            _append_kv(
                writer,
                key="stats",
                value=", ".join(parts),
                max_chars=policy.tool_detail_max_chars,
            )
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def stat_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for stat outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    results = payload.get("results")
    if isinstance(results, list):
        _append_kv(
            writer,
            key="results",
            value=str(len(results)),
            max_chars=policy.tool_detail_max_chars,
        )
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _append_first_match(
    writer: BoundedLineWriter,
    first: Mapping[str, JSONValue],
    *,
    max_chars: int,
) -> None:
    path = as_str(first.get("path"))
    line_no = as_int(first.get("line"))
    col = as_int(first.get("column"))
    text = as_str(first.get("text")) or ""
    if not path or line_no is None:
        return
    loc = f"{path}:{line_no}"
    if col is not None:
        loc = f"{loc}:{col}"
    preview = shorten_line(text, limit=max_chars)
    writer.append(f"- first: {loc} {preview}")


def rg_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for rg outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    pattern = as_str(payload.get("pattern"))
    if pattern:
        _append_kv(
            writer,
            key="pattern",
            value=pattern,
            max_chars=policy.tool_detail_max_chars,
        )
    matches = payload.get("matches")
    if isinstance(matches, list):
        _append_kv(
            writer,
            key="matches",
            value=str(len(matches)),
            max_chars=policy.tool_detail_max_chars,
        )
        if matches and isinstance(matches[0], Mapping):
            _append_first_match(
                writer,
                matches[0],
                max_chars=policy.tool_detail_max_chars,
            )
    counts = payload.get("counts")
    if isinstance(counts, list):
        _append_kv(
            writer,
            key="counts",
            value=str(len(counts)),
            max_chars=policy.tool_detail_max_chars,
        )
    files = payload.get("files")
    if isinstance(files, list):
        _append_kv(
            writer,
            key="files",
            value=str(len(files)),
            max_chars=policy.tool_detail_max_chars,
        )
    count_total = as_int(payload.get("count_total"))
    if count_total is not None:
        _append_kv(
            writer,
            key="count_total",
            value=str(count_total),
            max_chars=policy.tool_detail_max_chars,
        )
    coverage = as_json_object(payload.get("coverage"))
    if coverage is not None:
        files_searched = as_int(coverage.get("files_searched"))
        if files_searched is not None:
            _append_kv(
                writer,
                key="files_searched",
                value=str(files_searched),
                max_chars=policy.tool_detail_max_chars,
            )
        files_matched = as_int(coverage.get("files_matched"))
        if files_matched is not None:
            _append_kv(
                writer,
                key="files_matched",
                value=str(files_matched),
                max_chars=policy.tool_detail_max_chars,
            )
    _append_page(writer, payload, policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def agent_run_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript summary lines for agent_run outputs."""
    writer = BoundedLineWriter(
        max_lines=max(0, int(policy.tool_output_max_lines)),
        lines=[],
    )
    _append_agent_run_summary(writer, payload, policy)
    _append_agent_run_ids(writer, payload, policy)
    _append_agent_run_warning(writer, payload, policy)
    _append_agent_run_tool_counts(writer, payload, policy)
    _append_agent_run_truncated(writer, payload)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _append_agent_run_summary(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> None:
    summary = as_str(payload.get("summary")) or ""
    if not summary:
        return
    first_line = summary.splitlines()[0]
    _append_kv(
        writer,
        key="summary",
        value=first_line,
        max_chars=policy.tool_detail_max_chars,
    )


def _append_agent_run_ids(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> None:
    report_id = as_str(payload.get("report_id"))
    if report_id:
        _append_kv(
            writer,
            key="report_id",
            value=report_id,
            max_chars=policy.tool_detail_max_chars,
        )
    response_id = as_str(payload.get("response_id"))
    if response_id:
        _append_kv(
            writer,
            key="response_id",
            value=response_id,
            max_chars=policy.tool_detail_max_chars,
        )


def _append_agent_run_warning(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> None:
    warnings = payload.get("warnings")
    if not isinstance(warnings, list) or not warnings:
        return
    first = warnings[0]
    if not isinstance(first, str) or not first:
        return
    _append_kv(
        writer,
        key="warning",
        value=first,
        max_chars=policy.tool_detail_max_chars,
    )


def _tool_counts_text(payload: Mapping[str, JSONValue]) -> str | None:
    tool_counts = payload.get("tool_counts")
    tool_counts_map = as_json_object(tool_counts) if tool_counts is not None else None
    if tool_counts_map is None:
        return None
    parts: list[str] = []
    for name, count in tool_counts_map.items():
        if not isinstance(count, int) or isinstance(count, bool):
            continue
        parts.append(f"{name} x{count}" if count > 1 else name)
    if not parts:
        return None
    return ", ".join(parts)


def _append_agent_run_tool_counts(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> None:
    tool_text = _tool_counts_text(payload)
    if tool_text is None:
        return
    _append_kv(
        writer,
        key="tools",
        value=tool_text,
        max_chars=policy.tool_detail_max_chars,
    )


def _append_agent_run_truncated(
    writer: BoundedLineWriter,
    payload: Mapping[str, JSONValue],
) -> None:
    if payload.get("truncated") is True:
        writer.append("- tool_outputs_truncated: true")


__all__ = (
    "agent_run_lines",
    "bat_lines",
    "fd_lines",
    "rg_lines",
    "stat_lines",
    "tree_lines",
)
