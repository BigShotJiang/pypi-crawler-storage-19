"""Diff formatting helpers shared across transcript renderers."""

from __future__ import annotations

import re
from typing import Literal

DIFF_HINT_LINE = "view full diff: /last diff full"

DiffLineKind = Literal["add", "remove", "hunk", "header", "context"]

_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
_DIFF_FILE_HEADERS: tuple[str, ...] = ("+++", "---")
_MAX_LINE_NUMBER_PARTS = 2
_PREFIX_RULES: dict[str, tuple[int, int]] = {
    "+": (0, 1),
    "-": (1, 0),
    " ": (1, 1),
}


def _parse_hunk_header(line: str) -> tuple[int, int] | None:
    if not line.startswith("@@"):
        return None
    match = _HUNK_RE.match(line)
    if match is None:
        return None
    return int(match.group(1)), int(match.group(3))


def _prefix_rule(line: str) -> tuple[int, int] | None:
    return _PREFIX_RULES.get(line[:1])


def _scan_diff_line_numbers(lines: list[str]) -> tuple[int, int]:
    max_old = 0
    max_new = 0
    old_line: int | None = None
    new_line: int | None = None
    for line in lines:
        hunk = _parse_hunk_header(line)
        if hunk is not None:
            old_line, new_line = hunk
            max_old = max(max_old, old_line)
            max_new = max(max_new, new_line)
            continue
        if line.startswith(_DIFF_FILE_HEADERS):
            continue
        rule = _prefix_rule(line)
        if rule is None:
            continue
        delta_old, delta_new = rule
        if delta_old and old_line is not None:
            max_old = max(max_old, old_line)
            old_line += delta_old
        if delta_new and new_line is not None:
            max_new = max(max_new, new_line)
            new_line += delta_new
    return max_old, max_new


def _apply_prefix_line(
    line: str,
    *,
    old_line: int | None,
    new_line: int | None,
) -> tuple[int | None, int | None, str, str]:
    rule = _prefix_rule(line)
    if rule is None:
        return old_line, new_line, "", ""
    delta_old, delta_new = rule
    old_num = str(old_line) if delta_old and old_line is not None else ""
    new_num = str(new_line) if delta_new and new_line is not None else ""
    if delta_old and old_line is not None:
        old_line += delta_old
    if delta_new and new_line is not None:
        new_line += delta_new
    return old_line, new_line, old_num, new_num


def format_unified_diff_lines(diff: str) -> list[str]:
    """Return unified diff lines prefixed with old/new line numbers."""
    raw = diff.strip("\n")
    if not raw:
        return []
    lines = raw.splitlines()
    max_old, max_new = _scan_diff_line_numbers(lines)
    width = max(len(str(max_old)), len(str(max_new)), 1)
    old_line: int | None = None
    new_line: int | None = None
    out: list[str] = []
    for line in lines:
        old_num = ""
        new_num = ""
        hunk = _parse_hunk_header(line)
        if hunk is not None:
            old_line, new_line = hunk
        elif line.startswith(_DIFF_FILE_HEADERS):
            pass
        else:
            old_line, new_line, old_num, new_num = _apply_prefix_line(
                line,
                old_line=old_line,
                new_line=new_line,
            )
        prefix = f"{old_num:>{width}} {new_num:>{width}} | "
        out.append(f"{prefix}{line}")
    return out


def parse_numbered_diff_line(line: str) -> tuple[str, str, DiffLineKind] | None:
    """Return (prefix, content, kind) when the line matches numbered diff format."""
    left, sep, content = line.partition(" | ")
    if not sep:
        return None
    if not left:
        return None
    if any(ch not in " 0123456789" for ch in left):
        return None
    stripped = left.strip()
    if stripped:
        parts = stripped.split()
        if len(parts) > _MAX_LINE_NUMBER_PARTS or any(
            not part.isdigit() for part in parts
        ):
            return None
    kind = classify_diff_content(content)
    return f"{left} | ", content, kind


def classify_diff_content(content: str) -> DiffLineKind:
    """Classify a unified diff line content into a diff kind."""
    if content.startswith(_DIFF_FILE_HEADERS):
        return "header"
    if content.startswith("@@"):
        return "hunk"
    if content.startswith("+"):
        return "add"
    if content.startswith("-"):
        return "remove"
    return "context"


__all__ = (
    "DIFF_HINT_LINE",
    "DiffLineKind",
    "classify_diff_content",
    "format_unified_diff_lines",
    "parse_numbered_diff_line",
)
