"""Transcript rendering helpers for streamed run items.

This package turns streamed agent run items into a bounded, readable transcript.
It is intentionally UI-only: it does not affect engine/session semantics.
"""

from __future__ import annotations

from agenterm.ui.transcript.model import TranscriptPolicy

__all__ = ("TranscriptPolicy",)
