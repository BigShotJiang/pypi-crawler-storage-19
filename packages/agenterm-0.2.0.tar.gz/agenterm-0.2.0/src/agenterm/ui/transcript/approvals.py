"""Approval transcript block builders for REPL tool approvals."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.ui.tool_events import (
    BoundedLineWriter,
    approval_event_type,
    approval_label,
    shorten_line,
)
from agenterm.ui.transcript.diffs import format_unified_diff_lines

if TYPE_CHECKING:
    from agenterm.core.approvals import (
        CompressionApprovalItem,
        McpApprovalItem,
        PatchApprovalItem,
        ShellApprovalItem,
    )
    from agenterm.core.approvals_audit import ApprovalDecision
    from agenterm.ui.transcript.model import TranscriptPolicy


@dataclass(frozen=True)
class ApprovalTranscriptBlock:
    """Typed transcript payload for an approval event."""

    event_type: str
    label: str
    success: bool | None
    detail_lines: tuple[str, ...]


def _writer(policy: TranscriptPolicy) -> BoundedLineWriter:
    return BoundedLineWriter(
        max_lines=policy.tool_detail_max_lines,
        lines=[],
    )


def _append_reason(
    writer: BoundedLineWriter,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> None:
    if decision is None or decision.approved:
        return
    reason = decision.reason or ""
    if not reason:
        return
    writer.append(
        f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
    )


def _shell_detail_lines(
    item: ShellApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    writer = _writer(policy)
    writer.append(f"- id: {item.id}")
    if item.description:
        description = shorten_line(
            item.description,
            limit=policy.tool_detail_max_chars,
        )
        writer.append(f"- description: {description}")
    if item.cwd:
        writer.append(f"- cwd: {item.cwd}")
    if item.commands:
        writer.append("- commands:")
        for cmd in item.commands:
            if not writer.append(
                f"  {shorten_line(cmd, limit=policy.tool_detail_max_chars)}",
            ):
                break
    _append_reason(writer, decision=decision, policy=policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _patch_detail_lines(
    item: PatchApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    lines: list[str] = [
        f"- id: {item.id}",
        f"- op: {item.operation_type}",
        f"- path: {item.path}",
    ]
    if item.description:
        description = shorten_line(
            item.description,
            limit=policy.tool_detail_max_chars,
        )
        lines.append(f"- description: {description}")
    if policy.verbosity == "quiet":
        if decision is None or decision.approved:
            return tuple(lines)
        reason = decision.reason or ""
        if reason:
            lines.append(
                f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
            )
        return tuple(lines)
    if decision is None:
        diff = (item.diff or "").strip()
        if diff:
            lines.append("- diff:")
            lines.extend([f"  {line}" for line in format_unified_diff_lines(diff)])
        return tuple(lines)
    if decision.approved:
        return tuple(lines)
    reason = decision.reason or ""
    if reason:
        lines.append(
            f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
        )
    return tuple(lines)


def _mcp_detail_lines(
    item: McpApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    writer = _writer(policy)
    writer.append(f"- id: {item.id}")
    writer.append(f"- server: {item.server_label}")
    writer.append(f"- tool: {item.tool_name}")
    args = item.arguments_json or ""
    if args:
        writer.append("- args:")
        for line in args.splitlines():
            if not writer.append(
                f"  {shorten_line(line, limit=policy.tool_detail_max_chars)}",
            ):
                break
    _append_reason(writer, decision=decision, policy=policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _compress_detail_lines(
    item: CompressionApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    writer = _writer(policy)
    writer.append(f"- id: {item.id}")
    writer.append(f"- action: {item.action}")
    message = shorten_line(item.message, limit=policy.tool_detail_max_chars)
    writer.append(f"- message: {message}")
    _append_reason(writer, decision=decision, policy=policy)
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def build_shell_approval_block(
    item: ShellApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> ApprovalTranscriptBlock:
    """Return a bounded transcript block for a shell approval event."""
    event_type, success = approval_event_type(decision)
    return ApprovalTranscriptBlock(
        event_type=event_type,
        label=approval_label("shell"),
        success=success,
        detail_lines=_shell_detail_lines(item, decision=decision, policy=policy),
    )


def build_patch_approval_block(
    item: PatchApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> ApprovalTranscriptBlock:
    """Return a transcript block for an apply_patch approval event."""
    event_type, success = approval_event_type(decision)
    return ApprovalTranscriptBlock(
        event_type=event_type,
        label=approval_label("patch"),
        success=success,
        detail_lines=_patch_detail_lines(item, decision=decision, policy=policy),
    )


def build_mcp_approval_block(
    item: McpApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> ApprovalTranscriptBlock:
    """Return a bounded transcript block for an MCP approval event."""
    event_type, success = approval_event_type(decision)
    return ApprovalTranscriptBlock(
        event_type=event_type,
        label=approval_label("mcp"),
        success=success,
        detail_lines=_mcp_detail_lines(item, decision=decision, policy=policy),
    )


def build_compress_approval_block(
    item: CompressionApprovalItem,
    *,
    decision: ApprovalDecision | None,
    policy: TranscriptPolicy,
) -> ApprovalTranscriptBlock:
    """Return a bounded transcript block for a compression approval event."""
    event_type, success = approval_event_type(decision)
    return ApprovalTranscriptBlock(
        event_type=event_type,
        label=approval_label("compress"),
        success=success,
        detail_lines=_compress_detail_lines(item, decision=decision, policy=policy),
    )


__all__ = (
    "ApprovalTranscriptBlock",
    "build_compress_approval_block",
    "build_mcp_approval_block",
    "build_patch_approval_block",
    "build_shell_approval_block",
)
