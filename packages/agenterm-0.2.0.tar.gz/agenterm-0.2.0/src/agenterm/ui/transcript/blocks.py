"""Typed transcript blocks derived from streamed run items.

The transcript is the operator's truth surface. To keep it deterministic and
inspectable, we first map each `RunItem` into a typed block model (with bounded
detail lines) and only then render it to the console.

The REPL may additionally index extracted artifacts (e.g., apply_patch diffs)
from these blocks without re-parsing printed output.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agents.editor import ApplyPatchResult
from agents.items import (
    MCPApprovalRequestItem,
    MCPApprovalResponseItem,
    ReasoningItem,
    RunItem,
    ToolCallItem,
    ToolCallOutputItem,
)
from agents.tool import ShellResult
from openai.types.responses.response_apply_patch_tool_call import (
    OperationCreateFile,
    OperationUpdateFile,
    ResponseApplyPatchToolCall,
)
from openai.types.responses.response_file_search_tool_call import (
    ResponseFileSearchToolCall,
)
from openai.types.responses.response_function_shell_tool_call import (
    ResponseFunctionShellToolCall,
)
from openai.types.responses.response_function_tool_call import (
    ResponseFunctionToolCall,
)
from openai.types.responses.response_function_web_search import (
    ResponseFunctionWebSearch,
)
from openai.types.responses.response_output_item import (
    ImageGenerationCall,
    LocalShellCall,
    McpCall,
)

from agenterm.core.tool_output_envelope import (
    parse_function_tool_output_envelope,
    parse_mcp_tool_output_envelope,
)
from agenterm.ui.tool_events import (
    ToolOutputSummaryPolicy,
    label_for_tool_type,
    raw_item_type,
    shorten_line,
    tool_output_summary_lines,
)
from agenterm.ui.transcript.diffs import DIFF_HINT_LINE, format_unified_diff_lines
from agenterm.ui.transcript.mcp_failures import (
    mcp_call_failed,
    mcp_failure_detail_lines,
)
from agenterm.ui.transcript.search_details import (
    file_search_detail_lines,
    web_search_detail_lines,
)
from agenterm.ui.transcript.tool_output_envelope import (
    function_tool_envelope_lines,
    mcp_envelope_lines,
)

if TYPE_CHECKING:
    from openai.types.responses.response_apply_patch_tool_call import (
        OperationDeleteFile,
    )

    from agenterm.ui.transcript.model import TranscriptPolicy


@dataclass(frozen=True)
class ApplyPatchCallArtifact:
    """The last apply_patch tool call as a typed artifact.

    This captures the raw tool call operation and diff text so REPL commands
    can re-render it with different boundedness policies than the live transcript
    without re-parsing printed output.
    """

    op_type: str
    path: str
    diff: str | None


@dataclass(frozen=True)
class TranscriptArtifacts:
    """Typed artifacts extracted while building transcript blocks."""

    apply_patch_call: ApplyPatchCallArtifact | None = None


@dataclass(frozen=True)
class ReasoningBlock:
    """Transcript block for reasoning items (summary-only)."""

    kind: Literal["reasoning"]
    summary: str | None


@dataclass(frozen=True)
class ToolCallBlock:
    """Transcript block for tool call items."""

    kind: Literal["tool_call"]
    label: str
    detail_lines: tuple[str, ...]


@dataclass(frozen=True)
class ToolOutputBlock:
    """Transcript block for tool output items."""

    kind: Literal["tool_output"]
    label: str
    success: bool | None
    detail_lines: tuple[str, ...]


@dataclass(frozen=True)
class ImageArtifactBlock:
    """Transcript block for a generated image artifact."""

    kind: Literal["artifact_image"]
    artifact_id: str
    path: str
    mime: str
    size_bytes: int


type TranscriptBlock = (
    ReasoningBlock | ToolCallBlock | ToolOutputBlock | ImageArtifactBlock
)


@dataclass(frozen=True)
class TranscriptBuild:
    """Result of mapping one RunItem into a transcript block + extracted artifacts."""

    block: TranscriptBlock | None
    artifacts: TranscriptArtifacts


def _build_reasoning_summary(
    item: ReasoningItem,
    *,
    policy: TranscriptPolicy,
) -> str | None:
    summary_parts = item.raw_item.summary
    texts: list[str] = []
    for part in summary_parts:
        text = part.text
        if text:
            texts.append(text)
    summary = "\n".join(texts).strip()
    if not summary:
        return None
    limit = policy.reasoning_summary_max_chars
    if limit > 0 and len(summary) > limit:
        summary = f"{summary[: limit - 1]}…"
    return summary


def _apply_patch_artifact(call: ResponseApplyPatchToolCall) -> ApplyPatchCallArtifact:
    op = call.operation
    diff: str | None = None
    if isinstance(op, (OperationCreateFile, OperationUpdateFile)):
        diff = op.diff
    # OperationDeleteFile carries no diff (still a meaningful last operation).
    return ApplyPatchCallArtifact(op_type=op.type, path=op.path, diff=diff)


def _tool_output_lines(
    item: ToolCallOutputItem,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    summary_policy = ToolOutputSummaryPolicy(
        max_lines=policy.tool_output_max_lines,
        shell_preview_max_chars=policy.shell_preview_max_chars,
    )
    out = item.output
    if isinstance(out, (ShellResult, ApplyPatchResult)):
        include_excerpt = policy.diffs_mode != "off"
        return tool_output_summary_lines(
            out,
            policy=summary_policy,
            include_apply_patch_excerpt=include_excerpt,
        )
    return ()


def _apply_patch_call_detail_lines(
    call: ResponseApplyPatchToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    op: OperationCreateFile | OperationUpdateFile | OperationDeleteFile = call.operation
    lines: list[str] = [f"- op: {op.type}", f"- path: {op.path}"]
    if policy.verbosity == "quiet" or policy.diffs_mode == "off":
        return lines
    diff: str | None = None
    if isinstance(op, (OperationCreateFile, OperationUpdateFile)):
        diff = op.diff
    if not diff:
        return lines
    diff_lines = format_unified_diff_lines(diff)
    if not diff_lines:
        return lines
    lines.append("- diff:")
    lines.extend([f"  {line}" for line in diff_lines[: policy.tool_detail_max_lines]])
    if len(diff_lines) > policy.tool_detail_max_lines:
        lines.append("  …")
        lines.append(f"  {DIFF_HINT_LINE}")
    return lines


def _shell_call_detail_lines(
    call: ResponseFunctionShellToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    lines: list[str] = []
    cmds = list(call.action.commands or [])
    if cmds:
        lines.append("- commands:")
    lines.extend(
        [
            f"  {shorten_line(cmd, limit=policy.tool_detail_max_chars)}"
            for cmd in cmds[: policy.tool_detail_max_lines]
        ],
    )
    if len(cmds) > policy.tool_detail_max_lines:
        lines.append("  …")
    timeout = call.action.timeout_ms
    if timeout is not None:
        lines.append(f"- timeout_ms: {timeout}")
    max_out = call.action.max_output_length
    if max_out is not None:
        lines.append(f"- max_output_length: {max_out}")
    return lines


def _mcp_call_detail_lines(call: McpCall, *, policy: TranscriptPolicy) -> list[str]:
    lines: list[str] = [f"- server: {call.server_label}", f"- tool: {call.name}"]
    args = call.arguments or ""
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return lines


def _mcp_approval_request_detail_lines(
    item: MCPApprovalRequestItem,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    req = item.raw_item
    lines: list[str] = [
        f"- request_id: {req.id}",
        f"- server: {req.server_label}",
        f"- tool: {req.name}",
    ]
    args = req.arguments or ""
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return tuple(lines)


def _mcp_approval_response_block(
    item: MCPApprovalResponseItem,
    *,
    policy: TranscriptPolicy,
) -> ToolOutputBlock:
    raw = item.raw_item
    approval_request_id = raw.get("approval_request_id", "")
    approve_val = raw.get("approve", False)
    reason = raw.get("reason")
    lines: list[str] = [
        f"- request_id: {approval_request_id}",
        f"- approve: {approve_val}",
    ]
    if reason:
        lines.append(
            f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
        )
    return ToolOutputBlock(
        kind="tool_output",
        label="mcp approval",
        success=approve_val,
        detail_lines=tuple(lines),
    )


def _local_shell_call_detail_lines(
    call: LocalShellCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    lines: list[str] = []
    wd = call.action.working_directory
    if wd:
        lines.append(f"- cwd: {wd}")
    cmd_parts = list(call.action.command or [])
    if cmd_parts:
        joined = " ".join(cmd_parts)
        lines.append(
            f"- cmd: {shorten_line(joined, limit=policy.tool_detail_max_chars)}",
        )
    timeout = call.action.timeout_ms
    if timeout is not None:
        lines.append(f"- timeout_ms: {timeout}")
    return lines


def _image_generation_call_detail_lines(
    call: ImageGenerationCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    lines = [
        f"- status: {call.status}",
        f"- id: {shorten_line(call.id, limit=policy.tool_detail_max_chars)}",
    ]
    if isinstance(call.result, str) and call.result:
        lines.append(f"- result: (base64, {len(call.result)} chars)")
    return lines


def _tool_call_detail_lines(
    item: ToolCallItem,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    raw_obj = item.raw_item
    lines: tuple[str, ...] = ()
    if isinstance(raw_obj, ResponseApplyPatchToolCall):
        lines = tuple(_apply_patch_call_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, ResponseFunctionShellToolCall):
        lines = tuple(_shell_call_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, ResponseFileSearchToolCall):
        lines = tuple(file_search_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, ResponseFunctionWebSearch):
        lines = tuple(web_search_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, McpCall):
        lines = tuple(_mcp_call_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, ImageGenerationCall):
        lines = tuple(_image_generation_call_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, LocalShellCall):
        lines = tuple(_local_shell_call_detail_lines(raw_obj, policy=policy))
    return lines


def build_transcript_item(
    item: RunItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBuild:
    """Convert a RunItem to a typed transcript block (and extracted artifacts)."""
    artifacts = _build_transcript_artifacts(item)
    block = _build_transcript_block(item, policy=policy)
    return TranscriptBuild(block=block, artifacts=artifacts)


def _build_transcript_artifacts(item: RunItem) -> TranscriptArtifacts:
    if isinstance(item, ToolCallItem) and isinstance(
        item.raw_item,
        ResponseApplyPatchToolCall,
    ):
        return TranscriptArtifacts(
            apply_patch_call=_apply_patch_artifact(item.raw_item),
        )
    return TranscriptArtifacts()


def _build_tool_call_block(
    item: ToolCallItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBlock:
    raw = item.raw_item
    if isinstance(raw, ResponseFunctionToolCall):
        label = raw.name
    else:
        label = label_for_tool_type(raw_item_type(raw), is_output=False)
    details = _tool_call_detail_lines(item, policy=policy)
    return ToolCallBlock(kind="tool_call", label=label, detail_lines=details)


def _build_tool_output_block(
    item: ToolCallOutputItem,
    *,
    policy: TranscriptPolicy,
) -> ToolOutputBlock:
    label = label_for_tool_type(raw_item_type(item.raw_item), is_output=True)
    details = _tool_output_lines(item, policy=policy)
    success: bool | None = True
    out = item.output
    if isinstance(out, str):
        fn_env = parse_function_tool_output_envelope(out)
        if fn_env is not None:
            label = fn_env.tool
            success = fn_env.ok
            details = function_tool_envelope_lines(fn_env, policy=policy)
        else:
            mcp_env = parse_mcp_tool_output_envelope(out)
            if mcp_env is not None:
                label = "mcp"
                success = mcp_env.ok
                details = mcp_envelope_lines(mcp_env, policy=policy)
    return ToolOutputBlock(
        kind="tool_output",
        label=label,
        success=success,
        detail_lines=details,
    )


def _build_transcript_block(
    item: RunItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBlock | None:
    block: TranscriptBlock | None
    if isinstance(item, ReasoningItem):
        summary: str | None = None
        if policy.reasoning_mode != "off" and policy.verbosity != "quiet":
            summary = _build_reasoning_summary(item, policy=policy)
        block = ReasoningBlock(kind="reasoning", summary=summary)
    elif isinstance(item, MCPApprovalRequestItem):
        block = ToolCallBlock(
            kind="tool_call",
            label="mcp approval",
            detail_lines=_mcp_approval_request_detail_lines(item, policy=policy),
        )
    elif isinstance(item, MCPApprovalResponseItem):
        block = _mcp_approval_response_block(item, policy=policy)
    elif isinstance(item, ToolCallItem):
        raw = item.raw_item
        if isinstance(raw, McpCall) and mcp_call_failed(raw):
            block = ToolOutputBlock(
                kind="tool_output",
                label=label_for_tool_type(raw_item_type(raw), is_output=True),
                success=False,
                detail_lines=mcp_failure_detail_lines(raw, policy=policy),
            )
        else:
            block = _build_tool_call_block(item, policy=policy)
    elif isinstance(item, ToolCallOutputItem):
        block = _build_tool_output_block(item, policy=policy)
    else:
        block = None
    return block


__all__ = (
    "ApplyPatchCallArtifact",
    "ImageArtifactBlock",
    "ReasoningBlock",
    "ToolCallBlock",
    "ToolOutputBlock",
    "TranscriptArtifacts",
    "TranscriptBlock",
    "TranscriptBuild",
    "build_transcript_item",
)
