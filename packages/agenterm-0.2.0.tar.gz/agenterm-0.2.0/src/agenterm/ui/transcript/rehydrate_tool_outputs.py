"""Tool output rehydration helpers for transcripts."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_int, as_json_list, as_json_object, as_str
from agenterm.core.text import shorten_line
from agenterm.core.tool_output_envelope import (
    parse_function_tool_output_envelope,
    parse_mcp_tool_output_envelope,
)
from agenterm.ui.tool_events import BoundedLineWriter, label_for_tool_type
from agenterm.ui.transcript.blocks import ToolOutputBlock
from agenterm.ui.transcript.tool_output_envelope import (
    function_tool_envelope_lines,
    mcp_envelope_lines,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.json_types import JSONValue
    from agenterm.ui.transcript.model import TranscriptPolicy

TOOL_OUTPUT_TYPES: set[str] = {
    "apply_patch_call_output",
    "computer_call_output",
    "custom_tool_call_output",
    "file_search_call_output",
    "function_call_output",
    "local_shell_call_output",
    "mcp_approval_response",
    "shell_call_output",
    "web_search_call_output",
}


def _preview_output_line(
    output: str,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    preview = shorten_line(output, limit=policy.tool_detail_max_chars)
    if not preview:
        return ()
    return (f"- output: {preview}",)


def _shell_output_entry_lines(
    entry: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    outcome = as_json_object(entry.get("outcome"))
    status = "completed"
    exit_code: int | None = None
    if outcome is not None:
        outcome_type = as_str(outcome.get("type"))
        if outcome_type == "timeout":
            status = "timeout"
        elif outcome_type == "exit":
            exit_code = as_int(outcome.get("exit_code"))
    line = f"- status: {status}"
    if exit_code is not None:
        line += f" exit={exit_code}"
    preview = _shell_output_preview(entry, policy=policy)
    if preview:
        return (line, preview)
    return (line,)


def _shell_output_preview(
    entry: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> str | None:
    stdout = as_str(entry.get("stdout")) or ""
    stderr = as_str(entry.get("stderr")) or ""
    preview_source = stdout.strip() or stderr.strip()
    if not preview_source:
        return None
    first_line = preview_source.splitlines()[0]
    preview = shorten_line(first_line, limit=policy.tool_detail_max_chars)
    return f"  out: {preview}"


def _shell_call_output_lines(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    output_list = as_json_list(item.get("output"))
    if output_list is None:
        return ()
    writer = BoundedLineWriter(
        max_lines=policy.tool_output_max_lines,
        lines=[],
    )
    max_out = as_int(item.get("max_output_length"))
    if max_out is not None:
        writer.append(f"- max_output_length: {max_out}")
    for entry in output_list:
        if not isinstance(entry, Mapping):
            continue
        for line in _shell_output_entry_lines(entry, policy=policy):
            if not writer.append(line):
                break
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _apply_patch_output_lines(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    writer = BoundedLineWriter(
        max_lines=policy.tool_output_max_lines,
        lines=[],
    )
    status = as_str(item.get("status"))
    if status:
        writer.append(f"- status: {status}")
    output = as_str(item.get("output")) or ""
    if output:
        for line in output.splitlines():
            if not writer.append(
                shorten_line(line, limit=policy.tool_detail_max_chars),
            ):
                break
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _mcp_approval_response_lines(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    request_id = as_str(item.get("approval_request_id")) or "(request)"
    approve_raw = item.get("approve")
    approve_val = approve_raw if isinstance(approve_raw, bool) else False
    lines: list[str] = [
        f"- request_id: {request_id}",
        f"- approve: {approve_val}",
    ]
    reason = as_str(item.get("reason"))
    if reason:
        lines.append(
            f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
        )
    return tuple(lines)


def _computer_call_output_lines(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    output = as_json_object(item.get("output"))
    if output is None:
        return ()
    file_id = as_str(output.get("file_id"))
    image_url = as_str(output.get("image_url"))
    if file_id or image_url:
        detail = file_id or image_url or ""
        preview = shorten_line(detail, limit=policy.tool_detail_max_chars)
        return (f"- output: {preview}",)
    return ("- output: (screenshot)",)


@dataclass(frozen=True)
class _ToolOutputParts:
    label: str
    success: bool | None
    details: tuple[str, ...]


def _function_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    output = item.get("output")
    if isinstance(output, str):
        fn_env = parse_function_tool_output_envelope(output)
        if fn_env is not None:
            return _ToolOutputParts(
                label=fn_env.tool,
                success=fn_env.ok,
                details=function_tool_envelope_lines(fn_env, policy=policy),
            )
        mcp_env = parse_mcp_tool_output_envelope(output)
        if mcp_env is not None:
            return _ToolOutputParts(
                label="mcp",
                success=mcp_env.ok,
                details=mcp_envelope_lines(mcp_env, policy=policy),
            )
        return _ToolOutputParts(
            label=base_label,
            success=True,
            details=_preview_output_line(output, policy=policy),
        )
    if isinstance(output, list):
        return _ToolOutputParts(
            label=base_label,
            success=True,
            details=(f"- output_items: {len(output)}",),
        )
    return _ToolOutputParts(label=base_label, success=True, details=())


def _shell_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    return _ToolOutputParts(
        label=base_label,
        success=True,
        details=_shell_call_output_lines(item, policy=policy),
    )


def _apply_patch_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    status = as_str(item.get("status"))
    success: bool | None = True
    if status == "failed":
        success = False
    return _ToolOutputParts(
        label=base_label,
        success=success,
        details=_apply_patch_output_lines(item, policy=policy),
    )


def _mcp_approval_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    approve_raw = item.get("approve")
    success: bool | None = True
    if isinstance(approve_raw, bool):
        success = approve_raw
    return _ToolOutputParts(
        label=base_label,
        success=success,
        details=_mcp_approval_response_lines(item, policy=policy),
    )


def _computer_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    return _ToolOutputParts(
        label=base_label,
        success=True,
        details=_computer_call_output_lines(item, policy=policy),
    )


def _default_output_parts(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
    base_label: str,
) -> _ToolOutputParts:
    output = item.get("output")
    if isinstance(output, str):
        details = _preview_output_line(output, policy=policy)
    elif isinstance(output, list):
        details = (f"- output_items: {len(output)}",)
    else:
        details = ()
    return _ToolOutputParts(
        label=base_label,
        success=True,
        details=details,
    )


_OUTPUT_HANDLERS: dict[
    str,
    Callable[[Mapping[str, JSONValue], TranscriptPolicy, str], _ToolOutputParts],
] = {
    "function_call_output": _function_output_parts,
    "custom_tool_call_output": _function_output_parts,
    "local_shell_call_output": _function_output_parts,
    "shell_call_output": _shell_output_parts,
    "apply_patch_call_output": _apply_patch_output_parts,
    "mcp_approval_response": _mcp_approval_output_parts,
    "computer_call_output": _computer_output_parts,
}


def build_tool_output(
    item_type: str,
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> ToolOutputBlock:
    """Return a tool output block for a tool output input item."""
    base_label = label_for_tool_type(item_type, is_output=True)
    handler: Callable[
        [Mapping[str, JSONValue], TranscriptPolicy, str],
        _ToolOutputParts,
    ]
    handler = _OUTPUT_HANDLERS.get(item_type) or _default_output_parts
    parts = handler(item, policy, base_label)
    return ToolOutputBlock(
        kind="tool_output",
        label=parts.label,
        success=parts.success,
        detail_lines=parts.details,
    )


__all__ = ("TOOL_OUTPUT_TYPES", "build_tool_output")
