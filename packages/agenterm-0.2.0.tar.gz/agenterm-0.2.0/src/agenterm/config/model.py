"""Typed configuration model for agenterm (ARCH.md surface)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from agents.model_settings import ModelSettings, ToolChoice
from openai.types.shared import Reasoning

from agenterm.config.attachments import AttachmentsConfig
from agenterm.config.compression import CompressionConfig
from agenterm.config.mcp_models import McpBridgeConfig, McpExposeConfig
from agenterm.config.steward import StewardConfig
from agenterm.config.tool_bundles import (
    ToolBundleConfig,
    default_bundle_selection,
    default_bundles_map,
)
from agenterm.config.tool_models import (
    ApplyPatchToolConfig,
    FileSearchToolConfig,
    FunctionToolConfig,
    ImageGenerationToolConfig,
    ShellToolConfig,
    WebSearchToolConfig,
)
from agenterm.config.tools_policy import (
    AgentRunReportToolConfig,
    AgentRunToolConfig,
    BatToolConfig,
    DangerousToolsConfig,
    FdToolConfig,
    GetPlanToolConfig,
    RgToolConfig,
    StatToolConfig,
    TreeToolConfig,
    UpdatePlanToolConfig,
)
from agenterm.constants.defaults import DEFAULT_MODEL_ID
from agenterm.constants.display import (
    REPL_UI_MAX_TRANSCRIPT_ENTRIES_DEFAULT,
    TRANSCRIPT_ATTACHMENTS_MAX_LINES_DEFAULT,
    TRANSCRIPT_ATTACHMENTS_PATH_MAX_CHARS_DEFAULT,
    TRANSCRIPT_MCP_ARGS_PREVIEW_MAX_CHARS_DEFAULT,
    TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT,
    TRANSCRIPT_TOOL_DETAIL_MAX_CHARS_DEFAULT,
    TRANSCRIPT_TOOL_DETAIL_MAX_LINES_DEFAULT,
    TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT,
)
from agenterm.constants.include import DEFAULT_RESPONSE_INCLUDE
from agenterm.constants.limits import TOOL_OUTPUT_MAX_CHARS_DEFAULT
from agenterm.core.errors import ValidationError
from agenterm.core.model_id import (
    model_plane,
    openai_model_requires_reasoning,
    openai_model_supports_reasoning,
)

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agenterm.config.mcp_filters import McpAllowedTools, McpRequireApproval
    from agenterm.config.text_format import TextFormat
    from agenterm.core.choices.approvals import ApprovalMode
    from agenterm.core.choices.mcp import (
        EncodingErrorHandler,
        McpConnectorId,
        McpServerKind,
    )
    from agenterm.core.choices.model import (
        ModelTruncation,
        ModelVerbosity,
        PromptCacheRetention,
    )
    from agenterm.core.choices.repl import (
        ReplDiffsMode,
        ReplReasoningMode,
        ReplStreamMode,
        ReplVerbosity,
    )
    from agenterm.core.choices.repl_ui import (
        ReplColorDepth,
        ReplCompletionMode,
        ReplEditingMode,
        ReplTheme,
    )
    from agenterm.core.json_types import JSONValue


@dataclass(frozen=True)
class AgentConfig:
    """Top-level agent configuration (agent name, model, limits)."""

    name: str = "default"
    model: str = DEFAULT_MODEL_ID
    max_turns: int = 100
    instructions: str | None = field(default=None, metadata={"template": False})
    path: Path | None = field(default=None, metadata={"template": False})
    source: str | None = field(default=None, metadata={"template": False})
    explicit: bool = field(default=False, metadata={"template": False})


@dataclass(frozen=True)
class ModelConfig:
    """ModelSettings surface for Responses-based agents (file-format friendly)."""

    temperature: float | None = 1.0
    top_p: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    tool_choice: ToolChoice | None = "auto"
    parallel_tool_calls: bool | None = True
    truncation: ModelTruncation | None = "disabled"
    max_output_tokens: int | None = 32000
    reasoning: Reasoning | None = field(
        default_factory=lambda: Reasoning(effort="medium")
    )
    verbosity: ModelVerbosity | None = "medium"
    metadata: Mapping[str, str] | None = None
    # Structured output schema (mutually exclusive): text_format vs text_format_file.
    text_format: TextFormat | None = None
    text_format_file: Path | None = None
    store: bool = True
    context_window: int | None = None
    prompt_cache_retention: PromptCacheRetention | None = "24h"
    include_usage: bool | None = True
    top_logprobs: int | None = None
    extra_query: Mapping[str, JSONValue] | None = None
    extra_body: Mapping[str, JSONValue] | None = None
    extra_headers: Mapping[str, str] | None = None


@dataclass(frozen=True)
class OpenAIProviderConfig:
    """OpenAI endpoint overrides (API key is always sourced from env)."""

    base_url: str | None = None


@dataclass(frozen=True)
class GatewayRouteConfig:
    """LiteLLM gateway route definition."""

    provider: str
    base_url: str | None = None
    api_key_env: str | None = None
    headers: Mapping[str, str] | None = None
    model_allowlist: tuple[str, ...] = field(default_factory=tuple)
    allow_any_model: bool = False
    supports_compaction: bool = False
    supports_file_id: bool = False
    supports_image_url: bool = False
    allow_inline_data_url: bool = False


def _default_gateway_routes() -> dict[str, GatewayRouteConfig]:
    """Return default gateway route mapping."""
    return {}


@dataclass(frozen=True)
class GatewayProviderConfig:
    """Gateway provider routing config (route name -> route config)."""

    routes: Mapping[str, GatewayRouteConfig] = field(
        default_factory=_default_gateway_routes
    )


@dataclass(frozen=True)
class ProvidersConfig:
    """Provider selection config for OpenAI + gateway planes."""

    openai: OpenAIProviderConfig = field(default_factory=OpenAIProviderConfig)
    gateway: GatewayProviderConfig = field(default_factory=GatewayProviderConfig)


@dataclass(frozen=True)
class McpConnectorConfig:
    """Configuration for a provider-hosted MCP connector (Agents HostedMCPTool)."""

    name: str
    server_url: str | None = None
    authorization_env: str | None = None
    server_description: str | None = None
    connector_id: McpConnectorId | None = None
    headers: Mapping[str, str] | None = None
    allowed_tools: McpAllowedTools | None = None
    require_approval: McpRequireApproval | None = None


@dataclass(frozen=True)
class ToolsConfig:
    """Aggregate configuration for all tool families."""

    output_max_chars: int = TOOL_OUTPUT_MAX_CHARS_DEFAULT
    file_search: FileSearchToolConfig | None = field(
        default_factory=FileSearchToolConfig
    )
    web_search: WebSearchToolConfig | None = field(default_factory=WebSearchToolConfig)
    shell: ShellToolConfig | None = field(default_factory=ShellToolConfig)
    apply_patch: ApplyPatchToolConfig | None = field(
        default_factory=ApplyPatchToolConfig
    )
    update_plan: UpdatePlanToolConfig | None = field(
        default_factory=UpdatePlanToolConfig
    )
    get_plan: GetPlanToolConfig | None = field(default_factory=GetPlanToolConfig)
    rg: RgToolConfig | None = field(default_factory=RgToolConfig)
    fd: FdToolConfig | None = field(default_factory=FdToolConfig)
    bat: BatToolConfig | None = field(default_factory=BatToolConfig)
    tree: TreeToolConfig | None = field(default_factory=TreeToolConfig)
    stat: StatToolConfig | None = field(default_factory=StatToolConfig)
    agent_run: AgentRunToolConfig | None = field(default_factory=AgentRunToolConfig)
    agent_run_report: AgentRunReportToolConfig | None = field(
        default_factory=AgentRunReportToolConfig
    )
    image_generation: ImageGenerationToolConfig | None = field(
        default_factory=ImageGenerationToolConfig
    )
    function_tools: list[FunctionToolConfig] = field(default_factory=list)
    dangerous: DangerousToolsConfig = field(default_factory=DangerousToolsConfig)
    bundles: Mapping[str, ToolBundleConfig] = field(default_factory=default_bundles_map)
    default_bundles: list[str] = field(default_factory=default_bundle_selection)


@dataclass(frozen=True)
class McpServerStdioConfig:
    """Configuration for an MCP stdio server."""

    command: str
    args: list[str] = field(default_factory=list)
    env: Mapping[str, str] | None = None
    cwd: Path | None = None
    encoding: str = "utf-8"
    encoding_error_handler: EncodingErrorHandler = "strict"


@dataclass(frozen=True)
class McpServerSseConfig:
    """Configuration for an MCP SSE server."""

    url: str
    headers: Mapping[str, str] | None = None
    timeout: float | None = None
    sse_read_timeout: float | None = None


@dataclass(frozen=True)
class McpServerStreamableHttpConfig:
    """Configuration for an MCP streamable HTTP server."""

    url: str
    headers: Mapping[str, str] | None = None
    timeout: float | None = None
    sse_read_timeout: float | None = None
    terminate_on_close: bool | None = None
    httpx_client_factory_key: str | None = None


@dataclass(frozen=True)
class McpToolFilterConfig:
    """Server-level MCP tool filtering configuration."""

    allowed_tool_names: list[str] | None = None
    blocked_tool_names: list[str] | None = None
    callable_key: str | None = None


@dataclass(frozen=True)
class McpServerRuntimeConfig:
    """Runtime configuration common to all MCP server types."""

    cache_tools: bool = False  # Cache tools list to avoid list_tools round-trips.
    session_timeout: float | None = 5.0  # ClientSession timeout (null disables).


@dataclass(frozen=True)
class McpServerConfig:
    """One MCP server entry for Agents MCP servers."""

    key: str
    kind: McpServerKind
    name: str | None = None
    tool_filter: McpToolFilterConfig | None = None
    # Whether to use `tool_result.structured_content` for MCP tool results.
    # Defaults to False to avoid duplicate content.
    use_structured_content: bool = False
    message_handler_key: str | None = None
    stdio: McpServerStdioConfig | None = None
    sse: McpServerSseConfig | None = None
    streamable_http: McpServerStreamableHttpConfig | None = None
    runtime: McpServerRuntimeConfig = field(default_factory=McpServerRuntimeConfig)


@dataclass(frozen=True)
class McpConfig:
    """Top-level MCP configuration (server list)."""

    servers: list[McpServerConfig] = field(default_factory=list)
    connectors: list[McpConnectorConfig] = field(default_factory=list)
    convert_schemas_to_strict: bool = False
    bridge: McpBridgeConfig = field(default_factory=McpBridgeConfig)
    expose: McpExposeConfig = field(default_factory=McpExposeConfig)


@dataclass(frozen=True)
class RunDefaults:
    """Default per-run behavior for the CLI."""

    background: bool = False
    timeout_seconds: float | None = 600.0
    live: bool = False
    json_output: bool = False
    # Tracing fields; when set, they flow into RunConfig.
    trace_enabled: bool = True
    trace_id: str | None = None
    group_id: str | None = None
    trace_metadata: Mapping[str, str] | None = None
    trace_include_sensitive_data: bool = False


def _effective_reasoning_settings(
    *,
    model_id: str,
    reasoning: Reasoning | None,
) -> Reasoning | None:
    if reasoning is None:
        if model_plane(model_id) == "openai" and openai_model_requires_reasoning(
            model_id
        ):
            return Reasoning(effort="low")
        return None
    if model_plane(model_id) != "openai" or not openai_model_supports_reasoning(
        model_id
    ):
        msg = "model.reasoning is only supported for OpenAI GPT-5 models."
        raise ValidationError(msg)
    return reasoning


@dataclass(frozen=True)
class RetryPolicyConfig:
    """Unified retry policy for a single surface."""

    max_retries: int
    base_backoff_seconds: float
    max_backoff_seconds: float
    jitter_ratio: float
    retry_after_max_seconds: float | None = None


@dataclass(frozen=True)
class RetriesConfig:
    """Retry policies for provider, MCP, and store surfaces."""

    provider: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=10,
            base_backoff_seconds=0.5,
            max_backoff_seconds=8.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=60.0,
        ),
    )
    mcp: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=3,
            base_backoff_seconds=1.0,
            max_backoff_seconds=8.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=None,
        ),
    )
    store: RetryPolicyConfig = field(
        default_factory=lambda: RetryPolicyConfig(
            max_retries=5,
            base_backoff_seconds=0.05,
            max_backoff_seconds=1.0,
            jitter_ratio=0.25,
            retry_after_max_seconds=None,
        ),
    )


@dataclass(frozen=True)
class ReplApprovalsConfig:
    """Default approval policy for REPL sessions."""

    mode: ApprovalMode = "prompt"


@dataclass(frozen=True)
class ReplUxConfig:
    """Default UX controls for interactive REPL sessions."""

    markdown: bool = False
    reasoning: ReplReasoningMode = "summary"
    reasoning_summary_max_chars: int = 0
    diffs: ReplDiffsMode = "summary"
    stream: ReplStreamMode = "final"
    verbosity: ReplVerbosity = "normal"


@dataclass(frozen=True)
class ReplTranscriptConfig:
    """Transcript boundedness defaults for REPL/streamed output."""

    tool_output_max_lines: int = TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT
    shell_preview_max_chars: int = TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT
    tool_detail_max_lines: int = TRANSCRIPT_TOOL_DETAIL_MAX_LINES_DEFAULT
    tool_detail_max_chars: int = TRANSCRIPT_TOOL_DETAIL_MAX_CHARS_DEFAULT
    mcp_args_preview_max_chars: int = TRANSCRIPT_MCP_ARGS_PREVIEW_MAX_CHARS_DEFAULT
    attachments_max_lines: int = TRANSCRIPT_ATTACHMENTS_MAX_LINES_DEFAULT
    attachments_path_max_chars: int = TRANSCRIPT_ATTACHMENTS_PATH_MAX_CHARS_DEFAULT


@dataclass(frozen=True)
class ReplUiConfig:
    """Default prompt UI controls for interactive REPL sessions."""

    theme: ReplTheme = "dark"
    color_depth: ReplColorDepth = "auto"
    editing_mode: ReplEditingMode = "vi"
    mouse: bool = True
    completion: ReplCompletionMode = "full"
    max_transcript_entries: int = REPL_UI_MAX_TRANSCRIPT_ENTRIES_DEFAULT


@dataclass(frozen=True)
class ReplConfig:
    """REPL-only configuration (does not affect one-shot `run` outputs)."""

    approvals: ReplApprovalsConfig = field(default_factory=ReplApprovalsConfig)
    ux: ReplUxConfig = field(default_factory=ReplUxConfig)
    transcript: ReplTranscriptConfig = field(default_factory=ReplTranscriptConfig)
    ui: ReplUiConfig = field(default_factory=ReplUiConfig)


@dataclass(frozen=True)
class GuardrailsConfig:
    """Declarative selection of input/output guardrails for a run."""

    load_modules: list[str] = field(default_factory=list)
    input: list[str] = field(default_factory=list)
    output: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class AppConfig:
    """Root configuration object used by both CLI and engine."""

    agent: AgentConfig = field(default_factory=AgentConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    providers: ProvidersConfig = field(default_factory=ProvidersConfig)
    retries: RetriesConfig = field(default_factory=RetriesConfig)
    compression: CompressionConfig = field(default_factory=CompressionConfig)
    attachments: AttachmentsConfig = field(default_factory=AttachmentsConfig)
    tools: ToolsConfig = field(default_factory=ToolsConfig)
    mcp: McpConfig = field(default_factory=McpConfig)
    steward: StewardConfig = field(default_factory=StewardConfig)
    run: RunDefaults = field(default_factory=RunDefaults)
    repl: ReplConfig = field(default_factory=ReplConfig)
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)

    def to_model_settings(self) -> ModelSettings:
        """Convert ModelConfig into Agents ModelSettings (single mapping source)."""
        mc = self.model
        model_id = self.agent.model
        reasoning = _effective_reasoning_settings(
            model_id=model_id,
            reasoning=mc.reasoning,
        )
        return ModelSettings(
            temperature=mc.temperature,
            top_p=mc.top_p,
            frequency_penalty=mc.frequency_penalty,
            presence_penalty=mc.presence_penalty,
            tool_choice=mc.tool_choice,
            parallel_tool_calls=mc.parallel_tool_calls,
            truncation=mc.truncation,
            max_tokens=mc.max_output_tokens,
            reasoning=reasoning,
            verbosity=mc.verbosity,
            metadata=dict(mc.metadata) if mc.metadata is not None else None,
            store=mc.store,
            prompt_cache_retention=mc.prompt_cache_retention,
            include_usage=mc.include_usage,
            # response_include is fixed by agenterm; see constants.include.
            response_include=list(DEFAULT_RESPONSE_INCLUDE),
            top_logprobs=mc.top_logprobs,
            extra_query=dict(mc.extra_query) if mc.extra_query is not None else None,
            extra_body=dict(mc.extra_body) if mc.extra_body is not None else None,
            extra_headers=dict(mc.extra_headers)
            if mc.extra_headers is not None
            else None,
            extra_args=None,
        )
