"""Providers section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "============================================================",
        "PROVIDERS - OpenAI + gateway (LiteLLM in-process) settings",
        "============================================================",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "providers.openai": FieldDoc(
        inline="OpenAI settings (API key is always sourced from env)",
    ),
    "providers.openai.base_url": FieldDoc(
        inline=(
            "Optional OpenAI-compatible endpoint override (overrides OPENAI_BASE_URL)"
        ),
    ),
    "providers.gateway": FieldDoc(
        inline="Gateway routes (LiteLLM in-process; no external runtime)",
    ),
    "providers.gateway.routes": FieldDoc(
        before=(
            "Gateway route map (route name -> route config).",
            "Each route is referenced as gateway/<route>/<model>.",
            "Route names must be non-empty and must not contain '/'.",
            "When allow_any_model is false, model_allowlist must be non-empty.",
            "api_key_env names the env var with the key (no secrets in config).",
            "LiteLLM routes convert Responses inputs to Chat Completions:",
            "- input_image requires image_url (file_id rejected).",
            "- input_file requires file_data (file_url/file_id rejected).",
            "Capability flags (supports_compaction / supports_file_id / "
            "supports_image_url / allow_inline_data_url) gate compression and "
            "attachment handling.",
            "Example:",
            "routes:",
            "  openrouter:",
            "    provider: openrouter",
            "    api_key_env: OPENROUTER_API_KEY",
            "    base_url: null",
            "    headers: null",
            "    model_allowlist:",
            "      - google/gemini-3",
            "    allow_any_model: false",
            "    supports_compaction: false",
            "    supports_file_id: false",
            "    supports_image_url: true",
            "    allow_inline_data_url: false",
        ),
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
