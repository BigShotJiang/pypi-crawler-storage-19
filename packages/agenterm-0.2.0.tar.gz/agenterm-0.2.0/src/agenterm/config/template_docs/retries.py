"""Retries section docs for the config template."""

from __future__ import annotations

from agenterm.config.template_docs.base import FieldDoc, SectionDoc

SECTION_DOC = SectionDoc(
    lines=(
        "==============================================================================",
        "RETRIES - Unified retry policy (provider/MCP/store)",
        "==============================================================================",
        "SDK retries are disabled; agenterm owns the retry loop.",
    ),
)


FIELD_DOCS: dict[str, FieldDoc] = {
    "retries.provider": FieldDoc(
        before=("Provider retries (model calls: streamed/background/agent_run).",),
    ),
    "retries.provider.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.provider.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.provider.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.provider.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.provider.retry_after_max_seconds": FieldDoc(
        inline="Cap for Retry-After (null disables)",
    ),
    "retries.mcp": FieldDoc(
        before=("MCP retries (list_tools/call_tool).",),
    ),
    "retries.mcp.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.mcp.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.mcp.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.mcp.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.mcp.retry_after_max_seconds": FieldDoc(
        inline="Ignored for MCP (no Retry-After headers)",
    ),
    "retries.store": FieldDoc(
        before=("SQLite store retries (SQLITE_BUSY).",),
    ),
    "retries.store.max_retries": FieldDoc(
        inline="Non-negative; 0 disables retries",
    ),
    "retries.store.base_backoff_seconds": FieldDoc(
        inline="Base seconds for exponential backoff",
    ),
    "retries.store.max_backoff_seconds": FieldDoc(
        inline="Max seconds for exponential backoff",
    ),
    "retries.store.jitter_ratio": FieldDoc(
        inline="0.0-1.0; jitter applied as 1 - ratio * rand()",
    ),
    "retries.store.retry_after_max_seconds": FieldDoc(
        inline="Ignored for SQLite",
    ),
}


__all__ = ("FIELD_DOCS", "SECTION_DOC")
