"""Built-in tool bundle definitions for config defaults."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

ToolBundleScope = Literal["main", "delegate"]


@dataclass(frozen=True)
class ToolBundleConfig:
    """Tool bundle definition (composition + scope + selectors)."""

    bundles: list[str] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
    selectors: list[str] = field(default_factory=list)
    scope: ToolBundleScope = "main"


def default_bundles_map() -> dict[str, ToolBundleConfig]:
    """Return built-in tool bundle definitions."""
    return {
        "inspect": ToolBundleConfig(
            tools=[
                "fn:rg",
                "fn:fd",
                "fn:bat",
                "fn:tree",
                "fn:stat",
            ],
        ),
        "plan": ToolBundleConfig(
            tools=[
                "fn:update_plan",
                "fn:get_plan",
            ],
        ),
        "delegate": ToolBundleConfig(
            tools=[
                "fn:agent_run",
                "fn:agent_run_report",
            ],
        ),
        "steward": ToolBundleConfig(tools=["fn:steward"]),
        "edit": ToolBundleConfig(tools=["fn:apply_patch"]),
        "shell": ToolBundleConfig(tools=["fn:shell"]),
        "integrations": ToolBundleConfig(
            selectors=[
                "mcp:*",
                "hosted:mcp:*",
            ],
        ),
        "extensions": ToolBundleConfig(selectors=["fn:user:*"]),
        "research": ToolBundleConfig(
            tools=[
                "hosted:openai:web_search",
                "hosted:openai:file_search",
                "hosted:openai:image_generation",
            ],
            scope="delegate",
        ),
    }


def default_bundle_selection() -> list[str]:
    """Return bundle names enabled by default for new sessions."""
    return ["inspect", "plan", "delegate", "steward"]


__all__ = (
    "ToolBundleConfig",
    "ToolBundleScope",
    "default_bundle_selection",
    "default_bundles_map",
)
