"""Trace metadata normalization shared across run and REPL builders."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import MutableMapping


def parse_trace_metadata(
    trace_metadata: list[str] | None,
) -> MutableMapping[str, str] | None:
    """Convert trace metadata entries into a dict.

    Raises:
      ConfigError: If any entry is not in key=value form.

    """
    if not trace_metadata:
        return None
    meta: MutableMapping[str, str] = {}
    for raw in trace_metadata:
        if "=" not in raw:
            msg = f"Invalid trace metadata entry (expected key=value): {raw}"
            raise ConfigError(msg)
        key, value = raw.split("=", 1)
        key_str = key.strip()
        if not key_str:
            msg = f"Invalid trace metadata key in: {raw}"
            raise ConfigError(msg)
        meta[key_str] = value
    return meta


__all__ = ("parse_trace_metadata",)
