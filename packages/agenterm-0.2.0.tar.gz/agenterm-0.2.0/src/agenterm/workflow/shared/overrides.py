"""Apply CLI/runtime overrides onto an AppConfig.

Greenfield posture: CLI overrides are intentionally minimal and explicit.
All other behavior is configuration-driven.

Supported overrides:
- model selection (`--model`)
- tracing (`--trace` on|off or ID:GROUP:meta)
- store override (`--store` / `--no-store` / model.store)
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.config.editors import set_model, set_model_store
from agenterm.workflow.shared.trace import parse_trace_metadata

if TYPE_CHECKING:
    from typing import Protocol

    from agenterm.config.model import AppConfig

    class _ConfigInputs(Protocol):
        @property
        def model(self) -> str | None: ...

        @property
        def trace_enabled(self) -> bool | None: ...

        @property
        def trace_id(self) -> str | None: ...

        @property
        def trace_group(self) -> str | None: ...

        @property
        def trace_metadata(self) -> list[str] | None: ...

        @property
        def store_override(self) -> bool | None: ...


def _apply_model(cfg: AppConfig, model: str | None) -> AppConfig:
    return set_model(cfg, model) if model is not None else cfg


def _apply_trace(
    cfg: AppConfig,
    *,
    trace_enabled: bool | None,
    trace_id: str | None,
    trace_group: str | None,
    trace_metadata: list[str] | None,
) -> AppConfig:
    meta_dict = parse_trace_metadata(trace_metadata)
    run_cfg = cfg.run
    run_updated = replace(
        run_cfg,
        trace_enabled=(
            run_cfg.trace_enabled if trace_enabled is None else trace_enabled
        ),
        trace_id=trace_id if trace_id is not None else run_cfg.trace_id,
        group_id=trace_group if trace_group is not None else run_cfg.group_id,
        trace_metadata=meta_dict if meta_dict is not None else run_cfg.trace_metadata,
    )
    return replace(cfg, run=run_updated) if run_updated is not run_cfg else cfg


def _apply_store(cfg: AppConfig, *, store_override: bool | None) -> AppConfig:
    if store_override is None:
        return cfg
    return set_model_store(cfg, store=store_override)


def build_effective_config(
    base_cfg: AppConfig,
    overrides: _ConfigInputs,
) -> AppConfig:
    """Apply CLI overrides on top of a base AppConfig."""
    cfg = base_cfg
    cfg = _apply_model(cfg, overrides.model)
    cfg = _apply_trace(
        cfg,
        trace_enabled=overrides.trace_enabled,
        trace_id=overrides.trace_id,
        trace_group=overrides.trace_group,
        trace_metadata=overrides.trace_metadata,
    )
    return _apply_store(cfg, store_override=overrides.store_override)


__all__ = ("build_effective_config",)
