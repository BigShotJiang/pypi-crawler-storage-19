"""Provider retry helpers shared across run workflows."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import httpx
from agents.exceptions import MaxTurnsExceeded
from openai import APIConnectionError, APIError, APIStatusError, APITimeoutError

from agenterm.core.error_litellm import (
    is_litellm_retryable,
    litellm_exception_types,
    litellm_status_code,
)
from agenterm.core.errors import PipelineError
from agenterm.core.rate_limits import parse_retry_after_seconds
from agenterm.core.retry import RetryDecision, RetryNotice, RetryPolicy

if TYPE_CHECKING:
    from agenterm.config.model import RetryPolicyConfig

_RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({408, 409, 429})
_RETRYABLE_STATUS_MIN = 500


def retry_policy_from_config(cfg: RetryPolicyConfig) -> RetryPolicy:
    """Convert RetryPolicyConfig to a runtime RetryPolicy."""
    return RetryPolicy(
        max_retries=cfg.max_retries,
        base_backoff_seconds=cfg.base_backoff_seconds,
        max_backoff_seconds=cfg.max_backoff_seconds,
        jitter_ratio=cfg.jitter_ratio,
        retry_after_max_seconds=cfg.retry_after_max_seconds,
    )


def unwrap_retry_cause(exc: Exception) -> Exception:
    """Unwrap retryable causes from pipeline wrappers."""
    if isinstance(exc, PipelineError) and isinstance(exc.__cause__, Exception):
        return exc.__cause__
    return exc


def status_code_for_exception(exc: Exception) -> int | None:
    """Extract an HTTP status code from provider exceptions when available."""
    if isinstance(exc, APIStatusError):
        return exc.status_code
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code
    return litellm_status_code(exc)


def retry_after_for_exception(exc: Exception) -> float | None:
    """Extract a Retry-After delay (seconds) from provider exceptions."""
    if isinstance(exc, APIStatusError):
        return parse_retry_after_seconds(exc.response.headers)
    if isinstance(exc, httpx.HTTPStatusError):
        return parse_retry_after_seconds(exc.response.headers)
    return None


def is_retryable_exception(exc: Exception) -> bool:
    """Return True when a provider exception is eligible for retry."""
    if is_litellm_retryable(exc):
        return True
    if isinstance(exc, (APITimeoutError, APIConnectionError)):
        return True
    if isinstance(exc, httpx.TimeoutException):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        return status in _RETRYABLE_STATUS_CODES or status >= _RETRYABLE_STATUS_MIN
    if isinstance(exc, APIStatusError):
        status = exc.status_code
        return status in _RETRYABLE_STATUS_CODES or status >= _RETRYABLE_STATUS_MIN
    return isinstance(exc, httpx.HTTPError)


def retry_label(exc: Exception) -> str:
    """Return a user-facing retry label for provider exceptions."""
    status = status_code_for_exception(exc)
    if status is None:
        return exc.__class__.__name__
    return f"HTTP {status}"


def provider_retry_decision(exc: Exception) -> RetryDecision:
    """Classify provider errors for retry."""
    root = unwrap_retry_cause(exc)
    if isinstance(root, (MaxTurnsExceeded, asyncio.CancelledError)):
        return RetryDecision(retry=False, label=retry_label(root))
    return RetryDecision(
        retry=is_retryable_exception(root),
        label=retry_label(root),
        retry_after_seconds=retry_after_for_exception(root),
    )


def provider_retry_notice(notice: RetryNotice) -> str:
    """Format a retry notice for REPL/CLI output."""
    suffix = ""
    if notice.retry_after_seconds is not None:
        suffix = f", retry_after={notice.retry_after_seconds:.1f}s"
    return (
        f"warn> {notice.label}{suffix}; retrying in {notice.delay_seconds:.1f}s "
        f"({notice.attempt + 1}/{notice.max_retries + 1})..."
    )


def provider_retry_exceptions() -> tuple[type[Exception], ...]:
    """Return the provider exception types eligible for retry classification."""
    return (APIError, httpx.HTTPError, *litellm_exception_types())


__all__ = (
    "is_retryable_exception",
    "provider_retry_decision",
    "provider_retry_exceptions",
    "provider_retry_notice",
    "retry_after_for_exception",
    "retry_label",
    "retry_policy_from_config",
    "status_code_for_exception",
    "unwrap_retry_cause",
)
