"""End-of-run persistence for agent runs."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from agents.result import RunResultBase

from agenterm.core.errors import AgentermError, ConfigError, DatabaseError
from agenterm.engine.usage_ledger import build_request_usage_records
from agenterm.store.session.service import (
    insert_request_usage,
    session_store,
    session_usage_totals,
    store_run_usage,
)
from agenterm.workflow.run.model import RunPostprocessResult
from agenterm.workflow.run.postprocess_store import (
    persist_branch_store,
    warn_or_raise_store_error,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import ModelResponse

    from agenterm.core.token_usage import TokenUsage
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.session.models import Session


@dataclass(frozen=True)
class _LedgerSnapshot:
    usage_total: TokenUsage | None


class _UsageLike(Protocol):
    @property
    def input_tokens(self) -> int: ...


class _ModelResponseLike(Protocol):
    @property
    def usage(self) -> _UsageLike: ...


class TurnResultLike(Protocol):
    @property
    def raw_responses(self) -> Sequence[_ModelResponseLike]: ...

    @property
    def last_response_id(self) -> str | None: ...


async def _persist_response_ledger(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    run_number: int,
    model: str,
    raw_responses: list[ModelResponse],
) -> None:
    records = build_request_usage_records(
        session_id=session_id,
        branch_id=branch_id,
        kind="response",
        run_number=run_number,
        model=model,
        base_previous_response_id=None,
        raw_responses=raw_responses,
    )
    await insert_request_usage(store=store, records=records)


def _last_request_input_tokens(
    raw_responses: Sequence[_ModelResponseLike],
) -> int | None:
    if not raw_responses:
        return None
    return raw_responses[-1].usage.input_tokens


async def _safe_ledger_snapshot(
    *,
    store: AsyncStore,
    session_id: str | None,
    branch_id: str | None,
    run_number: int | None,
    model: str,
    raw_responses: list[ModelResponse],
    emit_line: Callable[[str], None] | None,
) -> _LedgerSnapshot:
    if session_id is None:
        return _LedgerSnapshot(usage_total=None)
    effective_branch = branch_id or "main"

    if run_number is not None:
        try:
            await _persist_response_ledger(
                store=store,
                session_id=session_id,
                branch_id=effective_branch,
                run_number=run_number,
                model=model,
                raw_responses=raw_responses,
            )
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=emit_line,
                context="Failed to persist request usage ledger",
            )

    usage_total: TokenUsage | None = None
    try:
        usage_total = await session_usage_totals(
            store=store,
            session_id=session_id,
            branch_id=effective_branch,
        )
    except ConfigError:
        raise
    except (OSError, sqlite3.Error, DatabaseError) as exc:
        warn_or_raise_store_error(
            exc,
            emit_line=emit_line,
            context="Failed to read usage totals",
        )
    return _LedgerSnapshot(
        usage_total=usage_total,
    )


async def _maybe_build_ledger_snapshot(
    *,
    store: AsyncStore | None,
    session_id: str | None,
    branch_id: str | None,
    run_number: int | None,
    result: TurnResultLike,
    model: str,
    emit_line: Callable[[str], None] | None,
) -> _LedgerSnapshot:
    if store is None or not isinstance(result, RunResultBase):
        return _LedgerSnapshot(usage_total=None)
    run_result: RunResultBase = result
    raw_responses: list[ModelResponse] = list(run_result.raw_responses)
    return await _safe_ledger_snapshot(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        model=model,
        raw_responses=raw_responses,
        emit_line=emit_line,
    )


async def postprocess_run(
    result: TurnResultLike,
    *,
    session: Session | None,
    session_id: str | None,
    branch_id: str | None,
    store_enabled: bool,
    model: str,
    run_number: int | None,
    emit_line: Callable[[str], None] | None = None,
) -> RunPostprocessResult:
    """Persist usage and update session metadata."""
    try:
        await store_run_usage(
            session,
            result if isinstance(result, RunResultBase) else None,
        )
    except ConfigError:
        raise
    except AgentermError as exc:
        if emit_line is not None:
            emit_line(f"warn> {exc}")
        else:
            raise

    last_response_id = result.last_response_id

    store = session_store() if isinstance(session_id, str) and session_id else None
    raw_responses_like = list(result.raw_responses)
    ledger = await _maybe_build_ledger_snapshot(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        result=result,
        model=model,
        emit_line=emit_line,
    )

    response_id_for_output = (
        last_response_id if isinstance(last_response_id, str) else None
    )
    await persist_branch_store(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        store_enabled=store_enabled,
        last_response_id=response_id_for_output if store_enabled else None,
        emit_line=emit_line,
    )

    last_input_tokens = _last_request_input_tokens(raw_responses_like)
    request_count = len(raw_responses_like) if raw_responses_like else None
    return RunPostprocessResult(
        response_id=response_id_for_output,
        branch_id=branch_id,
        run_number=run_number,
        usage_total=ledger.usage_total,
        usage_compact=None,
        last_request_input_tokens=last_input_tokens,
        last_request_count=request_count,
    )


async def postprocess_cancelled_run(
    *,
    session_id: str | None,
    branch_id: str | None,
    store_enabled: bool,
    run_number: int | None,
    emit_line: Callable[[str], None] | None = None,
) -> RunPostprocessResult:
    """Return a minimal postprocess result for cancelled runs."""
    _ = session_id
    if emit_line is not None and store_enabled:
        emit_line("warn> Run cancelled; no usage persisted.")
    return RunPostprocessResult(
        response_id=None,
        branch_id=branch_id,
        run_number=run_number,
        usage_total=None,
        usage_compact=None,
        last_request_input_tokens=None,
        last_request_count=None,
    )


__all__ = ("postprocess_cancelled_run", "postprocess_run")
