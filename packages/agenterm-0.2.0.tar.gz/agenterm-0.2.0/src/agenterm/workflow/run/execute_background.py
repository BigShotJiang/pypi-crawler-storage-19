"""Background agent-run execution (single-path orchestration)."""

from __future__ import annotations

import asyncio
import sqlite3
from dataclasses import replace
from typing import TYPE_CHECKING

import httpx
from agents.exceptions import AgentsException, MaxTurnsExceeded
from openai import APIError

from agenterm.core.errors import AgentermError
from agenterm.core.retry import RetryNotice, retry_async
from agenterm.engine.result_summary import extract_final_text
from agenterm.engine.run import run_once
from agenterm.store.history import history_store
from agenterm.store.session.service import current_branch_turn_number
from agenterm.workflow.run.event_ledger import RunEventRecorder
from agenterm.workflow.run.model import BackgroundRunResult, RunExecutionContext
from agenterm.workflow.run.pipeline import build_run_pipeline
from agenterm.workflow.run.postprocess import postprocess_run
from agenterm.workflow.run.resume import apply_resume
from agenterm.workflow.run.retry_policy import (
    provider_retry_decision,
    provider_retry_exceptions,
    provider_retry_notice,
    retry_policy_from_config,
)
from agenterm.workflow.run.status import (
    RunStatusHandle,
    error_envelope_json,
    start_run_status,
    update_run_status_record,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.items import TResponseInputItem
    from agents.result import RunResult


async def _background_branch_turn_range(
    handle: RunStatusHandle | None,
) -> tuple[int | None, int | None]:
    if handle is None:
        return None, None
    store = history_store()
    branch_turn_end = await current_branch_turn_number(
        store,
        session_id=handle.session_id,
        branch_id=handle.branch_id,
    )
    base = handle.branch_turn_base
    if base is None or branch_turn_end <= base:
        return None, None
    return base + 1, branch_turn_end


async def _handle_background_failure(
    exc: Exception,
    *,
    handle: RunStatusHandle | None,
    run_ctx: RunExecutionContext,
) -> None:
    if isinstance(exc, MaxTurnsExceeded):
        status = "failed"
        error_json = error_envelope_json(
            exc,
            ctx=run_ctx,
            operation="run.background",
        )
    elif isinstance(exc, asyncio.CancelledError):
        status = "cancelled"
        error_json = None
    else:
        status = "failed"
        error_json = error_envelope_json(
            exc,
            ctx=run_ctx,
            operation="run.background",
        )
    branch_turn_start, branch_turn_end = await _background_branch_turn_range(handle)
    await update_run_status_record(
        handle,
        status=status,
        response_id=None,
        error_json=error_json,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
    )


_RUN_FAILURE_EXCEPTIONS: tuple[type[Exception], ...] = (
    AgentermError,
    AgentsException,
    APIError,
    httpx.HTTPError,
    sqlite3.Error,
    OSError,
)


async def execute_background_run(
    ctx: RunExecutionContext,
    *,
    input_items: str | list[TResponseInputItem],
    emit_line: Callable[[str], None] | None = None,
) -> BackgroundRunResult:
    """Execute a single background agent run (provider-hosted, non-streaming)."""
    handle = await start_run_status(ctx)
    run_ctx = ctx
    if handle is not None and ctx.tool_context is not None:
        run_ctx = replace(
            run_ctx,
            tool_context=replace(
                ctx.tool_context,
                run_number=handle.run_number,
            ),
        )
    event_recorder = RunEventRecorder.from_status_handle(
        handle=handle,
        session_id=run_ctx.session_id,
        branch_id=run_ctx.branch_id,
        model=run_ctx.cfg.agent.model,
        trace_id=run_ctx.cfg.run.trace_id,
        emit_line=emit_line,
    )

    try:
        plan = build_run_pipeline(
            run_ctx,
            background=True,
            emit_line=emit_line,
        )
        resumed, _ = await apply_resume(
            run_ctx,
            input_items,
            emit_line=emit_line,
        )
        policy = retry_policy_from_config(run_ctx.cfg.retries.provider)

        async def _call() -> RunResult:
            return await run_once(run_ctx.agent, resumed, opts=plan.run_options)

        def _on_retry(notice: RetryNotice) -> None:
            if emit_line is None:
                return
            emit_line(provider_retry_notice(notice))

        result = await retry_async(
            _call,
            policy=policy,
            retry_on=provider_retry_exceptions(),
            classify=provider_retry_decision,
            on_retry=_on_retry,
        )
        if event_recorder is not None:
            await event_recorder.record_synthetic_responses(result.raw_responses)
        post = await postprocess_run(
            result,
            session=run_ctx.session,
            session_id=run_ctx.session_id,
            branch_id=run_ctx.branch_id,
            store_enabled=run_ctx.store_enabled,
            model=run_ctx.cfg.agent.model,
            run_number=handle.run_number if handle is not None else None,
            emit_line=emit_line,
        )
    except _RUN_FAILURE_EXCEPTIONS as exc:
        await _handle_background_failure(
            exc,
            handle=handle,
            run_ctx=run_ctx,
        )
        raise
    branch_turn_start, branch_turn_end = await _background_branch_turn_range(handle)
    await update_run_status_record(
        handle,
        status="completed",
        response_id=post.response_id,
        error_json=None,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
    )
    return BackgroundRunResult(
        result=result,
        last_agent=result.last_agent,
        final_text=extract_final_text(result) or "",
        post=post,
    )


__all__ = ("execute_background_run",)
