"""Force-cancel persistence for stalled streamed runs."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from agenterm.core.errors import AgentermError
from agenterm.store.runs.repo import update_run_status
from agenterm.store.session.service import session_store
from agenterm.store.turn_attempts import mark_turn_attempt_cancelled

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.workflow.run.model import RunRef


async def force_cancel_run(
    *,
    run_ref: RunRef | None,
    emit_line: Callable[[str], None] | None = None,
) -> None:
    """Persist a forced cancellation for a stalled run task."""
    if run_ref is None:
        return
    if (
        run_ref.run_id is None
        or run_ref.run_number is None
        or run_ref.session_id is None
        or run_ref.branch_id is None
    ):
        return
    try:
        store = session_store()
        await update_run_status(
            store=store,
            run_id=run_ref.run_id,
            status="cancelled",
            response_id=None,
            error_json=None,
            branch_turn_start=None,
            branch_turn_end=None,
        )
        await mark_turn_attempt_cancelled(
            store=store,
            session_id=run_ref.session_id,
            branch_id=run_ref.branch_id,
            run_number=run_ref.run_number,
            cancel_reason=run_ref.cancel_reason,
        )
    except (AgentermError, sqlite3.Error, OSError) as exc:
        if emit_line is not None:
            emit_line(f"warn> Failed to persist forced cancellation: {exc}")


__all__ = ("force_cancel_run",)
