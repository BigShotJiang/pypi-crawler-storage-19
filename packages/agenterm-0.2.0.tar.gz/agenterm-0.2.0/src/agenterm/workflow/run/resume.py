"""Resume handling for cancelled runs."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from agents.items import ItemHelpers

from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.response_items import parse_input_item
from agenterm.store.session.service import session_store
from agenterm.store.turn_attempts import consume_latest_cancelled_attempt
from agenterm.workflow.run.postprocess_store import warn_or_raise_store_error

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue
    from agenterm.workflow.run.model import RunExecutionContext

type ResumeOutcome = tuple[str | list[TResponseInputItem], bool]


def _resume_items(
    items: Sequence[Mapping[str, JSONValue]],
) -> list[TResponseInputItem]:
    return [parse_input_item(item, context="resume.item") for item in items]


async def apply_resume(
    ctx: RunExecutionContext,
    input_items: str | list[TResponseInputItem],
    *,
    emit_line: Callable[[str], None] | None,
) -> ResumeOutcome:
    """Append cancelled turn attempt items to the next run input."""
    session_id = ctx.session_id
    if not isinstance(session_id, str) or not session_id:
        return input_items, False
    branch_id = ctx.branch_id or "main"
    store = session_store()
    try:
        attempt = await consume_latest_cancelled_attempt(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
    except ConfigError:
        raise
    except (OSError, sqlite3.Error, DatabaseError) as exc:
        warn_or_raise_store_error(
            exc,
            emit_line=emit_line,
            context="Failed to load cancelled turn attempt",
        )
        return input_items, False
    if attempt is None:
        return input_items, False
    _, items = attempt
    payloads = [record.item for record in items]
    resume_items = _resume_items(payloads)
    if not resume_items:
        return input_items, False
    merged = ItemHelpers.input_to_new_input_list(input_items)
    return [*resume_items, *merged], True


__all__ = ("ResumeOutcome", "apply_resume")
