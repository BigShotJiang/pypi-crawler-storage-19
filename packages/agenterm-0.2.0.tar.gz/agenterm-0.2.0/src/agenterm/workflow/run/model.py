"""Typed models for canonical agent-run workflows."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from agenterm.core.cancellation import CancellationScope, CancelToken

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.agent import Agent
    from agents.items import RunItem, TResponseInputItem
    from agents.memory import Session
    from agents.result import RunResultBase, RunResultStreaming

    from agenterm.config.model import AppConfig, RetryPolicyConfig
    from agenterm.core.approvals import ApprovalsContext
    from agenterm.core.choices.repl import ReplStreamMode
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.core.token_usage import TokenUsage
    from agenterm.engine.mcp_pool import McpServerPool


@dataclass(frozen=True)
class RunExecutionContext:
    """Dependencies and configuration for executing a single agent run."""

    cfg: AppConfig
    agent: Agent
    session: Session | None
    session_id: str | None
    branch_id: str | None
    store_enabled: bool
    interactive: bool
    workflow_name: str
    approvals: ApprovalsContext
    mcp_pool: McpServerPool | None = None
    tool_context: ToolRuntimeContext | None = None


@dataclass(frozen=True)
class StreamEventCallbacks:
    """Optional callbacks for rendering/observing streamed events."""

    on_text_delta: Callable[[str], None] | None = None
    on_reasoning_summary_delta: Callable[[str], None] | None = None
    on_run_item: Callable[[RunItem], None] | None = None
    on_raw_event_type: Callable[[str], None] | None = None
    on_agent_updated: Callable[[Agent], None] | None = None


type RunCancelReason = Literal["user", "timeout"]


@dataclass
class RunRef:
    """Mutable reference to an in-flight streamed run for cancellation hooks."""

    streaming: RunResultStreaming | None = None
    cancel_mode: Literal["immediate", "after_turn"] | None = None
    cancel_reason: RunCancelReason | None = None
    suppress_output: bool = False
    cancel_scope: CancellationScope = field(default_factory=CancellationScope)
    run_id: str | None = None
    run_number: int | None = None
    session_id: str | None = None
    branch_id: str | None = None

    def request_cancel(
        self,
        *,
        mode: Literal["immediate", "after_turn"],
        suppress_output: bool = True,
        reason: RunCancelReason = "user",
    ) -> None:
        """Request cancellation and optionally suppress further output."""
        self.cancel_mode = mode
        self.cancel_reason = reason
        if suppress_output:
            self.suppress_output = True
        self.cancel_scope.cancel()
        if self.streaming is not None:
            self.streaming.cancel(mode=mode)

    @property
    def cancel_token(self) -> CancelToken:
        """Return the shared cancellation token for this run."""
        return self.cancel_scope.token


@dataclass(frozen=True)
class StreamedRunRequest:
    """Inputs and policies required to execute and consume a streamed agent run."""

    input_items: str | list[TResponseInputItem]
    callbacks: StreamEventCallbacks
    stream_mode: ReplStreamMode
    retry_policy: RetryPolicyConfig | None = None
    run_ref: RunRef | None = None
    postprocess_emit_line: Callable[[str], None] | None = None
    retry_emit_line: Callable[[str], None] | None = None


@dataclass(frozen=True)
class RunPostprocessResult:
    """End-of-run outputs shared across surfaces."""

    response_id: str | None
    branch_id: str | None
    run_number: int | None
    usage_total: TokenUsage | None
    usage_compact: TokenUsage | None
    last_request_input_tokens: int | None
    last_request_count: int | None


@dataclass(frozen=True)
class StreamedRunResult:
    """Result of a fully-consumed streamed agent run."""

    streaming: RunResultStreaming
    last_agent: Agent
    final_text: str
    post: RunPostprocessResult


@dataclass(frozen=True)
class BackgroundRunResult:
    """Result of a background (non-streaming) agent run."""

    result: RunResultBase
    last_agent: Agent
    final_text: str
    post: RunPostprocessResult


__all__ = (
    "BackgroundRunResult",
    "RunCancelReason",
    "RunExecutionContext",
    "RunPostprocessResult",
    "RunRef",
    "StreamEventCallbacks",
    "StreamedRunRequest",
    "StreamedRunResult",
)
