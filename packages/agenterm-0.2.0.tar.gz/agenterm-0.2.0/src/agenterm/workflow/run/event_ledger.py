"""Run event ledger recording helpers."""

from __future__ import annotations

import asyncio
import sqlite3
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.models.fake_id import FAKE_RESPONSES_ID
from openai.types.responses import Response, ResponseCompletedEvent
from openai.types.responses.response_created_event import ResponseCreatedEvent
from openai.types.responses.response_image_gen_call_partial_image_event import (
    ResponseImageGenCallPartialImageEvent,
)
from openai.types.responses.response_output_item import (
    ImageGenerationCall,
    ResponseOutputItem,
)
from openai.types.responses.response_output_item_added_event import (
    ResponseOutputItemAddedEvent,
)
from openai.types.responses.response_output_item_done_event import (
    ResponseOutputItemDoneEvent,
)
from openai.types.responses.response_usage import ResponseUsage

from agenterm.artifacts.image_generation import (
    persist_image_generation_call,
    persist_image_generation_partial,
)
from agenterm.constants.limits import RUN_EVENT_BATCH_MAX_SIZE
from agenterm.core.envelope import iso_timestamp
from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.json_codec import is_json_object, loads_json_value
from agenterm.core.model_id import model_plane
from agenterm.store.run_events import (
    RunEventEnvelope,
    RunEventInsert,
    RunEventPayload,
    insert_run_events_batch,
)
from agenterm.workflow.run.spool import (
    RunIdentity,
    append_run_event_spool,
    start_run_event_spool,
)

if TYPE_CHECKING:
    from collections.abc import Callable, MutableMapping, Sequence
    from pathlib import Path

    from agents.items import ModelResponse, TResponseStreamEvent

    from agenterm.artifacts.repo import ArtifactRecord
    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.run_events.models import RunEventPlane
    from agenterm.workflow.run.status import RunStatusHandle


def _artifact_reference(record: ArtifactRecord) -> dict[str, JSONValue]:
    return {
        "artifact_id": record.artifact_id,
        "kind": record.kind,
        "mime": record.mime,
        "path": record.path,
        "size_bytes": record.size_bytes,
        "created_at": record.created_at,
        "source_type": record.source_type,
        "source_id": record.source_id,
        "session_id": record.session_id,
    }


def _event_payload(event: TResponseStreamEvent) -> dict[str, JSONValue]:
    raw = event.to_json(
        indent=None,
        use_api_names=True,
        exclude_unset=True,
        exclude_defaults=False,
        exclude_none=False,
    )
    parsed = loads_json_value(raw)
    if not is_json_object(value=parsed):
        msg = "stream event payload is not a JSON object"
        raise DatabaseError(msg)
    return dict(parsed)


def _usage_for_response(resp: ModelResponse) -> ResponseUsage:
    usage = resp.usage
    return ResponseUsage(
        input_tokens=usage.input_tokens,
        input_tokens_details=usage.input_tokens_details,
        output_tokens=usage.output_tokens,
        output_tokens_details=usage.output_tokens_details,
        total_tokens=usage.total_tokens,
    )


def _response_for_synthetic_event(
    *,
    response_id: str,
    model: str,
    output_items: list[ResponseOutputItem],
    usage: ResponseUsage,
) -> Response:
    return Response(
        id=response_id,
        created_at=time.time(),
        model=model,
        object="response",
        output=output_items,
        tool_choice="auto",
        tools=[],
        parallel_tool_calls=False,
        status="completed",
        usage=usage,
    )


@dataclass
class RunEventRecorder:
    """Record streamed events into the run event ledger."""

    store: AsyncStore
    run_id: str | None
    session_id: str
    branch_id: str
    run_number: int
    model: str
    plane: RunEventPlane
    trace_id: str | None
    emit_line: Callable[[str], None] | None

    _request_index: int = -1
    _event_seq: int = 0
    _response_id: str | None = None
    _spool_path: Path | None = None

    @classmethod
    def from_status_handle(
        cls,
        *,
        handle: RunStatusHandle | None,
        session_id: str | None,
        branch_id: str | None,
        model: str,
        trace_id: str | None,
        emit_line: Callable[[str], None] | None,
    ) -> RunEventRecorder | None:
        """Build a recorder from a run status handle."""
        if handle is None:
            return None
        if not isinstance(session_id, str) or not session_id:
            return None
        branch = branch_id or "main"
        plane = model_plane(model)
        return cls(
            store=handle.store,
            run_id=handle.run_id,
            session_id=session_id,
            branch_id=branch,
            run_number=handle.run_number,
            model=model,
            plane=plane,
            trace_id=trace_id,
            emit_line=emit_line,
        )

    def _start_request(self, response_id: str | None) -> None:
        if self._request_index < 0:
            self._request_index = 0
        else:
            self._request_index += 1
        self._event_seq = 0
        self._response_id = response_id

    async def _scrub_payload(
        self,
        event: TResponseStreamEvent,
        payload: MutableMapping[str, JSONValue],
    ) -> None:
        if (
            isinstance(event, ResponseImageGenCallPartialImageEvent)
            and event.partial_image_b64
        ):
            artifact = await persist_image_generation_partial(
                store=self.store,
                session_id=self.session_id,
                item_id=event.item_id,
                partial_index=event.partial_image_index,
                result_b64=event.partial_image_b64,
            )
            payload["partial_image_b64"] = _artifact_reference(artifact)

        if isinstance(
            event,
            (
                ResponseOutputItemAddedEvent,
                ResponseOutputItemDoneEvent,
            ),
        ):
            item = event.item
            if isinstance(item, ImageGenerationCall) and item.result:
                artifact = await persist_image_generation_call(
                    store=self.store,
                    session_id=self.session_id,
                    call_id=item.id,
                    result_b64=item.result,
                )
                item_payload = payload.get("item")
                if isinstance(item_payload, dict):
                    item_payload["result"] = _artifact_reference(artifact)

    async def _build_insert(
        self,
        event: TResponseStreamEvent,
        *,
        force_new_request: bool,
        response_id_override: str | None,
    ) -> RunEventInsert:
        if force_new_request:
            self._start_request(response_id_override)
        elif isinstance(event, ResponseCreatedEvent):
            self._start_request(event.response.id)
        elif self._request_index < 0:
            self._start_request(None)

        payload = _event_payload(event)
        await self._scrub_payload(event, payload)
        event_seq = self._event_seq
        self._event_seq += 1

        envelope = RunEventEnvelope(
            schema_version=1,
            trace_id=self.trace_id,
            ts=iso_timestamp(),
            event=RunEventPayload(
                type=str(event.type),
                plane=self.plane,
                model=self.model,
                response_id=self._response_id,
                request_index=self._request_index,
                payload=payload,
                raw_provider_payload=None,
            ),
        )
        return RunEventInsert(
            session_id=self.session_id,
            branch_id=self.branch_id,
            run_number=self.run_number,
            request_index=self._request_index,
            event_seq=event_seq,
            event_type=str(event.type),
            response_id=self._response_id,
            model=self.model,
            envelope=envelope,
        )

    async def _persist_inserts(self, inserts: Sequence[RunEventInsert]) -> None:
        if self._spool_path is not None:
            await append_run_event_spool(path=self._spool_path, inserts=inserts)
            return
        try:
            await insert_run_events_batch(store=self.store, records=inserts)
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            await self._spool_events(inserts, exc=exc)

    async def _spool_events(
        self,
        inserts: Sequence[RunEventInsert],
        *,
        exc: Exception,
    ) -> None:
        run = RunIdentity(
            run_id=self.run_id,
            session_id=self.session_id,
            branch_id=self.branch_id,
            run_number=self.run_number,
        )
        if self._spool_path is None:
            self._spool_path = await start_run_event_spool(
                store=self.store,
                run=run,
                emit_line=self.emit_line,
            )
            if self.emit_line is not None:
                self.emit_line(
                    "warn> Run event persistence failed; spooling to "
                    f"{self._spool_path}: {exc}"
                )
        await append_run_event_spool(path=self._spool_path, inserts=inserts)

    async def record_raw_event(self, event: TResponseStreamEvent) -> None:
        """Record a raw Responses stream event."""
        await self.record_raw_events_batch([event])

    async def record_raw_events_batch(
        self,
        events: Sequence[TResponseStreamEvent],
    ) -> None:
        """Record a batch of raw Responses stream events."""
        if not events:
            return
        inserts: list[RunEventInsert] = [
            await self._build_insert(
                event,
                force_new_request=False,
                response_id_override=None,
            )
            for event in events
        ]
        await self._persist_inserts(inserts)

    async def record_synthetic_responses(
        self,
        responses: Sequence[ModelResponse],
    ) -> None:
        """Record synthetic response.completed events for non-streaming runs."""
        inserts: list[RunEventInsert] = []
        for resp in responses:
            response_id = resp.response_id or FAKE_RESPONSES_ID
            response = _response_for_synthetic_event(
                response_id=response_id,
                model=self.model,
                output_items=list(resp.output),
                usage=_usage_for_response(resp),
            )
            event = ResponseCompletedEvent(
                response=response,
                sequence_number=0,
                type="response.completed",
            )
            inserts.append(
                await self._build_insert(
                    event,
                    force_new_request=True,
                    response_id_override=response_id,
                )
            )
        await self._persist_inserts(inserts)


@dataclass(frozen=True)
class _QueueSentinel:
    """Sentinel to signal the run event batcher to shut down."""


_QUEUE_SENTINEL = _QueueSentinel()


class RunEventBatcher:
    """Queue-backed batch writer for the run event ledger."""

    def __init__(
        self,
        recorder: RunEventRecorder,
        *,
        batch_max_size: int = RUN_EVENT_BATCH_MAX_SIZE,
    ) -> None:
        """Initialize a batcher that flushes events to the ledger."""
        self._recorder = recorder
        self._batch_max_size = max(1, int(batch_max_size))
        self._queue: asyncio.Queue[TResponseStreamEvent | _QueueSentinel] = (
            asyncio.Queue()
        )
        self._task: asyncio.Task[None] | None = asyncio.create_task(self._run())
        self._closed = False

    async def record_raw_event(self, event: TResponseStreamEvent) -> None:
        """Enqueue a raw Responses stream event for batched persistence."""
        if self._closed:
            return
        await self._queue.put(event)

    async def close(self) -> None:
        """Flush queued events and stop the background task."""
        if self._closed:
            return
        self._closed = True
        await self._queue.put(_QUEUE_SENTINEL)
        if self._task is not None:
            await self._task
            self._task = None

    async def _run(self) -> None:
        batch: list[TResponseStreamEvent] = []
        shutdown = False
        while True:
            item = await self._queue.get()
            if isinstance(item, _QueueSentinel):
                shutdown = True
            else:
                batch.append(item)
            if batch:
                while not shutdown and len(batch) < self._batch_max_size:
                    try:
                        next_item = self._queue.get_nowait()
                    except asyncio.QueueEmpty:
                        break
                    if isinstance(next_item, _QueueSentinel):
                        shutdown = True
                        break
                    batch.append(next_item)
                await self._recorder.record_raw_events_batch(batch)
                batch = []
            if shutdown:
                break


__all__ = ("RunEventBatcher", "RunEventRecorder")
