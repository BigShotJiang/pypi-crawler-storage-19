"""Shared run execution pipeline helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.engine.history_packing import HistoryPackingOptions
from agenterm.engine.run import RunExecOptions

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.workflow.run.model import RunExecutionContext


@dataclass(frozen=True)
class RunPipelinePlan:
    """Resolved execution inputs shared by streamed and background runs."""

    run_options: RunExecOptions


def build_run_pipeline(
    ctx: RunExecutionContext,
    *,
    background: bool,
    emit_line: Callable[[str], None] | None = None,
) -> RunPipelinePlan:
    """Return the shared execution plan for a run."""
    run_number = ctx.tool_context.run_number if ctx.tool_context is not None else None
    opts = RunExecOptions(
        cfg=ctx.cfg,
        workflow_name=ctx.workflow_name,
        session=ctx.session,
        background=background,
        tool_context=ctx.tool_context,
        history_packing=HistoryPackingOptions(
            interactive=ctx.interactive,
            approvals=ctx.approvals,
            cancel_token=ctx.tool_context.cancel_token if ctx.tool_context else None,
            emit_line=emit_line,
            run_number=run_number,
            origin_branch_id=ctx.branch_id,
        ),
    )
    return RunPipelinePlan(
        run_options=opts,
    )


__all__ = ("RunPipelinePlan", "build_run_pipeline")
