"""Types shared by spool persistence and replay."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

type SpoolKind = Literal["run_events", "turn_attempt"]
type SpoolRecordType = Literal["header", "event", "item", "status"]


@dataclass(frozen=True)
class RunIdentity:
    """Run identity metadata stored in spool files."""

    run_id: str | None
    session_id: str
    branch_id: str
    run_number: int


@dataclass(frozen=True)
class SpoolReplayResult:
    """Result from replaying a spool file."""

    kind: SpoolKind
    session_id: str
    branch_id: str
    run_number: int
    run_id: str | None
    events: int
    items: int
    spool_path: str


__all__ = ("RunIdentity", "SpoolKind", "SpoolRecordType", "SpoolReplayResult")
