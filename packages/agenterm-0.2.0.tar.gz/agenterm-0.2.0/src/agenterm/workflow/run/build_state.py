"""Builders for run-surface configuration and tool selection."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.config.decode import discover_config_path
from agenterm.engine.config_effective import build_runtime_config
from agenterm.workflow.shared.config_files import load_base_config
from agenterm.workflow.shared.overrides import build_effective_config
from agenterm.workflow.shared.tools import build_tools_context

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.tool_selection import ToolCatalog, ToolSelection
    from agenterm.core.toolspec import ToolSpec


@dataclass(frozen=True)
class ConfigAndTools:
    """Bundle of effective AppConfig and tools metadata derived from flags."""

    cfg: AppConfig
    tools: ToolCatalog
    selection: ToolSelection
    selected_tools: list[ToolSpec] | None
    config_path: Path | None = None
    background: bool = False


@dataclass(frozen=True)
class ConfigInputs:
    """Inputs required to build effective config and tools context."""

    config: Path | None
    agent_name: str | None
    model: str | None
    trace_enabled: bool | None
    trace_id: str | None
    trace_group: str | None
    trace_metadata: list[str] | None
    store_override: bool | None
    allow_dangerous: bool
    hosted_mode: bool
    background_flag: bool | None
    tool_select: list[str] | None


@dataclass(frozen=True)
class RunConfigInputs(ConfigInputs):
    """Run-surface specific inputs (adds tools gate flag)."""

    no_tools: bool


def build_config_bundle(inputs: ConfigInputs) -> ConfigAndTools:
    """Return effective AppConfig and tools context derived from flags + config."""
    base_cfg = load_base_config(
        inputs.config,
        agent_name=inputs.agent_name,
    )
    conf_path = discover_config_path(inputs.config)
    cfg = build_effective_config(base_cfg, inputs)

    effective_background = (
        bool(inputs.background_flag)
        if inputs.background_flag is not None
        else bool(cfg.run.background)
    )

    tools_ctx, sel, selected = build_tools_context(
        cfg,
        tool_select=inputs.tool_select,
        allow_dangerous=inputs.allow_dangerous,
        hosted_mode=bool(inputs.hosted_mode or effective_background),
    )

    return ConfigAndTools(
        cfg=cfg,
        tools=tools_ctx,
        selection=sel,
        selected_tools=list(selected) if selected is not None else None,
        config_path=conf_path,
        background=effective_background,
    )


def build_run_config_bundle(
    inputs: RunConfigInputs,
) -> tuple[ConfigAndTools, AppConfig, bool, bool]:
    """Return (bundle, runtime cfg, tools_enabled, background) for run surfaces."""
    cfg_bundle = build_config_bundle(inputs)
    tools_enabled = not bool(inputs.no_tools)
    runtime_cfg = build_runtime_config(cfg_bundle.cfg, tools_enabled=tools_enabled)
    return cfg_bundle, runtime_cfg, tools_enabled, cfg_bundle.background


__all__ = (
    "ConfigAndTools",
    "ConfigInputs",
    "RunConfigInputs",
    "build_config_bundle",
    "build_run_config_bundle",
)
