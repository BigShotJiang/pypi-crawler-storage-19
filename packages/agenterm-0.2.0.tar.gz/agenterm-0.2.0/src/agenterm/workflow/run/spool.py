"""Durable spool helpers for run events and turn attempts."""

from __future__ import annotations

import asyncio
import uuid
from typing import TYPE_CHECKING

from agenterm.config.paths import ensure_run_spool_dir
from agenterm.core.envelope import iso_timestamp
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.json_codec import dumps_compact
from agenterm.store.run_events import insert_run_events_batch_ignore_conflicts
from agenterm.store.runs.repo import update_run_recovery
from agenterm.store.turn_attempts import (
    insert_turn_attempt_item,
    mark_turn_attempt_cancelled,
    start_turn_attempt,
)
from agenterm.workflow.run.spool_models import RunIdentity, SpoolKind, SpoolReplayResult
from agenterm.workflow.run.spool_parse import (
    load_spool_lines,
    parse_event_row,
    parse_spool_header,
    parse_turn_attempt_rows,
    require_spool_int,
    require_spool_text,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from pathlib import Path

    from agenterm.core.json_types import JSONMapping, JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.run_events.models import RunEventInsert

_SPOOL_SCHEMA_VERSION = 1
_REPLAY_BATCH_SIZE = 200


def _spool_filename(kind: SpoolKind, *, run_number: int) -> str:
    return f"run-{run_number}-{kind}-{uuid.uuid4().hex}.jsonl"


def _spool_path(kind: SpoolKind, *, run_number: int) -> Path:
    root = ensure_run_spool_dir()
    return root / _spool_filename(kind, run_number=run_number)


def _write_text_atomic(path: Path, text: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(path)
    except OSError as exc:
        msg = f"Failed to write run spool {path}: {exc}"
        raise FilesystemError(msg) from exc


def _append_lines(path: Path, lines: Sequence[str]) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            for line in lines:
                handle.write(line)
                handle.write("\n")
    except OSError as exc:
        msg = f"Failed to append run spool {path}: {exc}"
        raise FilesystemError(msg) from exc


def _header_record(kind: SpoolKind, run: RunIdentity) -> dict[str, JSONValue]:
    return {
        "schema_version": _SPOOL_SCHEMA_VERSION,
        "kind": kind,
        "record_type": "header",
        "created_at": iso_timestamp(),
        "run": {
            "run_id": run.run_id,
            "session_id": run.session_id,
            "branch_id": run.branch_id,
            "run_number": run.run_number,
        },
    }


def _event_record(*, insert: RunEventInsert) -> dict[str, JSONValue]:
    event_json = dumps_compact(
        insert.envelope.to_json(),
        sort_keys=True,
        ensure_ascii=True,
        context="run.spool.event_json",
    )
    return {
        "schema_version": _SPOOL_SCHEMA_VERSION,
        "kind": "run_events",
        "record_type": "event",
        "event": {
            "request_index": insert.request_index,
            "event_seq": insert.event_seq,
            "event_type": insert.event_type,
            "response_id": insert.response_id,
            "model": insert.model,
            "event_json": event_json,
        },
    }


def _status_record(
    *,
    status: str,
    cancel_reason: str | None,
) -> dict[str, JSONValue]:
    return {
        "schema_version": _SPOOL_SCHEMA_VERSION,
        "kind": "turn_attempt",
        "record_type": "status",
        "status": status,
        "cancel_reason": cancel_reason,
    }


async def _mark_recovery(
    *,
    store: AsyncStore,
    run: RunIdentity,
    spool_path: Path,
    emit_line: Callable[[str], None] | None,
) -> None:
    if run.run_id is None:
        return
    try:
        await update_run_recovery(
            store=store,
            run_id=run.run_id,
            recovery_state="needs_replay",
            recovery_spool_path=str(spool_path),
        )
    except (DatabaseError, OSError) as exc:  # pragma: no cover - defensive
        if emit_line is not None:
            emit_line(f"warn> Failed to mark run recovery state: {exc}")


async def start_run_event_spool(
    *,
    store: AsyncStore,
    run: RunIdentity,
    emit_line: Callable[[str], None] | None,
) -> Path:
    """Create a run-events spool file with a header record."""
    path = _spool_path("run_events", run_number=run.run_number)
    header = dumps_compact(
        _header_record("run_events", run),
        ensure_ascii=True,
        context="run.spool.run_events.header",
    )
    await asyncio.to_thread(_write_text_atomic, path, header + "\n")
    await _mark_recovery(store=store, run=run, spool_path=path, emit_line=emit_line)
    return path


async def append_run_event_spool(
    *,
    path: Path,
    inserts: Sequence[RunEventInsert],
) -> None:
    """Append serialized run-event records to a spool file."""
    lines = [
        dumps_compact(
            _event_record(insert=ins),
            context="run.spool.run_events.record",
        )
        for ins in inserts
    ]
    await asyncio.to_thread(_append_lines, path, lines)


async def start_turn_attempt_spool(
    *,
    store: AsyncStore,
    run: RunIdentity,
    emit_line: Callable[[str], None] | None,
) -> Path:
    """Create a turn-attempt spool file with a header record."""
    path = _spool_path("turn_attempt", run_number=run.run_number)
    header = dumps_compact(
        _header_record("turn_attempt", run),
        ensure_ascii=True,
        context="run.spool.turn_attempt.header",
    )
    await asyncio.to_thread(_write_text_atomic, path, header + "\n")
    await _mark_recovery(store=store, run=run, spool_path=path, emit_line=emit_line)
    return path


async def append_turn_attempt_items(
    *,
    path: Path,
    items: Sequence[JSONMapping],
) -> None:
    """Append turn-attempt item records to a spool file."""
    lines = [
        dumps_compact(
            item,
            ensure_ascii=True,
            context="run.spool.turn_attempt.item",
        )
        for item in items
    ]
    await asyncio.to_thread(_append_lines, path, lines)


async def append_turn_attempt_status(
    *,
    path: Path,
    status: str,
    cancel_reason: str | None,
) -> None:
    """Append a terminal status record to a turn-attempt spool file."""
    record = dumps_compact(
        _status_record(status=status, cancel_reason=cancel_reason),
        ensure_ascii=True,
        context="run.spool.turn_attempt.status",
    )
    await asyncio.to_thread(_append_lines, path, [record])


async def _mark_replayed(
    *,
    store: AsyncStore,
    run: RunIdentity,
    path: Path,
) -> None:
    if run.run_id is None:
        return
    await update_run_recovery(
        store=store,
        run_id=run.run_id,
        recovery_state="replayed",
        recovery_spool_path=str(path),
    )


async def _replay_run_events(
    *,
    store: AsyncStore,
    run: RunIdentity,
    rows: Sequence[JSONMapping],
    path: Path,
) -> int:
    events: list[tuple[int, int, str, str | None, str, str]] = []
    event_count = 0
    for row in rows:
        parsed = parse_event_row(row)
        if parsed is None:
            continue
        events.append(parsed)
        event_count += 1
        if len(events) >= _REPLAY_BATCH_SIZE:
            await insert_run_events_batch_ignore_conflicts(
                store=store,
                session_id=run.session_id,
                branch_id=run.branch_id,
                run_number=run.run_number,
                events=events,
            )
            events = []
    if events:
        await insert_run_events_batch_ignore_conflicts(
            store=store,
            session_id=run.session_id,
            branch_id=run.branch_id,
            run_number=run.run_number,
            events=events,
        )
    await _mark_replayed(store=store, run=run, path=path)
    return event_count


async def _replay_turn_attempt(
    *,
    store: AsyncStore,
    run: RunIdentity,
    rows: Sequence[JSONMapping],
    path: Path,
) -> int:
    items, status, cancel_reason = parse_turn_attempt_rows(rows)
    await start_turn_attempt(
        store=store,
        session_id=run.session_id,
        branch_id=run.branch_id,
        run_number=run.run_number,
    )
    for row in items:
        item_seq = require_spool_int(row.get("item_seq"), field="item.item_seq")
        item_type = require_spool_text(row.get("item_type"), field="item.item_type")
        item = row.get("item")
        if not isinstance(item, dict):
            msg = "Spool item record missing item payload"
            raise ValidationError(msg)
        seen_val = row.get("seen_by_model")
        seen = bool(seen_val) if isinstance(seen_val, bool) else False
        await insert_turn_attempt_item(
            store=store,
            session_id=run.session_id,
            branch_id=run.branch_id,
            run_number=run.run_number,
            item_seq=item_seq,
            item_type=item_type,
            item=item,
            seen_by_model=seen,
        )
    if status == "cancelled":
        await mark_turn_attempt_cancelled(
            store=store,
            session_id=run.session_id,
            branch_id=run.branch_id,
            run_number=run.run_number,
            cancel_reason=cancel_reason,
        )
    await _mark_replayed(store=store, run=run, path=path)
    return len(items)


async def replay_spool_file(
    *,
    store: AsyncStore,
    path: Path,
) -> SpoolReplayResult:
    """Replay a run spool file into the meta store."""
    rows = load_spool_lines(path)
    kind, run = parse_spool_header(rows[0])
    if kind == "run_events":
        event_count = await _replay_run_events(
            store=store,
            run=run,
            rows=rows[1:],
            path=path,
        )
        return SpoolReplayResult(
            kind="run_events",
            session_id=run.session_id,
            branch_id=run.branch_id,
            run_number=run.run_number,
            run_id=run.run_id,
            events=event_count,
            items=0,
            spool_path=str(path),
        )
    item_count = await _replay_turn_attempt(
        store=store,
        run=run,
        rows=rows[1:],
        path=path,
    )
    return SpoolReplayResult(
        kind="turn_attempt",
        session_id=run.session_id,
        branch_id=run.branch_id,
        run_number=run.run_number,
        run_id=run.run_id,
        events=0,
        items=item_count,
        spool_path=str(path),
    )


__all__ = (
    "RunIdentity",
    "SpoolReplayResult",
    "append_run_event_spool",
    "append_turn_attempt_items",
    "append_turn_attempt_status",
    "replay_spool_file",
    "start_run_event_spool",
    "start_turn_attempt_spool",
)
