"""REPL workflow assembly helpers."""
