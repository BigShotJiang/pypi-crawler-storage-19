"""Shared helpers for local CLI tool implementations."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_bool, as_int, as_str_list
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.subprocess_runner import run_subprocess

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue

INVALID_INPUT_KIND = "invalid_input"
NOT_FOUND_KIND = "not_found"
TOOL_ERROR_KIND = "tool_error"

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")

# Safe environment variables to inherit (mirrors MCP SDK pattern).
_SAFE_INHERITED_ENV_VARS: tuple[str, ...] = (
    ("HOME", "LOGNAME", "PATH", "SHELL", "TERM", "USER")
    if os.name != "nt"
    else (
        "APPDATA",
        "HOMEDRIVE",
        "HOMEPATH",
        "LOCALAPPDATA",
        "PATH",
        "PATHEXT",
        "PROCESSOR_ARCHITECTURE",
        "SYSTEMDRIVE",
        "SYSTEMROOT",
        "TEMP",
        "USERNAME",
        "USERPROFILE",
    )
)


def build_safe_env(extra: Mapping[str, str] | None = None) -> dict[str, str]:
    """Return environment with only safe inherited variables."""
    env: dict[str, str] = {}
    for key in _SAFE_INHERITED_ENV_VARS:
        value = os.environ.get(key)
        if value is None:
            continue
        if value.startswith("()"):
            continue
        env[key] = value
    if extra:
        env.update(extra)
    return env


def error_output(
    tool: str,
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    """Return an error envelope string for a tool failure."""
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = FunctionToolOutputEnvelope(
        tool=tool,
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def success_output(tool: str, payload: Mapping[str, JSONValue]) -> str:
    """Return a success envelope string for a tool payload."""
    env = FunctionToolOutputEnvelope(tool=tool, ok=True, payload=dict(payload))
    return env.to_json_string()


def parse_bounded_int(
    value: JSONValue | None,
    *,
    default: int,
    min_value: int,
    max_value: int,
) -> int | None:
    """Parse a bounded integer or return None on invalid bounds."""
    if value is None:
        return int(default)
    parsed = as_int(value)
    if parsed is None:
        return None
    if parsed < min_value or parsed > max_value:
        return None
    return int(parsed)


def parse_optional_bool(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
    default: bool,
) -> bool | None:
    """Parse an optional boolean from a JSON payload."""
    if key not in payload:
        return default
    value = payload.get(key)
    parsed = as_bool(value)
    if parsed is None:
        return None
    return parsed


def parse_optional_str_list(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
    default: Sequence[str],
    allow_empty: bool = False,
) -> list[str] | None:
    """Parse an optional list of strings from a JSON payload."""
    if key not in payload:
        return list(default)
    parsed = as_str_list(payload.get(key))
    if parsed is None:
        return None
    if not parsed and not allow_empty:
        return None
    return parsed


def resolve_path(
    workspace_root: Path,
    raw: str,
) -> tuple[Path, str] | None:
    """Resolve a workspace-relative path and return (abs, rel)."""
    resolved, _reason = resolve_path_checked(workspace_root, raw)
    return resolved


def resolve_path_checked(
    workspace_root: Path,
    raw: str,
    *,
    expect: str | None = None,
) -> tuple[tuple[Path, str] | None, str | None]:
    """Resolve a workspace-relative path with error reasons for tool errors."""
    candidate, reason = _parse_raw_path(raw)
    if reason is not None or candidate is None:
        return None, reason or "empty_path"
    root = workspace_root.resolve()
    resolved, reason = _normalize_candidate(root, candidate)
    if reason is not None or resolved is None:
        return None, reason or "resolve_error"
    reason = _check_expectation(resolved, expect)
    if reason is not None:
        return None, reason
    rel = resolved.relative_to(root).as_posix()
    return (resolved, rel), None


def _parse_raw_path(raw: str) -> tuple[Path | None, str | None]:
    stripped = raw.strip()
    if not stripped:
        return None, "empty_path"
    if stripped.startswith("~"):
        return None, "tilde_path"
    candidate = Path(raw)
    if candidate.is_absolute():
        return None, "absolute_path"
    return candidate, None


def _normalize_candidate(root: Path, candidate: Path) -> tuple[Path | None, str | None]:
    parts: list[str] = []
    for part in candidate.parts:
        if part in {"", "."}:
            continue
        if part == "..":
            if not parts:
                return None, "outside_workspace"
            parts.pop()
            continue
        parts.append(part)
        current = root.joinpath(*parts)
        if current.is_symlink():
            return None, "symlink_path"
    resolved = root.joinpath(*parts)
    return resolved, None


def _check_expectation(resolved: Path, expect: str | None) -> str | None:
    if expect is None:
        return None
    if expect not in {"any", "file", "dir"}:
        return "invalid_expectation"
    if not resolved.exists():
        return "not_found"
    if expect == "file" and not resolved.is_file():
        return "not_a_file"
    if expect == "dir" and not resolved.is_dir():
        return "not_a_dir"
    return None


def reason_details(
    reason: str | None,
    *,
    field: str | None = None,
) -> dict[str, JSONValue] | None:
    """Return optional error details for a reason/field pair."""
    if reason is None and field is None:
        return None
    details: dict[str, JSONValue] = {}
    if reason is not None:
        details["reason"] = reason
    if field is not None:
        details["field"] = field
    return details


def path_error_kind(reason: str | None) -> str:
    """Return the tool error kind for a path resolution failure."""
    if reason == "not_found":
        return NOT_FOUND_KIND
    return INVALID_INPUT_KIND


def build_page(
    *,
    cursor_kind: str,
    cursor: int,
    limit: int,
    returned: int,
    next_cursor: int | None,
) -> dict[str, JSONValue]:
    """Build a consistent page object for bounded tool outputs."""
    return {
        "cursor_kind": cursor_kind,
        "cursor": int(cursor),
        "limit": int(limit),
        "returned": int(returned),
        "has_more": next_cursor is not None,
        "next_cursor": int(next_cursor) if next_cursor is not None else None,
    }


def strip_ansi(text: str) -> str:
    """Strip ANSI color escape sequences."""
    return _ANSI_RE.sub("", text)


async def run_command(
    cmd: Sequence[str],
    *,
    cwd: str,
    env: Mapping[str, str],
    cancel_token: CancelToken | None = None,
) -> tuple[int, str, str]:
    """Run a command and capture stdout/stderr as UTF-8 text."""
    result = await run_subprocess(
        cmd,
        cwd=cwd,
        env=env,
        timeout_ms=None,
        cancel_token=cancel_token,
    )
    stdout_bytes = result.stdout
    stderr_bytes = result.stderr
    stdout_text = stdout_bytes.decode("utf-8", "replace") if stdout_bytes else ""
    stderr_text = stderr_bytes.decode("utf-8", "replace") if stderr_bytes else ""
    return int(result.exit_code), stdout_text, stderr_text


__all__ = (
    "INVALID_INPUT_KIND",
    "NOT_FOUND_KIND",
    "TOOL_ERROR_KIND",
    "build_safe_env",
    "error_output",
    "parse_bounded_int",
    "parse_optional_bool",
    "parse_optional_str_list",
    "path_error_kind",
    "reason_details",
    "resolve_path",
    "resolve_path_checked",
    "run_command",
    "strip_ansi",
    "success_output",
)
