"""rg schema + argument parsing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.limits import (
    RG_CONTEXT_MAX,
    RG_CONTEXT_MIN,
    RG_MAX_LINE_CHARS_DEFAULT,
    RG_MAX_LINE_CHARS_MAX,
    RG_MAX_LINE_CHARS_MIN,
    RG_MAX_MATCHES_DEFAULT,
    RG_MAX_MATCHES_MAX,
    RG_MAX_MATCHES_MIN,
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    error_output,
    parse_bounded_int,
    parse_optional_bool,
    parse_optional_str_list,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue

RG_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "rg search parameters.",
    "properties": {
        "pattern": {
            "type": "string",
            "description": "Search pattern (regex by default).",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Workspace-relative paths to search.",
            "default": ["."],
        },
        "literal": {
            "type": "boolean",
            "description": "Treat pattern as a literal string.",
            "default": False,
        },
        "case_sensitive": {
            "type": "boolean",
            "description": "Force case-sensitive search (overrides smart_case).",
            "default": False,
        },
        "smart_case": {
            "type": "boolean",
            "description": "Smart-case search when case_sensitive is false.",
            "default": False,
        },
        "before": {
            "type": "integer",
            "minimum": 0,
            "description": "Context lines before each match.",
            "default": RG_CONTEXT_MIN,
        },
        "after": {
            "type": "integer",
            "minimum": 0,
            "description": "Context lines after each match.",
            "default": RG_CONTEXT_MIN,
        },
        "context": {
            "type": "integer",
            "minimum": 0,
            "description": "If >0, overrides before/after with symmetric context.",
            "default": RG_CONTEXT_MIN,
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden files and directories.",
            "default": False,
        },
        "no_ignore": {
            "type": "boolean",
            "description": "Disable ignore files (e.g., .gitignore).",
            "default": False,
        },
        "glob": {
            "type": ["string", "array", "null"],
            "items": {"type": "string"},
            "description": "Glob filter(s) passed to rg -g.",
            "default": [],
        },
        "result_mode": {
            "type": "string",
            "enum": ["matches", "files", "count"],
            "description": "Result shape: matches, files, or count.",
            "default": "matches",
        },
        "offset": {
            "type": "integer",
            "minimum": 0,
            "description": "0-based paging offset.",
            "default": SAFE_OFFSET_MIN,
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "description": "Max results per page (bounded).",
            "default": RG_MAX_MATCHES_DEFAULT,
        },
        "max_line_chars": {
            "type": "integer",
            "minimum": 1,
            "description": "Max characters per matched/context line.",
            "default": RG_MAX_LINE_CHARS_DEFAULT,
        },
    },
    "required": ["pattern"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class RgArgs:
    """Parsed rg arguments."""

    pattern: str
    paths: list[str]
    literal: bool
    case_sensitive: bool
    smart_case: bool
    before: int
    after: int
    include_hidden: bool
    no_ignore: bool
    result_mode: str
    offset: int
    limit: int
    max_line_chars: int


@dataclass(frozen=True)
class RgCoreParts:
    """Parsed core rg arguments."""

    pattern: str
    paths: list[str]
    flags: tuple[bool, bool, bool, bool, bool]
    context_pair: tuple[int, int]
    mode: str


@dataclass(frozen=True)
class RgPagingParts:
    """Parsed rg pagination arguments."""

    pagination: tuple[int, int]
    glob_filters: list[str]
    max_chars: int


def _rg_error(message: str) -> str:
    return error_output("rg", kind=INVALID_INPUT_KIND, message=message)


def _parse_rg_payload(raw: str) -> tuple[dict[str, JSONValue] | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _rg_error("Invalid rg payload.")
    if set(payload) - {
        "pattern",
        "paths",
        "literal",
        "case_sensitive",
        "smart_case",
        "before",
        "after",
        "context",
        "include_hidden",
        "no_ignore",
        "glob",
        "result_mode",
        "offset",
        "limit",
        "max_line_chars",
    }:
        return None, _rg_error("Invalid rg payload.")
    return payload, None


def _parse_rg_paths(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str] | None, str | None]:
    paths = parse_optional_str_list(payload, key="paths", default=["."])
    if paths is None:
        return None, _rg_error("Invalid rg paths.")
    return paths, None


def _parse_rg_flags(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[bool, bool, bool, bool, bool] | None, str | None]:
    literal = parse_optional_bool(payload, key="literal", default=False)
    case_sensitive = parse_optional_bool(payload, key="case_sensitive", default=False)
    smart_case = parse_optional_bool(payload, key="smart_case", default=False)
    include_hidden = parse_optional_bool(payload, key="include_hidden", default=False)
    no_ignore = parse_optional_bool(payload, key="no_ignore", default=False)
    if (
        literal is None
        or case_sensitive is None
        or smart_case is None
        or include_hidden is None
        or no_ignore is None
    ):
        return None, _rg_error("Invalid rg flags.")
    return (literal, case_sensitive, smart_case, include_hidden, no_ignore), None


def _parse_rg_context(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int] | None, str | None]:
    before = parse_bounded_int(
        payload.get("before"),
        default=RG_CONTEXT_MIN,
        min_value=RG_CONTEXT_MIN,
        max_value=RG_CONTEXT_MAX,
    )
    after = parse_bounded_int(
        payload.get("after"),
        default=RG_CONTEXT_MIN,
        min_value=RG_CONTEXT_MIN,
        max_value=RG_CONTEXT_MAX,
    )
    context = parse_bounded_int(
        payload.get("context"),
        default=RG_CONTEXT_MIN,
        min_value=RG_CONTEXT_MIN,
        max_value=RG_CONTEXT_MAX,
    )
    if before is None or after is None or context is None:
        return None, _rg_error("Invalid rg context bounds.")
    if context > 0:
        return (context, context), None
    return (before, after), None


def _parse_rg_mode(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, str | None]:
    mode = as_str(payload.get("result_mode")) or "matches"
    if mode not in {"matches", "files", "count"}:
        return None, _rg_error("Invalid rg result_mode.")
    return mode, None


def _parse_rg_pagination(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int] | None, str | None]:
    offset_val = parse_bounded_int(
        payload.get("offset"),
        default=SAFE_OFFSET_MIN,
        min_value=SAFE_OFFSET_MIN,
        max_value=SAFE_OFFSET_MAX,
    )
    limit_val = parse_bounded_int(
        payload.get("limit"),
        default=RG_MAX_MATCHES_DEFAULT,
        min_value=RG_MAX_MATCHES_MIN,
        max_value=RG_MAX_MATCHES_MAX,
    )
    if offset_val is None or limit_val is None:
        return None, _rg_error("Invalid rg pagination bounds.")
    return (offset_val, limit_val), None


def _parse_rg_glob_filters(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str] | None, str | None]:
    glob_raw = payload.get("glob")
    if isinstance(glob_raw, str):
        return [glob_raw], None
    if isinstance(glob_raw, list):
        glob_filters = parse_optional_str_list(
            payload,
            key="glob",
            default=[],
            allow_empty=True,
        )
        if glob_filters is None:
            return None, _rg_error("Invalid rg glob filter.")
        return glob_filters, None
    if glob_raw is not None:
        return None, _rg_error("Invalid rg glob filter.")
    return [], None


def _parse_rg_max_line_chars(
    payload: Mapping[str, JSONValue],
) -> tuple[int | None, str | None]:
    max_chars = parse_bounded_int(
        payload.get("max_line_chars"),
        default=RG_MAX_LINE_CHARS_DEFAULT,
        min_value=RG_MAX_LINE_CHARS_MIN,
        max_value=RG_MAX_LINE_CHARS_MAX,
    )
    if max_chars is None:
        return None, _rg_error("Invalid rg max_line_chars.")
    return max_chars, None


def _parse_rg_core(
    payload: Mapping[str, JSONValue],
) -> tuple[RgCoreParts | None, str | None]:
    pattern = as_str(payload.get("pattern"))
    if pattern is None or pattern == "":
        return None, _rg_error("rg requires a pattern.")
    paths, error = _parse_rg_paths(payload)
    if error is not None or paths is None:
        return None, error or _rg_error("Invalid rg payload.")
    flags, error = _parse_rg_flags(payload)
    if error is not None or flags is None:
        return None, error or _rg_error("Invalid rg payload.")
    context_pair, error = _parse_rg_context(payload)
    if error is not None or context_pair is None:
        return None, error or _rg_error("Invalid rg payload.")
    mode, error = _parse_rg_mode(payload)
    if error is not None or mode is None:
        return None, error or _rg_error("Invalid rg payload.")
    return (
        RgCoreParts(
            pattern=pattern,
            paths=paths,
            flags=flags,
            context_pair=context_pair,
            mode=mode,
        ),
        None,
    )


def _parse_rg_paging(
    payload: Mapping[str, JSONValue],
) -> tuple[RgPagingParts | None, str | None]:
    pagination, error = _parse_rg_pagination(payload)
    if error is not None or pagination is None:
        return None, error or _rg_error("Invalid rg payload.")
    glob_filters, error = _parse_rg_glob_filters(payload)
    if error is not None or glob_filters is None:
        return None, error or _rg_error("Invalid rg payload.")
    max_chars, error = _parse_rg_max_line_chars(payload)
    if error is not None or max_chars is None:
        return None, error or _rg_error("Invalid rg payload.")
    return (
        RgPagingParts(
            pagination=pagination,
            glob_filters=glob_filters,
            max_chars=max_chars,
        ),
        None,
    )


def _parse_rg_args_payload(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[RgArgs, list[str]] | None, str | None]:
    core, error = _parse_rg_core(payload)
    if error is not None or core is None:
        return None, error or _rg_error("Invalid rg payload.")
    paging, error = _parse_rg_paging(payload)
    if error is not None or paging is None:
        return None, error or _rg_error("Invalid rg payload.")
    literal, case_sensitive, smart_case, include_hidden, no_ignore = core.flags
    before, after = core.context_pair
    offset, limit = paging.pagination
    return (
        (
            RgArgs(
                pattern=core.pattern,
                paths=core.paths,
                literal=literal,
                case_sensitive=case_sensitive,
                smart_case=smart_case,
                before=before,
                after=after,
                include_hidden=include_hidden,
                no_ignore=no_ignore,
                result_mode=core.mode,
                offset=offset,
                limit=limit,
                max_line_chars=paging.max_chars,
            ),
            paging.glob_filters,
        ),
        None,
    )


def parse_rg_args(raw: str) -> tuple[tuple[RgArgs, list[str]] | None, str | None]:
    """Parse rg arguments + glob filters from a raw JSON payload string."""
    payload, error = _parse_rg_payload(raw)
    if error is not None or payload is None:
        return None, error or _rg_error("Invalid rg payload.")
    return _parse_rg_args_payload(payload)


__all__ = ("RG_SCHEMA", "RgArgs", "parse_rg_args")
