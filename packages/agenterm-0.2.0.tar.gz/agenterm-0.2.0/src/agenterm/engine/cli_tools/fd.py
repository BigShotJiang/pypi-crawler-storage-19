"""fd local CLI tool implementation."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    FD_MAX_DEPTH_MAX,
    FD_MAX_DEPTH_MIN,
    FD_MAX_RESULTS_DEFAULT,
    FD_MAX_RESULTS_MAX,
    FD_MAX_RESULTS_MIN,
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    build_safe_env,
    error_output,
    parse_bounded_int,
    parse_optional_bool,
    parse_optional_str_list,
    path_error_kind,
    reason_details,
    resolve_path,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import FdToolConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_FD_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "fd file discovery parameters.",
    "properties": {
        "pattern": {
            "type": ["string", "null"],
            "description": "Pattern to match; null matches all.",
        },
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Workspace-relative search roots.",
            "default": ["."],
        },
        "max_depth": {
            "type": ["integer", "null"],
            "minimum": FD_MAX_DEPTH_MIN,
            "maximum": FD_MAX_DEPTH_MAX,
            "description": "Maximum search depth; null means no limit.",
        },
        "mode": {
            "type": "string",
            "enum": ["regex", "glob", "fixed"],
            "description": "Pattern mode: regex (default), glob, or fixed.",
            "default": "regex",
        },
        "type": {
            "type": "string",
            "enum": ["file", "dir", "symlink", "any"],
            "description": "Filter by entry type.",
            "default": "any",
        },
        "include_hidden": {
            "type": "boolean",
            "description": "Include hidden files and directories.",
            "default": False,
        },
        "no_ignore": {
            "type": "boolean",
            "description": "Disable ignore files (e.g., .gitignore).",
            "default": False,
        },
        "exclude": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Exclude glob patterns.",
            "default": [],
        },
        "offset": {
            "type": "integer",
            "minimum": 0,
            "description": "0-based paging offset.",
            "default": SAFE_OFFSET_MIN,
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "description": "Max results per page (bounded).",
            "default": FD_MAX_RESULTS_DEFAULT,
        },
    },
    "additionalProperties": False,
}


@dataclass(frozen=True)
class FdArgs:
    """Parsed fd arguments."""

    pattern: str | None
    paths: list[str]
    max_depth: int | None
    mode: str
    type_filter: str
    include_hidden: bool
    no_ignore: bool
    exclude: list[str]
    offset: int
    limit: int


def _fd_error(message: str) -> str:
    return error_output("fd", kind=INVALID_INPUT_KIND, message=message)


def _parse_fd_payload(raw: str) -> tuple[dict[str, JSONValue] | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _fd_error("Invalid fd payload.")
    if set(payload) - {
        "pattern",
        "paths",
        "max_depth",
        "mode",
        "type",
        "include_hidden",
        "no_ignore",
        "exclude",
        "offset",
        "limit",
    }:
        return None, _fd_error("Invalid fd payload.")
    return payload, None


def _parse_fd_pattern(
    payload: Mapping[str, JSONValue],
) -> tuple[str | None, str | None]:
    pattern_obj = payload.get("pattern")
    if pattern_obj is None:
        return None, None
    pattern = as_str(pattern_obj)
    if pattern is None or pattern == "":
        return None, _fd_error("Invalid fd pattern.")
    return pattern, None


def _parse_fd_paths(
    payload: Mapping[str, JSONValue],
) -> tuple[list[str] | None, str | None]:
    paths = parse_optional_str_list(payload, key="paths", default=["."])
    if paths is None:
        return None, _fd_error("Invalid fd paths.")
    return paths, None


def _parse_fd_max_depth(
    payload: Mapping[str, JSONValue],
) -> tuple[int | None, str | None]:
    if "max_depth" not in payload:
        return None, None
    max_depth_raw = payload.get("max_depth")
    if max_depth_raw is None:
        return None, None
    max_depth = parse_bounded_int(
        max_depth_raw,
        default=FD_MAX_DEPTH_MIN,
        min_value=FD_MAX_DEPTH_MIN,
        max_value=FD_MAX_DEPTH_MAX,
    )
    if max_depth is None:
        return None, _fd_error("Invalid fd max_depth.")
    return max_depth, None


def _parse_fd_mode(payload: Mapping[str, JSONValue]) -> tuple[str | None, str | None]:
    mode = as_str(payload.get("mode")) or "regex"
    if mode not in {"regex", "glob", "fixed"}:
        return None, _fd_error("Invalid fd mode.")
    return mode, None


def _parse_fd_type(payload: Mapping[str, JSONValue]) -> tuple[str | None, str | None]:
    type_filter = as_str(payload.get("type")) or "any"
    if type_filter not in {"file", "dir", "symlink", "any"}:
        return None, _fd_error("Invalid fd type.")
    return type_filter, None


def _parse_fd_flags(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[bool, bool, list[str]] | None, str | None]:
    include_hidden = parse_optional_bool(payload, key="include_hidden", default=False)
    no_ignore = parse_optional_bool(payload, key="no_ignore", default=False)
    if include_hidden is None or no_ignore is None:
        return None, _fd_error("Invalid fd flags.")
    exclude = parse_optional_str_list(
        payload,
        key="exclude",
        default=[],
        allow_empty=True,
    )
    if exclude is None:
        return None, _fd_error("Invalid fd exclude list.")
    return (include_hidden, no_ignore, exclude), None


def _parse_fd_pagination(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[int, int] | None, str | None]:
    offset = parse_bounded_int(
        payload.get("offset"),
        default=SAFE_OFFSET_MIN,
        min_value=SAFE_OFFSET_MIN,
        max_value=SAFE_OFFSET_MAX,
    )
    limit = parse_bounded_int(
        payload.get("limit"),
        default=FD_MAX_RESULTS_DEFAULT,
        min_value=FD_MAX_RESULTS_MIN,
        max_value=FD_MAX_RESULTS_MAX,
    )
    if offset is None or limit is None:
        return None, _fd_error("Invalid fd pagination.")
    return (offset, limit), None


def _parse_fd_args(raw: str) -> tuple[FdArgs | None, str | None]:
    payload: dict[str, JSONValue] | None = None
    error: str | None = None
    pattern: str | None = None
    paths: list[str] | None = None
    max_depth: int | None = None
    mode: str | None = None
    type_filter: str | None = None
    flags: tuple[bool, bool, list[str]] | None = None
    pagination: tuple[int, int] | None = None

    payload, error = _parse_fd_payload(raw)
    if error is None and payload is not None:
        pattern, error = _parse_fd_pattern(payload)
    if error is None and payload is not None:
        paths, error = _parse_fd_paths(payload)
    if error is None and payload is not None:
        max_depth, error = _parse_fd_max_depth(payload)
    if error is None and payload is not None:
        mode, error = _parse_fd_mode(payload)
    if error is None and payload is not None:
        type_filter, error = _parse_fd_type(payload)
    if error is None and payload is not None:
        flags, error = _parse_fd_flags(payload)
    if error is None and payload is not None:
        pagination, error = _parse_fd_pagination(payload)

    if error is not None:
        return None, error
    if (
        payload is None
        or paths is None
        or mode is None
        or type_filter is None
        or flags is None
        or pagination is None
    ):
        return None, _fd_error("Invalid fd payload.")
    include_hidden, no_ignore, exclude = flags
    offset, limit = pagination
    return (
        FdArgs(
            pattern=pattern,
            paths=paths,
            max_depth=max_depth,
            mode=mode,
            type_filter=type_filter,
            include_hidden=include_hidden,
            no_ignore=no_ignore,
            exclude=exclude,
            offset=offset,
            limit=limit,
        ),
        None,
    )


def _resolve_paths(
    workspace_root: Path, paths: Iterable[str]
) -> tuple[list[str] | None, str | None]:
    resolved: list[str] = []
    for raw in paths:
        resolved_pair, reason = resolve_path_checked(workspace_root, raw, expect="any")
        if resolved_pair is None:
            return None, reason or "invalid_path"
        _abs_path, rel = resolved_pair
        resolved.append(rel)
    return resolved, None


def _fd_command(
    args: FdArgs,
    *,
    resolved_paths: list[str],
    max_results: int,
) -> list[str]:
    cmd: list[str] = ["fd", "--color=never", "--max-results", str(max_results)]
    if args.max_depth is not None:
        cmd.extend(["--max-depth", str(args.max_depth)])
    if args.mode == "glob":
        cmd.append("--glob")
    elif args.mode == "fixed":
        cmd.append("--fixed-strings")
    if args.include_hidden:
        cmd.append("--hidden")
    if args.no_ignore:
        cmd.append("--no-ignore")
    if args.type_filter != "any":
        cmd.extend(["--type", args.type_filter])
    for exclude in args.exclude:
        cmd.extend(["--exclude", exclude])
    for path in resolved_paths:
        cmd.extend(["--search-path", path])
    if args.pattern is not None:
        cmd.append(args.pattern)
    return cmd


def _parse_fd_output(
    stdout_text: str,
    *,
    workspace_root: Path,
) -> list[str]:
    matches: list[str] = []
    for line in stdout_text.splitlines():
        candidate = line.strip()
        if not candidate:
            continue
        resolved = resolve_path(workspace_root, candidate)
        if resolved is None:
            continue
        _abs_path, rel = resolved
        matches.append(rel)
    return matches


def _stable_matches(matches: list[str]) -> list[str]:
    return sorted(set(matches))


def build_fd_tool(
    cfg: FdToolConfig | None,
    *,
    workspace_root: Path,
) -> FunctionTool | None:
    """Build the fd tool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("fd", _FD_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        args, error = _parse_fd_args(raw)
        if error is not None:
            return error
        if args is None:
            return error_output(
                "fd",
                kind=INVALID_INPUT_KIND,
                message="Invalid fd payload.",
            )
        resolved_paths, reason = await asyncio.to_thread(
            _resolve_paths, workspace_root, args.paths
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if reason is not None or resolved_paths is None:
            return error_output(
                "fd",
                kind=path_error_kind(reason),
                message="Invalid fd path.",
                details=reason_details(reason, field="paths"),
            )
        max_results = min(FD_MAX_RESULTS_MAX, args.offset + args.limit)
        cmd = _fd_command(
            args,
            resolved_paths=resolved_paths,
            max_results=max_results,
        )
        exit_code, stdout_text, _stderr_text = await run_command(
            cmd,
            cwd=str(workspace_root),
            env=build_safe_env(),
            cancel_token=cancel_token,
        )
        if exit_code != 0:
            return error_output(
                "fd",
                kind=TOOL_ERROR_KIND,
                message="Failed to list files.",
                details=reason_details("command_failed"),
            )
        matches = await asyncio.to_thread(
            _parse_fd_output, stdout_text, workspace_root=workspace_root
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        stable = _stable_matches(matches)
        total = len(stable)
        sliced = (
            list(stable[args.offset : args.offset + args.limit])
            if args.offset < total
            else []
        )
        returned = len(sliced)
        page_has_more = args.offset + returned < total
        next_cursor = args.offset + returned if page_has_more else None
        page = build_page(
            cursor_kind="offset",
            cursor=args.offset,
            limit=args.limit,
            returned=returned,
            next_cursor=next_cursor,
        )
        capped = len(matches) >= max_results
        stats_complete = not capped
        stats_reason = "result_cap" if capped else None
        matches_json: list[JSONValue] = list(sliced)
        payload: dict[str, JSONValue] = {
            "pattern": args.pattern,
            "matches": matches_json,
            "page": page,
            "coverage": {
                "stats_complete": stats_complete,
                "stats_partial_reason": stats_reason,
            },
        }
        return success_output("fd", payload)

    return FunctionTool(
        name="fd",
        description=(
            "Find files and directories under the workspace with fd; use for "
            "bounded discovery.\n"
            "Inputs: pattern (regex/glob/fixed), paths, max_depth, type, "
            "include_hidden/no_ignore, exclude, offset/limit.\n"
            "Outputs: matches plus page and coverage.\n"
            "Errors: invalid_input for bad payload/paths; "
            "tool_error for command failures."
        ),
        params_json_schema=_FD_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_fd_tool",)
