"""bat local CLI tool implementation."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from functools import partial
from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    BAT_MAX_BYTES_DEFAULT,
    BAT_MAX_BYTES_MAX,
    BAT_MAX_BYTES_MIN,
    BAT_MAX_LINES_DEFAULT,
    BAT_MAX_LINES_MAX,
    BAT_MAX_LINES_MIN,
    BAT_START_LINE_MAX,
    BAT_START_LINE_MIN,
)
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    build_page,
    build_safe_env,
    error_output,
    parse_bounded_int,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import BatToolConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_BAT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "bat file preview parameters.",
    "properties": {
        "path": {
            "type": "string",
            "description": "Workspace-relative file path.",
        },
        "start_line": {
            "type": "integer",
            "minimum": 1,
            "description": "1-based starting line.",
            "default": BAT_START_LINE_MIN,
        },
        "limit_lines": {
            "type": "integer",
            "minimum": 1,
            "description": "Max lines to return (bounded).",
            "default": BAT_MAX_LINES_DEFAULT,
        },
        "max_bytes": {
            "type": "integer",
            "minimum": 1,
            "description": "Max UTF-8 bytes returned across lines.",
            "default": BAT_MAX_BYTES_DEFAULT,
        },
    },
    "required": ["path"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class BatArgs:
    """Parsed bat arguments."""

    path: str
    start_line: int
    limit_lines: int
    max_bytes: int


def _bat_error(message: str) -> str:
    return error_output("bat", kind=INVALID_INPUT_KIND, message=message)


def _parse_bat_args(raw: str) -> tuple[BatArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _bat_error("Invalid bat payload.")
    if set(payload) - {"path", "start_line", "limit_lines", "max_bytes"}:
        return None, _bat_error("Invalid bat payload.")
    path = as_str(payload.get("path"))
    if path is None or path == "":
        return None, _bat_error("bat requires a path.")
    start_line = parse_bounded_int(
        payload.get("start_line"),
        default=BAT_START_LINE_MIN,
        min_value=BAT_START_LINE_MIN,
        max_value=BAT_START_LINE_MAX,
    )
    limit_lines = parse_bounded_int(
        payload.get("limit_lines"),
        default=BAT_MAX_LINES_DEFAULT,
        min_value=BAT_MAX_LINES_MIN,
        max_value=BAT_MAX_LINES_MAX,
    )
    max_bytes = parse_bounded_int(
        payload.get("max_bytes"),
        default=BAT_MAX_BYTES_DEFAULT,
        min_value=BAT_MAX_BYTES_MIN,
        max_value=BAT_MAX_BYTES_MAX,
    )
    if start_line is None or limit_lines is None or max_bytes is None:
        return None, _bat_error("Invalid bat bounds.")
    return (
        BatArgs(
            path=path,
            start_line=start_line,
            limit_lines=limit_lines,
            max_bytes=max_bytes,
        ),
        None,
    )


def _bat_command(args: BatArgs, *, rel_path: str) -> list[str]:
    end_line = args.start_line + args.limit_lines
    return [
        "bat",
        "--color=never",
        "--decorations=always",
        "--paging=never",
        "--wrap=never",
        "--style=numbers",
        "--line-range",
        f"{args.start_line}:{end_line}",
        rel_path,
    ]


def _count_lines(path: Path) -> int:
    count = 0
    last_byte: int | None = None
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(64 * 1024), b""):
            count += chunk.count(b"\n")
            if chunk:
                last_byte = chunk[-1]
    if last_byte is None:
        return 0
    if last_byte != ord("\n"):
        count += 1
    return count


def _parse_bat_output(
    stdout_text: str,
    *,
    args: BatArgs,
    rel_path: str,
) -> dict[str, JSONValue]:
    lines_out: list[dict[str, JSONValue]] = []
    bytes_used = 0
    has_more = False
    next_line: int | None = None
    for raw_line in stdout_text.splitlines():
        stripped = raw_line.lstrip()
        if not stripped:
            continue
        num_str, sep, rest = stripped.partition(" ")
        if sep == "" or not num_str.isdigit():
            continue
        line_no = int(num_str)
        if len(lines_out) >= args.limit_lines:
            has_more = True
            next_line = line_no
            break
        text_out = rest
        line_bytes = len(text_out.encode("utf-8"))
        if lines_out:
            line_bytes += 1
        if bytes_used + line_bytes > args.max_bytes:
            has_more = True
            next_line = line_no
            break
        bytes_used += line_bytes
        lines_out.append({"line": line_no, "text": text_out})
    lines_json: list[JSONValue] = list(lines_out)
    page = build_page(
        cursor_kind="line",
        cursor=args.start_line,
        limit=args.limit_lines,
        returned=len(lines_out),
        next_cursor=next_line if has_more else None,
    )
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "lines": lines_json,
        "bytes": bytes_used,
        "page": page,
    }
    return payload


async def _bat_payload_from_args(
    *,
    args: BatArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    resolved, reason = await asyncio.to_thread(
        resolve_path_checked,
        workspace_root,
        args.path,
        expect="file",
    )
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    if resolved is None:
        return None, error_output(
            "bat",
            kind=path_error_kind(reason),
            message="Invalid bat path.",
            details=reason_details(reason, field="path"),
        )
    abs_path, rel_path = resolved
    try:
        total_lines = await asyncio.to_thread(_count_lines, abs_path)
    except OSError:
        total_lines = None
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    if total_lines is None:
        return None, error_output(
            "bat",
            kind=TOOL_ERROR_KIND,
            message="Failed to read file.",
            details=reason_details("count_failed"),
        )
    if args.start_line > total_lines:
        details = reason_details("out_of_range", field="start_line") or {}
        details["total_lines"] = int(total_lines)
        return None, error_output(
            "bat",
            kind=INVALID_INPUT_KIND,
            message="Invalid bat start_line.",
            details=details,
        )
    cmd = _bat_command(args, rel_path=rel_path)
    exit_code, stdout_text, _stderr_text = await run_command(
        cmd,
        cwd=str(workspace_root),
        env=build_safe_env(),
        cancel_token=cancel_token,
    )
    if exit_code != 0:
        return None, error_output(
            "bat",
            kind=TOOL_ERROR_KIND,
            message="Failed to read file.",
            details=reason_details("command_failed"),
        )
    payload = _parse_bat_output(
        stdout_text,
        args=args,
        rel_path=rel_path,
    )
    payload["total_lines"] = int(total_lines)
    return payload, None


async def _invoke_bat(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    args, error = _parse_bat_args(raw)
    if error is not None:
        return error
    if args is None:
        return error_output(
            "bat",
            kind=INVALID_INPUT_KIND,
            message="Invalid bat payload.",
        )
    payload, error = await _bat_payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _bat_error("Invalid bat payload.")
    return success_output("bat", payload)


def build_bat_tool(
    cfg: BatToolConfig | None,
    *,
    workspace_root: Path,
) -> FunctionTool | None:
    """Build the bat tool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("bat", _BAT_SCHEMA)

    return FunctionTool(
        name="bat",
        description=(
            "Preview file contents with line numbers; use for bounded file reads.\n"
            "Inputs: path (workspace-relative), start_line, limit_lines, max_bytes.\n"
            "Outputs: lines, total_lines, bytes, and page cursor.\n"
            "Errors: invalid_input for bad payload/path or out-of-range start_line; "
            "tool_error for read/command failures."
        ),
        params_json_schema=_BAT_SCHEMA,
        on_invoke_tool=partial(_invoke_bat, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_bat_tool",)
