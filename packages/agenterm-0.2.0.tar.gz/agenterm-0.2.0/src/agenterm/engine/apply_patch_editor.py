"""Workspace-scoped ApplyPatchEditor integrating approvals."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING

from agents.apply_diff import apply_diff
from agents.editor import ApplyPatchEditor, ApplyPatchOperation, ApplyPatchResult
from agents.tool_context import ToolContext

from agenterm.core.errors import ToolExecutionError
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.core.plan import ToolRuntimeContext

if TYPE_CHECKING:
    from agenterm.core.approvals import PatchApprovalManager
    from agenterm.core.cancellation import CancelToken


def _rejection_output(reason: str | None) -> str:
    base = "Apply patch operation rejected by user."
    return f"{base}\nReason: {reason}" if reason else base


def _apply_patch_failure_hints(reason: str) -> list[str]:
    lowered = reason.lower()
    if "invalid context" in lowered or "invalid eof context" in lowered:
        return [
            "hint> diff context did not match the file; rebase the patch "
            "on current contents.",
            "hint> use /last diff full to inspect the patch.",
        ]
    if "invalid add file line" in lowered:
        return ["hint> create_file diffs must contain only '+' lines."]
    return []


def _apply_patch_failure_output(reason: str, *, op_type: str, relative: str) -> str:
    label = op_type.replace("_", " ")
    reason = reason.strip()
    lines = [f"Apply patch failed ({label} {relative})."]
    if reason:
        lines.append(f"Reason: {reason}")
    lines.extend(_apply_patch_failure_hints(reason))
    return "\n".join(lines)


def _apply_patch_failure_result(
    *,
    reason: str,
    op_type: str,
    relative: str,
) -> ApplyPatchResult:
    return ApplyPatchResult(
        status="failed",
        output=_apply_patch_failure_output(reason, op_type=op_type, relative=relative),
    )


def _extract_description(operation: ApplyPatchOperation) -> str | None:
    ctx = operation.ctx_wrapper
    if not isinstance(ctx, ToolContext):
        return None
    raw = ctx.tool_arguments
    if not raw:
        return None
    payload = parse_json_object(raw)
    if payload is None:
        return None
    description = as_str(payload.get("description"))
    if description is None:
        return None
    cleaned = description.strip()
    return cleaned if cleaned else None


def _extract_cancel_token(operation: ApplyPatchOperation) -> CancelToken | None:
    ctx = operation.ctx_wrapper
    if not isinstance(ctx, ToolContext):
        return None
    runtime = ctx.context
    if not isinstance(runtime, ToolRuntimeContext):
        return None
    return runtime.cancel_token


class WorkspaceEditor(ApplyPatchEditor):
    """Workspace-scoped ApplyPatchEditor with approval integration."""

    def __init__(
        self,
        root: Path,
        approvals: PatchApprovalManager,
    ) -> None:
        """Initialize editor rooted at `root` with approval manager."""
        self._root = root.resolve()
        self._approvals = approvals

    async def create_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Create a new file after approval, applying the provided diff."""
        cancel_token = _extract_cancel_token(operation)
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        relative = self._relative_path(operation.path)
        description = _extract_description(operation)
        item = self._approvals.register(
            operation.type,
            relative,
            operation.diff or "",
            description=description,
        )
        decision = await self._approvals.wait(item.id, cancel_token=cancel_token)
        if not decision.approved:
            return ApplyPatchResult(
                status="failed",
                output=_rejection_output(decision.reason),
            )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        target = self._resolve(operation.path)
        diff = operation.diff or ""
        try:
            content = apply_diff("", diff, mode="create")
        except ValueError as exc:
            return _apply_patch_failure_result(
                reason=str(exc),
                op_type=operation.type,
                relative=relative,
            )
        try:
            await asyncio.to_thread(target.parent.mkdir, parents=True, exist_ok=True)
            await asyncio.to_thread(target.write_text, content, encoding="utf-8")
        except OSError as exc:
            return _apply_patch_failure_result(
                reason=f"Failed to write file: {exc}",
                op_type=operation.type,
                relative=relative,
            )
        return ApplyPatchResult(
            status="completed",
            output=f"Created {relative}",
        )

    async def update_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Update an existing file after approval."""
        cancel_token = _extract_cancel_token(operation)
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        relative = self._relative_path(operation.path)
        description = _extract_description(operation)
        item = self._approvals.register(
            operation.type,
            relative,
            operation.diff or "",
            description=description,
        )
        decision = await self._approvals.wait(item.id, cancel_token=cancel_token)
        if not decision.approved:
            return ApplyPatchResult(
                status="failed",
                output=_rejection_output(decision.reason),
            )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        target = self._resolve(operation.path)
        try:
            original = await asyncio.to_thread(target.read_text, encoding="utf-8")
        except OSError as exc:
            return _apply_patch_failure_result(
                reason=f"Failed to read file: {exc}",
                op_type=operation.type,
                relative=relative,
            )
        diff = operation.diff or ""
        try:
            patched = apply_diff(original, diff)
        except ValueError as exc:
            return _apply_patch_failure_result(
                reason=str(exc),
                op_type=operation.type,
                relative=relative,
            )
        try:
            await asyncio.to_thread(target.write_text, patched, encoding="utf-8")
        except OSError as exc:
            return _apply_patch_failure_result(
                reason=f"Failed to write file: {exc}",
                op_type=operation.type,
                relative=relative,
            )
        return ApplyPatchResult(
            status="completed",
            output=f"Updated {relative}",
        )

    async def delete_file(self, operation: ApplyPatchOperation) -> ApplyPatchResult:
        """Delete a file after approval."""
        cancel_token = _extract_cancel_token(operation)
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        relative = self._relative_path(operation.path)
        description = _extract_description(operation)
        item = self._approvals.register(
            operation.type,
            relative,
            operation.diff or "",
            description=description,
        )
        decision = await self._approvals.wait(item.id, cancel_token=cancel_token)
        if not decision.approved:
            return ApplyPatchResult(
                status="failed",
                output=_rejection_output(decision.reason),
            )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        target = self._resolve(operation.path)
        try:
            await asyncio.to_thread(target.unlink, missing_ok=True)
        except OSError as exc:
            return _apply_patch_failure_result(
                reason=f"Failed to delete file: {exc}",
                op_type=operation.type,
                relative=relative,
            )
        return ApplyPatchResult(
            status="completed",
            output=f"Deleted {relative}",
        )

    def _relative_path(self, value: str) -> str:
        resolved = self._resolve(value)
        return resolved.relative_to(self._root).as_posix()

    def _resolve(self, value: str) -> Path:
        candidate = Path(value)
        target = candidate if candidate.is_absolute() else (self._root / candidate)
        target = target.resolve()
        try:
            target.relative_to(self._root)
        except ValueError as exc:
            message = f"Operation outside workspace: {value}"
            raise ToolExecutionError(message) from exc
        return target
