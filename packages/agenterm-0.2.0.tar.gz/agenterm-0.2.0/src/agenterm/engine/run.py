"""Execution wrappers around Agents Runner.

These helpers provide a single path for run execution and are responsible
for mapping low-level SDK exceptions into the CLI's AgentermError hierarchy.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agents.exceptions import AgentsException, MaxTurnsExceeded
from agents.run import RunConfig, Runner
from openai import APIError

from agenterm.core.errors import PipelineError
from agenterm.core.model_id import is_openai_model_id, model_plane
from agenterm.core.openai_client import get_openai_client
from agenterm.engine.history_packing import (
    HistoryPackingOptions,
    build_session_input_callback,
)
from agenterm.engine.run_config import build_run_config
from agenterm.engine.run_errors import format_agents_error, format_provider_error
from agenterm.store.session.agenterm_session import AgentermSQLiteSession
from agenterm.store.session.service import DEFAULT_SESSION_INPUT_CALLBACK

if TYPE_CHECKING:
    from agents.agent import Agent
    from agents.items import TResponseInputItem
    from agents.memory import Session
    from agents.result import RunResult, RunResultStreaming

    from agenterm.config.model import AppConfig
    from agenterm.core.plan import ToolRuntimeContext


def _needs_openai_client(model_id: str) -> bool:
    return is_openai_model_id(model_id)


def _apply_session_input_callback(
    run_cfg: RunConfig,
    *,
    opts: RunExecOptions,
    model_id: str,
) -> RunConfig:
    if opts.session is None:
        return run_cfg
    if not isinstance(opts.session, AgentermSQLiteSession):
        return run_cfg
    history_packing = opts.history_packing or HistoryPackingOptions(
        interactive=False,
        approvals=None,
    )
    callback = build_session_input_callback(
        cfg=opts.cfg,
        session=opts.session,
        model_id=model_id,
        options=history_packing,
    )
    return replace(run_cfg, session_input_callback=callback)


def _apply_response_include_override(
    run_cfg: RunConfig,
    *,
    opts: RunExecOptions,
) -> RunConfig:
    if opts.response_include is None:
        return run_cfg
    ms = run_cfg.model_settings or opts.cfg.to_model_settings()
    ms = replace(ms, response_include=list(opts.response_include))
    return replace(run_cfg, model_settings=ms)


@dataclass(frozen=True)
class RunExecOptions:
    """Immutable execution options shared by run_once and run_streamed."""

    cfg: AppConfig
    workflow_name: str = "agenterm run"
    session: Session | None = None
    background: bool = False
    tool_context: ToolRuntimeContext | None = None
    model_id: str | None = None
    max_turns: int | None = None
    history_packing: HistoryPackingOptions | None = None
    response_include: tuple[str, ...] | None = None


async def run_once(
    agent: Agent,
    input_items: str | list[TResponseInputItem],
    *,
    opts: RunExecOptions,
) -> RunResult:
    """Execute a single non-streaming agent run.

    SDK-specific exceptions are wrapped in AgentermError so edges can handle
    failures uniformly.
    """
    effective_model = opts.model_id or opts.cfg.agent.model
    provider_label = model_plane(effective_model)
    if _needs_openai_client(effective_model):
        get_openai_client()
    cfg = opts.cfg
    run_cfg = build_run_config(
        cfg,
        workflow_name=opts.workflow_name,
        model_id=effective_model,
    )
    max_turns = opts.max_turns if opts.max_turns is not None else cfg.agent.max_turns
    if opts.background:
        # When running in background mode, we rely on the Responses API
        # `background` flag. This is plumbed via ModelSettings.extra_args
        # so the engine path remains single and based on Agents.
        ms = run_cfg.model_settings or cfg.to_model_settings()
        extra_args = dict(ms.extra_args or {})
        extra_args["background"] = True
        # Background responses must be stored server-side so they can be
        # inspected later.
        ms = replace(ms, extra_args=extra_args, store=True)
        # Background runs require provider-side persistence, but can still be
        # invoked in stateless input mode (e.g., a compaction reseed run).
        run_cfg = replace(
            run_cfg,
            model_settings=ms,
            session_input_callback=DEFAULT_SESSION_INPUT_CALLBACK,
        )
    run_cfg = _apply_session_input_callback(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg = _apply_response_include_override(run_cfg, opts=opts)

    try:

        async def _do_run() -> RunResult:
            return await Runner.run(
                starting_agent=agent,
                input=input_items,
                max_turns=max_turns,
                previous_response_id=None,
                auto_previous_response_id=False,
                conversation_id=None,
                run_config=run_cfg,
                session=opts.session,
                context=opts.tool_context,
            )

        return await _do_run()
    except APIError as exc:
        # Normalize OpenAI client errors into a single PipelineError with a
        # user-facing message derived from the concrete error subclass.
        raise PipelineError(
            format_provider_error(exc, provider_label=provider_label)
        ) from exc
    except MaxTurnsExceeded:
        raise
    except AgentsException as exc:
        raise PipelineError(format_agents_error(exc)) from exc


def run_streamed(
    agent: Agent,
    input_items: str | list[TResponseInputItem],
    *,
    opts: RunExecOptions,
) -> RunResultStreaming:
    """Execute a streaming agent run and return the streaming handle."""
    effective_model = opts.model_id or opts.cfg.agent.model
    provider_label = model_plane(effective_model)
    if _needs_openai_client(effective_model):
        get_openai_client()
    cfg = opts.cfg
    run_cfg = build_run_config(
        cfg,
        workflow_name=opts.workflow_name,
        model_id=effective_model,
    )
    run_cfg = _apply_session_input_callback(
        run_cfg,
        opts=opts,
        model_id=effective_model,
    )
    run_cfg = _apply_response_include_override(run_cfg, opts=opts)
    try:
        return Runner.run_streamed(
            starting_agent=agent,
            input=input_items,
            max_turns=(
                opts.max_turns if opts.max_turns is not None else cfg.agent.max_turns
            ),
            previous_response_id=None,
            auto_previous_response_id=False,
            conversation_id=None,
            run_config=run_cfg,
            session=opts.session,
            context=opts.tool_context,
        )
    except APIError as exc:
        raise PipelineError(
            format_provider_error(exc, provider_label=provider_label)
        ) from exc
    except MaxTurnsExceeded:
        raise
    except AgentsException as exc:
        raise PipelineError(format_agents_error(exc)) from exc
