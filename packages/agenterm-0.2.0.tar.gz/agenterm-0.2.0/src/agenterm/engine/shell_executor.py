"""Seatbelt-sandboxed shell executor for Agents ShellTool.

Security model (macOS only):
- Commands run inside a macOS Seatbelt sandbox (sandbox-exec)
- Filesystem writes confined to workspace root (cwd where agenterm launched)
- Temp directory writes allowed (/tmp, /private/var/folders, /private/tmp)
- /dev/null writes allowed (needed by git, many Unix tools)
- Network access configurable (allow/deny)
- Full shell features work (pipes, redirection, chaining) within sandbox
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

from agents.tool import (
    ShellActionRequest,
    ShellCallOutcome,
    ShellCommandOutput,
    ShellCommandRequest,
    ShellResult,
)

from agenterm.core.errors import ValidationError
from agenterm.core.json_codec import JSONLike, as_json_object, as_str
from agenterm.engine.subprocess_runner import run_subprocess

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.tool_models import ShellToolConfig
    from agenterm.core.approvals import ShellApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.choices.tools import SandboxNetwork

# Safe environment variables to inherit (mirrors MCP SDK pattern).
# Reference: .venv/lib/python3.12/site-packages/mcp/client/stdio/__init__.py:28-45
_SAFE_INHERITED_ENV_VARS: tuple[str, ...] = (
    ("HOME", "LOGNAME", "PATH", "SHELL", "TERM", "USER")
    if sys.platform != "win32"
    else (
        "APPDATA",
        "HOMEDRIVE",
        "HOMEPATH",
        "LOCALAPPDATA",
        "PATH",
        "PATHEXT",
        "PROCESSOR_ARCHITECTURE",
        "SYSTEMDRIVE",
        "SYSTEMROOT",
        "TEMP",
        "USERNAME",
        "USERPROFILE",
    )
)


def _get_default_environment() -> dict[str, str]:
    """Return environment with only safe inherited variables.

    Mirrors the MCP SDK pattern for secure subprocess environments.
    Shell functions (values starting with '()') are filtered as a security measure.
    """
    env = dict[str, str]()
    for key in _SAFE_INHERITED_ENV_VARS:
        value = os.environ.get(key)
        if value is None:
            continue
        # Skip shell functions (security risk)
        if value.startswith("()"):
            continue
        env[key] = value
    return env


def _build_shell_env(custom: Mapping[str, str] | None) -> dict[str, str]:
    """Build shell environment from safe defaults plus optional custom vars."""
    base = _get_default_environment()
    if custom is not None:
        return {**base, **custom}
    return base


def _generate_seatbelt_policy(
    workspace_root: Path,
    network: SandboxNetwork,
) -> str:
    """Generate Seatbelt policy string with workspace confinement.

    The policy:
    - Starts permissive (allow default)
    - Denies all file writes except under workspace_root, temp dirs, and /dev/null
    - Allows or denies network based on config
    - Allows process execution and file reads everywhere
    """
    network_rule = "(allow network*)" if network == "allow" else "(deny network*)"
    workspace_path = str(workspace_root.resolve())

    return f"""(version 1)

; Start permissive, then restrict
(allow default)

; Network access (configurable)
{network_rule}

; Deny all writes by default
(deny file-write*)

; Allow writes ONLY under workspace root
(allow file-write* (subpath "{workspace_path}"))

; Allow writes to temp directories (needed for many tools)
(allow file-write* (subpath "/private/var/folders/"))
(allow file-write* (subpath "/private/tmp/"))
(allow file-write* (subpath "/tmp/"))

; Allow /dev/null (needed by git, many Unix tools for output suppression)
(allow file-write* (literal "/dev/null"))

; Allow process execution (needed to run commands)
(allow process*)

; Allow reading everywhere (model needs to read system files, binaries, etc.)
(allow file-read*)
"""


def _write_policy_sync(policy: str) -> Path:
    """Write Seatbelt policy to temp file synchronously.

    Uses os.write on file descriptor for efficiency (policy is <1KB).
    Returns path to temp file for cleanup.
    """
    policy_fd, policy_path_str = tempfile.mkstemp(suffix=".sb", text=True)
    try:
        os.write(policy_fd, policy.encode("utf-8"))
    finally:
        os.close(policy_fd)
    return Path(policy_path_str)


async def _execute_sandboxed_command(
    cmd: str,
    policy: str,
    cwd: Path,
    timeout_ms: int,
    env: Mapping[str, str],
    cancel_token: CancelToken | None,
) -> ShellCommandOutput:
    """Execute single command via sandbox-exec."""
    # Write policy file (outside sandbox - we're the parent process)
    # Use to_thread to avoid blocking the event loop
    policy_path = await asyncio.to_thread(_write_policy_sync, policy)
    try:
        result = await run_subprocess(
            [
                "sandbox-exec",
                "-f",
                str(policy_path),
                "sh",
                "-c",
                cmd,
            ],
            cwd=str(cwd),
            env=env,
            timeout_ms=timeout_ms,
            cancel_token=cancel_token,
        )
        return ShellCommandOutput(
            command=cmd,
            stdout=result.stdout.decode("utf-8", errors="ignore"),
            stderr=result.stderr.decode("utf-8", errors="ignore"),
            outcome=ShellCallOutcome(
                type="timeout" if result.timed_out else "exit",
                exit_code=result.exit_code,
            ),
        )
    finally:
        # Clean up policy file
        policy_path.unlink(missing_ok=True)


_TRUNCATION_MARKER = "\n...[truncated]\n"


def _truncate_text(value: str, *, limit: int) -> tuple[str, bool]:
    """Return (possibly truncated text, was_truncated).

    The returned string is always <= limit characters.
    """
    if limit <= 0:
        return "", bool(value)
    if len(value) <= limit:
        return value, False
    if limit <= len(_TRUNCATION_MARKER):
        return _TRUNCATION_MARKER[:limit], True
    return value[: limit - len(_TRUNCATION_MARKER)] + _TRUNCATION_MARKER, True


def _truncate_shell_output(
    out: ShellCommandOutput,
    *,
    max_output_length: int,
) -> ShellCommandOutput:
    """Apply a strict stdout+stderr character budget to a single command."""
    stdout = out.stdout or ""
    stderr = out.stderr or ""
    if max_output_length <= 0:
        if not stdout and not stderr:
            return out
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = True
        return ShellCommandOutput(
            command=out.command,
            stdout="",
            stderr="",
            outcome=out.outcome,
            provider_data=provider_data,
        )
    if len(stdout) + len(stderr) <= max_output_length:
        return out
    if not stdout:
        stderr_trunc, truncated = _truncate_text(stderr, limit=max_output_length)
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = truncated
        return ShellCommandOutput(
            command=out.command,
            stdout="",
            stderr=stderr_trunc,
            outcome=out.outcome,
            provider_data=provider_data,
        )
    if not stderr:
        stdout_trunc, truncated = _truncate_text(stdout, limit=max_output_length)
        provider_data = dict(out.provider_data or {})
        provider_data["truncated"] = truncated
        return ShellCommandOutput(
            command=out.command,
            stdout=stdout_trunc,
            stderr="",
            outcome=out.outcome,
            provider_data=provider_data,
        )

    failed = out.outcome.type != "exit" or (out.outcome.exit_code not in (None, 0))
    stderr_budget = max_output_length // 2 if failed else max_output_length // 4
    stdout_budget = max_output_length - stderr_budget

    # Transfer unused budget to the other stream.
    if len(stderr) < stderr_budget:
        stdout_budget += stderr_budget - len(stderr)
        stderr_budget = len(stderr)
    elif len(stdout) < stdout_budget:
        stderr_budget += stdout_budget - len(stdout)
        stdout_budget = len(stdout)

    stdout_trunc, stdout_truncated = _truncate_text(stdout, limit=stdout_budget)
    stderr_trunc, stderr_truncated = _truncate_text(stderr, limit=stderr_budget)
    truncated = stdout_truncated or stderr_truncated
    provider_data = dict(out.provider_data or {})
    provider_data["truncated"] = truncated
    return ShellCommandOutput(
        command=out.command,
        stdout=stdout_trunc,
        stderr=stderr_trunc,
        outcome=out.outcome,
        provider_data=provider_data,
    )


def _rejection_result(
    commands: list[str],
    working_dir: Path,
    *,
    reason: str | None,
    max_output_length: int | None,
) -> ShellResult:
    """Build rejection result when user declines approval."""
    base = "Shell command execution rejected by user."
    stderr = f"{base}\nReason: {reason}" if reason else base
    return ShellResult(
        output=[
            ShellCommandOutput(
                command="; ".join(commands),
                stdout="",
                stderr=stderr,
                outcome=ShellCallOutcome(type="exit", exit_code=1),
            ),
        ],
        max_output_length=max_output_length,
        provider_data={"working_directory": str(working_dir)},
    )


def _clean_optional_str(value: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned if cleaned else None


def _parse_shell_call_metadata(
    raw: JSONLike | None,
) -> tuple[str | None, str | None]:
    raw_map = as_json_object(raw) if raw is not None else None
    if raw_map is None:
        return None, None
    description = _clean_optional_str(as_str(raw_map.get("description")))
    call_cwd = _clean_optional_str(as_str(raw_map.get("cwd")))
    return description, call_cwd


def _resolve_shell_working_dir(
    *,
    workspace_root: Path,
    tool_cfg: ShellToolConfig,
    call_cwd: str | None,
) -> Path:
    if call_cwd is not None:
        candidate = Path(call_cwd)
        if candidate.is_absolute() or call_cwd.startswith("~"):
            message = f"Shell cwd must be workspace-relative: {call_cwd}"
            raise ValidationError(message)
        resolved = (workspace_root / candidate).resolve()
        try:
            resolved.relative_to(workspace_root)
        except ValueError as exc:
            message = f"Shell cwd outside workspace: {call_cwd}"
            raise ValidationError(message) from exc
        return resolved
    if tool_cfg.working_dir is not None:
        candidate = (
            tool_cfg.working_dir
            if tool_cfg.working_dir.is_absolute()
            else (workspace_root / tool_cfg.working_dir)
        ).resolve()
        try:
            candidate.relative_to(workspace_root)
        except ValueError as exc:
            message = f"Shell working_dir outside workspace: {candidate}"
            raise ValidationError(message) from exc
        return candidate
    return workspace_root


async def _run_shell_commands(
    *,
    commands: list[str],
    policy: str,
    working_dir: Path,
    timeout_ms: int,
    shell_env: Mapping[str, str],
    max_output_length: int | None,
    cancel_token: CancelToken | None,
) -> list[ShellCommandOutput]:
    outputs: list[ShellCommandOutput] = []
    for cmd in commands:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        output = await _execute_sandboxed_command(
            cmd=cmd,
            policy=policy,
            cwd=working_dir,
            timeout_ms=timeout_ms,
            env=shell_env,
            cancel_token=cancel_token,
        )
        if isinstance(max_output_length, int):
            output = _truncate_shell_output(
                output,
                max_output_length=max_output_length,
            )
        outputs.append(output)
        if output.outcome.type != "exit" or output.outcome.exit_code != 0:
            break
    return outputs


async def run_shell_sandboxed(
    request: ShellCommandRequest,
    *,
    tool_cfg: ShellToolConfig,
    workspace_root: Path,
    approvals: ShellApprovalManager,
    cancel_token: CancelToken | None,
) -> ShellResult:
    """Execute shell command in Seatbelt sandbox.

    Security is enforced at OS level by Seatbelt:
    - Filesystem writes only under workspace_root
    - Network access controlled by tool_cfg.sandbox.network
    - Full shell features (pipes, redirection, chaining) work within sandbox

    Approval is for user control flow only (not security):
    - Every invocation registers an approval request.
    - The host resolves approvals via the approvals manager (prompted in REPL,
      auto-resolved in one-shot runs).

    Cancellation:
    - If cancel_token is set, aborts in-flight commands and raises CancelledError.
    """
    action: ShellActionRequest = request.data.action
    commands = list(action.commands or [])
    effective_max_output_length = (
        action.max_output_length
        if action.max_output_length is not None
        else tool_cfg.max_output_length
    )
    description, call_cwd = _parse_shell_call_metadata(request.data.raw)
    working_dir = _resolve_shell_working_dir(
        workspace_root=workspace_root,
        tool_cfg=tool_cfg,
        call_cwd=call_cwd,
    )

    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    approval_item = approvals.register(
        commands,
        str(working_dir),
        description=description,
    )
    decision = await approvals.wait(approval_item.id, cancel_token=cancel_token)
    if not decision.approved:
        return _rejection_result(
            commands,
            working_dir,
            reason=decision.reason,
            max_output_length=effective_max_output_length,
        )

    # Generate Seatbelt policy
    policy = _generate_seatbelt_policy(
        workspace_root=workspace_root,
        network=tool_cfg.sandbox.network,
    )

    # Build shell environment (safe defaults + optional custom vars from config)
    shell_env = _build_shell_env(tool_cfg.env)

    timeout_ms = action.timeout_ms or tool_cfg.timeout_ms or 60000
    outputs = await _run_shell_commands(
        commands=commands,
        policy=policy,
        working_dir=working_dir,
        timeout_ms=timeout_ms,
        shell_env=shell_env,
        max_output_length=effective_max_output_length,
        cancel_token=cancel_token,
    )

    return ShellResult(
        output=outputs,
        max_output_length=effective_max_output_length,
        provider_data={"working_directory": str(working_dir)},
    )
