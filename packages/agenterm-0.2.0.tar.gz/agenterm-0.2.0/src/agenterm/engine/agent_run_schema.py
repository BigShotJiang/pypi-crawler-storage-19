"""Schema constants for agent_run reporting."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

AGENT_RUN_REPORT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Stored agent_run report payload.",
    "properties": {
        "schema_version": {
            "type": "integer",
            "description": "Report schema version.",
        },
        "tool_call_id": {
            "type": "string",
            "description": "Tool call id for the agent_run invocation.",
        },
        "trace_id": {
            "type": ["string", "null"],
            "description": "Trace id for the invocation, if available.",
        },
        "created_at": {
            "type": "string",
            "description": "RFC3339 timestamp for report creation.",
        },
        "model": {
            "type": "string",
            "description": "Delegated model identifier.",
        },
        "instructions": {
            "type": "string",
            "description": "Instructions supplied to the delegated agent.",
        },
        "input": {
            "type": "string",
            "description": "Input text sent to the delegated agent.",
        },
        "input_items": {
            "type": "array",
            "items": {},
            "description": "Serialized input items list.",
        },
        "output_text": {
            "type": ["string", "null"],
            "description": "Final output text, if present.",
        },
        "output_items": {
            "type": "array",
            "items": {},
            "description": "Serialized output items list.",
        },
        "tools_available": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Tools available to the delegated agent.",
        },
        "tools_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Tools invoked by the delegated agent.",
        },
        "tool_counts": {
            "type": "object",
            "description": "Tool call counts keyed by tool name.",
        },
        "truncated": {
            "type": "boolean",
            "description": "True when output was truncated.",
        },
        "warnings": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Warnings emitted during the run.",
        },
        "usage": {
            "type": "object",
            "description": "Token usage accounting.",
        },
        "response_id": {
            "type": ["string", "null"],
            "description": "Primary response id, if available.",
        },
        "response_ids": {
            "type": "array",
            "items": {"type": "string"},
            "description": "All response ids captured during the run.",
        },
    },
    "required": [
        "schema_version",
        "tool_call_id",
        "trace_id",
        "created_at",
        "model",
        "instructions",
        "input",
        "input_items",
        "output_text",
        "output_items",
        "tools_available",
        "tools_used",
        "tool_counts",
        "truncated",
        "warnings",
        "usage",
        "response_id",
        "response_ids",
    ],
    "additionalProperties": False,
}


__all__ = ("AGENT_RUN_REPORT_SCHEMA",)
