"""Shared error formatting for Agents runner failures."""

from __future__ import annotations

from agents.exceptions import (
    AgentsException,
    InputGuardrailTripwireTriggered,
    MaxTurnsExceeded,
    OutputGuardrailTripwireTriggered,
)
from openai import APIConnectionError, APIError, APIStatusError, APITimeoutError

from agenterm.core.error_litellm import litellm_error_payload
from agenterm.core.error_openai import openai_error_payload, openai_status_message


def _provider_display_name(
    label: str | None,
    *,
    llm_provider: str | None = None,
) -> str:
    if label == "openai":
        return "OpenAI"
    if label == "gateway":
        if llm_provider:
            return f"{llm_provider} (via gateway)"
        return "Gateway"
    if isinstance(label, str) and label:
        return label
    return "Provider"


def format_provider_error(exc: APIError, *, provider_label: str | None) -> str:
    """Return a concise, user-facing message for provider API errors."""
    litellm_message, litellm_details = litellm_error_payload(exc)
    llm_provider_raw = litellm_details.get("llm_provider")
    llm_provider = (
        llm_provider_raw
        if isinstance(llm_provider_raw, str) and llm_provider_raw
        else None
    )
    provider_name = _provider_display_name(
        provider_label,
        llm_provider=llm_provider,
    )
    if isinstance(exc, APITimeoutError):
        return f"{provider_name} API timeout: {exc}"
    if isinstance(exc, APIConnectionError):
        return f"{provider_name} API connection error: {exc}"
    if isinstance(exc, APIStatusError):
        return openai_status_message(
            exc,
            provider_name=provider_name,
            detail_message=litellm_message,
        )

    message, details = openai_error_payload(exc)
    if message is None and litellm_message:
        message = litellm_message
    suffix_bits: list[str] = []
    code = details.get("code")
    if isinstance(code, str) and code:
        suffix_bits.append(f"code={code}")
    param = details.get("param")
    if isinstance(param, str) and param:
        suffix_bits.append(f"param={param}")
    suffix = f" ({', '.join(suffix_bits)})" if suffix_bits else ""
    detail = message or str(exc)
    return f"{provider_name} API error{suffix}: {detail}"


def format_agents_error(exc: AgentsException) -> str:
    """Return a concise message for Agents engine errors."""
    if isinstance(exc, InputGuardrailTripwireTriggered):
        gr = exc.guardrail_result.guardrail
        return f"Guardrail blocked input: {gr.get_name()}"

    if isinstance(exc, OutputGuardrailTripwireTriggered):
        gr = exc.guardrail_result.guardrail
        return f"Guardrail blocked output: {gr.get_name()}"

    if isinstance(exc, MaxTurnsExceeded):
        return str(exc)

    return f"Agents engine error: {exc}"


__all__ = ("format_agents_error", "format_provider_error")
