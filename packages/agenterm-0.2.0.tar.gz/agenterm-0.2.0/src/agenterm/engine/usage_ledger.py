"""Conversion helpers for persisting per-request usage.

This module maps Agents SDK run results (per-request `ModelResponse` objects)
into agenterm's per-request request-usage ledger records.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.token_usage import TokenUsage
from agenterm.store.session.request_usage import RequestKind, RequestUsageRecord

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.items import ModelResponse


def build_request_usage_records(
    *,
    session_id: str,
    branch_id: str,
    kind: RequestKind,
    run_number: int,
    model: str,
    base_previous_response_id: str | None,
    raw_responses: Sequence[ModelResponse],
) -> list[RequestUsageRecord]:
    """Build request-usage records from Agents per-request model responses."""
    out: list[RequestUsageRecord] = []
    prev_id: str | None = base_previous_response_id
    for idx, resp in enumerate(raw_responses):
        usage = TokenUsage.from_agents_usage(resp.usage)
        out.append(
            RequestUsageRecord(
                session_id=session_id,
                branch_id=branch_id,
                kind=kind,
                run_number=int(run_number),
                request_index=int(idx),
                model=model,
                previous_response_id=prev_id,
                response_id=resp.response_id,
                usage=usage,
            ),
        )
        if resp.response_id:
            prev_id = resp.response_id
    return out


__all__ = ("build_request_usage_records",)
