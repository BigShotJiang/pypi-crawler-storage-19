"""Pre-flight validation for tool schemas.

This module validates that JSON schemas are compatible with OpenAI's strict
mode constraints before sending to the API. Catches errors at build time
with clear messages instead of cryptic API errors at runtime.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue


def validate_strict_schema(
    tool_name: str,
    schema: Mapping[str, JSONValue],
) -> None:
    """Validate schema is compatible with OpenAI strict mode.

    OpenAI's strict mode requires:
    - Root level must have `type: "object"`
    - No `anyOf`/`oneOf`/`allOf` at root level
    - `additionalProperties: false` (added by ensure_strict_json_schema)

    Args:
        tool_name: Name of the tool (for error messages).
        schema: The JSON schema to validate.

    Raises:
        ConfigError: If schema is incompatible with strict mode.

    """
    if not schema:
        return

    for combinator in ("anyOf", "oneOf", "allOf"):
        if combinator in schema:
            msg = (
                f"Tool '{tool_name}' has invalid schema for strict mode: "
                f"'{combinator}' at root level is not supported. "
                "Use a single object with optional fields instead."
            )
            raise ConfigError(msg)

    root_type = schema.get("type")
    if root_type != "object":
        msg = (
            f"Tool '{tool_name}' has invalid schema for strict mode: "
            f"root must have 'type: \"object\"', got 'type: \"{root_type}\"'. "
            "OpenAI strict mode requires a single object type at the root level."
        )
        raise ConfigError(msg)


__all__ = ("validate_strict_schema",)
