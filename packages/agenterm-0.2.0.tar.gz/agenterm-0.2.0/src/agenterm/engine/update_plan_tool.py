"""Built-in update_plan tool for plan rendering."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.core.errors import ToolExecutionError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.plan import (
    ToolRuntimeContext,
    parse_plan_update,
    plan_error_details,
)
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.store.async_db import AsyncStore
from agenterm.store.plan.repo import (
    get_latest_plan_snapshot,
    get_plan_series,
    insert_plan_snapshot,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool_context import ToolContext

    from agenterm.config.model import UpdatePlanToolConfig
    from agenterm.core.json_types import JSONValue

_PLAN_STEP_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Single plan step.",
    "properties": {
        "step": {
            "type": "string",
            "description": "Plan step text shown to the user.",
        },
        "status": {
            "type": "string",
            "enum": ["pending", "in_progress", "completed"],
            "description": "Step status (only one step may be in_progress).",
        },
    },
    "additionalProperties": False,
}

_UPDATE_PLAN_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Full plan update payload.",
    "properties": {
        "steps": {
            "type": "array",
            "items": _PLAN_STEP_SCHEMA,
            "description": "Entire plan (empty only when allow_empty is true).",
        },
        "explanation": {
            "type": ["string", "null"],
            "description": "Optional context about the plan.",
        },
        "allow_empty": {
            "type": ["boolean", "null"],
            "description": "Allow clearing the plan by sending empty steps.",
            "default": False,
        },
    },
    "required": ["steps"],
    "additionalProperties": False,
}

_INVALID_MESSAGE = "Invalid update_plan payload."
_INVALID_INPUT_KIND = "invalid_input"


def _error_output(message: str, *, details: Mapping[str, JSONValue]) -> str:
    err = ToolOutputError(
        kind=_INVALID_INPUT_KIND,
        message=message,
        details=dict(details),
    )
    env = FunctionToolOutputEnvelope(
        tool="update_plan",
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def build_update_plan_tool(
    cfg: UpdatePlanToolConfig | None,
) -> FunctionTool | None:
    """Build the update_plan tool when configured."""
    if cfg is None:
        return None

    validate_strict_schema("update_plan", _UPDATE_PLAN_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        payload = parse_json_object(raw) if raw else None
        if payload is None:
            return _error_output(
                _INVALID_MESSAGE,
                details={"field": "payload", "reason": "invalid_payload"},
            )
        update, error = parse_plan_update(payload)
        if error is not None or update is None:
            details = (
                plan_error_details(error)
                if error is not None
                else {"field": "payload", "reason": "invalid_payload"}
            )
            return _error_output(_INVALID_MESSAGE, details=details)
        session_id = ctx.context.session_id
        branch_id = ctx.context.branch_id
        if not session_id or not branch_id:
            msg = "update_plan requires a session id and branch id"
            raise ToolExecutionError(msg)
        store = AsyncStore(ctx.context.db_path)
        latest = await get_latest_plan_snapshot(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if (
            latest is not None
            and latest.steps == update.steps
            and latest.explanation == update.explanation
        ):
            snapshot = latest
        else:
            snapshot = await insert_plan_snapshot(
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                steps=update.steps,
                explanation=update.explanation,
                trace_id=ctx.context.trace_id,
                tool_call_id=ctx.tool_call_id,
            )
        if ctx.tool_call_id:
            ctx.context.plan_cache[ctx.tool_call_id] = snapshot
        series = await get_plan_series(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
        )
        payload_out = series.to_json()
        env = FunctionToolOutputEnvelope(
            tool="update_plan",
            ok=True,
            payload=payload_out,
        )
        return env.to_json_string()

    return FunctionTool(
        name="update_plan",
        description=(
            "Update the plan shown to the user.\n"
            "Inputs: steps (full list), explanation (optional), allow_empty to clear. "
            "Only one step may be in_progress.\n"
            "Outputs: plan_state, steps, explanation, revision, plan_created_at, "
            "plan_updated_at.\n"
            "Errors: invalid_input with field/reason for validation issues."
        ),
        params_json_schema=_UPDATE_PLAN_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_update_plan_tool",)
