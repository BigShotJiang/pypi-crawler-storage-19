"""Expose local FunctionTools as an MCP server via FastMCP."""

from __future__ import annotations

import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import TYPE_CHECKING

from agents.tool import FunctionTool
from agents.tool_context import ToolContext
from mcp import types as mtypes
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.config.paths import meta_store_path
from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.constants.tools import TOOL_TYPE_FUNCTION
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import AgentermError, ConfigError
from agenterm.core.function_tools import resolve_function_tools
from agenterm.core.json_codec import (
    as_str,
    dumps_compact,
    require_json_object,
    require_json_value,
)
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
    parse_function_tool_output_envelope,
)
from agenterm.core.tool_selection import ToolCatalog, ToolSelection, resolve_selection
from agenterm.core.toolspec import is_fn_key, is_user_fn_key, make_fn_key
from agenterm.engine.agent_factory import build_agent_from_config
from agenterm.engine.agent_run_report_tool import build_agent_run_report_tool
from agenterm.engine.agent_run_tool import AGENT_RUN_REPORT_SCHEMA, build_agent_run_tool
from agenterm.engine.cli_tools import (
    build_bat_tool,
    build_fd_tool,
    build_rg_tool,
    build_stat_tool,
    build_tree_tool,
)
from agenterm.engine.function_tool_wrappers import (
    build_apply_patch_function_tool,
    build_shell_function_tool,
)
from agenterm.engine.get_plan_tool import build_get_plan_tool
from agenterm.engine.tool_output_clamp import ToolOutputClamp
from agenterm.engine.update_plan_tool import build_update_plan_tool
from agenterm.store.async_db import AsyncStore

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable, Mapping, Sequence
    from contextlib import AbstractAsyncContextManager

    from agenterm.config.model import AppConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.toolspec import ToolSpec

_ERROR_KIND_TOOL = "tool_error"
_EXPOSE_EXCLUDE_KEYS = {make_fn_key("steward")}

_FUNCTION_TOOL_OUTPUT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "properties": {
        "schema_version": {"type": "integer"},
        "tool": {"type": "string"},
        "ok": {"type": "boolean"},
        "truncated": {"type": "boolean"},
        "payload": {"type": "object"},
        "error": {
            "type": "object",
            "properties": {
                "kind": {"type": "string"},
                "message": {"type": "string"},
                "details": {"type": "object"},
            },
            "required": ["kind", "message", "details"],
            "additionalProperties": False,
        },
    },
    "required": ["schema_version", "tool", "ok", "truncated", "payload"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class McpExposeState:
    """Immutable state shared by the MCP exposure server."""

    tools: Mapping[str, FunctionTool]
    tool_defs: tuple[mtypes.Tool, ...]
    tool_context: ToolRuntimeContext


def _resolve_expose_specs(cfg: AppConfig) -> tuple[ToolSpec, ...]:
    tools_map, bundles_map, default_bundles = build_tool_catalog_from_config(cfg)
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(default_bundles),
    )
    expose = cfg.mcp.expose
    explicit = expose.bundles is not None or expose.tools is not None
    bundles = (
        tuple(expose.bundles) if expose.bundles is not None else tuple(default_bundles)
    )
    keys = tuple(expose.tools or ())
    selection = ToolSelection(
        selected_bundles=bundles,
        selected_keys=keys,
        explicit_override=explicit,
    )
    resolved = resolve_selection(selection, catalog=catalog)
    if resolved.error is not None:
        raise ConfigError(resolved.error)
    specs = resolved.specs
    filtered = tuple(
        spec for spec in specs if is_fn_key(spec.key) or is_user_fn_key(spec.key)
    )
    if _EXPOSE_EXCLUDE_KEYS:
        filtered = tuple(
            spec for spec in filtered if spec.key not in _EXPOSE_EXCLUDE_KEYS
        )
    if not expose.allow_dangerous:
        filtered = tuple(spec for spec in filtered if not spec.dangerous)
    return filtered


def _user_tool_map(specs: Sequence[ToolSpec]) -> Mapping[str, FunctionTool]:
    names = [
        spec.name for spec in specs if spec.name and spec.type == TOOL_TYPE_FUNCTION
    ]
    tools = resolve_function_tools(names)
    return MappingProxyType({tool.name: tool for tool in tools})


def _append_tool(tools: list[FunctionTool], tool: FunctionTool | None) -> None:
    if tool is not None:
        tools.append(tool)


def _mcp_builtin_builders(
    cfg: AppConfig,
    *,
    workspace_root: Path,
) -> Mapping[str, Callable[[], FunctionTool | None]]:
    approvals = ApprovalsContext(mode="auto")
    return {
        make_fn_key("shell"): lambda: build_shell_function_tool(
            cfg.tools.shell,
            workspace_root=workspace_root,
            approvals=approvals.shell,
        ),
        make_fn_key("apply_patch"): lambda: build_apply_patch_function_tool(
            cfg.tools.apply_patch,
            workspace_root=workspace_root,
            approvals=approvals.patch,
        ),
        make_fn_key("update_plan"): lambda: build_update_plan_tool(
            cfg.tools.update_plan
        ),
        make_fn_key("get_plan"): lambda: build_get_plan_tool(cfg.tools.get_plan),
        make_fn_key("rg"): lambda: build_rg_tool(
            cfg.tools.rg,
            workspace_root=workspace_root,
        ),
        make_fn_key("fd"): lambda: build_fd_tool(
            cfg.tools.fd,
            workspace_root=workspace_root,
        ),
        make_fn_key("bat"): lambda: build_bat_tool(
            cfg.tools.bat,
            workspace_root=workspace_root,
        ),
        make_fn_key("tree"): lambda: build_tree_tool(
            cfg.tools.tree,
            workspace_root=workspace_root,
        ),
        make_fn_key("stat"): lambda: build_stat_tool(
            cfg.tools.stat,
            workspace_root=workspace_root,
        ),
        make_fn_key("agent_run"): lambda: build_agent_run_tool(
            cfg,
            workspace_root=workspace_root,
            agent_builder=build_agent_from_config,
        ),
        make_fn_key("agent_run_report"): lambda: build_agent_run_report_tool(
            cfg.tools.agent_run_report
        ),
    }


def _build_function_tools(
    cfg: AppConfig,
    specs: Sequence[ToolSpec],
    *,
    workspace_root: Path,
) -> list[FunctionTool]:
    user_tools = _user_tool_map(specs)
    builders = _mcp_builtin_builders(cfg, workspace_root=workspace_root)
    clamp = ToolOutputClamp(cfg.tools.output_max_chars)
    tools: list[FunctionTool] = []
    for spec in specs:
        builder = builders.get(spec.key)
        if builder is not None:
            _append_tool(tools, builder())
            continue
        if spec.type == TOOL_TYPE_FUNCTION and spec.name:
            tool = user_tools.get(spec.name)
            if tool is not None:
                tools.append(tool)
            continue
    wrapped = clamp.wrap_tools(tools)
    return [tool for tool in wrapped if isinstance(tool, FunctionTool)]


def _tool_output_schema(tool: FunctionTool) -> dict[str, JSONValue]:
    if tool.name == "agent_run":
        return dict(AGENT_RUN_REPORT_SCHEMA)
    return dict(_FUNCTION_TOOL_OUTPUT_SCHEMA)


def _tool_defs(tools: Sequence[FunctionTool]) -> tuple[mtypes.Tool, ...]:
    defs: list[mtypes.Tool] = []
    for tool in tools:
        schema = dict(tool.params_json_schema)
        if "properties" not in schema:
            schema["properties"] = {}
        defs.append(
            mtypes.Tool(
                name=tool.name,
                description=tool.description or "",
                inputSchema=schema,
                outputSchema=_tool_output_schema(tool),
            ),
        )
    return tuple(defs)


def _tool_context(cfg: AppConfig) -> ToolRuntimeContext:
    return ToolRuntimeContext(
        db_path=meta_store_path(),
        session_id=None,
        branch_id=None,
        run_number=None,
        trace_id=cfg.run.trace_id,
        plan_cache={},
        cancel_token=None,
    )


def _tool_summary_text(env: FunctionToolOutputEnvelope) -> str:
    summary = as_str(env.payload.get("summary"))
    if summary:
        return summary
    if env.ok:
        if env.truncated:
            return f"{env.tool} ok (output truncated)"
        if _payload_has_more(env.payload):
            return f"{env.tool} ok (has_more)"
        return f"{env.tool} ok"
    return f"{env.tool} error"


def _payload_has_more(payload: Mapping[str, JSONValue]) -> bool:
    page_obj = payload.get("page")
    if not isinstance(page_obj, dict):
        return False
    return page_obj.get("has_more") is True


def _error_text(tool_name: str, message: str) -> str:
    env = FunctionToolOutputEnvelope(
        tool=tool_name,
        ok=False,
        payload={},
        error=ToolOutputError(kind=_ERROR_KIND_TOOL, message=message, details={}),
    )
    return env.to_json_string()


async def _agent_run_structured_output(
    env: FunctionToolOutputEnvelope,
    *,
    tool_context: ToolRuntimeContext,
) -> tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]:
    report_id = as_str(env.payload.get("report_id"))
    if report_id is None:
        raise ToolError(_error_text("agent_run", "agent_run report_id missing"))
    report = await load_agent_run_report(
        store=AsyncStore(tool_context.db_path),
        artifact_id=report_id,
    )
    if report is None:
        raise ToolError(_error_text("agent_run", "agent_run report not found"))
    summary = as_str(env.payload.get("summary")) or ""
    blocks: Sequence[mtypes.ContentBlock] = [
        mtypes.TextContent(type="text", text=summary),
    ]
    return blocks, report


def build_mcp_expose_state(
    cfg: AppConfig,
    *,
    workspace_root: Path,
) -> McpExposeState:
    """Build MCP exposure state (tool registry + runtime context)."""
    specs = _resolve_expose_specs(cfg)
    tools = _build_function_tools(cfg, specs, workspace_root=workspace_root)
    tool_map_raw: dict[str, FunctionTool] = {}
    for tool in tools:
        if tool.name in tool_map_raw:
            msg = f"Duplicate FunctionTool name for MCP exposure: {tool.name}"
            raise ConfigError(msg)
        tool_map_raw[tool.name] = tool
    tool_map = MappingProxyType(tool_map_raw)
    return McpExposeState(
        tools=tool_map,
        tool_defs=_tool_defs(tools),
        tool_context=_tool_context(cfg),
    )


class McpExposeServer(FastMCP[McpExposeState]):
    """FastMCP server exposing local FunctionTools."""

    def __init__(self, cfg: AppConfig, *, workspace_root: Path) -> None:
        """Initialize the MCP exposure server."""
        self._cfg = cfg
        self._workspace_root = workspace_root
        self._state: McpExposeState | None = None
        super().__init__(
            name="agenterm",
            host=cfg.mcp.expose.host,
            port=cfg.mcp.expose.port,
            lifespan=self._lifespan,
        )

    def _setup_handlers(self) -> None:
        super()._setup_handlers()
        self._mcp_server.call_tool(validate_input=True)(self._call_tool_handler)

    def _lifespan(
        self,
        _app: FastMCP[McpExposeState],
    ) -> AbstractAsyncContextManager[McpExposeState]:
        """Build FastMCP lifespan context with tool selection state."""

        @asynccontextmanager
        async def _ctx() -> AsyncIterator[McpExposeState]:
            state = build_mcp_expose_state(
                self._cfg,
                workspace_root=self._workspace_root,
            )
            self._state = state
            try:
                yield state
            finally:
                self._state = None

        return _ctx()

    def _require_state(self) -> McpExposeState:
        if self._state is None:
            msg = "MCP expose server is not initialized"
            raise ConfigError(msg)
        return self._state

    async def list_tools(self) -> list[mtypes.Tool]:
        """List available MCP tools (FunctionTools only)."""
        state = self._require_state()
        return list(state.tool_defs)

    async def _call_tool_handler(
        self,
        name: str,
        arguments: Mapping[str, JSONValue],
        *,
        state: McpExposeState | None = None,
    ) -> (
        Sequence[mtypes.ContentBlock]
        | dict[str, JSONValue]
        | tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]
    ):
        """Invoke a FunctionTool and return MCP content blocks or structured output."""
        state = self._require_state() if state is None else state
        tool = state.tools.get(name)
        if tool is None:
            raise ToolError(_error_text(name, "Unknown tool"))
        args_json = dumps_compact(
            require_json_object(
                value=arguments,
                context="mcp.expose.arguments",
            ),
            ensure_ascii=True,
            context="mcp.expose.arguments",
        )
        tool_call_id = uuid.uuid4().hex
        tool_ctx = ToolContext(
            context=state.tool_context,
            tool_name=name,
            tool_call_id=tool_call_id,
            tool_arguments=args_json,
            tool_call=None,
        )
        try:
            output = await tool.on_invoke_tool(tool_ctx, args_json)
        except AgentermError as exc:
            raise ToolError(_error_text(tool.name, str(exc))) from exc
        if isinstance(output, str):
            parsed = parse_function_tool_output_envelope(output)
            if parsed is not None:
                if not parsed.ok:
                    raise ToolError(output)
                if parsed.tool == "agent_run":
                    return await _agent_run_structured_output(
                        parsed,
                        tool_context=state.tool_context,
                    )
                summary = _tool_summary_text(parsed)
                return [mtypes.TextContent(type="text", text=summary)], parsed.to_json()
            env = FunctionToolOutputEnvelope(
                tool=tool.name,
                ok=True,
                payload={"text": output},
            )
            summary = _tool_summary_text(env)
            return [mtypes.TextContent(type="text", text=summary)], env.to_json()
        env = FunctionToolOutputEnvelope(
            tool=tool.name,
            ok=True,
            payload={
                "result": require_json_value(
                    value=output,
                    context=f"mcp.expose.output.{tool.name}",
                )
            },
        )
        summary = _tool_summary_text(env)
        return [mtypes.TextContent(type="text", text=summary)], env.to_json()

    async def call_tool_with_state(
        self,
        name: str,
        arguments: Mapping[str, JSONValue],
        *,
        state: McpExposeState,
    ) -> (
        Sequence[mtypes.ContentBlock]
        | dict[str, JSONValue]
        | tuple[Sequence[mtypes.ContentBlock], dict[str, JSONValue]]
    ):
        """Invoke a FunctionTool with an explicit state (testing helper)."""
        return await self._call_tool_handler(name, arguments, state=state)


async def serve_mcp_expose(
    cfg: AppConfig,
    *,
    workspace_root: Path | None = None,
) -> None:
    """Run FastMCP server to expose local FunctionTools."""
    if not cfg.mcp.expose.enabled:
        message = "mcp.expose.enabled must be true to start the MCP server"
        raise ConfigError(message)
    root = workspace_root or Path.cwd()
    server = McpExposeServer(cfg, workspace_root=root)
    transport = cfg.mcp.expose.transport
    if transport == "stdio":
        await server.run_stdio_async()
    elif transport == "sse":
        await server.run_sse_async()
    else:
        await server.run_streamable_http_async()


__all__ = ("McpExposeServer", "build_mcp_expose_state", "serve_mcp_expose")
