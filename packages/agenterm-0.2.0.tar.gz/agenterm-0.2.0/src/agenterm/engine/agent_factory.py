"""Build Agents `Agent` instances from AppConfig for the CLI."""

from __future__ import annotations

from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Final

from agents.agent import Agent, MCPConfig

from agenterm.constants.tools import (
    TOOL_TYPE_FILE_SEARCH,
    TOOL_TYPE_FUNCTION,
    TOOL_TYPE_HOSTED_MCP,
    TOOL_TYPE_IMAGE_GENERATION,
    TOOL_TYPE_WEB_SEARCH,
)
from agenterm.core.errors import ValidationError
from agenterm.core.function_tools import resolve_function_tools
from agenterm.core.model_id import ModelPlane, model_plane
from agenterm.engine.agent_run_report_tool import build_agent_run_report_tool
from agenterm.engine.agent_run_tool import build_agent_run_tool
from agenterm.engine.cli_tools import (
    build_bat_tool,
    build_fd_tool,
    build_rg_tool,
    build_stat_tool,
    build_tree_tool,
)
from agenterm.engine.function_tool_wrappers import (
    build_apply_patch_function_tool,
    build_shell_function_tool,
)
from agenterm.engine.get_plan_tool import build_get_plan_tool
from agenterm.engine.mcp_bridge import wrap_mcp_servers
from agenterm.engine.output_schema import build_output_schema_from_text_format
from agenterm.engine.tool_builders import (
    build_apply_patch_tool,
    build_file_search_tool,
    build_hosted_mcp_tools,
    build_image_generation_tool,
    build_shell_tool,
    build_web_search_tool,
)
from agenterm.engine.tool_output_clamp import ToolOutputClamp
from agenterm.engine.update_plan_tool import build_update_plan_tool
from agenterm.steward.tool import build_steward_tool

if TYPE_CHECKING:
    from collections.abc import Callable

    from agents.mcp import MCPServer
    from agents.model_settings import ModelSettings
    from agents.tool import Tool

    from agenterm.config.model import AppConfig, ToolsConfig
    from agenterm.core.approvals import ApprovalsContext
    from agenterm.core.toolspec import ToolSpec

_HOSTED_MCP_KEY_PREFIX: Final[str] = "hosted:mcp:"


def _maybe_add_tool(tools: list[Tool], tool: Tool | None) -> None:
    if tool is None:
        return
    tools.append(tool)


def _shell_builder_for_plane(
    *,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
    plane: ModelPlane,
) -> Callable[[], Tool | None]:
    if plane == "gateway":

        def builder() -> Tool | None:
            return build_shell_function_tool(
                tools_cfg.shell,
                workspace_root=root,
                approvals=approvals.shell,
            )

        return builder

    def builder() -> Tool | None:
        return build_shell_tool(tools_cfg.shell, root, approvals.shell)

    return builder


def _patch_builder_for_plane(
    *,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
    plane: ModelPlane,
) -> Callable[[], Tool | None]:
    if plane == "gateway":

        def builder() -> Tool | None:
            return build_apply_patch_function_tool(
                tools_cfg.apply_patch,
                workspace_root=root,
                approvals=approvals.patch,
            )

        return builder

    def builder() -> Tool | None:
        return build_apply_patch_tool(
            tools_cfg.apply_patch,
            root,
            approvals.patch,
        )

    return builder


def _builtin_tool_builders(
    *,
    cfg: AppConfig,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
    plane: ModelPlane,
) -> dict[str, Callable[[], Tool | None]]:
    return {
        TOOL_TYPE_FILE_SEARCH: partial(build_file_search_tool, tools_cfg.file_search),
        TOOL_TYPE_WEB_SEARCH: partial(build_web_search_tool, tools_cfg.web_search),
        "shell": _shell_builder_for_plane(
            tools_cfg=tools_cfg,
            root=root,
            approvals=approvals,
            plane=plane,
        ),
        "apply_patch": _patch_builder_for_plane(
            tools_cfg=tools_cfg,
            root=root,
            approvals=approvals,
            plane=plane,
        ),
        "update_plan": partial(build_update_plan_tool, tools_cfg.update_plan),
        "get_plan": partial(build_get_plan_tool, tools_cfg.get_plan),
        "rg": partial(build_rg_tool, tools_cfg.rg, workspace_root=root),
        "fd": partial(build_fd_tool, tools_cfg.fd, workspace_root=root),
        "bat": partial(build_bat_tool, tools_cfg.bat, workspace_root=root),
        "tree": partial(build_tree_tool, tools_cfg.tree, workspace_root=root),
        "stat": partial(build_stat_tool, tools_cfg.stat, workspace_root=root),
        "agent_run": partial(
            build_agent_run_tool,
            cfg,
            workspace_root=root,
            agent_builder=build_agent_from_config,
        ),
        "agent_run_report": partial(
            build_agent_run_report_tool,
            tools_cfg.agent_run_report,
        ),
        "steward": partial(build_steward_tool, cfg),
        TOOL_TYPE_IMAGE_GENERATION: partial(
            build_image_generation_tool,
            tools_cfg.image_generation,
        ),
    }


def _build_selected_builtin_tools(
    selected: list[ToolSpec],
    *,
    cfg: AppConfig,
    tools_cfg: ToolsConfig,
    root: Path,
    approvals: ApprovalsContext,
    plane: ModelPlane,
) -> list[Tool]:
    builders = _builtin_tool_builders(
        cfg=cfg,
        tools_cfg=tools_cfg,
        root=root,
        approvals=approvals,
        plane=plane,
    )
    tools: list[Tool] = []
    for spec in selected:
        builder = builders.get(spec.type)
        if builder is None:
            continue
        _maybe_add_tool(tools, builder())
    return tools


def _hosted_mcp_connector_name_from_key(key: str) -> str | None:
    if not key.startswith(_HOSTED_MCP_KEY_PREFIX):
        return None
    name = key[len(_HOSTED_MCP_KEY_PREFIX) :].strip()
    return name if name else None


def _selected_hosted_mcp_connector_names(
    selected: list[ToolSpec],
) -> tuple[str, ...]:
    out: list[str] = []
    for spec in selected:
        if spec.type != TOOL_TYPE_HOSTED_MCP:
            continue
        name = _hosted_mcp_connector_name_from_key(str(spec.key))
        if name is not None:
            out.append(name)
    return tuple(out)


def _selected_function_names(
    selected: list[ToolSpec],
) -> tuple[str, ...]:
    out: list[str] = []
    for spec in selected:
        if spec.type != TOOL_TYPE_FUNCTION:
            continue
        name = (spec.name or "").strip()
        if name:
            out.append(name)
    return tuple(out)


def build_agent_from_config(
    cfg: AppConfig,
    *,
    selected_tools: list[ToolSpec] | None,
    approvals: ApprovalsContext,
    workspace_root: Path | None = None,
    mcp_servers: list[MCPServer] | None = None,
) -> Agent:
    """Construct an Agents Agent from AppConfig."""
    model_name = cfg.agent.model
    plane = model_plane(model_name)
    model_settings: ModelSettings = cfg.to_model_settings()
    output_schema = build_output_schema_from_text_format(cfg.model.text_format)

    tools_cfg = cfg.tools

    root = workspace_root or Path.cwd()

    selected = list(selected_tools) if selected_tools is not None else []
    if plane == "gateway":
        hosted = [spec.key for spec in selected if spec.plane == "hosted"]
        if hosted:
            msg = (
                "Gateway models do not support hosted tools. "
                f"Remove: {', '.join(hosted)}"
            )
            raise ValidationError(msg)
    tools = _build_selected_builtin_tools(
        selected,
        cfg=cfg,
        tools_cfg=tools_cfg,
        root=root,
        approvals=approvals,
        plane=plane,
    )

    selected_hosted_mcp_names = _selected_hosted_mcp_connector_names(selected)
    if selected_hosted_mcp_names:
        selected_set = set(selected_hosted_mcp_names)
        connectors = [tc for tc in cfg.mcp.connectors if tc.name in selected_set]
        tools.extend(build_hosted_mcp_tools(connectors, approvals=approvals.mcp))

    selected_func_names = _selected_function_names(selected)
    if selected_func_names:
        tools.extend(resolve_function_tools(list(selected_func_names)))

    clamp = ToolOutputClamp(cfg.tools.output_max_chars)
    tools = clamp.wrap_tools(tools)

    mcp_servers_effective = list(mcp_servers) if mcp_servers is not None else []
    if mcp_servers_effective:
        mcp_servers_effective = wrap_mcp_servers(
            mcp_servers_effective,
            approvals=approvals.mcp,
            bridge_cfg=cfg.mcp.bridge,
            output_clamp=clamp,
        )
    mcp_cfg: MCPConfig = {
        "convert_schemas_to_strict": cfg.mcp.convert_schemas_to_strict,
    }

    return Agent(
        name=cfg.agent.name,
        instructions=cfg.agent.instructions,
        model=model_name,
        model_settings=model_settings,
        tools=tools,
        mcp_servers=mcp_servers_effective,
        mcp_config=mcp_cfg,
        output_type=output_schema,
    )
