"""Helper builders for tool configurations used by the agent factory."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from agents.tool import (
    ApplyPatchTool,
    FileSearchTool,
    HostedMCPTool,
    ImageGenerationTool,
    ShellCommandRequest,
    ShellResult,
    ShellTool,
    WebSearchTool,
)

from agenterm.core.errors import ConfigError
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.platform import is_macos
from agenterm.engine.apply_patch_editor import WorkspaceEditor
from agenterm.engine.shell_executor import run_shell_sandboxed
from agenterm.engine.tool_config_parse import (
    parse_file_search_filters,
    parse_file_search_ranking_options,
    parse_image_generation_config,
    parse_web_search_filters,
    parse_web_search_user_location,
)

if TYPE_CHECKING:
    from pathlib import Path

    from agents.tool import MCPToolApprovalFunctionResult, MCPToolApprovalRequest
    from openai.types.responses.file_search_tool_param import (
        Filters as FileSearchFilters,
    )
    from openai.types.responses.tool_param import (
        Mcp,
    )

    from agenterm.config.model import McpConnectorConfig
    from agenterm.config.tool_models import (
        ApplyPatchToolConfig,
        FileSearchToolConfig,
        ImageGenerationToolConfig,
        ShellToolConfig,
        WebSearchToolConfig,
    )
    from agenterm.core.approvals import (
        McpApprovalManager,
        PatchApprovalManager,
        ShellApprovalManager,
    )


def build_file_search_tool(cfg: FileSearchToolConfig | None) -> FileSearchTool | None:
    """Build the hosted file_search tool when configured and ready."""
    if cfg is None:
        return None
    if not cfg.vector_store_ids:
        return None
    ranking = parse_file_search_ranking_options(cfg.ranking_options)
    filters: FileSearchFilters | None = parse_file_search_filters(cfg.filters)
    return FileSearchTool(
        vector_store_ids=list(cfg.vector_store_ids),
        max_num_results=cfg.max_num_results,
        include_search_results=cfg.include_search_results,
        ranking_options=ranking,
        filters=filters,
    )


def build_web_search_tool(cfg: WebSearchToolConfig | None) -> WebSearchTool | None:
    """Build the hosted web_search tool when configured and ready."""
    if cfg is None:
        return None
    user_loc = parse_web_search_user_location(cfg.user_location)
    filters = parse_web_search_filters(cfg.filters)
    return WebSearchTool(
        user_location=user_loc,
        filters=filters,
        search_context_size=cfg.search_context_size,
    )


def build_shell_tool(
    conf: ShellToolConfig | None,
    workspace_root: Path,
    approvals: ShellApprovalManager,
) -> ShellTool | None:
    """Build the shell tool with Seatbelt sandbox enforcement."""
    if not is_macos():
        return None
    if conf is None:
        return None

    async def _executor(req: ShellCommandRequest) -> ShellResult:
        ctx = req.ctx_wrapper.context
        cancel_token = ctx.cancel_token if isinstance(ctx, ToolRuntimeContext) else None
        return await run_shell_sandboxed(
            req,
            tool_cfg=conf,
            workspace_root=workspace_root,
            approvals=approvals,
            cancel_token=cancel_token,
        )

    return ShellTool(executor=_executor)


def build_apply_patch_tool(
    cfg: ApplyPatchToolConfig | None,
    workspace_root: Path,
    approvals: PatchApprovalManager,
) -> ApplyPatchTool | None:
    """Build the hosted apply_patch tool when configured."""
    if cfg is None:
        return None
    editor = WorkspaceEditor(workspace_root, approvals)
    return ApplyPatchTool(editor=editor)


def build_image_generation_tool(
    cfg: ImageGenerationToolConfig | None,
) -> ImageGenerationTool | None:
    """Build the hosted image_generation tool when configured."""
    if cfg is None:
        return None
    tool_config = parse_image_generation_config(cfg)
    return ImageGenerationTool(tool_config=tool_config)


def _authorization_from_env(var_name: str | None) -> str | None:
    if not var_name:
        return None
    val = os.getenv(var_name)
    if not val:
        return None
    return val


def _tool_config_for_hosted(tc: McpConnectorConfig) -> Mcp | None:
    tool_config: Mcp = {
        "server_label": tc.name,
        "type": "mcp",
    }

    if tc.server_url is None:
        if tc.connector_id is None:
            msg = (
                f"Invalid MCP connector '{tc.name}': set exactly one of server_url or "
                "connector_id"
            )
            raise ConfigError(msg)
        tool_config["connector_id"] = tc.connector_id
    else:
        if tc.connector_id is not None:
            msg = (
                f"Invalid MCP connector '{tc.name}': server_url and connector_id are "
                "mutually exclusive"
            )
            raise ConfigError(msg)
        tool_config["server_url"] = tc.server_url

    for key, val in (
        ("server_description", tc.server_description),
        ("allowed_tools", tc.allowed_tools),
        ("require_approval", tc.require_approval),
    ):
        if val is not None:
            tool_config[key] = val

    if tc.headers is not None:
        tool_config["headers"] = {str(k): str(v) for k, v in tc.headers.items()}
    auth_val = _authorization_from_env(tc.authorization_env)
    if auth_val is not None:
        tool_config["authorization"] = auth_val
    return tool_config


def build_hosted_mcp_tools(
    seq: list[McpConnectorConfig],
    *,
    approvals: McpApprovalManager,
) -> list[HostedMCPTool]:
    """Translate hosted MCP tool configs into Agents HostedMCPTool instances."""
    tools: list[HostedMCPTool] = []

    async def _on_hosted_mcp_approval_request(
        req: MCPToolApprovalRequest,
    ) -> MCPToolApprovalFunctionResult:
        data = req.data
        cancel_token = None
        ctx = req.ctx_wrapper.context
        if isinstance(ctx, ToolRuntimeContext):
            cancel_token = ctx.cancel_token
            if cancel_token is not None:
                cancel_token.raise_if_cancelled()
        item = approvals.register(
            server_label=str(data.server_label),
            tool_name=str(data.name),
            arguments_json=str(data.arguments),
        )
        decision = await approvals.wait(item.id, cancel_token=cancel_token)
        result: MCPToolApprovalFunctionResult = {"approve": decision.approved}
        if (
            not decision.approved
            and isinstance(decision.reason, str)
            and decision.reason
        ):
            result["reason"] = decision.reason
        return result

    for tc in seq:
        tool_cfg = _tool_config_for_hosted(tc)
        if tool_cfg is not None:
            tools.append(
                HostedMCPTool(
                    tool_config=tool_cfg,
                    on_approval_request=_on_hosted_mcp_approval_request,
                ),
            )
    return tools


__all__ = (
    "build_apply_patch_tool",
    "build_file_search_tool",
    "build_hosted_mcp_tools",
    "build_image_generation_tool",
    "build_shell_tool",
    "build_web_search_tool",
)
