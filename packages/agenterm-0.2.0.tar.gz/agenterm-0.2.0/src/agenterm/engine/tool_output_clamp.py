"""Unified tool output clamp helpers."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from agents.tool import FunctionTool, Tool

from agenterm.core.json_codec import dumps_compact
from agenterm.core.tool_output_envelope import (
    parse_function_tool_output_envelope,
    parse_mcp_tool_output_envelope,
)
from agenterm.core.tool_output_limits import (
    limit_function_tool_output,
    limit_mcp_tool_output,
    limit_tool_output_text,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.tool_context import ToolContext

    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext
    from agenterm.core.tool_output_envelope import (
        FunctionToolOutputEnvelope,
        McpToolOutputEnvelope,
    )


@dataclass(frozen=True)
class ToolOutputClamp:
    """Clamp tool outputs to a single global max length."""

    max_chars: int

    def clamp_value(self, value: JSONValue) -> JSONValue:
        """Clamp a raw tool output value (string or envelope)."""
        if self.max_chars <= 0:
            return value
        if not isinstance(value, str):
            return value
        parsed = parse_function_tool_output_envelope(value)
        if parsed is not None:
            limited = limit_function_tool_output(parsed, max_chars=self.max_chars)
            return limited.to_json_string()
        parsed_mcp = parse_mcp_tool_output_envelope(value)
        if parsed_mcp is not None:
            limited = limit_mcp_tool_output(parsed_mcp, max_chars=self.max_chars)
            return dumps_compact(
                limited.to_json(),
                ensure_ascii=True,
                context="tool_output_clamp.mcp.envelope",
            )
        return limit_tool_output_text(value, max_chars=self.max_chars)

    def clamp_function_envelope(
        self,
        env: FunctionToolOutputEnvelope,
    ) -> FunctionToolOutputEnvelope:
        """Clamp a FunctionTool envelope in structured form."""
        if self.max_chars <= 0:
            return env
        return limit_function_tool_output(env, max_chars=self.max_chars)

    def clamp_mcp_envelope(
        self,
        env: McpToolOutputEnvelope,
    ) -> McpToolOutputEnvelope:
        """Clamp an MCP tool envelope in structured form."""
        if self.max_chars <= 0:
            return env
        return limit_mcp_tool_output(env, max_chars=self.max_chars)

    def wrap_function_tool(self, tool: FunctionTool) -> FunctionTool:
        """Return a FunctionTool wrapper that clamps output length."""
        if self.max_chars <= 0:
            return tool
        inner = tool.on_invoke_tool

        async def _invoke(
            ctx: ToolContext[ToolRuntimeContext],
            raw: str,
        ) -> JSONValue:
            output = await inner(ctx, raw)
            return self.clamp_value(output)

        return replace(tool, on_invoke_tool=_invoke)

    def wrap_tools(self, tools: Sequence[Tool]) -> list[Tool]:
        """Clamp outputs for all FunctionTools in a tool list."""
        if self.max_chars <= 0:
            return list(tools)
        out: list[Tool] = []
        for tool in tools:
            if isinstance(tool, FunctionTool):
                out.append(self.wrap_function_tool(tool))
            else:
                out.append(tool)
        return out


__all__ = ("ToolOutputClamp",)
