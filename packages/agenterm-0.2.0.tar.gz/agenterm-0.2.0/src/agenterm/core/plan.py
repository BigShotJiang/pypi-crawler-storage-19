"""Typed plan updates and snapshots for plan tools."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Literal, TypeGuard

from agenterm.core.json_codec import as_bool, is_json_value

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue

PlanStepStatus = Literal["pending", "in_progress", "completed"]
PlanState = Literal["missing", "active", "cleared"]


@dataclass(frozen=True)
class PlanStep:
    """One plan step rendered in the transcript."""

    step: str
    status: PlanStepStatus


@dataclass(frozen=True)
class PlanUpdate:
    """A full plan update payload."""

    steps: tuple[PlanStep, ...]
    explanation: str | None


@dataclass(frozen=True)
class PlanSnapshot:
    """Persisted plan snapshot stored in SQLite."""

    session_id: str
    branch_id: str
    revision: int
    steps: tuple[PlanStep, ...]
    explanation: str | None
    trace_id: str | None
    tool_call_id: str | None
    created_at: str | None


@dataclass(frozen=True)
class PlanSeries:
    """Resolved plan state for tool payloads."""

    plan_state: PlanState
    steps: tuple[PlanStep, ...]
    explanation: str | None
    revision: int | None
    plan_created_at: str | None
    plan_updated_at: str | None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this payload."""
        return {
            "plan_state": self.plan_state,
            "steps": plan_steps_payload(self.steps),
            "explanation": self.explanation,
            "revision": self.revision,
            "plan_created_at": self.plan_created_at,
            "plan_updated_at": self.plan_updated_at,
        }


@dataclass(frozen=True)
class PlanParseError:
    """Structured parse error for update_plan validation."""

    field: str
    reason: str


@dataclass(frozen=True)
class ToolRuntimeContext:
    """Tool execution context shared across built-in tools."""

    db_path: Path
    session_id: str | None
    branch_id: str | None
    run_number: int | None
    trace_id: str | None
    plan_cache: dict[str, PlanSnapshot]
    cancel_token: CancelToken | None


def parse_plan_update(
    payload: Mapping[str, JSONValue],
) -> tuple[PlanUpdate | None, PlanParseError | None]:
    """Parse a strict update_plan payload into a PlanUpdate."""
    update: PlanUpdate | None = None
    error: PlanParseError | None = None
    if not _has_only_allowed_keys(
        payload,
        allowed={"steps", "explanation", "allow_empty"},
    ):
        error = PlanParseError(field="payload", reason="unknown_keys")
    else:
        allow_empty = _parse_allow_empty(payload)
        if allow_empty is None:
            error = PlanParseError(field="allow_empty", reason="invalid_bool")
        else:
            steps, error = _parse_plan_steps_for_update(payload)
            if error is None and steps is not None:
                if not steps and not allow_empty:
                    error = PlanParseError(field="steps", reason="empty_steps")
                else:
                    ok, explanation = _parse_explanation(payload)
                    if not ok:
                        error = PlanParseError(
                            field="explanation", reason="invalid_type"
                        )
                    elif _count_in_progress(steps) > 1:
                        error = PlanParseError(
                            field="steps", reason="multiple_in_progress"
                        )
                    else:
                        update = PlanUpdate(steps=steps, explanation=explanation)
    return update, error


def plan_error_details(error: PlanParseError) -> dict[str, JSONValue]:
    """Return JSON-ready error details for a plan parse error."""
    return {"field": error.field, "reason": error.reason}


def plan_steps_payload(steps: Sequence[PlanStep]) -> list[JSONValue]:
    """Return a JSON-safe list of plan step objects."""
    return [{"step": step.step, "status": step.status} for step in steps]


def parse_plan_steps(value: JSONValue | None) -> tuple[PlanStep, ...] | None:
    """Parse a JSON value into a tuple of PlanStep entries."""
    if not isinstance(value, list):
        return None
    steps: list[PlanStep] = []
    for item in value:
        step = _parse_plan_step(item)
        if step is None:
            return None
        steps.append(step)
    return tuple(steps)


def normalize_plan_timestamp(value: str | None) -> str | None:
    """Normalize timestamps to RFC3339 (UTC)."""
    if value is None:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        try:
            parsed = datetime.strptime(f"{value} +0000", "%Y-%m-%d %H:%M:%S %z")
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    else:
        parsed = parsed.astimezone(UTC)
    return parsed.isoformat()


def derive_plan_series(snapshots: Sequence[PlanSnapshot]) -> PlanSeries:
    """Compute the current plan series from snapshots."""
    if not snapshots:
        return PlanSeries(
            plan_state="missing",
            steps=(),
            explanation=None,
            revision=None,
            plan_created_at=None,
            plan_updated_at=None,
        )
    ordered = sorted(snapshots, key=lambda item: item.revision, reverse=True)
    latest = ordered[0]
    updated_at = normalize_plan_timestamp(latest.created_at)
    if not latest.steps:
        return PlanSeries(
            plan_state="cleared",
            steps=(),
            explanation=latest.explanation,
            revision=latest.revision,
            plan_created_at=updated_at,
            plan_updated_at=updated_at,
        )
    created_at = updated_at
    for snapshot in ordered[1:]:
        if not snapshot.steps:
            break
        candidate = normalize_plan_timestamp(snapshot.created_at)
        if candidate is not None:
            created_at = candidate
    return PlanSeries(
        plan_state="active",
        steps=latest.steps,
        explanation=latest.explanation,
        revision=latest.revision,
        plan_created_at=created_at,
        plan_updated_at=updated_at,
    )


def _parse_plan_steps_for_update(
    payload: Mapping[str, JSONValue],
) -> tuple[tuple[PlanStep, ...] | None, PlanParseError | None]:
    if "steps" not in payload:
        return None, PlanParseError(field="steps", reason="missing")
    steps = parse_plan_steps(payload.get("steps"))
    if steps is None:
        return None, PlanParseError(field="steps", reason="invalid_steps")
    return steps, None


def _parse_plan_step(item: JSONValue) -> PlanStep | None:
    if not isinstance(item, Mapping):
        return None
    typed_item: dict[str, JSONValue] = {}
    for key, val in item.items():
        if not is_json_value(value=val):
            return None
        typed_item[str(key)] = val
    if not _has_only_allowed_keys(typed_item, allowed={"step", "status"}):
        return None
    step_val = typed_item.get("step")
    status_val = typed_item.get("status")
    if not isinstance(step_val, str) or not isinstance(status_val, str):
        return None
    if not _is_plan_status(status_val):
        return None
    return PlanStep(step=step_val, status=status_val)


def _has_only_allowed_keys(
    payload: Mapping[str, JSONValue],
    *,
    allowed: set[str],
) -> bool:
    return not any(str(key) not in allowed for key in payload)


def _is_plan_status(value: str) -> TypeGuard[PlanStepStatus]:
    return value in {"pending", "in_progress", "completed"}


def _parse_explanation(
    payload: Mapping[str, JSONValue],
) -> tuple[bool, str | None]:
    if "explanation" not in payload:
        return True, None
    explanation_val = payload.get("explanation")
    if explanation_val is None:
        return True, None
    if not isinstance(explanation_val, str):
        return False, None
    return True, explanation_val


def _parse_allow_empty(payload: Mapping[str, JSONValue]) -> bool | None:
    if "allow_empty" not in payload:
        return False
    allow_empty_raw = payload.get("allow_empty")
    if allow_empty_raw is None:
        return False
    allow_empty_val = as_bool(allow_empty_raw)
    if allow_empty_val is None:
        return None
    return bool(allow_empty_val)


def _count_in_progress(steps: Sequence[PlanStep]) -> int:
    return sum(1 for step in steps if step.status == "in_progress")


__all__ = (
    "PlanParseError",
    "PlanSeries",
    "PlanSnapshot",
    "PlanState",
    "PlanStep",
    "PlanStepStatus",
    "PlanUpdate",
    "ToolRuntimeContext",
    "derive_plan_series",
    "normalize_plan_timestamp",
    "parse_plan_steps",
    "parse_plan_update",
    "plan_error_details",
    "plan_steps_payload",
)
