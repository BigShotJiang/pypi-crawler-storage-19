"""Typed error hierarchy for agenterm."""

from __future__ import annotations

import asyncio


class AgentermError(Exception):
    """Base error for the CLI engine."""


class ConfigError(AgentermError):
    """Raised when configuration is invalid or inconsistent."""


class ValidationError(AgentermError):
    """Raised when user-provided or schema-validated values are invalid."""


class UsageError(AgentermError):
    """Raised when a CLI invocation is invalid or unsupported."""


class DispatchError(AgentermError):
    """Raised when command dispatch or routing fails."""


class PipelineError(AgentermError):
    """Raised for errors occurring during pipeline execution."""


class McpConnectError(AgentermError):
    """Raised when MCP discovery or connectivity fails."""


class ToolExecutionError(AgentermError):
    """Raised when a local tool executor fails in a way that aborts the workflow."""


class FilesystemError(AgentermError):
    """Raised when filesystem operations fail or paths cannot be resolved."""


class DatabaseError(AgentermError):
    """Raised when local SQLite store access or schema expectations fail."""


class AuthError(AgentermError):
    """Raised when authentication is missing or invalid."""


class RateLimitError(AgentermError):
    """Raised when provider rate limits prevent a request."""


class OperationTimeoutError(AgentermError):
    """Raised when an operation exceeds a configured timeout."""


class OperationCancelledError(asyncio.CancelledError):
    """Raised when a cooperative cancellation token is triggered."""

    def __init__(self, message: str | None = None) -> None:
        """Initialize the cancellation message for cooperative aborts."""
        super().__init__(message or "Operation cancelled.")


__all__ = (
    "AgentermError",
    "AuthError",
    "ConfigError",
    "DatabaseError",
    "DispatchError",
    "FilesystemError",
    "McpConnectError",
    "OperationCancelledError",
    "OperationTimeoutError",
    "PipelineError",
    "RateLimitError",
    "ToolExecutionError",
    "UsageError",
    "ValidationError",
)
