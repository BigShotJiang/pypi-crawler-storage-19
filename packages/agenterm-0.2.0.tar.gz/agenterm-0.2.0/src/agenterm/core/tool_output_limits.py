"""Shared output-length clamps for tool output envelopes."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, TypeVar

from agenterm.core.json_codec import dumps_compact, json_size

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.core.json_types import JSONValue
    from agenterm.core.tool_output_envelope import (
        FunctionToolOutputEnvelope,
        McpToolOutputEnvelope,
    )

_TEnv = TypeVar("_TEnv")
_ELLIPSIS = "..."
_ELLIPSIS_LEN = len(_ELLIPSIS)


def _truncate_text_to_fit(
    env: _TEnv,
    *,
    max_chars: int,
    text: str,
    apply_text: Callable[[_TEnv, str], _TEnv],
    length: Callable[[_TEnv], int],
) -> str:
    if max_chars <= 0:
        return ""
    low = 0
    high = len(text)
    best = ""
    while low <= high:
        mid = (low + high) // 2
        candidate = text[:mid]
        if length(apply_text(env, candidate)) <= max_chars:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def limit_tool_output_text(text: str, *, max_chars: int) -> str:
    """Return a truncated text tool output within max_chars."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    if max_chars <= _ELLIPSIS_LEN:
        return "." * max_chars
    return f"{text[: max_chars - _ELLIPSIS_LEN]}{_ELLIPSIS}"


def _function_env_size(env: FunctionToolOutputEnvelope) -> int:
    return json_size(env.to_json())


def _with_payload_preview(
    env: FunctionToolOutputEnvelope,
    preview: str,
) -> FunctionToolOutputEnvelope:
    payload: dict[str, JSONValue] = {"preview": preview}
    return replace(env, payload=payload)


def _with_function_error_message(
    env: FunctionToolOutputEnvelope,
    message: str,
) -> FunctionToolOutputEnvelope:
    if env.error is None:
        return env
    return replace(env, error=replace(env.error, message=message))


def _truncate_function_ok(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    preview = dumps_compact(
        env.payload,
        ensure_ascii=True,
        context="tool_output_limits.function.preview",
    )
    baseline = _with_payload_preview(env, "")
    if _function_env_size(baseline) > max_chars:
        return replace(env, payload={})
    fitted = _truncate_text_to_fit(
        env,
        max_chars=max_chars,
        text=preview,
        apply_text=_with_payload_preview,
        length=_function_env_size,
    )
    if not fitted:
        return replace(env, payload={})
    return _with_payload_preview(env, fitted)


def _truncate_function_error(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    error = env.error
    if error is None:
        return env
    if error.details:
        trimmed = replace(env, error=replace(error, details={}))
        if _function_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        error = env.error
        if error is None:
            return env
    if error.message:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=error.message,
            apply_text=_with_function_error_message,
            length=_function_env_size,
        )
        return _with_function_error_message(env, fitted)
    return env


def limit_function_tool_output(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    """Clamp a FunctionTool output envelope to max_chars."""
    if max_chars <= 0:
        return env
    if _function_env_size(env) <= max_chars:
        return env
    truncated_env = replace(env, truncated=True)
    if truncated_env.ok:
        return _truncate_function_ok(truncated_env, max_chars=max_chars)
    return _truncate_function_error(truncated_env, max_chars=max_chars)


def _mcp_env_size(env: McpToolOutputEnvelope) -> int:
    return json_size(env.to_json())


def _with_mcp_content_text(
    env: McpToolOutputEnvelope,
    text: str,
) -> McpToolOutputEnvelope:
    if env.content is None:
        return env
    return replace(env, content=replace(env.content, text=text))


def _with_mcp_error_message(
    env: McpToolOutputEnvelope,
    message: str,
) -> McpToolOutputEnvelope:
    if env.error is None:
        return env
    return replace(env, error=replace(env.error, message=message))


def _truncate_mcp_ok(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    content = env.content
    if content is None:
        return env
    if content.data is not None:
        trimmed = replace(env, content=replace(content, data=None))
        if _mcp_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        content = env.content
        if content is None:
            return env
    text = content.text
    if text:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=text,
            apply_text=_with_mcp_content_text,
            length=_mcp_env_size,
        )
        return _with_mcp_content_text(env, fitted)
    return env


def _truncate_mcp_error(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    error = env.error
    if error is None:
        return env
    if error.details:
        trimmed = replace(env, error=replace(error, details={}))
        if _mcp_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        error = env.error
        if error is None:
            return env
    if error.message:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=error.message,
            apply_text=_with_mcp_error_message,
            length=_mcp_env_size,
        )
        return _with_mcp_error_message(env, fitted)
    return env


def limit_mcp_tool_output(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    """Clamp an MCP output envelope to max_chars."""
    if max_chars <= 0:
        return env
    if _mcp_env_size(env) <= max_chars:
        return env
    truncated_env = replace(env, truncated=True)
    if truncated_env.ok:
        return _truncate_mcp_ok(truncated_env, max_chars=max_chars)
    return _truncate_mcp_error(truncated_env, max_chars=max_chars)


__all__ = (
    "limit_function_tool_output",
    "limit_mcp_tool_output",
    "limit_tool_output_text",
)
