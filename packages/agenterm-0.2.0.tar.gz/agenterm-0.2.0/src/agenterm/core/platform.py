"""Platform feature helpers for agenterm.

This module centralizes platform checks so tool availability can be made
consistent across:
- tool spec construction (selection/UI), and
- tool building (agent runtime).
"""

from __future__ import annotations

import sys


def is_macos() -> bool:
    """Return True when running on macOS (darwin)."""
    return sys.platform == "darwin"


__all__ = ("is_macos",)
