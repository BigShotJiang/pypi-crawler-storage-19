"""Unified retry helpers (bounded exponential backoff + jitter)."""

from __future__ import annotations

import asyncio
import secrets
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

_RANDOM = secrets.SystemRandom()


@dataclass(frozen=True)
class RetryPolicy:
    """Retry policy parameters shared across surfaces."""

    max_retries: int
    base_backoff_seconds: float
    max_backoff_seconds: float
    jitter_ratio: float
    retry_after_max_seconds: float | None = None


@dataclass(frozen=True)
class RetryDecision:
    """Classification result for a retryable error."""

    retry: bool
    label: str | None = None
    retry_after_seconds: float | None = None


@dataclass(frozen=True)
class RetryNotice:
    """Retry metadata surfaced to callers."""

    label: str
    attempt: int
    max_retries: int
    delay_seconds: float
    retry_after_seconds: float | None


def retry_delay_seconds(
    policy: RetryPolicy,
    *,
    attempt: int,
    retry_after_seconds: float | None,
    rand: Callable[[], float] | None = None,
) -> float:
    """Return the delay for the next retry attempt."""
    if (
        retry_after_seconds is not None
        and policy.retry_after_max_seconds is not None
        and 0 < retry_after_seconds <= policy.retry_after_max_seconds
    ):
        return max(0.0, retry_after_seconds)
    base = min(
        policy.base_backoff_seconds * (2**attempt),
        policy.max_backoff_seconds,
    )
    jitter = policy.jitter_ratio
    jitter_factor = 1.0 - (jitter * (rand() if rand is not None else _RANDOM.random()))
    return max(0.0, base * jitter_factor)


async def retry_async[T](
    func: Callable[[], Awaitable[T]],
    *,
    policy: RetryPolicy,
    retry_on: tuple[type[Exception], ...],
    classify: Callable[[Exception], RetryDecision],
    on_retry: Callable[[RetryNotice], None] | None = None,
    sleep: Callable[[float], Awaitable[None]] | None = None,
) -> T:
    """Execute func with retries based on classification."""
    sleeper = sleep or asyncio.sleep
    if not retry_on:
        msg = "retry_on must include at least one exception type"
        raise ValueError(msg)
    attempts = max(0, int(policy.max_retries)) + 1
    last_exc: Exception | None = None
    for attempt in range(attempts):
        try:
            return await func()
        except retry_on as exc:
            last_exc = exc
            decision = classify(exc)
            if not decision.retry or attempt >= attempts - 1:
                raise
            delay = retry_delay_seconds(
                policy,
                attempt=attempt,
                retry_after_seconds=decision.retry_after_seconds,
            )
            if on_retry is not None:
                label = decision.label or exc.__class__.__name__
                on_retry(
                    RetryNotice(
                        label=label,
                        attempt=attempt,
                        max_retries=attempts - 1,
                        delay_seconds=delay,
                        retry_after_seconds=decision.retry_after_seconds,
                    ),
                )
            await sleeper(delay)
    msg = "retry loop exited without returning"
    raise RuntimeError(msg) from last_exc


__all__ = (
    "RetryDecision",
    "RetryNotice",
    "RetryPolicy",
    "retry_async",
    "retry_delay_seconds",
)
