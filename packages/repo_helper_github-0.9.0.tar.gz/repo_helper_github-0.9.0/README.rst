###################
repo_helper_github
###################

.. start short_desc

**Manage GitHub repositories with repo-helper.**

.. end short_desc


.. start shields

.. list-table::
	:stub-columns: 1
	:widths: 10 90

	* - Docs
	  - |docs| |docs_check|
	* - Tests
	  - |actions_linux| |actions_windows| |actions_macos| |coveralls|
	* - PyPI
	  - |pypi-version| |supported-versions| |supported-implementations| |wheel|
	* - Activity
	  - |commits-latest| |commits-since| |maintained| |pypi-downloads|
	* - QA
	  - |codefactor| |actions_flake8| |actions_mypy|
	* - Other
	  - |license| |language| |requires|

.. |docs| image:: https://img.shields.io/readthedocs/repo-helper-github/latest?logo=read-the-docs
	:target: https://repo-helper-github.readthedocs.io/en/latest
	:alt: Documentation Build Status

.. |docs_check| image:: https://github.com/repo-helper/repo_helper_github/workflows/Docs%20Check/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22Docs+Check%22
	:alt: Docs Check Status

.. |actions_linux| image:: https://github.com/repo-helper/repo_helper_github/workflows/Linux/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22Linux%22
	:alt: Linux Test Status

.. |actions_windows| image:: https://github.com/repo-helper/repo_helper_github/workflows/Windows/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22Windows%22
	:alt: Windows Test Status

.. |actions_macos| image:: https://github.com/repo-helper/repo_helper_github/workflows/macOS/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22macOS%22
	:alt: macOS Test Status

.. |actions_flake8| image:: https://github.com/repo-helper/repo_helper_github/workflows/Flake8/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22Flake8%22
	:alt: Flake8 Status

.. |actions_mypy| image:: https://github.com/repo-helper/repo_helper_github/workflows/mypy/badge.svg
	:target: https://github.com/repo-helper/repo_helper_github/actions?query=workflow%3A%22mypy%22
	:alt: mypy status

.. |requires| image:: https://dependency-dash.repo-helper.uk/github/repo-helper/repo_helper_github/badge.svg
	:target: https://dependency-dash.repo-helper.uk/github/repo-helper/repo_helper_github/
	:alt: Requirements Status

.. |coveralls| image:: https://img.shields.io/coveralls/github/repo-helper/repo_helper_github/master?logo=coveralls
	:target: https://coveralls.io/github/repo-helper/repo_helper_github?branch=master
	:alt: Coverage

.. |codefactor| image:: https://img.shields.io/codefactor/grade/github/repo-helper/repo_helper_github?logo=codefactor
	:target: https://www.codefactor.io/repository/github/repo-helper/repo_helper_github
	:alt: CodeFactor Grade

.. |pypi-version| image:: https://img.shields.io/pypi/v/repo_helper_github
	:target: https://pypi.org/project/repo_helper_github/
	:alt: PyPI - Package Version

.. |supported-versions| image:: https://img.shields.io/pypi/pyversions/repo_helper_github?logo=python&logoColor=white
	:target: https://pypi.org/project/repo_helper_github/
	:alt: PyPI - Supported Python Versions

.. |supported-implementations| image:: https://img.shields.io/pypi/implementation/repo_helper_github
	:target: https://pypi.org/project/repo_helper_github/
	:alt: PyPI - Supported Implementations

.. |wheel| image:: https://img.shields.io/pypi/wheel/repo_helper_github
	:target: https://pypi.org/project/repo_helper_github/
	:alt: PyPI - Wheel

.. |license| image:: https://img.shields.io/github/license/repo-helper/repo_helper_github
	:target: https://github.com/repo-helper/repo_helper_github/blob/master/LICENSE
	:alt: License

.. |language| image:: https://img.shields.io/github/languages/top/repo-helper/repo_helper_github
	:alt: GitHub top language

.. |commits-since| image:: https://img.shields.io/github/commits-since/repo-helper/repo_helper_github/v0.9.0
	:target: https://github.com/repo-helper/repo_helper_github/pulse
	:alt: GitHub commits since tagged version

.. |commits-latest| image:: https://img.shields.io/github/last-commit/repo-helper/repo_helper_github
	:target: https://github.com/repo-helper/repo_helper_github/commit/master
	:alt: GitHub last commit

.. |maintained| image:: https://img.shields.io/maintenance/yes/2026
	:alt: Maintenance

.. |pypi-downloads| image:: https://img.shields.io/pypi/dm/repo_helper_github
	:target: https://pypistats.org/packages/repo_helper_github
	:alt: PyPI - Downloads

.. end shields

Installation
--------------

.. start installation

``repo_helper_github`` can be installed from PyPI.

To install with ``pip``:

.. code-block:: bash

	$ python -m pip install repo_helper_github

.. end installation
