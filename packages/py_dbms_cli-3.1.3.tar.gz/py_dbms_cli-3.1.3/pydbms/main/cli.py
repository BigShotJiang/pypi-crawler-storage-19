# pydbms/pydbms/main/cli.py

from .core import main

def run():
    main()