"""Tests for the GradientAI client."""

import os
import pytest
from unittest.mock import Mock, patch, MagicMock

from do_gradient_ai import GradientAI, Message, ChatResponse
from do_gradient_ai.clients.chat import ChatClient
from do_gradient_ai.clients.base import BaseClient
from do_gradient_ai.models.messages import normalize_messages


class TestMessage:
    """Tests for Message class."""

    def test_user_message(self):
        msg = Message.user("Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"

    def test_assistant_message(self):
        msg = Message.assistant("Hi there")
        assert msg.role == "assistant"
        assert msg.content == "Hi there"

    def test_system_message(self):
        msg = Message.system("Be helpful")
        assert msg.role == "system"
        assert msg.content == "Be helpful"

    def test_to_dict(self):
        msg = Message.user("Test")
        d = msg.to_dict()
        assert d == {"role": "user", "content": "Test"}

    def test_from_dict(self):
        msg = Message.from_dict({"role": "user", "content": "Test"})
        assert msg.role == "user"
        assert msg.content == "Test"


class TestNormalizeMessages:
    """Tests for message normalization."""

    def test_string_input(self):
        msgs = normalize_messages("Hello")
        assert len(msgs) == 1
        assert msgs[0].role == "user"
        assert msgs[0].content == "Hello"

    def test_string_with_system(self):
        msgs = normalize_messages("Hello", system="Be helpful")
        assert len(msgs) == 2
        assert msgs[0].role == "system"
        assert msgs[1].role == "user"

    def test_message_input(self):
        msg = Message.user("Hello")
        msgs = normalize_messages(msg)
        assert len(msgs) == 1
        assert msgs[0].content == "Hello"

    def test_dict_input(self):
        msgs = normalize_messages({"role": "user", "content": "Hello"})
        assert len(msgs) == 1
        assert msgs[0].role == "user"

    def test_list_input(self):
        msgs = normalize_messages([
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello"},
        ])
        assert len(msgs) == 2


class TestGradientAI:
    """Tests for the main GradientAI client."""

    def test_init_default(self):
        client = GradientAI()
        assert client._inference_key is None
        assert client._management_token is None

    def test_init_with_keys(self):
        client = GradientAI(
            inference_key="test-key",
            management_token="test-token",
        )
        assert client._inference_key == "test-key"
        assert client._management_token == "test-token"

    def test_lazy_initialization(self):
        client = GradientAI()
        assert client._chat is None
        # Access triggers initialization
        _ = client.chat
        assert client._chat is not None

    def test_repr(self):
        client = GradientAI(inference_key="test")
        repr_str = repr(client)
        assert "GradientAI" in repr_str
        assert "***" in repr_str  # Key should be masked


class TestChatClient:
    """Tests for ChatClient."""

    def test_default_model(self):
        client = ChatClient(inference_key="test")
        assert client.model == "llama3.3-70b-instruct"

    def test_custom_model(self):
        client = ChatClient(inference_key="test", model="custom-model")
        assert client.model == "custom-model"


class TestChatResponse:
    """Tests for ChatResponse parsing."""

    def test_from_api_response(self):
        api_response = {
            "id": "test-id",
            "model": "llama3.3-70b-instruct",
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": "Hello there!"
                    },
                    "finish_reason": "stop"
                }
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 5,
                "total_tokens": 15
            }
        }
        response = ChatResponse.from_api_response(api_response)
        assert response.content == "Hello there!"
        assert response.model == "llama3.3-70b-instruct"
        assert response.usage.total_tokens == 15

    def test_empty_choices(self):
        api_response = {
            "id": "test-id",
            "model": "test",
            "choices": []
        }
        response = ChatResponse.from_api_response(api_response)
        assert response.content == ""


# Integration tests (require API key)
@pytest.mark.skipif(
    not os.environ.get("GRADIENT_API_KEY"),
    reason="GRADIENT_API_KEY not set"
)
class TestIntegration:
    """Integration tests with real API."""

    def test_list_models(self):
        client = GradientAI()
        models = client.models.list()
        assert len(models) > 0
        assert any("llama" in m.id.lower() for m in models)

    def test_simple_completion(self):
        client = GradientAI()
        response = client.chat.complete(
            "Say 'test' and nothing else.",
            max_tokens=10,
        )
        assert response.content
        assert len(response.content) > 0

    def test_streaming(self):
        client = GradientAI()
        chunks = list(client.chat.stream(
            "Count from 1 to 3.",
            max_tokens=20,
        ))
        assert len(chunks) > 0
        full_text = "".join(chunks)
        assert "1" in full_text

    def test_callable_interface(self):
        client = GradientAI()
        result = client("Say hello", max_tokens=10)
        assert isinstance(result, str)
        assert len(result) > 0
