"""
Unified GradientAI client for DigitalOcean's Gradient AI platform.

Provides a single entry point for all Gradient AI capabilities:
- Serverless inference (chat completions)
- Knowledge bases (RAG)
- AI agents (managed assistants)
- Image generation
- Model management
"""

from typing import Optional, Dict, Any, List, Iterator, Union

from .clients.base import BaseClient
from .clients.chat import ChatClient
from .clients.knowledge_bases import KnowledgeBasesClient
from .clients.agents import AgentsClient
from .clients.models import ModelsClient, RegionsClient
from .clients.images import ImagesClient
from .models.messages import Message, ChatResponse, MessageInput
from .models.agent import Agent, AgentConfig


class GradientAI:
    """
    Unified client for DigitalOcean's Gradient AI platform.

    Provides access to all Gradient AI services through a single interface.
    Automatically handles authentication for both inference and management APIs.

    Authentication:
        - GRADIENT_API_KEY: Required for inference (chat, KB queries, agent chat)
        - DIGITALOCEAN_TOKEN: Required for management (create/update/delete resources)

    Example:
        >>> from do_gradient_ai import GradientAI
        >>>
        >>> # Initialize with environment variables
        >>> client = GradientAI()
        >>>
        >>> # Or with explicit keys
        >>> client = GradientAI(
        ...     inference_key="sk-do-...",
        ...     management_token="dop_v1_..."
        ... )
        >>>
        >>> # Chat completion
        >>> response = client.chat.complete("Hello!")
        >>> print(response.content)
        >>>
        >>> # Stream a response
        >>> for chunk in client.chat.stream("Tell me a story"):
        ...     print(chunk, end="")
        >>>
        >>> # Query a knowledge base
        >>> results = client.knowledge_bases.query(kb_id, "What is the return policy?")
        >>>
        >>> # Chat with an agent
        >>> response = client.agents.chat(agent_id, "Help me with my order")

    Attributes:
        chat: ChatClient for completions
        knowledge_bases: KnowledgeBasesClient for RAG
        agents: AgentsClient for managed assistants
        models: ModelsClient for model listing
        regions: RegionsClient for region listing
        images: ImagesClient for image generation
    """

    def __init__(
        self,
        inference_key: Optional[str] = None,
        management_token: Optional[str] = None,
        model: Optional[str] = None,
        timeout: int = 300,
    ):
        """
        Initialize the Gradient AI client.

        Args:
            inference_key: Model access key (env: GRADIENT_API_KEY)
            management_token: DigitalOcean API token (env: DIGITALOCEAN_TOKEN)
            model: Default model for chat completions
            timeout: Request timeout in seconds (default: 300)
        """
        # Store common config
        self._inference_key = inference_key
        self._management_token = management_token
        self._timeout = timeout
        self._model = model

        # Initialize sub-clients lazily
        self._chat: Optional[ChatClient] = None
        self._knowledge_bases: Optional[KnowledgeBasesClient] = None
        self._agents: Optional[AgentsClient] = None
        self._models: Optional[ModelsClient] = None
        self._regions: Optional[RegionsClient] = None
        self._images: Optional[ImagesClient] = None

    @property
    def chat(self) -> ChatClient:
        """Access chat completions client."""
        if self._chat is None:
            self._chat = ChatClient(
                inference_key=self._inference_key,
                model=self._model,
                timeout=self._timeout,
            )
        return self._chat

    @property
    def knowledge_bases(self) -> KnowledgeBasesClient:
        """Access knowledge bases client for RAG."""
        if self._knowledge_bases is None:
            self._knowledge_bases = KnowledgeBasesClient(
                inference_key=self._inference_key,
                management_token=self._management_token,
                timeout=self._timeout,
            )
        return self._knowledge_bases

    @property
    def agents(self) -> AgentsClient:
        """Access agents client for managed AI assistants."""
        if self._agents is None:
            self._agents = AgentsClient(
                inference_key=self._inference_key,
                management_token=self._management_token,
                timeout=self._timeout,
            )
        return self._agents

    @property
    def models(self) -> ModelsClient:
        """Access models client for listing available models."""
        if self._models is None:
            self._models = ModelsClient(
                inference_key=self._inference_key,
                timeout=self._timeout,
            )
        return self._models

    @property
    def regions(self) -> RegionsClient:
        """Access regions client for listing available regions."""
        if self._regions is None:
            self._regions = RegionsClient(
                management_token=self._management_token,
                timeout=self._timeout,
            )
        return self._regions

    @property
    def images(self) -> ImagesClient:
        """Access images client for image generation."""
        if self._images is None:
            self._images = ImagesClient(
                inference_key=self._inference_key,
                timeout=self._timeout,
            )
        return self._images

    # Convenience methods for common operations

    def complete(
        self,
        messages: MessageInput,
        model: Optional[str] = None,
        **kwargs,
    ) -> ChatResponse:
        """
        Generate a chat completion (convenience method).

        Args:
            messages: Input messages (string, Message, dict, or list)
            model: Model to use
            **kwargs: Additional parameters

        Returns:
            ChatResponse with generated content

        Example:
            >>> response = client.complete("What is Python?")
            >>> print(response.content)
        """
        return self.chat.complete(messages, model=model, **kwargs)

    def stream(
        self,
        messages: MessageInput,
        model: Optional[str] = None,
        **kwargs,
    ) -> Iterator[str]:
        """
        Stream a chat completion (convenience method).

        Args:
            messages: Input messages
            model: Model to use
            **kwargs: Additional parameters

        Yields:
            Text chunks

        Example:
            >>> for chunk in client.stream("Tell me a story"):
            ...     print(chunk, end="", flush=True)
        """
        return self.chat.stream(messages, model=model, **kwargs)

    def list_models(self) -> List[str]:
        """
        List available model IDs (convenience method).

        Returns:
            List of model ID strings
        """
        return self.models.list_ids()

    def query_knowledge_base(
        self,
        kb_id: str,
        query: str,
        num_results: int = 5,
        **kwargs,
    ):
        """
        Query a knowledge base (convenience method).

        Args:
            kb_id: Knowledge base UUID
            query: Search query
            num_results: Number of results
            **kwargs: Additional parameters

        Returns:
            RetrievalResponse with results
        """
        return self.knowledge_bases.query(kb_id, query, num_results=num_results, **kwargs)

    def agent_chat(
        self,
        agent_id: str,
        messages: MessageInput,
        **kwargs,
    ):
        """
        Chat with an agent (convenience method).

        Args:
            agent_id: Agent UUID
            messages: User message(s)
            **kwargs: Additional parameters

        Returns:
            AgentChatResponse with content and citations
        """
        return self.agents.chat(agent_id, messages, **kwargs)

    def __call__(self, prompt: str, **kwargs) -> str:
        """
        Shorthand for simple completions.

        Args:
            prompt: User prompt
            **kwargs: Additional parameters

        Returns:
            Generated text content

        Example:
            >>> text = client("What is Python?")
        """
        return self.chat(prompt, **kwargs)

    def __repr__(self) -> str:
        return (
            f"GradientAI(model={self._model or 'default'}, "
            f"inference_key={'***' if self._inference_key else 'env'}, "
            f"management_token={'***' if self._management_token else 'env'})"
        )


# Alias for backwards compatibility
Client = GradientAI
