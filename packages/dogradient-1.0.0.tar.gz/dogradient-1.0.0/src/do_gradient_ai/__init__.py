"""
DigitalOcean Gradient AI Platform - Complete Python SDK

A comprehensive, unofficial Python client for the DigitalOcean Gradient AI Platform.
Provides full access to serverless inference, knowledge bases, agents, and more.

Quick Start:
    from do_gradient_ai import GradientAI

    # Initialize client
    client = GradientAI(api_key="your-key")

    # Chat completion
    response = client.chat.complete("What is Python?")
    print(response.content)

    # Stream completion
    for chunk in client.chat.stream("Explain AI"):
        print(chunk, end="")

    # Knowledge base query
    results = client.knowledge_bases.query(kb_id, "search query")

    # List available models
    models = client.models.list()

Features:
    - Serverless inference with 23+ models (Llama, Claude, GPT, Mistral, etc.)
    - Knowledge bases with RAG (create, manage, query with citations)
    - AI agents (create, configure, chat)
    - Image generation
    - Streaming support
    - Async support
    - CLI tool included

Installation:
    pip install do-gradient-ai

Environment Variables:
    GRADIENT_API_KEY - Model access key for inference
    DIGITALOCEAN_TOKEN - API token for management operations

Documentation:
    https://docs.digitalocean.com/products/gradient-ai-platform/

Author: Luke Steuber
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Luke Steuber"
__email__ = "luke@lukesteuber.com"

from .client import GradientAI
from .clients.chat import ChatClient
from .clients.knowledge_bases import KnowledgeBasesClient
from .clients.agents import AgentsClient
from .clients.models import ModelsClient
from .clients.images import ImagesClient

from .models.messages import Message, ChatResponse, StreamChunk
from .models.knowledge_base import (
    KnowledgeBase,
    DataSource,
    RetrievalResult,
    ChunkingStrategy,
)
from .models.agent import Agent, AgentConfig
from .models.common import Usage, Model

__all__ = [
    # Main client
    "GradientAI",
    # Sub-clients
    "ChatClient",
    "KnowledgeBasesClient",
    "AgentsClient",
    "ModelsClient",
    "ImagesClient",
    # Message models
    "Message",
    "ChatResponse",
    "StreamChunk",
    # Knowledge base models
    "KnowledgeBase",
    "DataSource",
    "RetrievalResult",
    "ChunkingStrategy",
    # Agent models
    "Agent",
    "AgentConfig",
    # Common models
    "Usage",
    "Model",
    # Version
    "__version__",
]
