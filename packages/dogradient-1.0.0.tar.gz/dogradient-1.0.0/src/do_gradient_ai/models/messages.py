"""Message and chat response models."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List, Union
from .common import Usage


@dataclass
class Message:
    """
    Chat message for conversations.

    Attributes:
        role: Message role - "system", "user", or "assistant"
        content: Message content text
        name: Optional name for the message author
        metadata: Optional additional metadata

    Example:
        >>> msg = Message(role="user", content="Hello!")
        >>> msg = Message.user("Hello!")
        >>> msg = Message.system("You are helpful.")
    """
    role: str
    content: str
    name: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API-compatible dictionary."""
        d = {"role": self.role, "content": self.content}
        if self.name:
            d["name"] = self.name
        return d

    @classmethod
    def user(cls, content: str, **kwargs) -> "Message":
        """Create a user message."""
        return cls(role="user", content=content, **kwargs)

    @classmethod
    def assistant(cls, content: str, **kwargs) -> "Message":
        """Create an assistant message."""
        return cls(role="assistant", content=content, **kwargs)

    @classmethod
    def system(cls, content: str, **kwargs) -> "Message":
        """Create a system message."""
        return cls(role="system", content=content, **kwargs)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Message":
        """Create from dictionary."""
        return cls(
            role=data.get("role", "user"),
            content=data.get("content", ""),
            name=data.get("name"),
            metadata=data.get("metadata"),
        )


@dataclass
class ChatResponse:
    """
    Response from a chat completion.

    Attributes:
        content: Generated text content
        model: Model ID used for generation
        usage: Token usage statistics
        finish_reason: Why generation stopped ("stop", "length", etc.)
        id: Unique response ID
        metadata: Additional response metadata
    """
    content: str
    model: str
    usage: Usage
    finish_reason: Optional[str] = None
    id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "ChatResponse":
        """Create from API response dictionary."""
        choices = data.get("choices", [{}])
        choice = choices[0] if choices else {}
        message = choice.get("message", {})

        return cls(
            content=message.get("content", ""),
            model=data.get("model", ""),
            usage=Usage.from_dict(data.get("usage", {})),
            finish_reason=choice.get("finish_reason"),
            id=data.get("id"),
            metadata={
                "created": data.get("created"),
                "object": data.get("object"),
            },
        )

    def __str__(self) -> str:
        return self.content


@dataclass
class StreamChunk:
    """
    A chunk from a streaming response.

    Attributes:
        content: Text content of this chunk
        finish_reason: Set on final chunk if generation complete
        model: Model ID (usually only on first chunk)
        id: Response ID (usually only on first chunk)
    """
    content: str
    finish_reason: Optional[str] = None
    model: Optional[str] = None
    id: Optional[str] = None

    @classmethod
    def from_api_chunk(cls, data: Dict[str, Any]) -> "StreamChunk":
        """Create from API stream chunk."""
        choices = data.get("choices", [{}])
        choice = choices[0] if choices else {}
        delta = choice.get("delta", {})

        return cls(
            content=delta.get("content", ""),
            finish_reason=choice.get("finish_reason"),
            model=data.get("model"),
            id=data.get("id"),
        )


# Type alias for message input flexibility
MessageInput = Union[Message, Dict[str, str], str]


def normalize_messages(
    messages: Union[List[MessageInput], MessageInput, None],
    system: Optional[str] = None,
) -> List[Message]:
    """
    Normalize various message input formats to List[Message].

    Accepts:
        - List of Message objects
        - List of dicts with role/content
        - Single string (converted to user message)
        - None with system prompt

    Args:
        messages: Input messages in various formats
        system: Optional system prompt to prepend

    Returns:
        Normalized list of Message objects
    """
    result = []

    # Add system message if provided
    if system:
        result.append(Message.system(system))

    # Handle None
    if messages is None:
        return result

    # Handle single string
    if isinstance(messages, str):
        result.append(Message.user(messages))
        return result

    # Handle single message
    if isinstance(messages, Message):
        result.append(messages)
        return result

    if isinstance(messages, dict):
        result.append(Message.from_dict(messages))
        return result

    # Handle list
    for msg in messages:
        if isinstance(msg, Message):
            result.append(msg)
        elif isinstance(msg, dict):
            result.append(Message.from_dict(msg))
        elif isinstance(msg, str):
            result.append(Message.user(msg))

    return result
