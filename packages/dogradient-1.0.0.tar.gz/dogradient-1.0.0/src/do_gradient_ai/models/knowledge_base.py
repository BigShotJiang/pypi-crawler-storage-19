"""Knowledge base data models."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime
from enum import Enum


class ChunkingStrategy(str, Enum):
    """Available chunking strategies for knowledge bases."""
    SECTION_BASED = "CHUNKING_ALGORITHM_SECTION_BASED"
    SEMANTIC = "CHUNKING_ALGORITHM_SEMANTIC"
    HIERARCHICAL = "CHUNKING_ALGORITHM_HIERARCHICAL"
    FIXED_LENGTH = "CHUNKING_ALGORITHM_FIXED_LENGTH"


class DataSourceType(str, Enum):
    """Types of data sources for knowledge bases."""
    FILE = "file"
    SPACES = "spaces"
    WEB_CRAWLER = "web_crawler"
    DROPBOX = "dropbox"
    S3 = "s3"


@dataclass
class ChunkingOptions:
    """
    Chunking configuration options.

    Attributes:
        max_chunk_size: Maximum tokens per chunk (section/semantic/fixed)
        parent_chunk_size: Parent chunk size for hierarchical chunking
        child_chunk_size: Child chunk size for hierarchical chunking
        semantic_threshold: Similarity threshold for semantic chunking (0-1)
    """
    max_chunk_size: Optional[int] = None
    parent_chunk_size: Optional[int] = None
    child_chunk_size: Optional[int] = None
    semantic_threshold: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API-compatible dictionary."""
        d = {}
        if self.max_chunk_size is not None:
            d["max_chunk_size"] = self.max_chunk_size
        if self.parent_chunk_size is not None:
            d["parent_chunk_size"] = self.parent_chunk_size
        if self.child_chunk_size is not None:
            d["child_chunk_size"] = self.child_chunk_size
        if self.semantic_threshold is not None:
            d["semantic_threshold"] = self.semantic_threshold
        return d

    @classmethod
    def section_based(cls, max_size: int = 500) -> "ChunkingOptions":
        """Create section-based chunking options."""
        return cls(max_chunk_size=max_size)

    @classmethod
    def semantic(cls, max_size: int = 500, threshold: float = 0.5) -> "ChunkingOptions":
        """Create semantic chunking options."""
        return cls(max_chunk_size=max_size, semantic_threshold=threshold)

    @classmethod
    def hierarchical(cls, parent_size: int = 1000, child_size: int = 350) -> "ChunkingOptions":
        """Create hierarchical chunking options."""
        return cls(parent_chunk_size=parent_size, child_chunk_size=child_size)

    @classmethod
    def fixed_length(cls, size: int = 500) -> "ChunkingOptions":
        """Create fixed-length chunking options."""
        return cls(max_chunk_size=size)


@dataclass
class DataSource:
    """
    A data source attached to a knowledge base.

    Attributes:
        id: Unique identifier
        type: Type of data source
        name: Display name
        config: Source-specific configuration
        chunking_strategy: How to chunk the content
        chunking_options: Chunking parameters
        status: Current indexing status
        created_at: Creation timestamp
    """
    id: str
    type: DataSourceType
    name: Optional[str] = None
    config: Dict[str, Any] = field(default_factory=dict)
    chunking_strategy: ChunkingStrategy = ChunkingStrategy.SECTION_BASED
    chunking_options: Optional[ChunkingOptions] = None
    status: Optional[str] = None
    created_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DataSource":
        """Create from API response dictionary."""
        # Determine type from config keys
        source_type = DataSourceType.FILE
        if "spaces_data_source" in data:
            source_type = DataSourceType.SPACES
        elif "web_crawler_data_source" in data:
            source_type = DataSourceType.WEB_CRAWLER
        elif "dropbox_data_source" in data:
            source_type = DataSourceType.DROPBOX
        elif "s3_data_source" in data:
            source_type = DataSourceType.S3

        chunking_options = None
        if "chunking_options" in data:
            chunking_options = ChunkingOptions(
                max_chunk_size=data["chunking_options"].get("max_chunk_size"),
                parent_chunk_size=data["chunking_options"].get("parent_chunk_size"),
                child_chunk_size=data["chunking_options"].get("child_chunk_size"),
                semantic_threshold=data["chunking_options"].get("semantic_threshold"),
            )

        return cls(
            id=data.get("uuid", data.get("id", "")),
            type=source_type,
            name=data.get("name"),
            config=data,
            chunking_strategy=ChunkingStrategy(data.get("chunking_algorithm", ChunkingStrategy.SECTION_BASED)),
            chunking_options=chunking_options,
            status=data.get("status"),
            created_at=data.get("created_at"),
        )

    @classmethod
    def spaces(
        cls,
        bucket_name: str,
        region: str,
        folder: Optional[str] = None,
        chunking: ChunkingStrategy = ChunkingStrategy.SECTION_BASED,
        chunking_options: Optional[ChunkingOptions] = None,
    ) -> Dict[str, Any]:
        """Create Spaces data source configuration."""
        config = {
            "spaces_data_source": {
                "bucket_name": bucket_name,
                "region": region,
            },
            "chunking_algorithm": chunking.value,
        }
        if folder:
            config["spaces_data_source"]["folder"] = folder
        if chunking_options:
            config["chunking_options"] = chunking_options.to_dict()
        return config

    @classmethod
    def web_crawler(
        cls,
        base_url: str,
        crawling_option: str = "SCOPED",
        max_pages: int = 100,
        exclude_tags: Optional[List[str]] = None,
        chunking: ChunkingStrategy = ChunkingStrategy.SECTION_BASED,
        chunking_options: Optional[ChunkingOptions] = None,
    ) -> Dict[str, Any]:
        """Create web crawler data source configuration."""
        config = {
            "web_crawler_data_source": {
                "base_url": base_url,
                "crawling_option": crawling_option,
                "max_pages": max_pages,
                "embed_media": False,
            },
            "chunking_algorithm": chunking.value,
        }
        if exclude_tags:
            config["web_crawler_data_source"]["exclude_tags"] = exclude_tags
        if chunking_options:
            config["chunking_options"] = chunking_options.to_dict()
        return config


@dataclass
class RetrievalResult:
    """
    A single result from knowledge base retrieval.

    Attributes:
        text: The retrieved text content
        score: Relevance score
        metadata: Source metadata (item_name, timestamps, etc.)
        citation: Source citation information
    """
    text: str
    score: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    citation: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RetrievalResult":
        """Create from API response dictionary."""
        metadata = data.get("metadata", {})
        return cls(
            text=data.get("text_content", data.get("text", "")),
            score=data.get("score"),
            metadata=metadata,
            citation=metadata.get("item_name"),
        )

    @property
    def source(self) -> Optional[str]:
        """Get the source URL or filename."""
        return self.metadata.get("item_name")


@dataclass
class RetrievalResponse:
    """
    Response from a knowledge base query.

    Attributes:
        results: List of retrieval results
        total: Total number of results
        query: Original query string
    """
    results: List[RetrievalResult]
    total: int
    query: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any], query: Optional[str] = None) -> "RetrievalResponse":
        """Create from API response dictionary."""
        results = [
            RetrievalResult.from_dict(r)
            for r in data.get("results", [])
        ]
        return cls(
            results=results,
            total=data.get("total_results", len(results)),
            query=query,
        )


@dataclass
class IndexingJob:
    """
    An indexing job for a knowledge base data source.

    Attributes:
        id: Job identifier
        status: Current status (pending, running, completed, failed)
        data_source_id: Associated data source
        created_at: When the job was created
        completed_at: When the job finished
        error: Error message if failed
    """
    id: str
    status: str
    data_source_id: Optional[str] = None
    created_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IndexingJob":
        """Create from API response dictionary."""
        return cls(
            id=data.get("id", data.get("uuid", "")),
            status=data.get("status", "unknown"),
            data_source_id=data.get("data_source_uuid"),
            created_at=data.get("created_at"),
            completed_at=data.get("completed_at"),
            error=data.get("error"),
        )


@dataclass
class IndexingSchedule:
    """
    A scheduled indexing job.

    Attributes:
        id: Schedule identifier
        knowledge_base_id: Associated knowledge base
        time: Time of day to run (HH:MM)
        days: Days of week to run (1=Mon, 7=Sun)
    """
    id: str
    knowledge_base_id: str
    time: str
    days: List[int]

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IndexingSchedule":
        """Create from API response dictionary."""
        return cls(
            id=data.get("id", data.get("uuid", "")),
            knowledge_base_id=data.get("knowledge_base_uuid", ""),
            time=data.get("time", ""),
            days=data.get("days", []),
        )


@dataclass
class KnowledgeBase:
    """
    A knowledge base for RAG.

    Attributes:
        id: Unique identifier (UUID)
        name: Display name
        description: Optional description
        project_id: Associated project
        region: Datacenter region
        embedding_model: Model used for embeddings
        data_sources: Attached data sources
        status: Current status
        tags: Associated tags
        created_at: Creation timestamp
        metadata: Additional metadata
    """
    id: str
    name: str
    description: Optional[str] = None
    project_id: Optional[str] = None
    region: Optional[str] = None
    embedding_model: Optional[str] = None
    data_sources: List[DataSource] = field(default_factory=list)
    status: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    created_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KnowledgeBase":
        """Create from API response dictionary."""
        data_sources = [
            DataSource.from_dict(ds)
            for ds in data.get("datasources", data.get("data_sources", []))
        ]

        return cls(
            id=data.get("uuid", data.get("id", "")),
            name=data.get("name", ""),
            description=data.get("description"),
            project_id=data.get("project_id"),
            region=data.get("region"),
            embedding_model=data.get("embedding_model_uuid"),
            data_sources=data_sources,
            status=data.get("status"),
            tags=data.get("tags", []),
            created_at=data.get("created_at"),
            metadata=data,
        )
