"""Agent data models."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class AgentRoute:
    """
    A route to another agent for multi-agent routing.

    Attributes:
        id: Route identifier
        target_agent_id: Agent to route to
        description: When to use this route
        priority: Route priority (lower = higher priority)
    """
    id: str
    target_agent_id: str
    description: Optional[str] = None
    priority: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentRoute":
        """Create from API response dictionary."""
        return cls(
            id=data.get("id", data.get("uuid", "")),
            target_agent_id=data.get("target_agent_uuid", ""),
            description=data.get("description"),
            priority=data.get("priority", 0),
        )


@dataclass
class AgentConfig:
    """
    Configuration for creating or updating an agent.

    Attributes:
        name: Agent display name
        model_id: Foundation model UUID
        instruction: System instructions for the agent
        description: Agent description
        project_id: Associated project UUID
        region: Datacenter region (e.g., "tor1", "nyc1")
        knowledge_base_ids: Knowledge bases to attach
        tags: Tags for organization
        temperature: Response randomness (0-1)
        max_tokens: Maximum response tokens
        guardrails: Safety guardrail configuration
    """
    name: str
    model_id: str
    instruction: str
    project_id: str
    region: str = "tor1"
    description: Optional[str] = None
    knowledge_base_ids: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    guardrails: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to API request dictionary."""
        d = {
            "name": self.name,
            "model_uuid": self.model_id,
            "instruction": self.instruction,
            "project_id": self.project_id,
            "region": self.region,
        }

        if self.description:
            d["description"] = self.description
        if self.knowledge_base_ids:
            d["knowledge_base_uuid"] = self.knowledge_base_ids
        if self.tags:
            d["tags"] = self.tags
        if self.temperature is not None:
            d["temperature"] = self.temperature
        if self.max_tokens is not None:
            d["max_tokens"] = self.max_tokens
        if self.guardrails:
            d["guardrails"] = self.guardrails

        return d


@dataclass
class Agent:
    """
    An AI agent on the Gradient platform.

    Attributes:
        id: Unique identifier (UUID)
        name: Display name
        model_id: Foundation model UUID
        instruction: System instructions
        description: Agent description
        project_id: Associated project
        region: Datacenter region
        knowledge_base_ids: Attached knowledge bases
        routes: Agent routes for multi-agent routing
        endpoint: Chat endpoint URL
        status: Current status
        tags: Associated tags
        created_at: Creation timestamp
        updated_at: Last update timestamp
        metadata: Additional metadata
    """
    id: str
    name: str
    model_id: Optional[str] = None
    instruction: Optional[str] = None
    description: Optional[str] = None
    project_id: Optional[str] = None
    region: Optional[str] = None
    knowledge_base_ids: List[str] = field(default_factory=list)
    routes: List[AgentRoute] = field(default_factory=list)
    endpoint: Optional[str] = None
    status: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Agent":
        """Create from API response dictionary."""
        routes = [
            AgentRoute.from_dict(r)
            for r in data.get("routes", [])
        ]

        kb_ids = data.get("knowledge_base_uuid", data.get("knowledge_base_ids", []))
        if isinstance(kb_ids, str):
            kb_ids = [kb_ids]

        return cls(
            id=data.get("uuid", data.get("id", "")),
            name=data.get("name", ""),
            model_id=data.get("model_uuid"),
            instruction=data.get("instruction"),
            description=data.get("description"),
            project_id=data.get("project_id"),
            region=data.get("region"),
            knowledge_base_ids=kb_ids,
            routes=routes,
            endpoint=data.get("endpoint"),
            status=data.get("status"),
            tags=data.get("tags", []),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            metadata=data,
        )

    @property
    def chat_url(self) -> Optional[str]:
        """Get the chat endpoint URL."""
        if self.endpoint:
            return self.endpoint
        if self.id:
            return f"https://agent.do-ai.run/{self.id}"
        return None


@dataclass
class AgentChatResponse:
    """
    Response from an agent chat.

    Attributes:
        content: Generated response text
        agent_id: Agent that generated the response
        citations: Knowledge base citations used
        usage: Token usage (if available)
        metadata: Additional response metadata
    """
    content: str
    agent_id: str
    citations: List[Dict[str, Any]] = field(default_factory=list)
    usage: Optional[Dict[str, int]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any], agent_id: str = "") -> "AgentChatResponse":
        """Create from API response dictionary."""
        choices = data.get("choices", [{}])
        choice = choices[0] if choices else {}
        message = choice.get("message", {})

        return cls(
            content=message.get("content", ""),
            agent_id=agent_id,
            citations=data.get("citations", []),
            usage=data.get("usage"),
            metadata=data,
        )
