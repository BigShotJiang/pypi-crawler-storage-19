"""Common data models used across the SDK."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class Usage:
    """Token usage statistics."""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Usage":
        return cls(
            prompt_tokens=data.get("prompt_tokens", 0),
            completion_tokens=data.get("completion_tokens", 0),
            total_tokens=data.get("total_tokens", 0),
        )


@dataclass
class Model:
    """AI model information."""
    id: str
    name: str
    provider: Optional[str] = None
    description: Optional[str] = None
    context_length: Optional[int] = None
    capabilities: List[str] = field(default_factory=list)
    created_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Model":
        return cls(
            id=data.get("id", data.get("uuid", "")),
            name=data.get("name", data.get("id", "")),
            provider=data.get("provider", data.get("owned_by")),
            description=data.get("description"),
            context_length=data.get("context_length"),
            capabilities=data.get("capabilities", []),
            created_at=data.get("created_at"),
            metadata=data,
        )


@dataclass
class Region:
    """DigitalOcean region information."""
    slug: str
    name: str
    available: bool = True
    features: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Region":
        return cls(
            slug=data.get("slug", ""),
            name=data.get("name", ""),
            available=data.get("available", True),
            features=data.get("features", []),
        )


@dataclass
class Project:
    """DigitalOcean project information."""
    id: str
    name: str
    description: Optional[str] = None
    environment: Optional[str] = None
    is_default: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Project":
        return cls(
            id=data.get("id", data.get("uuid", "")),
            name=data.get("name", ""),
            description=data.get("description"),
            environment=data.get("environment"),
            is_default=data.get("is_default", False),
        )


@dataclass
class APIError(Exception):
    """API error with details."""
    message: str
    status_code: int
    error_type: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

    def __str__(self) -> str:
        return f"[{self.status_code}] {self.error_type or 'Error'}: {self.message}"
