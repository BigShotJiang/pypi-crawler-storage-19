#!/usr/bin/env python3
"""
Command-line interface for DigitalOcean Gradient AI Platform.

Usage:
    gradient chat "Your message here"
    gradient chat --stream "Tell me a story"
    gradient models list
    gradient kb query <kb-id> "search query"
    gradient agent chat <agent-id> "message"
"""

import argparse
import json
import os
import sys
from typing import Optional

from . import __version__, GradientAI
from .models.messages import Message


def get_client(args) -> GradientAI:
    """Create client with args/environment."""
    return GradientAI(
        inference_key=getattr(args, 'api_key', None),
        management_token=getattr(args, 'token', None),
        model=getattr(args, 'model', None),
    )


def cmd_chat(args):
    """Handle chat command."""
    client = get_client(args)

    # Build messages
    messages = []
    if args.system:
        messages.append(Message.system(args.system))

    # Read from stdin if no message provided
    if args.message:
        user_input = args.message
    elif not sys.stdin.isatty():
        user_input = sys.stdin.read().strip()
    else:
        print("Error: No message provided. Use -m or pipe input.", file=sys.stderr)
        sys.exit(1)

    messages.append(Message.user(user_input))

    try:
        if args.stream:
            for chunk in client.chat.stream(
                messages,
                model=args.model,
                temperature=args.temperature,
                max_tokens=args.max_tokens,
            ):
                print(chunk, end="", flush=True)
            print()  # Final newline
        else:
            response = client.chat.complete(
                messages,
                model=args.model,
                temperature=args.temperature,
                max_tokens=args.max_tokens,
            )
            if args.json:
                print(json.dumps({
                    "content": response.content,
                    "model": response.model,
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens if response.usage else None,
                        "completion_tokens": response.usage.completion_tokens if response.usage else None,
                        "total_tokens": response.usage.total_tokens if response.usage else None,
                    }
                }, indent=2))
            else:
                print(response.content)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_models_list(args):
    """List available models."""
    client = get_client(args)

    try:
        models = client.models.list()

        if args.json:
            print(json.dumps([{
                "id": m.id,
                "name": m.name,
                "provider": m.provider,
                "context_length": m.context_length,
            } for m in models], indent=2))
        else:
            print(f"Found {len(models)} models:\n")
            for m in models:
                ctx = f" ({m.context_length:,} ctx)" if m.context_length else ""
                provider = f" [{m.provider}]" if m.provider else ""
                print(f"  {m.id}{provider}{ctx}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_models_get(args):
    """Get model details."""
    client = get_client(args)

    try:
        model = client.models.get(args.model_id)

        if args.json:
            print(json.dumps({
                "id": model.id,
                "name": model.name,
                "provider": model.provider,
                "context_length": model.context_length,
                "description": model.description,
            }, indent=2))
        else:
            print(f"Model: {model.id}")
            if model.name:
                print(f"Name: {model.name}")
            if model.provider:
                print(f"Provider: {model.provider}")
            if model.context_length:
                print(f"Context Length: {model.context_length:,}")
            if model.description:
                print(f"Description: {model.description}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_kb_list(args):
    """List knowledge bases."""
    client = get_client(args)

    try:
        kbs = client.knowledge_bases.list()

        if args.json:
            print(json.dumps([{
                "id": kb.id,
                "name": kb.name,
                "region": kb.region,
                "status": kb.status,
            } for kb in kbs], indent=2))
        else:
            if not kbs:
                print("No knowledge bases found.")
            else:
                print(f"Found {len(kbs)} knowledge base(s):\n")
                for kb in kbs:
                    status = f" [{kb.status}]" if kb.status else ""
                    region = f" ({kb.region})" if kb.region else ""
                    print(f"  {kb.id}: {kb.name}{region}{status}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_kb_query(args):
    """Query a knowledge base."""
    client = get_client(args)

    try:
        results = client.knowledge_bases.query(
            args.kb_id,
            args.query,
            num_results=args.num_results,
        )

        if args.json:
            print(json.dumps({
                "query": results.query,
                "results": [{
                    "text": r.text,
                    "score": r.score,
                    "source": r.source,
                } for r in results.results]
            }, indent=2))
        else:
            print(f"Query: {results.query}\n")
            print(f"Found {len(results.results)} result(s):\n")
            for i, r in enumerate(results.results, 1):
                score = f" (score: {r.score:.3f})" if r.score else ""
                source = f"\n  Source: {r.source}" if r.source else ""
                text = r.text[:200] + "..." if len(r.text) > 200 else r.text
                print(f"{i}.{score}{source}")
                print(f"   {text}\n")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_agents_list(args):
    """List agents."""
    client = get_client(args)

    try:
        agents = client.agents.list()

        if args.json:
            print(json.dumps([{
                "id": a.id,
                "name": a.name,
                "model": a.model_id,
                "status": a.status,
            } for a in agents], indent=2))
        else:
            if not agents:
                print("No agents found.")
            else:
                print(f"Found {len(agents)} agent(s):\n")
                for a in agents:
                    status = f" [{a.status}]" if a.status else ""
                    model = f" ({a.model_id})" if a.model_id else ""
                    print(f"  {a.id}: {a.name}{model}{status}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_agent_chat(args):
    """Chat with an agent."""
    client = get_client(args)

    # Read message
    if args.message:
        user_input = args.message
    elif not sys.stdin.isatty():
        user_input = sys.stdin.read().strip()
    else:
        print("Error: No message provided. Use -m or pipe input.", file=sys.stderr)
        sys.exit(1)

    try:
        if args.stream:
            for chunk in client.agents.stream_chat(args.agent_id, user_input):
                print(chunk, end="", flush=True)
            print()
        else:
            response = client.agents.chat(args.agent_id, user_input)

            if args.json:
                print(json.dumps({
                    "content": response.content,
                    "citations": response.citations,
                }, indent=2))
            else:
                print(response.content)
                if response.citations:
                    print("\nCitations:")
                    for c in response.citations:
                        if isinstance(c, dict):
                            print(f"  - {c.get('source', c)}")
                        else:
                            print(f"  - {c}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_interactive(args):
    """Interactive chat mode."""
    client = get_client(args)

    print(f"Gradient AI Interactive Chat")
    print(f"Model: {args.model or client.chat.model}")
    print("Type 'exit' or 'quit' to end, 'clear' to reset history.\n")

    messages = []
    if args.system:
        messages.append(Message.system(args.system))

    try:
        while True:
            try:
                user_input = input("You: ").strip()
            except EOFError:
                break

            if not user_input:
                continue
            if user_input.lower() in ('exit', 'quit'):
                break
            if user_input.lower() == 'clear':
                messages = []
                if args.system:
                    messages.append(Message.system(args.system))
                print("History cleared.\n")
                continue

            messages.append(Message.user(user_input))

            print("Assistant: ", end="", flush=True)
            full_response = ""
            for chunk in client.chat.stream(
                messages,
                model=args.model,
                temperature=args.temperature,
                max_tokens=args.max_tokens,
            ):
                print(chunk, end="", flush=True)
                full_response += chunk
            print("\n")

            messages.append(Message.assistant(full_response))

    except KeyboardInterrupt:
        print("\n\nGoodbye!")
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_test(args):
    """Test connection and authentication."""
    print("Testing Gradient AI connection...\n")

    client = get_client(args)

    # Test inference API
    print("1. Testing inference API...", end=" ", flush=True)
    try:
        models = client.models.list()
        print(f"OK ({len(models)} models available)")
    except Exception as e:
        print(f"FAILED: {e}")

    # Test chat
    print("2. Testing chat completion...", end=" ", flush=True)
    try:
        response = client.chat.complete("Say 'test successful' in exactly two words.", max_tokens=10)
        print(f"OK (response: '{response.content[:50]}...')" if len(response.content) > 50 else f"OK (response: '{response.content}')")
    except Exception as e:
        print(f"FAILED: {e}")

    # Test management API (if token available)
    print("3. Testing management API...", end=" ", flush=True)
    try:
        kbs = client.knowledge_bases.list()
        print(f"OK ({len(kbs)} knowledge bases)")
    except Exception as e:
        if "401" in str(e) or "Unauthorized" in str(e):
            print("SKIPPED (no DIGITALOCEAN_TOKEN)")
        else:
            print(f"FAILED: {e}")

    print("\nTest complete.")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="DigitalOcean Gradient AI Platform CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  gradient chat "What is Python?"
  gradient chat --stream "Tell me a story"
  gradient chat -m "Hello" --model mistral-nemo-instruct
  echo "Summarize this" | gradient chat
  gradient models list
  gradient kb list
  gradient kb query <kb-id> "search query"
  gradient agents list
  gradient agent chat <agent-id> "Help me"
  gradient interactive
  gradient test

Environment Variables:
  GRADIENT_API_KEY      Model access key for inference
  DIGITALOCEAN_TOKEN    API token for management operations
        """
    )
    parser.add_argument('--version', action='version', version=f'do-gradient-ai {__version__}')
    parser.add_argument('--api-key', help='Gradient API key (or GRADIENT_API_KEY env)')
    parser.add_argument('--token', help='DigitalOcean token (or DIGITALOCEAN_TOKEN env)')
    parser.add_argument('--json', action='store_true', help='Output as JSON')

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Chat command
    chat_parser = subparsers.add_parser('chat', help='Chat completion')
    chat_parser.add_argument('message', nargs='?', help='Message to send')
    chat_parser.add_argument('-m', '--message', dest='message_flag', help='Message (alternative)')
    chat_parser.add_argument('-s', '--stream', action='store_true', help='Stream response')
    chat_parser.add_argument('--system', help='System prompt')
    chat_parser.add_argument('--model', help='Model to use')
    chat_parser.add_argument('--temperature', type=float, default=0.7, help='Temperature (0-1)')
    chat_parser.add_argument('--max-tokens', type=int, default=1024, help='Max output tokens')
    chat_parser.set_defaults(func=lambda args: cmd_chat(args))

    # Models command
    models_parser = subparsers.add_parser('models', help='Model operations')
    models_sub = models_parser.add_subparsers(dest='models_cmd')

    models_list_parser = models_sub.add_parser('list', help='List models')
    models_list_parser.set_defaults(func=cmd_models_list)

    models_get_parser = models_sub.add_parser('get', help='Get model details')
    models_get_parser.add_argument('model_id', help='Model ID')
    models_get_parser.set_defaults(func=cmd_models_get)

    # Knowledge base commands
    kb_parser = subparsers.add_parser('kb', help='Knowledge base operations')
    kb_sub = kb_parser.add_subparsers(dest='kb_cmd')

    kb_list_parser = kb_sub.add_parser('list', help='List knowledge bases')
    kb_list_parser.set_defaults(func=cmd_kb_list)

    kb_query_parser = kb_sub.add_parser('query', help='Query knowledge base')
    kb_query_parser.add_argument('kb_id', help='Knowledge base ID')
    kb_query_parser.add_argument('query', help='Search query')
    kb_query_parser.add_argument('-n', '--num-results', type=int, default=5, help='Number of results')
    kb_query_parser.set_defaults(func=cmd_kb_query)

    # Agent commands
    agents_parser = subparsers.add_parser('agents', help='Agent operations')
    agents_sub = agents_parser.add_subparsers(dest='agents_cmd')

    agents_list_parser = agents_sub.add_parser('list', help='List agents')
    agents_list_parser.set_defaults(func=cmd_agents_list)

    # Agent chat (separate command for clarity)
    agent_parser = subparsers.add_parser('agent', help='Agent interaction')
    agent_sub = agent_parser.add_subparsers(dest='agent_cmd')

    agent_chat_parser = agent_sub.add_parser('chat', help='Chat with agent')
    agent_chat_parser.add_argument('agent_id', help='Agent ID')
    agent_chat_parser.add_argument('message', nargs='?', help='Message to send')
    agent_chat_parser.add_argument('-m', '--message', dest='message_flag', help='Message (alternative)')
    agent_chat_parser.add_argument('-s', '--stream', action='store_true', help='Stream response')
    agent_chat_parser.set_defaults(func=cmd_agent_chat)

    # Interactive mode
    interactive_parser = subparsers.add_parser('interactive', aliases=['i'], help='Interactive chat')
    interactive_parser.add_argument('--system', help='System prompt')
    interactive_parser.add_argument('--model', help='Model to use')
    interactive_parser.add_argument('--temperature', type=float, default=0.7, help='Temperature')
    interactive_parser.add_argument('--max-tokens', type=int, default=1024, help='Max tokens')
    interactive_parser.set_defaults(func=cmd_interactive)

    # Test command
    test_parser = subparsers.add_parser('test', help='Test connection')
    test_parser.set_defaults(func=cmd_test)

    # Parse and execute
    args = parser.parse_args()

    # Handle message flag alternative
    if hasattr(args, 'message_flag') and args.message_flag:
        args.message = args.message_flag

    if not args.command:
        parser.print_help()
        sys.exit(0)

    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == '__main__':
    main()
