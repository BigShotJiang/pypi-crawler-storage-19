"""Models client for listing available models."""

from typing import Optional, Dict, Any, List

from .base import BaseClient
from ..models.common import Model, Region


class ModelsClient(BaseClient):
    """
    Client for listing available models and regions.

    Provides access to foundation models available on the Gradient platform,
    including models from Meta (Llama), OpenAI (GPT), Anthropic (Claude),
    Mistral, DeepSeek, and others.

    Example:
        >>> client = ModelsClient(inference_key="your-key")

        >>> # List all models
        >>> models = client.list()
        >>> for m in models:
        ...     print(f"{m.id}: {m.name}")

        >>> # Get specific model info
        >>> model = client.get("llama3.3-70b-instruct")
    """

    def list(self) -> List[Model]:
        """
        List all available models.

        Returns:
            List of Model objects

        Requires:
            GRADIENT_API_KEY

        Example:
            >>> models = client.list()
            >>> print(f"Found {len(models)} models")
            >>> for m in models:
            ...     print(f"  - {m.id}")
        """
        response = self._inference_request("GET", "/models")
        return [
            Model.from_dict(m)
            for m in response.get("data", [])
        ]

    def get(self, model_id: str) -> Model:
        """
        Get information about a specific model.

        Args:
            model_id: Model identifier

        Returns:
            Model object

        Requires:
            GRADIENT_API_KEY
        """
        response = self._inference_request("GET", f"/models/{model_id}")
        return Model.from_dict(response)

    def list_ids(self) -> List[str]:
        """
        List just model IDs (convenience method).

        Returns:
            List of model ID strings

        Requires:
            GRADIENT_API_KEY
        """
        models = self.list()
        return [m.id for m in models]

    def list_by_provider(self, provider: str) -> List[Model]:
        """
        Filter models by provider.

        Args:
            provider: Provider name (e.g., "openai", "anthropic", "meta")

        Returns:
            Filtered list of Model objects

        Requires:
            GRADIENT_API_KEY
        """
        models = self.list()
        provider_lower = provider.lower()
        return [
            m for m in models
            if provider_lower in (m.id.lower() + (m.provider or "").lower())
        ]

    def list_management_models(self) -> List[Dict[str, Any]]:
        """
        List models available for agent creation (via management API).

        Returns:
            List of model configurations

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/models")
        return response.get("models", [])

    def list_embedding_models(self) -> List[Dict[str, Any]]:
        """
        List embedding models for knowledge bases.

        Returns:
            List of embedding model configurations

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/embedding_models")
        return response.get("embedding_models", [])


class RegionsClient(BaseClient):
    """
    Client for listing available regions.

    Example:
        >>> client = RegionsClient()
        >>> regions = client.list()
    """

    def list(self) -> List[Region]:
        """
        List available regions for Gradient resources.

        Returns:
            List of Region objects

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/regions")
        return [
            Region.from_dict(r)
            for r in response.get("regions", [])
        ]
