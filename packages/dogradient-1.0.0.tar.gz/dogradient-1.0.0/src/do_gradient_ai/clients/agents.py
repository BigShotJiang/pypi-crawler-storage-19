"""Agents client for AI agent management."""

from typing import Optional, Dict, Any, List, Iterator

from .base import BaseClient
from ..models.agent import Agent, AgentConfig, AgentChatResponse
from ..models.messages import Message, normalize_messages, MessageInput


class AgentsClient(BaseClient):
    """
    Client for managing AI agents on the Gradient platform.

    Agents are managed AI assistants with custom instructions, knowledge bases,
    guardrails, and multi-agent routing capabilities.

    Requires DIGITALOCEAN_TOKEN for management operations.
    Requires GRADIENT_API_KEY for chat operations.

    Example:
        >>> client = AgentsClient()

        >>> # List agents
        >>> agents = client.list()

        >>> # Chat with an agent
        >>> response = client.chat(agent_id, "Hello!")
        >>> print(response.content)

        >>> # Create an agent
        >>> agent = client.create(
        ...     AgentConfig(
        ...         name="Support Bot",
        ...         model_id="...",
        ...         instruction="You are a helpful support agent.",
        ...         project_id="...",
        ...     )
        ... )
    """

    def list(self) -> List[Agent]:
        """
        List all agents.

        Returns:
            List of Agent objects

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/agents")
        return [
            Agent.from_dict(a)
            for a in response.get("agents", [])
        ]

    def get(self, agent_id: str) -> Agent:
        """
        Get a specific agent.

        Args:
            agent_id: Agent UUID

        Returns:
            Agent object

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", f"/agents/{agent_id}")
        return Agent.from_dict(response.get("agent", response))

    def create(self, config: AgentConfig) -> Agent:
        """
        Create a new agent.

        Args:
            config: Agent configuration

        Returns:
            Created Agent object

        Requires:
            DIGITALOCEAN_TOKEN

        Example:
            >>> agent = client.create(
            ...     AgentConfig(
            ...         name="Support Bot",
            ...         model_id="95ea6652-75ed-11ef-bf8f-4e013e2ddde4",
            ...         instruction="You are a helpful customer support agent.",
            ...         project_id="37455431-84bd-4fa2-94cf-e8486f8f8c5e",
            ...         region="tor1",
            ...         knowledge_base_ids=["kb-uuid-here"],
            ...     )
            ... )
        """
        response = self._management_request(
            "POST",
            "/agents",
            json_data=config.to_dict(),
        )
        return Agent.from_dict(response.get("agent", response))

    def update(
        self,
        agent_id: str,
        name: Optional[str] = None,
        instruction: Optional[str] = None,
        description: Optional[str] = None,
        knowledge_base_ids: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> Agent:
        """
        Update an agent.

        Args:
            agent_id: Agent UUID
            name: New name
            instruction: New instructions
            description: New description
            knowledge_base_ids: New knowledge base list
            tags: New tags

        Returns:
            Updated Agent object

        Requires:
            DIGITALOCEAN_TOKEN
        """
        data = {}
        if name:
            data["name"] = name
        if instruction:
            data["instruction"] = instruction
        if description is not None:
            data["description"] = description
        if knowledge_base_ids is not None:
            data["knowledge_base_uuid"] = knowledge_base_ids
        if tags is not None:
            data["tags"] = tags

        response = self._management_request(
            "PUT",
            f"/agents/{agent_id}",
            json_data=data,
        )
        return Agent.from_dict(response.get("agent", response))

    def delete(self, agent_id: str) -> bool:
        """
        Delete an agent.

        Args:
            agent_id: Agent UUID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request("DELETE", f"/agents/{agent_id}")
        return True

    def chat(
        self,
        agent_id: str,
        messages: MessageInput,
        stream: bool = False,
        **kwargs,
    ) -> AgentChatResponse:
        """
        Chat with an agent.

        Args:
            agent_id: Agent UUID
            messages: User message(s)
            stream: Whether to stream (not yet supported via this method)
            **kwargs: Additional parameters

        Returns:
            AgentChatResponse with content and citations

        Requires:
            GRADIENT_API_KEY

        Example:
            >>> response = client.chat(
            ...     agent_id="...",
            ...     messages="What is the refund policy?",
            ... )
            >>> print(response.content)
            >>> for citation in response.citations:
            ...     print(f"Source: {citation['source']}")
        """
        normalized = normalize_messages(messages)
        formatted = [msg.to_dict() for msg in normalized]

        url = f"{self.AGENT_CHAT_BASE_URL}/{agent_id}"

        data = {
            "messages": formatted,
            **kwargs,
        }

        headers = self._get_headers("inference")
        response = self.session.post(
            url,
            headers=headers,
            json=data,
            timeout=self.timeout,
        )

        response_data = self._handle_response(response)
        return AgentChatResponse.from_dict(response_data, agent_id=agent_id)

    def stream_chat(
        self,
        agent_id: str,
        messages: MessageInput,
        **kwargs,
    ) -> Iterator[str]:
        """
        Stream a chat with an agent.

        Args:
            agent_id: Agent UUID
            messages: User message(s)
            **kwargs: Additional parameters

        Yields:
            Text chunks

        Requires:
            GRADIENT_API_KEY
        """
        normalized = normalize_messages(messages)
        formatted = [msg.to_dict() for msg in normalized]

        url = f"{self.AGENT_CHAT_BASE_URL}/{agent_id}"

        data = {
            "messages": formatted,
            "stream": True,
            **kwargs,
        }

        headers = self._get_headers("inference")
        response = self.session.post(
            url,
            headers=headers,
            json=data,
            timeout=self.timeout,
            stream=True,
        )

        for event in self._stream_sse(response):
            choices = event.get("choices", [{}])
            if choices:
                delta = choices[0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    yield content

    # Agent routes (multi-agent)

    def add_route(
        self,
        agent_id: str,
        target_agent_id: str,
        description: Optional[str] = None,
        priority: int = 0,
    ) -> Dict[str, Any]:
        """
        Add a route to another agent.

        Used for multi-agent routing where one agent can delegate to others.

        Args:
            agent_id: Parent agent UUID
            target_agent_id: Target agent UUID to route to
            description: When to use this route
            priority: Route priority (lower = higher priority)

        Returns:
            Route configuration

        Requires:
            DIGITALOCEAN_TOKEN
        """
        data = {
            "target_agent_uuid": target_agent_id,
        }
        if description:
            data["description"] = description
        if priority:
            data["priority"] = priority

        response = self._management_request(
            "POST",
            f"/agents/{agent_id}/routes",
            json_data=data,
        )
        return response.get("route", response)

    def list_routes(self, agent_id: str) -> List[Dict[str, Any]]:
        """
        List routes for an agent.

        Args:
            agent_id: Agent UUID

        Returns:
            List of route configurations

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", f"/agents/{agent_id}/routes")
        return response.get("routes", [])

    def delete_route(self, agent_id: str, route_id: str) -> bool:
        """
        Delete a route from an agent.

        Args:
            agent_id: Agent UUID
            route_id: Route UUID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request("DELETE", f"/agents/{agent_id}/routes/{route_id}")
        return True
