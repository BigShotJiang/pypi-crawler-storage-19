"""Images client for image generation."""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
import base64

from .base import BaseClient


@dataclass
class ImageResponse:
    """
    Response from image generation.

    Attributes:
        data: Base64-encoded image data
        url: URL to image (if applicable)
        revised_prompt: Model's revised prompt
        model: Model used
        metadata: Additional response data
    """
    data: Optional[str] = None
    url: Optional[str] = None
    revised_prompt: Optional[str] = None
    model: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, item: Dict[str, Any], model: str = "") -> "ImageResponse":
        """Create from API response item."""
        return cls(
            data=item.get("b64_json"),
            url=item.get("url"),
            revised_prompt=item.get("revised_prompt"),
            model=model,
            metadata=item,
        )

    def save(self, path: str) -> str:
        """
        Save image to file.

        Args:
            path: File path to save to

        Returns:
            Path saved to

        Raises:
            ValueError: If no image data available
        """
        if self.data:
            with open(path, "wb") as f:
                f.write(base64.b64decode(self.data))
            return path
        elif self.url:
            import requests
            response = requests.get(self.url)
            response.raise_for_status()
            with open(path, "wb") as f:
                f.write(response.content)
            return path
        else:
            raise ValueError("No image data available")

    @property
    def bytes(self) -> bytes:
        """Get raw image bytes."""
        if self.data:
            return base64.b64decode(self.data)
        elif self.url:
            import requests
            response = requests.get(self.url)
            response.raise_for_status()
            return response.content
        else:
            raise ValueError("No image data available")


@dataclass
class ImageGenerationResponse:
    """
    Full response from image generation.

    Attributes:
        images: List of generated images
        created: Timestamp of creation
        model: Model used
    """
    images: List[ImageResponse]
    created: Optional[int] = None
    model: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ImageGenerationResponse":
        """Create from API response."""
        model = data.get("model", "")
        images = [
            ImageResponse.from_dict(item, model=model)
            for item in data.get("data", [])
        ]
        return cls(
            images=images,
            created=data.get("created"),
            model=model,
        )

    @property
    def image(self) -> ImageResponse:
        """Get first image (convenience)."""
        if self.images:
            return self.images[0]
        raise ValueError("No images in response")


class ImagesClient(BaseClient):
    """
    Client for image generation.

    Note: Image generation availability depends on your Gradient subscription tier
    and the models available to your account.

    Example:
        >>> client = ImagesClient(inference_key="your-key")

        >>> # Generate an image
        >>> response = client.generate("A sunset over mountains")
        >>> response.image.save("sunset.png")

        >>> # Generate multiple images
        >>> response = client.generate("Abstract art", n=4)
        >>> for i, img in enumerate(response.images):
        ...     img.save(f"art_{i}.png")
    """

    DEFAULT_MODEL = "dall-e-3"  # If available on tier

    def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        n: int = 1,
        size: str = "1024x1024",
        quality: str = "standard",
        style: Optional[str] = None,
        response_format: str = "b64_json",
        **kwargs,
    ) -> ImageGenerationResponse:
        """
        Generate images from a text prompt.

        Args:
            prompt: Text description of image to generate
            model: Model to use (default varies by availability)
            n: Number of images to generate (1-4)
            size: Image size ("256x256", "512x512", "1024x1024", "1792x1024", "1024x1792")
            quality: Quality level ("standard" or "hd")
            style: Style preset ("vivid" or "natural")
            response_format: "b64_json" or "url"
            **kwargs: Additional model parameters

        Returns:
            ImageGenerationResponse with generated images

        Requires:
            GRADIENT_API_KEY

        Example:
            >>> response = client.generate(
            ...     prompt="A futuristic city at night",
            ...     size="1024x1024",
            ...     quality="hd",
            ... )
            >>> response.image.save("city.png")
        """
        data = {
            "prompt": prompt,
            "model": model or self.DEFAULT_MODEL,
            "n": n,
            "size": size,
            "quality": quality,
            "response_format": response_format,
            **kwargs,
        }

        if style:
            data["style"] = style

        response = self._inference_request(
            "POST",
            "/images/generations",
            json_data=data,
        )
        return ImageGenerationResponse.from_dict(response)

    def create_variation(
        self,
        image: bytes,
        model: Optional[str] = None,
        n: int = 1,
        size: str = "1024x1024",
        response_format: str = "b64_json",
    ) -> ImageGenerationResponse:
        """
        Create variations of an existing image.

        Args:
            image: Image bytes
            model: Model to use
            n: Number of variations
            size: Output size
            response_format: Output format

        Returns:
            ImageGenerationResponse with variations

        Requires:
            GRADIENT_API_KEY
        """
        # This endpoint typically requires multipart form data
        import io

        files = {
            "image": ("image.png", io.BytesIO(image), "image/png"),
        }

        data = {
            "model": model or self.DEFAULT_MODEL,
            "n": n,
            "size": size,
            "response_format": response_format,
        }

        headers = self._get_headers("inference")
        # Remove Content-Type for multipart
        del headers["Content-Type"]

        response = self.session.post(
            f"{self.INFERENCE_BASE_URL}/images/variations",
            headers=headers,
            files=files,
            data=data,
            timeout=self.timeout,
        )

        response_data = self._handle_response(response)
        return ImageGenerationResponse.from_dict(response_data)

    def edit(
        self,
        image: bytes,
        prompt: str,
        mask: Optional[bytes] = None,
        model: Optional[str] = None,
        n: int = 1,
        size: str = "1024x1024",
        response_format: str = "b64_json",
    ) -> ImageGenerationResponse:
        """
        Edit an image with a text prompt.

        Args:
            image: Original image bytes
            prompt: Edit instructions
            mask: Optional mask image (transparent areas will be edited)
            model: Model to use
            n: Number of outputs
            size: Output size
            response_format: Output format

        Returns:
            ImageGenerationResponse with edited images

        Requires:
            GRADIENT_API_KEY
        """
        import io

        files = {
            "image": ("image.png", io.BytesIO(image), "image/png"),
        }

        if mask:
            files["mask"] = ("mask.png", io.BytesIO(mask), "image/png")

        data = {
            "prompt": prompt,
            "model": model or self.DEFAULT_MODEL,
            "n": n,
            "size": size,
            "response_format": response_format,
        }

        headers = self._get_headers("inference")
        del headers["Content-Type"]

        response = self.session.post(
            f"{self.INFERENCE_BASE_URL}/images/edits",
            headers=headers,
            files=files,
            data=data,
            timeout=self.timeout,
        )

        response_data = self._handle_response(response)
        return ImageGenerationResponse.from_dict(response_data)

    def __call__(self, prompt: str, **kwargs) -> ImageResponse:
        """
        Shorthand for generating a single image.

        Args:
            prompt: Image description
            **kwargs: Additional parameters

        Returns:
            Single ImageResponse
        """
        response = self.generate(prompt, n=1, **kwargs)
        return response.image
