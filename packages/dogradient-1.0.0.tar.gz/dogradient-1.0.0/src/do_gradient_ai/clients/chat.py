"""Chat completions client for serverless inference."""

from typing import Optional, Dict, Any, List, Iterator, Union
import asyncio

from .base import BaseClient
from ..models.messages import (
    Message,
    ChatResponse,
    StreamChunk,
    MessageInput,
    normalize_messages,
)
from ..models.common import Usage


class ChatClient(BaseClient):
    """
    Client for chat completions via serverless inference.

    Provides access to 23+ foundation models including:
    - Meta Llama (3.3-70b, 3.2-3b, 3.2-1b, etc.)
    - DeepSeek (R1-distill-llama-70b)
    - Mistral (nemo-instruct)
    - OpenAI (GPT-4o, GPT-5) - requires higher tier
    - Anthropic (Claude) - requires higher tier

    Example:
        >>> client = ChatClient(inference_key="your-key")
        >>> response = client.complete("Hello!")
        >>> print(response.content)

        >>> # Streaming
        >>> for chunk in client.stream("Tell me a story"):
        ...     print(chunk, end="")

        >>> # With conversation history
        >>> messages = [
        ...     Message.system("You are helpful."),
        ...     Message.user("What is Python?"),
        ... ]
        >>> response = client.complete(messages)
    """

    DEFAULT_MODEL = "llama3.3-70b-instruct"

    def __init__(
        self,
        inference_key: Optional[str] = None,
        model: Optional[str] = None,
        **kwargs,
    ):
        """
        Initialize the chat client.

        Args:
            inference_key: Model access key (env: GRADIENT_API_KEY)
            model: Default model to use
            **kwargs: Additional base client options
        """
        super().__init__(inference_key=inference_key, **kwargs)
        self.model = model or self.DEFAULT_MODEL

    def complete(
        self,
        messages: Union[List[MessageInput], MessageInput],
        model: Optional[str] = None,
        system: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        top_p: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        stop: Optional[List[str]] = None,
        **kwargs,
    ) -> ChatResponse:
        """
        Generate a chat completion.

        Args:
            messages: Input messages (string, Message, dict, or list)
            model: Model to use (default: llama3.3-70b-instruct)
            system: System prompt to prepend
            temperature: Sampling temperature (0-1)
            max_tokens: Maximum output tokens
            top_p: Nucleus sampling parameter
            frequency_penalty: Frequency penalty (-2 to 2)
            presence_penalty: Presence penalty (-2 to 2)
            stop: Stop sequences
            **kwargs: Additional model parameters

        Returns:
            ChatResponse with generated content

        Example:
            >>> # Simple string input
            >>> response = client.complete("Hello!")

            >>> # With system prompt
            >>> response = client.complete("Hello!", system="Be friendly")

            >>> # Full conversation
            >>> response = client.complete([
            ...     {"role": "user", "content": "Hi"},
            ...     {"role": "assistant", "content": "Hello!"},
            ...     {"role": "user", "content": "How are you?"},
            ... ])
        """
        normalized = normalize_messages(messages, system)
        formatted = [msg.to_dict() for msg in normalized]

        data = {
            "model": model or self.model,
            "messages": formatted,
            "temperature": temperature,
            "max_tokens": max_tokens,
            **kwargs,
        }

        if top_p is not None:
            data["top_p"] = top_p
        if frequency_penalty is not None:
            data["frequency_penalty"] = frequency_penalty
        if presence_penalty is not None:
            data["presence_penalty"] = presence_penalty
        if stop:
            data["stop"] = stop

        response = self._inference_request("POST", "/chat/completions", json_data=data)
        return ChatResponse.from_api_response(response)

    def stream(
        self,
        messages: Union[List[MessageInput], MessageInput],
        model: Optional[str] = None,
        system: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs,
    ) -> Iterator[str]:
        """
        Stream a chat completion.

        Args:
            messages: Input messages
            model: Model to use
            system: System prompt
            temperature: Sampling temperature
            max_tokens: Maximum output tokens
            **kwargs: Additional parameters

        Yields:
            Text chunks as they're generated

        Example:
            >>> for chunk in client.stream("Tell me a story"):
            ...     print(chunk, end="", flush=True)
        """
        normalized = normalize_messages(messages, system)
        formatted = [msg.to_dict() for msg in normalized]

        data = {
            "model": model or self.model,
            "messages": formatted,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            **kwargs,
        }

        response = self._inference_request(
            "POST",
            "/chat/completions",
            json_data=data,
            stream=True,
        )

        for event in self._stream_sse(response):
            chunk = StreamChunk.from_api_chunk(event)
            if chunk.content:
                yield chunk.content

    def stream_chunks(
        self,
        messages: Union[List[MessageInput], MessageInput],
        **kwargs,
    ) -> Iterator[StreamChunk]:
        """
        Stream with full chunk objects (includes metadata).

        Args:
            messages: Input messages
            **kwargs: Additional parameters

        Yields:
            StreamChunk objects with content and metadata
        """
        normalized = normalize_messages(messages, kwargs.pop("system", None))
        formatted = [msg.to_dict() for msg in normalized]

        data = {
            "model": kwargs.pop("model", self.model),
            "messages": formatted,
            "temperature": kwargs.pop("temperature", 0.7),
            "max_tokens": kwargs.pop("max_tokens", 1024),
            "stream": True,
            **kwargs,
        }

        response = self._inference_request(
            "POST",
            "/chat/completions",
            json_data=data,
            stream=True,
        )

        for event in self._stream_sse(response):
            yield StreamChunk.from_api_chunk(event)

    async def acomplete(
        self,
        messages: Union[List[MessageInput], MessageInput],
        **kwargs,
    ) -> ChatResponse:
        """
        Async version of complete().

        Args:
            messages: Input messages
            **kwargs: Same as complete()

        Returns:
            ChatResponse
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.complete(messages, **kwargs)
        )

    async def astream(
        self,
        messages: Union[List[MessageInput], MessageInput],
        **kwargs,
    ):
        """
        Async generator version of stream().

        Args:
            messages: Input messages
            **kwargs: Same as stream()

        Yields:
            Text chunks
        """
        loop = asyncio.get_event_loop()

        # Run the sync stream in a thread
        def sync_stream():
            return list(self.stream(messages, **kwargs))

        chunks = await loop.run_in_executor(None, sync_stream)
        for chunk in chunks:
            yield chunk

    def __call__(
        self,
        prompt: str,
        **kwargs,
    ) -> str:
        """
        Shorthand for simple completions.

        Args:
            prompt: User prompt
            **kwargs: Additional parameters

        Returns:
            Generated text content

        Example:
            >>> text = client("What is Python?")
        """
        response = self.complete(prompt, **kwargs)
        return response.content
