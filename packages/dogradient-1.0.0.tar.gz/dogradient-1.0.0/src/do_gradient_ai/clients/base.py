"""Base client with common HTTP functionality."""

import os
import json
from typing import Optional, Dict, Any, Iterator, Union
from urllib.parse import urljoin
import requests

from ..models.common import APIError


class BaseClient:
    """
    Base HTTP client for DigitalOcean APIs.

    Handles authentication, request building, and error handling
    for both the inference API and the management API.
    """

    # API endpoints
    INFERENCE_BASE_URL = "https://inference.do-ai.run/v1"
    MANAGEMENT_BASE_URL = "https://api.digitalocean.com/v2/gen-ai"
    KB_QUERY_BASE_URL = "https://kbaas.do-ai.run/v1"
    AGENT_CHAT_BASE_URL = "https://agent.do-ai.run"

    def __init__(
        self,
        inference_key: Optional[str] = None,
        management_token: Optional[str] = None,
        timeout: int = 60,
    ):
        """
        Initialize the base client.

        Args:
            inference_key: Model access key for serverless inference
                          (env: GRADIENT_API_KEY)
            management_token: DigitalOcean API token for management
                             (env: DIGITALOCEAN_TOKEN)
            timeout: Request timeout in seconds
        """
        self.inference_key = inference_key or os.getenv(
            "GRADIENT_API_KEY",
            os.getenv("GRADIENT_MODEL_ACCESS_KEY", "")
        )
        self.management_token = management_token or os.getenv(
            "DIGITALOCEAN_TOKEN",
            os.getenv("DO_API_TOKEN", "")
        )
        self.timeout = timeout
        self._session: Optional[requests.Session] = None

    @property
    def session(self) -> requests.Session:
        """Get or create HTTP session."""
        if self._session is None:
            self._session = requests.Session()
        return self._session

    def _get_headers(self, api_type: str = "inference") -> Dict[str, str]:
        """
        Get headers for API request.

        Args:
            api_type: "inference" or "management"

        Returns:
            Headers dictionary
        """
        headers = {"Content-Type": "application/json"}

        if api_type == "inference":
            if not self.inference_key:
                raise ValueError(
                    "Inference API key required. Set GRADIENT_API_KEY environment "
                    "variable or pass inference_key parameter."
                )
            headers["Authorization"] = f"Bearer {self.inference_key}"
        elif api_type == "management":
            if not self.management_token:
                raise ValueError(
                    "Management API token required. Set DIGITALOCEAN_TOKEN environment "
                    "variable or pass management_token parameter."
                )
            headers["Authorization"] = f"Bearer {self.management_token}"

        return headers

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """
        Handle API response, raising appropriate errors.

        Args:
            response: HTTP response object

        Returns:
            Parsed JSON response

        Raises:
            APIError: On non-2xx status codes
        """
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("message", error_data.get("error", {}).get("message", "Unknown error"))
                error_type = error_data.get("error", {}).get("type", "api_error")
            except (json.JSONDecodeError, KeyError):
                message = response.text or f"HTTP {response.status_code}"
                error_type = "http_error"

            raise APIError(
                message=message,
                status_code=response.status_code,
                error_type=error_type,
                details=error_data if 'error_data' in locals() else None,
            )

        if response.status_code == 204:
            return {}

        try:
            return response.json()
        except json.JSONDecodeError:
            return {"raw": response.text}

    def _request(
        self,
        method: str,
        url: str,
        api_type: str = "inference",
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        stream: bool = False,
    ) -> Union[Dict[str, Any], requests.Response]:
        """
        Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            url: Full URL to request
            api_type: "inference" or "management"
            json_data: JSON body data
            params: Query parameters
            stream: Whether to stream the response

        Returns:
            Parsed JSON response or Response object if streaming
        """
        headers = self._get_headers(api_type)

        response = self.session.request(
            method=method,
            url=url,
            headers=headers,
            json=json_data,
            params=params,
            timeout=self.timeout,
            stream=stream,
        )

        if stream:
            return response

        return self._handle_response(response)

    def _inference_request(
        self,
        method: str,
        endpoint: str,
        **kwargs,
    ) -> Union[Dict[str, Any], requests.Response]:
        """Make a request to the inference API."""
        url = urljoin(self.INFERENCE_BASE_URL + "/", endpoint.lstrip("/"))
        return self._request(method, url, api_type="inference", **kwargs)

    def _management_request(
        self,
        method: str,
        endpoint: str,
        **kwargs,
    ) -> Dict[str, Any]:
        """Make a request to the management API."""
        url = urljoin(self.MANAGEMENT_BASE_URL + "/", endpoint.lstrip("/"))
        return self._request(method, url, api_type="management", **kwargs)

    def _stream_sse(
        self,
        response: requests.Response,
    ) -> Iterator[Dict[str, Any]]:
        """
        Parse Server-Sent Events from a streaming response.

        Args:
            response: Streaming HTTP response

        Yields:
            Parsed JSON event data
        """
        for line in response.iter_lines(decode_unicode=True):
            if not line:
                continue

            if line.startswith("data: "):
                data = line[6:]

                if data == "[DONE]":
                    break

                try:
                    yield json.loads(data)
                except json.JSONDecodeError:
                    continue
