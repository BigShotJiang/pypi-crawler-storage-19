"""Knowledge bases client for RAG functionality."""

from typing import Optional, Dict, Any, List
from urllib.parse import urljoin

from .base import BaseClient
from ..models.knowledge_base import (
    KnowledgeBase,
    DataSource,
    RetrievalResult,
    RetrievalResponse,
    ChunkingStrategy,
    ChunkingOptions,
    IndexingJob,
    IndexingSchedule,
)


class KnowledgeBasesClient(BaseClient):
    """
    Client for managing knowledge bases and RAG queries.

    Knowledge bases enable retrieval-augmented generation (RAG) by storing
    and indexing documents, web pages, and other content for semantic search.

    Requires DIGITALOCEAN_TOKEN for management operations.
    Requires GRADIENT_API_KEY for query operations.

    Example:
        >>> client = KnowledgeBasesClient()

        >>> # List knowledge bases
        >>> kbs = client.list()

        >>> # Query a knowledge base
        >>> results = client.query(kb_id, "What is the return policy?")
        >>> for r in results.results:
        ...     print(f"{r.score}: {r.text[:100]}...")

        >>> # Create a knowledge base
        >>> kb = client.create(
        ...     name="docs",
        ...     project_id="...",
        ...     region="tor1",
        ... )
    """

    def list(self) -> List[KnowledgeBase]:
        """
        List all knowledge bases.

        Returns:
            List of KnowledgeBase objects

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/knowledge_bases")
        return [
            KnowledgeBase.from_dict(kb)
            for kb in response.get("knowledge_bases", [])
        ]

    def get(self, kb_id: str) -> KnowledgeBase:
        """
        Get a specific knowledge base.

        Args:
            kb_id: Knowledge base UUID

        Returns:
            KnowledgeBase object

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", f"/knowledge_bases/{kb_id}")
        return KnowledgeBase.from_dict(response.get("knowledge_base", response))

    def create(
        self,
        name: str,
        project_id: str,
        region: str = "tor1",
        embedding_model_id: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        datasources: Optional[List[Dict[str, Any]]] = None,
    ) -> KnowledgeBase:
        """
        Create a new knowledge base.

        Args:
            name: Display name
            project_id: Project UUID
            region: Datacenter region (e.g., "tor1", "nyc1")
            embedding_model_id: Embedding model UUID (uses default if not specified)
            description: Optional description
            tags: Optional tags
            datasources: Optional initial data sources (see DataSource.spaces(), etc.)

        Returns:
            Created KnowledgeBase object

        Requires:
            DIGITALOCEAN_TOKEN

        Example:
            >>> kb = client.create(
            ...     name="Company Docs",
            ...     project_id="37455431-84bd-4fa2-94cf-e8486f8f8c5e",
            ...     region="tor1",
            ...     datasources=[
            ...         DataSource.spaces("my-bucket", "tor1", folder="docs/"),
            ...     ],
            ... )
        """
        data = {
            "name": name,
            "project_id": project_id,
            "region": region,
        }

        if embedding_model_id:
            data["embedding_model_uuid"] = embedding_model_id
        if description:
            data["description"] = description
        if tags:
            data["tags"] = tags
        if datasources:
            data["datasources"] = datasources

        response = self._management_request("POST", "/knowledge_bases", json_data=data)
        return KnowledgeBase.from_dict(response.get("knowledge_base", response))

    def update(
        self,
        kb_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> KnowledgeBase:
        """
        Update a knowledge base.

        Args:
            kb_id: Knowledge base UUID
            name: New name
            description: New description
            tags: New tags

        Returns:
            Updated KnowledgeBase object

        Requires:
            DIGITALOCEAN_TOKEN
        """
        data = {}
        if name:
            data["name"] = name
        if description is not None:
            data["description"] = description
        if tags is not None:
            data["tags"] = tags

        response = self._management_request(
            "PUT",
            f"/knowledge_bases/{kb_id}",
            json_data=data,
        )
        return KnowledgeBase.from_dict(response.get("knowledge_base", response))

    def delete(self, kb_id: str) -> bool:
        """
        Delete a knowledge base.

        Args:
            kb_id: Knowledge base UUID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request("DELETE", f"/knowledge_bases/{kb_id}")
        return True

    def query(
        self,
        kb_id: str,
        query: str,
        num_results: int = 5,
        alpha: float = 0.5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> RetrievalResponse:
        """
        Query a knowledge base for relevant content.

        Uses hybrid search (semantic + keyword) with configurable blending.

        Args:
            kb_id: Knowledge base UUID
            query: Search query text
            num_results: Number of results to return (default: 5)
            alpha: Blend between semantic (0) and keyword (1) search (default: 0.5)
            filters: Optional metadata filters

        Returns:
            RetrievalResponse with results and citations

        Requires:
            GRADIENT_API_KEY (with GenAI:read scope)

        Example:
            >>> results = client.query(
            ...     kb_id="...",
            ...     query="What is the refund policy?",
            ...     num_results=10,
            ...     filters={
            ...         "or_all": [
            ...             {"starts_with": {"key": "item_name", "value": "https://docs."}}
            ...         ]
            ...     },
            ... )
            >>> for r in results.results:
            ...     print(f"[{r.source}] {r.text[:100]}...")
        """
        url = f"{self.KB_QUERY_BASE_URL}/{kb_id}/retrieve"

        data = {
            "query": query,
            "num_results": num_results,
            "alpha": alpha,
        }

        if filters:
            data["filters"] = filters

        # Query endpoint uses inference key
        headers = self._get_headers("inference")
        response = self.session.post(
            url,
            headers=headers,
            json=data,
            timeout=self.timeout,
        )

        response_data = self._handle_response(response)
        return RetrievalResponse.from_dict(response_data, query=query)

    # Data source management

    def add_data_source(
        self,
        kb_id: str,
        data_source: Dict[str, Any],
    ) -> DataSource:
        """
        Add a data source to a knowledge base.

        Args:
            kb_id: Knowledge base UUID
            data_source: Data source configuration (use DataSource.spaces(), etc.)

        Returns:
            Created DataSource object

        Requires:
            DIGITALOCEAN_TOKEN

        Example:
            >>> ds = client.add_data_source(
            ...     kb_id="...",
            ...     data_source=DataSource.web_crawler(
            ...         "https://docs.example.com",
            ...         max_pages=500,
            ...     ),
            ... )
        """
        data = {"knowledge_base_uuid": kb_id, **data_source}

        response = self._management_request(
            "POST",
            f"/knowledge_bases/{kb_id}/data_sources",
            json_data=data,
        )
        return DataSource.from_dict(response.get("data_source", response))

    def list_data_sources(self, kb_id: str) -> List[DataSource]:
        """
        List data sources for a knowledge base.

        Args:
            kb_id: Knowledge base UUID

        Returns:
            List of DataSource objects

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request(
            "GET",
            f"/knowledge_bases/{kb_id}/data_sources",
        )
        return [
            DataSource.from_dict(ds)
            for ds in response.get("data_sources", [])
        ]

    def delete_data_source(self, kb_id: str, ds_id: str) -> bool:
        """
        Delete a data source from a knowledge base.

        Args:
            kb_id: Knowledge base UUID
            ds_id: Data source UUID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request(
            "DELETE",
            f"/knowledge_bases/{kb_id}/data_sources/{ds_id}",
        )
        return True

    # Indexing job management

    def start_indexing(self, kb_id: str, ds_id: str) -> IndexingJob:
        """
        Start an indexing job for a data source.

        Args:
            kb_id: Knowledge base UUID
            ds_id: Data source UUID

        Returns:
            IndexingJob object

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request(
            "POST",
            f"/knowledge_bases/{kb_id}/data_sources/{ds_id}/indexing_jobs",
        )
        return IndexingJob.from_dict(response.get("indexing_job", response))

    def get_indexing_job(self, kb_id: str, job_id: str) -> IndexingJob:
        """
        Get indexing job status.

        Args:
            kb_id: Knowledge base UUID
            job_id: Indexing job ID

        Returns:
            IndexingJob object with current status

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request(
            "GET",
            f"/knowledge_bases/{kb_id}/indexing_jobs/{job_id}",
        )
        return IndexingJob.from_dict(response.get("indexing_job", response))

    def cancel_indexing(self, kb_id: str, job_id: str) -> bool:
        """
        Cancel an indexing job.

        Args:
            kb_id: Knowledge base UUID
            job_id: Indexing job ID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request(
            "DELETE",
            f"/knowledge_bases/{kb_id}/indexing_jobs/{job_id}",
        )
        return True

    # Scheduled indexing

    def create_schedule(
        self,
        kb_id: str,
        time: str,
        days: List[int],
    ) -> IndexingSchedule:
        """
        Create a scheduled indexing job.

        Args:
            kb_id: Knowledge base UUID
            time: Time of day (HH:MM, 24-hour format)
            days: Days of week (1=Monday, 7=Sunday)

        Returns:
            IndexingSchedule object

        Requires:
            DIGITALOCEAN_TOKEN

        Example:
            >>> # Index every weekday at 6 PM
            >>> schedule = client.create_schedule(
            ...     kb_id="...",
            ...     time="18:00",
            ...     days=[1, 2, 3, 4, 5],
            ... )
        """
        response = self._management_request(
            "POST",
            "/scheduled-indexing",
            json_data={
                "knowledge_base_uuid": kb_id,
                "time": time,
                "days": days,
            },
        )
        return IndexingSchedule.from_dict(response.get("schedule", response))

    def list_schedules(self) -> List[IndexingSchedule]:
        """
        List all indexing schedules.

        Returns:
            List of IndexingSchedule objects

        Requires:
            DIGITALOCEAN_TOKEN
        """
        response = self._management_request("GET", "/scheduled-indexing")
        return [
            IndexingSchedule.from_dict(s)
            for s in response.get("schedules", [])
        ]

    def delete_schedule(self, schedule_id: str) -> bool:
        """
        Delete an indexing schedule.

        Args:
            schedule_id: Schedule ID

        Returns:
            True if successful

        Requires:
            DIGITALOCEAN_TOKEN
        """
        self._management_request("DELETE", f"/scheduled-indexing/{schedule_id}")
        return True
