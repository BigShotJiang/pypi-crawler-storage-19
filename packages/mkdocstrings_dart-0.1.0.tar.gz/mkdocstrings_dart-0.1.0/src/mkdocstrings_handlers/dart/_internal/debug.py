# In _get_debug_info(), change:
packages = ["mkdocstrings-dart"]

# To just show relevant info:
packages = []
