# config.py
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass(frozen=True, kw_only=True)
class DartOptions:
    """Options for rendering and collecting Dart documentation."""

    paths: List[str] = field(default_factory=lambda: ["lib"])
    """List of directories to search for Dart source files, relative to the project root."""

    show_source: bool = True
    """Whether to show the source code in the rendered documentation."""

    exclude_files: List[str] = field(default_factory=list)
    """List of filenames (without path) to exclude from documentation, e.g. barrel files."""

    # From original template – useful heading options
    heading: str = ""
    heading_level: int = 2
    show_symbol_type_heading: bool = False
    show_symbol_type_toc: bool = False
    toc_label: str = ""

    # Extra catch-all for future extensions
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_data(cls, **data: Any) -> "DartOptions":
        """Create an instance from raw config dict, using only known fields."""
        # Define known fields explicitly to avoid __dataclass_fields__ lookup
        known_fields = {
            "paths", "show_source", "exclude_files",
            "heading", "heading_level", "show_symbol_type_heading",
            "show_symbol_type_toc", "toc_label", "extra"
        }
        filtered = {k: v for k, v in data.items() if k in known_fields}
        return cls(**filtered)

@dataclass(frozen=True, kw_only=True)
class DartConfig:
    """Global handler configuration from mkdocs.yml."""

    options: Dict[str, Any] = field(default_factory=dict)
    """Global options defined under handlers.dart.options."""

    @classmethod
    def from_data(cls, **data: Any) -> "DartConfig":
        return cls(options=data.get("options", {}))
