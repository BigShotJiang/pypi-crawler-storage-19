# handler.py

from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict

import yaml  # Required for pubspec.yaml parsing (add PyYAML to dependencies)
from mkdocs.exceptions import PluginError
from mkdocstrings import BaseHandler, CollectionError, CollectorItem, get_logger

from mkdocstrings_handlers.dart._internal.config import DartConfig, DartOptions

_logger = get_logger(__name__)


class DartHandler(BaseHandler):
    name: str = "dart"
    domain: str = "dart"
    enable_inventory: bool = False
    fallback_theme: str = "material"

    _collected: Dict[str, CollectorItem]

    def __init__(self, config: DartConfig, base_dir: Path, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.config = config
        self.base_dir = base_dir
        self.global_options = config.options.copy()

        self._collected = {}

        _logger.debug("DartHandler initialized with base_dir=%s", base_dir)
        _logger.debug("Global options: %s", self.global_options)

    def get_options(self, local_options: dict[str, Any]) -> DartOptions:
        """Merge global and local options."""
        merged = {**self.global_options, **local_options}
        try:
            return DartOptions.from_data(**merged)
        except Exception as e:
            raise PluginError(f"Invalid Dart handler options: {e}") from e

    def collect(self, identifier: str, options: DartOptions) -> CollectorItem:
        """Collect documentation for a Dart identifier using dartdoc_json on individual files."""
        _logger.info("Collecting Dart identifier: %s", identifier)

        # === Auto-detect package name from pubspec.yaml ===
        if not hasattr(self, "_package_name"):
            pubspec_path = self.base_dir / "pubspec.yaml"
            if pubspec_path.exists():
                try:
                    with open(pubspec_path, "r", encoding="utf-8") as f:
                        pubspec = yaml.safe_load(f)
                    self._package_name = pubspec.get("name", "unknown_package")
                    _logger.debug("Detected package name: %s", self._package_name)
                except Exception as e:
                    _logger.warning("Failed to parse pubspec.yaml: %s", e)
                    self._package_name = "unknown_package"
            else:
                _logger.warning("pubspec.yaml not found in %s", self.base_dir)
                self._package_name = "unknown_package"

        # === Cache parsed dartdoc_json data across collections ===
        if not hasattr(self, "_identifier_map"):
            self._identifier_map: Dict[str, dict] = {}
            self._file_data: Dict[str, list[dict]] = {}  # relative_path -> units

            search_dirs = [self.base_dir / p for p in options.paths]
            exclude_set = set(options.exclude_files)

            dart_files: list[Path] = []
            for dir_path in search_dirs:
                if dir_path.exists() and dir_path.is_dir():
                    dart_files.extend(dir_path.rglob("*.dart"))
                else:
                    _logger.warning("Search path does not exist: %s", dir_path)

            if not dart_files:
                raise CollectionError(f"No Dart files found in paths: {options.paths}")

            _logger.debug("Found %d Dart files to process", len(dart_files))

            for file_path in dart_files:
                if file_path.name in exclude_set:
                    _logger.debug("Skipping excluded file: %s", file_path.name)
                    continue

                relative_path = file_path.relative_to(self.base_dir)
                _logger.debug("Processing file: %s", relative_path)

                with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
                    cmd = [
                        "dartdoc_json",
                        str(file_path),
                        "--output", tmp.name,
                    ]

                    try:
                        subprocess.run(cmd, check=True, capture_output=True, text=True)
                    except FileNotFoundError:
                        raise CollectionError(
                            "dartdoc_json not found. Please run: dart pub global activate dartdoc_json"
                        ) from None
                    except subprocess.CalledProcessError as e:
                        error_msg = e.stderr.strip() or e.stdout.strip() or "Unknown error"
                        raise CollectionError(
                            f"dartdoc_json failed on {file_path}:\n{error_msg}"
                        ) from e

                    try:
                        with open(tmp.name) as f:
                            units = json.load(f)
                    except json.JSONDecodeError as e:
                        raise CollectionError(f"Invalid JSON output from {file_path}: {e}") from e
                    finally:
                        Path(tmp.name).unlink()

                    if not units:
                        continue

                    self._file_data[str(relative_path)] = units

                    # Index all top-level declarations with their source file
                    current_file_path = Path(relative_path)  # relative to base_dir
                    for unit in units:
                        for decl in unit.get("declarations", []):
                            qname = decl.get("qualifiedName") or decl.get("name")
                            if qname:
                                # Make a copy and attach the source file path
                                enriched_decl = decl.copy()
                                enriched_decl["_source_file"] = str(current_file_path)

                                full_id = f"{self._package_name}.{qname}"
                                self._identifier_map[full_id] = enriched_decl
                                self._identifier_map[qname] = enriched_decl

            _logger.debug("Indexed %d identifiers", len(self._identifier_map))

        # === Resolve the requested identifier ===
        data = self._identifier_map.get(identifier)
        if not data:
            if "." not in identifier:
                data = self._identifier_map.get(f"{self._package_name}.{identifier}")
            if not data:
                raise CollectionError(f"Identifier not found: {identifier}")

        # === Build member list ===
        members = []
        for member in data.get("members", []):
            member_qname = member.get("qualifiedName") or member.get("name")
            member_id = f"{self._package_name}.{member_qname}" if member_qname else None
            members.append({
                "name": member.get("name"),
                "path": member_id,
                "kind": member.get("kind"),
                "docstring": member.get("description"),
                "parameters": member.get("parameters"),  # Pass full params for rich rendering
                "returns": member.get("returns"),
                "members": [],  # Future: recursive nesting
            })

        # === Extract source code if requested ===
        source_code = None
        if options.show_source:
            # Use the enriched _source_file we attached
            source_rel = data.get("_source_file")
            if source_rel:
                source_path = self.base_dir / source_rel
                if source_path.is_file():
                    try:
                        source_code = source_path.read_text(encoding="utf-8")
                        _logger.debug("Loaded source code from %s", source_path)
                    except Exception as e:
                        _logger.warning("Could not read source file %s: %s", source_path, e)
                else:
                    _logger.warning("Source file not found or not a file: %s", source_path)
            else:
                _logger.debug("No _source_file attached for %s", data.get("name"))

        # === Final CollectorItem ===
        collector_item: CollectorItem = {
            "name": data.get("name", identifier.split(".")[-1]),
            "path": identifier,
            "kind": data.get("kind", "unknown"),
            "docstring": data.get("description"),
            "source_code": source_code,
            "members": members,
        }

        self._collected[identifier] = collector_item
        return collector_item

    def render(
        self,
        data: CollectorItem,
        options: DartOptions,
        locale: str | None = None,
    ) -> str:
        """Render the collected data using a Jinja template."""
        template = self.env.get_template("object.html.jinja")

        context = {
            "config": options,
            "data": data,
            "heading_level": options.heading_level,
            "root": True,
            "package_name": getattr(self, "_package_name", "unknown_package"),
        }

        return template.render(**context)

    def get_aliases(self, identifier: str) -> tuple[str, ...]:
        """Return known aliases for cross-referencing."""
        if identifier in self._collected:
            return (self._collected[identifier]["path"],)
        return ()

    def update_env(self, config: dict) -> None:  # noqa: ARG002
        """Update the Jinja environment with mkdocstrings filters and formatting options."""
        super().update_env(config)  # Critical: registers convert_markdown, crossref, etc.

        self.env.trim_blocks = True
        self.env.lstrip_blocks = True
        self.env.keep_trailing_newline = False


def get_handler(
    handler_config: dict[str, Any],
    tool_config: Any,
    **kwargs: Any,
) -> DartHandler:
    """Factory function used by mkdocstrings to instantiate the handler."""
    base_dir = Path(tool_config.config_file_path or "./mkdocs.yml").parent
    config = DartConfig.from_data(**handler_config)
    return DartHandler(config=config, base_dir=base_dir, **kwargs)
