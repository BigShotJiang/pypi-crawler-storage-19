"""Dart handler for mkdocstrings."""

from mkdocstrings_handlers.dart._internal.handler import get_handler
from mkdocstrings_handlers.dart._internal.config import DartConfig, DartOptions

__all__ = [
    "get_handler",
    "DartConfig",
    "DartOptions",
]
