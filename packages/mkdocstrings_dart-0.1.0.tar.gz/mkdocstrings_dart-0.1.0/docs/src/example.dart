/// A simple calculator class for demonstration purposes.
///
/// This class performs basic arithmetic operations and showcases
/// how mkdocstrings-dart renders doc comments, parameters, and source code.
///
/// Example:
///
/// ```dart
/// final calc = Calculator();
/// print(calc.add(5, 3)); // -> 8
/// ```
class Calculator {
  /// Creates a new calculator instance.
  ///
  /// [initialValue] sets the starting value (defaults to 0).
  Calculator({this.initialValue = 0});

  /// The current value of the calculator.
  final double initialValue;

  /// Adds two numbers.
  ///
  /// [a] The first number.
  /// [b] The second number.
  ///
  /// Returns the sum of [a] and [b].
  double add(double a, double b) {
    return a + b;
  }

  /// Multiplies two numbers.
  ///
  /// Returns the product.
  double multiply(double a, double b) => a * b;

  /// Resets the calculator to zero.
  ///
  /// This method doesn't actually store state — it's just for demo!
  void reset() {
    print('Reset to 0');
  }
}
