# mkdocstrings-dart Demo

This is a live demonstration of the Dart handler in action.

::: Calculator
