# Changelog

## [0.1.0] - 2026-01-10

### Added

- Initial public release of **mkdocstrings-dart** — the first Dart handler for mkdocstrings!
- Full rendering of classes, constructors, methods, getters/setters
- Parameter tables with types and defaults
- Return type display
- Collapsible source code panel with Dart syntax highlighting (via highlight.js)
- Automatic package name detection from `pubspec.yaml`
- Support for both `::: package.Class` and `::: Class` identifier styles
- Configurable options: `paths`, `show_source`, `exclude_files`, `heading_level`
- Modern, wide, responsive styling with professional look and feel
- Powered by `dartdoc_json` for accurate parsing of Dart doc comments and structure
- Demo site in `docs/` with live example

### Notes

- Requires `dart pub global activate dartdoc_json`
- Tested with MkDocs Material theme
