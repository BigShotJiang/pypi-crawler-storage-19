"""Supernote command line tool."""
