# Changelog

## v0.1.0 (released 2026-01-10)

### Features and Improvements

- **Breaking** Extract core library functionality out of pogo-migrate. [[9a00ead](https://github.com/NRWLDev/pogo-core/commit/9a00ead4e35833263e9f354d197e6235a1a4da37)]

### Miscellaneous

- Improve test coverage. [[a11d7c2](https://github.com/NRWLDev/pogo-core/commit/a11d7c2c38769335d60a2cd6e052a6aa33c21aa4)]
