from .cADBturnnel import cADBturnnel as cADBturnnel
from _typeshed import Incomplete
from enum import Enum

class POSIX_TZ(Enum):
    KST = 'KST-9'
    JST = 'JST-9'
    HKT = 'HKT-8'
    SGT = 'SGT-8'
    ICT = 'ICT-7'
    PST = 'PST8PDT'
    GMT = 'GMT0BST'
    CET = 'CET-1CEST'
    EST = 'EST5EDT'
    AEST = 'AEST-10AEDT'
    GST = 'GST-4'
    IST = 'IST-5:30'
    MSK = 'MSK-3'
    BRT3 = 'BRT3'
    NZST = 'NZST-12NZDT'

class cTSynchor:
    UTC_VALID_VAR: float
    SpecialZone: Incomplete
    @property
    def turnnel(self): ...
    def sync_timestamp(self) -> None: ...
    def __init__(self, chan: cADBturnnel, valid_timestamp_scope: float = ...) -> None: ...
    def __del__(self) -> None: ...
