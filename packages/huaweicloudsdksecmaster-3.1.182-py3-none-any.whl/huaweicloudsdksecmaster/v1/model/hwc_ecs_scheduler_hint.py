# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class HwcEcsSchedulerHint:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'group': 'list[str]',
        'tenancy': 'list[str]',
        'dedicated_host_id': 'list[str]'
    }

    attribute_map = {
        'group': 'group',
        'tenancy': 'tenancy',
        'dedicated_host_id': 'dedicated_host_id'
    }

    def __init__(self, group=None, tenancy=None, dedicated_host_id=None):
        r"""HwcEcsSchedulerHint

        The model defined in huaweicloud sdk

        :param group: 云服务器组ID，UUID格式。 云服务器组的ID可以从控制台或者参考查询云服务器组列表获取。
        :type group: list[str]
        :param tenancy: 在指定的专属主机或者共享主机上创建弹性云服务器。 参数值为shared或者dedicated。
        :type tenancy: list[str]
        :param dedicated_host_id: 专属主机的ID。 说明： 专属主机的ID仅在tenancy为dedicated时生效。
        :type dedicated_host_id: list[str]
        """
        
        

        self._group = None
        self._tenancy = None
        self._dedicated_host_id = None
        self.discriminator = None

        if group is not None:
            self.group = group
        if tenancy is not None:
            self.tenancy = tenancy
        if dedicated_host_id is not None:
            self.dedicated_host_id = dedicated_host_id

    @property
    def group(self):
        r"""Gets the group of this HwcEcsSchedulerHint.

        云服务器组ID，UUID格式。 云服务器组的ID可以从控制台或者参考查询云服务器组列表获取。

        :return: The group of this HwcEcsSchedulerHint.
        :rtype: list[str]
        """
        return self._group

    @group.setter
    def group(self, group):
        r"""Sets the group of this HwcEcsSchedulerHint.

        云服务器组ID，UUID格式。 云服务器组的ID可以从控制台或者参考查询云服务器组列表获取。

        :param group: The group of this HwcEcsSchedulerHint.
        :type group: list[str]
        """
        self._group = group

    @property
    def tenancy(self):
        r"""Gets the tenancy of this HwcEcsSchedulerHint.

        在指定的专属主机或者共享主机上创建弹性云服务器。 参数值为shared或者dedicated。

        :return: The tenancy of this HwcEcsSchedulerHint.
        :rtype: list[str]
        """
        return self._tenancy

    @tenancy.setter
    def tenancy(self, tenancy):
        r"""Sets the tenancy of this HwcEcsSchedulerHint.

        在指定的专属主机或者共享主机上创建弹性云服务器。 参数值为shared或者dedicated。

        :param tenancy: The tenancy of this HwcEcsSchedulerHint.
        :type tenancy: list[str]
        """
        self._tenancy = tenancy

    @property
    def dedicated_host_id(self):
        r"""Gets the dedicated_host_id of this HwcEcsSchedulerHint.

        专属主机的ID。 说明： 专属主机的ID仅在tenancy为dedicated时生效。

        :return: The dedicated_host_id of this HwcEcsSchedulerHint.
        :rtype: list[str]
        """
        return self._dedicated_host_id

    @dedicated_host_id.setter
    def dedicated_host_id(self, dedicated_host_id):
        r"""Sets the dedicated_host_id of this HwcEcsSchedulerHint.

        专属主机的ID。 说明： 专属主机的ID仅在tenancy为dedicated时生效。

        :param dedicated_host_id: The dedicated_host_id of this HwcEcsSchedulerHint.
        :type dedicated_host_id: list[str]
        """
        self._dedicated_host_id = dedicated_host_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, HwcEcsSchedulerHint):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
