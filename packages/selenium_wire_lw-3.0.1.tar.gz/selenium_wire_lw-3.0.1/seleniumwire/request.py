"""Houses the classes used to transfer request and response data between components. """

from datetime import datetime
from http import HTTPStatus
from http.client import HTTPMessage
from typing import Iterable, Optional, Union
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit

from mitmproxy.certs import Cert
import zlib
import brotli
import zstd

class HTTPHeaders(HTTPMessage):
    """A dict-like data-structure to hold HTTP headers.

    Note that duplicate key names are permitted.
    """

    def __repr__(self):
        return repr(self.items())

class CommonWeb:
    _body: bytes

    def __init__(self, headers: Iterable[tuple[str, str]]):
        self.headers = HTTPHeaders()

        for k, v in headers:
            self.headers.add_header(k, v)

    def decompress_body(self):
        encoding = self.headers.get("content-encoding")
        if encoding == "gzip":
            return zlib.decompress(self._body, wbits = 16+zlib.MAX_WBITS)
        elif encoding == "br":
            return brotli.decompress(self._body)
        elif encoding == "deflate":
            return zlib.decompress(self._body, wbits = 0)
        elif encoding == "zstd":
            return zstd.decompress(self._body)
        elif encoding is None:
            return self._body

        raise RuntimeError("Unhandled compression method: {}".format(encoding))

    @property
    def body(self) -> bytes:
        """Get the request body.

        Returns: The request body as bytes.
        """
        return self._body

    @body.setter
    def body(self, b: bytes | str | None):
        if b is None:
            self._body = b""
        elif isinstance(b, str):
            self._body = b.encode("utf-8")
        elif not isinstance(b, bytes):
            raise TypeError("body must be of type bytes")
        else:
            self._body = b

class Request(CommonWeb):
    """Represents an HTTP request."""

    def __init__(
        self,
        *,
        method: str,
        url: str,
        headers: Iterable[tuple[str, str]],
        body: bytes | str | None = b""
    ):
        """Initialise a new Request object.

        Args:
            method: The request method - GET, POST etc.
            url: The request URL.
            headers: The request headers as an iterable of 2-element tuples.
            body: The request body as bytes.
        """
        super().__init__(headers)

        self.id: Optional[str] = None  # The id is set for captured requests
        self.method = method
        self.url = url

        self.body = body  # type: ignore
        self.response: Optional[Response] = None
        self.date: datetime = datetime.now()
        self.ws_messages: list[WebSocketMessage] = []
        self.certificate_list: list[Cert] = []

    def __getstate__(self):
        state = self.__dict__
        state["certificate_list"] = [cert.get_state() for cert in state["certificate_list"]]
        return state

    def __setstate__(self, state):
        state["certificate_list"] = [Cert.from_state(cert) for cert in state["certificate_list"]]
        self.__dict__ = state


    @property
    def querystring(self) -> str:
        """Get the query string from the request.

        Returns: The query string.
        """
        return urlsplit(self.url).query

    @querystring.setter
    def querystring(self, qs: str):
        parts = list(urlsplit(self.url))
        parts[3] = qs
        self.url = urlunsplit(parts)

    @property
    def params(self) -> dict[str, Union[str, list[str]]]:
        """Get the request parameters.

        Parameters are returned as a dictionary. Each dictionary entry will have a single
        string value, unless a parameter happens to occur more than once in the request,
        in which case the value will be a list of strings.

        Returns: A dictionary of request parameters.
        """
        qs = self.querystring

        if self.headers.get("Content-Type") == "application/x-www-form-urlencoded" and self.body:
            qs = self.body.decode("utf-8", errors="replace")

        return {name: val[0] if len(val) == 1 else val for name, val in parse_qs(qs, keep_blank_values=True).items()}

    @params.setter
    def params(self, p: dict[str, Union[str, list[str]]]):
        qs = urlencode(p, doseq=True)

        if self.headers.get("Content-Type") == "application/x-www-form-urlencoded":
            self.body = qs.encode("utf-8", errors="replace")
        else:
            parts = list(urlsplit(self.url))
            parts[3] = qs
            self.url = urlunsplit(parts)

    @property
    def path(self) -> str:
        """Get the request path.

        Returns: The request path.
        """
        return urlsplit(self.url).path

    @path.setter
    def path(self, p: str):
        parts = list(urlsplit(self.url))
        parts[2] = p
        self.url = urlunsplit(parts)

    @property
    def host(self) -> str:
        """Get the request host.

        Returns: The request host.
        """
        return urlsplit(self.url).netloc

    def create_response(
        self,
        status_code: HTTPStatus,
        headers: Union[dict[str, str], Iterable[tuple[str, str]]] = (),
        body: bytes = b"",
    ):
        """Create a response object and attach it to this request."""
        try:
            reason = {v: v.phrase for v in HTTPStatus.__members__.values()}[status_code]
        except KeyError:
            raise ValueError("Unknown status code: {}".format(status_code))

        if isinstance(headers, dict):
            headers = headers.items()

        self.response = Response(status_code=status_code, reason=reason, headers=headers, body=body)

    def abort(self, error_code: HTTPStatus = HTTPStatus.FORBIDDEN):
        """Convenience method for signalling that this request is to be terminated
        with a specific error code.
        """
        self.create_response(status_code=error_code)

    def __repr__(self):
        return "Request(method={method!r}, url={url!r}, headers={headers!r}, body={_body!r})".format_map(vars(self))

    def __str__(self):
        return self.url


class Response(CommonWeb):
    """Represents an HTTP response."""

    def __init__(
        self,
        *,
        status_code: int,
        reason: str,
        headers: Iterable[tuple[str, str]],
        body: bytes | str | None = b""
    ):
        """Initialise a new Response object.

        Args:
            status_code: The status code.
            reason: The reason message (e.g. "OK" or "Not Found").
            headers: The response headers as an iterable of 2-element tuples.
            body: The response body as bytes.
        """
        super().__init__(headers)

        self.status_code = status_code
        self.reason = reason

        self.body = body  # type: ignore
        self.date: datetime = datetime.now()
        self.certificate_list: list[Cert] = []

    def __getstate__(self):
        state = self.__dict__
        state["certificate_list"] = [cert.get_state() for cert in state["certificate_list"]]
        return state

    def __setstate__(self, state):
        state["certificate_list"] = [Cert.from_state(cert) for cert in state["certificate_list"]]
        self.__dict__ = state

    def __repr__(self):
        return (
            "Response(status_code={status_code!r}, reason={reason!r}, headers={headers!r}, "
            "body={_body!r})".format_map(vars(self))
        )

    def __str__(self):
        return "{} {}".format(self.status_code, self.reason)


class WebSocketMessage:
    """Represents a websocket message transmitted between client and server
    or vice versa.
    """

    def __init__(self, *, from_client: bool, content: Union[str, bytes], date: datetime):
        """Initialise a new websocket message.

        Args:
            from_client: True if the message was sent by the client.
            content: The text or binary message data.
            date: The datetime the message was sent or received.
        """
        self.from_client = from_client
        self.content = content
        self.date = date

    def __str__(self):
        if isinstance(self.content, str):
            return self.content
        return f"<{len(self.content)} bytes of binary websocket data>"

    def __eq__(self, other):
        if not isinstance(other, WebSocketMessage):
            return False
        elif self is other:
            return True
        return self.from_client == other.from_client and self.content == other.content and self.date == other.date
