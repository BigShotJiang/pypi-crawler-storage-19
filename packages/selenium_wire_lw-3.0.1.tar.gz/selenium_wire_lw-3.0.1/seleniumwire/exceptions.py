class SeleniumWireException(Exception):
    pass
