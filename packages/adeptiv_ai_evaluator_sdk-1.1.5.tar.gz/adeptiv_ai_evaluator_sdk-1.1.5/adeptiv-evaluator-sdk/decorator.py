import time
import inspect
import functools
import asyncio

from opentelemetry.trace import Status, StatusCode

from .telemetry import init_telemetry
from .config import config
from .utils import hash_text, safe_value

_tracer, _logger = init_telemetry()


def trace_llm(
    name: str = None,
    model: str = None,
    operation: str = "llm",
    capture_inputs: bool = True,
    capture_outputs: bool = True,
    preview_limit: int = 500,
):
    def decorator(func):
        span_name = name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _tracer.start_as_current_span(span_name) as span:
                start_time = time.time()

                # OpenTelemetry GenAI attributes
                span.set_attribute("genai.operation", operation)
                span.set_attribute("genai.model", model or "unknown")

                # Adeptiv identity
                span.set_attribute("adeptiv.sdk", "adeptiv-genai")
                span.set_attribute("adeptiv.function", func.__name__)

                if capture_inputs or config.capture_inputs:
                    span.set_attribute(
                        "genai.prompt.hash",
                        hash_text(str(args) + str(kwargs)),
                    )

                try:
                    result = func(*args, **kwargs)

                    latency = (time.time() - start_time) * 1000
                    span.set_attribute("genai.latency_ms", latency)

                    if capture_outputs or config.capture_outputs:
                        raw = str(result)
                        span.set_attribute(
                            "genai.response.type",
                            type(result).__name__,
                        )
                        span.set_attribute(
                            "genai.response.size",
                            len(raw),
                        )
                        span.set_attribute(
                            "genai.response.hash",
                            hash_text(raw),
                        )
                        span.set_attribute(
                            "adeptiv.response.preview",
                            safe_value(raw, preview_limit),
                        )

                    return result

                except Exception as e:
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    _logger.exception("LLM invocation failed")
                    raise

        return wrapper

    return decorator


def trace_agent(
    agent_name: str,
    model: str = None,
    capture_outputs: bool = True,
    preview_limit: int = 500,
):
    def decorator(func):
        async def _run(func, *args, **kwargs):
            with _tracer.start_as_current_span(f"agent.{agent_name}") as span:
                span.set_attribute("genai.operation", "agent")
                span.set_attribute("genai.model", model or "unknown")

                span.set_attribute("adeptiv.agent.name", agent_name)
                span.set_attribute("adeptiv.agent.framework", "custom")

                start_time = time.time()

                try:
                    result = await func(*args, **kwargs)

                    latency = (time.time() - start_time) * 1000
                    span.set_attribute("genai.latency_ms", latency)

                    if capture_outputs:
                        raw = str(result)
                        span.set_attribute(
                            "genai.response.hash",
                            hash_text(raw),
                        )
                        span.add_event(
                            "genai.agent.response",
                            {
                                "preview": safe_value(raw, preview_limit),
                            },
                        )

                    return result

                except Exception as e:
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    raise

        if inspect.iscoroutinefunction(func):
            return functools.wraps(func)(_run)
        else:
            return functools.wraps(func)(
                lambda *a, **k: asyncio.run(_run(func, *a, **k))
            )

    return decorator
