"""GitHub Actions related utils."""
