CLI Reference
=============

Complete reference for all ``mater-cli`` commands.

.. click:: src.cli:cli
   :prog: mater-cli
   :nested: full