import os
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.abspath(".."))

project = "init-mater-project"
copyright = f"{datetime.now().year}, Lauranne Sarribouette"
author = "Lauranne Sarribouette"

try:
    import tomllib

    pyproject_path = Path("..") / "pyproject.toml"
    with open(pyproject_path, "rb") as f:
        pyproject_data = tomllib.load(f)
    release = pyproject_data["project"]["version"]
except Exception:
    release = "0.1.0"

# -- General configuration ---------------------------------------------------
extensions = [
    "sphinx_click",  # CLI documentation
    "sphinx_copybutton",  # Copy code button
    "sphinx_design",  # Nice UI components
    "myst_parser",  # Markdown support
]

# MyST markdown configuration
myst_enable_extensions = [
    "colon_fence",
    "deflist",
    "tasklist",
]

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}

# -- HTML output configuration -----------------------------------------------
html_theme = "pydata_sphinx_theme"

html_theme_options = {
    "navbar_align": "left",
    "show_prev_next": False,
    "secondary_sidebar_items": ["page-toc"],
    "show_toc_level": 4,
    "icon_links": [
        {
            "name": "GitLab",
            "url": "https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project",
            "icon": "fa-brands fa-gitlab",
            "type": "fontawesome",
        },
        {
            "name": "PyPI",
            "url": "https://pypi.org/project/init-mater-project/",
            "icon": "fa-brands fa-python",
            "type": "fontawesome",
        },
    ],
    "icon_links_label": "Quick Links",
}

# Static files
html_static_path = ["_static"]

html_logo = "_static/MATER_logo.png"

# Table of contents settings
toc_object_entries_show_parents = "hide"
