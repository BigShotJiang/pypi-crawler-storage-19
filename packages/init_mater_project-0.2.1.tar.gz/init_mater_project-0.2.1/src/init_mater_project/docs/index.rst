init-mater-project
==================

**CLI tool to transform raw datasets into MATER-ready data and run your own MATER simulations.**

CLI Reference
-------------

Complete documentation of all ``mater-cli`` commands and options.

.. toctree::

   cli_reference