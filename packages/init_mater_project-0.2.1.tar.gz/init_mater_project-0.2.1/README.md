# init-mater-project

[![PyPI version](https://img.shields.io/pypi/v/init-mater-project.svg)](https://pypi.org/project/init-mater-project/)
[![Python](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
![Coverage](https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project/badges/main/coverage.svg)
[![MATER](https://img.shields.io/badge/framework-MATER-orange.svg)](https://isterre-dynamic-modeling.gricad-pages.univ-grenoble-alpes.fr/mater-project/mater)
[![UV](https://img.shields.io/badge/managed_by-UV-blue.svg)](https://docs.astral.sh/uv/)
[![License](https://img.shields.io/badge/license-LGPLv3-blue.svg)](LICENSE)

**CLI tool to transform raw datasets into MATER-ready data and run your own MATER simulations.**

## Quick Start

You can create a new MATER project:

```bash
# Run without install — recommended
uvx init-mater-project my-project
# Or 
pipx run init-mater-project my-project

cd my-project
```

Alternatively, you can initialize a project in the working directory:

```bash
mkdir my-project
cd my-project

# Run without install — recommended
uvx init-mater-project
# Or 
pipx run init-mater-project

cd my-simulation
```

Run and visualise your first MATER simulation:

```bash
uv run mater-cli simulation run --example

# Visualise outputs
uv run mater-cli simulation serve --example
```

`init-mater-project` creates a complete MATER project with:
- Configuration templates
- Data pipeline structure  
- CLI toolchain
- Outputs visualisation app
- Example datasets
- Documentation

## Documentation

- **[Detailed Documentation](link-to-come)** — MkDocs with configuration, user guide, developer guide, testing, deployment, architecture
- **[Changelog](https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project/-/blob/main/CHANGELOG.md)**
- **[Contributing](https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project/-/blob/main/CONTRIBUTING.md)**
- **[License](https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project/-/blob/main/LICENSE)** — LGPLv3 License details, third-party dependencies are listed in [THIRD_PARTY_LICENSES.md](https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/init-mater-project/-/blob/main/THIRD_PARTY_LICENSES.md)