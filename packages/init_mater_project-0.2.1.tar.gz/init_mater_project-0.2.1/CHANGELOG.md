## 0.2.1 - 2025-01-09

### Changed
- MATER version upgrade with Python 3.10 backward compatibility

### Fixed
- UTF-8 encoding for Windows compatibility across file operations

## 0.2.0 - 2025-12-01

### Added
- Sphinx auto-generated CLI documentation
- Streamlit visualization app for MATER outputs (charts, multi-simulations, data export)
- Excel format support via python-calamine

### Changed
- Project generation with improved default path handling
- MATER version upgrade with optimized dependencies

### Fixed
- Unit test echo messages
- Missing lib folder in .gitignore
- README badge and quick start section