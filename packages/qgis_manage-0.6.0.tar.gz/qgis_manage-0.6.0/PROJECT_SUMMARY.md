# PROJECT SUMMARY - qgis-plugin-manager
Analysis Date: 2026-01-11 23:49:26
Analyzer Version: 2.0 (Ai-Context-Core)

## 📊 KEY METRICS
- **Total Modules**: 10
- **Lines of Code**: 1,665
- **Total Size**: 0.5 MB
- **Average Complexity**: 20.3
- **Docstring Coverage**: 79.3%
- **Quality Score**: 70.0/100
- **Test Files**: 8

## 📁 STRUCTURE
- **Python Files**: 18
- **Total Files**: 89
- **Primary File Types**: .py, .pyi, .json, .pyc, .so

## 🚨 CRITICAL ISSUES

### 🔒 Security Issues:
- **src/qgis_manager/core.py**: 2 issues (Max: HIGH)
- **generator_export/generator.py**: 1 issues (Max: MEDIUM)
- **src/qgis_manager/config.py**: 1 issues (Max: MEDIUM)

### 🏗️ Critical Technical Debt:
- **src/qgis_manager/discovery.py**: 2 issues (Score: 4)
- **src/qgis_manager/core.py**: 2 issues (Score: 4)
- **src/qgis_manager/cli.py**: 2 issues (Score: 4)


## 💡 MAIN RECOMMENDATIONS

### generator_export/generator.py
- Low docstring coverage (1/4 functions).

### src/qgis_manager/hooks.py
- Very long functions (average 54.0 lines/function).

### src/qgis_manager/validation.py
- High complexity (19) with several functions. Consider breaking down large logic.

## 📈 COMPLEXITY DISTRIBUTION
- low (0-5): 2 modules (20.0%)
- medium (6-15): 4 modules (40.0%)
- high (16-30): 2 modules (20.0%)
- very_high (31+): 2 modules (20.0%)