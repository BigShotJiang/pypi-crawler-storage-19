#!/usr/bin/env python3
"""
Simple HTTP server for ACWS Web Client
Serves the static HTML file and servers.ini configuration
"""


import http.server
import socketserver
import os
import sys
from pathlib import Path


class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom request handler with better error messages"""

    def __init__(self, *args, directory=None, **kwargs):
        if directory is None:
            directory = Path(__file__).parent.absolute()
        super().__init__(*args, directory=directory, **kwargs)

    def end_headers(self):
        # Add CORS headers to allow cross-origin requests if needed
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def log_message(self, fmt, *args):
        """Override to show cleaner log messages"""
        print(f"[{self.log_date_time_string()}] {fmt % args}")


def main(ip, port, script_dir):
    """Start the HTTP server with CLI options"""
    script_dir = Path(script_dir).absolute()
    os.chdir(script_dir)

    # Check if index.html exists
    if not (script_dir / 'index.html').exists():
        print(f"ERROR: index.html not found in {script_dir}")
        print("Please make sure index.html is in the same directory as server.py")
        sys.exit(1)

    max_attempts = 10
    for attempt in range(max_attempts):
        try:
            with socketserver.TCPServer((ip, port),
                                        MyHTTPRequestHandler,
                                        bind_and_activate=True) as httpd:
                print("=" * 60)
                print("ACWS Web Client - HTTP Server")
                print("=" * 60)
                print(f"Serving directory: {script_dir}")
                print(f"Server running at: http://{ip}:{port}/")
                print(f"Open in browser: http://{ip}:{port}/index.html")
                print("=" * 60)
                print("Press Ctrl+C to stop the server")
                print("=" * 60)
                httpd.serve_forever()
        except OSError as e:
            if e.errno == 48 or "Address already in use" in str(e):
                port += 1
                if attempt < max_attempts - 1:
                    print(f"Port {port - 1} is in use, trying port {port}...")
                    continue
            raise
    print(
        f"ERROR: Could not find an available port after {max_attempts} attempts")
    sys.exit(1)
