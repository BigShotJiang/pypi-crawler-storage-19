
"""Main entry point for the ac_http_server module."""

import argparse
from pathlib import Path
import sys

from .server import main

# Default values
DEFAULT_PORT = 8000
DEFAULT_IP = "0.0.0.0"
DEFAULT_SCRIPT_DIR = Path(__file__).parent.absolute()

# Ensure the module can be run as a script
if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="ACWS Web Client HTTP Server")
    parser.add_argument("--ip", type=str, default=DEFAULT_IP,
                        help="IP address to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help="Port number to bind (default: 8000)")
    parser.add_argument("--dir", type=str, default=str(DEFAULT_SCRIPT_DIR),
                        help="Directory to serve (default: script location)")
    args = parser.parse_args()
    try:
        print("Starting ACWS Web Client HTTP Server...")
        sys.exit(main(ip=args.ip, port=args.port, script_dir=args.dir))
    except KeyboardInterrupt:
        print("\nServer stopped by user")
