"""Tests for AXM constants."""

from axm import constants


def test_constants_exist() -> None:
    """Verify that required constants are defined."""
    assert constants.DEFAULT_SCHEMA_VERSION == "1.0"
