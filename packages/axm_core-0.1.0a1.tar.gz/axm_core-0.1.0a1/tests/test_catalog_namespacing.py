"""Test registry namespacing to avoid name collisions."""

from axm.catalog.entries.data import DataEntry
from axm.catalog.entries.operation import OperationEntry
from axm.catalog.loading.catalog import DataCatalog


def make_data_entry(name: str) -> DataEntry:
    """Create a minimal DataEntry for testing."""
    return DataEntry(
        name=name,
        version="1.0.0",
        identity={
            "display_name": name.title(),
            "description": f"Test {name}",
            "domain": "test",
            "owner": {"team": "test", "contact": "test@test.com"},
        },
        schema={"format": "tabular"},
        location={"storage": "file", "path_template": f"data/{name}.csv"},
    )


def make_op_entry(name: str) -> OperationEntry:
    """Create a minimal OperationEntry for testing."""
    return OperationEntry(
        name=name,
        version="1.0.0",
        identity={
            "display_name": name.title(),
            "description": f"Test op {name}",
            "domain": "test",
            "owner": {"team": "test", "contact": "test@test.com"},
        },
        spec={"type": "python_file", "source": f"{name}.py", "entrypoint": name},
        inputs=[],
        outputs=[],
    )


class TestRegistryNamespacing:
    """Test separate registries by kind."""

    def test_same_name_different_kinds_no_collision(self) -> None:
        """Same name in different kinds should not collide."""
        catalog = DataCatalog()

        data_entry = make_data_entry("users")
        op_entry = make_op_entry("users")

        catalog.register(data_entry)
        catalog.register(op_entry)

        # Both should be retrievable via typed accessors
        assert catalog.data["users"] == data_entry
        assert catalog.operations["users"] == op_entry

    def test_data_accessor(self) -> None:
        """catalog.data['name'] returns DataEntry."""
        catalog = DataCatalog()
        entry = make_data_entry("test")
        catalog.register(entry)

        assert catalog.data["test"] is entry
        assert isinstance(catalog.data["test"], DataEntry)

    def test_operations_accessor(self) -> None:
        """catalog.operations['name'] returns OperationEntry."""
        catalog = DataCatalog()
        entry = make_op_entry("my_op")
        catalog.register(entry)

        assert catalog.operations["my_op"] is entry
        assert isinstance(catalog.operations["my_op"], OperationEntry)

    def test_backward_compat_namespaced_key(self) -> None:
        """catalog['data:name'] for backward compatibility."""
        catalog = DataCatalog()
        entry = make_data_entry("test")
        catalog.register(entry)

        # Namespaced key access
        assert catalog["data:test"] is entry
