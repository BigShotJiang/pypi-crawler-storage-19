"""Smoke tests to verify project setup."""

from axm import __version__, get_version


def test_version_is_valid() -> None:
    """Verify version string format."""
    assert __version__ == "0.1.0"
    assert get_version() == __version__
    parts = __version__.split(".")
    assert len(parts) == 3
    assert all(part.isdigit() for part in parts)


def test_package_imports() -> None:
    """Verify all submodules are importable."""
    import axm.catalog
    import axm.core
    import axm.utils

    assert axm.catalog is not None
    assert axm.core is not None
    assert axm.utils is not None
