"""Tests for catalog base protocols and common models."""

from datetime import datetime

from axm.core import (
    CatalogMetadata,
    Severity,
    ValidationError,
    ValidationResult,
)


class TestValidationError:
    """Tests for ValidationError model."""

    def test_create_error(self) -> None:
        """Should create a validation error with required fields."""
        error = ValidationError(
            field="email",
            message="Invalid email format",
            severity=Severity.ERROR,
        )
        assert error.field == "email"
        assert error.message == "Invalid email format"
        assert error.severity == Severity.ERROR

    def test_create_warning(self) -> None:
        """Should support warning severity."""
        warning = ValidationError(
            field="age",
            message="Value seems unusually high",
            severity=Severity.WARNING,
        )
        assert warning.severity == Severity.WARNING


class TestValidationResult:
    """Tests for ValidationResult model."""

    def test_valid_result(self) -> None:
        """Should create a valid result with no errors."""
        result = ValidationResult(is_valid=True, errors=[], warnings=[])
        assert result.is_valid is True
        assert len(result.errors) == 0
        assert len(result.warnings) == 0

    def test_invalid_result_with_errors(self) -> None:
        """Should create invalid result with errors."""
        errors = [
            ValidationError(
                field="user_id",
                message="Cannot be null",
                severity=Severity.ERROR,
            )
        ]
        result = ValidationResult(is_valid=False, errors=errors, warnings=[])
        assert result.is_valid is False
        assert len(result.errors) == 1
        assert result.errors[0].field == "user_id"

    def test_factory_valid(self) -> None:
        """Should create valid result via factory method."""
        result = ValidationResult.valid()
        assert result.is_valid is True
        assert len(result.errors) == 0

    def test_factory_invalid(self) -> None:
        """Should create invalid result via factory method."""
        result = ValidationResult.invalid(
            field="email",
            message="Required field missing",
        )
        assert result.is_valid is False
        assert len(result.errors) == 1


class TestCatalogMetadata:
    """Tests for CatalogMetadata model."""

    def test_default_values(self) -> None:
        """Should have sensible defaults."""
        meta = CatalogMetadata()
        assert meta.owner is None
        assert meta.tags == []
        assert meta.created_at is None

    def test_full_metadata(self) -> None:
        """Should support all fields."""
        now = datetime.now()
        meta = CatalogMetadata(
            owner="data-team",
            tags=["pii", "users"],
            created_at=now,
        )
        assert meta.owner == "data-team"
        assert "pii" in meta.tags
        assert meta.created_at == now
