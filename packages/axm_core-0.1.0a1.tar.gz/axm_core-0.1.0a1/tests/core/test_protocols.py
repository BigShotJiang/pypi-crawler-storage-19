"""Tests for catalog base protocols."""

from collections.abc import Iterator
from pathlib import Path
from typing import Any, Self

from axm.core import BaseCatalog, BaseCatalogEntry, BaseValidator, ValidationResult


class MockEntry:
    """Mock implementation of BaseCatalogEntry for testing."""

    def __init__(
        self,
        name: str,
        version: str = "1.0",
        description: str | None = None,
    ) -> None:
        self.name = name
        self.version = version
        self.description = description

    @classmethod
    def from_yaml(cls, path: Path) -> Self:
        """Load from YAML file."""
        return cls(name=path.stem)

    def to_yaml(self) -> str:
        """Serialize to YAML."""
        return f"name: {self.name}\nversion: {self.version}"

    def validate_entry(self) -> ValidationResult:
        """Validate entry."""
        return ValidationResult.valid()


class TestBaseCatalogEntry:
    """Tests for BaseCatalogEntry protocol."""

    def test_entry_implements_protocol(self) -> None:
        """MockEntry should satisfy BaseCatalogEntry protocol."""
        entry: BaseCatalogEntry = MockEntry(name="users", version="1.0")
        assert entry.name == "users"
        assert entry.version == "1.0"

    def test_entry_from_yaml(self, tmp_path: Path) -> None:
        """Should load entry from YAML path."""
        yaml_file = tmp_path / "test.axm"
        yaml_file.write_text("name: test")

        entry = MockEntry.from_yaml(yaml_file)
        # stem of "test.axm" is "test"
        assert entry.name == "test"

    def test_entry_to_yaml(self) -> None:
        """Should serialize entry to YAML string."""
        entry = MockEntry(name="users", version="2.0")
        yaml_str = entry.to_yaml()
        assert "name: users" in yaml_str
        assert "version: 2.0" in yaml_str

    def test_entry_validate(self) -> None:
        """Should return ValidationResult."""
        entry = MockEntry(name="test")
        result = entry.validate_entry()
        assert isinstance(result, ValidationResult)
        assert result.is_valid is True


class MockCatalog:
    """Mock implementation of BaseCatalog for testing."""

    def __init__(self) -> None:
        self._entries: dict[str, MockEntry] = {}

    def __getitem__(self, name: str) -> MockEntry:
        return self._entries[name]

    def __iter__(self) -> Iterator[MockEntry]:
        return iter(self._entries.values())

    def __len__(self) -> int:
        return len(self._entries)

    def register(self, entry: MockEntry) -> None:
        self._entries[entry.name] = entry

    @classmethod
    def from_directory(cls, path: Path) -> Self:
        catalog = cls()
        for yaml_file in path.glob("*.axm"):
            entry = MockEntry.from_yaml(yaml_file)
            catalog.register(entry)
        return catalog


class TestBaseCatalog:
    """Tests for BaseCatalog protocol."""

    def test_catalog_implements_protocol(self) -> None:
        """MockCatalog should satisfy BaseCatalog protocol."""
        catalog: BaseCatalog[MockEntry] = MockCatalog()
        entry = MockEntry(name="users")
        catalog.register(entry)
        assert catalog["users"].name == "users"

    def test_catalog_iteration(self) -> None:
        """Should iterate over entries."""
        catalog = MockCatalog()
        catalog.register(MockEntry(name="users"))
        catalog.register(MockEntry(name="orders"))

        names = [e.name for e in catalog]
        assert "users" in names
        assert "orders" in names

    def test_catalog_from_directory(self, tmp_path: Path) -> None:
        """Should load catalog from directory."""
        (tmp_path / "users.axm").write_text("name: users")
        (tmp_path / "orders.axm").write_text("name: orders")

        catalog = MockCatalog.from_directory(tmp_path)
        assert len(catalog) == 2


class MockValidator:
    """Mock implementation of BaseValidator for testing."""

    def __init__(self, always_valid: bool = True) -> None:
        self._always_valid = always_valid

    def validate(self, data: Any) -> ValidationResult:
        if self._always_valid:
            return ValidationResult.valid()
        return ValidationResult.invalid(field="data", message="Invalid")


class TestBaseValidator:
    """Tests for BaseValidator protocol."""

    def test_validator_implements_protocol(self) -> None:
        """MockValidator should satisfy BaseValidator protocol."""
        validator: BaseValidator = MockValidator()
        result = validator.validate({"key": "value"})
        assert isinstance(result, ValidationResult)

    def test_validator_returns_valid(self) -> None:
        """Should return valid result."""
        validator = MockValidator(always_valid=True)
        result = validator.validate({})
        assert result.is_valid is True

    def test_validator_returns_invalid(self) -> None:
        """Should return invalid result."""
        validator = MockValidator(always_valid=False)
        result = validator.validate({})
        assert result.is_valid is False
