"""AXM test suite."""
