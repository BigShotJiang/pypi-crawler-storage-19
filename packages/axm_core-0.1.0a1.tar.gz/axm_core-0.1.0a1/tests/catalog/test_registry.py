"""Tests for Catalog Registry singleton."""

import pytest

from axm.catalog.loading import DataCatalog
from axm.catalog.registry import CatalogRegistry


class TestCatalogRegistry:
    """Tests for CatalogRegistry singleton."""

    def setup_method(self) -> None:
        """Reset registry before each test."""
        CatalogRegistry.reset()

    def test_singleton_instance(self) -> None:
        """Should return the same instance."""
        reg1 = CatalogRegistry()
        reg2 = CatalogRegistry()
        assert reg1 is reg2
        assert CatalogRegistry.get() is reg1

    def test_register_catalog(self) -> None:
        """Should register and retrieve a catalog."""
        registry = CatalogRegistry()
        catalog = DataCatalog()

        registry.register("data", catalog)

        assert "data" in registry
        assert registry.get_catalog("data") is catalog
        assert registry["data"] is catalog

    def test_get_nonexistent_catalog(self) -> None:
        """Should raise KeyError for unknown catalog domain."""
        registry = CatalogRegistry()

        with pytest.raises(KeyError):
            registry.get_catalog("unknown")

    def test_reset_registry(self) -> None:
        """Should clear all registered catalogs."""
        registry = CatalogRegistry()
        registry.register("data", DataCatalog())

        CatalogRegistry.reset()

        # New instance should be empty
        new_registry = CatalogRegistry()
        assert "data" not in new_registry

    def test_register_duplicate_warning(self) -> None:
        """Should allow overwriting catalog (maybe with warning log in future)."""
        registry = CatalogRegistry()
        cat1 = DataCatalog()
        cat2 = DataCatalog()

        registry.register("data", cat1)
        registry.register("data", cat2)

        assert registry["data"] is cat2
