"""Tests for standard common rules — RED phase."""

from axm.catalog.rules.common import is_email, is_positive, not_empty


class TestCommonRules:
    """Tests for standard library rules."""

    def test_not_empty(self) -> None:
        """Should validate non-empty values."""
        rule = not_empty
        assert rule.check("hello") is True
        assert rule.check([1]) is True
        assert rule.check("") is False
        assert rule.check(None) is False
        assert rule.check([]) is False

    def test_is_email(self) -> None:
        """Should validate email formats."""
        rule = is_email
        assert rule.check("test@example.com") is True
        assert rule.check("user.name+tag@domain.co.uk") is True
        assert rule.check("invalid") is False
        assert rule.check("user@") is False
        assert rule.check("@domain.com") is False
        assert rule.check(None) is False

    def test_is_positive(self) -> None:
        """Should validate positive numbers."""
        rule = is_positive
        assert rule.check(1) is True
        assert rule.check(0.1) is True
        assert rule.check(0) is False
        assert rule.check(-1) is False
        assert rule.check("not_number") is False
