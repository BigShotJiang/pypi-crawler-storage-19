"""Tests for Rules and Presets system — RED phase."""

import pytest

from axm.catalog.rules.base import Preset, Rule
from axm.catalog.rules.registry import RuleRegistry


class TestPresets:
    """Tests for Rule and Preset abstractions."""

    def test_rule_validation(self) -> None:
        """Should validate using a simple lambda rule."""
        rule = Rule(
            name="is_positive",
            description="Checks if value is positive",
            callback=lambda x: isinstance(x, (int, float)) and x > 0,
        )

        assert rule.check(10) is True
        assert rule.check(-5) is False
        assert rule.check("string") is False

    def test_preset_composition(self) -> None:
        """Should composite multiple rules into a preset."""
        rule1 = Rule(name="not_none", description="x", callback=lambda x: x is not None)
        rule2 = Rule(
            name="is_int", description="x", callback=lambda x: isinstance(x, int)
        )

        preset = Preset(name="valid_int", rules=[rule1, rule2])

        # All pass
        assert preset.check(10).is_valid is True

        # Fail rule2
        res_float = preset.check(10.5)
        assert res_float.is_valid is False
        assert "is_int" in str(res_float.errors)

        # Fail rule1
        res_none = preset.check(None)
        assert res_none.is_valid is False


class TestRuleRegistry:
    """Tests for the global rule registry."""

    def setup_method(self) -> None:
        RuleRegistry.reset()

    def test_register_and_get(self) -> None:
        """Should register and retrieve rules."""
        rule = Rule(name="test", description="d", callback=lambda x: True)
        RuleRegistry.register(rule)

        retrieved = RuleRegistry.get("test")
        assert retrieved == rule

    def test_get_nonexistent(self) -> None:
        """Should raise error for missing rule."""
        with pytest.raises(KeyError):
            RuleRegistry.get("ghost")
