"""Tests for YAML loader — RED phase."""

from pathlib import Path

import pytest
from pydantic import ValidationError as PydanticValidationError

from axm.catalog.entries import DataEntry, SchemaFormat
from axm.catalog.loading import (
    DataCatalog,
    YAMLLoadError,
    load_data_entry,
)
from axm_image.entries.image import ImageEntry
from axm_tabular.entries.tabular import TabularEntry

FIXTURES_DIR = Path(__file__).parent.parent.parent / "fixtures" / "catalogs"
VALID_DIR = FIXTURES_DIR / "valid"
INVALID_DIR = FIXTURES_DIR / "invalid"


class TestLoadDataEntry:
    """Tests for load_data_entry function."""

    def test_load_valid_complete(self) -> None:
        """Should load a complete AXM file with all fields."""
        entry = load_data_entry(VALID_DIR / "users.axm")

        assert entry.name == "users"
        assert entry.version == "1.0.0"
        assert entry.identity.display_name == "Users Table"
        assert entry.identity.owner.team == "data-team"

        assert isinstance(entry, TabularEntry)

        # users.axm is tabular
        assert entry.data_schema.format == SchemaFormat.TABULAR

        # also check that it is indeed a TabularSchema instance if we want,
        # or just rely on format
        assert hasattr(entry.data_schema, "spec")
        assert getattr(entry.data_schema.spec, "columns", None) is not None
        assert entry.location.storage == "filesystem"
        assert entry.provenance is not None
        assert entry.provenance.source_type == "raw"
        assert entry.governance is not None
        assert entry.governance.sensitivity.pii is True

    def test_load_minimal(self) -> None:
        """Should load a minimal AXM file with only required fields."""
        entry = load_data_entry(VALID_DIR / "minimal.axm")

        assert entry.name == "minimal"

        assert isinstance(entry, DataEntry)

        assert entry.provenance is None
        assert entry.governance is None

    def test_load_image_schema(self) -> None:
        """Should load an image schema format."""
        entry = load_data_entry(VALID_DIR / "images.axm")

        assert entry.name == "camera_images"

        assert isinstance(entry, ImageEntry)

        assert entry.data_schema.format == SchemaFormat.IMAGE
        assert entry.data_schema.spec.width == 1024
        assert entry.data_schema.spec.height == 1024
        assert entry.provenance is not None
        assert entry.provenance.source_type == "derived"

    def test_missing_name_error(self) -> None:
        """Should raise error when required field is missing."""
        with pytest.raises(PydanticValidationError):
            load_data_entry(INVALID_DIR / "missing_name.yaml")

    def test_bad_syntax_error(self) -> None:
        """Should raise error for invalid YAML syntax."""
        with pytest.raises(YAMLLoadError):
            load_data_entry(INVALID_DIR / "bad_syntax.yaml")

    def test_file_not_found(self) -> None:
        """Should raise FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            load_data_entry(Path("/nonexistent/file.yaml"))

    def test_entry_has_source_path_after_loading(self) -> None:
        """Entry should have _source_path set to the source .axm file."""
        entry = load_data_entry(VALID_DIR / "users.axm")

        assert entry._source_path is not None
        assert entry._source_path == (VALID_DIR / "users.axm").resolve()


class TestDataCatalog:
    """Tests for DataCatalog class."""

    def test_from_directory(self) -> None:
        """Should load all .axm files from directory."""
        catalog = DataCatalog.from_directory(VALID_DIR)

        assert len(catalog) == 4
        assert "users" in catalog
        assert "camera_images" in catalog
        assert "minimal" in catalog

    def test_getitem(self) -> None:
        """Should get entry by name."""
        catalog = DataCatalog.from_directory(VALID_DIR)

        entry = catalog["users"]
        assert entry.name == "users"

        assert isinstance(entry, TabularEntry)

    def test_getitem_not_found(self) -> None:
        """Should raise KeyError for unknown entry."""
        catalog = DataCatalog.from_directory(VALID_DIR)

        with pytest.raises(KeyError):
            _ = catalog["nonexistent"]

    def test_iteration(self) -> None:
        """Should iterate over all entries."""
        catalog = DataCatalog.from_directory(VALID_DIR)

        names = [e.name for e in catalog]
        assert "users" in names
        assert "camera_images" in names
        assert "minimal" in names

    def test_load_unknown_format_fallback(self) -> None:
        """Should fall back to generic DataEntry for unknown format."""
        entry = load_data_entry(VALID_DIR / "unknown_format.axm")

        # Should be loaded as generic DataEntry
        assert isinstance(entry, DataEntry)
        assert not isinstance(entry, ImageEntry)
        assert not isinstance(entry, TabularEntry)

        # Check that generic fields are preserved
        assert entry.name == "weird_data"
        assert entry.data_schema.format == "alien_technology"
        assert entry.data_schema.spec["warp_factor"] == 9
