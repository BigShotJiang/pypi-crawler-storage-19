"""Catalog test fixtures."""
