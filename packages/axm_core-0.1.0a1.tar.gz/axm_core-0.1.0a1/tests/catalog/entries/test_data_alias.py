"""Tests for DataEntry model aliases."""

from axm.catalog.entries import (
    DataEntry,
    Identity,
    Location,
    Owner,
    Schema,
    SchemaFormat,
)


def test_data_entry_alias_schema() -> None:
    """DataEntry should accept 'schema' as alias for 'data_schema'."""
    entry = DataEntry.model_validate(
        {
            "name": "alias_test",
            "version": "1.0.0",
            "identity": {
                "display_name": "Alias Test",
                "description": "Testing alias",
                "domain": "test",
                "owner": {"team": "test", "contact": "test@test.com"},
            },
            "schema": {"format": "tabular", "spec": {}},
            "location": {"storage": "filesystem", "path_template": "/data"},
        }
    )
    assert entry.data_schema.format == SchemaFormat.TABULAR


def test_axm_version_default() -> None:
    """DataEntry should use DEFAULT_SCHEMA_VERSION by default."""
    from axm.constants import DEFAULT_SCHEMA_VERSION

    entry = DataEntry(
        name="defaults",
        version="1.0.0",
        identity=Identity(
            display_name="Defaults",
            description="Testing defaults",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        data_schema=Schema(format=SchemaFormat.TABULAR, spec={}),
        location=Location(storage="filesystem", path_template="/data"),
    )
    assert entry.axm == DEFAULT_SCHEMA_VERSION
