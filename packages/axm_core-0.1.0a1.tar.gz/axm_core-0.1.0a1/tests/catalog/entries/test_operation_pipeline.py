"""Tests for OperationEntry and PipelineEntry models."""

from axm.catalog.entries import (
    OperationEntry,
    OperationType,
    PipelineEntry,
)


def test_operation_entry_with_python_file():
    """Test creating an OperationEntry with python_file type."""
    op = OperationEntry(
        name="clean_data",
        version="1.0.0",
        identity={
            "display_name": "Clean Data",
            "description": "Removes nulls",
            "domain": "etl",
            "owner": {"team": "data-eng", "contact": "de@example.com"},
        },
        spec={
            "type": "python_file",
            "source": "scripts/clean.py",
            "entrypoint": "main",
        },
        inputs=[{"name": "raw", "data_ref": "raw_users", "version": "*"}],
        outputs=[{"name": "clean", "data_ref": "clean_users", "version": "1.0"}],
    )
    assert op.name == "clean_data"
    assert op.spec.type == OperationType.PYTHON_FILE
    assert len(op.inputs) == 1
    assert op.inputs[0].data_ref == "raw_users"


def test_operation_entry_with_python_package():
    """Test creating an OperationEntry with python_package type."""
    op = OperationEntry(
        name="transform_data",
        version="2.0.0",
        identity={
            "display_name": "Transform Data",
            "description": "Transforms data using installed package",
            "domain": "etl",
            "owner": {"team": "data-eng", "contact": "de@example.com"},
        },
        spec={
            "type": "python_package",
            "package": "mycompany-etl",
            "package_version": ">=1.0,<2.0",
            "entrypoint": "mycompany_etl.ops:transform",
        },
        execution={
            "timeout_seconds": 7200,
            "retries": 3,
            "resources": {"cpu": "4", "memory": "8Gi"},
        },
    )
    assert op.spec.type == OperationType.PYTHON_PACKAGE
    assert op.spec.package == "mycompany-etl"
    assert op.execution is not None
    assert op.execution.timeout_seconds == 7200


def test_pipeline_entry_with_schedule():
    """Test creating a PipelineEntry with schedule."""
    pipeline = PipelineEntry(
        name="daily_etl",
        version="1.0.0",
        identity={
            "display_name": "Daily ETL",
            "description": "Daily ETL pipeline",
            "domain": "data_eng",
            "owner": {"team": "data", "contact": "de@example.com"},
        },
        schedule={
            "cron": "0 2 * * *",
            "timezone": "Europe/Paris",
            "data_offset_days": -1,
        },
        timing={
            "expected_duration_minutes": 30,
            "sla_deadline_minutes": 60,
            "alert_on_sla_breach": True,
        },
        inputs=[{"name": "raw", "data_ref": "raw_users", "version": "*"}],
        outputs=[{"name": "clean", "data_ref": "clean_users", "version": "1.0"}],
        dag={
            "steps": [
                {"id": "step1", "operation": "clean_data", "dependencies": []},
            ]
        },
        execution={"max_parallel_steps": 2, "fail_fast": True},
    )
    assert pipeline.name == "daily_etl"
    assert pipeline.schedule is not None
    assert pipeline.schedule.cron == "0 2 * * *"
    assert pipeline.schedule.data_offset_days == -1
    assert pipeline.timing is not None
    assert pipeline.timing.sla_deadline_minutes == 60


def test_pipeline_entry_without_schedule():
    """Test creating a PipelineEntry without schedule (externally triggered)."""
    pipeline = PipelineEntry(
        name="adhoc_pipeline",
        version="1.0.0",
        identity={
            "display_name": "Adhoc Pipeline",
            "description": "Triggered externally",
            "domain": "data_eng",
            "owner": {"team": "data", "contact": "de@example.com"},
        },
        dag={"steps": [{"id": "step1", "operation": "clean_data"}]},
    )
    assert pipeline.schedule is None
    assert pipeline.timing is None
    assert pipeline.execution is None
