"""Tests for Identity and Owner models."""

from axm.catalog.entries import Identity, Owner


class TestIdentityExtendedFields:
    """Tests for data_type and category fields in Identity."""

    def test_identity_with_data_type(self) -> None:
        """Identity accepts data_type field."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="Bretigny Camera",
            description="Raw visible images",
            domain="images",
            owner=owner,
            data_type="visible",  # NEW FIELD
        )
        assert identity.data_type == "visible"

    def test_identity_with_category(self) -> None:
        """Identity accepts category field."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="Bretigny Camera",
            description="Raw visible images",
            domain="images",
            owner=owner,
            category="raw",  # NEW FIELD
        )
        assert identity.category == "raw"

    def test_identity_data_type_optional(self) -> None:
        """data_type defaults to None when not specified."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="X",
            description="Y",
            domain="z",
            owner=owner,
        )
        assert identity.data_type is None

    def test_identity_category_optional(self) -> None:
        """category defaults to None when not specified."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="X",
            description="Y",
            domain="z",
            owner=owner,
        )
        assert identity.category is None
