from axm.catalog.entries import (
    DataEntry,
    Identity,
    Location,
    OperationEntry,
    Owner,
    PipelineEntry,
    Schema,
)
from axm.catalog.entries.operation import OperationSpec, OperationType
from axm.catalog.entries.pipeline import DAG
from axm.core import ValidationResult


def test_data_entry_validate(tmp_path):
    entry = DataEntry(
        name="test_data",
        version="1.0.0",
        identity=Identity(
            display_name="Test",
            description="Test Description",
            domain="core",
            owner=Owner(team="data", contact="test@example.com"),
        ),
        data_schema=Schema(format="json", spec={}),
        location=Location(storage="fs", path_template=str(tmp_path / "test")),
    )
    # failure expected here initially
    result = entry.validate_entry()
    assert isinstance(result, ValidationResult)
    assert result.is_valid


def test_operation_entry_validate():
    entry = OperationEntry(
        name="test_op",
        version="1.0.0",
        identity=Identity(
            display_name="Test Op",
            description="Test Description",
            domain="core",
            owner=Owner(team="data", contact="test@example.com"),
        ),
        spec=OperationSpec(type=OperationType.BASH, entrypoint="echo hello"),
    )
    result = entry.validate_entry()
    assert isinstance(result, ValidationResult)
    assert result.is_valid


def test_pipeline_entry_validate():
    entry = PipelineEntry(
        name="test_pipe",
        version="1.0.0",
        identity=Identity(
            display_name="Test Pipe",
            description="Test Pipe",
            domain="core",
            owner=Owner(team="data", contact="test@example.com"),
        ),
        dag=DAG(steps=[]),
    )
    result = entry.validate_entry()
    assert isinstance(result, ValidationResult)
    assert result.is_valid
