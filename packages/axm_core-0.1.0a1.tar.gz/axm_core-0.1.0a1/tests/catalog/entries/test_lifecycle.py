"""Tests for DataEntry and Lifecycle models."""

import pytest
from pydantic import ValidationError

from axm.catalog.entries import FrequencyUnit, Temporal


class TestFrequencyUnitEnum:
    """Tests for strict FrequencyUnit enumeration."""

    def test_frequency_unit_seconds(self) -> None:
        """FrequencyUnit accepts 'seconds'."""
        temporal = Temporal(frequency=30, frequency_unit=FrequencyUnit.SECONDS)
        assert temporal.frequency_unit == FrequencyUnit.SECONDS

    def test_frequency_unit_minutes(self) -> None:
        """FrequencyUnit accepts 'minutes'."""
        temporal = Temporal(frequency=5, frequency_unit=FrequencyUnit.MINUTES)
        assert temporal.frequency_unit == FrequencyUnit.MINUTES

    def test_frequency_unit_hours(self) -> None:
        """FrequencyUnit accepts 'hours'."""
        temporal = Temporal(frequency=1, frequency_unit=FrequencyUnit.HOURS)
        assert temporal.frequency_unit == FrequencyUnit.HOURS

    def test_frequency_unit_days(self) -> None:
        """FrequencyUnit accepts 'days'."""
        temporal = Temporal(frequency=1, frequency_unit=FrequencyUnit.DAYS)
        assert temporal.frequency_unit == FrequencyUnit.DAYS

    def test_frequency_unit_rejects_invalid(self) -> None:
        """FrequencyUnit rejects invalid values."""
        with pytest.raises(ValidationError):
            Temporal(frequency=30, frequency_unit="milliseconds")  # Invalid
