"""Tests for DataEntry models — RED phase."""

from axm.catalog.entries import (
    AccessControl,
    AssetOperation,
    DataEntry,
    Governance,
    Identity,
    Location,
    Owner,
    Provenance,
    Retention,
    Schema,
    SchemaFormat,
    Sensitivity,
    StreamOperation,
    Temporal,
)


class TestOwner:
    """Tests for Owner model."""

    def test_required_fields(self) -> None:
        """Owner requires team and contact."""
        owner = Owner(team="data-team", contact="data@example.com")
        assert owner.team == "data-team"
        assert owner.contact == "data@example.com"

    def test_optional_steward(self) -> None:
        """Steward is optional."""
        owner = Owner(team="data-team", contact="x@y.com", steward="John Doe")
        assert owner.steward == "John Doe"


class TestIdentity:
    """Tests for Identity model."""

    def test_required_fields(self) -> None:
        """Identity requires display_name, description, domain, owner."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="Users Table",
            description="All users",
            domain="core",
            owner=owner,
        )
        assert identity.display_name == "Users Table"
        assert identity.domain == "core"

    def test_optional_tags(self) -> None:
        """Tags are optional and default to empty list."""
        owner = Owner(team="team", contact="a@b.com")
        identity = Identity(
            display_name="X",
            description="Y",
            domain="z",
            owner=owner,
        )
        assert identity.tags == []


class TestSchema:
    """Tests for Schema model."""

    def test_tabular_format(self) -> None:
        """Schema can be tabular format."""
        schema = Schema(format=SchemaFormat.TABULAR, spec={"columns": []})
        assert schema.format == SchemaFormat.TABULAR

    def test_image_format(self) -> None:
        """Schema can be image format."""
        schema = Schema(
            format=SchemaFormat.IMAGE,
            spec={"dimensions": [1024, 1024], "channels": 3},
        )
        assert schema.format == SchemaFormat.IMAGE
        assert schema.spec["dimensions"] == [1024, 1024]


class TestLocation:
    """Tests for Location model."""

    def test_filesystem_location(self) -> None:
        """Location can be filesystem."""
        loc = Location(
            storage="filesystem",
            path_template="{base}/{date}/file.csv",
        )
        assert loc.storage == "filesystem"
        assert "{date}" in loc.path_template


class TestDataEntry:
    """Tests for DataEntry model."""

    def test_minimal_entry(self) -> None:
        """DataEntry with only required fields."""
        entry = DataEntry(
            name="users",
            version="1.0.0",
            identity=Identity(
                display_name="Users",
                description="User data",
                domain="core",
                owner=Owner(team="team", contact="a@b.com"),
            ),
            data_schema=Schema(format=SchemaFormat.TABULAR, spec={}),
            location=Location(storage="filesystem", path_template="/data/users"),
        )
        assert entry.name == "users"
        assert entry.version == "1.0.0"
        assert entry.kind == "data"
        assert entry.axm == "1.0"

    def test_full_entry(self) -> None:
        """DataEntry with all optional fields."""
        entry = DataEntry(
            name="images",
            version="2.0.0",
            identity=Identity(
                display_name="Images",
                description="Image data",
                domain="media",
                owner=Owner(team="media", contact="m@m.com"),
                subdomain="photos",
                tags=["images", "photos"],
            ),
            data_schema=Schema(
                format=SchemaFormat.IMAGE, spec={"dimensions": [512, 512]}
            ),
            location=Location(storage="s3", path_template="s3://bucket/images"),
            provenance=Provenance(
                source_type="derived",
                created_by_pipeline="resize-pipeline",
                created_by_version="1.0.0",
            ),
            operation=StreamOperation(
                temporal=Temporal(frequency=60, frequency_unit="seconds"),
                retention=Retention(policy="permanent"),
            ),
            governance=Governance(
                sensitivity=Sensitivity(level="internal", pii=False),
                access=AccessControl(read=["team-a"], write=["admin"]),
            ),
        )
        assert entry.provenance is not None
        assert entry.provenance.source_type == "derived"
        assert entry.operation is not None
        assert entry.governance is not None

    def test_asset_operation(self) -> None:
        """AssetOperation can be used with type='asset'."""
        entry = DataEntry(
            name="static_assets",
            version="1.0.0",
            identity=Identity(
                display_name="Static Assets",
                description="Reference data",
                domain="core",
                owner=Owner(team="data", contact="d@d.com"),
            ),
            data_schema=Schema(format=SchemaFormat.BINARY, spec={}),
            location=Location(storage="s3", path_template="s3://b/a"),
            operation=AssetOperation(
                attributes={"camera_model": "Sony"},
                manifest={"file1": "path/to/1"},
            ),
        )
        assert entry.operation is not None
        assert entry.operation.type == "asset"
        assert isinstance(entry.operation, AssetOperation)
        assert entry.operation.attributes["camera_model"] == "Sony"
