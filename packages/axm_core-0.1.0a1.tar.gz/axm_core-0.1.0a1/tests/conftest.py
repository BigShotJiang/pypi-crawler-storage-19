"""Pytest configuration and shared fixtures."""

import pytest


@pytest.fixture
def sample_fixture() -> str:
    """Example fixture for demonstration."""
    return "axm"
