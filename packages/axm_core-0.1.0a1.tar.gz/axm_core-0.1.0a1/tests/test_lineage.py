"""Tests for lineage compatibility validation."""

from axm.catalog.entries import DataBinding
from axm.catalog.validation.lineage import (
    check_schema_compatibility,
)


class TestSchemaCompatibility:
    """Tests for schema compatibility checking between producer and consumer."""

    def test_compatible_types_pass(self) -> None:
        """Test that matching types pass compatibility check."""
        producer_schema = {
            "format": "tabular",
            "columns": [{"name": "user_id", "type": "integer", "nullable": False}],
        }
        consumer_binding = DataBinding(name="user_id", data_ref="users")

        errors = check_schema_compatibility(
            producer_schema, consumer_binding, "integer"
        )

        assert len(errors) == 0

    def test_type_mismatch_fails(self) -> None:
        """Test that mismatched types return error."""
        producer_schema = {
            "format": "tabular",
            "columns": [{"name": "user_id", "type": "integer", "nullable": False}],
        }
        consumer_binding = DataBinding(name="user_id", data_ref="users")

        errors = check_schema_compatibility(producer_schema, consumer_binding, "string")

        assert len(errors) == 1
        assert "type mismatch" in errors[0].message.lower()
        assert "integer" in errors[0].message
        assert "string" in errors[0].message

    def test_nullable_producer_to_nonnullable_consumer_fails(self) -> None:
        """Test that nullable producer to non-nullable consumer fails."""
        producer_schema = {
            "format": "tabular",
            "columns": [{"name": "email", "type": "string", "nullable": True}],
        }
        consumer_binding = DataBinding(name="email", data_ref="emails", required=True)

        errors = check_schema_compatibility(
            producer_schema, consumer_binding, "string", consumer_nullable=False
        )

        assert len(errors) == 1
        assert "nullable" in errors[0].message.lower()

    def test_missing_column_in_producer_fails(self) -> None:
        """Test that missing column in producer fails."""
        producer_schema = {
            "format": "tabular",
            "columns": [{"name": "id", "type": "integer", "nullable": False}],
        }
        consumer_binding = DataBinding(name="email", data_ref="emails")

        errors = check_schema_compatibility(producer_schema, consumer_binding, "string")

        assert len(errors) == 1
        assert "not found" in errors[0].message.lower()
