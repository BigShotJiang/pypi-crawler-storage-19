"""Tests for Operation Protocol and Registry — TDD RED phase."""

import pytest

from axm.operations import OperationProtocol, OperationRegistry, OperationResult


class TestOperationProtocol:
    """Tests for the OperationProtocol abstract base class."""

    def test_protocol_requires_name(self) -> None:
        """OperationProtocol requires a name property."""

        # Concrete implementation
        class TestOp(OperationProtocol):
            @property
            def name(self) -> str:
                return "test.operation"

            def execute(self, data, context, config):
                return OperationResult(data=data, success=True)

        op = TestOp()
        assert op.name == "test.operation"

    def test_protocol_requires_execute(self) -> None:
        """OperationProtocol requires an execute method."""

        class TestOp(OperationProtocol):
            @property
            def name(self) -> str:
                return "test.op"

            def execute(self, data, context, config):
                return OperationResult(data="processed", success=True)

        op = TestOp()
        result = op.execute("input", {}, {})
        assert result.success is True
        assert result.data == "processed"


class TestOperationResult:
    """Tests for OperationResult dataclass."""

    def test_successful_result(self) -> None:
        """Can create a successful result."""
        result = OperationResult(data={"key": "value"}, success=True)
        assert result.success is True
        assert result.data == {"key": "value"}
        assert result.error is None

    def test_failed_result(self) -> None:
        """Can create a failed result with error."""
        result = OperationResult(data=None, success=False, error="File not found")
        assert result.success is False
        assert result.error == "File not found"

    def test_result_with_metadata(self) -> None:
        """Can include metadata in result."""
        result = OperationResult(
            data=[1, 2, 3],
            success=True,
            metadata={"count": 3},
        )
        assert result.metadata == {"count": 3}


class TestOperationRegistry:
    """Tests for OperationRegistry singleton."""

    def setup_method(self) -> None:
        """Reset registry before each test."""
        OperationRegistry.reset()

    def test_register_operation(self) -> None:
        """Can register an operation class."""

        class MyOp(OperationProtocol):
            @property
            def name(self) -> str:
                return "my.operation"

            def execute(self, data, context, config):
                return OperationResult(data=data, success=True)

        OperationRegistry.register("my.operation", MyOp)
        assert "my.operation" in OperationRegistry.list_all()

    def test_get_operation(self) -> None:
        """Can retrieve a registered operation."""

        class MyOp(OperationProtocol):
            @property
            def name(self) -> str:
                return "get.test"

            def execute(self, data, context, config):
                return OperationResult(data=data, success=True)

        OperationRegistry.register("get.test", MyOp)
        op = OperationRegistry.get("get.test")
        assert op.name == "get.test"

    def test_get_nonexistent_raises(self) -> None:
        """Getting nonexistent operation raises KeyError."""
        with pytest.raises(KeyError, match=r"not\.registered"):
            OperationRegistry.get("not.registered")

    def test_list_all_operations(self) -> None:
        """Can list all registered operations."""

        class OpA(OperationProtocol):
            @property
            def name(self) -> str:
                return "op.a"

            def execute(self, data, context, config):
                return OperationResult(data=data, success=True)

        class OpB(OperationProtocol):
            @property
            def name(self) -> str:
                return "op.b"

            def execute(self, data, context, config):
                return OperationResult(data=data, success=True)

        OperationRegistry.register("op.a", OpA)
        OperationRegistry.register("op.b", OpB)

        ops = OperationRegistry.list_all()
        assert "op.a" in ops
        assert "op.b" in ops
