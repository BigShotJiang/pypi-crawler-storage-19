"""Tests for the @operation decorator."""


def test_operation_decorator_marks_function() -> None:
    """Test that @operation adds _axm_meta to function."""
    from axm.discovery import operation

    @operation(inputs=["raw_data"], outputs=["clean_data"])
    def my_func(inputs: dict, parameters: dict) -> dict:
        return {}

    assert hasattr(my_func, "_axm_meta")
    assert my_func._axm_meta["kind"] == "operation"
    assert my_func._axm_meta["inputs"] == ["raw_data"]
    assert my_func._axm_meta["outputs"] == ["clean_data"]


def test_operation_decorator_preserves_function() -> None:
    """Test that decorated function still works."""
    from axm.discovery import operation

    @operation(inputs=["a"], outputs=["b"])
    def add_one(inputs: dict, parameters: dict) -> dict:
        return {"result": inputs.get("value", 0) + 1}

    result = add_one({"value": 5}, {})
    assert result == {"result": 6}


def test_operation_decorator_extracts_metadata() -> None:
    """Test that decorator extracts function name and docstring."""
    from axm.discovery import operation

    @operation(inputs=["x"], outputs=["y"])
    def process_data(inputs: dict, parameters: dict) -> dict:
        """Process the input data."""
        return {}

    assert process_data._axm_meta["entrypoint"] == "process_data"
    assert "Process the input data" in process_data._axm_meta.get("description", "")


def test_operation_decorator_with_domain() -> None:
    """Test that domain parameter is captured."""
    from axm.discovery import operation

    @operation(inputs=[], outputs=[], domain="analytics")
    def analyze(inputs: dict, parameters: dict) -> dict:
        return {}

    assert analyze._axm_meta["domain"] == "analytics"


def test_operation_decorator_default_domain() -> None:
    """Test that default domain is 'default'."""
    from axm.discovery import operation

    @operation(inputs=[], outputs=[])
    def simple(inputs: dict, parameters: dict) -> dict:
        return {}

    assert simple._axm_meta["domain"] == "default"
