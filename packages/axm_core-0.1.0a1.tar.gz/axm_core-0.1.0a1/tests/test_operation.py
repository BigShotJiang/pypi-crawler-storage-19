"""Tests for Operation models (StreamOperation and AssetOperation).

TDD RED Phase: These tests should FAIL until the Operation models are implemented.
"""


class TestStreamOperation:
    """Tests for StreamOperation model."""

    def test_stream_operation_with_temporal(self) -> None:
        """StreamOperation should accept temporal configuration."""
        from axm.catalog.entries.data import StreamOperation

        op = StreamOperation(
            type="stream",
            temporal={
                "frequency": 30,
                "frequency_unit": "seconds",
            },
        )
        assert op.type == "stream"
        assert op.temporal is not None
        assert op.temporal.frequency == 30

    def test_stream_operation_with_retention(self) -> None:
        """StreamOperation should accept retention policy."""
        from axm.catalog.entries.data import StreamOperation

        op = StreamOperation(
            type="stream",
            retention={"policy": "permanent"},
        )
        assert op.retention is not None
        assert op.retention.policy == "permanent"

    def test_stream_operation_default_type(self) -> None:
        """StreamOperation should default to type='stream'."""
        from axm.catalog.entries.data import StreamOperation

        op = StreamOperation()
        assert op.type == "stream"


class TestAssetOperation:
    """Tests for AssetOperation model."""

    def test_asset_operation_with_attributes(self) -> None:
        """AssetOperation should accept arbitrary attributes dict."""
        from axm.catalog.entries.data import AssetOperation

        op = AssetOperation(
            type="asset",
            attributes={
                "camera": {"name": "Bretigny Camera", "type": "hemispherical"},
                "position": {"longitude": 2.346, "latitude": 48.600},
            },
        )
        assert op.type == "asset"
        assert op.attributes["camera"]["name"] == "Bretigny Camera"

    def test_asset_operation_with_manifest(self) -> None:
        """AssetOperation should accept manifest dict."""
        from axm.catalog.entries.data import AssetOperation

        op = AssetOperation(
            type="asset",
            manifest={
                "azimuth": "azimuth.jp2",
                "zenith": "zenith.jp2",
            },
        )
        assert op.manifest["azimuth"] == "azimuth.jp2"

    def test_asset_operation_default_type(self) -> None:
        """AssetOperation should default to type='asset'."""
        from axm.catalog.entries.data import AssetOperation

        op = AssetOperation()
        assert op.type == "asset"

    def test_asset_operation_manifest_optional(self) -> None:
        """AssetOperation manifest should be optional."""
        from axm.catalog.entries.data import AssetOperation

        op = AssetOperation(
            type="asset",
            attributes={"key": "value"},
        )
        assert op.manifest == {}


class TestOperationDiscriminator:
    """Tests for Operation discriminated union."""

    def test_operation_discriminator_stream(self) -> None:
        """Operation union should resolve to StreamOperation when type=stream."""
        from pydantic import TypeAdapter

        from axm.catalog.entries.data import (
            AssetOperation,
            Operation,
            StreamOperation,
        )

        data = {"type": "stream", "temporal": {"frequency": 30}}
        adapter: TypeAdapter[StreamOperation | AssetOperation] = TypeAdapter(Operation)
        op = adapter.validate_python(data)
        assert isinstance(op, StreamOperation)

    def test_operation_discriminator_asset(self) -> None:
        """Operation union should resolve to AssetOperation when type=asset."""
        from pydantic import TypeAdapter

        from axm.catalog.entries.data import (
            AssetOperation,
            Operation,
            StreamOperation,
        )

        data = {"type": "asset", "attributes": {"key": "value"}}
        adapter: TypeAdapter[StreamOperation | AssetOperation] = TypeAdapter(Operation)
        op = adapter.validate_python(data)
        assert isinstance(op, AssetOperation)
