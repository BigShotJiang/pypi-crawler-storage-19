# AXM Core

Core data contracts, validation, and catalog primitives for AXM.

## Installation

```bash
pip install axm-core
```

## Features

- **Data Contracts** — Define schemas, ownership, and compliance in YAML
- **Validation** — Zero-trust validation with Pydantic v2
- **Catalog** — Organize and discover data assets

## Documentation

Full documentation: https://JarryGabriel.github.io/axm-protocols/
