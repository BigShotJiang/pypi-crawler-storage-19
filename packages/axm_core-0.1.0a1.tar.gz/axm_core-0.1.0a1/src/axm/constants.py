"""Global constants for AXM."""

DEFAULT_SCHEMA_VERSION = "1.0"
