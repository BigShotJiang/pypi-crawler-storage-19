"""Base protocol and types for AXM operations."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class OperationResult:
    """Result of an operation execution.

    Attributes:
        data: The output data from the operation.
        success: Whether the operation succeeded.
        error: Error message if failed.
        metadata: Additional metadata about the execution.
    """

    data: Any
    success: bool
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class OperationProtocol(ABC):
    """Abstract base class for all operations.

    Operations are the atomic units of work in AXM pipelines.
    They receive data, transform it, and return results.

    Example:
        >>> class MyOperation(OperationProtocol):
        ...     @property
        ...     def name(self) -> str:
        ...         return "my.operation"
        ...
        ...     def execute(self, data, context, config):
        ...         return OperationResult(data=data.upper(), success=True)
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique identifier for this operation.

        Returns:
            String name like 'image.load' or 'tabular.filter'.
        """
        ...

    @abstractmethod
    def execute(
        self,
        data: Any,
        context: dict[str, Any],
        config: dict[str, Any],
    ) -> OperationResult:
        """Execute the operation.

        Args:
            data: Input data to process.
            context: Contextual information (paths, dates, etc.).
            config: Operation-specific configuration.

        Returns:
            OperationResult with processed data and status.
        """
        ...
