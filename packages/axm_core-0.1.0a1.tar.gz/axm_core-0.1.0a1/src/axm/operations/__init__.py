"""AXM Operations Framework.

Provides the base protocol and registry for pluggable operations.
"""

from axm.operations.base import OperationProtocol, OperationResult
from axm.operations.registry import OperationRegistry

__all__ = [
    "OperationProtocol",
    "OperationRegistry",
    "OperationResult",
]
