"""Operation Registry for plugin discovery and management."""

from typing import ClassVar

from axm.operations.base import OperationProtocol


class OperationRegistry:
    """Singleton registry for operation implementations.

    Operations can be registered manually or discovered automatically
    via Python entry points.

    Example:
        >>> from axm.operations import OperationRegistry
        >>> OperationRegistry.register("my.op", MyOperation)
        >>> op = OperationRegistry.get("my.op")
    """

    _operations: ClassVar[dict[str, type[OperationProtocol]]] = {}
    _loaded: ClassVar[bool] = False

    @classmethod
    def register(cls, name: str, op_class: type[OperationProtocol]) -> None:
        """Register an operation class.

        Args:
            name: Unique operation name (e.g., 'image.load').
            op_class: The operation class to register.
        """
        cls._operations[name] = op_class

    @classmethod
    def get(cls, name: str) -> OperationProtocol:
        """Get an operation instance by name.

        Args:
            name: The operation name to retrieve.

        Returns:
            An instance of the registered operation.

        Raises:
            KeyError: If operation is not registered.
        """
        cls._load_plugins()
        if name not in cls._operations:
            available = list(cls._operations.keys())
            raise KeyError(f"Operation '{name}' not found. Available: {available}")
        return cls._operations[name]()

    @classmethod
    def list_all(cls) -> list[str]:
        """List all registered operation names.

        Returns:
            List of operation names.
        """
        cls._load_plugins()
        return list(cls._operations.keys())

    @classmethod
    def reset(cls) -> None:
        """Reset the registry (useful for testing)."""
        cls._operations = {}
        cls._loaded = False

    @classmethod
    def _load_plugins(cls) -> None:
        """Load operations from entry points.

        This is called automatically on first access.
        Plugins register via 'axm.operations' entry point group.
        """
        if cls._loaded:
            return

        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="axm.operations")
            for ep in eps:
                try:
                    module = ep.load()
                    if hasattr(module, "register_operations"):
                        module.register_operations(cls)
                except Exception:  # noqa: S110
                    # Silently skip failed plugins
                    pass
        except Exception:  # noqa: S110
            # Entry points not available
            pass

        cls._loaded = True
