"""Registry for catalog entry types.

Allows plugins to register specialized DataEntry subclasses.
"""

from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from axm.catalog.entries.base import Entry


class EntryTypeRegistry:
    """Registry for mapping kinds and formats to Entry classes.

    Example:
        >>> EntryTypeRegistry.register("data", "tabular", TabularEntry)
        >>> cls = EntryTypeRegistry.get("data", "tabular")
    """

    # Map (kind, schema_format) -> EntryClass
    _registry: ClassVar[dict[tuple[str, str | None], type["Entry"]]] = {}
    _loaded: ClassVar[bool] = False

    @classmethod
    def register(cls, kind: str, fmt: str | None, entry_cls: type["Entry"]) -> None:
        """Register a new entry type.

        Args:
            kind: Entry kind (e.g., "data", "operation", "pipeline").
            fmt: Schema format (e.g., "tabular", "image") or None for generic.
            entry_cls: The class to use for instantiation.
        """
        cls._registry[(kind, fmt)] = entry_cls

    @classmethod
    def get(cls, kind: str, fmt: str | None = None) -> type["Entry"]:
        """Get the registered class for a kind/format.

        Args:
            kind: Entry kind.
            fmt: Schema format.

        Returns:
            Registered class or generic DataEntry if not found (for data kind).
        """
        cls._load_plugins()

        # Try exact match
        if (kind, fmt) in cls._registry:
            return cls._registry[(kind, fmt)]

        # Fallback for data: if specific format not found, return generic data entry
        # But generic entry must be registered under (data, None)
        if kind == "data" and (kind, None) in cls._registry:
            return cls._registry[(kind, None)]

        raise KeyError(f"No entry type registered for kind='{kind}', format='{fmt}'")

    @classmethod
    def _load_plugins(cls) -> None:
        """Load entry plugins via entry points."""
        if cls._loaded:
            return

        try:
            from importlib.metadata import entry_points

            eps = entry_points(group="axm.entries")
            for ep in eps:
                try:
                    module = ep.load()
                    if hasattr(module, "register_entries"):
                        module.register_entries(cls)
                except Exception:  # noqa: S110
                    pass
        except Exception:  # noqa: S110
            pass

        cls._loaded = True
