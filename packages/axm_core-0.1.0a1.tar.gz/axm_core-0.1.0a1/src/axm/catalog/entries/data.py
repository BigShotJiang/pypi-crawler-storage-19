"""DataEntry models for AXM Data Catalog.

This module defines the core data structures for representing datasets
in the AXM catalog system. Each DataEntry describes a dataset's schema,
location, governance, and quality rules.

Example:
    >>> from axm.catalog.models import DataEntry, Identity, Schema, Location
    >>> entry = DataEntry(
    ...     name="users",
    ...     version="1.0.0",
    ...     identity=Identity(...),
    ...     data_schema=Schema(format=SchemaFormat.TABULAR, spec={...}),
    ...     location=Location(storage="filesystem", path_template="/data/u.parquet"),
    ... )
"""

from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field

from axm.catalog.entries.base import Entry, Identity
from axm.core import ValidationResult


class SchemaFormat(str, Enum):
    """Supported data schema formats.

    Attributes:
        TABULAR: Structured columnar data (CSV, Parquet, etc.).
        IMAGE: Image files (PNG, JPEG, etc.).
        AUDIO: Audio files (WAV, MP3, etc.).
        JSON: Semi-structured JSON documents.
        BINARY: Raw binary blobs.
    """

    TABULAR = "tabular"
    IMAGE = "image"
    AUDIO = "audio"
    JSON = "json"
    BINARY = "binary"


# ═══════════════════════════════════════════════════════════
# SCHEMA — Data structure
# ═══════════════════════════════════════════════════════════


class Schema(BaseModel):
    """Schema definition for data entry.

    Attributes:
        format: The data format (tabular, image, json, etc.).
        spec: Format-specific schema specification. For tabular, contains
            a "columns" list with name, type, nullable, and rules.
        evolution_policy: How schema changes are handled (e.g., "strict", "additive").
    """

    format: str
    spec: Any = Field(default_factory=dict)
    evolution_policy: str | None = None


# ═══════════════════════════════════════════════════════════
# LOCATION — Where is the data?
# ═══════════════════════════════════════════════════════════


class Location(BaseModel):
    """Data storage location.

    Attributes:
        storage: Storage backend type (filesystem, s3, gcs, database).
        path_template: Path pattern with optional variables like {date}, {partition}.
        variables: Default values for path template variables.
    """

    storage: str
    path_template: str
    variables: dict[str, str] = Field(default_factory=dict)


# ═══════════════════════════════════════════════════════════
# PROVENANCE — Where does it come from?
# ═══════════════════════════════════════════════════════════


class SourceInput(BaseModel):
    """Reference to a source dataset.

    Attributes:
        name: Name of the source DataEntry.
        version: Version constraint (e.g., "1.0.0", "*", ">=1.0").
    """

    name: str
    version: str = "*"


class Provenance(BaseModel):
    """Data provenance and lineage.

    Attributes:
        source_type: Origin classification (raw, derived, external, aggregated).
        created_by_pipeline: Name of the pipeline that produces this data.
        created_by_version: Version of the producing pipeline.
        inputs: List of source datasets this data depends on.
    """

    source_type: str
    created_by_pipeline: str | None = None
    created_by_version: str | None = None
    inputs: list[SourceInput] = Field(default_factory=list)


# ═══════════════════════════════════════════════════════════
# LIFECYCLE — Temporal & Retention
# ═══════════════════════════════════════════════════════════


class FrequencyUnit(str, Enum):
    """Valid frequency units for temporal configuration.

    Attributes:
        SECONDS: Frequency in seconds.
        MINUTES: Frequency in minutes.
        HOURS: Frequency in hours.
        DAYS: Frequency in days.
    """

    SECONDS = "seconds"
    MINUTES = "minutes"
    HOURS = "hours"
    DAYS = "days"


class Temporal(BaseModel):
    """Temporal characteristics of data.

    Attributes:
        frequency: How often the data is produced.
        frequency_unit: Unit for frequency (seconds, minutes, hours, days).
        window_start: Start time constraint (e.g., "08:00").
        window_end: End time constraint (e.g., "18:00").
        timezone: Timezone for temporal calculations (default: UTC).
    """

    frequency: int
    frequency_unit: FrequencyUnit = FrequencyUnit.SECONDS
    window_start: str | None = None
    window_end: str | None = None
    timezone: str = "UTC"


class Retention(BaseModel):
    """Data retention policy.

    Attributes:
        policy: Retention rule (permanent, days:N, archive:N).
    """

    policy: str


class Availability(BaseModel):
    """Data availability window.

    Attributes:
        start_date: When data becomes available (ISO format).
        end_date: When data expires or is deprecated.
    """

    start_date: str | None = None
    end_date: str | None = None


# ═══════════════════════════════════════════════════════════
# OPERATION — Operational Profile (Stream vs Asset)
# ═══════════════════════════════════════════════════════════


class StreamOperation(BaseModel):
    """Operational profile for streaming/regular data.

    This represents data that is produced on a schedule with lifecycle rules.

    Attributes:
        type: Discriminator field, always "stream".
        temporal: Timing and frequency configuration.
        retention: Data retention policy.
        availability: Availability window.
    """

    type: Literal["stream"] = "stream"
    temporal: Temporal | None = None
    retention: Retention | None = None
    availability: Availability | None = None


class AssetOperation(BaseModel):
    """Operational profile for static/reference assets.

    This represents reference data with metadata and a file manifest.

    Attributes:
        type: Discriminator field, always "asset".
        attributes: Arbitrary metadata dictionary (e.g., camera info, position).
        manifest: Mapping of logical names to file names.
    """

    type: Literal["asset"] = "asset"
    attributes: dict[str, Any] = Field(default_factory=dict)
    manifest: dict[str, str] = Field(default_factory=dict)


# Discriminated union for polymorphic operation field
Operation = Annotated[
    StreamOperation | AssetOperation,
    Field(discriminator="type"),
]


# ═══════════════════════════════════════════════════════════
# GOVERNANCE — Access & Compliance
# ═══════════════════════════════════════════════════════════


class Sensitivity(BaseModel):
    """Data sensitivity classification.

    Attributes:
        level: Classification level (public, internal, confidential, restricted).
        pii: Whether data contains Personally Identifiable Information.
        encrypted: Whether data is encrypted at rest.
    """

    level: str = "internal"
    pii: bool = False
    encrypted: bool = False


class AccessControl(BaseModel):
    """Access control rules.

    Attributes:
        read: List of groups/roles with read access.
        write: List of groups/roles with write access.
    """

    read: list[str] = Field(default_factory=list)
    write: list[str] = Field(default_factory=list)


class Compliance(BaseModel):
    """Compliance information.

    Attributes:
        frameworks: Applicable compliance frameworks (GDPR, HIPAA, SOC2).
        last_audit: Date of last compliance audit (ISO format).
    """

    frameworks: list[str] = Field(default_factory=list)
    last_audit: str | None = None


class Governance(BaseModel):
    """Governance section of a data entry.

    Attributes:
        sensitivity: Data sensitivity classification.
        access: Access control rules.
        compliance: Compliance framework information.
    """

    sensitivity: Sensitivity = Field(default_factory=Sensitivity)
    access: AccessControl = Field(default_factory=AccessControl)
    compliance: Compliance | None = None


# ═══════════════════════════════════════════════════════════
# QUALITY — Validation & Metrics
# ═══════════════════════════════════════════════════════════


class QualityRule(BaseModel):
    """A quality validation rule.

    Attributes:
        type: Rule type (e.g., "completeness", "uniqueness").
        threshold: Threshold value as string (e.g., ">0.95", "100%").
    """

    type: str
    threshold: str


class Quality(BaseModel):
    """Quality section of a data entry.

    Attributes:
        rules: List of quality rules to enforce.
        expected_daily_files: Expected number of files per day.
        expected_file_size_mb: Expected file size in megabytes.
    """

    rules: list[QualityRule] = Field(default_factory=list)
    expected_daily_files: int | None = None
    expected_file_size_mb: float | None = None


# ═══════════════════════════════════════════════════════════
# DATA ENTRY — Main model
# ═══════════════════════════════════════════════════════════


class DataEntry(Entry):
    """A complete data catalog entry.

    This is the primary model representing a dataset in AXM. It combines
    identity, schema, location, and optional governance/quality metadata.

    Attributes:
        axm: Schema version (e.g., "1.0").
        kind: Entry type, always "data" for DataEntry.
        name: Unique identifier for this dataset.
        version: Semantic version of the dataset definition.
        identity: Ownership and classification metadata.
        data_schema: Schema definition (aliased from "schema" in YAML).
        location: Storage location configuration.
        provenance: Optional lineage information.
        operation: Operational profile (stream or asset).
        lifecycle: Deprecated. Use operation with type="stream" instead.
        governance: Optional access control and compliance.
        quality: Optional quality rules and expectations.

    Example:
        >>> entry = DataEntry(
        ...     name="users",
        ...     version="1.0.0",
        ...     identity=Identity(
        ...         display_name="Users",
        ...         description="User accounts",
        ...         domain="core",
        ...         owner=Owner(team="platform", contact="team@ex.com"),
        ...     ),
        ...     data_schema=Schema(format=SchemaFormat.TABULAR, spec={}),
        ...     location=Location(storage="fs", path_template="/data/u.parquet"),
        ... )
    """

    # Core (required)
    kind: str = "data"

    # Required sections
    identity: Identity
    data_schema: Schema = Field(alias="schema")
    location: Location

    # Optional sections
    provenance: Provenance | None = None
    operation: Operation | None = None

    governance: Governance | None = None
    quality: Quality | None = None

    def validate_entry(self) -> ValidationResult:
        """Validate the entry state (e.g. cross-field logic)."""
        # Pydantic handles structural validation.
        # Here we can add business logic checks.
        return ValidationResult(is_valid=True, errors=[])
