"""Base models shared across catalog entries."""

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr

from axm.constants import DEFAULT_SCHEMA_VERSION


class Entry(BaseModel):
    """Base class for all catalog entries.

    Attributes:
        axm: Schema version (e.g., "1.0").
        kind: Entry type (data, operation, pipeline).
        name: Unique identifier.
        version: Semantic version of the entry.
    """

    model_config = ConfigDict(populate_by_name=True)

    axm: str = DEFAULT_SCHEMA_VERSION
    kind: str
    name: str
    version: str

    # Internal: path to the .axm file that defined this entry
    _source_path: Path | None = PrivateAttr(default=None)


class Owner(BaseModel):
    """Data ownership information."""

    team: str
    contact: str
    steward: str | None = None


class Identity(BaseModel):
    """Identity section of a data entry."""

    display_name: str
    description: str
    domain: str
    owner: Owner
    subdomain: str | None = None
    tags: list[str] = Field(default_factory=list)
    # Classification fields
    data_type: str | None = None  # e.g., "visible", "infrared", "thermal"
    category: str | None = None  # e.g., "raw", "processed", "derived"
