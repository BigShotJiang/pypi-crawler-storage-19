"""OperationEntry models for AXM Data Catalog.

This module defines operation entries representing atomic units of work
in AXM pipelines. Operations define executable code and its data bindings.

Example:
    >>> from axm.catalog.models import OperationEntry, OperationSpec, OperationType
    >>> op = OperationEntry(
    ...     name="clean_users",
    ...     version="1.0.0",
    ...     identity=Identity(...),
    ...     spec=OperationSpec(type=OperationType.PYTHON_PACKAGE, package="myetl"),
    ... )
"""

from enum import Enum

from pydantic import BaseModel, Field

from axm.catalog.entries.base import Entry, Identity
from axm.core import ValidationResult


class OperationType(str, Enum):
    """Supported operation types.

    Attributes:
        PYTHON_FILE: A .py file with an entrypoint function.
        PYTHON_PACKAGE: An installed PyPI package.
        SQL_FILE: A SQL file executed against a database.
        BASH: A shell command.
        DOCKER: A Docker image.
    """

    PYTHON_FILE = "python_file"
    PYTHON_PACKAGE = "python_package"
    SQL_FILE = "sql_file"
    BASH = "bash"
    DOCKER = "docker"


class ResourceSpec(BaseModel):
    """Resource requests for operation execution.

    Attributes:
        cpu: CPU request (e.g., "2", "500m").
        memory: Memory request (e.g., "4Gi", "512Mi").
        gpu: GPU request (e.g., "1").
    """

    cpu: str | None = None
    memory: str | None = None
    gpu: str | None = None


class ExecutionSpec(BaseModel):
    """Execution behavior configuration.

    Attributes:
        timeout_seconds: Maximum execution time before timeout (default: 3600).
        retries: Number of retry attempts on failure (default: 0).
        retry_delay_seconds: Delay between retries (default: 60).
        resources: Optional resource requests (CPU, memory, GPU).
    """

    timeout_seconds: int = 3600
    retries: int = 0
    retry_delay_seconds: int = 60
    resources: ResourceSpec | None = None


class OperationSpec(BaseModel):
    """Implementation details of the operation.

    Attributes:
        type: The operation type (python_file, python_package, sql_file, bash, docker).
        source: Path to source file (for python_file, sql_file, bash).
        package: PyPI package name (for python_package).
        package_version: Version constraint for package (e.g., ">=1.0,<2.0").
        entrypoint: Entry point function or command.
        env: Environment variables to set during execution.
        image: Docker image reference (for docker type).
    """

    type: OperationType
    source: str | None = None
    package: str | None = None
    package_version: str | None = None
    entrypoint: str | None = None
    env: dict[str, str] = Field(default_factory=dict)
    image: str | None = None


class DataBinding(BaseModel):
    """Reference to a DataEntry for input/output.

    Attributes:
        name: Local name for this binding (used in operation code).
        data_ref: Name of the referenced DataEntry.
        version: Version constraint (e.g., "1.0.0", "*", ">=1.0").
        required: Whether this binding is required (default: True).
    """

    name: str
    data_ref: str
    version: str = "*"
    required: bool = True


class OperationEntry(Entry):
    """A catalog entry representing an atomic operation.

    Operations are the building blocks of pipelines. Each operation defines
    what code runs and how it connects to input/output data.

    Attributes:
        axm: Schema version (e.g., "1.0").
        kind: Entry type, always "operation" for OperationEntry.
        name: Unique identifier for this operation.
        version: Semantic version of the operation definition.
        identity: Ownership and classification metadata.
        spec: Implementation details (type, package, entrypoint).
        inputs: List of input data bindings.
        outputs: List of output data bindings.
        execution: Optional execution configuration (timeout, retries).

    Example:
        >>> entry = OperationEntry(
        ...     name="clean_users",
        ...     version="1.0.0",
        ...     identity=Identity(...),
        ...     spec=OperationSpec(
        ...         type=OperationType.PYTHON_PACKAGE,
        ...         package="mycompany-etl",
        ...         entrypoint="mycompany_etl.ops:clean",
        ...     ),
        ...     inputs=[DataBinding(name="raw", data_ref="raw_users")],
        ...     outputs=[DataBinding(name="clean", data_ref="clean_users")],
        ... )
    """

    kind: str = "operation"

    # Sections
    identity: Identity
    spec: OperationSpec
    inputs: list[DataBinding] = Field(default_factory=list)
    outputs: list[DataBinding] = Field(default_factory=list)
    execution: ExecutionSpec | None = None

    def validate_entry(self) -> ValidationResult:
        """Validate operation entry specific logic."""
        return ValidationResult(is_valid=True, errors=[])
