"""PipelineEntry models for AXM Data Catalog.

This module defines pipeline entries representing orchestrated workflows
in AXM. Pipelines connect operations in a DAG with optional scheduling.

Example:
    >>> from axm.catalog.models import PipelineEntry, DAG, PipelineStep
    >>> pipeline = PipelineEntry(
    ...     name="daily_etl",
    ...     version="1.0.0",
    ...     identity=Identity(...),
    ...     dag=DAG(steps=[PipelineStep(id="clean", operation="clean_users")]),
    ... )
"""

from typing import Any

from pydantic import BaseModel, Field

from axm.catalog.entries.base import Entry, Identity
from axm.catalog.entries.operation import DataBinding
from axm.core import ValidationResult


class Schedule(BaseModel):
    """Pipeline scheduling configuration (optional).

    If omitted, the pipeline is triggered externally (e.g., via API or event).

    Attributes:
        cron: Cron expression (e.g., "0 2 * * *" for 2 AM daily).
        timezone: Timezone for cron evaluation (default: UTC).
        catchup: Whether to backfill missed runs (default: False).
        data_offset_days: Temporal offset for data processing.
            Use -1 for J-1 (yesterday), -7 for weekly lag.
    """

    cron: str
    timezone: str = "UTC"
    catchup: bool = False
    data_offset_days: int = 0


class Timing(BaseModel):
    """SLA and timing expectations.

    Attributes:
        expected_duration_minutes: Typical run duration for monitoring.
        sla_deadline_minutes: Maximum allowed duration before SLA breach.
        alert_on_sla_breach: Whether to trigger alerts on SLA violation.
    """

    expected_duration_minutes: int | None = None
    sla_deadline_minutes: int | None = None
    alert_on_sla_breach: bool = False


class PipelineExecution(BaseModel):
    """Pipeline-level execution configuration.

    Attributes:
        max_parallel_steps: Maximum concurrent step executions (default: 4).
        fail_fast: Stop pipeline on first step failure (default: True).
    """

    max_parallel_steps: int = 4
    fail_fast: bool = True


class PipelineStep(BaseModel):
    """A single step in a pipeline DAG.

    Attributes:
        id: Unique identifier for this step within the pipeline.
        operation: Name of the OperationEntry to execute.
        arguments: Optional arguments to pass to the operation.
        dependencies: List of step IDs that must complete before this step.
    """

    id: str
    operation: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    dependencies: list[str] = Field(default_factory=list)


class DAG(BaseModel):
    """Directed Acyclic Graph definition.

    Attributes:
        steps: Ordered list of pipeline steps. Dependencies define the graph.
    """

    steps: list[PipelineStep]


class PipelineEntry(Entry):
    """A catalog entry representing a pipeline (workflow).

    Pipelines orchestrate multiple operations as a DAG. They can be scheduled
    via cron or triggered externally.

    Attributes:
        axm: Schema version (e.g., "1.0").
        kind: Entry type, always "pipeline" for PipelineEntry.
        name: Unique identifier for this pipeline.
        version: Semantic version of the pipeline definition.
        identity: Ownership and classification metadata.
        schedule: Optional cron schedule. If None, triggered externally.
        timing: Optional SLA and duration expectations.
        inputs: Pipeline-level input data bindings.
        outputs: Pipeline-level output data bindings.
        dag: The directed acyclic graph of steps.
        execution: Optional execution configuration.

    Example:
        >>> entry = PipelineEntry(
        ...     name="daily_etl",
        ...     version="1.0.0",
        ...     identity=Identity(...),
        ...     schedule=Schedule(cron="0 2 * * *", timezone="Europe/Paris"),
        ...     dag=DAG(steps=[
        ...         PipelineStep(id="clean", operation="clean_users"),
        ...         PipelineStep(id="agg", operation="agg", dependencies=["clean"]),
        ...     ]),
        ... )
    """

    kind: str = "pipeline"

    # Sections
    identity: Identity

    # Optional schedule (if None, triggered externally)
    schedule: Schedule | None = None

    # SLA / Timing
    timing: Timing | None = None

    # Data bindings
    inputs: list[DataBinding] = Field(default_factory=list)
    outputs: list[DataBinding] = Field(default_factory=list)

    # DAG definition
    dag: DAG

    # Execution config
    execution: PipelineExecution | None = None

    def validate_entry(self) -> ValidationResult:
        """Validate pipeline entry specific logic."""
        return ValidationResult(is_valid=True, errors=[])
