"""YAML loader for AXM catalog entries."""

from pathlib import Path

import yaml
from loguru import logger

from axm.catalog.entries.base import Entry

CatalogEntry = Entry


class YAMLLoadError(Exception):
    """Error loading or parsing YAML file."""


def load_catalog_entry(path: Path) -> CatalogEntry:
    """Load a catalog entry (Data, Operation, Pipeline) from a YAML file.

    Args:
        path: Path to the .axm file.

    Returns:
        Parsed and validated CatalogEntry.

    Raises:
        FileNotFoundError: If file doesn't exist.
        YAMLLoadError: If YAML parsing fails.
        ValidationError: If Pydantic validation fails.
    """
    if not path.exists():
        logger.error(f"File not found: {path}")
        raise FileNotFoundError(f"File not found: {path}")

    try:
        with open(path) as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        logger.error(f"Invalid YAML in {path}: {e}")
        raise YAMLLoadError(f"Invalid YAML in {path}: {e}") from e

    kind = data.get("kind", "data")

    # Determine format for data entries
    fmt = None
    if kind == "data":
        schema_data = data.get("schema", {})
        fmt = schema_data.get("format")

    # Load from registry
    from axm.catalog.entries.registry import EntryTypeRegistry

    try:
        entry_cls = EntryTypeRegistry.get(kind, fmt)
        entry = entry_cls.model_validate(data)
        entry._source_path = path.resolve()
        return entry
    except KeyError:
        logger.warning(
            f"Unknown type kind='{kind}' format='{fmt}' in {path}, "
            "using generic DataEntry if possible"
        )
        # Fallback attempt usually handled by registry get, but fail safe here?
        # For now let it raise or handle better. Drowning to simple fallback
        from axm.catalog.entries import DataEntry, OperationEntry, PipelineEntry

        if kind == "operation":
            return OperationEntry.model_validate(data)
        elif kind == "pipeline":
            return PipelineEntry.model_validate(data)
        else:
            return DataEntry.model_validate(data)


# Backwards compatibility alias
load_data_entry = load_catalog_entry
