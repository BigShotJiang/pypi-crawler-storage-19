"""Registration for core entry types."""

from axm.catalog.entries.data import DataEntry
from axm.catalog.entries.operation import OperationEntry
from axm.catalog.entries.pipeline import PipelineEntry
from axm.catalog.entries.registry import EntryTypeRegistry


def register_entries(registry: type[EntryTypeRegistry]) -> None:
    """Register core types."""
    # Generic data
    registry.register("data", None, DataEntry)

    # Other core types
    registry.register("operation", None, OperationEntry)
    registry.register("pipeline", None, PipelineEntry)
