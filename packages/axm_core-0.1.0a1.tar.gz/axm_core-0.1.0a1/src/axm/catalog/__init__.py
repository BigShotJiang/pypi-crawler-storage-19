"""AXM Catalog — Data contract and validation system."""

from axm.catalog.entries import (
    AccessControl,
    Availability,
    Compliance,
    DataEntry,
    Governance,
    Identity,
    Location,
    Owner,
    Provenance,
    Quality,
    QualityRule,
    Retention,
    Schema,
    SchemaFormat,
    Sensitivity,
    SourceInput,
    Temporal,
)
from axm.catalog.loading import DataCatalog, YAMLLoadError, load_data_entry
from axm.catalog.registry import CatalogRegistry
from axm.catalog.validation import SchemaValidator
from axm.core import (
    BaseCatalog,
    BaseCatalogEntry,
    BaseValidator,
    CatalogMetadata,
    Severity,
    ValidationError,
    ValidationResult,
)

__all__ = [
    # DataEntry models
    "AccessControl",
    "Availability",
    # Protocols
    "BaseCatalog",
    "BaseCatalogEntry",
    "BaseValidator",
    # Validation
    "CatalogMetadata",
    "CatalogRegistry",
    "Compliance",
    # Loader
    "DataCatalog",
    "DataEntry",
    "Governance",
    "Identity",
    "Location",
    "Owner",
    "Provenance",
    "Quality",
    "QualityRule",
    "Retention",
    "Schema",
    "SchemaFormat",
    "SchemaValidator",
    "Sensitivity",
    "Severity",
    "SourceInput",
    "Temporal",
    "ValidationError",
    "ValidationResult",
    "YAMLLoadError",
    "load_data_entry",
]
