"""Lineage compatibility validation for AXM schemas.

Provides utilities to check schema compatibility between producers and consumers
in data pipelines.
"""

from dataclasses import dataclass
from typing import Any

from axm.catalog.entries import DataBinding


@dataclass
class SchemaCompatibilityError:
    """Error representing a schema compatibility issue.

    Attributes:
        message: Human-readable error message.
        producer_type: The type provided by the producer.
        consumer_type: The type expected by the consumer.
    """

    message: str
    producer_type: str | None = None
    consumer_type: str | None = None


def check_schema_compatibility(
    producer_schema: dict[str, Any],
    consumer_binding: DataBinding,
    expected_type: str,
    consumer_nullable: bool = True,
) -> list[SchemaCompatibilityError]:
    """Check schema compatibility between producer and consumer.

    Validates that the producer's schema can satisfy the consumer's requirements.

    Args:
        producer_schema: Schema definition from the producer DataEntry.
        consumer_binding: The input binding from the consumer operation.
        expected_type: The type expected by the consumer for this binding.
        consumer_nullable: Whether the consumer accepts null values.

    Returns:
        List of compatibility errors. Empty list if compatible.
    """
    errors: list[SchemaCompatibilityError] = []
    column_name = consumer_binding.name

    # Find the column in producer schema
    producer_columns = producer_schema.get("columns", [])
    producer_column = None
    for col in producer_columns:
        if col.get("name") == column_name:
            producer_column = col
            break

    # Check if column exists
    if producer_column is None:
        errors.append(
            SchemaCompatibilityError(
                message=f"Column '{column_name}' not found in producer schema",
                producer_type=None,
                consumer_type=expected_type,
            )
        )
        return errors

    producer_type = producer_column.get("type", "unknown")
    producer_nullable = producer_column.get("nullable", True)

    # Check type compatibility
    if producer_type != expected_type:
        errors.append(
            SchemaCompatibilityError(
                message=(
                    f"Type mismatch for '{column_name}': "
                    f"producer has {producer_type}, consumer expects {expected_type}"
                ),
                producer_type=producer_type,
                consumer_type=expected_type,
            )
        )

    # Check nullability
    if producer_nullable and not consumer_nullable:
        errors.append(
            SchemaCompatibilityError(
                message=(
                    f"Nullable mismatch for '{column_name}': "
                    f"producer is nullable but consumer requires non-null"
                ),
                producer_type=producer_type,
                consumer_type=expected_type,
            )
        )

    return errors
