"""Validation module for AXM catalog entries."""

from axm.catalog.validation.validator import SchemaValidator

__all__ = [
    "SchemaValidator",
]
