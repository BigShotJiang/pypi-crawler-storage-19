"""Registry for data schema validators.

This registry allows plugins to register validators for specific data formats.
"""

import importlib.metadata
import logging
from typing import Any, ClassVar, Protocol, runtime_checkable

from axm.core import BaseValidator

logger = logging.getLogger(__name__)


@runtime_checkable
class DataValidator(BaseValidator, Protocol):
    """Protocol for data schema validators."""

    def __init__(self, entry: Any) -> None: ...


class ValidatorRegistry:
    """Registry for data validators."""

    _registry: ClassVar[dict[str, type[DataValidator]]] = {}

    @classmethod
    def register(cls, fmt: str, validator_cls: type[DataValidator]) -> None:
        """Register a validator class for a specific format.

        Args:
            fmt: The schema format string (e.g., "tabular", "image").
            validator_cls: The validator class to use.
        """
        logger.debug(
            f"Registering validator for format '{fmt}': {validator_cls.__name__}"
        )
        cls._registry[fmt] = validator_cls

    @classmethod
    def get(cls, fmt: str) -> type[DataValidator] | None:
        """Get a validator class for the given format.

        Args:
            fmt: The schema format string.

        Returns:
            The validator class, or None if not found.
        """
        if not cls._registry:
            cls.discover_validators()
        return cls._registry.get(fmt)

    @classmethod
    def discover_validators(cls) -> None:
        """Discover validators registered via entry points."""
        entry_points = importlib.metadata.entry_points(group="axm.validators")

        for ep in entry_points:
            try:
                register_func = ep.load()
                register_func()
                logger.debug(f"Loaded validators from {ep.name}")
            except Exception as e:
                logger.error(f"Failed to load validators from {ep.name}: {e}")
