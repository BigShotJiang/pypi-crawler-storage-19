"""Validator for DataEntry schemas."""

from typing import Any

from axm.catalog.entries import DataEntry
from axm.catalog.validation.registry import ValidatorRegistry
from axm.core import BaseValidator, Severity, ValidationError, ValidationResult


class SchemaValidator(BaseValidator):
    """Validates data against DataEntry schema using registered validators."""

    def __init__(self, entry: DataEntry) -> None:
        """Initialize validator with data entry definition."""
        self.entry = entry

    def validate(self, data: Any) -> ValidationResult:
        """Validate data against schema.

        Args:
            data: The data object to validate (type depends on format).

        Returns:
            ValidationResult containing status and errors.
        """
        fmt = self.entry.data_schema.format

        # Look up validator class for the format
        validator_cls = ValidatorRegistry.get(fmt)

        if not validator_cls:
            return ValidationResult(
                is_valid=False,
                errors=[
                    ValidationError(
                        field="schema.format",
                        message=f"No validator registered for format: {fmt}",
                        severity=Severity.ERROR,
                    )
                ],
            )

        # Instantiate and delegate
        # We assume the validator class accepts 'entry' in init
        try:
            validator = validator_cls(self.entry)
            return validator.validate(data)
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[
                    ValidationError(
                        field="validator",
                        message=f"Validator execution failed: {e}",
                        severity=Severity.ERROR,
                    )
                ],
            )
