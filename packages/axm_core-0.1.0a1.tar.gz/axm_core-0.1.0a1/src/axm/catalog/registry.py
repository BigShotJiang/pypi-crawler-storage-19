"""Global registry for AXM catalogs."""

from axm.catalog.loading import DataCatalog


class CatalogRegistry:
    """Singleton registry for accessing catalogs globally.

    Usage::

        registry = CatalogRegistry.get()
        registry.register("data", DataCatalog.from_directory(...))
        users_entry = registry["data"]["users"]
    """

    _instance: "CatalogRegistry | None" = None

    def __init__(self) -> None:
        """Initialize registry. Use CatalogRegistry.get() instead."""
        self._catalogs: dict[str, DataCatalog] = {}

    def __new__(cls) -> "CatalogRegistry":
        """Implement Singleton pattern."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            # Initialize explicitly here to avoid re-init if __init__ is called again
            # though normal usage should be via get() or impl that checks instance
            cls._instance._catalogs = {}
        return cls._instance

    @classmethod
    def get(cls) -> "CatalogRegistry":
        """Get the singleton instance of the registry."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance (useful for testing)."""
        cls._instance = None

    def register(self, domain: str, catalog: DataCatalog) -> None:
        """Register a catalog for a specific domain (e.g., 'data', 'operators')."""
        self._catalogs[domain] = catalog

    def get_catalog(self, domain: str) -> DataCatalog:
        """Get catalog for a specific domain."""
        return self._catalogs[domain]

    def __getitem__(self, domain: str) -> DataCatalog:
        """Get catalog by domain name."""
        return self.get_catalog(domain)

    def __contains__(self, domain: str) -> bool:
        """Check if domain is registered."""
        return domain in self._catalogs
