"""Base abstractions for validation rules and presets."""

from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, Field

from axm.core import Severity, ValidationError, ValidationResult


class Rule(BaseModel):
    """A named validation rule."""

    name: str
    description: str
    callback: Callable[[Any], bool]
    severity: Severity = Severity.ERROR

    def check(self, value: Any, field_name: str | None = None) -> bool:
        """Execute the rule's logic against a value."""
        try:
            return self.callback(value)
        except Exception:
            return False


class Preset(BaseModel):
    """A collection of rules applied together."""

    name: str
    rules: list[Rule] = Field(default_factory=list)

    def check(self, value: Any, field_name: str = "value") -> ValidationResult:
        """Apply all rules in the preset to the value."""
        errors: list[ValidationError] = []

        for rule in self.rules:
            if not rule.check(value, field_name):
                errors.append(
                    ValidationError(
                        field=field_name,
                        message=f"Rule '{rule.name}' failed: {rule.description}",
                        severity=rule.severity,
                    )
                )

        return ValidationResult(is_valid=len(errors) == 0, errors=errors)
