"""Registry for validation rules."""

from typing import ClassVar

from axm.catalog.rules.base import Rule


class RuleRegistry:
    """Singleton registry for validation rules."""

    _rules: ClassVar[dict[str, Rule]] = {}

    @classmethod
    def register(cls, rule: Rule) -> None:
        """Register a new global rule."""
        if rule.name in cls._rules:
            # Optionally warn or overwrite
            pass
        cls._rules[rule.name] = rule

    @classmethod
    def get(cls, name: str) -> Rule:
        """Get a rule by name."""
        try:
            return cls._rules[name]
        except KeyError as err:
            raise KeyError(f"Rule '{name}' not found in registry.") from err

    @classmethod
    def reset(cls) -> None:
        """Clear registry (for testing)."""
        cls._rules = {}
