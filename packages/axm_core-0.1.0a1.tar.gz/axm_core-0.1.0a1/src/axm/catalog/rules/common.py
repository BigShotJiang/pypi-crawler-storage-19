"""Standard library of validation rules."""

import re
from typing import Any

from axm.catalog.rules.base import Rule


def _not_empty(value: Any) -> bool:
    """Check if value is not None and not empty."""
    if value is None:
        return False
    if hasattr(value, "__len__") and len(value) == 0:
        return False
    return True


not_empty = Rule(
    name="not_empty",
    description="Value must not be None or empty",
    callback=_not_empty,
)


def _is_email(value: Any) -> bool:
    """Check if value is a valid email string."""
    if not isinstance(value, str):
        return False
    # Simple regex for email validation
    # user@domain.tld
    pattern = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
    return bool(re.match(pattern, value))


is_email = Rule(
    name="is_email",
    description="Value must be a valid email address",
    callback=_is_email,
)


def _is_positive(value: Any) -> bool:
    """Check if value is a positive number."""
    if not isinstance(value, (int, float)):
        return False
    return value > 0


is_positive = Rule(
    name="is_positive",
    description="Value must be a positive number",
    callback=_is_positive,
)
