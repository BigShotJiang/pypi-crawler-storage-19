"""Validation presets and rules."""

from axm.catalog.rules.base import Preset, Rule
from axm.catalog.rules.common import is_email, is_positive, not_empty
from axm.catalog.rules.registry import RuleRegistry

__all__ = ["Preset", "Rule", "RuleRegistry", "is_email", "is_positive", "not_empty"]
