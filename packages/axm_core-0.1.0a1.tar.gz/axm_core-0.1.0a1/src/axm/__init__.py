"""AXM: Metadata-Driven Micro-Orchestrator for Resilient Data Pipelines."""

__version__ = "0.1.0"


def get_version() -> str:
    """Return the current version of AXM."""
    return __version__


__all__ = ["__version__", "get_version"]
