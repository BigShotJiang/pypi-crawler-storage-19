"""Decorators for marking Python functions as AXM operations."""

from collections.abc import Callable
from functools import wraps
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")


def operation(
    inputs: list[str],
    outputs: list[str],
    domain: str = "default",
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Mark a function as an AXM operation.

    This decorator attaches metadata to the function that can be used
    by `axm discover` to auto-generate .axm contract files.

    Args:
        inputs: List of input data entry names this operation consumes.
        outputs: List of output data entry names this operation produces.
        domain: Domain/category for the operation (default: "default").

    Returns:
        Decorated function with _axm_meta attribute.

    Example:
        >>> @operation(inputs=["raw_users"], outputs=["clean_users"])
        ... def clean_users(inputs: dict, parameters: dict) -> dict:
        ...     return {"clean_users": processed_data}
    """

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            return func(*args, **kwargs)

        # Attach metadata for discovery
        wrapper._axm_meta = {  # type: ignore[attr-defined]
            "kind": "operation",
            "entrypoint": func.__name__,
            "description": func.__doc__ or "",
            "inputs": inputs,
            "outputs": outputs,
            "domain": domain,
        }

        return wrapper

    return decorator
