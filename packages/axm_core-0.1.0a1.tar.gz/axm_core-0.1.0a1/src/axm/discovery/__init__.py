"""AXM Discovery module - Auto-generate contracts from code."""

from axm.discovery.decorators import operation

__all__ = ["operation"]
