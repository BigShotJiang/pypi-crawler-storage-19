"""Core protocols for AXM catalog system.

These protocols define the interfaces for catalog entries, catalogs, and validators.
They are shared across all AXM modules.
"""

from collections.abc import Iterator
from pathlib import Path
from typing import Any, Protocol, Self, runtime_checkable

from axm.core.types import ValidationResult


@runtime_checkable
class BaseCatalogEntry(Protocol):
    """Protocol definition for any entry in the AXM catalog system.

    This protocol ensures that all catalog entries (whether they are Datasets,
    Pipelines, or Operators) share a common interface for serialization and validation.

    Attributes:
        name: The unique identifier for the catalog entry.
        version: Semantic version string of the entry.
        description: Optional human-readable description.
    """

    name: str
    version: str
    description: str | None

    @classmethod
    def from_yaml(cls, path: Path) -> Self:
        """Load a catalog entry instance from a YAML file.

        Args:
            path: The filesystem path to the YAML file.

        Returns:
            An instance of the implementing class populated with data from the file.

        Raises:
            FileNotFoundError: If the path does not exist.
            ValueError: If the YAML content is invalid.
        """
        ...

    def to_yaml(self) -> str:
        """Serialize the catalog entry to a YAML formatted string.

        Returns:
            A string containing the YAML representation of the entry.
        """
        ...

    def validate_entry(self) -> ValidationResult:
        """Perform strict validation of the entry against its schema.

        Returns:
            A ValidationResult object containing success status and error messages.
        """
        ...


@runtime_checkable
class BaseCatalog[T: BaseCatalogEntry](Protocol):
    """Protocol for a container that holds catalog entries of a specific type.

    A Catalog acts as a registry and a lookup mechanism. It supports dict-like
    access to entries by name.

    Type Parameters:
        T: The type of BaseCatalogEntry this catalog holds.
    """

    def __getitem__(self, name: str) -> T:
        """Retrieve a registered entry by its name.

        Args:
            name: The unique identifier of the entry.

        Returns:
            The requested entry instance.

        Raises:
            KeyError: If no entry with the given name exists.
        """
        ...

    def __iter__(self) -> Iterator[T]:
        """Iterate over all registered entries in the catalog.

        Returns:
            An iterator yielding catalog entry instances.
        """
        ...

    def register(self, entry: T) -> None:
        """Register a new entry into the catalog.

        Args:
            entry: The entry instance to register.

        Raises:
            ValueError: If an entry with the same name already exists.
        """
        ...

    @classmethod
    def from_directory(cls, path: Path) -> Self:
        """Initialize a catalog by scanning a directory for YAML files.

        Args:
            path: The root directory to scan.

        Returns:
            A fully populated Catalog instance.
        """
        ...


@runtime_checkable
class BaseValidator(Protocol):
    """Protocol for external validators that can check data integrity.

    Validators are distinct from the internal BaseCatalogEntry.validate method
    as they often involve checking external resources or complex logic.
    """

    def validate(self, data: Any) -> ValidationResult:
        """Validate the provided data object.

        Args:
            data: The data structure or object to validate.

        Returns:
            A ValidationResult indicating if the data is valid according to rules.
        """
        ...
