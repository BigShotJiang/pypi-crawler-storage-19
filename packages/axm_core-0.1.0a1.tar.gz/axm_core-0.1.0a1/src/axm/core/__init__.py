"""AXM core types and protocols.

This module exports foundational types shared across all AXM modules.
"""

from axm.core.protocols import BaseCatalog, BaseCatalogEntry, BaseValidator
from axm.core.types import (
    CatalogMetadata,
    Severity,
    ValidationError,
    ValidationResult,
)

__all__ = [
    "BaseCatalog",
    "BaseCatalogEntry",
    "BaseValidator",
    "CatalogMetadata",
    "Severity",
    "ValidationError",
    "ValidationResult",
]
