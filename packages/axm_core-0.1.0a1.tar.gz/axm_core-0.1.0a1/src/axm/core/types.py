"""Core validation types for AXM.

These types are shared across all AXM modules (catalog, pipeline, etc.).
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel


class Severity(str, Enum):
    """Validation error severity levels."""

    ERROR = "error"
    WARNING = "warning"


class ValidationError(BaseModel):
    """A single validation error or warning."""

    field: str
    message: str
    severity: Severity


class ValidationResult(BaseModel):
    """Result of a validation operation."""

    is_valid: bool
    errors: list[ValidationError] = []
    warnings: list[ValidationError] = []

    @classmethod
    def valid(cls) -> "ValidationResult":
        """Create a valid result with no errors."""
        return cls(is_valid=True, errors=[], warnings=[])

    @classmethod
    def invalid(
        cls,
        field: str,
        message: str,
        severity: Severity = Severity.ERROR,
    ) -> "ValidationResult":
        """Create an invalid result with a single error."""
        error = ValidationError(field=field, message=message, severity=severity)
        return cls(is_valid=False, errors=[error], warnings=[])


class CatalogMetadata(BaseModel):
    """Common metadata for catalog entries."""

    owner: str | None = None
    tags: list[str] = []
    created_at: datetime | None = None
