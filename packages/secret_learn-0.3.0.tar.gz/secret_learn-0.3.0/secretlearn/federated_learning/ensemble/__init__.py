"""SecretFlow ensemble adapters"""
