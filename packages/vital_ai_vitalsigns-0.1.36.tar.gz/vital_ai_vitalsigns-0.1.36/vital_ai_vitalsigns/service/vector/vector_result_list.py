

class VitalVectorResultList:
    pass

