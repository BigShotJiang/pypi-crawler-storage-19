============
Django Click
============

Project information:

.. image:: https://img.shields.io/pypi/v/django-click.svg
   :target: https://pypi.python.org/pypi/django-click

.. image:: https://img.shields.io/pypi/dm/django-click.svg
   :target: https://pypi.python.org/pypi/django-click

.. image:: https://img.shields.io/badge/docs-TODO-lightgrey.svg
   :target: http://django-click.readthedocs.org/en/latest/

.. image:: https://img.shields.io/pypi/l/django-click.svg
   :target: https://github.com/GaretJax/django-click/blob/master/LICENSE

.. |python-support| image:: https://img.shields.io/pypi/pyversions/django-click
   :target: https://pypi.python.org/pypi/django-click
   :alt: Supported Python versions

.. |django-support| image:: https://img.shields.io/pypi/djversions/django-click
   :target: https://pypi.python.org/pypi/django-click
   :alt: Supported Django versions

Automated code metrics:

.. image:: https://img.shields.io/coveralls/GaretJax/django-click/master.svg
   :target: https://coveralls.io/r/GaretJax/django-click?branch=master

``django-click`` is a library to easily write Django management commands using the
``click`` command line library.

* Free software: MIT license
* Documentation for the Click command line library: https://click.palletsprojects.com/en/stable/
* Compatible with Django 4.2, 5.2 and 6.0 running on Python 3.10, 3.11, 3.12, 3.13 and 3.14

  * 3.10+ required for Django 5.2 and above
  * 3.12+ required for Django 6.0 and above


Installation
============

::

  pip install django-click


Example
=======

Create a command module as you would usually do, but instead of creating a
class, just put a ``djclick`` command into
``<yourapp>/management/commands/helloworld.py``:

.. code:: python

   import djclick as click

   @click.command()
   @click.argument('name')
   def command(name):
       click.secho(f'Hello, {name}', fg='red')

And then call the command with::

   $ ./manage.py helloworld django-click
   Hello, django-click

Check out the `test commands
<https://github.com/GaretJax/django-click/tree/master/djclick/test/testprj/testapp/management/commands>`_
for additional example commands and advanced usage.

Release Notes and Contributors
==============================

* `Release Notes on GitHub <https://github.com/GaretJax/django-click/releases>`_
* `Our Wonderful Contributors <https://github.com/GaretJax/django-click/graphs/contributors>`_

This package is a member of `Django Commons <https://github.com/django-commons/>`_ and adheres to the community's `Code of Conduct <https://github.com/django-commons/membership/blob/main/CODE_OF_CONDUCT.md>`_. It is maintained by `Jonathan Stoppani <https://github.com/GaretJax/>`_ and `Timothy Allen <https://github.com/FlipperPA/>`_, who have many professional responsibilities. We are thrilled that our employers allow us a certain amount of time to contribute to open-source projects. We add features as they are necessary for our projects, and try to keep up with Issues and Pull Requests as best we can. Due to constraints of time (our full time jobs!), Feature Requests without a Pull Request may not be implemented, but we are always open to new ideas and grateful for contributions and our users.
