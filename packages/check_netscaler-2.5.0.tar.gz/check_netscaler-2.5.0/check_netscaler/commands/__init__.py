"""Check command implementations"""
