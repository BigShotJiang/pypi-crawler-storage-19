# Console Web Radio Player (Python)

A simple **console-based web radio player** written in **Python**, using low-level streaming concepts.
The player connects to an online radio stream, plays audio in real time, and displays **ICY metadata** (current track information) in the terminal.

This project is intended for **learning purposes**, focusing on networking, streaming, and protocol-level concepts.

---

## ✨ Features

* Console (terminal) based radio player
* Streams live internet radio (Icecast / Shoutcast)
* Displays current song title using ICY metadata
* Uses Python standard libraries for networking
* Audio playback via `ffplay`
* Clean and minimal implementation

---

## 🛠️ Tech Stack

* **Language:** Python 3
* **Networking:** `urllib` (HTTP streaming over sockets)
* **Audio playback:** `ffplay` (FFmpeg)
* **Protocol:** ICY (Icecast/Shoutcast metadata)

---

## 📁 Project Structure

```
radio-player/
├── radio_client_icy.py
└── README.md
```

---

## 📦 Requirements

* Python 3.8+
* FFmpeg (for `ffplay`)

### Install FFmpeg (Ubuntu/Debian)

```bash
sudo apt install ffmpeg
```

---

## ▶️ Usage

```bash
python3 radio_client_icy.py
```

Stop playback with:

```
Ctrl + C
```

---

## 🔄 Changing the Radio Station

Edit the stream URL inside `radio_client_icy.py`:

```python
STREAM_URL = "https://s2.audiostream.hu/juventus_192k"
```

Examples:

* BBC Radio 1
  `http://stream.live.vc.bbcmedia.co.uk/bbc_radio_one`
* FIP Radio
  `http://icecast.radiofrance.fr/fip-hifi.aac`

---

## 📡 ICY Metadata

The player reads ICY metadata blocks from the stream and extracts:

* Artist name
* Track title

Displayed in real time as:

```
🎵 Now playing: Artist - Track
```

---

## ⚠️ Notes

* Not all radio streams provide ICY metadata
* Designed for educational and experimental use
* No GUI – terminal only
* Audio decoding is handled externally by `ffplay`

---

## 🔮 Future Improvements

* Station selection menu
* Track change detection
* Pause / resume support
* ncurses-based UI
* POSIX socket implementation in C
* Custom streaming server

---

## 📜 License

This project is open source and free to use.

---

## 🙌 Author

Created by **Komka László**
GitHub: [https://github.com/niaxinus](https://github.com/niaxinus)
