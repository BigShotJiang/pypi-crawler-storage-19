class RoutingInstanceMixin:
    pass
