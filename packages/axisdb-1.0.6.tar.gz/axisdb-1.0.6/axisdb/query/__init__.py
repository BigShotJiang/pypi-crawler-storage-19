"""Query AST and evaluation."""
