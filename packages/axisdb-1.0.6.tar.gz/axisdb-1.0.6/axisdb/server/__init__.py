"""Optional server wrappers (FastAPI)."""
