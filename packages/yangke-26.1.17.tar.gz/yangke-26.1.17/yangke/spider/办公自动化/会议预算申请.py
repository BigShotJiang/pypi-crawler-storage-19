
def 登录协同():
    pass

def 进入BIP财务系统():
    pass

def 进入会议开支预算页面():
    # 点击我要申请
    pass
    # 选择会议开支预算表

    # 点击q