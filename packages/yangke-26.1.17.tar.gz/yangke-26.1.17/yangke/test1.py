# import torch
# import torch.nn as nn
#
# # 1. 定义一个简单网络
# net = nn.Sequential(
#         nn.Linear(7, 20),
#         nn.Tanh(),
#         nn.Linear(20, 1))
#
# # 2. 构造一条样本（batch_size=1），并打开梯度追踪
# x = torch.randn(1, 7, requires_grad=True)   # 必须设成 True
#
# # 3. 前向
# predict = net(x)          # shape (1,1)
#
# # 4. 求 predict 对 x 第 2 个分量（index=1）的偏导数
# #    方法 1：torch.autograd.grad
# grad_2, = torch.autograd.grad(
#             outputs=predict,      # 要对谁求导
#             inputs=x,             # 求导变量
#             retain_graph=True,    # 如果后面还要 backward 就保留图
#             create_graph=True)    # 如果想继续在高阶导里用，就打开
# # grad_2 形状与 x 相同，(1,7)
# print('∂predict/∂x2 =', grad_2[0, 1].item())
#
# #    方法 2：先对 predict 做 backward，再读 x.grad
# #    但这样会把 7 个梯度都算出来，而且只能得到 ∂loss/∂x
# #    这里我们手动把 predict 当成标量 loss 来处理：
# net.zero_grad()
# if x.grad is not None:
#     x.grad.zero_()
# predict.backward(retain_graph=True)
# print('同样 ∂predict/∂x2 =', x.grad[0, 1].item())

from yangke.common.config import logger, add_file_logger

add_file_logger(log_file='default.log', rotation="50 MB", retention="360 days")


def test():
    logger.info('test')
    logger.debug('debug')


if __name__ == '__main__':
    test()
