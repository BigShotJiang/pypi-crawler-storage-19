import vgamepad

UP = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_UP
DOWN = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_DOWN
LEFT = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_LEFT
RIGHT = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_DPAD_RIGHT
A = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_A
B = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_B
X = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_X
Y = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_Y
START = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_START
BACK = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_BACK
GUIDE = vgamepad.XUSB_BUTTON.XUSB_GAMEPAD_GUIDE


class GamePad:
    def __init__(self):
        self.gamepad = vgamepad.VX360Gamepad()
        # 创建按钮映射字典
        self.button_map = {
            "A": A,
            "B": B,
            "X": X,
            "Y": Y,
            "START": START,
            "BACK": BACK,
            "GUIDE": GUIDE,
            "LEFT": LEFT,
            "RIGHT": RIGHT,
            "UP": UP,
            "DOWN": DOWN
        }

    def press_button(self, btn):
        # 按下虚拟手柄按键
        if btn in self.button_map:
            button = self.button_map[btn]
            self.gamepad.press_button(button)
            self.gamepad.update()
        else:
            print("Invalid button")

    def release_button(self, btn):
        # 释放虚拟手柄按键
        if btn in self.button_map:
            button = self.button_map[btn]
            self.gamepad.release_button(button)
            self.gamepad.update()
        else:
            print("Invalid button")

    def btn_clicked(self, btn):
        # 按下并释放虚拟手柄按键
        if btn in self.button_map:
            button = self.button_map[btn]
            self.gamepad.press_button(button)
            self.gamepad.update()
            self.gamepad.release_button(button)
            self.gamepad.update()
        else:
            print("Invalid button")

    def reset(self):
        # 将虚拟手柄状态重置
        self.gamepad.reset()
        self.gamepad.update()

# def LEFT_TRIGGER(value):
#     gamepad.left_trigger(value)
#     # 左扳机轴 value改成0到255之间的整数
#
#
# def RIGHT_TRIGGER(value):
#     gamepad.right_trigger(value)
#     # 右扳机轴 value改成0到255之间的整数
#
#
# def LEFT_JOYSTICK(x_value, y_value):
#     gamepad.left_joystick(x_value, y_value)
#     # 左摇杆XY轴  x_values和y_values 改成-32768到32767之间的整数
#
#
# def RIGHT_JOYSTCIK(x_value, y_value):
#     gamepad.right_joystick(x_value, y_value)
#     # 右摇杆XY轴  x_values和y_values 改成-32768到32767之间的整数

# 扳机轴等于1就是完全按下扳机，等于0则是完全松开扳机
# def LEFT_TRIGGER(value):
#     gamepad.left_trigger_float(value)
#     # 左扳机轴 value改成0.0到1.0之间的浮点值，可以精确到小数点后5位
#
#
# def RIGHT_TRIGGER(value):
#     gamepad.right_trigger_float(value)
#     # 右扳机轴 value改成0.0到1.0之间的浮点值，可以精确到小数点后5位
#
#
# # 摇杆的X轴大于0就是摇杆推右，Y轴大于0就是摇杆推上
# def LEFT_JOYSTICK(x_value, y_value):
#     gamepad.left_joystick_float(x_value, y_value)
#     # 左摇杆XY轴  x_values和y_values改成-1.0到1.0之间的浮点值，可以精确到小数点后5位
#
#
# def RIGHT_JOYSTCIK(x_value, y_value):
#     gamepad.right_joystick_float(x_value, y_value)
#     # 右摇杆XY轴  x_values和y_values改成-1.0到1.0之间的浮点值，可以精确到小数点后5位
#
