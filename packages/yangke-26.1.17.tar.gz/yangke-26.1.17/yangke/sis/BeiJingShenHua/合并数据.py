import os
import pandas as pd

# 指定文件夹路径
folder = r'D:\原始数据'

# 获取文件夹中所有txt文件
file_list = [f for f in os.listdir(folder) if f.endswith('.txt')]

# 初始化一个空的DataFrame用于存储合并后的数据
combined_data = pd.DataFrame()

# 遍历所有文件并读取数据
for file_name in file_list:
    file_path = os.path.join(folder, file_name)
    # 读取CSV格式的txt文件
    data = pd.read_csv(file_path)
    # 将数据追加到combined_data中
    combined_data = pd.concat([combined_data, data], ignore_index=True)

# 保存合并后的数据到新的CSV文件
output_path = os.path.join(folder, 'combined_data.csv')
combined_data.to_csv(output_path, index=False)

print(f"已成功合并 {len(file_list)} 个文件，结果保存至: {output_path}")
