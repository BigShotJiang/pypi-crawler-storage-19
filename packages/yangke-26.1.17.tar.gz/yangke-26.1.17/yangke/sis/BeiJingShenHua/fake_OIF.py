class SystemLib:
    def __init__(self):
        ...


class MathLib:
    def __init__(self):
        ...


class PointLib:
    def __init__(self):
        ...

    @staticmethod
    def GetFloatPoint(kks) -> float | None:
        return None

    @staticmethod
    def GetPoint(kks) -> float | None:
        """
        这个返回的是double数据，精度更高
        """
        return None

    @staticmethod
    def GetIntPoint(kks) -> int | None:
        """
        这个返回的是int数据，精度更高
        """
        return None

    @staticmethod
    def GetBoolPoint(kks) -> bool | None:
        """
        这个返回的是bool数据，精度更高
        """
        return None

    @staticmethod
    def GetFloatPointList(kks_list):
        return [PointLib.GetFloatPoint(kks) for kks in kks_list]

    @staticmethod
    def SetPoint(kks, value):
        """
        这个返回的是bool数据，精度更高
        """
        return True

    @staticmethod
    def SetBoolPoint(kks, value):
        """
        这个返回的是bool数据，精度更高
        """
        return True

    @staticmethod
    def SetIntPoint(kks, value):
        """
        这个返回的是int数据，精度更高
        """
        return True

    @staticmethod
    def SetFloatPoint(kks, value):
        """
        这个返回的是double数据，精度更高
        """
        return True


class ExecutionLib:
    def __init__(self):
        ...


class MemoryLib:
    def __init__(self):
        ...
