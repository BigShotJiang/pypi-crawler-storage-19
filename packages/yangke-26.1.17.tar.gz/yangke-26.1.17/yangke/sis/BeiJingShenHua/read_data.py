import os
import pandas as pd
import numpy as np

if __name__=="__main__":
    data = pd.read_csv(r"C:\Users\YangKe\Desktop\冷端优化历史数据\Points_2025_10_14__11_41_38.csv")
    print(data.head())
