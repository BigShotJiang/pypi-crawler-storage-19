"""
启动ollama服务，运行以下命令：
docker compose up -d
其中，up表示根据compose.yaml创建并启动容器，-d表示后台运行，也可通过-p指定项目名称，如docker compose -p oi up -d, 则所有容器/网络都会以 oi_ 为前缀。

docker exec -it ollama /bin/bash

ollama run qwq
"""
