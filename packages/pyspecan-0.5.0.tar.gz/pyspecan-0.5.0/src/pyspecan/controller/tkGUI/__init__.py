"""tkGUI Controller helpers"""
