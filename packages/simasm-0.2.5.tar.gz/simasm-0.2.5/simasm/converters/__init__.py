"""
SimASM Converters Module

This module provides converters from high-level simulation formalisms
(Event Graph, Activity Cycle Diagram) specified in JSON to SimASM code.

The converters implement fine-grained step semantics for trace equivalence
between different formalisms.

Usage:
    Event Graph:
        from simasm.converters.event_graph.schema import EventGraphSpec
        from simasm.converters.event_graph.converter import convert_eg

    ACD:
        from simasm.converters.acd.schema import ACDSpec
        from simasm.converters.acd.converter import convert_acd
"""

# Event Graph converters
from .event_graph.schema import EventGraphSpec
from .event_graph.converter import convert_eg, convert_eg_from_json, EventGraphConverter

# ACD converters
from .acd.schema import ACDSpec
from .acd.converter import convert_acd, convert_acd_from_json, ACDConverter

__all__ = [
    # Event Graph
    "EventGraphSpec", "EventGraphConverter", "convert_eg", "convert_eg_from_json",
    # ACD
    "ACDSpec", "ACDConverter", "convert_acd", "convert_acd_from_json",
]
