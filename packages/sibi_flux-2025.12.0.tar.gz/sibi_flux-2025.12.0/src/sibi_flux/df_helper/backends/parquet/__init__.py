from __future__ import annotations

from ._parquet_options import ParquetConfig

__all__ = [
    "ParquetConfig",
]
