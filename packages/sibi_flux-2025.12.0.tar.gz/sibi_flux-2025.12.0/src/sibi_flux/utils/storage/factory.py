from typing import Any, Dict, Iterable, List, Literal, Optional, Type
from sibi_flux.utils.storage import StorageManager


def create_storage_manager(
    settings_class: Type[Any],
    depots_dict: Optional[Dict[str, Iterable[str]]] = None,
    clear_existing: bool = False,
    write_mode: Literal["full-access", "read-only"] = "full-access",
) -> StorageManager:
    """
    Factory helper to create initialized StorageManager from Pydantic Settings.

    Args:
        settings_class: A Pydantic Settings class (e.g. FsSettings)
        depots_dict: Optional dictionary of depot definitions {depot_name: [subdirs]}
        clear_existing: Whether to clear existing directories on setup
        write_mode: 'full-access' (creates dirs) or 'read-only' (passive)

    Returns:
        Initialized StorageManager instance.
    """
    settings = settings_class()
    manager = StorageManager(
        storage_path=settings.fs_path,
        fs_type=settings.fs_type,
        fs_options=settings.to_fsspec_options(),
    )
    if depots_dict:
        manager.rebuild_depot_paths(
            depots_dict, clear_existing=clear_existing, write_mode=write_mode
        )
    return manager
