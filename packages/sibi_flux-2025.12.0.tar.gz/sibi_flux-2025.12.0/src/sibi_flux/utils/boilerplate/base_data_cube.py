"""
Base DataCube module.

Provides the foundational classes for DataCube definitions and loading logic.
"""

from __future__ import annotations

import asyncio
from typing import Optional, Any, Dict

import dask.dataframe as dd
import pandas as pd

from sibi_flux.df_helper import DfHelper
from sibi_flux.dask_cluster import dask_is_empty


DataFrameType = dd.DataFrame | pd.DataFrame


class BaseDatacube(DfHelper):
    """
    Base cube with sync/async load hooks and resilient Dask handling.

    Lifecycle:
      1. load() / aload() calls parent DfHelper to fetch raw data.
      2. If data exists, calls fix_data() (sync) or afix_data() (async).
      3. Result is stored in self.df and returned.

    Subclasses should override:
      - fix_data(self, df): for CPU-bound transformations (Pandas/Dask map_partitions)
      - afix_data(self, df): for I/O-bound transformations (DB lookups, etc.)
    """

    # Class-level config overrides (e.g. backend='parquet')
    config: Dict[str, Any] = {}

    def __init__(self, **kwargs):

        combined_config = {**self.config, **kwargs}
        super().__init__(**combined_config)

        # State container
        self.df: Optional[DataFrameType] = None

    # -----------------------------------------------------------------------
    # Hooks (Override these)
    # -----------------------------------------------------------------------
    def fix_data(self, df: DataFrameType, **kwargs) -> DataFrameType:
        """
        Synchronous transformation hook.

        Args:
            df: The loaded dataframe (Pandas or Dask)
            **kwargs: The options passed to load()

        Returns:
            The transformed dataframe.
        """
        return df

    async def afix_data(self, df: DataFrameType, **kwargs) -> DataFrameType:
        """
        Asynchronous transformation hook.

        Defaults to calling fix_data(). Override this ONLY if you need
        to perform async operations (like awaiting other DB calls).
        """
        return self.fix_data(df, **kwargs)

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------
    def load(self, **kwargs) -> DataFrameType:
        """
        Synchronous load pipeline.
        """
        # 1. Load Raw Data (Delegate to DfHelper)
        df = super().load(**kwargs)

        # 2. Check Emptiness (Resilient)
        if not self._is_empty(df):
            # 3. Apply Transform Hook
            df = self.fix_data(df, **kwargs)
        else:
            self.logger.debug(f"No data loaded by {self.__class__.__name__}")

        # 4. Update State & Return
        self.df = df
        return df

    async def aload(self, **kwargs) -> DataFrameType:
        """
        Asynchronous load pipeline.
        """
        # 1. Load Raw Data
        df = await super().aload(**kwargs)

        # 2. Check Emptiness (Non-blocking)
        # _is_empty triggers dask.compute(), so we must offload to thread
        is_empty = await asyncio.to_thread(self._is_empty, df)

        if not is_empty:
            # 3. Apply Async Transform Hook
            # (Note: afix_data calls fix_data by default, so this covers both cases)
            df = await self.afix_data(df, **kwargs)
        else:
            self.logger.debug(f"No data loaded by {self.__class__.__name__}")

        # 4. Update State & Return
        self.df = df
        return df

    # -----------------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------------
    def _is_empty(self, df: Optional[DataFrameType]) -> bool:
        """
        Robust emptiness check using dask_cluster.
        """
        if df is None:
            return True

        if isinstance(df, pd.DataFrame):
            return df.empty

        # Use our new resilient checker
        # This prevents the "compute whole graph to check length" disaster
        # Pass the client if we have one (from DfHelper/DaskClientMixin)
        client = getattr(self, "dask_client", None)
        return dask_is_empty(df, dask_client=client, logger=self.logger)
