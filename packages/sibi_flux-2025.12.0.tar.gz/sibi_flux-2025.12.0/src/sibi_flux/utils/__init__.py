from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from . import parquet_saver  # noqa: F401
    from . import clickhouse_writer  # noqa: F401
    from . import boilerplate  # noqa: F401
    from .date_utils import BusinessDays, FileAgeChecker, DateUtils
    from .data_utils import DataUtils
    from .common import ensure_slash
    from .retry import with_retry


__all__ = [
    "BusinessDays",
    "FileAgeChecker",
    "DateUtils",
    "DataUtils",
    "ensure_slash",
    "with_retry",
]
_SUBMODULES = {
    "parquet_saver",
    "clickhouse_writer",
    "boilerplate",
}

_EXPORTS = {
    "BusinessDays": ".date_utils",
    "FileAgeChecker": ".date_utils",
    "DateUtils": ".date_utils",
    "DataUtils": ".data_utils",
    "ensure_slash": ".common",
    "with_retry": ".retry",
}


def __getattr__(name: str):
    if name in _SUBMODULES:
        import importlib

        return importlib.import_module(f".{name}", __package__)

    if name in _EXPORTS:
        import importlib

        module_path = _EXPORTS[name]
        module = importlib.import_module(module_path, __package__)
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = list(_SUBMODULES) + list(_EXPORTS.keys())
