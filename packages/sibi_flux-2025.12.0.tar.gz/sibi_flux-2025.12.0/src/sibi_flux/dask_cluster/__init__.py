"""
Dask Resilience - A module for robust Dask operations with automatic recovery.
"""

from .core import (
    safe_compute,
    safe_persist,
    safe_gather,
    safe_wait,
    dask_is_empty,
    dask_is_probably_empty,
    dask_is_empty_truthful,
    UniqueValuesExtractor,
)

from .client_manager import (
    DaskClientMixin,
    get_persistent_client,
    shared_dask_session,
    force_close_persistent_client,
)

from .async_core import (
    async_compute,
    async_persist,
)

# Define public API
__all__ = [
    # Core operations
    "safe_compute",
    "safe_persist",
    "safe_gather",
    "safe_wait",
    "dask_is_empty",
    "dask_is_probably_empty",
    "dask_is_empty_truthful",
    "UniqueValuesExtractor",
    # Client management
    "DaskClientMixin",
    "get_persistent_client",
    "shared_dask_session",
    "force_close_persistent_client",
    # Async operations
    "async_compute",
    "async_persist",
]
