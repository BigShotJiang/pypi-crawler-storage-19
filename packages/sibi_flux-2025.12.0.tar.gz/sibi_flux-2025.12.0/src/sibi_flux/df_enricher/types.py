"""
Enricher Types module.

Type definitions for the DataFrame enrichment subsystem.
"""

from __future__ import annotations

import pandas as pd
import dask.dataframe as dd

DdfLike = dd.DataFrame | pd.DataFrame
