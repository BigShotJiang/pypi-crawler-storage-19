from __future__ import annotations

from typing import Optional, ClassVar, Type
import dask.dataframe as dd

from sibi_flux.core.managed_resource import ManagedResource
from sibi_flux.utils.boilerplate.hybrid_data_loader import HybridDataLoader
from sibi_flux.logger import Logger


class Dataset(ManagedResource):
    """
    Base class for Hybrid Datasets.
    Merges historical (Parquet) and live (Datacube) data.
    """

    # Declarative Configuration
    historical_reader: ClassVar[Optional[Type]] = None
    live_reader: ClassVar[Optional[Type]] = None
    date_field: ClassVar[str] = ""

    def __init__(
        self, start_date: str, end_date: str, logger: Optional[Logger] = None, **kwargs
    ):
        super().__init__(logger=logger, **kwargs)
        self.start_date = start_date
        self.end_date = end_date
        self.df: Optional[dd.DataFrame] = None

        # Ensure configuration is present
        if not self.date_field:
            raise ValueError(f"{self.__class__.__name__} must define date_field.")
        if not self.historical_reader and not self.live_reader:
            raise ValueError(
                f"{self.__class__.__name__} must define at least one reader."
            )

    def load(self, *, source: str = "auto", **kwargs) -> dd.DataFrame:
        """
        Synchronous wrapper for aload.
        Use this when using Dataset as a provider_class in a synchronous context (e.g. BaseArtifact.load).
        """
        import asyncio
        import threading

        # Check if we are in a loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # If we are in a running loop, we can't use asyncio.run().
            # We must run in a separate thread to block this sync call without blocking the loop.
            # This is a common pattern when bridging sync -> async in a running loop.
            if threading.current_thread() is threading.main_thread():
                # Ideally we shouldn't block main thread loop, but .load() contract is blocking.
                # The safest way is a thread-pool runner.
                from concurrent.futures import ThreadPoolExecutor

                with ThreadPoolExecutor() as pool:
                    future = pool.submit(
                        lambda: asyncio.run(self.aload(source=source, **kwargs))
                    )
                    return future.result()
            else:
                # We are in a thread, so create a new loop for this thread?
                # Or just run_coroutine_threadsafe if we had access to the main loop,
                # but here we just want to run it.
                return asyncio.run(self.aload(source=source, **kwargs))
        else:
            return asyncio.run(self.aload(source=source, **kwargs))

    async def aload(self, *, source: str = "auto", **kwargs) -> dd.DataFrame:
        """
        Asynchronously loads data.
        source: 'auto' (default), 'live', 'historical'
        """
        self.logger.info(
            f"Loading {self.__class__.__name__} [{source}] from {self.start_date} to {self.end_date}"
        )

        try:
            if source == "auto":
                if self.historical_reader and self.live_reader:
                    self.df = await self._load_hybrid(**kwargs)
                elif self.live_reader:
                    self.df = await self._load_live(**kwargs)
                elif self.historical_reader:
                    self.df = await self._load_historical(**kwargs)
            elif source == "live":
                self.df = await self._load_live(**kwargs)
            elif source == "historical":
                self.df = await self._load_historical(**kwargs)
            else:
                raise ValueError(f"Invalid source: {source}")

            # Hook for post-processing
            self.df = self._post_process(self.df)

            self.logger.debug(
                f"{self.__class__.__name__} loaded. Meta: {self.df._meta.columns.tolist()}"
            )
            return self.df

        except Exception as e:
            self.logger.error(f"Failed to load {self.__class__.__name__}: {str(e)}")
            raise e

    async def _load_hybrid(self, **kwargs) -> dd.DataFrame:
        loader = HybridDataLoader(
            start_date=self.start_date,
            end_date=self.end_date,
            historical_reader=self.historical_reader,
            live_reader=self.live_reader,
            date_field=self.date_field,
            logger=self.logger,
            debug=self.debug,
        )
        return await loader.aload(**kwargs)

    async def _load_live(self, **kwargs) -> dd.DataFrame:
        if not self.live_reader:
            raise ValueError("No live_reader configured.")

        # Instantiate and load
        reader = self.live_reader(logger=self.logger, debug=self.debug)
        # Use date filtering if supported by kwargs mapping or manual filter
        # For now, we assume the reader handles kwargs or we pass explicit date params if needed
        # But Datacube normally filters by kwargs like `date_field__date`
        # We'll rely on kwargs passing, but we might want to inject date filters like HybridDataLoader does

        # Inject standard date filters if enabled
        # But HybridDataLoader does specific splitting. Here we might just want "load everything in range"
        # Since this is "load live", it typically means "from DB".
        # We should probably construct the date range filter manually.
        filter_kwargs = kwargs.copy()
        if self.date_field and self.start_date and self.end_date:
            filter_kwargs[f"{self.date_field}__date__range"] = [
                self.start_date,
                self.end_date,
            ]

        return await reader.aload(**filter_kwargs)

    async def _load_historical(self, **kwargs) -> dd.DataFrame:
        if not self.historical_reader:
            raise ValueError("No historical_reader configured.")

        reader = self.historical_reader(
            parquet_start_date=self.start_date,
            parquet_end_date=self.end_date,
            logger=self.logger,
            debug=self.debug,
        )
        return await reader.aload(**kwargs)

    def _post_process(self, df: dd.DataFrame) -> dd.DataFrame:
        """
        Override to apply custom post-processing, index resetting, or validation.
        """
        return df
