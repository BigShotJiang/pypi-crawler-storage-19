from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .router import BaseMCPRouter
    from .client import GenericMcpClient

def __getattr__(name: str):
    if name in ("BaseMCPRouter", "McpRouter"):
        try:
            from .router import BaseMCPRouter
            return BaseMCPRouter
        except ImportError as e:
            raise ImportError("Optional dependency 'mcp' (and 'fastapi') missing. Install 'sibi-flux[mcp]'.") from e
    if name in ("GenericMcpClient", "McpClient"):
        try:
            from .client import GenericMcpClient
            return GenericMcpClient
        except ImportError as e:
            raise ImportError("Optional dependency 'mcp' (and 'httpx') missing. Install 'sibi-flux[mcp]'.") from e
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# Aliases for cleaner usage
# Note: In lazy loading, we handle aliases in __getattr__ logic above by checking matching names


__all__ = ["BaseMCPRouter", "McpRouter", "GenericMcpClient", "McpClient"]
