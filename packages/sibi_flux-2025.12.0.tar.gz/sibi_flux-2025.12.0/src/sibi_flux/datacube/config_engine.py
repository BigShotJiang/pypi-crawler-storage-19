import re
import yaml
from pathlib import Path
from typing import Literal, Optional, Any
from collections.abc import Mapping, Sequence
from pydantic import BaseModel

# --- Schema Definitions ---


class GlobalSettings(BaseModel):
    cubes_root_path: str
    fields_module_root: str
    default_db_conn: str
    env_file: Optional[str] = ".env.linux"
    exclusions: list[str] = []


class DiscoveryRule(BaseModel):
    pattern: str
    match_type: Literal["prefix", "exact", "regex"] = "prefix"
    domain: str
    output_template: str

    # Optional: Override the DB connection for specific tables
    db_conn_override: Optional[str] = None


class GeneratorConfig(BaseModel):
    version: float
    settings: GlobalSettings
    discovery_rules: list[DiscoveryRule]


# --- Logic Engine ---


class ConfigurationEngine:
    def __init__(self, config_path: str = "generator_config.yaml"):
        # Resolve config path relative to this file if not absolute
        path = Path(config_path)
        if not path.is_absolute():
            path = Path(__file__).parent / config_path

        self.config_path = path
        self.config = self._load_config()

    def _load_config(self) -> GeneratorConfig:
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {self.config_path}")

        with open(self.config_path, "r") as f:
            raw_data = yaml.safe_load(f)
        return GeneratorConfig(**raw_data)

    def resolve_table(self, table_name: str) -> Optional[dict[str, Any]]:
        """
        Iterates through rules to find a match.
        Returns a dict with resolved paths and metadata.
        """
        # 1. Check Global Exclusions
        for pattern in self.config.settings.exclusions:
            # We assume exclusions are regex patterns for flexibility
            if re.search(pattern, table_name):
                return None

        # 2. Check Rules
        for rule in self.config.discovery_rules:
            match_data = self._check_match(rule, table_name)
            if match_data is not None:
                return self._build_result(rule, table_name, match_data)

        return None  # No match found

    def _check_match(
        self, rule: DiscoveryRule, table_name: str
    ) -> Optional[dict[str, str]]:
        """
        Checks if rule matches table_name.
        Returns capturing groups dict if match (empty dict for non-regex matches), None otherwise.
        """
        if rule.match_type == "exact":
            if table_name == rule.pattern:
                return {}

        elif rule.match_type == "prefix":
            if table_name.startswith(rule.pattern):
                return {}

        elif rule.match_type == "regex":
            m = re.search(rule.pattern, table_name)
            if m:
                # Combine numbered groups (as strings) and named groups
                groups = {str(i + 1): g for i, g in enumerate(m.groups())}
                groups.update(m.groupdict())
                return groups

        return None

    def _build_result(
        self, rule: DiscoveryRule, table_name: str, groups: dict[str, str]
    ) -> dict[str, Any]:
        """Constructs the final paths based on global settings + rule + captured groups"""

        # 1. Resolve Output Subpath with Template Substitution
        # Supports {feature}, {1}, etc.
        try:
            subpath = rule.output_template.format(**groups)
        except KeyError:
            # Fallback for safe substitution if keys missing? Or let it raise?
            # Let's try to be safe but warn? For now, strict formatting.
            subpath = rule.output_template

        # 2. Resolve Physical Path
        root = Path(self.config.settings.cubes_root_path)
        full_output_path = str(root / subpath)

        # 3. Resolve Field Map Path (Smart Guessing)
        # e.g., solutions.conf.transforms.fields.logistics.asm_tracking_X.field_map
        field_map_module = (
            f"{self.config.settings.fields_module_root}."
            f"{rule.domain}.{table_name}.field_map"
        )

        return {
            "domain": rule.domain,
            "path": full_output_path,  # 'path' key is expected by generator
            "save_to_path": full_output_path,
            "field_map": field_map_module,  # 'field_map' template logic relies on discovery result often
            "connection_obj": rule.db_conn_override
            or self.config.settings.default_db_conn,
        }


# --- Module Level Interface ---

_ENGINE = None


def get_engine() -> ConfigurationEngine:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = ConfigurationEngine()
    return _ENGINE


def match_rule(table_name: str) -> Optional[dict[str, str]]:
    """
    Finds the first matching rule for a table name.
    """
    engine = get_engine()
    return engine.resolve_table(table_name)
