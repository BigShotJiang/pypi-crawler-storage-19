import yaml
import os
from typing import Set, Dict, Any, Optional
from sqlalchemy import create_engine, inspect
from rich.console import Console

# Import the ConfigurationEngine
from .config_engine import ConfigurationEngine

console = Console()


class DiscoveryOrchestrator:
    def __init__(
        self,
        config_path: str = "generator_config.yaml",
        whitelist_path: str = "discovery_whitelist.yaml",
        registry_path: str = "datacube_registry.yaml",
        db_connection_str: Optional[str] = None,
    ):

        self.config_engine = ConfigurationEngine(config_path)

        self.whitelist_path = whitelist_path
        self.registry_path = registry_path
        self.db_url = db_connection_str

    def run(self, dry_run: bool = False, prune: bool = False):
        """
        Executes the 4-step discovery workflow.
        """
        console.rule("[bold blue]Step 1: Read Schema[/]")
        db_tables = self._step_1_read_schema()

        console.rule("[bold blue]Step 2: Read Whitelist[/]")
        target_tables = self._step_2_apply_whitelist(db_tables)

        console.rule("[bold blue]Step 3: Apply Discovery Rules[/]")
        new_registry_entries = self._step_3_apply_rules(target_tables)

        console.rule("[bold blue]Step 4: Generate Registry[/]")
        self._step_4_update_registry(new_registry_entries, dry_run, prune)

    # --- Step 1: Read Schema ---
    def _step_1_read_schema(self) -> Set[str]:
        """Introspects the database to get the raw list of actual tables."""
        if not self.db_url:
            raise ValueError("No database connection string provided.")

        try:
            engine = create_engine(self.db_url)
            inspector = inspect(engine)
            tables = set(inspector.get_table_names())
            console.print(f"Found [green]{len(tables)}[/] tables in the database.")
            return tables
        except Exception as e:
            console.print(f"[red]Error connecting to DB: {e}[/red]")
            raise

    # --- Step 2: Read Whitelist ---
    def _step_2_apply_whitelist(self, db_tables: Set[str]) -> Set[str]:
        """
        Intersects the DB tables with the whitelist.
        If NO whitelist file exists, we default to ALL tables (Pure Rule-Driven).
        """
        if not os.path.exists(self.whitelist_path):
            console.print(
                "[dim]No whitelist file found. Proceeding in Rule-Driven Mode (using configurator exclusions).[/dim]"
            )
            return db_tables

        with open(self.whitelist_path, "r") as f:
            data = yaml.safe_load(f) or {}

        # Support whitelist as list of strings or dict keys under 'tables' key usually
        if isinstance(data, dict) and "tables" in data:
            raw = data["tables"]
        else:
            raw = data

        if isinstance(raw, dict):
            whitelisted_tables = set(raw.keys())
        elif isinstance(raw, list):
            whitelisted_tables = set(raw)
        else:
            whitelisted_tables = set()

        if not whitelisted_tables:
            console.print(
                "[yellow]Whitelist found but empty. Processing ALL tables.[/]"
            )
            return db_tables

        # 1. Validation: Whitelisted items missing from DB
        missing = whitelisted_tables - db_tables
        if missing:
            console.print(
                f"[red]Warning: {len(missing)} tables in whitelist not found in DB:[/]"
            )
            for t in missing:
                console.print(f"  - {t}")

        # 2. Filtering: Only process tables that exist in both
        valid_tables = db_tables.intersection(whitelisted_tables)
        console.print(
            f"Proceeding with [green]{len(valid_tables)}[/] whitelisted tables."
        )

        return valid_tables

    # --- Step 3: Apply Rules ---
    def _step_3_apply_rules(self, tables: Set[str]) -> Dict[str, Any]:
        """
        Runs the ConfigurationEngine against the filtered table list.
        Returns a dictionary ready for the registry.
        """
        registry_updates = {}

        for table in tables:
            # delegated to the Logic Engine
            match_result = self.config_engine.resolve_table(table)

            if match_result:
                registry_updates[table] = {
                    "path": match_result["path"],
                    "field_map": match_result["field_map"],
                    "connection_obj": match_result["connection_obj"],
                }
            else:
                console.print(f"[dim]Skipping {table}: No matching discovery rule.[/]")

        console.print(
            f"Mapped [green]{len(registry_updates)}[/] tables to configuration rules."
        )
        return registry_updates

    # --- Step 4: Generate Datacube Registry ---
    def _step_4_update_registry(
        self, new_entries: Dict[str, Any], dry_run: bool, prune: bool
    ):
        """
        Merges new entries into existing registry and saved.
        """
        # Load existing
        current_data = {}
        if os.path.exists(self.registry_path):
            with open(self.registry_path, "r") as f:
                current_data = yaml.safe_load(f) or {}

        if "tables" not in current_data:
            current_data["tables"] = {}

        if prune:
            current_data["tables"] = new_entries
            console.print(
                "[yellow]Prune active: Registry replaced with discovery results.[/]"
            )
        else:
            # Merge: Update existing keys, add new ones.
            current_data["tables"].update(new_entries)

        # Sort tables for readability
        current_data["tables"] = dict(sorted(current_data["tables"].items()))

        if dry_run:
            console.print("[yellow]DRY RUN: Registry would be updated with keys:[/]")
            console.print(list(new_entries.keys()))
        else:
            with open(self.registry_path, "w") as f:
                yaml.dump(current_data, f, sort_keys=False)
            console.print(f"[bold green]Success! Updated {self.registry_path}[/]")
