from typing import List, MutableMapping, Optional
from pathlib import Path
from .field_registry import GlobalFieldRegistry

# Singleton instance to avoid reloading YAML multiple times
_SHARED_REGISTRY: Optional[GlobalFieldRegistry] = None


class FieldMapFactory:
    """
    Factory for creating field translation maps.
    Uses a shared GlobalFieldRegistry instance to translate field names.
    """

    @classmethod
    def create(cls, table_name: str, columns: List[str]) -> MutableMapping[str, str]:
        """
        Creates a field map dictionary for the given table and columns.

        Args:
            table_name: The name of the database table (for context/logging if needed).
            columns: List of column names to translate.

        Returns:
            A MutableMapping (dict) where key=column_name, value=translated_name.
        """
        registry = cls._get_registry()

        mapping = {}
        for col in columns:
            # We use the registry solely for lookups.
            # If the key isn't there, we default to identity.
            if col in registry:
                mapping[col] = registry[col]
            else:
                mapping[col] = col

        return mapping

    @classmethod
    def _get_registry(cls) -> GlobalFieldRegistry:
        global _SHARED_REGISTRY
        if _SHARED_REGISTRY is None:
            # Assume standard location relative to project root
            registry_path = Path("solutions/conf/global_field_translations.yaml")
            _SHARED_REGISTRY = GlobalFieldRegistry(registry_path)

        return _SHARED_REGISTRY
