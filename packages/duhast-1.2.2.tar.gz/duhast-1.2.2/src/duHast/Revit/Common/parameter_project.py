"""
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Project parameters related methods
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

"""
#
# License:
#
#
# Revit Batch Processor Sample Code
#
# BSD License
# Copyright 2025, Jan Christel
# All rights reserved.

# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

# - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# - Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# This software is provided by the copyright holder "as is" and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed.
# In no event shall the copyright holder be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits;
# or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.
#
#
#


def get_project_parameter_bindings(doc):
    """
    Get all project parameter bindings in the document.
    
    :param doc: Current Revit document
    :type doc: Autodesk.Revit.DB.Document
    
    :return: List of parameter bindings
    :rtype: list of Autodesk.Revit.DB.ParameterBinding
    """
    
    map = doc.ParameterBindings
    it = map.ForwardIterator()
    it.Reset()

    result = []  

    while it.MoveNext():
        
        binding = it.Current  

        result.append(binding)

    return result


def get_project_parameter_definitions(doc):
    """
    Get all project parameter definitions in the document.
    
    :param doc: Current Revit document
    :type doc: Autodesk.Revit.DB.Document
    
    :return: List of parameter bindings
    :rtype: list of Autodesk.Revit.DB.ParameterBinding
    """
    
    map = doc.ParameterBindings
    it = map.ForwardIterator()
    it.Reset()

    result = []  

    while it.MoveNext():
        definition = it.Key
       
        result.append(definition)

    return result


def get_project_parameter_definition_by_name(doc,parameter_name):
    """
    Get a project parameter definition by name.
    
    :param doc: Current Revit document
    :type doc: Autodesk.Revit.DB.Document
    
    :param parameter_name: Name of the parameter to search for
    :type parameter_name: str
    
    :return: Parameter definition if found, None otherwise
    :rtype: Autodesk.Revit.DB.Definition or None
    """
    
    definitions = get_project_parameter_definitions(doc)
    
    for definition in definitions:
        if definition.Name == parameter_name:
            return definition
    
    return None