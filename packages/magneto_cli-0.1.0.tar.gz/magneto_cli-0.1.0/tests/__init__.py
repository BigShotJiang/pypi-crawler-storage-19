"""
Test suite for Magneto
"""

