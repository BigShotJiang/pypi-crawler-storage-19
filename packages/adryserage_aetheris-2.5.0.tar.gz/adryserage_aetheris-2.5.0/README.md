# Aetheris by Adryan - Multi-Agent Code Analysis System

[![PyPI version](https://badge.fury.io/py/adryserage-aetheris.svg)](https://badge.fury.io/py/adryserage-aetheris)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub Actions](https://img.shields.io/github/actions/workflow/status/adryserage/code_reviewer/code-review.yml?label=CI)](https://github.com/adryserage/code_reviewer/actions)
[![PyPI downloads](https://img.shields.io/pypi/dm/adryserage-aetheris.svg)](https://pypi.org/project/adryserage-aetheris/)

Automated code analysis system using multiple cooperating AI agents to provide comprehensive quality, security, and architecture analysis of your codebase.

## Quick Start

```bash
# Install
pip install adryserage-aetheris

# Configure
echo "GEMINI_API_KEY=your_key_here" > .env

# Analyze
aetheris analysis
```

## Commands

| Command | Description | Documentation |
|---------|-------------|---------------|
| `aetheris analysis` | Full codebase analysis | [analysis.md](docs/commands/analysis.md) |
| `aetheris fix` | Fix bugs with Claude Code | [fix.md](docs/commands/fix.md) |
| `aetheris pr` | Review GitHub Pull Requests | [pr-review.md](docs/commands/pr-review.md) |
| `aetheris user-story` | Analyze user flows | [user-story.md](docs/commands/user-story.md) |
| `aetheris issues` | Create GitHub issues from analysis | [issues.md](docs/commands/issues.md) |
| `aetheris pr-gen` | Generate PRs with AI fixes | [pr-gen.md](docs/commands/pr-gen.md) |

## Features

### Multi-Provider AI
- **Providers**: Gemini, Claude (Anthropic), OpenAI
- **Consensus Mode**: Only report issues found by ALL providers
- **Structured Outputs**: JSON responses validated via Pydantic

### Analysis Capabilities
- Security vulnerabilities (injections, secrets, weak crypto)
- Code quality and metrics
- Architecture review
- Dependency CVE scanning via OSV API
- CWE/OWASP classifications

### Performance
- **Smart Cache**: 60-80% API cost reduction (git SHA based)
- **Parallelization**: Dependency graph-based
- **Context Caching**: 50% cost reduction (Gemini)
- **Batch API**: 50% price reduction (Gemini)

### Automation
- GitHub Actions integration
- Auto-fix with Claude Code
- GitHub issue creation
- PR generation with fixes

## Documentation

| Topic | Link |
|-------|------|
| Installation | [docs/installation.md](docs/installation.md) |
| Configuration | [docs/configuration.md](docs/configuration.md) |
| AI Providers | [docs/ai-providers.md](docs/ai-providers.md) |
| Commands Reference | [docs/commands/README.md](docs/commands/README.md) |
| Analysis Agents | [docs/agents.md](docs/agents.md) |
| Features | [docs/features.md](docs/features.md) |
| GitHub Actions | [docs/github-actions.md](docs/github-actions.md) |
| Extensibility | [docs/PLUGINS.md](docs/PLUGINS.md) |
| Troubleshooting | [docs/troubleshooting.md](docs/troubleshooting.md) |

## Analysis Agents

Aetheris uses **6 specialized agents**:

1. **Code Analysis Expert** - Individual file analysis
2. **Architect Analysis Agent** - Architecture overview
3. **Security Analysis Agent** - Vulnerability detection
4. **Code Metrics Agent** - Complexity and duplication
5. **Dependency Vulnerability Agent** - CVE scanning
6. **Quality Assurance Agent** - Final synthesis

## Basic Configuration

Create `.env` file:

```env
# AI Provider (gemini, openai, claude)
AI_PROVIDER=gemini
GEMINI_API_KEY=your_key_here

# Optional
AI_MODEL=gemini-2.5-pro
BATCH_SIZE=10
ENABLE_CACHE=true
```

See [Configuration Guide](docs/configuration.md) for all options.

## Example Workflows

### Full Analysis
```bash
aetheris analysis
```

### Analyze and Fix Bugs
```bash
aetheris fix --analyze-first --auto --batch-size 10
```

### PR Review with Multiple Providers
```bash
aetheris pr --url https://github.com/owner/repo/pull/123 --providers gemini,claude
```

### Create Issues and Generate Fix PRs
```bash
aetheris issues
aetheris pr-gen --link-issues
```

## Project Structure

```
aetheris/
├── src/
│   ├── core/           # Main modules (analyzer, orchestrator, cache)
│   ├── models/         # Data models
│   ├── agents/         # AI agents
│   └── services/       # Utilities
├── docs/               # Documentation
├── scripts/            # Utility scripts
└── main.py            # Entry point
```

## Supported Languages

Python, TypeScript, JavaScript, Dart/Flutter, Java, Kotlin, Swift, Go, Rust, C/C++, C#, PHP, Ruby, and more.

## Output

Reports generated in `docs/analyses/`:
- Individual file reports
- Architecture overview
- Quality assurance report
- Vulnerabilities report
- Performance metrics (JSON)

## License

MIT License

## Contributing

Contributions welcome! Please open an issue or pull request.

## Resources

- [Repository](https://github.com/adryserage/aetheris)
- [PyPI Package](https://pypi.org/project/adryserage-aetheris/)
- [Gemini API](https://ai.google.dev/docs)
- [OpenAI API](https://platform.openai.com/docs)
- [Claude API](https://docs.anthropic.com)
