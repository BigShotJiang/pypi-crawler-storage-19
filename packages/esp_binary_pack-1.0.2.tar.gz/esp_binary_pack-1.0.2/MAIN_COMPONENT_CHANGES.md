# Main Component Changes

## Overview

In version 1.0.0, we have unified the handling of the `main` component with other prebuilt components. This simplifies the directory structure and makes the behavior more consistent.

## Old Behavior (< 1.0.0)

Previously, the `main` component was treated specially:
- The `main` library was often kept in the root `main/` directory or handled differently than other components.
- This led to inconsistencies where `main` might be built from source while others were prebuilt, or vice versa, in a confusing manner.

## New Behavior (>= 1.0.0)

Now, the `main` component follows the same rules as any other component:

1.  **Prebuilt Library**: The `libmain.a` file is extracted to `prebuild_components/main/libmain.a`.
2.  **Stub Main**: The original `main/` directory in the generated project now contains a "stub" `main.c` and a `CMakeLists.txt` that links to the prebuilt library.
3.  **Registration**: The `prebuild_components/main` component is automatically added to the build via `EXTRA_COMPONENT_DIRS`.

## Benefits

- **Consistency**: All prebuilt code lives in `prebuild_components/`.
- **Cleanliness**: The source tree `main/` is kept clean and only serves as an entry point to link the prebuilt logic.
- **Flexibility**: Easier to exclude `main` from prebuilding if desired (by creating a different rule or exclude list entry in the future).
