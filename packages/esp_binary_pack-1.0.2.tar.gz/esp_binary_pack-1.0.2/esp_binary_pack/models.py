"""
Data models for ESP-IDF Binary Pack Script
"""

from dataclasses import dataclass
from typing import List


class ComponentInfo:
    """Component information from project_description.json"""
    def __init__(self, name: str, data: dict):
        self.name = name
        self.dir = data.get('dir', '')
        self.reqs = data.get('reqs', [])
        self.priv_reqs = data.get('priv_reqs', [])
        self.include_dirs = data.get('include_dirs', [])
        self.lib = data.get('lib', '')
        self.file = data.get('file', '')  # Library file path (generator expression)
        self.type = data.get('type', 'LIBRARY')
        self.sources = data.get('sources', [])


@dataclass
class ProjectConfig:
    """Project configuration parameters"""
    project_path: str
    idf_path: str
    build_dir: str
    output_dir: str
    extract_headers: bool
    exclude_list: List[str]
    include_list: List[str]
    pack_managed_components: bool = False
    project_name: str = 'esp_project'
    project_ver: str = '1.0'

