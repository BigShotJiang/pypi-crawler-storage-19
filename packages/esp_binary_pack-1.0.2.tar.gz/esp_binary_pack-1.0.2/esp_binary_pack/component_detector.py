"""
Component detection and filtering utilities for ESP-IDF Binary Pack Script
"""

import os
import re
from typing import Dict, List, Set, Tuple, Optional

from .models import ComponentInfo


def is_user_component(component_dir: str, idf_path: str) -> bool:
    """Check if component is a user component (not from IDF_PATH/components)"""
    idf_components = os.path.join(idf_path, 'components')
    idf_components = os.path.normpath(idf_components)
    component_dir = os.path.normpath(component_dir)
    
    try:
        # Check if component_dir is under idf_components
        common_path = os.path.commonpath([idf_components, component_dir])
        if os.path.normpath(common_path) == os.path.normpath(idf_components):
            # Component is under IDF components, not a user component
            return False
        return True
    except (ValueError, OSError):
        # Different drives on Windows or no common path
        return True


def is_managed_component(component_dir: str) -> bool:
    """
    Check if component is from managed_components directory
    
    Args:
        component_dir: Component directory path
        
    Returns:
        True if component is from managed_components, False otherwise
    """
    component_dir = os.path.normpath(component_dir)
    path_parts = component_dir.split(os.sep)
    
    # Check if 'managed_components' is in the path
    return 'managed_components' in path_parts


def is_prebuilt_component(component_dir: str) -> bool:
    """
    Check if a component is a prebuilt component by examining its CMakeLists.txt
    
    A component is considered prebuilt if:
    1. Its CMakeLists.txt contains 'add_prebuilt_library'
    2. The library path in add_prebuilt_library points to component directory (not build dir)
    
    Returns:
        True if component is prebuilt, False otherwise
    """
    cmake_file = os.path.join(component_dir, 'CMakeLists.txt')
    if not os.path.exists(cmake_file):
        return False
    
    try:
        with open(cmake_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Check if contains add_prebuilt_library
        if 'add_prebuilt_library' not in content:
            return False
        
        # Patterns that indicate library path points to component directory
        # These patterns are used in add_prebuilt_library calls to reference
        # libraries within the component directory
        component_dir_patterns = [
            'CMAKE_CURRENT_SOURCE_DIR',
            'CMAKE_CURRENT_LIST_DIR',
            '${CMAKE_CURRENT_SOURCE_DIR}',
            '${CMAKE_CURRENT_LIST_DIR}',
            'COMPONENT_PATH',
            '${COMPONENT_PATH}',
            'COMPONENT_DIR',
            '${COMPONENT_DIR}',
        ]
        
        # Patterns that indicate library path points to build directory (NOT prebuilt)
        build_dir_patterns = [
            'CMAKE_BINARY_DIR',
            'BUILD_DIR',
            'CMAKE_CURRENT_BINARY_DIR',
            '${CMAKE_BINARY_DIR}',
            '${BUILD_DIR}',
            '${CMAKE_CURRENT_BINARY_DIR}',
        ]
        
        # Extract all add_prebuilt_library calls, handling multi-line cases
        # Strategy: find all add_prebuilt_library calls and check their paths
        lines = content.split('\n')
        in_add_prebuilt = False
        add_prebuilt_lines = []
        open_parens = 0
        
        for line in lines:
            stripped_line = line.strip()
            
            # Check if this line starts a new add_prebuilt_library call
            if 'add_prebuilt_library' in stripped_line:
                in_add_prebuilt = True
                add_prebuilt_lines = [line]
                # Count parentheses in this line
                open_parens = stripped_line.count('(') - stripped_line.count(')')
                # If balanced, check immediately
                if open_parens == 0:
                    call_content = line
                    if any(pattern in call_content for pattern in component_dir_patterns):
                        if not any(bp in call_content for bp in build_dir_patterns):
                            return True
                    in_add_prebuilt = False
                    add_prebuilt_lines = []
            elif in_add_prebuilt:
                add_prebuilt_lines.append(line)
                open_parens += line.count('(') - line.count(')')
                # If parentheses are balanced, we have a complete call
                if open_parens == 0:
                    call_content = '\n'.join(add_prebuilt_lines)
                    # Check if this call uses component directory patterns
                    if any(pattern in call_content for pattern in component_dir_patterns):
                        if not any(bp in call_content for bp in build_dir_patterns):
                            return True
                    in_add_prebuilt = False
                    add_prebuilt_lines = []
        
        # Fallback: if file contains add_prebuilt_library and component directory patterns,
        # and no build directory patterns, assume it's prebuilt
        # This handles cases where regex matching might fail
        has_component_pattern = any(pattern in content for pattern in component_dir_patterns)
        has_build_pattern = any(pattern in content for pattern in build_dir_patterns)
        
        if has_component_pattern and not has_build_pattern:
            return True
        
        # Also try regex-based matching as a fallback
        # Match add_prebuilt_library calls (handle multi-line with DOTALL)
        matches = re.findall(
            r'add_prebuilt_library\s*\([^)]*(?:\n[^)]*)*\)',
            content,
            re.MULTILINE | re.DOTALL
        )
        
        for match in matches:
            # Check if path contains component directory patterns
            if any(pattern in match for pattern in component_dir_patterns):
                if not any(bp in match for bp in build_dir_patterns):
                    return True
        
        return False
    except Exception as e:
        print(f"Warning: Failed to check if component is prebuilt: {e}")
        return False


def filter_user_components(
    components: Dict[str, ComponentInfo],
    idf_path: str,
    exclude_list: List[str],
    include_list: List[str]
) -> Tuple[Dict[str, ComponentInfo], Dict[str, ComponentInfo]]:
    """
    Filter components to only include user components
    
    Returns:
        Tuple of (included_components, excluded_components)
    """
    filtered = {}
    excluded = {}
    
    for name, comp in components.items():
        # Check if it's a user component
        if not is_user_component(comp.dir, idf_path):
            continue
        
        # Check exclude list
        if name in exclude_list and name not in include_list:
            excluded[name] = comp
            continue
        
        # Check if forced to include
        if name in include_list:
            filtered[name] = comp
            continue
        
        # Default: include all user components
        filtered[name] = comp
    
    return filtered, excluded


def merge_dependencies(components: Dict[str, ComponentInfo]) -> Dict[str, Set[str]]:
    """Merge all component dependencies"""
    all_reqs = set()
    all_priv_reqs = set()
    
    for comp in components.values():
        all_reqs.update(comp.reqs)
        all_priv_reqs.update(comp.priv_reqs)
    
    # Filter out components that are in our binary_libs
    component_names = set(components.keys())
    filtered_reqs = all_reqs - component_names
    filtered_priv_reqs = all_priv_reqs - component_names
    
    return {
        'reqs': filtered_reqs,
        'priv_reqs': filtered_priv_reqs
    }


def collect_components_to_copy_as_is(
    initial_components: Dict[str, ComponentInfo],
    all_components: Dict[str, ComponentInfo],
    idf_path: str,
    lib_mapping: Dict[str, Tuple[str, str]],
    excluded_components: Dict[str, ComponentInfo],
    visited: Optional[Set[str]] = None
) -> Dict[str, Tuple[ComponentInfo, str]]:
    """
    Recursively collect all components that need to be copied as-is (prebuilt or excluded)
    and their dependencies.
    
    Args:
        initial_components: Initial set of components to start from (prebuilt or excluded)
        all_components: All available components from project_description.json
        idf_path: IDF path to check if component is user component
        lib_mapping: Dictionary of components that have been packaged as libraries
        excluded_components: Dictionary of components that have been explicitly excluded
        visited: Set of component names already processed (to avoid cycles)
    
    Returns:
        Dictionary mapping component_name -> (ComponentInfo, reason)
        reason can be: 'prebuilt', 'excluded', 'no_library_found', 'dependency_of_prebuilt', 'dependency_of_excluded', 'dependency_of_no_lib'
    """
    if visited is None:
        visited = set()
    
    result = {}
    
    for comp_name, comp_info in initial_components.items():
        if comp_name in visited:
            continue
        
        visited.add(comp_name)
        
        # Determine reason for this component
        if comp_name in excluded_components:
            reason = 'excluded'
        elif is_prebuilt_component(comp_info.dir):
            reason = 'prebuilt'
        elif comp_name not in lib_mapping:
            # Component without library file
            reason = 'no_library_found'
        else:
            # This shouldn't happen for initial_components, but handle it
            reason = 'dependency'
        
        result[comp_name] = (comp_info, reason)
        
        # Recursively collect dependencies
        all_deps = set(comp_info.reqs) | set(comp_info.priv_reqs)
        
        for dep_name in all_deps:
            if dep_name in visited:
                continue
            
            # Skip ESP-IDF official components
            if dep_name in all_components:
                dep_info = all_components[dep_name]
                if not is_user_component(dep_info.dir, idf_path):
                    continue  # Skip ESP-IDF components
            
            # Skip components that are already packaged as libraries
            if dep_name in lib_mapping:
                continue
            
            # Check if dependency is a prebuilt component or excluded component
            if dep_name in all_components:
                dep_info = all_components[dep_name]
                
                # Check if it's a prebuilt component
                if is_prebuilt_component(dep_info.dir):
                    # Recursively collect this prebuilt component and its dependencies
                    sub_result = collect_components_to_copy_as_is(
                        {dep_name: dep_info},
                        all_components,
                        idf_path,
                        lib_mapping,
                        excluded_components,
                        visited
                    )
                    for sub_name, (sub_info, sub_reason) in sub_result.items():
                        if sub_name not in result:
                            # Update reason to indicate it's a dependency
                            if reason.startswith('prebuilt') or reason == 'prebuilt':
                                new_reason = 'dependency_of_prebuilt'
                            elif reason.startswith('excluded') or reason == 'excluded':
                                new_reason = 'dependency_of_excluded'
                            elif reason == 'no_library_found':
                                new_reason = 'dependency_of_no_lib'
                            else:
                                new_reason = 'dependency'
                            result[sub_name] = (sub_info, new_reason)
                
                # Check if it's an excluded component
                elif dep_name in excluded_components:
                    # Recursively collect this excluded component and its dependencies
                    sub_result = collect_components_to_copy_as_is(
                        {dep_name: dep_info},
                        all_components,
                        idf_path,
                        lib_mapping,
                        excluded_components,
                        visited
                    )
                    for sub_name, (sub_info, sub_reason) in sub_result.items():
                        if sub_name not in result:
                            result[sub_name] = (sub_info, sub_reason)
                
                # If dependency is a user component but not packaged and not excluded,
                # it needs to be copied as source code
                elif is_user_component(dep_info.dir, idf_path):
                    if dep_name not in result:
                        if reason == 'prebuilt':
                            new_reason = 'dependency_of_prebuilt'
                        elif reason == 'excluded':
                            new_reason = 'dependency_of_excluded'
                        elif reason == 'no_library_found':
                            new_reason = 'dependency_of_no_lib'
                        else:
                            new_reason = 'dependency'
                        result[dep_name] = (dep_info, new_reason)
                        
                        # Recursively collect its dependencies
                        sub_result = collect_components_to_copy_as_is(
                            {dep_name: dep_info},
                            all_components,
                            idf_path,
                            lib_mapping,
                            excluded_components,
                            visited
                        )
                        for sub_name, (sub_info, sub_reason) in sub_result.items():
                            if sub_name not in result:
                                result[sub_name] = (sub_info, sub_reason)
    
    return result

