"""
CMake parsing utilities for ESP-IDF Binary Pack Script
"""

import os
import re
from typing import Dict, List, Set, Optional


def parse_cmake_variables(content: str) -> Dict[str, str]:
    """Parse CMake variable definitions from content"""
    variables = {}
    
    # Match set(VAR_NAME value) patterns
    # Handle both single-line and multi-line set() calls
    set_pattern = r'set\s*\(\s*(\w+)\s+([^)]+)\)'
    
    for match in re.finditer(set_pattern, content, re.MULTILINE | re.DOTALL):
        var_name = match.group(1)
        var_value = match.group(2).strip()
        
        # Don't remove quotes from the entire value for multi-line values
        # Instead, process each line individually
        
        # Filter out comment lines (lines starting with #)
        # Split by newlines, filter comments, rejoin
        lines = var_value.split('\n')
        filtered_lines = []
        for line in lines:
            stripped = line.strip()
            # Skip empty lines and comment lines
            if stripped and not stripped.startswith('#'):
                # Remove inline comments (everything after #)
                if '#' in stripped:
                    # Find # that's not inside quotes
                    comment_pos = stripped.find('#')
                    # Simple check: if # is after quotes, it's likely a comment
                    # For now, just remove everything after #
                    stripped = stripped[:comment_pos].strip()
                if stripped:
                    # Remove quotes from each line (each line may have its own quotes)
                    if stripped.startswith('"') and stripped.endswith('"'):
                        stripped = stripped[1:-1]
                    elif stripped.startswith("'") and stripped.endswith("'"):
                        stripped = stripped[1:-1]
                    filtered_lines.append(stripped)
        
        # Rejoin filtered lines
        if filtered_lines:
            var_value = '\n'.join(filtered_lines)
        else:
            var_value = ''
        
        variables[var_name] = var_value
    
    return variables


def resolve_cmake_variable(var_expr: str, variables: Dict[str, str], component_dir: str, visited: Optional[Set[str]] = None) -> str:
    """
    Resolve a CMake variable expression to an actual path
    
    Args:
        var_expr: Variable expression like ${VAR_NAME} or ${CMAKE_CURRENT_LIST_DIR}
        variables: Dictionary of parsed CMake variables
        component_dir: Component directory path
        visited: Set of variables being resolved (to detect cycles)
    
    Returns:
        Resolved path relative to component directory, or "." if it's the component dir itself
    """
    if visited is None:
        visited = set()
    
    # Remove ${} wrapper
    if var_expr.startswith('${') and var_expr.endswith('}'):
        var_name = var_expr[2:-1]
    else:
        var_name = var_expr
    
    # Handle CMake built-in variables
    if var_name in ['CMAKE_CURRENT_LIST_DIR', 'CMAKE_CURRENT_SOURCE_DIR']:
        return "."
    
    # Check for circular dependency
    if var_name in visited:
        # Circular reference detected, return original expression
        return var_expr
    
    # Handle user-defined variables
    if var_name in variables:
        visited.add(var_name)
        var_value = variables[var_name]
        
        # Recursively resolve nested variables with max iterations to prevent infinite loops
        max_iterations = 10
        iteration = 0
        while '${' in var_value and iteration < max_iterations:
            iteration += 1
            # Find all variable references
            var_refs = re.findall(r'\$\{([^}]+)\}', var_value)
            if not var_refs:
                break
            
            # Track if any replacement was made
            made_replacement = False
            
            # Resolve each variable reference
            for ref_var in var_refs:
                if ref_var in ['CMAKE_CURRENT_LIST_DIR', 'CMAKE_CURRENT_SOURCE_DIR']:
                    resolved = component_dir
                    var_value = var_value.replace(f"${{{ref_var}}}", resolved)
                    made_replacement = True
                elif ref_var in variables:
                    # Recursively resolve (with cycle detection)
                    resolved = resolve_cmake_variable(f"${{{ref_var}}}", variables, component_dir, visited.copy())
                    # If resolved to ".", use component_dir
                    if resolved == ".":
                        resolved = component_dir
                    elif resolved.startswith('${'):
                        # Couldn't resolve, skip this one
                        continue
                    elif not os.path.isabs(resolved):
                        resolved = os.path.join(component_dir, resolved)
                    
                    # Replace in var_value
                    old_value = var_value
                    var_value = var_value.replace(f"${{{ref_var}}}", resolved)
                    if old_value != var_value:
                        made_replacement = True
                else:
                    # Can't resolve, skip
                    continue
            
            # If no replacement was made, break to avoid infinite loop
            if not made_replacement:
                break
        
        visited.remove(var_name)
        
        # Now var_value should be a path (possibly absolute)
        # Convert to relative path from component_dir
        if os.path.isabs(var_value):
            var_path = var_value
        else:
            var_path = os.path.join(component_dir, var_value)
        
        # Normalize the path
        var_path = os.path.normpath(var_path)
        component_dir_norm = os.path.normpath(component_dir)
        
        # If it resolves to component_dir, return "."
        if var_path == component_dir_norm:
            return "."
        
        # Otherwise, try to get relative path
        try:
            rel_path = os.path.relpath(var_path, component_dir_norm)
            if not rel_path.startswith('..'):
                return rel_path
        except (ValueError, OSError):
            pass
    
    # If we can't resolve it, return the original expression
    return var_expr


def parse_include_dirs_from_cmake(component_dir: str) -> List[str]:
    """Parse INCLUDE_DIRS from original component CMakeLists.txt and resolve variables"""
    cmake_file = os.path.join(component_dir, 'CMakeLists.txt')
    if not os.path.exists(cmake_file):
        return []
    
    try:
        with open(cmake_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # First, parse all variable definitions
        variables = parse_cmake_variables(content)
        
        # Also parse list(APPEND INCLUDE_DIRS ...) statements to get all include directories
        # This handles cases where INCLUDE_DIRS is built dynamically using list(APPEND ...)
        include_dirs_from_list_append = []
        list_append_pattern = r'list\s*\(\s*APPEND\s+INCLUDE_DIRS\s+([^)]+)\)'
        for match in re.finditer(list_append_pattern, content, re.MULTILINE | re.DOTALL):
            append_value = match.group(1).strip()
            # Resolve variables in the append value
            if '${' in append_value:
                var_pattern = r'\$\{([^}]+)\}'
                resolved_value = append_value
                for var_match in re.finditer(var_pattern, append_value):
                    var_expr = var_match.group(0)
                    resolved_dir = resolve_cmake_variable(var_expr, variables, component_dir)
                    resolved_value = resolved_value.replace(var_expr, resolved_dir)
                append_value = resolved_value
            
            # Process the directory path
            if append_value and append_value != ".":
                abs_path = os.path.normpath(os.path.join(component_dir, append_value))
                if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                    append_value = "."
                else:
                    try:
                        rel_path = os.path.relpath(abs_path, component_dir)
                        if not rel_path.startswith('..'):
                            append_value = rel_path
                    except (ValueError, OSError):
                        pass
            
            if append_value and append_value not in include_dirs_from_list_append:
                include_dirs_from_list_append.append(append_value)
        
        # Find the idf_component_register block
        register_match = re.search(
            r'idf_component_register\s*\((.*?)\)',
            content,
            re.DOTALL
        )
        
        if not register_match:
            # If no idf_component_register found, return directories from list(APPEND ...)
            return include_dirs_from_list_append if include_dirs_from_list_append else ["."]
        
        register_content = register_match.group(1)
        
        # Find INCLUDE_DIRS line(s)
        include_dirs_match = re.search(
            r'INCLUDE_DIRS\s+([^\n]+)',
            register_content,
            re.MULTILINE
        )
        
        if not include_dirs_match:
            # If no INCLUDE_DIRS in idf_component_register, return directories from list(APPEND ...)
            return include_dirs_from_list_append if include_dirs_from_list_append else ["."]
        
        include_dirs_str = include_dirs_match.group(1).strip()
        
        # Check if INCLUDE_DIRS uses a variable (e.g., ${includes_public})
        var_match = re.match(r'\$\{(\w+)\}$', include_dirs_str.strip())
        if var_match:
            # INCLUDE_DIRS uses a variable, get the variable value
            var_name = var_match.group(1)
            if var_name in variables:
                # Variable value may be multi-line, parse each line
                var_value = variables[var_name]
                # Split by newlines and process each line
                dirs = []
                for line in var_value.split('\n'):
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    # Remove quotes if present
                    if line.startswith('"') and line.endswith('"'):
                        line = line[1:-1]
                    elif line.startswith("'") and line.endswith("'"):
                        line = line[1:-1]
                    
                    # Resolve variables in the line
                    if '${' in line:
                        var_pattern = r'\$\{([^}]+)\}'
                        resolved_line = line
                        for var_match_inner in re.finditer(var_pattern, line):
                            var_expr = var_match_inner.group(0)
                            var_name_inner = var_match_inner.group(1)
                            
                            # Handle special runtime properties that can't be resolved statically
                            # These are typically obtained via idf_component_get_property
                            # For now, we skip them as they require runtime evaluation
                            if var_name_inner in ['freertos_include', 'ORIG_INCLUDE_PATH']:
                                # Skip this line as it requires runtime property resolution
                                resolved_line = None
                                break
                            
                            resolved_value = resolve_cmake_variable(var_expr, variables, component_dir)
                            if resolved_value and resolved_value != var_expr:
                                resolved_line = resolved_line.replace(var_expr, resolved_value)
                            else:
                                # Can't resolve, skip this line
                                resolved_line = None
                                break
                        if resolved_line:
                            line = resolved_line
                        else:
                            continue
                    
                    if line:
                        # Process the directory path
                        if line != ".":
                            abs_path = os.path.normpath(os.path.join(component_dir, line))
                            if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                                line = "."
                            else:
                                try:
                                    rel_path = os.path.relpath(abs_path, component_dir)
                                    if not rel_path.startswith('..'):
                                        line = rel_path
                                except (ValueError, OSError):
                                    pass
                        
                        if line:
                            dirs.append(line)
                
                # Merge with directories from list(APPEND ...)
                for append_dir in include_dirs_from_list_append:
                    if append_dir not in dirs:
                        dirs.append(append_dir)
                
                return dirs if dirs else ["."]
        
        # Parse the include directories (direct paths, not variables)
        # Handle quoted strings and multiple directories
        dirs = []
        # Match quoted strings or unquoted strings (including variables)
        for match in re.finditer(r'["\']([^"\']+)["\']|(\S+)', include_dirs_str):
            dir_str = match.group(1) or match.group(2)
            if dir_str:
                dir_str = dir_str.strip()
                
                # Resolve variables in the directory string
                if '${' in dir_str:
                    # Extract variable references
                    var_pattern = r'\$\{([^}]+)\}'
                    resolved_dir = dir_str
                    for var_match in re.finditer(var_pattern, dir_str):
                        var_expr = var_match.group(0)
                        resolved_value = resolve_cmake_variable(var_expr, variables, component_dir)
                        resolved_dir = resolved_dir.replace(var_expr, resolved_value)
                    dir_str = resolved_dir
                
                # If the resolved string contains newlines, split by newlines first
                # This handles cases where variables expand to multi-line values
                if '\n' in dir_str:
                    # Split by newlines and process each line separately
                    lines = dir_str.split('\n')
                    for line in lines:
                        line = line.strip()
                        if not line or line.startswith('#'):
                            continue
                        # Process this line as a directory (may contain multiple space-separated dirs)
                        if ' ' in line and not os.path.exists(os.path.join(component_dir, line)):
                            # Split by spaces and process each directory separately
                            split_dirs = line.split()
                            for split_dir in split_dirs:
                                split_dir = split_dir.strip()
                                if split_dir:
                                    # Process this directory
                                    if split_dir != ".":
                                        # Check if it's an absolute path that equals component_dir
                                        abs_path = os.path.normpath(os.path.join(component_dir, split_dir))
                                        if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                                            split_dir = "."
                                        else:
                                            # Try to get relative path
                                            try:
                                                rel_path = os.path.relpath(abs_path, component_dir)
                                                if not rel_path.startswith('..'):
                                                    split_dir = rel_path
                                            except (ValueError, OSError):
                                                pass
                                    
                                    if split_dir and split_dir not in dirs:
                                        dirs.append(split_dir)
                        else:
                            # Single directory path
                            if line and line != ".":
                                # Check if it's an absolute path that equals component_dir
                                abs_path = os.path.normpath(os.path.join(component_dir, line))
                                if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                                    line = "."
                                else:
                                    # Try to get relative path
                                    try:
                                        rel_path = os.path.relpath(abs_path, component_dir)
                                        if not rel_path.startswith('..'):
                                            line = rel_path
                                    except (ValueError, OSError):
                                        pass
                            
                            if line and line not in dirs:
                                dirs.append(line)
                    continue
                
                # If the resolved string contains multiple space-separated paths,
                # split them into separate directories
                # This handles cases like: COMPONENT_ADD_INCLUDEDIRS = "include interface device/include"
                if ' ' in dir_str and not os.path.exists(os.path.join(component_dir, dir_str)):
                    # Split by spaces and process each directory separately
                    split_dirs = dir_str.split()
                    for split_dir in split_dirs:
                        split_dir = split_dir.strip()
                        if split_dir:
                            # Process this directory
                            if split_dir != ".":
                                # Check if it's an absolute path that equals component_dir
                                abs_path = os.path.normpath(os.path.join(component_dir, split_dir))
                                if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                                    split_dir = "."
                                else:
                                    # Try to get relative path
                                    try:
                                        rel_path = os.path.relpath(abs_path, component_dir)
                                        if not rel_path.startswith('..'):
                                            split_dir = rel_path
                                    except (ValueError, OSError):
                                        pass
                            
                            if split_dir and split_dir not in dirs:
                                dirs.append(split_dir)
                else:
                    # Single directory path
                    # If resolved to component directory itself, use "."
                    if dir_str and dir_str != ".":
                        # Check if it's an absolute path that equals component_dir
                        abs_path = os.path.normpath(os.path.join(component_dir, dir_str))
                        if os.path.normpath(abs_path) == os.path.normpath(component_dir):
                            dir_str = "."
                        else:
                            # Try to get relative path
                            try:
                                rel_path = os.path.relpath(abs_path, component_dir)
                                if not rel_path.startswith('..'):
                                    dir_str = rel_path
                            except (ValueError, OSError):
                                pass
                    
                    if dir_str:
                        dirs.append(dir_str)
        
        # Merge with directories from list(APPEND ...)
        for append_dir in include_dirs_from_list_append:
            if append_dir not in dirs:
                dirs.append(append_dir)
        
        return dirs if dirs else ["."]
    except Exception as e:
        print(f"Warning: Failed to parse INCLUDE_DIRS from {cmake_file}: {e}")
        return []

