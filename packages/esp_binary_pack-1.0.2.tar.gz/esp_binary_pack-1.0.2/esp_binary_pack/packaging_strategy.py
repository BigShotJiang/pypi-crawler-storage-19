"""
Packaging strategies for ESP-IDF Binary Pack Script
"""

import os
import shutil
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple

from .models import ComponentInfo
from .component_detector import is_prebuilt_component, is_managed_component
from .file_extractor import find_library_file, generate_unique_lib_name, extract_headers
from .cmake_generator import generate_component_cmake
from .file_copier import copy_prebuilt_component


class PackagingStrategy(ABC):
    """Abstract base class for packaging strategies"""
    
    @abstractmethod
    def extract_libraries(
        self,
        components: Dict[str, ComponentInfo],
        build_dir: str,
        project_path: str,
        output_dir: str,
        pack_managed_components: bool = False
    ) -> Tuple[Dict[str, Tuple[str, str]], List[Tuple[str, ComponentInfo]], List[Tuple[str, ComponentInfo]]]:
        """
        Extract library files to appropriate locations
        
        Args:
            components: Dictionary of components to process
            build_dir: Build directory path
            project_path: Project root path
            output_dir: Output directory path
            pack_managed_components: Whether to pack managed components as libraries (default: False)
        
        Returns:
            Tuple of (lib_mapping, prebuilt_components, components_without_lib)
            lib_mapping: Dictionary mapping component_name -> (lib_name, lib_file)
            prebuilt_components: List of (component_name, ComponentInfo) for prebuilt components
            components_without_lib: List of (component_name, ComponentInfo) for components without library files
        """
        pass
    
    @abstractmethod
    def copy_prebuilt_components(
        self,
        prebuilt_components: List[Tuple[str, ComponentInfo]],
        output_dir: str
    ) -> None:
        """Copy prebuilt components as-is to output directory"""
        pass
    
    @abstractmethod
    def extract_headers(
        self,
        components: Dict[str, ComponentInfo],
        lib_mapping: Dict[str, Tuple[str, str]],
        output_dir: str,
        extract_headers_flag: bool
    ) -> Dict[str, List[str]]:
        """
        Extract header files to appropriate locations
        
        Returns:
            Dictionary mapping component_name -> list of original INCLUDE_DIRS
        """
        pass
    
    @abstractmethod
    def generate_cmake_files(
        self,
        components: Dict[str, ComponentInfo],
        lib_mapping: Dict[str, Tuple[str, str]],
        output_dir: str,
        all_user_components: Dict[str, ComponentInfo],
        original_include_dirs_map: Dict[str, List[str]],
        components_copied_as_source: set = None
    ) -> None:
        """Generate CMakeLists.txt files""" 
        pass


class SeparatePackagingStrategy(PackagingStrategy):
    """Strategy for separate packaging: each component in its own directory"""
    
    def extract_libraries(
        self,
        components: Dict[str, ComponentInfo],
        build_dir: str,
        project_path: str,
        output_dir: str,
        pack_managed_components: bool = False
    ) -> Tuple[Dict[str, Tuple[str, str]], List[Tuple[str, ComponentInfo]], List[Tuple[str, ComponentInfo]]]:
        """
        Extract library files to component-specific directories
        
        Args:
            components: Dictionary of components to process
            build_dir: Build directory path
            project_path: Project root path
            output_dir: Output directory path
            pack_managed_components: Whether to pack managed components as libraries (default: False)
        
        Returns:
            Tuple of (lib_mapping, prebuilt_components, components_without_lib)
            lib_mapping: Dictionary mapping component_name -> (lib_name, lib_file)
            prebuilt_components: List of (component_name, ComponentInfo) for prebuilt components
            components_without_lib: List of (component_name, ComponentInfo) for components without library files
        """
        lib_mapping = {}
        existing_names = set()
        prebuilt_components = []
        components_without_lib = []
        prebuild_components_dir = os.path.join(output_dir, 'prebuild_components')
        
        for comp_name, comp_info in components.items():
            # Check if it's a managed component
            if is_managed_component(comp_info.dir):
                if pack_managed_components:
                    # Try to pack managed component as library
                    # Find library file for managed component
                    lib_path = find_library_file(build_dir, comp_name, comp_info)
                    if lib_path:
                        # Generate unique library name
                        lib_name, lib_file = generate_unique_lib_name(
                            comp_name, comp_info.dir, project_path, existing_names
                        )
                        
                        # All components including main go to prebuild_components directory
                        comp_dir = os.path.join(prebuild_components_dir, comp_name)
                        os.makedirs(comp_dir, exist_ok=True)
                        
                        # Copy library file to component directory
                        dest_lib = os.path.join(comp_dir, lib_file)
                        shutil.copy2(lib_path, dest_lib)
                        print(f"  Packed managed component {comp_name} -> prebuild_components/{comp_name}/{lib_file}")
                        
                        lib_mapping[comp_name] = (lib_name, lib_file)
                    else:
                        # Managed component without library file will be copied as-is
                        components_without_lib.append((comp_name, comp_info))
                        print(f"  Detected managed component: {comp_name}, no library file found, will copy to components/")
                else:
                    # Do not pack managed components, copy as-is
                    components_without_lib.append((comp_name, comp_info))
                    print(f"  Detected managed component: {comp_name}, will copy to components/ (packing disabled)")
                continue
            
            # Then check if it's a prebuilt component
            # Prebuilt components should be copied as-is, even if they have .a files in build dir
            if is_prebuilt_component(comp_info.dir):
                prebuilt_components.append((comp_name, comp_info))
                print(f"  Detected prebuilt component: {comp_name}, will copy as-is")
                continue
            
            # Find library file for non-prebuilt components
            lib_path = find_library_file(build_dir, comp_name, comp_info)
            if not lib_path:
                # Component without library file will be copied as-is
                components_without_lib.append((comp_name, comp_info))
                print(f"  Library file not found for component {comp_name}, will copy as-is")
                continue
            
            # Generate unique library name
            lib_name, lib_file = generate_unique_lib_name(
                comp_name, comp_info.dir, project_path, existing_names
            )
            
            # All components including main go to prebuild_components directory
            comp_dir = os.path.join(prebuild_components_dir, comp_name)
            os.makedirs(comp_dir, exist_ok=True)
            
            # Copy library file to component directory
            dest_lib = os.path.join(comp_dir, lib_file)
            shutil.copy2(lib_path, dest_lib)
            print(f"  Copied {comp_name} -> prebuild_components/{comp_name}/{lib_file}")
            
            lib_mapping[comp_name] = (lib_name, lib_file)
        
        return lib_mapping, prebuilt_components, components_without_lib
    
    def copy_prebuilt_components(
        self,
        prebuilt_components: List[Tuple[str, ComponentInfo]],
        output_dir: str
    ) -> None:
        """Copy prebuilt components as-is to output directory"""
        if not prebuilt_components:
            return
        
        for comp_name, comp_info in prebuilt_components:
            copy_prebuilt_component(comp_name, comp_info, output_dir)
    
    def extract_headers(
        self,
        components: Dict[str, ComponentInfo],
        lib_mapping: Dict[str, Tuple[str, str]],
        output_dir: str,
        extract_headers_flag: bool
    ) -> Dict[str, List[str]]:
        """Extract header files to component-specific include directories"""
        original_include_dirs_map = {}
        
        if not extract_headers_flag:
            return original_include_dirs_map
        
        prebuild_components_dir = os.path.join(output_dir, 'prebuild_components')
        for comp_name, comp_info in components.items():
            if comp_name not in lib_mapping:
                continue
            
            # All components including main go to prebuild_components directory
            comp_dir = os.path.join(prebuild_components_dir, comp_name)
            
            # Extract headers directly to component directory (not to include/ subdirectory)
            has_headers, original_include_dirs = extract_headers(comp_info, comp_dir)
            if has_headers:
                original_include_dirs_map[comp_name] = original_include_dirs
        
        return original_include_dirs_map
    
    def generate_cmake_files(
        self,
        components: Dict[str, ComponentInfo],
        lib_mapping: Dict[str, Tuple[str, str]],
        output_dir: str,
        all_user_components: Dict[str, ComponentInfo],
        original_include_dirs_map: Dict[str, List[str]],
        components_copied_as_source: set = None
    ) -> None:
        """Generate CMakeLists.txt for each component"""
        prebuild_components_dir = os.path.join(output_dir, 'prebuild_components')
        
        for comp_name, comp_info in components.items():
            if comp_name not in lib_mapping:
                continue
            
            lib_name, lib_file = lib_mapping[comp_name]
            
            # All components including main go to prebuild_components directory
            comp_dir = os.path.join(prebuild_components_dir, comp_name)
            cmake_file = os.path.join(comp_dir, 'CMakeLists.txt')
            
            # Get original include dirs for this component
            original_include_dirs = original_include_dirs_map.get(comp_name, [])
            
            generate_component_cmake(
                comp_name,
                comp_info,
                lib_file,
                cmake_file,
                lib_mapping,
                all_user_components,
                original_include_dirs,
                components_copied_as_source
            )

