"""
File extraction utilities for ESP-IDF Binary Pack Script
"""

import hashlib
import os
import re
import shutil
from typing import List, Optional, Set, Tuple

from .models import ComponentInfo
from .cmake_parser import parse_include_dirs_from_cmake


def generate_unique_lib_name(
    component_name: str,
    component_path: str,
    project_path: str,
    existing_names: Set[str]
) -> Tuple[str, str]:
    """
    Generate unique library filename based on component path
    
    Returns:
        Tuple of (lib_name_without_ext, lib_name_with_ext)
    """
    try:
        # Normalize paths
        component_path = os.path.normpath(component_path)
        project_path = os.path.normpath(project_path)
        
        rel_path = os.path.relpath(component_path, project_path)
        rel_path = os.path.normpath(rel_path)
        
        # Split path into parts
        path_parts = [p for p in rel_path.split(os.sep) if p and p != '.']
        
        # Simple cases
        if len(path_parts) == 1 and path_parts[0] == component_name:
            base_name = f"lib{component_name}"
        elif len(path_parts) == 1 and path_parts[0] == 'main':
            base_name = "libmain"
        elif 'components' in path_parts:
            # Extract component name from path like components/my_audio or ../components/my_audio
            try:
                comp_idx = path_parts.index('components')
                if comp_idx + 1 < len(path_parts):
                    comp_name = path_parts[comp_idx + 1]
                    base_name = f"lib{comp_name}"
                else:
                    base_name = f"lib{component_name}"
            except ValueError:
                base_name = f"lib{component_name}"
        elif 'managed_components' in path_parts:
            # Extract from managed_components path
            try:
                mgd_idx = path_parts.index('managed_components')
                if mgd_idx + 1 < len(path_parts):
                    comp_name = path_parts[mgd_idx + 1]
                    base_name = f"libmanaged_{comp_name}"
                else:
                    base_name = f"lib{component_name}"
            except ValueError:
                base_name = f"lib{component_name}"
        else:
            # Use component name directly, or extract from path
            # Use the last meaningful part (usually component name)
            if path_parts:
                base_name = f"lib{path_parts[-1]}"
            else:
                base_name = f"lib{component_name}"
        
        # Normalize: remove invalid characters, limit length
        base_name = base_name.replace('-', '_').replace('__', '_')
        if len(base_name) > 50:  # Reasonable limit
            # Too long, use hash
            path_hash = hashlib.md5(rel_path.encode()).hexdigest()[:8]
            base_name = f"lib{path_hash}_{component_name}"
        
    except (ValueError, AttributeError):
        # Fallback: use hash of full path
        path_hash = hashlib.md5(component_path.encode()).hexdigest()[:8]
        base_name = f"lib{path_hash}_{component_name}"
    
    # Handle conflicts
    final_name = base_name
    counter = 1
    while final_name in existing_names:
        final_name = f"{base_name}_{counter}"
        counter += 1
    
    existing_names.add(final_name)
    
    return final_name, f"{final_name}.a"


def find_library_file(build_dir: str, component_name: str, component_info: Optional[ComponentInfo] = None) -> Optional[str]:
    """Find the compiled .a library file for a component"""
    # First, try to use the file path from component_info if available
    # The 'file' field may contain a generator expression like "$<TARGET_LINKER_FILE:__idf_comp>"
    # We need to resolve it to actual path: build/esp-idf/{component_name}/lib{component_name}.a
    if component_info and component_info.file:
        # If file path contains generator expression, extract the component name
        # and construct the actual path
        if '$<' in component_info.file:
            # Generator expression, construct path manually
            lib_path = os.path.join(build_dir, 'esp-idf', component_name, f'lib{component_name}.a')
            if os.path.exists(lib_path):
                return lib_path
        else:
            # Direct path, try to use it (may be relative or absolute)
            if os.path.isabs(component_info.file):
                if os.path.exists(component_info.file):
                    return component_info.file
            else:
                # Relative path, try relative to build_dir
                lib_path = os.path.join(build_dir, component_info.file)
                if os.path.exists(lib_path):
                    return lib_path
    
    # Fallback: try standard ESP-IDF paths
    lib_path = os.path.join(build_dir, 'esp-idf', component_name, f'lib{component_name}.a')
    if os.path.exists(lib_path):
        return lib_path
    
    # Try alternative paths
    alt_paths = [
        os.path.join(build_dir, component_name, f'lib{component_name}.a'),
        os.path.join(build_dir, 'esp-idf', component_name, f'{component_name}.a'),
    ]
    
    for alt_path in alt_paths:
        if os.path.exists(alt_path):
            return alt_path
    
    return None


def extract_headers(component_info: ComponentInfo, output_component_dir: str) -> Tuple[bool, List[str]]:
    """
    Extract header files from component to output component directory
    Returns: (has_headers, original_include_dirs)
    """
    component_dir = component_info.dir
    component_name = component_info.name
    if not os.path.exists(component_dir):
        return False, []
    
    # Parse original INCLUDE_DIRS from CMakeLists.txt
    original_include_dirs = parse_include_dirs_from_cmake(component_dir)
    
    # Normalize component directory path for comparison
    component_dir = os.path.normpath(os.path.abspath(component_dir))
    
    # Helper function to check if a path is within component_dir
    def is_within_component_dir(path):
        """Check if path is within component_dir"""
        try:
            path_abs = os.path.normpath(os.path.abspath(path))
            rel_path = os.path.relpath(path_abs, component_dir)
            return not rel_path.startswith('..')
        except (ValueError, OSError):
            return False
    
    # Get all include directories from original component
    include_dirs = component_info.include_dirs
    valid_include_dirs = []
    
    for inc_dir in include_dirs:
        if is_within_component_dir(inc_dir) and os.path.exists(inc_dir):
            valid_include_dirs.append(inc_dir)
    
    # Fallback: look for common include directories within component
    if not valid_include_dirs:
        for possible_dir in ['include', 'inc']:
            inc_path = os.path.join(component_dir, possible_dir)
            if os.path.exists(inc_path) and os.path.isdir(inc_path):
                valid_include_dirs.append(inc_path)
    
    # Collect all .h and .hpp files
    header_files = []
    header_extensions = ('.h', '.hpp')
    for include_dir in valid_include_dirs:
        if os.path.exists(include_dir):
            for root, dirs, files in os.walk(include_dir):
                if not is_within_component_dir(root):
                    dirs[:] = []
                    continue
                
                for file in files:
                    if file.endswith(header_extensions):
                        file_path = os.path.join(root, file)
                        if is_within_component_dir(file_path):
                            header_files.append(file_path)
    
    # Also scan component root directory
    for root, dirs, files in os.walk(component_dir):
        if not is_within_component_dir(root):
            dirs[:] = []
            continue
        
        for file in files:
            if file.endswith(header_extensions):
                file_path = os.path.join(root, file)
                if is_within_component_dir(file_path):
                    header_files.append(file_path)
    
    if not header_files:
        return False, original_include_dirs
    
    # Copy header files according to original INCLUDE_DIRS structure
    # If original uses ".", copy directly to component root
    # If original uses "include", copy to include/ directory
    # If original uses multiple dirs, maintain relative structure
    
    copied_files = []
    for header_file in header_files:
        try:
            rel_path = os.path.relpath(header_file, component_dir)
            
            # Determine destination based on original INCLUDE_DIRS
            if original_include_dirs:
                # Find which original include_dir this file belongs to
                dest_path = None
                for orig_inc_dir in original_include_dirs:
                    orig_inc_abs = os.path.normpath(os.path.join(component_dir, orig_inc_dir))
                    try:
                        if os.path.commonpath([header_file, orig_inc_abs]) == orig_inc_abs:
                            # This file is in this include directory
                            file_rel_to_inc = os.path.relpath(header_file, orig_inc_abs)
                            # Recreate the same structure in output
                            dest_path = os.path.join(output_component_dir, orig_inc_dir, file_rel_to_inc)
                            break
                    except ValueError:
                        # Paths don't share a common path, skip this include_dir
                        continue
                
                if not dest_path:
                    # File not in any original include_dir, use relative path from component root
                    dest_path = os.path.join(output_component_dir, rel_path)
            else:
                # No original INCLUDE_DIRS found, use relative path
                dest_path = os.path.join(output_component_dir, rel_path)
            
            # Create subdirectories if needed
            dest_dir = os.path.dirname(dest_path)
            if dest_dir:
                os.makedirs(dest_dir, exist_ok=True)
            
            if not os.path.exists(dest_path):
                shutil.copy2(header_file, dest_path)
                copied_files.append(dest_path)
        except Exception as e:
            print(f"Warning: Failed to copy header {header_file}: {e}")
    
    # Copy Kconfig file and all referenced Kconfig files recursively
    _copy_kconfig_recursive(component_dir, output_component_dir, component_name)
    
    return len(copied_files) > 0, original_include_dirs


def _copy_kconfig_recursive(
    component_dir: str,
    output_component_dir: str,
    component_name: str,
    kconfig_rel_path: str = "Kconfig",
    visited: Optional[Set[str]] = None
) -> None:
    """
    Recursively copy Kconfig file and all Kconfig files referenced via rsource statements
    
    Args:
        component_dir: Source component directory
        output_component_dir: Destination component directory
        component_name: Component name for logging
        kconfig_rel_path: Relative path to Kconfig file from component_dir
        visited: Set of already processed Kconfig paths to avoid cycles
    """
    if visited is None:
        visited = set()
    
    # Normalize path to avoid duplicates
    kconfig_key = os.path.normpath(kconfig_rel_path)
    if kconfig_key in visited:
        return
    visited.add(kconfig_key)
    
    kconfig_path = os.path.join(component_dir, kconfig_rel_path)
    if not os.path.exists(kconfig_path):
        return
    
    try:
        dest_kconfig_path = os.path.join(output_component_dir, kconfig_rel_path)
        dest_kconfig_dir = os.path.dirname(dest_kconfig_path)
        
        # Create destination directory if needed
        if dest_kconfig_dir and not os.path.exists(dest_kconfig_dir):
            os.makedirs(dest_kconfig_dir, exist_ok=True)
        
        # Copy the Kconfig file
        if not os.path.exists(dest_kconfig_path):
            shutil.copy2(kconfig_path, dest_kconfig_path)
            if kconfig_rel_path == "Kconfig":
                print(f"Copied Kconfig for component {component_name}")
            else:
                print(f"Copied Kconfig: {kconfig_rel_path} for component {component_name}")
        
        # Parse the Kconfig file to find rsource statements
        with open(kconfig_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Find all rsource statements: rsource "path/to/Kconfig" or rsource 'path/to/Kconfig'
        # Pattern matches: rsource "..." or rsource '...'
        rsource_pattern = r'rsource\s+["\']([^"\']+)["\']'
        matches = re.findall(rsource_pattern, content)
        
        # Process each referenced Kconfig file
        for referenced_path in matches:
            # Resolve relative path from the current Kconfig file's directory
            current_kconfig_dir = os.path.dirname(kconfig_path)
            referenced_abs_path = os.path.normpath(os.path.join(current_kconfig_dir, referenced_path))
            
            # Check if the referenced file is within the component directory
            try:
                rel_to_component = os.path.relpath(referenced_abs_path, component_dir)
                if not rel_to_component.startswith('..'):
                    # Recursively copy the referenced Kconfig file
                    _copy_kconfig_recursive(
                        component_dir,
                        output_component_dir,
                        component_name,
                        rel_to_component,
                        visited
                    )
            except ValueError:
                # Path is outside component directory, skip
                pass
                
    except Exception as e:
        print(f"Warning: Failed to copy Kconfig {kconfig_rel_path} for component {component_name}: {e}")

