"""
Project builder for ESP-IDF Binary Pack Script
"""

import os
import shutil
from typing import Dict

from .models import ComponentInfo, ProjectConfig
from .packaging_strategy import PackagingStrategy
from .utils import read_project_description
from .component_detector import filter_user_components, collect_components_to_copy_as_is, is_managed_component
from .cmake_generator import generate_main_cmake, generate_main_c, generate_root_cmake
from .file_copier import copy_project_files, copy_components_as_is, copy_managed_components, rewrite_override_paths


class ProjectBuilder:
    """Builder class for constructing binary project using packaging strategy"""
    
    def __init__(self, strategy: PackagingStrategy, config: ProjectConfig):
        self.strategy = strategy
        self.config = config
    
    def build(self) -> None:
        """Build the binary project"""
        # Read project description
        print(f"Reading project description from {self.config.build_dir}...")
        project_desc = read_project_description(self.config.build_dir)
        
        # Update config with project info
        self.config.project_name = project_desc.get('project_name', 'esp_project')
        self.config.project_ver = project_desc.get('project_version', '1.0')
        
        # Parse component info
        build_component_info = project_desc.get('build_component_info', {})
        components = {}
        for name, data in build_component_info.items():
            components[name] = ComponentInfo(name, data)
        
        # Filter user components
        print("Filtering user components...")
        user_components, excluded_components = filter_user_components(
            components, self.config.idf_path, 
            self.config.exclude_list, self.config.include_list
        )
        print(f"Found {len(user_components)} user components to pack")
        if excluded_components:
            print(f"Found {len(excluded_components)} excluded components to copy as source")
        
        # Create output directory structure
        print(f"Creating output directory: {self.config.output_dir}")
        os.makedirs(self.config.output_dir, exist_ok=True)
        
        # Extract libraries using strategy (this also detects prebuilt components)
        print("Extracting library files...")
        lib_mapping, prebuilt_components, components_without_lib = self.strategy.extract_libraries(
            user_components,
            self.config.build_dir,
            self.config.project_path,
            self.config.output_dir,
            self.config.pack_managed_components
        )
        
        # Collect all components that need to be copied as-is
        # This includes: prebuilt components, excluded components, components without library files, and their dependencies
        initial_components_to_copy = {}
        
        # Add prebuilt components
        for comp_name, comp_info in prebuilt_components:
            initial_components_to_copy[comp_name] = comp_info
        
        # Add excluded components
        for comp_name, comp_info in excluded_components.items():
            initial_components_to_copy[comp_name] = comp_info
        
        # Add components without library files
        for comp_name, comp_info in components_without_lib:
            initial_components_to_copy[comp_name] = comp_info
        
        # Recursively collect all components that need to be copied as-is
        if initial_components_to_copy:
            print("\nCollecting components to copy as-is (including dependencies)...")
            components_to_copy = collect_components_to_copy_as_is(
                initial_components_to_copy,
                components,  # All components from project_description.json
                self.config.idf_path,
                lib_mapping,
                excluded_components
            )
            
            # Separate managed components from other components
            # Copy managed components as source if:
            # 1. pack_managed_components is False (default: copy as source code)
            # 2. pack_managed_components is True but no library file was found (packing failed, need source)
            managed_components = {
                comp_name: (comp_info, reason)
                for comp_name, (comp_info, reason) in components_to_copy.items()
                if is_managed_component(comp_info.dir)
            }
            
            # If pack_managed_components is True, filter out managed components that were successfully packed
            if self.config.pack_managed_components:
                # Only keep managed components that are in components_to_copy (meaning they weren't packed)
                managed_components = {
                    comp_name: (comp_info, reason)
                    for comp_name, (comp_info, reason) in managed_components.items()
                    if comp_name not in lib_mapping
                }
            
            other_components = {
                comp_name: (comp_info, reason)
                for comp_name, (comp_info, reason) in components_to_copy.items()
                if comp_name not in managed_components
            }
            
            # Special handling for main component: it should go to main/ directory, not components/
            # If main is in other_components (excluded or needs to be copied as source),
            # remove it from other_components and handle it separately in the main component section
            if 'main' in other_components:
                other_components.pop('main')
                print(f"  Note: main component will be handled separately (not copied to components/)")
            
            # Copy managed components to components/ directory
            if managed_components:
                copy_managed_components(managed_components, self.config.output_dir)
            
            # Copy other components (prebuilt, excluded, etc.) to components/ directory
            if other_components:
                copy_components_as_is(
                    other_components,
                    self.config.output_dir
                )
        
        # Extract headers using strategy
        original_include_dirs_map = {}
        if self.config.extract_headers:
            print("Extracting header files...")
            original_include_dirs_map = self.strategy.extract_headers(
                user_components,
                lib_mapping,
                self.config.output_dir,
                self.config.extract_headers
            )
        
        # Collect all components that were copied as source (not packaged as libraries)
        # This includes: managed components, excluded components, prebuilt components, and components without lib files
        components_copied_as_source = set()
        if initial_components_to_copy:
            # components_to_copy was collected in lines 82-88 via collect_components_to_copy_as_is
            components_copied_as_source = set(components_to_copy.keys())
        
        # Generate CMake files using strategy
        print("Generating CMakeLists.txt files...")
        self.strategy.generate_cmake_files(
            user_components,
            lib_mapping,
            self.config.output_dir,
            user_components,
            original_include_dirs_map,
            components_copied_as_source
        )
        
        # Generate main component
        main_is_lib = 'main' in user_components and 'main' in lib_mapping
        if main_is_lib:
            print("Generating main component (as library)...")
            # Main library is in prebuild_components/main/
            # Generate stub main.c and CMakeLists.txt in main/ directory
            generate_main_cmake(self.config.output_dir, main_is_lib)
            generate_main_c(self.config.output_dir, main_is_lib)
        else:
            print("Main component will use source code")
            # Copy main source if exists
            main_src = os.path.join(self.config.project_path, 'main')
            if os.path.exists(main_src):
                main_dst = os.path.join(self.config.output_dir, 'main')
                if not os.path.exists(main_dst):
                    try:
                        shutil.copytree(main_src, main_dst, 
                                      ignore=shutil.ignore_patterns('*.o', '*.a', 'build', '*.d', '.git'))
                    except Exception as e:
                        print(f"Warning: Failed to copy main source: {e}")
                        # Create minimal main if copy fails
                        os.makedirs(main_dst, exist_ok=True)
                        generate_main_cmake(self.config.output_dir, False)
                        generate_main_c(self.config.output_dir, False)
            else:
                # Create minimal main if source doesn't exist
                generate_main_cmake(self.config.output_dir, False)
                generate_main_c(self.config.output_dir, False)
        
        # Generate root CMakeLists.txt
        print("Generating root CMakeLists.txt...")
        generate_root_cmake(
            self.config.project_name, 
            self.config.project_ver, 
            os.path.join(self.config.output_dir, 'CMakeLists.txt')
        )
        
        # Copy project files
        print("Copying project configuration files...")
        copy_project_files(self.config.project_path, self.config.output_dir)
        
        # Rewrite override_path in idf_component.yml files for all copied components
        # This must be done after all components are copied
        all_copied_components = set()
        if initial_components_to_copy:
            all_copied_components = set(components_to_copy.keys())
        
        # Also include main if it was copied (even if it was excluded from components_to_copy)
        main_dst = os.path.join(self.config.output_dir, 'main')
        if os.path.exists(main_dst):
            all_copied_components.add('main')
        
        # Pass lib_mapping so we can also check prebuild_components directory
        rewrite_override_paths(self.config.output_dir, all_copied_components, lib_mapping)
        
        print(f"\nDone! Binary project generated in: {self.config.output_dir}")
        print(f"You can now build it with: cd {self.config.output_dir} && idf.py build")
