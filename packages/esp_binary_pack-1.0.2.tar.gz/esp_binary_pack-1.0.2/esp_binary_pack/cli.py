#!/usr/bin/env python3
"""
ESP-IDF Binary Pack Script

This script extracts compiled .a library files from an ESP-IDF project and
generates a new project that uses prebuilt libraries instead of source code.

Usage:
    python idf_binary_pack.py [options]

Options:
    --exclude COMP1,COMP2    Components to exclude from binary packing
    --include COMP1,COMP2    Components to force include (even if excluded)
    --output-dir DIR         Output directory (default: {project_name}_binary)
    --idf-path PATH          IDF_PATH (default: from environment)
    --extract-headers        Extract header files to include directory
"""

import argparse
import os
import sys

from .models import ProjectConfig
from .utils import get_idf_path, get_project_path, read_project_description
from .packaging_strategy import SeparatePackagingStrategy
from .project_builder import ProjectBuilder


def main():
    parser = argparse.ArgumentParser(
        description='Extract ESP-IDF project libraries and generate binary-only project',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        '--exclude',
        type=str,
        default='',
        help='Comma-separated list of components to exclude'
    )
    
    parser.add_argument(
        '--include',
        type=str,
        default='',
        help='Comma-separated list of components to force include'
    )
    
    parser.add_argument(
        '--output-dir',
        type=str,
        default=None,
        help='Output directory (default: {project_name}_binary)'
    )
    
    parser.add_argument(
        '--idf-path',
        type=str,
        default=None,
        help='IDF_PATH (default: from environment)'
    )
    
    parser.add_argument(
        '--extract-headers',
        action='store_true',
        help='Extract header files to include directory'
    )
    
    parser.add_argument(
        '--build-dir',
        type=str,
        default='build',
        help='Build directory (default: build)'
    )
    
    parser.add_argument(
        '--pack-managed-components',
        action='store_true',
        help='Pack managed components as libraries (default: copy managed components as source code)'
    )
    
    args = parser.parse_args()
    
    # Get paths
    project_path = get_project_path()
    idf_path = args.idf_path or get_idf_path()
    build_dir = os.path.join(project_path, args.build_dir)
    
    # Read project description to get project name for default output dir
    try:
        project_desc = read_project_description(build_dir)
        project_name = project_desc.get('project_name', 'esp_project')
    except FileNotFoundError:
        # Will be read again in ProjectBuilder, use default for now
        project_name = 'esp_project'
    
    # Determine output directory
    if args.output_dir:
        output_dir = args.output_dir
    else:
        output_dir = os.path.join(project_path, f"{project_name}_binary")
    
    # Parse exclude/include lists
    exclude_list = [c.strip() for c in args.exclude.split(',') if c.strip()]
    include_list = [c.strip() for c in args.include.split(',') if c.strip()]
    
    # Create configuration
    config = ProjectConfig(
        project_path=project_path,
        idf_path=idf_path,
        build_dir=build_dir,
        output_dir=output_dir,
        extract_headers=args.extract_headers,
        exclude_list=exclude_list,
        include_list=include_list,
        pack_managed_components=args.pack_managed_components
    )
    
    # Use separate packaging strategy
    strategy = SeparatePackagingStrategy()
    
    # Build project using builder pattern
    builder = ProjectBuilder(strategy, config)
    builder.build()


if __name__ == '__main__':
    main()
