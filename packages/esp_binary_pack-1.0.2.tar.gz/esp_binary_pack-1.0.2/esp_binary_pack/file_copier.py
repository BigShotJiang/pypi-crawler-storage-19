"""
File copying utilities for ESP-IDF Binary Pack Script
"""

import os
import re
import shutil
from typing import Dict, Tuple, Optional

from .models import ComponentInfo
from .component_detector import is_managed_component


def copy_project_files(project_path: str, output_dir: str) -> None:
    """Copy project configuration files"""
    # Copy sdkconfig and sdkconfig.defaults
    config_files = ['sdkconfig', 'sdkconfig.defaults']
    
    for file_name in config_files:
        src = os.path.join(project_path, file_name)
        if os.path.exists(src):
            dst = os.path.join(output_dir, file_name)
            shutil.copy2(src, dst)
            print(f"Copied {file_name}")
    
    # Read partition table filename from sdkconfig
    partition_table_file = _get_partition_table_from_sdkconfig(project_path)
    
    if partition_table_file:
        src = os.path.join(project_path, partition_table_file)
        if os.path.exists(src):
            dst = os.path.join(output_dir, partition_table_file)
            # Create parent directory if needed (in case partition table is in subdirectory)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            print(f"Copied partition table: {partition_table_file}")
        else:
            print(f"Warning: Partition table file not found: {partition_table_file}")
    else:
        print("Warning: Could not determine partition table file from sdkconfig")


def _get_partition_table_from_sdkconfig(project_path: str) -> str:
    """
    Read partition table filename from sdkconfig
    
    Returns:
        Partition table filename (relative path), or None if not found
    """
    sdkconfig_path = os.path.join(project_path, 'sdkconfig')
    
    if not os.path.exists(sdkconfig_path):
        return None
    
    try:
        with open(sdkconfig_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                # Look for CONFIG_PARTITION_TABLE_FILENAME
                if line.startswith('CONFIG_PARTITION_TABLE_FILENAME='):
                    # Extract the value (remove quotes)
                    value = line.split('=', 1)[1].strip()
                    # Remove surrounding quotes if present
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    return value
    except Exception as e:
        print(f"Warning: Failed to read sdkconfig: {e}")
    
    return None


def copy_excluded_components(
    excluded_components: Dict[str, ComponentInfo],
    output_dir: str
) -> None:
    """Copy excluded components as source code"""
    if not excluded_components:
        return
    
    components_dir = os.path.join(output_dir, 'components')
    os.makedirs(components_dir, exist_ok=True)
    
    print("Copying excluded components as source code...")
    for comp_name, comp_info in excluded_components.items():
        comp_src = comp_info.dir
        comp_dst = os.path.join(components_dir, comp_name)
        
        if os.path.exists(comp_dst):
            print(f"  Component {comp_name} already exists, skipping")
            continue
        
        if os.path.exists(comp_src):
            try:
                # Copy component directory, excluding build artifacts
                shutil.copytree(
                    comp_src,
                    comp_dst,
                    ignore=shutil.ignore_patterns(
                        'build', '.git', '*.o', '*.d', 
                        '*.pyc', '__pycache__', '.DS_Store'
                    )
                )
                print(f"  Copied {comp_name} -> components/{comp_name}")
            except Exception as e:
                print(f"  Warning: Failed to copy component {comp_name}: {e}")


def copy_prebuilt_component(
    comp_name: str,
    comp_info: ComponentInfo,
    output_dir: str
) -> None:
    """
    Copy a prebuilt component as-is to output directory
    
    Args:
        comp_name: Component name
        comp_info: Component information
        output_dir: Output directory
    """
    comp_src = comp_info.dir
    if not os.path.exists(comp_src):
        print(f"Warning: Component directory not found: {comp_src}")
        return
    
    # All components go to components directory
    comp_dst = os.path.join(output_dir, 'components', comp_name)
    
    if os.path.exists(comp_dst):
        print(f"  Component {comp_name} already exists, skipping")
        return
    
    try:
        # Copy component directory, excluding build artifacts
        shutil.copytree(
            comp_src,
            comp_dst,
            ignore=shutil.ignore_patterns(
                'build', '.git', '*.o', '*.d', 
                '*.pyc', '__pycache__', '.DS_Store'
            )
        )
        print(f"  Copied prebuilt component {comp_name} -> components/{comp_name}/")
    except Exception as e:
        print(f"  Warning: Failed to copy prebuilt component {comp_name}: {e}")


def copy_components_as_is(
    components_to_copy: Dict[str, Tuple[ComponentInfo, str]],
    output_dir: str
) -> None:
    """
    Copy components as-is to output directory with detailed logging
    
    Args:
        components_to_copy: Dictionary mapping component_name -> (ComponentInfo, reason)
            reason can be: 'prebuilt', 'excluded', 'no_library_found', 'dependency_of_prebuilt', 'dependency_of_excluded', 'dependency_of_no_lib'
        output_dir: Output directory
    """
    if not components_to_copy:
        return
    
    # Group components by reason for better logging
    by_reason = {}
    for comp_name, (comp_info, reason) in components_to_copy.items():
        if reason not in by_reason:
            by_reason[reason] = []
        by_reason[reason].append((comp_name, comp_info))
    
    # Print summary
    print(f"\nFound {len(components_to_copy)} component(s) to copy as-is:")
    for reason, comps in sorted(by_reason.items()):
        reason_descriptions = {
            'prebuilt': 'Prebuilt component (contains prebuilt libraries)',
            'excluded': 'Excluded via --exclude parameter',
            'no_library_found': 'No library file found (will copy as source code)',
            'dependency_of_prebuilt': 'Dependency of prebuilt component',
            'dependency_of_excluded': 'Dependency of excluded component',
            'dependency_of_no_lib': 'Dependency of component without library file',
            'dependency': 'Dependency of component to copy'
        }
        desc = reason_descriptions.get(reason, reason)
        print(f"  {len(comps)} component(s) - {desc}")
        for comp_name, _ in comps:
            print(f"    - {comp_name}")
    
    print("\nCopying components as-is...")
    
    # Copy each component
    for comp_name, (comp_info, reason) in components_to_copy.items():
        comp_src = comp_info.dir
        if not os.path.exists(comp_src):
            print(f"  Warning: Component directory not found: {comp_src}")
            continue
        
        # All components go to components directory
        comp_dst = os.path.join(output_dir, 'components', comp_name)
        
        if os.path.exists(comp_dst):
            print(f"  Component {comp_name} already exists, skipping")
            continue
        
        try:
            # Copy component directory, excluding build artifacts
            shutil.copytree(
                comp_src,
                comp_dst,
                ignore=shutil.ignore_patterns(
                    'build', '.git', '*.o', '*.d', 
                    '*.pyc', '__pycache__', '.DS_Store'
                )
            )
            
            # Log with reason
            reason_descriptions = {
                'prebuilt': 'prebuilt component',
                'excluded': 'excluded component',
                'no_library_found': 'component without library file',
                'dependency_of_prebuilt': 'dependency of prebuilt component',
                'dependency_of_excluded': 'dependency of excluded component',
                'dependency_of_no_lib': 'dependency of component without library file',
                'dependency': 'dependency component'
            }
            desc = reason_descriptions.get(reason, 'component')
            print(f"  Copied {comp_name} ({desc}) -> components/{comp_name}/")
        except Exception as e:
            print(f"  Warning: Failed to copy component {comp_name}: {e}")
    
    print("\nNote: Components copied as-is contain their original CMakeLists.txt and files.")
    print("      No modifications were made to these components.")


def copy_managed_components(
    components_to_copy: Dict[str, Tuple[ComponentInfo, str]],
    output_dir: str
) -> None:
    """
    Copy managed components to components directory in output project
    
    Args:
        components_to_copy: Dictionary mapping component_name -> (ComponentInfo, reason)
        output_dir: Output directory
    """
    # Filter out only managed components
    managed_components = {
        comp_name: (comp_info, reason)
        for comp_name, (comp_info, reason) in components_to_copy.items()
        if is_managed_component(comp_info.dir)
    }
    
    if not managed_components:
        return
    
    components_dir = os.path.join(output_dir, 'components')
    os.makedirs(components_dir, exist_ok=True)
    
    print(f"\nCopying {len(managed_components)} managed component(s) to components/...")
    
    for comp_name, (comp_info, reason) in managed_components.items():
        comp_src = comp_info.dir
        if not os.path.exists(comp_src):
            print(f"  Warning: Component directory not found: {comp_src}")
            continue
        
        # Copy to components/component_name
        comp_dst = os.path.join(components_dir, comp_name)
        
        if os.path.exists(comp_dst):
            print(f"  Component {comp_name} already exists in components/, skipping")
            continue
        
        try:
            # Copy component directory, excluding build artifacts
            shutil.copytree(
                comp_src,
                comp_dst,
                ignore=shutil.ignore_patterns(
                    'build', '.git', '*.o', '*.d', 
                    '*.pyc', '__pycache__', '.DS_Store'
                )
            )
            print(f"  Copied {comp_name} -> components/{comp_name}/")
        except Exception as e:
            print(f"  Warning: Failed to copy managed component {comp_name}: {e}")
    
    print("\nNote: Managed components are copied as-is to components/ directory.")
    print("      They will be used directly by ESP-IDF component manager.")


def rewrite_override_paths(output_dir: str, copied_components: set, lib_mapping: Dict[str, Tuple[str, str]] = None) -> None:
    """
    Rewrite override_path in idf_component.yml files for all copied components
    
    Args:
        output_dir: Output directory of the binary project
        copied_components: Set of component names that were copied to the output project
        lib_mapping: Dictionary mapping component_name -> (lib_name, lib_file) for prebuilt components
    """
    components_dir = os.path.join(output_dir, 'components')
    prebuild_components_dir = os.path.join(output_dir, 'prebuild_components')
    main_dir = os.path.join(output_dir, 'main')
    
    # Build a set of all available components (both in components/ and prebuild_components/)
    all_available_components = set()
    component_locations = {}  # Map component_name -> ('components' or 'prebuild_components')
    
    if os.path.exists(components_dir):
        for item in os.listdir(components_dir):
            item_path = os.path.join(components_dir, item)
            if os.path.isdir(item_path):
                all_available_components.add(item)
                component_locations[item] = 'components'
    
    if lib_mapping and os.path.exists(prebuild_components_dir):
        for comp_name in lib_mapping.keys():
            comp_path = os.path.join(prebuild_components_dir, comp_name)
            if os.path.exists(comp_path):
                all_available_components.add(comp_name)
                component_locations[comp_name] = 'prebuild_components'
    
    # Collect all directories that might contain idf_component.yml
    dirs_to_check = []
    if os.path.exists(components_dir):
        for item in os.listdir(components_dir):
            item_path = os.path.join(components_dir, item)
            if os.path.isdir(item_path):
                dirs_to_check.append((item_path, item))
    if os.path.exists(main_dir):
        dirs_to_check.append((main_dir, 'main'))
    
    if not dirs_to_check:
        return
    
    print("\nRewriting override_path in idf_component.yml files...")
    
    for comp_dir, comp_name in dirs_to_check:
        yml_file = os.path.join(comp_dir, 'idf_component.yml')
        if not os.path.exists(yml_file):
            continue
        
        try:
            # Read original file to preserve formatting
            with open(yml_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            new_lines = []
            modified = False
            i = 0
            processed_override_paths = {}  # Track which dependencies have had their override_path processed
            
            while i < len(lines):
                line = lines[i]
                
                # Check if this line contains override_path
                if 'override_path' in line and ':' in line:
                    # Get indentation of override_path line
                    override_indent = len(line) - len(line.lstrip())
                    
                    # Extract the override_path value
                    # Format: "    override_path: \"path/to/component\""
                    match = re.search(r'override_path\s*:\s*["\']?([^"\'\n]+)["\']?', line)
                    if match:
                        old_path = match.group(1).strip()
                        
                        # Find the component name this override_path refers to
                        # Look backwards to find the dependency name (less indented line)
                        dep_name = None
                        j = i - 1
                        while j >= 0:
                            prev_line = lines[j]
                            prev_stripped = prev_line.strip()
                            
                            # Skip empty lines and comments
                            if not prev_stripped or prev_stripped.startswith('#'):
                                j -= 1
                                continue
                            
                            prev_indent = len(prev_line) - len(prev_line.lstrip())
                            
                            # Check if this is a dependency name (less indented than override_path)
                            if prev_indent < override_indent and ':' in prev_stripped:
                                # This could be the dependency name
                                dep_match = re.match(r'^([^:]+):\s*(.*)$', prev_stripped)
                                if dep_match:
                                    potential_name = dep_match.group(1).strip()
                                    # Skip known YAML keys
                                    if potential_name not in ['dependencies', 'version']:
                                        dep_name = potential_name
                                        break
                            
                            # If we've gone back too far (reached dependencies: or top level), stop
                            if prev_indent == 0 and 'dependencies' in prev_stripped:
                                break
                            
                            j -= 1
                        
                        if dep_name:
                            # Remove namespace if present (e.g., "espressif/name" -> "name")
                            dep_name_clean = dep_name.split('/')[-1] if '/' in dep_name else dep_name
                            
                            # Check if we've already processed override_path for this dependency
                            # If yes, skip this duplicate override_path line
                            if dep_name_clean in processed_override_paths:
                                modified = True
                                print(f"  Removed duplicate override_path in {comp_name}/idf_component.yml for {dep_name_clean}")
                                # Skip this duplicate override_path line
                                i += 1
                                # Skip continuation lines (more indented lines after override_path)
                                while i < len(lines):
                                    next_line = lines[i]
                                    if not next_line.strip() or next_line.strip().startswith('#'):
                                        # Empty line or comment, keep it
                                        new_lines.append(next_line)
                                        i += 1
                                        continue
                                    # Check indentation
                                    next_indent = len(next_line) - len(next_line.lstrip())
                                    if next_indent > override_indent:
                                        # Still in the same block, skip it
                                        i += 1
                                    else:
                                        # Same or less indentation, new key or end of dict
                                        break
                                continue
                            
                            # Mark this dependency as processed
                            processed_override_paths[dep_name_clean] = True
                            
                            # Check if the target component is available (in components/ or prebuild_components/)
                            if dep_name_clean in all_available_components:
                                # Determine target component location
                                target_location = component_locations.get(dep_name_clean, 'components')
                                
                                if target_location == 'prebuild_components':
                                    # Component is in prebuild_components (prebuilt library)
                                    target_comp_dir = os.path.join(prebuild_components_dir, dep_name_clean)
                                else:
                                    # Component is in components (source code)
                                    target_comp_dir = os.path.join(components_dir, dep_name_clean)
                                
                                if os.path.exists(target_comp_dir):
                                    try:
                                        # Calculate relative path from current component to target component
                                        rel_path = os.path.relpath(target_comp_dir, comp_dir)
                                        # Normalize path separators
                                        rel_path = rel_path.replace('\\', '/')
                                        
                                        # Update the line with new path, preserving quotes style
                                        if '"' in line:
                                            new_line = re.sub(
                                                r'override_path\s*:\s*"[^"]+"',
                                                f'override_path: "{rel_path}"',
                                                line
                                            )
                                        elif "'" in line:
                                            new_line = re.sub(
                                                r"override_path\s*:\s*'[^']+'",
                                                f"override_path: '{rel_path}'",
                                                line
                                            )
                                        else:
                                            new_line = re.sub(
                                                r'override_path\s*:\s*[^\s\n]+',
                                                f'override_path: "{rel_path}"',
                                                line
                                            )
                                        new_lines.append(new_line)
                                        modified = True
                                        location_desc = "prebuild_components" if target_location == 'prebuild_components' else "components"
                                        print(f"  Updated override_path in {comp_name}/idf_component.yml: {old_path} -> {rel_path} (for {dep_name_clean} in {location_desc})")
                                        
                                        # Skip continuation lines and any duplicate override_path lines for this dependency
                                        i += 1
                                        while i < len(lines):
                                            next_line = lines[i]
                                            next_stripped = next_line.strip()
                                            
                                            # Check if this is another override_path line (same or similar indentation)
                                            if 'override_path' in next_line and ':' in next_line:
                                                next_indent = len(next_line) - len(next_line.lstrip())
                                                # If same or similar indentation, it's likely a duplicate override_path
                                                if abs(next_indent - override_indent) <= 2:
                                                    modified = True
                                                    print(f"  Removed duplicate override_path in {comp_name}/idf_component.yml for {dep_name_clean}")
                                                    i += 1
                                                    continue
                                            
                                            if not next_stripped or next_stripped.startswith('#'):
                                                # Empty line or comment, keep it
                                                new_lines.append(next_line)
                                                i += 1
                                                continue
                                            
                                            # Check indentation
                                            next_indent = len(next_line) - len(next_line.lstrip())
                                            if next_indent > override_indent:
                                                # Still in the same block, skip it
                                                i += 1
                                            else:
                                                # Same or less indentation, new key or end of dict
                                                break
                                        continue
                                    except ValueError:
                                        # Paths are on different drives (Windows), skip
                                        new_lines.append(line)
                                else:
                                    # Target component not found, remove override_path
                                    modified = True
                                    print(f"  Removed override_path in {comp_name}/idf_component.yml: target component {dep_name_clean} not found")
                                    # Skip the override_path line (don't add it to new_lines)
                                    i += 1
                                    # Skip continuation lines (more indented lines after override_path)
                                    while i < len(lines):
                                        next_line = lines[i]
                                        if not next_line.strip() or next_line.strip().startswith('#'):
                                            # Empty line or comment, keep it
                                            new_lines.append(next_line)
                                            i += 1
                                            continue
                                        # Check indentation
                                        next_indent = len(next_line) - len(next_line.lstrip())
                                        if next_indent > override_indent:
                                            # Still in the same block, skip it
                                            i += 1
                                        else:
                                            # Same or less indentation, new key or end of dict
                                            break
                                    continue
                            else:
                                # Target component is not available (not in components/ or prebuild_components/), remove override_path
                                modified = True
                                print(f"  Removed override_path in {comp_name}/idf_component.yml: target component {dep_name_clean} is not available")
                                # Skip the override_path line (don't add it to new_lines)
                                i += 1
                                # Skip continuation lines (more indented lines after override_path)
                                while i < len(lines):
                                    next_line = lines[i]
                                    if not next_line.strip() or next_line.strip().startswith('#'):
                                        # Empty line or comment, keep it
                                        new_lines.append(next_line)
                                        i += 1
                                        continue
                                    # Check indentation
                                    next_indent = len(next_line) - len(next_line.lstrip())
                                    if next_indent > override_indent:
                                        # Still in the same block, skip it
                                        i += 1
                                    else:
                                        # Same or less indentation, new key or end of dict
                                        break
                                continue
                        else:
                            # Could not determine dependency name, remove override_path to be safe
                            modified = True
                            print(f"  Removed override_path in {comp_name}/idf_component.yml: could not determine target component")
                            # Skip the override_path line (don't add it to new_lines)
                            i += 1
                            # Skip continuation lines (more indented lines after override_path)
                            while i < len(lines):
                                next_line = lines[i]
                                if not next_line.strip() or next_line.strip().startswith('#'):
                                    # Empty line or comment, keep it
                                    new_lines.append(next_line)
                                    i += 1
                                    continue
                                # Check indentation
                                next_indent = len(next_line) - len(next_line.lstrip())
                                if next_indent > override_indent:
                                    # Still in the same block, skip it
                                    i += 1
                                else:
                                    # Same or less indentation, new key or end of dict
                                    break
                            continue
                
                new_lines.append(line)
                i += 1
            
            # Write back if modified
            if modified:
                with open(yml_file, 'w', encoding='utf-8') as f:
                    f.writelines(new_lines)
        except Exception as e:
            print(f"  Warning: Failed to rewrite override_path in {comp_name}/idf_component.yml: {e}")

