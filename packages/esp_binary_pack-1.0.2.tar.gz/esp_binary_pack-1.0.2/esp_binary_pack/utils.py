"""
Utility functions for ESP-IDF Binary Pack Script
"""

import json
import os


def get_idf_path() -> str:
    """Get IDF_PATH from environment"""
    idf_path = os.environ.get('IDF_PATH')
    if not idf_path:
        raise RuntimeError("IDF_PATH environment variable is not set")
    return idf_path


def get_project_path() -> str:
    """Get current project path (assumed to be current working directory)"""
    return os.getcwd()


def read_project_description(build_dir: str) -> dict:
    """Read project_description.json from build directory"""
    desc_file = os.path.join(build_dir, 'project_description.json')
    if not os.path.exists(desc_file):
        raise FileNotFoundError(
            f"project_description.json not found in {build_dir}. "
            "Please build the project first with 'idf.py build'"
        )
    
    with open(desc_file, 'r', encoding='utf-8') as f:
        return json.load(f)

