# File Copy Analysis

## Issue Description

In previous versions, when a component was excluded from prebuilding (i.e., copied as source), valid `.a` (static library) files that were part of that component's source distribution might have been accidentally excluded.

## The Cause

The default exclusion rules included `*.a` or similar patterns intended to clean up build artifacts. However, some components include 3rd-party prebuilt libraries (e.g., `libfoo.a`) inside their source directories.

## The Fix

We have updated the file copier logic to **explicitly allow** `.a` files when copying a component directory, even if they might match other exclusion patterns (though standard build artifacts like `*.o` are still excluded).

### Exclusion Rules

The following are **EXCLUDED**:
- `build/` directories
- `.git/` directories
- `*.o` (Object files)
- `*.d` (Dependency files)
- `__pycache__` and `*.pyc`

The following are **PRESERVED**:
- `*.a` (Static libraries) - vital for components that wrap prebuilt binaries.
- All source files (`*.c`, `*.h`, `*.cpp`, etc.)
- `CMakeLists.txt` and `idf_component.yml`

This ensures that "source" components which rely on internal prebuilt blobs continue to work correctly in the generated project.
