# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-01-12

### Changed
- **Major**: Main component library is now placed in `prebuild_components/main/` alongside other prebuilt components.
- **Major**: Managed components are now moved to `components/` directory.
- **Major**: `EXTRA_COMPONENT_DIRS` is automatically configured in the root `CMakeLists.txt`.
- **Breaking**: The default output structure has changed significantly to support better component separation.

### Fixed
- Fixed an issue where `.a` files were excluded when copying components as source (see FILE_COPY_ANALYSIS.md).

## [0.2.0] - 2026-01-11

### Added
- Initial support for component exclusion via `--exclude`.
- Basic header extraction support.
