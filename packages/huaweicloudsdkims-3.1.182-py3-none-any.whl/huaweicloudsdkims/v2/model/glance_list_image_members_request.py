# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GlanceListImageMembersRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'image_id': 'str',
        'limit': 'int',
        'marker': 'str'
    }

    attribute_map = {
        'image_id': 'image_id',
        'limit': 'limit',
        'marker': 'marker'
    }

    def __init__(self, image_id=None, limit=None, marker=None):
        r"""GlanceListImageMembersRequest

        The model defined in huaweicloud sdk

        :param image_id: 镜像id
        :type image_id: str
        :param limit: 查询镜像成员列表时每页的数量。
        :type limit: int
        :param marker: 分页标识，用于查询下一页内容。
        :type marker: str
        """
        
        

        self._image_id = None
        self._limit = None
        self._marker = None
        self.discriminator = None

        self.image_id = image_id
        if limit is not None:
            self.limit = limit
        if marker is not None:
            self.marker = marker

    @property
    def image_id(self):
        r"""Gets the image_id of this GlanceListImageMembersRequest.

        镜像id

        :return: The image_id of this GlanceListImageMembersRequest.
        :rtype: str
        """
        return self._image_id

    @image_id.setter
    def image_id(self, image_id):
        r"""Sets the image_id of this GlanceListImageMembersRequest.

        镜像id

        :param image_id: The image_id of this GlanceListImageMembersRequest.
        :type image_id: str
        """
        self._image_id = image_id

    @property
    def limit(self):
        r"""Gets the limit of this GlanceListImageMembersRequest.

        查询镜像成员列表时每页的数量。

        :return: The limit of this GlanceListImageMembersRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this GlanceListImageMembersRequest.

        查询镜像成员列表时每页的数量。

        :param limit: The limit of this GlanceListImageMembersRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def marker(self):
        r"""Gets the marker of this GlanceListImageMembersRequest.

        分页标识，用于查询下一页内容。

        :return: The marker of this GlanceListImageMembersRequest.
        :rtype: str
        """
        return self._marker

    @marker.setter
    def marker(self, marker):
        r"""Sets the marker of this GlanceListImageMembersRequest.

        分页标识，用于查询下一页内容。

        :param marker: The marker of this GlanceListImageMembersRequest.
        :type marker: str
        """
        self._marker = marker

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GlanceListImageMembersRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
