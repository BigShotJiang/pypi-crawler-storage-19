"""Core SDK components."""
