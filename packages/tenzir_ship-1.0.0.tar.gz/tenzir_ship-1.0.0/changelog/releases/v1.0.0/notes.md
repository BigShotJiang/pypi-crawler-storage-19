This major release renames the package from `tenzir-changelog` to `tenzir-ship` and introduces several breaking changes to streamline the CLI interface. The `show` command now uses intuitive positional tokens (`unreleased`, `released`, `latest`, `all`) instead of flags, and the `release notes` command has been merged into `show --release`. A new `stats` command provides adaptive project statistics, and the table layout has been enhanced with better title formatting and inline component labels.

## 💥 Breaking changes

### Modules command replaced with global option

The `modules` command has been removed. Use the `--show-modules` global option instead to list discovered modules.

Migration:

```bash
# Before
tenzir-changelog modules

# After
tenzir-changelog --show-modules
```

The PATH column now displays clean relative paths (for example, `plugins/brand/changelog`) instead of paths with `../` prefixes (for example, `../plugins/brand/changelog`).

*By @mavam and @claude.*

### Package renamed from tenzir-changelog to tenzir-ship

The project has been renamed from `tenzir-changelog` to `tenzir-ship`. This includes the package name, CLI command, Python module, and GitHub repository.

**Migration:**

```bash
# Old
uvx tenzir-changelog add

# New
uvx tenzir-ship add
```

```python
# Old
from tenzir_changelog import Changelog

# New
from tenzir_ship import Changelog
```

All command names remain unchanged (`add`, `show`, `validate`, `release`). The repository has moved from `tenzir/changelog` to `tenzir/ship`.

The old `tenzir-changelog` PyPI package will remain available for a transition period but will not receive further updates.

*By @mavam and @claude.*

### Scope filtering flags replaced with positional tokens

The show command now uses positional scope tokens instead of flags to filter entries. The `--all`, `--released`, `--unreleased`, and `--latest` flags have been removed in favor of cleaner positional identifiers.

Use `show unreleased`, `show released`, `show latest`, or `show all` to filter entries by scope. The `--release` flag now purely controls presentation (grouping and metadata display) rather than affecting which entries are shown.

This change provides clearer separation between **what to show** (scope) and **how to show it** (presentation), making the command interface more intuitive.

**Breaking change:** `show --release` without identifiers now shows **all** entries grouped by release, whereas previously it defaulted to showing only the latest release. Use `show latest --release` to restore the previous behavior.

**Migration examples:**

- `show --unreleased` → `show unreleased`
- `show --released` → `show released`
- `show --latest` → `show latest`
- `show --all` → `show all` or just `show`
- `show --release` → `show latest --release` (to get previous behavior)
- `show --release --latest` → `show latest --release`

*By @mavam and @claude.*

### Unified show command replaces release notes

The `release notes` command has been removed and replaced by the unified `show` command with new `--release`, `--all`, and `--released-only` flags.

Previously, the CLI had two overlapping commands with different mental models: `show` displayed entries in a flat list, while `release notes` formatted them as release documents. This caused confusion because both produced similar JSON output for single releases but had different defaults and use cases.

The new design follows a single principle: **selection is always entry-centric, and `--release` is a display modifier**. Version identifiers like `v1.0.0` mean "entries from release v1.0.0", and the `--release` flag changes how those entries are presented—grouped by release with full metadata—rather than what gets selected.

**Migration guide**:

| Old command | New command | | ----------------------------- | ------------------------------ | | `release notes v1.0.0` | `show v1.0.0 --release -m` | | `release notes v1.0.0 --json` | `show v1.0.0 --release --json` | | `release notes -` | `show --release -m` | | `release notes - --json` | `show --release --json` |

**New capabilities**: The `--all` flag enables batch export of all releases in a single invocation.

```bash
# Export all releases as JSON (new)
tenzir-changelog show --all --release --json

# Export only released versions, excluding unreleased
tenzir-changelog show --all --release --released-only --json
```

This is particularly valuable for documentation sync scripts that previously required invoking the tool once per release. With ~320 releases across 7 projects, the sync time drops from ~2 minutes to ~2-3 seconds.

**JSON output consistency**: With `--release`, JSON output is always an array of release objects, even for a single release. This ensures deterministic parsing in scripts.

```json
[
  {
    "version": "v1.0.0",
    "title": "Release Title",
    "intro": "Release introduction...",
    "entries": [...]
  }
]
```

Without `--release`, JSON remains a single object with a flat `entries` array.

*By @mavam and @claude.*

## 🚀 Features

### Statistics command with adaptive view modes

The `stats` command replaces the `--stats` flag and automatically adapts its display based on project structure. For single projects, it shows a vertical card view with detailed statistics organized into sections (Project, Releases, Entry Types, Entry Status). For multi-module projects, it displays a compact table comparing all modules side-by-side.

The vertical view presents project metadata, release history with exponentially weighted cadence calculations, entry type distribution with percentages, and shipped vs unreleased counts. The table view uses emoji headers for consistent visual scanning across both formats.

Additional options include `--table` to force table view regardless of project structure, and `--json` to export structured data for programmatic consumption.

*By @mavam and @claude.*

## 🔧 Changes

### Enhanced table layout for show command

The title column now expands to fill available terminal width, ensuring optimal use of screen space. Component labels appear inline after the title in a dimmed green style, replacing the separate component column. The column order has been adjusted to show PR numbers before the entry type, and the column header changed from "PRs" to "PR". Empty PR values display as a dimmed dash for visual consistency.

*By @mavam and @claude.*

## 🐞 Bug fixes

### Markdown table formatting in release notes

Markdown tables in release notes and entry descriptions now render correctly. Previously, tables were collapsed into a single line because the `normalize_markdown()` function lacked GFM (GitHub Flavored Markdown) support.

The fix adds the `mdformat-gfm` plugin to enable proper table formatting. This ensures migration guides, comparison tables, and other tabular content display as intended in both CLI output and exported markdown files.

*By @mavam and @claude.*
