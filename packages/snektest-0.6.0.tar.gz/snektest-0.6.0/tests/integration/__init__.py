"""Integration tests for snektest."""
