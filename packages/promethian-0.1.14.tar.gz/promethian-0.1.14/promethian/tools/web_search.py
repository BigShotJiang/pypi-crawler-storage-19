"""Web search tool for Promethian.

Uses DuckDuckGo for web searches - no API key required.
This is a built-in tool that's always available to the agent.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any


@dataclass
class SearchResult:
    """A single search result."""
    title: str
    url: str
    snippet: str


@dataclass
class WebSearchResult:
    """Result from a web search."""
    success: bool
    results: list[SearchResult] | None = None
    error: str | None = None
    query: str = ""


class WebSearchTool:
    """
    Web search tool using DuckDuckGo.

    Provides:
    - search(query) - Search the web and get results
    - news_search(query) - Search for recent news
    """

    def __init__(self, max_results: int = 5):
        self.max_results = max_results
        self._ddgs = None

    def _ensure_ddgs(self):
        """Ensure DuckDuckGo search is available."""
        if self._ddgs is None:
            try:
                # Try new package name first
                from ddgs import DDGS
                self._ddgs = DDGS()
            except ImportError:
                try:
                    # Fall back to old package name
                    from duckduckgo_search import DDGS
                    self._ddgs = DDGS()
                except ImportError:
                    raise RuntimeError(
                        "ddgs not installed. Run: pip install ddgs"
                    )
        return self._ddgs

    async def search(
        self,
        query: str,
        max_results: int | None = None,
        region: str = "wt-wt",
    ) -> WebSearchResult:
        """
        Search the web using DuckDuckGo.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)
            region: Region for results (default: worldwide)

        Returns:
            WebSearchResult with list of results
        """
        try:
            ddgs = self._ensure_ddgs()
            num_results = max_results or self.max_results

            # Run in thread pool since ddgs is synchronous
            loop = asyncio.get_event_loop()
            raw_results = await loop.run_in_executor(
                None,
                lambda: list(ddgs.text(query, max_results=num_results, region=region))
            )

            results = [
                SearchResult(
                    title=r.get("title", ""),
                    url=r.get("href", r.get("link", "")),
                    snippet=r.get("body", r.get("snippet", "")),
                )
                for r in raw_results
            ]

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
            )

    async def news_search(
        self,
        query: str,
        max_results: int | None = None,
        region: str = "wt-wt",
    ) -> WebSearchResult:
        """
        Search for recent news using DuckDuckGo.

        Args:
            query: The search query
            max_results: Maximum number of results (default: 5)
            region: Region for results (default: worldwide)

        Returns:
            WebSearchResult with list of news results
        """
        try:
            ddgs = self._ensure_ddgs()
            num_results = max_results or self.max_results

            # Run in thread pool since ddgs is synchronous
            loop = asyncio.get_event_loop()
            raw_results = await loop.run_in_executor(
                None,
                lambda: list(ddgs.news(query, max_results=num_results, region=region))
            )

            results = [
                SearchResult(
                    title=r.get("title", ""),
                    url=r.get("url", r.get("link", "")),
                    snippet=r.get("body", r.get("excerpt", "")),
                )
                for r in raw_results
            ]

            return WebSearchResult(
                success=True,
                results=results,
                query=query,
            )

        except Exception as e:
            return WebSearchResult(
                success=False,
                error=str(e),
                query=query,
            )

    def get_tool_schemas(self) -> list[dict]:
        """Get Claude tool schemas for web search actions."""
        return [
            {
                "name": "web_search",
                "description": (
                    "Search the web using DuckDuckGo. Returns titles, URLs, and snippets "
                    "for the top results. Use this to find information, documentation, "
                    "tutorials, or any web content."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "web_news_search",
                "description": (
                    "Search for recent news articles using DuckDuckGo. Returns titles, "
                    "URLs, and snippets for recent news. Use this for current events "
                    "or recent developments."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "The news search query"
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of results (default 5, max 10)",
                            "default": 5
                        }
                    },
                    "required": ["query"]
                }
            },
        ]

    async def execute_tool(self, name: str, params: dict) -> WebSearchResult:
        """Execute a web search tool by name."""
        max_results = min(params.get("max_results", 5), 10)  # Cap at 10

        if name == "web_search":
            return await self.search(
                query=params["query"],
                max_results=max_results,
            )
        elif name == "web_news_search":
            return await self.news_search(
                query=params["query"],
                max_results=max_results,
            )
        else:
            return WebSearchResult(
                success=False,
                error=f"Unknown web search tool: {name}",
                query=params.get("query", ""),
            )


# Singleton web search tool instance
_web_search: WebSearchTool | None = None


def get_web_search(max_results: int = 5) -> WebSearchTool:
    """Get the global web search tool instance."""
    global _web_search
    if _web_search is None:
        _web_search = WebSearchTool(max_results=max_results)
    return _web_search


def reset_web_search() -> None:
    """Reset the global web search tool instance."""
    global _web_search
    _web_search = None
