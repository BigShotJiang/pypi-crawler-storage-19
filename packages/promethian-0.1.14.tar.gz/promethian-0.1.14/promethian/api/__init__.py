"""API client for Promethian central server."""
