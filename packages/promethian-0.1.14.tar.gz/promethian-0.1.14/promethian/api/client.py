"""API client for Promethian central server."""

from __future__ import annotations

import os
from datetime import datetime
from dataclasses import dataclass, field
from typing import Any

import httpx

from promethian.core.types import Skill, Tool, SkillSearchResult, ToolSearchResult


@dataclass
class SessionInfo:
    """Information about an active session."""
    session_id: str
    expires_at: datetime
    items_retrieved: list[str] = field(default_factory=list)


@dataclass
class ContributionResult:
    """Result of contributing a skill or tool."""
    status: str
    item_id: str | None = None
    quality_score: float | None = None
    message: str = ""
    merged_with: str | None = None


class PromethianAPIClient:
    """
    Client for the Promethian central knowledge API.

    Handles authentication, session management, and all API calls.
    """

    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 120.0,
    ):
        self.api_url = (
            api_url
            or os.environ.get("PROMETHIAN_API_URL")
            or "https://promethian-api.fly.dev"
        )
        self.api_key = api_key or os.environ.get("PROMETHIAN_API_KEY") or os.environ.get("PROMETHIAN_AUTH_TOKEN")

        if not self.api_key:
            raise ValueError(
                "Promethian auth token is required. Run setup again."
            )

        self.timeout = timeout
        self._token: str | None = None
        self._token_expires: datetime | None = None
        self._session: SessionInfo | None = None
        self._client = httpx.AsyncClient(timeout=timeout)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "PromethianAPIClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    # ============================================
    # AUTHENTICATION
    # ============================================

    async def _ensure_token(self) -> str:
        """Ensure we have a valid access token."""
        # Device tokens (pmt_...) are used directly
        if self.api_key.startswith("pmt_"):
            return self.api_key

        # Legacy API keys need JWT exchange
        if self._token and self._token_expires:
            if datetime.utcnow() < self._token_expires:
                return self._token

        response = await self._client.post(
            f"{self.api_url}/auth/token",
            json={"api_key": self.api_key},
        )
        response.raise_for_status()
        data = response.json()

        self._token = data["access_token"]
        self._token_expires = datetime.fromisoformat(
            data["expires_at"].replace("Z", "+00:00")
        )

        return self._token

    async def _headers(self) -> dict:
        """Get headers for authenticated requests."""
        token = await self._ensure_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    # ============================================
    # SESSION MANAGEMENT
    # ============================================

    async def start_session(self, task_description: str) -> SessionInfo:
        """
        Start a new task session.

        Sessions are required before searching for skills/tools.
        """
        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/session/start",
            json={"task_description": task_description},
            headers=headers,
        )

        if response.status_code == 400:
            # Already have active session
            error = response.json()
            raise ValueError(error.get("detail", "Session error"))

        response.raise_for_status()
        data = response.json()

        self._session = SessionInfo(
            session_id=data["session_id"],
            expires_at=datetime.fromisoformat(
                data["expires_at"].replace("Z", "+00:00")
            ),
        )

        return self._session

    async def get_current_session(self) -> SessionInfo | None:
        """Get the current active session if any."""
        headers = await self._headers()
        response = await self._client.get(
            f"{self.api_url}/session/current",
            headers=headers,
        )
        response.raise_for_status()

        if response.status_code == 200 and response.json():
            data = response.json()
            self._session = SessionInfo(
                session_id=data["session_id"],
                expires_at=datetime.fromisoformat(
                    data["expires_at"].replace("Z", "+00:00")
                ),
                items_retrieved=[],  # Will be populated as we search
            )
            return self._session

        return None

    async def complete_session(
        self,
        overall_success: bool | None = None,
        items_feedback: list[dict] | None = None,
        new_skills: list[dict] | None = None,
        new_tools: list[dict] | None = None,
        self_heal_steps: int = 0,
        notes: str | None = None,
        # New parameters for enhanced feedback
        session_id: str | None = None,  # Allow explicit session_id
        success_score: float | None = None,  # 0-1 nuanced score
        satisfaction_signals: list[dict] | None = None,
        conversation_length: int = 1,
        had_refinements: bool = False,
        user_initiated_close: bool = True,
    ) -> dict:
        """
        Complete the current session with feedback.

        This MUST be called before starting a new session.

        Args:
            overall_success: Legacy boolean success (optional if success_score provided)
            items_feedback: Feedback for each retrieved item
            new_skills: New skills to contribute
            new_tools: New tools to contribute
            self_heal_steps: Number of self-healing attempts
            notes: Additional notes
            session_id: Explicit session ID (optional, uses current session if not provided)
            success_score: Nuanced success score 0-1 (preferred over overall_success)
            satisfaction_signals: List of satisfaction signals from conversation
            conversation_length: Number of user turns in conversation
            had_refinements: Whether user needed to correct/refine
            user_initiated_close: Whether user explicitly ended (vs timeout)
        """
        # Determine session ID
        sid = session_id or (self._session.session_id if self._session else None)
        if not sid:
            raise ValueError("No active session to complete")

        # Build request body
        body = {
            "session_id": sid,
            "items_feedback": items_feedback or [],
            "new_skills": new_skills or [],
            "new_tools": new_tools or [],
            "self_heal_steps": self_heal_steps,
            "notes": notes,
            "conversation_length": conversation_length,
            "had_refinements": had_refinements,
            "user_initiated_close": user_initiated_close,
        }

        # Prefer success_score over overall_success
        if success_score is not None:
            body["success_score"] = success_score
        elif overall_success is not None:
            body["overall_success"] = overall_success

        # Add satisfaction signals if provided
        if satisfaction_signals:
            body["satisfaction_signals"] = satisfaction_signals

        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/session/complete",
            json=body,
            headers=headers,
        )
        response.raise_for_status()

        self._session = None
        return response.json()

    @property
    def has_active_session(self) -> bool:
        """Check if there's an active session."""
        if not self._session:
            return False
        return datetime.utcnow() < self._session.expires_at

    # ============================================
    # SEARCH
    # ============================================

    async def search_skills(
        self,
        query: str,
        max_results: int = 5,
        min_similarity: float = 0.3,
        include_content: bool = True,
        tags: list[str] | None = None,
    ) -> tuple[list[SkillSearchResult], str]:
        """
        Search for relevant skills.

        Returns (results, query_id). The query_id is needed to access full content.
        """
        if not self.has_active_session:
            raise ValueError("Active session required. Call start_session first.")

        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/skills/search",
            json={
                "query": query,
                "max_results": max_results,
                "min_similarity": min_similarity,
                "include_content": include_content,
                "tags": tags,
            },
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        results = []
        for item in data["results"]:
            results.append(SkillSearchResult(
                id=item["id"],
                name=item["name"],
                description=item["description"],
                tags=item["tags"],
                similarity_score=item["similarity_score"],
                success_rate=item["success_rate"],
                usage_count=item["usage_count"],
                content=item.get("content"),
            ))

            # Track retrieved items
            if self._session:
                self._session.items_retrieved.append(item["id"])

        return results, data["query_id"]

    async def search_tools(
        self,
        query: str,
        max_results: int = 5,
        min_similarity: float = 0.3,
        include_content: bool = True,
        tags: list[str] | None = None,
    ) -> tuple[list[ToolSearchResult], str]:
        """
        Search for relevant tools.

        Returns (results, query_id). The query_id is needed to access full content.
        """
        if not self.has_active_session:
            raise ValueError("Active session required. Call start_session first.")

        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/tools/search",
            json={
                "query": query,
                "max_results": max_results,
                "min_similarity": min_similarity,
                "include_content": include_content,
                "tags": tags,
            },
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        results = []
        for item in data["results"]:
            results.append(ToolSearchResult(
                id=item["id"],
                name=item["name"],
                description=item["description"],
                function_name=item["function_name"],
                parameters=item["parameters"],
                dependencies=item.get("dependencies", []),
                tags=item["tags"],
                similarity_score=item["similarity_score"],
                success_rate=item["success_rate"],
                usage_count=item["usage_count"],
                code=item.get("code"),
            ))

            # Track retrieved items
            if self._session:
                self._session.items_retrieved.append(item["id"])

        return results, data["query_id"]

    # ============================================
    # ITEM ACCESS
    # ============================================

    async def get_skill(self, skill_id: str, query_id: str) -> Skill:
        """Get a skill by ID. Requires query_id from a recent search."""
        headers = await self._headers()
        headers["X-Query-ID"] = query_id

        response = await self._client.get(
            f"{self.api_url}/skills/{skill_id}",
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        return Skill.from_dict(data)

    async def get_tool(self, tool_id: str, query_id: str) -> Tool:
        """Get a tool by ID. Requires query_id from a recent search."""
        headers = await self._headers()
        headers["X-Query-ID"] = query_id

        response = await self._client.get(
            f"{self.api_url}/tools/{tool_id}",
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        return Tool.from_dict(data)

    # ============================================
    # CONTRIBUTION
    # ============================================

    async def contribute_skill(
        self,
        skill: Skill,
        source_task: str | None = None,
        execution_success: bool = True,
    ) -> ContributionResult:
        """Submit a skill as a contribution."""
        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/skills/contribute",
            json={
                "name": skill.name,
                "description": skill.description,
                "content": skill.content,
                "tags": skill.tags,
                "source_task": source_task,
                "execution_success": execution_success,
            },
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        return ContributionResult(
            status=data["status"],
            item_id=data.get("item_id"),
            quality_score=data.get("quality_score"),
            message=data.get("message", ""),
            merged_with=data.get("merged_with"),
        )

    async def contribute_tool(
        self,
        tool: Tool,
        source_task: str | None = None,
        execution_success: bool = True,
    ) -> ContributionResult:
        """Submit a tool as a contribution."""
        headers = await self._headers()
        response = await self._client.post(
            f"{self.api_url}/tools/contribute",
            json={
                "name": tool.name,
                "description": tool.description,
                "code": tool.code,
                "function_name": tool.function_name,
                "parameters": tool.parameters,
                "dependencies": tool.dependencies,
                "tags": tool.tags,
                "source_task": source_task,
                "execution_success": execution_success,
            },
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()

        return ContributionResult(
            status=data["status"],
            item_id=data.get("item_id"),
            quality_score=data.get("quality_score"),
            message=data.get("message", ""),
            merged_with=data.get("merged_with"),
        )

    # ============================================
    # HEALTH CHECK
    # ============================================

    async def health_check(self) -> dict:
        """Check API health status."""
        response = await self._client.get(f"{self.api_url}/health")
        response.raise_for_status()
        return response.json()
