"""Claude SDK wrapper for Promethian Agent."""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any

import anthropic


# Model pricing per 1M tokens (as of 2025)
MODEL_PRICING = {
    "claude-opus-4-5-20251101": {"input": 15.00, "output": 75.00},
    "claude-opus-4-20250514": {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-20250514": {"input": 3.00, "output": 15.00},
    "claude-haiku-3-5-20241022": {"input": 0.80, "output": 4.00},
    # Fallback for unknown models
    "default": {"input": 3.00, "output": 15.00},
}


@dataclass
class ModelUsage:
    """Token usage for a specific model."""
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    api_calls: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def estimated_cost(self) -> float:
        """Estimate cost in USD based on token usage."""
        pricing = MODEL_PRICING.get(self.model, MODEL_PRICING["default"])
        input_cost = (self.input_tokens / 1_000_000) * pricing["input"]
        output_cost = (self.output_tokens / 1_000_000) * pricing["output"]
        return input_cost + output_cost


@dataclass
class UsageStats:
    """Aggregated usage statistics across all models."""
    by_model: dict[str, ModelUsage] = field(default_factory=dict)

    @property
    def total_input_tokens(self) -> int:
        return sum(m.input_tokens for m in self.by_model.values())

    @property
    def total_output_tokens(self) -> int:
        return sum(m.output_tokens for m in self.by_model.values())

    @property
    def total_tokens(self) -> int:
        return self.total_input_tokens + self.total_output_tokens

    @property
    def total_api_calls(self) -> int:
        return sum(m.api_calls for m in self.by_model.values())

    @property
    def estimated_cost(self) -> float:
        """Total estimated cost in USD."""
        return sum(m.estimated_cost for m in self.by_model.values())

    def record(self, model: str, input_tokens: int, output_tokens: int) -> None:
        """Record usage for a model."""
        if model not in self.by_model:
            self.by_model[model] = ModelUsage(model=model)
        self.by_model[model].input_tokens += input_tokens
        self.by_model[model].output_tokens += output_tokens
        self.by_model[model].api_calls += 1

    def merge(self, other: "UsageStats") -> None:
        """Merge another UsageStats into this one."""
        for model, usage in other.by_model.items():
            if model not in self.by_model:
                self.by_model[model] = ModelUsage(model=model)
            self.by_model[model].input_tokens += usage.input_tokens
            self.by_model[model].output_tokens += usage.output_tokens
            self.by_model[model].api_calls += usage.api_calls

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_tokens,
            "total_api_calls": self.total_api_calls,
            "estimated_cost_usd": round(self.estimated_cost, 4),
            "by_model": {
                model: {
                    "input_tokens": usage.input_tokens,
                    "output_tokens": usage.output_tokens,
                    "api_calls": usage.api_calls,
                    "estimated_cost_usd": round(usage.estimated_cost, 4),
                }
                for model, usage in self.by_model.items()
            },
        }


class ClaudeClient:
    """
    Wrapper around the Anthropic Claude SDK.

    Handles completions, structured output, and tool use.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "claude-opus-4-5-20251101",
        max_tokens: int = 8192,
        track_usage: bool = True,
    ):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY is required. "
                "Set it in your environment or pass it to the client."
            )

        self.client = anthropic.Anthropic(api_key=self.api_key)
        self.model = model
        self.max_tokens = max_tokens
        self.track_usage = track_usage
        self._usage = UsageStats()

    @property
    def usage(self) -> UsageStats:
        """Get current usage statistics."""
        return self._usage

    def reset_usage(self) -> None:
        """Reset usage statistics."""
        self._usage = UsageStats()

    def _record_usage(self, response: Any, model: str) -> None:
        """Record usage from an API response."""
        if self.track_usage and hasattr(response, "usage"):
            self._usage.record(
                model=model,
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )

    async def complete(
        self,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float = 0.7,
    ) -> str:
        """Get a text completion from Claude."""
        messages = [{"role": "user", "content": prompt}]
        used_model = model or self.model

        kwargs = {
            "model": used_model,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": messages,
            "temperature": temperature,
        }

        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        self._record_usage(response, used_model)

        return response.content[0].text

    async def complete_json(
        self,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> dict:
        """
        Get a JSON-structured completion from Claude.

        Instructs Claude to return valid JSON and parses the response.
        """
        full_prompt = f"""{prompt}

Respond with valid JSON only. No markdown code blocks, no explanation, just the JSON object."""

        response = await self.complete(
            prompt=full_prompt,
            system=system,
            model=model,
            max_tokens=max_tokens,
            temperature=0.3,  # Lower temperature for structured output
        )

        return self._parse_json(response)

    def _parse_json(self, text: str) -> dict:
        """Parse JSON from response, handling markdown code blocks."""
        json_str = text.strip()

        # Remove markdown code blocks if present
        if json_str.startswith("```"):
            json_str = re.sub(r"^```(?:json)?\n?", "", json_str)
            json_str = re.sub(r"\n?```$", "", json_str)

        return json.loads(json_str)

    async def complete_with_tools(
        self,
        prompt: str,
        tools: list[dict],
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> tuple[str, list[dict]]:
        """
        Get a completion with tool use from Claude.

        Returns (text_content, tool_calls) where tool_calls is a list of
        {id, name, input} dictionaries.
        """
        messages = [{"role": "user", "content": prompt}]
        used_model = model or self.model

        kwargs = {
            "model": used_model,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": messages,
            "tools": tools,
        }

        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        self._record_usage(response, used_model)

        # Extract text and tool calls
        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                })

        return "\n".join(text_parts), tool_calls

    async def continue_with_tool_result(
        self,
        messages: list[dict],
        tool_results: list[dict],
        tools: list[dict],
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> tuple[str, list[dict]]:
        """
        Continue a conversation after tool execution.

        tool_results should be a list of {tool_use_id, content} dicts.
        """
        # Add tool results as assistant turn
        tool_result_content = [
            {
                "type": "tool_result",
                "tool_use_id": r["tool_use_id"],
                "content": r["content"],
            }
            for r in tool_results
        ]

        messages = messages + [{"role": "user", "content": tool_result_content}]
        used_model = model or self.model

        kwargs = {
            "model": used_model,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": messages,
            "tools": tools,
        }

        if system:
            kwargs["system"] = system

        response = self.client.messages.create(**kwargs)
        self._record_usage(response, used_model)

        # Extract text and tool calls
        text_parts = []
        tool_calls = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                })

        return "\n".join(text_parts), tool_calls
