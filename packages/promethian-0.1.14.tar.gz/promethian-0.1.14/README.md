# Promethian

A self-improving AI agent that learns from every task.

## Installation

```bash
# Recommended: use pipx for isolated install
pipx install promethian

# Or with pip
pip install promethian
```

Requires Python 3.10+

## Quick Start

```bash
promethian
```

This opens an interactive REPL. On first run, you'll be prompted to:
1. Enter your Anthropic API key
2. Create a free Promethian account (via email)

Then just type tasks:

```
> build a web scraper for hacker news
[agent plans and executes...]

> add error handling and retry logic
[agent continues...]

> /help
```

## One-off Tasks

Run a single task without entering the REPL:

```bash
promethian "analyze this CSV and create a summary report"
```

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/search <query>` | Search the knowledge base |
| `/config` | Show current configuration |
| `/set <key> <value>` | Change a setting |
| `/register` | Login to Promethian |
| `/quit` | Exit |

## Configuration

Config is stored in `~/.promethian/config.json`. You can also use environment variables:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
export PROMETHIAN_AUTH_TOKEN=pmt_...
```

## How It Works

Promethian runs locally on your machine using your Anthropic API key. It:

1. **Plans** - Breaks down your task into steps
2. **Executes** - Runs each step, using tools when needed
3. **Learns** - Extracts reusable skills and tools
4. **Shares** - Contributes learnings to the community knowledge base

The knowledge base at promethian.io stores skills and tools that improve over time as more people use them.

## Requirements

- Python 3.10+
- Anthropic API key ([get one here](https://console.anthropic.com))
- Free Promethian account (created via CLI)

## License

MIT
