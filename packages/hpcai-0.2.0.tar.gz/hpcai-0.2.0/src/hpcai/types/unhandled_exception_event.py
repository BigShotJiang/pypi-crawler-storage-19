# Copyright 2025 Thinking Machines Lab
#
# Licensed under the Apache License, Version 2.0
#
# Modifications:
# - Adapted for HPC-AI cloud fine-tuning workflow
# Copyright © 2025 HPC-AI.COM

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel
from .severity import Severity
from .event_type import EventType

__all__ = ["UnhandledExceptionEvent"]


class UnhandledExceptionEvent(BaseModel):
    error_message: str

    error_type: str

    event: EventType
    """Telemetry event type"""

    event_id: str

    event_session_index: int

    severity: Severity
    """Log severity level"""

    timestamp: datetime

    traceback: Optional[str] = None
    """Optional Python traceback string"""
