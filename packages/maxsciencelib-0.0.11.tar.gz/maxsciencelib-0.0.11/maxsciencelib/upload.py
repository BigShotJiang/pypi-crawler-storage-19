import os
import time
from typing import Optional, List

from selenium import webdriver
from selenium.webdriver.edge.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def upload_sharepoint(
    url_sharepoint: str,
    diretorio: str,
    tempo_espera_fim: int = 20,
    timeout: int = 30
) -> None:
    """
    Realiza upload automático de todos os arquivos de um diretório para um
    diretório do SharePoint utilizando Selenium + Edge.

    Parâmetros
    ----------
    url_sharepoint : str
        URL do diretório do SharePoint onde os arquivos serão carregados
    diretorio : str
        Caminho local contendo APENAS os arquivos a serem enviados
    tempo_espera_fim : int, opcional
        Tempo em segundos para aguardar após o upload antes de fechar o navegador
    timeout : int, opcional
        Timeout máximo (em segundos) para esperar elementos na página

    Retorno
    -------
    None

    Exceções
    --------
    FileNotFoundError
        Se o diretório não existir ou estiver vazio
    RuntimeError
        Se ocorrer erro durante a automação
    """

    if not os.path.isdir(diretorio):
        raise FileNotFoundError(f"Diretório não encontrado: {diretorio}")

    arquivos: List[str] = [
        os.path.join(diretorio, f)
        for f in os.listdir(diretorio)
        if os.path.isfile(os.path.join(diretorio, f))
    ]

    if not arquivos:
        raise FileNotFoundError(f"Nenhum arquivo encontrado em: {diretorio}")

    options = Options()
    options.add_argument("--start-maximized")

    driver = webdriver.Edge(options=options)
    wait = WebDriverWait(driver, timeout)

    try:
        driver.get(url_sharepoint)

        def clicar(xpath: str):
            wait.until(EC.element_to_be_clickable((By.XPATH, xpath))).click()

        clicar("//span[text()='Carregar']")
        clicar("//button[.//span[text()='Arquivos']]")

        input_file = wait.until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file']"))
        )
        input_file.send_keys("\n".join(arquivos))

        # Tenta clicar em "Substituir tudo" se existir
        try:
            wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, "//button[.//span[contains(text(), 'Substituir tudo')]]")
                )
            ).click()
        except Exception:
            pass

        time.sleep(tempo_espera_fim)

    except Exception as e:
        raise RuntimeError(f"Erro ao realizar upload no SharePoint: {e}") from e

    finally:
        driver.quit()
