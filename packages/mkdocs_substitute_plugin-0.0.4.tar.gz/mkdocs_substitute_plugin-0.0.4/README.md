# mkdocs SUBSTITUTE

For more information about this package please visit
[this homepage](https://www.code-is-poetry.de/substitute_eng/)
