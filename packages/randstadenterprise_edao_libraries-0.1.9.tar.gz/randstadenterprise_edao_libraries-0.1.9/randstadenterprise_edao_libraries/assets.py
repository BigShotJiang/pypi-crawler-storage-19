# randstadenterprise_edao_libraries/assets.py
import requests
from typing import List, Dict, Any, Optional, Callable, Union

from . import helpers # Provides get_http_headers, array_to_csv
from . import logs    # Provides log function (for type hinting)
from . import objects # Import all dataclasses
from . import http # Import all dataclasses

from randstadenterprise_edao_libraries.objects import Asset

# Define the type for the log function for clean type hinting
LogFunc = Callable[[str], None] 

# =======================================================================
# CORE API RETRIEVAL FUNCTIONS (GET_ALL)
# =======================================================================

# =======================================================================
#     Retrieves ALL repositories (owned or shared) from a Domo instance by handling full pagination.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :returns: A single list containing all raw asset dictionary objects.
# =======================================================================
def get_instance_assets (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[objects.Asset]:

    log_func(f'____ get_instance_assets({inst_url})')
    
    all_assets: List[objects.Asset] = [] 
    
    asset_page_results = _get_instance_assets_page (inst_url, inst_dev_token, log_func, 0, 30)
    all_assets = _load_asset_objects(log_func, asset_page_results)

    log_func(f"_______ TOTAL ASSETS: {str(len(all_assets))}")
    
    log_func(f"____ END get_instance_assets: {inst_url}")
    
    return all_assets

# END def get_instance_assets

# =======================================================================
#     Retrieves a repository by id
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :returns: A single asset object.
# =======================================================================
def get_asset_by_id (inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str) -> objects.Asset:

    log_func(f'____ get_asset_by_id({inst_url})')
    api_url = f"https://{inst_url}.domo.com/api/apps/v1/designs/{asset_id}?parts=owners%2Ccards%2Cversions%2Ccreator"

    resp = http.get(api_url, inst_dev_token, log_func)
    
    asset_object = _load_asset_object(log_func, resp)
        
    log_func(f"____ END get_asset_by_id: {inst_url}")
    
    return asset_object

# END def get_asset_by_id

# =======================================================================
#     Add Asset Owner
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :param owner_id: The user id to add
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
def add_asset_owner (inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str, owner_id) -> Optional[str]:

    log_func(f'____ add_asset_owner({inst_url})')  
    
    asset = get_asset_by_id (inst_url, inst_dev_token, log_func, asset_id)
    asset_owners = asset.owners
    
    ext_owner_ids = []
    for eo in ext_owner_ids:
        ext_owner_id = eo.id
        ext_owner_ids.append(str(ext_owner_id))
    # END for o in asset_owners:
        
    ext_owner_ids.append(str(owner_id))
    
    body = ext_owner_ids
    api_url = f"https://{inst_url}.domo.com/api/apps/v1/designs/{asset_id}/permissions/ADMIN"
    
    resp = http.post(api_url, inst_dev_token, log_func, body)
        
    log_func(f"____ END add_asset_owner: {inst_url}")
    
    return "SUCCESS"

# END def add_asset_owner

# =======================================================================
#     Remove Asset Owner
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :param owner_id: The user id to remove
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
def remove_asset_owner (inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str, owner_id) -> Optional[str]:

    log_func(f'____ remove_asset_owner({inst_url})')  
    
    api_url = f"https://{inst_url}.domo.com/domoapps/designs/{asset_id}/permissions/ADMIN/ids?users={owner_id}"
    
    resp = http.delete(api_url, inst_dev_token, log_func)
        
    log_func(f"____ END remove_asset_owner: {inst_url}")
    
    return "SUCCESS"  

# END def remove_asset_owner

# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# PRIVATE: LOAD ASSET OBJECTS
#     (PRIVATE) Retrieves a single page of datasets using the PyDomo SDK.
    
#     :param datasets_json: json array of dataset data
#     :param log_func: Pre-bound logging function.
#     :returns: A list of dataset dictionary objects.
# =======================================================================
# def _load_asset_objects (log_func: LogFunc, json_array: Any) -> List[Dict[str, Asset]]:
    
#     # log_func(f"____ _load_asset_objects(datasets_json={str(json_array)})")
#     # log_func(f"______ _load_asset_objects(datasets_json={str(len(json_array))})")
    
#     # Change to a list
#     objects = [] 
#     if json_array is not None:
#         for json in json_array:
#             obj = _load_asset_object (log_func, json)
            
#             # Change to .append()
#             objects.append(obj)
            
#     return objects

# # END def _load_asset_objects


def _load_asset_objects(log_func: LogFunc, json_array: Any) -> List[objects.Asset]:
    """
    Parses a list of raw JSON objects into a list of objects.Asset instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_asset_object(log_func, json_item)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_asset_objects

# =======================================================================
# PRIVATE: LOAD ASSET OBJECT
#     (PRIVATE) Retrieves a single page of datasets using the PyDomo SDK.
    
#     :param json: json of dataset data
#     :param log_func: Pre-bound logging function.
#     :returns: A list of dataset dictionary objects.
# =======================================================================
# def _load_asset_object (log_func: LogFunc, json: Any) -> Optional[objects.Asset]:
    
#     # log_func(f"____ _load_asset_object(dataset_json={str(json)})")
#     # log_func(f"______ _load_asset_object(dataset_json={str(json.get('name', ''))})")

#     object = None
#     if json is not None:
#         return objects.Asset (
#             asset_id=json.get('id', ''),
#             name=json.get('name', ''),
#             owner=json.get('owner', ''),

#             created_by=json.get('createdBy', ''),
#             created_date=json.get('createdDate', ''),
#             updated_by=json.get('updatedBy', ''),
#             updated_date=json.get('updatedDate', ''),

#             latest_version=json.get('latestVersion', ''),
#             owners=json.get('owners', {}),
#             creator=json.get('creator', {}),
            
#             # Now fields with defaults
#             description=json.get('description', None),
#             versions=json.get('versions', {}),
#             instances=json.get('instances', []),
#             referencing_cards=json.get('referencingCards', []),

#             deleted_date=json.get('deletedDate', None),
#             trusted=json.get('trusted', False),
#             has_thumbnail=json.get('hasThumbnail', True),

#         )        
#     # END json is not None:

#     # log_func(f"____ END _load_asset_object(dataset_json={str(json)})")
#     # log_func(f"______ END _load_asset_object(dataset_json={str(json.name)})")

#     return object
# # END def _load_asset_object


def _load_asset_object(log_func: LogFunc, json: Any) -> objects.Asset:
    """
    Parses raw JSON into an objects.Asset instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_asset_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the Asset object
        return objects.Asset (
            asset_id=json.get('id', ''),
            name=json.get('name', ''),
            owner=json.get('owner', ''),

            created_by=json.get('createdBy', ''),
            created_date=json.get('createdDate', ''),
            updated_by=json.get('updatedBy', ''),
            updated_date=json.get('updatedDate', ''),

            latest_version=json.get('latestVersion', ''),
            owners=json.get('owners', {}),
            creator=json.get('creator', {}),
            
            # Now fields with defaults
            description=json.get('description', None),
            versions=json.get('versions', {}),
            instances=json.get('instances', []),
            referencing_cards=json.get('referencingCards', []),

            deleted_date=json.get('deletedDate', None),
            trusted=json.get('trusted', False),
            has_thumbnail=json.get('hasThumbnail', True),

        )       
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate objects.Asset. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_asset_object(log_func: LogFunc, json: Any) -> objects.Asset:    


# =======================================================================
# =======================================================================
# =======================================================================
# PRIVATE API HELPER FUNCTIONS
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# (PRIVATE HELPER) Fetches a single paginated result of assests.
#     Used by get_instance_assests
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param offset: The starting index for pagination.
#     :param limit: The number of results to return.
#     :returns: The raw JSON response dictionary containing 'assets' or an empty dict on error.
# =======================================================================
def _get_instance_assets_page (inst_url: str, inst_dev_token: str, log_func: LogFunc, offset: int, limit: int) -> Any:

    log_func(f'_______ _get_instance_assets_page(offset: {str(offset)}, limit: {str(limit)})')

    api_url_query = f'?checkAdminAuthority=true&deleted=false&direction=desc&limit={limit}&offset={offset}&order=updated&parts=owners&parts=creator&parts=thumbnail&parts=versions&search=&withPermission=ADMIN'
    api_url = f'https://{inst_url}.domo.com/api/apps/v1/designs{api_url_query}'
    
    page_result = http.get(api_url, inst_dev_token, log_func)
        
    log_func('_______ END _get_instance_assets_page()')

    return page_result
# END def _get_instance_assets_page


def _get_invited_domains (inst_url: str, inst_dev_token: str, repo_id: str, log_func: LogFunc) -> List[Dict[str, str]]:
    """
    (PRIVATE HELPER) Fetches the list of domains an owned repository has been shared with.
    Used by get_instance_repositories_map for owned repositories.
    
    :param inst_url: The Domo instance URL prefix.
    :param inst_dev_token: The developer token.
    :param repo_id: The ID of the repository.
    :param log_func: Pre-bound logging function.
    :returns: A list of dictionaries, each containing 'repositoryId' and 'invitedDomain'.
    """

    log_func(f'____________________ _getInvitedDomains(repo_id: {repo_id})')

    api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/access'
    
    invited_domains_result = []
    
    try:
        # START try
        resp = requests.get(api_url, headers=helpers.get_http_headers(inst_dev_token), timeout=20)
        resp.raise_for_status() 
        
        invited_domains_json = resp.json()
        # Extract the 'accessList' array, ensuring it exists and is a list
        if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list):
            # START if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list)
            invited_domains_result = invited_domains_json["accessList"]
            # END if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list)
            
        # END try
    except requests.exceptions.RequestException as e:
        # START except requests.exceptions.RequestException
        log_func(f"ERROR fetching invited domains (repo_id: {repo_id}): {type(e).__name__} - {e}")
        # END except requests.exceptions.RequestException
        
    log_func('____________________ END _getInvitedDomains()')

    return invited_domains_result
# END def _get_invited_domains


def _get_repository_owners (
    inst_url: str, inst_dev_token: str, shared_repos: bool, repo_id: str, deploy_id: Optional[str], log_func: LogFunc
) -> Dict[str, Any]:
    """
    (PRIVATE HELPER) Fetches user and group permissions for a repository (or deployment).
    Used by get_instance_repositories_map.
    
    :param inst_url: The Domo instance URL prefix.
    :param inst_dev_token: The developer token.
    :param shared_repos: If True, the permissions are for a shared deployment; False for an owned repo.
    :param repo_id: The ID of the repository.
    :param deploy_id: The deployment ID, required if shared_repos is True.
    :param log_func: Pre-bound logging function.
    :returns: A dictionary containing 'userPermissions' and 'groupPermissions', or an empty dict on error.
    """

    log_func(f'____________________ _getRepositoryOwners(repo_id: {repo_id}, deploy_id: {deploy_id})')

    # Construct the API URL based on whether it's an owned repo or a shared deployment
    if shared_repos and deploy_id:
        # START if shared_repos and deploy_id
        api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/deployments/{deploy_id}/permissions'
        # END if shared_repos and deploy_id
    else:
        # START else
        api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/permissions'
        # END else
    
    owners_result = {}
    
    try:
        # START try
        resp = requests.get(api_url, headers=helpers.get_http_headers(inst_dev_token), timeout=20)
        resp.raise_for_status() 
        owners_result = resp.json()
        # END try
    except requests.exceptions.RequestException as e:
        # START except requests.exceptions.RequestException
        log_func(f"ERROR fetching repository owners (repo_id: {repo_id}, deploy_id: {deploy_id}): {type(e).__name__} - {e}")
        # END except requests.exceptions.RequestException
        
    log_func('____________________ END _getRepositoryOwners()')

    return owners_result
# END def _get_repository_owners


def _get_repository_content_ids_string (
    repo: Dict[str, Any], content_key: str, log_func: LogFunc
) -> str:
    """
    (PRIVATE HELPER) Extracts a pipe-separated string of IDs for a specific content type 
    (e.g., 'pageIds', 'viewIds') from a repository object.
    
    :param repo: The repository dictionary object.
    :param content_key: The key within 'repositoryContent' (e.g., 'pageIds').
    :param log_func: Pre-bound logging function.
    :returns: Pipe-separated string of IDs, or an empty string.
    """
    
    # log_func(f'_______________ _get_repository_content_ids_string({content_key})')

    content_ids_str = ""
    
    if "repositoryContent" in repo:
        # START if "repositoryContent" in repo
        repository_content = repo["repositoryContent"]
        if content_key in repository_content:
            # START if content_key in repository_content
            id_list = repository_content[content_key]
            if isinstance(id_list, list):
                # START if isinstance(id_list, list)
                # Concatenate IDs with a pipe separator using a list comprehension
                content_ids_str = "|".join([str(id_val) for id_val in id_list])
                # END if isinstance(id_list, list)
            # END if content_key in repository_content
        # END if "repositoryContent" in repo

    # log_func(f'_______________ END _get_repository_content_ids_string({content_key})')
    return content_ids_str
# END def _get_repository_content_ids_string