# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 3.3.4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.3.3...654e8f80f619c7820dd82dfbe3c6d985b6a69e28))

### Bugs fixed

- Fix cell duplication when YStore diverges from disk [#376](https://github.com/jupyter-server/jupyter_ydoc/pull/376) ([@jordanhboxer](https://github.com/jordanhboxer), [@davidbrochart](https://github.com/davidbrochart), [@dmonad](https://github.com/dmonad), [@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Bump toshimaru/auto-author-assign from 3.0.0 to 3.0.1 [#375](https://github.com/jupyter-server/jupyter_ydoc/pull/375) ([@davidbrochart](https://github.com/davidbrochart))
- Bump toshimaru/auto-author-assign from 2.1.1 to 3.0.0 [#373](https://github.com/jupyter-server/jupyter_ydoc/pull/373) ([@davidbrochart](https://github.com/davidbrochart))
- Bump actions/upload-artifact from 5 to 6 [#371](https://github.com/jupyter-server/jupyter_ydoc/pull/371) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-12-10&to=2026-01-09&type=c))

@davidbrochart ([activity](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2025-12-10..2026-01-09&type=Issues)) | @dmonad ([activity](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Admonad+updated%3A2025-12-10..2026-01-09&type=Issues)) | @jordanhboxer ([activity](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajordanhboxer+updated%3A2025-12-10..2026-01-09&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-12-10..2026-01-09&type=Issues))

<!-- <END NEW CHANGELOG ENTRY> -->

## 3.3.3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.3.2...3900efdeefef21eb6e117fdd30827ee4c9149ff3))

### Bugs fixed

- Fix multi-byte Unicode handling in files [#370](https://github.com/jupyter-server/jupyter_ydoc/pull/370) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-12-01&to=2025-12-10&type=c))

[@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-12-01..2025-12-10&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-12-01..2025-12-10&type=Issues)

## 3.3.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.3.1...87e205209dbfed2d367424e6913c88916e77d98e))

### Enhancements made

- Perform granular updates if reloading textual files [#366](https://github.com/jupyter-server/jupyter_ydoc/pull/366) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Bump actions/checkout from 5 to 6 [#363](https://github.com/jupyter-server/jupyter_ydoc/pull/363) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-11-21&to=2025-12-01&type=c))

[@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2025-11-21..2025-12-01&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-11-21..2025-12-01&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-11-21..2025-12-01&type=Issues)

## 3.3.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.3.0...0a0d0bc23b5894db0b00c5b073861025757c72db))

### Bugs fixed

- Hard-reload a cell if its outputs change and include `stream` [#362](https://github.com/jupyter-server/jupyter_ydoc/pull/362) ([@krassowski](https://github.com/krassowski))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-11-21&to=2025-11-21&type=c))

[@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-11-21..2025-11-21&type=Issues)

## 3.3.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.2.1...91d2742a5faff878f7d802e994922e7c3bcf9d33))

### Bugs fixed

- Fix cell modifications causing cell output reload and shift to active cell index [#360](https://github.com/jupyter-server/jupyter_ydoc/pull/360) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Add more tests, require Python 3.10+ [#359](https://github.com/jupyter-server/jupyter_ydoc/pull/359) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-11-18&to=2025-11-21&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2025-11-18..2025-11-21&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-11-18..2025-11-21&type=Issues)

## 3.2.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.2.0...af869e7be801c1ca49c30256e30f2683ce03749c))

### Bugs fixed

- Fix syntax highlighting regression (default metadata structure not being set) [#358](https://github.com/jupyter-server/jupyter_ydoc/pull/358) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-11-17&to=2025-11-18&type=c))

[@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-11-17..2025-11-18&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-11-17..2025-11-18&type=Issues)

## 3.2.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.1.0...85206ea5cadcb7fc0419edc98fb47b765f3050b5))

### Bugs fixed

- Improve reloading of documents to avoid spurious side-effects [#355](https://github.com/jupyter-server/jupyter_ydoc/pull/355) ([@krassowski](https://github.com/krassowski))
- Preserve `document_id` state when setting notebook source [#338](https://github.com/jupyter-server/jupyter_ydoc/pull/338) ([@apeng-stripe](https://github.com/apeng-stripe))

### Maintenance and upkeep improvements

- Bump actions/upload-artifact from 4 to 5 [#349](https://github.com/jupyter-server/jupyter_ydoc/pull/349) ([@dependabot](https://github.com/dependabot))
- Bump actions/setup-python from 5 to 6 [#340](https://github.com/jupyter-server/jupyter_ydoc/pull/340) ([@dependabot](https://github.com/dependabot))
- Test against `pycrdt-websocket` `v0.16.0` & update dev dependencies [#339](https://github.com/jupyter-server/jupyter_ydoc/pull/339) ([@krassowski](https://github.com/krassowski))
- Bump actions/checkout from 4 to 5 [#337](https://github.com/jupyter-server/jupyter_ydoc/pull/337) ([@dependabot](https://github.com/dependabot))
- Bump actions/create-github-app-token from 1 to 2 [#318](https://github.com/jupyter-server/jupyter_ydoc/pull/318) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-07-01&to=2025-11-17&type=c))

[@apeng-stripe](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Aapeng-stripe+updated%3A2025-07-01..2025-11-17&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2025-07-01..2025-11-17&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-07-01..2025-11-17&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-07-01..2025-11-17&type=Issues)

## 3.1.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.5...280e6e33c0d283456e5519607186db08bccfaa5b))

### Enhancements made

- Add `clearOutputs()` method to `ISharedCodeCell` [#330](https://github.com/jupyter-server/jupyter_ydoc/pull/330) ([@Darshan808](https://github.com/Darshan808))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-05-07&to=2025-07-01&type=c))

[@Darshan808](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3ADarshan808+updated%3A2025-05-07..2025-07-01&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-05-07..2025-07-01&type=Issues)

## 3.0.5

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.4...9a28796415aeb19ffaf0ca7f5fab2bf39ee04755))

### Maintenance and upkeep improvements

- Bump `ip` from 2.0.0 to 2.0.1 [#325](https://github.com/jupyter-server/jupyter_ydoc/pull/325) ([@dlqqq](https://github.com/dlqqq))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-04-18&to=2025-05-07&type=c))

[@dlqqq](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adlqqq+updated%3A2025-04-18..2025-05-07&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-04-18..2025-05-07&type=Issues)

## 3.0.4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.3...accc3139a8bf5b5c7492a37af50309ffb810f7fd))

### Bugs fixed

- Set `undoManager` in constructor for cells in notebook [#321](https://github.com/jupyter-server/jupyter_ydoc/pull/321) ([@krassowski](https://github.com/krassowski))
- Fix including Typescript source in package [#312](https://github.com/jupyter-server/jupyter_ydoc/pull/312) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Bump apache/skywalking-eyes from 0.4.0 to 0.7.0 [#310](https://github.com/jupyter-server/jupyter_ydoc/pull/310) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2025-01-28&to=2025-04-18&type=c))

[@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2025-01-28..2025-04-18&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2025-01-28..2025-04-18&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2025-01-28..2025-04-18&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2025-01-28..2025-04-18&type=Issues)

## 3.0.3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.2...678a0a483421cbcb10cd56f4948dc944ac976555))

### Bugs fixed

- Fix missing nbformat version [#304](https://github.com/jupyter-server/jupyter_ydoc/pull/304) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Increase pycrdt compatible version range [#307](https://github.com/jupyter-server/jupyter_ydoc/pull/307) ([@davidbrochart](https://github.com/davidbrochart))
- Use micromamba in CI [#301](https://github.com/jupyter-server/jupyter_ydoc/pull/301) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-12-02&to=2025-01-28&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-12-02..2025-01-28&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2024-12-02..2025-01-28&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-12-02..2025-01-28&type=Issues)

## 3.0.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.1...db70566443ffc92e9bf62e2064e9b928ca2e96d7))

### Bugs fixed

- Fix stream output [#294](https://github.com/jupyter-server/jupyter_ydoc/pull/294) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-11-18&to=2024-12-02&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-11-18..2024-12-02&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-11-18..2024-12-02&type=Issues)

## 3.0.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0...2ed6216e488db36c2757390c96195db9909e7908))

### Maintenance and upkeep improvements

- Fix tests [#288](https://github.com/jupyter-server/jupyter_ydoc/pull/288) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-10-29&to=2024-11-18&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-10-29..2024-11-18&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-10-29..2024-11-18&type=Issues)

## 3.0.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@2.0.1...8cf3b0f53bf763edf254e91fed65aaa7062e3250))

### Enhancements made

- Add the awareness in the shared document interface [#282](https://github.com/jupyter-server/jupyter_ydoc/pull/282) ([@brichet](https://github.com/brichet))
- Doc awareness [#277](https://github.com/jupyter-server/jupyter_ydoc/pull/277) ([@brichet](https://github.com/brichet))
- Improve notebook output stream initialization [#275](https://github.com/jupyter-server/jupyter_ydoc/pull/275) ([@davidbrochart](https://github.com/davidbrochart))
- Add YDocument source getter/setter [#273](https://github.com/jupyter-server/jupyter_ydoc/pull/273) ([@davidbrochart](https://github.com/davidbrochart))
- Allow empty notebook [#266](https://github.com/jupyter-server/jupyter_ydoc/pull/266) ([@davidbrochart](https://github.com/davidbrochart))
- Add `streamOutputChange` attribute to cell change object [#264](https://github.com/jupyter-server/jupyter_ydoc/pull/264) ([@davidbrochart](https://github.com/davidbrochart))
- Add `hash` property with setter and getter [#262](https://github.com/jupyter-server/jupyter_ydoc/pull/262) ([@krassowski](https://github.com/krassowski))
- Expose `execution_state` in the JS package [#259](https://github.com/jupyter-server/jupyter_ydoc/pull/259) ([@krassowski](https://github.com/krassowski))
- Add undo_manager to Y documents [#248](https://github.com/jupyter-server/jupyter_ydoc/pull/248) ([@davidbrochart](https://github.com/davidbrochart))
- Add optional origin to transaction, filter out 'modeldb' origin [#246](https://github.com/jupyter-server/jupyter_ydoc/pull/246) ([@davidbrochart](https://github.com/davidbrochart))
- Add appendStreamOutput and removeStreamOutput methods [#241](https://github.com/jupyter-server/jupyter_ydoc/pull/241) ([@davidbrochart](https://github.com/davidbrochart))
- Update python>=3.8, pycrdt>=0.8.11, pre-commit, README [#217](https://github.com/jupyter-server/jupyter_ydoc/pull/217) ([@davidbrochart](https://github.com/davidbrochart))
- Store YBlob as bytes, not base64-encoded string [#209](https://github.com/jupyter-server/jupyter_ydoc/pull/209) ([@davidbrochart](https://github.com/davidbrochart))
- Change notebook code cell stream output schema [#201](https://github.com/jupyter-server/jupyter_ydoc/pull/201) ([@davidbrochart](https://github.com/davidbrochart))
- Add cell execution_state [#197](https://github.com/jupyter-server/jupyter_ydoc/pull/197) ([@davidbrochart](https://github.com/davidbrochart))

### Bugs fixed

- Fix attachments change attribute assignment [#260](https://github.com/jupyter-server/jupyter_ydoc/pull/260) ([@krassowski](https://github.com/krassowski))
- Fix createOutputs, rename 'modeldb' origin to 'silent-change' [#254](https://github.com/jupyter-server/jupyter_ydoc/pull/254) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Revert #266 [#280](https://github.com/jupyter-server/jupyter_ydoc/pull/280) ([@davidbrochart](https://github.com/davidbrochart))
- Improve notebook output stream initialization [#275](https://github.com/jupyter-server/jupyter_ydoc/pull/275) ([@davidbrochart](https://github.com/davidbrochart))
- Fix dict type for python 3.8 [#253](https://github.com/jupyter-server/jupyter_ydoc/pull/253) ([@davidbrochart](https://github.com/davidbrochart))
- Bump toshimaru/auto-author-assign from 2.1.0 to 2.1.1 [#247](https://github.com/jupyter-server/jupyter_ydoc/pull/247) ([@dependabot](https://github.com/dependabot))
- Revert publish 3.0.0a0 (9c87cfd7c7e967a1fbef8ce96899d426862e84fb) [#245](https://github.com/jupyter-server/jupyter_ydoc/pull/245) ([@davidbrochart](https://github.com/davidbrochart))
- Update releaser workflows [#244](https://github.com/jupyter-server/jupyter_ydoc/pull/244) ([@jtpio](https://github.com/jtpio))
- Bump notebook version 1.0.0 -> 2.0.0 [#236](https://github.com/jupyter-server/jupyter_ydoc/pull/236) ([@davidbrochart](https://github.com/davidbrochart))
- Fix subscription type, update pycrdt>=0.8.16 [#222](https://github.com/jupyter-server/jupyter_ydoc/pull/222) ([@davidbrochart](https://github.com/davidbrochart))
- Update python>=3.8, pycrdt>=0.8.11, pre-commit, README [#217](https://github.com/jupyter-server/jupyter_ydoc/pull/217) ([@davidbrochart](https://github.com/davidbrochart))
- Bump pre-commit/action from 3.0.0 to 3.0.1 [#215](https://github.com/jupyter-server/jupyter_ydoc/pull/215) ([@dependabot](https://github.com/dependabot))
- Remove mention to y_py in docs [#214](https://github.com/jupyter-server/jupyter_ydoc/pull/214) ([@martinRenou](https://github.com/martinRenou))
- Bump toshimaru/auto-author-assign from 2.0.1 to 2.1.0 [#212](https://github.com/jupyter-server/jupyter_ydoc/pull/212) ([@dependabot](https://github.com/dependabot))

### Documentation improvements

- Remove mention to y_py in docs [#214](https://github.com/jupyter-server/jupyter_ydoc/pull/214) ([@martinRenou](https://github.com/martinRenou))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-12-26&to=2024-10-29&type=c))

[@brichet](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Abrichet+updated%3A2023-12-26..2024-10-29&type=Issues) | [@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-12-26..2024-10-29&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-12-26..2024-10-29&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajtpio+updated%3A2023-12-26..2024-10-29&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2023-12-26..2024-10-29&type=Issues) | [@lumberbot-app](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Alumberbot-app+updated%3A2023-12-26..2024-10-29&type=Issues) | [@martinRenou](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3AmartinRenou+updated%3A2023-12-26..2024-10-29&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-12-26..2024-10-29&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-12-26..2024-10-29&type=Issues) | [@Zsailer](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3AZsailer+updated%3A2023-12-26..2024-10-29&type=Issues)

## 3.0.0b0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a10...5a205d912bb399684a2886d4d323b77669f63eb8))

### Enhancements made

- Add the awareness in the shared document interface [#282](https://github.com/jupyter-server/jupyter_ydoc/pull/282) ([@brichet](https://github.com/brichet))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-10-17&to=2024-10-18&type=c))

[@brichet](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Abrichet+updated%3A2024-10-17..2024-10-18&type=Issues)

## 3.0.0a10

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a9...dc71f641f72826232772509a8c9cea474d7ccc9f))

### Maintenance and upkeep improvements

- Revert #266 [#280](https://github.com/jupyter-server/jupyter_ydoc/pull/280) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-10-10&to=2024-10-17&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-10-10..2024-10-17&type=Issues)

## 3.0.0a9

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a8...877e5b9bb449b6f4e2472337e41f27c3bf24ead1))

### Enhancements made

- Doc awareness [#277](https://github.com/jupyter-server/jupyter_ydoc/pull/277) ([@brichet](https://github.com/brichet))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-09-26&to=2024-10-10&type=c))

[@brichet](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Abrichet+updated%3A2024-09-26..2024-10-10&type=Issues) | [@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-09-26..2024-10-10&type=Issues) | [@lumberbot-app](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Alumberbot-app+updated%3A2024-09-26..2024-10-10&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-09-26..2024-10-10&type=Issues)

## 3.0.0a8

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a7...b20878676d4564641ac142804eaf27331ddb342c))

### Enhancements made

- Improve notebook output stream initialization [#275](https://github.com/jupyter-server/jupyter_ydoc/pull/275) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Improve notebook output stream initialization [#275](https://github.com/jupyter-server/jupyter_ydoc/pull/275) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-09-18&to=2024-09-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-09-18..2024-09-26&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-09-18..2024-09-26&type=Issues)

## 3.0.0a7

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a6...3f323117ba2e8cf36f0e06c0ec9b9fa2c192278b))

### Enhancements made

- Add YDocument source getter/setter [#273](https://github.com/jupyter-server/jupyter_ydoc/pull/273) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-08-30&to=2024-09-18&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-08-30..2024-09-18&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-08-30..2024-09-18&type=Issues)

## 3.0.0a6

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a5...00ca649ec94ec5a00dad9656f7a122a7f9248590))

### Enhancements made

- Allow empty notebook [#266](https://github.com/jupyter-server/jupyter_ydoc/pull/266) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-08-23&to=2024-08-30&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-08-23..2024-08-30&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-08-23..2024-08-30&type=Issues)

## 3.0.0a5

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a4...e97181c93ce91fdb56968b9e4ed8fc6006049cd5))

### Enhancements made

- Add `streamOutputChange` attribute to cell change object [#264](https://github.com/jupyter-server/jupyter_ydoc/pull/264) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-08-19&to=2024-08-23&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-08-19..2024-08-23&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-08-19..2024-08-23&type=Issues)

## 3.0.0a4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a3...14a8573f296086865849673d68ad4b1aaab2eb82))

### Enhancements made

- Add `hash` property with setter and getter [#262](https://github.com/jupyter-server/jupyter_ydoc/pull/262) ([@krassowski](https://github.com/krassowski))

### Bugs fixed

- Fix attachments change attribute assignment [#260](https://github.com/jupyter-server/jupyter_ydoc/pull/260) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-08-07&to=2024-08-19&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-08-07..2024-08-19&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2024-08-07..2024-08-19&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-08-07..2024-08-19&type=Issues)

## 3.0.0a3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a2...8fbbd6985f686e7876b301ad5637052001caa128))

### Enhancements made

- Expose `execution_state` in the JS package [#259](https://github.com/jupyter-server/jupyter_ydoc/pull/259) ([@krassowski](https://github.com/krassowski))
- Add cell execution_state [#197](https://github.com/jupyter-server/jupyter_ydoc/pull/197) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-07-12&to=2024-08-07&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-07-12..2024-08-07&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2024-07-12..2024-08-07&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-07-12..2024-08-07&type=Issues)

## 3.0.0a2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a1...db935c175e8b3d37ec32284b5171c26458817528))

### Bugs fixed

- Fix createOutputs, rename 'modeldb' origin to 'silent-change' [#254](https://github.com/jupyter-server/jupyter_ydoc/pull/254) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Fix dict type for python 3.8 [#253](https://github.com/jupyter-server/jupyter_ydoc/pull/253) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-07-05&to=2024-07-12&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-07-05..2024-07-12&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-07-05..2024-07-12&type=Issues)

## 3.0.0a1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@3.0.0-a0...8e3f25bdcfb8ed36cd740dd958d5d04580cd54ef))

### Enhancements made

- Add undo_manager to Y documents [#248](https://github.com/jupyter-server/jupyter_ydoc/pull/248) ([@davidbrochart](https://github.com/davidbrochart))
- Add optional origin to transaction, filter out 'modeldb' origin [#246](https://github.com/jupyter-server/jupyter_ydoc/pull/246) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Bump toshimaru/auto-author-assign from 2.1.0 to 2.1.1 [#247](https://github.com/jupyter-server/jupyter_ydoc/pull/247) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2024-06-26&to=2024-07-05&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2024-06-26..2024-07-05&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2024-06-26..2024-07-05&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2024-06-26..2024-07-05&type=Issues)

## 3.0.0a0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@2.0.1...cc9a21d918ca5cd4336b65783586ca74ca98a889))

### Enhancements made

- Add appendStreamOutput and removeStreamOutput methods [#241](https://github.com/jupyter-server/jupyter_ydoc/pull/241) ([@davidbrochart](https://github.com/davidbrochart))
- Update python>=3.8, pycrdt>=0.8.11, pre-commit, README [#217](https://github.com/jupyter-server/jupyter_ydoc/pull/217) ([@davidbrochart](https://github.com/davidbrochart))
- Store YBlob as bytes, not base64-encoded string [#209](https://github.com/jupyter-server/jupyter_ydoc/pull/209) ([@davidbrochart](https://github.com/davidbrochart))
- Change notebook code cell stream output schema [#201](https://github.com/jupyter-server/jupyter_ydoc/pull/201) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Revert publish 3.0.0a0 (9c87cfd7c7e967a1fbef8ce96899d426862e84fb) [#245](https://github.com/jupyter-server/jupyter_ydoc/pull/245) ([@davidbrochart](https://github.com/davidbrochart))
- Update releaser workflows [#244](https://github.com/jupyter-server/jupyter_ydoc/pull/244) ([@jtpio](https://github.com/jtpio))
- Bump notebook version 1.0.0 -> 2.0.0 [#236](https://github.com/jupyter-server/jupyter_ydoc/pull/236) ([@davidbrochart](https://github.com/davidbrochart))
- Fix subscription type, update pycrdt>=0.8.16 [#222](https://github.com/jupyter-server/jupyter_ydoc/pull/222) ([@davidbrochart](https://github.com/davidbrochart))
- Update python>=3.8, pycrdt>=0.8.11, pre-commit, README [#217](https://github.com/jupyter-server/jupyter_ydoc/pull/217) ([@davidbrochart](https://github.com/davidbrochart))
- Bump pre-commit/action from 3.0.0 to 3.0.1 [#215](https://github.com/jupyter-server/jupyter_ydoc/pull/215) ([@dependabot](https://github.com/dependabot))
- Remove mention to y_py in docs [#214](https://github.com/jupyter-server/jupyter_ydoc/pull/214) ([@martinRenou](https://github.com/martinRenou))
- Bump toshimaru/auto-author-assign from 2.0.1 to 2.1.0 [#212](https://github.com/jupyter-server/jupyter_ydoc/pull/212) ([@dependabot](https://github.com/dependabot))

### Documentation improvements

- Remove mention to y_py in docs [#214](https://github.com/jupyter-server/jupyter_ydoc/pull/214) ([@martinRenou](https://github.com/martinRenou))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-12-26&to=2024-06-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-12-26..2024-06-26&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-12-26..2024-06-26&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajtpio+updated%3A2023-12-26..2024-06-26&type=Issues) | [@martinRenou](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3AmartinRenou+updated%3A2023-12-26..2024-06-26&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-12-26..2024-06-26&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-12-26..2024-06-26&type=Issues) | [@Zsailer](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3AZsailer+updated%3A2023-12-26..2024-06-26&type=Issues)

## 2.0.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@2.0.0...c9c6b93148e48c29125bc3dbf777ab637da7f4b2))

### Maintenance and upkeep improvements

- Update pycrdt v0.8 [#208](https://github.com/jupyter-server/jupyter_ydoc/pull/208) ([@davidbrochart](https://github.com/davidbrochart))
- Bump actions/upload-artifact from 3 to 4 [#205](https://github.com/jupyter-server/jupyter_ydoc/pull/205) ([@dependabot](https://github.com/dependabot))
- Bump actions/setup-python from 4 to 5 [#203](https://github.com/jupyter-server/jupyter_ydoc/pull/203) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-12-08&to=2023-12-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-12-08..2023-12-26&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-12-08..2023-12-26&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-12-08..2023-12-26&type=Issues)

## 2.0.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.1.1...bd998983bbf6b566bb0314faa48b8e51ba7747b6))

### Maintenance and upkeep improvements

- Bump conda-incubator/setup-miniconda from 2 to 3 [#202](https://github.com/jupyter-server/jupyter_ydoc/pull/202) ([@dependabot](https://github.com/dependabot))
- Use pycrdt instead of y-py [#194](https://github.com/jupyter-server/jupyter_ydoc/pull/194) ([@davidbrochart](https://github.com/davidbrochart))
- Switch from hub to gh CLI [#190](https://github.com/jupyter-server/jupyter_ydoc/pull/190) ([@hbcarlos](https://github.com/hbcarlos))
- Bump toshimaru/auto-author-assign from 2.0.0 to 2.0.1 [#187](https://github.com/jupyter-server/jupyter_ydoc/pull/187) ([@dependabot](https://github.com/dependabot))

### Documentation improvements

- Fix JupyterCAD links [#199](https://github.com/jupyter-server/jupyter_ydoc/pull/199) ([@davidbrochart](https://github.com/davidbrochart))
- Fix a typo in docs (wrong closing quote) [#192](https://github.com/jupyter-server/jupyter_ydoc/pull/192) ([@krassowski](https://github.com/krassowski))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-09-29&to=2023-12-08&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-09-29..2023-12-08&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-09-29..2023-12-08&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-09-29..2023-12-08&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2023-09-29..2023-12-08&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-09-29..2023-12-08&type=Issues)

## 1.1.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.1.0...9afd2c90c541d25edaa814cef70fc9b99219cf52))

### Bugs fixed

- Fix joining of `source` when `source` is an array of strings [#186](https://github.com/jupyter-server/jupyter_ydoc/pull/186) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Bump toshimaru/auto-author-assign from 1.6.2 to 2.0.0 [#184](https://github.com/jupyter-server/jupyter_ydoc/pull/184) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-09-21&to=2023-09-29&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-09-21..2023-09-29&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-09-21..2023-09-29&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajtpio+updated%3A2023-09-21..2023-09-29&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-09-21..2023-09-29&type=Issues)

## 1.1.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.1.0-a0...3bbafabcb26f24278bf4a41b77a05f4f43f519f2))

### Maintenance and upkeep improvements

- Add source to dist for sourcemaps [#182](https://github.com/jupyter-server/jupyter_ydoc/pull/182) ([@vidartf](https://github.com/vidartf))
- Bump actions/checkout from 3 to 4 [#180](https://github.com/jupyter-server/jupyter_ydoc/pull/180) ([@dependabot](https://github.com/dependabot))

### Documentation improvements

- Update CHANGELOG.md [#177](https://github.com/jupyter-server/jupyter_ydoc/pull/177) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-06-29&to=2023-09-21&type=c))

[@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2023-06-29..2023-09-21&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-06-29..2023-09-21&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-06-29..2023-09-21&type=Issues) | [@vidartf](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Avidartf+updated%3A2023-06-29..2023-09-21&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-06-29..2023-09-21&type=Issues)

## 1.1.0a0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.0.2...b7a1dc047e9a91a831dab68fdb294d56f46ab168))

### Enhancements made

- Create awareness interface [#171](https://github.com/jupyter-server/jupyter_ydoc/pull/171) ([@hbcarlos](https://github.com/hbcarlos))

### Maintenance and upkeep improvements

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-04-14&to=2023-06-29&type=c))

[@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-04-14..2023-06-29&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-04-14..2023-06-29&type=Issues)

## 1.0.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.0.1...3b3a4af50ea46abd886076b69b93ee0dab6b05c5))

### Enhancements made

- Trust the default cell [#161](https://github.com/jupyter-server/jupyter_ydoc/pull/161) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Run yarn subprocess in shell mode [#162](https://github.com/jupyter-server/jupyter_ydoc/pull/162) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-04-11&to=2023-04-14&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-04-11..2023-04-14&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-04-11..2023-04-14&type=Issues) | [@krassowski](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Akrassowski+updated%3A2023-04-11..2023-04-14&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-04-11..2023-04-14&type=Issues)

## 1.0.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@1.0.0...6672e3dd27c2980f45ce1037101f0198fac3d9ff))

### Bugs fixed

- Fix metadata issue [#158](https://github.com/jupyter-server/jupyter_ydoc/pull/158) ([@hbcarlos](https://github.com/hbcarlos))

### Maintenance and upkeep improvements

### Documentation improvements

- Fix ignore_links [#155](https://github.com/jupyter-server/jupyter_ydoc/pull/155) ([@fcollonval](https://github.com/fcollonval))
- Enhance the documentation [#154](https://github.com/jupyter-server/jupyter_ydoc/pull/154) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-03-29&to=2023-04-11&type=c))

[@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-03-29..2023-04-11&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-03-29..2023-04-11&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-03-29..2023-04-11&type=Issues)

## 1.0.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.3.4...6ad2fde183a3f592d8a2ff58254b229859caba01))

### Enhancements made

- Add py.typed [#152](https://github.com/jupyter-server/jupyter_ydoc/pull/152) ([@davidbrochart](https://github.com/davidbrochart))
- Add model version [#139](https://github.com/jupyter-server/jupyter_ydoc/pull/139) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Add py.typed [#152](https://github.com/jupyter-server/jupyter_ydoc/pull/152) ([@davidbrochart](https://github.com/davidbrochart))
- Bump dependencies and yarn [#151](https://github.com/jupyter-server/jupyter_ydoc/pull/151) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-02-22&to=2023-03-28&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-02-22..2023-03-28&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-02-22..2023-03-28&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-02-22..2023-03-28&type=Issues)

## 0.3.4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.3.3...3c3aa3e0421193f391b10ae23745f235a6923cff))

### Bugs fixed

- Fix notebook undo scope [#148](https://github.com/jupyter-server/jupyter_ydoc/pull/148) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Add releaser workflows [#150](https://github.com/jupyter-server/jupyter_ydoc/pull/150) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-02-21&to=2023-02-22&type=c))

[@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-02-21..2023-02-22&type=Issues)

## 0.3.3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.3.2...c7b05c187afcf7e0c27bd42dbc5038f53250ca8c))

### Bugs fixed

- Workaround for ypy 0.6.0 [#147](https://github.com/jupyter-server/jupyter_ydoc/pull/147) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-02-20&to=2023-02-21&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-02-20..2023-02-21&type=Issues)

## 0.3.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.3.1...544b1dc696635b3e6a81250e411a5f5de84a0aff))

### Enhancements made

- Update `YDocument` constructor [#142](https://github.com/jupyter-server/jupyter_ydoc/pull/142) ([@trungleduc](https://github.com/trungleduc))
- Add ycells getter [#136](https://github.com/jupyter-server/jupyter_ydoc/pull/136) ([@davidbrochart](https://github.com/davidbrochart))
- Split documents into separate files [#135](https://github.com/jupyter-server/jupyter_ydoc/pull/135) ([@davidbrochart](https://github.com/davidbrochart))

### Maintenance and upkeep improvements

- Update with ypy v0.6.0 [#145](https://github.com/jupyter-server/jupyter_ydoc/pull/145) ([@davidbrochart](https://github.com/davidbrochart))
- Update `YDocument` constructor [#142](https://github.com/jupyter-server/jupyter_ydoc/pull/142) ([@trungleduc](https://github.com/trungleduc))
- Add ycells getter [#136](https://github.com/jupyter-server/jupyter_ydoc/pull/136) ([@davidbrochart](https://github.com/davidbrochart))
- Split documents into separate files [#135](https://github.com/jupyter-server/jupyter_ydoc/pull/135) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-01-26&to=2023-02-20&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-01-26..2023-02-20&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2023-01-26..2023-02-20&type=Issues) | [@trungleduc](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Atrungleduc+updated%3A2023-01-26..2023-02-20&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-01-26..2023-02-20&type=Issues)

## 0.3.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.3.0...f130d4b26f4039309d27edba7213ae5d73a0a2bf))

### Bugs fixed

- Fixes handling metadata changes [#134](https://github.com/jupyter-server/jupyter_ydoc/pull/134) ([@hbcarlos](https://github.com/hbcarlos))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-01-24&to=2023-01-26&type=c))

[@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-01-24..2023-01-26&type=Issues)

## 0.3.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/234334f70cc763f05f4e9185e6d957d96e8f5a24...e8510e0196e959f40863cdb92ec358c1257526dc))

### Enhancements made

- Improves the initialization [#124](https://github.com/jupyter-server/jupyter_ydoc/pull/124) ([@hbcarlos](https://github.com/hbcarlos))
- Improve Python API [#122](https://github.com/jupyter-server/jupyter_ydoc/pull/122) ([@davidbrochart](https://github.com/davidbrochart))
- Notebook metadata [#115](https://github.com/jupyter-server/jupyter_ydoc/pull/115) ([@hbcarlos](https://github.com/hbcarlos))
- Make `YDocument` a `IObservableDisposable` [#108](https://github.com/jupyter-server/jupyter_ydoc/pull/108) ([@fcollonval](https://github.com/fcollonval))
- Add readme to javascript package [#106](https://github.com/jupyter-server/jupyter_ydoc/pull/106) ([@fcollonval](https://github.com/fcollonval))
- Adds docstring to the python package [#101](https://github.com/jupyter-server/jupyter_ydoc/pull/101) ([@hbcarlos](https://github.com/hbcarlos))
- Import shared model [#86](https://github.com/jupyter-server/jupyter_ydoc/pull/86) ([@fcollonval](https://github.com/fcollonval))
- Add path document attribute [#81](https://github.com/jupyter-server/jupyter_ydoc/pull/81) ([@davidbrochart](https://github.com/davidbrochart))
- Make YBaseDoc an abstract base class [#74](https://github.com/jupyter-server/jupyter_ydoc/pull/74) ([@davidbrochart](https://github.com/davidbrochart))

### Bugs fixed

- Fixes multiple bugs [#131](https://github.com/jupyter-server/jupyter_ydoc/pull/131) ([@hbcarlos](https://github.com/hbcarlos))
- Fixes metadata [#120](https://github.com/jupyter-server/jupyter_ydoc/pull/120) ([@hbcarlos](https://github.com/hbcarlos))
- Support cell.source is \[list, of, string\] [#112](https://github.com/jupyter-server/jupyter_ydoc/pull/112) ([@Wh1isper](https://github.com/Wh1isper))
- Removes YMap for attachements [#77](https://github.com/jupyter-server/jupyter_ydoc/pull/77) ([@fcollonval](https://github.com/fcollonval))
- Drop `pkg_resources` [#59](https://github.com/jupyter-server/jupyter_ydoc/pull/59) ([@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Integrity check [#132](https://github.com/jupyter-server/jupyter_ydoc/pull/132) ([@hbcarlos](https://github.com/hbcarlos))
- Import all document types from __init__ [#127](https://github.com/jupyter-server/jupyter_ydoc/pull/127) ([@davidbrochart](https://github.com/davidbrochart))
- docs: small README typo fix [#126](https://github.com/jupyter-server/jupyter_ydoc/pull/126) ([@agoose77](https://github.com/agoose77))
- Bump toshimaru/auto-author-assign from 1.6.1 to 1.6.2 [#121](https://github.com/jupyter-server/jupyter_ydoc/pull/121) ([@dependabot](https://github.com/dependabot))
- Set up lerna [#119](https://github.com/jupyter-server/jupyter_ydoc/pull/119) ([@fcollonval](https://github.com/fcollonval))
- Bump tj-actions/changed-files from 35.1.0 to 35.2.1 [#118](https://github.com/jupyter-server/jupyter_ydoc/pull/118) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 35.0.0 to 35.1.0 [#116](https://github.com/jupyter-server/jupyter_ydoc/pull/116) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 34.5.3 to 35.0.0 [#113](https://github.com/jupyter-server/jupyter_ydoc/pull/113) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 34.5.0 to 34.5.3 [#109](https://github.com/jupyter-server/jupyter_ydoc/pull/109) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 34.4.4 to 34.5.0 [#100](https://github.com/jupyter-server/jupyter_ydoc/pull/100) ([@dependabot](https://github.com/dependabot))
- Bump actions/upload-artifact from 2 to 3 [#99](https://github.com/jupyter-server/jupyter_ydoc/pull/99) ([@dependabot](https://github.com/dependabot))
- Rename JS package to `@jupyter/ydoc` [#97](https://github.com/jupyter-server/jupyter_ydoc/pull/97) ([@jtpio](https://github.com/jtpio))
- Bump tj-actions/changed-files from 34.4.0 to 34.4.4 [#94](https://github.com/jupyter-server/jupyter_ydoc/pull/94) ([@dependabot](https://github.com/dependabot))
- Backport #90 on branch main (Releaser) [#92](https://github.com/jupyter-server/jupyter_ydoc/pull/92) ([@fcollonval](https://github.com/fcollonval))
- Bump tj-actions/changed-files from 34.2.2 to 34.4.0 [#91](https://github.com/jupyter-server/jupyter_ydoc/pull/91) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 34.0.2 to 34.2.2 [#87](https://github.com/jupyter-server/jupyter_ydoc/pull/87) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 33.0.0 to 34.0.2 [#84](https://github.com/jupyter-server/jupyter_ydoc/pull/84) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 31.0.3 to 33.0.0 [#80](https://github.com/jupyter-server/jupyter_ydoc/pull/80) ([@dependabot](https://github.com/dependabot))
- Bump pre-commit/action from 2.0.0 to 3.0.0 [#72](https://github.com/jupyter-server/jupyter_ydoc/pull/72) ([@dependabot](https://github.com/dependabot))
- Bump actions/checkout from 2 to 3 [#71](https://github.com/jupyter-server/jupyter_ydoc/pull/71) ([@dependabot](https://github.com/dependabot))
- Bump actions/setup-python from 2 to 4 [#70](https://github.com/jupyter-server/jupyter_ydoc/pull/70) ([@dependabot](https://github.com/dependabot))
- Bump actions/cache from 1 to 3 [#69](https://github.com/jupyter-server/jupyter_ydoc/pull/69) ([@dependabot](https://github.com/dependabot))
- Bump actions/setup-node from 2 to 3 [#68](https://github.com/jupyter-server/jupyter_ydoc/pull/68) ([@dependabot](https://github.com/dependabot))
- Bump tj-actions/changed-files from 31.0.1 to 31.0.3 [#67](https://github.com/jupyter-server/jupyter_ydoc/pull/67) ([@dependabot](https://github.com/dependabot))

### Documentation improvements

- Add badges [#105](https://github.com/jupyter-server/jupyter_ydoc/pull/105) ([@fcollonval](https://github.com/fcollonval))
- Docs [#102](https://github.com/jupyter-server/jupyter_ydoc/pull/102) ([@hbcarlos](https://github.com/hbcarlos))
- Adds docstring to the python package [#101](https://github.com/jupyter-server/jupyter_ydoc/pull/101) ([@hbcarlos](https://github.com/hbcarlos))
- Documentation [#95](https://github.com/jupyter-server/jupyter_ydoc/pull/95) ([@hbcarlos](https://github.com/hbcarlos))

### API and Breaking Changes

- Remove factory API [#133](https://github.com/jupyter-server/jupyter_ydoc/pull/133) ([@hbcarlos](https://github.com/hbcarlos))
- Fixes multiple bugs [#131](https://github.com/jupyter-server/jupyter_ydoc/pull/131) ([@hbcarlos](https://github.com/hbcarlos))
- Import shared model [#86](https://github.com/jupyter-server/jupyter_ydoc/pull/86) ([@fcollonval](https://github.com/fcollonval))

### Other merged PRs

- Fixes build js docs [#96](https://github.com/jupyter-server/jupyter_ydoc/pull/96) ([@hbcarlos](https://github.com/hbcarlos))
- Add workflows to ease maintenance [#64](https://github.com/jupyter-server/jupyter_ydoc/pull/64) ([@fcollonval](https://github.com/fcollonval))
- Test a case with plotly renderer [#63](https://github.com/jupyter-server/jupyter_ydoc/pull/63) ([@fcollonval](https://github.com/fcollonval))
- Pin @jupyterlab/shared-models >=4.0.0-alpha.10,\<4.0.0-alpha.14 [#61](https://github.com/jupyter-server/jupyter_ydoc/pull/61) ([@davidbrochart](https://github.com/davidbrochart))
- Cast only if number has same value [#57](https://github.com/jupyter-server/jupyter_ydoc/pull/57) ([@davidbrochart](https://github.com/davidbrochart))
- Add back YMap for cell metadata [#53](https://github.com/jupyter-server/jupyter_ydoc/pull/53) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-09-26&to=2023-01-24&type=c))

[@agoose77](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Aagoose77+updated%3A2022-09-26..2023-01-24&type=Issues) | [@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-09-26..2023-01-24&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adependabot+updated%3A2022-09-26..2023-01-24&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2022-09-26..2023-01-24&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-09-26..2023-01-24&type=Issues) | [@jtpio](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajtpio+updated%3A2022-09-26..2023-01-24&type=Issues) | [@meeseeksdev](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ameeseeksdev+updated%3A2022-09-26..2023-01-24&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2022-09-26..2023-01-24&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2022-09-26..2023-01-24&type=Issues) | [@Wh1isper](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3AWh1isper+updated%3A2022-09-26..2023-01-24&type=Issues)

## 0.2.5

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.2.4...e441c6e8bf84419be6586adeceb0012700d7f3a1))

### Enhancements made

- Trust the default cell [#161](https://github.com/jupyter-server/jupyter_ydoc/pull/161) ([@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Bump y-py to 0.6.0+ [#175](https://github.com/jupyter-server/jupyter_ydoc/pull/175) ([@fcollonval](https://github.com/fcollonval))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-04-12&to=2023-07-18&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-04-12..2023-07-18&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-04-12..2023-07-18&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2023-04-12..2023-07-18&type=Issues)

## 0.2.4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/@jupyter/ydoc@0.2.3...5d70749d13f83c618e6c90c70ebc4e2c8257dfa0))

### Bugs fixed

- Fix metadata issue [#158](https://github.com/jupyter-server/jupyter_ydoc/pull/158) ([@hbcarlos](https://github.com/hbcarlos))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2023-03-10&to=2023-04-12&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2023-03-10..2023-04-12&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2023-03-10..2023-04-12&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2023-03-10..2023-04-12&type=Issues)

## 0.2.3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/8854a43982e623f926a2094f58819716eb16bd77...e4c4b6ca5a6731104c909ebc12eb4cf500345df5))

### Bugs fixed

- Fix notebook undo scope [#148](https://github.com/jupyter-server/jupyter_ydoc/pull/148) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Rename JS package to `@jupyter/ydoc` [#97](https://github.com/jupyter-server/jupyter_ydoc/pull/97) ([@jtpio](https://github.com/jtpio))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-11-29&to=2023-03-10&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-11-29..2023-03-10&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2022-11-29..2023-03-10&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2022-11-29..2023-03-10&type=Issues)

## 0.2.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.2.1...ae5e46d3e4756f80452e9416e70ac6aa9ab7475a))

### Bugs fixed

- Removes YMap for attachements [#77](https://github.com/jupyter-server/jupyter_ydoc/pull/77) ([@fcollonval](https://github.com/fcollonval))

### Other merged PRs

- Add path document attribute [#82](https://github.com/jupyter-server/jupyter_ydoc/pull/82) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-09-29&to=2022-10-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-09-29..2022-10-26&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Afcollonval+updated%3A2022-09-29..2022-10-26&type=Issues) | [@meeseeksmachine](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ameeseeksmachine+updated%3A2022-09-29..2022-10-26&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2022-09-29..2022-10-26&type=Issues)

## 0.2.1

Back-port of #56, #57 and #59.

## 0.2.0

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.17...55dc65afafb669d0a5552e485cf860d402740dc7))

### Merged PRs

- Use hatch [#51](https://github.com/jupyter-server/jupyter_ydoc/pull/51) ([@davidbrochart](https://github.com/davidbrochart))
- Removes YMap for cell metadata [#50](https://github.com/jupyter-server/jupyter_ydoc/pull/50) ([@hbcarlos](https://github.com/hbcarlos))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-08-01&to=2022-09-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-08-01..2022-09-26&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-08-01..2022-09-26&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2022-08-01..2022-09-26&type=Issues)

## 0.1.17

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.16...106ee079e2ad9ed7c8b25693932ad921e3ea3e20))

### Merged PRs

- Handle missing attachment key [#43](https://github.com/jupyter-server/jupyter_ydoc/pull/43) ([@jimgoo](https://github.com/jimgoo))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-07-27&to=2022-08-01&type=c))

[@jimgoo](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ajimgoo+updated%3A2022-07-27..2022-08-01&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2022-07-27..2022-08-01&type=Issues)

## 0.1.16

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.15...780f8b8e898e31b6e82017a2bc2d04475728890f))

### Merged PRs

- Move ypy-websocket dependency to test [#41](https://github.com/jupyter-server/jupyter_ydoc/pull/41) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-07-27&to=2022-07-27&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-07-27..2022-07-27&type=Issues)

## 0.1.15

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.14...41a1ad194b5cd26dc405ef9d774c05dde494a489))

### Merged PRs

- Add YNotebook get_cell, set_cell, append_cell [#35](https://github.com/jupyter-server/jupyter_ydoc/pull/35) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-07-26&to=2022-07-27&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-07-26..2022-07-27&type=Issues)

## 0.1.14

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.13...523dc9e3ff9aed516ff0b0e3f2f7528f6da02faa))

### Merged PRs

- Align notebook schema with JupyterLab HEAD [#38](https://github.com/jupyter-server/jupyter_ydoc/pull/38) ([@davidbrochart](https://github.com/davidbrochart))
- [pre-commit.ci] pre-commit autoupdate [#37](https://github.com/jupyter-server/jupyter_ydoc/pull/37) ([@pre-commit-ci](https://github.com/pre-commit-ci))
- [pre-commit.ci] pre-commit autoupdate [#36](https://github.com/jupyter-server/jupyter_ydoc/pull/36) ([@pre-commit-ci](https://github.com/pre-commit-ci))
- [pre-commit.ci] pre-commit autoupdate [#28](https://github.com/jupyter-server/jupyter_ydoc/pull/28) ([@pre-commit-ci](https://github.com/pre-commit-ci))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-07-04&to=2022-07-26&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-07-04..2022-07-26&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2022-07-04..2022-07-26&type=Issues)

## 0.1.13

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.12...807dc511e2d3536c62d0710d2b97a21c6e704337))

### Merged PRs

- Update API [#32](https://github.com/jupyter-server/jupyter_ydoc/pull/32) ([@hbcarlos](https://github.com/hbcarlos))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-06-30&to=2022-07-04&type=c))

[@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-06-30..2022-07-04&type=Issues)

## 0.1.12

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.11...05c97a4b32b826f7c5224d8807340314a7df832d))

### Merged PRs

- Fix type checking when casting [#30](https://github.com/jupyter-server/jupyter_ydoc/pull/30) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-06-09&to=2022-06-30&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-06-09..2022-06-30&type=Issues)

## 0.1.11

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.10...9329161e338ac999a1c342bce89bf4f642b426aa))

### Merged PRs

- Changes the schema [#27](https://github.com/jupyter-server/jupyter_ydoc/pull/27) ([@hbcarlos](https://github.com/hbcarlos))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-19&to=2022-06-09&type=c))

[@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-05-19..2022-06-09&type=Issues)

## 0.1.10

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.9...142953275358ce675203d3de479cf8f2a4413fe8))

### Merged PRs

- Remove document apply_update method [#25](https://github.com/jupyter-server/jupyter_ydoc/pull/25) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-19&to=2022-05-19&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-19..2022-05-19&type=Issues)

## 0.1.9

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.8...4654f6176af5c6f26f18646283e9eec16b1f013f))

### Merged PRs

- Add document apply_update method [#23](https://github.com/jupyter-server/jupyter_ydoc/pull/23) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-12&to=2022-05-19&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-12..2022-05-19&type=Issues)

## 0.1.8

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.7...3662d97fadde04e70dd599523666f2716dcd14de))

### Merged PRs

- Move nbformat and nbformat_minor to meta YMap [#21](https://github.com/jupyter-server/jupyter_ydoc/pull/21) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-11&to=2022-05-12&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-11..2022-05-12&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-05-11..2022-05-12&type=Issues)

## 0.1.7

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.6...b382a35a052da5b99c94d9bedaaa92634b5d1fb4))

### Merged PRs

- Also observe the state YMap [#19](https://github.com/jupyter-server/jupyter_ydoc/pull/19) ([@davidbrochart](https://github.com/davidbrochart))
- Change URL to point to jupyter-server [#18](https://github.com/jupyter-server/jupyter_ydoc/pull/18) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-11&to=2022-05-11&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-11..2022-05-11&type=Issues)

## 0.1.6

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.5...09cf7997439a7ca2a36041390a4e93984277a36c))

### Merged PRs

- Allow to set dirty whatever the previous value [#16](https://github.com/jupyter-server/jupyter_ydoc/pull/16) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-10&to=2022-05-11&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-10..2022-05-11&type=Issues)

## 0.1.5

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.4...5b36f6bed6c4d5a789b9dd7b06a526889e515511))

### Merged PRs

- Adds id to cells [#13](https://github.com/jupyter-server/jupyter_ydoc/pull/13) ([@hbcarlos](https://github.com/hbcarlos))
- [pre-commit.ci] pre-commit autoupdate [#12](https://github.com/jupyter-server/jupyter_ydoc/pull/12) ([@pre-commit-ci](https://github.com/pre-commit-ci))
- Transfer repo to jupyter-server org [#11](https://github.com/jupyter-server/jupyter_ydoc/pull/11) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-09&to=2022-05-10&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-09..2022-05-10&type=Issues) | [@hbcarlos](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Ahbcarlos+updated%3A2022-05-09..2022-05-10&type=Issues) | [@pre-commit-ci](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Apre-commit-ci+updated%3A2022-05-09..2022-05-10&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Awelcome+updated%3A2022-05-09..2022-05-10&type=Issues)

## 0.1.4

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.3...d6e754a8c957582029d923cadc4e6547a324718c))

### Merged PRs

- Update ypy>=0.5.0 [#9](https://github.com/jupyter-server/jupyter_ydoc/pull/9) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-05&to=2022-05-09&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-05..2022-05-09&type=Issues)

## 0.1.3

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.2...c68ebe54e500edde4eb34aa598dfb7bbb4d22b63))

### Merged PRs

- Add setuptools to install_requires [#7](https://github.com/jupyter-server/jupyter_ydoc/pull/7) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-05&to=2022-05-05&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-05..2022-05-05&type=Issues)

## 0.1.2

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/v0.1.1...6a1fc44531344e1f930a7fd52b62cbd289873be0))

### Merged PRs

- Improve jupyter_ydoc.ydocs [#5](https://github.com/jupyter-server/jupyter_ydoc/pull/5) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-04&to=2022-05-05&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-04..2022-05-05&type=Issues)

## 0.1.1

([Full Changelog](https://github.com/jupyter-server/jupyter_ydoc/compare/0.1.0...9db91b826c38116ab1e00b26140dd49950e1a793))

### Merged PRs

- Add test [#3](https://github.com/jupyter-server/jupyter_ydoc/pull/3) ([@davidbrochart](https://github.com/davidbrochart))
- Update README [#1](https://github.com/jupyter-server/jupyter_ydoc/pull/1) ([@davidbrochart](https://github.com/davidbrochart))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyter-server/jupyter_ydoc/graphs/contributors?from=2022-05-02&to=2022-05-04&type=c))

[@davidbrochart](https://github.com/search?q=repo%3Ajupyter-server%2Fjupyter_ydoc+involves%3Adavidbrochart+updated%3A2022-05-02..2022-05-04&type=Issues)

## 0.1.0
