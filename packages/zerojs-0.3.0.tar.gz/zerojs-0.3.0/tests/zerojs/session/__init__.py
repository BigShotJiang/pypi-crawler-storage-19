"""Session storage tests."""
