# type: ignore
# ruff: noqa
# flake8: noqa
# @omlish-generated
# Generated from Protobuf3.g4 by ANTLR 4.13.2
from ....text.antlr._runtime._all import *
if "." in __name__:
    from .Protobuf3Parser import Protobuf3Parser
else:
    from Protobuf3Parser import Protobuf3Parser

# This class defines a complete listener for a parse tree produced by Protobuf3Parser.
class Protobuf3Listener(ParseTreeListener):

    # Enter a parse tree produced by Protobuf3Parser#proto.
    def enterProto(self, ctx:Protobuf3Parser.ProtoContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#proto.
    def exitProto(self, ctx:Protobuf3Parser.ProtoContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#syntax.
    def enterSyntax(self, ctx:Protobuf3Parser.SyntaxContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#syntax.
    def exitSyntax(self, ctx:Protobuf3Parser.SyntaxContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#syntaxExtra.
    def enterSyntaxExtra(self, ctx:Protobuf3Parser.SyntaxExtraContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#syntaxExtra.
    def exitSyntaxExtra(self, ctx:Protobuf3Parser.SyntaxExtraContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#importStmt.
    def enterImportStmt(self, ctx:Protobuf3Parser.ImportStmtContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#importStmt.
    def exitImportStmt(self, ctx:Protobuf3Parser.ImportStmtContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#packageStmt.
    def enterPackageStmt(self, ctx:Protobuf3Parser.PackageStmtContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#packageStmt.
    def exitPackageStmt(self, ctx:Protobuf3Parser.PackageStmtContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#option.
    def enterOption(self, ctx:Protobuf3Parser.OptionContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#option.
    def exitOption(self, ctx:Protobuf3Parser.OptionContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#optionName.
    def enterOptionName(self, ctx:Protobuf3Parser.OptionNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#optionName.
    def exitOptionName(self, ctx:Protobuf3Parser.OptionNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#optionBody.
    def enterOptionBody(self, ctx:Protobuf3Parser.OptionBodyContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#optionBody.
    def exitOptionBody(self, ctx:Protobuf3Parser.OptionBodyContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#optionBodyVariable.
    def enterOptionBodyVariable(self, ctx:Protobuf3Parser.OptionBodyVariableContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#optionBodyVariable.
    def exitOptionBodyVariable(self, ctx:Protobuf3Parser.OptionBodyVariableContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#topLevelDef.
    def enterTopLevelDef(self, ctx:Protobuf3Parser.TopLevelDefContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#topLevelDef.
    def exitTopLevelDef(self, ctx:Protobuf3Parser.TopLevelDefContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#message.
    def enterMessage(self, ctx:Protobuf3Parser.MessageContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#message.
    def exitMessage(self, ctx:Protobuf3Parser.MessageContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageBody.
    def enterMessageBody(self, ctx:Protobuf3Parser.MessageBodyContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageBody.
    def exitMessageBody(self, ctx:Protobuf3Parser.MessageBodyContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageBodyContent.
    def enterMessageBodyContent(self, ctx:Protobuf3Parser.MessageBodyContentContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageBodyContent.
    def exitMessageBodyContent(self, ctx:Protobuf3Parser.MessageBodyContentContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#enumDef.
    def enterEnumDef(self, ctx:Protobuf3Parser.EnumDefContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#enumDef.
    def exitEnumDef(self, ctx:Protobuf3Parser.EnumDefContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#enumBody.
    def enterEnumBody(self, ctx:Protobuf3Parser.EnumBodyContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#enumBody.
    def exitEnumBody(self, ctx:Protobuf3Parser.EnumBodyContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#enumField.
    def enterEnumField(self, ctx:Protobuf3Parser.EnumFieldContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#enumField.
    def exitEnumField(self, ctx:Protobuf3Parser.EnumFieldContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#enumValueOption.
    def enterEnumValueOption(self, ctx:Protobuf3Parser.EnumValueOptionContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#enumValueOption.
    def exitEnumValueOption(self, ctx:Protobuf3Parser.EnumValueOptionContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#extend.
    def enterExtend(self, ctx:Protobuf3Parser.ExtendContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#extend.
    def exitExtend(self, ctx:Protobuf3Parser.ExtendContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#service.
    def enterService(self, ctx:Protobuf3Parser.ServiceContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#service.
    def exitService(self, ctx:Protobuf3Parser.ServiceContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#rpc.
    def enterRpc(self, ctx:Protobuf3Parser.RpcContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#rpc.
    def exitRpc(self, ctx:Protobuf3Parser.RpcContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#reserved.
    def enterReserved(self, ctx:Protobuf3Parser.ReservedContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#reserved.
    def exitReserved(self, ctx:Protobuf3Parser.ReservedContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#ranges.
    def enterRanges(self, ctx:Protobuf3Parser.RangesContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#ranges.
    def exitRanges(self, ctx:Protobuf3Parser.RangesContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#rangeRule.
    def enterRangeRule(self, ctx:Protobuf3Parser.RangeRuleContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#rangeRule.
    def exitRangeRule(self, ctx:Protobuf3Parser.RangeRuleContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fieldNames.
    def enterFieldNames(self, ctx:Protobuf3Parser.FieldNamesContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fieldNames.
    def exitFieldNames(self, ctx:Protobuf3Parser.FieldNamesContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#typeRule.
    def enterTypeRule(self, ctx:Protobuf3Parser.TypeRuleContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#typeRule.
    def exitTypeRule(self, ctx:Protobuf3Parser.TypeRuleContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#simpleType.
    def enterSimpleType(self, ctx:Protobuf3Parser.SimpleTypeContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#simpleType.
    def exitSimpleType(self, ctx:Protobuf3Parser.SimpleTypeContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fieldNumber.
    def enterFieldNumber(self, ctx:Protobuf3Parser.FieldNumberContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fieldNumber.
    def exitFieldNumber(self, ctx:Protobuf3Parser.FieldNumberContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#field.
    def enterField(self, ctx:Protobuf3Parser.FieldContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#field.
    def exitField(self, ctx:Protobuf3Parser.FieldContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fieldOptions.
    def enterFieldOptions(self, ctx:Protobuf3Parser.FieldOptionsContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fieldOptions.
    def exitFieldOptions(self, ctx:Protobuf3Parser.FieldOptionsContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fieldOption.
    def enterFieldOption(self, ctx:Protobuf3Parser.FieldOptionContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fieldOption.
    def exitFieldOption(self, ctx:Protobuf3Parser.FieldOptionContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#oneof.
    def enterOneof(self, ctx:Protobuf3Parser.OneofContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#oneof.
    def exitOneof(self, ctx:Protobuf3Parser.OneofContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#oneofField.
    def enterOneofField(self, ctx:Protobuf3Parser.OneofFieldContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#oneofField.
    def exitOneofField(self, ctx:Protobuf3Parser.OneofFieldContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#mapField.
    def enterMapField(self, ctx:Protobuf3Parser.MapFieldContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#mapField.
    def exitMapField(self, ctx:Protobuf3Parser.MapFieldContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#keyType.
    def enterKeyType(self, ctx:Protobuf3Parser.KeyTypeContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#keyType.
    def exitKeyType(self, ctx:Protobuf3Parser.KeyTypeContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#reservedWord.
    def enterReservedWord(self, ctx:Protobuf3Parser.ReservedWordContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#reservedWord.
    def exitReservedWord(self, ctx:Protobuf3Parser.ReservedWordContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fullIdent.
    def enterFullIdent(self, ctx:Protobuf3Parser.FullIdentContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fullIdent.
    def exitFullIdent(self, ctx:Protobuf3Parser.FullIdentContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageName.
    def enterMessageName(self, ctx:Protobuf3Parser.MessageNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageName.
    def exitMessageName(self, ctx:Protobuf3Parser.MessageNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#enumName.
    def enterEnumName(self, ctx:Protobuf3Parser.EnumNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#enumName.
    def exitEnumName(self, ctx:Protobuf3Parser.EnumNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageOrEnumName.
    def enterMessageOrEnumName(self, ctx:Protobuf3Parser.MessageOrEnumNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageOrEnumName.
    def exitMessageOrEnumName(self, ctx:Protobuf3Parser.MessageOrEnumNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#fieldName.
    def enterFieldName(self, ctx:Protobuf3Parser.FieldNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#fieldName.
    def exitFieldName(self, ctx:Protobuf3Parser.FieldNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#oneofName.
    def enterOneofName(self, ctx:Protobuf3Parser.OneofNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#oneofName.
    def exitOneofName(self, ctx:Protobuf3Parser.OneofNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#mapName.
    def enterMapName(self, ctx:Protobuf3Parser.MapNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#mapName.
    def exitMapName(self, ctx:Protobuf3Parser.MapNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#serviceName.
    def enterServiceName(self, ctx:Protobuf3Parser.ServiceNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#serviceName.
    def exitServiceName(self, ctx:Protobuf3Parser.ServiceNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#rpcName.
    def enterRpcName(self, ctx:Protobuf3Parser.RpcNameContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#rpcName.
    def exitRpcName(self, ctx:Protobuf3Parser.RpcNameContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageType.
    def enterMessageType(self, ctx:Protobuf3Parser.MessageTypeContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageType.
    def exitMessageType(self, ctx:Protobuf3Parser.MessageTypeContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#messageOrEnumType.
    def enterMessageOrEnumType(self, ctx:Protobuf3Parser.MessageOrEnumTypeContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#messageOrEnumType.
    def exitMessageOrEnumType(self, ctx:Protobuf3Parser.MessageOrEnumTypeContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#emptyStmt.
    def enterEmptyStmt(self, ctx:Protobuf3Parser.EmptyStmtContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#emptyStmt.
    def exitEmptyStmt(self, ctx:Protobuf3Parser.EmptyStmtContext):
        pass


    # Enter a parse tree produced by Protobuf3Parser#constant.
    def enterConstant(self, ctx:Protobuf3Parser.ConstantContext):
        pass

    # Exit a parse tree produced by Protobuf3Parser#constant.
    def exitConstant(self, ctx:Protobuf3Parser.ConstantContext):
        pass



del Protobuf3Parser