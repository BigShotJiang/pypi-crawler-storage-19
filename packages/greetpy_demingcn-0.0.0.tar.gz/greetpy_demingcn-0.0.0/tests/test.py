#!/usr/bin/env python
# -*-encoding:utf-8-*-
# ------------------------------------------------------------------------------
# Name:         test.py
# Description:  
# Author:       Deming
# Date:         2026/1/11 22:58
# ------------------------------------------------------------------------------
import pytest
from greetpy_demingcn import greet, greet_multiple, Greeter


def test_greet():
    """测试greet函数"""
    assert greet() == "Hello, World!"
    assert greet("Alice") == "Hello, Alice!"


def test_greet_multiple():
    """测试greet_multiple函数"""
    result = greet_multiple(["Alice", "Bob"])
    assert result == ["Hello, Alice!", "Hello, Bob!"]

    result = greet_multiple(["Alice"], "Hi")
    assert result == ["Hi, Alice!"]


def test_greeter_class():
    """测试Greeter类"""
    greeter = Greeter("Alice")
    assert greeter.say_hello() == "Hello, Alice!"
    assert greeter.say_hi() == "Hi, Alice!"


if __name__ == "__main__":
    pytest.main()
