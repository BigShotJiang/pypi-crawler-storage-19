# GreetPy

一个简单的Python打招呼包，用于演示如何创建和发布Python包。

## 安装

```bash
pip install greetpy_demingcn
```

## 使用方法
### 基本使用
```python
from greetpy_demingcn import greet, greet_multiple, Greeter

# 使用函数
print(greet("Alice"))  # Hello, Alice!

# 向多个人打招呼
messages = greet_multiple(["Alice", "Bob", "Charlie"])
for msg in messages:
    print(msg)

# 使用类
greeter = Greeter("World")
print(greeter.say_hello())  # Hello, World!
print(greeter.say_hi())     # Hi, World!
```

### 命令行工具
安装后可以使用命令行工具：
```bash
greet-deming Alice
# 输出: Hello, Alice!
```

## 功能
- greet(name): 向一个人打招呼 
- greet_multiple(names, greeting): 向多个人打招呼 
- Greeter 类: 更灵活的打招呼器

## 开发
1. 克隆仓库 
2. 安装开发依赖：pip install -e ".[dev]"
3. 运行测试：pytest
