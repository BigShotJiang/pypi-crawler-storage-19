"""
greetpy - 一个简单的打招呼包
"""

# 导入包的主要功能到顶层命名空间
from .greet import greet, greet_multiple, Greeter

# 定义包的版本号
__version__ = "0.1.0"
# 作者信息
__author__ = "DemingLiu <demingcn@163.com>"
# 定义公开的API接口
__all__ = ["greet", "greet_multiple", "Greeter"]