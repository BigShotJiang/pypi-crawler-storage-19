#!/usr/bin/env python
# -*-encoding:utf-8-*-
# ------------------------------------------------------------------------------
# Name:         cli.py
# Description:  命令行接口
# Author:       Deming
# Date:         2026/1/11 23:05
# ------------------------------------------------------------------------------
import argparse
from .greet import greet, greet_multiple


def main():
    parser = argparse.ArgumentParser(description="Greet someone")
    parser.add_argument("names", nargs="*", default=["World"],
                        help="Names to greet (default: World)")
    parser.add_argument("-g", "--greeting", default="Hello",
                        help="Greeting word (default: Hello)")
    parser.add_argument("-s", "--separator", default="\n",
                        help="Separator between greetings (default: newline)")

    args = parser.parse_args()

    if len(args.names) == 1:
        message = greet(args.names[0])
    else:
        messages = greet_multiple(args.names, args.greeting)
        message = args.separator.join(messages)

    print(message)


if __name__ == "__main__":
    main()