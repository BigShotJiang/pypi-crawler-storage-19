#!/usr/bin/env python
# -*-encoding:utf-8-*-
# ------------------------------------------------------------------------------
# Name:         greet.py
# Description:  
# Author:       Deming
# Date:         2026/1/11 22:55
# ------------------------------------------------------------------------------
"""
打招呼模块
"""


class Greeter:
    """打招呼器类"""

    def __init__(self, name: str = "World"):
        self.name = name

    def say_hello(self) -> str:
        """说你好"""
        return f"Hello, {self.name}!"

    def say_hi(self) -> str:
        """说嗨"""
        return f"Hi, {self.name}!"


def greet(name: str = "World") -> str:
    """
    简单的打招呼函数

    Args:
        name: 要打招呼的名字，默认为"World"

    Returns:
        打招呼的字符串

    Examples:
        >>> greet("Alice")
        'Hello, Alice!'
    """
    return f"Hello, {name}!"


def greet_multiple(names: list, greeting: str = "Hello") -> list:
    """
    向多个人打招呼

    Args:
        names: 名字列表
        greeting: 问候语，默认为"Hello"

    Returns:
        问候语列表

    Examples:
        >>> greet_multiple(["Alice", "Bob"])
        ['Hello, Alice!', 'Hello, Bob!']
    """
    return [f"{greeting}, {name}!" for name in names]