"""API module for KohakuBoard"""
