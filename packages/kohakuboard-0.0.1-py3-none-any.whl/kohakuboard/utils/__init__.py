"""Utilities for KohakuBoard."""
