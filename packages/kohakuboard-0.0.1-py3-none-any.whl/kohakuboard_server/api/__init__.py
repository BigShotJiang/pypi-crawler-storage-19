"""KohakuBoard Server API endpoints"""
