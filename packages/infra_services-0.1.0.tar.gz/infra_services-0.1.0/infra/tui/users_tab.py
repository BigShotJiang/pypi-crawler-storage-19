"""
Users Tab for Infra TUI
"""

from textual.app import ComposeResult
from textual.widgets import Static, Label, Button
from textual.containers import Horizontal, ScrollableContainer
from ..core.users import UserManager


class UsersTab(Static):
    """Tab for user and group management"""

    def compose(self) -> ComposeResult:
        yield Label("User & Group Management", id="users-title")
        yield Label(f"Group: {UserManager.GROUP_NAME}", id="group-name")
        yield Label("Delete requires no home directory. Use CLI for force delete: [cyan]infra user delete -r <user>[/]", id="users-help")
        yield Label("", id="users-spacer")

        # Header row
        yield Horizontal(
            Label("Username", id="header-username", classes="col-username"),
            Label("Infra", id="header-group-action", classes="col-group"),
            Label("Docker", id="header-docker", classes="col-docker"),
            Label("Sudo", id="header-add-sudo", classes="col-sudo"),
            Label("No Pass", id="header-sudo-action", classes="col-nopass"),
            Label("Passwd", id="header-passwd", classes="col-passwd"),
            Label("Delete", id="header-delete", classes="col-delete"),
            id="users-header"
        )

        yield ScrollableContainer(id="users-list")

        yield Label("", id="users-spacer2")
        yield Horizontal(
            Button("Create User", id="create-user", variant="primary"),
            id="create-user-container"
        )
