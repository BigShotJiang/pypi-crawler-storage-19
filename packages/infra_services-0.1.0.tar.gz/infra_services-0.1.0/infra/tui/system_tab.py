"""
System Tab for Infra TUI
"""

from textual.app import ComposeResult
from textual.widgets import Static, Label, DataTable


class SystemTab(Static):
    """Tab for system information"""

    def compose(self) -> ComposeResult:
        yield Label("System Information", id="system-title")
        yield Label("Press **R** to refresh | Press **9** for Help", id="system-help")
        yield DataTable(id="system-table")
