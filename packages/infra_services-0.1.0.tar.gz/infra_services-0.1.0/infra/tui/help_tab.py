"""
Help Tab for Infra TUI
"""

from textual.app import ComposeResult
from textual.widgets import Static, Label


class HelpTab(Static):
    """Tab for help and documentation"""

    def compose(self) -> ComposeResult:
        yield Label("Help & Documentation", id="help-title")
        yield Label("""
[bold]CLI Commands[/]

To manage infra services from the command line:

  [cyan]infra[/]                    - Launch this TUI
  [cyan]infra status[/]             - Show all service statuses
  [cyan]infra start <service>[/]    - Start a service
  [cyan]infra stop <service>[/]     - Stop a service
  [cyan]infra restart <service>[/]  - Restart a service
  [cyan]infra logs <service>[/]     - View service logs

[bold]Cloudflare Commands[/]

  [cyan]infra cloudflare list-tokens[/]     - List all tokens
  [cyan]infra cloudflare add-token[/]       - Add a new token
  [cyan]infra cloudflare list-domains[/]    - List domains
  [cyan]infra cloudflare test[/]            - Test connection

[bold]Uninstall[/]

To completely remove infra:

  [cyan]infra uninstall[/]

This will:
  - Stop all managed Docker services
  - Remove the infra-users group
  - Remove configuration from /etc/infra/
  - Uninstall the Python package

Note: Docker service files in /opt/infra-services/ will remain.
To remove them: [cyan]sudo rm -rf /opt/infra-services[/]

[bold]User Commands[/]

  [cyan]infra user delete <username>[/]     - Delete a user (no home dir)
  [cyan]infra user delete -r <username>[/]  - Delete user AND home directory

Note: Users with home directories can only be deleted via CLI with -r flag.

[bold]Service Locations[/]

  Docker Services: [cyan]/opt/infra-services/services/[/]
  Configuration:   [cyan]/etc/infra/[/]

[bold]Adding New Services[/]

1. Create service directory:
   [cyan]mkdir -p /opt/infra-services/services/my-service[/]

2. Add docker-compose.yml:
   [cyan]nano /opt/infra-services/services/my-service/docker-compose.yml[/]

3. Service is automatically available in infra!
""", id="help-content")
