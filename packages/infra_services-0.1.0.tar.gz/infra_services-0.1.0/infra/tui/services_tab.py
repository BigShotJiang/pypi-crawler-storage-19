"""
Services Tab for Infra TUI
"""

from textual.app import ComposeResult
from textual.widgets import Static, Label, DataTable


class ServicesTab(Static):
    """Tab for Docker service management"""

    def compose(self) -> ComposeResult:
        yield Label("Docker Services Status", id="status-title")
        yield DataTable(id="services-table")
