"""TUI application for infra services"""
