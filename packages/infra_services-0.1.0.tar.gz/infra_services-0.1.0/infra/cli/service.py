"""
Service management CLI commands
Start, stop, restart services
"""

import sys
from ..core.docker import DockerManager
from ..core.config import Config


def start_service(service_name: str):
    """Start a service"""
    if not Config.service_exists(service_name):
        print(f"✗ Service '{service_name}' not found")
        sys.exit(1)

    service_dir = Config.get_service_dir(service_name)
    print(f"Starting {service_name}...")

    if DockerManager.start_service(service_name, str(service_dir)):
        print(f"✓ {service_name} started successfully")
    else:
        print(f"✗ Failed to start {service_name}")
        sys.exit(1)


def stop_service(service_name: str):
    """Stop a service"""
    if not Config.service_exists(service_name):
        print(f"✗ Service '{service_name}' not found")
        sys.exit(1)

    service_dir = Config.get_service_dir(service_name)
    print(f"Stopping {service_name}...")

    if DockerManager.stop_service(service_name, str(service_dir)):
        print(f"✓ {service_name} stopped successfully")
    else:
        print(f"✗ Failed to stop {service_name}")
        sys.exit(1)


def restart_service(service_name: str):
    """Restart a service"""
    stop_service(service_name)
    start_service(service_name)


def logs_service(service_name: str, tail: int = 100):
    """Show logs for a service"""
    container_name = f"infra_{service_name}"
    logs = DockerManager.get_service_logs(service_name, tail)

    if logs:
        print(f"\n=== Logs for {service_name} ===\n")
        print(logs)
    else:
        print(f"✗ No logs found for {service_name}")
        sys.exit(1)
