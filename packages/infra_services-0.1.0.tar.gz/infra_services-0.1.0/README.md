# Infra CLI

Infrastructure services management CLI and TUI.

## What is Infra CLI?

Infra CLI is a Python package that manages Docker Compose services. It works with service definitions stored in `/opt/infra-services/`.

## Installation

```bash
pip install infra-cli
```

Or for development:

```bash
git clone https://github.com/metrotelinc/weaverbird-infra.git
cd weaverbird-infra
pip install -e .
```

## Quick Start

```bash
# Launch the TUI
infra

# Or use CLI commands directly
infra status
infra start traefik
infra cloudflare list-tokens
```

## Directory Structure

```
# Development (your machine)
weaverbird-infra/                    # Git repo (Python code)
├── infra/                           # Python package
├── pyproject.toml
└── README.md

# Production (servers)
/opt/infra-services/                 # Docker Compose files
├── services/
│   ├── traefik/
│   ├── wireguard/
│   └── mqtt/

/etc/infra/                          # Configuration & secrets
├── infra.env                        # Environment variables
└── cloudflare.json                  # API tokens
```

## Features

- **Docker Service Management**: Start, stop, restart, and view logs for services
- **Cloudflare DNS Integration**: Manage DNS records across multiple accounts/tokens
- **User Management**: Manage the `infra-users` group for multi-admin access
- **System Info**: View disk, memory, CPU, uptime, and load
- **Terminal UI**: Interactive TUI for easy management
- **Dynamic Service Discovery**: Automatically finds all services in `/opt/infra-services/services/`

## Configuration

Configuration is stored in `/etc/infra/`:

### Environment Variables (`/etc/infra/infra.env`)

```bash
CLOUDFLARE_API_TOKEN=your_token_here
CLOUDFLARE_EMAIL=your@email.com
TRAEFIK_DOMAIN=example.com
WG_HOST=vpn.example.com
WG_PORT=51820
MOSQUITTO_USERNAME=admin
MOSQUITTO_PASSWORD=changeme
```

### Cloudflare Tokens (`/etc/infra/cloudflare.json`)

```bash
infra cloudflare add-token personal
```

## Managing Services

### Adding a New Service

1. Create service directory:
   ```bash
   mkdir -p /opt/infra-services/services/my-service
   ```

2. Add docker-compose.yml:
   ```bash
   nano /opt/infra-services/services/my-service/docker-compose.yml
   ```

3. Service is automatically available:
   ```bash
   infra status              # Shows "my-service"
   infra start my-service
   ```

### Service Discovery

Infra automatically discovers services from `/opt/infra-services/services/`:

- **Flat**: `services/traefik/docker-compose.yml` → `traefik`
- **Nested**: `services/project/dev/docker-compose.yml` → `project/dev`
- **Multiple**: `services/app/docker-compose.yml` + `docker-compose.prod.yml`

### Disabling a Service

```bash
# Stop it
infra stop my-service

# Or rename the file
mv /opt/infra-services/services/my-service/docker-compose.yml \
   /opt/infra-services/services/my-service/docker-compose.yml.disabled
```

## Uninstall

```bash
infra uninstall
```

This will:
1. Stop all managed Docker services
2. Remove the `infra-users` group
3. Remove configuration from `/etc/infra/`
4. Uninstall the Python package

**Note:** Docker service files remain in `/opt/infra-services/`. To remove them:
```bash
sudo rm -rf /opt/infra-services
```

## License

Apache License 2.0 - See [LICENSE](LICENSE) for details.
