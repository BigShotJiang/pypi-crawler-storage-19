"""
INL Block layers for INL-LLM.

Contains:
- UltraOptimizedINLBlock: Main transformer block with all optimizations
"""

import torch
import torch.nn as nn
from typing import Optional, Tuple, Dict

from .normalization import RMSNorm, SwiGLU
from .attention import GroupedQueryAttention
from .cache import INLCacheLayer

from ..optimizations.advanced_optimizations import SharedController, HierarchicalEquilibriumINL, MixtureOfIntegrators
from ..optimizations.optimizations import AdaptiveHierarchicalINL
from ..core.adaptive_budget_allocator import AdaptiveBudgetAllocator


class UltraOptimizedINLBlock(nn.Module):
    """
    Ultra-optimized INL block with all optimizations enabled (v3).

    Uses:
    - RMSNorm (faster than LayerNorm)
    - GQA + RoPE (better attention + position encoding)
    - SwiGLU (better activation)
    - Shared controllers (across all blocks in the model)
    - Hierarchical equilibrium OR MoE integrators
    - Sparse harmonic excitation
    - Adaptive early stopping
    - Gradient checkpointing
    """

    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_iterations: int,
        shared_controller: SharedController,
        layer_idx: int,
        feedforward_dim: int,
        dropout: float = 0.1,
        use_gradient_checkpointing: bool = False,
        use_adaptive_stopping: bool = True,
        adaptive_convergence_threshold: float = 0.001,
        group_size: int = 64,
        excitation_sparsity: float = 0.1,
        budget_allocator: Optional[AdaptiveBudgetAllocator] = None,
        # v3 optimizations
        num_kv_heads: Optional[int] = None,  # GQA: fewer KV heads
        max_seq_len: int = 4096,
        rope_base: float = 10000.0,
        # MoE INL (Mixture of Integrators)
        use_moe: bool = False,
        num_experts: int = 8,
        moe_top_k: int = 2,
        num_layers: int = 24  # Total layers for layer embedding
    ):
        super().__init__()

        self.d_model = d_model
        self.num_iterations = num_iterations
        self.layer_idx = layer_idx
        self.shared_controller = shared_controller
        self.use_adaptive_stopping = use_adaptive_stopping
        self.budget_allocator = budget_allocator
        self.use_moe = use_moe

        # v3: RMSNorm instead of LayerNorm
        self.norm1 = RMSNorm(d_model)
        self.norm2 = RMSNorm(d_model)
        self.norm_attn = RMSNorm(d_model)

        # v3: GQA + RoPE instead of standard MHA
        self.attention = GroupedQueryAttention(
            embed_dim=d_model,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,  # GQA
            dropout=dropout,
            max_seq_len=max_seq_len,
            rope_base=rope_base
        )

        # INL Dynamics: MoE or standard
        if use_moe:
            # MoE: Multiple expert integrators with routing
            base_inl = MixtureOfIntegrators(
                hidden_dim=d_model,
                output_dim=d_model,
                num_experts=num_experts,
                top_k=moe_top_k,
                target_value=0.0,
                dt=0.1,
                num_layers=num_layers,
                layer_idx=layer_idx
            )
            # MoE doesn't use adaptive stopping (different interface)
            self.inl = base_inl
        else:
            # Standard: Hierarchical equilibrium + sparse excitation
            base_inl = HierarchicalEquilibriumINL(
                hidden_dim=d_model,
                output_dim=d_model,
                group_size=group_size,
                target_value=0.0,
                dt=0.1
            )
            if use_adaptive_stopping:
                self.inl = AdaptiveHierarchicalINL(
                    inl_layer=base_inl,
                    convergence_threshold=adaptive_convergence_threshold,
                    min_iterations=3,
                    max_iterations=num_iterations,
                    check_interval=1
                )
            else:
                self.inl = base_inl

        # v3: SwiGLU instead of GELU FFN
        # SwiGLU hidden dim is typically 8/3 * d_model to match param count
        swiglu_hidden = int(feedforward_dim * 2 / 3)  # Adjust for 3 matrices
        self.ff = SwiGLU(
            in_features=d_model,
            hidden_features=swiglu_hidden,
            out_features=d_model,
            dropout=dropout
        )

        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        cache_layer: Optional[INLCacheLayer] = None,
        use_cache: bool = False,
        start_pos: int = 0  # v3: for RoPE position encoding
    ) -> Tuple[torch.Tensor, Dict]:
        batch_size, seq_len, d_model = x.shape

        # Step 1: Attention with KV cache and RoPE
        x_norm = self.norm_attn(x)

        # Build causal mask
        if use_cache and cache_layer is not None:
            # During generation with cache: mask is for new tokens attending to all previous tokens
            past_len = cache_layer.get_seq_length()
            total_len = past_len + seq_len
            # Create mask [seq_len, total_len] where each new token can attend to all previous + itself
            attn_mask = torch.zeros(seq_len, total_len, device=x.device, dtype=torch.bool)
            # Only mask future tokens within the new sequence
            if seq_len > 1:
                new_causal_mask = torch.triu(
                    torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool),
                    diagonal=1
                )
                attn_mask[:, past_len:] = new_causal_mask
        elif mask is None:
            # Standard causal mask for full sequence
            attn_mask = torch.triu(
                torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool),
                diagonal=1
            )
        else:
            attn_mask = mask

        # v3: Pass start_pos to attention for RoPE
        attn_output, _ = self.attention(x_norm, attn_mask=attn_mask, cache_layer=cache_layer, use_cache=use_cache, start_pos=start_pos)
        x = x + self.dropout(attn_output)
        context = attn_output

        # Step 2: INL Dynamics (ultra-optimized with adaptive early stopping)
        x_norm = self.norm1(x)

        # Initialize integrator states (x, v)
        # NOTE: We always initialize fresh for each forward pass.
        # The integrator dynamics run WITHIN each layer, not across tokens.
        # The cache is ONLY for attention K,V to avoid recomputing attention over past tokens.
        x_state = x_norm.clone()
        v_state = torch.zeros_like(x_norm)

        # Flatten for INL processing
        x_flat_init = x_state.reshape(batch_size * seq_len, d_model)
        v_flat_init = v_state.reshape(batch_size * seq_len, d_model)
        ctx_flat = context.reshape(batch_size * seq_len, d_model)

        # Get iteration budget (if budget allocator available)
        if self.budget_allocator is not None:
            max_iters = self.budget_allocator.get_layer_budget(self.layer_idx, self.training)
        else:
            max_iters = self.num_iterations

        # Use adaptive forward if available (inference mode with early stopping)
        if self.use_adaptive_stopping and hasattr(self.inl, 'forward_adaptive') and not self.training:
            # Adaptive early stopping (3x faster inference)
            x_final_flat, v_final_flat, adaptive_result = self.inl.forward_adaptive(
                ctx_flat,
                x_flat_init,
                v_flat_init,
                num_iterations=max_iters,
                use_early_stopping=True,
                return_trajectory=True
            )

            # Get trajectories from adaptive result
            if 'x_trajectory' in adaptive_result:
                x_traj_flat = adaptive_result['x_trajectory']  # [B*S, T+1, D]
                v_traj_flat = adaptive_result['v_trajectory']  # [B*S, T+1, D]
            else:
                # Fallback: single final state
                x_traj_flat = x_final_flat.unsqueeze(1)
                v_traj_flat = v_final_flat.unsqueeze(1)

            aux_infos = {
                'x': x_traj_flat,
                'v': v_traj_flat,
                'mu': adaptive_result.get('mu'),
                'mu_global': adaptive_result.get('mu_global'),
                'mu_offsets': adaptive_result.get('mu_offsets'),
                'iterations_used': adaptive_result.get('iterations_used'),
                'avg_iterations': adaptive_result.get('avg_iterations'),
                'max_iterations': max_iters,
                'layer_idx': self.layer_idx
            }

            output = x_final_flat.reshape(batch_size, seq_len, d_model)

        else:
            # Budget-aware training mode
            x_trajectory = [x_flat_init.clone()]
            v_trajectory = [v_flat_init.clone()]

            x_flat, v_flat = x_flat_init, v_flat_init
            x_prev = x_flat_init
            actual_iterations = 0

            for iteration in range(max_iters):
                x_next_flat, v_next_flat, aux = self.inl(ctx_flat, x_flat, v_flat, step=iteration)

                # Check for early stopping (if budget allocator with convergence checking)
                if (self.budget_allocator is not None and
                    iteration >= self.budget_allocator.warmup_iterations and
                    not self.training):

                    converged = self.budget_allocator.check_convergence(x_next_flat, x_flat, iteration)
                    if converged:
                        x_flat, v_flat = x_next_flat, v_next_flat
                        actual_iterations = iteration + 1
                        x_trajectory.append(x_flat.clone())
                        v_trajectory.append(v_flat.clone())
                        break

                x_prev = x_flat
                x_flat, v_flat = x_next_flat, v_next_flat
                actual_iterations = iteration + 1

                # Save trajectories for loss computation
                x_trajectory.append(x_flat.clone())
                v_trajectory.append(v_flat.clone())

            # Update budget statistics (during training)
            if self.training and self.budget_allocator is not None:
                final_delta = torch.norm(x_flat - x_prev, dim=-1).mean().item()
                self.budget_allocator.update_statistics(
                    self.layer_idx,
                    actual_iterations,
                    final_delta
                )

            # Stack trajectories: [B*S, T+1, D]
            x_traj_flat = torch.stack(x_trajectory, dim=1)
            v_traj_flat = torch.stack(v_trajectory, dim=1)

            aux_infos = {
                'x': x_traj_flat,
                'v': v_traj_flat,
                'mu': aux.get('mu', None),
                'mu_global': aux.get('mu_global', None),
                'mu_offsets': aux.get('mu_offsets', None),
                'iterations_used': actual_iterations,
                'max_iterations': max_iters,
                'layer_idx': self.layer_idx
            }

            output = x_flat.reshape(batch_size, seq_len, d_model)

        # NOTE: No need to update integrator cache - we don't cache x, v states
        # since integrator dynamics are computed fresh for each token.

        # Residual
        x = x + self.dropout(output)

        # Feedforward
        x = x + self.ff(self.norm2(x))

        return x, aux_infos
