# is even
use this library if you want to check if an integer is even or not and you think '%' is stupid.
the minimum and maximum value supported by this library are `-25338` and `25338`.

# installation
```bash
uv add isnotodd
```
or if you are old
```bash
pip install isnotodd
```

# usage
```python
from is_not_odd import is_even

print(is_even(25338))
```
