"""EntelligenceAI CLI - AI-powered code review from your terminal."""

from importlib.metadata import version

__version__ = version("entelligence-cli")

from .cli import cli
from .git_operations import GitOperations
from .api_client import APIClient, APIConfig
from .config import ConfigManager

__all__ = ["cli", "GitOperations", "APIClient", "APIConfig", "ConfigManager", "__version__"]
