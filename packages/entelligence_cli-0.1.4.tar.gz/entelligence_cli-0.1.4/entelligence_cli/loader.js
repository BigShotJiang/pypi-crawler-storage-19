const fs = require('fs');
const path = require('path');

// Read the ASCII art file
const asciiArtPath = path.join(__dirname, 'ascii-art.txt');
const baseAsciiArt = fs.readFileSync(asciiArtPath, 'utf-8');
// Remove trailing newlines and split
const trimmedArt = baseAsciiArt.replace(/\n+$/, '');
const artLines = trimmedArt.split('\n');
const artHeight = artLines.length;
const artWidth = Math.max(...artLines.map(l => l.length));

// ANSI color codes - green shades only
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',           // Regular green
  brightGreen: '\x1b[92m',     // Bright green
  boldBrightGreen: '\x1b[1;92m', // Bold bright green (most prominent)
  darkGreen: '\x1b[2;32m',     // Dark green (dim)
  dim: '\x1b[2m',
  bold: '\x1b[1m'
};

// Character groups for smooth animation transitions
const charGroups = {
  '-': ['-', '=', '~'],
  '=': ['-', '=', '+'],
  '+': ['=', '+', '*'],
  '*': ['+', '*', '#'],
  '#': ['*', '#', '%'],
  '%': ['#', '%', '@'],
  '@': ['%', '@'],
  ':': [':', ';', '.'],
  '.': [':', '.', ',']
};

// Get color for a character (green shades only)
function getColorForChar(char, frame, charIdx, lineIdx) {
  // Calculate relative position in the art (0.0 to 1.0)
  const totalLines = artLines.length;
  const linePosition = lineIdx / totalLines;
  
  // Center/core area (middle section, around 30-60% of height) - MOST PROMINENT
  const isCoreArea = linePosition >= 0.30 && linePosition <= 0.60;
  
  // Create color variation based on position and frame for dynamic effect
  const colorWave = Math.sin((charIdx * 0.1) + (lineIdx * 0.15) + (frame * 0.2)) * 0.5 + 0.5;
  const colorWave2 = Math.sin((charIdx * 0.15) + (lineIdx * 0.2) + (frame * 0.25)) * 0.5 + 0.5;
  
  if (char === '#' || char === '%' || char === '@') {
    // Major green - brightest shades
    if (isCoreArea) {
      // Core area - always use bold bright green for maximum prominence
      return colors.boldBrightGreen;
    }
    return colorWave > 0.5 ? colors.brightGreen : colors.green;
  } else if (char === '*' || char === '+') {
    // Medium green shades
    if (isCoreArea) {
      // Core area - use bright green
      return colors.brightGreen;
    }
    return colorWave2 > 0.5 ? colors.green : colors.darkGreen;
  } else if (char === '=' || char === '-') {
    // Green shades for flow characters
    return colorWave > 0.5 ? colors.green : colors.darkGreen;
  } else if (char === ':' || char === ';' || char === '.' || char === ',') {
    // Darker green for sparse characters
    return colors.darkGreen;
  }
  return colors.reset;
}

// Create animated version of ASCII art with visible motion and colors
function createAnimatedArt(frame) {
  return artLines.map((line, lineIdx) => {
    return line.split('').map((char, charIdx) => {
      // Skip spaces
      if (char === ' ') return char;
      
      let animatedChar = char;
      
      // Calculate if we're in the core area
      const totalLines = artLines.length;
      const linePosition = lineIdx / totalLines;
      const isCoreArea = linePosition >= 0.30 && linePosition <= 0.60;
      
      // Create multiple wave patterns for complex, visible motion
      const wave1 = Math.sin((charIdx * 0.12) + (frame * 0.25)) * 0.5 + 0.5;
      const wave2 = Math.sin((lineIdx * 0.18) + (frame * 0.15)) * 0.5 + 0.5;
      const wave3 = Math.sin((charIdx + lineIdx) * 0.08 + (frame * 0.3)) * 0.5 + 0.5;
      const combinedWave = (wave1 + wave2 + wave3) / 3;
      
      // Animate characters with strong randomization
      // Reduce animation in core area to keep it stable and prominent
      if (charGroups[char]) {
        const group = charGroups[char];
        const randomFactor = Math.random();
        const frameBased = (frame + charIdx + lineIdx * 10) % 7;
        
        // Less animation in core area to maintain prominence
        if (isCoreArea) {
          const shouldAnimate = combinedWave > 0.6 || (randomFactor > 0.7 && frameBased < 1);
          if (shouldAnimate) {
            const selector = (Math.floor(combinedWave * 100) + frameBased + Math.floor(randomFactor * 10)) % group.length;
            animatedChar = group[selector];
          }
        } else {
          // More aggressive animation outside core area
          const shouldAnimate = combinedWave > 0.45 || randomFactor > 0.5 || frameBased < 2;
          if (shouldAnimate) {
            const selector = (Math.floor(combinedWave * 100) + frameBased + Math.floor(randomFactor * 10)) % group.length;
            animatedChar = group[selector];
          }
        }
      }
      
      // Add color to the character (with frame and position for dynamic colors)
      const color = getColorForChar(animatedChar, frame, charIdx, lineIdx);
      return `${color}${animatedChar}${colors.reset}`;
    }).join('');
  }).join('\n');
}

// Animation state
let frame = 0;
let lineCount = artLines.length;
let timer = null;

// Compute centered paddings for current terminal size
function computeCenterPadding(contentWidth, contentHeight) {
  const cols = process.stdout.columns || 80;
  const rows = process.stdout.rows || 24;
  const leftPad = Math.max(0, Math.floor((cols - contentWidth) / 2));
  const topPad = Math.max(0, Math.floor((rows - contentHeight) / 2));
  return { leftPad, topPad, cols, rows };
}

// Animated "EntelligenceAI" logo text below the art
function renderLogo(frame) {
  const text = 'EntelligenceAI';
  const pulse = (i) => {
    const wave = Math.sin((frame * 0.25) + (i * 0.4)) * 0.5 + 0.5;
    if (wave > 0.75) return colors.boldBrightGreen;
    if (wave > 0.5) return colors.brightGreen;
    if (wave > 0.25) return colors.green;
    return colors.darkGreen;
  };
  const dotsCount = (frame % 4);
  const dots = '.'.repeat(dotsCount);
  const colored = [...text].map((ch, i) => `${pulse(i)}${ch}${colors.reset}`).join('');
  return `${colored}${colors.dim}${dots.padEnd(3, ' ')}${colors.reset}`;
}

// Animation function - draws centered art and logo
function animate() {
  const logoStr = renderLogo(frame);
  const logoWidth = logoStr.replace(/\x1b\[[0-9;]*m/g, '').length;
  const totalHeight = artHeight + 2; // art + spacer + logo (logo drawn on same final line count)
  const contentWidth = Math.max(artWidth, logoWidth);
  const { leftPad, topPad } = computeCenterPadding(contentWidth, totalHeight + 1);

  // Create animated art and split into lines
  let animatedArt = createAnimatedArt(frame).replace(/\n+$/, '');
  const artColoredLines = animatedArt.split('\n');
  
  // Move to home and clear
  process.stdout.write('\x1b[H');
  process.stdout.write('\x1b[J');
  
  // Top padding
  if (topPad > 0) process.stdout.write('\n'.repeat(topPad));
  
  // Left padding spaces
  const leftSpaces = ' '.repeat(leftPad);
  
  // Draw art
  for (const ln of artColoredLines) {
    process.stdout.write(leftSpaces + ln + '\n');
  }
  
  // Spacer and logo line centered (may be shorter than art width)
  const logoLeft = Math.max(0, leftPad + Math.floor((contentWidth - logoWidth) / 2));
  process.stdout.write('\n');
  process.stdout.write(' '.repeat(logoLeft) + colors.bold + logoStr + colors.reset + '\n');
  
  frame++;
}

// Handle cleanup on exit
process.on('SIGINT', () => {
  // Clear screen and exit
  if (timer) clearInterval(timer);
  process.stdout.write('\x1b[2J\x1b[H\x1b[?25h');
  process.exit(0);
});

// Start/Stop controls and standalone execution
function start(intervalMs = 100) {
  if (timer) return;
  // Clear and hide cursor
  process.stdout.write('\x1b[2J\x1b[H\x1b[?25l');
  timer = setInterval(animate, intervalMs);
}

function stop() {
  if (timer) {
    clearInterval(timer);
    timer = null;
  }
  process.stdout.write('\x1b[2J\x1b[H\x1b[?25h');
}

if (require.main === module) {
  start(100);
}

module.exports = { start, stop };
