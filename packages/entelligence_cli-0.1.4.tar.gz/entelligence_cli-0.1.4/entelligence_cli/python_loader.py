"""Pure Python animated ASCII art loader using rich library."""
import time
import math
import random
from pathlib import Path
from rich.console import Console
from rich.live import Live
from rich.text import Text
from rich.align import Align


class AnimatedLoader:
    """Animated ASCII art loader with color animations."""

    # Character transition groups for animation
    CHAR_GROUPS = {
        '-': ['-', '=', '~'],
        '=': ['-', '=', '+'],
        '+': ['=', '+', '*'],
        '*': ['+', '*', '#'],
        '#': ['*', '#', '%'],
        '%': ['#', '%', '@'],
        '@': ['%', '@'],
        ':': [':', ';', '.'],
        '.': [':', '.', ',']
    }

    # Green color shades for animation - matching JS ANSI codes
    COLORS = {
        'darkGreen': 'dim green',           # dark green (dim)
        'green': 'green',                    # regular green
        'brightGreen': 'bright_green',       # bright green
        'boldBrightGreen': 'bold bright_green'  # bold bright green (most prominent)
    }

    def __init__(self, title: str = "EntelligenceAI", subtitle: str = ""):
        # Support cycling through multiple titles (list) or single title (string)
        if isinstance(title, list):
            self.titles = title
        else:
            self.titles = [title]
        self.subtitle = subtitle
        self.console = Console()
        self.frame = 0

        # Load ASCII art
        ascii_art_path = Path(__file__).parent / "ascii-art.txt"
        with open(ascii_art_path, 'r', encoding='utf-8') as f:
            art_content = f.read()

        # Remove trailing newlines and split
        self.art_lines = art_content.rstrip('\n').split('\n')
        self.art_height = len(self.art_lines)
        self.art_width = max(len(line) for line in self.art_lines)

    def _get_color_for_char(self, char: str, char_idx: int, line_idx: int) -> str:
        """Get animated color for a character based on position and frame - matches JS version exactly."""
        # Calculate relative position (0.0 to 1.0)
        line_position = line_idx / self.art_height

        # Core area (middle 30-60%) is most prominent
        is_core_area = 0.30 <= line_position <= 0.60

        # Create color wave patterns - same as JS
        color_wave = math.sin((char_idx * 0.1) + (line_idx * 0.15) + (self.frame * 0.2)) * 0.5 + 0.5
        color_wave2 = math.sin((char_idx * 0.15) + (line_idx * 0.2) + (self.frame * 0.25)) * 0.5 + 0.5

        if char in ['#', '%', '@']:
            # Major green - brightest shades
            if is_core_area:
                # Core area - always use bold bright green for maximum prominence
                return self.COLORS['boldBrightGreen']
            return self.COLORS['brightGreen'] if color_wave > 0.5 else self.COLORS['green']
        elif char in ['*', '+']:
            # Medium green shades
            if is_core_area:
                # Core area - use bright green
                return self.COLORS['brightGreen']
            return self.COLORS['green'] if color_wave2 > 0.5 else self.COLORS['darkGreen']
        elif char in ['=', '-']:
            # Green shades for flow characters
            return self.COLORS['green'] if color_wave > 0.5 else self.COLORS['darkGreen']
        elif char in [':', ';', '.', ',']:
            # Darker green for sparse characters
            return self.COLORS['darkGreen']

        return ""

    def _animate_char(self, char: str, char_idx: int, line_idx: int) -> str:
        """Animate a character by transitioning to similar characters."""
        if char == ' ' or char not in self.CHAR_GROUPS:
            return char

        line_position = line_idx / self.art_height
        is_core_area = 0.30 <= line_position <= 0.60

        # Create wave patterns for animation
        wave1 = math.sin((char_idx * 0.12) + (self.frame * 0.25)) * 0.5 + 0.5
        wave2 = math.sin((line_idx * 0.18) + (self.frame * 0.15)) * 0.5 + 0.5
        wave3 = math.sin((char_idx + line_idx) * 0.08 + (self.frame * 0.3)) * 0.5 + 0.5
        combined_wave = (wave1 + wave2 + wave3) / 3

        group = self.CHAR_GROUPS[char]
        random_factor = random.random()
        frame_based = (self.frame + char_idx + line_idx * 10) % 7

        # Less animation in core area
        if is_core_area:
            should_animate = combined_wave > 0.6 or (random_factor > 0.7 and frame_based < 1)
        else:
            should_animate = combined_wave > 0.45 or random_factor > 0.5 or frame_based < 2

        if should_animate:
            selector = (int(combined_wave * 100) + frame_based + int(random_factor * 10)) % len(group)
            return group[selector]

        return char

    def _create_frame(self) -> Text:
        """Create a single animated frame."""
        result = Text()

        for line_idx, line in enumerate(self.art_lines):
            for char_idx, char in enumerate(line):
                if char == ' ':
                    result.append(' ')
                else:
                    animated_char = self._animate_char(char, char_idx, line_idx)
                    color = self._get_color_for_char(animated_char, char_idx, line_idx)
                    result.append(animated_char, style=color)
            result.append('\n')

        # Add animated title/subtitle - matching JS renderLogo exactly
        dots_count = self.frame % 4
        dots = '.' * dots_count
        dots_padded = dots + ' ' * (3 - dots_count)

        # Cycle through titles every 60 frames (~6 seconds)
        current_title = self.titles[(self.frame // 60) % len(self.titles)]

        # Animated title with pulsing colors - same logic as JS
        # Note: Each character already has bold in boldBrightGreen, so the outer bold wrapper
        # from JS (colors.bold + logoStr) is effectively replicated per-character
        title_text = Text()
        for i, ch in enumerate(current_title):
            wave = math.sin((self.frame * 0.25) + (i * 0.4)) * 0.5 + 0.5
            if wave > 0.75:
                color = self.COLORS['boldBrightGreen']
            elif wave > 0.5:
                color = self.COLORS['brightGreen']
            elif wave > 0.25:
                color = self.COLORS['green']
            else:
                color = self.COLORS['darkGreen']
            title_text.append(ch, style=f"bold {color}")

        title_text.append(dots_padded, style="dim")

        # Calculate center padding for title relative to ASCII art width
        title_width = len(current_title) + len(dots_padded)
        art_width = self.art_width
        title_padding = max(0, (art_width - title_width) // 2)

        # Add title with calculated padding to center it
        result.append('\n')
        if title_padding > 0:
            result.append(' ' * title_padding)
        result.append(title_text)

        return Align.center(result)

    def run(self, duration: float = None):
        """Run the animated loader."""
        try:
            with Live(
                self._create_frame(),
                console=self.console,
                refresh_per_second=10,
                transient=True
            ) as live:
                start_time = time.time()
                while duration is None or (time.time() - start_time) < duration:
                    time.sleep(0.1)
                    self.frame += 1
                    live.update(self._create_frame())
        except KeyboardInterrupt:
            pass


def main():
    """Standalone execution for testing."""
    loader = AnimatedLoader(title="EntelligenceAI", subtitle="Analyzing your code...")
    loader.run()


if __name__ == '__main__':
    main()
