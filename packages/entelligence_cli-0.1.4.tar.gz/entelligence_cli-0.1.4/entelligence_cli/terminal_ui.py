from rich.console import Console, Group
from rich.syntax import Syntax
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.markdown import Markdown
from rich.layout import Layout
from rich.align import Align
from rich.text import Text
from rich.live import Live
import threading
import time
import itertools
from contextlib import contextmanager
import os
from typing import List, Dict, Any, Tuple
import sys
import os
import subprocess
import platform
import termios
import tty
from pathlib import Path

console = Console()

class TerminalUI:
    def __init__(self, output_mode='rich'):
        """
        Initialize Terminal UI.
        
        Args:
            output_mode: 'rich' for full UI, 'plain' for simple text, 'prompt-only' for minimal
        """
        self.console = console
        self.output_mode = output_mode
        # Accent color for subtle highlights
        self.accent = "#00e5ff"
        self._stop_loader_event: threading.Event | None = None
    
    @contextmanager
    def loader_screen(self, title: str = "Summoning the ghosts of bugs past...", phrases: List[str] | None = None, interval: float = 0.9):
        """
        Display a full-screen animated loader with cycling phrases until the context exits.
        Usage:
            with ui.loader_screen("Getting AI review..."):
                result = api_call()
        """
        if phrases is None:
            phrases = [
                "Summoning the ghosts of bugs past...",
                "Feeding diffs to the entropy dragons...",
                "Persuading linters to be nice...",
                "Untangling merge-knot paradoxes...",
                "Counting semicolons very carefully...",
                "Convincing tests to pass in public...",
            ]
        stop_event = threading.Event()
        self._stop_loader_event = stop_event
        def _animate():
            phrase_cycle = itertools.cycle(phrases)
            with Live(console=self.console, refresh_per_second=8, screen=True) as live:
                while not stop_event.is_set():
                    phrase = next(phrase_cycle)
                    panel = Panel.fit(
                        Align.center(f"[{self.accent}]{title}[/]\n\n{phrase}"),
                        border_style="white",
                    )
                    live.update(Align.center(panel))
                    # Small sleep; still responsive to stop
                    for _ in range(int(max(1, interval * 10))):
                        if stop_event.is_set():
                            break
                        time.sleep(0.1)
        t = threading.Thread(target=_animate, daemon=True)
        t.start()
        try:
            yield
        finally:
            stop_event.set()
            t.join(timeout=2.0)

    @contextmanager
    def ascii_art_loader(self, title: str = "EntelligenceAI", subtitle: str = "Analyzing your changes..."):
        """
        Full-screen animated ASCII logo loader using pure Python.
        """
        import threading
        from .python_loader import AnimatedLoader

        # Create and run loader in a separate thread
        loader = AnimatedLoader(title=title, subtitle=subtitle)
        stop_event = threading.Event()

        def run_loader():
            try:
                while not stop_event.is_set():
                    loader.frame += 1
                    # The loader will handle its own animation loop
                    if stop_event.wait(0.1):
                        break
            except Exception:
                pass

        thread = threading.Thread(target=run_loader, daemon=True)

        try:
            from rich.live import Live
            with Live(
                loader._create_frame(),
                console=loader.console,
                refresh_per_second=10,
                transient=True
            ) as live:
                thread.start()

                # Update the live display in the main thread
                def update_display():
                    while not stop_event.is_set():
                        live.update(loader._create_frame())
                        if stop_event.wait(0.1):
                            break

                update_thread = threading.Thread(target=update_display, daemon=True)
                update_thread.start()

                yield

                stop_event.set()
                update_thread.join(timeout=1.0)
        finally:
            stop_event.set()
            thread.join(timeout=1.0)

    @contextmanager
    def file_tree_loader(
        self,
        title: str,
        files_with_stats: List[Dict[str, int]],
        header: str | None = None,
        tick: float = 0.1,
        min_per_file_sec: float = 1.0,
        target_seconds: float = 180.0,  # soft target 3 minutes; typical 2-4 min
    ):
        """
        Animated loader that shows a file tree with + / - counts and highlights
        one file at a time while work is in progress.
        """
        stop_event = threading.Event()
        def _progress_bar(elapsed: float) -> str:
            if target_seconds <= 0:
                return ""
            frac = max(0.0, min(1.0, elapsed / target_seconds))
            width = 30
            filled = int(frac * width)
            bar = f"[{self.accent}]" + "█" * filled + "[/]" + "░" * (width - filled)
            pct = f"{int(frac*100):3d}%"
            return f"{bar}  {pct}"
        def build_tree_lines(active_index: int, elapsed: float) -> Text:
            lines: List[str] = []
            if header:
                lines.append(f"[{self.accent}]{header}[/]\n")
            lines.append(f"[white]{title}[/]")
            pb = _progress_bar(elapsed)
            if pb:
                lines.append(pb + "\n")
            # Build simple tree by indenting path parts
            for idx, entry in enumerate(files_with_stats):
                path = entry.get("path", "")
                additions = entry.get("additions", 0)
                deletions = entry.get("deletions", 0)
                parts = path.split(os.sep)
                indent = "  " * max(0, len(parts) - 1)
                name = parts[-1]
                prefix = "▹"
                if idx < active_index:
                    prefix = "[green]✔[/]"
                elif idx == active_index:
                    prefix = f"[{self.accent}]▶[/]"
                line = f"{indent}{prefix} {path}"
                counts = f"  [green]+{additions}[/] [red]-{deletions}[/]"
                lines.append(f"{line}{counts}")
            text = Text.from_markup("\n".join(lines))
            text.no_wrap = False
            text.overflow = "fold"
            return text
        def _animate():
            with Live(console=self.console, refresh_per_second=12, screen=True) as live:
                start = time.time()
                total = max(1, len(files_with_stats))
                last_change = time.time()
                while not stop_event.is_set():
                    elapsed = time.time() - start
                    # Compute active index based on elapsed time and per-file target
                    per_file = max(min_per_file_sec, (target_seconds / total) if target_seconds > 0 else min_per_file_sec)
                    active_idx = min(int(elapsed // per_file), total - 1)
                    # Keep animating but do not cycle back after reaching the end
                    live.update(Panel(build_tree_lines(active_idx, elapsed), border_style="white", title="Preparing review"))
                    time.sleep(tick)
                    last_change = time.time()
        t = threading.Thread(target=_animate, daemon=True)
        t.start()
        try:
            yield
        finally:
            stop_event.set()
            t.join(timeout=2.0)
    
    def _compute_pane_widths(self) -> Tuple[int, int, int]:
        """
        Heuristic widths for left/center/right panes based on terminal width.
        Layout ratios are approximately 1 : 2 : 2.
        """
        total = self.console.size.width
        # Leave a small allowance for borders/padding
        body_width = max(40, total - 6)
        left = max(20, body_width * 1 // 5)
        center = max(30, body_width * 2 // 5)
        right = max(30, body_width - left - center)
        return left, center, right
    
    def show_banner(self):
        """Display a welcome banner."""
        banner = """
╔═══════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                               ║
║    ███████╗███╗   ██╗████████╗███████╗██╗     ██╗     ██╗ ██████╗ ███████╗███╗   ██╗ ██████╗███████╗          ║
║    ██╔════╝████╗  ██║╚══██╔══╝██╔════╝██║     ██║     ██║██╔════╝ ██╔════╝████╗  ██║██╔════╝██╔════╝          ║
║    █████╗  ██╔██╗ ██║   ██║   █████╗  ██║     ██║     ██║██║  ███╗█████╗  ██╔██╗ ██║██║     █████╗            ║
║    ██╔══╝  ██║╚██╗██║   ██║   ██╔══╝  ██║     ██║     ██║██║   ██║██╔══╝  ██║╚██╗██║██║     ██╔══╝            ║
║    ███████╗██║ ╚████║   ██║   ███████╗███████╗███████╗██║╚██████╔╝███████╗██║ ╚████║╚██████╗███████╗          ║
║    ╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚══════╝╚══════╝╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝ ╚═════╝╚══════╝          ║
║                                                                                                               ║
║                               AI-Powered Code Review & Intelligence                                           ║
║                                                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════╝
        """
        self.console.print(Align.center(Text(banner, style="bold green")))
    
    def show_file_changes(self, files: List[str]):
        """Display list of changed files."""
        table = Table(title="Changed Files", show_header=True, header_style="bold magenta")
        table.add_column("File Path", style="cyan")
        
        for file_path in files:
            table.add_row(file_path)
        
        self.console.print(table)
    
    def show_file_changes_with_stats(self, files_with_stats: List[Dict]):
        """Display list of changed files with additions/deletions per file."""
        table = Table(title="Changed Files", show_header=True, header_style="bold magenta")
        table.add_column("File Path", style="cyan")
        table.add_column("+", style="green", justify="right")
        table.add_column("-", style="red", justify="right")
        
        for entry in files_with_stats:
            path = entry.get("path", "")
            additions = entry.get("additions", 0)
            deletions = entry.get("deletions", 0)
            table.add_row(path, str(additions), str(deletions))
        
        self.console.print(table)
    
    def show_diff(self, file_path: str, diff: str):
        """Display diff with syntax highlighting."""
        self.console.print(f"\n[bold yellow]Diff for {file_path}:[/bold yellow]")
        
        syntax = Syntax(diff, "diff", theme="monokai", line_numbers=False)
        self.console.print(Panel(syntax, border_style="blue"))
    
    def show_code_snippet(self, file_path: str, code: str, language: str = "python"):
        """Display code snippet with syntax highlighting."""
        self.console.print(f"\n[bold green]Code in {file_path}:[/bold green]")
        
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
        self.console.print(Panel(syntax, border_style="green"))
    
    def show_review_comments(self, comments: List[Dict]):
        """Display code review comments."""
        for comment in comments:
            severity = comment.get("severity", "info")
            color_map = {
                "error": "red",
                "warning": "yellow",
                "info": "blue",
                "suggestion": "green"
            }
            color = color_map.get(severity, "white")
            
            self.console.print(f"\n[bold {color}]{severity.upper()}[/bold {color}]")
            
            if "file" in comment:
                self.console.print(f"File: [cyan]{comment['file']}[/cyan]")
            
            if "line" in comment:
                self.console.print(f"Line: {comment['line']}")
            
            # Display the comment message
            message = comment.get("message", "")
            if message:
                md = Markdown(message)
                self.console.print(Panel(md, border_style=color))
            
            # Display code context if available
            if "code_snippet" in comment:
                syntax = Syntax(
                    comment["code_snippet"],
                    comment.get("language", "python"),
                    theme="monokai",
                    line_numbers=True,
                    start_line=comment.get("start_line", 1)
                )
                self.console.print(syntax)
    
    def show_progress(self, message: str):
        """Show a progress spinner."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True
        )
    
    def show_summary(self, summary: Dict):
        """Display a summary of the review."""
        table = Table(title="Review Summary", show_header=True, header_style="bold magenta")
        table.add_column("Metric", style="cyan")
        table.add_column("Count", style="yellow")
        
        table.add_row("Files Changed", str(summary.get("files_changed", 0)))
        table.add_row("Errors", str(summary.get("errors", 0)))
        table.add_row("Warnings", str(summary.get("warnings", 0)))
        table.add_row("Suggestions", str(summary.get("suggestions", 0)))
        
        self.console.print(table)
    
    def error(self, message: str):
        """Display an error message."""
        self.console.print(f"[bold red]Error:[/bold red] {message}")
    
    def success(self, message: str):
        """Display a success message."""
        self.console.print(f"[bold green]✓[/bold green] {message}")
    
    def info(self, message: str):
        """Display an info message."""
        self.console.print(f"[blue]ℹ[/blue] {message}")

    # ---------- New scaffolded pages and helpers ----------
    def render_intro(self, context: Dict[str, Any]):
        """
        Intro/Triage page modeled after the 'splash' screen.
        Expects:
          repo_path, branch, base_branch, compare_mode
          num_files, insertions, deletions
        """
        self.show_banner()
        repo_line = f"repo: [cyan]{context.get('repo_path','?')}[/cyan]"
        compare = f"comparing: [yellow]{context.get('branch','?')}[/yellow] → [yellow]{context.get('base_branch','?')}[/yellow] (base)"
        stats = f"\n📄 {context.get('num_files',0)} Files changed\n  {context.get('insertions',0)} insertions | {context.get('deletions',0)} deletions"
        mode = f"\nMode: [magenta]{context.get('compare_mode','committed')}[/magenta]"
        self.console.print(Align.center(repo_line))
        self.console.print(Align.center(compare))
        self.console.print(Align.center(stats))
        self.console.print(Align.center(mode))
        self.console.print("\n" + Align.center("[bold]Hit Enter to start review[/bold]").renderable)
        self.console.print(Align.center("[dim]Hit Space to view last session[/dim]"))
    
    def run_intro(self, context: Dict[str, Any]) -> str:
        """
        Render intro and wait for user action.
        Returns: 'proceed' on Enter, 'last' on Space, 'quit' on q/Esc.
        """
        while True:
            self.console.clear()
            self.render_intro(context)
            key = self._read_key()
            if key in ("\r", "\n"):  # Enter
                return "proceed"
            if key == " ":
                return "last"
            if key in ("q", "\x1b"):  # q or Esc
                return "quit"

    def _aggregate_file_severity(self, comments: List[Dict]) -> Dict[str, Dict[str, int]]:
        """Aggregate comment counts per file by severity."""
        counts: Dict[str, Dict[str, int]] = {}
        for c in comments:
            path = c.get("file", "unknown")
            sev = c.get("severity", "info")
            file_counts = counts.setdefault(path, {"error": 0, "warning": 0, "suggestion": 0})
            if sev == "error":
                file_counts["error"] += 1
            elif sev == "warning":
                file_counts["warning"] += 1
            else:
                file_counts["suggestion"] += 1
        return counts

    def build_review_state(self, repo_info: Dict[str, Any], files_with_stats: List[Dict], comments: List[Dict], summary: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge file stats with severity counts and produce a minimal state
        structure consumable by render_review().
        """
        severity_map = self._aggregate_file_severity(comments)
        files_merged: List[Dict[str, Any]] = []
        for entry in files_with_stats:
            path = entry.get("path", "")
            counts = severity_map.get(path, {"error": 0, "warning": 0, "suggestion": 0})
            merged = {
                "path": path,
                "additions": entry.get("additions", 0),
                "deletions": entry.get("deletions", 0),
                "counts": counts
            }
            files_merged.append(merged)
        # Sort by severity weight then by total churn
        def sort_key(e: Dict[str, Any]) -> Tuple[int, int]:
            sev_score = e["counts"]["error"] * 100 + e["counts"]["warning"] * 10 + e["counts"]["suggestion"]
            churn = e["additions"] + e["deletions"]
            return (-sev_score, -churn)
        files_merged.sort(key=sort_key)
        state = {
            "repo": repo_info,
            "summary": summary or {},
            "files": files_merged,
            "comments": comments,
            "selectedFileIdx": 0,
            "selectedCommentIdx": 0,
            "pane": "files",
            "expandedFiles": set(),          # paths expanded in left pane
            "selectedRowIdx": 0,             # index into visible rows (files + comments)
            "appliedIds": set()              # ids of comments successfully applied
        }
        return state

    def compose_review_layout(self, state: Dict[str, Any]) -> Layout:
        """
        Build the three-pane review layout renderable without printing it.
        Used by both static rendering and interactive Live updates.
        """
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(name="body", ratio=1),
            Layout(name="footer", size=3)
        )
        layout["body"].split_row(
            Layout(name="files", ratio=1),
            Layout(name="center", ratio=2),
            Layout(name="details", ratio=2),
        )
        # Header
        repo = state.get("repo", {})
        summary = state.get("summary", {})
        hdr = (
            f"[{self.accent}]Repo[/]: {repo.get('name', repo.get('path','?'))}   "
            f"[{self.accent}]Branch[/]: {repo.get('branch','?')} → {repo.get('base','?')}   "
            f"[{self.accent}]Errors[/]: {summary.get('errors',0)}   "
            f"[{self.accent}]Warnings[/]: {summary.get('warnings',0)}   "
            f"[{self.accent}]Suggestions[/]: {summary.get('suggestions',0)}"
        )
        layout["header"].update(Panel(hdr, border_style="white"))
        # Compute pane widths for better wrapping
        left_w, center_w, right_w = self._compute_pane_widths()
        # Build "visible rows" for left pane: files plus expanded comments
        files = state.get("files", [])
        expanded: set = state.get("expandedFiles", set())
        all_comments: List[Dict[str, Any]] = state.get("comments", [])
        path_to_comments: Dict[str, List[Dict[str, Any]]] = {}
        for c in all_comments:
            path_to_comments.setdefault(c.get("file", ""), []).append(c)
        visible_rows: List[Dict[str, Any]] = []
        for file_index, f in enumerate(files):
            visible_rows.append({"type": "file", "path": f.get("path", ""), "file_index": file_index})
            if f.get("path", "") in expanded:
                for idx, c in enumerate(path_to_comments.get(f.get("path", ""), [])):
                    visible_rows.append({
                        "type": "comment",
                        "path": f.get("path", ""),
                        "file_index": file_index,
                        "comment_index": idx
                    })
        # Persist visible rows for the input loop to use
        state["visible_rows"] = visible_rows
        selected_row = min(state.get("selectedRowIdx", 0), max(0, len(visible_rows) - 1))
        state["selectedRowIdx"] = selected_row

        # Files list (simple list, no grid) with per-file dropdown comments
        list_lines = []
        for row_idx, row in enumerate(visible_rows):
            is_selected = row_idx == selected_row
            if row["type"] == "file":
                f = files[row["file_index"]]
                is_expanded = f.get("path", "") in expanded
                caret = "▾" if is_expanded else "▸"
                label = f"[{self.accent}]{caret}[/] {f.get('path','')}"
                if is_selected:
                    label = f"[{self.accent} bold]{label}[/]"
                list_lines.append(label)
            else:
                # Comment row: indent and show a short preview
                file_path = row["path"]
                c = path_to_comments.get(file_path, [])[row["comment_index"]]
                sev = c.get("severity", "info").upper()
                preview = c.get("message", "").split("\n", 1)[0]
                cid = c.get("id", id(c))
                is_applied = cid in state.get("appliedIds", set())
                dot = "[green]●[/]" if is_applied else "•"
                label = f"    {dot} [{self.accent}]↳[/] [{sev}] {preview[:80]}"
                if is_selected:
                    label = f"[{self.accent} bold]{label}[/]"
                list_lines.append(label)
        files_list_text = Text.from_markup("\n".join(list_lines) if list_lines else "No files")
        files_list_text.no_wrap = False
        files_list_text.overflow = "fold"
        layout["files"].update(Panel(files_list_text, title="Files", border_style="white", width=left_w))
        # Center pane: show code snippet for selected comment, else placeholder
        selected_comment = None
        if visible_rows:
            row = visible_rows[selected_row]
            if row["type"] == "comment":
                selected_comment = path_to_comments.get(row["path"], [])[row["comment_index"]]
        if selected_comment and selected_comment.get("code_snippet"):
            code = selected_comment["code_snippet"]
            lang = selected_comment.get("language", "python")
            syntax = Syntax(code, lang, theme="monokai", line_numbers=True, word_wrap=True, code_width=center_w - 4)
            layout["center"].update(Panel(syntax, title=f"{row['path']}", border_style="white", width=center_w))
        else:
            # Hide center pane until a comment is selected
            layout["center"].update(Panel(Text(""), border_style="white", width=center_w))
        # Details pane: selected comment details with patch preview
        if selected_comment:
            c0 = selected_comment
            sev = c0.get("severity", "info").upper()
            msg = c0.get("message", "")
            meta = f"File: {c0.get('file','?')}  Line: {c0.get('line','?')}"
            header = f"[bold]{sev}[/bold]\n{meta}\n"
            body_renderables = []
            # Description
            if msg:
                body_renderables.append(Text.from_markup(f"[{self.accent}]Description[/]"))
                body_renderables.append(Markdown(msg))
            # Show extra metadata if provided (suggestion type, impact, score, etc.)
            extra = c0.get("extra") or {}
            extra_lines: List[str] = []
            if extra.get("suggestion_type"):
                extra_lines.append(f"Suggestion: {extra.get('suggestion_type')}")
            if extra.get("impact"):
                extra_lines.append(f"Impact: {extra.get('impact')}")
            if extra.get("score"):
                extra_lines.append(f"Score: {extra.get('score')}")
            if extra.get("line_numbers"):
                extra_lines.append(f"Lines: {extra.get('line_numbers')}")
            if extra_lines:
                body_renderables.append(Text.from_markup(f"[{self.accent}]Details[/]"))
                body_renderables.append(Text("\n".join(extra_lines)))
            # Committable suggestion (code)
            apply_snippet = c0.get("apply_snippet")
            if apply_snippet:
                lang_guess = c0.get("language", "text")
                syntax_apply = Syntax(apply_snippet, lang_guess, theme="monokai", line_numbers=False, word_wrap=True, code_width=right_w - 4)
                body_renderables.append(Text.from_markup(f"[{self.accent}]Committable Suggestion[/]"))
                body_renderables.append(syntax_apply)
            # Proposed fix diff (if available)
            if c0.get("suggested_patch"):
                patch = c0["suggested_patch"]
                diff_syntax = Syntax(patch, "diff", theme="monokai", line_numbers=False, word_wrap=True, code_width=right_w - 4)
                body_renderables.append(Text.from_markup(f"[{self.accent}]Proposed fix (diff)[/]"))
                body_renderables.append(diff_syntax)
            # Reasoning
            if extra.get("reasoning"):
                body_renderables.append(Text.from_markup(f"[{self.accent}]Reasoning[/]"))
                body_renderables.append(Markdown(str(extra.get("reasoning"))))
            # Prompt for AI agents (render as JSON code if available)
            agent_prompt = extra.get("agent_prompt")
            if agent_prompt:
                try:
                    # Pretty JSON if it's JSON
                    prompt_text = agent_prompt
                    syntax_prompt = Syntax(prompt_text, "json", theme="monokai", line_numbers=False, word_wrap=True, code_width=right_w - 4)
                    body_renderables.append(Text.from_markup(f"[{self.accent}]Prompt to Fix with AI[/]"))
                    body_renderables.append(syntax_prompt)
                except Exception:
                    body_renderables.append(Text.from_markup(f"[{self.accent}]Prompt to Fix with AI[/]"))
                    body_renderables.append(Text(str(agent_prompt)))
                # Add bug description and reasoning under the proposed fix
                context_parts: List[str] = []
                if msg:
                    context_parts.append("**Bug Description**\n\n" + str(msg))
                if extra.get("reasoning"):
                    context_parts.append("**Reasoning**\n\n" + str(extra.get("reasoning")))
                if context_parts:
                    context_md = "\n\n".join(context_parts)
                    body_renderables.append(Text.from_markup(f"[{self.accent}]Proposed Fix Context[/]"))
                    body_renderables.append(Markdown(context_md))
            # Build stacked group: header + collected panels
            stacked: List[Any] = []
            # Header
            stacked.append(Text.from_markup(f"[{self.accent}]Proposed Fix[/]"))
            stacked.append(Text.from_markup(header))
            # Panels in desired order: Description, Committable Suggestion, Proposed fix (diff), Reasoning, Prompt, Details, Context
            for r in body_renderables:
                stacked.append(r)
            # Compose and render once so it doesn't overwrite
            layout["details"].update(Panel(Group(*stacked), border_style="white", width=right_w))
        else:
            # Hide details until a comment is selected
            layout["details"].update(Panel(Text(""), border_style="white", width=right_w))
        # Footer hints
        status = state.get("status_message", "")
        footer = "↑/↓ move • Enter expand/select • h/l collapse/expand • a apply • r reject • c copy • q quit"
        if status:
            footer += f"\n{status}"
        layout["footer"].update(Panel(footer, border_style="white"))
        return layout

    def render_review(self, state: Dict[str, Any]):
        """
        Static three-pane review layout scaffold. This consumes the state produced by
        build_review_state(...) and renders a non-interactive layout.
        """
        self.console.print(self.compose_review_layout(state))

    # --------- Interactive controls and actions ----------
    def _read_key(self) -> str:
        """Read a single key (supports arrow keys) without echoing."""
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch1 = sys.stdin.read(1)
            if ch1 == "\x1b":  # escape sequence
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    return f"\x1b[{ch3}"
                return "\x1b"
            return ch1
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def _copy_to_clipboard(self, text: str) -> bool:
        try:
            if platform.system().lower() == "darwin":
                p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                p.communicate(input=text.encode("utf-8"))
                return p.returncode == 0
            elif platform.system().lower() == "linux":
                p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
                p.communicate(input=text.encode("utf-8"))
                return p.returncode == 0
            else:
                return False
        except Exception:
            return False

    def _git_apply_with_fallbacks(self, patch: str, repo_path: str) -> Tuple[bool, str]:
        """Try to apply a unified diff using git apply with multiple fallbacks."""

        # First try: Try different strip levels (a/, b/ prefix handling)
        for apply_flags in [[], ["-p0"], ["-p1"]]:
            try:
                apply_cmd = ["git", "apply", "--index"] + apply_flags
                subprocess.run(apply_cmd, input=patch.encode("utf-8"), cwd=repo_path, capture_output=True, check=True)
                return True, "Applied suggestion via git and staged changes."
            except subprocess.CalledProcessError:
                continue

        # Fallback 2: Try with --3way for conflicts
        try:
            result = subprocess.run(
                ["git", "apply", "--3way", "--index"],
                input=patch.encode("utf-8"),
                cwd=repo_path,
                capture_output=True,
                check=True
            )
            # 3-way merge might not auto-stage, explicitly stage
            subprocess.run(["git", "add", "-A"], cwd=repo_path, capture_output=True)
            return True, "Applied with 3-way merge and staged changes."
        except subprocess.CalledProcessError as e:
            err = e.stderr.decode("utf-8", errors="ignore") if e.stderr else "Unknown error"
            pass

        # Final attempt: --reject (creates .rej files)
        try:
            subprocess.run(["git", "apply", "--reject"], input=patch.encode("utf-8"), cwd=repo_path, capture_output=True, check=True)
            return False, "Patch partially applied with rejects; please resolve .rej hunks."
        except subprocess.CalledProcessError as e:
            err = e.stderr.decode("utf-8", errors="ignore") if e.stderr else "Unknown error"
            return False, f"Failed to apply patch: {err.strip()}"
    
    def _apply_snippet_by_lines(self, file_path: str, start_line: int, end_line: int, new_code: str, repo_path: str) -> Tuple[bool, str]:
        """
        Replace lines [start_line, end_line] (1-based inclusive) in file_path with new_code.
        Stage the change with `git add`. Returns (ok, message).
        """
        try:
            abs_path = os.path.join(repo_path, file_path)
            with open(abs_path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
            
            # Validate line numbers
            s = max(1, int(start_line))
            total_lines = len(lines)
            if end_line is None:
                e = s
            else:
                e = max(s, int(end_line))
            
            # Clamp to valid range
            if s > total_lines:
                return False, f"Start line {s} exceeds file length ({total_lines} lines)"
            e = min(e, total_lines)
            
            # Convert to 0-based for slicing
            s0 = s - 1  # inclusive start
            e0 = e      # exclusive end (so we replace lines s through e inclusive)
            
            new_lines = [ln for ln in new_code.splitlines() if ln.strip() or ln == ""]
            
            # Replace lines [s, e] with new_lines
            updated = lines[:s0] + new_lines + lines[e0:]
            
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write("\n".join(updated) + ("\n" if (updated and updated) else ""))
            
            subprocess.run(["git", "add", "--", file_path], cwd=repo_path, capture_output=True, check=True)
            return True, f"Applied to {file_path}:{s}-{e} and staged."
        except Exception as ex:
            return False, f"Failed: {ex}"
    
    def _apply_snippet_by_context(self, file_path: str, context_line: str, end_marker: str, new_code: str, repo_path: str) -> Tuple[bool, str]:
        """
        Apply a code change by finding a context line in the file and replacing until an end marker.
        This handles cases where the file structure has changed and line numbers don't match.

        Args:
            file_path: Path to the file
            context_line: A line that should be present in the file (used to find the location)
            end_marker: A unique line that identifies where to stop replacing
            new_code: The new code to insert
            repo_path: Repository path

        Returns:
            (success, message)
        """
        try:
            abs_path = os.path.join(repo_path, file_path)
            with open(abs_path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()

            # Find the context line - use apply_start line number from backend if available
            context_idx = None
            if end_marker and end_marker.replace(" ", "").isdigit():
                # end_marker is being used as line number
                line_num = int(end_marker)
                if 1 <= line_num <= len(lines):
                    context_idx = line_num - 1
            else:
                # Search for context line
                for i, line in enumerate(lines):
                    if line == context_line:
                        context_idx = i
                        break

                if context_idx is None:
                    # Try loose match as fallback
                    for i, line in enumerate(lines):
                        if line.strip() == context_line.strip():
                            context_idx = i
                            break

            if context_idx is None:
                return False, f"Could not find context line in file"

            # Find the real end of the block using brace counting
            # We're looking for the matching } that closes the block starting at context_idx
            block_end = context_idx
            brace_count = 0
            for i in range(context_idx, len(lines)):
                line = lines[i]
                # Count braces
                brace_count += line.count('{') - line.count('}')
                block_end = i
                # When brace_count reaches 0, we've found the closing }
                if brace_count == 0:
                    break

            # If we didn't find closing brace, use end_marker or default
            if brace_count != 0:
                # Fallback to end_marker search
                if end_marker:
                    for i in range(context_idx + 1, min(context_idx + 20, len(lines))):
                        if lines[i] == end_marker or lines[i].strip() == end_marker.strip():
                            block_end = i
                            break
                # Last resort: use next 15 lines
                if brace_count != 0:
                    block_end = min(context_idx + 15, len(lines) - 1)

            # Use new_code AS-IS from backend (preserves indentation)
            correct_lines = new_code.splitlines()

            # Replace the ENTIRE block from context_idx to block_end (inclusive)
            updated = lines[:context_idx] + correct_lines + lines[block_end + 1:]

            with open(abs_path, "w", encoding="utf-8") as f:
                f.write("\n".join(updated) + ("\n" if updated else ""))

            subprocess.run(["git", "add", "--", file_path], cwd=repo_path, capture_output=True, check=True)
            return True, f"Applied fix to {file_path} and staged."
        except Exception as ex:
            return False, f"Failed: {ex}"

    def _fix_corrupted_404_file(self, file_path: str, correct_code: str, repo_path: str) -> Tuple[bool, str]:
        """
        Fix the 404 file corruption pattern.
        
        Handles two corruption patterns:
        1. Merged line: "}, [router]);Name=..." (old pattern)
        2. Duplicate consecutive lines (new pattern from bad diffs)
        """
        try:
            abs_path = os.path.join(repo_path, file_path)
            with open(abs_path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
            
            correct_lines = [ln for ln in correct_code.splitlines() if ln.strip() or ln == ""]
            
            # Pattern 1: Check for merged corruption "}, [router]);Name="
            corruption_start = None
            for i, line in enumerate(lines):
                stripped = line.strip()
                if "}, [router]);" in stripped and "Name=" in stripped:
                    corruption_start = i
                    break
            
            # Pattern 2: Check for duplicate consecutive lines (new pattern)
            # This happens when backend generates diff with duplicate context lines
            if corruption_start is None:
                for i in range(len(lines) - 1):
                    line1 = lines[i].strip()
                    line2 = lines[i + 1].strip()
                    # Skip empty lines
                    if line1 and line2 and line1 == line2:
                        # Found duplicate! Remove the second occurrence
                        corruption_start = i
                        corruption_end = i + 1
                        # Build fixed file: keep everything, just remove line at corruption_end
                        fixed = lines[:corruption_end] + lines[corruption_end + 1:]
                        with open(abs_path, "w", encoding="utf-8") as f:
                            f.write("\n".join(fixed) + ("\n" if fixed else ""))
                        subprocess.run(["git", "add", "--", file_path], cwd=repo_path, capture_output=True, check=True)
                        return True, f"Removed duplicate line in {file_path} and staged."
            
            if corruption_start is None:
                return False, "Could not find corruption pattern"
            
            # Pattern 1 continuation: Find end of merged corruption
            corruption_end = None
            for i in range(corruption_start + 1, len(lines)):
                stripped = lines[i].strip()
                if stripped == "}, [router]);" or stripped.startswith("}, [router]);"):
                    corruption_end = i
                    break
            
            if corruption_end is None:
                return False, "Could not find corruption end"
            
            # Build the fixed file
            fixed = lines[:corruption_start] + correct_lines + lines[corruption_end + 1:]
            
            with open(abs_path, "w", encoding="utf-8") as f:
                f.write("\n".join(fixed) + ("\n" if fixed else ""))
            
            subprocess.run(["git", "add", "--", file_path], cwd=repo_path, capture_output=True, check=True)
            return True, f"Fixed corruption in {file_path} and staged."
            
        except Exception as ex:
            return False, f"Failed: {ex}"

    def run_interactive_review(self, repo_info: Dict[str, Any], files_with_stats: List[Dict], comments: List[Dict], summary: Dict[str, Any], repo_path: str):
        """
        Build state and start a simple key-driven loop to handle actions.
        Supported keys: ↑/↓ (scroll details), Esc/← (close details -> focus files), c (copy prompt),
        a (apply suggestion via git apply), r (reject), j/k (cycle comments), q (quit).
        """
        state = self.build_review_state(repo_info, files_with_stats, comments, summary)
        state["details_scroll_offset"] = 0
        state["pane"] = "details"
        rejected_ids: set = set()
        # Ensure initial visible comments are present before first render
        state["comments"] = [c for c in comments if c.get("id", id(c)) not in rejected_ids]
        # Use Live without alternate screen for broader terminal compatibility
        with Live(self.compose_review_layout(state), console=self.console, refresh_per_second=10, screen=False, auto_refresh=False) as live:
            live.refresh()
            while True:
                # Keep comments view in sync each loop and refresh immediately
                visible_comments = [c for c in comments if c.get("id", id(c)) not in rejected_ids]
                state["comments"] = visible_comments
                live.update(self.compose_review_layout(state))
                live.refresh()
                key = self._read_key()
                # Move selection in left pane
                if key in ("\x1b[A", "k"):  # up
                    state["selectedRowIdx"] = max(0, state.get("selectedRowIdx", 0) - 1)
                elif key in ("\x1b[B", "j"):  # down
                    state["selectedRowIdx"] = min(len(state.get("visible_rows", [])) - 1, state.get("selectedRowIdx", 0) + 1)
            # Close details focus
                elif key in ("\x1b", "\x1b[D"):  # esc or left
                    state["pane"] = "files"
                # Expand/collapse/select on Enter or l/h
                elif key in ("\r", "\n", "l"):
                    rows = state.get("visible_rows", [])
                    if rows:
                        row = rows[state.get("selectedRowIdx", 0)]
                        if row["type"] == "file":
                            path = row["path"]
                            if path in state["expandedFiles"]:
                                state["expandedFiles"].remove(path)
                            else:
                                state["expandedFiles"].add(path)
                        else:
                            # comment selection updates indices for actions
                            state["selectedFileIdx"] = row["file_index"]
                            state["selectedCommentIdx"] = row["comment_index"]
                elif key == "h":
                    rows = state.get("visible_rows", [])
                    if rows:
                        row = rows[state.get("selectedRowIdx", 0)]
                        if row["type"] == "file":
                            state["expandedFiles"].discard(row["path"])
                        else:
                            # move focus to parent file row
                            file_row_idx = 0
                            for i, r in enumerate(rows):
                                if r["type"] == "file" and r["path"] == row["path"]:
                                    file_row_idx = i
                                    break
                            state["selectedRowIdx"] = file_row_idx
            # Copy prompt
                elif key == "c":
                    # Determine selected comment
                    rows = state.get("visible_rows", [])
                    if rows and rows[state.get("selectedRowIdx", 0)]["type"] == "comment":
                        row = rows[state.get("selectedRowIdx", 0)]
                        file_comments = [c for c in visible_comments if c.get("file") == row["path"]]
                        idx = row["comment_index"]
                        if idx < len(file_comments):
                            prompt = file_comments[idx].get("ai_prompt") or file_comments[idx].get("message", "")
                            if self._copy_to_clipboard(prompt):
                                state["status_message"] = "Copied prompt to clipboard."
                            else:
                                state["status_message"] = "Clipboard unavailable; prompt printed below.\n" + prompt
                    else:
                        state["status_message"] = "No file selected."
            # Apply suggestion
                elif key == "a":
                    rows = state.get("visible_rows", [])
                    if rows:
                        current = rows[state.get("selectedRowIdx", 0)]
                        # If on a file row, try first patchable comment under it
                        if current["type"] == "file":
                            file_path = current["path"]
                            file_comments = [c for c in visible_comments if c.get("file") == file_path]
                            target_idx = next((i for i, c in enumerate(file_comments) if c.get("suggested_patch") or (c.get("apply_snippet") and c.get("apply_start"))), None)
                            if target_idx is None or target_idx >= len(file_comments):
                                state["status_message"] = "No apply-ready comments under this file."
                            else:
                                target = file_comments[target_idx]
                                target_id = target.get("id", id(target))
                                
                                # Check if already applied
                                if target_id in state.get("appliedIds", set()):
                                    state["status_message"] = "Already applied."
                                    live.update(self.compose_review_layout(state))
                                    live.refresh()
                                    continue
                                
                                state["status_message"] = f"Processing apply for {file_path}..."
                                live.update(self.compose_review_layout(state))
                                live.refresh()
                                
                                if target.get("suggested_patch"):
                                    ok, msg = self._git_apply_with_fallbacks(target.get("suggested_patch"), repo_path)
                                    # Fall back to corruption fix if git apply fails
                                    if not ok and target.get("apply_snippet"):
                                        # Try the special 404 file corruption fix
                                        if file_path.endswith("not-found.tsx"):
                                            ok, msg = self._fix_corrupted_404_file(
                                                file_path=file_path,
                                                correct_code=target.get("apply_snippet") or "",
                                                repo_path=repo_path,
                                            )
                                        # Fall back to line-based apply
                                        if not ok:
                                            start_line = target.get("apply_start") or target.get("line") or 1
                                            end_line = target.get("apply_end") or target.get("line") or target.get("apply_start") or 1
                                            ok, msg = self._apply_snippet_by_lines(
                                                file_path=file_path,
                                                start_line=start_line,
                                                end_line=end_line,
                                                new_code=target.get("apply_snippet") or "",
                                                repo_path=repo_path,
                                            )
                                else:
                                    ok, msg = self._apply_snippet_by_lines(
                                        file_path=file_path,
                                        start_line=target.get("apply_start") or target.get("line") or 1,
                                        end_line=target.get("apply_end") or target.get("line") or target.get("apply_start") or 1,
                                        new_code=target.get("apply_snippet") or "",
                                        repo_path=repo_path,
                                    )
                                state["status_message"] = msg
                                if ok:
                                    cid = file_comments[target_idx].get("id", id(file_comments[target_idx]))
                                    applied = state.get("appliedIds", set()); applied.add(cid); state["appliedIds"] = applied
                                    # Keep focus on file row (shows green dot on its comments)
                        else:
                            # On a specific comment row
                            row = current
                            file_comments = [c for c in visible_comments if c.get("file") == row["path"]]
                            idx = row["comment_index"]
                            if idx < len(file_comments):
                                target = file_comments[idx]
                                target_id = target.get("id", id(target))
                                
                                # Check if already applied
                                if target_id in state.get("appliedIds", set()):
                                    state["status_message"] = "Already applied."
                                    live.update(self.compose_review_layout(state))
                                    live.refresh()
                                    continue
                                
                                if target.get("suggested_patch"):
                                    patch = target.get("suggested_patch")
                                    # Ensure patch has proper headers for git apply
                                    if not patch.startswith("diff --git"):
                                        # Add basic headers
                                        file_path = row["path"]
                                        patch = f"diff --git a/{file_path} b/{file_path}\n--- a/{file_path}\n+++ b/{file_path}\n{patch}"
                                    ok, msg = self._git_apply_with_fallbacks(patch, repo_path)
                                    # Fall back to corruption fix if git apply fails
                                    if not ok and target.get("apply_snippet"):
                                        # Try the special 404 file corruption fix
                                        if row["path"].endswith("not-found.tsx"):
                                            ok, msg = self._fix_corrupted_404_file(
                                                file_path=row["path"],
                                                correct_code=target.get("apply_snippet") or "",
                                                repo_path=repo_path,
                                            )
                                        # Fall back to line-based apply
                                        if not ok and target.get("apply_start") or target.get("line"):
                                            ok, msg = self._apply_snippet_by_lines(
                                                file_path=row["path"],
                                                start_line=target.get("apply_start") or target.get("line") or 1,
                                                end_line=target.get("apply_end") or target.get("line") or target.get("apply_start") or 1,
                                                new_code=target.get("apply_snippet") or "",
                                                repo_path=repo_path,
                                            )
                                else:
                                    if not (target.get("apply_snippet") and (target.get("apply_start") or target.get("line"))):
                                        state["status_message"] = "No suggested patch or committable snippet available for this comment."
                                        ok = False; msg = state["status_message"]
                                    else:
                                        ok, msg = self._apply_snippet_by_lines(
                                            file_path=row["path"],
                                            start_line=target.get("apply_start") or target.get("line") or 1,
                                            end_line=target.get("apply_end") or target.get("line") or target.get("apply_start") or 1,
                                            new_code=target.get("apply_snippet") or "",
                                            repo_path=repo_path,
                                        )
                                state["status_message"] = msg
                                if ok:
                                    # Mark as applied and move selection back to the parent file row
                                    cid = target.get("id", id(target))
                                    applied = state.get("appliedIds", set()); applied.add(cid); state["appliedIds"] = applied
                                    # Move focus to parent file row
                                    for i, r in enumerate(rows):
                                        if r["type"] == "file" and r["path"] == row["path"]:
                                            state["selectedRowIdx"] = i
                                            break
                    else:
                        state["status_message"] = "No file selected."
            # Reject
                elif key == "r":
                    rows = state.get("visible_rows", [])
                    if rows and rows[state.get("selectedRowIdx", 0)]["type"] == "comment":
                        row = rows[state.get("selectedRowIdx", 0)]
                        file_comments = [c for c in visible_comments if c.get("file") == row["path"]]
                        idx = row["comment_index"]
                        if idx < len(file_comments):
                            cid = file_comments[idx].get("id", id(file_comments[idx]))
                            rejected_ids.add(cid)
                            state["status_message"] = "Comment dismissed."
                    else:
                        state["status_message"] = "No file selected."
            # Quit
                elif key in ("q", "\x03"):  # q or Ctrl-C
                    break
                # Refresh the frame after processing the key
                live.update(self.compose_review_layout(state))
                live.refresh()

        