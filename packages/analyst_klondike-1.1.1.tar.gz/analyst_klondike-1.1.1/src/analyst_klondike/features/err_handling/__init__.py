from typing import Any

from analyst_klondike.features.message_box.mb_hook import show_message


def catch_error(func: Any):

    def wrapper(*args: Any, **kwagrs: Any):
        try:
            return func(*args, **kwagrs)
        except Exception as ex:
            show_message("Произошла ошибка: " + str(ex))
            return None

    return wrapper


__all__ = [
    "catch_error"
]
