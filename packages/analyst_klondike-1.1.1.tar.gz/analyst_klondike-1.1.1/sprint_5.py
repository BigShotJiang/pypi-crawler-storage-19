# pylint: skip-file

def is_prime(n: int) -> bool:
    """
    Простое число
    Напишите функцию, которая возращает true, если число является простым.
    Число является простым, если нацело делится только на 1 и само себя. 
    Например:
    - 7 - простое, т.к. делится нацело только на себя и 1.
    - 8, к примеру, простым не является, потому что без остатка делится еще и на 2, и 4.
    Подсказка: пройдетесь по всем числам, меньше заданного и проверьте делимость
    """
    return False


assert is_prime(1) == True
assert is_prime(2) == True
assert is_prime(3) == True
assert is_prime(4) == False
assert is_prime(5) == True
assert is_prime(6) == False
assert is_prime(8) == False
assert is_prime(11) == True
assert is_prime(13) == True
assert is_prime(14) == False


def is_list_growing(lst: list[float]) -> bool:
    """
    Возрастание списка
    Напишите функцию, которая вернет true, если список является полностью возрастающим,
    т.е. каждый следующий элемент больше предыдущего.
    Например:
    - solution([]) -> True, считаем, что пустой список возрастает
    - solution([1,4]) -> True
    - solution([1,3,5,6]) -> True
    - solution([1,3,5,2]) -> False
    """
    return False


assert is_list_growing([]) == True
assert is_list_growing([1, 4]) == True
assert is_list_growing([1, 3, 5, 6]) == True
assert is_list_growing([1, 3, 5, 2]) == False
assert is_list_growing([10, 5]) == False
assert is_list_growing([10, 5, 2]) == False
assert is_list_growing([8, 2, -1]) == False


def get_views_count(n: int) -> str:
    """
    Просмотры
    Напишите функцию, которая принимает n - число просмотров и возвращает надпись в формате 'n просмотров'.
    Таким образом, суть задачи в том, чтобы правильно вычислить падеж слова 'просмотр' в зависимости от числа n.
    Например:
    - solution(0) -> 0 просмотров
    - solution(1) -> 1 просмотр
    - solution(2) -> 2 просмотра
    - solution(23) -> 23 просмотра
    - solution(567) -> 567 просмотров
    Считаем, что в функцию всегда передается число большее нуля.
    Подсказка: поищите закономерность.
    """
    return ""


assert get_views_count(0) == '0 просмотров'
assert get_views_count(1) == '1 просмотр'
assert get_views_count(2) == '2 просмотра'
assert get_views_count(3) == '3 просмотра'
assert get_views_count(4) == '4 просмотра'
assert get_views_count(5) == '5 просмотров'
assert get_views_count(6) == '6 просмотров'
assert get_views_count(7) == '7 просмотров'
assert get_views_count(10) == '10 просмотров'
assert get_views_count(19) == '19 просмотров'
assert get_views_count(20) == '20 просмотров'
assert get_views_count(21) == '21 просмотр'
assert get_views_count(22) == '22 просмотра'
assert get_views_count(23) == '23 просмотра'
assert get_views_count(24) == '24 просмотра'
assert get_views_count(31) == '31 просмотр'
assert get_views_count(37) == '37 просмотров'
assert get_views_count(96) == '96 просмотров'
assert get_views_count(117) == '117 просмотров'
assert get_views_count(134) == '134 просмотра'
assert get_views_count(164) == '164 просмотра'
assert get_views_count(851) == '851 просмотр'
assert get_views_count(1054) == '1054 просмотра'
assert get_views_count(1069) == '1069 просмотров'
assert get_views_count(1175) == '1175 просмотров'
assert get_views_count(102543) == '102543 просмотра'


def move_zeros_new_list(lst: list[int]) -> list[int]:
    """
    Перемещение нулей
    Написать функцию, которая принимает список чисел и возвращает +новый+ список, в котором нули сдвинуты вправо.
    Обратите внимание, что нужно вернуть новый список, исходный не изменяется.

    Например:
        - solution([]) -> []
        - solution([1, 2, 3]) -> [1, 2, 3]. Нет нулей, значит вернуть точно такой же список.        
        - solution([0, 0, 0, 0, 0, 0, 0]) -> [0, 0, 0, 0, 0, 0, 0]. Одни нули, возвращаем копию исходного списка. 
        - solution([1, 0, 0, 2, 3, 0, 1]) -> [1, 2, 3, 1, 0, 0, 0]. Нули сдвинуты вправо.
    """
    return []


assert move_zeros_new_list([]) == []
assert move_zeros_new_list([1, 2, 3]) == [1, 2, 3]
assert move_zeros_new_list([0, 0, 0, 0]) == [0, 0, 0, 0]
assert move_zeros_new_list([1, 0, 0, 2, 3, 0, 1]) == [1, 2, 3, 1, 0, 0, 0]


def move_right(lst: list[int], k: int) -> list[int]:
    """
    Сдвиг вправо
    Дан список и число k. Циклически сдвиньте элементы списка вправо на k позиций.
    Например:

     - solution([1, 2, 3, 4, 5], k=2) -> [4, 5, 1, 2, 3]
     - solution([1, 2, 3, 4, 5], k=1) -> [5, 1, 2, 3, 4]
     - solution([1, 2, 3, 4, 5], k=3) -> [2, 4, 5, 1, 2]   
     - solution([1, 2, 3, 4, 5], k=4) -> [2, 3, 4, 5, 1]
     - solution([1, 2, 3, 4, 5], k=5) -> [1, 2, 3, 4, 5]

    """
    return []


assert move_right([1, 2, 3, 4, 5], 2) == [4, 5, 1, 2, 3]
assert move_right([1, 2, 3, 4, 5], 1) == [5, 1, 2, 3, 4]
assert move_right([1, 2, 3, 4, 5], 3) == [2, 4, 5, 1, 2]
assert move_right([1, 2, 3, 4, 5], 4) == [2, 3, 4, 5, 1]
assert move_right([1, 2, 3, 4, 5], 5) == [1, 2, 3, 4, 5]


def clean_name(fio: str) -> str:
    """
    Очистка строки
    Данные загрузились из БД с лишними символами, а должны быть только русские буквы.
    Напишите функцию, которая удаляет символы, которые не являются русскими буквами.
    Например:
    "Иsвtrан Ив^%ан Ива?но)вич" -> "Иванов Иван Иванович"
    """
    return ""


assert clean_name("Иsвtrан Ив^%ан Ива?но)вич") == "Иван Иван Иванович"
assert clean_name("Пет&ров П#етр Петр+ович") == "Петров Петр Петрович"


def get_pct_growth(s: list[float]) -> list[str]:
    """
    Процентный рост
    Дан массив цен акций, вывести список, содержащий темпы прироста от периода к периоду, результат округлите до целого.
    Для первого элемента списка выведите значение None. 
    Например: 
    - solution([100, 150, 300, 400]) == [None, '50%', '100%', '33%'].

    Подсказка: знак "%" - это строка и итоговый список должен быть списком строк.
    Используйте либо интерполяцию, либо сложите строки.
    """
    return []


assert get_pct_growth([100, 150, 300, 400]) == [None, '50%', '100%', '33%']
