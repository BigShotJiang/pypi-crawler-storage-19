"""
Example for usage of the Turbo Design Tool
"""
import carbatpy as cb
import sys
import time
import datetime
from carbatpy.optional.spp_machines import Compressor, Turbine, require_spp_machines

#%%
# Compressor
# Initiate Compressor
print(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))

# Test compressor runtime
start = time.time()
Fluid= "pentane * propane * ethane"
Composition = [0.11, 0.7, 0.19]
P_in = 128604.9122629143
Temp_in = 286.5733615490751
P_out = 3361353.5072705583
V_dot_in = 17.50971555097697

Results1 = Compressor()
OutletState, MachineData = Results1.designCompressor(Fluid, 
                                                    Composition, 
                                                    P_in, 
                                                    Temp_in, 
                                                    P_out, 
                                                    V_dot_in, 
                                                    GearedCompressor=False,
                                                    Plot=False,
                                                    EfficiencyConvergence=5e-2,
                                                    MaxIterations=10
                                                    )
print(Results1.BasicParameters.StageNumber)
end = time.time()
runtime1 = end - start
print(runtime1/60)

sys.exit()

start = time.time()
Fluid= "hexane * pentane * propane * ethane"
Composition = [0.03118315, 0.12699793, 0.82770259, 0.01411633]
P_in = 128604.9122629143
Temp_in = 286.5733615490751
P_out = 3361353.5072705583
V_dot_in = 17.50971555097697

Results2 = Compressor()
OutletState, MachineData = Results2.designCompressor(Fluid, 
                                                    Composition, 
                                                    P_in, 
                                                    Temp_in, 
                                                    P_out, 
                                                    V_dot_in, 
                                                    GearedCompressor=False,
                                                    Plot=False,
                                                    EfficiencyConvergence=5e-2,
                                                    MaxIterations=10
                                                    )
print(Results2.BasicParameters.StageNumber)
end = time.time()
runtime1 = end - start
print(runtime1/60)

start = time.time()
Composition = [0.05, 0.05, 0.75, 0.15]

Results3 = Compressor()
OutletState, MachineData = Results3.designCompressor(Fluid, 
                                                    Composition, 
                                                    P_in, 
                                                    Temp_in, 
                                                    P_out, 
                                                    V_dot_in, 
                                                    GearedCompressor=False,
                                                    Plot=False,
                                                    EfficiencyConvergence=5e-2,
                                                    MaxIterations=10
                                                    )

print(Results3.BasicParameters.StageNumber)
end = time.time()
runtime1 = end - start
print(runtime1/60)

start = time.time()
Fluid = "propane"
Composition = [1.0]
Results4 = Compressor()
OutletState, MachineData = Results4.designCompressor(Fluid, 
                                                    Composition, 
                                                    P_in, 
                                                    Temp_in, 
                                                    P_out, 
                                                    V_dot_in, 
                                                    GearedCompressor=False,
                                                    Plot=False,
                                                    EfficiencyConvergence=5e-2,
                                                    MaxIterations=10
                                                    )
print(Results4.BasicParameters.StageNumber)
end = time.time()
runtime4 = end - start
print(runtime4/60)

sys.exit()

#%%
Results = Compressor()
# Example from Repository
# Create inputs for the Tool
InletTemperature = 300           # Inlet temperature in K
InletPressure = 1e5              # Inlet pressure in Pa
OutletPressure = 30e5             # Desired outlet pressure in Pa
WorkingFluid = "ethane * propane * pentane * hexane"  # Working fluid as named in REFPROP
WorkingFluidComposition = [0.15, 0.75, 0.05, 0.05]    # Working fluid composition in mole fractions
InletVolumeFlow = 1.5              # Inlet volume flow in m^3/s

# Calling the design method
OutletState, MachineData = Results.designCompressor(WorkingFluid, 
                                                    WorkingFluidComposition, 
                                                    InletPressure, 
                                                    InletTemperature, 
                                                    OutletPressure, 
                                                    InletVolumeFlow, 
                                                    GearedCompressor=False,
                                                    Plot=True,
                                                    EfficiencyConvergence=5e-2
                                                    )

# Results:
    # OutletState: working fluid state at the compressor outlet as a carbatpy state object
    # MachineData: dictionary containing the details of the compressor design, used by further methods
#%%
# Outletstate
print(OutletState.state)

# Total efficiency in MachineData at the last stage:
print(Results.IsentropicEfficiency[-1])
print(Results.PolytropicEfficiency)

#%%
# Turbine
# Create inputs for the Tool
InletTemperature = 300+273.15
InletPressure = 20e5
OutletPressure = 1e5 
WorkingFluid = "ethane * propane * pentane * hexane"
WorkingFluidComposition = [0.15, 0.75, 0.05, 0.05]
MassFlow = 1
TS = cb.CB_DEFAULTS['Fluid_Defaults']['TRANS_STRING']

myfluid = cb.init_fluid(WorkingFluid, WorkingFluidComposition)
InletState = myfluid.set_state([InletTemperature, InletPressure], "TP", 
                               wanted=TS,output="FluidState")

# Class initialisation
Results_turbine = Turbine()

# Calling the design method
OutletState_turbine, MachineData_turbine = Results_turbine.designTurbine(WorkingFluid, 
                                                 WorkingFluidComposition, 
                                                 InletState, 
                                                 OutletPressure, 
                                                 MassFlow, 
                                                 Plot=True)

#%%
# Outletstate
print(OutletState_turbine.state)

# Total efficiency in MachineData at the last stage:
print(Results_turbine.IsentropicEfficiency[-1])
print(Results_turbine.PolytropicEfficiency)
