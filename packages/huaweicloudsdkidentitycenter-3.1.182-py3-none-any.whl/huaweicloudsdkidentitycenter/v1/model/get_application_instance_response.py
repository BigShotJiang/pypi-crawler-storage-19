# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class GetApplicationInstanceResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'application_instance': 'ApplicationInstanceDto'
    }

    attribute_map = {
        'application_instance': 'application_instance'
    }

    def __init__(self, application_instance=None):
        r"""GetApplicationInstanceResponse

        The model defined in huaweicloud sdk

        :param application_instance: 
        :type application_instance: :class:`huaweicloudsdkidentitycenter.v1.ApplicationInstanceDto`
        """
        
        super().__init__()

        self._application_instance = None
        self.discriminator = None

        if application_instance is not None:
            self.application_instance = application_instance

    @property
    def application_instance(self):
        r"""Gets the application_instance of this GetApplicationInstanceResponse.

        :return: The application_instance of this GetApplicationInstanceResponse.
        :rtype: :class:`huaweicloudsdkidentitycenter.v1.ApplicationInstanceDto`
        """
        return self._application_instance

    @application_instance.setter
    def application_instance(self, application_instance):
        r"""Sets the application_instance of this GetApplicationInstanceResponse.

        :param application_instance: The application_instance of this GetApplicationInstanceResponse.
        :type application_instance: :class:`huaweicloudsdkidentitycenter.v1.ApplicationInstanceDto`
        """
        self._application_instance = application_instance

    def to_dict(self):
        import warnings
        warnings.warn("GetApplicationInstanceResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GetApplicationInstanceResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
