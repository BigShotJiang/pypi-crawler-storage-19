# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListCatalogApplicationsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'applications': 'list[ApplicationTemplateDisplayDto]',
        'page_info': 'PageInfoDto'
    }

    attribute_map = {
        'applications': 'applications',
        'page_info': 'page_info'
    }

    def __init__(self, applications=None, page_info=None):
        r"""ListCatalogApplicationsResponse

        The model defined in huaweicloud sdk

        :param applications: 应用程序目录中的应用程序列表
        :type applications: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationTemplateDisplayDto`]
        :param page_info: 
        :type page_info: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        
        super().__init__()

        self._applications = None
        self._page_info = None
        self.discriminator = None

        if applications is not None:
            self.applications = applications
        if page_info is not None:
            self.page_info = page_info

    @property
    def applications(self):
        r"""Gets the applications of this ListCatalogApplicationsResponse.

        应用程序目录中的应用程序列表

        :return: The applications of this ListCatalogApplicationsResponse.
        :rtype: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationTemplateDisplayDto`]
        """
        return self._applications

    @applications.setter
    def applications(self, applications):
        r"""Sets the applications of this ListCatalogApplicationsResponse.

        应用程序目录中的应用程序列表

        :param applications: The applications of this ListCatalogApplicationsResponse.
        :type applications: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationTemplateDisplayDto`]
        """
        self._applications = applications

    @property
    def page_info(self):
        r"""Gets the page_info of this ListCatalogApplicationsResponse.

        :return: The page_info of this ListCatalogApplicationsResponse.
        :rtype: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        return self._page_info

    @page_info.setter
    def page_info(self, page_info):
        r"""Sets the page_info of this ListCatalogApplicationsResponse.

        :param page_info: The page_info of this ListCatalogApplicationsResponse.
        :type page_info: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        self._page_info = page_info

    def to_dict(self):
        import warnings
        warnings.warn("ListCatalogApplicationsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListCatalogApplicationsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
