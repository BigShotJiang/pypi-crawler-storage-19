# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListApplicationAssignmentsForPrincipalResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'application_assignments': 'list[ApplicationAssignmentDto]',
        'page_info': 'PageInfoDto'
    }

    attribute_map = {
        'application_assignments': 'application_assignments',
        'page_info': 'page_info'
    }

    def __init__(self, application_assignments=None, page_info=None):
        r"""ListApplicationAssignmentsForPrincipalResponse

        The model defined in huaweicloud sdk

        :param application_assignments: 
        :type application_assignments: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationAssignmentDto`]
        :param page_info: 
        :type page_info: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        
        super().__init__()

        self._application_assignments = None
        self._page_info = None
        self.discriminator = None

        if application_assignments is not None:
            self.application_assignments = application_assignments
        if page_info is not None:
            self.page_info = page_info

    @property
    def application_assignments(self):
        r"""Gets the application_assignments of this ListApplicationAssignmentsForPrincipalResponse.

        :return: The application_assignments of this ListApplicationAssignmentsForPrincipalResponse.
        :rtype: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationAssignmentDto`]
        """
        return self._application_assignments

    @application_assignments.setter
    def application_assignments(self, application_assignments):
        r"""Sets the application_assignments of this ListApplicationAssignmentsForPrincipalResponse.

        :param application_assignments: The application_assignments of this ListApplicationAssignmentsForPrincipalResponse.
        :type application_assignments: list[:class:`huaweicloudsdkidentitycenter.v1.ApplicationAssignmentDto`]
        """
        self._application_assignments = application_assignments

    @property
    def page_info(self):
        r"""Gets the page_info of this ListApplicationAssignmentsForPrincipalResponse.

        :return: The page_info of this ListApplicationAssignmentsForPrincipalResponse.
        :rtype: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        return self._page_info

    @page_info.setter
    def page_info(self, page_info):
        r"""Sets the page_info of this ListApplicationAssignmentsForPrincipalResponse.

        :param page_info: The page_info of this ListApplicationAssignmentsForPrincipalResponse.
        :type page_info: :class:`huaweicloudsdkidentitycenter.v1.PageInfoDto`
        """
        self._page_info = page_info

    def to_dict(self):
        import warnings
        warnings.warn("ListApplicationAssignmentsForPrincipalResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListApplicationAssignmentsForPrincipalResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
