# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DescribeRegisteredRegionsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'regions': 'list[RegionDto]'
    }

    attribute_map = {
        'regions': 'regions'
    }

    def __init__(self, regions=None):
        r"""DescribeRegisteredRegionsResponse

        The model defined in huaweicloud sdk

        :param regions: 局点列表
        :type regions: list[:class:`huaweicloudsdkidentitycenter.v1.RegionDto`]
        """
        
        super().__init__()

        self._regions = None
        self.discriminator = None

        if regions is not None:
            self.regions = regions

    @property
    def regions(self):
        r"""Gets the regions of this DescribeRegisteredRegionsResponse.

        局点列表

        :return: The regions of this DescribeRegisteredRegionsResponse.
        :rtype: list[:class:`huaweicloudsdkidentitycenter.v1.RegionDto`]
        """
        return self._regions

    @regions.setter
    def regions(self, regions):
        r"""Sets the regions of this DescribeRegisteredRegionsResponse.

        局点列表

        :param regions: The regions of this DescribeRegisteredRegionsResponse.
        :type regions: list[:class:`huaweicloudsdkidentitycenter.v1.RegionDto`]
        """
        self._regions = regions

    def to_dict(self):
        import warnings
        warnings.warn("DescribeRegisteredRegionsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DescribeRegisteredRegionsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
