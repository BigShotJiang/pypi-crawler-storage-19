"""
Intentra CLI - Main command entry point.
"""

import logging
import sys
from pathlib import Path

import click
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    stream=sys.stderr,
)

logger = logging.getLogger("intentra")


def _get_version():
    """Get version from pyproject.toml."""
    try:
        repo_root = Path(__file__).resolve().parents[3]
        pyproject = repo_root / "pyproject.toml"
        if pyproject.exists():
            with pyproject.open("rb") as f:
                data = tomllib.load(f)
                return data.get("project", {}).get("version", "unknown")
    except Exception:
        pass
    return "unknown"


def _print_version(ctx, param, value):
    """Click callback to print version and exit early when --version is passed."""
    if not value or ctx.resilient_parsing:
        return
    version = _get_version()
    click.echo(f"v{version}")
    ctx.exit()


@click.group()
@click.option(
    "--version",
    is_flag=True,
    callback=_print_version,
    expose_value=False,
    is_eager=True,
    help="Show intentra version and exit",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output (debug mode)",
)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    default=False,
    help="Quiet mode (only print errors)",
)
@click.pass_context
def cli(ctx, verbose, quiet):
    """
    Intentra - Cross-platform automation agent with intent-driven execution.
    
    Control your devices through natural language commands.
    """
    # Set logging level based on options
    if quiet:
        logging.getLogger().setLevel(logging.ERROR)
    elif verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)
    
    # Store context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet


@cli.command()
def help():
    """Show help message."""
    ctx = click.get_current_context()
    click.echo(ctx.parent.get_help())


# Set default command to show help when no command is provided
cli.add_command(help, name="help")

# Import and register commands
from intentra.cli.commands import run, devices
cli.add_command(run.run, name="run")
cli.add_command(devices.devices, name="devices")


def main():
    """Main entry point for intentra CLI."""
    cli()


if __name__ == "__main__":
    main()
