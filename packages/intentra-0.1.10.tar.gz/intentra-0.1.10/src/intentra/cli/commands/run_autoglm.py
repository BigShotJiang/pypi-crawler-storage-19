"""
AutoGLM 任务执行函数

负责在 plan b 模式下使用 autoglm 执行任务。
"""

import logging
import sys
import time
from pathlib import Path

import click

from intentra.autoglm import AutoGLMAdapter, AutoGLMTrajectoryAdapter, ConfigMapper

logger = logging.getLogger("intentra")


async def _run_task_autoglm(
    task_description: str,
    config_path: str | None = None,
    device: str | None = None,
    trace_dir: str | None = None,
    timeout: int | None = None,
    retry: int = 0,
    output_format: str = "text",
    verbose: bool = False,
    quiet: bool = False,
) -> dict:
    """
    使用 autoglm 执行任务。
    
    Args:
        task_description: 任务描述
        device: 设备 ID
        trace_dir: 轨迹目录
        timeout: 超时时间（秒）
        retry: 重试次数
        output_format: 输出格式
        verbose: 详细日志
        quiet: 静默模式
    
    Returns:
        执行结果字典
    """
    start_time = time.time()
    
    try:
        # 创建配置映射器
        # 如果提供了配置文件路径，使用统一配置加载器加载 plan_b 配置
        if config_path:
            from intentra.config import UnifiedConfigLoader
            
            try:
                load_result = UnifiedConfigLoader.load(config_path, plan="b")
                config_mapper = load_result.config  # ConfigMapper
                
                # 记录加载信息
                logger.info(f"Loaded configuration from: {config_path}")
                logger.debug(f"Config format: {load_result.format.value}")
                if load_result.warnings:
                    for warning in load_result.warnings:
                        logger.warning(warning)
                
                # 应用 CLI 参数覆盖（CLI 参数优先级最高）
                if device:
                    config_mapper.device_id = device
                if timeout:
                    config_mapper.timeout = timeout
                if verbose:
                    config_mapper.verbose = verbose
                if quiet:
                    config_mapper.quiet = quiet
            except Exception as e:
                error_msg = (
                    f"Error: Failed to load configuration from {config_path}: {e}\n"
                    "Please check your configuration file."
                )
                logger.error(error_msg)
                if output_format == "json":
                    return {
                        "success": False,
                        "exit_code": 2,
                        "error_message": f"Configuration error: {e}",
                        "output": error_msg,
                    }
                else:
                    click.echo(error_msg, err=True)
                    sys.exit(2)
        else:
            # 没有配置文件，使用默认配置
            config_mapper = ConfigMapper(
                device=device,
                timeout=timeout,
                config_path=None,
                verbose=verbose,
                quiet=quiet,
            )
        
        # 创建轨迹适配器（如果启用）
        trajectory_adapter = None
        if trace_dir:
            try:
                trajectory_adapter = AutoGLMTrajectoryAdapter(base_path=trace_dir)
            except OSError as e:
                error_msg = (
                    f"Failed to create trajectory directory: {trace_dir}\n"
                    f"Error: {e}\n"
                    "Please check directory permissions or choose a different location."
                )
                logger.error(error_msg)
                if output_format == "json":
                    return {
                        "success": False,
                        "exit_code": 2,
                        "error_message": f"Cannot create trajectory directory: {e}",
                        "output": error_msg,
                    }
                else:
                    click.echo(error_msg, err=True)
                    sys.exit(2)
            except Exception as e:
                logger.warning(f"Failed to initialize trajectory adapter: {e}")
        
        # 创建 autoglm 适配器
        adapter = AutoGLMAdapter(
            config_mapper=config_mapper,
            trajectory_adapter=trajectory_adapter,
        )
        
        # 执行任务（带重试逻辑）
        last_result = None
        last_error = None
        
        for attempt in range(retry + 1):
            if attempt > 0:
                logger.info(f"Retry attempt {attempt}/{retry}")
            
            try:
                result = adapter.execute_task(task_description)
                last_result = result
                
                if result["success"]:
                    break
                else:
                    logger.warning(f"Task execution failed (attempt {attempt + 1}/{retry + 1})")
                    
            except KeyboardInterrupt:
                logger.info("Task interrupted by user")
                if trajectory_adapter:
                    try:
                        trajectory_adapter.stop()
                    except Exception:
                        pass
                return {
                    "success": False,
                    "exit_code": 130,  # SIGINT
                    "error_message": "Interrupted by user",
                    "output": "Task interrupted",
                }
            except Exception as e:
                last_error = e
                logger.error(f"Task execution error (attempt {attempt + 1}/{retry + 1}): {e}")
                if trajectory_adapter:
                    try:
                        trajectory_adapter.stop()
                    except Exception:
                        pass
                if verbose:
                    import traceback
                    logger.debug(traceback.format_exc())
                if attempt == retry:
                    logger.error(f"All {retry + 1} attempt(s) failed")
                    break
        
        execution_time = time.time() - start_time
        
        # 格式化结果
        if last_result:
            execution_result = {
                "success": last_result["success"],
                "exit_code": last_result["exit_code"],
                "execution_time": round(execution_time, 2),
                "output": last_result.get("message", "Task completed" if last_result["success"] else "Task failed"),
            }
            
            # 添加轨迹目录信息
            if trace_dir and trajectory_adapter:
                trajectory_dir = trajectory_adapter.get_trajectory_dir()
                if trajectory_dir:
                    execution_result["trace_id"] = str(trajectory_dir)
        else:
            # 所有重试失败
            execution_result = {
                "success": False,
                "exit_code": 1,
                "execution_time": round(execution_time, 2),
                "error_message": str(last_error) if last_error else "Task execution failed",
                "output": f"Error: {last_error}" if last_error else "Task execution failed",
            }
        
        return execution_result
        
    except ImportError as e:
        execution_time = time.time() - start_time
        error_msg = (
            f"Error: Failed to import autoglm modules: {e}\n"
            "This may indicate that autoglm code was not properly ported.\n"
            "Please verify that src/autoglm/ directory exists and contains all required modules."
        )
        logger.error(error_msg)
        if output_format == "json":
            return {
                "success": False,
                "exit_code": 2,
                "execution_time": round(execution_time, 2),
                "error_message": f"Failed to import autoglm: {e}",
                "output": error_msg,
            }
        else:
            click.echo(error_msg, err=True)
            sys.exit(2)
    except Exception as e:
        execution_time = time.time() - start_time
        error_msg = f"Unexpected error: {e}"
        logger.error(error_msg)
        if verbose:
            import traceback
            logger.debug(traceback.format_exc())
        
        return {
            "success": False,
            "exit_code": 2,
            "execution_time": round(execution_time, 2),
            "error_message": str(e),
            "output": error_msg,
        }
