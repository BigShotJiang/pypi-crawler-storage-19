"""
Intentra CLI run command - Execute automation tasks using natural language.
"""

import asyncio
import json
import logging
import sys
from pathlib import Path

import click

from .run_autoglm import _run_task_autoglm

logger = logging.getLogger("intentra")


def coro(f):
    """Decorator to run async function."""
    def wrapper(*args, **kwargs):
        return asyncio.run(f(*args, **kwargs))
    return wrapper


async def run_task(
    task_description: str,
    plan: str = "a",
    config_path: str | None = None,
    device: str | None = None,
    trace_dir: str | None = None,
    timeout: int | None = None,
    retry: int = 0,
    output_format: str = "text",
    verbose: bool = False,
    quiet: bool = False,
    auto_vision: bool = False,
    vision_keywords: str | None = None,
) -> dict:
    """
    Run an automation task using droidrun (plan a) or autoglm (plan b).
    
    Args:
        plan: Execution plan, 'a' for droidrun (default), 'b' for autoglm
    
    Returns:
        dict: Execution result with success, exit_code, execution_time, output, etc.
    """
    import time
    start_time = time.time()
    
    try:
        logger.info(f"Starting task execution: {task_description[:50]}...")
        logger.info(f"Using plan: {plan} ({'droidrun' if plan == 'a' else 'autoglm'})")
        if config_path:
            logger.info(f"Using config file: {config_path}")
        if device:
            logger.info(f"Target device: {device}")
        if trace_dir:
            logger.info(f"Trace directory: {trace_dir}")
        if timeout:
            logger.info(f"Timeout: {timeout}s")
        if retry > 0:
            logger.info(f"Retry count: {retry}")
        if auto_vision:
            logger.info("Auto-vision analysis enabled (LLM-driven decision)")
            if vision_keywords:
                logger.warning(
                    "⚠️ --vision-keywords parameter is deprecated. "
                    "LLM now autonomously decides when vision analysis is needed."
                )
        
        # Plan selection: route to appropriate execution engine
        if plan == "b":
            # Plan b: Use autoglm
            return await _run_task_autoglm(
                task_description=task_description,
                config_path=config_path,
                device=device,
                trace_dir=trace_dir,
                timeout=timeout,
                retry=retry,
                output_format=output_format,
                verbose=verbose,
                quiet=quiet,
            )
        elif plan == "a":
            # Plan a: Use droidrun (default)
            pass  # Continue with existing droidrun logic
        else:
            # Invalid plan value
            error_msg = (
                f"Error: Invalid plan value: {plan}\n"
                "Valid options are: 'a' (droidrun) or 'b' (autoglm)\n"
                "Default is 'a' (droidrun)."
            )
            logger.error(error_msg)
            if output_format == "json":
                return {
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Invalid plan value: {plan}",
                    "output": error_msg,
                }
            else:
                click.echo(error_msg, err=True)
                sys.exit(2)
        
        # Import droidrun components
        try:
            from droidrun.agent.droid import DroidAgent
            from droidrun.agent import ResultEvent
            from droidrun.config_manager import DroidrunConfig
        except ImportError as e:
            error_msg = (
                f"Error: Failed to import droidrun modules: {e}\n"
                "This may indicate that droidrun code was not properly ported.\n"
                "Please verify that src/droidrun/ directory exists and contains all required modules."
            )
            logger.error(error_msg)
            if output_format == "json":
                return {
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Failed to import droidrun: {e}",
                    "output": error_msg,
                }
            else:
                click.echo(error_msg, err=True)
                sys.exit(2)
        
        # Load config: use unified config loader or defaults
        try:
            if config_path:
                logger.info(f"Loading configuration from: {config_path}")
                from intentra.config import UnifiedConfigLoader
                
                # 使用统一配置加载器加载配置
                load_result = UnifiedConfigLoader.load(config_path, plan="a")
                config = load_result.config  # DroidrunConfig
                
                # 记录加载信息
                logger.debug(f"Configuration loaded from file: {config_path}")
                logger.debug(f"Config format: {load_result.format.value}")
                if load_result.warnings:
                    for warning in load_result.warnings:
                        logger.warning(warning)
            else:
                config = DroidrunConfig()
                logger.debug("Using default configuration")
        except FileNotFoundError as e:
            error_msg = (
                f"Error: Configuration file not found: {config_path}\n"
                "Please check the file path and try again."
            )
            logger.error(error_msg)
            if output_format == "json":
                return {
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Configuration file not found: {config_path}",
                    "output": error_msg,
                }
            else:
                click.echo(error_msg, err=True)
                sys.exit(2)
        except Exception as e:
            error_msg = (
                f"Error: Failed to load configuration: {e}\n"
                "Please check your configuration files."
            )
            logger.error(error_msg)
            if output_format == "json":
                return {
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Configuration error: {e}",
                    "output": error_msg,
                }
            else:
                click.echo(error_msg, err=True)
                sys.exit(2)
        
        # Apply CLI overrides
        if device:
            config.device.serial = device
            logger.debug(f"Device override: {device}")
        if timeout:
            # Note: droidrun uses timeout in DroidAgent constructor, not config
            logger.debug(f"Timeout override: {timeout}s")
        
        # Apply auto-vision CLI overrides (only for plan a / droidrun)
        if plan == "a" and auto_vision:
            # Initialize auto_vision config if not exists
            if config.agent.manager.auto_vision is None:
                config.agent.manager.auto_vision = {}
            
            # Enable auto-vision
            config.agent.manager.auto_vision["enabled"] = True
            logger.debug("Auto-vision enabled via CLI parameter (LLM-driven decision)")
            
            # Note: vision-keywords parameter is deprecated - LLM now decides when vision analysis is needed
            if vision_keywords:
                logger.warning(
                    "⚠️ --vision-keywords parameter is deprecated. "
                    "LLM now autonomously decides when vision analysis is needed. "
                    "Ignoring --vision-keywords parameter."
                )
        elif auto_vision and plan == "b":
            logger.warning("Auto-vision is only supported for plan 'a' (droidrun), ignoring --auto-vision flag")
        if trace_dir:
            # Intentra's trajectory adapter handles trajectory saving independently
            # However, we need to ensure droidrun emits ScreenshotEvent so we can collect screenshots
            # ScreenshotEvent is only emitted when:
            #   1. vision is enabled, OR
            #   2. config.logging.save_trajectory != "none"
            # Since we want to collect screenshots without modifying droidrun's behavior too much,
            # we set save_trajectory to "step" to enable screenshot events, but droidrun will
            # save its own trajectory to a different location (config.logging.trajectory_path)
            if config.logging.save_trajectory == "none":
                # Only enable if not already set (respect user's config file settings)
                config.logging.save_trajectory = "step"
                logger.debug("Enabled droidrun screenshot events for Intentra trajectory collection")
            logger.debug(f"Trace directory: {trace_dir}")
        
        # Initialize trajectory adapter if trace_dir is provided
        # 提前安装日志捕获，确保捕获所有日志（包括 DroidAgent 初始化时的日志）
        trajectory_adapter = None
        if trace_dir:
            try:
                from intentra.trajectory import TrajectoryAdapter
                trajectory_adapter = TrajectoryAdapter(base_path=trace_dir)
                # 在创建 DroidAgent 之前启动适配器，确保捕获所有日志
                trajectory_adapter.start()
                logger.debug("Trajectory adapter started (before DroidAgent initialization)")
            except OSError as e:
                # 轨迹目录创建失败，提供清晰的错误提示
                error_msg = (
                    f"Failed to create trajectory directory: {trace_dir}\n"
                    f"Error: {e}\n"
                    "Please check directory permissions or choose a different location."
                )
                logger.error(error_msg)
                if output_format == "json":
                    return {
                        "success": False,
                        "exit_code": 2,
                        "error_message": f"Cannot create trajectory directory: {e}",
                        "output": error_msg,
                    }
                else:
                    click.echo(error_msg, err=True)
                    sys.exit(2)
            except Exception as e:
                logger.warning(f"Failed to initialize trajectory adapter: {e}")
                # Continue execution even if trajectory adapter fails
        
        # Set logging level
        # 注意：如果 trajectory_adapter 已启动，它已经设置了相关 logger 的级别为 DEBUG
        # 这里只设置 intentra logger 的级别，避免覆盖 trajectory_adapter 的设置
        if verbose:
            # 如果 trajectory_adapter 未启动，设置 droidrun logger 级别
            if not trajectory_adapter:
                logging.getLogger("droidrun").setLevel(logging.DEBUG)
            logging.getLogger("intentra").setLevel(logging.DEBUG)
        elif quiet:
            logging.getLogger("droidrun").setLevel(logging.ERROR)
            logging.getLogger("intentra").setLevel(logging.ERROR)
        else:
            # 默认情况下，如果 trajectory_adapter 已启动，保持 DEBUG 级别以捕获所有日志
            # 如果未启动，使用默认级别（通常是 INFO）
            if not trajectory_adapter:
                # 不设置级别，使用默认级别
                pass
        
        # Run agent with retry logic
        last_result: ResultEvent | None = None
        last_error = None
        
        for attempt in range(retry + 1):
            if attempt > 0:
                logger.info(f"Retry attempt {attempt}/{retry}")
            
            try:
                # Initialize DroidAgent
                logger.debug("Initializing DroidAgent...")
                droid_agent = DroidAgent(
                    goal=task_description,
                    config=config,
                    timeout=timeout or 1000,
                )
                logger.debug("DroidAgent initialized")
                
                # Run agent
                logger.info("Starting agent execution...")
                handler = droid_agent.run()
                
                # Stream events and collect trajectory data
                async for event in handler.stream_events():
                    # Events are handled by droidrun's log handler
                    logger.debug(f"Event received: {type(event).__name__}")
                    
                    # Collect trajectory data if adapter is active
                    if trajectory_adapter:
                        try:
                            await trajectory_adapter.process_event(event)
                        except Exception as e:
                            # Data collection failure should not affect task execution
                            logger.debug(f"Failed to process event for trajectory: {e}")
                
                result: ResultEvent = await handler
                last_result = result
                logger.info(f"Task execution completed: success={result.success}")
                
                # Save trajectory data if adapter is active
                if trajectory_adapter:
                    try:
                        trajectory_dir = trajectory_adapter.stop()
                        logger.info(f"Trajectory saved to: {trajectory_dir}")
                        if last_result:
                            # Add trajectory directory to result
                            if not hasattr(last_result, 'trajectory_dir'):
                                last_result.trajectory_dir = str(trajectory_dir)
                    except Exception as e:
                        logger.warning(f"Failed to save trajectory data: {e}")
                        # Continue even if trajectory save fails
                
                if result.success:
                    break
                else:
                    logger.warning(f"Task execution failed (attempt {attempt + 1}/{retry + 1})")
                    
            except KeyboardInterrupt:
                logger.info("Task interrupted by user")
                # Save trajectory data even if interrupted
                if trajectory_adapter:
                    try:
                        trajectory_adapter.stop()
                    except Exception:
                        pass
                return {
                    "success": False,
                    "exit_code": 130,  # SIGINT
                    "error_message": "Interrupted by user",
                    "output": "Task interrupted",
                }
            except Exception as e:
                last_error = e
                logger.error(f"Task execution error (attempt {attempt + 1}/{retry + 1}): {e}")
                # Save trajectory data even if task failed
                if trajectory_adapter:
                    try:
                        trajectory_adapter.stop()
                    except Exception:
                        pass
                if verbose:
                    import traceback
                    logger.debug(traceback.format_exc())
                if attempt == retry:
                    # Last attempt failed
                    logger.error(f"All {retry + 1} attempt(s) failed")
                    break
        
        execution_time = time.time() - start_time
        
        # Format result
        if last_result:
            execution_result = {
                "success": last_result.success,
                "exit_code": 0 if last_result.success else 1,
                "execution_time": round(execution_time, 2),
                "output": "Task completed successfully" if last_result.success else "Task failed",
            }
            
            # Add trace_id if trace_dir is set
            if trace_dir:
                execution_result["trace_id"] = getattr(last_result, "trace_id", None)
        else:
            # All retries failed
            execution_result = {
                "success": False,
                "exit_code": 1,
                "execution_time": round(execution_time, 2),
                "error_message": str(last_error) if last_error else "Task execution failed",
                "output": f"Error: {last_error}" if last_error else "Task execution failed",
            }
        
        return execution_result
        
    except ImportError as e:
        execution_time = time.time() - start_time
        error_msg = (
            f"Error: Missing dependencies - {e}\n"
            "Please install all required dependencies:\n"
            "  pip install -r requirements.txt\n"
            "Or install the package in development mode:\n"
            "  pip install -e ."
        )
        logger.error(error_msg)
        if verbose:
            import traceback
            logger.debug(traceback.format_exc())
        
        return {
            "success": False,
            "exit_code": 2,
            "execution_time": round(execution_time, 2),
            "error_message": f"Missing dependencies: {e}",
            "output": error_msg,
        }
    except Exception as e:
        execution_time = time.time() - start_time
        error_msg = f"Unexpected error: {e}"
        logger.error(error_msg)
        if verbose:
            import traceback
            logger.debug(traceback.format_exc())
        
        return {
            "success": False,
            "exit_code": 2,
            "execution_time": round(execution_time, 2),
            "error_message": str(e),
            "output": error_msg,
        }


@click.command()
@click.argument("task_description", type=str)
@click.option(
    "--config", "-c",
    type=click.Path(exists=True, file_okay=True, dir_okay=False),
    help="Path to configuration file (YAML format). Supports unified config format (with plan_a/plan_b) or legacy droidrun format.",
    default=None,
)
@click.option(
    "--device", "-d",
    help="Device serial number or IP address (e.g., emulator-5554)",
    default=None,
)
@click.option(
    "--trace-dir",
    type=click.Path(file_okay=False, dir_okay=True),
    help="Directory to save execution traces (will be created if it doesn't exist)",
    default=None,
)
@click.option(
    "--timeout",
    type=int,
    help="Task execution timeout in seconds (default: 1000)",
    default=None,
)
@click.option(
    "--retry",
    type=int,
    default=0,
    help="Number of retries on failure (default: 0)",
)
@click.option(
    "--output",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format: 'text' for human-readable output, 'json' for machine-readable output",
)
@click.option(
    "--plan",
    type=click.Choice(["a", "b"], case_sensitive=False),
    default="a",
    help="Execution plan: 'a' for droidrun (default), 'b' for autoglm",
)
@click.option(
    "--auto-vision",
    is_flag=True,
    default=False,
    help="Enable automatic vision analysis for reasoning mode (plan a only)",
)
@click.option(
    "--vision-keywords",
    type=str,
    default=None,
    help="[DEPRECATED] Comma-separated keywords for vision detection. LLM now autonomously decides when vision analysis is needed.",
)
@click.pass_context
@coro
async def run(ctx, task_description, config, device, trace_dir, timeout, retry, output, plan, auto_vision, vision_keywords):
    """
    Execute an automation task using natural language description.
    
    This command uses droidrun's DroidAgent to execute tasks on Android devices.
    The task description should be in natural language (Chinese or English).
    
    \b
    Examples:
        # Basic usage
        intentra run "打开设置应用"
        
        # With device selection
        intentra run "打开设置应用" --device emulator-5554
        
        # Save execution traces
        intentra run "打开设置应用" --trace-dir ./traces
        
        # With timeout and retry
        intentra run "打开设置应用" --timeout 300 --retry 3
        
        # JSON output
        intentra run "打开设置应用" --output json
        
        # Complex task
        intentra run "打开设置，找到关于手机，查看 Android 版本" \\
            --device emulator-5554 \\
            --trace-dir ./my-traces \\
            --timeout 300 \\
            --retry 3 \\
            --output json
        
        # With custom config file
        intentra run "打开设置应用" --config ./config.yaml
        
        # Enable auto-vision analysis
        intentra run "在相册中查找照片" --auto-vision
        
        # Auto-vision (LLM autonomously decides when vision analysis is needed)
        intentra run "find images" --auto-vision
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    
    # Validate config file if provided
    if config:
        config_path = Path(config)
        if not config_path.exists():
            error_msg = (
                f"Error: Configuration file not found: {config}\n"
                "Please provide a valid path to a YAML configuration file."
            )
            if output == "json":
                click.echo(json.dumps({
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Configuration file not found: {config}",
                }, indent=2))
            else:
                click.echo(error_msg, err=True)
            sys.exit(2)
        if not config_path.is_file():
            error_msg = (
                f"Error: Configuration path is not a file: {config}\n"
                "Please provide a valid YAML configuration file path."
            )
            if output == "json":
                click.echo(json.dumps({
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Configuration path is not a file: {config}",
                }, indent=2))
            else:
                click.echo(error_msg, err=True)
            sys.exit(2)
    
    # Validate task description
    if not task_description or not task_description.strip():
        error_msg = (
            "Error: Task description cannot be empty.\n"
            "Please provide a task description, for example:\n"
            '  intentra run "打开设置应用"'
        )
        if output == "json":
            click.echo(json.dumps({
                "success": False,
                "exit_code": 2,
                "error_message": "Task description cannot be empty",
            }, indent=2))
        else:
            click.echo(error_msg, err=True)
        sys.exit(2)
    
    # Validate task description length
    if len(task_description.strip()) > 1000:
        error_msg = (
            "Error: Task description is too long (maximum 1000 characters).\n"
            f"Current length: {len(task_description)} characters."
        )
        if output == "json":
            click.echo(json.dumps({
                "success": False,
                "exit_code": 2,
                "error_message": "Task description is too long (maximum 1000 characters)",
            }, indent=2))
        else:
            click.echo(error_msg, err=True)
        sys.exit(2)
    
    # Validate trace_dir if provided
    if trace_dir:
        trace_path = Path(trace_dir)
        if not trace_path.exists():
            try:
                trace_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"Created trace directory: {trace_dir}")
            except PermissionError:
                error_msg = (
                    f"Error: Permission denied. Cannot create trace directory: {trace_dir}\n"
                    "Please check directory permissions or choose a different location."
                )
                if output == "json":
                    click.echo(json.dumps({
                        "success": False,
                        "exit_code": 2,
                        "error_message": f"Permission denied: Cannot create trace directory: {trace_dir}",
                    }, indent=2))
                else:
                    click.echo(error_msg, err=True)
                sys.exit(2)
            except Exception as e:
                error_msg = (
                    f"Error: Cannot create trace directory: {trace_dir}\n"
                    f"Reason: {e}\n"
                    "Please check the path and try again."
                )
                if output == "json":
                    click.echo(json.dumps({
                        "success": False,
                        "exit_code": 2,
                        "error_message": f"Cannot create trace directory: {e}",
                    }, indent=2))
                else:
                    click.echo(error_msg, err=True)
                sys.exit(2)
        elif not trace_path.is_dir():
            error_msg = (
                f"Error: Trace path is not a directory: {trace_dir}\n"
                "Please provide a valid directory path."
            )
            if output == "json":
                click.echo(json.dumps({
                    "success": False,
                    "exit_code": 2,
                    "error_message": f"Trace path is not a directory: {trace_dir}",
                }, indent=2))
            else:
                click.echo(error_msg, err=True)
            sys.exit(2)
    
    # Validate timeout
    if timeout is not None and (timeout < 1 or timeout > 3600):
        error_msg = (
            f"Error: Invalid timeout value: {timeout}\n"
            "Timeout must be between 1 and 3600 seconds."
        )
        if output == "json":
            click.echo(json.dumps({
                "success": False,
                "exit_code": 2,
                "error_message": f"Invalid timeout value: {timeout} (must be 1-3600)",
            }, indent=2))
        else:
            click.echo(error_msg, err=True)
        sys.exit(2)
    
    # Validate retry
    if retry < 0 or retry > 10:
        error_msg = (
            f"Error: Invalid retry count: {retry}\n"
            "Retry count must be between 0 and 10."
        )
        if output == "json":
            click.echo(json.dumps({
                "success": False,
                "exit_code": 2,
                "error_message": f"Invalid retry count: {retry} (must be 0-10)",
            }, indent=2))
        else:
            click.echo(error_msg, err=True)
        sys.exit(2)
    
    # Run task
    result = await run_task(
        task_description=task_description,
        plan=plan,
        config_path=config,
        device=device,
        trace_dir=trace_dir,
        timeout=timeout,
        retry=retry,
        output_format=output,
        verbose=verbose,
        quiet=quiet,
        auto_vision=auto_vision,
        vision_keywords=vision_keywords,
    )
    
    # Output result with better error messages
    if output == "json":
        click.echo(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        if result["success"]:
            if not quiet:
                click.echo(f"✓ Task completed successfully (took {result.get('execution_time', 0):.2f}s)")
        else:
            error_msg = result.get('error_message', result.get('output', 'Unknown error'))
            exit_code = result.get('exit_code', 1)
            
            # Provide helpful error messages based on exit code
            if exit_code == 2:
                click.echo(f"✗ Configuration error: {error_msg}", err=True)
                click.echo("\nTroubleshooting:", err=True)
                click.echo("  - Check that ADB is installed and in PATH", err=True)
                click.echo("  - Verify device is connected: intentra devices", err=True)
                click.echo("  - Check task description is valid", err=True)
            elif exit_code == 130:
                click.echo("✗ Task interrupted by user", err=True)
            else:
                click.echo(f"✗ Task failed: {error_msg}", err=True)
                if retry > 0:
                    click.echo(f"  (Failed after {retry + 1} attempt(s))", err=True)
    
    # Exit with appropriate code
    sys.exit(result["exit_code"])
