"""
Intentra CLI devices command - List connected Android devices.
"""

import asyncio
import json
import logging
import sys

import click

logger = logging.getLogger("intentra")


def coro(f):
    """Decorator to run async function."""
    def wrapper(*args, **kwargs):
        return asyncio.run(f(*args, **kwargs))
    return wrapper


async def list_devices(verbose: bool = False) -> list[dict]:
    """
    List connected Android devices.
    
    Returns:
        list[dict]: List of device information dictionaries
    """
    try:
        from async_adbutils import adb
        
        devices = await adb.list()
        device_list = []
        
        for device in devices:
            device_info = {
                "serial": device.serial,
            }
            
            if verbose:
                # Try to get additional device info
                try:
                    # Get device properties (simplified - may need more implementation)
                    device_info["model"] = "Unknown"
                    device_info["android_version"] = "Unknown"
                except Exception:
                    pass
            
            device_list.append(device_info)
        
        return device_list
        
    except Exception as e:
        logger.error(f"Error listing devices: {e}")
        raise


@click.command()
@click.option(
    "--output",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format: 'text' for human-readable output, 'json' for machine-readable output",
)
@click.pass_context
@coro
async def devices(ctx, output):
    """
    List connected Android devices.
    
    This command queries ADB to find all connected Android devices and emulators.
    Use --verbose to see detailed device information including model and Android version.
    
    \b
    Examples:
        # Basic usage
        intentra devices
        
        # Detailed output
        intentra --verbose devices
        
        # JSON output
        intentra devices --output json
    """
    verbose = ctx.obj.get("verbose", False)
    quiet = ctx.obj.get("quiet", False)
    
    try:
        device_list = await list_devices(verbose=verbose)
        
        if output == "json":
            result = {
                "devices": device_list,
                "count": len(device_list),
            }
            click.echo(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            if not device_list:
                click.echo("No devices connected.")
                if not quiet:
                    click.echo("\nTroubleshooting:")
                    click.echo("  - Connect a device via USB and enable USB debugging")
                    click.echo("  - Or connect via network: adb connect <ip>:<port>")
                    click.echo("  - Verify ADB is working: adb devices")
            else:
                click.echo(f"Found {len(device_list)} connected device(s):")
                for device in device_list:
                    if verbose and "model" in device:
                        click.echo(f"  • {device['serial']} ({device.get('model', 'Unknown')}, {device.get('android_version', 'Unknown')})")
                    else:
                        click.echo(f"  • {device['serial']}")
        
        sys.exit(0)
        
    except ImportError as e:
        # ADB tools not available
        error_msg = (
            "Error: ADB tools not available.\n"
            "Please install Android SDK Platform Tools and ensure 'adb' is in your PATH.\n"
            f"Details: {e}"
        )
        if output == "json":
            result = {
                "error": "ADB tools not available",
                "error_message": str(e),
                "devices": [],
                "count": 0,
            }
            click.echo(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            click.echo(error_msg, err=True)
        sys.exit(1)
    except Exception as e:
        error_msg = f"Error listing devices: {e}"
        if verbose:
            import traceback
            logger.debug(traceback.format_exc())
        
        if output == "json":
            result = {
                "error": error_msg,
                "error_message": str(e),
                "devices": [],
                "count": 0,
            }
            click.echo(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            click.echo(error_msg, err=True)
            if not quiet:
                click.echo("\nTroubleshooting:", err=True)
                click.echo("  - Check that ADB is installed: adb version", err=True)
                click.echo("  - Verify ADB is in PATH: which adb", err=True)
                click.echo("  - Try running: adb devices", err=True)
        sys.exit(1)
