"""
Intentra CLI - Command line interface for Intentra automation agent.
"""
