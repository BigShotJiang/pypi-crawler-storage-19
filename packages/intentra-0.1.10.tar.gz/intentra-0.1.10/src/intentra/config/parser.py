"""
配置解析器

负责识别配置文件格式、加载 YAML 文件和提取配置段。
"""

import logging
from enum import Enum
from pathlib import Path
from typing import Dict, Any

import yaml

logger = logging.getLogger("intentra.config")


class ConfigFormat(Enum):
    """配置文件格式枚举。"""

    UNIFIED = "unified"  # 融合配置文件格式
    UNKNOWN = "unknown"  # 未知格式（不符合融合配置文件格式）


class ConfigParser:
    """配置解析器，负责识别配置文件格式和提取配置段。"""

    @staticmethod
    def load_yaml_file(path: str) -> Dict[str, Any]:
        """
        安全加载 YAML 文件。

        Args:
            path: 配置文件路径（相对路径或绝对路径）

        Returns:
            解析后的配置字典，如果文件为空则返回空字典

        Raises:
            FileNotFoundError: 文件不存在
            yaml.YAMLError: YAML 语法错误
            UnicodeDecodeError: 编码错误
        """
        file_path = Path(path).resolve()
        
        if not file_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {path}")

        if not file_path.is_file():
            raise ValueError(f"Configuration path is not a file: {path}")

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
            return data or {}  # 处理空文件情况
        except yaml.YAMLError as e:
            raise yaml.YAMLError(f"Failed to parse YAML file {path}: {e}") from e
        except UnicodeDecodeError as e:
            raise UnicodeDecodeError(
                f"Failed to decode file {path}. Please ensure the file is UTF-8 encoded: {e}"
            ) from e

    @staticmethod
    def identify_config_format(data: Dict[str, Any]) -> ConfigFormat:
        """
        识别配置文件格式。

        识别规则：
        - 如果包含 plan_a 或 plan_b 键 → UNIFIED（融合配置文件）
        - 否则 → UNKNOWN（未知格式，不符合融合配置文件格式）

        Args:
            data: 解析后的配置字典

        Returns:
            ConfigFormat 枚举值
        """
        if not isinstance(data, dict):
            return ConfigFormat.UNKNOWN

        # 检查是否为融合配置文件格式
        if "plan_a" in data or "plan_b" in data:
            return ConfigFormat.UNIFIED

        # 不符合融合配置文件格式
        return ConfigFormat.UNKNOWN

    @staticmethod
    def extract_plan_config(data: Dict[str, Any], plan: str) -> Dict[str, Any]:
        """
        从融合配置文件中提取指定 plan 的配置段。

        Args:
            data: 解析后的配置字典
            plan: 计划标识，"a" 表示 plan_a，"b" 表示 plan_b

        Returns:
            提取的配置段字典，如果不存在则返回空字典

        Raises:
            ValueError: plan 值无效
        """
        if plan not in ("a", "b"):
            raise ValueError(f"Invalid plan value: {plan}. Must be 'a' or 'b'")

        plan_key = f"plan_{plan}"
        return data.get(plan_key, {})
