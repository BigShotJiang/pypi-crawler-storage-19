"""
统一配置加载器

提供统一的接口加载融合配置文件。
"""

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Union, TYPE_CHECKING, Any

from droidrun.config_manager import DroidrunConfig

from .parser import ConfigParser, ConfigFormat

if TYPE_CHECKING:
    from intentra.autoglm.config_mapper import ConfigMapper

logger = logging.getLogger("intentra.config")


@dataclass
class ConfigLoadResult:
    """配置加载结果。"""

    config: Union[DroidrunConfig, "ConfigMapper", Any]  # type: ignore
    """加载的配置对象"""
    format: ConfigFormat
    """识别的配置文件格式"""
    plan: str
    """使用的 plan ("a" 或 "b")"""
    source_path: str
    """配置文件路径"""
    warnings: List[str] = field(default_factory=list)
    """警告信息列表"""


class UnifiedConfigLoader:
    """统一配置加载器，仅支持融合配置文件格式。"""

    @staticmethod
    def load(config_path: str, plan: str = "a") -> ConfigLoadResult:
        """
        加载配置文件。

        Args:
            config_path: 配置文件路径（相对路径或绝对路径）
            plan: 执行计划，"a" 表示 droidrun，"b" 表示 autoglm

        Returns:
            ConfigLoadResult: 配置加载结果，包含配置对象和元数据

        Raises:
            FileNotFoundError: 配置文件不存在
            yaml.YAMLError: YAML 语法错误
            ConfigValidationError: 配置验证失败
            ValueError: 配置文件不符合融合格式（不包含 plan_a 或 plan_b）
        """
        # 规范化路径
        config_path = str(Path(config_path).resolve())

        # 加载并解析 YAML 文件
        parser = ConfigParser()
        data = parser.load_yaml_file(config_path)

        # 识别配置文件格式
        format_type = parser.identify_config_format(data)

        # 根据格式和 plan 加载配置
        if format_type == ConfigFormat.UNIFIED:
            # 融合配置文件
            return UnifiedConfigLoader._load_unified_config(
                parser, data, config_path, plan
            )
        else:
            # 不符合融合配置文件格式
            raise ValueError(
                f"配置文件不符合融合格式: {config_path}\n"
                "融合配置文件必须包含 plan_a 或 plan_b 配置段。\n"
                "请参考 config_example_unified.yaml 了解正确的配置文件格式。"
            )

    @staticmethod
    def _load_unified_config(
        parser: ConfigParser,
        data: dict,
        config_path: str,
        plan: str,
    ) -> ConfigLoadResult:
        """加载融合配置文件。"""
        warnings = []

        if plan == "a":
            # 提取 plan_a 配置段
            plan_a_data = parser.extract_plan_config(data, "a")
            if not plan_a_data:
                warnings.append("plan_a section is empty, using default droidrun configuration")
                plan_a_data = {}

            # 使用 DroidrunConfig.from_dict() 加载
            config = DroidrunConfig.from_dict(plan_a_data)
            return ConfigLoadResult(
                config=config,
                format=ConfigFormat.UNIFIED,
                plan="a",
                source_path=config_path,
                warnings=warnings,
            )

        elif plan == "b":
            # 提取 plan_b 配置段
            plan_b_data = parser.extract_plan_config(data, "b")
            if not plan_b_data:
                warnings.append("plan_b section is empty, using default autoglm configuration")
                plan_b_data = {}

            # 动态导入 ConfigMapper 以避免循环依赖
            from intentra.autoglm.config_mapper import ConfigMapper

            # 使用 ConfigMapper.from_config_dict() 加载
            config = ConfigMapper.from_config_dict(plan_b_data)
            return ConfigLoadResult(
                config=config,
                format=ConfigFormat.UNIFIED,
                plan="b",
                source_path=config_path,
                warnings=warnings,
            )

        else:
            raise ValueError(f"Invalid plan value: {plan}. Must be 'a' or 'b'")
