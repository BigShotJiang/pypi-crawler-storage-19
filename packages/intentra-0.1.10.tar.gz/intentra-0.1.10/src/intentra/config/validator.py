"""
配置验证器

负责验证配置文件的结构和参数有效性。
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger("intentra.config")


class ConfigValidationError(Exception):
    """配置验证错误。"""

    pass


class UnsupportedFormatError(Exception):
    """不支持的配置格式错误。"""

    pass


class ConfigValidator:
    """配置验证器，验证配置文件结构。"""

    @staticmethod
    def validate_unified_config(data: Dict[str, Any]) -> List[str]:
        """
        验证融合配置文件结构。

        Args:
            data: 解析后的配置字典

        Returns:
            警告信息列表（如果配置有效但有一些问题）

        Raises:
            ConfigValidationError: 配置验证失败
        """
        warnings = []

        if not isinstance(data, dict):
            raise ConfigValidationError("Configuration must be a dictionary")

        # 检查是否至少包含 plan_a 或 plan_b
        has_plan_a = "plan_a" in data
        has_plan_b = "plan_b" in data

        if not has_plan_a and not has_plan_b:
            raise ConfigValidationError(
                "Unified configuration file must contain at least one of: plan_a or plan_b"
            )

        # 验证 plan_a 结构（如果存在）
        if has_plan_a:
            plan_a_data = data.get("plan_a", {})
            if not isinstance(plan_a_data, dict):
                raise ConfigValidationError("plan_a must be a dictionary")
            if not plan_a_data:
                warnings.append("plan_a section is empty")

        # 验证 plan_b 结构（如果存在）
        if has_plan_b:
            plan_b_data = data.get("plan_b", {})
            if not isinstance(plan_b_data, dict):
                raise ConfigValidationError("plan_b must be a dictionary")
            if not plan_b_data:
                warnings.append("plan_b section is empty")
            else:
                # 验证 plan_b 的配置参数
                ConfigValidator._validate_plan_b_config(plan_b_data)

        return warnings

    @staticmethod
    def _validate_plan_b_config(plan_b_data: Dict[str, Any]) -> None:
        """
        验证 plan_b 配置段的参数。

        Args:
            plan_b_data: plan_b 配置段字典

        Raises:
            ConfigValidationError: 配置验证失败
        """
        # 验证 api_base_url（如果提供）
        if "api_base_url" in plan_b_data:
            api_base_url = plan_b_data["api_base_url"]
            if not isinstance(api_base_url, str):
                raise ConfigValidationError("plan_b.api_base_url must be a string")
            # 基本 URL 格式验证
            if api_base_url and not (api_base_url.startswith("http://") or api_base_url.startswith("https://")):
                raise ConfigValidationError(
                    f"plan_b.api_base_url must be a valid URL starting with http:// or https://: {api_base_url}"
                )

        # 验证 api_key（如果提供）
        if "api_key" in plan_b_data:
            api_key = plan_b_data["api_key"]
            if not isinstance(api_key, str):
                raise ConfigValidationError("plan_b.api_key must be a string")

        # 验证 model_name（如果提供）
        if "model_name" in plan_b_data:
            model_name = plan_b_data["model_name"]
            if not isinstance(model_name, str):
                raise ConfigValidationError("plan_b.model_name must be a string")
            if not model_name:
                raise ConfigValidationError("plan_b.model_name cannot be empty")

    @staticmethod
    def validate_plan_a_config(plan_a_data: Dict[str, Any]) -> List[str]:
        """
        验证 plan_a 配置段是否符合 DroidrunConfig 结构要求。

        注意：这里只做基本结构验证，详细的验证由 DroidrunConfig.from_dict() 处理。

        Args:
            plan_a_data: plan_a 配置段字典

        Returns:
            警告信息列表

        Raises:
            ConfigValidationError: 配置验证失败
        """
        warnings = []

        if not isinstance(plan_a_data, dict):
            raise ConfigValidationError("plan_a must be a dictionary")

        # 基本结构验证（DroidrunConfig 会进行更详细的验证）
        # 这里只检查是否为字典类型

        return warnings
