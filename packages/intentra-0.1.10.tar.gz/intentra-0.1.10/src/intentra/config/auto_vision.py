"""
Auto Vision Analysis configuration.

This module provides configuration classes for automatic vision analysis.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AutoVisionConfig:
    """Configuration for automatic vision analysis."""

    enabled: bool = False
    vision_llm_profile: Optional[str] = None

    def validate(self) -> tuple[bool, Optional[str]]:
        """
        Validate configuration.

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not self.enabled:
            return True, None

        if not self.vision_llm_profile:
            return False, "vision_llm_profile must be configured when auto_vision.enabled=True"

        return True, None
