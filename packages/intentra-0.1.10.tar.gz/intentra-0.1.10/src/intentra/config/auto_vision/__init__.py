"""
Auto Vision Analysis module for reasoning mode.

This module provides automatic vision analysis capabilities that allow
LLM to autonomously decide when vision analysis is needed.
"""

# Import AutoVisionConfig from parent module using importlib to avoid circular import
import importlib.util
from pathlib import Path

# Load AutoVisionConfig from auto_vision.py in parent directory
parent_dir = Path(__file__).parent.parent
auto_vision_py = parent_dir / "auto_vision.py"
if auto_vision_py.exists():
    spec = importlib.util.spec_from_file_location("intentra.config.auto_vision_module", auto_vision_py)
    auto_vision_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(auto_vision_module)
    AutoVisionConfig = auto_vision_module.AutoVisionConfig
else:
    # Fallback: try direct import
    from ..auto_vision import AutoVisionConfig

__all__ = ["AutoVisionConfig"]
