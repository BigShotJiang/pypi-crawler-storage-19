"""
配置映射器

负责将 intentra CLI 参数转换为 autoglm 的配置对象。
"""

import logging
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from autoglm.phone_agent.agent import AgentConfig
    from autoglm.phone_agent.model import ModelConfig

logger = logging.getLogger("intentra.autoglm")


class ConfigMapper:
    """
    配置映射器，将 intentra CLI 参数转换为 autoglm 的配置对象。
    
    根据规范要求，不支持的参数应静默忽略并记录警告日志。
    """

    def __init__(
        self,
        device: str | None = None,
        timeout: int | None = None,
        config_path: str | None = None,
        verbose: bool = False,
        quiet: bool = False,
        base_url: str | None = None,
        model_name: str | None = None,
        api_key: str | None = None,
    ):
        """
        初始化配置映射器。
        
        Args:
            device: 设备 ID
            timeout: 超时时间（秒）
            config_path: 配置文件路径（如果 autoglm 支持）
            verbose: 是否输出详细日志
            quiet: 是否静默模式
            base_url: 模型 API base URL
            model_name: 模型名称
            api_key: API 密钥
        """
        self.device_id = device
        self.timeout = timeout
        self.config_path = config_path
        self.verbose = verbose
        self.quiet = quiet
        self.base_url = base_url or os.getenv("PHONE_AGENT_BASE_URL", "http://localhost:8000/v1")
        self.model_name = model_name or os.getenv("PHONE_AGENT_MODEL", "autoglm-phone-9b")
        self.api_key = api_key or os.getenv("PHONE_AGENT_API_KEY", "EMPTY")
        
        # 处理 config_path：如果 autoglm 不支持配置文件，静默忽略
        if config_path:
            logger.warning(
                f"Config file support for autoglm is not implemented. "
                f"Ignoring --config parameter: {config_path}"
            )

    def to_model_config(self) -> "ModelConfig":
        """
        转换为 autoglm 的 ModelConfig。
        
        Returns:
            ModelConfig 实例
        """
        # 动态导入以避免循环依赖
        from autoglm.phone_agent.model import ModelConfig
        
        return ModelConfig(
            base_url=self.base_url,
            model_name=self.model_name,
            api_key=self.api_key,
        )

    def to_agent_config(self) -> "AgentConfig":
        """
        转换为 autoglm 的 AgentConfig。
        
        Returns:
            AgentConfig 实例
        """
        # 动态导入以避免循环依赖
        from autoglm.phone_agent.agent import AgentConfig
        
        # 计算 max_steps
        max_steps = 100  # 默认值
        if self.timeout:
            max_steps = self._timeout_to_max_steps(self.timeout)
        
        # 处理 verbose/quiet
        verbose = self.verbose
        if self.quiet:
            verbose = False
        
        return AgentConfig(
            max_steps=max_steps,
            device_id=self.device_id,
            verbose=verbose,
        )

    def _timeout_to_max_steps(self, timeout: int) -> int:
        """
        将超时时间（秒）转换为 max_steps。
        
        估算规则：每步约 5-10 秒，取平均值 7.5 秒
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            估算的 max_steps
        """
        # 每步平均耗时约 7.5 秒
        avg_step_time = 7.5
        max_steps = int(timeout / avg_step_time)
        
        # 确保至少为 1
        return max(1, max_steps)

    @classmethod
    def from_config_dict(cls, data: dict) -> "ConfigMapper":
        """
        从配置字典创建 ConfigMapper。
        
        配置优先级：CLI 参数 > 配置文件 > 环境变量 > 默认值
        
        Args:
            data: 配置字典，包含 api_base_url、api_key、model_name
        
        Returns:
            ConfigMapper 实例
        """
        # 从配置字典提取参数，如果未提供则使用 None（会回退到环境变量或默认值）
        base_url = data.get("api_base_url")
        api_key = data.get("api_key")
        model_name = data.get("model_name")
        
        return cls(
            base_url=base_url,
            model_name=model_name,
            api_key=api_key,
        )
