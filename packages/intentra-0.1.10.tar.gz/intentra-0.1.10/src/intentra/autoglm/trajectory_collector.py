"""
AutoGLM 轨迹数据收集器

负责收集 autoglm 产生的截图、操作信息和日志。
"""

import base64
from datetime import datetime
from typing import TYPE_CHECKING

from intentra.trajectory.collector import OperationInfo

if TYPE_CHECKING:
    # 注意：autoglm 使用 phone_agent 作为顶级包
    # 在运行时，需要将 src/autoglm 添加到 sys.path
    pass

from .utils import base64_to_png_bytes


class AutoGLMTrajectoryCollector:
    """
    autoglm 轨迹数据收集器，负责收集截图、操作信息和日志。
    
    Attributes:
        screenshots: 截图列表（索引，PNG 数据）
        operations: 操作信息列表
        screenshot_index: 截图索引计数器
    """

    def __init__(self):
        """初始化收集器。"""
        self.screenshots: list[tuple[int, bytes]] = []
        self.operations: list[OperationInfo] = []
        self.screenshot_index = 0

    def collect_screenshot(self, screenshot) -> None:
        """
        收集截图。
        
        Args:
            screenshot: autoglm 的截图对象（包含 base64_data 属性）
        """
        try:
            # 从 base64 转换为 PNG bytes
            png_bytes = base64_to_png_bytes(screenshot.base64_data)
            
            # 添加到截图列表
            self.screenshots.append((self.screenshot_index, png_bytes))
            self.screenshot_index += 1
        except Exception as e:
            # 收集失败不应影响任务执行
            import logging
            logger = logging.getLogger("intentra.autoglm")
            logger.warning(f"Failed to collect screenshot: {e}")

    def collect_operation(self, step_result) -> None:
        """
        收集操作信息。
        
        Args:
            step_result: autoglm 的 StepResult 对象
        """
        try:
            # 提取操作信息
            action = step_result.action or {}
            action_type = action.get("_metadata", "unknown")
            
            # 确定操作类型
            if action_type == "finish":
                op_type = "finish"
            elif "click" in action_type.lower() or "tap" in action_type.lower():
                op_type = "click"
            elif "swipe" in action_type.lower() or "drag" in action_type.lower():
                op_type = "swipe"
            elif "input" in action_type.lower() or "type" in action_type.lower():
                op_type = "input"
            else:
                op_type = action_type
            
            # 创建 OperationInfo
            operation = OperationInfo(
                timestamp=datetime.now().isoformat(),
                type=op_type,
                target=str(action.get("target", "")),
                action=str(action),
                result=step_result.message,
                success=step_result.success,
            )
            
            # 添加到操作列表
            self.operations.append(operation)
        except Exception as e:
            # 收集失败不应影响任务执行
            import logging
            logger = logging.getLogger("intentra.autoglm")
            logger.warning(f"Failed to collect operation: {e}")

    def reset(self) -> None:
        """重置收集器状态。"""
        self.screenshots.clear()
        self.operations.clear()
        self.screenshot_index = 0
