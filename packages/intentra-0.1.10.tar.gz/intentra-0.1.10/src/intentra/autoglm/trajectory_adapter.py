"""
AutoGLM 轨迹收集适配器

负责收集 autoglm 产生的截图、操作信息和日志，并保存为 intentra 标准格式。
"""

import io
import logging
import sys
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

# 添加 autoglm 到 Python 路径，以便 autoglm 的内部导入能够工作
# autoglm 使用 `from phone_agent.agent import PhoneAgent` 这样的导入
# 需要将 src/autoglm 添加到路径中
_autoglm_path = Path(__file__).resolve().parents[2] / "autoglm"
if str(_autoglm_path) not in sys.path:
    sys.path.insert(0, str(_autoglm_path))

from intentra.trajectory import LogCaptureHandler, LogEntry, TrajectoryWriter
from intentra.trajectory.collector import OperationInfo

from .trajectory_collector import AutoGLMTrajectoryCollector

if TYPE_CHECKING:
    from phone_agent.agent import StepResult

logger = logging.getLogger("intentra.autoglm")


class TeeIO:
    """
    一个同时写入多个目标的文件对象。
    
    用于同时捕获输出并显示在控制台上。
    """
    
    def __init__(self, *targets):
        """初始化，targets 是要写入的目标列表。"""
        self.targets = targets
        self.captured_lines = []
        self.buffer = ""  # 用于处理不完整的行
    
    def write(self, data):
        """写入数据到所有目标。"""
        # 写入所有目标
        for target in self.targets:
            target.write(data)
            target.flush()
        
        # 捕获内容（按行处理）
        if data:
            # 将新数据添加到缓冲区
            self.buffer += data
            
            # 处理完整的行
            while '\n' in self.buffer:
                line, self.buffer = self.buffer.split('\n', 1)
                if line.strip():  # 跳过空行
                    timestamp = datetime.now().isoformat()
                    self.captured_lines.append(LogEntry(
                        timestamp=timestamp,
                        level="INFO",
                        logger="autoglm.stdout",
                        message=line,
                    ))
        
        return len(data)
    
    def flush(self):
        """刷新所有目标。"""
        for target in self.targets:
            if hasattr(target, 'flush'):
                target.flush()
    
    def get_logs(self) -> list[LogEntry]:
        """获取捕获的日志条目。"""
        # 处理缓冲区中剩余的内容（最后一行可能没有换行符）
        if self.buffer.strip():
            timestamp = datetime.now().isoformat()
            self.captured_lines.append(LogEntry(
                timestamp=timestamp,
                level="INFO",
                logger="autoglm.stdout",
                message=self.buffer.rstrip('\n'),
            ))
        return list(self.captured_lines)


class StdoutStderrCapture:
    """
    捕获 stdout 和 stderr 的输出。
    
    autoglm 使用 print() 直接输出到控制台，而不是使用 logging 模块。
    这个类用于捕获这些 print() 输出，以便保存到轨迹记录中。
    """
    
    def __init__(self):
        """初始化捕获器。"""
        self.stdout_capture = io.StringIO()
        self.stderr_capture = io.StringIO()
        self.original_stdout = None
        self.original_stderr = None
        self.stdout_tee = None
        self.stderr_tee = None
    
    def __enter__(self):
        """开始捕获 stdout 和 stderr。"""
        self.original_stdout = sys.stdout
        self.original_stderr = sys.stderr
        
        # 创建 TeeIO，同时写入捕获器和原始 stdout
        self.stdout_tee = TeeIO(self.original_stdout, self.stdout_capture)
        self.stderr_tee = TeeIO(self.original_stderr, self.stderr_capture)
        
        sys.stdout = self.stdout_tee
        sys.stderr = self.stderr_tee
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """停止捕获并恢复原始 stdout 和 stderr。"""
        sys.stdout = self.original_stdout
        sys.stderr = self.original_stderr
    
    def get_logs(self) -> list[LogEntry]:
        """获取捕获的日志条目。"""
        all_logs = []
        if self.stdout_tee:
            all_logs.extend(self.stdout_tee.get_logs())
        if self.stderr_tee:
            # stderr 日志标记为 ERROR 级别
            stderr_logs = self.stderr_tee.get_logs()
            for log in stderr_logs:
                log.level = "ERROR"
                log.logger = "autoglm.stderr"
            all_logs.extend(stderr_logs)
        return all_logs


class AutoGLMTrajectoryAdapter:
    """
    autoglm 轨迹收集适配器，负责收集 autoglm 产生的截图、操作信息和日志。
    
    适配层通过拦截 autoglm 的执行过程来收集轨迹数据，
    然后按照 intentra 的格式要求组织并保存为三个部分：截图、操作信息、过程日志。
    """

    def __init__(self, base_path: str | Path | None = None):
        """
        初始化轨迹收集适配器。
        
        Args:
            base_path: 轨迹记录基础目录路径（默认: "trajectories"）
        """
        if base_path is None:
            base_path = "trajectories"
        if isinstance(base_path, str):
            base_path = Path(base_path)

        self.base_path = base_path.resolve()
        self.trajectory_dir: Path | None = None
        self.collector = AutoGLMTrajectoryCollector()
        self.writer = TrajectoryWriter(base_path=self.base_path)
        self.log_handler: LogCaptureHandler | None = None
        self.stdout_stderr_capture: StdoutStderrCapture | None = None
        self.started = False

    def start(self) -> None:
        """
        启动适配器，初始化收集器和日志捕获。
        
        Raises:
            OSError: 如果无法创建轨迹目录
        """
        if self.started:
            logger.warning("AutoGLMTrajectoryAdapter already started")
            return

        try:
            # 创建轨迹目录
            self.trajectory_dir = self.writer.create_trajectory_dir()
            logger.info(f"Trajectory directory created: {self.trajectory_dir}")

            # 初始化日志捕获 - 捕获 autoglm 相关的 logger
            target_loggers = ["phone_agent", "autoglm", "httpx", "httpcore", "urllib3"]
            self.log_handler = LogCaptureHandler(target_loggers=target_loggers)
            
            # 安装 handler 到多个 logger，并设置日志级别为 DEBUG 以确保捕获所有日志
            loggers_to_capture = [
                "phone_agent",
                "autoglm",
                "httpx",
                "httpcore",
                "urllib3",
            ]
            
            for logger_name in loggers_to_capture:
                target_logger = logging.getLogger(logger_name)
                target_logger.addHandler(self.log_handler)
                target_logger.setLevel(logging.DEBUG)
                target_logger.propagate = False

            # 启动 stdout/stderr 捕获（autoglm 使用 print() 直接输出）
            self.stdout_stderr_capture = StdoutStderrCapture()
            self.stdout_stderr_capture.__enter__()

            self.started = True
            logger.debug("AutoGLMTrajectoryAdapter started")
        except OSError as e:
            logger.error(f"Failed to create trajectory directory: {e}")
            raise OSError(f"Cannot create trajectory directory: {self.base_path}") from e

    def collect_screenshot(self, screenshot) -> None:
        """
        收集截图。
        
        Args:
            screenshot: autoglm 的截图对象（包含 base64_data 属性）
        """
        if not self.started:
            logger.warning("AutoGLMTrajectoryAdapter not started, skipping screenshot collection")
            return
        
        self.collector.collect_screenshot(screenshot)

    def collect_operation(self, step_result) -> None:
        """
        收集操作信息。
        
        Args:
            step_result: autoglm 的 StepResult 对象
        """
        if not self.started:
            logger.warning("AutoGLMTrajectoryAdapter not started, skipping operation collection")
            return
        
        self.collector.collect_operation(step_result)

    def stop(self) -> Path:
        """
        停止适配器，保存轨迹数据。
        
        Returns:
            轨迹记录目录路径
        
        Raises:
            IOError: 如果保存失败
            RuntimeError: 如果适配器未启动
        """
        if not self.started:
            raise RuntimeError("AutoGLMTrajectoryAdapter not started")

        try:
            # 停止 stdout/stderr 捕获
            if self.stdout_stderr_capture:
                self.stdout_stderr_capture.__exit__(None, None, None)
                stdout_stderr_logs = self.stdout_stderr_capture.get_logs()
            else:
                stdout_stderr_logs = []
            
            # 卸载日志捕获处理器
            if self.log_handler:
                loggers_to_remove = [
                    "phone_agent",
                    "autoglm",
                    "httpx",
                    "httpcore",
                    "urllib3",
                ]
                
                for logger_name in loggers_to_remove:
                    target_logger = logging.getLogger(logger_name)
                    target_logger.removeHandler(self.log_handler)
                    # 恢复默认日志级别
                    target_logger.setLevel(logging.WARNING)

            # 合并 logging 日志和 stdout/stderr 日志
            all_logs = []
            if self.log_handler:
                all_logs.extend(self.log_handler.get_logs())
            all_logs.extend(stdout_stderr_logs)
            
            # 按时间戳排序
            all_logs.sort(key=lambda x: x.timestamp)

            # 保存所有数据
            self.writer.save_all(
                screenshots=self.collector.screenshots,
                operations=self.collector.operations,
                logs=all_logs,
            )

            self.started = False
            logger.info(f"Trajectory data saved to: {self.trajectory_dir}")
            return self.trajectory_dir
        except Exception as e:
            logger.error(f"Failed to save trajectory data: {e}")
            raise IOError(f"Failed to save trajectory data: {e}") from e

    def get_trajectory_dir(self) -> Path | None:
        """
        获取当前轨迹记录目录路径。
        
        Returns:
            轨迹记录目录路径，如果未启动则返回 None
        """
        return self.trajectory_dir
