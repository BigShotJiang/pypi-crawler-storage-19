"""
AutoGLM 适配层

负责将 intentra CLI 的参数映射到 autoglm 的配置，并收集 autoglm 产生的轨迹数据。
"""

from .adapter import AutoGLMAdapter
from .config_mapper import ConfigMapper
from .trajectory_adapter import AutoGLMTrajectoryAdapter

__all__ = [
    "AutoGLMAdapter",
    "ConfigMapper",
    "AutoGLMTrajectoryAdapter",
]
