"""
工具函数

提供 autoglm 适配层所需的工具函数。
"""

import base64
from io import BytesIO
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from PIL import Image


def base64_to_png_bytes(base64_data: str) -> bytes:
    """
    将 base64 编码的图像数据转换为 PNG bytes。
    
    Args:
        base64_data: base64 编码的图像数据
        
    Returns:
        PNG 格式的字节数据
    """
    try:
        from PIL import Image
        
        # 解码 base64
        image_data = base64.b64decode(base64_data)
        
        # 打开图像
        image = Image.open(BytesIO(image_data))
        
        # 转换为 PNG 格式
        png_buffer = BytesIO()
        image.save(png_buffer, format="PNG")
        
        return png_buffer.getvalue()
    except Exception as e:
        # 如果转换失败，尝试直接使用原始数据
        # 某些情况下 base64_data 可能已经是 PNG 格式
        try:
            return base64.b64decode(base64_data)
        except Exception:
            raise ValueError(f"Failed to convert base64 to PNG: {e}") from e
