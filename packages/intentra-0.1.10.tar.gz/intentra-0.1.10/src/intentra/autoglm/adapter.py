"""
AutoGLM 适配器主类

负责初始化 autoglm、执行任务、收集轨迹数据。
"""

import logging
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

# 添加 autoglm 到 Python 路径，以便 autoglm 的内部导入能够工作
_autoglm_path = Path(__file__).resolve().parents[2] / "autoglm"
if str(_autoglm_path) not in sys.path:
    sys.path.insert(0, str(_autoglm_path))

if TYPE_CHECKING:
    from phone_agent.agent import PhoneAgent, StepResult

from .config_mapper import ConfigMapper
from .trajectory_adapter import AutoGLMTrajectoryAdapter

logger = logging.getLogger("intentra.autoglm")


class AutoGLMAdapter:
    """
    autoglm 适配器主类，负责初始化 autoglm、执行任务、收集轨迹数据。
    
    适配层通过拦截 PhoneAgent 的执行过程来收集轨迹数据，
    然后按照 intentra 的格式要求组织并保存。
    """

    def __init__(
        self,
        config_mapper: ConfigMapper,
        trajectory_adapter: AutoGLMTrajectoryAdapter | None = None,
    ):
        """
        初始化适配器。
        
        Args:
            config_mapper: 配置映射器，包含 CLI 参数到 autoglm 配置的映射
            trajectory_adapter: 可选的轨迹收集适配器
        """
        self.config_mapper = config_mapper
        self.trajectory_adapter = trajectory_adapter
        self.phone_agent: "PhoneAgent | None" = None

    def _create_phone_agent(self) -> "PhoneAgent":
        """
        创建 PhoneAgent 实例。
        
        Returns:
            PhoneAgent 实例
        """
        # 动态导入以避免循环依赖
        from phone_agent.agent import PhoneAgent
        
        # 获取配置
        model_config = self.config_mapper.to_model_config()
        agent_config = self.config_mapper.to_agent_config()
        
        # 创建 PhoneAgent 实例
        phone_agent = PhoneAgent(
            model_config=model_config,
            agent_config=agent_config,
        )
        
        return phone_agent

    def execute_task(self, task_description: str) -> dict:
        """
        执行任务，返回结果字典。
        
        Args:
            task_description: 自然语言任务描述
            
        Returns:
            dict 包含以下键：
            - success: bool - 任务是否成功
            - message: str - 任务完成消息
            - exit_code: int - 退出代码（0 表示成功，非零表示失败）
            - execution_time: float - 执行时间（秒）
        """
        start_time = time.time()
        
        try:
            # 启动轨迹收集（如果启用）
            if self.trajectory_adapter:
                self.trajectory_adapter.start()
            
            # 创建 PhoneAgent 实例
            self.phone_agent = self._create_phone_agent()
            
            # 使用 step 方法逐步执行，以便收集轨迹数据
            # 第一步：执行初始步骤
            result = self.phone_agent.step(task_description)
            
            # 收集第一个步骤的数据
            if self.trajectory_adapter:
                # 获取当前截图（通过 device_factory）
                try:
                    from phone_agent.device_factory import get_device_factory
                    device_factory = get_device_factory()
                    screenshot = device_factory.get_screenshot(self.config_mapper.device_id)
                    if screenshot:
                        self.trajectory_adapter.collect_screenshot(screenshot)
                except Exception as e:
                    logger.debug(f"Failed to collect initial screenshot: {e}")
                
                self.trajectory_adapter.collect_operation(result)
            
            # 继续执行直到完成或达到最大步数
            while not result.finished and self.phone_agent.step_count < self.phone_agent.agent_config.max_steps:
                result = self.phone_agent.step()
                
                # 收集每个步骤的数据
                if self.trajectory_adapter:
                    try:
                        from phone_agent.device_factory import get_device_factory
                        device_factory = get_device_factory()
                        screenshot = device_factory.get_screenshot(self.config_mapper.device_id)
                        if screenshot:
                            self.trajectory_adapter.collect_screenshot(screenshot)
                    except Exception as e:
                        logger.debug(f"Failed to collect screenshot: {e}")
                    
                    self.trajectory_adapter.collect_operation(result)
            
            # 获取最终消息
            message = result.message or ("Task completed" if result.success else "Task failed")
            
            # 判断任务是否成功（基于 StepResult）
            success = result.success if hasattr(result, 'success') else (message and "failed" not in message.lower() and "error" not in message.lower())
            
            execution_time = time.time() - start_time
            
            # 停止轨迹收集（如果启用）
            if self.trajectory_adapter:
                try:
                    trajectory_dir = self.trajectory_adapter.stop()
                    logger.info(f"Trajectory saved to: {trajectory_dir}")
                except Exception as e:
                    logger.warning(f"Failed to save trajectory: {e}")
            
            return {
                "success": success,
                "message": message,
                "exit_code": 0 if success else 1,
                "execution_time": round(execution_time, 2),
            }
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Task execution failed: {e}")
            
            # 即使失败也要保存轨迹数据
            if self.trajectory_adapter and self.trajectory_adapter.started:
                try:
                    self.trajectory_adapter.stop()
                except Exception:
                    pass
            
            return {
                "success": False,
                "message": f"Task execution failed: {e}",
                "exit_code": 1,
                "execution_time": round(execution_time, 2),
            }
