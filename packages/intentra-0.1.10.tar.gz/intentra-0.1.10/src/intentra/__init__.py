"""
Intentra - Cross-platform automation agent with intent-driven execution.

This package contains Intentra-specific code that wraps droidrun functionality.
"""

__version__ = "0.1.0"
