"""
Intentra 轨迹记录适配层

此模块提供轨迹记录适配器，用于从 droidrun 收集轨迹数据并按照 intentra 的格式要求保存。

注意：所有开发和测试工作必须在 `conda activate intentra` 环境中进行。

主要组件：
- TrajectoryAdapter: 轨迹记录适配器主类，负责协调数据收集和保存
- TrajectoryCollector: 数据收集器，负责从 droidrun 收集截图、操作信息和日志
- TrajectoryWriter: 数据写入器，负责将数据保存到文件系统
- LogCaptureHandler: 日志捕获处理器，用于捕获 droidrun 的日志输出

使用示例：
    ```python
    from intentra.trajectory import TrajectoryAdapter
    
    # 创建适配器
    adapter = TrajectoryAdapter(base_path="./my-traces")
    
    # 启动适配器
    adapter.start()
    
    # 在任务执行过程中处理事件
    async for event in handler.stream_events():
        await adapter.process_event(event)
    
    # 停止适配器并保存数据
    trajectory_dir = adapter.stop()
    ```

轨迹记录格式：
    轨迹记录包含三个部分：
    1. screenshots/: 截图目录，包含按时间顺序的 PNG 文件
    2. operations.json: 操作信息 JSON 文件
    3. logs.txt: 过程日志文本文件
"""

__all__ = [
    "TrajectoryAdapter",
    "TrajectoryCollector",
    "TrajectoryWriter",
    "LogCaptureHandler",
]

from .adapter import TrajectoryAdapter
from .collector import TrajectoryCollector, OperationInfo
from .writer import TrajectoryWriter
from .logger_capture import LogCaptureHandler, LogEntry
