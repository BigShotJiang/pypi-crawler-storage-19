"""
数据收集器

负责从 droidrun 收集三类数据：截图、操作信息、过程日志。
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Tuple

from llama_index.core.workflow import Event


@dataclass
class OperationInfo:
    """操作信息数据模型。"""

    timestamp: str
    type: str
    target: Optional[str] = None
    action: Optional[str] = None
    result: Optional[str] = None
    success: Optional[bool] = None

    def __post_init__(self):
        """验证数据格式。"""
        if not self.timestamp:
            raise ValueError("timestamp cannot be empty")
        if not self.type:
            raise ValueError("type cannot be empty")
        # 验证时间戳格式（ISO 8601）
        try:
            datetime.fromisoformat(self.timestamp.replace("Z", "+00:00"))
        except ValueError:
            raise ValueError(f"Invalid timestamp format: {self.timestamp}")


class TrajectoryCollector:
    """
    数据收集器，负责从 droidrun 收集三类数据。
    
    Attributes:
        screenshots: 截图列表（索引，数据）
        operations: 操作信息列表
        screenshot_index: 当前截图索引
    """

    def __init__(self):
        """初始化数据收集器。"""
        self.screenshots: List[Tuple[int, bytes]] = []
        self.operations: List[OperationInfo] = []
        self.screenshot_index: int = 0

    def collect_screenshot(self, event: Event) -> None:
        """
        从事件中收集截图。
        
        Args:
            event: ScreenshotEvent 实例，包含 screenshot 属性（bytes）
        
        Note:
            截图按顺序索引，从 0 开始递增。
        """
        if hasattr(event, "screenshot") and event.screenshot:
            self.screenshots.append((self.screenshot_index, event.screenshot))
            self.screenshot_index += 1

    def collect_operation(self, event: Event) -> None:
        """
        从事件中收集操作信息。
        
        Args:
            event: 事件实例（CodeActCodeEvent, CodeActOutputEvent, ExecutorActionEvent 等）
        """
        try:
            timestamp = datetime.now().isoformat()
            event_type = event.__class__.__name__

            # 根据事件类型提取操作信息
            if event_type == "CodeActCodeEvent":
                if hasattr(event, "code"):
                    self.operations.append(
                        OperationInfo(
                            timestamp=timestamp,
                            type="code_execution",
                            action=event.code,
                        )
                    )
            elif event_type == "CodeActOutputEvent":
                if hasattr(event, "output"):
                    # 检查是否有对应的 code 操作
                    if self.operations and self.operations[-1].type == "code_execution":
                        self.operations[-1].result = event.output
                        # 尝试判断是否成功（简单启发式）
                        if "Error" in event.output or "Exception" in event.output:
                            self.operations[-1].success = False
                        else:
                            self.operations[-1].success = True
                    else:
                        self.operations.append(
                            OperationInfo(
                                timestamp=timestamp,
                                type="code_output",
                                result=event.output,
                            )
                        )
            elif event_type == "ExecutorActionEvent":
                if hasattr(event, "action_json"):
                    self.operations.append(
                        OperationInfo(
                            timestamp=timestamp,
                            type="executor_action",
                            action=event.action_json,
                            target=getattr(event, "description", None),
                        )
                    )
            elif event_type == "ExecutorActionResultEvent":
                if hasattr(event, "action") and hasattr(event, "success"):
                    self.operations.append(
                        OperationInfo(
                            timestamp=timestamp,
                            type="executor_action_result",
                            result=getattr(event, "summary", None),
                            success=event.success,
                            action=str(event.action) if hasattr(event, "action") else None,
                        )
                    )
        except Exception:
            # 数据收集失败不应影响任务执行，静默忽略
            pass

    def get_screenshots(self) -> List[Tuple[int, bytes]]:
        """
        获取所有截图。
        
        Returns:
            截图列表（索引，数据）
        """
        return list(self.screenshots)

    def get_operations(self) -> List[OperationInfo]:
        """
        获取所有操作信息。
        
        Returns:
            操作信息列表
        """
        return list(self.operations)

    def clear(self) -> None:
        """清空所有收集的数据。"""
        self.screenshots.clear()
        self.operations.clear()
        self.screenshot_index = 0
