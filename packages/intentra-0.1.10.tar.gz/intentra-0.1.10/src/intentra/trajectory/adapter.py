"""
轨迹记录适配器

负责从 droidrun 收集轨迹数据并保存。
"""

import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from droidrun.agent.droid import DroidAgent
    from llama_index.core.workflow import Event, WorkflowHandler

from .collector import TrajectoryCollector
from .logger_capture import LogCaptureHandler
from .writer import TrajectoryWriter

logger = logging.getLogger("intentra.trajectory")


class TrajectoryAdapter:
    """
    轨迹记录适配器，负责从 droidrun 收集轨迹数据并保存。
    
    适配层通过监听 droidrun 的事件流和访问其 Trajectory 对象来收集轨迹数据，
    然后按照 intentra 的格式要求组织并保存为三个部分：截图、操作信息、过程日志。
    """

    def __init__(self, base_path: str | Path | None = None):
        """
        初始化轨迹记录适配器。
        
        Args:
            base_path: 轨迹记录基础目录路径（默认: "trajectories"）
        """
        if base_path is None:
            base_path = "trajectories"
        if isinstance(base_path, str):
            base_path = Path(base_path)

        self.base_path = base_path.resolve()
        self.trajectory_dir: Path | None = None
        self.collector = TrajectoryCollector()
        self.writer = TrajectoryWriter(base_path=self.base_path)
        self.log_handler: LogCaptureHandler | None = None
        self.started = False

    def start(self) -> None:
        """
        启动适配器，初始化收集器和日志捕获。
        
        安装日志捕获处理器到多个相关 logger，并设置日志级别以确保捕获所有相关日志。
        
        Raises:
            OSError: 如果无法创建轨迹目录
        """
        if self.started:
            logger.warning("TrajectoryAdapter already started")
            return

        try:
            # 创建轨迹目录
            self.trajectory_dir = self.writer.create_trajectory_dir()
            logger.info(f"Trajectory directory created: {self.trajectory_dir}")

            # 初始化日志捕获 - 捕获多个相关 logger
            # 包括 droidrun 主 logger 和 HTTP 客户端库的 logger
            target_loggers = ["droidrun", "httpx", "httpcore", "urllib3"]
            self.log_handler = LogCaptureHandler(target_loggers=target_loggers)
            
            # 安装 handler 到多个 logger，并设置日志级别为 DEBUG 以确保捕获所有日志
            loggers_to_capture = [
                "droidrun",
                "httpx",
                "httpcore",
                "urllib3",
            ]
            
            for logger_name in loggers_to_capture:
                target_logger = logging.getLogger(logger_name)
                # 设置日志级别为 DEBUG 以确保捕获所有级别的日志
                target_logger.setLevel(logging.DEBUG)
                target_logger.addHandler(self.log_handler)
            
            logger.debug("Log capture handler installed on multiple loggers")

            self.started = True
        except OSError as e:
            raise OSError(f"Cannot create trajectory directory: {self.base_path}") from e

    def collect_from_droidrun(
        self,
        droid_agent: "DroidAgent",
        handler: "WorkflowHandler",
    ) -> None:
        """
        从 droidrun 收集轨迹数据。
        
        此方法保留用于向后兼容，但实际的事件处理通过 process_event() 方法完成。
        
        Args:
            droid_agent: DroidAgent 实例
            handler: WorkflowHandler 实例，用于访问事件流
        
        Note:
            事件流监听在外部通过 async for 循环处理，每个事件通过 process_event() 处理。
        """
        if not self.started:
            logger.warning("TrajectoryAdapter not started, skipping data collection")
            return
        # 事件处理通过 process_event() 方法完成

    async def process_event(self, event: "Event") -> None:
        """
        处理单个事件，收集相关数据。
        
        Args:
            event: 事件实例（ScreenshotEvent, CodeActCodeEvent 等）
        
        Note:
            此方法异步处理事件，不会阻塞事件流。如果数据收集失败，会记录警告但不影响任务执行。
        """
        if not self.started:
            return

        try:
            # 导入事件类型（延迟导入避免循环依赖）
            from droidrun.agent.common.events import ScreenshotEvent

            # 收集截图
            if isinstance(event, ScreenshotEvent):
                self.collector.collect_screenshot(event)

            # 收集操作信息
            self.collector.collect_operation(event)
        except Exception as e:
            # 数据收集失败不应影响任务执行
            logger.warning(f"Failed to collect data from event {type(event).__name__}: {e}")

    def get_trajectory_dir(self) -> Path | None:
        """
        获取当前轨迹记录目录。
        
        Returns:
            轨迹记录目录路径，如果适配器未启动则返回 None
        """
        return self.trajectory_dir

    def stop(self) -> Path:
        """
        停止适配器，保存所有收集的数据。
        
        即使任务执行失败，也会保存已收集的数据。
        
        Returns:
            轨迹记录目录路径
        
        Raises:
            IOError: 如果数据保存失败
        """
        if not self.started:
            logger.warning("TrajectoryAdapter not started, nothing to save")
            return self.trajectory_dir or self.base_path

        try:
            # 获取收集的数据
            screenshots = self.collector.get_screenshots()
            operations = self.collector.get_operations()
            logs = self.log_handler.get_logs() if self.log_handler else []

            # 保存所有数据（即使为空也创建目录结构）
            trajectory_dir = self.writer.save_all(screenshots, operations, logs)
            logger.info(f"Trajectory data saved to: {trajectory_dir}")

            # 清理日志捕获 - 从所有已安装的 logger 中移除 handler
            if self.log_handler:
                loggers_to_clean = ["droidrun", "httpx", "httpcore", "urllib3"]
                for logger_name in loggers_to_clean:
                    target_logger = logging.getLogger(logger_name)
                    try:
                        target_logger.removeHandler(self.log_handler)
                    except Exception:
                        # 如果 handler 不在该 logger 中，忽略错误
                        pass
                self.log_handler.clear()
                self.log_handler = None

            self.started = False
            return trajectory_dir
        except Exception as e:
            # 即使保存失败，也尝试清理资源
            if self.log_handler:
                loggers_to_clean = ["droidrun", "httpx", "httpcore", "urllib3"]
                for logger_name in loggers_to_clean:
                    target_logger = logging.getLogger(logger_name)
                    try:
                        target_logger.removeHandler(self.log_handler)
                    except Exception:
                        pass
                self.log_handler = None

            # 记录错误但不影响任务执行
            logger.error(f"Failed to save trajectory data: {e}")
            # 不抛出异常，确保任务执行可以继续
            return self.trajectory_dir or self.base_path
