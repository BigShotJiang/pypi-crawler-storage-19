"""
数据写入器

负责将收集的数据保存到文件系统。
"""

import json
import logging
import os
import shutil
import time
from pathlib import Path
from typing import List, Tuple

from .collector import OperationInfo
from .logger_capture import LogEntry

logger = logging.getLogger("intentra.trajectory.writer")


class TrajectoryWriter:
    """
    数据写入器，负责将收集的数据保存到文件系统。
    
    Attributes:
        base_path: 轨迹记录基础目录路径
        trajectory_dir: 当前轨迹记录目录
    """

    def __init__(self, base_path: str | Path = "trajectories"):
        """
        初始化数据写入器。
        
        Args:
            base_path: 轨迹记录基础目录路径（默认: "trajectories"）
        """
        if isinstance(base_path, str):
            base_path = Path(base_path)
        self.base_path = base_path.resolve()
        self.trajectory_dir: Path | None = None

    def create_trajectory_dir(self) -> Path:
        """
        创建唯一的轨迹记录目录。
        
        Returns:
            创建的轨迹记录目录路径
        
        Raises:
            OSError: 如果无法创建目录（权限不足、磁盘空间不足等）
        """
        # 检查磁盘空间（简单检查：尝试创建目录）
        try:
            # 确保基础目录存在
            self.base_path.mkdir(parents=True, exist_ok=True)
            
            # 检查是否有写入权限
            if not os.access(self.base_path, os.W_OK):
                raise OSError(f"No write permission for directory: {self.base_path}")
            
            # 检查磁盘空间（通过尝试创建测试文件）
            test_file = self.base_path / ".space_check"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except OSError as e:
                if e.errno == 28:  # No space left on device
                    raise OSError(
                        f"Insufficient disk space in {self.base_path}. "
                        "Please free up space or choose a different location."
                    ) from e
                raise
            
            # 扫描现有目录，找出所有数字命名的目录
            existing_indices = []
            if self.base_path.exists():
                for item in self.base_path.iterdir():
                    if item.is_dir() and item.name.isdigit():
                        try:
                            existing_indices.append(int(item.name))
                        except ValueError:
                            # 忽略无法转换为整数的目录名
                            continue
            
            # 计算下一个 index（使用文件锁确保并发安全）
            import fcntl
            import platform
            
            lock_file = self.base_path / ".index_lock"
            lock_file.parent.mkdir(parents=True, exist_ok=True)
            
            # 使用文件锁确保并发安全
            with open(lock_file, "w") as f:
                if platform.system() != "Windows":
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                else:
                    import msvcrt
                    msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
                
                try:
                    # 重新扫描（可能在等待锁时其他进程已创建目录）
                    existing_indices = []
                    if self.base_path.exists():
                        for item in self.base_path.iterdir():
                            if item.is_dir() and item.name.isdigit():
                                try:
                                    existing_indices.append(int(item.name))
                                except ValueError:
                                    continue
                    
                    # 计算下一个 index
                    next_index = max(existing_indices) + 1 if existing_indices else 0
                    
                    # 创建新目录（基于 index 的命名格式）
                    folder_name = str(next_index)
                    self.trajectory_dir = self.base_path / folder_name
                    self.trajectory_dir.mkdir(parents=True, exist_ok=True)
                finally:
                    if platform.system() != "Windows":
                        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                    # Windows 锁会自动释放
            
            return self.trajectory_dir
        except OSError:
            raise
        except Exception as e:
            raise OSError(f"Failed to create trajectory directory: {e}") from e

    def save_screenshots(self, screenshots: List[Tuple[int, bytes]]) -> None:
        """
        保存截图到 screenshots/ 目录。
        
        Args:
            screenshots: 截图列表（索引，数据）
        
        Raises:
            IOError: 如果保存失败
        """
        if not self.trajectory_dir:
            raise ValueError("Trajectory directory not created. Call create_trajectory_dir() first.")

        screenshots_dir = self.trajectory_dir / "screenshots"
        screenshots_dir.mkdir(exist_ok=True)

        for index, screenshot_bytes in screenshots:
            # 处理路径中的特殊字符（使用安全的文件名）
            safe_index = str(index).zfill(4)
            screenshot_path = screenshots_dir / f"{safe_index}.png"
            try:
                # 原子性写入：先写入临时文件，再重命名
                temp_path = screenshot_path.with_suffix(".tmp")
                temp_path.write_bytes(screenshot_bytes)
                temp_path.rename(screenshot_path)
            except OSError as e:
                # 处理磁盘空间不足等系统错误
                if e.errno == 28:  # No space left on device
                    raise IOError(
                        f"Insufficient disk space. Failed to save screenshot {index}. "
                        "Please free up space and try again."
                    ) from e
                raise IOError(f"Failed to save screenshot {index}: {e}") from e
            except Exception as e:
                raise IOError(f"Failed to save screenshot {index}: {e}") from e

    def save_operations(self, operations: List[OperationInfo]) -> None:
        """
        保存操作信息到 operations.json。
        
        Args:
            operations: 操作信息列表
        
        Raises:
            IOError: 如果保存失败
        """
        if not self.trajectory_dir:
            raise ValueError("Trajectory directory not created. Call create_trajectory_dir() first.")

        operations_data = {
            "version": "1.0",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "total_operations": len(operations),
            "operations": [
                {
                    "timestamp": op.timestamp,
                    "type": op.type,
                    "target": op.target,
                    "action": op.action,
                    "result": op.result,
                    "success": op.success,
                }
                for op in operations
            ],
        }

        operations_path = self.trajectory_dir / "operations.json"
        try:
            # 原子性写入：先写入临时文件，再重命名
            temp_path = operations_path.with_suffix(".tmp")
            with temp_path.open("w", encoding="utf-8") as f:
                json.dump(operations_data, f, indent=2, ensure_ascii=False)
            temp_path.rename(operations_path)
        except Exception as e:
            raise IOError(f"Failed to save operations: {e}") from e

    def save_logs(self, logs: List[LogEntry]) -> None:
        """
        保存日志到 logs.txt。
        
        Args:
            logs: 日志条目列表
        
        Raises:
            IOError: 如果保存失败
        """
        if not self.trajectory_dir:
            raise ValueError("Trajectory directory not created. Call create_trajectory_dir() first.")

        logs_path = self.trajectory_dir / "logs.txt"
        try:
            # 原子性写入：先写入临时文件，再重命名
            temp_path = logs_path.with_suffix(".tmp")
            with temp_path.open("w", encoding="utf-8") as f:
                for log_entry in logs:
                    line = (
                        f"{log_entry.timestamp} [{log_entry.level}] "
                        f"{log_entry.logger}"
                    )
                    if log_entry.module:
                        line += f":{log_entry.module}"
                    if log_entry.function:
                        line += f".{log_entry.function}"
                    if log_entry.line:
                        line += f":{log_entry.line}"
                    line += f": {log_entry.message}\n"
                    f.write(line)
            temp_path.rename(logs_path)
        except Exception as e:
            raise IOError(f"Failed to save logs: {e}") from e

    def save_all(
        self,
        screenshots: List[Tuple[int, bytes]],
        operations: List[OperationInfo],
        logs: List[LogEntry],
    ) -> Path:
        """
        保存所有数据，返回轨迹目录路径。
        
        即使某些数据为空，也会创建目录结构。
        
        Args:
            screenshots: 截图列表
            operations: 操作信息列表
            logs: 日志条目列表
        
        Returns:
            轨迹记录目录路径
        
        Raises:
            IOError: 如果保存失败
        """
        if not self.trajectory_dir:
            self.create_trajectory_dir()

        # 保存所有数据（即使为空也创建目录结构）
        try:
            # 创建 screenshots 目录（即使没有截图）
            screenshots_dir = self.trajectory_dir / "screenshots"
            screenshots_dir.mkdir(exist_ok=True)
            
            if screenshots:
                self.save_screenshots(screenshots)
            else:
                # 即使没有截图，也确保目录存在
                screenshots_dir.mkdir(exist_ok=True)
            
            # 保存操作信息（即使为空也创建文件）
            try:
                if operations:
                    self.save_operations(operations)
                else:
                    # 即使没有操作，也创建空文件以保持目录结构
                    operations_path = self.trajectory_dir / "operations.json"
                    if not operations_path.exists():
                        operations_data = {
                            "version": "1.0",
                            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                            "total_operations": 0,
                            "operations": [],
                        }
                        temp_path = operations_path.with_suffix(".tmp")
                        with temp_path.open("w", encoding="utf-8") as f:
                            json.dump(operations_data, f, indent=2, ensure_ascii=False)
                        temp_path.rename(operations_path)
            except Exception as e:
                logger.warning(f"Failed to save operations: {e}")
                # 即使失败，也尝试创建空文件
                operations_path = self.trajectory_dir / "operations.json"
                if not operations_path.exists():
                    try:
                        operations_data = {
                            "version": "1.0",
                            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                            "total_operations": 0,
                            "operations": [],
                        }
                        operations_path.write_text(
                            json.dumps(operations_data, indent=2, ensure_ascii=False),
                            encoding="utf-8"
                        )
                    except Exception:
                        pass  # 如果还是失败，至少记录警告
            
            # 保存日志（即使为空也创建文件）
            try:
                if logs:
                    self.save_logs(logs)
                else:
                    # 即使没有日志，也创建空文件以保持目录结构
                    logs_path = self.trajectory_dir / "logs.txt"
                    if not logs_path.exists():
                        logs_path.write_text("", encoding="utf-8")
            except Exception as e:
                logger.warning(f"Failed to save logs: {e}")
                # 即使失败，也尝试创建空文件
                logs_path = self.trajectory_dir / "logs.txt"
                if not logs_path.exists():
                    try:
                        logs_path.write_text("", encoding="utf-8")
                    except Exception:
                        pass  # 如果还是失败，至少记录警告
        except IOError as e:
            # 重新抛出 IOError
            raise
        except Exception as e:
            # 其他异常转换为 IOError
            raise IOError(f"Failed to save trajectory data: {e}") from e

        return self.trajectory_dir
