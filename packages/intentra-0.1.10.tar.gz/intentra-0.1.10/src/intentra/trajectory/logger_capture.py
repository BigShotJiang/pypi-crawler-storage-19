"""
日志捕获处理器

用于捕获 droidrun 输出的所有日志，以便保存到轨迹记录中。
"""

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class LogEntry:
    """日志条目数据模型。"""

    timestamp: str
    level: str
    logger: str
    message: str
    module: Optional[str] = None
    function: Optional[str] = None
    line: Optional[int] = None

    def __post_init__(self):
        """验证数据格式。"""
        if not self.timestamp:
            raise ValueError("timestamp cannot be empty")
        if self.level not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            raise ValueError(f"Invalid log level: {self.level}")
        if not self.message:
            raise ValueError("message cannot be empty")


class LogCaptureHandler(logging.Handler):
    """
    日志捕获处理器，继承 logging.Handler。
    
    用于捕获 droidrun 的日志输出，转换为 LogEntry 并保存到列表中。
    """

    def __init__(self, target_loggers: List[str] | None = None):
        """
        初始化日志捕获处理器。
        
        Args:
            target_loggers: 目标 logger 名称列表（默认为 ["droidrun"]）
                           支持多个 logger，如 ["droidrun", "httpx", "httpcore"]
        """
        super().__init__()
        self.logs: List[LogEntry] = []
        if target_loggers is None:
            target_loggers = ["droidrun"]
        self.target_loggers = target_loggers

    def emit(self, record: logging.LogRecord) -> None:
        """
        处理日志记录，转换为 LogEntry 并添加到列表。
        
        Args:
            record: logging.LogRecord 实例
        """
        # 检查是否匹配任何一个目标 logger
        matched = False
        for target_logger in self.target_loggers:
            if record.name.startswith(target_logger):
                matched = True
                break
        
        if not matched:
            return

        try:
            # 获取消息内容
            message = record.getMessage()
            
            # 跳过空消息，避免验证错误
            if not message or not message.strip():
                return

            # 格式化时间戳为 ISO 8601 格式
            timestamp = datetime.fromtimestamp(record.created).isoformat()

            log_entry = LogEntry(
                timestamp=timestamp,
                level=record.levelname,
                logger=record.name,
                message=message,
                module=record.module,
                function=record.funcName,
                line=record.lineno,
            )

            self.logs.append(log_entry)
        except Exception:
            # 如果转换失败，忽略该日志记录，避免影响正常日志输出
            # 不调用 handleError，避免产生额外的错误日志
            pass

    def get_logs(self) -> List[LogEntry]:
        """
        获取所有捕获的日志条目。
        
        Returns:
            日志条目列表
        """
        return list(self.logs)

    def clear(self) -> None:
        """清空捕获的日志。"""
        self.logs.clear()
