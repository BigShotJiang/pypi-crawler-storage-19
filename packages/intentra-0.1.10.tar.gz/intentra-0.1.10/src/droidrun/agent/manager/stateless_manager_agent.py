"""
StatelessManagerAgent - Stateless planning agent that rebuilds context each turn.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Type

from llama_index.core.llms.llm import LLM
from llama_index.core.workflow import Context, StartEvent, StopEvent, Workflow, step
from pydantic import BaseModel
from opentelemetry import trace

from droidrun.agent.common.events import RecordUIStateEvent, ScreenshotEvent
from droidrun.agent.manager.events import (
    ManagerContextEvent,
    ManagerPlanDetailsEvent,
    ManagerResponseEvent,
)
from droidrun.agent.manager.prompts import parse_manager_response
from droidrun.agent.usage import get_usage_from_response
from droidrun.agent.utils.chat_utils import to_chat_messages
from droidrun.agent.utils.inference import acall_with_retries
from droidrun.agent.utils.tracing_setup import record_langfuse_screenshot
from droidrun.agent.utils.prompt_resolver import PromptResolver
from droidrun.config_manager.prompt_loader import PromptLoader

if TYPE_CHECKING:
    from droidrun.agent.droid import DroidAgentState
    from droidrun.config_manager.config_manager import AgentConfig, TracingConfig
    from droidrun.tools import Tools


logger = logging.getLogger("droidrun")


class StatelessManagerAgent(Workflow):
    def __init__(
        self,
        llm: LLM,
        tools_instance: "Tools | None",
        shared_state: "DroidAgentState",
        agent_config: "AgentConfig",
        custom_tools: dict = None,
        output_model: Type[BaseModel] | None = None,
        prompt_resolver: Optional[PromptResolver] = None,
        tracing_config: "TracingConfig | None" = None,
        vision_llm: LLM | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.llm = llm
        self.vision_llm = vision_llm
        self.config = agent_config.manager
        self.vision = self.config.vision
        self.tools_instance = tools_instance
        self.shared_state = shared_state
        self.custom_tools = custom_tools if custom_tools is not None else {}
        self.output_model = output_model
        self.agent_config = agent_config
        self.prompt_resolver = prompt_resolver or PromptResolver()
        self.tracing_config = tracing_config

        # Initialize auto-vision components if enabled (same as ManagerAgent)
        if self.config.auto_vision and self.config.auto_vision.get("enabled", False):
            from intentra.config.auto_vision import AutoVisionConfig

            auto_vision_config = AutoVisionConfig(
                enabled=True,
                vision_llm_profile=self.config.vision_llm_profile,
            )

            is_valid, error_msg = auto_vision_config.validate()
            if not is_valid:
                logger.warning(f"⚠️ Auto-vision configuration invalid: {error_msg}. Disabling auto-vision.")
            else:
                logger.debug("🔍 Auto-vision enabled (LLM-driven decision)")

    def _build_action_history(self) -> list[dict]:
        if not self.shared_state.action_history:
            return []

        n = min(5, len(self.shared_state.action_history))
        return [
            {
                "action": act,
                "summary": summ,
                "outcome": outcome,
                "error": err,
            }
            for act, summ, outcome, err in zip(
                self.shared_state.action_history[-n:],
                self.shared_state.summary_history[-n:],
                self.shared_state.action_outcomes[-n:],
                self.shared_state.error_descriptions[-n:],
                strict=True,
            )
        ]

    async def _build_prompt(self, has_text_to_modify: bool) -> str:
        # Check if auto-vision is enabled
        auto_vision_enabled = (
            self.config.auto_vision
            and self.config.auto_vision.get("enabled", False)
            and self.vision_llm is not None
        )

        variables = {
            "instruction": self.shared_state.instruction,
            "device_date": await self.tools_instance.get_date(),
            "previous_plan": self.shared_state.previous_plan,
            "previous_state": self.shared_state.previous_formatted_device_state,
            "memory": self.shared_state.memory,
            "last_thought": self.shared_state.last_thought,
            "progress_summary": self.shared_state.progress_summary,
            "action_history": self._build_action_history(),
            "current_state": self.shared_state.formatted_device_state,
            "text_manipulation_enabled": has_text_to_modify,
            "auto_vision_enabled": auto_vision_enabled,
        }

        custom_prompt = self.prompt_resolver.get_prompt("manager_system")
        if custom_prompt:
            return PromptLoader.render_template(custom_prompt, variables)

        return await PromptLoader.load_prompt(
            self.agent_config.get_manager_system_prompt_path(),
            variables,
        )

    async def _validate_and_retry(
        self, messages: list[dict], initial_response: str
    ) -> str:
        output = initial_response
        parsed = parse_manager_response(output)

        max_retries = 3
        retry_count = 0

        # Check if auto-vision is enabled
        auto_vision_enabled = (
            self.config.auto_vision
            and self.config.auto_vision.get("enabled", False)
            and self.vision_llm is not None
        )

        while retry_count < max_retries:
            error_message = None

            # Validate need_vision_analysis field if auto-vision is enabled
            if auto_vision_enabled:
                need_vision = parsed.get("need_vision_analysis")
                if need_vision is None:
                    # Field is missing
                    error_message = (
                        "**MISSING REQUIRED FIELD:** You must include the `<need_vision_analysis>` tag as the **first tag** in your response.\n\n"
                        "**Required format:**\n"
                        "<need_vision_analysis>true</need_vision_analysis>\n"
                        "OR\n"
                        "<need_vision_analysis>false</need_vision_analysis>\n\n"
                        "**Position requirement:** This tag MUST be the very first tag in your response (before `<thought>`).\n\n"
                        "**When to set to true:** When you need visual analysis (finding photos, identifying UI elements, analyzing visual content).\n"
                        "**When to set to false:** When text-only information is sufficient.\n\n"
                        "Please retry with the correct format."
                    )
                elif not output.strip().startswith("<need_vision_analysis>"):
                    # Field exists but not at the start
                    error_message = (
                        "**INCORRECT POSITION:** The `<need_vision_analysis>` tag must be the **first tag** in your response.\n\n"
                        "**Current issue:** The tag is present but not at the beginning of your response.\n\n"
                        "**Required format (must be first):**\n"
                        "<need_vision_analysis>true</need_vision_analysis>\n"
                        "<thought>...</thought>\n"
                        "<plan>...</plan>\n"
                        "...\n\n"
                        "Please move the `<need_vision_analysis>` tag to the very beginning of your response and retry."
                    )
                elif parsed.get("answer") and need_vision:
                    # Check if request_accomplished appears before need_vision_analysis (shouldn't happen if need_vision is true)
                    # This is a logical check - if need_vision is true, we should wait for vision analysis
                    answer_pos = output.find("<request_accomplished")
                    if answer_pos == -1:
                        answer_pos = output.find("<answer")
                    need_vision_pos = output.find("<need_vision_analysis>")
                    if answer_pos != -1 and need_vision_pos != -1 and answer_pos < need_vision_pos:
                        error_message = (
                            "**LOGICAL ERROR:** You set need_vision_analysis='true' but used <request_accomplished> or <answer> before waiting for vision analysis.\n\n"
                            "**Required behavior:**\n"
                            "1. First, output <need_vision_analysis>true</need_vision_analysis>\n"
                            "2. Then, output your <thought> and <plan>\n"
                            "3. Wait for vision analysis results\n"
                            "4. Only then decide if the task is complete and use <request_accomplished> or <answer>\n\n"
                            "**Do NOT** immediately use <request_accomplished success='false'> when you need vision analysis. Wait for the visual information first.\n\n"
                            "Please retry with the correct sequence."
                        )

            if error_message:
                retry_count += 1
                logger.warning(
                    f"Manager response invalid (retry {retry_count}/{max_retries}): need_vision_analysis validation failed"
                )

                # Build retry messages
                retry_messages = messages + [
                    {"role": "assistant", "content": [{"text": output}]},
                    {"role": "user", "content": [{"text": error_message}]},
                ]

                chat_messages = to_chat_messages(retry_messages)

                try:
                    response = await acall_with_retries(
                        self.llm, chat_messages, stream=self.agent_config.streaming
                    )
                    output = response.message.content
                    parsed = parse_manager_response(output)
                except Exception as e:
                    logger.error(f"LLM retry failed: {e}")
                    break
                continue  # Continue to next iteration to re-validate

            if parsed["answer"] and not parsed["plan"]:
                if parsed["success"] is None:
                    error_message = (
                        'You must include success="true" or success="false" attribute '
                        "in the <answer> or <request_accomplished> tag.\n"
                        'Example: <answer success="true">Task completed</answer>\n'
                        "Retry again."
                    )
                else:
                    break
            elif parsed["plan"] and parsed["answer"]:
                error_message = (
                    "You cannot include both <plan> and <answer> tags. "
                    "Use <answer> only when the task is complete.\n"
                    "Retry again."
                )
            elif not parsed["plan"] and not parsed["answer"]:
                error_message = (
                    "You must provide either a <plan> or an <answer>. "
                    "Please provide a plan with numbered steps."
                )
            else:
                break

            if error_message:
                retry_count += 1
                logger.warning(
                    f"Manager response invalid (retry {retry_count}/{max_retries}): {error_message}"
                )

                retry_messages = messages + [
                    {"role": "assistant", "content": [{"text": output}]},
                    {"role": "user", "content": [{"text": error_message}]},
                ]

                chat_messages = to_chat_messages(retry_messages)

                try:
                    response = await acall_with_retries(self.llm, chat_messages)
                    output = response.message.content
                    parsed = parse_manager_response(output)
                except Exception as e:
                    logger.error(f"LLM retry failed: {e}")
                    break

        return output

    @step
    async def prepare_context(
        self, ctx: Context, ev: StartEvent
    ) -> ManagerContextEvent:
        formatted_text, focused_text, a11y_tree, phone_state = (
            await self.tools_instance.get_state()
        )

        self.shared_state.previous_formatted_device_state = (
            self.shared_state.formatted_device_state
        )
        self.shared_state.formatted_device_state = formatted_text
        self.shared_state.focused_text = focused_text
        self.shared_state.a11y_tree = a11y_tree
        self.shared_state.phone_state = phone_state

        self.shared_state.update_current_app(
            package_name=phone_state.get("packageName", "Unknown"),
            activity_name=phone_state.get("currentApp", "Unknown"),
        )

        ctx.write_event_to_stream(RecordUIStateEvent(ui_state=a11y_tree))

        screenshot = None
        if self.vision or (
            hasattr(self.tools_instance, "save_trajectories")
            and self.tools_instance.save_trajectories != "none"
        ):
            try:
                result = await self.tools_instance.take_screenshot()
                if isinstance(result, tuple):
                    success, screenshot = result
                    if not success:
                        screenshot = None
                else:
                    screenshot = result

                if screenshot:
                    # Extract screen dimensions from screenshot (like autoglm does)
                    try:
                        from PIL import Image
                        from io import BytesIO
                        img = Image.open(BytesIO(screenshot))
                        width, height = img.size
                        self.shared_state.width = width
                        self.shared_state.height = height
                        logger.debug(f"📐 Extracted screen dimensions from screenshot: {width}x{height}")
                    except Exception as e:
                        logger.debug(f"Could not extract screen dimensions from screenshot: {e}")
                    
                    ctx.write_event_to_stream(ScreenshotEvent(screenshot=screenshot))
                    parent_span = trace.get_current_span()
                    record_langfuse_screenshot(
                        screenshot,
                        parent_span=parent_span,
                        screenshots_enabled=bool(
                            self.tracing_config
                            and self.tracing_config.langfuse_screenshots
                        ),
                        vision_enabled=self.vision,
                    )
            except Exception as e:
                logger.warning(f"Failed to capture screenshot: {e}")

        focused_text_clean = focused_text.replace("'", "").strip()
        has_text_to_modify = focused_text_clean != ""

        self.shared_state.has_text_to_modify = has_text_to_modify
        self.shared_state.screenshot = screenshot

        event = ManagerContextEvent()
        ctx.write_event_to_stream(event)
        return event

    @step
    async def get_response(
        self, ctx: Context, ev: ManagerContextEvent
    ) -> ManagerResponseEvent:
        """Get LLM response with conditional vision support (stateless version)."""
        has_text_to_modify = self.shared_state.has_text_to_modify
        screenshot = self.shared_state.screenshot

        prompt_text = await self._build_prompt(has_text_to_modify)
        
        # Phase 1: Call standard LLM first (without screenshot)
        messages = [{"role": "user", "content": [{"text": prompt_text}]}]
        chat_messages = to_chat_messages(messages)

        try:
            logger.info("[cyan]Manager response:[/cyan]")
            response = await acall_with_retries(
                self.llm, chat_messages, stream=self.agent_config.streaming
            )
            output = response.message.content
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            raise RuntimeError(f"Error calling LLM in stateless manager: {e}") from e

        usage = None
        try:
            usage = get_usage_from_response(self.llm.class_name(), response)
        except Exception as e:
            logger.warning(f"Could not get usage: {e}")

        # Phase 2: Check if vision mode should be activated based on LLM decision
        should_use_vision_llm = False
        if self.vision_llm:
            # Parse response to get need_vision_analysis field
            parsed = parse_manager_response(output)
            need_vision = parsed.get("need_vision_analysis", False)

            should_use_vision_llm = need_vision

            if should_use_vision_llm:
                logger.info(
                    "🔍 Vision mode requested by LLM via need_vision_analysis flag"
                )

                # Capture screenshot if not already captured
                if not screenshot:
                    try:
                        result = await self.tools_instance.take_screenshot()
                        if isinstance(result, tuple):
                            success, screenshot = result
                            if not success:
                                logger.warning("📸 Screenshot capture failed for vision mode")
                                screenshot = None
                        else:
                            screenshot = result

                        if screenshot:
                            # Extract screen dimensions from screenshot (like autoglm does)
                            try:
                                from PIL import Image
                                from io import BytesIO
                                img = Image.open(BytesIO(screenshot))
                                width, height = img.size
                                self.shared_state.width = width
                                self.shared_state.height = height
                                logger.debug(f"📐 Extracted screen dimensions from vision screenshot: {width}x{height}")
                            except Exception as e:
                                logger.debug(f"Could not extract screen dimensions from vision screenshot: {e}")
                            
                            ctx.write_event_to_stream(ScreenshotEvent(screenshot=screenshot))
                            parent_span = trace.get_current_span()
                            record_langfuse_screenshot(
                                screenshot,
                                parent_span=parent_span,
                                screenshots_enabled=bool(
                                    self.tracing_config
                                    and self.tracing_config.langfuse_screenshots
                                ),
                                vision_enabled=True,
                            )
                            logger.debug("📸 Screenshot captured for vision mode")
                    except Exception as e:
                        logger.warning(f"Failed to capture screenshot for vision mode: {e}")
                        screenshot = None

                # Re-call with vision LLM if screenshot is available
                if screenshot:
                    try:
                        logger.info("[cyan]🔍 Using vision LLM for visual analysis...[/cyan]")
                        
                        # Check if vision_llm is AutoGLM-Phone and use simplified prompt
                        vision_profile_name = self.config.vision_llm_profile
                        is_autoglm_model = False
                        if vision_profile_name:
                            try:
                                # Method 1: Check LLM object attributes
                                if hasattr(self.vision_llm, 'model') and self.vision_llm.model == "AutoGLM-Phone":
                                    is_autoglm_model = True
                                elif hasattr(self.vision_llm, '_model') and self.vision_llm._model == "AutoGLM-Phone":
                                    is_autoglm_model = True
                                # Method 2: Check from config if available
                                elif hasattr(self.agent_config, 'config'):
                                    config = self.agent_config.config
                                    if hasattr(config, 'llm_profiles') and vision_profile_name in config.llm_profiles:
                                        vision_profile = config.llm_profiles[vision_profile_name]
                                        if vision_profile.model == "AutoGLM-Phone":
                                            is_autoglm_model = True
                            except Exception as e:
                                logger.debug(f"Could not check vision profile model: {e}")
                        
                        # Build prompt for vision LLM
                        vision_prompt_text = prompt_text
                        if is_autoglm_model:
                            # Use simplified prompt for AutoGLM-Phone (参考 autoglm 的简洁风格，适合小模型)
                            try:
                                # Get the prompt directory path
                                prompt_dir = Path(self.agent_config.get_manager_system_prompt_path()).parent
                                autoglm_prompt_path = prompt_dir / "system_autoglm_vision.jinja2"
                                
                                vision_prompt_text = await PromptLoader.load_prompt(
                                    str(autoglm_prompt_path),
                                    {
                                        "instruction": self.shared_state.instruction,
                                        "device_date": await self.tools_instance.get_date(),
                                        "memory": self.shared_state.memory or "",
                                        "last_thought": self.shared_state.last_thought or "",
                                    }
                                )
                                logger.debug("📝 Using simplified AutoGLM-Phone prompt for vision LLM")
                            except FileNotFoundError:
                                logger.warning("⚠️ Autoglm prompt template not found, using standard prompt")
                                # Continue with standard prompt_text
                        
                        messages_with_vision = [{"role": "user", "content": [
                            {"text": vision_prompt_text},
                            {"image": screenshot}
                        ]}]
                        
                        # Ensure message format for AutoGLM-Phone (each user message must have text)
                        if is_autoglm_model:
                            from droidrun.agent.utils.vision_llm_adapter import ensure_autoglm_message_format
                            messages_with_vision = ensure_autoglm_message_format(messages_with_vision)
                        
                        chat_messages_vision = to_chat_messages(messages_with_vision)

                        vision_response = await acall_with_retries(
                            self.vision_llm,
                            chat_messages_vision,
                            stream=self.agent_config.streaming,
                        )
                        output = vision_response.message.content

                        # Convert autoglm response format to droidrun format if needed
                        if is_autoglm_model:
                            from droidrun.agent.utils.vision_llm_adapter import convert_autoglm_response
                            try:
                                output = convert_autoglm_response(output)
                                # Mark that current subgoal is from AutoGLM-Phone (for coordinate conversion)
                                self.shared_state.vision_llm_is_autoglm = True
                                logger.debug("✅ Converted autoglm response format to droidrun format")
                            except Exception as e:
                                logger.warning(
                                    f"⚠️ Failed to convert autoglm response format: {e}. "
                                    f"Using original response. Error type: {type(e).__name__}"
                                )
                                # Continue with original output

                        # Update usage from vision LLM call
                        try:
                            vision_usage = get_usage_from_response(
                                self.vision_llm.class_name(), vision_response
                            )
                            if vision_usage:
                                usage = vision_usage
                        except Exception as e:
                            logger.warning(f"Could not get usage from vision LLM: {e}")

                        logger.info("✅ Vision LLM response generated")
                    except Exception as e:
                        logger.warning(
                            f"Vision LLM call failed, using standard LLM response: {e}"
                        )
                        # Continue with original output from standard LLM
                else:
                    logger.warning(
                        "⚠️ Vision mode triggered but screenshot unavailable, using standard LLM response"
                    )
            else:
                logger.debug("📝 No vision analysis requested, using standard LLM")
                # Reset flag since we're using standard LLM (not AutoGLM-Phone)
                self.shared_state.vision_llm_is_autoglm = False

        output = await self._validate_and_retry(messages, output)

        event = ManagerResponseEvent(response=output, usage=usage)
        ctx.write_event_to_stream(event)
        return event

    @step
    async def process_response(
        self, ctx: Context, ev: ManagerResponseEvent
    ) -> ManagerPlanDetailsEvent:
        output = ev.response
        parsed = parse_manager_response(output)

        self.shared_state.previous_plan = parsed["plan"]
        self.shared_state.last_thought = parsed["thought"]

        if parsed.get("progress_summary"):
            self.shared_state.progress_summary = parsed["progress_summary"]

        memory_update = parsed.get("memory", "").strip()
        if memory_update:
            if self.shared_state.memory:
                self.shared_state.memory += "\n" + memory_update
            else:
                self.shared_state.memory = memory_update

        self.shared_state.plan = parsed["plan"]
        self.shared_state.current_subgoal = parsed["current_subgoal"]
        self.shared_state.manager_answer = parsed["answer"]

        event = ManagerPlanDetailsEvent(
            plan=parsed["plan"],
            subgoal=parsed["current_subgoal"],
            thought=parsed["thought"],
            answer=parsed["answer"],
            memory_update=memory_update,
            progress_summary=parsed.get("progress_summary", ""),
            success=parsed["success"],
            full_response=output,
        )
        ctx.write_event_to_stream(event)
        return event

    @step
    async def finalize(self, ctx: Context, ev: ManagerPlanDetailsEvent) -> StopEvent:
        return StopEvent(
            result={
                "plan": ev.plan,
                "current_subgoal": ev.subgoal,
                "thought": ev.thought,
                "manager_answer": ev.answer,
                "memory_update": ev.memory_update,
                "success": ev.success,
            }
        )
