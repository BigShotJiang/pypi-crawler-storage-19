"""
ManagerAgent - Planning and reasoning workflow.

This agent is responsible for:
- Analyzing the current state
- Creating plans and subgoals
- Tracking progress
- Deciding when tasks are complete
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Type

from llama_index.core.llms.llm import LLM
from llama_index.core.workflow import Context, StartEvent, StopEvent, Workflow, step
from pydantic import BaseModel
from opentelemetry import trace

from droidrun.agent.common.events import RecordUIStateEvent, ScreenshotEvent
from droidrun.agent.manager.events import (
    ManagerContextEvent,
    ManagerPlanDetailsEvent,
    ManagerResponseEvent,
)
from droidrun.agent.manager.prompts import parse_manager_response
from droidrun.agent.usage import get_usage_from_response
from droidrun.agent.utils.chat_utils import (
    to_chat_messages,
    filter_empty_messages,
)
import copy
from droidrun.agent.utils.inference import acall_with_retries
from droidrun.agent.utils.tracing_setup import record_langfuse_screenshot
from droidrun.agent.utils.prompt_resolver import PromptResolver
from droidrun.agent.utils.tools import build_custom_tool_descriptions
from droidrun.app_cards.app_card_provider import AppCardProvider
from droidrun.app_cards.providers import (
    CompositeAppCardProvider,
    LocalAppCardProvider,
    ServerAppCardProvider,
)
from droidrun.config_manager.prompt_loader import PromptLoader

if TYPE_CHECKING:
    from droidrun.agent.droid import DroidAgentState
    from droidrun.config_manager.config_manager import AgentConfig, TracingConfig
    from droidrun.tools import Tools


logger = logging.getLogger("droidrun")


class ManagerAgent(Workflow):
    """
    Planning and reasoning agent that decides what to do next.

    The Manager:
    1. Analyzes current device state and action history
    2. Creates plans with specific subgoals
    3. Tracks progress and completed steps
    4. Decides when tasks are complete or need to provide answers
    """

    def __init__(
        self,
        llm: LLM,
        tools_instance: "Tools | None",
        shared_state: "DroidAgentState",
        agent_config: "AgentConfig",
        custom_tools: dict = None,
        output_model: Type[BaseModel] | None = None,
        prompt_resolver: Optional[PromptResolver] = None,
        tracing_config: "TracingConfig | None" = None,
        vision_llm: LLM | None = None,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.llm = llm
        self.vision_llm = vision_llm
        self.config = agent_config.manager
        self.vision = self.config.vision
        self.tools_instance = tools_instance
        self.shared_state = shared_state
        self.custom_tools = custom_tools if custom_tools is not None else {}
        self.output_model = output_model
        self.agent_config = agent_config
        self.app_card_config = self.agent_config.app_cards
        self.prompt_resolver = prompt_resolver or PromptResolver()
        self.tracing_config = tracing_config

        # Initialize app card provider
        self.app_card_provider: AppCardProvider = self._initialize_app_card_provider()

        # Initialize auto-vision components if enabled
        if self.config.auto_vision and self.config.auto_vision.get("enabled", False):
            from intentra.config.auto_vision import AutoVisionConfig

            # Build AutoVisionConfig from manager config
            auto_vision_config = AutoVisionConfig(
                enabled=True,
                vision_llm_profile=self.config.vision_llm_profile,
            )

            # Validate configuration
            is_valid, error_msg = auto_vision_config.validate()
            if not is_valid:
                logger.warning(
                    f"⚠️ Auto-vision configuration invalid: {error_msg}. "
                    f"Disabling auto-vision. Please check your configuration file."
                )
            else:
                logger.debug("🔍 Auto-vision enabled (LLM-driven decision)")

        logger.debug("ManagerAgent initialized.")

    def _initialize_app_card_provider(self) -> AppCardProvider:
        """Initialize app card provider based on configuration mode."""
        if not self.app_card_config.enabled:

            class DisabledProvider(AppCardProvider):
                async def load_app_card(
                    self, package_name: str, instruction: str = ""
                ) -> str:
                    return ""

            return DisabledProvider()

        mode = self.app_card_config.mode.lower()

        if mode == "local":
            return LocalAppCardProvider(
                app_cards_dir=self.app_card_config.app_cards_dir
            )
        elif mode == "server":
            if not self.app_card_config.server_url:
                logger.warning("Server mode but no server_url, falling back to local")
                return LocalAppCardProvider(
                    app_cards_dir=self.app_card_config.app_cards_dir
                )
            return ServerAppCardProvider(
                server_url=self.app_card_config.server_url,
                timeout=self.app_card_config.server_timeout,
                max_retries=self.app_card_config.server_max_retries,
            )
        elif mode == "composite":
            if not self.app_card_config.server_url:
                logger.warning("Composite mode but no server_url, falling back to local")
                return LocalAppCardProvider(
                    app_cards_dir=self.app_card_config.app_cards_dir
                )
            return CompositeAppCardProvider(
                server_url=self.app_card_config.server_url,
                app_cards_dir=self.app_card_config.app_cards_dir,
                server_timeout=self.app_card_config.server_timeout,
                server_max_retries=self.app_card_config.server_max_retries,
            )
        else:
            logger.warning(f"Unknown app_card mode '{mode}', falling back to local")
            return LocalAppCardProvider(
                app_cards_dir=self.app_card_config.app_cards_dir
            )

    async def _build_system_prompt(self, has_text_to_modify: bool) -> str:
        """Build system prompt with all context."""
        # Build error history if needed
        error_history = None
        if self.shared_state.error_flag_plan:
            k = self.shared_state.err_to_manager_thresh
            error_history = [
                {"action": act, "summary": summ, "error": err_des}
                for act, summ, err_des in zip(
                    self.shared_state.action_history[-k:],
                    self.shared_state.summary_history[-k:],
                    self.shared_state.error_descriptions[-k:],
                    strict=True,
                )
            ]

        # Get available secrets
        available_secrets = []
        if (
            hasattr(self.tools_instance, "credential_manager")
            and self.tools_instance.credential_manager
        ):
            available_secrets = await self.tools_instance.credential_manager.get_keys()

        # Output schema if provided
        output_schema = None
        if self.output_model is not None:
            output_schema = self.output_model.model_json_schema()

        # Check if auto-vision is enabled
        auto_vision_enabled = (
            self.config.auto_vision
            and self.config.auto_vision.get("enabled", False)
            and self.vision_llm is not None
        )

        variables = {
            "instruction": self.shared_state.instruction,
            "device_date": await self.tools_instance.get_date(),
            "app_card": self.shared_state.app_card,
            "important_notes": "",  # TODO: implement
            "error_history": error_history,
            "text_manipulation_enabled": has_text_to_modify,
            "custom_tools_descriptions": build_custom_tool_descriptions(
                self.custom_tools
            ),
            "scripter_execution_enabled": self.agent_config.scripter.enabled,
            "scripter_max_steps": self.agent_config.scripter.max_steps,
            "available_secrets": available_secrets,
            "variables": self.shared_state.custom_variables,
            "output_schema": output_schema,
            "auto_vision_enabled": auto_vision_enabled,
        }

        custom_prompt = self.prompt_resolver.get_prompt("manager_system")
        if custom_prompt:
            return PromptLoader.render_template(custom_prompt, variables)
        else:
            return await PromptLoader.load_prompt(
                self.agent_config.get_manager_system_prompt_path(),
                variables,
            )

    def _build_user_message_content(self) -> str:
        """Build user message content with last action context."""
        parts = []

        # Add last thought
        if self.shared_state.last_thought:
            parts.append(f"<thought>\n{self.shared_state.last_thought}\n</thought>\n")

        # Add last action
        if self.shared_state.last_action:
            action_str = json.dumps(self.shared_state.last_action)
            parts.append(f"<last_action>\n{action_str}\n</last_action>\n")

        # Add last action summary
        if self.shared_state.last_summary:
            parts.append(
                f"<last_action_description>\n{self.shared_state.last_summary}\n</last_action_description>\n"
            )

        return "".join(parts)

    def _build_messages_with_context(
        self, system_prompt: str, screenshot: bytes | None = None, force_vision: bool = False
    ) -> list[dict]:
        """
        Build messages from history and inject current context.

        Args:
            system_prompt: System prompt text
            screenshot: Current screenshot if vision enabled

        Returns:
            List of message dicts ready for conversion
        """

        # Start with system message
        messages = [{"role": "system", "content": [{"text": system_prompt}]}]

        # Add accumulated message history (deep copy to avoid mutation)
        messages.extend(copy.deepcopy(self.shared_state.message_history))

        # Find last user message
        user_indices = [i for i, msg in enumerate(messages) if msg["role"] == "user"]

        if user_indices:
            last_user_idx = user_indices[-1]

            # Add memory to last user message
            current_memory = (self.shared_state.memory or "").strip()
            if current_memory:
                messages[last_user_idx]["content"].append(
                    {"text": f"\n<memory>\n{current_memory}\n</memory>\n"}
                )

            # Add current device state
            current_state = self.shared_state.formatted_device_state.strip()
            if current_state:
                messages[last_user_idx]["content"].append(
                    {"text": f"\n<device_state>\n{current_state}\n</device_state>\n"}
                )

            # Add screenshot if vision enabled OR force_vision (for auto-vision mode)
            if screenshot and (self.vision or force_vision):
                messages[last_user_idx]["content"].append({"image": screenshot})

            # Add script result if available
            if self.shared_state.last_scripter_message:
                status = "SUCCESS" if self.shared_state.last_scripter_success else "FAILED"
                script_context = (
                    f'\n<script_result status="{status}">\n'
                    f"{self.shared_state.last_scripter_message}\n"
                    f"</script_result>\n"
                )
                messages[last_user_idx]["content"].append({"text": script_context})
                self.shared_state.last_scripter_message = ""

            # Add previous device state to second-to-last user message
            if len(user_indices) >= 2:
                second_last_idx = user_indices[-2]
                prev_state = self.shared_state.previous_formatted_device_state.strip()
                if prev_state:
                    messages[second_last_idx]["content"].append(
                        {"text": f"\n<device_state>\n{prev_state}\n</device_state>\n"}
                    )

        messages = filter_empty_messages(messages)
        return messages

    async def _validate_and_retry(
        self, messages: list[dict], initial_response: str
    ) -> str:
        """Validate LLM response and retry if needed."""
        output = initial_response
        parsed = parse_manager_response(output)

        max_retries = 3
        retry_count = 0

        # Check if auto-vision is enabled
        auto_vision_enabled = (
            self.config.auto_vision
            and self.config.auto_vision.get("enabled", False)
            and self.vision_llm is not None
        )

        while retry_count < max_retries:
            error_message = None

            # Validate need_vision_analysis field if auto-vision is enabled
            if auto_vision_enabled:
                need_vision = parsed.get("need_vision_analysis")
                if need_vision is None:
                    # Field is missing
                    error_message = (
                        "**MISSING REQUIRED FIELD:** You must include the `<need_vision_analysis>` tag as the **first tag** in your response.\n\n"
                        "**Required format:**\n"
                        "<need_vision_analysis>true</need_vision_analysis>\n"
                        "OR\n"
                        "<need_vision_analysis>false</need_vision_analysis>\n\n"
                        "**Position requirement:** This tag MUST be the very first tag in your response (before `<thought>`).\n\n"
                        "**When to set to true:** When you need visual analysis (finding photos, identifying UI elements, analyzing visual content).\n"
                        "**When to set to false:** When text-only information is sufficient.\n\n"
                        "Please retry with the correct format."
                    )
                elif not output.strip().startswith("<need_vision_analysis>"):
                    # Field exists but not at the start
                    error_message = (
                        "**INCORRECT POSITION:** The `<need_vision_analysis>` tag must be the **first tag** in your response.\n\n"
                        "**Current issue:** The tag is present but not at the beginning of your response.\n\n"
                        "**Required format (must be first):**\n"
                        "<need_vision_analysis>true</need_vision_analysis>\n"
                        "<thought>...</thought>\n"
                        "<plan>...</plan>\n"
                        "...\n\n"
                        "Please move the `<need_vision_analysis>` tag to the very beginning of your response and retry."
                    )
                elif parsed.get("answer") and need_vision:
                    # Check if request_accomplished appears before need_vision_analysis (shouldn't happen if need_vision is true)
                    # This is a logical check - if need_vision is true, we should wait for vision analysis
                    answer_pos = output.find("<request_accomplished")
                    need_vision_pos = output.find("<need_vision_analysis>")
                    if answer_pos != -1 and need_vision_pos != -1 and answer_pos < need_vision_pos:
                        error_message = (
                            "**LOGICAL ERROR:** You set need_vision_analysis='true' but used <request_accomplished> before waiting for vision analysis.\n\n"
                            "**Required behavior:**\n"
                            "1. First, output <need_vision_analysis>true</need_vision_analysis>\n"
                            "2. Then, output your <thought> and <plan>\n"
                            "3. Wait for vision analysis results\n"
                            "4. Only then decide if the task is complete and use <request_accomplished>\n\n"
                            "**Do NOT** immediately use <request_accomplished success='false'> when you need vision analysis. Wait for the visual information first.\n\n"
                            "Please retry with the correct sequence."
                        )

            if error_message:
                retry_count += 1
                logger.warning(
                    f"Manager response invalid (retry {retry_count}/{max_retries}): need_vision_analysis validation failed"
                )

                # Build retry messages
                retry_messages = messages + [
                    {"role": "assistant", "content": [{"text": output}]},
                    {"role": "user", "content": [{"text": error_message}]},
                ]

                chat_messages = to_chat_messages(retry_messages)

                try:
                    response = await acall_with_retries(
                        self.llm, chat_messages, stream=self.agent_config.streaming
                    )
                    output = response.message.content
                    parsed = parse_manager_response(output)
                except Exception as e:
                    logger.error(f"LLM retry failed: {e}")
                    break
                continue  # Continue to next iteration to re-validate

            if parsed["answer"] and not parsed["plan"]:
                if parsed["success"] is None:
                    error_message = (
                        'You must include success="true" or success="false" attribute '
                        "in the <request_accomplished> tag.\n"
                        'Example: <request_accomplished success="true">Task completed</request_accomplished>\n'
                        "Retry again."
                    )
                else:
                    break  # Valid
            elif parsed["plan"] and parsed["answer"]:
                error_message = (
                    "You cannot use both request_accomplished tag while the plan is not finished. "
                    "If you want to use request_accomplished tag, please make sure the plan is finished.\n"
                    "Retry again."
                )
            elif not parsed["plan"]:
                error_message = (
                    "You must provide a plan to complete the task. "
                    "Please provide a plan with the correct format."
                )
            else:
                break  # Valid: plan without answer

            if error_message:
                retry_count += 1
                logger.warning(
                    f"Manager response invalid (retry {retry_count}/{max_retries}): {error_message}"
                )

                # Build retry messages
                retry_messages = messages + [
                    {"role": "assistant", "content": [{"text": output}]},
                    {"role": "user", "content": [{"text": error_message}]},
                ]

                chat_messages = to_chat_messages(retry_messages)

                try:
                    response = await acall_with_retries(
                        self.llm, chat_messages, stream=self.agent_config.streaming
                    )
                    output = response.message.content
                    parsed = parse_manager_response(output)
                except Exception as e:
                    logger.error(f"LLM retry failed: {e}")
                    break

        return output

    # ========================================================================
    # Workflow Steps
    # ========================================================================

    @step
    async def prepare_context(
        self, ctx: Context, ev: StartEvent
    ) -> ManagerContextEvent:
        """Gather context and prepare manager prompt."""
        logger.debug("💬 Preparing manager context...")

        # Get and format device state
        formatted_text, focused_text, a11y_tree, phone_state = (
            await self.tools_instance.get_state()
        )

        # Update shared state (previous ← current, current ← new)
        self.shared_state.previous_formatted_device_state = (
            self.shared_state.formatted_device_state
        )
        self.shared_state.formatted_device_state = formatted_text
        self.shared_state.focused_text = focused_text
        self.shared_state.a11y_tree = a11y_tree
        self.shared_state.phone_state = phone_state

        # Update package/activity tracking
        self.shared_state.update_current_app(
            package_name=phone_state.get("packageName", "Unknown"),
            activity_name=phone_state.get("currentApp", "Unknown"),
        )

        # Stream UI state for trajectory
        ctx.write_event_to_stream(RecordUIStateEvent(ui_state=a11y_tree))

        # Load app card
        if self.app_card_config.enabled:
            try:
                self.shared_state.app_card = await self.app_card_provider.load_app_card(
                    package_name=self.shared_state.current_package_name,
                    instruction=self.shared_state.instruction,
                )
            except Exception as e:
                logger.warning(f"Error loading app card: {e}")
                self.shared_state.app_card = ""
        else:
            self.shared_state.app_card = ""

        # Capture screenshot if needed
        screenshot = None
        if self.vision or (
            hasattr(self.tools_instance, "save_trajectories")
            and self.tools_instance.save_trajectories != "none"
        ):
            try:
                result = await self.tools_instance.take_screenshot()
                if isinstance(result, tuple):
                    success, screenshot = result
                    if not success:
                        logger.warning("📸 Screenshot capture failed")
                        screenshot = None
                else:
                    screenshot = result

                if screenshot:
                    # Extract screen dimensions from screenshot (like autoglm does)
                    try:
                        from PIL import Image
                        from io import BytesIO
                        img = Image.open(BytesIO(screenshot))
                        width, height = img.size
                        self.shared_state.width = width
                        self.shared_state.height = height
                        logger.debug(f"📐 Extracted screen dimensions from screenshot: {width}x{height}")
                    except Exception as e:
                        logger.debug(f"Could not extract screen dimensions from screenshot: {e}")
                    
                    ctx.write_event_to_stream(ScreenshotEvent(screenshot=screenshot))
                    parent_span = trace.get_current_span()
                    record_langfuse_screenshot(
                        screenshot,
                        parent_span=parent_span,
                        screenshots_enabled=bool(
                            self.tracing_config
                            and self.tracing_config.langfuse_screenshots
                        ),
                        vision_enabled=self.vision,
                    )
                    logger.debug("📸 Screenshot captured for Manager")
            except Exception as e:
                logger.warning(f"Failed to capture screenshot: {e}")

        # Detect text manipulation mode
        focused_text_clean = focused_text.replace("'", "").strip()
        has_text_to_modify = focused_text_clean != ""

        # Store for next step
        self.shared_state.has_text_to_modify = has_text_to_modify
        self.shared_state.screenshot = screenshot

        # Build user message and add to history
        user_content = self._build_user_message_content()
        self.shared_state.message_history.append(
            {"role": "user", "content": [{"text": user_content}]}
        )

        event = ManagerContextEvent()
        ctx.write_event_to_stream(event)
        return event

    @step
    async def get_response(
        self, ctx: Context, ev: ManagerContextEvent
    ) -> ManagerResponseEvent:
        """Get LLM response with conditional vision support."""
        logger.debug("🧠 Manager thinking about the plan...")

        has_text_to_modify = self.shared_state.has_text_to_modify
        screenshot = self.shared_state.screenshot

        # Build system prompt
        system_prompt = await self._build_system_prompt(has_text_to_modify)

        # Phase 1: Call standard LLM first (without screenshot for initial response)
        messages = self._build_messages_with_context(
            system_prompt=system_prompt, screenshot=None, force_vision=False
        )
        chat_messages = to_chat_messages(messages)

        try:
            logger.info("[cyan]📋 Manager response:[/cyan]")
            response = await acall_with_retries(
                self.llm, chat_messages, stream=self.agent_config.streaming
            )
            output = response.message.content
        except Exception as e:
            logger.error(f"LLM call failed: {e}")
            raise RuntimeError(f"Error calling LLM in manager: {e}") from e

        # Extract usage from first call
        usage = None
        try:
            usage = get_usage_from_response(self.llm.class_name(), response)
        except Exception as e:
            logger.warning(f"Could not get usage: {e}")

        # Phase 2: Check if vision mode should be activated based on LLM decision
        should_use_vision_llm = False
        if self.vision_llm:
            # Parse response to get need_vision_analysis field
            parsed = parse_manager_response(output)
            need_vision = parsed.get("need_vision_analysis", False)

            should_use_vision_llm = need_vision

            if should_use_vision_llm:
                logger.info(
                    "🔍 Vision mode requested by LLM via need_vision_analysis flag"
                )

                # Capture screenshot if not already captured
                if not screenshot:
                    try:
                        result = await self.tools_instance.take_screenshot()
                        if isinstance(result, tuple):
                            success, screenshot = result
                            if not success:
                                logger.warning("📸 Screenshot capture failed for vision mode")
                                screenshot = None
                        else:
                            screenshot = result

                        if screenshot:
                            # Extract screen dimensions from screenshot (like autoglm does)
                            try:
                                from PIL import Image
                                from io import BytesIO
                                img = Image.open(BytesIO(screenshot))
                                width, height = img.size
                                self.shared_state.width = width
                                self.shared_state.height = height
                                logger.debug(f"📐 Extracted screen dimensions from vision screenshot: {width}x{height}")
                            except Exception as e:
                                logger.debug(f"Could not extract screen dimensions from vision screenshot: {e}")
                            
                            ctx.write_event_to_stream(ScreenshotEvent(screenshot=screenshot))
                            parent_span = trace.get_current_span()
                            record_langfuse_screenshot(
                                screenshot,
                                parent_span=parent_span,
                                screenshots_enabled=bool(
                                    self.tracing_config
                                    and self.tracing_config.langfuse_screenshots
                                ),
                                vision_enabled=True,
                            )
                            logger.debug("📸 Screenshot captured for vision mode")
                    except Exception as e:
                        logger.warning(
                            f"⚠️ Failed to capture screenshot for vision mode: {e}. "
                            f"Falling back to standard LLM response."
                        )
                        screenshot = None

                # Re-call with vision LLM if screenshot is available
                if screenshot:
                    try:
                        logger.info("[cyan]🔍 Using vision LLM for visual analysis...[/cyan]")
                        
                        # Check if vision_llm is AutoGLM-Phone and use simplified prompt
                        vision_profile_name = self.config.vision_llm_profile
                        is_autoglm_model = False
                        if vision_profile_name:
                            # Try to detect AutoGLM-Phone model
                            try:
                                # Method 1: Check LLM object attributes
                                if hasattr(self.vision_llm, 'model') and self.vision_llm.model == "AutoGLM-Phone":
                                    is_autoglm_model = True
                                elif hasattr(self.vision_llm, '_model') and self.vision_llm._model == "AutoGLM-Phone":
                                    is_autoglm_model = True
                                # Method 2: Check from config if available (through agent_config)
                                elif hasattr(self.agent_config, 'config'):
                                    config = self.agent_config.config
                                    if hasattr(config, 'llm_profiles') and vision_profile_name in config.llm_profiles:
                                        vision_profile = config.llm_profiles[vision_profile_name]
                                        if vision_profile.model == "AutoGLM-Phone":
                                            is_autoglm_model = True
                            except Exception as e:
                                logger.debug(f"Could not check vision profile model: {e}")
                        
                        # Build system prompt for vision LLM
                        if is_autoglm_model:
                            # Use simplified prompt for AutoGLM-Phone (参考 autoglm 的简洁风格，适合小模型)
                            try:
                                # Get the prompt directory path
                                prompt_dir = Path(self.agent_config.get_manager_system_prompt_path()).parent
                                autoglm_prompt_path = prompt_dir / "system_autoglm_vision.jinja2"
                                
                                vision_system_prompt = await PromptLoader.load_prompt(
                                    str(autoglm_prompt_path),
                                    {
                                        "instruction": self.shared_state.instruction,
                                        "device_date": await self.tools_instance.get_date(),
                                        "memory": self.shared_state.memory or "",
                                        "last_thought": self.shared_state.last_thought or "",
                                    }
                                )
                                logger.debug("📝 Using simplified AutoGLM-Phone prompt for vision LLM")
                            except FileNotFoundError:
                                logger.warning("⚠️ Autoglm prompt template not found, using standard prompt")
                                vision_system_prompt = system_prompt
                        else:
                            # Use standard system prompt
                            vision_system_prompt = system_prompt
                        
                        messages_with_vision = self._build_messages_with_context(
                            system_prompt=vision_system_prompt,
                            screenshot=screenshot,
                            force_vision=True,
                        )
                        
                        # Ensure message format for AutoGLM-Phone (each user message must have text)
                        if is_autoglm_model:
                            from droidrun.agent.utils.vision_llm_adapter import ensure_autoglm_message_format
                            messages_with_vision = ensure_autoglm_message_format(messages_with_vision)
                        
                        chat_messages_vision = to_chat_messages(messages_with_vision)

                        vision_response = await acall_with_retries(
                            self.vision_llm,
                            chat_messages_vision,
                            stream=self.agent_config.streaming,
                        )
                        output = vision_response.message.content

                        # Convert autoglm response format to droidrun format if needed
                        if is_autoglm_model:
                            from droidrun.agent.utils.vision_llm_adapter import convert_autoglm_response
                            try:
                                output = convert_autoglm_response(output)
                                # Mark that current subgoal is from AutoGLM-Phone (for coordinate conversion)
                                self.shared_state.vision_llm_is_autoglm = True
                                logger.debug("✅ Converted autoglm response format to droidrun format")
                            except Exception as e:
                                logger.warning(
                                    f"⚠️ Failed to convert autoglm response format: {e}. "
                                    f"Using original response. Error type: {type(e).__name__}"
                                )
                                # Continue with original output
                        else:
                            # Reset flag if not using AutoGLM-Phone
                            self.shared_state.vision_llm_is_autoglm = False

                        # Log vision mode usage statistics
                        logger.debug(
                            f"📊 Vision mode statistics: "
                            f"need_vision_analysis={need_vision}"
                        )
                        
                        # Update usage from vision LLM call
                        try:
                            vision_usage = get_usage_from_response(
                                self.vision_llm.class_name(), vision_response
                            )
                            if vision_usage:
                                usage = vision_usage
                        except Exception as e:
                            logger.warning(f"Could not get usage from vision LLM: {e}")

                        logger.info("✅ Vision LLM response generated")
                    except Exception as e:
                        logger.warning(
                            f"⚠️ Vision LLM call failed: {e}. "
                            f"Falling back to standard LLM response. "
                            f"Error type: {type(e).__name__}"
                        )
                        # Continue with original output from standard LLM
                else:
                    logger.warning(
                        "⚠️ Vision mode triggered but screenshot unavailable, using standard LLM response"
                    )
            else:
                logger.debug("📝 No vision analysis requested, using standard LLM")
                # Reset flag since we're using standard LLM (not AutoGLM-Phone)
                self.shared_state.vision_llm_is_autoglm = False

        # Validate and retry if needed
        output = await self._validate_and_retry(messages, output)

        event = ManagerResponseEvent(response=output, usage=usage)
        ctx.write_event_to_stream(event)
        return event

    @step
    async def process_response(
        self, ctx: Context, ev: ManagerResponseEvent
    ) -> ManagerPlanDetailsEvent:
        """Parse LLM response and update state."""
        logger.debug("⚙️ Processing manager response...")

        output = ev.response
        parsed = parse_manager_response(output)

        # Update memory (append)
        memory_update = parsed.get("memory", "").strip()
        if memory_update:
            if self.shared_state.memory:
                self.shared_state.memory += "\n" + memory_update
            else:
                self.shared_state.memory = memory_update

        # Append assistant response to message history
        self.shared_state.message_history.append(
            {"role": "assistant", "content": [{"text": output}]}
        )

        # Update unified state fields
        self.shared_state.previous_plan = self.shared_state.plan
        self.shared_state.plan = parsed["plan"]
        self.shared_state.current_subgoal = parsed["current_subgoal"]
        self.shared_state.last_thought = parsed["thought"]
        self.shared_state.manager_answer = parsed["answer"]
        # Note: vision_llm_is_autoglm flag is set in get_response when AutoGLM-Phone vision LLM is used
        # It will be reset to False in the next get_response call if standard LLM is used

        if parsed.get("progress_summary"):
            self.shared_state.progress_summary = parsed["progress_summary"]

        event = ManagerPlanDetailsEvent(
            plan=parsed["plan"],
            subgoal=parsed["current_subgoal"],
            thought=parsed["thought"],
            answer=parsed["answer"],
            memory_update=memory_update,
            progress_summary=parsed.get("progress_summary", ""),
            success=parsed["success"],
            full_response=output,
        )
        ctx.write_event_to_stream(event)
        return event

    @step
    async def finalize(self, ctx: Context, ev: ManagerPlanDetailsEvent) -> StopEvent:
        logger.debug("✅ Manager planning complete")

        return StopEvent(
            result={
                "plan": ev.plan,
                "current_subgoal": ev.subgoal,
                "thought": ev.thought,
                "manager_answer": ev.answer,
                "memory_update": ev.memory_update,
                "success": ev.success,
            }
        )
