"""
Vision LLM Adapter - 用于适配 AutoGLM-Phone 等特殊 vision LLM 的响应格式。

主要功能：
1. 将 AutoGLM-Phone 的响应格式转换为 droidrun ManagerAgent 期望的格式
2. 处理 autoglm 特有的响应格式（<think>...</think><answer>...</answer> 或 do(action=...)）
"""

import re
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger("droidrun")


def convert_autoglm_response(response: str) -> str:
    """
    将 AutoGLM-Phone 的响应格式转换为 droidrun ManagerAgent 期望的格式。
    
    Autoglm 格式（vision LLM 使用简化格式）:
    <think>...</think>
    <answer>视觉分析结果</answer>
    
    或者直接：
    do(action="Tap", element=[x,y])
    finish(message="...")
    
    转换为 Droidrun 格式:
    <need_vision_analysis>true</need_vision_analysis>
    <thought>...</thought>
    <plan>...</plan>
    <current_subgoal>...</current_subgoal>
    <request_accomplished success="true|false">...</request_accomplished>
    
    Args:
        response: Autoglm 的原始响应文本
        
    Returns:
        转换后的 droidrun 格式响应文本
    """
    if not response or not response.strip():
        logger.warning("⚠️ Empty response from autoglm vision LLM")
        return _build_default_response("视觉分析响应为空")
    
    response = response.strip()
    
    # 提取 thinking 部分（支持多种格式）
    thinking = ""
    
    # 方法1: 尝试提取 <think>...</think> 标签（prompt 中使用的格式）
    reasoning_match = re.search(r'<think>(.*?)</think>', response, re.DOTALL)
    if reasoning_match:
        thinking = reasoning_match.group(1).strip()
    else:
        # 方法2: 尝试提取 <think>...</think> 标签（autoglm 标准格式）
        think_match = re.search(r'<think>(.*?)</think>', response, re.DOTALL)
        if think_match:
            thinking = think_match.group(1).strip()
        else:
            # 方法3: 如果没有标签，尝试提取 do(action= 或 finish( 之前的内容作为 thinking
            if "do(action=" in response:
                thinking = response.split("do(action=")[0].strip()
            elif "finish(message=" in response:
                thinking = response.split("finish(message=")[0].strip()
            else:
                # 如果没有明显的分隔符，使用前100个字符作为 thinking
                thinking = response[:100].strip() if len(response) > 100 else response.strip()
    
    # 提取 answer/analysis 部分
    analysis = ""
    
    # 方法1: 尝试提取 <answer>...</answer> 标签
    answer_match = re.search(r'<answer>(.*?)</answer>', response, re.DOTALL)
    if answer_match:
        analysis = answer_match.group(1).strip()
    else:
        # 方法2: 检查是否是操作指令格式
        if "do(action=" in response:
            # 提取 do(action=...) 部分
            do_match = re.search(r'do\(action="([^"]+)"[^)]*\)', response, re.DOTALL)
            if do_match:
                action_type = do_match.group(1)
                analysis = f"检测到操作指令: {action_type}。但作为视觉分析 LLM，应该只提供视觉分析结果，而不是操作指令。"
            else:
                analysis = "检测到操作指令格式，但无法解析。"
        elif "finish(message=" in response:
            # 提取 finish(message=...) 部分
            finish_match = re.search(r'finish\(message="([^"]+)"\)', response)
            if finish_match:
                finish_msg = finish_match.group(1)
                analysis = f"任务完成: {finish_msg}"
            else:
                analysis = "检测到任务完成信号。"
        else:
            # 方法3: 如果没有 answer 标签，使用整个响应作为分析（去除 thinking 部分）
            if thinking and response.startswith(thinking):
                analysis = response[len(thinking):].strip()
            else:
                analysis = response.strip()
    
    # 如果 analysis 为空，使用 thinking 作为分析
    if not analysis and thinking:
        analysis = thinking
        thinking = "视觉分析完成"
    elif not analysis:
        analysis = "无法提取视觉分析结果"
    
    # 构建 droidrun 格式
    # Droidrun 验证规则：不能同时有 plan 和 request_accomplished
    # - 如果有 plan，表示需要继续执行，不应该有 request_accomplished
    # - 如果有 request_accomplished，表示任务完成，不应该有 plan
    
    result = "<need_vision_analysis>true</need_vision_analysis>\n"
    result += f"<thought>\n{thinking if thinking else '视觉分析完成'}\n</thought>\n"
    
    # 检查是否是 finish 指令（任务完成）
    is_finish = "finish(message=" in response
    
    if is_finish:
        # finish 指令：任务完成，只输出 request_accomplished，不输出 plan
        finish_match = re.search(r'finish\(message="([^"]+)"\)', response)
        finish_msg = finish_match.group(1) if finish_match else analysis
        result += f'<request_accomplished success="true">\n{finish_msg}\n</request_accomplished>'
        logger.debug("✅ Converted autoglm finish response to droidrun format (task completed)")
    else:
        # do 指令或其他格式：需要继续执行，只输出 plan，不输出 request_accomplished
        # 从分析结果中提取关键信息构建 plan
        suggested_action = _extract_suggested_action_from_autoglm_response(response, analysis, thinking)
        
        if suggested_action:
            result += f"<plan>\n1. {suggested_action}\n</plan>\n"
            result += f"<current_subgoal>{suggested_action}</current_subgoal>\n"
        else:
            # 如果没有明确的操作建议，基于视觉分析结果构建 plan
            result += "<plan>\n1. 基于视觉分析继续任务\n</plan>\n"
            result += "<current_subgoal>基于视觉分析继续任务</current_subgoal>\n"
        
        logger.debug("✅ Converted autoglm do/analysis response to droidrun format (continue execution)")
    
    return result


def _extract_suggested_action_from_autoglm_response(response: str, analysis: str, thinking: str) -> Optional[str]:
    """
    从 AutoGLM 响应中提取建议的操作。
    
    优先从 do(action=...) 指令中提取，如果没有则从分析文本中提取。
    
    Args:
        response: AutoGLM 的原始响应文本
        analysis: 提取的分析文本
        thinking: 提取的思考文本
        
    Returns:
        建议的操作描述，如果没有则返回 None
    """
    # 优先从 do(action=...) 指令中提取操作类型
    if "do(action=" in response:
        do_match = re.search(r'do\(action="([^"]+)"', response)
        if do_match:
            action_type = do_match.group(1)
            # 提取坐标或其他参数
            element_match = re.search(r'element=\[(\d+),(\d+)\]', response)
            if element_match:
                x, y = element_match.group(1), element_match.group(2)
                # Droidrun 现在支持直接坐标点击
                # 格式：直接使用坐标，Executor 会调用 click(coordinate=[x, y])
                if action_type.lower() in ["tap", "click"]:
                    return f"点击坐标 ({x}, {y})"
                else:
                    return f"在坐标 ({x}, {y}) 执行 {action_type} 操作"
            else:
                # 检查其他参数
                app_match = re.search(r'app="([^"]+)"', response)
                if app_match:
                    app_name = app_match.group(1)
                    return f"打开应用: {app_name}"
                text_match = re.search(r'text="([^"]+)"', response)
                if text_match:
                    text_content = text_match.group(1)
                    if action_type.lower() in ["type", "type_name"]:
                        return f"输入文本: {text_content[:50]}"
                    else:
                        return f"执行 {action_type} 操作，文本: {text_content[:20]}..."
                return f"执行 {action_type} 操作"
    
    # 如果没有 do 指令，从分析文本中提取
    return _extract_suggested_action(analysis or thinking)


def _extract_suggested_action(analysis: str) -> Optional[str]:
    """
    从视觉分析结果中提取建议的操作。
    
    Args:
        analysis: 视觉分析文本
        
    Returns:
        建议的操作描述，如果没有则返回 None
    """
    # 查找常见的建议操作关键词
    suggestions = {
        "滑动": "滑动查找",
        "点击": "点击目标元素",
        "输入": "输入文本",
        "返回": "返回上一页",
        "搜索": "执行搜索",
        "查找": "查找目标内容",
        "打开": "打开应用或页面",
    }
    
    analysis_lower = analysis.lower()
    for keyword, action in suggestions.items():
        if keyword in analysis_lower:
            return action
    
    # 如果没有找到关键词，尝试从分析中提取第一个动作
    # 例如："建议：滑动查找目标照片" -> "滑动查找目标照片"
    suggestion_match = re.search(r'建议[：:]\s*([^。\n]+)', analysis)
    if suggestion_match:
        return suggestion_match.group(1).strip()
    
    return None


def ensure_autoglm_message_format(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    确保消息格式符合 AutoGLM-Phone API 要求。
    
    AutoGLM-Phone API 要求：
    - 每个 user message 的 content 中必须至少有一个非空的 text 项
    - 不能只有 image 而没有 text
    
    Args:
        messages: 原始消息列表
        
    Returns:
        修复后的消息列表
    """
    fixed_messages = []
    
    for msg in messages:
        fixed_msg = msg.copy()
        
        # 只处理 user 消息
        if msg.get("role") == "user":
            content = msg.get("content", [])
            if isinstance(content, list) and len(content) > 0:
                # 检查是否有 image
                has_image = any(
                    "image" in item
                    for item in content
                    if isinstance(item, dict)
                )
                
                # 检查是否有非空的 text
                has_non_empty_text = any(
                    item.get("text") and item.get("text").strip()
                    for item in content
                    if isinstance(item, dict) and "text" in item
                )
                
                # AutoGLM-Phone API 要求：第一个 content 项必须是非空的 text
                # 如果有 image，确保第一个 content 项是非空的 text
                if has_image:
                    # 检查第一个 content 项
                    first_item = content[0] if content else None
                    
                    if not first_item or not isinstance(first_item, dict):
                        # 第一个项不存在或不是 dict，在开头插入 text
                        fixed_content = [{"text": "Screen analysis request."}] + content
                        fixed_msg["content"] = fixed_content
                        logger.debug("⚠️ Added placeholder text as first content item for AutoGLM-Phone")
                    elif "text" in first_item:
                        # 第一个项是 text
                        first_text = first_item.get("text", "")
                        if not first_text or not first_text.strip():
                            # 第一个 text 是空的，替换它
                            fixed_content = [{"text": "Screen analysis request."}] + content[1:]
                            fixed_msg["content"] = fixed_content
                            logger.debug("⚠️ Replaced empty first text with placeholder for AutoGLM-Phone")
                        # 如果第一个 text 非空，不需要修改
                    else:
                        # 第一个项不是 text（可能是 image），在开头插入 text
                        fixed_content = [{"text": "Screen analysis request."}] + content
                        fixed_msg["content"] = fixed_content
                        logger.debug("⚠️ Added placeholder text as first content item for AutoGLM-Phone")
                elif not has_non_empty_text and len(content) > 0:
                    # 没有 image 但没有非空 text，在开头插入 text（保险起见）
                    fixed_content = [{"text": "Screen analysis request."}] + content
                    fixed_msg["content"] = fixed_content
                    logger.debug("⚠️ Added placeholder text for AutoGLM-Phone user message without text")
        
        fixed_messages.append(fixed_msg)
    
    return fixed_messages


def _build_default_response(message: str) -> str:
    """
    构建默认的 droidrun 格式响应。
    
    Args:
        message: 错误或默认消息
        
    Returns:
        Droidrun 格式的响应文本
    """
    return f"""<need_vision_analysis>true</need_vision_analysis>
<thought>
视觉分析未完成
</thought>
<plan>
1. 重新尝试视觉分析
</plan>
<current_subgoal>重新尝试视觉分析</current_subgoal>
<request_accomplished success="false">
{message}
</request_accomplished>"""
