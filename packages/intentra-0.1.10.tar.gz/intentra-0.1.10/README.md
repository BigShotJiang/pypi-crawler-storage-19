# Intentra

[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)](LICENSE)

Intentra 是一个跨平台的自动化代理框架，支持通过自然语言意图驱动执行移动设备自动化任务。

## 特性

- 🤖 **意图驱动执行**：使用自然语言描述任务，自动转换为设备操作
- 📱 **跨平台支持**：支持 Android 和 iOS 设备
- 🔄 **多执行引擎**：支持 droidrun 和 autoglm 两种执行引擎
- 🎯 **智能视觉分析**：自动判断是否需要视觉分析来完成任务
- 📊 **轨迹记录**：支持记录和回放执行轨迹
- ⚙️ **灵活配置**：支持统一的配置文件格式

## 安装

### 从源码安装

```bash
# 克隆仓库
git clone https://github.com/your-org/intentra.git
cd intentra

# 安装依赖
pip install -e .
```

### 从 PyPI 安装（待发布）

```bash
pip install intentra
```

## 快速开始

### 基本使用

```bash
# 运行一个简单的任务
intentra run "打开设置应用"

# 指定设备
intentra run "打开设置应用" --device emulator-5554

# 使用不同的执行引擎
intentra run "打开设置应用" --plan a  # 使用 droidrun
intentra run "打开设置应用" --plan b  # 使用 autoglm
```

### 查看帮助

```bash
# 查看主命令帮助
intentra --help

# 查看子命令帮助
intentra run --help
intentra devices --help
```

## 系统要求

- Python 3.11 或更高版本
- ADB（Android Debug Bridge）已安装并在 PATH 中（Android 设备）
- 已连接的 Android 或 iOS 设备

## 项目结构

```
intentra/
├── src/
│   ├── intentra/          # Intentra 核心代码
│   ├── droidrun/          # Droidrun 框架集成
│   └── autoglm/           # AutoGLM 框架集成
├── tests/                 # 测试文件
├── pyproject.toml         # 项目配置
├── MANIFEST.in            # 打包清单
└── LICENSE                # 许可证文件
```

## 配置

Intentra 支持统一的配置文件格式。详细配置说明请参考 [配置文档](docs/CONFIG_FILE_USAGE.md)。

示例配置文件：`config_example_unified.yaml`

## 文档

- [CLI 使用指南](docs/CLI_USAGE.md)
- [配置文件使用](docs/CONFIG_FILE_USAGE.md)

## 开发

### 设置开发环境

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 代码格式化
ruff check .
ruff format .
```

### 贡献

欢迎贡献代码！请查看项目的贡献指南。

## 许可证

本项目采用 Apache 2.0 许可证。详情请参阅 [LICENSE](LICENSE) 文件。

## 致谢

- [DroidRun](https://github.com/your-org/droidrun) - Android 自动化框架
- [AutoGLM](https://github.com/your-org/autoglm) - iOS 自动化框架

## 联系方式

- 问题反馈：[GitHub Issues](https://github.com/your-org/intentra/issues)
- 项目主页：[GitHub Repository](https://github.com/your-org/intentra)
