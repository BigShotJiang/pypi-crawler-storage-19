"""
Pydantic models for CLE Engine API requests and responses.
"""

from datetime import date
from typing import Optional, List

from pydantic import BaseModel, Field


class ComputeRequest(BaseModel):
    """Request model for computing CLE due dates."""

    jurisdiction: str = Field(..., description="US state or territory code, e.g. 'CA'")
    profession: str = Field(default="lawyer", description="Licensed profession")
    last_name: Optional[str] = Field(
        default=None, description="Used for surname-based reporting groups"
    )
    birth_date: Optional[date] = Field(default=None, description="Date of birth")
    admission_date: Optional[date] = Field(default=None, description="Date of bar admission")
    reporting_category: Optional[str] = Field(
        default=None,
        description="State-specific reporting category or compliance group identifier",
    )
    reporting_period_end: Optional[date] = Field(
        default=None,
        description="Reporting period end date for states that use fixed multi-year cycles",
    )
    renewal_year: Optional[int] = Field(
        default=None,
        description="Renewal year for jurisdictions that tie CLE compliance to biennial license renewal",
    )

    class Config:
        """Pydantic configuration."""

        json_encoders = {date: lambda v: v.isoformat() if v else None}


class Citation(BaseModel):
    """Citation to source documentation."""

    source_id: str
    excerpt_id: Optional[str] = None
    url: Optional[str] = None


class ComputeResponse(BaseModel):
    """Response model from CLE due date computation."""

    due_date: Optional[date] = None
    cycle_start: Optional[date] = None
    cycle_end: Optional[date] = None
    credits_required: Optional[int] = None
    reporting_group: Optional[str] = None
    cle_required: Optional[bool] = None
    required_fields: List[str] = Field(default_factory=list)
    missing_fields: List[str] = Field(default_factory=list)
    citations: List[Citation] = Field(default_factory=list)
    notes: Optional[str] = None


class HealthResponse(BaseModel):
    """Response from the health check endpoint."""

    status: str


class Jurisdiction(BaseModel):
    """Jurisdiction information."""

    code: str = Field(..., description="State/territory code, e.g. 'CA'")
    name: str = Field(..., description="Full name, e.g. 'California'")
    cle_required: bool = Field(..., description="Whether CLE is mandatory")
    credits_per_cycle: Optional[int] = Field(
        default=None, description="Total credits required per cycle"
    )
    cycle_years: Optional[int] = Field(default=None, description="Length of reporting cycle in years")
