"""
Custom exceptions for the CLE Engine SDK.
"""

from typing import Optional, Any, Dict


class CLEEngineError(Exception):
    """Base exception for all CLE Engine SDK errors."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_body: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_body = response_body or {}

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(CLEEngineError):
    """Raised when API key authentication fails (401/403)."""

    pass


class RateLimitError(CLEEngineError):
    """Raised when API rate limit is exceeded (429)."""

    def __init__(
        self,
        message: str,
        status_code: int = 429,
        response_body: Optional[Dict[str, Any]] = None,
        retry_after: Optional[int] = None,
    ) -> None:
        super().__init__(message, status_code, response_body)
        self.retry_after = retry_after


class ValidationError(CLEEngineError):
    """Raised when request validation fails (400/422)."""

    pass


class ServerError(CLEEngineError):
    """Raised when the server encounters an error (5xx)."""

    pass


class NetworkError(CLEEngineError):
    """Raised when a network-level error occurs."""

    pass
