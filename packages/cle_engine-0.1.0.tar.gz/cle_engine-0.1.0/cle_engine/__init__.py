"""
CLE Engine Python SDK

A Python client library for the CLE Engine API, providing
easy access to continuing legal education deadline computation.
"""

from cle_engine.client import CLEEngineClient
from cle_engine.models import (
    ComputeRequest,
    ComputeResponse,
    Citation,
    HealthResponse,
    Jurisdiction,
)
from cle_engine.exceptions import (
    CLEEngineError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    ServerError,
    NetworkError,
)

__version__ = "0.1.0"
__all__ = [
    "CLEEngineClient",
    "ComputeRequest",
    "ComputeResponse",
    "Citation",
    "HealthResponse",
    "Jurisdiction",
    "CLEEngineError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "NetworkError",
]
