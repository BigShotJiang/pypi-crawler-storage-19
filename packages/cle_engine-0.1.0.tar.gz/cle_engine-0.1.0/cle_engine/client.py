"""
CLE Engine API Client.

Provides a simple interface for interacting with the CLE Engine API.
"""

import os
from datetime import date
from typing import Optional, List, Dict, Any, Union

import requests

from cle_engine.models import (
    ComputeRequest,
    ComputeResponse,
    HealthResponse,
    Jurisdiction,
)
from cle_engine.exceptions import (
    CLEEngineError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    ServerError,
    NetworkError,
)


class CLEEngineClient:
    """
    Client for the CLE Engine API.

    This client provides methods to interact with the CLE Engine API for
    computing continuing legal education (CLE) deadlines across US jurisdictions.

    Example:
        >>> from cle_engine import CLEEngineClient
        >>> client = CLEEngineClient(api_key="your-api-key")
        >>> result = client.compute_due_date(jurisdiction="CA", admission_date="2020-01-15")
        >>> print(result.due_date)
    """

    DEFAULT_BASE_URL = "https://api.cle-engine.com"
    DEFAULT_TIMEOUT = 30

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        """
        Initialize the CLE Engine client.

        Args:
            api_key: API key for authentication. If not provided, will look for
                     CLE_ENGINE_API_KEY environment variable.
            base_url: Base URL for the API. Defaults to https://api.cle-engine.com
                      or CLE_ENGINE_BASE_URL environment variable.
            timeout: Request timeout in seconds. Defaults to 30.

        Raises:
            ValueError: If no API key is provided or found in environment.
        """
        self.api_key = api_key or os.environ.get("CLE_ENGINE_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key is required. Provide it as an argument or set "
                "the CLE_ENGINE_API_KEY environment variable."
            )

        self.base_url = (
            base_url
            or os.environ.get("CLE_ENGINE_BASE_URL")
            or self.DEFAULT_BASE_URL
        ).rstrip("/")

        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "cle-engine-python/0.1.0",
            }
        )

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            json_data: JSON payload for the request

        Returns:
            Parsed JSON response

        Raises:
            AuthenticationError: If authentication fails
            RateLimitError: If rate limit is exceeded
            ValidationError: If request validation fails
            ServerError: If server encounters an error
            NetworkError: If a network error occurs
            CLEEngineError: For other API errors
        """
        url = f"{self.base_url}{endpoint}"

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=json_data,
                timeout=self.timeout,
            )
        except requests.exceptions.Timeout as e:
            raise NetworkError(f"Request timed out: {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}") from e
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Request failed: {e}") from e

        return self._handle_response(response)

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """
        Handle the API response and raise appropriate exceptions.

        Args:
            response: The HTTP response object

        Returns:
            Parsed JSON response

        Raises:
            Various CLEEngineError subclasses based on status code
        """
        try:
            body = response.json() if response.content else {}
        except ValueError:
            body = {"raw_content": response.text}

        if response.ok:
            return body

        error_message = body.get("detail", body.get("message", response.reason))
        status_code = response.status_code

        if status_code == 401:
            raise AuthenticationError(
                "Invalid or missing API key",
                status_code=status_code,
                response_body=body,
            )
        if status_code == 403:
            raise AuthenticationError(
                f"Access forbidden: {error_message}",
                status_code=status_code,
                response_body=body,
            )
        if status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                "Rate limit exceeded",
                status_code=status_code,
                response_body=body,
                retry_after=int(retry_after) if retry_after else None,
            )
        if status_code in (400, 422):
            raise ValidationError(
                f"Validation error: {error_message}",
                status_code=status_code,
                response_body=body,
            )
        if status_code >= 500:
            raise ServerError(
                f"Server error: {error_message}",
                status_code=status_code,
                response_body=body,
            )

        raise CLEEngineError(
            f"API error: {error_message}",
            status_code=status_code,
            response_body=body,
        )

    def health_check(self) -> HealthResponse:
        """
        Check the health status of the API.

        This endpoint does not require authentication.

        Returns:
            HealthResponse with status information

        Example:
            >>> client.health_check()
            HealthResponse(status='ok')
        """
        # Health check doesn't require auth, but we still use session
        url = f"{self.base_url}/health"
        try:
            response = requests.get(url, timeout=self.timeout)
            response.raise_for_status()
            return HealthResponse(**response.json())
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Health check failed: {e}") from e

    def compute_due_date(
        self,
        jurisdiction: str,
        profession: str = "lawyer",
        last_name: Optional[str] = None,
        birth_date: Optional[Union[date, str]] = None,
        admission_date: Optional[Union[date, str]] = None,
        reporting_category: Optional[str] = None,
        reporting_period_end: Optional[Union[date, str]] = None,
        renewal_year: Optional[int] = None,
    ) -> ComputeResponse:
        """
        Compute the CLE due date for a given jurisdiction and attorney.

        Args:
            jurisdiction: US state or territory code (e.g., 'CA', 'NY', 'TX')
            profession: Licensed profession (default: 'lawyer')
            last_name: Attorney's last name (used for surname-based reporting groups)
            birth_date: Date of birth (date object or ISO string 'YYYY-MM-DD')
            admission_date: Date of bar admission (date object or ISO string)
            reporting_category: State-specific reporting category identifier
            reporting_period_end: End date for fixed multi-year cycle states
            renewal_year: Renewal year for biennial renewal jurisdictions

        Returns:
            ComputeResponse containing due date, cycle info, and requirements

        Raises:
            ValidationError: If required fields are missing or invalid
            AuthenticationError: If API key is invalid
            RateLimitError: If rate limit is exceeded

        Example:
            >>> result = client.compute_due_date(
            ...     jurisdiction="CA",
            ...     admission_date="2020-01-15"
            ... )
            >>> print(f"Due date: {result.due_date}")
            >>> print(f"Credits required: {result.credits_required}")
        """

        def to_iso(d: Optional[Union[date, str]]) -> Optional[str]:
            if d is None:
                return None
            if isinstance(d, date):
                return d.isoformat()
            return d

        request_data = ComputeRequest(
            jurisdiction=jurisdiction.upper(),
            profession=profession,
            last_name=last_name,
            birth_date=date.fromisoformat(to_iso(birth_date)) if birth_date else None,
            admission_date=date.fromisoformat(to_iso(admission_date)) if admission_date else None,
            reporting_category=reporting_category,
            reporting_period_end=(
                date.fromisoformat(to_iso(reporting_period_end)) if reporting_period_end else None
            ),
            renewal_year=renewal_year,
        )

        # Build payload, excluding None values
        payload = request_data.model_dump(mode="json", exclude_none=True)

        response_data = self._make_request("POST", "/v1/compute", json_data=payload)
        return ComputeResponse(**response_data)

    def get_jurisdictions(self) -> List[Jurisdiction]:
        """
        Get a list of supported jurisdictions.

        Returns:
            List of Jurisdiction objects with CLE requirements info

        Note:
            This endpoint may not be available in all API versions.
            Check your API documentation for availability.

        Example:
            >>> jurisdictions = client.get_jurisdictions()
            >>> for j in jurisdictions:
            ...     print(f"{j.code}: {j.name} - CLE required: {j.cle_required}")
        """
        response_data = self._make_request("GET", "/v1/jurisdictions")

        # Handle both list response and wrapped response
        if isinstance(response_data, list):
            return [Jurisdiction(**j) for j in response_data]
        jurisdictions_list = response_data.get("jurisdictions", [])
        return [Jurisdiction(**j) for j in jurisdictions_list]

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self) -> "CLEEngineClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        self.close()

    def __repr__(self) -> str:
        """String representation of the client."""
        return f"CLEEngineClient(base_url='{self.base_url}')"
