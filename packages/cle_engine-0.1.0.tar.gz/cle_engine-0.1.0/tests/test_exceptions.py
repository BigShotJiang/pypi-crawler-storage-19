"""Tests for custom exceptions."""

import pytest

from cle_engine.exceptions import (
    CLEEngineError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    ServerError,
    NetworkError,
)


class TestCLEEngineError:
    """Tests for base CLEEngineError."""

    def test_basic_error(self):
        """Test basic error creation."""
        error = CLEEngineError("Something went wrong")
        assert str(error) == "Something went wrong"
        assert error.message == "Something went wrong"
        assert error.status_code is None
        assert error.response_body == {}

    def test_error_with_status_code(self):
        """Test error with status code."""
        error = CLEEngineError("Not found", status_code=404)
        assert str(error) == "[404] Not found"
        assert error.status_code == 404

    def test_error_with_response_body(self):
        """Test error with response body."""
        body = {"detail": "Not found", "code": "RESOURCE_NOT_FOUND"}
        error = CLEEngineError("Not found", status_code=404, response_body=body)
        assert error.response_body == body
        assert error.response_body["code"] == "RESOURCE_NOT_FOUND"


class TestAuthenticationError:
    """Tests for AuthenticationError."""

    def test_is_cle_engine_error(self):
        """Test that it's a subclass of CLEEngineError."""
        error = AuthenticationError("Invalid API key", status_code=401)
        assert isinstance(error, CLEEngineError)
        assert error.status_code == 401

    def test_can_be_caught_as_base_error(self):
        """Test that it can be caught as CLEEngineError."""
        with pytest.raises(CLEEngineError):
            raise AuthenticationError("Invalid API key")


class TestRateLimitError:
    """Tests for RateLimitError."""

    def test_with_retry_after(self):
        """Test rate limit error with retry after."""
        error = RateLimitError(
            "Rate limit exceeded",
            status_code=429,
            retry_after=60,
        )
        assert error.retry_after == 60
        assert error.status_code == 429

    def test_without_retry_after(self):
        """Test rate limit error without retry after."""
        error = RateLimitError("Rate limit exceeded")
        assert error.retry_after is None


class TestValidationError:
    """Tests for ValidationError."""

    def test_validation_error(self):
        """Test validation error."""
        error = ValidationError(
            "Invalid jurisdiction",
            status_code=400,
            response_body={"field": "jurisdiction", "error": "Invalid code"},
        )
        assert error.status_code == 400
        assert error.response_body["field"] == "jurisdiction"


class TestServerError:
    """Tests for ServerError."""

    def test_server_error(self):
        """Test server error."""
        error = ServerError("Internal server error", status_code=500)
        assert error.status_code == 500


class TestNetworkError:
    """Tests for NetworkError."""

    def test_network_error(self):
        """Test network error."""
        error = NetworkError("Connection refused")
        assert "Connection refused" in str(error)
        assert error.status_code is None


class TestExceptionHierarchy:
    """Tests for exception hierarchy."""

    def test_all_inherit_from_base(self):
        """Test that all exceptions inherit from CLEEngineError."""
        errors = [
            AuthenticationError("test"),
            RateLimitError("test"),
            ValidationError("test"),
            ServerError("test"),
            NetworkError("test"),
        ]
        for error in errors:
            assert isinstance(error, CLEEngineError)

    def test_catch_by_base_class(self):
        """Test catching all errors by base class."""
        exceptions_to_raise = [
            AuthenticationError("auth"),
            RateLimitError("rate"),
            ValidationError("validation"),
            ServerError("server"),
            NetworkError("network"),
        ]

        for exc in exceptions_to_raise:
            try:
                raise exc
            except CLEEngineError as e:
                assert e is exc
