"""Tests for the CLEEngineClient."""

import os
from datetime import date
from unittest.mock import patch

import pytest
import responses

from cle_engine import (
    CLEEngineClient,
    ComputeResponse,
    HealthResponse,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    ServerError,
)


TEST_API_KEY = "test-api-key-12345"
TEST_BASE_URL = "https://api.cle-engine.com"


class TestClientInitialization:
    """Tests for client initialization."""

    def test_init_with_api_key(self):
        """Test client initialization with explicit API key."""
        client = CLEEngineClient(api_key=TEST_API_KEY)
        assert client.api_key == TEST_API_KEY
        assert client.base_url == TEST_BASE_URL

    def test_init_with_custom_base_url(self):
        """Test client initialization with custom base URL."""
        custom_url = "https://custom.api.com"
        client = CLEEngineClient(api_key=TEST_API_KEY, base_url=custom_url)
        assert client.base_url == custom_url

    def test_init_strips_trailing_slash(self):
        """Test that trailing slashes are stripped from base URL."""
        client = CLEEngineClient(api_key=TEST_API_KEY, base_url="https://api.test.com/")
        assert client.base_url == "https://api.test.com"

    def test_init_from_environment(self):
        """Test client initialization from environment variables."""
        with patch.dict(os.environ, {"CLE_ENGINE_API_KEY": "env-api-key"}):
            client = CLEEngineClient()
            assert client.api_key == "env-api-key"

    def test_init_missing_api_key_raises(self):
        """Test that missing API key raises ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            # Ensure the env var is not set
            os.environ.pop("CLE_ENGINE_API_KEY", None)
            with pytest.raises(ValueError, match="API key is required"):
                CLEEngineClient()

    def test_context_manager(self):
        """Test client as context manager."""
        with CLEEngineClient(api_key=TEST_API_KEY) as client:
            assert client.api_key == TEST_API_KEY

    def test_repr(self):
        """Test string representation."""
        client = CLEEngineClient(api_key=TEST_API_KEY)
        assert "CLEEngineClient" in repr(client)
        assert TEST_BASE_URL in repr(client)


class TestHealthCheck:
    """Tests for the health check endpoint."""

    @responses.activate
    def test_health_check_success(self):
        """Test successful health check."""
        responses.add(
            responses.GET,
            f"{TEST_BASE_URL}/health",
            json={"status": "ok"},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.health_check()

        assert isinstance(result, HealthResponse)
        assert result.status == "ok"

    @responses.activate
    def test_health_check_server_error(self):
        """Test health check with server error."""
        responses.add(
            responses.GET,
            f"{TEST_BASE_URL}/health",
            json={"error": "Internal Server Error"},
            status=500,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(Exception):
            client.health_check()


class TestComputeDueDate:
    """Tests for the compute_due_date method."""

    @responses.activate
    def test_compute_due_date_basic(self):
        """Test basic due date computation."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={
                "due_date": "2025-12-31",
                "cycle_start": "2024-01-01",
                "cycle_end": "2025-12-31",
                "credits_required": 25,
                "cle_required": True,
                "required_fields": ["admission_date"],
                "missing_fields": [],
                "citations": [],
            },
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.compute_due_date(
            jurisdiction="CA",
            admission_date="2020-01-15",
        )

        assert isinstance(result, ComputeResponse)
        assert result.due_date == date(2025, 12, 31)
        assert result.credits_required == 25
        assert result.cle_required is True

    @responses.activate
    def test_compute_due_date_with_date_objects(self):
        """Test computation with date objects instead of strings."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={
                "due_date": "2025-12-31",
                "cle_required": True,
            },
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.compute_due_date(
            jurisdiction="CA",
            admission_date=date(2020, 1, 15),
            birth_date=date(1990, 6, 15),
        )

        assert result.due_date == date(2025, 12, 31)

        # Verify the request was made with correct format
        assert len(responses.calls) == 1
        request_body = responses.calls[0].request.body
        assert "2020-01-15" in request_body
        assert "1990-06-15" in request_body

    @responses.activate
    def test_compute_due_date_jurisdiction_uppercase(self):
        """Test that jurisdiction is uppercased."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"cle_required": True},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        client.compute_due_date(jurisdiction="ca")

        # Verify the request was made with uppercase jurisdiction
        assert len(responses.calls) == 1
        request_body = responses.calls[0].request.body
        assert '"jurisdiction":"CA"' in request_body or '"jurisdiction": "CA"' in request_body

    @responses.activate
    def test_compute_due_date_all_parameters(self):
        """Test computation with all optional parameters."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"cle_required": True, "reporting_group": "A-L"},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.compute_due_date(
            jurisdiction="NY",
            profession="lawyer",
            last_name="Smith",
            birth_date="1985-03-20",
            admission_date="2015-05-01",
            reporting_category="Group1",
            reporting_period_end="2025-03-31",
            renewal_year=2025,
        )

        assert result.reporting_group == "A-L"


class TestErrorHandling:
    """Tests for error handling."""

    @responses.activate
    def test_authentication_error_401(self):
        """Test 401 authentication error."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Invalid API key"},
            status=401,
        )

        client = CLEEngineClient(api_key="invalid-key")
        with pytest.raises(AuthenticationError) as exc_info:
            client.compute_due_date(jurisdiction="CA")

        assert exc_info.value.status_code == 401
        assert "Invalid" in str(exc_info.value)

    @responses.activate
    def test_authentication_error_403(self):
        """Test 403 forbidden error."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Subscription expired"},
            status=403,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(AuthenticationError) as exc_info:
            client.compute_due_date(jurisdiction="CA")

        assert exc_info.value.status_code == 403

    @responses.activate
    def test_rate_limit_error(self):
        """Test rate limit error with retry-after header."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Rate limit exceeded"},
            status=429,
            headers={"Retry-After": "60"},
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(RateLimitError) as exc_info:
            client.compute_due_date(jurisdiction="CA")

        assert exc_info.value.status_code == 429
        assert exc_info.value.retry_after == 60

    @responses.activate
    def test_validation_error_400(self):
        """Test validation error."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Invalid jurisdiction code"},
            status=400,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(ValidationError) as exc_info:
            client.compute_due_date(jurisdiction="INVALID")

        assert exc_info.value.status_code == 400

    @responses.activate
    def test_validation_error_422(self):
        """Test 422 unprocessable entity error."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Missing required field"},
            status=422,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(ValidationError) as exc_info:
            client.compute_due_date(jurisdiction="CA")

        assert exc_info.value.status_code == 422

    @responses.activate
    def test_server_error(self):
        """Test server error."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"detail": "Internal server error"},
            status=500,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        with pytest.raises(ServerError) as exc_info:
            client.compute_due_date(jurisdiction="CA")

        assert exc_info.value.status_code == 500


class TestGetJurisdictions:
    """Tests for the get_jurisdictions method."""

    @responses.activate
    def test_get_jurisdictions_list_response(self):
        """Test getting jurisdictions with list response."""
        responses.add(
            responses.GET,
            f"{TEST_BASE_URL}/v1/jurisdictions",
            json=[
                {
                    "code": "CA",
                    "name": "California",
                    "cle_required": True,
                    "credits_per_cycle": 25,
                    "cycle_years": 3,
                },
                {
                    "code": "SD",
                    "name": "South Dakota",
                    "cle_required": False,
                },
            ],
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.get_jurisdictions()

        assert len(result) == 2
        assert result[0].code == "CA"
        assert result[0].cle_required is True
        assert result[1].code == "SD"
        assert result[1].cle_required is False

    @responses.activate
    def test_get_jurisdictions_wrapped_response(self):
        """Test getting jurisdictions with wrapped response."""
        responses.add(
            responses.GET,
            f"{TEST_BASE_URL}/v1/jurisdictions",
            json={
                "jurisdictions": [
                    {"code": "NY", "name": "New York", "cle_required": True},
                ]
            },
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        result = client.get_jurisdictions()

        assert len(result) == 1
        assert result[0].code == "NY"


class TestRequestHeaders:
    """Tests for request headers."""

    @responses.activate
    def test_api_key_header(self):
        """Test that API key is sent in header."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"cle_required": True},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        client.compute_due_date(jurisdiction="CA")

        assert len(responses.calls) == 1
        request = responses.calls[0].request
        assert request.headers["X-API-Key"] == TEST_API_KEY

    @responses.activate
    def test_content_type_header(self):
        """Test that content type is set correctly."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"cle_required": True},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        client.compute_due_date(jurisdiction="CA")

        request = responses.calls[0].request
        assert "application/json" in request.headers["Content-Type"]

    @responses.activate
    def test_user_agent_header(self):
        """Test that user agent is set."""
        responses.add(
            responses.POST,
            f"{TEST_BASE_URL}/v1/compute",
            json={"cle_required": True},
            status=200,
        )

        client = CLEEngineClient(api_key=TEST_API_KEY)
        client.compute_due_date(jurisdiction="CA")

        request = responses.calls[0].request
        assert "cle-engine-python" in request.headers["User-Agent"]
