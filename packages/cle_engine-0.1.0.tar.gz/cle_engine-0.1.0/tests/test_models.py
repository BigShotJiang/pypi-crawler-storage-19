"""Tests for the Pydantic models."""

from datetime import date

import pytest

from cle_engine.models import (
    ComputeRequest,
    ComputeResponse,
    Citation,
    HealthResponse,
    Jurisdiction,
)


class TestComputeRequest:
    """Tests for ComputeRequest model."""

    def test_minimal_request(self):
        """Test request with only required field."""
        request = ComputeRequest(jurisdiction="CA")
        assert request.jurisdiction == "CA"
        assert request.profession == "lawyer"
        assert request.last_name is None

    def test_full_request(self):
        """Test request with all fields."""
        request = ComputeRequest(
            jurisdiction="NY",
            profession="lawyer",
            last_name="Smith",
            birth_date=date(1985, 3, 20),
            admission_date=date(2015, 5, 1),
            reporting_category="Group1",
            reporting_period_end=date(2025, 3, 31),
            renewal_year=2025,
        )
        assert request.jurisdiction == "NY"
        assert request.last_name == "Smith"
        assert request.birth_date == date(1985, 3, 20)
        assert request.renewal_year == 2025

    def test_json_serialization(self):
        """Test JSON serialization of dates."""
        request = ComputeRequest(
            jurisdiction="CA",
            admission_date=date(2020, 1, 15),
        )
        json_dict = request.model_dump(mode="json")
        assert json_dict["admission_date"] == "2020-01-15"

    def test_exclude_none_serialization(self):
        """Test that None values can be excluded."""
        request = ComputeRequest(jurisdiction="CA")
        json_dict = request.model_dump(mode="json", exclude_none=True)
        assert "last_name" not in json_dict
        assert "birth_date" not in json_dict
        assert "jurisdiction" in json_dict


class TestComputeResponse:
    """Tests for ComputeResponse model."""

    def test_minimal_response(self):
        """Test response with minimal fields."""
        response = ComputeResponse()
        assert response.due_date is None
        assert response.required_fields == []
        assert response.citations == []

    def test_full_response(self):
        """Test response with all fields populated."""
        response = ComputeResponse(
            due_date=date(2025, 12, 31),
            cycle_start=date(2024, 1, 1),
            cycle_end=date(2025, 12, 31),
            credits_required=25,
            reporting_group="A-L",
            cle_required=True,
            required_fields=["admission_date"],
            missing_fields=[],
            citations=[
                Citation(source_id="ca-mcle-rules", url="https://example.com")
            ],
            notes="Standard 3-year cycle",
        )
        assert response.due_date == date(2025, 12, 31)
        assert response.credits_required == 25
        assert len(response.citations) == 1
        assert response.citations[0].source_id == "ca-mcle-rules"

    def test_response_from_dict(self):
        """Test creating response from dictionary (API response)."""
        data = {
            "due_date": "2025-12-31",
            "cle_required": True,
            "credits_required": 25,
            "missing_fields": ["birth_date"],
        }
        response = ComputeResponse(**data)
        assert response.due_date == date(2025, 12, 31)
        assert response.missing_fields == ["birth_date"]


class TestCitation:
    """Tests for Citation model."""

    def test_minimal_citation(self):
        """Test citation with only required field."""
        citation = Citation(source_id="test-source")
        assert citation.source_id == "test-source"
        assert citation.excerpt_id is None
        assert citation.url is None

    def test_full_citation(self):
        """Test citation with all fields."""
        citation = Citation(
            source_id="ny-cle-rules",
            excerpt_id="section-1500",
            url="https://nycourts.gov/cle",
        )
        assert citation.source_id == "ny-cle-rules"
        assert citation.excerpt_id == "section-1500"


class TestHealthResponse:
    """Tests for HealthResponse model."""

    def test_health_response(self):
        """Test health response creation."""
        response = HealthResponse(status="ok")
        assert response.status == "ok"


class TestJurisdiction:
    """Tests for Jurisdiction model."""

    def test_minimal_jurisdiction(self):
        """Test jurisdiction with required fields only."""
        jurisdiction = Jurisdiction(
            code="CA",
            name="California",
            cle_required=True,
        )
        assert jurisdiction.code == "CA"
        assert jurisdiction.name == "California"
        assert jurisdiction.credits_per_cycle is None

    def test_full_jurisdiction(self):
        """Test jurisdiction with all fields."""
        jurisdiction = Jurisdiction(
            code="CA",
            name="California",
            cle_required=True,
            credits_per_cycle=25,
            cycle_years=3,
        )
        assert jurisdiction.credits_per_cycle == 25
        assert jurisdiction.cycle_years == 3

    def test_non_mandatory_jurisdiction(self):
        """Test jurisdiction where CLE is not mandatory."""
        jurisdiction = Jurisdiction(
            code="SD",
            name="South Dakota",
            cle_required=False,
        )
        assert jurisdiction.cle_required is False
