class FFmpegNormalizeError(Exception):
    pass
