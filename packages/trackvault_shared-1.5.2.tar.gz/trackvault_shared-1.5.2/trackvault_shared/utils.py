"""
Shared utility functions for TrackVault microservices
"""

import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime

def setup_logging(service_name: str, level: str = "INFO") -> logging.Logger:
    """
    Setup standardized logging for microservices
    
    Args:
        service_name: Name of the service
        level: Logging level (DEBUG, INFO, WARNING, ERROR)
        
    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(service_name)
    logger.setLevel(getattr(logging, level.upper()))
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    # Add handler if not already added
    if not logger.handlers:
        logger.addHandler(console_handler)
    
    return logger

def get_redis_url() -> str:
    """
    Get Redis URL from environment variables
    
    Returns:
        Redis connection URL
    """
    return os.getenv("REDIS_URL", "redis://localhost:6379/0")

def get_service_config() -> Dict[str, Any]:
    """
    Get common service configuration
    
    Returns:
        Dictionary with service configuration
    """
    return {
        "redis_url": get_redis_url(),
        "log_level": os.getenv("LOG_LEVEL", "INFO"),
        "environment": os.getenv("ENVIRONMENT", "development"),
        "service_version": os.getenv("SERVICE_VERSION", "1.0.0"),
    }

def format_event_data(event_type: str, data: Dict[str, Any], source_service: str) -> Dict[str, Any]:
    """
    Format event data with standard fields
    
    Args:
        event_type: Type of event
        data: Event payload
        source_service: Name of source service
        
    Returns:
        Formatted event data
    """
    return {
        "event_type": event_type,
        "data": data,
        "timestamp": datetime.utcnow().isoformat(),
        "source_service": source_service,
        "event_id": f"{source_service}_{int(datetime.utcnow().timestamp())}"
    }
