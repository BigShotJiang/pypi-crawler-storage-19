"""
Redis-Based Rate Limiter for Stateless Horizontal Scaling
Time Complexity: O(1) per request check
Space Complexity: O(n) where n = unique clients (stored in Redis)
"""
import redis.asyncio as aioredis
import os
import time
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class RedisRateLimiter:
    """
    Redis-based rate limiter using sliding window algorithm
    Supports stateless horizontal scaling - all instances share the same Redis state
    """
    
    def __init__(self, redis_url: str):
        """
        Initialize Redis rate limiter
        
        Args:
            redis_url: Redis connection URL
        """
        self.redis_url = redis_url
        self.redis: Optional[aioredis.Redis] = None
        self._connection_lock = False
    
    async def _get_redis(self) -> aioredis.Redis:
        """Get or create Redis connection"""
        if self.redis is None or await self.redis.ping() is False:
            max_connections = int(os.getenv("REDIS_MAX_CONNECTIONS", "20"))
            self.redis = await aioredis.from_url(
                self.redis_url,
                decode_responses=True,
                max_connections=max_connections
            )
        return self.redis
    
    async def check_rate_limit(
        self,
        client_id: str,
        limit_type: str,  # 'service', 'user', 'internal'
        max_requests: int,
        window_seconds: int
    ) -> Tuple[bool, int, Optional[int]]:
        """
        Check rate limit using Redis sliding window
        
        Args:
            client_id: Unique client identifier (IP, user_id, etc.)
            limit_type: Type of limit ('service', 'user', 'internal')
            max_requests: Maximum requests allowed in window
            window_seconds: Time window in seconds
            
        Returns:
            (allowed, remaining, retry_after_seconds)
        """
        try:
            redis_client = await self._get_redis()
            now = int(time.time())
            window_start = now - window_seconds
            
            # Create rate limit key
            rate_key = f"rate_limit:{limit_type}:{client_id}"
            
            # Get current requests in window using sorted set
            # Remove old entries (before window_start)
            await redis_client.zremrangebyscore(rate_key, 0, window_start)
            
            # Count current requests in window
            current_count = await redis_client.zcard(rate_key)
            
            if current_count < max_requests:
                # Allow request - add current timestamp
                await redis_client.zadd(rate_key, {str(now): now})
                await redis_client.expire(rate_key, window_seconds + 10)  # Add buffer
                
                remaining = max_requests - current_count - 1
                return True, remaining, None
            else:
                # Rate limited - calculate retry after
                # Get oldest timestamp in window
                oldest = await redis_client.zrange(rate_key, 0, 0, withscores=True)
                if oldest:
                    oldest_time = int(oldest[0][1])
                    retry_after = window_seconds - (now - oldest_time) + 1
                else:
                    retry_after = window_seconds
                
                return False, 0, retry_after
                
        except Exception as e:
            # Fail open - allow request if Redis is unavailable
            logger.error(f"Redis rate limiter error: {e}")
            return True, max_requests, None
    
    async def close(self):
        """Close Redis connection"""
        if self.redis:
            await self.redis.close()
            self.redis = None


# Global rate limiter instance (lazy initialization)
_global_rate_limiter: Optional[RedisRateLimiter] = None


def get_rate_limiter(redis_url: str = None) -> RedisRateLimiter:
    """
    Get global Redis rate limiter instance
    
    Args:
        redis_url: Redis URL (uses REDIS_URL env var if not provided)
    """
    global _global_rate_limiter
    
    if _global_rate_limiter is None:
        if redis_url is None:
            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        _global_rate_limiter = RedisRateLimiter(redis_url)
    
    return _global_rate_limiter

