"""
RBAC Role Definitions for TrackVault Multi-Tenant SaaS Platform

This module defines the global role hierarchy and role-based permissions.
Source of truth for RBAC is WORKSPACE membership, not tenant.

Roles (from highest to lowest privilege):
1. Owner - Full system control, cannot be deleted or downgraded
2. Admin - Same operational privileges as Owner, cannot manage Admins
3. Manager - Manages projects, VAPT workflows, and collaboration
4. Member - Execution-focused, can create and manage owned resources
5. Guest - Explicitly restricted, sandboxed role

CRITICAL: All RBAC checks must be workspace-scoped, not tenant-scoped.
"""

from enum import Enum
from typing import Set, Dict, List, Optional
from pydantic import BaseModel, Field


class Role(str, Enum):
    """
    Global role enumeration for TrackVault platform.
    
    Role hierarchy (from highest to lowest privilege):
    OWNER > ADMIN > MANAGER > MEMBER > GUEST
    """
    OWNER = "owner"
    ADMIN = "admin"
    MANAGER = "manager"
    MEMBER = "member"
    GUEST = "guest"
    
    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def from_string(cls, role_str: str) -> "Role":
        """Convert string to Role enum (case-insensitive)"""
        try:
            return cls(role_str.lower())
        except ValueError:
            raise ValueError(
                f"Invalid role: {role_str}. "
                f"Valid roles: {', '.join([r.value for r in cls])}"
            )
    
    @property
    def hierarchy_level(self) -> int:
        """
        Get numeric hierarchy level (higher = more privileged).
        Used for role comparison and permission inheritance.
        """
        hierarchy = {
            Role.OWNER: 5,
            Role.ADMIN: 4,
            Role.MANAGER: 3,
            Role.MEMBER: 2,
            Role.GUEST: 1,
        }
        return hierarchy[self]
    
    def has_higher_privilege_than(self, other: "Role") -> bool:
        """Check if this role has higher privilege than another role"""
        return self.hierarchy_level > other.hierarchy_level
    
    def has_equal_or_higher_privilege_than(self, other: "Role") -> bool:
        """Check if this role has equal or higher privilege than another role"""
        return self.hierarchy_level >= other.hierarchy_level


class RoleCapabilities(BaseModel):
    """
    Defines what each role can do globally across all services.
    This is the source of truth for role-based capabilities.
    """
    role: Role = Field(..., description="The role these capabilities apply to")
    can_manage_admins: bool = Field(False, description="Can add/remove admin users")
    can_delete_owner: bool = Field(False, description="Can delete or downgrade the owner")
    can_create_projects: bool = Field(False, description="Can create new projects")
    can_delete_any_project: bool = Field(False, description="Can delete any project regardless of ownership")
    can_delete_owned_projects: bool = Field(False, description="Can delete projects they created")
    can_edit_any_project: bool = Field(False, description="Can edit any project")
    can_create_tasks: bool = Field(False, description="Can create tasks")
    can_edit_any_task: bool = Field(False, description="Can edit any task")
    can_delete_any_task: bool = Field(False, description="Can delete any task")
    can_delete_owned_tasks: bool = Field(False, description="Can delete tasks they created")
    can_create_milestones: bool = Field(False, description="Can create milestones")
    can_delete_owned_milestones: bool = Field(False, description="Can delete milestones they created")
    can_delete_any_milestone: bool = Field(False, description="Can delete any milestone")
    can_create_templates: bool = Field(False, description="Can create task templates")
    can_manage_labels: bool = Field(False, description="Can create and edit labels")
    can_comment: bool = Field(False, description="Can create comments on tasks/milestones")
    can_delete_any_comment: bool = Field(False, description="Can delete any comment")
    can_submit_vulnerabilities: bool = Field(False, description="Can submit VAPT vulnerabilities")
    can_edit_any_vulnerability: bool = Field(False, description="Can edit any vulnerability")
    can_edit_owned_vulnerabilities: bool = Field(False, description="Can edit vulnerabilities they submitted")
    can_manage_vapt_templates: bool = Field(False, description="Can manage VAPT templates")
    can_delete_vapt_templates: bool = Field(False, description="Can delete VAPT templates")
    can_manage_assets: bool = Field(False, description="Can create/edit VAPT assets")
    can_generate_reports: bool = Field(False, description="Can generate/download reports")
    can_create_channels: bool = Field(False, description="Can create chat channels")
    can_archive_channels: bool = Field(False, description="Can archive chat channels")
    can_delete_channels: bool = Field(False, description="Can permanently delete channels")
    can_create_kb_collections: bool = Field(False, description="Can create knowledge base collections")
    can_edit_kb_documents: bool = Field(False, description="Can edit knowledge base documents")
    can_delete_owned_kb_items: bool = Field(False, description="Can delete KB items they created")
    can_delete_any_kb_item: bool = Field(False, description="Can delete any KB item")
    is_sandboxed: bool = Field(False, description="Whether this role is restricted to explicitly granted resources")


# Role Capabilities Matrix (Source of Truth)
ROLE_CAPABILITIES: Dict[Role, RoleCapabilities] = {
    Role.OWNER: RoleCapabilities(
        role=Role.OWNER,
        can_manage_admins=True,
        can_delete_owner=False,  # Owner cannot be deleted
        can_create_projects=True,
        can_delete_any_project=True,
        can_delete_owned_projects=True,
        can_edit_any_project=True,
        can_create_tasks=True,
        can_edit_any_task=True,
        can_delete_any_task=True,
        can_delete_owned_tasks=True,
        can_create_milestones=True,
        can_delete_owned_milestones=True,
        can_delete_any_milestone=True,
        can_create_templates=True,
        can_manage_labels=True,
        can_comment=True,
        can_delete_any_comment=True,
        can_submit_vulnerabilities=True,
        can_edit_any_vulnerability=True,
        can_edit_owned_vulnerabilities=True,
        can_manage_vapt_templates=True,
        can_delete_vapt_templates=True,
        can_manage_assets=True,
        can_generate_reports=True,
        can_create_channels=True,
        can_archive_channels=True,
        can_delete_channels=True,
        can_create_kb_collections=True,
        can_edit_kb_documents=True,
        can_delete_owned_kb_items=True,
        can_delete_any_kb_item=True,
        is_sandboxed=False,
    ),
    Role.ADMIN: RoleCapabilities(
        role=Role.ADMIN,
        can_manage_admins=False,  # CRITICAL: Admin cannot add/remove other Admins
        can_delete_owner=False,   # CRITICAL: Admin cannot delete or downgrade Owner
        can_create_projects=True,
        can_delete_any_project=True,
        can_delete_owned_projects=True,
        can_edit_any_project=True,
        can_create_tasks=True,
        can_edit_any_task=True,
        can_delete_any_task=True,
        can_delete_owned_tasks=True,
        can_create_milestones=True,
        can_delete_owned_milestones=True,
        can_delete_any_milestone=True,
        can_create_templates=True,
        can_manage_labels=True,
        can_comment=True,
        can_delete_any_comment=True,
        can_submit_vulnerabilities=True,
        can_edit_any_vulnerability=True,
        can_edit_owned_vulnerabilities=True,
        can_manage_vapt_templates=True,
        can_delete_vapt_templates=True,
        can_manage_assets=True,
        can_generate_reports=True,
        can_create_channels=True,
        can_archive_channels=True,
        can_delete_channels=False,  # Only Owner can permanently delete channels
        can_create_kb_collections=True,
        can_edit_kb_documents=True,
        can_delete_owned_kb_items=True,
        can_delete_any_kb_item=True,
        is_sandboxed=False,
    ),
    Role.MANAGER: RoleCapabilities(
        role=Role.MANAGER,
        can_manage_admins=False,
        can_delete_owner=False,
        can_create_projects=True,
        can_delete_any_project=False,  # Configurable via settings
        can_delete_owned_projects=True,
        can_edit_any_project=True,
        can_create_tasks=True,
        can_edit_any_task=True,
        can_delete_any_task=True,
        can_delete_owned_tasks=True,
        can_create_milestones=True,
        can_delete_owned_milestones=True,
        can_delete_any_milestone=False,
        can_create_templates=True,
        can_manage_labels=True,
        can_comment=True,
        can_delete_any_comment=False,
        can_submit_vulnerabilities=True,
        can_edit_any_vulnerability=True,
        can_edit_owned_vulnerabilities=True,
        can_manage_vapt_templates=False,  # Configurable via settings
        can_delete_vapt_templates=False,
        can_manage_assets=True,
        can_generate_reports=True,
        can_create_channels=True,
        can_archive_channels=True,
        can_delete_channels=False,
        can_create_kb_collections=True,
        can_edit_kb_documents=True,
        can_delete_owned_kb_items=True,
        can_delete_any_kb_item=False,
        is_sandboxed=False,
    ),
    Role.MEMBER: RoleCapabilities(
        role=Role.MEMBER,
        can_manage_admins=False,
        can_delete_owner=False,
        can_create_projects=False,
        can_delete_any_project=False,
        can_delete_owned_projects=False,
        can_edit_any_project=False,
        can_create_tasks=True,
        can_edit_any_task=True,  # Members can edit any task (collaboration)
        can_delete_any_task=False,
        can_delete_owned_tasks=True,
        can_create_milestones=False,
        can_delete_owned_milestones=False,
        can_delete_any_milestone=False,
        can_create_templates=False,
        can_manage_labels=False,
        can_comment=True,
        can_delete_any_comment=False,
        can_submit_vulnerabilities=True,
        can_edit_any_vulnerability=False,
        can_edit_owned_vulnerabilities=True,
        can_manage_vapt_templates=False,
        can_delete_vapt_templates=False,
        can_manage_assets=False,
        can_generate_reports=True,
        can_create_channels=True,
        can_archive_channels=False,
        can_delete_channels=False,
        can_create_kb_collections=True,
        can_edit_kb_documents=True,
        can_delete_owned_kb_items=True,
        can_delete_any_kb_item=False,
        is_sandboxed=False,
    ),
    Role.GUEST: RoleCapabilities(
        role=Role.GUEST,
        can_manage_admins=False,
        can_delete_owner=False,
        can_create_projects=False,
        can_delete_any_project=False,
        can_delete_owned_projects=False,
        can_edit_any_project=False,
        can_create_tasks=False,
        can_edit_any_task=False,
        can_delete_any_task=False,
        can_delete_owned_tasks=False,
        can_create_milestones=False,
        can_delete_owned_milestones=False,
        can_delete_any_milestone=False,
        can_create_templates=False,
        can_manage_labels=False,
        can_comment=False,  # Guests can only comment if explicitly allowed
        can_delete_any_comment=False,
        can_submit_vulnerabilities=False,
        can_edit_any_vulnerability=False,
        can_edit_owned_vulnerabilities=False,
        can_manage_vapt_templates=False,
        can_delete_vapt_templates=False,
        can_manage_assets=False,
        can_generate_reports=False,
        can_create_channels=False,
        can_archive_channels=False,
        can_delete_channels=False,
        can_create_kb_collections=False,
        can_edit_kb_documents=False,
        can_delete_owned_kb_items=False,
        can_delete_any_kb_item=False,
        is_sandboxed=True,  # Guests are fully sandboxed
    ),
}


def get_role_capabilities(role: Role) -> RoleCapabilities:
    """Get capabilities for a given role"""
    return ROLE_CAPABILITIES[role]


def get_all_roles() -> List[Role]:
    """Get all available roles in descending order of privilege"""
    return [Role.OWNER, Role.ADMIN, Role.MANAGER, Role.MEMBER, Role.GUEST]


def can_role_perform_action(role: Role, capability: str) -> bool:
    """
    Check if a role can perform a specific action based on capabilities.
    
    Args:
        role: The role to check
        capability: The capability name (e.g., 'can_create_projects')
        
    Returns:
        True if the role has the capability, False otherwise
    """
    role_caps = get_role_capabilities(role)
    return getattr(role_caps, capability, False)


# Role validation functions
def is_valid_role(role_str: str) -> bool:
    """Check if a string is a valid role"""
    try:
        Role.from_string(role_str)
        return True
    except ValueError:
        return False


def validate_role_change(
    current_role: Role,
    new_role: Role,
    actor_role: Role
) -> tuple[bool, Optional[str]]:
    """
    Validate if a role change is allowed.
    
    Rules:
    - Owner cannot be deleted or downgraded
    - Only Owner can add/remove Admins
    - Only Owner/Admin can change roles below Admin
    
    Returns:
        (is_valid, error_message)
    """
    # Cannot downgrade or delete Owner
    if current_role == Role.OWNER and new_role != Role.OWNER:
        return False, "Cannot downgrade or delete Owner role"
    
    # Only Owner can manage Admins
    if new_role == Role.ADMIN and actor_role != Role.OWNER:
        return False, "Only Owner can assign Admin role"
    
    if current_role == Role.ADMIN and actor_role != Role.OWNER:
        return False, "Only Owner can modify Admin role"
    
    # Only Owner/Admin can change other roles
    if actor_role not in [Role.OWNER, Role.ADMIN]:
        return False, "Only Owner or Admin can change user roles"
    
    return True, None

