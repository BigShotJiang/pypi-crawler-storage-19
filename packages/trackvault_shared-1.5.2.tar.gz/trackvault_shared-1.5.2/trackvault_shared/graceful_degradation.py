"""
Graceful Degradation Utilities
Industry Standard: Return partial data when some services are unavailable

Time Complexity: O(1) per service call
Space Complexity: O(1)
"""
from typing import Dict, Any, Optional, List, Callable, Awaitable
import logging

logger = logging.getLogger(__name__)


class ServiceUnavailable(Exception):
    """Raised when a service is unavailable"""
    pass


async def get_with_fallback(
    primary_call: Callable[[], Awaitable[Any]],
    fallback_value: Any,
    service_name: str,
    log_warning: bool = True
) -> Any:
    """
    Call service with fallback value if unavailable
    
    Industry Standard: Graceful degradation pattern
    - Try primary call
    - Return fallback if unavailable
    - Log warning for monitoring
    
    Args:
        primary_call: Async function to call
        fallback_value: Value to return if call fails
        service_name: Name of service (for logging)
        log_warning: Whether to log warning on failure
    
    Returns:
        Result from primary_call or fallback_value
    """
    try:
        return await primary_call()
    except Exception as e:
        if log_warning:
            logger.warning(
                f"Service {service_name} unavailable, using fallback",
                extra={
                    "service": service_name,
                    "error": str(e),
                    "error_type": type(e).__name__
                }
            )
        return fallback_value


def create_partial_response(
    data: Dict[str, Any],
    unavailable_services: List[str],
    warnings: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Create response with partial data and metadata about unavailable services
    
    Industry Standard: Include metadata about data completeness
    Allows frontend to handle partial data gracefully
    
    Args:
        data: Response data (may be partial)
        unavailable_services: List of services that were unavailable
        warnings: Optional list of warning messages
    
    Returns:
        Response dict with data and metadata
    """
    response = {
        "data": data,
        "metadata": {
            "complete": len(unavailable_services) == 0,
            "unavailable_services": unavailable_services
        }
    }
    
    if warnings:
        response["metadata"]["warnings"] = warnings
    
    return response


async def call_multiple_with_fallback(
    service_calls: Dict[str, Callable[[], Awaitable[Any]]],
    fallback_values: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Call multiple services with individual fallbacks
    
    Industry Standard: Parallel service calls with independent fallbacks
    - Calls all services in parallel
    - Uses fallback for each service that fails
    - Returns combined result with metadata
    
    Args:
        service_calls: Dict mapping service_name -> async callable
        fallback_values: Optional dict mapping service_name -> fallback value
    
    Returns:
        Dict with results and metadata about unavailable services
    """
    import asyncio
    
    fallback_values = fallback_values or {}
    unavailable_services = []
    results = {}
    
    # Create tasks for all service calls
    tasks = {
        service_name: asyncio.create_task(call())
        for service_name, call in service_calls.items()
    }
    
    # Wait for all tasks to complete
    for service_name, task in tasks.items():
        try:
            results[service_name] = await task
        except Exception as e:
            logger.warning(
                f"Service {service_name} call failed",
                extra={"service": service_name, "error": str(e)}
            )
            unavailable_services.append(service_name)
            # Use fallback if available
            if service_name in fallback_values:
                results[service_name] = fallback_values[service_name]
            else:
                results[service_name] = None
    
    return {
        "results": results,
        "unavailable_services": unavailable_services,
        "complete": len(unavailable_services) == 0
    }

