"""
Service Discovery Client
Discovers services dynamically from service registry

Time Complexity: O(1) with caching, O(n) without cache
Space Complexity: O(n) where n = number of services
"""
import httpx
import asyncio
import time
from typing import Optional, Dict, Callable, Awaitable
import logging

logger = logging.getLogger(__name__)


class ServiceDiscoveryClient:
    """
    Client for service discovery
    
    Features:
    - Caching service URLs (5 minute TTL)
    - Automatic cache refresh
    - Fallback to hardcoded URLs if registry unavailable
    - Thread-safe caching
    - Optional service token support for registry authentication
    - Fail-fast to fallback on auth errors (reduces coupling)
    """
    
    def __init__(
        self,
        registry_url: str,
        cache_ttl: int = 300,  # 5 minutes
        fallback_urls: Optional[Dict[str, str]] = None,
        get_service_token: Optional[Callable[[], Awaitable[str]]] = None
    ):
        """
        Initialize service discovery client
        
        Args:
            registry_url: URL of the service registry (Auth Service)
            cache_ttl: Cache TTL in seconds (default: 5 minutes)
            fallback_urls: Optional fallback URLs if registry unavailable
            get_service_token: Optional async function to get service token for registry auth
        """
        self.registry_url = registry_url.rstrip('/')
        self.cache_ttl = cache_ttl
        self.fallback_urls = fallback_urls or {}
        self.get_service_token = get_service_token
        
        # Cache: service_name -> (url, timestamp)
        self._cache: Dict[str, tuple[str, float]] = {}
        self._cache_lock = asyncio.Lock()
        
        # HTTP client for registry calls
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client"""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=5.0)
        return self._client
    
    async def close(self):
        """Close HTTP client"""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    def _is_cache_valid(self, timestamp: float) -> bool:
        """Check if cache entry is still valid"""
        return (time.time() - timestamp) < self.cache_ttl
    
    async def get_service_url(self, service_name: str) -> Optional[str]:
        """
        Get service URL by name
        
        Checks cache first, then registry, then fallback.
        
        Time Complexity: O(1) with cache, O(n) without cache
        """
        async with self._cache_lock:
            # Check cache first
            if service_name in self._cache:
                url, timestamp = self._cache[service_name]
                if self._is_cache_valid(timestamp):
                    logger.debug(f"Service {service_name} found in cache: {url}")
                    return url
                else:
                    # Cache expired, remove it
                    del self._cache[service_name]
        
        # Cache miss or expired - fetch from registry
        try:
            url = await self._fetch_from_registry(service_name)
            if url:
                async with self._cache_lock:
                    self._cache[service_name] = (url, time.time())
                logger.info(f"Service {service_name} discovered from registry: {url}")
                return url
        except Exception as e:
            logger.warning(f"Failed to discover service {service_name} from registry: {e}")
        
        # Fallback to hardcoded URL if available
        if service_name in self.fallback_urls:
            fallback_url = self.fallback_urls[service_name]
            logger.warning(f"Using fallback URL for {service_name}: {fallback_url}")
            return fallback_url
        
        logger.error(f"Service {service_name} not found in registry and no fallback available")
        return None
    
    async def _fetch_from_registry(self, service_name: str) -> Optional[str]:
        """
        Fetch service URL from registry
        
        Returns None on any error (auth, network, timeout) to trigger fallback.
        This reduces coupling - if registry is down or auth fails, we use fallback URLs.
        """
        try:
            client = await self._get_client()
            
            # ✅ FIX: Get service token if provider is available
            headers = {}
            if self.get_service_token:
                try:
                    token = await self.get_service_token()
                    if token:
                        headers["X-Service-Token"] = token
                except Exception as token_error:
                    # If token generation fails, log at debug level and continue without token
                    # This allows graceful degradation - registry may still work or we'll use fallback
                    logger.debug(f"Could not get service token for registry call: {token_error}")
            
            response = await client.get(
                f"{self.registry_url}/internal/v1/registry/services/{service_name}",
                headers=headers,
                timeout=2.0  # ✅ Reduced timeout for fail-fast behavior
            )
            
            if response.status_code == 200:
                service_info = response.json()
                if service_info.get("status") == "healthy":
                    return service_info.get("service_url")
                else:
                    logger.debug(f"Service {service_name} is not healthy: {service_info.get('status')}")
                    return None
            elif response.status_code == 404:
                logger.debug(f"Service {service_name} not found in registry")
                return None
            elif response.status_code in (400, 401, 403):
                # ✅ FIX: Auth errors - fail fast to fallback (reduces coupling)
                # Don't log as error - this is expected when service tokens aren't configured
                logger.debug(
                    f"Registry auth failed ({response.status_code}) for {service_name}, "
                    f"using fallback URL. This is normal if service discovery is optional."
                )
                return None
            else:
                logger.debug(f"Registry returned {response.status_code} for service {service_name}")
                return None
                
        except httpx.TimeoutException:
            # ✅ Reduced logging - timeouts are expected if registry is down
            logger.debug(f"Timeout fetching service {service_name} from registry (using fallback)")
            return None
        except httpx.RequestError as e:
            # ✅ Reduced logging - network errors are expected if registry is down
            logger.debug(f"Request error fetching service {service_name} from registry: {e} (using fallback)")
            return None
        except Exception as e:
            # Only log unexpected errors at warning level
            logger.warning(f"Unexpected error fetching service {service_name} from registry: {e}")
            return None
    
    async def list_all_services(self) -> Dict[str, str]:
        """
        List all registered services
        
        Returns:
            Dictionary mapping service_name -> service_url
        """
        try:
            client = await self._get_client()
            
            # ✅ FIX: Get service token if provider is available
            headers = {}
            if self.get_service_token:
                try:
                    token = await self.get_service_token()
                    if token:
                        headers["X-Service-Token"] = token
                except Exception as token_error:
                    logger.debug(f"Could not get service token for registry list: {token_error}")
            
            response = await client.get(
                f"{self.registry_url}/internal/v1/registry/services",
                headers=headers,
                params={"status_filter": "healthy"},
                timeout=2.0  # ✅ Reduced timeout for fail-fast
            )
            
            if response.status_code == 200:
                data = response.json()
                services = {}
                for service in data.get("services", []):
                    if service.get("status") == "healthy":
                        services[service["service_name"]] = service["service_url"]
                
                # Update cache
                async with self._cache_lock:
                    for service_name, service_url in services.items():
                        self._cache[service_name] = (service_url, time.time())
                
                return services
            elif response.status_code in (400, 401, 403):
                # ✅ Auth errors - fail fast (reduces coupling)
                logger.debug(f"Registry auth failed ({response.status_code}) when listing services")
                return {}
            else:
                logger.debug(f"Registry returned {response.status_code} when listing services")
                return {}
                
        except httpx.TimeoutException:
            logger.debug("Timeout listing services from registry")
            return {}
        except httpx.RequestError as e:
            logger.debug(f"Request error listing services from registry: {e}")
            return {}
        except Exception as e:
            logger.warning(f"Unexpected error listing services from registry: {e}")
            return {}
    
    async def clear_cache(self):
        """Clear service URL cache"""
        async with self._cache_lock:
            self._cache.clear()
        logger.info("Service discovery cache cleared")
    
    async def get_cached_services(self) -> Dict[str, str]:
        """Get all cached service URLs"""
        async with self._cache_lock:
            return {
                name: url
                for name, (url, timestamp) in self._cache.items()
                if self._is_cache_valid(timestamp)
            }


# Global instance (optional - can be created per service)
_service_discovery_client: Optional[ServiceDiscoveryClient] = None


def get_service_discovery_client(
    registry_url: str,
    cache_ttl: int = 300,
    fallback_urls: Optional[Dict[str, str]] = None,
    get_service_token: Optional[Callable[[], Awaitable[str]]] = None
) -> ServiceDiscoveryClient:
    """
    Get or create global service discovery client
    
    Args:
        registry_url: URL of the service registry
        cache_ttl: Cache TTL in seconds
        fallback_urls: Optional fallback URLs
        get_service_token: Optional async function to get service token for registry auth
        
    Returns:
        ServiceDiscoveryClient instance
    """
    global _service_discovery_client
    
    if _service_discovery_client is None:
        _service_discovery_client = ServiceDiscoveryClient(
            registry_url=registry_url,
            cache_ttl=cache_ttl,
            fallback_urls=fallback_urls,
            get_service_token=get_service_token
        )
    
    return _service_discovery_client

