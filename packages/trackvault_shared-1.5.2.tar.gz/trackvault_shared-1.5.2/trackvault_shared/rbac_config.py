"""
RBAC Configuration Management for TrackVault

Manages configurable policy overrides and RBAC settings.
Configuration can be loaded from database, environment variables, or default values.

Configuration flags allow Owner/Admin to customize RBAC behavior:
- Allow managers to delete any project
- Allow managers to manage VAPT templates
- Allow guests to comment
- etc.

Configuration is workspace-scoped and can be different per workspace.
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
import os
import json
import structlog

from .rbac_policy import PolicyConfig

logger = structlog.get_logger(__name__)


class WorkspaceRBACConfig(BaseModel):
    """
    Workspace-level RBAC configuration.
    
    Each workspace can have different RBAC policy overrides.
    This allows flexible permission models per workspace.
    """
    workspace_id: str = Field(..., description="Workspace ID")
    tenant_id: str = Field(..., description="Tenant ID")
    
    # Policy overrides
    allow_managers_delete_any_project: bool = Field(
        False,
        description="Allow managers to delete any project (not just owned)"
    )
    allow_managers_manage_vapt_templates: bool = Field(
        False,
        description="Allow managers to upload and manage VAPT templates"
    )
    allow_guests_comment: bool = Field(
        False,
        description="Allow guests to create comments on tasks/milestones"
    )
    allow_members_discover_public_channels: bool = Field(
        True,
        description="Allow members to discover and join public channels"
    )
    allow_members_edit_any_task: bool = Field(
        True,
        description="Allow members to edit any task (not just owned)"
    )
    allow_guests_view_milestones: bool = Field(
        False,
        description="Allow guests to view milestones"
    )
    
    # Audit settings
    enable_detailed_audit_logging: bool = Field(
        True,
        description="Enable detailed audit logging for all RBAC actions"
    )
    audit_log_retention_days: int = Field(
        365,
        description="Number of days to retain audit logs"
    )
    
    # Security settings
    require_mfa_for_destructive_actions: bool = Field(
        False,
        description="Require MFA for destructive actions (deletion, role changes)"
    )
    
    def to_policy_config(self) -> PolicyConfig:
        """Convert to PolicyConfig for RBAC engine"""
        return PolicyConfig(
            allow_managers_delete_any_project=self.allow_managers_delete_any_project,
            allow_managers_manage_vapt_templates=self.allow_managers_manage_vapt_templates,
            allow_guests_comment=self.allow_guests_comment,
            allow_members_discover_public_channels=self.allow_members_discover_public_channels,
            allow_members_edit_any_task=self.allow_members_edit_any_task,
            allow_guests_view_milestones=self.allow_guests_view_milestones,
        )
    
    @classmethod
    def get_default_config(cls, workspace_id: str, tenant_id: str) -> "WorkspaceRBACConfig":
        """Get default RBAC configuration for a workspace"""
        return cls(
            workspace_id=workspace_id,
            tenant_id=tenant_id,
            allow_managers_delete_any_project=False,
            allow_managers_manage_vapt_templates=False,
            allow_guests_comment=False,
            allow_members_discover_public_channels=True,
            allow_members_edit_any_task=True,
            allow_guests_view_milestones=False,
            enable_detailed_audit_logging=True,
            audit_log_retention_days=365,
            require_mfa_for_destructive_actions=False,
        )


class RBACConfigManager:
    """
    Manages RBAC configuration loading and caching.
    
    Configuration is loaded from:
    1. Database (workspace-specific settings)
    2. Environment variables (global defaults)
    3. Default values (hardcoded fallback)
    """
    
    def __init__(self):
        """Initialize the configuration manager"""
        self.logger = logger.bind(component="rbac_config_manager")
        self._config_cache: Dict[str, WorkspaceRBACConfig] = {}
        self._load_global_defaults()
    
    def _load_global_defaults(self):
        """Load global default configuration from environment"""
        try:
            config_json = os.getenv("TRACKVAULT_RBAC_CONFIG")
            if config_json:
                config_data = json.loads(config_json)
                self._global_defaults = config_data
                self.logger.info("loaded_rbac_config_from_env", config=config_data)
            else:
                self._global_defaults = {}
        except Exception as e:
            self.logger.warning("failed_to_load_rbac_config_from_env", error=str(e))
            self._global_defaults = {}
    
    async def get_workspace_config(
        self,
        workspace_id: str,
        tenant_id: str,
        db_loader: Optional[Any] = None
    ) -> WorkspaceRBACConfig:
        """
        Get RBAC configuration for a workspace.
        
        Args:
            workspace_id: Workspace ID
            tenant_id: Tenant ID
            db_loader: Optional database loader function
            
        Returns:
            WorkspaceRBACConfig
        """
        # Check cache first
        cache_key = f"{tenant_id}:{workspace_id}"
        if cache_key in self._config_cache:
            return self._config_cache[cache_key]
        
        # Try to load from database if loader is provided
        if db_loader:
            try:
                config_data = await db_loader(workspace_id, tenant_id)
                if config_data:
                    config = WorkspaceRBACConfig(**config_data)
                    self._config_cache[cache_key] = config
                    return config
            except Exception as e:
                self.logger.warning(
                    "failed_to_load_workspace_config_from_db",
                    workspace_id=workspace_id,
                    error=str(e)
                )
        
        # Fall back to default configuration
        config = WorkspaceRBACConfig.get_default_config(workspace_id, tenant_id)
        
        # Apply global defaults
        for key, value in self._global_defaults.items():
            if hasattr(config, key):
                setattr(config, key, value)
        
        self._config_cache[cache_key] = config
        return config
    
    def invalidate_cache(self, workspace_id: str, tenant_id: str):
        """Invalidate cached configuration for a workspace"""
        cache_key = f"{tenant_id}:{workspace_id}"
        if cache_key in self._config_cache:
            del self._config_cache[cache_key]
            self.logger.info(
                "invalidated_workspace_config_cache",
                workspace_id=workspace_id,
                tenant_id=tenant_id
            )
    
    def clear_all_cache(self):
        """Clear all cached configuration"""
        self._config_cache.clear()
        self.logger.info("cleared_all_config_cache")


# Global config manager instance
_config_manager: Optional[RBACConfigManager] = None


def get_config_manager() -> RBACConfigManager:
    """Get the global RBAC configuration manager"""
    global _config_manager
    if _config_manager is None:
        _config_manager = RBACConfigManager()
    return _config_manager


async def get_policy_config_for_workspace(
    workspace_id: str,
    tenant_id: str,
    db_loader: Optional[Any] = None
) -> PolicyConfig:
    """
    Get PolicyConfig for a workspace.
    
    Convenience function that loads workspace config and converts to PolicyConfig.
    
    Args:
        workspace_id: Workspace ID
        tenant_id: Tenant ID
        db_loader: Optional database loader function
        
    Returns:
        PolicyConfig for the workspace
    """
    manager = get_config_manager()
    workspace_config = await manager.get_workspace_config(workspace_id, tenant_id, db_loader)
    return workspace_config.to_policy_config()


def update_workspace_config(
    workspace_id: str,
    tenant_id: str,
    config_updates: Dict[str, Any]
):
    """
    Update workspace RBAC configuration.
    
    This is a helper function that should be called after updating the database.
    It invalidates the cache so the next request loads fresh config.
    
    Args:
        workspace_id: Workspace ID
        tenant_id: Tenant ID
        config_updates: Dictionary of configuration updates
    """
    manager = get_config_manager()
    manager.invalidate_cache(workspace_id, tenant_id)
    
    logger.info(
        "workspace_rbac_config_updated",
        workspace_id=workspace_id,
        tenant_id=tenant_id,
        updates=config_updates
    )


# Environment variable helpers
def load_rbac_config_from_env() -> Dict[str, Any]:
    """
    Load RBAC configuration from environment variables.
    
    Environment variables:
    - TRACKVAULT_RBAC_CONFIG: JSON string with global defaults
    - TRACKVAULT_RBAC_MANAGERS_DELETE_ANY_PROJECT: bool
    - TRACKVAULT_RBAC_MANAGERS_MANAGE_VAPT: bool
    - TRACKVAULT_RBAC_GUESTS_COMMENT: bool
    
    Returns:
        Dictionary of configuration values
    """
    config = {}
    
    # Load from JSON if available
    config_json = os.getenv("TRACKVAULT_RBAC_CONFIG")
    if config_json:
        try:
            config = json.loads(config_json)
        except json.JSONDecodeError:
            logger.warning("invalid_rbac_config_json", config_json=config_json)
    
    # Load individual env vars (override JSON)
    if os.getenv("TRACKVAULT_RBAC_MANAGERS_DELETE_ANY_PROJECT"):
        config["allow_managers_delete_any_project"] = os.getenv(
            "TRACKVAULT_RBAC_MANAGERS_DELETE_ANY_PROJECT"
        ).lower() == "true"
    
    if os.getenv("TRACKVAULT_RBAC_MANAGERS_MANAGE_VAPT"):
        config["allow_managers_manage_vapt_templates"] = os.getenv(
            "TRACKVAULT_RBAC_MANAGERS_MANAGE_VAPT"
        ).lower() == "true"
    
    if os.getenv("TRACKVAULT_RBAC_GUESTS_COMMENT"):
        config["allow_guests_comment"] = os.getenv(
            "TRACKVAULT_RBAC_GUESTS_COMMENT"
        ).lower() == "true"
    
    return config

