"""
Retry Pattern with Exponential Backoff
Handles transient failures in distributed systems
"""

import asyncio
import random
from typing import Callable, Any, Optional, Type, Tuple
import logging

logger = logging.getLogger(__name__)

class RetryConfig:
    """Configuration for retry behavior"""
    
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        jitter: bool = True,
        retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,)
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions

async def retry_with_backoff(
    func: Callable,
    *args,
    config: Optional[RetryConfig] = None,
    **kwargs
) -> Any:
    """
    Retry function with exponential backoff
    
    Args:
        func: Function to retry
        *args: Positional arguments for function
        config: Retry configuration
        **kwargs: Keyword arguments for function
        
    Returns:
        Function result
        
    Raises:
        Last exception if all retries fail
    """
    if config is None:
        config = RetryConfig()
    
    last_exception = None
    
    for attempt in range(config.max_retries + 1):
        try:
            result = await func(*args, **kwargs)
            if attempt > 0:
                logger.info(f"Function succeeded on attempt {attempt + 1}")
            return result
            
        except config.retryable_exceptions as e:
            last_exception = e
            
            if attempt == config.max_retries:
                logger.error(f"Function failed after {config.max_retries + 1} attempts: {e}")
                raise e
            
            # Calculate delay with exponential backoff
            delay = min(
                config.base_delay * (config.exponential_base ** attempt),
                config.max_delay
            )
            
            # Add jitter to prevent thundering herd
            if config.jitter:
                delay *= (0.5 + random.random() * 0.5)
            
            logger.warning(f"Function failed on attempt {attempt + 1}, retrying in {delay:.2f}s: {e}")
            await asyncio.sleep(delay)
    
    # This should never be reached, but just in case
    if last_exception:
        raise last_exception

# Pre-configured retry configs for different use cases
DATABASE_RETRY_CONFIG = RetryConfig(
    max_retries=3,
    base_delay=1.0,
    max_delay=10.0,
    retryable_exceptions=(ConnectionError, TimeoutError, OSError)
)

REDIS_RETRY_CONFIG = RetryConfig(
    max_retries=5,
    base_delay=0.5,
    max_delay=5.0,
    retryable_exceptions=(ConnectionError, TimeoutError, OSError)
)

EXTERNAL_API_RETRY_CONFIG = RetryConfig(
    max_retries=3,
    base_delay=2.0,
    max_delay=30.0,
    retryable_exceptions=(ConnectionError, TimeoutError, OSError)
)

# Convenience functions
async def retry_database_operation(func: Callable, *args, **kwargs) -> Any:
    """Retry database operations"""
    return await retry_with_backoff(func, *args, config=DATABASE_RETRY_CONFIG, **kwargs)

async def retry_redis_operation(func: Callable, *args, **kwargs) -> Any:
    """Retry Redis operations"""
    return await retry_with_backoff(func, *args, config=REDIS_RETRY_CONFIG, **kwargs)

async def retry_external_api(func: Callable, *args, **kwargs) -> Any:
    """Retry external API calls"""
    return await retry_with_backoff(func, *args, config=EXTERNAL_API_RETRY_CONFIG, **kwargs)
