"""
Event schemas for TrackVault microservices
Defines Pydantic models for all event types in the system
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime


# ============================================================================
# USER EVENTS (Auth Service)
# ============================================================================

class UserEmailChangedEvent(BaseModel):
    """Event published when a user's email address is changed"""
    user_id: str
    tenant_id: str
    old_email: str
    new_email: str
    changed_by: str
    timestamp: str


class UserNameChangedEvent(BaseModel):
    """Event published when a user's full name is changed"""
    user_id: str
    tenant_id: str
    old_name: str
    new_name: str
    changed_by: str
    timestamp: str


class UserDeletionRequestedEvent(BaseModel):
    """
    Event published when a user requests account deletion
    Triggers coordinated ownership transfer across all services
    """
    user_id: str
    tenant_id: str
    email: str  # For audit trail
    deletion_type: str = Field(default="permanent", description="permanent or anonymize")
    requested_at: str
    requested_by: str  # Could be user themselves or admin


class UserDeletionCompletedEvent(BaseModel):
    """
    Event published when user deletion is fully complete
    Published by Auth Service after all transfers confirmed
    """
    user_id: str
    transfer_id: str
    deleted_at: str
    audit_summary: Dict[str, int] = Field(
        description="Summary of transferred/anonymized items per resource type"
    )


# ============================================================================
# WORKSPACE EVENTS (Project Service)
# ============================================================================

class WorkspaceCreatedEvent(BaseModel):
    """Event published when a new workspace is created"""
    workspace_id: str
    tenant_id: str
    workspace_name: str
    workspace_slug: str
    owner_id: str
    created_by: str
    timestamp: str


class WorkspaceRenamedEvent(BaseModel):
    """Event published when a workspace is renamed"""
    workspace_id: str
    tenant_id: str
    old_name: str
    new_name: str
    renamed_by: str
    timestamp: str


# ============================================================================
# PROJECT EVENTS (Project Service)
# ============================================================================

class ProjectCreatedEvent(BaseModel):
    """Event published when a new project is created"""
    project_id: str
    workspace_id: str
    tenant_id: str
    project_title: str
    project_identifier: str
    created_by: str
    timestamp: str


class ProjectRenamedEvent(BaseModel):
    """Event published when a project is renamed"""
    project_id: str
    workspace_id: str
    tenant_id: str
    old_title: str
    new_title: str
    renamed_by: str
    timestamp: str


# ============================================================================
# OWNERSHIP TRANSFER EVENTS (Project Service - Orchestrator)
# ============================================================================

class UserOwnershipTransferStartedEvent(BaseModel):
    """
    Event published when ownership transfer begins for a deleted user
    Coordinator event - all services should listen and begin their transfers
    """
    user_id: str
    transfer_id: str = Field(description="Unique ID for this transfer operation")
    affected_tenants: List[str] = Field(description="List of tenant IDs affected")
    estimated_items: int = Field(description="Estimated total resources to transfer")
    started_at: str


class UserResourcesTransferredEvent(BaseModel):
    """
    Event published by each service when it completes resource transfer
    Project Service (orchestrator) listens to track completion
    """
    transfer_id: str
    service_name: str = Field(description="Name of service completing transfer")
    user_id: str
    workspace_id: Optional[str] = Field(default=None, description="Workspace context if applicable")
    tenant_id: str
    items_transferred: Dict[str, int] = Field(
        description="Count of items transferred per resource type"
    )
    new_owner_id: Optional[str] = Field(default=None, description="New owner if transferred (None if anonymized)")
    completed_at: str


# ============================================================================
# CASCADING DELETION EVENTS
# ============================================================================

class WorkspaceDeletedEvent(BaseModel):
    """
    Event published when a workspace is deleted
    Triggers cascading deletion of all workspace data across services
    """
    workspace_id: str
    tenant_id: str
    deleted_by: str
    deletion_reason: str = Field(description="user_requested, inactive, admin_action")
    deleted_at: str


class ProjectDeletedEvent(BaseModel):
    """
    Event published when a project is deleted
    Triggers cascading deletion of tasks, milestones, labels, and cleanup in other services
    """
    project_id: str
    workspace_id: str
    tenant_id: str
    deleted_by: str
    deletion_reason: str
    deleted_at: str


class TaskDeletedEvent(BaseModel):
    """Event published when a task is deleted"""
    task_id: str
    project_id: str
    workspace_id: str
    deleted_by: str
    deleted_at: str


class MilestoneDeletedEvent(BaseModel):
    """Event published when a milestone is deleted"""
    milestone_id: str
    project_id: str
    deleted_by: str
    deleted_at: str


class LabelDeletedEvent(BaseModel):
    """Event published when a label is deleted"""
    label_id: str
    project_id: str
    deleted_by: str
    deleted_at: str


class SpaceDeletedEvent(BaseModel):
    """
    Event published when a knowledge space is deleted
    Triggers deletion of all pages and unpublishing of sites
    """
    space_id: str
    workspace_id: str
    deleted_by: str
    deleted_at: str


class PageDeletedEvent(BaseModel):
    """Event published when a knowledge page is deleted"""
    page_id: str
    space_id: str
    workspace_id: str
    deleted_by: str
    deleted_at: str


class RoomDeletedEvent(BaseModel):
    """
    Event published when a chat room is deleted
    Triggers deletion of all messages in the room
    """
    room_id: str
    workspace_id: str
    deleted_by: str
    deleted_at: str


class VulnerabilityDeletedEvent(BaseModel):
    """Event published when a vulnerability is deleted"""
    vulnerability_id: str
    workspace_id: str
    project_id: Optional[str] = Field(default=None)
    deleted_by: str
    deleted_at: str


# ============================================================================
# EVENT TYPE REGISTRY
# ============================================================================

EVENT_SCHEMAS = {
    # User events
    "user.email_changed": UserEmailChangedEvent,
    "user.name_changed": UserNameChangedEvent,
    "user.deletion_requested": UserDeletionRequestedEvent,
    "user.deletion_completed": UserDeletionCompletedEvent,
    
    # Workspace events
    "workspace.created": WorkspaceCreatedEvent,
    "workspace.renamed": WorkspaceRenamedEvent,
    "workspace.deleted": WorkspaceDeletedEvent,
    
    # Project events
    "project.created": ProjectCreatedEvent,
    "project.renamed": ProjectRenamedEvent,
    "project.deleted": ProjectDeletedEvent,
    
    # Task events
    "task.deleted": TaskDeletedEvent,
    
    # Milestone events
    "milestone.deleted": MilestoneDeletedEvent,
    
    # Label events
    "label.deleted": LabelDeletedEvent,
    
    # Knowledge events
    "space.deleted": SpaceDeletedEvent,
    "page.deleted": PageDeletedEvent,
    
    # Chat events
    "room.deleted": RoomDeletedEvent,
    
    # VAPT events
    "vulnerability.deleted": VulnerabilityDeletedEvent,
    
    # Ownership transfer events
    "user.ownership_transfer_started": UserOwnershipTransferStartedEvent,
    "user.resources_transferred": UserResourcesTransferredEvent,
}


def get_event_schema(event_type: str) -> Optional[type[BaseModel]]:
    """Get the Pydantic schema for a given event type"""
    return EVENT_SCHEMAS.get(event_type)


def validate_event_data(event_type: str, data: Dict[str, Any]) -> BaseModel:
    """
    Validate event data against its schema
    
    Raises:
        ValueError: If event type unknown or data invalid
    """
    schema = get_event_schema(event_type)
    if not schema:
        raise ValueError(f"Unknown event type: {event_type}")
    
    return schema(**data)
