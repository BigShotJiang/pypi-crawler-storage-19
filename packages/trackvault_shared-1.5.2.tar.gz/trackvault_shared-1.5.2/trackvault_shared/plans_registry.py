"""
Shared Plans Registry for TrackVault Multi-Tenancy
Consistent plan definitions across all microservices

This registry defines plans based on:
- Free users: 5 workspaces, 5 members per workspace, unlimited projects
- Team plan: Enhanced features for growing teams  
- Enterprise plan: Full features for large organizations

All plans are designed around the current project service capabilities.
"""

from typing import Dict, List, Any
from enum import Enum
import os
import json

class PlanType(str, Enum):
    """Plan type enumeration"""
    FREE = "free"
    TEAM = "team"
    ENTERPRISE = "enterprise"

class TenantType(str, Enum):
    """Tenant type enumeration"""
    INDIVIDUAL = "individual"
    ORGANIZATION = "organization"

# Unified plan definitions (defaults)
UNIFIED_PLANS_DEFAULTS = {
    PlanType.FREE: {
        "name": "free",
        "display_name": "Free",
        "description": "Perfect for individuals and small teams getting started",
        "price": 0,
        # Optional per-seat billing. If provided, overrides flat price for total billing
        "price_per_seat": 0,
        "billing_cycle": "monthly",
        "currency": "USD",
        
        # Tenant-level limits
        "tenant_limits": {
            "max_tenants_per_user": 1,  # Individual tenant only
            "tenant_type": TenantType.INDIVIDUAL,
            "max_users_per_tenant": 1,  # Only the owner
        },
        
        # Workspace limits
        "workspace_limits": {
            "max_workspaces": 5,
            "max_members_per_workspace": 5,
            "max_projects_per_workspace": -1,  # Unlimited projects
            "max_storage_gb_per_workspace": 1,
            "max_api_calls_per_month": 1000,
        },
        
        # Feature flags
        "features": [
            # Core project management
            "project_crud",
            "task_management",
            "milestone_tracking",
            "basic_analytics",
            "file_attachments",
            "team_collaboration",
            "basic_reporting",
            
            # Workspace features
            "workspace_management",
            "member_invitations",
            "basic_permissions",
            "activity_feeds",
            
            # Project features
            "project_templates",
            "task_templates",
            "basic_workflows",
            "time_tracking",
            "comments_and_notes",
            "basic_search",
            "export_basic",
        ],
        
        # Restrictions
        "restrictions": [
            "no_advanced_analytics",
            "no_custom_roles",
            "no_api_access",
            "no_webhooks",
            "no_advanced_integrations",
            "no_priority_support",
        ],
        
        # UI/UX features
        "ui_features": [
            "basic_dashboard",
            "project_boards",
            "task_lists",
            "calendar_view",
            "basic_notifications",
        ],
    },
    
    PlanType.TEAM: {
        "name": "team",
        "display_name": "Team",
        "description": "Perfect for growing teams that need advanced collaboration",
        "price": 7,
        # Optional per-seat billing. If provided, overrides flat price for total billing
        "price_per_seat": 7,
        "billing_cycle": "monthly",
        "currency": "USD",
        
        # Tenant-level limits
        "tenant_limits": {
            "max_tenants_per_user": 1,  # Individual tenant only
            "tenant_type": TenantType.INDIVIDUAL,
            "max_users_per_tenant": 10,  # Up to 10 team members
        },
        
        # Workspace limits
        "workspace_limits": {
            "max_workspaces": 10,
            "max_members_per_workspace": 25,
            "max_projects_per_workspace": -1,  # Unlimited projects
            "max_storage_gb_per_workspace": 10,
            "max_api_calls_per_month": 10000,
        },
        
        # Feature flags (includes all Free features plus)
        "features": [
            # All Free features
            "project_crud",
            "task_management",
            "milestone_tracking",
            "basic_analytics",
            "file_attachments",
            "team_collaboration",
            "basic_reporting",
            "workspace_management",
            "member_invitations",
            "basic_permissions",
            "activity_feeds",
            "project_templates",
            "task_templates",
            "basic_workflows",
            "time_tracking",
            "comments_and_notes",
            "basic_search",
            "export_basic",
            
            # Team-specific features
            "advanced_analytics",
            "custom_fields",
            "advanced_workflows",
            "bulk_operations",
            "advanced_search",
            "advanced_reporting",
            "custom_dashboards",
            "team_management",
            "role_based_permissions",
            "advanced_notifications",
            "email_integrations",
            "calendar_integrations",
            "export_advanced",
            "import_data",
            "api_access",
            "webhooks",
            "priority_support",
        ],
        
        # Restrictions
        "restrictions": [
            "no_enterprise_security",
            "no_sso",
            "no_custom_branding",
            "no_dedicated_support",
            "no_advanced_integrations",
        ],
        
        # UI/UX features
        "ui_features": [
            "advanced_dashboard",
            "project_boards",
            "task_lists",
            "calendar_view",
            "advanced_notifications",
            "custom_views",
            "advanced_filters",
            "bulk_actions",
            "team_analytics",
        ],
    },
    
    PlanType.ENTERPRISE: {
        "name": "enterprise",
        "display_name": "Enterprise",
        "description": "Full-featured solution for large organizations",
        "price": 15,
        # Optional per-seat billing. If provided, overrides flat price for total billing
        "price_per_seat": 15,
        "billing_cycle": "monthly",
        "currency": "USD",
        
        # Tenant-level limits
        "tenant_limits": {
            "max_tenants_per_user": 1,  # Individual tenant only
            "tenant_type": TenantType.ORGANIZATION,
            "max_users_per_tenant": 1000,  # Up to 1000 users
        },
        
        # Workspace limits
        "workspace_limits": {
            "max_workspaces": -1,  # Unlimited workspaces
            "max_members_per_workspace": -1,  # Unlimited members
            "max_projects_per_workspace": -1,  # Unlimited projects
            "max_storage_gb_per_workspace": 1000,
            "max_api_calls_per_month": 100000,
        },
        
        # Feature flags (includes all Team features plus)
        "features": [
            # All Free and Team features
            "project_crud",
            "task_management",
            "milestone_tracking",
            "basic_analytics",
            "file_attachments",
            "team_collaboration",
            "basic_reporting",
            "workspace_management",
            "member_invitations",
            "basic_permissions",
            "activity_feeds",
            "project_templates",
            "task_templates",
            "basic_workflows",
            "time_tracking",
            "comments_and_notes",
            "basic_search",
            "export_basic",
            "advanced_analytics",
            "custom_fields",
            "advanced_workflows",
            "bulk_operations",
            "advanced_search",
            "advanced_reporting",
            "custom_dashboards",
            "team_management",
            "role_based_permissions",
            "advanced_notifications",
            "email_integrations",
            "calendar_integrations",
            "export_advanced",
            "import_data",
            "api_access",
            "webhooks",
            "priority_support",
            
            # Enterprise-specific features
            "enterprise_security",
            "sso_integration",
            "advanced_audit_logs",
            "compliance_reporting",
            "custom_branding",
            "white_labeling",
            "advanced_integrations",
            "custom_webhooks",
            "dedicated_support",
            "sla_guarantee",
            "custom_roles",
            "advanced_permissions",
            "data_retention_policies",
            "backup_and_restore",
            "advanced_analytics_enterprise",
            "custom_reports",
            "api_rate_limits_high",
            "webhook_rate_limits_high",
        ],
        
        # Restrictions
        "restrictions": [],  # No restrictions for enterprise
        
        # UI/UX features
        "ui_features": [
            "enterprise_dashboard",
            "project_boards",
            "task_lists",
            "calendar_view",
            "advanced_notifications",
            "custom_views",
            "advanced_filters",
            "bulk_actions",
            "team_analytics",
            "enterprise_analytics",
            "custom_branding_ui",
            "advanced_permissions_ui",
            "audit_logs_ui",
            "compliance_dashboard",
        ],
    },
}

def _merge_plan(default_plan: Dict[str, Any], override_plan: Dict[str, Any]) -> Dict[str, Any]:
    """Shallow-merge plan dictionaries with nested merges for known sub-objects."""
    if not override_plan:
        return default_plan
    merged = {**default_plan}
    for k, v in override_plan.items():
        if k in ("tenant_limits", "workspace_limits") and isinstance(v, dict):
            merged[k] = {**default_plan.get(k, {}), **v}
        elif k in ("features", "restrictions", "ui_features") and isinstance(v, list):
            merged[k] = v
        else:
            merged[k] = v
    return merged

def _index_defaults_by_name(defaults: Dict[Enum, Dict[str, Any]]) -> Dict[str, Enum]:
    return {v.get("name", str(k)).lower(): k for k, v in defaults.items()}

def load_unified_plans_from_env() -> Dict[Enum, Dict[str, Any]]:
    """
    Load plan overrides from TRACKVAULT_PLANS_JSON env (JSON). Structure options:
    - Array of plan objects with "name" matching defaults (free/team/enterprise)
    - Object keyed by plan name: { "free": { ... }, "team": { ... } }
    Only listed fields are overridden; others use defaults.
    """
    env_key = "TRACKVAULT_PLANS_JSON"
    raw = os.getenv(env_key)
    if not raw:
        return UNIFIED_PLANS_DEFAULTS
    try:
        data = json.loads(raw)
    except Exception:
        # Fallback to defaults on parse error
        return UNIFIED_PLANS_DEFAULTS

    name_to_enum = _index_defaults_by_name(UNIFIED_PLANS_DEFAULTS)
    merged: Dict[Enum, Dict[str, Any]] = {}

    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "")).lower()
            if name in name_to_enum:
                enum_key = name_to_enum[name]
                merged[enum_key] = _merge_plan(UNIFIED_PLANS_DEFAULTS[enum_key], item)
        # Carry forward non-overridden defaults
        for enum_key, plan in UNIFIED_PLANS_DEFAULTS.items():
            if enum_key not in merged:
                merged[enum_key] = plan
        return merged

    if isinstance(data, dict):
        for name, override in data.items():
            key = str(name).lower()
            if key in name_to_enum and isinstance(override, dict):
                enum_key = name_to_enum[key]
                merged[enum_key] = _merge_plan(UNIFIED_PLANS_DEFAULTS[enum_key], override)
        # Carry forward non-overridden defaults
        for enum_key, plan in UNIFIED_PLANS_DEFAULTS.items():
            if enum_key not in merged:
                merged[enum_key] = plan
        return merged

    # Unknown shape → defaults
    return UNIFIED_PLANS_DEFAULTS

# Final unified plans map (env overrides applied)
UNIFIED_PLANS = load_unified_plans_from_env()

# Legacy plan mapping for backward compatibility
LEGACY_PLAN_MAPPING = {
    "trial": PlanType.FREE,
    "freelance": PlanType.TEAM,
    "corporate": PlanType.ENTERPRISE,
    "custom": PlanType.ENTERPRISE,
}

def get_plan_by_name(plan_name: str) -> Dict[str, Any]:
    """Get plan details by plan name (case-insensitive)"""
    plan_name = plan_name.lower()
    
    # Check direct mapping first
    for plan_type, plan_data in UNIFIED_PLANS.items():
        if plan_data["name"].lower() == plan_name:
            return plan_data
    
    # Check legacy mapping
    if plan_name in LEGACY_PLAN_MAPPING:
        legacy_plan_type = LEGACY_PLAN_MAPPING[plan_name]
        return UNIFIED_PLANS[legacy_plan_type]
    
    return None

def get_plan_features(plan_name: str) -> List[str]:
    """Get the list of feature flags for a given plan name"""
    plan = get_plan_by_name(plan_name)
    return plan["features"] if plan else []

def get_plan_limits(plan_name: str) -> Dict[str, Any]:
    """Get plan limits for a given plan name"""
    plan = get_plan_by_name(plan_name)
    if not plan:
        return {}
    
    return {
        "tenant_limits": plan["tenant_limits"],
        "workspace_limits": plan["workspace_limits"],
    }

def can_user_access_feature(plan_name: str, feature: str) -> bool:
    """Check if a plan has access to a specific feature"""
    plan = get_plan_by_name(plan_name)
    if not plan:
        return False
    
    return feature in plan["features"]

def get_plan_restrictions(plan_name: str) -> List[str]:
    """Get plan restrictions for a given plan name"""
    plan = get_plan_by_name(plan_name)
    return plan["restrictions"] if plan else []

def is_plan_restricted(plan_name: str, restriction: str) -> bool:
    """Check if a plan has a specific restriction"""
    restrictions = get_plan_restrictions(plan_name)
    return restriction in restrictions

def get_workspace_limits_for_plan(plan_name: str) -> Dict[str, Any]:
    """Get workspace-specific limits for a plan"""
    plan = get_plan_by_name(plan_name)
    return plan["workspace_limits"] if plan else {}

def get_tenant_limits_for_plan(plan_name: str) -> Dict[str, Any]:
    """Get tenant-specific limits for a plan"""
    plan = get_plan_by_name(plan_name)
    return plan["tenant_limits"] if plan else {}

def validate_plan_usage(plan_name: str, usage: Dict[str, int]) -> Dict[str, Any]:
    """Validate current usage against plan limits"""
    plan = get_plan_by_name(plan_name)
    if not plan:
        return {"valid": False, "errors": ["Invalid plan"]}
    
    workspace_limits = plan["workspace_limits"]
    tenant_limits = plan["tenant_limits"]
    
    errors = []
    warnings = []
    
    # Check workspace limits
    if "workspaces" in usage:
        max_workspaces = workspace_limits["max_workspaces"]
        if max_workspaces != -1 and usage["workspaces"] > max_workspaces:
            errors.append(f"Workspace limit exceeded: {usage['workspaces']}/{max_workspaces}")
    
    if "members_per_workspace" in usage:
        max_members = workspace_limits["max_members_per_workspace"]
        if max_members != -1 and usage["members_per_workspace"] > max_members:
            errors.append(f"Members per workspace limit exceeded: {usage['members_per_workspace']}/{max_members}")
    
    if "projects_per_workspace" in usage:
        max_projects = workspace_limits["max_projects_per_workspace"]
        if max_projects != -1 and usage["projects_per_workspace"] > max_projects:
            errors.append(f"Projects per workspace limit exceeded: {usage['projects_per_workspace']}/{max_projects}")
    
    if "storage_gb" in usage:
        max_storage = workspace_limits["max_storage_gb_per_workspace"]
        if max_storage != -1 and usage["storage_gb"] > max_storage:
            errors.append(f"Storage limit exceeded: {usage['storage_gb']}GB/{max_storage}GB")
    
    # Check tenant limits
    if "users_per_tenant" in usage:
        max_users = tenant_limits["max_users_per_tenant"]
        if max_users != -1 and usage["users_per_tenant"] > max_users:
            errors.append(f"Users per tenant limit exceeded: {usage['users_per_tenant']}/{max_users}")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "limits": {
            "workspace": workspace_limits,
            "tenant": tenant_limits,
        }
    }

def get_plan_comparison() -> Dict[str, Any]:
    """Get a comparison of all plans for display purposes"""
    comparison = {
        "plans": [],
        "features": [],
        "limits": {
            "workspaces": [],
            "members_per_workspace": [],
            "projects_per_workspace": [],
            "storage_gb": [],
            "users_per_tenant": [],
        }
    }
    
    # Collect all unique features
    all_features = set()
    for plan_data in UNIFIED_PLANS.values():
        all_features.update(plan_data["features"])
    comparison["features"] = sorted(list(all_features))
    
    # Build plan comparison
    for plan_type, plan_data in UNIFIED_PLANS.items():
        plan_info = {
            "name": plan_data["name"],
            "display_name": plan_data["display_name"],
            "description": plan_data["description"],
            "price": plan_data["price"],
            "currency": plan_data["currency"],
            "billing_cycle": plan_data["billing_cycle"],
            "features": plan_data["features"],
            "restrictions": plan_data["restrictions"],
            "limits": {
                "workspaces": plan_data["workspace_limits"]["max_workspaces"],
                "members_per_workspace": plan_data["workspace_limits"]["max_members_per_workspace"],
                "projects_per_workspace": plan_data["workspace_limits"]["max_projects_per_workspace"],
                "storage_gb": plan_data["workspace_limits"]["max_storage_gb_per_workspace"],
                "users_per_tenant": plan_data["tenant_limits"]["max_users_per_tenant"],
            }
        }
        comparison["plans"].append(plan_info)
    
    return comparison

# Export the main plans registry
PLANS = UNIFIED_PLANS
