"""
RBAC Permission Definitions for TrackVault

Defines actions, resources, and permission mappings for the RBAC system.
This module provides the granular permission matrix for all operations.

CRITICAL CONCEPTS:
- Permissions are ACTION + RESOURCE combinations (e.g., "delete:project")
- Ownership checks are separate from permissions
- Configurable policies can override default permissions
"""

from enum import Enum
from typing import Set, List, Optional
from dataclasses import dataclass


class Action(str, Enum):
    """
    All possible actions in the TrackVault platform.
    Actions are resource-agnostic and combined with resources for permission checks.
    """
    # Core CRUD operations
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    
    # Administrative actions
    MANAGE = "manage"  # Full management access
    CONFIGURE = "configure"  # Configuration changes
    
    # Collaboration actions
    COMMENT = "comment"
    INVITE = "invite"
    SHARE = "share"
    
    # Report and export actions
    EXPORT = "export"
    GENERATE = "generate"
    DOWNLOAD = "download"
    
    # Channel/room actions
    ARCHIVE = "archive"
    JOIN = "join"
    LEAVE = "leave"
    
    # Assignment actions
    ASSIGN = "assign"
    UNASSIGN = "unassign"
    
    # Status change actions
    APPROVE = "approve"
    REJECT = "reject"
    COMPLETE = "complete"
    
    def __str__(self) -> str:
        return self.value


class Resource(str, Enum):
    """
    All protected resources in the TrackVault platform.
    Resources are combined with actions for permission checks.
    """
    # Project Service resources
    WORKSPACE = "workspace"
    PROJECT = "project"
    TASK = "task"
    SUBTASK = "subtask"
    MILESTONE = "milestone"
    LABEL = "label"
    TASK_TEMPLATE = "task_template"
    COMMENT = "comment"
    ACTIVITY = "activity"
    
    # VAPT Service resources
    VULNERABILITY = "vulnerability"
    ASSET = "asset"
    VAPT_TEMPLATE = "vapt_template"
    VAPT_REPORT = "vapt_report"
    
    # Chat Service resources
    CHANNEL = "channel"
    MESSAGE = "message"
    THREAD = "thread"
    
    # Knowledge Base resources
    KB_COLLECTION = "kb_collection"
    KB_DOCUMENT = "kb_document"
    KB_PAGE = "kb_page"
    
    # User management resources
    USER = "user"
    ROLE = "role"
    INVITATION = "invitation"
    
    # System resources
    SETTINGS = "settings"
    AUDIT_LOG = "audit_log"
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class Permission:
    """
    Represents a single permission (action + resource combination).
    
    Examples:
        - Permission(Action.CREATE, Resource.PROJECT) → "create:project"
        - Permission(Action.DELETE, Resource.TASK) → "delete:task"
    """
    action: Action
    resource: Resource
    
    def __str__(self) -> str:
        return f"{self.action}:{self.resource}"
    
    def __hash__(self) -> int:
        return hash((self.action, self.resource))
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Permission):
            return False
        return self.action == other.action and self.resource == other.resource
    
    @classmethod
    def from_string(cls, permission_str: str) -> "Permission":
        """
        Parse permission string to Permission object.
        
        Args:
            permission_str: String in format "action:resource" (e.g., "create:project")
            
        Returns:
            Permission object
            
        Raises:
            ValueError: If format is invalid
        """
        try:
            action_str, resource_str = permission_str.split(":", 1)
            action = Action(action_str.lower())
            resource = Resource(resource_str.lower())
            return cls(action, resource)
        except (ValueError, KeyError) as e:
            raise ValueError(
                f"Invalid permission format: {permission_str}. "
                f"Expected format: 'action:resource'"
            ) from e


# ============================================================================
# Permission Sets by Service
# ============================================================================

class ProjectServicePermissions:
    """Permission sets for Project Service resources"""
    
    # Project permissions
    CREATE_PROJECT = Permission(Action.CREATE, Resource.PROJECT)
    READ_PROJECT = Permission(Action.READ, Resource.PROJECT)
    UPDATE_PROJECT = Permission(Action.UPDATE, Resource.PROJECT)
    DELETE_PROJECT = Permission(Action.DELETE, Resource.PROJECT)
    MANAGE_PROJECT = Permission(Action.MANAGE, Resource.PROJECT)
    
    # Task permissions
    CREATE_TASK = Permission(Action.CREATE, Resource.TASK)
    READ_TASK = Permission(Action.READ, Resource.TASK)
    UPDATE_TASK = Permission(Action.UPDATE, Resource.TASK)
    DELETE_TASK = Permission(Action.DELETE, Resource.TASK)
    ASSIGN_TASK = Permission(Action.ASSIGN, Resource.TASK)
    
    # Milestone permissions
    CREATE_MILESTONE = Permission(Action.CREATE, Resource.MILESTONE)
    READ_MILESTONE = Permission(Action.READ, Resource.MILESTONE)
    UPDATE_MILESTONE = Permission(Action.UPDATE, Resource.MILESTONE)
    DELETE_MILESTONE = Permission(Action.DELETE, Resource.MILESTONE)
    
    # Label permissions
    CREATE_LABEL = Permission(Action.CREATE, Resource.LABEL)
    UPDATE_LABEL = Permission(Action.UPDATE, Resource.LABEL)
    DELETE_LABEL = Permission(Action.DELETE, Resource.LABEL)
    
    # Template permissions
    CREATE_TASK_TEMPLATE = Permission(Action.CREATE, Resource.TASK_TEMPLATE)
    UPDATE_TASK_TEMPLATE = Permission(Action.UPDATE, Resource.TASK_TEMPLATE)
    DELETE_TASK_TEMPLATE = Permission(Action.DELETE, Resource.TASK_TEMPLATE)
    
    # Comment permissions
    CREATE_COMMENT = Permission(Action.COMMENT, Resource.COMMENT)
    DELETE_COMMENT = Permission(Action.DELETE, Resource.COMMENT)


class VAPTServicePermissions:
    """Permission sets for VAPT Service resources"""
    
    # Vulnerability permissions
    CREATE_VULNERABILITY = Permission(Action.CREATE, Resource.VULNERABILITY)
    READ_VULNERABILITY = Permission(Action.READ, Resource.VULNERABILITY)
    UPDATE_VULNERABILITY = Permission(Action.UPDATE, Resource.VULNERABILITY)
    DELETE_VULNERABILITY = Permission(Action.DELETE, Resource.VULNERABILITY)
    
    # Asset permissions
    CREATE_ASSET = Permission(Action.CREATE, Resource.ASSET)
    READ_ASSET = Permission(Action.READ, Resource.ASSET)
    UPDATE_ASSET = Permission(Action.UPDATE, Resource.ASSET)
    DELETE_ASSET = Permission(Action.DELETE, Resource.ASSET)
    
    # VAPT Template permissions
    CREATE_VAPT_TEMPLATE = Permission(Action.CREATE, Resource.VAPT_TEMPLATE)
    UPDATE_VAPT_TEMPLATE = Permission(Action.UPDATE, Resource.VAPT_TEMPLATE)
    DELETE_VAPT_TEMPLATE = Permission(Action.DELETE, Resource.VAPT_TEMPLATE)
    MANAGE_VAPT_TEMPLATE = Permission(Action.MANAGE, Resource.VAPT_TEMPLATE)
    
    # Report permissions
    GENERATE_REPORT = Permission(Action.GENERATE, Resource.VAPT_REPORT)
    DOWNLOAD_REPORT = Permission(Action.DOWNLOAD, Resource.VAPT_REPORT)
    EXPORT_REPORT = Permission(Action.EXPORT, Resource.VAPT_REPORT)


class ChatServicePermissions:
    """Permission sets for Chat Service resources"""
    
    # Channel permissions
    CREATE_CHANNEL = Permission(Action.CREATE, Resource.CHANNEL)
    READ_CHANNEL = Permission(Action.READ, Resource.CHANNEL)
    UPDATE_CHANNEL = Permission(Action.UPDATE, Resource.CHANNEL)
    DELETE_CHANNEL = Permission(Action.DELETE, Resource.CHANNEL)
    ARCHIVE_CHANNEL = Permission(Action.ARCHIVE, Resource.CHANNEL)
    JOIN_CHANNEL = Permission(Action.JOIN, Resource.CHANNEL)
    LEAVE_CHANNEL = Permission(Action.LEAVE, Resource.CHANNEL)
    
    # Message permissions
    CREATE_MESSAGE = Permission(Action.CREATE, Resource.MESSAGE)
    READ_MESSAGE = Permission(Action.READ, Resource.MESSAGE)
    UPDATE_MESSAGE = Permission(Action.UPDATE, Resource.MESSAGE)
    DELETE_MESSAGE = Permission(Action.DELETE, Resource.MESSAGE)


class KnowledgeBasePermissions:
    """Permission sets for Knowledge Base Service resources"""
    
    # Collection permissions
    CREATE_KB_COLLECTION = Permission(Action.CREATE, Resource.KB_COLLECTION)
    READ_KB_COLLECTION = Permission(Action.READ, Resource.KB_COLLECTION)
    UPDATE_KB_COLLECTION = Permission(Action.UPDATE, Resource.KB_COLLECTION)
    DELETE_KB_COLLECTION = Permission(Action.DELETE, Resource.KB_COLLECTION)
    
    # Document permissions
    CREATE_KB_DOCUMENT = Permission(Action.CREATE, Resource.KB_DOCUMENT)
    READ_KB_DOCUMENT = Permission(Action.READ, Resource.KB_DOCUMENT)
    UPDATE_KB_DOCUMENT = Permission(Action.UPDATE, Resource.KB_DOCUMENT)
    DELETE_KB_DOCUMENT = Permission(Action.DELETE, Resource.KB_DOCUMENT)
    SHARE_KB_DOCUMENT = Permission(Action.SHARE, Resource.KB_DOCUMENT)


# ============================================================================
# Permission Groups for Common Operations
# ============================================================================

class PermissionGroups:
    """Pre-defined permission groups for common operations"""
    
    # Full project management
    PROJECT_FULL_ACCESS = {
        ProjectServicePermissions.CREATE_PROJECT,
        ProjectServicePermissions.READ_PROJECT,
        ProjectServicePermissions.UPDATE_PROJECT,
        ProjectServicePermissions.DELETE_PROJECT,
        ProjectServicePermissions.MANAGE_PROJECT,
    }
    
    # Task management
    TASK_FULL_ACCESS = {
        ProjectServicePermissions.CREATE_TASK,
        ProjectServicePermissions.READ_TASK,
        ProjectServicePermissions.UPDATE_TASK,
        ProjectServicePermissions.DELETE_TASK,
        ProjectServicePermissions.ASSIGN_TASK,
    }
    
    # VAPT full access
    VAPT_FULL_ACCESS = {
        VAPTServicePermissions.CREATE_VULNERABILITY,
        VAPTServicePermissions.READ_VULNERABILITY,
        VAPTServicePermissions.UPDATE_VULNERABILITY,
        VAPTServicePermissions.DELETE_VULNERABILITY,
        VAPTServicePermissions.CREATE_ASSET,
        VAPTServicePermissions.READ_ASSET,
        VAPTServicePermissions.UPDATE_ASSET,
        VAPTServicePermissions.MANAGE_VAPT_TEMPLATE,
        VAPTServicePermissions.GENERATE_REPORT,
    }
    
    # Chat access
    CHAT_FULL_ACCESS = {
        ChatServicePermissions.CREATE_CHANNEL,
        ChatServicePermissions.READ_CHANNEL,
        ChatServicePermissions.UPDATE_CHANNEL,
        ChatServicePermissions.DELETE_CHANNEL,
        ChatServicePermissions.ARCHIVE_CHANNEL,
        ChatServicePermissions.CREATE_MESSAGE,
        ChatServicePermissions.READ_MESSAGE,
    }
    
    # Knowledge base access
    KB_FULL_ACCESS = {
        KnowledgeBasePermissions.CREATE_KB_COLLECTION,
        KnowledgeBasePermissions.READ_KB_COLLECTION,
        KnowledgeBasePermissions.UPDATE_KB_COLLECTION,
        KnowledgeBasePermissions.DELETE_KB_COLLECTION,
        KnowledgeBasePermissions.CREATE_KB_DOCUMENT,
        KnowledgeBasePermissions.READ_KB_DOCUMENT,
        KnowledgeBasePermissions.UPDATE_KB_DOCUMENT,
        KnowledgeBasePermissions.DELETE_KB_DOCUMENT,
    }


def parse_permissions(permission_strings: List[str]) -> Set[Permission]:
    """
    Parse a list of permission strings into Permission objects.
    
    Args:
        permission_strings: List of strings in format "action:resource"
        
    Returns:
        Set of Permission objects
    """
    permissions = set()
    for perm_str in permission_strings:
        try:
            permissions.add(Permission.from_string(perm_str))
        except ValueError:
            # Skip invalid permissions
            continue
    return permissions


def get_all_permissions() -> Set[Permission]:
    """Get all defined permissions across all services"""
    all_perms = set()
    
    # Project Service permissions
    for attr_name in dir(ProjectServicePermissions):
        if not attr_name.startswith('_'):
            attr = getattr(ProjectServicePermissions, attr_name)
            if isinstance(attr, Permission):
                all_perms.add(attr)
    
    # VAPT Service permissions
    for attr_name in dir(VAPTServicePermissions):
        if not attr_name.startswith('_'):
            attr = getattr(VAPTServicePermissions, attr_name)
            if isinstance(attr, Permission):
                all_perms.add(attr)
    
    # Chat Service permissions
    for attr_name in dir(ChatServicePermissions):
        if not attr_name.startswith('_'):
            attr = getattr(ChatServicePermissions, attr_name)
            if isinstance(attr, Permission):
                all_perms.add(attr)
    
    # Knowledge Base permissions
    for attr_name in dir(KnowledgeBasePermissions):
        if not attr_name.startswith('_'):
            attr = getattr(KnowledgeBasePermissions, attr_name)
            if isinstance(attr, Permission):
                all_perms.add(attr)
    
    return all_perms

