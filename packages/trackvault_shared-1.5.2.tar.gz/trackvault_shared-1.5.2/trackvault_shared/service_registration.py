"""
Service Registration Utility
Auto-registers services with service registry on startup

Time Complexity: O(1) per registration
Space Complexity: O(1)
"""
import httpx
import asyncio
import logging
from typing import Optional
import os

logger = logging.getLogger(__name__)


async def register_service_with_registry(
    service_name: str,
    service_url: str,
    health_check_url: str,
    registry_url: str,
    version: Optional[str] = None,
    environment: Optional[str] = None,
    service_token: Optional[str] = None,
    max_retries: int = 3
) -> bool:
    """
    Register a service with the service registry
    
    Args:
        service_name: Name of the service (e.g., 'project-service')
        service_url: Base URL of the service
        health_check_url: Health check endpoint URL
        registry_url: Service registry URL (Auth Service)
        version: Optional service version
        environment: Optional environment (development, staging, production)
        service_token: Optional service token for authentication
        max_retries: Maximum retry attempts
        
    Returns:
        True if registration successful, False otherwise
    """
    # Get instance ID (hostname or container ID)
    registered_by = os.getenv("HOSTNAME") or os.getenv("CONTAINER_ID") or "unknown"
    
    payload = {
        "service_name": service_name,
        "service_url": service_url,
        "health_check_url": health_check_url,
        "version": version,
        "environment": environment or os.getenv("ENVIRONMENT", "development"),
        "registered_by": registered_by
    }
    
    headers = {}
    if service_token:
        headers["X-Service-Token"] = service_token
    
    for attempt in range(max_retries):
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.post(
                    f"{registry_url}/internal/v1/registry/register",
                    json=payload,
                    headers=headers
                )
                
                if response.status_code in [200, 201]:
                    logger.info(
                        f"Service {service_name} registered successfully with registry",
                        service_url=service_url,
                        attempt=attempt + 1
                    )
                    return True
                else:
                    logger.warning(
                        f"Service registration failed: {response.status_code}",
                        service_name=service_name,
                        response_text=response.text[:200],
                        attempt=attempt + 1
                    )
        except httpx.TimeoutException:
            logger.warning(
                f"Service registration timeout (attempt {attempt + 1}/{max_retries})",
                service_name=service_name
            )
        except httpx.RequestError as e:
            logger.warning(
                f"Service registration request error (attempt {attempt + 1}/{max_retries}): {e}",
                service_name=service_name
            )
        except Exception as e:
            logger.error(
                f"Unexpected error during service registration: {e}",
                service_name=service_name,
                exc_info=True
            )
        
        # Wait before retry (exponential backoff)
        if attempt < max_retries - 1:
            await asyncio.sleep(2 ** attempt)  # 1s, 2s, 4s...
    
    logger.error(
        f"Failed to register service {service_name} after {max_retries} attempts",
        registry_url=registry_url
    )
    return False


async def unregister_service_from_registry(
    service_name: str,
    registry_url: str,
    service_token: Optional[str] = None
) -> bool:
    """
    Unregister a service from the service registry
    
    Called on graceful shutdown.
    
    Args:
        service_name: Name of the service
        registry_url: Service registry URL
        service_token: Optional service token
        
    Returns:
        True if unregistration successful, False otherwise
    """
    headers = {}
    if service_token:
        headers["X-Service-Token"] = service_token
    
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.delete(
                f"{registry_url}/internal/v1/registry/services/{service_name}",
                headers=headers
            )
            
            if response.status_code in [200, 204]:
                logger.info(f"Service {service_name} unregistered successfully")
                return True
            else:
                logger.warning(
                    f"Service unregistration returned {response.status_code}",
                    service_name=service_name
                )
                return False
    except Exception as e:
        logger.warning(f"Error unregistering service {service_name}: {e}")
        return False

