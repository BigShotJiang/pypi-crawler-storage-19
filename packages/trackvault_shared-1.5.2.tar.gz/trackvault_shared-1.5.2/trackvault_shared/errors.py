"""
Standard Error Response Format
Industry Standard: RFC 7807 Problem Details for HTTP APIs

Time Complexity: O(1)
Space Complexity: O(1)
"""
from typing import Optional, Dict, Any
from trackvault_shared.tracing import get_request_id, get_trace_id


class StandardErrorResponse:
    """Standard error response format following RFC 7807"""
    
    @staticmethod
    def create(
        title: str,
        status: int,
        detail: str,
        error_type: Optional[str] = None,
        instance: Optional[str] = None,
        additional_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create standard error response
        Industry Standard: RFC 7807 Problem Details for HTTP APIs
        
        Args:
            title: Short, human-readable summary
            status: HTTP status code
            detail: Human-readable explanation
            error_type: URI identifying the problem type
            instance: URI identifying the specific occurrence
            additional_data: Optional additional fields
            
        Returns:
            Standard error response dict
        """
        error = {
            "type": error_type or f"https://api.trackvault.com/errors/{status}",
            "title": title,
            "status": status,
            "detail": detail,
            "instance": instance or "/",
            "request_id": get_request_id(),
            "trace_id": get_trace_id()
        }
        
        if additional_data:
            error.update(additional_data)
        
        return error
    
    @staticmethod
    def unauthorized(detail: str = "Unauthorized", instance: Optional[str] = None) -> Dict[str, Any]:
        """Create 401 Unauthorized error"""
        return StandardErrorResponse.create(
            title="Unauthorized",
            status=401,
            detail=detail,
            error_type="https://api.trackvault.com/errors/unauthorized",
            instance=instance
        )
    
    @staticmethod
    def forbidden(detail: str = "Forbidden", instance: Optional[str] = None) -> Dict[str, Any]:
        """Create 403 Forbidden error"""
        return StandardErrorResponse.create(
            title="Forbidden",
            status=403,
            detail=detail,
            error_type="https://api.trackvault.com/errors/forbidden",
            instance=instance
        )
    
    @staticmethod
    def not_found(resource: str = "Resource", instance: Optional[str] = None) -> Dict[str, Any]:
        """Create 404 Not Found error"""
        return StandardErrorResponse.create(
            title="Not Found",
            status=404,
            detail=f"{resource} not found",
            error_type="https://api.trackvault.com/errors/not-found",
            instance=instance
        )
    
    @staticmethod
    def validation_error(detail: str, errors: Optional[Dict[str, Any]] = None, instance: Optional[str] = None) -> Dict[str, Any]:
        """Create 422 Validation Error"""
        error = StandardErrorResponse.create(
            title="Validation Error",
            status=422,
            detail=detail,
            error_type="https://api.trackvault.com/errors/validation-error",
            instance=instance
        )
        if errors:
            error["errors"] = errors
        return error
    
    @staticmethod
    def internal_error(detail: str = "Internal Server Error", instance: Optional[str] = None) -> Dict[str, Any]:
        """Create 500 Internal Server Error"""
        return StandardErrorResponse.create(
            title="Internal Server Error",
            status=500,
            detail=detail,
            error_type="https://api.trackvault.com/errors/internal-error",
            instance=instance
        )

