"""
Shared data models for TrackVault microservices
"""

from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class EventData(BaseModel):
    """Standard event data structure"""
    event_type: str = Field(..., description="Type of event")
    data: Dict[str, Any] = Field(..., description="Event payload data")
    timestamp: str = Field(..., description="ISO timestamp of event")
    source_service: str = Field(..., description="Service that published the event")
    event_id: str = Field(..., description="Unique event identifier")

class UserProfile(BaseModel):
    """User profile data model"""
    user_id: str = Field(..., description="Unique user identifier")
    email: str = Field(..., description="User email address")
    full_name: Optional[str] = Field(None, description="User's full name")
    display_name: Optional[str] = Field(None, description="User's display name")
    tenant_id: str = Field(..., description="Tenant identifier")
    created_at: Optional[datetime] = Field(None, description="Account creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")

class WorkspaceMember(BaseModel):
    """Workspace member data model"""
    user_id: str = Field(..., description="User identifier")
    email: str = Field(..., description="User email")
    full_name: Optional[str] = Field(None, description="User's full name")
    role: str = Field(..., description="Member role in workspace")
    is_active: bool = Field(True, description="Whether member is active")
    joined_at: Optional[datetime] = Field(None, description="When member joined")

class ServiceHealth(BaseModel):
    """Service health check model"""
    service_name: str = Field(..., description="Name of the service")
    status: str = Field(..., description="Health status (healthy/unhealthy)")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    version: Optional[str] = Field(None, description="Service version")
    dependencies: Dict[str, str] = Field(default_factory=dict, description="Dependency statuses")
