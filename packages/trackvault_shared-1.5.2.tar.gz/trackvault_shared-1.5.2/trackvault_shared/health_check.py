"""
Health Check Implementation
Provides comprehensive health status for microservices
"""

import asyncio
import time
from datetime import datetime
from typing import Dict, Any, Optional
import logging
from enum import Enum

logger = logging.getLogger(__name__)

class HealthStatus(Enum):
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"

class HealthChecker:
    """Health checker for microservice components"""
    
    def __init__(self):
        self.checks = {}
        self.start_time = time.time()
    
    def add_check(self, name: str, check_func: callable, critical: bool = True):
        """Add a health check function"""
        self.checks[name] = {
            "func": check_func,
            "critical": critical,
            "last_check": None,
            "last_result": None
        }
    
    async def check_all(self) -> Dict[str, Any]:
        """Run all health checks"""
        results = {}
        overall_status = HealthStatus.HEALTHY
        critical_failures = 0
        
        for name, check_info in self.checks.items():
            try:
                start_time = time.time()
                result = await check_info["func"]()
                duration = time.time() - start_time
                
                check_info["last_check"] = datetime.utcnow().isoformat()
                check_info["last_result"] = result
                
                results[name] = {
                    "status": "healthy",
                    "duration_ms": round(duration * 1000, 2),
                    "details": result
                }
                
            except Exception as e:
                duration = time.time() - start_time
                check_info["last_check"] = datetime.utcnow().isoformat()
                check_info["last_result"] = {"error": str(e)}
                
                results[name] = {
                    "status": "unhealthy",
                    "duration_ms": round(duration * 1000, 2),
                    "error": str(e)
                }
                
                if check_info["critical"]:
                    critical_failures += 1
                    overall_status = HealthStatus.UNHEALTHY
                elif overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
        
        return {
            "status": overall_status.value,
            "timestamp": datetime.utcnow().isoformat(),
            "uptime_seconds": round(time.time() - self.start_time, 2),
            "checks": results,
            "summary": {
                "total_checks": len(self.checks),
                "healthy_checks": len([r for r in results.values() if r["status"] == "healthy"]),
                "unhealthy_checks": len([r for r in results.values() if r["status"] == "unhealthy"]),
                "critical_failures": critical_failures
            }
        }

# Common health check functions
async def check_database_connection() -> Dict[str, Any]:
    """Check database connectivity"""
    try:
        # This would be implemented based on your database
        # For MongoDB with Beanie:
        from app.core.database import get_database
        db = get_database()
        await db.command("ping")
        return {"message": "Database connection successful"}
    except Exception as e:
        raise Exception(f"Database connection failed: {str(e)}")

async def check_redis_connection() -> Dict[str, Any]:
    """Check Redis connectivity"""
    try:
        from trackvault_shared.event_bus import get_auth_event_bus
        event_bus = get_auth_event_bus()
        await event_bus.redis.ping()
        return {"message": "Redis connection successful"}
    except Exception as e:
        raise Exception(f"Redis connection failed: {str(e)}")

async def check_disk_space() -> Dict[str, Any]:
    """Check available disk space"""
    import shutil
    try:
        total, used, free = shutil.disk_usage("/")
        free_percent = (free / total) * 100
        
        if free_percent < 10:
            raise Exception(f"Low disk space: {free_percent:.1f}% free")
        
        return {
            "total_gb": round(total / (1024**3), 2),
            "used_gb": round(used / (1024**3), 2),
            "free_gb": round(free / (1024**3), 2),
            "free_percent": round(free_percent, 1)
        }
    except Exception as e:
        raise Exception(f"Disk space check failed: {str(e)}")

async def check_memory_usage() -> Dict[str, Any]:
    """Check memory usage"""
    try:
        import psutil
        memory = psutil.virtual_memory()
        
        if memory.percent > 90:
            raise Exception(f"High memory usage: {memory.percent}%")
        
        return {
            "total_gb": round(memory.total / (1024**3), 2),
            "used_gb": round(memory.used / (1024**3), 2),
            "free_gb": round(memory.available / (1024**3), 2),
            "usage_percent": memory.percent
        }
    except Exception as e:
        raise Exception(f"Memory check failed: {str(e)}")

# Global health checker instances
auth_health_checker = HealthChecker()
project_health_checker = HealthChecker()

# Add common checks
auth_health_checker.add_check("database", check_database_connection, critical=True)
auth_health_checker.add_check("redis", check_redis_connection, critical=True)
auth_health_checker.add_check("disk_space", check_disk_space, critical=False)
auth_health_checker.add_check("memory", check_memory_usage, critical=False)

project_health_checker.add_check("database", check_database_connection, critical=True)
project_health_checker.add_check("redis", check_redis_connection, critical=True)
project_health_checker.add_check("disk_space", check_disk_space, critical=False)
project_health_checker.add_check("memory", check_memory_usage, critical=False)
