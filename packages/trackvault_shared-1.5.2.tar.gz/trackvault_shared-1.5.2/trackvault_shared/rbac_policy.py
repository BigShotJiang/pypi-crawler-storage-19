"""
RBAC Policy Engine for TrackVault

This module implements the core RBAC policy evaluation logic with:
- Role-based permission checks
- Ownership-aware access control
- Configurable policy overrides
- Workspace-scoped enforcement

CRITICAL RULES:
1. Source of truth is WORKSPACE membership, not tenant
2. Ownership checks are separate from role checks
3. Default deny on ambiguity
4. Configuration flags can override default policies
5. Backend enforcement only - never trust frontend
"""

from typing import Optional, Dict, Any, Set
from dataclasses import dataclass
import structlog

from .rbac_roles import Role, get_role_capabilities, ROLE_CAPABILITIES
from .rbac_permissions import Permission, Action, Resource

logger = structlog.get_logger(__name__)


@dataclass
class AccessContext:
    """
    Context information for access control decisions.
    Contains all information needed to make an authorization decision.
    """
    # Actor information
    user_id: str
    role: Role
    workspace_id: str
    tenant_id: str
    
    # Resource information
    resource_type: Resource
    resource_id: Optional[str] = None
    resource_owner_id: Optional[str] = None
    project_id: Optional[str] = None
    
    # Additional context
    action: Action = Action.READ
    is_public_resource: bool = False
    is_explicitly_granted: bool = False
    
    def is_owner_of_resource(self) -> bool:
        """Check if user is the owner of the resource"""
        if not self.resource_owner_id:
            return False
        return self.user_id == self.resource_owner_id


@dataclass
class PolicyConfig:
    """
    Configuration for policy overrides and feature flags.
    These can be loaded from database or environment.
    """
    # Project deletion policy
    allow_managers_delete_any_project: bool = False
    
    # VAPT template management policy
    allow_managers_manage_vapt_templates: bool = False
    
    # Comment policy
    allow_guests_comment: bool = False
    
    # Channel discovery policy
    allow_members_discover_public_channels: bool = True
    
    # Task editing policy (already enabled by default for members)
    allow_members_edit_any_task: bool = True
    
    # Milestone viewing policy
    allow_guests_view_milestones: bool = False
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "PolicyConfig":
        """Create PolicyConfig from dictionary (e.g., from database)"""
        return cls(
            allow_managers_delete_any_project=config_dict.get(
                "allow_managers_delete_any_project", False
            ),
            allow_managers_manage_vapt_templates=config_dict.get(
                "allow_managers_manage_vapt_templates", False
            ),
            allow_guests_comment=config_dict.get("allow_guests_comment", False),
            allow_members_discover_public_channels=config_dict.get(
                "allow_members_discover_public_channels", True
            ),
            allow_members_edit_any_task=config_dict.get(
                "allow_members_edit_any_task", True
            ),
            allow_guests_view_milestones=config_dict.get(
                "allow_guests_view_milestones", False
            ),
        )


class RBACPolicyEngine:
    """
    Core RBAC policy evaluation engine.
    
    Responsibilities:
    - Evaluate role-based permissions
    - Check ownership constraints
    - Apply configurable policy overrides
    - Enforce workspace-scoped access
    - Log authorization decisions
    """
    
    def __init__(self, policy_config: Optional[PolicyConfig] = None):
        """
        Initialize the RBAC policy engine.
        
        Args:
            policy_config: Optional policy configuration for overrides
        """
        self.policy_config = policy_config or PolicyConfig()
        self.logger = logger.bind(component="rbac_policy_engine")
    
    def has_permission(
        self,
        context: AccessContext,
        permission: Permission,
        check_ownership: bool = False
    ) -> tuple[bool, Optional[str]]:
        """
        Check if user has permission to perform an action on a resource.
        
        Args:
            context: Access control context
            permission: Permission to check
            check_ownership: Whether to enforce ownership check
            
        Returns:
            (has_permission, denial_reason)
        """
        # Step 1: Get role capabilities
        role_caps = get_role_capabilities(context.role)
        
        # Step 2: Check if role is sandboxed (Guest)
        if role_caps.is_sandboxed and not context.is_explicitly_granted:
            return False, "Guest role requires explicit resource access grant"
        
        # Step 3: Check workspace membership (assumed validated before this point)
        # This check should happen at API gateway / middleware level
        
        # Step 4: Evaluate permission based on action and resource
        has_perm, reason = self._evaluate_permission(
            context=context,
            permission=permission,
            role_caps=role_caps
        )
        
        if not has_perm:
            return False, reason
        
        # Step 5: Apply ownership check if required
        if check_ownership:
            is_owner_check_passed, owner_reason = self._check_ownership(
                context=context,
                permission=permission,
                role_caps=role_caps
            )
            if not is_owner_check_passed:
                return False, owner_reason
        
        # Step 6: Log successful authorization
        self.logger.info(
            "authorization_granted",
            user_id=context.user_id,
            role=str(context.role),
            workspace_id=context.workspace_id,
            permission=str(permission),
            resource_id=context.resource_id,
        )
        
        return True, None
    
    def _evaluate_permission(
        self,
        context: AccessContext,
        permission: Permission,
        role_caps
    ) -> tuple[bool, Optional[str]]:
        """
        Evaluate permission based on role and action/resource combination.
        
        This is the core permission evaluation logic that maps permissions
        to role capabilities with configurable overrides.
        """
        action = permission.action
        resource = permission.resource
        
        # ===== PROJECT SERVICE PERMISSIONS =====
        
        if resource == Resource.PROJECT:
            if action == Action.CREATE:
                if role_caps.can_create_projects:
                    return True, None
                return False, "Role does not have permission to create projects"
            
            elif action == Action.DELETE:
                # Configurable override for managers
                if context.role == Role.MANAGER:
                    if self.policy_config.allow_managers_delete_any_project:
                        return True, None
                    # Manager can only delete owned projects (checked separately)
                    return True, None  # Ownership check handles the rest
                
                if role_caps.can_delete_any_project:
                    return True, None
                return False, "Role does not have permission to delete projects"
            
            elif action in [Action.UPDATE, Action.MANAGE]:
                if role_caps.can_edit_any_project:
                    return True, None
                return False, "Role does not have permission to edit projects"
            
            elif action == Action.READ:
                # All workspace members can read projects
                return True, None
        
        elif resource == Resource.TASK:
            if action == Action.CREATE:
                if role_caps.can_create_tasks:
                    return True, None
                return False, "Role does not have permission to create tasks"
            
            elif action == Action.UPDATE:
                if role_caps.can_edit_any_task:
                    return True, None
                return False, "Role does not have permission to edit tasks"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_any_task:
                    return True, None
                # Members can delete owned tasks (ownership check required)
                if role_caps.can_delete_owned_tasks:
                    return True, None
                return False, "Role does not have permission to delete tasks"
            
            elif action == Action.READ:
                # All workspace members except guests can read tasks
                if context.role != Role.GUEST:
                    return True, None
                return False, "Guests cannot read tasks without explicit access"
        
        elif resource == Resource.MILESTONE:
            if action == Action.CREATE:
                if role_caps.can_create_milestones:
                    return True, None
                return False, "Role does not have permission to create milestones"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_any_milestone:
                    return True, None
                if role_caps.can_delete_owned_milestones:
                    return True, None  # Ownership check required
                return False, "Role does not have permission to delete milestones"
            
            elif action == Action.READ:
                # Members and above can read milestones
                if context.role in [Role.OWNER, Role.ADMIN, Role.MANAGER, Role.MEMBER]:
                    return True, None
                # Guests can read only if configured
                if self.policy_config.allow_guests_view_milestones:
                    return True, None
                return False, "Guests cannot view milestones"
        
        elif resource == Resource.COMMENT:
            if action == Action.COMMENT:
                if context.role == Role.GUEST:
                    if self.policy_config.allow_guests_comment:
                        return True, None
                    return False, "Guests cannot comment without explicit permission"
                if role_caps.can_comment:
                    return True, None
                return False, "Role does not have permission to comment"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_any_comment:
                    return True, None
                # Users can delete their own comments (ownership check required)
                return True, None
        
        # ===== VAPT SERVICE PERMISSIONS =====
        
        elif resource == Resource.VAPT_TEMPLATE:
            if action in [Action.CREATE, Action.UPDATE, Action.MANAGE]:
                # Configurable override for managers
                if context.role == Role.MANAGER:
                    if self.policy_config.allow_managers_manage_vapt_templates:
                        return True, None
                    return False, "Managers cannot manage VAPT templates (policy disabled)"
                
                if role_caps.can_manage_vapt_templates:
                    return True, None
                return False, "Role does not have permission to manage VAPT templates"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_vapt_templates:
                    return True, None
                return False, "Role does not have permission to delete VAPT templates"
        
        elif resource == Resource.VULNERABILITY:
            if action == Action.CREATE:
                if role_caps.can_submit_vulnerabilities:
                    return True, None
                return False, "Role does not have permission to submit vulnerabilities"
            
            elif action == Action.UPDATE:
                if role_caps.can_edit_any_vulnerability:
                    return True, None
                if role_caps.can_edit_owned_vulnerabilities:
                    return True, None  # Ownership check required
                return False, "Role does not have permission to edit vulnerabilities"
            
            elif action == Action.READ:
                # All workspace members except guests can read vulnerabilities
                if context.role != Role.GUEST:
                    return True, None
                return False, "Guests cannot read vulnerabilities"
        
        elif resource == Resource.ASSET:
            if action in [Action.CREATE, Action.UPDATE]:
                if role_caps.can_manage_assets:
                    return True, None
                return False, "Role does not have permission to manage assets"
            
            elif action == Action.READ:
                # All workspace members can read assets
                if context.role != Role.GUEST:
                    return True, None
                return False, "Guests cannot read assets"
        
        elif resource == Resource.VAPT_REPORT:
            if action in [Action.GENERATE, Action.DOWNLOAD, Action.EXPORT]:
                if role_caps.can_generate_reports:
                    return True, None
                return False, "Role does not have permission to generate reports"
        
        # ===== CHAT SERVICE PERMISSIONS =====
        
        elif resource == Resource.CHANNEL:
            if action == Action.CREATE:
                if role_caps.can_create_channels:
                    return True, None
                return False, "Role does not have permission to create channels"
            
            elif action == Action.ARCHIVE:
                if role_caps.can_archive_channels:
                    return True, None
                return False, "Role does not have permission to archive channels"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_channels:
                    return True, None
                return False, "Only Owner can permanently delete channels"
            
            elif action == Action.JOIN:
                # Public channels
                if context.is_public_resource:
                    if context.role != Role.GUEST:
                        return True, None
                    return False, "Guests cannot join public channels"
                # Private channels require explicit invite
                return False, "Private channel requires invitation"
        
        # ===== KNOWLEDGE BASE PERMISSIONS =====
        
        elif resource == Resource.KB_COLLECTION:
            if action == Action.CREATE:
                if role_caps.can_create_kb_collections:
                    return True, None
                return False, "Role does not have permission to create KB collections"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_any_kb_item:
                    return True, None
                if role_caps.can_delete_owned_kb_items:
                    return True, None  # Ownership check required
                return False, "Role does not have permission to delete KB collections"
        
        elif resource == Resource.KB_DOCUMENT:
            if action == Action.CREATE:
                if role_caps.can_create_kb_collections:
                    return True, None
                return False, "Role does not have permission to create KB documents"
            
            elif action == Action.UPDATE:
                if role_caps.can_edit_kb_documents:
                    return True, None
                return False, "Role does not have permission to edit KB documents"
            
            elif action == Action.DELETE:
                if role_caps.can_delete_any_kb_item:
                    return True, None
                if role_caps.can_delete_owned_kb_items:
                    return True, None  # Ownership check required
                return False, "Role does not have permission to delete KB documents"
        
        # Default: deny unknown permissions
        return False, f"Unknown permission: {permission}"
    
    def _check_ownership(
        self,
        context: AccessContext,
        permission: Permission,
        role_caps
    ) -> tuple[bool, Optional[str]]:
        """
        Check ownership constraints for resources that require it.
        
        Ownership checks are applied for deletion of:
        - Projects (Manager role)
        - Tasks (Member role)
        - Milestones (Manager role)
        - Comments (all roles)
        - Vulnerabilities (Member role)
        - KB items (Member role)
        """
        action = permission.action
        resource = permission.resource
        
        # Owner/Admin bypass all ownership checks
        if context.role in [Role.OWNER, Role.ADMIN]:
            return True, None
        
        # Check if user is owner of resource
        is_owner = context.is_owner_of_resource()
        
        # Project deletion ownership check (Manager)
        if resource == Resource.PROJECT and action == Action.DELETE:
            if context.role == Role.MANAGER:
                if not self.policy_config.allow_managers_delete_any_project:
                    if not is_owner:
                        return False, "Managers can only delete projects they created"
        
        # Task deletion ownership check (Member)
        if resource == Resource.TASK and action == Action.DELETE:
            if context.role == Role.MEMBER:
                if not is_owner:
                    return False, "Members can only delete tasks they created"
        
        # Milestone deletion ownership check (Manager)
        if resource == Resource.MILESTONE and action == Action.DELETE:
            if context.role == Role.MANAGER:
                if not is_owner:
                    return False, "Managers can only delete milestones they created"
        
        # Comment deletion ownership check (all roles)
        if resource == Resource.COMMENT and action == Action.DELETE:
            if context.role not in [Role.OWNER, Role.ADMIN]:
                if not is_owner:
                    return False, "Users can only delete comments they created"
        
        # Vulnerability editing ownership check (Member)
        if resource == Resource.VULNERABILITY and action == Action.UPDATE:
            if context.role == Role.MEMBER:
                if not is_owner:
                    return False, "Members can only edit vulnerabilities they submitted"
        
        # KB item deletion ownership check (Member)
        if resource in [Resource.KB_COLLECTION, Resource.KB_DOCUMENT] and action == Action.DELETE:
            if context.role == Role.MEMBER:
                if not is_owner:
                    return False, "Members can only delete KB items they created"
        
        return True, None
    
    def can_modify_user_role(
        self,
        actor_role: Role,
        target_current_role: Role,
        target_new_role: Role
    ) -> tuple[bool, Optional[str]]:
        """
        Check if actor can modify a user's role.
        
        Rules:
        - Only Owner can add/remove Admins
        - Owner cannot be downgraded
        - Only Owner/Admin can modify other roles
        """
        from .rbac_roles import validate_role_change
        return validate_role_change(target_current_role, target_new_role, actor_role)


# Global policy engine instance (can be configured per service)
_global_policy_engine: Optional[RBACPolicyEngine] = None


def get_policy_engine(policy_config: Optional[PolicyConfig] = None) -> RBACPolicyEngine:
    """
    Get the global policy engine instance.
    
    Args:
        policy_config: Optional policy configuration (will initialize if not set)
        
    Returns:
        RBACPolicyEngine instance
    """
    global _global_policy_engine
    if _global_policy_engine is None or policy_config is not None:
        _global_policy_engine = RBACPolicyEngine(policy_config)
    return _global_policy_engine


def has_permission(
    user_id: str,
    role: Role,
    workspace_id: str,
    tenant_id: str,
    action: Action,
    resource: Resource,
    resource_id: Optional[str] = None,
    resource_owner_id: Optional[str] = None,
    check_ownership: bool = False,
    policy_config: Optional[PolicyConfig] = None
) -> tuple[bool, Optional[str]]:
    """
    Convenience function for checking permissions.
    
    Args:
        user_id: User ID
        role: User's role
        workspace_id: Workspace ID
        tenant_id: Tenant ID
        action: Action to perform
        resource: Resource type
        resource_id: Optional resource ID
        resource_owner_id: Optional resource owner ID
        check_ownership: Whether to enforce ownership check
        policy_config: Optional policy configuration
        
    Returns:
        (has_permission, denial_reason)
    """
    context = AccessContext(
        user_id=user_id,
        role=role,
        workspace_id=workspace_id,
        tenant_id=tenant_id,
        resource_type=resource,
        resource_id=resource_id,
        resource_owner_id=resource_owner_id,
        action=action
    )
    
    permission = Permission(action, resource)
    engine = get_policy_engine(policy_config)
    
    return engine.has_permission(context, permission, check_ownership)

