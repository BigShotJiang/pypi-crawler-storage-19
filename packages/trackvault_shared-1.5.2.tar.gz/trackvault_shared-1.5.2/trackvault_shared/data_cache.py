"""
Event-Driven Data Cache Service
Caches user, workspace, and project data locally with event-driven updates

Time Complexity: O(1) for cache operations
Space Complexity: O(n) where n = number of cached items
"""

import json
import logging
from typing import Optional, Dict, Any, Callable
from datetime import datetime, timedelta
import redis.asyncio as aioredis
from trackvault_shared.event_bus import EventBus

logger = logging.getLogger(__name__)


class DataCacheService:
    """
    Production-ready data cache service with event-driven updates
    
    Features:
    - Redis-backed caching with TTL
    - Event-driven cache invalidation/updates
    - HTTP fallback on cache miss
    - Automatic cache refresh on events
    
    Designed for 3000+ concurrent users with high cache hit rates.
    """
    
    def __init__(
        self,
        redis_url: str,
        service_name: str,
        default_ttl: int = 3600,  # 1 hour default TTL
        event_bus: Optional[EventBus] = None
    ):
        """
        Initialize data cache service
        
        Args:
            redis_url: Redis connection URL
            service_name: Name of the service using this cache
            default_ttl: Default TTL in seconds
            event_bus: Optional event bus for event-driven updates
        """
        self.redis_url = redis_url
        self.service_name = service_name
        self.default_ttl = default_ttl
        self.event_bus = event_bus
        self.redis: Optional[aioredis.Redis] = None
        self._connected = False
    
    async def connect(self):
        """Connect to Redis"""
        if not self._connected:
            try:
                self.redis = aioredis.from_url(
                    self.redis_url,
                    decode_responses=True
                )
                await self.redis.ping()
                self._connected = True
                logger.info(f"DataCacheService connected to Redis for {self.service_name}")
            except Exception as e:
                logger.error(f"Failed to connect to Redis: {e}")
                raise
    
    async def disconnect(self):
        """Disconnect from Redis"""
        if self.redis:
            await self.redis.close()
            self._connected = False
            logger.info(f"DataCacheService disconnected from Redis for {self.service_name}")
    
    def _get_cache_key(self, cache_type: str, entity_id: str, context: Optional[str] = None) -> str:
        """
        Generate cache key
        
        Format: cache:{service}:{type}:{id}:{context}
        """
        key_parts = ["cache", self.service_name, cache_type, entity_id]
        if context:
            key_parts.append(context)
        return ":".join(key_parts)
    
    async def get(
        self,
        cache_type: str,
        entity_id: str,
        context: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Get cached data
        
        Args:
            cache_type: Type of cache (user, workspace, project, etc.)
            entity_id: Entity ID
            context: Optional context (e.g., workspace_id)
            
        Returns:
            Cached data as dict, or None if not found
        """
        if not self._connected:
            await self.connect()
        
        try:
            cache_key = self._get_cache_key(cache_type, entity_id, context)
            cached_data = await self.redis.get(cache_key)
            
            if cached_data:
                data = json.loads(cached_data)
                logger.debug(
                    f"Cache hit: {cache_type}:{entity_id}",
                    extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id}
                )
                return data
            
            logger.debug(
                f"Cache miss: {cache_type}:{entity_id}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id}
            )
            return None
            
        except Exception as e:
            logger.error(
                f"Error getting cache: {e}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id},
                exc_info=True
            )
            return None
    
    async def set(
        self,
        cache_type: str,
        entity_id: str,
        data: Dict[str, Any],
        ttl: Optional[int] = None,
        context: Optional[str] = None
    ):
        """
        Set cached data
        
        Args:
            cache_type: Type of cache (user, workspace, project, etc.)
            entity_id: Entity ID
            data: Data to cache
            ttl: Optional TTL in seconds (uses default if None)
            context: Optional context (e.g., workspace_id)
        """
        if not self._connected:
            await self.connect()
        
        try:
            cache_key = self._get_cache_key(cache_type, entity_id, context)
            ttl = ttl or self.default_ttl
            
            # Add metadata
            cached_data = {
                "data": data,
                "cached_at": datetime.utcnow().isoformat(),
                "ttl": ttl
            }
            
            await self.redis.setex(
                cache_key,
                ttl,
                json.dumps(cached_data)
            )
            
            logger.debug(
                f"Cache set: {cache_type}:{entity_id} (TTL: {ttl}s)",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id}
            )
            
        except Exception as e:
            logger.error(
                f"Error setting cache: {e}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id},
                exc_info=True
            )
    
    async def delete(
        self,
        cache_type: str,
        entity_id: str,
        context: Optional[str] = None
    ):
        """
        Delete cached data
        
        Args:
            cache_type: Type of cache
            entity_id: Entity ID
            context: Optional context
        """
        if not self._connected:
            await self.connect()
        
        try:
            cache_key = self._get_cache_key(cache_type, entity_id, context)
            await self.redis.delete(cache_key)
            
            logger.debug(
                f"Cache deleted: {cache_type}:{entity_id}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id}
            )
            
        except Exception as e:
            logger.error(
                f"Error deleting cache: {e}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id},
                exc_info=True
            )
    
    async def get_or_fetch(
        self,
        cache_type: str,
        entity_id: str,
        fetch_func: Callable,
        ttl: Optional[int] = None,
        context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get from cache or fetch if miss
        
        Args:
            cache_type: Type of cache
            entity_id: Entity ID
            fetch_func: Async function to fetch data if cache miss
            ttl: Optional TTL
            context: Optional context
            
        Returns:
            Data as dict (from cache or fetch)
        """
        # Try cache first
        cached_data = await self.get(cache_type, entity_id, context)
        if cached_data:
            return cached_data.get("data", {})
        
        # Cache miss - fetch and cache
        try:
            fetched_data = await fetch_func()
            if fetched_data:
                await self.set(cache_type, entity_id, fetched_data, ttl, context)
            return fetched_data or {}
        except Exception as e:
            logger.error(
                f"Error in get_or_fetch: {e}",
                extra={"service": self.service_name, "cache_type": cache_type, "entity_id": entity_id},
                exc_info=True
            )
            return {}
    
    async def invalidate_pattern(self, pattern: str):
        """
        Invalidate all cache keys matching pattern
        
        Args:
            pattern: Redis key pattern (e.g., "cache:service:user:*")
        """
        if not self._connected:
            await self.connect()
        
        try:
            keys = []
            async for key in self.redis.scan_iter(match=pattern):
                keys.append(key)
            
            if keys:
                await self.redis.delete(*keys)
                logger.info(
                    f"Invalidated {len(keys)} cache keys matching pattern: {pattern}",
                    extra={"service": self.service_name, "pattern": pattern, "count": len(keys)}
                )
        except Exception as e:
            logger.error(
                f"Error invalidating cache pattern: {e}",
                extra={"service": self.service_name, "pattern": pattern},
                exc_info=True
            )
    
    def subscribe_to_events(self):
        """
        Subscribe to events for automatic cache updates
        
        Subscribes to:
        - user.profile.updated -> Update user cache
        - workspace.updated -> Update workspace cache
        - workspace.deleted -> Delete workspace cache
        - project.updated -> Update project cache
        - project.deleted -> Delete project cache
        """
        if not self.event_bus:
            logger.warning("Event bus not configured - event-driven cache updates disabled")
            return
        
        # User events
        self.event_bus.subscribe("user.profile.updated", self._handle_user_updated)
        self.event_bus.subscribe("user.name_changed", self._handle_user_updated)
        self.event_bus.subscribe("user.email.changed", self._handle_user_updated)
        
        # Workspace events
        self.event_bus.subscribe("workspace.updated", self._handle_workspace_updated)
        self.event_bus.subscribe("workspace.renamed", self._handle_workspace_updated)
        self.event_bus.subscribe("workspace.deleted", self._handle_workspace_deleted)
        
        # Project events
        self.event_bus.subscribe("project.updated", self._handle_project_updated)
        self.event_bus.subscribe("project.renamed", self._handle_project_updated)
        self.event_bus.subscribe("project.deleted", self._handle_project_deleted)
        
        logger.info(f"DataCacheService subscribed to events for {self.service_name}")
    
    async def _handle_user_updated(self, event_data: Dict[str, Any]):
        """Handle user update event"""
        user_id = event_data.get("user_id") or event_data.get("data", {}).get("user_id")
        if user_id:
            # Invalidate user cache - will be refreshed on next access
            await self.delete("user", user_id)
            logger.debug(f"Invalidated user cache: {user_id}")
    
    async def _handle_workspace_updated(self, event_data: Dict[str, Any]):
        """Handle workspace update event"""
        workspace_id = event_data.get("workspace_id") or event_data.get("data", {}).get("workspace_id")
        if workspace_id:
            # Update cache with new data if available
            workspace_data = event_data.get("data", {})
            if workspace_data:
                await self.set("workspace", workspace_id, workspace_data)
            else:
                # Invalidate if no data provided
                await self.delete("workspace", workspace_id)
            logger.debug(f"Updated workspace cache: {workspace_id}")
    
    async def _handle_workspace_deleted(self, event_data: Dict[str, Any]):
        """Handle workspace deletion event"""
        workspace_id = event_data.get("workspace_id") or event_data.get("data", {}).get("workspace_id")
        if workspace_id:
            # Delete workspace cache and all related caches
            await self.delete("workspace", workspace_id)
            # Also invalidate project caches for this workspace
            await self.invalidate_pattern(f"cache:{self.service_name}:project:*:{workspace_id}")
            logger.debug(f"Deleted workspace cache: {workspace_id}")
    
    async def _handle_project_updated(self, event_data: Dict[str, Any]):
        """Handle project update event"""
        project_id = event_data.get("project_id") or event_data.get("data", {}).get("project_id")
        workspace_id = event_data.get("workspace_id") or event_data.get("data", {}).get("workspace_id")
        if project_id:
            # Update cache with new data if available
            project_data = event_data.get("data", {})
            if project_data:
                await self.set("project", project_id, project_data, context=workspace_id)
            else:
                # Invalidate if no data provided
                await self.delete("project", project_id, context=workspace_id)
            logger.debug(f"Updated project cache: {project_id}")
    
    async def _handle_project_deleted(self, event_data: Dict[str, Any]):
        """Handle project deletion event"""
        project_id = event_data.get("project_id") or event_data.get("data", {}).get("project_id")
        workspace_id = event_data.get("workspace_id") or event_data.get("data", {}).get("workspace_id")
        if project_id:
            await self.delete("project", project_id, context=workspace_id)
            logger.debug(f"Deleted project cache: {project_id}")

