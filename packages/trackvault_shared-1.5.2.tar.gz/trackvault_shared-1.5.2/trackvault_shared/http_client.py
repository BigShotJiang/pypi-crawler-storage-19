"""
Enhanced HTTP Client with Circuit Breaker and Retry Logic
Production-ready HTTP client for microservice communication

Time Complexity: O(1) per request (with caching)
Space Complexity: O(1)
"""

import aiohttp
import asyncio
import logging
from typing import Optional, Dict, Any, Callable
from datetime import datetime
import time

from trackvault_shared.circuit_breaker import CircuitBreaker, CircuitState
from trackvault_shared.retry import retry_with_backoff, RetryConfig, EXTERNAL_API_RETRY_CONFIG

logger = logging.getLogger(__name__)


class EnhancedHTTPClient:
    """
    Production-ready HTTP client with:
    - Circuit breaker protection
    - Exponential backoff retry
    - Timeout handling
    - Structured logging
    - Metrics collection (optional)
    
    Designed for 200K+ user scale with zero downtime deployments.
    """
    
    def __init__(
        self,
        base_url: str,
        service_name: str,
        timeout: int = 30,
        circuit_breaker: Optional[CircuitBreaker] = None,
        retry_config: Optional[RetryConfig] = None,
        enable_metrics: bool = False
    ):
        """
        Initialize enhanced HTTP client
        
        Args:
            base_url: Base URL of the target service
            service_name: Name of the target service (for logging/metrics)
            timeout: Request timeout in seconds
            circuit_breaker: Optional circuit breaker instance (creates default if None)
            retry_config: Optional retry configuration (uses default if None)
            enable_metrics: Enable metrics collection (requires metrics implementation)
        """
        self.base_url = base_url.rstrip('/')
        self.service_name = service_name
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.enable_metrics = enable_metrics
        
        # Initialize circuit breaker if not provided
        if circuit_breaker is None:
            self.circuit_breaker = CircuitBreaker(
                failure_threshold=5,
                timeout=60,
                expected_exception=Exception
            )
        else:
            self.circuit_breaker = circuit_breaker
        
        # Initialize retry config if not provided
        if retry_config is None:
            self.retry_config = EXTERNAL_API_RETRY_CONFIG
        else:
            self.retry_config = retry_config
        
        # Session management (lazy initialization)
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session (lazy initialization)"""
        if self._session is None or self._session.closed:
            import os
            # Get connection pool settings from environment variables
            max_connections = int(os.getenv("HTTP_MAX_CONNECTIONS", "100"))
            max_keepalive = int(os.getenv("HTTP_MAX_KEEPALIVE_CONNECTIONS", "20"))
            
            # Create connector with configurable pool sizes
            connector = aiohttp.TCPConnector(
                limit=max_connections,
                limit_per_host=max_keepalive,
                ttl_dns_cache=300,
                use_dns_cache=True
            )
            self._session = aiohttp.ClientSession(timeout=self.timeout, connector=connector)
        return self._session
    
    async def close(self):
        """Close HTTP session"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
    
    async def _make_request(
        self,
        method: str,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        data: Optional[Any] = None,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """
        Internal method to make HTTP request with circuit breaker and retry
        
        Time Complexity: O(1) per request
        Space Complexity: O(1)
        """
        url = f"{self.base_url}{path}"
        start_time = time.time()
        
        # Prepare headers
        request_headers = headers or {}
        if 'Content-Type' not in request_headers and json_data is not None:
            request_headers['Content-Type'] = 'application/json'
        
        # ✅ INDUSTRY STANDARD: Add distributed tracing headers
        try:
            from trackvault_shared.tracing import get_tracing_headers
            request_headers = get_tracing_headers(request_headers)
        except ImportError:
            # Tracing module not available, continue without tracing
            pass
        
        # Wrap request in circuit breaker and retry
        async def _execute_request():
            """Execute HTTP request"""
            session = await self._get_session()
            
            try:
                # Sanitize params for yarl (convert booleans to strings)
                request_params = params
                if request_params:
                    request_params = {
                        k: (str(v).lower() if isinstance(v, bool) else v) 
                        for k, v in request_params.items()
                    }

                # Make request
                async with session.request(
                    method=method,
                    url=url,
                    headers=request_headers,
                    params=request_params,
                    json=json_data,
                    data=data,
                    **kwargs
                ) as response:
                    duration = time.time() - start_time
                    
                    # Log request
                    logger.debug(
                        f"HTTP {method} {url}",
                        extra={
                            "service": self.service_name,
                            "method": method,
                            "url": url,
                            "status": response.status,
                            "duration_ms": duration * 1000
                        }
                    )
                    
                    # Handle response
                    if 200 <= response.status < 300:
                        try:
                            result = await response.json()
                            return result
                        except Exception as e:
                            logger.warning(
                                f"Failed to parse JSON response from {url}: {e}",
                                extra={"service": self.service_name, "url": url}
                            )
                            return None
                    elif response.status == 404:
                        logger.debug(
                            f"Resource not found: {url}",
                            extra={"service": self.service_name, "url": url, "status": 404}
                        )
                        return None
                    elif response.status >= 500:
                        # Server error - will be retried
                        error_text = await response.text()
                        logger.warning(
                            f"Server error from {url}: {response.status}",
                            extra={
                                "service": self.service_name,
                                "url": url,
                                "status": response.status,
                                "error": error_text[:500]
                            }
                        )
                        raise aiohttp.ClientResponseError(
                            request_info=response.request_info,
                            history=response.history,
                            status=response.status,
                            message=error_text[:200]
                        )
                    else:
                        # Client error (4xx) - don't retry
                        error_text = await response.text()
                        logger.warning(
                            f"Client error from {url}: {response.status}",
                            extra={
                                "service": self.service_name,
                                "url": url,
                                "status": response.status,
                                "error": error_text[:500]
                            }
                        )
                        return None
                        
            except asyncio.TimeoutError:
                duration = time.time() - start_time
                logger.warning(
                    f"Request timeout: {url}",
                    extra={
                        "service": self.service_name,
                        "url": url,
                        "duration_ms": duration * 1000
                    }
                )
                raise
            except aiohttp.ClientError as e:
                duration = time.time() - start_time
                logger.warning(
                    f"Client error: {url} - {e}",
                    extra={
                        "service": self.service_name,
                        "url": url,
                        "error": str(e)
                    }
                )
                raise
            except Exception as e:
                duration = time.time() - start_time
                logger.error(
                    f"Unexpected error: {url} - {e}",
                    extra={
                        "service": self.service_name,
                        "url": url,
                        "error": str(e)
                    },
                    exc_info=True
                )
                raise
        
        # Execute with circuit breaker and retry
        try:
            # Wrap request in retry logic first, then circuit breaker
            async def _execute_with_retry():
                return await retry_with_backoff(
                    _execute_request,
                    config=self.retry_config
                )
            
            # Execute with circuit breaker protection
            result = await self.circuit_breaker.call(_execute_with_retry)
            
            return result
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(
                f"Request failed after retries: {url} - {e}",
                extra={
                    "service": self.service_name,
                    "url": url,
                    "duration_ms": duration * 1000,
                    "error": str(e)
                }
            )
            return None
    
    async def get(
        self,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """
        Make GET request with circuit breaker and retry
        
        Args:
            path: URL path (will be appended to base_url)
            headers: Optional HTTP headers
            params: Optional query parameters
            **kwargs: Additional arguments for aiohttp
            
        Returns:
            JSON response as dict, or None on error
        """
        return await self._make_request(
            method="GET",
            path=path,
            headers=headers,
            params=params,
            **kwargs
        )
    
    async def post(
        self,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        data: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """
        Make POST request with circuit breaker and retry
        
        Args:
            path: URL path
            json_data: Optional JSON data to send
            data: Optional raw data to send
            headers: Optional HTTP headers
            **kwargs: Additional arguments for aiohttp
            
        Returns:
            JSON response as dict, or None on error
        """
        return await self._make_request(
            method="POST",
            path=path,
            json_data=json_data,
            data=data,
            headers=headers,
            **kwargs
        )
    
    async def put(
        self,
        path: str,
        json_data: Optional[Dict[str, Any]] = None,
        data: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Make PUT request with circuit breaker and retry"""
        return await self._make_request(
            method="PUT",
            path=path,
            json_data=json_data,
            data=data,
            headers=headers,
            **kwargs
        )
    
    async def delete(
        self,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs
    ) -> Optional[Dict[str, Any]]:
        """Make DELETE request with circuit breaker and retry"""
        return await self._make_request(
            method="DELETE",
            path=path,
            headers=headers,
            **kwargs
        )
    
    def get_circuit_breaker_state(self) -> Dict[str, Any]:
        """Get current circuit breaker state (for monitoring)"""
        return self.circuit_breaker.get_state()
    
    def is_healthy(self) -> bool:
        """Check if service is healthy (circuit breaker not OPEN)"""
        return self.circuit_breaker.state != CircuitState.OPEN

