"""
TrackVault Shared Library
Shared utilities, event bus, schemas, and RBAC system for TrackVault microservices
"""

__version__ = "1.5.0"

# Event Bus
from .event_bus import EventBus, EventData, get_auth_event_bus, get_project_event_bus

# HTTP Client
from .http_client import EnhancedHTTPClient

# Data Cache
from .data_cache import DataCacheService

# Service Authentication
from .service_auth import ServiceTokenManager

# Service Discovery
from .service_discovery import ServiceDiscoveryClient, get_service_discovery_client

# Service Registration
from .service_registration import register_service_with_registry, unregister_service_from_registry

# Distributed Tracing
from .tracing import (
    generate_request_id,
    generate_trace_id,
    generate_span_id,
    get_request_id,
    get_trace_id,
    get_span_id,
    set_request_id,
    set_trace_id,
    set_span_id,
    get_tracing_headers,
    extract_tracing_from_headers,
    initialize_tracing_from_headers,
)

# Graceful Degradation
from .graceful_degradation import (
    ServiceUnavailable,
    get_with_fallback,
    create_partial_response,
    call_multiple_with_fallback,
)

# Standard Error Responses
from .errors import StandardErrorResponse

# Advanced Observability & Analytics
from .observability import (
    ObservabilityManager,
    APIPerformanceTracker,
    ErrorTracker,
    DistributedTracer,
    get_observability_manager
)
from .observability_middleware import ObservabilityMiddleware
from .analytics_router import router as analytics_router

# Soft Delete
from .soft_delete import (
    SoftDeleteMixin,
    SoftDeleteQueryMixin,
    soft_delete_filter
)

# Event Schemas
from .schemas import (
    # User events
    UserEmailChangedEvent,
    UserNameChangedEvent,
    UserDeletionRequestedEvent,
    UserDeletionCompletedEvent,

    # Workspace events
    WorkspaceCreatedEvent,
    WorkspaceRenamedEvent,
    WorkspaceDeletedEvent,

    # Project events
    ProjectCreatedEvent,
    ProjectRenamedEvent,
    ProjectDeletedEvent,

    # Task/Milestone/Label events
    TaskDeletedEvent,
    MilestoneDeletedEvent,
    LabelDeletedEvent,

    # Knowledge events
    SpaceDeletedEvent,
    PageDeletedEvent,

    # Chat events
    RoomDeletedEvent,

    # VAPT events
    VulnerabilityDeletedEvent,

    # Ownership transfer events
    UserOwnershipTransferStartedEvent,
    UserResourcesTransferredEvent,

    # Schema utilities
    EVENT_SCHEMAS,
    get_event_schema,
    validate_event_data,
)

# RBAC System
from .rbac_roles import (
    Role,
    RoleCapabilities,
    ROLE_CAPABILITIES,
    get_role_capabilities,
    get_all_roles,
    can_role_perform_action,
    is_valid_role,
    validate_role_change,
)

from .rbac_permissions import (
    Action,
    Resource,
    Permission,
    ProjectServicePermissions,
    VAPTServicePermissions,
    ChatServicePermissions,
    KnowledgeBasePermissions,
    PermissionGroups,
    parse_permissions,
    get_all_permissions,
)

from .rbac_policy import (
    AccessContext,
    PolicyConfig,
    RBACPolicyEngine,
    get_policy_engine,
    has_permission,
)

from .rbac_audit import (
    AuditAction,
    AuditSeverity,
    AuditLog,
    AuditLogger,
    get_audit_logger,
)

from .rbac_decorators import (
    RBACException,
    require_permission,
    require_role,
    require_workspace_membership,
    require_ownership,
    require_owner_or_admin,
    require_manager_or_above,
    require_member_or_above,
)

from .rbac_config import (
    WorkspaceRBACConfig,
    RBACConfigManager,
    get_config_manager,
    get_policy_config_for_workspace,
    update_workspace_config,
    load_rbac_config_from_env,
)
__all__ = [
    # Version
    "__version__",
    
    # Event Bus
    "EventBus",
    "EventData",
    "get_auth_event_bus",
    "get_project_event_bus",
    
    # Soft Delete
    "SoftDeleteMixin",
    "SoftDeleteQueryMixin",
    "soft_delete_filter",
    
    "HealthChecker",
    "HealthStatus",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitState",
    # Retry
    "RetryConfig",
    "retry_with_backoff",
    "retry_database_operation",
    "retry_redis_operation",
    "retry_external_api",
    # HTTP Client
    "EnhancedHTTPClient",
    # Data Cache
    "DataCacheService",
    # Service Authentication
    "ServiceTokenManager",
    # Service Discovery
    "ServiceDiscoveryClient",
    "get_service_discovery_client",
    # Service Registration
    "register_service_with_registry",
    "unregister_service_from_registry",
    # Distributed Tracing
    "generate_request_id",
    "generate_trace_id",
    "generate_span_id",
    "get_request_id",
    "get_trace_id",
    "get_span_id",
    "set_request_id",
    "set_trace_id",
    "set_span_id",
    "get_tracing_headers",
    "extract_tracing_from_headers",
    "initialize_tracing_from_headers",
    # Graceful Degradation
    "ServiceUnavailable",
    "get_with_fallback",
    "create_partial_response",
    "call_multiple_with_fallback",
    # Standard Error Responses
    "StandardErrorResponse",
    # Advanced Observability & Analytics
    "ObservabilityManager",
    "APIPerformanceTracker",
    "ErrorTracker",
    "DistributedTracer",
    "get_observability_manager",
    # Event Schemas
    "BaseEvent",
    "UserEmailChangedEvent",
    "UserNameChangedEvent",
    "WorkspaceRenamedEvent",
    "ProjectRenamedEvent",
    "ProjectCreatedEvent",
    "WorkspaceDeletedEvent",
    
    # RBAC System - Roles
    "Role",
    "RoleCapabilities",
    "ROLE_CAPABILITIES",
    "get_role_capabilities",
    "get_all_roles",
    "can_role_perform_action",
    "is_valid_role",
    "validate_role_change",
    
    # RBAC System - Permissions
    "Action",
    "Resource",
    "Permission",
    "ProjectServicePermissions",
    "VAPTServicePermissions",
    "ChatServicePermissions",
    "KnowledgeBasePermissions",
    "PermissionGroups",
    "parse_permissions",
    "get_all_permissions",
    
    # RBAC System - Policy Engine
    "AccessContext",
    "PolicyConfig",
    "RBACPolicyEngine",
    "get_policy_engine",
    "has_permission",
    
    # RBAC System - Audit Logging
    "AuditAction",
    "AuditSeverity",
    "AuditLog",
    "AuditLogger",
    "get_audit_logger",
    
    # RBAC System - Decorators
    "RBACException",
    "require_permission",
    "require_role",
    "require_workspace_membership",
    "require_ownership",
    "require_owner_or_admin",
    "require_manager_or_above",
    "require_member_or_above",
    
    # RBAC System - Configuration
    "WorkspaceRBACConfig",
    "RBACConfigManager",
    "get_config_manager",
    "get_policy_config_for_workspace",
    "update_workspace_config",
    "load_rbac_config_from_env",
]
