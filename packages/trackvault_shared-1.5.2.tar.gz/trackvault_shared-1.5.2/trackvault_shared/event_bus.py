"""
Event Bus Service for Microservice Communication
Handles event publishing and subscription using Redis Streams
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any, Callable, Optional, List
import redis.asyncio as aioredis
from pydantic import BaseModel

logger = logging.getLogger(__name__)

class EventData(BaseModel):
    """Standard event data structure"""
    event_type: str
    data: Dict[str, Any]
    timestamp: str
    source_service: str
    event_id: str

class EventBus:
    """Event Bus for microservice communication using Redis Streams"""
    
    def __init__(self, redis_url: str, service_name: str):
        self.redis_url = redis_url
        self.service_name = service_name
        self.redis: Optional[aioredis.Redis] = None
        self.subscribers: Dict[str, List[Callable]] = {}
        self.is_running = False
        self._task: Optional[asyncio.Task] = None
        
    async def connect(self):
        """Connect to Redis"""
        try:
            import os
            # Get max_connections from environment variable (defaults to 20)
            max_connections = int(os.getenv("REDIS_MAX_CONNECTIONS", "20"))
            self.redis = aioredis.from_url(
                self.redis_url,
                decode_responses=True,
                max_connections=max_connections
            )
            await self.redis.ping()
            logger.info(f"EventBus connected to Redis for {self.service_name}")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    async def disconnect(self):
        """Disconnect from Redis"""
        if self.redis:
            await self.redis.close()
            logger.info(f"EventBus disconnected from Redis for {self.service_name}")
    
    async def publish(self, event_type: str, data: Dict[str, Any], event_id: Optional[str] = None) -> str:
        """
        Publish an event to the message queue
        
        Args:
            event_type: Type of event (e.g., 'user.profile.updated')
            data: Event payload data
            event_id: Optional custom event ID
            
        Returns:
            str: Message ID from Redis Stream
        """
        if not self.redis:
            await self.connect()
        
        try:
            event_data = EventData(
                event_type=event_type,
                data=data,
                timestamp=datetime.utcnow().isoformat(),
                source_service=self.service_name,
                event_id=event_id or f"{self.service_name}_{int(datetime.utcnow().timestamp())}"
            )
            
            # Publish to Redis Stream
            message_id = await self.redis.xadd(
                "events",
                {
                    "event_type": event_type,
                    "data": json.dumps(data),
                    "timestamp": event_data.timestamp,
                    "source_service": self.service_name,
                    "event_id": event_data.event_id
                }
            )
            
            logger.info(f"Published event {event_type} with ID {message_id}")
            return message_id
            
        except Exception as e:
            logger.error(f"Failed to publish event {event_type}: {e}")
            raise
    
    def subscribe(self, event_type: str, handler: Callable):
        """
        Subscribe to specific event types
        
        Args:
            event_type: Type of event to listen for
            handler: Async function to handle the event
        """
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        
        self.subscribers[event_type].append(handler)
        logger.info(f"Subscribed to {event_type} events")
    
    async def start_processing(self):
        """Start processing events in background"""
        if self.is_running:
            logger.warning("Event processing already running")
            return
        
        if not self.redis:
            await self.connect()
        
        self.is_running = True
        self._task = asyncio.create_task(self._process_events())
        logger.info(f"Started event processing for {self.service_name}")
    
    async def stop_processing(self):
        """Stop processing events"""
        self.is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info(f"Stopped event processing for {self.service_name}")
    
    async def _process_events(self):
        """Background task to process events from Redis Stream"""
        last_id = "$"  # Start from the end of the stream
        
        while self.is_running:
            try:
                # Read from Redis Stream with timeout
                messages = await self.redis.xread(
                    {"events": last_id}, 
                    count=10, 
                    block=1000  # 1 second timeout
                )
                
                for stream, msgs in messages:
                    for msg_id, fields in msgs:
                        await self._handle_event(msg_id, fields)
                        last_id = msg_id
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error processing events: {e}")
                await asyncio.sleep(1)  # Wait before retrying
    
    async def _handle_event(self, msg_id: str, fields: Dict[str, str]):
        """Handle a single event"""
        try:
            event_type = fields.get("event_type")
            source_service = fields.get("source_service", "")
            timestamp = fields.get("timestamp", "")
            event_id = fields.get("event_id", msg_id)
            
            # Parse the data payload
            data = json.loads(fields.get("data", "{}"))
            
            # Merge event metadata with data to create full event structure
            # This ensures handlers receive event_type, source_service, timestamp at top level
            full_event_data = {
                "event_type": event_type,
                "source_service": source_service,
                "timestamp": timestamp,
                "event_id": event_id,
                **data  # Merge the actual event data
            }
            
            if event_type in self.subscribers:
                for handler in self.subscribers[event_type]:
                    try:
                        await handler(full_event_data)
                        logger.debug(f"Handled event {event_type} with handler {handler.__name__}")
                    except Exception as e:
                        logger.error(f"Error in event handler {handler.__name__} for {event_type}: {e}", exc_info=True)
            else:
                logger.debug(f"No subscribers for event type {event_type}")
                
        except Exception as e:
            logger.error(f"Error handling event {msg_id}: {e}", exc_info=True)

# Global event bus instances
_auth_event_bus: Optional[EventBus] = None
_project_event_bus: Optional[EventBus] = None
_vapt_event_bus: Optional[EventBus] = None
_chat_event_bus: Optional[EventBus] = None

def get_auth_event_bus(redis_url: str = "redis://localhost:6379/0") -> EventBus:
    """Get or create auth service event bus"""
    global _auth_event_bus
    if _auth_event_bus is None:
        _auth_event_bus = EventBus(redis_url, "auth-service")
    return _auth_event_bus

def get_project_event_bus(redis_url: str = "redis://localhost:6379/0") -> EventBus:
    """Get or create project service event bus"""
    global _project_event_bus
    if _project_event_bus is None:
        _project_event_bus = EventBus(redis_url, "project-service")
    return _project_event_bus

def get_vapt_event_bus(redis_url: str = "redis://localhost:6379/0") -> EventBus:
    """Get or create VAPT service event bus"""
    global _vapt_event_bus
    if _vapt_event_bus is None:
        _vapt_event_bus = EventBus(redis_url, "vapt-service")
    return _vapt_event_bus

def get_chat_event_bus(redis_url: str = "redis://localhost:6379/0") -> EventBus:
    """Get or create Chat service event bus"""
    global _chat_event_bus
    if _chat_event_bus is None:
        _chat_event_bus = EventBus(redis_url, "chat-service")
    return _chat_event_bus
