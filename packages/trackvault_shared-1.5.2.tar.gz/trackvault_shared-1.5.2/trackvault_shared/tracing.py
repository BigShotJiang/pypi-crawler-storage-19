"""
Distributed Tracing Utilities
Industry Standard: W3C Trace Context & OpenTelemetry-style trace propagation

Time Complexity: O(1) for all operations
Space Complexity: O(1)
"""
import uuid
import logging
from typing import Optional, Dict
from contextvars import ContextVar

logger = logging.getLogger(__name__)

# Context variables for request-scoped tracing
# Industry Standard: Use contextvars for async request-scoped data
request_id_var: ContextVar[Optional[str]] = ContextVar('request_id', default=None)
trace_id_var: ContextVar[Optional[str]] = ContextVar('trace_id', default=None)
span_id_var: ContextVar[Optional[str]] = ContextVar('span_id', default=None)


def generate_request_id() -> str:
    """
    Generate unique request ID
    Industry Standard: UUID v4 for request correlation
    """
    return str(uuid.uuid4())


def generate_trace_id() -> str:
    """
    Generate trace ID (can be same for all spans in a trace)
    Industry Standard: UUID v4 for trace correlation
    """
    return str(uuid.uuid4())


def generate_span_id() -> str:
    """
    Generate span ID (unique for each service call in a trace)
    Industry Standard: UUID v4 for span identification
    """
    return str(uuid.uuid4())


def get_request_id() -> Optional[str]:
    """Get current request ID from context"""
    return request_id_var.get()


def get_trace_id() -> Optional[str]:
    """Get current trace ID from context"""
    return trace_id_var.get()


def get_span_id() -> Optional[str]:
    """Get current span ID from context"""
    return span_id_var.get()


def set_request_id(request_id: str):
    """Set request ID in context"""
    request_id_var.set(request_id)


def set_trace_id(trace_id: str):
    """Set trace ID in context"""
    trace_id_var.set(trace_id)


def set_span_id(span_id: str):
    """Set span ID in context"""
    span_id_var.set(span_id)


def get_tracing_headers(headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Get tracing headers for outbound requests
    Industry Standard: W3C Trace Context format
    
    Headers added:
    - X-Request-ID: Unique request identifier
    - X-Trace-ID: Trace identifier (same across all spans in a trace)
    - X-Span-ID: Span identifier (unique for this service call)
    
    Args:
        headers: Optional existing headers dict to update
        
    Returns:
        Headers dict with tracing headers added
    """
    if headers is None:
        headers = {}
    
    # Get or generate request ID
    request_id = get_request_id()
    if not request_id:
        request_id = generate_request_id()
        set_request_id(request_id)
    headers["X-Request-ID"] = request_id
    
    # Get or generate trace ID
    trace_id = get_trace_id()
    if not trace_id:
        trace_id = generate_trace_id()
        set_trace_id(trace_id)
    headers["X-Trace-ID"] = trace_id
    
    # Generate new span ID for this service call
    span_id = generate_span_id()
    set_span_id(span_id)
    headers["X-Span-ID"] = span_id
    
    return headers


def extract_tracing_from_headers(headers: Dict[str, str]) -> Dict[str, Optional[str]]:
    """
    Extract tracing information from incoming request headers
    Industry Standard: Extract W3C Trace Context headers
    
    Args:
        headers: Request headers dict
        
    Returns:
        Dict with request_id, trace_id, span_id
    """
    return {
        "request_id": headers.get("X-Request-ID"),
        "trace_id": headers.get("X-Trace-ID"),
        "span_id": headers.get("X-Span-ID")
    }


def initialize_tracing_from_headers(headers: Dict[str, str]):
    """
    Initialize tracing context from incoming request headers
    Creates new IDs if not present in headers
    
    Args:
        headers: Request headers dict
    """
    request_id = headers.get("X-Request-ID") or generate_request_id()
    trace_id = headers.get("X-Trace-ID") or generate_trace_id()
    span_id = headers.get("X-Span-ID") or generate_span_id()
    
    set_request_id(request_id)
    set_trace_id(trace_id)
    set_span_id(span_id)
    
    return {
        "request_id": request_id,
        "trace_id": trace_id,
        "span_id": span_id
    }

