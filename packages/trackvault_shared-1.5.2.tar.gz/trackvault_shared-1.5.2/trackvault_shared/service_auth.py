"""
Service Authentication Utilities
For secure service-to-service communication

Time Complexity: O(1) for token operations
Space Complexity: O(1)
"""

import logging
from typing import Optional
from jose import JWTError, jwt
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class ServiceTokenManager:
    """
    Manages service tokens for service-to-service authentication
    
    Each service should:
    1. Get service account from Auth Service
    2. Generate service token
    3. Include token in X-Service-Token header for internal calls
    """
    
    def __init__(self, service_name: str, jwt_secret: str, jwt_algorithm: str = "HS256"):
        """
        Initialize service token manager
        
        Args:
            service_name: Name of this service
            jwt_secret: JWT secret key (shared with Auth Service)
            jwt_algorithm: JWT algorithm
        """
        self.service_name = service_name
        self.jwt_secret = jwt_secret
        self.jwt_algorithm = jwt_algorithm
        self._cached_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
    
    def generate_service_token(self, service_id: str, permissions: list = None) -> str:
        """
        Generate service token for authentication
        
        Args:
            service_id: Service account ID
            permissions: Optional permissions list
            
        Returns:
            JWT service token
        """
        payload = {
            "service_id": service_id,
            "service_name": self.service_name,
            "permissions": permissions or [],
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(hours=24),  # 24 hour expiration
            "type": "service"
        }
        
        return jwt.encode(
            payload,
            self.jwt_secret,
            algorithm=self.jwt_algorithm
        )
    
    def get_service_token_header(self, service_id: str, permissions: list = None) -> dict:
        """
        Get service token header for HTTP requests
        
        Args:
            service_id: Service account ID
            permissions: Optional permissions list
            
        Returns:
            Dictionary with X-Service-Token header
        """
        # Check if cached token is still valid
        if self._cached_token and self._token_expires_at:
            if datetime.utcnow() < self._token_expires_at:
                return {"X-Service-Token": self._cached_token}
        
        # Generate new token
        token = self.generate_service_token(service_id, permissions)
        self._cached_token = token
        self._token_expires_at = datetime.utcnow() + timedelta(hours=23)  # Refresh 1 hour before expiry
        
        return {"X-Service-Token": token}
    
    @staticmethod
    def verify_service_token(token: str, jwt_secret: str, jwt_algorithm: str = "HS256") -> Optional[dict]:
        """
        Verify service token
        
        Args:
            token: JWT service token
            jwt_secret: JWT secret key
            jwt_algorithm: JWT algorithm
            
        Returns:
            Token payload if valid, None otherwise
        """
        try:
            payload = jwt.decode(
                token,
                jwt_secret,
                algorithms=[jwt_algorithm],
                options={
                    "verify_signature": True,
                    "verify_exp": True,
                    "require_exp": True
                }
            )
            
            if payload.get("type") != "service":
                return None
            
            return payload
            
        except JWTError:
            return None
        except Exception as e:
            logger.error(f"Error verifying service token: {e}", exc_info=True)
            return None

