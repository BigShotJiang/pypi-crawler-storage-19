"""
RBAC Enforcement Decorators for FastAPI Endpoints

Provides decorators for declarative RBAC enforcement at API entry points.
These decorators integrate with FastAPI dependencies and enforce permissions
before handlers execute.

CRITICAL RULES:
1. All RBAC checks occur at API entry points (backend enforcement)
2. Never trust frontend permissions
3. Default deny on ambiguity
4. Log all authorization decisions
5. Fail fast with clear error messages

Usage:
```python
from trackvault_shared.rbac_decorators import require_permission, require_role
from trackvault_shared.rbac_permissions import Action, Resource

@router.delete("/projects/{project_id}")
@require_permission(Action.DELETE, Resource.PROJECT, check_ownership=True)
async def delete_project(
    project_id: str,
    current_user: Dict = Depends(get_current_user)
):
    # Handler code here
    pass
```
"""

from functools import wraps
from typing import Callable, Optional, List, Dict, Any
from fastapi import HTTPException, status, Depends, Request
import structlog

from .rbac_roles import Role
from .rbac_permissions import Action, Resource, Permission
from .rbac_policy import AccessContext, get_policy_engine, PolicyConfig
from .rbac_audit import get_audit_logger, AuditAction, AuditSeverity

logger = structlog.get_logger(__name__)


class RBACException(HTTPException):
    """Custom exception for RBAC failures"""
    def __init__(self, detail: str, status_code: int = status.HTTP_403_FORBIDDEN):
        super().__init__(status_code=status_code, detail=detail)


def _extract_user_context(func_kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract user context from function kwargs.
    Expects 'current_user' from FastAPI Depends(get_current_user)
    """
    current_user = func_kwargs.get('current_user')
    if not current_user:
        raise RBACException(
            "Authentication required: No user context found",
            status_code=status.HTTP_401_UNAUTHORIZED
        )
    
    # Validate required fields
    required_fields = ['user_id', 'role', 'workspace_id', 'tenant_id']
    missing_fields = [f for f in required_fields if f not in current_user]
    
    if missing_fields:
        raise RBACException(
            f"Invalid user context: Missing fields {missing_fields}",
            status_code=status.HTTP_401_UNAUTHORIZED
        )
    
    return current_user


def _get_resource_owner_id(
    func_kwargs: Dict[str, Any],
    owner_field: Optional[str] = None
) -> Optional[str]:
    """
    Extract resource owner ID from function kwargs.
    
    Args:
        func_kwargs: Function keyword arguments
        owner_field: Name of the field containing owner ID
        
    Returns:
        Owner ID if found, None otherwise
    """
    if not owner_field:
        return None
    
    # Check if owner_field is directly in kwargs
    if owner_field in func_kwargs:
        return func_kwargs[owner_field]
    
    # Check if it's in a nested resource object
    resource_names = ['resource', 'project', 'task', 'vulnerability', 'asset']
    for resource_name in resource_names:
        if resource_name in func_kwargs:
            resource = func_kwargs[resource_name]
            if hasattr(resource, owner_field):
                return getattr(resource, owner_field)
            elif isinstance(resource, dict) and owner_field in resource:
                return resource[owner_field]
    
    return None


def require_permission(
    action: Action,
    resource: Resource,
    check_ownership: bool = False,
    owner_field: str = "created_by",
    resource_id_field: str = None,
    policy_config: Optional[PolicyConfig] = None,
    audit_action: Optional[AuditAction] = None
):
    """
    Decorator that enforces RBAC permissions on FastAPI endpoints.
    
    Args:
        action: Action being performed (e.g., Action.DELETE)
        resource: Resource type (e.g., Resource.PROJECT)
        check_ownership: Whether to enforce ownership check
        owner_field: Name of the field containing resource owner ID
        resource_id_field: Name of the field containing resource ID
        policy_config: Optional policy configuration for overrides
        audit_action: Optional audit action to log
        
    Usage:
        @require_permission(Action.DELETE, Resource.PROJECT, check_ownership=True)
        async def delete_project(project_id: str, current_user: Dict):
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract user context
            try:
                current_user = _extract_user_context(kwargs)
            except RBACException:
                raise
            except Exception as e:
                logger.error("failed_to_extract_user_context", error=str(e))
                raise RBACException("Authentication required")
            
            # Parse role
            try:
                user_role = Role.from_string(current_user['role'])
            except ValueError:
                raise RBACException(f"Invalid role: {current_user['role']}")
            
            # Extract resource owner if ownership check is required
            resource_owner_id = None
            if check_ownership:
                resource_owner_id = _get_resource_owner_id(kwargs, owner_field)
            
            # Extract resource ID
            res_id = None
            if resource_id_field and resource_id_field in kwargs:
                res_id = kwargs[resource_id_field]
            
            # Build access context
            context = AccessContext(
                user_id=current_user['user_id'],
                role=user_role,
                workspace_id=current_user['workspace_id'],
                tenant_id=current_user['tenant_id'],
                resource_type=resource,
                resource_id=res_id,
                resource_owner_id=resource_owner_id,
                action=action
            )
            
            # Create permission
            permission = Permission(action, resource)
            
            # Check permission
            engine = get_policy_engine(policy_config)
            has_perm, denial_reason = engine.has_permission(
                context=context,
                permission=permission,
                check_ownership=check_ownership
            )
            
            # Log authorization decision
            if not has_perm:
                # Log denial
                audit_logger = get_audit_logger("rbac")
                audit_logger.log_permission_denied(
                    actor_user_id=current_user['user_id'],
                    actor_role=user_role,
                    permission=str(permission),
                    resource_type=resource,
                    resource_id=res_id,
                    denial_reason=denial_reason or "Unknown reason",
                    tenant_id=current_user['tenant_id'],
                    workspace_id=current_user['workspace_id']
                )
                
                # Raise HTTP 403
                raise RBACException(
                    detail=f"Access denied: {denial_reason or 'Insufficient permissions'}"
                )
            
            # Log successful authorization if audit action is specified
            if audit_action:
                audit_logger = get_audit_logger("rbac")
                audit_logger.log_action(
                    actor_user_id=current_user['user_id'],
                    actor_role=user_role,
                    action=audit_action,
                    action_details=f"Authorized {action} on {resource}",
                    tenant_id=current_user['tenant_id'],
                    workspace_id=current_user['workspace_id'],
                    resource_type=resource,
                    resource_id=res_id,
                    severity=AuditSeverity.INFO
                )
            
            # Execute the handler
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_role(
    min_role: Role,
    allow_owner_bypass: bool = True
):
    """
    Decorator that enforces minimum role requirement.
    
    Args:
        min_role: Minimum required role
        allow_owner_bypass: Whether to allow Owner to bypass (default: True)
        
    Usage:
        @require_role(Role.MANAGER)
        async def create_project(current_user: Dict):
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract user context
            try:
                current_user = _extract_user_context(kwargs)
            except RBACException:
                raise
            
            # Parse role
            try:
                user_role = Role.from_string(current_user['role'])
            except ValueError:
                raise RBACException(f"Invalid role: {current_user['role']}")
            
            # Check role hierarchy
            if allow_owner_bypass and user_role == Role.OWNER:
                # Owner bypasses all role checks
                return await func(*args, **kwargs)
            
            if not user_role.has_equal_or_higher_privilege_than(min_role):
                # Log denial
                audit_logger = get_audit_logger("rbac")
                audit_logger.log_permission_denied(
                    actor_user_id=current_user['user_id'],
                    actor_role=user_role,
                    permission=f"require_role:{min_role}",
                    resource_type=Resource.SETTINGS,  # Generic resource
                    resource_id=None,
                    denial_reason=f"Requires {min_role} role or higher",
                    tenant_id=current_user['tenant_id'],
                    workspace_id=current_user['workspace_id']
                )
                
                raise RBACException(
                    detail=f"Access denied: Requires {min_role} role or higher"
                )
            
            # Execute the handler
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_workspace_membership(
    workspace_id_field: str = "workspace_id",
    allow_guests: bool = False
):
    """
    Decorator that enforces workspace membership.
    
    Args:
        workspace_id_field: Name of the field containing workspace ID
        allow_guests: Whether to allow Guest role (default: False)
        
    Usage:
        @require_workspace_membership(workspace_id_field="workspace_id")
        async def get_workspace_data(workspace_id: str, current_user: Dict):
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract user context
            try:
                current_user = _extract_user_context(kwargs)
            except RBACException:
                raise
            
            # Extract workspace ID from kwargs
            workspace_id = kwargs.get(workspace_id_field)
            if not workspace_id:
                raise RBACException(
                    "Invalid request: Workspace ID not provided",
                    status_code=status.HTTP_400_BAD_REQUEST
                )
            
            # Check if user's workspace matches
            if current_user['workspace_id'] != workspace_id:
                # Log denial
                audit_logger = get_audit_logger("rbac")
                audit_logger.log_permission_denied(
                    actor_user_id=current_user['user_id'],
                    actor_role=Role.from_string(current_user['role']),
                    permission="workspace_membership",
                    resource_type=Resource.WORKSPACE,
                    resource_id=workspace_id,
                    denial_reason="User is not a member of this workspace",
                    tenant_id=current_user['tenant_id'],
                    workspace_id=workspace_id
                )
                
                raise RBACException(
                    detail="Access denied: Not a member of this workspace"
                )
            
            # Check if guests are allowed
            if not allow_guests:
                user_role = Role.from_string(current_user['role'])
                if user_role == Role.GUEST:
                    raise RBACException(
                        detail="Access denied: Guests not allowed"
                    )
            
            # Execute the handler
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


def require_ownership(
    resource_type: Resource,
    resource_id_field: str,
    owner_field: str = "created_by",
    allow_admins: bool = True
):
    """
    Decorator that enforces resource ownership.
    
    Args:
        resource_type: Type of resource
        resource_id_field: Name of the field containing resource ID
        owner_field: Name of the field containing owner ID
        allow_admins: Whether to allow Owner/Admin to bypass (default: True)
        
    Usage:
        @require_ownership(Resource.TASK, resource_id_field="task_id")
        async def delete_task(task_id: str, current_user: Dict):
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract user context
            try:
                current_user = _extract_user_context(kwargs)
            except RBACException:
                raise
            
            # Parse role
            user_role = Role.from_string(current_user['role'])
            
            # Owner/Admin bypass
            if allow_admins and user_role in [Role.OWNER, Role.ADMIN]:
                return await func(*args, **kwargs)
            
            # Extract resource owner
            resource_owner_id = _get_resource_owner_id(kwargs, owner_field)
            
            if not resource_owner_id:
                raise RBACException(
                    "Cannot verify ownership: Resource owner not found",
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            
            # Check ownership
            if current_user['user_id'] != resource_owner_id:
                # Extract resource ID for logging
                res_id = kwargs.get(resource_id_field)
                
                # Log denial
                audit_logger = get_audit_logger("rbac")
                audit_logger.log_permission_denied(
                    actor_user_id=current_user['user_id'],
                    actor_role=user_role,
                    permission=f"ownership:{resource_type}",
                    resource_type=resource_type,
                    resource_id=res_id,
                    denial_reason="User is not the owner of this resource",
                    tenant_id=current_user['tenant_id'],
                    workspace_id=current_user['workspace_id']
                )
                
                raise RBACException(
                    detail="Access denied: You must be the owner of this resource"
                )
            
            # Execute the handler
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


# Convenience decorators for common operations

def require_owner_or_admin():
    """Convenience decorator requiring Owner or Admin role"""
    return require_role(Role.ADMIN, allow_owner_bypass=True)


def require_manager_or_above():
    """Convenience decorator requiring Manager or higher role"""
    return require_role(Role.MANAGER, allow_owner_bypass=True)


def require_member_or_above():
    """Convenience decorator requiring Member or higher role"""
    return require_role(Role.MEMBER, allow_owner_bypass=True)

