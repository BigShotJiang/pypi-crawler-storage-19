"""
RBAC Audit Logging for TrackVault

Implements immutable audit logging for all RBAC-protected actions.
Every meaningful action must be logged with full context for compliance and security.

Audit logs must include:
- Actor user ID and role
- Action type and resource
- Ownership context
- Project/workspace context
- Timestamp
- Previous and new state (if applicable)

Logs are immutable and queryable for audit trails.
"""

from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum
from pydantic import BaseModel, Field
import structlog

from .rbac_roles import Role
from .rbac_permissions import Action, Resource

logger = structlog.get_logger(__name__)


class AuditAction(str, Enum):
    """
    High-level audit action types.
    More granular than RBAC actions, captures business intent.
    """
    # Authentication actions
    LOGIN = "login"
    LOGOUT = "logout"
    TOKEN_REFRESH = "token_refresh"
    PASSWORD_RESET = "password_reset"
    
    # Resource creation
    RESOURCE_CREATED = "resource_created"
    
    # Resource modification
    RESOURCE_UPDATED = "resource_updated"
    RESOURCE_DELETED = "resource_deleted"
    RESOURCE_ARCHIVED = "resource_archived"
    RESOURCE_RESTORED = "resource_restored"
    
    # Permission changes
    ROLE_ASSIGNED = "role_assigned"
    ROLE_REVOKED = "role_revoked"
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_DENIED = "permission_denied"
    
    # Workspace actions
    WORKSPACE_CREATED = "workspace_created"
    WORKSPACE_DELETED = "workspace_deleted"
    MEMBER_INVITED = "member_invited"
    MEMBER_REMOVED = "member_removed"
    
    # Project actions
    PROJECT_CREATED = "project_created"
    PROJECT_DELETED = "project_deleted"
    PROJECT_ARCHIVED = "project_archived"
    
    # VAPT actions
    VULNERABILITY_SUBMITTED = "vulnerability_submitted"
    VULNERABILITY_UPDATED = "vulnerability_updated"
    VULNERABILITY_DELETED = "vulnerability_deleted"
    REPORT_GENERATED = "report_generated"
    TEMPLATE_UPLOADED = "template_uploaded"
    
    # Security events
    ACCESS_DENIED = "access_denied"
    PRIVILEGE_ESCALATION_ATTEMPT = "privilege_escalation_attempt"
    UNAUTHORIZED_ACCESS_ATTEMPT = "unauthorized_access_attempt"
    
    # Configuration changes
    SETTINGS_CHANGED = "settings_changed"
    POLICY_OVERRIDE_ENABLED = "policy_override_enabled"
    POLICY_OVERRIDE_DISABLED = "policy_override_disabled"


class AuditSeverity(str, Enum):
    """Severity levels for audit events"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AuditLog(BaseModel):
    """
    Immutable audit log entry.
    
    Every RBAC-protected action must generate an audit log entry.
    Logs are stored in a dedicated audit log collection/table.
    """
    # Unique audit log ID
    audit_id: str = Field(..., description="Unique audit log identifier")
    
    # Timestamp
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="When the action occurred")
    
    # Actor information
    actor_user_id: str = Field(..., description="User who performed the action")
    actor_role: Role = Field(..., description="Role of the user at the time of action")
    actor_email: Optional[str] = Field(None, description="Email of the actor")
    
    # Action information
    action: AuditAction = Field(..., description="High-level action performed")
    action_details: str = Field(..., description="Human-readable description of the action")
    severity: AuditSeverity = Field(AuditSeverity.INFO, description="Severity of the action")
    
    # Resource information
    resource_type: Optional[Resource] = Field(None, description="Type of resource affected")
    resource_id: Optional[str] = Field(None, description="ID of the resource affected")
    resource_name: Optional[str] = Field(None, description="Name of the resource affected")
    resource_owner_id: Optional[str] = Field(None, description="Owner of the resource")
    
    # Context information
    workspace_id: Optional[str] = Field(None, description="Workspace context")
    project_id: Optional[str] = Field(None, description="Project context")
    tenant_id: str = Field(..., description="Tenant context")
    
    # State changes
    previous_state: Optional[Dict[str, Any]] = Field(None, description="Previous state of the resource")
    new_state: Optional[Dict[str, Any]] = Field(None, description="New state of the resource")
    
    # Additional metadata
    ip_address: Optional[str] = Field(None, description="IP address of the actor")
    user_agent: Optional[str] = Field(None, description="User agent string")
    request_id: Optional[str] = Field(None, description="Request ID for correlation")
    service_name: Optional[str] = Field(None, description="Microservice that generated this log")
    
    # Authorization information
    permission_checked: Optional[str] = Field(None, description="Permission that was checked")
    authorization_granted: bool = Field(True, description="Whether authorization was granted")
    denial_reason: Optional[str] = Field(None, description="Reason for denial if applicable")
    
    # Tags for filtering and search
    tags: Dict[str, Any] = Field(default_factory=dict, description="Additional tags for filtering")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            Role: lambda v: str(v),
            Resource: lambda v: str(v),
            AuditAction: lambda v: str(v),
            AuditSeverity: lambda v: str(v),
        }


class AuditLogger:
    """
    Utility class for creating and storing audit logs.
    
    This class provides convenience methods for logging common RBAC actions.
    """
    
    def __init__(self, service_name: str):
        """
        Initialize the audit logger.
        
        Args:
            service_name: Name of the microservice (e.g., "project-service", "vapt-service")
        """
        self.service_name = service_name
        self.logger = logger.bind(component="audit_logger", service=service_name)
    
    def log_action(
        self,
        actor_user_id: str,
        actor_role: Role,
        action: AuditAction,
        action_details: str,
        tenant_id: str,
        workspace_id: Optional[str] = None,
        resource_type: Optional[Resource] = None,
        resource_id: Optional[str] = None,
        resource_name: Optional[str] = None,
        resource_owner_id: Optional[str] = None,
        project_id: Optional[str] = None,
        previous_state: Optional[Dict[str, Any]] = None,
        new_state: Optional[Dict[str, Any]] = None,
        severity: AuditSeverity = AuditSeverity.INFO,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        request_id: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None
    ) -> AuditLog:
        """
        Log an RBAC action to the audit trail.
        
        Args:
            actor_user_id: User performing the action
            actor_role: Role of the user
            action: Action being performed
            action_details: Human-readable description
            tenant_id: Tenant ID
            workspace_id: Optional workspace context
            resource_type: Optional resource type
            resource_id: Optional resource ID
            resource_name: Optional resource name
            resource_owner_id: Optional resource owner ID
            project_id: Optional project context
            previous_state: Optional previous state
            new_state: Optional new state
            severity: Severity level
            ip_address: Optional IP address
            user_agent: Optional user agent
            request_id: Optional request ID
            tags: Optional additional tags
            
        Returns:
            AuditLog entry
        """
        import uuid
        
        audit_log = AuditLog(
            audit_id=str(uuid.uuid4()),
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=action,
            action_details=action_details,
            severity=severity,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            resource_owner_id=resource_owner_id,
            workspace_id=workspace_id,
            project_id=project_id,
            tenant_id=tenant_id,
            previous_state=previous_state,
            new_state=new_state,
            ip_address=ip_address,
            user_agent=user_agent,
            request_id=request_id,
            service_name=self.service_name,
            tags=tags or {}
        )
        
        # Log to structured logger
        self.logger.info(
            "audit_event",
            audit_id=audit_log.audit_id,
            actor_user_id=actor_user_id,
            actor_role=str(actor_role),
            action=str(action),
            resource_type=str(resource_type) if resource_type else None,
            resource_id=resource_id,
            workspace_id=workspace_id,
            tenant_id=tenant_id,
            severity=str(severity)
        )
        
        # TODO: Store in database/audit log service
        # This should be implemented by each microservice
        # For now, we just return the audit log object
        
        return audit_log
    
    def log_permission_denied(
        self,
        actor_user_id: str,
        actor_role: Role,
        permission: str,
        resource_type: Resource,
        resource_id: Optional[str],
        denial_reason: str,
        tenant_id: str,
        workspace_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        request_id: Optional[str] = None
    ) -> AuditLog:
        """
        Log a permission denial event.
        
        Args:
            actor_user_id: User who was denied
            actor_role: Role of the user
            permission: Permission that was denied
            resource_type: Resource type
            resource_id: Resource ID
            denial_reason: Reason for denial
            tenant_id: Tenant ID
            workspace_id: Optional workspace ID
            ip_address: Optional IP address
            request_id: Optional request ID
            
        Returns:
            AuditLog entry
        """
        return self.log_action(
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=AuditAction.ACCESS_DENIED,
            action_details=f"Permission denied: {permission} - {denial_reason}",
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            resource_type=resource_type,
            resource_id=resource_id,
            severity=AuditSeverity.WARNING,
            ip_address=ip_address,
            request_id=request_id,
            tags={
                "permission": permission,
                "denial_reason": denial_reason,
                "authorization_granted": False
            }
        )
    
    def log_resource_created(
        self,
        actor_user_id: str,
        actor_role: Role,
        resource_type: Resource,
        resource_id: str,
        resource_name: str,
        tenant_id: str,
        workspace_id: Optional[str] = None,
        project_id: Optional[str] = None,
        new_state: Optional[Dict[str, Any]] = None
    ) -> AuditLog:
        """Log resource creation"""
        return self.log_action(
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=AuditAction.RESOURCE_CREATED,
            action_details=f"Created {resource_type}: {resource_name}",
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            project_id=project_id,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            resource_owner_id=actor_user_id,
            new_state=new_state,
            severity=AuditSeverity.INFO
        )
    
    def log_resource_deleted(
        self,
        actor_user_id: str,
        actor_role: Role,
        resource_type: Resource,
        resource_id: str,
        resource_name: str,
        resource_owner_id: str,
        tenant_id: str,
        workspace_id: Optional[str] = None,
        project_id: Optional[str] = None,
        previous_state: Optional[Dict[str, Any]] = None
    ) -> AuditLog:
        """Log resource deletion"""
        return self.log_action(
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=AuditAction.RESOURCE_DELETED,
            action_details=f"Deleted {resource_type}: {resource_name}",
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            project_id=project_id,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            resource_owner_id=resource_owner_id,
            previous_state=previous_state,
            severity=AuditSeverity.WARNING
        )
    
    def log_resource_updated(
        self,
        actor_user_id: str,
        actor_role: Role,
        resource_type: Resource,
        resource_id: str,
        resource_name: str,
        tenant_id: str,
        workspace_id: Optional[str] = None,
        project_id: Optional[str] = None,
        previous_state: Optional[Dict[str, Any]] = None,
        new_state: Optional[Dict[str, Any]] = None
    ) -> AuditLog:
        """Log resource update"""
        return self.log_action(
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=AuditAction.RESOURCE_UPDATED,
            action_details=f"Updated {resource_type}: {resource_name}",
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            project_id=project_id,
            resource_type=resource_type,
            resource_id=resource_id,
            resource_name=resource_name,
            previous_state=previous_state,
            new_state=new_state,
            severity=AuditSeverity.INFO
        )
    
    def log_role_changed(
        self,
        actor_user_id: str,
        actor_role: Role,
        target_user_id: str,
        old_role: Role,
        new_role: Role,
        tenant_id: str,
        workspace_id: str
    ) -> AuditLog:
        """Log role assignment/change"""
        return self.log_action(
            actor_user_id=actor_user_id,
            actor_role=actor_role,
            action=AuditAction.ROLE_ASSIGNED,
            action_details=f"Changed user role from {old_role} to {new_role}",
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            severity=AuditSeverity.WARNING,
            previous_state={"user_id": target_user_id, "role": str(old_role)},
            new_state={"user_id": target_user_id, "role": str(new_role)},
            tags={"target_user_id": target_user_id}
        )


# Global audit logger instances per service
_audit_loggers: Dict[str, AuditLogger] = {}


def get_audit_logger(service_name: str) -> AuditLogger:
    """
    Get or create an audit logger for a service.
    
    Args:
        service_name: Name of the microservice
        
    Returns:
        AuditLogger instance
    """
    if service_name not in _audit_loggers:
        _audit_loggers[service_name] = AuditLogger(service_name)
    return _audit_loggers[service_name]

