"""
Analytics Dashboard Router
Provides comprehensive analytics endpoints for performance monitoring

Endpoints:
- /analytics/performance - API performance metrics
- /analytics/errors - Error analysis
- /analytics/dashboard - Complete analytics dashboard
- /metrics - Prometheus metrics (if enabled)
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import Response
from typing import Optional, Dict, Any
from datetime import datetime
import logging

from .observability import get_observability_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/performance")
async def get_performance_metrics(
    endpoint: Optional[str] = None,
    service_name: str = "default"
) -> Dict[str, Any]:
    """
    Get API performance metrics
    
    Returns:
    - Request counts
    - Latency (p50, p95, p99, avg, min, max)
    - Error rates
    - Response sizes
    """
    try:
        observability = get_observability_manager(service_name)
        stats = observability.performance_tracker.get_performance_stats(endpoint)
        
        return {
            "service": service_name,
            "endpoint": endpoint or "all",
            "metrics": stats,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get performance metrics: {str(e)}"
        )


@router.get("/errors")
async def get_error_analysis(
    hours: int = 24,
    service_name: str = "default"
) -> Dict[str, Any]:
    """
    Get error analysis
    
    Args:
        hours: Number of hours to analyze (default: 24)
        service_name: Service name
    
    Returns:
    - Total errors
    - Error types breakdown
    - Error patterns
    - Recent errors
    """
    try:
        observability = get_observability_manager(service_name)
        error_summary = observability.error_tracker.get_error_summary(hours)
        error_analysis = observability.performance_tracker.get_error_analysis()
        
        return {
            "service": service_name,
            "time_range_hours": hours,
            "error_summary": error_summary,
            "error_analysis": error_analysis,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting error analysis: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get error analysis: {str(e)}"
        )


@router.get("/dashboard")
async def get_analytics_dashboard(
    service_name: str = "default"
) -> Dict[str, Any]:
    """
    Get complete analytics dashboard
    
    Returns comprehensive analytics including:
    - Performance metrics
    - Error analysis
    - Request trends
    - Service health
    """
    try:
        observability = get_observability_manager(service_name)
        dashboard = observability.get_analytics_dashboard()
        
        return dashboard
    except Exception as e:
        logger.error(f"Error getting analytics dashboard: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get analytics dashboard: {str(e)}"
        )


@router.get("/metrics")
async def get_prometheus_metrics(service_name: str = "default"):
    """
    Get Prometheus metrics endpoint
    
    Returns metrics in Prometheus format for scraping
    """
    try:
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        
        return Response(
            content=generate_latest(),
            media_type=CONTENT_TYPE_LATEST
        )
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Prometheus metrics not available - install prometheus-client"
        )
    except Exception as e:
        logger.error(f"Error generating Prometheus metrics: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate metrics: {str(e)}"
        )

