"""
Soft Delete Mixin for MongoDB/Beanie Models
Provides soft delete functionality with recovery capability
"""

from typing import Optional
from datetime import datetime
from pydantic import Field


class SoftDeleteMixin:
    """
    Mixin to add soft delete capabilities to any model
    
    Usage:
        class MyModel(Document, SoftDeleteMixin):
            name: str
            
        # Soft delete
        await my_model.soft_delete(deleted_by="user_id", reason="user_requested")
        
        # Query active only
        active_items = await MyModel.find_active({"name": "test"})
        
        # Query including deleted
        all_items = await MyModel.find({"name": "test"})
        
        # Restore
        await my_model.restore()
    """
    
    # Soft delete fields
    deleted: bool = Field(default=False, description="Soft delete flag")
    deleted_at: Optional[datetime] = Field(default=None, description="When entity was deleted")
    deleted_by: Optional[str] = Field(default=None, description="User who deleted this entity")
    deletion_reason: Optional[str] = Field(default=None, description="Reason for deletion")
    
    async def soft_delete(
        self,
        deleted_by: str,
        reason: str = "user_requested"
    ):
        """
        Soft delete this entity
        
        Args:
            deleted_by: User ID who is deleting
            reason: Reason for deletion (user_requested, admin_action, etc.)
        """
        self.deleted = True
        self.deleted_at = datetime.utcnow()
        self.deleted_by = deleted_by
        self.deletion_reason = reason
        await self.save()
    
    async def restore(self):
        """Restore a soft-deleted entity"""
        self.deleted = False
        self.deleted_at = None
        self.deleted_by = None
        self.deletion_reason = None
        await self.save()
    
    @classmethod
    def find_active(cls, *args, **kwargs):
        """
        Find entities excluding soft-deleted ones
        Returns a query builder (not a coroutine) - use .to_list() to execute
        
        Usage:
            active_items = await MyModel.find_active({"name": "test"}).to_list()
        """
        # Add deleted=False to the query
        if args:
            # If using positional args (filter dict)
            query = args[0] if args else {}
            if isinstance(query, dict):
                query = {**query, "deleted": False}
            return cls.find(query, *args[1:], **kwargs)
        else:
            # If using kwargs or Beanie query syntax
            # Handle Beanie query syntax (e.g., MyModel.find(Model.field == value))
            if not kwargs:
                # If no kwargs, create a query with deleted=False
                return cls.find(cls.deleted == False)
            # If kwargs provided, add deleted=False
            if "deleted" not in kwargs:
                kwargs["deleted"] = False
            return cls.find(**kwargs)
    
    @classmethod
    async def find_deleted(cls, *args, **kwargs):
        """
        Find only soft-deleted entities
        
        Usage:
            deleted_items = await MyModel.find_deleted({"name": "test"})
        """
        if args:
            query = args[0] if args else {}
            query["deleted"] = True
            return await cls.find(query, *args[1:], **kwargs)
        else:
            kwargs["deleted"] = True
            return await cls.find(**kwargs)
    
    @classmethod
    async def count_active(cls, *args, **kwargs):
        """Count active entities only"""
        if args:
            query = args[0] if args else {}
            query["deleted"] = False
            return await cls.count(query)
        else:
            kwargs["deleted"] = False
            return await cls.count(**kwargs)


class SoftDeleteQueryMixin:
    """
    Helper functions for querying with soft delete awareness
    Can be used independently or with SoftDeleteMixin
    """
    
    @staticmethod
    def add_active_filter(query: dict) -> dict:
        """Add deleted=False to query dict"""
        return {**query, "deleted": False}
    
    @staticmethod
    def add_deleted_filter(query: dict) -> dict:
        """Add deleted=True to query dict"""
        return {**query, "deleted": True}


def soft_delete_filter(query: dict, include_deleted: bool = False) -> dict:
    """
    Decorator/helper to add soft delete filter to queries
    
    Usage:
        query = {"workspace_id": workspace_id}
        active_query = soft_delete_filter(query)  # Adds deleted=False
        all_query = soft_delete_filter(query, include_deleted=True)  # No filter
    """
    if include_deleted:
        return query
    return {**query, "deleted": False}
