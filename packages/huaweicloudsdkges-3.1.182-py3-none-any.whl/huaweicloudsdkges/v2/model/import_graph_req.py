# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ImportGraphReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'edgeset_path': 'str',
        'edgeset_format': 'str',
        'vertexset_path': 'str',
        'vertexset_format': 'str',
        'schema_path': 'str',
        'log_dir': 'str',
        'parallel_edge': 'ImportGraphReqParallelEdge',
        'delimiter': 'str',
        'trim_quote': 'str',
        'offline': 'bool'
    }

    attribute_map = {
        'edgeset_path': 'edgeset_path',
        'edgeset_format': 'edgeset_format',
        'vertexset_path': 'vertexset_path',
        'vertexset_format': 'vertexset_format',
        'schema_path': 'schema_path',
        'log_dir': 'log_dir',
        'parallel_edge': 'parallel_edge',
        'delimiter': 'delimiter',
        'trim_quote': 'trim_quote',
        'offline': 'offline'
    }

    def __init__(self, edgeset_path=None, edgeset_format=None, vertexset_path=None, vertexset_format=None, schema_path=None, log_dir=None, parallel_edge=None, delimiter=None, trim_quote=None, offline=None):
        r"""ImportGraphReq

        The model defined in huaweicloud sdk

        :param edgeset_path: 边文件目录或边文件名。
        :type edgeset_path: str
        :param edgeset_format: 边数据集格式。当前仅支持csv。  默认为csv。
        :type edgeset_format: str
        :param vertexset_path: 点文件目录或点文件名。
        :type vertexset_path: str
        :param vertexset_format: 点数据集格式。当前仅支持csv。  默认为csv。
        :type vertexset_format: str
        :param schema_path: 新增数据的元数据文件路径。
        :type schema_path: str
        :param log_dir: 导入图日志存放目录，用于存储导入失败的数据和详细错入原因。
        :type log_dir: str
        :param parallel_edge: 
        :type parallel_edge: :class:`huaweicloudsdkges.v2.ImportGraphReqParallelEdge`
        :param delimiter: csv格式文件字段分隔符，默认值为逗号（,）。list/set类型的字段内元素分隔符默认为分号（;）。
        :type delimiter: str
        :param trim_quote: csv格式文件字段包围符，默认值为双引号（\&quot;）。用来包围一个字段，如字段中含有分隔符或者换行等。
        :type trim_quote: str
        :param offline: 是否离线导入，取值为true或者false，默认取false。  - true 表示离线导入，导入速度较快，但导入过程中图处于锁定状态，不可读不可写。 - false 表示在线导入，相对离线导入，在线导入速度略慢，但导入过程中图并未锁定，可读不可写。
        :type offline: bool
        """
        
        

        self._edgeset_path = None
        self._edgeset_format = None
        self._vertexset_path = None
        self._vertexset_format = None
        self._schema_path = None
        self._log_dir = None
        self._parallel_edge = None
        self._delimiter = None
        self._trim_quote = None
        self._offline = None
        self.discriminator = None

        if edgeset_path is not None:
            self.edgeset_path = edgeset_path
        if edgeset_format is not None:
            self.edgeset_format = edgeset_format
        if vertexset_path is not None:
            self.vertexset_path = vertexset_path
        if vertexset_format is not None:
            self.vertexset_format = vertexset_format
        if schema_path is not None:
            self.schema_path = schema_path
        if log_dir is not None:
            self.log_dir = log_dir
        if parallel_edge is not None:
            self.parallel_edge = parallel_edge
        if delimiter is not None:
            self.delimiter = delimiter
        if trim_quote is not None:
            self.trim_quote = trim_quote
        if offline is not None:
            self.offline = offline

    @property
    def edgeset_path(self):
        r"""Gets the edgeset_path of this ImportGraphReq.

        边文件目录或边文件名。

        :return: The edgeset_path of this ImportGraphReq.
        :rtype: str
        """
        return self._edgeset_path

    @edgeset_path.setter
    def edgeset_path(self, edgeset_path):
        r"""Sets the edgeset_path of this ImportGraphReq.

        边文件目录或边文件名。

        :param edgeset_path: The edgeset_path of this ImportGraphReq.
        :type edgeset_path: str
        """
        self._edgeset_path = edgeset_path

    @property
    def edgeset_format(self):
        r"""Gets the edgeset_format of this ImportGraphReq.

        边数据集格式。当前仅支持csv。  默认为csv。

        :return: The edgeset_format of this ImportGraphReq.
        :rtype: str
        """
        return self._edgeset_format

    @edgeset_format.setter
    def edgeset_format(self, edgeset_format):
        r"""Sets the edgeset_format of this ImportGraphReq.

        边数据集格式。当前仅支持csv。  默认为csv。

        :param edgeset_format: The edgeset_format of this ImportGraphReq.
        :type edgeset_format: str
        """
        self._edgeset_format = edgeset_format

    @property
    def vertexset_path(self):
        r"""Gets the vertexset_path of this ImportGraphReq.

        点文件目录或点文件名。

        :return: The vertexset_path of this ImportGraphReq.
        :rtype: str
        """
        return self._vertexset_path

    @vertexset_path.setter
    def vertexset_path(self, vertexset_path):
        r"""Sets the vertexset_path of this ImportGraphReq.

        点文件目录或点文件名。

        :param vertexset_path: The vertexset_path of this ImportGraphReq.
        :type vertexset_path: str
        """
        self._vertexset_path = vertexset_path

    @property
    def vertexset_format(self):
        r"""Gets the vertexset_format of this ImportGraphReq.

        点数据集格式。当前仅支持csv。  默认为csv。

        :return: The vertexset_format of this ImportGraphReq.
        :rtype: str
        """
        return self._vertexset_format

    @vertexset_format.setter
    def vertexset_format(self, vertexset_format):
        r"""Sets the vertexset_format of this ImportGraphReq.

        点数据集格式。当前仅支持csv。  默认为csv。

        :param vertexset_format: The vertexset_format of this ImportGraphReq.
        :type vertexset_format: str
        """
        self._vertexset_format = vertexset_format

    @property
    def schema_path(self):
        r"""Gets the schema_path of this ImportGraphReq.

        新增数据的元数据文件路径。

        :return: The schema_path of this ImportGraphReq.
        :rtype: str
        """
        return self._schema_path

    @schema_path.setter
    def schema_path(self, schema_path):
        r"""Sets the schema_path of this ImportGraphReq.

        新增数据的元数据文件路径。

        :param schema_path: The schema_path of this ImportGraphReq.
        :type schema_path: str
        """
        self._schema_path = schema_path

    @property
    def log_dir(self):
        r"""Gets the log_dir of this ImportGraphReq.

        导入图日志存放目录，用于存储导入失败的数据和详细错入原因。

        :return: The log_dir of this ImportGraphReq.
        :rtype: str
        """
        return self._log_dir

    @log_dir.setter
    def log_dir(self, log_dir):
        r"""Sets the log_dir of this ImportGraphReq.

        导入图日志存放目录，用于存储导入失败的数据和详细错入原因。

        :param log_dir: The log_dir of this ImportGraphReq.
        :type log_dir: str
        """
        self._log_dir = log_dir

    @property
    def parallel_edge(self):
        r"""Gets the parallel_edge of this ImportGraphReq.

        :return: The parallel_edge of this ImportGraphReq.
        :rtype: :class:`huaweicloudsdkges.v2.ImportGraphReqParallelEdge`
        """
        return self._parallel_edge

    @parallel_edge.setter
    def parallel_edge(self, parallel_edge):
        r"""Sets the parallel_edge of this ImportGraphReq.

        :param parallel_edge: The parallel_edge of this ImportGraphReq.
        :type parallel_edge: :class:`huaweicloudsdkges.v2.ImportGraphReqParallelEdge`
        """
        self._parallel_edge = parallel_edge

    @property
    def delimiter(self):
        r"""Gets the delimiter of this ImportGraphReq.

        csv格式文件字段分隔符，默认值为逗号（,）。list/set类型的字段内元素分隔符默认为分号（;）。

        :return: The delimiter of this ImportGraphReq.
        :rtype: str
        """
        return self._delimiter

    @delimiter.setter
    def delimiter(self, delimiter):
        r"""Sets the delimiter of this ImportGraphReq.

        csv格式文件字段分隔符，默认值为逗号（,）。list/set类型的字段内元素分隔符默认为分号（;）。

        :param delimiter: The delimiter of this ImportGraphReq.
        :type delimiter: str
        """
        self._delimiter = delimiter

    @property
    def trim_quote(self):
        r"""Gets the trim_quote of this ImportGraphReq.

        csv格式文件字段包围符，默认值为双引号（\"）。用来包围一个字段，如字段中含有分隔符或者换行等。

        :return: The trim_quote of this ImportGraphReq.
        :rtype: str
        """
        return self._trim_quote

    @trim_quote.setter
    def trim_quote(self, trim_quote):
        r"""Sets the trim_quote of this ImportGraphReq.

        csv格式文件字段包围符，默认值为双引号（\"）。用来包围一个字段，如字段中含有分隔符或者换行等。

        :param trim_quote: The trim_quote of this ImportGraphReq.
        :type trim_quote: str
        """
        self._trim_quote = trim_quote

    @property
    def offline(self):
        r"""Gets the offline of this ImportGraphReq.

        是否离线导入，取值为true或者false，默认取false。  - true 表示离线导入，导入速度较快，但导入过程中图处于锁定状态，不可读不可写。 - false 表示在线导入，相对离线导入，在线导入速度略慢，但导入过程中图并未锁定，可读不可写。

        :return: The offline of this ImportGraphReq.
        :rtype: bool
        """
        return self._offline

    @offline.setter
    def offline(self, offline):
        r"""Sets the offline of this ImportGraphReq.

        是否离线导入，取值为true或者false，默认取false。  - true 表示离线导入，导入速度较快，但导入过程中图处于锁定状态，不可读不可写。 - false 表示在线导入，相对离线导入，在线导入速度略慢，但导入过程中图并未锁定，可读不可写。

        :param offline: The offline of this ImportGraphReq.
        :type offline: bool
        """
        self._offline = offline

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ImportGraphReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
