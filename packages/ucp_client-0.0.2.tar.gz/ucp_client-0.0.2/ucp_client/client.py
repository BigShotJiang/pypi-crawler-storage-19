#   Copyright 2026 UCP Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""Type-safe UCP Client for interacting with UCP Shopping API."""

import uuid
from typing import Any, Dict, Optional

import httpx
from ucp_sdk.models.discovery.profile_schema import UcpDiscoveryProfile
from ucp_sdk.models.schemas.shopping import checkout_create_req
from ucp_sdk.models.schemas.shopping import checkout_resp
from ucp_sdk.models.schemas.shopping import checkout_update_req
from ucp_sdk.models.schemas.shopping import order
from ucp_sdk.models.schemas.shopping import payment_create_req
from ucp_sdk.models.schemas.shopping.ap2_mandate import Ap2CompleteRequest


class UCPClientError(Exception):
    """Base exception for UCP client errors."""

    def __init__(self, message: str, status_code: Optional[int] = None, response_data: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data


class UCPClient:
    """Type-safe client for UCP Shopping API.

    Handles authentication, request signing, and provides type-safe methods
    for all UCP endpoints.
    """

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        ucp_agent_profile: Optional[str] = None,
        timeout: float = 30.0
    ):
        """Initialize the UCP client.

        Args:
            base_url: Base URL of the UCP server (e.g., "http://localhost:8182")
            api_key: Optional API key for authentication
            ucp_agent_profile: UCP-Agent header value (e.g., 'profile="https://agent.example/profile"')
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.ucp_agent_profile = ucp_agent_profile or 'profile="https://agent.example/profile"'
        self.timeout = timeout
        self._client = httpx.AsyncClient(timeout=timeout)

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self._client.aclose()

    def _get_headers(self, idempotency_key: Optional[str] = None) -> Dict[str, str]:
        """Generate standard headers for UCP requests."""
        headers = {
            "UCP-Agent": self.ucp_agent_profile,
            "Request-Signature": "test",  # In production, this should be properly signed
            "Request-Id": str(uuid.uuid4()),
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if self.api_key:
            headers["X-API-Key"] = self.api_key

        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        else:
            headers["Idempotency-Key"] = str(uuid.uuid4())

        return headers

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the UCP server."""
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(idempotency_key)

        try:
            response = await self._client.request(
                method=method,
                url=url,
                headers=headers,
                json=json_data,
            )

            if response.status_code >= 400:
                try:
                    error_data = response.json()
                except:
                    error_data = {"message": response.text}

                raise UCPClientError(
                    f"Request failed with status {response.status_code}: {error_data.get('message', 'Unknown error')}",
                    status_code=response.status_code,
                    response_data=error_data
                )

            return response.json()

        except httpx.RequestError as e:
            raise UCPClientError(f"Network error: {str(e)}") from e

    # Discovery Endpoints

    async def get_merchant_profile(self) -> UcpDiscoveryProfile:
        """Get the merchant's UCP profile and capabilities.

        Returns:
            UcpDiscoveryProfile: Merchant profile with supported capabilities
        """
        response_data = await self._make_request("GET", "/.well-known/ucp")
        return UcpDiscoveryProfile(**response_data)

    # Checkout Endpoints

    async def create_checkout(
        self,
        request: checkout_create_req.CheckoutCreateRequest,
        idempotency_key: Optional[str] = None
    ) -> checkout_resp.CheckoutResponse:
        """Create a new checkout session.

        Args:
            request: Checkout creation request data
            idempotency_key: Optional idempotency key for the request

        Returns:
            CheckoutResponse: Created checkout session
        """
        request_data = request.model_dump(mode="json", by_alias=True, exclude_unset=True)
        response_data = await self._make_request(
            "POST", "/checkout-sessions", request_data, idempotency_key
        )
        return checkout_resp.CheckoutResponse(**response_data)

    async def get_checkout(self, checkout_id: str) -> checkout_resp.CheckoutResponse:
        """Get a checkout session by ID.

        Args:
            checkout_id: The checkout session ID

        Returns:
            CheckoutResponse: Checkout session data
        """
        response_data = await self._make_request("GET", f"/checkout-sessions/{checkout_id}")
        return checkout_resp.CheckoutResponse(**response_data)

    async def update_checkout(
        self,
        checkout_id: str,
        request: checkout_update_req.CheckoutUpdateRequest,
        idempotency_key: Optional[str] = None
    ) -> checkout_resp.CheckoutResponse:
        """Update a checkout session.

        Args:
            checkout_id: The checkout session ID
            request: Checkout update request data
            idempotency_key: Optional idempotency key for the request

        Returns:
            CheckoutResponse: Updated checkout session
        """
        request_data = request.model_dump(mode="json", by_alias=True, exclude_unset=True)
        response_data = await self._make_request(
            "PUT", f"/checkout-sessions/{checkout_id}", request_data, idempotency_key
        )
        return checkout_resp.CheckoutResponse(**response_data)

    async def complete_checkout(
        self,
        checkout_id: str,
        payment_data: Dict[str, Any],
        risk_signals: Optional[Dict[str, Any]] = None,
        ap2: Optional[Ap2CompleteRequest] = None,
        idempotency_key: Optional[str] = None
    ) -> checkout_resp.CheckoutResponse:
        """Complete a checkout session with payment.

        Args:
            checkout_id: The checkout session ID
            payment_data: Payment instrument data
            risk_signals: Optional risk assessment signals
            ap2: Optional AP2 mandate data
            idempotency_key: Optional idempotency key for the request

        Returns:
            CheckoutResponse: Completed checkout session
        """
        request_data = {
            "payment_data": payment_data,
            "risk_signals": risk_signals or {},
        }
        if ap2:
            request_data["ap2"] = ap2.model_dump(mode="json", by_alias=True, exclude_unset=True)

        response_data = await self._make_request(
            "POST", f"/checkout-sessions/{checkout_id}/complete", request_data, idempotency_key
        )
        return checkout_resp.CheckoutResponse(**response_data)

    async def cancel_checkout(
        self,
        checkout_id: str,
        idempotency_key: Optional[str] = None
    ) -> checkout_resp.CheckoutResponse:
        """Cancel a checkout session.

        Args:
            checkout_id: The checkout session ID
            idempotency_key: Optional idempotency key for the request

        Returns:
            CheckoutResponse: Cancelled checkout session
        """
        response_data = await self._make_request(
            "POST", f"/checkout-sessions/{checkout_id}/cancel", idempotency_key=idempotency_key
        )
        return checkout_resp.CheckoutResponse(**response_data)

    # Order Endpoints

    async def get_order(self, order_id: str) -> Dict[str, Any]:
        """Get an order by ID.

        Args:
            order_id: The order ID

        Returns:
            Dict containing order data
        """
        return await self._make_request("GET", f"/orders/{order_id}")

    async def update_order(
        self,
        order_id: str,
        order_data: order.Order
    ) -> Dict[str, Any]:
        """Update an order.

        Args:
            order_id: The order ID
            order_data: Updated order data

        Returns:
            Dict containing updated order data
        """
        request_data = order_data.model_dump(mode="json", by_alias=True, exclude_unset=True)
        return await self._make_request("PUT", f"/orders/{order_id}", request_data)

    # Testing Endpoints (for development/testing only)

    async def simulate_shipping(self, order_id: str) -> Dict[str, Any]:
        """Simulate shipping an order (testing endpoint).

        Args:
            order_id: The order ID to ship

        Returns:
            Dict with shipping status
        """
        return await self._make_request("POST", f"/testing/simulate-shipping/{order_id}")

    # Webhook endpoint (typically called by server, but included for completeness)

    async def send_order_webhook(
        self,
        partner_id: str,
        order_data: order.Order
    ) -> Dict[str, Any]:
        """Send an order event webhook (typically called by the server).

        Args:
            partner_id: Partner identifier
            order_data: Order event data

        Returns:
            Dict with webhook response
        """
        request_data = order_data.model_dump(mode="json", by_alias=True, exclude_unset=True)
        return await self._make_request(
            "POST", f"/webhooks/partners/{partner_id}/events/order", request_data
        )
