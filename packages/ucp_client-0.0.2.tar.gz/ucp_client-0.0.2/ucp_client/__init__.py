#   Copyright 2026 UCP Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""UCP Client - Python client library for Universal Checkout Protocol.

This package provides:
- UCPClient: Type-safe async client for UCP Shopping API
- UCPAgentTools: LLM-friendly synchronous tools for agent frameworks
- UCPClientError: Exception class for UCP client errors

Example usage:
    from ucp_client import UCPAgentTools
    
    tools = UCPAgentTools("http://localhost:8182")
    merchant = tools.discover_merchant()
    cart = tools.create_cart(
        product_id="bouquet_roses",
        quantity=2,
        buyer_name="John Doe",
        buyer_email="john@example.com"
    )
"""

from .client import UCPClient, UCPClientError
from .agent_tools import UCPAgentTools, get_openai_tools_schema, get_anthropic_tools_schema

__version__ = "0.0.2"

__all__ = [
    "UCPClient",
    "UCPClientError",
    "UCPAgentTools",
    "get_openai_tools_schema",
    "get_anthropic_tools_schema",
]
