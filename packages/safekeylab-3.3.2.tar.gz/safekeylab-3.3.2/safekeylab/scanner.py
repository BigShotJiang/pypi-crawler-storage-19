"""
PII Scanner - Local scanning capabilities using PerfectPIIDetector
"""

import os
from typing import List, Dict, Any, Optional

from .perfect_pii_detector import PerfectPIIDetector, PIIEntity


class PIIScanner:
    """
    Local PII scanner for offline detection.

    Uses the PerfectPIIDetector for high-accuracy PII detection
    without requiring API calls.

    Example:
        scanner = PIIScanner()
        entities = scanner.scan_text("Contact john@example.com")
        for entity in entities:
            print(f"{entity['label']}: {entity['text']}")
    """

    def __init__(self):
        """Initialize local scanner with PII detector"""
        self.detector = PerfectPIIDetector()

    def scan_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Scan text for PII.

        Args:
            text: Text to scan

        Returns:
            List of detected PII entities as dictionaries
        """
        entities = self.detector.detect(text)
        return [self._entity_to_dict(e) for e in entities]

    def scan_file(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Scan file for PII based on file type.

        Currently supports text-based files. For multimodal scanning
        (images, audio, video), use the API client instead.

        Args:
            file_path: Path to file

        Returns:
            List of detected PII entities

        Raises:
            ValueError: If file type is not supported
            FileNotFoundError: If file doesn't exist
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        ext = file_path.lower().split(".")[-1]

        # Text-based files we can scan locally
        text_extensions = ["txt", "csv", "json", "xml", "md", "log", "py", "js", "html", "css", "yaml", "yml", "ini", "conf", "cfg"]

        if ext in text_extensions:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
            except UnicodeDecodeError:
                with open(file_path, "r", encoding="latin-1") as f:
                    content = f.read()
            return self.scan_text(content)

        # Multimodal files require API
        multimodal_extensions = {
            "image": ["jpg", "jpeg", "png", "gif", "bmp", "webp"],
            "audio": ["mp3", "wav", "m4a", "ogg", "flac"],
            "video": ["mp4", "avi", "mov", "webm", "mkv"],
            "document": ["pdf", "docx", "xlsx", "pptx", "doc", "xls"]
        }

        for modality, extensions in multimodal_extensions.items():
            if ext in extensions:
                raise ValueError(
                    f"File type '{ext}' requires multimodal scanning. "
                    f"Use SafeKeyClient.detect_{modality}() API method instead."
                )

        raise ValueError(f"Unsupported file type: {ext}")

    def scan_directory(
        self,
        directory: str,
        recursive: bool = True,
        extensions: Optional[List[str]] = None
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Scan directory for PII in text files.

        Args:
            directory: Directory path
            recursive: Scan subdirectories (default: True)
            extensions: List of file extensions to scan (default: common text files)

        Returns:
            Dictionary mapping file paths to PII entities
        """
        if not os.path.isdir(directory):
            raise ValueError(f"Not a directory: {directory}")

        # Default extensions for text scanning
        if extensions is None:
            extensions = ["txt", "csv", "json", "xml", "md", "log", "py", "js", "html", "yaml", "yml"]

        results = {}

        for root, dirs, files in os.walk(directory):
            for file in files:
                ext = file.lower().split(".")[-1]
                if ext not in extensions:
                    continue

                file_path = os.path.join(root, file)
                try:
                    entities = self.scan_file(file_path)
                    if entities:
                        results[file_path] = entities
                except Exception as e:
                    results[file_path] = [{"error": str(e)}]

            if not recursive:
                break

        return results

    def _entity_to_dict(self, entity: PIIEntity) -> Dict[str, Any]:
        """Convert PIIEntity dataclass to dictionary"""
        return {
            "text": entity.value,
            "label": entity.type,
            "confidence": entity.confidence,
            "start": entity.start,
            "end": entity.end,
            "modality": "text",
            "metadata": {}
        }

    def get_supported_types(self) -> List[str]:
        """Get list of PII types that can be detected"""
        return list(self.detector.patterns.keys())
