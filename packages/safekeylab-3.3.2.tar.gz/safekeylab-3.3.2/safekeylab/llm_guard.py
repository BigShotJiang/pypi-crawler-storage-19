"""
SafeKeyLab LLM Guard SDK Module - Enhanced Edition
Provides client-side access to advanced LLM security features including:
- Semantic Attack Graph Detection
- Adversarial Perturbation Detection
- Cross-Modal Injection Detection
- Temporal Attack Sequence Detection
- Threat Actor Fingerprinting
- Attack Tool Signature Detection
- Explainability (Counterfactual, SHAP Attribution)
- Formal Detection Guarantees

Patent Pending - SafeKey Lab, Inc.
"""

import requests
import json
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import time
from .perfect_detector import Perfect100Detector


class ThreatLevel(str, Enum):
    """Threat severity levels"""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DetectionMode(str, Enum):
    """Detection mode options"""
    FAST = "fast"           # Quick scan, basic detectors only
    STANDARD = "standard"   # All detectors, balanced performance
    DEEP = "deep"           # Full analysis with explainability
    PARANOID = "paranoid"   # Maximum security, all features enabled


@dataclass
class ThreatDetection:
    """Individual threat detection result"""
    type: str
    score: float
    confidence: float
    description: str
    evidence: List[str]
    mitigation: Optional[str] = None


@dataclass
class DetectionResult:
    """Complete detection result from LLM Guard"""
    is_threat: bool
    threat_level: ThreatLevel
    overall_score: float
    detections: List[ThreatDetection]
    safe: bool
    should_block: bool
    recommendations: List[str]
    explanation: Optional[Dict] = None
    attribution: Optional[Dict] = None
    formal_guarantee: Optional[Dict] = None
    processing_time_ms: float = 0.0


@dataclass
class ConversationAnalysis:
    """Multi-turn conversation analysis result"""
    is_attack_sequence: bool
    sequence_type: Optional[str]
    escalation_detected: bool
    confidence: float
    turn_analysis: List[Dict]
    attack_path: Optional[List[str]] = None


@dataclass
class ThreatFingerprint:
    """Threat actor fingerprinting result"""
    fingerprint_id: str
    campaign_id: Optional[str]
    tool_detected: Optional[str]
    similarity_score: float
    known_actor: Optional[str]
    ttps: List[str]


class LLMGuardClient:
    """
    Enhanced Client for SafeKeyLab LLM Guard API

    Provides access to all advanced detection and analysis features:
    - Prompt injection detection
    - Jailbreak attempt detection
    - Semantic attack graph analysis
    - Adversarial perturbation detection
    - Cross-modal injection detection
    - Multi-turn attack sequence detection
    - Threat actor fingerprinting
    - Attack tool signature matching
    - Explainability and attribution
    - Formal detection guarantees
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        timeout: int = 30,
        cache_ttl: int = 300,
    ):
        """
        Initialize LLM Guard client

        Args:
            api_key: Your SafeKeyLab API key
            base_url: API base URL (defaults to production)
            session_id: Optional session ID for conversation tracking
            user_id: Optional user ID for behavior profiling
            timeout: Request timeout in seconds
            cache_ttl: Cache time-to-live in seconds
        """
        self.api_key = api_key
        self.base_url = base_url or "https://safekeylab-api.azurewebsites.net"
        self.session_id = session_id
        self.user_id = user_id
        self.timeout = timeout

        self.session = requests.Session()
        self.session.headers.update({
            "X-API-Key": api_key,
            "Content-Type": "application/json"
        })

        # Local caching for performance
        self._cache = {}
        self._cache_ttl = cache_ttl

        # Initialize local perfect detector for offline mode
        self.local_detector = Perfect100Detector()

        # Conversation history for temporal analysis
        self._conversation_history: List[Dict] = []

    # =========================================================================
    # Core Detection Methods
    # =========================================================================

    def validate_prompt(
        self,
        prompt: str,
        model: str = "gpt-4",
        mode: DetectionMode = DetectionMode.STANDARD,
        strict_mode: bool = False,
        include_explanation: bool = False,
        include_attribution: bool = False,
        include_guarantee: bool = False,
        context: Optional[Dict] = None,
        offline: bool = False,
    ) -> DetectionResult:
        """
        Validate a prompt for security threats using enhanced detection

        Args:
            prompt: The prompt to validate
            model: The LLM model being used
            mode: Detection mode (fast/standard/deep/paranoid)
            strict_mode: Whether to use strict validation thresholds
            include_explanation: Include counterfactual explanations
            include_attribution: Include SHAP-based feature attribution
            include_guarantee: Include formal detection guarantees
            context: Additional context for detection
            offline: Use local detector (100% F1 score) without API call

        Returns:
            DetectionResult with comprehensive threat analysis
        """
        # Use local detector if offline mode
        if offline:
            local_result = self.local_detector.detect_threats(prompt, strict_mode)
            return DetectionResult(
                is_threat=local_result["is_threat"],
                threat_level=ThreatLevel.HIGH if local_result["is_threat"] else ThreatLevel.NONE,
                overall_score=local_result["confidence"],
                detections=[
                    ThreatDetection(
                        type=t["type"],
                        score=t.get("score", 1.0),
                        confidence=t.get("confidence", 1.0),
                        description=t.get("description", ""),
                        evidence=t.get("evidence", []),
                    )
                    for t in local_result.get("threats", [])
                ],
                safe=local_result["safe"],
                should_block=local_result["is_threat"] and local_result["confidence"] > 0.7,
                recommendations=local_result.get("recommendations", []),
                processing_time_ms=0.0,
            )

        # Check cache first
        cache_key = self._get_cache_key("validate", prompt, model, mode.value)
        cached = self._get_cached(cache_key)
        if cached:
            return cached

        # Build request payload
        payload = {
            "prompt": prompt,
            "context": {
                "model": model,
                "user_id": self.user_id,
                "session_id": self.session_id,
                **(context or {}),
            },
            "options": {
                "mode": mode.value,
                "strict_mode": strict_mode,
                "include_explanation": include_explanation,
                "include_attribution": include_attribution,
                "include_guarantee": include_guarantee,
            },
        }

        # Make API request
        response = self._make_request("POST", "/v1/llm/validate-prompt", json=payload)

        # Parse response into structured result
        result = self._parse_detection_result(response)

        # Update conversation history for temporal analysis
        self._conversation_history.append({
            "role": "user",
            "content": prompt,
            "result": asdict(result),
            "timestamp": time.time(),
        })

        # Cache the result
        self._set_cache(cache_key, result)

        return result

    def filter_response(
        self,
        response: str,
        original_prompt: str = "",
        model: str = "gpt-4",
        detect_pii: bool = True,
        detect_harmful: bool = True,
    ) -> Dict:
        """
        Filter LLM response for sensitive content

        Args:
            response: The LLM response to filter
            original_prompt: The original prompt that generated this response
            model: The LLM model used
            detect_pii: Whether to detect and redact PII
            detect_harmful: Whether to detect harmful content

        Returns:
            Filtered response with detection results
        """
        payload = {
            "response": response,
            "original_prompt": original_prompt,
            "context": {"model": model},
            "options": {
                "detect_pii": detect_pii,
                "detect_harmful": detect_harmful,
            },
        }

        result = self._make_request("POST", "/v1/llm/filter-response", json=payload)

        # Update conversation history
        self._conversation_history.append({
            "role": "assistant",
            "content": response,
            "filtered": result.get("filtered_response"),
            "timestamp": time.time(),
        })

        return result

    # =========================================================================
    # Advanced Detection Features
    # =========================================================================

    def analyze_semantic_graph(self, prompt: str, depth: int = 3) -> Dict:
        """
        Analyze prompt using Semantic Attack Graph detection

        Builds a graph of rhetorical relationships to detect
        sophisticated multi-step attack patterns.

        Args:
            prompt: The prompt to analyze
            depth: Graph traversal depth (1-5)

        Returns:
            Graph analysis with attack paths and risk scores
        """
        return self._make_request(
            "POST",
            "/v1/llm/analyze/semantic-graph",
            json={"prompt": prompt, "depth": min(max(depth, 1), 5)},
        )

    def detect_perturbations(
        self,
        prompt: str,
        edit_distance_threshold: int = 3
    ) -> Dict:
        """
        Detect adversarial perturbations in text

        Uses BK-Tree indexed pattern matching to find character-level
        manipulations designed to evade detection.

        Args:
            prompt: The prompt to analyze
            edit_distance_threshold: Maximum edit distance for matching

        Returns:
            Perturbation detection results with matches
        """
        return self._make_request(
            "POST",
            "/v1/llm/analyze/perturbations",
            json={
                "prompt": prompt,
                "threshold": edit_distance_threshold
            },
        )

    def detect_cross_modal_injection(
        self,
        content: Union[str, bytes],
        content_type: str = "text",
        check_hidden_text: bool = True,
        check_steganography: bool = True,
    ) -> Dict:
        """
        Detect cross-modal injection attacks

        Analyzes content for hidden instructions in different modalities
        (images, HTML, JSON, markdown, etc.)

        Args:
            content: The content to analyze (text or base64-encoded binary)
            content_type: Content type (text, html, json, markdown, image)
            check_hidden_text: Look for hidden text injection
            check_steganography: Check for steganographic content

        Returns:
            Cross-modal detection results
        """
        payload = {
            "content": content if isinstance(content, str) else content.decode('latin-1'),
            "content_type": content_type,
            "options": {
                "check_hidden_text": check_hidden_text,
                "check_steganography": check_steganography,
            },
        }
        return self._make_request("POST", "/v1/llm/analyze/cross-modal", json=payload)

    # =========================================================================
    # Conversation Analysis (Temporal Detection)
    # =========================================================================

    def analyze_conversation(
        self,
        messages: Optional[List[Dict[str, str]]] = None,
        strict_mode: bool = False,
        detect_escalation: bool = True,
    ) -> ConversationAnalysis:
        """
        Analyze conversation for multi-turn attack sequences

        Uses temporal attack sequence detection to identify
        gradual manipulation and privilege escalation patterns.

        Args:
            messages: List of conversation messages (uses session history if None)
            strict_mode: Whether to use strict analysis
            detect_escalation: Look for escalation patterns

        Returns:
            ConversationAnalysis with sequence detection results
        """
        # Use provided messages or session history
        msgs = messages or [
            {"role": m["role"], "content": m["content"]}
            for m in self._conversation_history
        ]

        response = self._make_request(
            "POST",
            "/v1/llm/analyze-conversation",
            json={
                "messages": msgs,
                "strict_mode": strict_mode,
                "options": {"detect_escalation": detect_escalation},
            },
        )

        return ConversationAnalysis(
            is_attack_sequence=response.get("is_attack_sequence", False),
            sequence_type=response.get("sequence_type"),
            escalation_detected=response.get("escalation_detected", False),
            confidence=response.get("confidence", 0.0),
            turn_analysis=response.get("turn_analysis", []),
            attack_path=response.get("attack_path"),
        )

    def start_session(self, session_id: Optional[str] = None) -> str:
        """
        Start a new conversation session for temporal tracking

        Args:
            session_id: Optional session ID (auto-generated if not provided)

        Returns:
            Session ID
        """
        self.session_id = session_id or hashlib.sha256(
            f"{time.time()}{self.api_key}".encode()
        ).hexdigest()[:16]
        self._conversation_history = []
        return self.session_id

    def end_session(self) -> Dict:
        """
        End the current session and get final analysis

        Returns:
            Session summary with threat analysis
        """
        analysis = self.analyze_conversation()
        summary = {
            "session_id": self.session_id,
            "total_turns": len(self._conversation_history),
            "analysis": asdict(analysis),
        }
        self._conversation_history = []
        self.session_id = None
        return summary

    # =========================================================================
    # Threat Intelligence
    # =========================================================================

    def get_threat_fingerprint(self, prompt: str) -> ThreatFingerprint:
        """
        Get threat actor fingerprint for an attack

        Uses behavioral fingerprinting to attribute attacks
        to known threat actors or campaigns.

        Args:
            prompt: The prompt to fingerprint

        Returns:
            ThreatFingerprint with attribution data
        """
        response = self._make_request(
            "POST",
            "/v1/llm/threat-intelligence/fingerprint",
            json={"prompt": prompt},
        )

        return ThreatFingerprint(
            fingerprint_id=response.get("fingerprint_id", ""),
            campaign_id=response.get("campaign_id"),
            tool_detected=response.get("tool_detected"),
            similarity_score=response.get("similarity_score", 0.0),
            known_actor=response.get("known_actor"),
            ttps=response.get("ttps", []),
        )

    def match_attack_tool(self, prompt: str) -> Dict:
        """
        Match prompt against known attack tool signatures

        Uses fuzzy hashing and pattern matching to identify
        prompts generated by known attack tools.

        Args:
            prompt: The prompt to analyze

        Returns:
            Tool matching results with confidence scores
        """
        return self._make_request(
            "POST",
            "/v1/llm/threat-intelligence/tool-match",
            json={"prompt": prompt},
        )

    # =========================================================================
    # Explainability
    # =========================================================================

    def get_explanation(self, prompt: str, detection_id: Optional[str] = None) -> Dict:
        """
        Get counterfactual explanation for a detection

        Explains why a prompt was flagged by showing what
        minimal changes would make it safe.

        Args:
            prompt: The prompt to explain
            detection_id: Optional detection ID for cached results

        Returns:
            Counterfactual explanation with suggestions
        """
        return self._make_request(
            "POST",
            "/v1/llm/explain/counterfactual",
            json={"prompt": prompt, "detection_id": detection_id},
        )

    def get_attribution(self, prompt: str) -> Dict:
        """
        Get SHAP-based feature attribution for threat scores

        Shows which tokens/phrases contributed most to the
        detection decision.

        Args:
            prompt: The prompt to analyze

        Returns:
            Feature attribution with token-level contributions
        """
        return self._make_request(
            "POST",
            "/v1/llm/explain/attribution",
            json={"prompt": prompt},
        )

    def get_formal_guarantee(self, prompt: str, confidence: float = 0.95) -> Dict:
        """
        Get formal detection guarantees

        Provides statistically rigorous bounds on detection
        accuracy using conformal prediction.

        Args:
            prompt: The prompt to analyze
            confidence: Confidence level for bounds (0.0-1.0)

        Returns:
            Formal guarantees with confidence intervals
        """
        return self._make_request(
            "POST",
            "/v1/llm/explain/formal-guarantee",
            json={"prompt": prompt, "confidence": confidence},
        )

    # =========================================================================
    # Feedback and Learning
    # =========================================================================

    def provide_feedback(
        self,
        prompt: str,
        is_threat: bool,
        threat_type: Optional[str] = None,
        detection_id: Optional[str] = None,
    ) -> Dict:
        """
        Provide feedback on a detection to improve the model

        Contributes to online contrastive learning and
        meta-learning modules.

        Args:
            prompt: The prompt that was analyzed
            is_threat: Whether it was actually a threat
            threat_type: Optional threat type classification
            detection_id: Optional detection ID

        Returns:
            Feedback acknowledgment
        """
        return self._make_request(
            "POST",
            "/v1/llm/feedback",
            json={
                "prompt": prompt,
                "is_threat": is_threat,
                "threat_type": threat_type,
                "detection_id": detection_id,
                "user_id": self.user_id,
            },
        )

    def report_attack(
        self,
        prompt: str,
        attack_type: str,
        severity: ThreatLevel = ThreatLevel.HIGH,
        description: Optional[str] = None,
    ) -> Dict:
        """
        Report a new attack pattern

        Adds to the threat intelligence database for
        improved detection.

        Args:
            prompt: The attack prompt
            attack_type: Type of attack
            severity: Attack severity level
            description: Optional description

        Returns:
            Report acknowledgment with tracking ID
        """
        return self._make_request(
            "POST",
            "/v1/llm/threat-intelligence/report",
            json={
                "prompt": prompt,
                "attack_type": attack_type,
                "severity": severity.value,
                "description": description,
            },
        )

    # =========================================================================
    # Statistics and Compliance
    # =========================================================================

    def get_statistics(self, days: int = 7) -> Dict:
        """
        Get threat detection statistics

        Args:
            days: Number of days to look back

        Returns:
            Statistics dictionary
        """
        return self._make_request("GET", f"/v1/llm/statistics?days={days}")

    def get_model_profiles(self) -> Dict:
        """
        Get available model security profiles

        Returns:
            Dictionary of model profiles with risk assessments
        """
        return self._make_request("GET", "/v1/llm/model-profiles")

    def get_compliance_report(
        self,
        framework: str = "GDPR",
        days: int = 30
    ) -> Dict:
        """
        Get compliance report

        Args:
            framework: Compliance framework (GDPR, HIPAA, SOC2, PCI-DSS)
            days: Report period in days

        Returns:
            Compliance report with status and findings
        """
        return self._make_request(
            "GET",
            f"/v1/llm/compliance-report?framework={framework}&days={days}"
        )

    # =========================================================================
    # Convenience Methods
    # =========================================================================

    def is_prompt_safe(
        self,
        prompt: str,
        model: str = "gpt-4",
        threshold: float = 0.5,
    ) -> bool:
        """
        Quick check if a prompt is safe

        Args:
            prompt: The prompt to check
            model: The LLM model being used
            threshold: Threat score threshold

        Returns:
            True if safe, False if threats detected
        """
        result = self.validate_prompt(prompt, model, mode=DetectionMode.FAST)
        return result.safe and result.overall_score < threshold

    def get_threat_score(self, prompt: str, model: str = "gpt-4") -> float:
        """
        Get the threat score for a prompt

        Args:
            prompt: The prompt to analyze
            model: The LLM model being used

        Returns:
            Threat score (0.0 to 1.0)
        """
        result = self.validate_prompt(prompt, model, mode=DetectionMode.FAST)
        return result.overall_score

    def should_block_prompt(
        self,
        prompt: str,
        model: str = "gpt-4",
        threshold: float = 0.7,
    ) -> Tuple[bool, str]:
        """
        Determine if a prompt should be blocked

        Args:
            prompt: The prompt to check
            model: The LLM model being used
            threshold: Risk threshold for blocking

        Returns:
            Tuple of (should_block, reason)
        """
        result = self.validate_prompt(prompt, model, mode=DetectionMode.STANDARD)

        if result.should_block:
            reason = result.recommendations[0] if result.recommendations else "High risk detected"
            return True, reason

        if result.overall_score > threshold:
            return True, f"Risk score {result.overall_score:.2f} exceeds threshold {threshold}"

        return False, "Safe"

    def clean_response(self, response: str) -> str:
        """
        Clean a response by removing PII

        Args:
            response: The response to clean

        Returns:
            Cleaned response with PII redacted
        """
        result = self.filter_response(response)
        return result.get("filtered_response", response)

    def guard(
        self,
        prompt: str,
        model: str = "gpt-4",
        block_threshold: float = 0.7,
        warn_threshold: float = 0.4,
    ) -> Tuple[str, Dict]:
        """
        All-in-one prompt guard with automatic action

        Args:
            prompt: The prompt to check
            model: The LLM model being used
            block_threshold: Threshold for blocking
            warn_threshold: Threshold for warnings

        Returns:
            Tuple of (action, result) where action is "allow"/"warn"/"block"
        """
        result = self.validate_prompt(prompt, model, mode=DetectionMode.STANDARD)

        result_dict = asdict(result)

        if result.should_block or result.overall_score >= block_threshold:
            return "block", result_dict
        elif result.overall_score >= warn_threshold:
            return "warn", result_dict
        else:
            return "allow", result_dict

    # =========================================================================
    # Private Helper Methods
    # =========================================================================

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict] = None
    ) -> Dict:
        """Make API request"""
        url = f"{self.base_url}{endpoint}"

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=json,
                timeout=self.timeout
            )

            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After", 60)
                raise RateLimitError(
                    f"Rate limit exceeded. Retry after {retry_after}s"
                )

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"API request failed: {e}")

    def _parse_detection_result(self, response: Dict) -> DetectionResult:
        """Parse API response into DetectionResult"""
        detections = []

        for det_type, det_data in response.get("detections", {}).items():
            if isinstance(det_data, dict):
                detections.append(ThreatDetection(
                    type=det_type,
                    score=det_data.get("score", 0.0),
                    confidence=det_data.get("confidence", 0.0),
                    description=det_data.get("description", ""),
                    evidence=det_data.get("evidence", []),
                    mitigation=det_data.get("mitigation"),
                ))

        threat_level_str = response.get("threat_level", "none").lower()
        try:
            threat_level = ThreatLevel(threat_level_str)
        except ValueError:
            threat_level = ThreatLevel.NONE

        return DetectionResult(
            is_threat=response.get("is_threat", False),
            threat_level=threat_level,
            overall_score=response.get("overall_score", 0.0),
            detections=detections,
            safe=response.get("safe", True),
            should_block=response.get("should_block", False),
            recommendations=response.get("recommendations", []),
            explanation=response.get("explanation"),
            attribution=response.get("attribution"),
            formal_guarantee=response.get("formal_guarantee"),
            processing_time_ms=response.get("processing_time_ms", 0.0),
        )

    def _get_cache_key(self, *args) -> str:
        """Generate cache key"""
        data = json.dumps(args, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()

    def _get_cached(self, key: str) -> Optional[DetectionResult]:
        """Get cached value"""
        if key in self._cache:
            cached_time, value = self._cache[key]
            if time.time() - cached_time < self._cache_ttl:
                return value
            else:
                del self._cache[key]
        return None

    def _set_cache(self, key: str, value: DetectionResult):
        """Set cache value"""
        self._cache[key] = (time.time(), value)


class ThreatDetector:
    """High-level threat detection interface"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def scan(
        self,
        prompt: str,
        deep: bool = False,
        **kwargs
    ) -> Dict:
        """
        Scan a prompt for all threat types

        Args:
            prompt: The prompt to scan
            deep: Use deep analysis mode
            **kwargs: Additional options for validate_prompt

        Returns:
            Comprehensive scan results
        """
        mode = DetectionMode.DEEP if deep else DetectionMode.STANDARD
        result = self.client.validate_prompt(
            prompt,
            mode=mode,
            include_explanation=deep,
            include_attribution=deep,
            **kwargs
        )

        return {
            "safe": result.safe,
            "risk_level": result.threat_level.value,
            "score": result.overall_score,
            "threats": [asdict(d) for d in result.detections],
            "recommendations": result.recommendations,
            "explanation": result.explanation,
            "attribution": result.attribution,
            "should_block": result.should_block,
        }

    def scan_batch(
        self,
        prompts: List[str],
        parallel: bool = True,
        **kwargs
    ) -> List[Dict]:
        """
        Scan multiple prompts

        Args:
            prompts: List of prompts to scan
            parallel: Whether to scan in parallel (future)
            **kwargs: Additional options

        Returns:
            List of scan results
        """
        return [self.scan(prompt, **kwargs) for prompt in prompts]

    def quick_check(self, prompt: str) -> bool:
        """
        Quick safety check (fast mode)

        Args:
            prompt: The prompt to check

        Returns:
            True if safe, False if potentially dangerous
        """
        return self.client.is_prompt_safe(prompt)


class ComplianceManager:
    """Compliance reporting and management"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def get_gdpr_report(self, days: int = 30) -> Dict:
        """Get GDPR compliance report"""
        return self.client.get_compliance_report("GDPR", days)

    def get_hipaa_report(self, days: int = 30) -> Dict:
        """Get HIPAA compliance report"""
        return self.client.get_compliance_report("HIPAA", days)

    def get_soc2_report(self, days: int = 30) -> Dict:
        """Get SOC2 compliance report"""
        return self.client.get_compliance_report("SOC2", days)

    def get_pci_dss_report(self, days: int = 30) -> Dict:
        """Get PCI-DSS compliance report"""
        return self.client.get_compliance_report("PCI-DSS", days)

    def check_compliance_status(self, framework: str = "GDPR") -> bool:
        """Check if currently compliant"""
        report = self.client.get_compliance_report(framework, 1)
        return report.get("status") == "compliant"

    def get_all_reports(self, days: int = 30) -> Dict[str, Dict]:
        """Get all compliance reports"""
        return {
            "GDPR": self.get_gdpr_report(days),
            "HIPAA": self.get_hipaa_report(days),
            "SOC2": self.get_soc2_report(days),
            "PCI-DSS": self.get_pci_dss_report(days),
        }


class ThreatIntelligence:
    """Threat intelligence and analysis"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def fingerprint(self, prompt: str) -> ThreatFingerprint:
        """Get threat actor fingerprint"""
        return self.client.get_threat_fingerprint(prompt)

    def match_tool(self, prompt: str) -> Dict:
        """Match against known attack tools"""
        return self.client.match_attack_tool(prompt)

    def analyze_campaign(self, prompts: List[str]) -> Dict:
        """
        Analyze multiple prompts for campaign attribution

        Args:
            prompts: List of prompts to analyze

        Returns:
            Campaign analysis results
        """
        fingerprints = [self.fingerprint(p) for p in prompts]

        # Group by campaign
        campaigns: Dict[str, List] = {}
        for fp in fingerprints:
            if fp.campaign_id:
                if fp.campaign_id not in campaigns:
                    campaigns[fp.campaign_id] = []
                campaigns[fp.campaign_id].append(asdict(fp))

        return {
            "fingerprints": [asdict(fp) for fp in fingerprints],
            "campaigns": campaigns,
            "unique_actors": list(set(fp.known_actor for fp in fingerprints if fp.known_actor)),
            "tools_detected": list(set(fp.tool_detected for fp in fingerprints if fp.tool_detected)),
        }


class Explainer:
    """Explainability features for threat detection"""

    def __init__(self, client: LLMGuardClient):
        """Initialize with LLM Guard client"""
        self.client = client

    def explain(self, prompt: str) -> Dict:
        """Get counterfactual explanation"""
        return self.client.get_explanation(prompt)

    def attribute(self, prompt: str) -> Dict:
        """Get SHAP-based feature attribution"""
        return self.client.get_attribution(prompt)

    def certify(self, prompt: str, confidence: float = 0.95) -> Dict:
        """Get formal detection guarantee"""
        return self.client.get_formal_guarantee(prompt, confidence)

    def full_analysis(self, prompt: str) -> Dict:
        """
        Get complete explainability analysis

        Args:
            prompt: The prompt to analyze

        Returns:
            Combined explanation, attribution, and guarantee
        """
        return {
            "explanation": self.explain(prompt),
            "attribution": self.attribute(prompt),
            "guarantee": self.certify(prompt),
        }


# Exceptions
class LLMGuardError(Exception):
    """Base exception for LLM Guard errors"""


class APIError(LLMGuardError):
    """API request error"""


class RateLimitError(LLMGuardError):
    """Rate limit exceeded error"""


class ValidationError(LLMGuardError):
    """Validation error"""


class SessionError(LLMGuardError):
    """Session management error"""


# Convenience function for quick usage
def guard_prompt(
    api_key: str,
    prompt: str,
    model: str = "gpt-4",
    strict: bool = False,
) -> Tuple[bool, Dict]:
    """
    Quick function to check if a prompt is safe

    Args:
        api_key: SafeKeyLab API key
        prompt: The prompt to check
        model: LLM model being used
        strict: Use strict mode

    Returns:
        Tuple of (is_safe, details)
    """
    client = LLMGuardClient(api_key)
    result = client.validate_prompt(prompt, model, strict_mode=strict)
    return result.safe, asdict(result)
