Avlos Specification Format
**************************
