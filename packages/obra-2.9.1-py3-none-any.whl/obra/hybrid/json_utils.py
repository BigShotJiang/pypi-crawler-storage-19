"""Utilities for extracting JSON payloads from LLM responses."""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.llm.cli_runner import invoke_llm_via_cli

EXTRACTION_PROMPT_TEMPLATE = """Extract plan items from this text as a JSON array.
Each item needs: id, title, description, acceptance_criteria (array), dependencies (array).
If the text contains no clear plan items, return an empty array [].
If items are numbered (1, 2, 3), use T1, T2, T3 as IDs.
Return ONLY valid JSON, no explanation or markdown.

Text to extract from:
---
{raw_response}
---

JSON array:
"""

logger = logging.getLogger(__name__)


def unwrap_claude_cli_json(data: dict[str, Any]) -> tuple[Any, bool]:
    """Unwrap Claude CLI JSON wrapper format.

    When Claude CLI is invoked with --output-format json, it returns a wrapper:
    {"type": "result", "result": "...", ...}

    This function extracts the actual LLM response from the "result" field.

    Args:
        data: Parsed JSON data that may be a Claude CLI wrapper

    Returns:
        Tuple of (unwrapped_data, was_wrapped) where:
        - unwrapped_data: The actual LLM response (parsed if JSON, or string)
        - was_wrapped: True if data was a Claude CLI wrapper

    ISSUE-SAAS-030: Fixes derivation returning empty plan items because
    the wrapper JSON was being treated as the plan instead of its result field.
    """
    if not isinstance(data, dict):
        return data, False

    # Check for Claude CLI wrapper signature
    if data.get("type") == "result" and "result" in data:
        result_content = data["result"]

        if isinstance(result_content, str):
            result_content = result_content.strip()
            # Remove markdown code blocks if present
            if result_content.startswith("```"):
                lines = result_content.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                result_content = "\n".join(lines[start:end])
            # Try to parse as JSON
            try:
                return json.loads(result_content), True
            except json.JSONDecodeError:
                # Return as-is if not valid JSON
                return result_content, True

        elif isinstance(result_content, (dict, list)):
            return result_content, True

    return data, False


def unwrap_gemini_cli_json(data: dict[str, Any]) -> tuple[Any, bool]:
    """Unwrap Gemini CLI JSON wrapper format.

    When Gemini CLI is invoked with --output-format json, it returns a wrapper:
    {"response": "...", "stats": {...}}

    This function extracts the actual LLM response from the "response" field.

    Args:
        data: Parsed JSON data that may be a Gemini CLI wrapper

    Returns:
        Tuple of (unwrapped_data, was_wrapped) where:
        - unwrapped_data: The actual LLM response (parsed if JSON, or string)
        - was_wrapped: True if data was a Gemini CLI wrapper

    FIX-GEMINI-UNWRAP-001: Adds Gemini-specific unwrapper to fix "Untitled"
    metadata in plan items when using Gemini CLI provider.
    """
    if not isinstance(data, dict):
        return data, False

    # Check for Gemini CLI wrapper signature: has "response" and "stats" keys
    if "response" in data and "stats" in data:
        response_content = data["response"]

        if isinstance(response_content, str):
            response_content = response_content.strip()
            # Remove markdown code blocks if present
            if response_content.startswith("```"):
                lines = response_content.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response_content = "\n".join(lines[start:end])
            # Try to parse as JSON (for structured prompts)
            try:
                return json.loads(response_content), True
            except json.JSONDecodeError:
                # Return as-is if not valid JSON
                return response_content, True

        elif isinstance(response_content, (dict, list)):
            return response_content, True

    return data, False


def extract_json_payload(text: str) -> str | None:
    """Extract a JSON object/array from a mixed response.

    Returns the first plausible JSON payload as a string, or None if not found.
    """
    trimmed = text.strip()
    if not trimmed:
        return None

    code_block = re.search(r"```(?:json)?\s*(.*?)```", trimmed, re.DOTALL)
    if code_block:
        candidate = code_block.group(1).strip()
        if candidate:
            return candidate

    for opener, closer in (("{", "}"), ("[", "]")):
        start = trimmed.find(opener)
        end = trimmed.rfind(closer)
        if start != -1 and end != -1 and end > start:
            return trimmed[start : end + 1].strip()

    return None


def _build_extraction_prompt(raw_response: str) -> str:
    """Build extraction prompt for LLM-based plan structure recovery."""
    return EXTRACTION_PROMPT_TEMPLATE.format(raw_response=raw_response.strip())


def is_garbage_response(text: str) -> bool:
    """Detect clearly unusable responses (errors, rate limits, gibberish)."""
    cleaned = text.strip()
    if not cleaned:
        return True

    lowered = cleaned.lower()
    error_markers = (
        "rate limit",
        "ratelimit",
        "too many requests",
        "exceeded your current quota",
        "quota exceeded",
        "please try again later",
        "invalid api key",
        "missing api key",
        "unauthorized",
        "forbidden",
        "temporarily unavailable",
        "error code",
        "http 429",
        "http 500",
    )
    if any(marker in lowered for marker in error_markers):
        return True

    compact = "".join(ch for ch in cleaned if not ch.isspace())
    if compact and " " not in cleaned and len(compact) > 48:
        return True

    non_word_ratio = sum(1 for ch in compact if not ch.isalnum()) / max(len(compact), 1)
    if non_word_ratio > 0.45 and len(compact) >= 12:
        return True

    alpha_ratio = sum(1 for ch in compact if ch.isalpha()) / max(len(compact), 1)
    return alpha_ratio < 0.2 and len(compact) >= 12


def _parse_extraction_response(response_text: str) -> list[dict[str, Any]] | None:
    """Parse extraction LLM response into plan item dictionaries."""
    try:
        parsed: Any = json.loads(response_text)
    except json.JSONDecodeError:
        payload = extract_json_payload(response_text)
        if not payload:
            return None
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError:
            return None

    if isinstance(parsed, dict):
        parsed, _ = unwrap_claude_cli_json(parsed)
        parsed, _ = unwrap_gemini_cli_json(parsed)

    if isinstance(parsed, str):
        try:
            parsed = json.loads(parsed)
        except json.JSONDecodeError:
            return None

    if not isinstance(parsed, list):
        return None

    items: list[dict[str, Any]] = []
    for item in parsed:
        if isinstance(item, dict):
            items.append(item)
        else:
            return None
    return items


def llm_extract_structure(
    raw_response: str,
    *,
    working_dir: Path,
    log_event: Callable[..., None] | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> tuple[list[dict[str, Any]] | None, bool]:
    """Extract structured plan items from a natural language response using an LLM."""
    if is_garbage_response(raw_response):
        return None, False

    normalized = raw_response.strip()
    prompt = _build_extraction_prompt(normalized)
    tier_config = resolve_tier_config("fast")

    try:
        response_text = invoke_llm_via_cli(
            prompt=prompt,
            cwd=working_dir,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
            log_event=log_event,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            call_site="llm_extract_structure",
        )
    except Exception as exc:
        logger.warning("LLM extraction failed: %s", exc)
        return None, False

    extracted_items = _parse_extraction_response(response_text)
    return extracted_items, extracted_items is not None
