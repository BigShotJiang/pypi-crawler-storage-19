from __future__ import annotations

from .registry import ExportRegistry
from pydantic import BaseModel, Field, ValidationError, ConfigDict, TypeAdapter, field_validator, model_validator
from .exports import ToolExport, AgentExport, FlowExport, HttpHandlerExport, McpServerExport
from .decorators import tool, agent, flow, flow_graph
from .http_api import http
from .mcp import mcp_server, CaeMcpServer

# LangGraph contract surface (local shim)
from .langgraph_shim import (
    StateGraph,
    START,
    END,
    InMemorySaver,
    tools_condition,
    ToolNode,
    MessagesState,
)

# LangChain contract surface (local shim)
from .langchain_shim import ChatPromptTemplate, PromptTemplate, Runnable, RunnableConfig

__all__ = [
    # registry and exports
    "ExportRegistry",
    "ToolExport", "AgentExport", "FlowExport", "HttpHandlerExport", "McpServerExport",
    # decorators
    "tool", "agent", "flow", "flow_graph",
    # http + mcp
    "http", "mcp_server", "CaeMcpServer",
    # langgraph surface
    "StateGraph", "START", "END", "InMemorySaver", "tools_condition", "ToolNode", "MessagesState",
    # langchain surface
    "ChatPromptTemplate", "PromptTemplate", "Runnable", "RunnableConfig",
    # pydantic surface
    "BaseModel", "Field","ValidationError", "ConfigDict","TypeAdapter", "field_validator", "model_validator"
]
