"""AirOps Python SDK for building custom tools.

Example:
    from pydantic import BaseModel, Field
    from airops import Tool, steps

    class Inputs(BaseModel):
        url: str = Field(..., description="URL to analyze")

    class Outputs(BaseModel):
        results: list[dict]

    tool = Tool(
        name="my_tool",
        description="Search for a URL",
        input_model=Inputs,
        output_model=Outputs,
    )

    @tool.handler
    def run(inputs: Inputs) -> Outputs:
        serp = steps.execute("google_search", {"query": f"site:{inputs.url}"})
        return Outputs(results=serp["results"])

    if __name__ == "__main__":
        tool.serve()
"""

from airops import secrets, steps
from airops._version import __version__
from airops.tool import Tool

__all__ = [
    "__version__",
    "Tool",
    "steps",
    "secrets",
]
