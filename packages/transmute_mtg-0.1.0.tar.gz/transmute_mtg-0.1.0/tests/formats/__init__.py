"""Tests for format handlers."""
