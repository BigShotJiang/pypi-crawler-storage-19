"""Tests for transmute."""
