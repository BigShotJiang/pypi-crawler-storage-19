"""Core Ralph logic."""
