
from __future__ import annotations
from typing import TypeAlias, Union, Any
from copy import deepcopy

def _to_str(num: Any) -> str:
    return str(num)

unknown: TypeAlias = str
lambda_json: TypeAlias = Union[unknown, dict[
    str,
    list[Union[list[str], 'Lambda', 'lambda_json']]
]]

def is_unknown(num: Any) -> bool:
    return isinstance(num, unknown)

class Lambda:
    def __init__(self, json: Any) -> None:
        self._num: lambda_json = self._replace(json)

    def _replace(self, json: Any) -> lambda_json:
        if is_unknown(json):
            return json
        elif isinstance(json, dict):
            json = deepcopy(json)
            key, value = next(iter(json.items()))
            if key == 'lambda':
                json['lambda'][1] = self._replace(value[1])
                return json
            elif key == 'execute':
                for i in range(len(value)):
                    value[i] = self._replace(value[i])
                json['execute'] = value
                return json
            else:
                raise NameError(f'Unknown key: {key}')
        elif isinstance(json, Lambda):
            return json._num
        else:
            raise TypeError(f'Bad json: {json}')

    def _parse(self, arg: list[lambda_json]) -> Lambda:
        length: int = len(arg)
        other = self.__copy__()
        if is_unknown(other._num):
            return other.__copy__()
        args: list[str] = other._num['lambda'][0]  # type: ignore[index]
        assert length == len(args), f'{length} != {len(args)}'
        for i in range(len(arg)):
            argi = arg[i] if is_unknown(arg[i]) else arg[i]
            other._num = self._become(other._num, argi, args[i])  # type: ignore[assignment]
        return other

    def _become(self, json: lambda_json, num: lambda_json, un: str) -> lambda_json:
        if is_unknown(json):
            return num if json == un else json
        elif isinstance(json, dict):
            json = deepcopy(json)
            key, value = next(iter(json.items()))
            if key == 'lambda':
                if un in value[0]:  # type: ignore[operator]
                    return json
                nums = self._become(value[1], num, un)  # type: ignore[arg-type]
                value[1] = nums
                return json
            elif key == 'execute':
                for i in range(len(value)):
                    value[i] = self._become(value[i], num, un)  # type: ignore[arg-type]
                return json
            else:
                raise NameError(f'Unknown key: {key}')
        else:
            raise TypeError(f'Bad json: {json}')

    def _beta(self, json: lambda_json) -> lambda_json:
        if is_unknown(json):
            return json
        elif isinstance(json, dict):
            new_json = deepcopy(json)
            key, value = next(iter(new_json.items()))
            if key == 'lambda':
                new_body = self._beta(value[1])  # type: ignore[arg-type]
                new_json[key][1] = new_body
                return new_json
            elif key == 'execute':
                temp: lambda_json = value[0]  # type: ignore[index]
                if is_unknown(temp):
                    return json
                func: lambda_json = self._beta(temp)
                assert isinstance(func, dict) and 'lambda' in func, f'Unknown lambda: {func}'
                func_args = func['lambda'][0]
                func_body = func['lambda'][1]
                args = value[1:]
                # assert len(args) == len(func_args), f'Can\'t match args: {len(args)} != {len(func_args)}'
                new_body = func_body
                new_args: list[str] = func_args[len(args):]  # type: ignore[slice]
                for arg_name, arg_value in zip(func_args, args):  # type: ignore[arg-type]
                    reduced_arg = self._beta(arg_value)  # type: ignore[arg-type]
                    new_body = self._become(new_body, reduced_arg, arg_name)  # type: ignore[arg-type]
                return self._beta(new_body) if len(args) == len(func_args) else {'lambda': [new_args, new_body]}  # type: ignore[return-value]
            else:
                raise NameError(f'Unknown key: {key}')
        else:
            raise TypeError(f'Bad json: {json}')

    def _getstr(self, num: lambda_json, symbol: str, end: str, sep: str) -> str:
        assert isinstance(symbol, str), f'Unknown symbol: {symbol}'
        assert isinstance(end, str), f'Unknown end: {end}'
        assert isinstance(sep, str), f'Unknown sep: {sep}'
        if is_unknown(num):
            return num # pyright: ignore[reportReturnType]
        elif isinstance(num, dict):
            key, value = next(iter(num.items()))
            if key == 'lambda':
                str_list: list[str] = []
                for i in value[0]:  # type: ignore[iterable]
                    str_list.append(f'{symbol.format(i)}.')
                body_str = self._getstr(value[1], symbol, end, sep)  # type: ignore[arg-type]
                return end.format(''.join(str_list), body_str)
            elif key == 'execute':
                for i in range(len(value)):
                    value[i] = self._getstr(value[i], symbol, end, sep) # pyright: ignore[reportArgumentType]
                execute_str = sep.join(map(_to_str, value)) # pyright: ignore[reportArgumentType]
                return f'({execute_str})'
            else:
                raise NameError(f'Unknown key: {key}')
        else:
            raise TypeError(f'Unknown type: {type(num)}, num: {num}')

    def __repr__(self) -> str:
        return str(self._num)

    def __str__(self) -> str:
        return self.getstr()

    def __copy__(self) -> Lambda:
        return Lambda(deepcopy(self._num))

    def __eq__(self, value: object) -> bool:
        return (isinstance(value, Lambda) and self._num == value._num) or (isinstance(value, dict) and self._num == value)

    def beta(self) -> Lambda:
        return Lambda(self._beta(self._num))

    def getstr(self, symbol: str = 'lambda {0}', end: str = '{0}{1}', sep: str = ' ') -> str:
        return self._getstr(self._num, symbol, end, sep)

    @property
    def num(self) -> lambda_json:
        return self._num

L: str = 'lambda'
E: str = 'execute'

lam_true: Lambda = Lambda({L: [['x', 'y'], 'x']})
lam_false: Lambda = Lambda({L: [['x', 'y'], 'y']})
lam_and: Lambda = Lambda({L: [['x', 'y'], {E: ['x', 'y', lam_false]}]})
lam_or: Lambda = Lambda({L: [['x', 'y'], {E: ['x', lam_true, 'y']}]})
lam_not: Lambda = Lambda({L: [['x'], {E: ['x', lam_false, lam_true]}]})

def beta(num: Lambda) -> Lambda:
    assert isinstance(num, Lambda), f'Unknown num: {num}'
    return num.beta()

def main() -> None:
    lambda_inst: Lambda = Lambda({'execute': [lam_and, {'execute': [lam_and, lam_false, lam_true]}]})
    beta_result: Lambda = beta(lambda_inst)
    print(beta_result.getstr(symbol='λ{0}'))

if __name__ == '__main__':
    main()
