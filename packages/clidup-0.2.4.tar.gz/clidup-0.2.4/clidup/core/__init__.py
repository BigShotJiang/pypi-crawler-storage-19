"""Core functionality module"""
