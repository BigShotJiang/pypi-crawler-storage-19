# Sykora

Terminal-based CLI chatbot for Hack Club AI endpoint.

## Installation

```bash
pip install sykora
```

## Usage

### Interactive Mode

```bash
sykora --token sk-hc-v1-your-token-here
```

### Single Message Mode

```bash
sykora --token sk-hc-v1-your-token-here "Hello, how are you?"
```

### Using Environment Variable

```bash
export HACK_CLUB_TOKEN=sk-hc-v1-your-token-here
sykora
```

## Requirements

- Python 3.7+
- Hack Club AI token
