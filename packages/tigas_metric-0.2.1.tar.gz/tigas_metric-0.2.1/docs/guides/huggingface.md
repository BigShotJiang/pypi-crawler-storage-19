# Интеграция с HuggingFace Hub

## Обзор

TIGAS интегрирован с HuggingFace Hub для автоматической загрузки предобученных моделей. Репозиторий: [H1merka/TIGAS](https://huggingface.co/H1merka/TIGAS)

### Текущая модель на Hub

| Параметр | Значение |
|----------|----------|
| Режим | Full Mode (`fast_mode=False`) |
| Эпох обучения | 15 |
| Val Accuracy | 71.03% |
| Val Loss | 0.216 |
| Параметры | ~18.9M |

> **Важно:** Модель на HuggingFace Hub обучена в режиме **Full Mode** (`fast_mode=False`). 
> При автозагрузке с `fast_mode=True` (по умолчанию) загрузятся только совместимые веса,
> а специфичные для fast_mode слои останутся случайно инициализированными.
> Для получения полной точности используйте модель с `fast_mode=False`.

---

## Автоматическая загрузка модели

### Базовое использование

```python
from tigas import TIGAS

# Автоматически скачает модель из HuggingFace Hub
# По умолчанию fast_mode=True, но модель обучена в full_mode
tigas = TIGAS(auto_download=True)

# Для полной точности (рекомендуется):
# tigas = TIGAS(auto_download=True, fast_mode=False)

# Или явно через compute_tigas_score
from tigas import compute_tigas_score
score = compute_tigas_score('image.jpg', auto_download=True)
```

### Кэширование

Модели кэшируются локально в:
```
~/.cache/tigas/models/best_model.pt
```

При повторных запусках модель загружается из кэша.

---

## Программный доступ к Hub

### Модуль model_hub

**Расположение:** [tigas/model_hub.py](../tigas/model_hub.py)

```python
from tigas.model_hub import (
    get_default_model_path,
    download_default_model,
    check_model_in_cache,
    clear_cache,
    cache_info,
    DEFAULT_MODEL_REPO
)

# Константа с именем репозитория
print(DEFAULT_MODEL_REPO)  # "H1merka/TIGAS"

# Путь к кэшированной модели
model_path = get_default_model_path()
# ~/.cache/tigas/models/best_model.pt

# Скачать/обновить модель
local_path = download_default_model(force_download=False)
```

### Функции

#### `download_default_model(force_download=False, show_progress=True)`

Загружает модель из HuggingFace Hub.

**Параметры:**
- `force_download` (bool): Перезагрузить даже если файл существует
- `show_progress` (bool): Показывать прогресс загрузки

**Возвращает:**
- `str`: Путь к загруженному файлу

```python
from tigas.model_hub import download_default_model

# Скачать если не существует
path = download_default_model()

# Принудительно обновить
path = download_default_model(force_download=True)
```

#### `get_default_model_path(auto_download=True)`

Возвращает путь к кэшированной модели.

```python
from tigas.model_hub import get_default_model_path

path = get_default_model_path(auto_download=False)
if path:
    print(f"Model cached at: {path}")
else:
    print("Model not downloaded yet")
```

#### `check_model_in_cache(model_filename="best_model.pt")`

Проверяет наличие модели в кэше.

```python
from tigas.model_hub import check_model_in_cache

cached = check_model_in_cache()
if cached:
    print(f"Found: {cached}")
```

#### `clear_cache()`

Очищает кэш моделей.

```python
from tigas.model_hub import clear_cache
clear_cache()
```

#### `cache_info()`

Информация о кэше.

```python
from tigas.model_hub import cache_info
info = cache_info()
print(f"Cache size: {info['total_size_mb']:.2f} MB")
```
```

---

## Публикация собственной модели

### Структура репозитория

```
H1merka/TIGAS/
├── README.md           # Model card
├── config.json         # Конфигурация модели
├── LICENSE            # Лицензия
└── tigas_model.pt     # Веса модели (state_dict)
```

### Подготовка модели к публикации

```python
import torch
from tigas.models import TIGASModel

# Загрузить обученную модель
model = TIGASModel(fast_mode=True)
checkpoint = torch.load('checkpoints/best_model.pt')
model.load_state_dict(checkpoint['model_state_dict'])

# Сохранить только state_dict для публикации
torch.save(model.state_dict(), 'model_publish/tigas_model.pt')
```

### config.json

```json
{
    "model_type": "tigas",
    "version": "1.0.0",
    "architecture": {
        "fast_mode": true,
        "img_size": 256,
        "feature_dim": 256,
        "num_stages": 4,
        "base_channels": 32
    },
    "training": {
        "epochs": 50,
        "batch_size": 16,
        "learning_rate": 1.25e-5,
        "optimizer": "AdamW",
        "scheduler": "CosineAnnealingLR"
    },
    "performance": {
        "accuracy": 0.95,
        "auc_roc": 0.98
    }
}
```

### README.md (Model Card)

```markdown
---
language:
- en
tags:
- image-classification
- deepfake-detection
- pytorch
license: mit
---

# TIGAS - Trained Image Generation Authenticity Score

A differentiable neural metric for detecting AI-generated images.

## Model Description

TIGAS outputs continuous scores [0,1] where:
- 1.0 = Real image
- 0.0 = AI-generated (fake) image

## Usage

\```python
from tigas import TIGAS

tigas = TIGAS(auto_download=True)
score = tigas('image.jpg')
print(f"Authenticity score: {score:.4f}")
\```

## Training Data

- Real images: [Dataset A]
- Fake images: [Generated by models X, Y, Z]

## Performance

| Metric | Value |
|--------|-------|
| Accuracy | 95% |
| AUC-ROC | 0.98 |

## Citation

\```bibtex
@software{tigas2024,
  title={TIGAS: Trained Image Generation Authenticity Score},
  author={...},
  year={2024}
}
\```
```

### Скрипт публикации

**Расположение:** [scripts/publish_to_hf.py](../scripts/publish_to_hf.py)

```python
"""
Публикация модели на HuggingFace Hub.

Использование:
    python scripts/publish_to_hf.py --checkpoint checkpoints/best_model.pt
"""

from huggingface_hub import HfApi, upload_folder
import argparse
import shutil
import os

def publish_model(checkpoint_path, repo_id="H1merka/TIGAS"):
    # Подготовка директории
    publish_dir = "model_publish"
    os.makedirs(publish_dir, exist_ok=True)
    
    # Копирование файлов
    shutil.copy(checkpoint_path, f"{publish_dir}/tigas_model.pt")
    
    # Загрузка на Hub
    api = HfApi()
    api.upload_folder(
        folder_path=publish_dir,
        repo_id=repo_id,
        repo_type="model"
    )
    
    print(f"Model published to: https://huggingface.co/{repo_id}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    args = parser.parse_args()
    publish_model(args.checkpoint)
```

---

## Работа с версиями

### Загрузка конкретной версии

```python
from huggingface_hub import hf_hub_download

# Скачать конкретную ревизию
path = hf_hub_download(
    repo_id="H1merka/TIGAS",
    filename="tigas_model.pt",
    revision="v1.0.0"  # Git tag или commit hash
)
```

### Версионирование моделей

```python
from huggingface_hub import HfApi

api = HfApi()

# Создать новый тег
api.create_tag(
    repo_id="H1merka/TIGAS",
    tag="v1.1.0",
    tag_message="Improved accuracy on StyleGAN images"
)
```

---

## Офлайн режим

### Использование локальной модели

```python
from tigas import TIGAS

# Указать локальный путь вместо auto_download
tigas = TIGAS(checkpoint_path='./local_models/tigas_model.pt')
```

### Проверка наличия модели

```python
from tigas.model_hub import get_model_path

model_path = get_model_path()
if model_path.exists():
    print("Model available offline")
else:
    print("Model needs to be downloaded")
```

### Полностью офлайн окружение

```python
import os

# Отключить интернет-запросы huggingface
os.environ['HF_HUB_OFFLINE'] = '1'

from tigas import TIGAS

# Будет использовать только кэш
tigas = TIGAS(auto_download=True)  # Использует кэш или ошибка
```

---

## Аутентификация

### Для приватных репозиториев

```python
from huggingface_hub import login

# Интерактивный логин
login()

# Или с токеном
login(token="hf_xxxxx")
```

### Через переменные окружения

```bash
export HF_TOKEN=hf_xxxxx
```

```python
from tigas import TIGAS

# Автоматически использует HF_TOKEN
tigas = TIGAS(auto_download=True)
```

---

## Интеграция с CI/CD

### GitHub Actions

```yaml
name: Download Model
on: [push]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      
      - name: Cache HuggingFace models
        uses: actions/cache@v3
        with:
          path: ~/.cache/huggingface
          key: hf-cache-${{ hashFiles('requirements.txt') }}
      
      - name: Install dependencies
        run: pip install -r requirements.txt
      
      - name: Download model
        run: python -c "from tigas.model_hub import download_model; download_model()"
      
      - name: Run tests
        run: pytest tests/
```

### Docker

```dockerfile
FROM python:3.10-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

# Предзагрузка модели при сборке
RUN python -c "from tigas.model_hub import download_model; download_model()"

COPY . .
CMD ["python", "app.py"]
```

---

## Troubleshooting

### Ошибка загрузки

```
huggingface_hub.utils.RepositoryNotFoundError: Repository Not Found
```

**Решение:**
1. Проверить имя репозитория
2. Проверить интернет-соединение
3. Для приватных репозиториев - авторизоваться

### Ошибка кэша

```
OSError: Cannot load model from cache
```

**Решение:**
```python
# Очистить кэш
import shutil
shutil.rmtree("~/.cache/tigas/models/", ignore_errors=True)

# Перезагрузить
from tigas.model_hub import download_model
download_model(force=True)
```

### Несовместимость версий

```
RuntimeError: Error(s) in loading state_dict
```

**Решение:**
1. Обновить пакет TIGAS
2. Загрузить совместимую версию модели
3. Использовать `strict=False` при загрузке (с осторожностью)

```python
model.load_state_dict(state_dict, strict=False)
```
