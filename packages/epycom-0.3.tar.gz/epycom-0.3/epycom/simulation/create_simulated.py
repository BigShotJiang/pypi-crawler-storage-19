# -*- coding: utf-8 -*-
# Copyright (c) St. Anne's University Hospital in Brno. International Clinical
# Research Center, Biomedical Engineering;
# Institute of Scientific Instruments of the CAS, v. v. i., Medical signals -
# Computational neuroscience. All Rights Reserved.
# Distributed under the (new) BSD License. See LICENSE.txt for more info.

"""
Some parts of code are recoded from package Anderson Brito da Silva's pyhfo
package (https://github.com/britodasilva/pyhfo)
"""

# Std imports

# Third pary imports
import numpy as np
from scipy.stats import norm

# Local imports

# ----- Noise types -----


def simulate_pinknoise(N):
    """
    Create a pink noise (1/f) with N points.

    Parameters
    ----------
    N: int
        Number of samples to be returned

    Returns
    -------
    pink_noise_array: numpy array
        1D array of pink noise
    """
    M = N
    # ensure that the N is even
    if N % 2:
        N += 1

    x = np.random.randn(N)  # generate a white noise
    X = np.fft.fft(x)  # FFT

    # prepare a vector for 1/f multiplication
    nPts = int(N / 2 + 1)
    n = range(1, nPts + 1)
    n = np.sqrt(n)

    # multiplicate the left half of the spectrum
    X[range(nPts)] = X[range(nPts)] / n

    # prepare a right half of the spectrum - a copy of the left one
    X[range(nPts, N)] = np.real(X[range(int(N / 2 - 1), 0, -1)]) - \
        1j * np.imag(X[range(int(N / 2 - 1), 0, -1)])

    y = np.fft.ifft(X)  # IFFT

    y = np.real(y)
    # normalising
    y -= np.mean(y)
    y /= np.sqrt(np.mean(y**2))
    # returning size of N
    if M % 2 == 1:
        y = y[:-1]
    return y


def simulate_brownnoise(N):
    """
    Create a brown noise (1/f²) with N points.

    Parameters
    ----------
    N: int
        Number of samples to be returned

    Returns
    -------
    brown_noise_array: numpy array
        1D array of brown noise
    """
    M = N
    # ensure that the N is even
    if N % 2:
        N += 1

    x = np.random.randn(N)  # generate a white noise

    X = np.fft.fft(x)  # FFT

    # prepare a vector for 1/f² multiplication
    nPts = int(N / 2 + 1)
    n = range(1, nPts + 1)

    # multiplicate the left half of the spectrum
    X[range(nPts)] = X[range(nPts)] / n
    # prepare a right half of the spectrum - a copy of the left one
    X[range(nPts, N)] = np.real(X[range(int(N / 2 - 1), 0, -1)]) - \
        1j * np.imag(X[range(int(N / 2 - 1), 0, -1)])

    y = np.fft.ifft(X)  # IFFT

    y = np.real(y)
    # normalising
    y -= np.mean(y)
    y /= np.sqrt(np.mean(y**2))
    # returning size of N
    if M % 2 == 1:
        y = y[:-1]
    return y


# ----- Artifacts -----
def simulate_delta(fs=5000, decay_dur=None):
    """
    Delta function with exponential decay.

    Parameters
    ----------
    fs: int
        Sampling frequency of the signal (default=5000)
    decay_dur: float
        Decay duration before returning to 0 in seconds

    Returns
    -------
    delta: numpy array
        1D numpy array with delta function
    """

    if decay_dur is None:
        decay_dur = np.random.random()

    decay_N = int(fs * decay_dur)
    return_value = 0.001  # This is the value where decay finishes
    decay_factor = np.log(return_value) / -decay_N
    t = np.linspace(0, decay_N, decay_N, endpoint=False)
    decay = np.exp(-t * decay_factor)

    delta = np.concatenate([[0], decay])

    return delta


def simulate_line_noise(fs=5000, freq=50, numcycles=None):
    """
    Line noise artifact.

    Parameters
    ----------
    fs: int
        Sampling frequency of the signal (default=5000)
    freq: float
        Line noise frequency (default=50)
    ncycles: float
        Number of cycles to create

    Returns
    -------
    line_noise: numpy array
        1D numpy array with line noise
    """

    if numcycles is None:
        numcycles = np.random.randint(3, 50)

    dur_samps = int((numcycles / freq) * fs)
    x = np.arange(dur_samps)
    y = np.sin(2 * np.pi * freq * x / fs)

    return y


def simulate_artifact_spike(fs=5000, dur=None):
    """
    Artifact like spike (sharp, not gaussian)

    Parameters
    ----------
    fs: int
        Sampling frequency of the signal (default=5000)
    dur: float
        Duration of the event in seconds

    Returns
    -------
    artifact_spike: numpy array
        1D numpy array with artifact spike
    """

    if dur is None:
        dur = round(np.random.random() / 10, 3)

    N = int(fs * dur)
    if not N % 2:  # Check if the number is odd - we want to have proper spike
        N -= 1
    y = np.zeros(N)
    y[:int(N / 2) + 1] = np.linspace(0, 1, int(N / 2) + 1)
    y[-int(N / 2):] = np.linspace(1, 0, int(N / 2) + 1)[1:]

    return y


# ----- HFO -----
def _wavelet(numcycles, f, fs):
    """
    Create a wavelet

    Parameters
    ----------
    numcycles: int
        Number of cycles (gaussian window)
    f: float
        Central frequency
    fs: float
        Signal sampling rate (default=5000)

    Returns
    -------
    wave: numpy array
        1D numpy array with waveform
    time: numpy array
        1D numpy array with the time vector
    """
    N = int((fs * numcycles) / f)
    time = np.linspace((-numcycles / 2) / float(f),
                       (numcycles / 2) / float(f), N)  # time vector
    std = numcycles / (2 * np.pi * f)  # standard deviation
    wave = np.exp(2 * 1j * np.pi * f * time) * \
        np.exp(-(time**2) / (2 * (std**2)))  # waveform
    return wave, time


def simulate_hfo(fs=5000, freq=None, numcycles=None):
    """
    Create an HFO

    Parameters
    ----------
    fs: float
        Sampling rate of the signal (default=5000)
    freq: float
        Frequency of the artificial HFO (default=None - random frequency
        between 80 nad 600 Hz)
    numcycles: int
        Number of HFO cycles (default=None - cycles between 9 - 14)

    Returns
    -------
    wave: numpy array
        1D numpy array with waveform
    time: numpy array
        1D numpy array with the time vector
    """
    if numcycles is None:
        numcycles = np.random.randint(9, 15)
    if freq is None:
        freq = np.random.randint(60, 600)
    wave, time = _wavelet(numcycles, freq, fs)
    return np.real(wave), time


# ----- Spike -----
def simulate_spike(fs=5000, dur=None):
    """
    Create a simple gausian spike.

    Parameters
    ----------
    fs: float
        Sampling rate (default=5000)
    dur: float
        Spike duration in seconds

    Returns
    -------
    spike numpy array
        1D numpy array with a sipke
    """
    if dur is None:
        dur = round(np.random.random() * 0.5, 2)

    x = np.linspace(-4, 4, int(fs * dur))  # 4 stds
    spike_dist = norm.pdf(x, loc=0, scale=1)  # Create gaussian shape
    # Normalize so that the peak is at 1
    spike = spike_dist * 1 / max(spike_dist)

    return spike

def simulate_ufo_blob(fs, freq, num_cycles, amplitude):
    """
    Produces a symmetric oscillation with smooth onset and offset (blob shape).

    The decision between 'blob' and 'pistol' in the UFO detector is based on
    the sharpness of the onset. This function uses a Gaussian window (wavelet)
    to ensure a gradual increase in amplitude, which results in a 'blob'
    classification.

    Parameters
    ----------
    fs : float
        Sampling frequency [Hz].
    freq : float
        Central frequency of the oscillation [Hz].
    num_cycles : float
        Number of cycles used to define the width of the Gaussian window.
    amplitude : float
        Peak amplitude of the oscillation.

    Returns
    -------
    wave : np.ndarray
        The generated "blob" waveform.
    """
    # Width of the Gaussian window
    std = num_cycles / (2 * np.pi * freq)
    # Time vector for the wavelet centered at 0
    t_wave = np.linspace(-4*std, 4*std, int(fs * 8 * std))
    # Gaussian-modulated sinusoid
    wave = amplitude * np.exp(-(t_wave**2) / (2 * std**2)) * np.cos(2 * np.pi * freq * t_wave)
    return wave


def simulate_ufo_pistol(fs, freq, num_cycles, amplitude):
    """
    Produces an oscillation starting with a sharp deflection (pistol shape).

    Parameters
    ----------
    fs : float
        Sampling frequency [Hz].
    freq : float
        Central frequency of the oscillation [Hz].
    num_cycles : float
        Number of cycles to simulate (determines duration).
    amplitude : float
        Peak amplitude of the oscillation.

    Returns
    -------
    wave : np.ndarray
        The generated "pistol" waveform.
    """
    # Calculate duration based on cycles and frequency
    duration = num_cycles / freq
    t = np.linspace(0, duration, int(fs * duration))

    # 1. Create a decaying envelope (Exponential decay)
    # tau is set so that the signal is significantly decayed by the end of num_cycles
    tau = duration / 4
    envelope = np.exp(-t / tau)

    # 2. Generate the sinusoid starting at its peak (using cosine)
    # This creates the "sharp" onset deflection (high contrast)
    oscillation = amplitude * np.cos(2 * np.pi * freq * t)

    wave = oscillation * envelope

    return wave

# def wavelet_spike(srate = 2000, f=None, numcycles = None):
#    '''
#    Create a wavelet spike.
#
#    Parameters:
#    ----------
#        f = None (Default) - Create a random Spike with central frequency
# between 60-600 Hz.
#        numcycles = None (Default) - Create a random Spike with numcycles
# between 1 - 2.
#
#    Returns:
#    ----------
#        wave - numpy array with waveform.
#        time - numpy array with the time vector.
#    '''
#    if numcycles is None:
#        numcycles = np.random.randint(1,3)
#    if f is None:
#        f = np.random.randint(60,600)
#    wave,time = wavelet(numcycles,f,srate)
#    return -np.real(wave),time

# %% Combinations - just convenience functions
