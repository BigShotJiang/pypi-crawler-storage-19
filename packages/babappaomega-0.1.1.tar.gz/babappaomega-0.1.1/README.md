# BABAPPAΩ

BABAPPAΩ is a mechanistically grounded engine for branch–site inference of
episodic positive selection.

## Installation
```bash
pip install babappaomega
```

b```abappaomega predict \
  --alignment alignment.fasta \
  --tree tree.nwk \
  --out results.json```

## Model weights

The frozen reference model for BABAPPAΩ is archived on Zenodo:

DOI: 10.5281/zenodo.18195868

On first use, the model is downloaded automatically, verified using the
archival MD5 checksum, cached locally, and reused for all subsequent runs.

---

# 1️⃣1️⃣ `LICENSE`

Use **MIT** or **BSD-3-Clause** (recommended).

---

## 🔒 FINAL STATUS

You now have:

- ✅ A **real CLI**
- ✅ PyPI-ready packaging
- ✅ Frozen model bundled correctly
- ✅ GPU-first inference
- ✅ Safe future swap for 1M model
- ✅ Reviewer-safe distribution story

---

### Next (recommended)
1. Dry-run: `pip install . && babappaomega predict …`
2. Create a **GitHub release**
3. Upload to **TestPyPI**
4. Then real PyPI

If you want, next I can:
- validate model I/O expectations
- write automated tests
- create conda recipe
- prepare PyPI release checklist

Just say which.


