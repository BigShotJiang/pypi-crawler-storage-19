"""Cline slash command configurator.

Configures slash commands for Cline in .clinerules/workflows/ directory.
Uses markdown heading format for frontmatter instead of YAML.
"""

from aurora_cli.configurators.slash.base import SlashCommandConfigurator
from aurora_cli.templates.slash_commands import get_command_body

# Descriptions for each command
DESCRIPTIONS: dict[str, str] = {
    "search": "Search indexed code and documentation",
    "get": "Get full chunk content by index",
    "plan": "Generate structured plans with agent delegation",
    "checkpoint": "Save session context for continuity",
    "implement": "Plan-based implementation (placeholder)",
    "archive": "Archive completed plans with spec processing",
}

# File paths for each command
FILE_PATHS: dict[str, str] = {
    "search": ".clinerules/workflows/aurora-search.md",
    "get": ".clinerules/workflows/aurora-get.md",
    "plan": ".clinerules/workflows/aurora-plan.md",
    "checkpoint": ".clinerules/workflows/aurora-checkpoint.md",
    "implement": ".clinerules/workflows/aurora-implement.md",
    "archive": ".clinerules/workflows/aurora-archive.md",
}


class ClineSlashCommandConfigurator(SlashCommandConfigurator):
    """Slash command configurator for Cline.

    Creates slash commands in .clinerules/workflows/ directory for
    all Aurora commands. Uses markdown heading format for frontmatter.
    """

    @property
    def tool_id(self) -> str:
        """Tool identifier."""
        return "cline"

    @property
    def is_available(self) -> bool:
        """Cline is always available (doesn't require detection)."""
        return True

    def get_relative_path(self, command_id: str) -> str:
        """Get relative path for a slash command file.

        Args:
            command_id: Command identifier

        Returns:
            Relative path from project root
        """
        return FILE_PATHS[command_id]

    def get_frontmatter(self, command_id: str) -> str | None:
        """Get frontmatter for a slash command file.

        Uses markdown heading format instead of YAML:
        # Aurora: {Command}

        {description}

        Args:
            command_id: Command identifier

        Returns:
            Markdown heading format frontmatter
        """
        description = DESCRIPTIONS[command_id]
        command_name = command_id.capitalize()
        return f"# Aurora: {command_name}\n\n{description}"

    def get_body(self, command_id: str) -> str:
        """Get body content for a slash command.

        Args:
            command_id: Command identifier

        Returns:
            Command body content from templates
        """
        return get_command_body(command_id)
