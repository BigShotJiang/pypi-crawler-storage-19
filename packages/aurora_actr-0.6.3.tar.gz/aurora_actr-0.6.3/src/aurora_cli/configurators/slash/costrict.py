"""CoStrict slash command configurator.

Configures slash commands for CoStrict AI in .cospec/aurora/commands/ directory.
"""

from aurora_cli.configurators.slash.base import SlashCommandConfigurator
from aurora_cli.templates.slash_commands import get_command_body

# Frontmatter for each command
FRONTMATTER: dict[str, str] = {
    "search": """---
name: Aurora: Search
description: Search indexed code and documentation
argument-hint: search query
category: Aurora
tags: [aurora, search, memory]
---""",
    "get": """---
name: Aurora: Get
description: Get full chunk content by index
argument-hint: chunk index number
category: Aurora
tags: [aurora, search, memory]
---""",
    "plan": """---
name: Aurora: Plan
description: Generate structured plans with agent delegation
argument-hint: request or feature description
category: Aurora
tags: [aurora, planning]
---""",
    "checkpoint": """---
name: Aurora: Checkpoint
description: Save session context for continuity
argument-hint: optional checkpoint name
category: Aurora
tags: [aurora, session, checkpoint]
---""",
    "implement": """---
name: Aurora: Implement
description: Plan-based implementation (placeholder)
argument-hint: plan ID to implement
category: Aurora
tags: [aurora, planning, implementation]
---""",
    "archive": """---
name: Aurora: Archive
description: Archive completed plans with spec processing
argument-hint: plan ID to archive
category: Aurora
tags: [aurora, planning, archive]
---""",
}

# File paths for each command
FILE_PATHS: dict[str, str] = {
    "search": ".cospec/aurora/commands/aurora-search.md",
    "get": ".cospec/aurora/commands/aurora-get.md",
    "plan": ".cospec/aurora/commands/aurora-plan.md",
    "checkpoint": ".cospec/aurora/commands/aurora-checkpoint.md",
    "implement": ".cospec/aurora/commands/aurora-implement.md",
    "archive": ".cospec/aurora/commands/aurora-archive.md",
}


class CostrictSlashCommandConfigurator(SlashCommandConfigurator):
    """Slash command configurator for CoStrict AI.

    Creates slash commands in .cospec/aurora/commands/ directory for
    all Aurora commands.
    """

    @property
    def tool_id(self) -> str:
        """Tool identifier."""
        return "costrict"

    @property
    def is_available(self) -> bool:
        """CoStrict is always available (doesn't require detection)."""
        return True

    def get_relative_path(self, command_id: str) -> str:
        """Get relative path for a slash command file.

        Args:
            command_id: Command identifier

        Returns:
            Relative path from project root
        """
        return FILE_PATHS[command_id]

    def get_frontmatter(self, command_id: str) -> str | None:
        """Get frontmatter for a slash command file.

        Args:
            command_id: Command identifier

        Returns:
            YAML frontmatter string
        """
        return FRONTMATTER[command_id]

    def get_body(self, command_id: str) -> str:
        """Get body content for a slash command.

        Args:
            command_id: Command identifier

        Returns:
            Command body content from templates
        """
        return get_command_body(command_id)
