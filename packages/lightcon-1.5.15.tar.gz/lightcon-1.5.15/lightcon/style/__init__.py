from ._plotstyle_1d import apply_style, reset, add_watermark, add_watermarks

__all__ = [
    "apply_style",
    "reset",
    "add_watermark",
    "add_watermarks",
]