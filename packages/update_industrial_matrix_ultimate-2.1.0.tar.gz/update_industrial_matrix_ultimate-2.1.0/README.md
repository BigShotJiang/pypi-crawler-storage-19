# Industrial Matrix

High-performance matrix computing library with SIMD optimization and OpenMP parallelization.

## Features

- **SIMD Optimization**: AVX2 vectorized operations for maximum performance
- **OpenMP Parallelization**: Multi-threaded matrix multiplication and operations
- **NumPy Integration**: Seamless conversion between NumPy arrays and Matrix objects
- **Multiple Data Types**: Support for float32, float64, int32, and int64
- **Modern C++17**: Clean, efficient implementation with PIMPL pattern

## Installation

### Prerequisites

```bash
sudo apt-get update
sudo apt-get install -y python3-dev python3-pip build-essential
```

### Install from source

```bash
pip install pybind11 numpy
python setup.py build_ext --inplace
python setup.py install
```

Or use pip in development mode:

```bash
pip install -e .
```

## Quick Start

```python
import industrial_matrix as im
import numpy as np

# Check system capabilities
print(im.system_info())

# Create matrices
A = im.MatrixF64.random(1000, 1000)
B = im.MatrixF64.ones(1000, 1000)

# Matrix operations
C = A @ B  # Matrix multiplication
D = A + B  # Element-wise addition
E = A.transpose()

# NumPy interoperability
np_array = np.random.rand(100, 100)
matrix = im.MatrixF64.from_numpy(np_array)
result = matrix.to_numpy()

# Benchmark
stats = im.benchmark(size=512, trials=10)
print(f"Performance: {stats['gflops']:.2f} GFLOPS")
```

## Performance

The library uses block-based matrix multiplication with cache optimization and SIMD instructions:

- **Single-threaded**: ~10-30 GFLOPS (depends on CPU)
- **Multi-threaded**: Scales linearly with core count
- **SIMD**: 4-8x speedup from AVX2 vectorization

## API Reference

### MatrixF64 / MatrixF32

#### Factory Methods
- `zeros(rows, cols)` - Create zero matrix
- `ones(rows, cols)` - Create matrix filled with ones
- `identity(n)` - Create identity matrix
- `random(rows, cols, min, max)` - Create random matrix

#### Properties
- `rows()` - Number of rows
- `cols()` - Number of columns
- `shape()` - Tuple of (rows, cols)
- `size()` - Total number of elements

#### Operations
- `matrix_multiply(other)` or `@` - Matrix multiplication
- `elementwise_add(other)` or `+` - Element-wise addition
- `elementwise_multiply(other)` or `*` - Element-wise multiplication
- `transpose()` - Matrix transpose
- `scalar_multiply(scalar)` - Scalar multiplication

#### Advanced Patterns

**Scalar Addition Workaround**

The library doesn't have a direct `scalar_add` method. To add a scalar to all elements:

```python
# Add scalar value to all matrix elements
ones = im.MatrixF64.ones(rows, cols)
scalar_matrix = ones.scalar_multiply(5.0)  # Create matrix of [5.0, 5.0, ...]
result = original_matrix.elementwise_add(scalar_matrix)

# Example: Add 10 to all elements
A = im.MatrixF64.random(100, 100)
offset = im.MatrixF64.ones(100, 100).scalar_multiply(10.0)
B = A.elementwise_add(offset)
```


#### NumPy Integration
- `from_numpy(array)` - Convert NumPy array to Matrix
- `to_numpy()` - Convert Matrix to NumPy array

## Requirements

- Python 3.7+
- NumPy 1.19.0+
- C++17 compatible compiler
- OpenMP support (optional, for parallelization)
- AVX2 CPU support (optional, for SIMD)

## License

MIT License

## Contributing

Contributions welcome! Please submit pull requests or open issues on GitHub.
