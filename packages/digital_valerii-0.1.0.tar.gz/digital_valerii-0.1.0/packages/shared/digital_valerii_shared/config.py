"""Shared configuration for Digital Valerii."""

from pydantic import Field
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """Database connection settings."""

    url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/digital_valerii",
        validation_alias="DATABASE_URL",
    )
    pool_size: int = Field(default=5, validation_alias="DB_POOL_SIZE")
    max_overflow: int = Field(default=10, validation_alias="DB_MAX_OVERFLOW")
    echo: bool = Field(default=False, validation_alias="DB_ECHO")

    model_config = {
        "env_prefix": "",
        "extra": "ignore",
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
    }


class QdrantSettings(BaseSettings):
    """Qdrant vector database settings."""

    url: str = Field(
        default="http://localhost:6333",
        validation_alias="QDRANT_URL",
    )
    api_key: str | None = Field(
        default=None,
        validation_alias="QDRANT_API_KEY",
    )
    collection_prefix: str = Field(
        default="dv_",
        validation_alias="QDRANT_COLLECTION_PREFIX",
    )
    timeout: int = Field(
        default=30,
        validation_alias="QDRANT_TIMEOUT",
    )
    vector_size: int = Field(
        default=1536,
        validation_alias="QDRANT_VECTOR_SIZE",
    )

    model_config = {
        "env_prefix": "",
        "extra": "ignore",
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
    }


class RedisSettings(BaseSettings):
    """Redis cache settings."""

    url: str = Field(
        default="redis://localhost:6379",
        validation_alias="REDIS_URL",
    )
    max_connections: int = Field(
        default=10,
        validation_alias="REDIS_MAX_CONNECTIONS",
    )
    socket_timeout: float = Field(
        default=5.0,
        validation_alias="REDIS_SOCKET_TIMEOUT",
    )
    socket_connect_timeout: float = Field(
        default=5.0,
        validation_alias="REDIS_SOCKET_CONNECT_TIMEOUT",
    )
    decode_responses: bool = Field(
        default=True,
        validation_alias="REDIS_DECODE_RESPONSES",
    )

    # TTL defaults (seconds)
    session_ttl: int = Field(default=86400)  # 24 hours
    working_memory_ttl: int = Field(default=3600)  # 1 hour
    cache_ttl: int = Field(default=300)  # 5 minutes
    lock_ttl: int = Field(default=30)  # 30 seconds

    model_config = {
        "env_prefix": "",
        "extra": "ignore",
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
    }


class EmbeddingSettings(BaseSettings):
    """Voyage embedding service settings."""

    api_key: str = Field(
        ...,  # Required
        validation_alias="VOYAGE_API_KEY",
    )
    model: str = Field(
        default="voyage-large-2",
        validation_alias="EMBEDDING_MODEL",
    )
    dimensions: int = Field(
        default=1536,
        validation_alias="EMBEDDING_DIMENSIONS",
    )
    max_tokens: int = Field(
        default=16000,
        validation_alias="EMBEDDING_MAX_TOKENS",
    )
    batch_size: int = Field(
        default=128,  # Voyage batch limit
        validation_alias="EMBEDDING_BATCH_SIZE",
    )
    timeout: float = Field(
        default=30.0,
        validation_alias="EMBEDDING_TIMEOUT",
    )
    cache_ttl: int = Field(
        default=86400,  # 24 hours
        validation_alias="EMBEDDING_CACHE_TTL",
    )

    model_config = {
        "env_prefix": "",
        "extra": "ignore",
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
    }


class WorkerSettings(BaseSettings):
    """Background worker settings."""

    max_jobs: int = Field(
        default=10,
        validation_alias="WORKER_MAX_JOBS",
    )
    job_timeout: int = Field(
        default=600,  # 10 minutes
        validation_alias="WORKER_JOB_TIMEOUT",
    )
    max_tries: int = Field(
        default=3,
        validation_alias="WORKER_MAX_TRIES",
    )
    retry_delay: int = Field(
        default=60,  # seconds
        validation_alias="WORKER_RETRY_DELAY",
    )
    soft_delete_retention_days: int = Field(
        default=90,
        validation_alias="SOFT_DELETE_RETENTION_DAYS",
    )

    model_config = {
        "env_prefix": "",
        "extra": "ignore",
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
    }
