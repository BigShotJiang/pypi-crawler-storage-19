"""Tests for Compact Handler service."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from packages.shared.digital_valerii_shared.config import DatabaseSettings
from packages.shared.digital_valerii_shared.database import IsolatedDatabase
from packages.shared.digital_valerii_shared.services.compact_handler import (
    COMPACT_MESSAGES,
    CompactHandler,
    CompactMessages,
    CompactResult,
    ConversationContext,
    InterfaceType,
    get_compact_messages,
)
from packages.shared.digital_valerii_shared.services.session_manager import (
    UnifiedSessionManager,
)


class TestInterfaceType:
    """Tests for InterfaceType enum."""

    def test_interface_type_values(self) -> None:
        """Test InterfaceType enum has correct values."""
        assert InterfaceType.WEB.value == "web"
        assert InterfaceType.SLACK.value == "slack"
        assert InterfaceType.MEETING.value == "meeting"
        assert InterfaceType.CLI.value == "cli"


class TestModels:
    """Tests for Pydantic models."""

    def test_compact_messages_extra_forbid(self) -> None:
        """Test CompactMessages rejects extra fields."""
        with pytest.raises(ValueError):
            CompactMessages(  # type: ignore[call-arg]
                pre="Before",
                post="After",
                extra_field="not allowed",
            )

    def test_compact_messages_valid(self) -> None:
        """Test CompactMessages accepts valid data."""
        messages = CompactMessages(
            pre="Before compact",
            post="After compact",
        )
        assert messages.pre == "Before compact"
        assert messages.post == "After compact"

    def test_conversation_context_extra_forbid(self) -> None:
        """Test ConversationContext rejects extra fields."""
        with pytest.raises(ValueError):
            ConversationContext(  # type: ignore[call-arg]
                user_id=uuid4(),
                channel=InterfaceType.WEB,
                extra_field="not allowed",
            )

    def test_conversation_context_valid(self) -> None:
        """Test ConversationContext accepts valid data."""
        user_id = uuid4()
        context = ConversationContext(
            user_id=user_id,
            channel=InterfaceType.SLACK,
            sdk_session_id="sdk-123",
            current_summary="Test summary",
            working_memory={"topics": ["project-x"]},
            active_context={"current_project": "test"},
            message_count=50,
        )
        assert context.user_id == user_id
        assert context.channel == InterfaceType.SLACK
        assert context.message_count == 50

    def test_conversation_context_defaults(self) -> None:
        """Test ConversationContext default values."""
        context = ConversationContext(
            user_id=uuid4(),
            channel=InterfaceType.WEB,
        )
        assert context.sdk_session_id is None
        assert context.current_summary is None
        assert context.working_memory == {}
        assert context.active_context == {}
        assert context.message_count == 0

    def test_compact_result_extra_forbid(self) -> None:
        """Test CompactResult rejects extra fields."""
        with pytest.raises(ValueError):
            CompactResult(  # type: ignore[call-arg]
                pre_message="Before",
                post_message="After",
                extra_field="not allowed",
            )

    def test_compact_result_valid(self) -> None:
        """Test CompactResult accepts valid data."""
        checkpoint_id = uuid4()
        result = CompactResult(
            checkpoint_id=checkpoint_id,
            pre_message="Before",
            post_message="After",
            summary="Test summary",
        )
        assert result.checkpoint_id == checkpoint_id
        assert result.pre_message == "Before"
        assert result.post_message == "After"
        assert result.summary == "Test summary"


class TestCompactMessages:
    """Tests for COMPACT_MESSAGES constant."""

    def test_all_channels_have_messages(self) -> None:
        """Test all interface types have defined messages."""
        for interface_type in InterfaceType:
            assert interface_type in COMPACT_MESSAGES
            messages = COMPACT_MESSAGES[interface_type]
            assert messages.pre
            assert messages.post

    def test_meeting_messages(self) -> None:
        """Test meeting channel has appropriate messages."""
        messages = COMPACT_MESSAGES[InterfaceType.MEETING]
        assert "хвилинку" in messages.pre.lower() or "момент" in messages.pre.lower()
        assert "терпіння" in messages.post.lower() or "зупинились" in messages.post.lower()

    def test_slack_messages(self) -> None:
        """Test Slack channel has appropriate messages."""
        messages = COMPACT_MESSAGES[InterfaceType.SLACK]
        assert len(messages.pre) < 100  # Should be concise for Slack
        assert len(messages.post) < 100

    def test_web_messages(self) -> None:
        """Test web channel has appropriate messages."""
        messages = COMPACT_MESSAGES[InterfaceType.WEB]
        assert messages.pre
        assert messages.post

    def test_cli_messages(self) -> None:
        """Test CLI channel has appropriate messages."""
        messages = COMPACT_MESSAGES[InterfaceType.CLI]
        assert "[" in messages.pre  # CLI uses brackets
        assert "[" in messages.post


class TestGetCompactMessages:
    """Tests for get_compact_messages helper function."""

    def test_returns_all_channels(self) -> None:
        """Test get_compact_messages returns all channels."""
        messages = get_compact_messages()
        assert "web" in messages
        assert "slack" in messages
        assert "meeting" in messages
        assert "cli" in messages

    def test_message_structure(self) -> None:
        """Test each channel has pre and post messages."""
        messages = get_compact_messages()
        for channel, channel_messages in messages.items():
            assert "pre" in channel_messages
            assert "post" in channel_messages
            assert isinstance(channel_messages["pre"], str)
            assert isinstance(channel_messages["post"], str)


class TestCompactHandlerSync:
    """Synchronous tests for CompactHandler."""

    def test_get_messages_for_channel(self) -> None:
        """Test get_messages_for_channel returns correct messages."""
        # This test doesn't need database - using mock session manager
        from unittest.mock import AsyncMock

        mock_manager = AsyncMock(spec=UnifiedSessionManager)
        handler = CompactHandler(mock_manager)

        for interface_type in InterfaceType:
            messages = handler.get_messages_for_channel(interface_type)
            assert isinstance(messages, CompactMessages)
            assert messages.pre == COMPACT_MESSAGES[interface_type].pre
            assert messages.post == COMPACT_MESSAGES[interface_type].post

    def test_get_pre_message(self) -> None:
        """Test get_pre_message returns pre message."""
        from unittest.mock import AsyncMock

        mock_manager = AsyncMock(spec=UnifiedSessionManager)
        handler = CompactHandler(mock_manager)

        for interface_type in InterfaceType:
            pre_msg = handler.get_pre_message(interface_type)
            assert pre_msg == COMPACT_MESSAGES[interface_type].pre

    def test_get_post_message(self) -> None:
        """Test get_post_message returns post message."""
        from unittest.mock import AsyncMock

        mock_manager = AsyncMock(spec=UnifiedSessionManager)
        handler = CompactHandler(mock_manager)

        for interface_type in InterfaceType:
            post_msg = handler.get_post_message(interface_type)
            assert post_msg == COMPACT_MESSAGES[interface_type].post


@pytest.mark.asyncio
class TestCompactHandler:
    """Async tests for CompactHandler service."""

    async def test_on_pre_compact_saves_checkpoint(self) -> None:
        """Test on_pre_compact saves checkpoint and returns messages."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            # Create session first
            await manager.get_or_create_session(user_id)

            context = ConversationContext(
                user_id=user_id,
                channel=InterfaceType.WEB,
                current_summary="We were discussing project X",
                working_memory={"topics": ["project-x", "deadline"]},
                active_context={"project": "X", "phase": "planning"},
                message_count=75,
            )

            result = await handler.on_pre_compact(context)

            assert result.checkpoint_id is not None
            assert result.pre_message == COMPACT_MESSAGES[InterfaceType.WEB].pre
            assert result.post_message == COMPACT_MESSAGES[InterfaceType.WEB].post
            assert result.summary == "We were discussing project X"

        await db.close()

    async def test_on_pre_compact_with_metadata(self) -> None:
        """Test on_pre_compact includes metadata in checkpoint."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            await manager.get_or_create_session(user_id)

            context = ConversationContext(
                user_id=user_id,
                channel=InterfaceType.SLACK,
                message_count=100,
            )

            compact_metadata = {
                "reason": "context_limit_reached",
                "trigger": "auto",
            }

            result = await handler.on_pre_compact(context, compact_metadata)

            assert result.checkpoint_id is not None
            assert result.pre_message == COMPACT_MESSAGES[InterfaceType.SLACK].pre

        await db.close()

    async def test_on_post_compact_returns_message(self) -> None:
        """Test on_post_compact returns appropriate message."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            await manager.get_or_create_session(user_id)

            context = ConversationContext(
                user_id=user_id,
                channel=InterfaceType.CLI,
            )

            message = await handler.on_post_compact(context)

            assert message == COMPACT_MESSAGES[InterfaceType.CLI].post

        await db.close()

    async def test_on_post_compact_with_source(self) -> None:
        """Test on_post_compact handles different sources."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            await manager.get_or_create_session(user_id)

            context = ConversationContext(
                user_id=user_id,
                channel=InterfaceType.MEETING,
            )

            # Test different sources
            for source in ["auto_compact", "manual", "recovery"]:
                message = await handler.on_post_compact(context, source=source)
                assert message == COMPACT_MESSAGES[InterfaceType.MEETING].post

        await db.close()

    async def test_get_context_summary_for_injection(self) -> None:
        """Test get_context_summary_for_injection returns checkpoint data."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            await manager.get_or_create_session(user_id)

            # First save a checkpoint via on_pre_compact
            context = ConversationContext(
                user_id=user_id,
                channel=InterfaceType.WEB,
                current_summary="Testing context injection",
                working_memory={"key": "value"},
                active_context={"project": "test"},
                message_count=50,
            )

            await handler.on_pre_compact(context)

            # Now get the summary for injection
            summary = await handler.get_context_summary_for_injection(user_id)

            assert summary is not None
            assert summary["summary"] == "Testing context injection"
            assert summary["working_memory"] == {"key": "value"}
            assert summary["active_context"] == {"project": "test"}
            assert summary["previous_message_count"] == 50
            assert summary["checkpoint_type"] == "pre_compact"
            assert "checkpoint_time" in summary

        await db.close()

    async def test_get_context_summary_for_injection_no_checkpoint(self) -> None:
        """Test get_context_summary_for_injection returns None when no checkpoint."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            await manager.get_or_create_session(user_id)

            # No checkpoint saved yet
            summary = await handler.get_context_summary_for_injection(user_id)

            assert summary is None

        await db.close()

    async def test_channel_specific_messages_are_used(self) -> None:
        """Test each channel gets its specific messages."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            for interface_type in InterfaceType:
                user_id = uuid4()
                await manager.get_or_create_session(user_id)

                context = ConversationContext(
                    user_id=user_id,
                    channel=interface_type,
                    message_count=10,
                )

                result = await handler.on_pre_compact(context)

                expected = COMPACT_MESSAGES[interface_type]
                assert result.pre_message == expected.pre
                assert result.post_message == expected.post

        await db.close()


@pytest.mark.asyncio
class TestCompactHandlerUserIsolation:
    """Tests verifying user data isolation in CompactHandler."""

    async def test_checkpoints_are_user_isolated(self) -> None:
        """Test that checkpoints are isolated between users."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user1 = uuid4()
        user2 = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            handler = CompactHandler(manager)

            # Create sessions for both users
            await manager.get_or_create_session(user1)
            await manager.get_or_create_session(user2)

            # Save checkpoint for user1
            context1 = ConversationContext(
                user_id=user1,
                channel=InterfaceType.WEB,
                current_summary="User 1 summary",
                message_count=100,
            )
            await handler.on_pre_compact(context1)

            # Save checkpoint for user2
            context2 = ConversationContext(
                user_id=user2,
                channel=InterfaceType.SLACK,
                current_summary="User 2 summary",
                message_count=50,
            )
            await handler.on_pre_compact(context2)

            # Get summaries - each user should see only their own
            summary1 = await handler.get_context_summary_for_injection(user1)
            summary2 = await handler.get_context_summary_for_injection(user2)

            assert summary1 is not None
            assert summary2 is not None
            assert summary1["summary"] == "User 1 summary"
            assert summary2["summary"] == "User 2 summary"
            assert summary1["previous_message_count"] == 100
            assert summary2["previous_message_count"] == 50

        await db.close()
