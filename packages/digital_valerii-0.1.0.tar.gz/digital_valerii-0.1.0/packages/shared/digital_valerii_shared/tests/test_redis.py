"""Tests for Redis cache service."""

from datetime import date, datetime
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from pydantic import ValidationError
from redis.exceptions import ConnectionError as RedisConnError

from packages.shared.digital_valerii_shared.config import RedisSettings
from packages.shared.digital_valerii_shared.services.redis import (
    MAX_SCAN_ITERATIONS,
    RedisConnectionError,
    RedisError,
    RedisKeyError,
    RedisLockError,
    RedisNamespace,
    RedisSerializationError,
    RedisService,
    SessionData,
    WorkingMemory,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def settings() -> RedisSettings:
    """Create test settings."""
    return RedisSettings(
        url="redis://localhost:6379",
        max_connections=5,
        session_ttl=3600,
        working_memory_ttl=1800,
        cache_ttl=300,
        lock_ttl=30,
    )


@pytest.fixture
def mock_redis() -> AsyncMock:
    """Create a mock Redis client."""
    client = AsyncMock()
    client.ping = AsyncMock(return_value=True)
    client.get = AsyncMock(return_value=None)
    client.set = AsyncMock(return_value=True)
    client.delete = AsyncMock(return_value=1)
    client.exists = AsyncMock(return_value=1)
    client.keys = AsyncMock(return_value=[])
    client.ttl = AsyncMock(return_value=100)
    client.expire = AsyncMock(return_value=True)
    client.incr = AsyncMock(return_value=1)
    client.aclose = AsyncMock()
    client.register_script = MagicMock(return_value=AsyncMock(return_value=1))
    return client


@pytest.fixture
def service(settings: RedisSettings, mock_redis: AsyncMock) -> RedisService:
    """Create a RedisService with mocked client."""
    svc = RedisService(settings)
    svc._client = mock_redis
    svc._release_script = AsyncMock(return_value=1)
    svc._extend_script = AsyncMock(return_value=1)
    return svc


# =============================================================================
# Model Tests
# =============================================================================


class TestSessionData:
    """Tests for SessionData model."""

    def test_valid_session_data(self) -> None:
        """Test creating valid SessionData."""
        session = SessionData(
            user_id="user123",
            created_at=datetime.now(),
            last_activity=datetime.now(),
            metadata={"key": "value"},
        )
        assert session.user_id == "user123"
        assert "key" in session.metadata

    def test_session_data_defaults(self) -> None:
        """Test SessionData default values."""
        session = SessionData(
            user_id="user123",
            created_at=datetime.now(),
            last_activity=datetime.now(),
        )
        assert session.metadata == {}

    def test_session_data_rejects_extra_fields(self) -> None:
        """Test that SessionData rejects unknown fields."""
        with pytest.raises(ValidationError):
            SessionData(
                user_id="user123",
                created_at=datetime.now(),
                last_activity=datetime.now(),
                extra_field="not allowed",
            )


class TestWorkingMemory:
    """Tests for WorkingMemory model."""

    def test_valid_working_memory(self) -> None:
        """Test creating valid WorkingMemory."""
        wm = WorkingMemory(
            session_id="session123",
            conversation_id="conv123",
            messages=[{"role": "user", "content": "Hello"}],
            context={"key": "value"},
            updated_at=datetime.now(),
        )
        assert wm.session_id == "session123"
        assert len(wm.messages) == 1

    def test_working_memory_defaults(self) -> None:
        """Test WorkingMemory default values."""
        wm = WorkingMemory(
            session_id="session123",
            updated_at=datetime.now(),
        )
        assert wm.conversation_id is None
        assert wm.messages == []
        assert wm.context == {}

    def test_working_memory_rejects_extra_fields(self) -> None:
        """Test that WorkingMemory rejects unknown fields."""
        with pytest.raises(ValidationError):
            WorkingMemory(
                session_id="session123",
                updated_at=datetime.now(),
                unknown="field",
            )


# =============================================================================
# RedisNamespace Tests
# =============================================================================


class TestRedisNamespace:
    """Tests for RedisNamespace enum."""

    def test_all_namespaces_defined(self) -> None:
        """Test all expected namespaces exist."""
        assert RedisNamespace.SESSIONS == "dv:sessions:"
        assert RedisNamespace.CACHE == "dv:cache:"
        assert RedisNamespace.RATE_LIMIT == "dv:rate:"
        assert RedisNamespace.LOCKS == "dv:lock:"
        assert RedisNamespace.WORKING_MEMORY == "dv:wm:"
        assert RedisNamespace.JOBS == "dv:jobs:"
        assert RedisNamespace.OUTBOX == "dv:outbox:"
        assert RedisNamespace.APPROVALS == "dv:approval:"

    def test_namespace_count(self) -> None:
        """Test that we have exactly 8 namespaces."""
        assert len(RedisNamespace) == 8


# =============================================================================
# Connection Tests
# =============================================================================


class TestRedisConnection:
    """Tests for Redis connection management."""

    def test_default_settings(self) -> None:
        """Test service creates with default settings."""
        service = RedisService()
        assert service.settings.url == "redis://localhost:6379"
        assert service.settings.max_connections == 10

    def test_custom_settings(self, settings: RedisSettings) -> None:
        """Test service accepts custom settings."""
        service = RedisService(settings)
        assert service.settings.max_connections == 5

    def test_client_not_connected_raises(self, settings: RedisSettings) -> None:
        """Test accessing client before connect raises error."""
        service = RedisService(settings)
        with pytest.raises(RedisConnectionError, match="not connected"):
            _ = service.client

    @pytest.mark.asyncio
    async def test_connect_success(self, settings: RedisSettings) -> None:
        """Test successful connection."""
        with (
            patch(
                "packages.shared.digital_valerii_shared.services.redis.ConnectionPool"
            ) as mock_pool,
            patch(
                "packages.shared.digital_valerii_shared.services.redis.Redis"
            ) as mock_redis_class,
        ):
            mock_client = AsyncMock()
            mock_client.ping = AsyncMock(return_value=True)
            mock_client.register_script = MagicMock(return_value=AsyncMock())
            mock_redis_class.return_value = mock_client
            mock_pool.from_url.return_value = MagicMock()

            service = RedisService(settings)
            await service.connect()

            assert service._client is not None
            mock_client.ping.assert_called_once()

    @pytest.mark.asyncio
    async def test_connect_failure(self, settings: RedisSettings) -> None:
        """Test connection failure raises error."""
        with (
            patch(
                "packages.shared.digital_valerii_shared.services.redis.ConnectionPool"
            ) as mock_pool,
            patch(
                "packages.shared.digital_valerii_shared.services.redis.Redis"
            ) as mock_redis_class,
        ):
            mock_client = AsyncMock()
            mock_client.ping = AsyncMock(
                side_effect=RedisConnError("Connection refused")
            )
            mock_redis_class.return_value = mock_client
            mock_pool.from_url.return_value = MagicMock()

            service = RedisService(settings)
            with pytest.raises(RedisConnectionError):
                await service.connect()

    @pytest.mark.asyncio
    async def test_close(self, service: RedisService, mock_redis: AsyncMock) -> None:
        """Test closing connection."""
        await service.close()
        mock_redis.aclose.assert_called_once()
        assert service._client is None

    @pytest.mark.asyncio
    async def test_health_check_healthy(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test health check when healthy."""
        result = await service.health_check()
        assert result is True
        mock_redis.ping.assert_called()

    @pytest.mark.asyncio
    async def test_health_check_unhealthy(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test health check when unhealthy."""
        mock_redis.ping.side_effect = Exception("Connection failed")
        result = await service.health_check()
        assert result is False

    @pytest.mark.asyncio
    async def test_health_check_not_connected(self, settings: RedisSettings) -> None:
        """Test health check when not connected."""
        service = RedisService(settings)
        result = await service.health_check()
        assert result is False


# =============================================================================
# Generic Operations Tests
# =============================================================================


class TestGenericOperations:
    """Tests for generic Redis operations."""

    def test_make_key(self, service: RedisService) -> None:
        """Test key generation with namespace."""
        key = service._make_key("mykey", RedisNamespace.SESSIONS)
        assert key == "dv:sessions:mykey"

    @pytest.mark.asyncio
    async def test_get_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting an existing key."""
        mock_redis.get.return_value = "test_value"
        result = await service.get("mykey", RedisNamespace.SESSIONS)
        assert result == "test_value"
        mock_redis.get.assert_called_with("dv:sessions:mykey")

    @pytest.mark.asyncio
    async def test_get_non_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting a non-existing key."""
        mock_redis.get.return_value = None
        result = await service.get("nonexistent", RedisNamespace.SESSIONS)
        assert result is None

    @pytest.mark.asyncio
    async def test_set_with_ttl(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting a value with TTL."""
        await service.set("mykey", "myvalue", RedisNamespace.CACHE, ttl=60)
        mock_redis.set.assert_called_with("dv:cache:mykey", "myvalue", ex=60)

    @pytest.mark.asyncio
    async def test_set_without_ttl(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting a value without TTL."""
        await service.set("mykey", "myvalue", RedisNamespace.CACHE)
        mock_redis.set.assert_called_with("dv:cache:mykey", "myvalue")

    @pytest.mark.asyncio
    async def test_delete_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test deleting an existing key."""
        mock_redis.delete.return_value = 1
        result = await service.delete("mykey", RedisNamespace.SESSIONS)
        assert result is True

    @pytest.mark.asyncio
    async def test_delete_non_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test deleting a non-existing key."""
        mock_redis.delete.return_value = 0
        result = await service.delete("nonexistent", RedisNamespace.SESSIONS)
        assert result is False

    @pytest.mark.asyncio
    async def test_exists_true(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test exists returns True for existing key."""
        mock_redis.exists.return_value = 1
        result = await service.exists("mykey", RedisNamespace.SESSIONS)
        assert result is True

    @pytest.mark.asyncio
    async def test_exists_false(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test exists returns False for non-existing key."""
        mock_redis.exists.return_value = 0
        result = await service.exists("nonexistent", RedisNamespace.SESSIONS)
        assert result is False

    @pytest.mark.asyncio
    async def test_keys_pattern(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test finding keys by pattern."""
        mock_redis.keys.return_value = [
            "dv:sessions:user1",
            "dv:sessions:user2",
        ]
        result = await service.keys("user*", RedisNamespace.SESSIONS)
        assert result == ["user1", "user2"]

    @pytest.mark.asyncio
    async def test_keys_empty(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test finding keys with no matches."""
        mock_redis.keys.return_value = []
        result = await service.keys("nonexistent*", RedisNamespace.SESSIONS)
        assert result == []

    @pytest.mark.asyncio
    async def test_ttl(self, service: RedisService, mock_redis: AsyncMock) -> None:
        """Test getting TTL."""
        mock_redis.ttl.return_value = 3600
        result = await service.ttl("mykey", RedisNamespace.SESSIONS)
        assert result == 3600


# =============================================================================
# JSON Operations Tests
# =============================================================================


class TestJSONOperations:
    """Tests for JSON operations."""

    @pytest.mark.asyncio
    async def test_get_json_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting existing JSON value."""
        mock_redis.get.return_value = '{"key": "value"}'
        result = await service.get_json("mykey", RedisNamespace.CACHE)
        assert result == {"key": "value"}

    @pytest.mark.asyncio
    async def test_get_json_non_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting non-existing JSON value."""
        mock_redis.get.return_value = None
        result = await service.get_json("nonexistent", RedisNamespace.CACHE)
        assert result is None

    @pytest.mark.asyncio
    async def test_get_json_invalid(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting invalid JSON raises error."""
        mock_redis.get.return_value = "not valid json"
        with pytest.raises(RedisSerializationError):
            await service.get_json("mykey", RedisNamespace.CACHE)

    @pytest.mark.asyncio
    async def test_set_json_dict(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting a JSON dict."""
        await service.set_json("mykey", {"key": "value"}, RedisNamespace.CACHE, ttl=60)
        mock_redis.set.assert_called()

    @pytest.mark.asyncio
    async def test_set_json_list(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting a JSON list."""
        await service.set_json("mykey", [1, 2, 3], RedisNamespace.CACHE)
        mock_redis.set.assert_called()

    def test_json_safe_uuid(self, service: RedisService) -> None:
        """Test JSON serialization of UUID."""
        test_uuid = uuid4()
        result = service._json_safe({"id": test_uuid})
        assert result["id"] == str(test_uuid)

    def test_json_safe_datetime(self, service: RedisService) -> None:
        """Test JSON serialization of datetime."""
        dt = datetime(2025, 1, 1, 12, 0, 0)
        result = service._json_safe({"timestamp": dt})
        assert result["timestamp"] == "2025-01-01T12:00:00"

    def test_json_safe_date(self, service: RedisService) -> None:
        """Test JSON serialization of date."""
        d = date(2025, 1, 1)
        result = service._json_safe({"date": d})
        assert result["date"] == "2025-01-01"

    def test_json_safe_decimal(self, service: RedisService) -> None:
        """Test JSON serialization of Decimal."""
        result = service._json_safe({"amount": Decimal("123.45")})
        assert result["amount"] == 123.45

    def test_json_safe_nested(self, service: RedisService) -> None:
        """Test JSON serialization of nested structures."""
        test_uuid = uuid4()
        dt = datetime(2025, 1, 1)
        data = {
            "nested": {
                "id": test_uuid,
                "items": [dt, Decimal("1.5")],
            }
        }
        result = service._json_safe(data)
        assert result["nested"]["id"] == str(test_uuid)
        assert result["nested"]["items"][0] == "2025-01-01T00:00:00"
        assert result["nested"]["items"][1] == 1.5


# =============================================================================
# Session Management Tests
# =============================================================================


class TestSessionManagement:
    """Tests for session management."""

    @pytest.mark.asyncio
    async def test_get_session(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting a session."""
        mock_redis.get.return_value = '{"user_id": "user123"}'
        result = await service.get_session("session123")
        assert result == {"user_id": "user123"}

    @pytest.mark.asyncio
    async def test_get_session_not_found(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting non-existing session."""
        mock_redis.get.return_value = None
        result = await service.get_session("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_session(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting a session."""
        await service.set_session("session123", {"user_id": "user123"})
        mock_redis.set.assert_called()
        # Verify TTL was set
        call_args = mock_redis.set.call_args
        assert call_args[1]["ex"] == service.settings.session_ttl

    @pytest.mark.asyncio
    async def test_delete_session(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test deleting a session."""
        mock_redis.delete.return_value = 1
        result = await service.delete_session("session123")
        assert result is True

    @pytest.mark.asyncio
    async def test_extend_session(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test extending session TTL."""
        mock_redis.expire.return_value = True
        result = await service.extend_session("session123")
        assert result is True
        mock_redis.expire.assert_called_with(
            "dv:sessions:session123", service.settings.session_ttl
        )

    @pytest.mark.asyncio
    async def test_extend_session_not_found(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test extending non-existing session."""
        mock_redis.expire.return_value = False
        result = await service.extend_session("nonexistent")
        assert result is False


# =============================================================================
# Working Memory Tests
# =============================================================================


class TestWorkingMemoryOps:
    """Tests for working memory operations."""

    @pytest.mark.asyncio
    async def test_get_working_memory(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting working memory."""
        mock_redis.get.return_value = '{"session_id": "s123", "messages": []}'
        result = await service.get_working_memory("s123")
        assert result == {"session_id": "s123", "messages": []}

    @pytest.mark.asyncio
    async def test_get_working_memory_not_found(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting non-existing working memory."""
        mock_redis.get.return_value = None
        result = await service.get_working_memory("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_set_working_memory(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test setting working memory."""
        await service.set_working_memory("s123", {"session_id": "s123"})
        mock_redis.set.assert_called()
        call_args = mock_redis.set.call_args
        assert call_args[1]["ex"] == service.settings.working_memory_ttl

    @pytest.mark.asyncio
    async def test_update_working_memory_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test updating existing working memory."""
        mock_redis.get.return_value = '{"key1": "value1"}'
        await service.update_working_memory("s123", {"key2": "value2"})
        # Should merge updates
        call_args = mock_redis.set.call_args
        assert "key1" in call_args[0][1]
        assert "key2" in call_args[0][1]

    @pytest.mark.asyncio
    async def test_update_working_memory_new(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test updating non-existing working memory creates it."""
        mock_redis.get.return_value = None
        await service.update_working_memory("s123", {"key": "value"})
        mock_redis.set.assert_called()

    @pytest.mark.asyncio
    async def test_delete_working_memory(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test deleting working memory."""
        mock_redis.delete.return_value = 1
        result = await service.delete_working_memory("s123")
        assert result is True


# =============================================================================
# Cache Operations Tests
# =============================================================================


class TestCacheOperations:
    """Tests for cache operations."""

    @pytest.mark.asyncio
    async def test_cache_get(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache get."""
        mock_redis.get.return_value = '{"cached": "data"}'
        result = await service.cache_get("mykey")
        assert result == {"cached": "data"}

    @pytest.mark.asyncio
    async def test_cache_get_miss(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache miss."""
        mock_redis.get.return_value = None
        result = await service.cache_get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_cache_set_default_ttl(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache set with default TTL."""
        await service.cache_set("mykey", {"data": "value"})
        call_args = mock_redis.set.call_args
        assert call_args[1]["ex"] == service.settings.cache_ttl

    @pytest.mark.asyncio
    async def test_cache_set_custom_ttl(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache set with custom TTL."""
        await service.cache_set("mykey", {"data": "value"}, ttl=600)
        call_args = mock_redis.set.call_args
        assert call_args[1]["ex"] == 600

    @pytest.mark.asyncio
    async def test_cache_delete(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache delete."""
        mock_redis.delete.return_value = 1
        result = await service.cache_delete("mykey")
        assert result is True

    @pytest.mark.asyncio
    async def test_cache_invalidate_pattern(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test invalidating cache by pattern."""
        mock_redis.keys.return_value = ["dv:cache:user:1", "dv:cache:user:2"]
        mock_redis.delete.return_value = 1
        result = await service.cache_invalidate_pattern("user:*")
        assert result == 2

    @pytest.mark.asyncio
    async def test_cache_invalidate_pattern_no_matches(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test invalidating cache with no matches."""
        mock_redis.keys.return_value = []
        result = await service.cache_invalidate_pattern("nonexistent:*")
        assert result == 0


# =============================================================================
# Distributed Lock Tests
# =============================================================================


class TestDistributedLocks:
    """Tests for distributed lock operations."""

    @pytest.mark.asyncio
    async def test_acquire_lock_success(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test acquiring a lock successfully."""
        mock_redis.set.return_value = True
        token = await service.acquire_lock("mylock")
        assert token is not None
        assert len(token) > 0

    @pytest.mark.asyncio
    async def test_acquire_lock_already_held(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test acquiring a lock that's already held."""
        mock_redis.set.return_value = False
        token = await service.acquire_lock("mylock")
        assert token is None

    @pytest.mark.asyncio
    async def test_acquire_lock_custom_ttl(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test acquiring lock with custom TTL."""
        mock_redis.set.return_value = True
        await service.acquire_lock("mylock", ttl=60)
        call_args = mock_redis.set.call_args
        assert call_args[1]["ex"] == 60

    @pytest.mark.asyncio
    async def test_acquire_lock_blocking_success(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test blocking lock acquisition succeeds."""
        # First attempt fails, second succeeds
        mock_redis.set.side_effect = [False, True]
        token = await service.acquire_lock("mylock", blocking=True, timeout=1.0)
        assert token is not None

    @pytest.mark.asyncio
    async def test_acquire_lock_blocking_timeout(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test blocking lock acquisition times out."""
        mock_redis.set.return_value = False
        token = await service.acquire_lock("mylock", blocking=True, timeout=0.1)
        assert token is None

    @pytest.mark.asyncio
    async def test_release_lock_success(self, service: RedisService) -> None:
        """Test releasing a lock successfully."""
        service._release_script = AsyncMock(return_value=1)
        result = await service.release_lock("mylock", "valid_token")
        assert result is True

    @pytest.mark.asyncio
    async def test_release_lock_wrong_token(self, service: RedisService) -> None:
        """Test releasing lock with wrong token."""
        service._release_script = AsyncMock(return_value=0)
        result = await service.release_lock("mylock", "wrong_token")
        assert result is False

    @pytest.mark.asyncio
    async def test_release_lock_not_connected(self, settings: RedisSettings) -> None:
        """Test releasing lock when not connected."""
        service = RedisService(settings)
        service._client = AsyncMock()  # Set client but not scripts
        service._release_script = None
        with pytest.raises(RedisLockError):
            await service.release_lock("mylock", "token")

    @pytest.mark.asyncio
    async def test_extend_lock_success(self, service: RedisService) -> None:
        """Test extending a lock successfully."""
        service._extend_script = AsyncMock(return_value=1)
        result = await service.extend_lock("mylock", "valid_token")
        assert result is True

    @pytest.mark.asyncio
    async def test_extend_lock_wrong_token(self, service: RedisService) -> None:
        """Test extending lock with wrong token."""
        service._extend_script = AsyncMock(return_value=0)
        result = await service.extend_lock("mylock", "wrong_token")
        assert result is False

    @pytest.mark.asyncio
    async def test_extend_lock_custom_ttl(self, service: RedisService) -> None:
        """Test extending lock with custom TTL."""
        service._extend_script = AsyncMock(return_value=1)
        await service.extend_lock("mylock", "token", ttl=120)
        service._extend_script.assert_called()


# =============================================================================
# Rate Limiting Tests
# =============================================================================


class TestRateLimiting:
    """Tests for rate limiting helpers."""

    @pytest.mark.asyncio
    async def test_increment_new_counter(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test incrementing a new counter."""
        mock_redis.incr.return_value = 1
        result = await service.increment("counter", RedisNamespace.RATE_LIMIT, ttl=60)
        assert result == 1
        mock_redis.expire.assert_called()

    @pytest.mark.asyncio
    async def test_increment_existing_counter(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test incrementing an existing counter."""
        mock_redis.incr.return_value = 5
        result = await service.increment("counter", RedisNamespace.RATE_LIMIT)
        assert result == 5
        mock_redis.expire.assert_not_called()

    @pytest.mark.asyncio
    async def test_get_counter_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting existing counter."""
        mock_redis.get.return_value = "42"
        result = await service.get_counter("counter", RedisNamespace.RATE_LIMIT)
        assert result == 42

    @pytest.mark.asyncio
    async def test_get_counter_not_existing(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting non-existing counter."""
        mock_redis.get.return_value = None
        result = await service.get_counter("counter", RedisNamespace.RATE_LIMIT)
        assert result == 0


# =============================================================================
# Error Handling Tests
# =============================================================================


class TestErrorHandling:
    """Tests for error handling."""

    def test_redis_error_hierarchy(self) -> None:
        """Test error class hierarchy."""
        assert issubclass(RedisConnectionError, RedisError)
        assert issubclass(RedisKeyError, RedisError)
        assert issubclass(RedisLockError, RedisError)
        assert issubclass(RedisSerializationError, RedisError)

    @pytest.mark.asyncio
    async def test_get_raises_key_error(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get raises RedisKeyError on failure."""
        from redis.exceptions import RedisError as BaseError

        mock_redis.get.side_effect = BaseError("Connection lost")
        with pytest.raises(RedisKeyError):
            await service.get("mykey", RedisNamespace.SESSIONS)

    @pytest.mark.asyncio
    async def test_set_raises_key_error(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test set raises RedisKeyError on failure."""
        from redis.exceptions import RedisError as BaseError

        mock_redis.set.side_effect = BaseError("Connection lost")
        with pytest.raises(RedisKeyError):
            await service.set("mykey", "value", RedisNamespace.SESSIONS)

    @pytest.mark.asyncio
    async def test_lock_acquire_raises_lock_error(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test lock acquire raises RedisLockError on failure."""
        from redis.exceptions import RedisError as BaseError

        mock_redis.set.side_effect = BaseError("Connection lost")
        with pytest.raises(RedisLockError):
            await service.acquire_lock("mylock")


# =============================================================================
# Edge Cases Tests
# =============================================================================


class TestEdgeCases:
    """Tests for edge cases."""

    @pytest.mark.asyncio
    async def test_ttl_no_expire(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test TTL returns -1 for key without expiry."""
        mock_redis.ttl.return_value = -1
        result = await service.ttl("mykey", RedisNamespace.SESSIONS)
        assert result == -1

    @pytest.mark.asyncio
    async def test_ttl_key_not_exists(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test TTL returns -2 for non-existing key."""
        mock_redis.ttl.return_value = -2
        result = await service.ttl("nonexistent", RedisNamespace.SESSIONS)
        assert result == -2

    @pytest.mark.asyncio
    async def test_empty_json_object(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting empty JSON object."""
        mock_redis.get.return_value = "{}"
        result = await service.get_json("mykey", RedisNamespace.CACHE)
        assert result == {}

    @pytest.mark.asyncio
    async def test_empty_json_array(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test getting empty JSON array."""
        mock_redis.get.return_value = "[]"
        result = await service.get_json("mykey", RedisNamespace.CACHE)
        assert result == []

    def test_json_safe_tuple(self, service: RedisService) -> None:
        """Test JSON serialization of tuples."""
        result = service._json_safe((1, 2, 3))
        assert result == [1, 2, 3]

    def test_json_safe_primitives(self, service: RedisService) -> None:
        """Test JSON serialization of primitives."""
        assert service._json_safe("string") == "string"
        assert service._json_safe(123) == 123
        assert service._json_safe(1.5) == 1.5
        assert service._json_safe(True) is True
        assert service._json_safe(None) is None

    @pytest.mark.asyncio
    async def test_connect_already_connected(self, service: RedisService) -> None:
        """Test connect when already connected does nothing."""
        # Already connected via fixture
        original_client = service._client
        await service.connect()
        assert service._client is original_client


# =============================================================================
# Round 2 Codex Fixes Tests
# =============================================================================


class TestRound2Fixes:
    """Tests for Round 2 Codex fixes."""

    @pytest.fixture
    def settings(self) -> RedisSettings:
        """Create test settings."""
        return RedisSettings(url="redis://localhost:6379")

    @pytest.fixture
    def mock_redis(self) -> AsyncMock:
        """Create mock Redis client."""
        mock = AsyncMock()
        mock.ping = AsyncMock(return_value=True)
        mock.get = AsyncMock(return_value=None)
        mock.set = AsyncMock(return_value=True)
        mock.delete = AsyncMock(return_value=1)
        mock.exists = AsyncMock(return_value=1)
        mock.scan = AsyncMock(return_value=(0, []))
        mock.ttl = AsyncMock(return_value=3600)
        mock.incr = AsyncMock(return_value=1)
        mock.expire = AsyncMock(return_value=True)
        mock.aclose = AsyncMock()
        mock.register_script = MagicMock(return_value=AsyncMock())
        return mock

    @pytest.fixture
    def service(self, settings: RedisSettings, mock_redis: AsyncMock) -> RedisService:
        """Create service with mock client."""
        svc = RedisService(settings)
        svc._client = mock_redis
        svc._pool = MagicMock()
        svc._release_script = AsyncMock()
        svc._extend_script = AsyncMock()
        return svc

    # -------------------------------------------------------------------------
    # HIGH-1: Connect failure clears state
    # -------------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_connect_failure_clears_state(self, settings: RedisSettings) -> None:
        """Test that failed connect() doesn't leave partial state."""
        service = RedisService(settings)

        with (
            patch(
                "packages.shared.digital_valerii_shared.services.redis.ConnectionPool"
            ) as mock_pool,
            patch(
                "packages.shared.digital_valerii_shared.services.redis.Redis"
            ) as mock_redis_class,
        ):
            mock_client = AsyncMock()
            mock_client.ping = AsyncMock(
                side_effect=RedisConnError("Connection refused")
            )
            mock_client.aclose = AsyncMock()
            mock_redis_class.return_value = mock_client
            mock_pool.from_url.return_value = MagicMock()

            with pytest.raises(RedisConnectionError):
                await service.connect()

            # State should be clean for retry
            assert service._client is None
            assert service._pool is None
            assert service._release_script is None
            assert service._extend_script is None

    @pytest.mark.asyncio
    async def test_connect_failure_closes_client(self, settings: RedisSettings) -> None:
        """Test that failed connect() calls aclose on partial client."""
        service = RedisService(settings)

        with (
            patch(
                "packages.shared.digital_valerii_shared.services.redis.ConnectionPool"
            ) as mock_pool,
            patch(
                "packages.shared.digital_valerii_shared.services.redis.Redis"
            ) as mock_redis_class,
        ):
            mock_client = AsyncMock()
            mock_client.ping = AsyncMock(
                side_effect=RedisConnError("Connection refused")
            )
            mock_client.aclose = AsyncMock()
            mock_redis_class.return_value = mock_client
            mock_pool.from_url.return_value = MagicMock()

            with pytest.raises(RedisConnectionError):
                await service.connect()

            # Should have called aclose to clean up
            mock_client.aclose.assert_called_once()

    # -------------------------------------------------------------------------
    # MEDIUM-1: keys() uses SCAN not KEYS
    # -------------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_keys_uses_scan(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test that keys() uses SCAN instead of KEYS."""
        mock_redis.scan = AsyncMock(
            return_value=(0, ["dv:cache:key1", "dv:cache:key2"])
        )

        result = await service.keys("*", RedisNamespace.CACHE)

        mock_redis.scan.assert_called()
        # Ensure KEYS was not used (mock doesn't have keys attribute set up for call)
        assert result == ["key1", "key2"]

    @pytest.mark.asyncio
    async def test_keys_scan_multiple_batches(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test that keys() handles multiple SCAN batches."""
        # First call returns cursor 1 (more data), second returns 0 (done)
        mock_redis.scan = AsyncMock(
            side_effect=[
                (1, ["dv:cache:key1"]),
                (0, ["dv:cache:key2"]),
            ]
        )

        result = await service.keys("*", RedisNamespace.CACHE)

        assert mock_redis.scan.call_count == 2
        assert result == ["key1", "key2"]

    @pytest.mark.asyncio
    async def test_keys_scan_iteration_limit(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test that keys() has iteration safety limit."""
        # Return non-zero cursor to force iteration limit
        mock_redis.scan = AsyncMock(return_value=(1, ["dv:cache:key"]))

        with pytest.raises(RedisKeyError, match="exceeded"):
            await service.keys("*", RedisNamespace.CACHE)

        # Should have hit the iteration limit
        assert mock_redis.scan.call_count == MAX_SCAN_ITERATIONS

    # -------------------------------------------------------------------------
    # MEDIUM-2: cache_invalidate_pattern uses pipeline
    # -------------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_cache_invalidate_uses_pipeline(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test that cache_invalidate_pattern uses pipeline."""
        mock_redis.scan = AsyncMock(return_value=(0, ["dv:cache:k1", "dv:cache:k2"]))

        # Create mock pipeline context manager
        mock_pipe = AsyncMock()
        mock_pipe.delete = MagicMock()
        mock_pipe.execute = AsyncMock(return_value=[1, 1])

        mock_pipeline_cm = AsyncMock()
        mock_pipeline_cm.__aenter__ = AsyncMock(return_value=mock_pipe)
        mock_pipeline_cm.__aexit__ = AsyncMock(return_value=None)
        mock_redis.pipeline = MagicMock(return_value=mock_pipeline_cm)

        count = await service.cache_invalidate_pattern("*")

        assert count == 2
        mock_redis.pipeline.assert_called_once_with(transaction=False)

    @pytest.mark.asyncio
    async def test_cache_invalidate_empty_pattern(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache_invalidate_pattern returns 0 for no matches."""
        mock_redis.scan = AsyncMock(return_value=(0, []))

        count = await service.cache_invalidate_pattern("nonexistent:*")

        assert count == 0

    @pytest.mark.asyncio
    async def test_cache_invalidate_partial_delete(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test cache_invalidate_pattern counts only successful deletes."""
        mock_redis.scan = AsyncMock(
            return_value=(0, ["dv:cache:k1", "dv:cache:k2", "dv:cache:k3"])
        )

        # Create mock pipeline - one key not found (returns 0)
        mock_pipe = AsyncMock()
        mock_pipe.delete = MagicMock()
        mock_pipe.execute = AsyncMock(return_value=[1, 0, 1])

        mock_pipeline_cm = AsyncMock()
        mock_pipeline_cm.__aenter__ = AsyncMock(return_value=mock_pipe)
        mock_pipeline_cm.__aexit__ = AsyncMock(return_value=None)
        mock_redis.pipeline = MagicMock(return_value=mock_pipeline_cm)

        count = await service.cache_invalidate_pattern("*")

        # Only 2 keys were actually deleted
        assert count == 2

    # -------------------------------------------------------------------------
    # LOW-1: get_counter ValueError handling
    # -------------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_counter_invalid_value(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get_counter raises on non-integer value."""
        mock_redis.get = AsyncMock(return_value="not_a_number")

        with pytest.raises(RedisKeyError, match="invalid value"):
            await service.get_counter("bad_counter", RedisNamespace.RATE_LIMIT)

    @pytest.mark.asyncio
    async def test_get_counter_empty_string(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get_counter raises on empty string value."""
        mock_redis.get = AsyncMock(return_value="")

        with pytest.raises(RedisKeyError, match="invalid value"):
            await service.get_counter("empty_counter", RedisNamespace.RATE_LIMIT)

    @pytest.mark.asyncio
    async def test_get_counter_float_string(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get_counter raises on float string value."""
        mock_redis.get = AsyncMock(return_value="3.14")

        with pytest.raises(RedisKeyError, match="invalid value"):
            await service.get_counter("float_counter", RedisNamespace.RATE_LIMIT)

    @pytest.mark.asyncio
    async def test_get_counter_valid_value(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get_counter works with valid integer string."""
        mock_redis.get = AsyncMock(return_value="42")

        result = await service.get_counter("valid_counter", RedisNamespace.RATE_LIMIT)

        assert result == 42

    @pytest.mark.asyncio
    async def test_get_counter_negative_value(
        self, service: RedisService, mock_redis: AsyncMock
    ) -> None:
        """Test get_counter works with negative integer string."""
        mock_redis.get = AsyncMock(return_value="-10")

        result = await service.get_counter(
            "negative_counter", RedisNamespace.RATE_LIMIT
        )

        assert result == -10
