"""Tests for Agent Options Builder.

This module contains tests for the AgentOptionsBuilder class
that creates options for Claude Agent SDK queries.
"""

from datetime import UTC, datetime
from unittest.mock import MagicMock, patch

import pytest
from digital_valerii_shared.agent.core import (
    AgentOptionsBuilder,
    ConversationContext,
    InterfaceType,
    MCPServerConfig,
)
from digital_valerii_shared.agent.personality import (
    ConversationMode,
    MemoryReference,
    PersonalityManager,
)


@pytest.fixture
def personality_manager() -> PersonalityManager:
    """Create a PersonalityManager instance."""
    return PersonalityManager()


@pytest.fixture
def mock_memory_hooks() -> MagicMock:
    """Create mock memory hooks."""
    hooks = MagicMock()
    hooks.get_hook_config.return_value = {"SessionStart": {}, "Stop": {}}
    return hooks


@pytest.fixture
def options_builder(personality_manager: PersonalityManager) -> AgentOptionsBuilder:
    """Create AgentOptionsBuilder without hooks."""
    return AgentOptionsBuilder(personality_manager)


@pytest.fixture
def options_builder_with_hooks(
    personality_manager: PersonalityManager,
    mock_memory_hooks: MagicMock,
) -> AgentOptionsBuilder:
    """Create AgentOptionsBuilder with hooks."""
    return AgentOptionsBuilder(personality_manager, mock_memory_hooks)


class TestAgentOptionsBuilderInit:
    """Tests for AgentOptionsBuilder initialization."""

    def test_init_minimal(self, personality_manager: PersonalityManager) -> None:
        """Test minimal initialization."""
        builder = AgentOptionsBuilder(personality_manager)
        assert builder.personality == personality_manager
        assert builder.memory_hooks is None

    def test_init_with_hooks(
        self,
        personality_manager: PersonalityManager,
        mock_memory_hooks: MagicMock,
    ) -> None:
        """Test initialization with hooks."""
        builder = AgentOptionsBuilder(personality_manager, mock_memory_hooks)
        assert builder.memory_hooks == mock_memory_hooks


class TestBuildOptions:
    """Tests for build method."""

    def test_build_default_options(self, options_builder: AgentOptionsBuilder) -> None:
        """Test building options with defaults."""
        context = ConversationContext()

        options = options_builder.build(context)

        assert "system_prompt" in options
        assert "allowed_tools" in options
        assert options["allowed_tools"] == AgentOptionsBuilder.DEFAULT_TOOLS
        assert "hooks" not in options  # No hooks provided

    def test_build_with_custom_tools(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test building options with custom tools."""
        context = ConversationContext()
        custom_tools = ["Read", "Bash"]

        options = options_builder.build(context, allowed_tools=custom_tools)

        assert options["allowed_tools"] == custom_tools

    def test_build_with_hooks(
        self, options_builder_with_hooks: AgentOptionsBuilder
    ) -> None:
        """Test building options with hooks."""
        context = ConversationContext()

        options = options_builder_with_hooks.build(context)

        assert "hooks" in options

    def test_build_with_session_resume(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test building options with session resume."""
        context = ConversationContext(session_id="session-123")

        options = options_builder.build(context)

        assert options["resume"] == "session-123"

    def test_build_without_session_resume(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test building options without session resume."""
        context = ConversationContext()

        options = options_builder.build(context)

        assert "resume" not in options

    def test_build_with_subagents(self, options_builder: AgentOptionsBuilder) -> None:
        """Test building options with subagents."""
        context = ConversationContext()

        options = options_builder.build(context, include_subagents=True)

        assert "agents" in options
        assert "memory-search" in options["agents"]
        assert "assessment-helper" in options["agents"]

    def test_build_with_memories(self, options_builder: AgentOptionsBuilder) -> None:
        """Test building options with memories."""
        context = ConversationContext()
        memories = [
            MemoryReference(
                content="Important memory",
                timestamp=datetime.now(tz=UTC),
                relevance=0.9,
            ),
        ]

        options = options_builder.build(context, memories=memories)

        # Memories should be injected into system prompt
        assert "system_prompt" in options


class TestBuildSystemPrompt:
    """Tests for build_system_prompt method."""

    def test_build_system_prompt(self, options_builder: AgentOptionsBuilder) -> None:
        """Test building just the system prompt."""
        context = ConversationContext()

        prompt = options_builder.build_system_prompt(context)

        assert isinstance(prompt, str)
        assert len(prompt) > 0

    def test_build_system_prompt_with_memories(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test building system prompt with memories."""
        context = ConversationContext()
        memories = [
            MemoryReference(
                content="Past conversation",
                timestamp=datetime.now(tz=UTC),
                relevance=0.8,
            ),
        ]

        prompt = options_builder.build_system_prompt(context, memories)

        assert isinstance(prompt, str)


class TestModeMapping:
    """Tests for interface to mode mapping."""

    def test_cli_maps_to_consulting(self, options_builder: AgentOptionsBuilder) -> None:
        """Test CLI maps to CONSULTING mode."""
        mode = options_builder._get_mode(InterfaceType.CLI)
        assert mode == ConversationMode.CONSULTING

    def test_web_maps_to_consulting(self, options_builder: AgentOptionsBuilder) -> None:
        """Test WEB maps to CONSULTING mode."""
        mode = options_builder._get_mode(InterfaceType.WEB)
        assert mode == ConversationMode.CONSULTING

    def test_slack_maps_to_casual(self, options_builder: AgentOptionsBuilder) -> None:
        """Test SLACK maps to CASUAL mode."""
        mode = options_builder._get_mode(InterfaceType.SLACK)
        assert mode == ConversationMode.CASUAL

    def test_meeting_maps_to_meeting(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test MEETING maps to MEETING mode."""
        mode = options_builder._get_mode(InterfaceType.MEETING)
        assert mode == ConversationMode.MEETING

    def test_api_maps_to_technical(self, options_builder: AgentOptionsBuilder) -> None:
        """Test API maps to TECHNICAL mode."""
        mode = options_builder._get_mode(InterfaceType.API)
        assert mode == ConversationMode.TECHNICAL


class TestToolLists:
    """Tests for tool list methods."""

    def test_get_default_tools(self, options_builder: AgentOptionsBuilder) -> None:
        """Test getting default tools."""
        tools = options_builder.get_default_tools()

        assert "Read" in tools
        assert "Glob" in tools
        assert "Grep" in tools
        assert "WebSearch" in tools
        assert "WebFetch" in tools

    def test_get_approval_tools(self, options_builder: AgentOptionsBuilder) -> None:
        """Test getting approval-required tools."""
        tools = options_builder.get_approval_tools()

        assert "Bash" in tools
        assert "Write" in tools
        assert "Edit" in tools

    def test_default_tools_not_mutated(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test that getting tools returns a copy."""
        tools1 = options_builder.get_default_tools()
        tools1.append("CustomTool")

        tools2 = options_builder.get_default_tools()
        assert "CustomTool" not in tools2


class TestSubagentDefinitions:
    """Tests for subagent definitions."""

    def test_get_subagent_definitions(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test getting subagent definitions."""
        definitions = options_builder._get_subagent_definitions()

        assert "memory-search" in definitions
        assert "assessment-helper" in definitions

    def test_memory_search_subagent(self, options_builder: AgentOptionsBuilder) -> None:
        """Test memory-search subagent definition."""
        definitions = options_builder._get_subagent_definitions()
        memory_search = definitions["memory-search"]

        assert "description" in memory_search
        assert "prompt" in memory_search
        assert "tools" in memory_search
        assert "Read" in memory_search["tools"]

    def test_assessment_helper_subagent(
        self, options_builder: AgentOptionsBuilder
    ) -> None:
        """Test assessment-helper subagent definition."""
        definitions = options_builder._get_subagent_definitions()
        assessment = definitions["assessment-helper"]

        assert "description" in assessment
        assert "WebSearch" in assessment["tools"]


# =============================================================================
# MCP Server Config Tests
# =============================================================================


class TestMCPServerConfig:
    """Tests for MCPServerConfig class."""

    def test_default_config(self) -> None:
        """Test default configuration."""
        config = MCPServerConfig()

        assert config.enable_memory is True
        assert config.enable_browser is False
        assert config.enable_local_office is False

    def test_custom_config(self) -> None:
        """Test custom configuration."""
        config = MCPServerConfig(
            enable_memory=False,
            enable_browser=True,
            enable_local_office=True,
        )

        assert config.enable_memory is False
        assert config.enable_browser is True
        assert config.enable_local_office is True

    def test_build_server_list_memory_only(self) -> None:
        """Test building server list with memory only."""
        config = MCPServerConfig(enable_memory=True)
        servers = config.build_server_list()

        assert len(servers) == 1
        assert servers[0]["name"] == "memory_mcp"

    def test_build_server_list_with_browser(self) -> None:
        """Test building server list with browser."""
        config = MCPServerConfig(enable_memory=True, enable_browser=True)
        servers = config.build_server_list()

        assert len(servers) == 2
        server_names = [s["name"] for s in servers]
        assert "memory_mcp" in server_names
        assert "playwright" in server_names

    def test_build_server_list_empty(self) -> None:
        """Test building empty server list."""
        config = MCPServerConfig(enable_memory=False)
        servers = config.build_server_list()

        assert servers == []

    def test_memory_mcp_config(self) -> None:
        """Test memory MCP configuration details."""
        config = MCPServerConfig(enable_memory=True)
        servers = config.build_server_list()

        memory_server = servers[0]
        assert memory_server["name"] == "memory_mcp"
        assert memory_server["command"] == "python"
        assert "-m" in memory_server["args"]
        assert "digital_valerii_shared.mcp.memory_server" in memory_server["args"]
        assert "env" in memory_server

    def test_playwright_mcp_config(self) -> None:
        """Test Playwright MCP configuration details."""
        config = MCPServerConfig(enable_browser=True, enable_memory=False)
        servers = config.build_server_list()

        playwright_server = servers[0]
        assert playwright_server["name"] == "playwright"
        assert playwright_server["command"] == "npx"
        assert "@playwright/mcp@latest" in playwright_server["args"]

    @patch("digital_valerii_shared.agent.core.options.sys.platform", "darwin")
    def test_office_mcp_on_macos(self) -> None:
        """Test Office MCP is included on macOS."""
        config = MCPServerConfig(
            enable_memory=False,
            enable_local_office=True,
        )
        servers = config.build_server_list()

        assert len(servers) == 1
        assert servers[0]["name"] == "office"

    @patch("digital_valerii_shared.agent.core.options.sys.platform", "linux")
    def test_office_mcp_not_on_linux(self) -> None:
        """Test Office MCP is not included on Linux."""
        config = MCPServerConfig(
            enable_memory=False,
            enable_local_office=True,
        )
        servers = config.build_server_list()

        assert servers == []

    @patch("digital_valerii_shared.agent.core.options.sys.platform", "win32")
    def test_office_mcp_not_on_windows(self) -> None:
        """Test Office MCP is not included on Windows."""
        config = MCPServerConfig(
            enable_memory=False,
            enable_local_office=True,
        )
        servers = config.build_server_list()

        assert servers == []


class TestAgentOptionsBuilderMCP:
    """Tests for MCP integration in AgentOptionsBuilder."""

    def test_init_default_mcp_config(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that default MCP config is created."""
        builder = AgentOptionsBuilder(personality_manager)

        assert builder.mcp_config is not None
        assert isinstance(builder.mcp_config, MCPServerConfig)

    def test_init_custom_mcp_config(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test initialization with custom MCP config."""
        mcp_config = MCPServerConfig(enable_browser=True)
        builder = AgentOptionsBuilder(personality_manager, mcp_config=mcp_config)

        assert builder.mcp_config == mcp_config
        assert builder.mcp_config.enable_browser is True

    def test_build_includes_mcp_servers(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that build includes MCP servers by default."""
        builder = AgentOptionsBuilder(personality_manager)
        context = ConversationContext()

        options = builder.build(context)

        assert "mcp_servers" in options
        assert len(options["mcp_servers"]) == 1  # memory only by default

    def test_build_excludes_mcp_servers(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that build can exclude MCP servers."""
        builder = AgentOptionsBuilder(personality_manager)
        context = ConversationContext()

        options = builder.build(context, include_mcp_servers=False)

        assert "mcp_servers" not in options

    def test_build_empty_mcp_servers_not_included(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that empty MCP server list is not included."""
        mcp_config = MCPServerConfig(enable_memory=False)
        builder = AgentOptionsBuilder(personality_manager, mcp_config=mcp_config)
        context = ConversationContext()

        options = builder.build(context)

        assert "mcp_servers" not in options

    def test_get_mcp_servers(self, personality_manager: PersonalityManager) -> None:
        """Test get_mcp_servers method."""
        mcp_config = MCPServerConfig(enable_memory=True, enable_browser=True)
        builder = AgentOptionsBuilder(personality_manager, mcp_config=mcp_config)

        servers = builder.get_mcp_servers()

        assert len(servers) == 2
        server_names = [s["name"] for s in servers]
        assert "memory_mcp" in server_names
        assert "playwright" in server_names
