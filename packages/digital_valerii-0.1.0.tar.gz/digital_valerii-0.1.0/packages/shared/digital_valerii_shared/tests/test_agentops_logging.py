"""Tests for AgentOps structured logging.

Component 6.5: AgentOps Framework
"""

import json
from collections.abc import Generator

import pytest
import structlog
from digital_valerii_shared.agentops.logging import (
    bind_context,
    clear_context,
    configure_logging,
    get_logger,
    unbind_context,
)


class TestConfigureLogging:
    """Tests for configure_logging function."""

    @pytest.fixture(autouse=True)
    def reset_structlog(self) -> Generator[None, None, None]:
        """Reset structlog configuration after each test."""
        yield
        # Reset to defaults
        structlog.reset_defaults()
        clear_context()

    def test_configure_json_format(self, capsys: pytest.CaptureFixture) -> None:
        """Test configure_logging with JSON format."""
        configure_logging(json_format=True, log_level="INFO")
        logger = get_logger("test")

        logger.info("test message", key="value")

        captured = capsys.readouterr()
        # Should be valid JSON
        log_entry = json.loads(captured.out.strip())
        assert log_entry["event"] == "test message"
        assert log_entry["key"] == "value"
        assert "timestamp" in log_entry
        assert log_entry["level"] == "info"

    def test_configure_console_format(self, capsys: pytest.CaptureFixture) -> None:
        """Test configure_logging with console format."""
        configure_logging(json_format=False, log_level="INFO")
        logger = get_logger("test")

        logger.info("test message")

        captured = capsys.readouterr()
        # Console format is human-readable
        assert "test message" in captured.out

    def test_configure_log_level_filters(self, capsys: pytest.CaptureFixture) -> None:
        """Test log level filtering."""
        configure_logging(json_format=True, log_level="WARNING")
        logger = get_logger("test")

        logger.info("should not appear")
        logger.warning("should appear")

        captured = capsys.readouterr()
        assert "should not appear" not in captured.out
        assert "should appear" in captured.out

    def test_configure_debug_level(self, capsys: pytest.CaptureFixture) -> None:
        """Test DEBUG level captures all messages."""
        configure_logging(json_format=True, log_level="DEBUG")
        logger = get_logger("test")

        logger.debug("debug message")
        logger.info("info message")

        captured = capsys.readouterr()
        assert "debug message" in captured.out
        assert "info message" in captured.out


class TestGetLogger:
    """Tests for get_logger function."""

    @pytest.fixture(autouse=True)
    def reset_structlog(self) -> Generator[None, None, None]:
        """Reset structlog configuration after each test."""
        configure_logging(json_format=True, log_level="INFO")
        yield
        structlog.reset_defaults()
        clear_context()

    def test_returns_bound_logger(self) -> None:
        """Test get_logger returns a BoundLogger."""
        logger = get_logger("my.module")
        # BoundLogger has these standard methods
        assert hasattr(logger, "info")
        assert hasattr(logger, "warning")
        assert hasattr(logger, "error")
        assert hasattr(logger, "debug")

    def test_logger_with_name(self, capsys: pytest.CaptureFixture) -> None:
        """Test logger includes the module name."""
        logger = get_logger("my.module.name")
        logger.info("test")

        # Just verify the logger works without errors
        _ = capsys.readouterr()


class TestContextBinding:
    """Tests for context binding functions."""

    @pytest.fixture(autouse=True)
    def reset_context(self) -> Generator[None, None, None]:
        """Clear context before and after each test."""
        clear_context()
        configure_logging(json_format=True, log_level="INFO")
        yield
        clear_context()
        structlog.reset_defaults()

    def test_bind_context_adds_fields(self, capsys: pytest.CaptureFixture) -> None:
        """Test bind_context adds fields to log output."""
        logger = get_logger("test")

        bind_context(user_id="123", session_id="abc")
        logger.info("user action")

        captured = capsys.readouterr()
        log_entry = json.loads(captured.out.strip())
        assert log_entry["user_id"] == "123"
        assert log_entry["session_id"] == "abc"

    def test_bind_context_multiple_calls(self, capsys: pytest.CaptureFixture) -> None:
        """Test multiple bind_context calls accumulate."""
        logger = get_logger("test")

        bind_context(first="1")
        bind_context(second="2")
        logger.info("test")

        captured = capsys.readouterr()
        log_entry = json.loads(captured.out.strip())
        assert log_entry["first"] == "1"
        assert log_entry["second"] == "2"

    def test_unbind_context_removes_keys(self, capsys: pytest.CaptureFixture) -> None:
        """Test unbind_context removes specific keys."""
        logger = get_logger("test")

        bind_context(keep="yes", remove="no")
        unbind_context("remove")
        logger.info("test")

        captured = capsys.readouterr()
        log_entry = json.loads(captured.out.strip())
        assert log_entry["keep"] == "yes"
        assert "remove" not in log_entry

    def test_clear_context_removes_all(self, capsys: pytest.CaptureFixture) -> None:
        """Test clear_context removes all bound context."""
        logger = get_logger("test")

        bind_context(first="1", second="2")
        clear_context()
        logger.info("test")

        captured = capsys.readouterr()
        log_entry = json.loads(captured.out.strip())
        assert "first" not in log_entry
        assert "second" not in log_entry


class TestLogLevels:
    """Tests for different log levels."""

    @pytest.fixture(autouse=True)
    def setup_logging(self) -> Generator[None, None, None]:
        """Configure logging for tests."""
        configure_logging(json_format=True, log_level="DEBUG")
        yield
        structlog.reset_defaults()

    def test_all_levels_work(self, capsys: pytest.CaptureFixture) -> None:
        """Test all log levels produce output."""
        logger = get_logger("test")

        logger.debug("debug")
        logger.info("info")
        logger.warning("warning")
        logger.error("error")

        captured = capsys.readouterr()
        assert "debug" in captured.out
        assert "info" in captured.out
        assert "warning" in captured.out
        assert "error" in captured.out
