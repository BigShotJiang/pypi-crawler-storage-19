"""Tests for License crypto and verification.

Component 4.10: Licensing & Protection System
"""

from datetime import UTC, datetime, timedelta

import pytest
from digital_valerii_shared.licensing.crypto import (
    decode_key,
    decode_signature,
    encode_key,
    encode_signature,
    generate_keypair,
    sign_data,
    verify_signature,
)
from digital_valerii_shared.licensing.exceptions import (
    LicenseExpiredError,
)
from digital_valerii_shared.licensing.license import License
from digital_valerii_shared.licensing.verification import (
    check_license_features,
    check_license_tier,
    get_current_month,
    sign_license,
    sign_monthly,
    validate_license,
    verify_license_signature,
    verify_monthly_activation,
)

# ============================================================================
# Crypto Tests
# ============================================================================


class TestCrypto:
    """Tests for crypto operations."""

    @pytest.fixture
    def keypair(self):
        """Generate keypair for testing."""
        try:
            return generate_keypair()
        except Exception:
            pytest.skip("PyNaCl not installed")

    def test_generate_keypair(self, keypair):
        """Test keypair generation."""
        public_key, private_key = keypair
        assert len(public_key) == 32  # Ed25519 public key
        assert len(private_key) == 32  # Ed25519 seed

    def test_sign_and_verify(self, keypair):
        """Test signing and verifying data."""
        public_key, private_key = keypair
        data = b"test data to sign"

        signature = sign_data(data, private_key)
        assert len(signature) == 64  # Ed25519 signature

        is_valid = verify_signature(data, signature, public_key)
        assert is_valid is True

    def test_verify_invalid_signature(self, keypair):
        """Test that invalid signatures are rejected."""
        public_key, private_key = keypair
        data = b"test data to sign"
        wrong_data = b"different data"

        signature = sign_data(data, private_key)
        is_valid = verify_signature(wrong_data, signature, public_key)
        assert is_valid is False

    def test_verify_wrong_key(self, keypair):
        """Test verification with wrong key fails."""
        _, private_key = keypair
        public_key2, _ = generate_keypair()

        data = b"test data"
        signature = sign_data(data, private_key)

        # Verify with different public key should fail
        is_valid = verify_signature(data, signature, public_key2)
        assert is_valid is False

    def test_key_encoding(self, keypair):
        """Test key encoding and decoding."""
        public_key, private_key = keypair

        # Encode and decode public key
        encoded = encode_key(public_key)
        assert isinstance(encoded, str)
        decoded = decode_key(encoded)
        assert decoded == public_key

        # Encode and decode private key
        encoded_priv = encode_key(private_key)
        decoded_priv = decode_key(encoded_priv)
        assert decoded_priv == private_key

    def test_signature_encoding(self, keypair):
        """Test signature encoding and decoding."""
        _, private_key = keypair
        data = b"test"

        signature = sign_data(data, private_key)
        encoded = encode_signature(signature)
        assert isinstance(encoded, str)

        decoded = decode_signature(encoded)
        assert decoded == signature


# ============================================================================
# License Tests
# ============================================================================


class TestLicense:
    """Tests for License dataclass."""

    def test_create_license(self):
        """Test creating a new license."""
        expires_at = datetime.now(UTC) + timedelta(days=365)
        license = License.create(
            client_id="test-client",
            client_name="Test Client",
            expires_at=expires_at,
            tier="professional",
            worker_count=10,
            features=["basic", "api"],
        )

        assert license.client_id == "test-client"
        assert license.tier == "professional"
        assert license.worker_count == 10
        assert "basic" in license.features

    def test_license_is_valid(self):
        """Test license validity check."""
        expires_at = datetime.now(UTC) + timedelta(days=30)
        license = License.create(
            client_id="test",
            client_name="Test",
            expires_at=expires_at,
        )

        assert license.is_valid is True
        assert license.is_expired is False

    def test_license_expired(self):
        """Test expired license detection."""
        expires_at = datetime.now(UTC) - timedelta(days=30)
        license = License.create(
            client_id="test",
            client_name="Test",
            expires_at=expires_at,
            grace_period_days=14,
        )

        assert license.is_valid is False
        assert license.is_expired is True

    def test_license_serialization(self):
        """Test license JSON serialization."""
        expires_at = datetime.now(UTC) + timedelta(days=30)
        license = License.create(
            client_id="test-client",
            client_name="Test Client",
            expires_at=expires_at,
            features=["basic"],
        )

        # Convert to JSON and back
        json_str = license.to_json()
        restored = License.from_json(json_str)

        assert restored.client_id == license.client_id
        assert restored.license_id == license.license_id
        assert restored.features == license.features


# ============================================================================
# Verification Tests
# ============================================================================


class TestVerification:
    """Tests for verification functions."""

    @pytest.fixture
    def keypair(self):
        """Generate keypair for testing."""
        try:
            return generate_keypair()
        except Exception:
            pytest.skip("PyNaCl not installed")

    @pytest.fixture
    def valid_license(self):
        """Create valid license for testing."""
        expires_at = datetime.now(UTC) + timedelta(days=365)
        return License.create(
            client_id="test-client",
            client_name="Test Client",
            expires_at=expires_at,
            tier="professional",
            features=["basic", "api", "analytics"],
        )

    def test_sign_license(self, keypair, valid_license):
        """Test signing a license."""
        public_key, private_key = keypair

        signed = sign_license(valid_license, private_key)
        assert signed.signature != b""
        assert len(signed.signature) == 64

    def test_verify_license_signature(self, keypair, valid_license):
        """Test verifying license signature."""
        public_key, private_key = keypair

        sign_license(valid_license, private_key)
        is_valid = verify_license_signature(valid_license, public_key)
        assert is_valid is True

    def test_verify_unsigned_license(self, keypair, valid_license):
        """Test verifying unsigned license fails."""
        public_key, _ = keypair

        # No signature
        is_valid = verify_license_signature(valid_license, public_key)
        assert is_valid is False

    def test_sign_monthly(self, keypair):
        """Test monthly activation signing."""
        _, private_key = keypair
        month = "2025-01"

        signature = sign_monthly(month, private_key)
        assert len(signature) == 64

    def test_verify_monthly_activation(self, keypair):
        """Test monthly activation verification."""
        public_key, private_key = keypair
        month = "2025-01"

        signature = sign_monthly(month, private_key)
        is_valid = verify_monthly_activation(month, signature, public_key)
        assert is_valid is True

    def test_validate_license_complete(self, keypair, valid_license):
        """Test complete license validation."""
        public_key, private_key = keypair

        sign_license(valid_license, private_key)

        # Should not raise
        validate_license(valid_license, public_key, check_monthly=False)

    def test_validate_expired_license(self, keypair):
        """Test validation rejects expired license."""
        public_key, private_key = keypair
        expires_at = datetime.now(UTC) - timedelta(days=30)

        license = License.create(
            client_id="test",
            client_name="Test",
            expires_at=expires_at,
            grace_period_days=14,
        )
        sign_license(license, private_key)

        with pytest.raises(LicenseExpiredError):
            validate_license(license, public_key, check_monthly=False)

    def test_get_current_month(self):
        """Test getting current month."""
        month = get_current_month()
        assert len(month) == 7  # YYYY-MM format
        assert month[4] == "-"

    def test_check_license_features(self, valid_license):
        """Test feature checking."""
        assert check_license_features(valid_license, ["basic"]) is True
        assert check_license_features(valid_license, ["basic", "api"]) is True
        assert check_license_features(valid_license, ["nonexistent"]) is False

    def test_check_license_tier(self, valid_license):
        """Test tier checking."""
        assert check_license_tier(valid_license, "starter") is True
        assert check_license_tier(valid_license, "standard") is True
        assert check_license_tier(valid_license, "professional") is True
        assert check_license_tier(valid_license, "enterprise") is False
