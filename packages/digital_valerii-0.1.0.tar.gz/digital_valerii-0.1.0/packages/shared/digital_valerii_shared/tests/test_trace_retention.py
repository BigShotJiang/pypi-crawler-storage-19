"""Tests for trace retention policy and service.

Component 6.5: AgentOps Framework
"""

from datetime import UTC, datetime, timedelta
from unittest.mock import patch
from uuid import uuid4

import pytest
from digital_valerii_shared.agentops.retention import (
    RetentionPolicy,
    TraceCategory,
    TraceRetentionService,
)


class MockTraceRetentionStore:
    """Mock store for testing retention service."""

    def __init__(self, expired_count: int = 0, user_count: int = 0):
        self.expired_count = expired_count
        self.user_count = user_count
        self.delete_expired_called = False
        self.delete_by_user_called = False
        self.deleted_user_id = None

    async def delete_expired(self) -> int:
        self.delete_expired_called = True
        return self.expired_count

    async def delete_by_user(self, user_id) -> int:
        self.delete_by_user_called = True
        self.deleted_user_id = user_id
        return self.user_count


class TestTraceCategory:
    """Tests for TraceCategory enum."""

    def test_enum_values(self) -> None:
        """Test all enum values exist."""
        assert TraceCategory.NORMAL.value == "normal"
        assert TraceCategory.SAFETY_VIOLATION.value == "safety_violation"
        assert TraceCategory.ERROR.value == "error"

    def test_string_inheritance(self) -> None:
        """Test enum inherits from str."""
        assert isinstance(TraceCategory.NORMAL, str)
        assert TraceCategory.NORMAL == "normal"


class TestRetentionPolicy:
    """Tests for RetentionPolicy."""

    @pytest.fixture
    def policy(self) -> RetentionPolicy:
        """Create policy instance."""
        return RetentionPolicy()

    def test_get_retention_days_normal(self, policy: RetentionPolicy) -> None:
        """Test retention days for normal traces."""
        days = policy.get_retention_days(TraceCategory.NORMAL)
        assert days == 30

    def test_get_retention_days_error(self, policy: RetentionPolicy) -> None:
        """Test retention days for error traces."""
        days = policy.get_retention_days(TraceCategory.ERROR)
        assert days == 90

    def test_get_retention_days_safety(self, policy: RetentionPolicy) -> None:
        """Test retention days for safety violation traces."""
        days = policy.get_retention_days(TraceCategory.SAFETY_VIOLATION)
        assert days == 365

    def test_get_expiry_date_normal(self, policy: RetentionPolicy) -> None:
        """Test expiry date calculation for normal traces."""
        now = datetime.now(UTC)
        expiry = policy.get_expiry_date(TraceCategory.NORMAL)

        expected = now + timedelta(days=30)
        # Allow 1 second tolerance for test execution time
        assert abs((expiry - expected).total_seconds()) < 1

    def test_get_expiry_date_error(self, policy: RetentionPolicy) -> None:
        """Test expiry date calculation for error traces."""
        now = datetime.now(UTC)
        expiry = policy.get_expiry_date(TraceCategory.ERROR)

        expected = now + timedelta(days=90)
        assert abs((expiry - expected).total_seconds()) < 1

    def test_get_expiry_date_safety(self, policy: RetentionPolicy) -> None:
        """Test expiry date calculation for safety traces."""
        now = datetime.now(UTC)
        expiry = policy.get_expiry_date(TraceCategory.SAFETY_VIOLATION)

        expected = now + timedelta(days=365)
        assert abs((expiry - expected).total_seconds()) < 1

    def test_should_sample_development(self, policy: RetentionPolicy) -> None:
        """Test all traces sampled in development."""
        # Run multiple times to verify it's always True
        for _ in range(100):
            assert (
                policy.should_sample(is_error=False, environment="development") is True
            )
            assert (
                policy.should_sample(is_error=True, environment="development") is True
            )

    def test_should_sample_staging(self, policy: RetentionPolicy) -> None:
        """Test all traces sampled in staging."""
        for _ in range(100):
            assert policy.should_sample(is_error=False, environment="staging") is True
            assert policy.should_sample(is_error=True, environment="staging") is True

    def test_should_sample_errors_always(self, policy: RetentionPolicy) -> None:
        """Test errors are always sampled in production."""
        for _ in range(100):
            assert policy.should_sample(is_error=True, environment="production") is True

    def test_should_sample_production_rate(self, policy: RetentionPolicy) -> None:
        """Test production sampling rate is approximately 10%."""
        with patch("random.random") as mock_random:
            # First verify the logic
            mock_random.return_value = 0.05  # Below 0.10
            assert (
                policy.should_sample(is_error=False, environment="production") is True
            )

            mock_random.return_value = 0.15  # Above 0.10
            assert (
                policy.should_sample(is_error=False, environment="production") is False
            )

    def test_should_sample_production_actual_rate(
        self, policy: RetentionPolicy
    ) -> None:
        """Test actual sampling rate is roughly 10%."""
        samples = 0
        runs = 10000

        for _ in range(runs):
            if policy.should_sample(is_error=False, environment="production"):
                samples += 1

        rate = samples / runs
        # Should be around 10% with some tolerance
        assert 0.05 < rate < 0.15


class TestTraceRetentionService:
    """Tests for TraceRetentionService."""

    @pytest.fixture
    def store(self) -> MockTraceRetentionStore:
        """Create mock store."""
        return MockTraceRetentionStore(expired_count=10, user_count=5)

    @pytest.fixture
    def service(self, store: MockTraceRetentionStore) -> TraceRetentionService:
        """Create service with mock store."""
        return TraceRetentionService(store=store)

    @pytest.mark.asyncio
    async def test_cleanup_expired(
        self, service: TraceRetentionService, store: MockTraceRetentionStore
    ) -> None:
        """Test cleanup_expired calls store and returns count."""
        deleted = await service.cleanup_expired()

        assert store.delete_expired_called is True
        assert deleted == 10

    @pytest.mark.asyncio
    async def test_gdpr_delete(
        self, service: TraceRetentionService, store: MockTraceRetentionStore
    ) -> None:
        """Test gdpr_delete calls store with user ID."""
        user_id = uuid4()
        deleted = await service.gdpr_delete(user_id)

        assert store.delete_by_user_called is True
        assert store.deleted_user_id == user_id
        assert deleted == 5

    def test_policy_property(self, service: TraceRetentionService) -> None:
        """Test policy property returns current policy."""
        policy = service.policy
        assert isinstance(policy, RetentionPolicy)

    def test_custom_policy(self, store: MockTraceRetentionStore) -> None:
        """Test service with custom policy."""
        custom_policy = RetentionPolicy()
        custom_policy.NORMAL_RETENTION_DAYS = 7

        service = TraceRetentionService(store=store, policy=custom_policy)

        assert service.policy.NORMAL_RETENTION_DAYS == 7


class TestRetentionConstants:
    """Tests for retention policy constants."""

    def test_default_normal_retention(self) -> None:
        """Test default normal retention is 30 days."""
        assert RetentionPolicy.NORMAL_RETENTION_DAYS == 30

    def test_default_error_retention(self) -> None:
        """Test default error retention is 90 days."""
        assert RetentionPolicy.ERROR_RETENTION_DAYS == 90

    def test_default_safety_retention(self) -> None:
        """Test default safety retention is 365 days."""
        assert RetentionPolicy.SAFETY_RETENTION_DAYS == 365

    def test_default_production_sample_rate(self) -> None:
        """Test default production sample rate is 10%."""
        assert RetentionPolicy.PRODUCTION_SAMPLE_RATE == 0.10

    def test_error_sample_rate_is_full(self) -> None:
        """Test errors are always sampled (100%)."""
        assert RetentionPolicy.ERROR_SAMPLE_RATE == 1.00
