"""Tests for audit logging service."""

from datetime import UTC, date, datetime
from decimal import Decimal
from uuid import uuid4

import pytest

from packages.shared.digital_valerii_shared.config import DatabaseSettings
from packages.shared.digital_valerii_shared.database import IsolatedDatabase
from packages.shared.digital_valerii_shared.models.audit_log import AuditLog
from packages.shared.digital_valerii_shared.services.audit import (
    AuditService,
    _json_safe,
)


class TestAuditLogModel:
    """Tests for AuditLog model."""

    def test_tablename(self) -> None:
        """Test table name is correct."""
        assert AuditLog.__tablename__ == "audit_logs"

    def test_has_required_columns(self) -> None:
        """Test model has all required columns."""
        columns = {c.name for c in AuditLog.__table__.columns}
        required = {
            "id",
            "timestamp",
            "user_id",
            "action",
            "resource",
            "ip_address",
            "user_agent",
            "details",
            "created_at",
        }
        assert required.issubset(columns)

    def test_has_indexes(self) -> None:
        """Test model has required indexes."""
        index_names = {idx.name for idx in AuditLog.__table__.indexes}
        expected_indexes = {
            "ix_audit_logs_timestamp",
            "ix_audit_logs_user_timestamp",
            "ix_audit_logs_action",
            "ix_audit_logs_resource",
        }
        assert expected_indexes.issubset(index_names)


@pytest.mark.asyncio
class TestAuditService:
    """Tests for AuditService."""

    async def test_log_creates_entry(self) -> None:
        """Test log method creates audit entry."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log(
                action="test_action",
                resource="test:resource",
            )

            assert entry.id is not None
            assert entry.action == "test_action"
            assert entry.resource == "test:resource"
            assert entry.timestamp is not None

        await db.close()

    async def test_log_with_all_fields(self) -> None:
        """Test log method with all optional fields."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log(
                action="login",
                resource=f"user:{user_id}",
                user_id=user_id,
                ip_address="192.168.1.1",
                user_agent="Mozilla/5.0",
                details={"method": "password", "success": True},
            )

            assert entry.user_id == user_id
            assert entry.ip_address == "192.168.1.1"
            assert entry.user_agent == "Mozilla/5.0"
            assert entry.details == {"method": "password", "success": True}

        await db.close()

    async def test_log_entity_change_create(self) -> None:
        """Test log_entity_change for create action."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        entity_id = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_entity_change(
                action="create",
                entity_type="project",
                entity_id=entity_id,
            )

            assert entry.action == "create"
            assert entry.resource == f"project:{entity_id}"
            assert entry.details["entity_type"] == "project"

        await db.close()

    async def test_log_entity_change_update_with_changes(self) -> None:
        """Test log_entity_change for update with change tracking."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        entity_id = uuid4()
        user_id = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_entity_change(
                action="update",
                entity_type="person",
                entity_id=entity_id,
                user_id=user_id,
                changes={
                    "name": ("Old Name", "New Name"),
                    "email": ("old@test.com", "new@test.com"),
                },
            )

            assert entry.action == "update"
            assert entry.user_id == user_id
            assert entry.details["changes"]["name"]["old"] == "Old Name"
            assert entry.details["changes"]["name"]["new"] == "New Name"
            assert entry.details["changes"]["email"]["old"] == "old@test.com"
            assert entry.details["changes"]["email"]["new"] == "new@test.com"

        await db.close()

    async def test_log_tool_use(self) -> None:
        """Test log_tool_use for tool usage tracking."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_tool_use(
                tool_name="calendar",
                user_id=user_id,
                parameters={"date": "2024-12-31"},
                approved=True,
                result="success",
            )

            assert entry.action == "tool_use"
            assert entry.resource == "tool:calendar"
            assert entry.user_id == user_id
            assert entry.details["parameters"] == {"date": "2024-12-31"}
            assert entry.details["approved"] is True
            assert entry.details["result"] == "success"

        await db.close()

    async def test_log_tool_use_blocked(self) -> None:
        """Test log_tool_use for blocked tool usage."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_tool_use(
                tool_name="dangerous_action",
                approved=False,
                result="blocked",
            )

            assert entry.details["approved"] is False
            assert entry.details["result"] == "blocked"

        await db.close()

    async def test_timestamp_is_utc(self) -> None:
        """Test that timestamp is in UTC."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        before = datetime.now(UTC)

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log(
                action="test",
                resource="test:resource",
            )

            after = datetime.now(UTC)
            # Make timestamp offset-aware for comparison
            entry_time = entry.timestamp.replace(tzinfo=UTC)
            assert before <= entry_time <= after

        await db.close()


class TestJsonSafe:
    """Tests for _json_safe serialization helper."""

    def test_uuid_conversion(self) -> None:
        """Test UUID is converted to string."""
        test_uuid = uuid4()
        result = _json_safe(test_uuid)
        assert result == str(test_uuid)
        assert isinstance(result, str)

    def test_decimal_conversion(self) -> None:
        """Test Decimal is converted to string."""
        test_decimal = Decimal("123.456")
        result = _json_safe(test_decimal)
        assert result == "123.456"
        assert isinstance(result, str)

    def test_datetime_conversion(self) -> None:
        """Test datetime is converted to ISO format."""
        test_dt = datetime(2024, 12, 31, 12, 30, 45, tzinfo=UTC)
        result = _json_safe(test_dt)
        assert result == "2024-12-31T12:30:45+00:00"
        assert isinstance(result, str)

    def test_date_conversion(self) -> None:
        """Test date is converted to ISO format."""
        test_date = date(2024, 12, 31)
        result = _json_safe(test_date)
        assert result == "2024-12-31"
        assert isinstance(result, str)

    def test_list_conversion(self) -> None:
        """Test list elements are recursively converted."""
        test_uuid = uuid4()
        test_list = [test_uuid, "string", 123]
        result = _json_safe(test_list)
        assert result == [str(test_uuid), "string", 123]
        assert isinstance(result, list)

    def test_tuple_conversion(self) -> None:
        """Test tuple elements are converted to list."""
        test_uuid = uuid4()
        test_tuple = (test_uuid, "string")
        result = _json_safe(test_tuple)
        assert result == [str(test_uuid), "string"]
        assert isinstance(result, list)

    def test_dict_conversion(self) -> None:
        """Test dict values are recursively converted."""
        test_uuid = uuid4()
        test_dict = {"id": test_uuid, "value": 123}
        result = _json_safe(test_dict)
        assert result == {"id": str(test_uuid), "value": 123}
        assert isinstance(result, dict)

    def test_nested_structure(self) -> None:
        """Test deeply nested structures are converted."""
        test_uuid = uuid4()
        test_dt = datetime(2024, 12, 31, tzinfo=UTC)
        nested = {
            "items": [
                {"id": test_uuid, "date": test_dt},
                {"values": [Decimal("1.5"), Decimal("2.5")]},
            ]
        }
        result = _json_safe(nested)
        assert result["items"][0]["id"] == str(test_uuid)
        assert result["items"][0]["date"] == test_dt.isoformat()
        assert result["items"][1]["values"] == ["1.5", "2.5"]

    def test_primitives_unchanged(self) -> None:
        """Test primitive types are returned unchanged."""
        assert _json_safe("string") == "string"
        assert _json_safe(123) == 123
        assert _json_safe(123.456) == 123.456
        assert _json_safe(True) is True
        assert _json_safe(None) is None


@pytest.mark.asyncio
class TestJsonSafeIntegration:
    """Integration tests for _json_safe with log_entity_change."""

    async def test_log_entity_change_with_uuid(self) -> None:
        """Test log_entity_change correctly serializes UUID in changes."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        entity_id = uuid4()
        old_ref = uuid4()
        new_ref = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_entity_change(
                action="update",
                entity_type="event",
                entity_id=entity_id,
                changes={"project_id": (old_ref, new_ref)},
            )

            assert entry.details["changes"]["project_id"]["old"] == str(old_ref)
            assert entry.details["changes"]["project_id"]["new"] == str(new_ref)

        await db.close()

    async def test_log_entity_change_with_datetime(self) -> None:
        """Test log_entity_change correctly serializes datetime in changes."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        entity_id = uuid4()
        old_dt = datetime(2024, 1, 1, tzinfo=UTC)
        new_dt = datetime(2024, 12, 31, tzinfo=UTC)

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_entity_change(
                action="update",
                entity_type="project",
                entity_id=entity_id,
                changes={"end_date": (old_dt, new_dt)},
            )

            assert entry.details["changes"]["end_date"]["old"] == old_dt.isoformat()
            assert entry.details["changes"]["end_date"]["new"] == new_dt.isoformat()

        await db.close()

    async def test_log_entity_change_with_decimal(self) -> None:
        """Test log_entity_change correctly serializes Decimal in changes."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        entity_id = uuid4()

        async with db.session() as session:
            service = AuditService(session)
            entry = await service.log_entity_change(
                action="update",
                entity_type="event",
                entity_id=entity_id,
                changes={"importance": (Decimal("0.5"), Decimal("0.9"))},
            )

            assert entry.details["changes"]["importance"]["old"] == "0.5"
            assert entry.details["changes"]["importance"]["new"] == "0.9"

        await db.close()
