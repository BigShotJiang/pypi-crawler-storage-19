"""Tests for Qdrant vector database service."""

import contextlib
from datetime import date, datetime
from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from pydantic import ValidationError
from qdrant_client.http.exceptions import UnexpectedResponse

from packages.shared.digital_valerii_shared.config import QdrantSettings
from packages.shared.digital_valerii_shared.services.qdrant import (
    ALLOWED_FILTER_FIELDS,
    COLLECTION_CONFIGS,
    MAX_IN_LIST_SIZE,
    CollectionInfo,
    QdrantCollectionError,
    QdrantConnectionError,
    QdrantService,
    QdrantVectorError,
    SearchResult,
    VectorPoint,
    with_retry,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def settings() -> QdrantSettings:
    """Create test settings."""
    return QdrantSettings(
        url="http://localhost:6333",
        collection_prefix="test_",
    )


@pytest.fixture
def mock_client() -> AsyncMock:
    """Create a mock Qdrant client."""
    client = AsyncMock()
    client.get_collections = AsyncMock(return_value=MagicMock(collections=[]))
    client.create_collection = AsyncMock()
    client.create_payload_index = AsyncMock()
    client.upsert = AsyncMock()
    client.search = AsyncMock(return_value=[])
    client.delete = AsyncMock()
    client.retrieve = AsyncMock(return_value=[])
    client.get_collection = AsyncMock()
    client.delete_collection = AsyncMock()
    client.close = AsyncMock()
    return client


@pytest.fixture
def service(settings: QdrantSettings, mock_client: AsyncMock) -> QdrantService:
    """Create a QdrantService with mocked client."""
    svc = QdrantService(settings)
    svc._client = mock_client
    return svc


# =============================================================================
# Model Tests
# =============================================================================


class TestVectorPoint:
    """Tests for VectorPoint model."""

    def test_valid_vector_point(self) -> None:
        """Test creating a valid VectorPoint."""
        point = VectorPoint(
            id=uuid4(),
            vector=[0.1, 0.2, 0.3],
            payload={"key": "value"},
        )
        assert len(point.vector) == 3
        assert point.payload == {"key": "value"}

    def test_rejects_extra_fields(self) -> None:
        """Test that VectorPoint rejects unknown fields."""
        with pytest.raises(ValidationError):
            VectorPoint(
                id=uuid4(),
                vector=[0.1],
                payload={},
                extra_field="not allowed",
            )


class TestSearchResult:
    """Tests for SearchResult model."""

    def test_valid_search_result(self) -> None:
        """Test creating a valid SearchResult."""
        result = SearchResult(
            id=uuid4(),
            score=0.95,
            payload={"type": "meeting"},
        )
        assert result.score == 0.95
        assert result.payload["type"] == "meeting"

    def test_rejects_extra_fields(self) -> None:
        """Test that SearchResult rejects unknown fields."""
        with pytest.raises(ValidationError):
            SearchResult(
                id=uuid4(),
                score=0.5,
                payload={},
                unknown="field",
            )


class TestCollectionInfo:
    """Tests for CollectionInfo model."""

    def test_valid_collection_info(self) -> None:
        """Test creating a valid CollectionInfo."""
        info = CollectionInfo(
            name="memories",
            vectors_count=100,
            points_count=100,
        )
        assert info.name == "memories"
        assert info.vectors_count == 100


# =============================================================================
# QdrantService Unit Tests
# =============================================================================


class TestQdrantServiceInit:
    """Tests for QdrantService initialization."""

    def test_default_settings(self) -> None:
        """Test service creates with default settings."""
        service = QdrantService()
        assert service.settings.url == "http://localhost:6333"
        assert service.settings.collection_prefix == "dv_"

    def test_custom_settings(self, settings: QdrantSettings) -> None:
        """Test service accepts custom settings."""
        service = QdrantService(settings)
        assert service.settings.collection_prefix == "test_"

    def test_collection_name_prefix(self, service: QdrantService) -> None:
        """Test collection name includes prefix."""
        name = service._collection_name("memories")
        assert name == "test_memories"


class TestQdrantServiceInitialize:
    """Tests for collection initialization."""

    @pytest.mark.asyncio
    async def test_initialize_creates_collections(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test initialize creates all required collections."""
        await service.initialize()

        assert mock_client.create_collection.call_count == 3
        collection_names = [
            call.kwargs["collection_name"]
            for call in mock_client.create_collection.call_args_list
        ]
        assert "test_memories" in collection_names
        assert "test_lessons" in collection_names
        assert "test_conversations" in collection_names

    @pytest.mark.asyncio
    async def test_initialize_creates_indexes(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test initialize creates payload indexes."""
        await service.initialize()

        # Check that indexes were created
        assert mock_client.create_payload_index.call_count > 0

    @pytest.mark.asyncio
    async def test_initialize_skips_existing_collections(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test initialize doesn't recreate existing collections."""
        # Mock existing collection
        mock_client.get_collections.return_value = MagicMock(
            collections=[MagicMock(name="test_memories")]
        )

        await service.initialize()

        # Should only create 2 collections (lessons and conversations)
        assert mock_client.create_collection.call_count == 2

    @pytest.mark.asyncio
    async def test_initialize_idempotent(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test initialize only runs once."""
        await service.initialize()
        await service.initialize()

        # Should only create collections once
        assert mock_client.create_collection.call_count == 3

    @pytest.mark.asyncio
    async def test_initialize_connection_error(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test initialize raises QdrantConnectionError on connection failure."""
        mock_client.get_collections.side_effect = UnexpectedResponse(
            status_code=500, reason_phrase="Error", content=b""
        )

        with pytest.raises(QdrantConnectionError):
            await service.initialize()


class TestQdrantServiceUpsert:
    """Tests for upsert operations."""

    @pytest.mark.asyncio
    async def test_upsert_single_vector(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test upserting a single vector."""
        vector_id = uuid4()
        vector = [0.1] * 1536
        payload = {"type": "meeting", "importance": 0.8}

        await service.upsert("memories", vector_id, vector, payload)

        mock_client.upsert.assert_called_once()
        call_kwargs = mock_client.upsert.call_args.kwargs
        assert call_kwargs["collection_name"] == "test_memories"
        assert len(call_kwargs["points"]) == 1

    @pytest.mark.asyncio
    async def test_upsert_serializes_uuid_in_payload(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test that UUIDs in payload are serialized to strings."""
        vector_id = uuid4()
        related_id = uuid4()
        payload = {"related_id": related_id}

        await service.upsert("memories", vector_id, [0.1] * 10, payload)

        call_kwargs = mock_client.upsert.call_args.kwargs
        point = call_kwargs["points"][0]
        assert point.payload["related_id"] == str(related_id)

    @pytest.mark.asyncio
    async def test_upsert_error_handling(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test upsert raises QdrantVectorError on failure."""
        mock_client.upsert.side_effect = Exception("Upsert failed")

        with pytest.raises(QdrantVectorError):
            await service.upsert("memories", uuid4(), [0.1], {})


class TestQdrantServiceUpsertBatch:
    """Tests for batch upsert operations."""

    @pytest.mark.asyncio
    async def test_upsert_batch(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test upserting multiple vectors in a batch."""
        points = [
            VectorPoint(id=uuid4(), vector=[0.1] * 10, payload={"idx": i})
            for i in range(5)
        ]

        await service.upsert_batch("memories", points)

        mock_client.upsert.assert_called_once()
        call_kwargs = mock_client.upsert.call_args.kwargs
        assert len(call_kwargs["points"]) == 5

    @pytest.mark.asyncio
    async def test_upsert_batch_empty(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test upserting empty batch does nothing."""
        await service.upsert_batch("memories", [])
        mock_client.upsert.assert_not_called()


class TestQdrantServiceSearch:
    """Tests for search operations."""

    @pytest.mark.asyncio
    async def test_search_basic(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test basic vector search."""
        mock_result = MagicMock()
        mock_result.id = str(uuid4())
        mock_result.score = 0.95
        mock_result.payload = {"type": "meeting"}
        mock_client.search.return_value = [mock_result]

        results = await service.search("memories", [0.1] * 10, limit=5)

        assert len(results) == 1
        assert results[0].score == 0.95
        mock_client.search.assert_called_once()

    @pytest.mark.asyncio
    async def test_search_with_filter(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test search with filters."""
        mock_client.search.return_value = []

        await service.search(
            "memories",
            [0.1] * 10,
            filters={"type": "meeting"},
        )

        call_kwargs = mock_client.search.call_args.kwargs
        assert call_kwargs["query_filter"] is not None

    @pytest.mark.asyncio
    async def test_search_with_range_filter(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test search with range filter."""
        mock_client.search.return_value = []

        await service.search(
            "memories",
            [0.1] * 10,
            filters={"importance": {"$gte": 0.5, "$lte": 1.0}},
        )

        call_kwargs = mock_client.search.call_args.kwargs
        assert call_kwargs["query_filter"] is not None

    @pytest.mark.asyncio
    async def test_search_with_in_filter(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test search with $in filter."""
        mock_client.search.return_value = []

        await service.search(
            "memories",
            [0.1] * 10,
            filters={"type": {"$in": ["meeting", "email"]}},
        )

        call_kwargs = mock_client.search.call_args.kwargs
        assert call_kwargs["query_filter"] is not None

    @pytest.mark.asyncio
    async def test_search_error_handling(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test search raises QdrantVectorError on failure."""
        mock_client.search.side_effect = Exception("Search failed")

        with pytest.raises(QdrantVectorError):
            await service.search("memories", [0.1] * 10)


class TestQdrantServiceDelete:
    """Tests for delete operations."""

    @pytest.mark.asyncio
    async def test_delete_single(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test deleting a single vector."""
        vector_id = uuid4()

        await service.delete("memories", [vector_id])

        mock_client.delete.assert_called_once()
        call_kwargs = mock_client.delete.call_args.kwargs
        assert call_kwargs["collection_name"] == "test_memories"

    @pytest.mark.asyncio
    async def test_delete_batch(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test deleting multiple vectors."""
        ids = [uuid4() for _ in range(5)]

        await service.delete("memories", ids)

        mock_client.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_empty(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test deleting empty list does nothing."""
        await service.delete("memories", [])
        mock_client.delete.assert_not_called()

    @pytest.mark.asyncio
    async def test_delete_error_handling(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test delete raises QdrantVectorError on failure."""
        mock_client.delete.side_effect = Exception("Delete failed")

        with pytest.raises(QdrantVectorError):
            await service.delete("memories", [uuid4()])


class TestQdrantServiceGet:
    """Tests for get operations."""

    @pytest.mark.asyncio
    async def test_get_existing(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test getting an existing vector."""
        vector_id = uuid4()
        mock_point = MagicMock()
        mock_point.id = str(vector_id)
        mock_point.vector = [0.1] * 10
        mock_point.payload = {"type": "meeting"}
        mock_client.retrieve.return_value = [mock_point]

        result = await service.get("memories", vector_id)

        assert result is not None
        assert result.id == vector_id
        assert result.payload["type"] == "meeting"

    @pytest.mark.asyncio
    async def test_get_non_existing(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test getting a non-existing vector returns None."""
        mock_client.retrieve.return_value = []

        result = await service.get("memories", uuid4())

        assert result is None

    @pytest.mark.asyncio
    async def test_get_error_handling(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test get raises QdrantVectorError on failure."""
        mock_client.retrieve.side_effect = Exception("Get failed")

        with pytest.raises(QdrantVectorError):
            await service.get("memories", uuid4())


class TestQdrantServiceCollectionInfo:
    """Tests for collection info operations."""

    @pytest.mark.asyncio
    async def test_get_collection_info(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test getting collection info."""
        mock_info = MagicMock()
        mock_info.vectors_count = 100
        mock_info.points_count = 100
        mock_client.get_collection.return_value = mock_info

        info = await service.get_collection_info("memories")

        assert info is not None
        assert info.name == "memories"
        assert info.vectors_count == 100

    @pytest.mark.asyncio
    async def test_get_collection_info_not_found(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test getting info for non-existing collection."""
        mock_client.get_collection.side_effect = UnexpectedResponse(
            status_code=404, reason_phrase="Not found", content=b""
        )

        info = await service.get_collection_info("nonexistent")

        assert info is None


class TestQdrantServiceHealthCheck:
    """Tests for health check operations."""

    @pytest.mark.asyncio
    async def test_health_check_healthy(
        self, service: QdrantService, _mock_client: AsyncMock
    ) -> None:
        """Test health check returns True when healthy."""
        result = await service.health_check()
        assert result is True

    @pytest.mark.asyncio
    async def test_health_check_unhealthy(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test health check returns False when unhealthy."""
        mock_client.get_collections.side_effect = Exception("Connection failed")

        result = await service.health_check()

        assert result is False


class TestQdrantServiceClose:
    """Tests for close operations."""

    @pytest.mark.asyncio
    async def test_close(self, service: QdrantService, mock_client: AsyncMock) -> None:
        """Test closing the service."""
        service._initialized = True

        await service.close()

        mock_client.close.assert_called_once()
        assert service._client is None
        assert service._initialized is False


class TestQdrantServiceDeleteCollection:
    """Tests for delete collection operations."""

    @pytest.mark.asyncio
    async def test_delete_collection(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test deleting a collection."""
        await service.delete_collection("memories")

        mock_client.delete_collection.assert_called_once_with(
            collection_name="test_memories"
        )

    @pytest.mark.asyncio
    async def test_delete_collection_error(
        self, service: QdrantService, mock_client: AsyncMock
    ) -> None:
        """Test delete collection raises QdrantCollectionError on failure."""
        mock_client.delete_collection.side_effect = Exception("Delete failed")

        with pytest.raises(QdrantCollectionError):
            await service.delete_collection("memories")


# =============================================================================
# Filter Building Tests
# =============================================================================


class TestFilterBuilding:
    """Tests for filter building."""

    def test_build_filter_empty(self, service: QdrantService) -> None:
        """Test building filter from empty dict."""
        result = service._build_filter({})
        assert result is None

    def test_build_filter_simple_match(self, service: QdrantService) -> None:
        """Test building filter with simple match."""
        result = service._build_filter({"type": "meeting"})
        assert result is not None
        assert len(result.must) == 1

    def test_build_filter_range(self, service: QdrantService) -> None:
        """Test building filter with range operators."""
        result = service._build_filter({"score": {"$gte": 0.5, "$lte": 1.0}})
        assert result is not None

    def test_build_filter_in(self, service: QdrantService) -> None:
        """Test building filter with $in operator."""
        result = service._build_filter({"type": {"$in": ["a", "b"]}})
        assert result is not None


# =============================================================================
# Payload Serialization Tests
# =============================================================================


class TestPayloadSerialization:
    """Tests for payload serialization."""

    def test_serialize_uuid(self, service: QdrantService) -> None:
        """Test serializing UUID to string."""
        test_uuid = uuid4()
        result = service._serialize_payload({"id": test_uuid})
        assert result["id"] == str(test_uuid)

    def test_serialize_uuid_list(self, service: QdrantService) -> None:
        """Test serializing list of UUIDs."""
        uuids = [uuid4(), uuid4()]
        result = service._serialize_payload({"ids": uuids})
        assert result["ids"] == [str(u) for u in uuids]

    def test_serialize_mixed_list(self, service: QdrantService) -> None:
        """Test serializing mixed list."""
        test_uuid = uuid4()
        result = service._serialize_payload({"items": [test_uuid, "string", 123]})
        assert result["items"] == [str(test_uuid), "string", 123]

    def test_serialize_primitives(self, service: QdrantService) -> None:
        """Test primitives pass through unchanged."""
        result = service._serialize_payload(
            {
                "string": "value",
                "int": 123,
                "float": 0.5,
                "bool": True,
            }
        )
        assert result["string"] == "value"
        assert result["int"] == 123
        assert result["float"] == 0.5
        assert result["bool"] is True

    def test_serialize_datetime(self, service: QdrantService) -> None:
        """Test serializing datetime to ISO format string."""
        dt = datetime(2025, 1, 1, 12, 30, 0)
        result = service._serialize_payload({"timestamp": dt})
        assert result["timestamp"] == "2025-01-01T12:30:00"

    def test_serialize_date(self, service: QdrantService) -> None:
        """Test serializing date to ISO format string."""
        d = date(2025, 1, 1)
        result = service._serialize_payload({"date": d})
        assert result["date"] == "2025-01-01"

    def test_serialize_decimal(self, service: QdrantService) -> None:
        """Test serializing Decimal to float."""
        decimal_val = Decimal("123.456")
        result = service._serialize_payload({"amount": decimal_val})
        assert result["amount"] == 123.456
        assert isinstance(result["amount"], float)

    def test_serialize_nested_dict(self, service: QdrantService) -> None:
        """Test serializing nested dictionaries with special types."""
        test_uuid = uuid4()
        dt = datetime(2025, 1, 1, 12, 0, 0)
        payload = {
            "nested": {
                "id": test_uuid,
                "timestamp": dt,
                "value": Decimal("99.99"),
            }
        }
        result = service._serialize_payload(payload)
        assert result["nested"]["id"] == str(test_uuid)
        assert result["nested"]["timestamp"] == "2025-01-01T12:00:00"
        assert result["nested"]["value"] == 99.99

    def test_serialize_nested_list(self, service: QdrantService) -> None:
        """Test serializing nested lists with special types."""
        test_uuid = uuid4()
        dt = datetime(2025, 1, 1)
        payload = {
            "items": [
                {"id": test_uuid},
                {"timestamp": dt},
                [Decimal("1.5"), Decimal("2.5")],
            ]
        }
        result = service._serialize_payload(payload)
        assert result["items"][0]["id"] == str(test_uuid)
        assert result["items"][1]["timestamp"] == "2025-01-01T00:00:00"
        assert result["items"][2] == [1.5, 2.5]

    def test_serialize_tuple(self, service: QdrantService) -> None:
        """Test serializing tuples to lists."""
        result = service._serialize_payload({"coords": (1.0, 2.0, 3.0)})
        assert result["coords"] == [1.0, 2.0, 3.0]
        assert isinstance(result["coords"], list)


# =============================================================================
# Filter Validation Tests
# =============================================================================


class TestFilterValidation:
    """Tests for filter field and value validation."""

    def test_filter_gt_only(self, service: QdrantService) -> None:
        """Test filter with only $gt operator (no $gte)."""
        result = service._build_filter({"score": {"$gt": 0.5}})
        assert result is not None
        assert len(result.must) == 1

    def test_filter_lt_only(self, service: QdrantService) -> None:
        """Test filter with only $lt operator (no $lte)."""
        result = service._build_filter({"score": {"$lt": 1.0}})
        assert result is not None
        assert len(result.must) == 1

    def test_filter_gt_and_lt(self, service: QdrantService) -> None:
        """Test filter with both $gt and $lt operators."""
        result = service._build_filter({"score": {"$gt": 0.5, "$lt": 1.0}})
        assert result is not None
        assert len(result.must) == 1

    def test_invalid_filter_field_raises_error(self, service: QdrantService) -> None:
        """Test that invalid filter field raises QdrantVectorError."""
        with pytest.raises(QdrantVectorError, match="Invalid filter field"):
            service._build_filter({"invalid_field": "value"}, collection="memories")

    def test_valid_filter_field_allowed(self, service: QdrantService) -> None:
        """Test that valid filter fields are allowed."""
        result = service._build_filter({"type": "meeting"}, collection="memories")
        assert result is not None

    def test_in_list_exceeds_max_size(self, service: QdrantService) -> None:
        """Test that $in list exceeding MAX_IN_LIST_SIZE raises error."""
        large_list = list(range(MAX_IN_LIST_SIZE + 1))
        with pytest.raises(QdrantVectorError, match="exceeds max size"):
            service._build_filter({"type": {"$in": large_list}})

    def test_in_list_within_max_size(self, service: QdrantService) -> None:
        """Test that $in list within MAX_IN_LIST_SIZE is allowed."""
        valid_list = list(range(MAX_IN_LIST_SIZE))
        result = service._build_filter({"type": {"$in": valid_list}})
        assert result is not None

    def test_filter_without_collection_skips_validation(
        self, service: QdrantService
    ) -> None:
        """Test that filter without collection skips field validation."""
        # Should not raise even with unknown field
        result = service._build_filter({"any_field": "value"})
        assert result is not None

    def test_allowed_filter_fields_constants(self) -> None:
        """Test that ALLOWED_FILTER_FIELDS has expected collections."""
        assert "memories" in ALLOWED_FILTER_FIELDS
        assert "lessons" in ALLOWED_FILTER_FIELDS
        assert "conversations" in ALLOWED_FILTER_FIELDS
        assert "type" in ALLOWED_FILTER_FIELDS["memories"]
        assert "category" in ALLOWED_FILTER_FIELDS["lessons"]
        assert "started_at" in ALLOWED_FILTER_FIELDS["conversations"]


# =============================================================================
# Retry Helper Tests
# =============================================================================


class TestRetryHelper:
    """Tests for retry helper function."""

    @pytest.mark.asyncio
    async def test_retry_success_first_try(self) -> None:
        """Test retry succeeds on first try."""

        async def success():
            return "ok"

        result = await with_retry(success, max_retries=3)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_retry_success_after_failure(self) -> None:
        """Test retry succeeds after initial failures."""
        attempts = [0]

        async def eventually_succeeds():
            attempts[0] += 1
            if attempts[0] < 3:
                raise QdrantConnectionError("Temporary failure")
            return "ok"

        result = await with_retry(eventually_succeeds, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert attempts[0] == 3

    @pytest.mark.asyncio
    async def test_retry_exhausted(self) -> None:
        """Test retry raises after all attempts exhausted."""

        async def always_fails():
            raise QdrantVectorError("Permanent failure")

        with pytest.raises(QdrantVectorError):
            await with_retry(always_fails, max_retries=2, base_delay=0.01)

    @pytest.mark.asyncio
    async def test_retry_with_collection_error(self) -> None:
        """Test retry handles QdrantCollectionError."""
        attempts = [0]

        async def fails_then_succeeds():
            attempts[0] += 1
            if attempts[0] < 2:
                raise QdrantCollectionError("Collection temporarily unavailable")
            return "ok"

        result = await with_retry(fails_then_succeeds, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert attempts[0] == 2

    @pytest.mark.asyncio
    async def test_retry_collection_error_exhausted(self) -> None:
        """Test retry raises QdrantCollectionError after exhausted."""

        async def always_fails():
            raise QdrantCollectionError("Permanent collection failure")

        with pytest.raises(QdrantCollectionError):
            await with_retry(always_fails, max_retries=2, base_delay=0.01)


# =============================================================================
# Integration Tests (require running Qdrant)
# =============================================================================


@pytest.mark.integration
class TestQdrantIntegration:
    """Integration tests with real Qdrant instance."""

    @pytest.fixture
    async def live_service(self) -> QdrantService:
        """Create a service connected to real Qdrant."""
        settings = QdrantSettings(
            url="http://localhost:6333",
            collection_prefix="integration_test_",
        )
        service = QdrantService(settings)

        # Cleanup before test
        for name in COLLECTION_CONFIGS:
            with contextlib.suppress(Exception):
                await service.delete_collection(name)

        yield service

        # Cleanup after test
        for name in COLLECTION_CONFIGS:
            with contextlib.suppress(Exception):
                await service.delete_collection(name)

        await service.close()

    @pytest.mark.asyncio
    async def test_full_workflow(self, live_service: QdrantService) -> None:
        """Test complete workflow: init, upsert, search, delete."""
        # Initialize
        await live_service.initialize()

        # Verify collections exist
        info = await live_service.get_collection_info("memories")
        assert info is not None
        assert info.points_count == 0

        # Upsert
        vector_id = uuid4()
        vector = [0.1] * 1536
        payload = {"type": "meeting", "importance": 0.8}
        await live_service.upsert("memories", vector_id, vector, payload)

        # Verify upserted
        point = await live_service.get("memories", vector_id)
        assert point is not None
        assert point.id == vector_id

        # Search
        results = await live_service.search("memories", vector, limit=1)
        assert len(results) == 1
        assert results[0].id == vector_id

        # Delete
        await live_service.delete("memories", [vector_id])

        # Verify deleted
        point = await live_service.get("memories", vector_id)
        assert point is None

    @pytest.mark.asyncio
    async def test_health_check_live(self, live_service: QdrantService) -> None:
        """Test health check with real Qdrant."""
        healthy = await live_service.health_check()
        assert healthy is True
