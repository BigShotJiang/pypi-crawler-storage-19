"""Tests for sequential workflow pattern.

Component 4.11: Orchestration Patterns
"""

import pytest
from digital_valerii_shared.workflows.base import (
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)
from digital_valerii_shared.workflows.sequential import SequentialWorkflow


class AddValueStep(WorkflowStep):
    """Test step that adds a value to context."""

    def __init__(self, key: str, value: str):
        self.key = key
        self.value = value

    @property
    def name(self) -> str:
        return f"AddValue_{self.key}"

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data[self.key] = self.value
        return context


class IncrementStep(WorkflowStep):
    """Test step that increments a counter."""

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data["counter"] = context.data.get("counter", 0) + 1
        return context


class FailingStep(WorkflowStep):
    """Test step that always fails."""

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        raise ValueError("Intentional failure")


class TestSequentialWorkflow:
    """Tests for SequentialWorkflow."""

    @pytest.mark.asyncio
    async def test_empty_workflow(self) -> None:
        """Test workflow with no steps."""
        workflow = SequentialWorkflow([])
        result = await workflow.run()

        assert result.data == {}
        assert result.history == []

    @pytest.mark.asyncio
    async def test_single_step(self) -> None:
        """Test workflow with single step."""
        workflow = SequentialWorkflow([AddValueStep("key", "value")])
        result = await workflow.run()

        assert result.data == {"key": "value"}
        assert len(result.history) == 1
        assert result.history[0]["step"] == "AddValue_key"
        assert result.history[0]["status"] == "completed"

    @pytest.mark.asyncio
    async def test_multiple_steps_sequential(self) -> None:
        """Test multiple steps execute in order."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("first", "1"),
                AddValueStep("second", "2"),
                AddValueStep("third", "3"),
            ]
        )
        result = await workflow.run()

        assert result.data == {"first": "1", "second": "2", "third": "3"}
        assert len(result.history) == 3
        assert [h["step"] for h in result.history] == [
            "AddValue_first",
            "AddValue_second",
            "AddValue_third",
        ]

    @pytest.mark.asyncio
    async def test_steps_share_context(self) -> None:
        """Test that steps share and modify the same context."""
        workflow = SequentialWorkflow(
            [
                IncrementStep(),
                IncrementStep(),
                IncrementStep(),
            ]
        )
        result = await workflow.run()

        assert result.data["counter"] == 3

    @pytest.mark.asyncio
    async def test_initial_context_preserved(self) -> None:
        """Test that initial context data is preserved."""
        initial = WorkflowContext(data={"existing": "data"})
        workflow = SequentialWorkflow([AddValueStep("new", "value")])
        result = await workflow.run(initial)

        assert result.data == {"existing": "data", "new": "value"}

    @pytest.mark.asyncio
    async def test_step_failure_stops_workflow(self) -> None:
        """Test that a failing step stops the workflow."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("before", "success"),
                FailingStep(),
                AddValueStep("after", "never_reached"),
            ]
        )

        with pytest.raises(WorkflowError) as exc_info:
            await workflow.run()

        assert "FailingStep" in str(exc_info.value)
        assert "Intentional failure" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_failure_records_error_in_history(self) -> None:
        """Test that failure is recorded in history."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("before", "success"),
                FailingStep(),
            ]
        )

        ctx = WorkflowContext()
        with pytest.raises(WorkflowError):
            await workflow.run(ctx)

        assert len(ctx.history) == 2
        assert ctx.history[0]["status"] == "completed"
        assert ctx.history[1]["status"] == "failed"
        assert "Intentional failure" in ctx.history[1]["error"]

    @pytest.mark.asyncio
    async def test_workflow_name(self) -> None:
        """Test custom workflow name."""
        workflow = SequentialWorkflow([], name="CustomWorkflow")
        assert workflow.name == "CustomWorkflow"

    @pytest.mark.asyncio
    async def test_workflow_id_preserved(self) -> None:
        """Test that workflow_id is preserved throughout execution."""
        initial = WorkflowContext()
        workflow_id = initial.workflow_id

        workflow = SequentialWorkflow(
            [
                AddValueStep("a", "1"),
                AddValueStep("b", "2"),
            ]
        )
        result = await workflow.run(initial)

        assert result.workflow_id == workflow_id
