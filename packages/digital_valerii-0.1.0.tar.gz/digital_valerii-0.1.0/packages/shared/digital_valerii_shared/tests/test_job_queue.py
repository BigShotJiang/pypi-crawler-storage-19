"""Tests for JobQueue service."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from arq.jobs import JobStatus as ArqJobStatus
from pydantic import ValidationError

from packages.shared.digital_valerii_shared.models.jobs import (
    JobPriority,
    JobRequest,
    JobResult,
    JobStatus,
    QueueStats,
)
from packages.shared.digital_valerii_shared.services.job_queue import (
    QUEUE_KEYS,
    JobConnectionError,
    JobEnqueueError,
    JobNotFoundError,
    JobQueue,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def job_queue():
    """Create a JobQueue instance."""
    return JobQueue()


@pytest.fixture
def mock_arq_pool():
    """Create a mock arq Redis pool."""
    pool = AsyncMock()
    pool.ping = AsyncMock(return_value=True)
    pool.close = AsyncMock()
    pool.zcard = AsyncMock(return_value=0)  # arq uses sorted sets
    pool.zrange = AsyncMock(return_value=[])  # arq uses sorted sets
    pool.set = AsyncMock()
    return pool


@pytest.fixture
def mock_job():
    """Create a mock arq Job."""
    job = MagicMock()
    job.job_id = "test-job-123"
    return job


# =============================================================================
# Connection Tests
# =============================================================================


class TestJobQueueConnection:
    """Tests for JobQueue connection management."""

    async def test_connect_success(self, job_queue, mock_arq_pool):
        """Test successful connection to job queue."""
        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.create_pool",
            new_callable=AsyncMock,
            return_value=mock_arq_pool,
        ):
            await job_queue.connect()

            assert job_queue._pool is not None
            mock_arq_pool.ping.assert_called_once()

    async def test_connect_already_connected(self, job_queue, mock_arq_pool):
        """Test connect when already connected does nothing."""
        job_queue._pool = mock_arq_pool

        await job_queue.connect()

        # Should not create new pool
        assert job_queue._pool is mock_arq_pool

    async def test_connect_failure(self, job_queue):
        """Test connection failure raises JobConnectionError."""
        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.create_pool",
            new_callable=AsyncMock,
            side_effect=Exception("Connection refused"),
        ):
            with pytest.raises(JobConnectionError) as exc_info:
                await job_queue.connect()

            assert "Failed to connect" in str(exc_info.value)

    async def test_disconnect(self, job_queue, mock_arq_pool):
        """Test disconnecting from job queue."""
        job_queue._pool = mock_arq_pool

        await job_queue.disconnect()

        assert job_queue._pool is None
        mock_arq_pool.close.assert_called_once()

    async def test_disconnect_when_not_connected(self, job_queue):
        """Test disconnect when not connected does nothing."""
        await job_queue.disconnect()

        assert job_queue._pool is None

    async def test_health_check_healthy(self, job_queue, mock_arq_pool):
        """Test health check returns True when healthy."""
        job_queue._pool = mock_arq_pool

        result = await job_queue.health_check()

        assert result is True
        mock_arq_pool.ping.assert_called_once()

    async def test_health_check_not_connected(self, job_queue):
        """Test health check returns False when not connected."""
        result = await job_queue.health_check()

        assert result is False

    async def test_health_check_ping_fails(self, job_queue, mock_arq_pool):
        """Test health check returns False when ping fails."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.ping.side_effect = Exception("Ping failed")

        result = await job_queue.health_check()

        assert result is False

    async def test_pool_property_when_connected(self, job_queue, mock_arq_pool):
        """Test pool property returns pool when connected."""
        job_queue._pool = mock_arq_pool

        result = job_queue.pool

        assert result is mock_arq_pool

    async def test_pool_property_when_not_connected(self, job_queue):
        """Test pool property raises error when not connected."""
        with pytest.raises(JobConnectionError) as exc_info:
            _ = job_queue.pool

        assert "not connected" in str(exc_info.value)


# =============================================================================
# Enqueue Tests
# =============================================================================


class TestJobQueueEnqueue:
    """Tests for job enqueueing."""

    async def test_enqueue_basic(self, job_queue, mock_arq_pool, mock_job):
        """Test basic job enqueueing."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(return_value=mock_job)

        job_id = await job_queue.enqueue(
            "test_job",
            {"key": "value"},
        )

        assert job_id == "test-job-123"
        mock_arq_pool.enqueue_job.assert_called_once()
        mock_arq_pool.set.assert_called_once()

    async def test_enqueue_with_priority(self, job_queue, mock_arq_pool, mock_job):
        """Test job enqueueing with priority."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(return_value=mock_job)

        await job_queue.enqueue(
            "test_job",
            {"key": "value"},
            priority=JobPriority.HIGH,
        )

        call_kwargs = mock_arq_pool.enqueue_job.call_args[1]
        assert call_kwargs["_queue_name"] == QUEUE_KEYS[JobPriority.HIGH]

    async def test_enqueue_with_delay(self, job_queue, mock_arq_pool, mock_job):
        """Test job enqueueing with delay."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(return_value=mock_job)

        await job_queue.enqueue(
            "test_job",
            {"key": "value"},
            delay_seconds=60,
        )

        call_kwargs = mock_arq_pool.enqueue_job.call_args[1]
        assert call_kwargs["_defer_by"] == 60

    async def test_enqueue_failure_null_job(self, job_queue, mock_arq_pool):
        """Test enqueue failure when job is None."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(return_value=None)

        with pytest.raises(JobEnqueueError) as exc_info:
            await job_queue.enqueue("test_job", {})

        assert "job is None" in str(exc_info.value)

    async def test_enqueue_failure_exception(self, job_queue, mock_arq_pool):
        """Test enqueue failure on exception."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(side_effect=Exception("Redis error"))

        with pytest.raises(JobEnqueueError) as exc_info:
            await job_queue.enqueue("test_job", {})

        assert "Redis error" in str(exc_info.value)

    async def test_enqueue_batch(self, job_queue, mock_arq_pool, mock_job):
        """Test batch job enqueueing."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.enqueue_job = AsyncMock(return_value=mock_job)

        jobs = [
            {"job_name": "job1", "payload": {"a": 1}},
            {"job_name": "job2", "payload": {"b": 2}},
        ]

        job_ids = await job_queue.enqueue_batch(jobs)

        assert len(job_ids) == 2
        assert mock_arq_pool.enqueue_job.call_count == 2


# =============================================================================
# Job Status Tests
# =============================================================================


class TestJobQueueStatus:
    """Tests for job status retrieval."""

    async def test_get_job_status_queued(self, job_queue, mock_arq_pool):
        """Test getting status for queued job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.queued
        job_info.result = None
        job_info.enqueue_time = datetime.now(UTC)
        job_info.finish_time = None

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.get_job_status("job-123")

        assert result.job_id == "job-123"
        assert result.status == JobStatus.QUEUED

    async def test_get_job_status_complete(self, job_queue, mock_arq_pool):
        """Test getting status for complete job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.complete
        job_info.result = {"count": 5}
        job_info.enqueue_time = datetime.now(UTC)
        job_info.finish_time = datetime.now(UTC)

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.get_job_status("job-123")

        assert result.status == JobStatus.COMPLETE
        assert result.result == {"count": 5}
        assert result.completed_at is not None

    async def test_get_job_status_failed(self, job_queue, mock_arq_pool):
        """Test getting status for failed job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.not_found  # arq uses not_found for failed
        job_info.result = "Error message"
        job_info.enqueue_time = datetime.now(UTC)
        job_info.finish_time = datetime.now(UTC)

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.get_job_status("job-123")

        assert result.status == JobStatus.FAILED
        assert "Error message" in result.error

    async def test_get_job_status_not_found(self, job_queue, mock_arq_pool):
        """Test getting status for non-existent job."""
        job_queue._pool = mock_arq_pool

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=None)
            MockJob.return_value = mock_job_instance

            with pytest.raises(JobNotFoundError) as exc_info:
                await job_queue.get_job_status("nonexistent-job")

        assert "not found" in str(exc_info.value)

    async def test_get_job_status_deferred(self, job_queue, mock_arq_pool):
        """Test getting status for deferred job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.deferred
        job_info.result = None
        job_info.enqueue_time = datetime.now(UTC)
        job_info.finish_time = None

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.get_job_status("job-123")

        assert result.status == JobStatus.DEFERRED

    async def test_get_job_status_in_progress(self, job_queue, mock_arq_pool):
        """Test getting status for in-progress job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.in_progress
        job_info.result = None
        job_info.enqueue_time = datetime.now(UTC)
        job_info.finish_time = None

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.get_job_status("job-123")

        assert result.status == JobStatus.IN_PROGRESS


# =============================================================================
# Cancel Tests
# =============================================================================


class TestJobQueueCancel:
    """Tests for job cancellation."""

    async def test_cancel_queued_job(self, job_queue, mock_arq_pool):
        """Test cancelling a queued job."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.queued

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            mock_job_instance.abort = AsyncMock()
            MockJob.return_value = mock_job_instance

            result = await job_queue.cancel_job("job-123")

        assert result is True
        mock_job_instance.abort.assert_called_once()

    async def test_cancel_in_progress_job(self, job_queue, mock_arq_pool):
        """Test cancelling in-progress job returns False."""
        job_queue._pool = mock_arq_pool

        job_info = MagicMock()
        job_info.status = ArqJobStatus.in_progress

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=job_info)
            MockJob.return_value = mock_job_instance

            result = await job_queue.cancel_job("job-123")

        assert result is False

    async def test_cancel_nonexistent_job(self, job_queue, mock_arq_pool):
        """Test cancelling non-existent job raises error."""
        job_queue._pool = mock_arq_pool

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.Job"
        ) as MockJob:
            mock_job_instance = MagicMock()
            mock_job_instance.info = AsyncMock(return_value=None)
            MockJob.return_value = mock_job_instance

            with pytest.raises(JobNotFoundError):
                await job_queue.cancel_job("nonexistent-job")


# =============================================================================
# Queue Stats Tests
# =============================================================================


class TestJobQueueStats:
    """Tests for queue statistics."""

    async def test_get_queue_stats(self, job_queue, mock_arq_pool):
        """Test getting queue statistics uses ZCARD."""
        job_queue._pool = mock_arq_pool

        # Mock different queue lengths using ZCARD (sorted sets)
        async def mock_zcard(key):
            lengths = {
                QUEUE_KEYS[JobPriority.HIGH]: 5,
                QUEUE_KEYS[JobPriority.DEFAULT]: 10,
                QUEUE_KEYS[JobPriority.LOW]: 3,
                QUEUE_KEYS[JobPriority.SCHEDULED]: 2,
            }
            return lengths.get(key, 0)

        mock_arq_pool.zcard = mock_zcard

        stats = await job_queue.get_queue_stats()

        assert stats.high_priority == 5
        assert stats.default == 10
        assert stats.low_priority == 3
        assert stats.scheduled == 2
        assert stats.total == 20

    async def test_get_queue_stats_empty(self, job_queue, mock_arq_pool):
        """Test getting queue statistics with empty queues."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.zcard = AsyncMock(return_value=0)

        stats = await job_queue.get_queue_stats()

        assert stats.high_priority == 0
        assert stats.default == 0
        assert stats.low_priority == 0
        assert stats.scheduled == 0
        assert stats.total == 0

    async def test_get_pending_jobs(self, job_queue, mock_arq_pool):
        """Test getting pending job IDs uses ZRANGE."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.zrange = AsyncMock(return_value=["job1", "job2"])

        job_ids = await job_queue.get_pending_jobs(limit=10)

        assert len(job_ids) >= 0

    async def test_get_pending_jobs_by_priority(self, job_queue, mock_arq_pool):
        """Test getting pending jobs filtered by priority uses ZRANGE."""
        job_queue._pool = mock_arq_pool
        mock_arq_pool.zrange = AsyncMock(return_value=["job1"])

        job_ids = await job_queue.get_pending_jobs(
            priority=JobPriority.HIGH,
            limit=10,
        )

        assert len(job_ids) >= 0
        mock_arq_pool.zrange.assert_called()


# =============================================================================
# Pydantic Model Tests
# =============================================================================


class TestJobModels:
    """Tests for job Pydantic models."""

    def test_job_request_valid(self):
        """Test valid JobRequest creation."""
        request = JobRequest(
            job_name="test_job",
            payload={"key": "value"},
            priority=JobPriority.HIGH,
            delay_seconds=60,
        )

        assert request.job_name == "test_job"
        assert request.priority == JobPriority.HIGH
        assert request.delay_seconds == 60

    def test_job_request_defaults(self):
        """Test JobRequest with defaults."""
        request = JobRequest(job_name="test_job")

        assert request.payload == {}
        assert request.priority == JobPriority.DEFAULT
        assert request.delay_seconds is None

    def test_job_request_forbids_extra(self):
        """Test JobRequest forbids extra fields."""
        with pytest.raises(ValueError):
            JobRequest(job_name="test", extra_field="not allowed")

    def test_job_result_frozen(self):
        """Test JobResult is immutable."""
        result = JobResult(
            job_id="123",
            status=JobStatus.COMPLETE,
            created_at=datetime.now(UTC),
        )

        with pytest.raises(ValidationError):
            result.status = JobStatus.FAILED

    def test_queue_stats_validation(self):
        """Test QueueStats validation."""
        stats = QueueStats(
            high_priority=5,
            default=10,
            low_priority=3,
            scheduled=2,
            total=20,
        )

        assert stats.total == 20

    def test_queue_stats_non_negative(self):
        """Test QueueStats requires non-negative values."""
        with pytest.raises(ValueError):
            QueueStats(
                high_priority=-1,
                default=0,
                low_priority=0,
                scheduled=0,
                total=0,
            )


# =============================================================================
# Round 2 - Codex Fix Tests
# =============================================================================


class TestArqSettingsUrlParsing:
    """Tests for Redis URL parsing fixes (MEDIUM-2)."""

    def test_arq_settings_with_tls(self):
        """Test rediss:// URL parsing enables SSL."""
        from packages.shared.digital_valerii_shared.config import RedisSettings
        from packages.shared.digital_valerii_shared.services.job_queue import JobQueue

        # Create mock settings with TLS URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "rediss://localhost:6379/0"
        mock_settings.socket_connect_timeout = 5.0

        queue = JobQueue(settings=mock_settings)
        arq_settings = queue._get_arq_settings()

        assert arq_settings.ssl is True
        assert arq_settings.host == "localhost"
        assert arq_settings.port == 6379
        assert arq_settings.database == 0

    def test_arq_settings_with_acl(self):
        """Test username:password URL parsing for Redis ACL."""
        from packages.shared.digital_valerii_shared.config import RedisSettings
        from packages.shared.digital_valerii_shared.services.job_queue import JobQueue

        # Create mock settings with ACL URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "redis://myuser:mypass@localhost:6379/2"
        mock_settings.socket_connect_timeout = 5.0

        queue = JobQueue(settings=mock_settings)
        arq_settings = queue._get_arq_settings()

        assert arq_settings.username == "myuser"
        assert arq_settings.password == "mypass"
        assert arq_settings.host == "localhost"
        assert arq_settings.port == 6379
        assert arq_settings.database == 2
        assert arq_settings.ssl is False

    def test_arq_settings_with_tls_and_acl(self):
        """Test rediss:// with username:password."""
        from packages.shared.digital_valerii_shared.config import RedisSettings
        from packages.shared.digital_valerii_shared.services.job_queue import JobQueue

        # Create mock settings with TLS + ACL URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "rediss://admin:secret@redis.example.com:6380/1"
        mock_settings.socket_connect_timeout = 5.0

        queue = JobQueue(settings=mock_settings)
        arq_settings = queue._get_arq_settings()

        assert arq_settings.ssl is True
        assert arq_settings.username == "admin"
        assert arq_settings.password == "secret"
        assert arq_settings.host == "redis.example.com"
        assert arq_settings.port == 6380
        assert arq_settings.database == 1

    def test_arq_settings_simple_url(self):
        """Test simple redis:// URL without auth."""
        from packages.shared.digital_valerii_shared.config import RedisSettings
        from packages.shared.digital_valerii_shared.services.job_queue import JobQueue

        # Create mock settings with simple URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "redis://127.0.0.1:6379"
        mock_settings.socket_connect_timeout = 5.0

        queue = JobQueue(settings=mock_settings)
        arq_settings = queue._get_arq_settings()

        assert arq_settings.ssl is False
        assert arq_settings.username is None
        assert arq_settings.password is None
        assert arq_settings.host == "127.0.0.1"
        assert arq_settings.port == 6379
        assert arq_settings.database == 0


class TestQueueLengthErrorLogging:
    """Tests for queue length error logging (LOW-1)."""

    async def test_queue_length_logs_redis_errors(self, job_queue, mock_arq_pool):
        """Test _get_queue_length logs Redis errors."""
        from redis.exceptions import RedisError

        job_queue._pool = mock_arq_pool
        mock_arq_pool.zcard = AsyncMock(side_effect=RedisError("Connection lost"))

        with patch(
            "packages.shared.digital_valerii_shared.services.job_queue.logger"
        ) as mock_logger:
            mock_logger.awarning = AsyncMock()

            result = await job_queue._get_queue_length("dv:jobs:high")

            assert result == 0
            mock_logger.awarning.assert_called_once()
            call_kwargs = mock_logger.awarning.call_args[1]
            assert call_kwargs["queue_key"] == "dv:jobs:high"
            assert "Connection lost" in call_kwargs["error"]

    async def test_queue_length_returns_zero_on_error(self, job_queue, mock_arq_pool):
        """Test _get_queue_length returns 0 on Redis error."""
        from redis.exceptions import RedisError

        job_queue._pool = mock_arq_pool
        mock_arq_pool.zcard = AsyncMock(side_effect=RedisError("Timeout"))

        result = await job_queue._get_queue_length("dv:jobs:default")

        assert result == 0
