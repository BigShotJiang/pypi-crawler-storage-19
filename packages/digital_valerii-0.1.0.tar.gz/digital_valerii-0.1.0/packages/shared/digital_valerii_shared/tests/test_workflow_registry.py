"""Tests for workflow registry.

Component 4.11: Orchestration Patterns
"""

import pytest
from digital_valerii_shared.workflows.base import WorkflowContext, WorkflowStep
from digital_valerii_shared.workflows.registry import (
    WORKFLOW_REGISTRY,
    WorkflowStepRegistry,
    get_workflow,
    list_workflows,
    register_workflow,
)
from digital_valerii_shared.workflows.sequential import SequentialWorkflow


class TestWorkflowRegistry:
    """Tests for workflow registry functions."""

    def setup_method(self) -> None:
        """Clear registry before each test."""
        WORKFLOW_REGISTRY.clear()

    def test_register_workflow_decorator(self) -> None:
        """Test registering a workflow with decorator."""

        @register_workflow("test_workflow")
        class TestWorkflow(SequentialWorkflow):
            pass

        assert "test_workflow" in WORKFLOW_REGISTRY
        assert WORKFLOW_REGISTRY["test_workflow"] is TestWorkflow

    def test_get_workflow(self) -> None:
        """Test getting a registered workflow."""

        @register_workflow("my_workflow")
        class MyWorkflow(SequentialWorkflow):
            pass

        result = get_workflow("my_workflow")
        assert result is MyWorkflow

    def test_get_unknown_workflow_raises(self) -> None:
        """Test getting unknown workflow raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            get_workflow("nonexistent")

        assert "Unknown workflow type: 'nonexistent'" in str(exc_info.value)

    def test_list_workflows(self) -> None:
        """Test listing registered workflows."""

        @register_workflow("workflow_a")
        class WorkflowA(SequentialWorkflow):
            pass

        @register_workflow("workflow_b")
        class WorkflowB(SequentialWorkflow):
            pass

        names = list_workflows()
        assert "workflow_a" in names
        assert "workflow_b" in names

    def test_list_empty_registry(self) -> None:
        """Test listing empty registry."""
        names = list_workflows()
        assert names == []


class TestWorkflowStepRegistry:
    """Tests for step registry."""

    def setup_method(self) -> None:
        """Clear step registry before each test."""
        WorkflowStepRegistry._steps.clear()

    def test_register_step(self) -> None:
        """Test registering a step class."""

        @WorkflowStepRegistry.register("my_step")
        class MyStep(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                return context

        assert "my_step" in WorkflowStepRegistry._steps
        assert WorkflowStepRegistry._steps["my_step"] is MyStep

    def test_get_step(self) -> None:
        """Test getting a registered step."""

        @WorkflowStepRegistry.register("test_step")
        class TestStep(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                return context

        result = WorkflowStepRegistry.get("test_step")
        assert result is TestStep

    def test_get_unknown_step_raises(self) -> None:
        """Test getting unknown step raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            WorkflowStepRegistry.get("unknown_step")

        assert "Unknown step type: 'unknown_step'" in str(exc_info.value)

    def test_list_steps(self) -> None:
        """Test listing registered steps."""

        @WorkflowStepRegistry.register("step_x")
        class StepX(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                return context

        @WorkflowStepRegistry.register("step_y")
        class StepY(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                return context

        names = WorkflowStepRegistry.list()
        assert "step_x" in names
        assert "step_y" in names
