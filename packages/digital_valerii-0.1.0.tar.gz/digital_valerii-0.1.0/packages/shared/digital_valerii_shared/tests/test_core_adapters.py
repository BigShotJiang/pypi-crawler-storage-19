"""Tests for Memory Manager Adapter.

This module contains tests for the MemoryManagerAdapter class
that bridges Component 1.5 MemoryManager with Agent Core interface.
"""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from digital_valerii_shared.agent.core.adapters import MemoryManagerAdapter


@pytest.fixture
def mock_real_memory_manager() -> MagicMock:
    """Create a mock Component 1.5 MemoryManager."""
    manager = MagicMock()
    manager.recall = AsyncMock()
    manager.store = AsyncMock()
    return manager


@pytest.fixture
def mock_memory_context() -> MagicMock:
    """Create a mock MemoryContext."""
    context = MagicMock()
    context.events = []
    context.people = []
    context.projects = []
    context.lessons = []
    return context


@pytest.fixture
def adapter(mock_real_memory_manager: MagicMock) -> MemoryManagerAdapter:
    """Create adapter with mock manager."""
    return MemoryManagerAdapter(mock_real_memory_manager)


class TestMemoryManagerAdapterInit:
    """Tests for adapter initialization."""

    def test_init_with_memory_manager(
        self, mock_real_memory_manager: MagicMock
    ) -> None:
        """Test initialization with memory manager."""
        adapter = MemoryManagerAdapter(mock_real_memory_manager)
        assert adapter._memory == mock_real_memory_manager


class TestRecall:
    """Tests for recall method."""

    @pytest.mark.asyncio
    async def test_recall_creates_context(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
        mock_memory_context: MagicMock,
    ) -> None:
        """Test that recall creates Context object."""
        mock_real_memory_manager.recall.return_value = mock_memory_context

        await adapter.recall(
            query="test query",
            conversation_id="conv-123",
            user_id="user-456",
            limit=5,
        )

        mock_real_memory_manager.recall.assert_called_once()
        call_args = mock_real_memory_manager.recall.call_args
        assert call_args.kwargs["query"] == "test query"
        assert call_args.kwargs["limit"] == 5
        assert call_args.kwargs["context"].session_id == "conv-123"

    @pytest.mark.asyncio
    async def test_recall_default_conversation_id(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
        mock_memory_context: MagicMock,
    ) -> None:
        """Test recall uses default conversation ID."""
        mock_real_memory_manager.recall.return_value = mock_memory_context

        await adapter.recall(query="test")

        call_args = mock_real_memory_manager.recall.call_args
        assert call_args.kwargs["context"].session_id == "default"

    @pytest.mark.asyncio
    async def test_recall_returns_memory_references(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that recall returns list of MemoryReference."""
        # Create mock MemoryContext with event
        mock_event = MagicMock()
        mock_event.event_id = uuid4()
        mock_event.event_type = "conversation"
        mock_event.title = "Meeting notes"
        mock_event.summary = "Discussed project timeline"
        mock_event.occurred_at = datetime.now(tz=UTC)
        mock_event.final_score = 0.85

        mock_context = MagicMock()
        mock_context.events = [mock_event]
        mock_context.people = []
        mock_context.projects = []
        mock_context.lessons = []

        mock_real_memory_manager.recall.return_value = mock_context

        result = await adapter.recall(query="meeting")

        assert len(result) == 1
        assert result[0].relevance == 0.85
        assert "Meeting notes" in result[0].content

    @pytest.mark.asyncio
    async def test_recall_converts_people(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that recall converts people to references."""
        mock_person = MagicMock()
        mock_person.id = uuid4()
        mock_person.name = "John Doe"
        mock_person.company = "ACME Corp"
        mock_person.relationship_type = "client"

        mock_context = MagicMock()
        mock_context.events = []
        mock_context.people = [mock_person]
        mock_context.projects = []
        mock_context.lessons = []

        mock_real_memory_manager.recall.return_value = mock_context

        result = await adapter.recall(query="john")

        assert len(result) == 1
        assert "John Doe" in result[0].content
        assert "ACME Corp" in result[0].content
        assert result[0].relevance == 0.5  # Default person relevance

    @pytest.mark.asyncio
    async def test_recall_converts_projects(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that recall converts projects to references."""
        mock_project = MagicMock()
        mock_project.id = uuid4()
        mock_project.name = "Website Redesign"
        mock_project.status = "in_progress"
        mock_project.description = "Redesigning company website"

        mock_context = MagicMock()
        mock_context.events = []
        mock_context.people = []
        mock_context.projects = [mock_project]
        mock_context.lessons = []

        mock_real_memory_manager.recall.return_value = mock_context

        result = await adapter.recall(query="website")

        assert len(result) == 1
        assert "Website Redesign" in result[0].content
        assert "in_progress" in result[0].content
        assert result[0].relevance == 0.6  # Default project relevance

    @pytest.mark.asyncio
    async def test_recall_converts_lessons(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that recall converts lessons to references."""
        mock_lesson = MagicMock()
        mock_lesson.id = uuid4()
        mock_lesson.content = "Always validate user input"
        mock_lesson.category = "security"
        mock_lesson.confidence = 0.95

        mock_context = MagicMock()
        mock_context.events = []
        mock_context.people = []
        mock_context.projects = []
        mock_context.lessons = [mock_lesson]

        mock_real_memory_manager.recall.return_value = mock_context

        result = await adapter.recall(query="security")

        assert len(result) == 1
        assert result[0].content == "Always validate user input"
        assert result[0].relevance == 0.95  # Uses lesson confidence

    @pytest.mark.asyncio
    async def test_recall_combined_sorted_by_relevance(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that combined results are sorted by relevance."""
        mock_event = MagicMock()
        mock_event.title = "Low relevance event"
        mock_event.summary = None
        mock_event.event_type = "note"
        mock_event.occurred_at = datetime.now(tz=UTC)
        mock_event.final_score = 0.3

        mock_lesson = MagicMock()
        mock_lesson.content = "High relevance lesson"
        mock_lesson.confidence = 0.9

        mock_context = MagicMock()
        mock_context.events = [mock_event]
        mock_context.people = []
        mock_context.projects = []
        mock_context.lessons = [mock_lesson]

        mock_real_memory_manager.recall.return_value = mock_context

        result = await adapter.recall(query="test")

        assert len(result) == 2
        # Higher relevance should come first
        assert result[0].relevance > result[1].relevance
        assert "High relevance lesson" in result[0].content

    @pytest.mark.asyncio
    async def test_recall_failure_returns_empty(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that recall failure returns empty list."""
        mock_real_memory_manager.recall.side_effect = Exception("DB error")

        result = await adapter.recall(query="test")

        assert result == []


class TestStore:
    """Tests for store method."""

    @pytest.mark.asyncio
    async def test_store_creates_context(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that store creates Context object."""
        await adapter.store(
            message="Hello",
            response="Hi there",
            conversation_id="conv-123",
            interface="slack",
        )

        mock_real_memory_manager.store.assert_called_once()
        call_args = mock_real_memory_manager.store.call_args
        assert call_args.kwargs["user_message"] == "Hello"
        assert call_args.kwargs["agent_response"] == "Hi there"
        assert call_args.kwargs["context"].session_id == "conv-123"
        assert call_args.kwargs["context"].interface == "slack"

    @pytest.mark.asyncio
    async def test_store_default_values(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test store with default values."""
        await adapter.store(
            message="Hello",
            response="Hi",
        )

        call_args = mock_real_memory_manager.store.call_args
        assert call_args.kwargs["context"].session_id == "default"
        assert call_args.kwargs["context"].interface == "agent"

    @pytest.mark.asyncio
    async def test_store_failure_handled(
        self,
        adapter: MemoryManagerAdapter,
        mock_real_memory_manager: MagicMock,
    ) -> None:
        """Test that store failure is handled gracefully."""
        mock_real_memory_manager.store.side_effect = Exception("DB error")

        # Should not raise
        await adapter.store(message="Hello", response="Hi")


class TestEventFormatting:
    """Tests for event formatting."""

    def test_format_event_with_title_and_summary(
        self, adapter: MemoryManagerAdapter
    ) -> None:
        """Test formatting event with title and summary."""
        mock_event = MagicMock()
        mock_event.title = "Meeting"
        mock_event.summary = "Discussed budget"
        mock_event.event_type = "meeting"

        result = adapter._format_event_content(mock_event)

        assert "Meeting" in result
        assert "Discussed budget" in result

    def test_format_event_with_title_only(self, adapter: MemoryManagerAdapter) -> None:
        """Test formatting event with title only."""
        mock_event = MagicMock()
        mock_event.title = "Quick note"
        mock_event.summary = None
        mock_event.event_type = "note"

        result = adapter._format_event_content(mock_event)

        assert result == "Quick note"

    def test_format_event_no_title_or_summary(
        self, adapter: MemoryManagerAdapter
    ) -> None:
        """Test formatting event without title or summary."""
        mock_event = MagicMock()
        mock_event.title = None
        mock_event.summary = None
        mock_event.event_type = "action"

        result = adapter._format_event_content(mock_event)

        assert "Event: action" in result


class TestPersonFormatting:
    """Tests for person formatting."""

    def test_format_person_full(self, adapter: MemoryManagerAdapter) -> None:
        """Test formatting person with all fields."""
        mock_person = MagicMock()
        mock_person.name = "Jane Smith"
        mock_person.company = "Tech Inc"
        mock_person.relationship_type = "partner"

        result = adapter._format_person_content(mock_person)

        assert "Jane Smith" in result
        assert "Tech Inc" in result
        assert "partner" in result

    def test_format_person_minimal(self, adapter: MemoryManagerAdapter) -> None:
        """Test formatting person with minimal fields."""
        mock_person = MagicMock()
        mock_person.name = "Bob"
        mock_person.company = None
        mock_person.relationship_type = None

        result = adapter._format_person_content(mock_person)

        assert "Person: Bob" in result


class TestProjectFormatting:
    """Tests for project formatting."""

    def test_format_project_full(self, adapter: MemoryManagerAdapter) -> None:
        """Test formatting project with all fields."""
        mock_project = MagicMock()
        mock_project.name = "Alpha"
        mock_project.status = "active"
        mock_project.description = "Main project for Q1"

        result = adapter._format_project_content(mock_project)

        assert "Alpha" in result
        assert "active" in result
        assert "Main project" in result

    def test_format_project_long_description_truncated(
        self, adapter: MemoryManagerAdapter
    ) -> None:
        """Test that long descriptions are truncated."""
        mock_project = MagicMock()
        mock_project.name = "Beta"
        mock_project.status = "planning"
        mock_project.description = "x" * 200

        result = adapter._format_project_content(mock_project)

        # Description should be truncated to 100 chars
        assert len(result) < 200

    def test_format_project_no_description(self, adapter: MemoryManagerAdapter) -> None:
        """Test formatting project without description."""
        mock_project = MagicMock()
        mock_project.name = "Gamma"
        mock_project.status = "complete"
        mock_project.description = None

        result = adapter._format_project_content(mock_project)

        assert "Gamma" in result
        assert "complete" in result
