"""Tests for Memory Hooks.

This module contains tests for the MemoryHooks class
that integrates memory with Claude Agent SDK lifecycle.
"""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import pytest
from digital_valerii_shared.agent.core.hooks import MemoryHooks
from digital_valerii_shared.agent.personality.models import MemoryReference


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    manager = MagicMock()
    manager.recall = AsyncMock(return_value=[])
    manager.store = AsyncMock(return_value=None)
    return manager


@pytest.fixture
def memory_hooks(mock_memory_manager: MagicMock) -> MemoryHooks:
    """Create MemoryHooks instance with mock manager."""
    return MemoryHooks(mock_memory_manager)


class TestMemoryHooksInit:
    """Tests for MemoryHooks initialization."""

    def test_init_with_memory_manager(self, mock_memory_manager: MagicMock) -> None:
        """Test initialization with memory manager."""
        hooks = MemoryHooks(mock_memory_manager)
        assert hooks._memory == mock_memory_manager
        assert hooks.recalled_memories == []

    def test_initial_state(self, memory_hooks: MemoryHooks) -> None:
        """Test initial state of hooks."""
        assert memory_hooks._last_prompt is None
        assert memory_hooks._recalled_memories == []
        assert memory_hooks._conversation_id is None
        assert memory_hooks._interface is None


class TestMemoryHooksContext:
    """Tests for context setting."""

    def test_set_context(self, memory_hooks: MemoryHooks) -> None:
        """Test setting context."""
        memory_hooks.set_context(
            conversation_id="conv-123",
            interface="slack",
        )
        assert memory_hooks._conversation_id == "conv-123"
        assert memory_hooks._interface == "slack"

    def test_set_context_partial(self, memory_hooks: MemoryHooks) -> None:
        """Test setting partial context."""
        memory_hooks.set_context(conversation_id="conv-456")
        assert memory_hooks._conversation_id == "conv-456"
        assert memory_hooks._interface is None

    def test_clear(self, memory_hooks: MemoryHooks) -> None:
        """Test clearing hook state."""
        memory_hooks.set_context("conv-123", "web")
        memory_hooks._last_prompt = "test"
        memory_hooks._recalled_memories = [
            MemoryReference(
                content="test",
                timestamp=datetime.now(tz=UTC),
                relevance=0.9,
            )
        ]

        memory_hooks.clear()

        assert memory_hooks._last_prompt is None
        assert memory_hooks._recalled_memories == []
        assert memory_hooks._conversation_id is None
        assert memory_hooks._interface is None


class TestOnSessionStart:
    """Tests for on_session_start hook."""

    @pytest.mark.asyncio
    async def test_session_start_recalls_memories(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that session start recalls memories."""
        mock_memory_manager.recall.return_value = [
            MemoryReference(
                content="Previous conversation",
                timestamp=datetime.now(tz=UTC),
                relevance=0.9,
            ),
        ]

        result = await memory_hooks.on_session_start(
            input_data={"prompt": "Hello"},
            tool_use_id="tool-1",
            context={},
        )

        mock_memory_manager.recall.assert_called_once()
        assert len(memory_hooks.recalled_memories) == 1
        assert "memory_context" in result

    @pytest.mark.asyncio
    async def test_session_start_best_effort_on_error(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that session start handles errors gracefully (best-effort)."""
        mock_memory_manager.recall.side_effect = Exception("Database unavailable")

        # Should NOT raise - best-effort behavior
        result = await memory_hooks.on_session_start(
            input_data={"prompt": "Hello"},
            tool_use_id="tool-1",
            context={},
        )

        # Should return empty dict and continue
        assert result == {}
        assert memory_hooks.recalled_memories == []

    @pytest.mark.asyncio
    async def test_session_start_clears_memories_on_error(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that memories are cleared on recall error."""
        # Pre-populate memories
        memory_hooks._recalled_memories = [
            MemoryReference(
                content="Old memory",
                timestamp=datetime.now(tz=UTC),
                relevance=0.5,
            ),
        ]
        mock_memory_manager.recall.side_effect = Exception("Network error")

        await memory_hooks.on_session_start(
            input_data={"prompt": "Hello"},
            tool_use_id="tool-1",
            context={},
        )

        # Old memories should be cleared
        assert memory_hooks.recalled_memories == []

    @pytest.mark.asyncio
    async def test_session_start_no_prompt(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test session start with no prompt."""
        result = await memory_hooks.on_session_start(
            input_data={},
            tool_use_id="tool-1",
            context={},
        )

        mock_memory_manager.recall.assert_not_called()
        assert result == {}

    @pytest.mark.asyncio
    async def test_session_start_empty_recall(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test session start with no recalled memories."""
        mock_memory_manager.recall.return_value = []

        result = await memory_hooks.on_session_start(
            input_data={"prompt": "Hello"},
            tool_use_id="tool-1",
            context={},
        )

        assert result == {}

    @pytest.mark.asyncio
    async def test_session_start_stores_prompt(
        self,
        memory_hooks: MemoryHooks,
    ) -> None:
        """Test that session start stores the prompt."""
        await memory_hooks.on_session_start(
            input_data={"prompt": "Test prompt"},
            tool_use_id="tool-1",
            context={},
        )

        assert memory_hooks._last_prompt == "Test prompt"


class TestOnStop:
    """Tests for on_stop hook."""

    @pytest.mark.asyncio
    async def test_stop_stores_interaction(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that stop hook stores interaction."""
        memory_hooks._last_prompt = "User message"

        result = await memory_hooks.on_stop(
            input_data={},
            tool_use_id="tool-1",
            context={"response": "Agent response"},
        )

        mock_memory_manager.store.assert_called_once_with(
            message="User message",
            response="Agent response",
            conversation_id=None,
            interface=None,
        )
        assert result == {}

    @pytest.mark.asyncio
    async def test_stop_no_prompt(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test stop hook with no prompt."""
        result = await memory_hooks.on_stop(
            input_data={},
            tool_use_id="tool-1",
            context={"response": "Response"},
        )

        mock_memory_manager.store.assert_not_called()
        assert result == {}

    @pytest.mark.asyncio
    async def test_stop_no_response(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test stop hook with no response."""
        memory_hooks._last_prompt = "User message"

        result = await memory_hooks.on_stop(
            input_data={},
            tool_use_id="tool-1",
            context={},
        )

        mock_memory_manager.store.assert_not_called()
        assert result == {}

    @pytest.mark.asyncio
    async def test_stop_with_context(
        self,
        memory_hooks: MemoryHooks,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test stop hook with full context."""
        memory_hooks.set_context("conv-123", "slack")
        memory_hooks._last_prompt = "Hello"

        await memory_hooks.on_stop(
            input_data={},
            tool_use_id="tool-1",
            context={"response": "Hi there"},
        )

        mock_memory_manager.store.assert_called_once_with(
            message="Hello",
            response="Hi there",
            conversation_id="conv-123",
            interface="slack",
        )


class TestHookConfig:
    """Tests for hook configuration."""

    def test_get_hook_config(self, memory_hooks: MemoryHooks) -> None:
        """Test getting hook configuration."""
        config = memory_hooks.get_hook_config()

        assert "SessionStart" in config
        assert "Stop" in config
        assert config["SessionStart"]["handler"] == memory_hooks.on_session_start
        assert config["Stop"]["handler"] == memory_hooks.on_stop


class TestMemoryFormatting:
    """Tests for memory formatting."""

    def test_format_memories_empty(self, memory_hooks: MemoryHooks) -> None:
        """Test formatting empty memories."""
        result = memory_hooks._format_memories_for_context()
        assert result == ""

    def test_format_memories_single(self, memory_hooks: MemoryHooks) -> None:
        """Test formatting single memory."""
        memory_hooks._recalled_memories = [
            MemoryReference(
                content="Important fact",
                timestamp=datetime.now(tz=UTC),
                relevance=0.9,
            ),
        ]

        result = memory_hooks._format_memories_for_context()

        assert "Important fact" in result
        assert "Relevant memories" in result

    def test_format_memories_sorted_by_relevance(
        self, memory_hooks: MemoryHooks
    ) -> None:
        """Test that memories are sorted by relevance."""
        now = datetime.now(tz=UTC)
        memory_hooks._recalled_memories = [
            MemoryReference(content="Low relevance", timestamp=now, relevance=0.3),
            MemoryReference(content="High relevance", timestamp=now, relevance=0.9),
        ]

        result = memory_hooks._format_memories_for_context()

        assert result.index("High relevance") < result.index("Low relevance")
