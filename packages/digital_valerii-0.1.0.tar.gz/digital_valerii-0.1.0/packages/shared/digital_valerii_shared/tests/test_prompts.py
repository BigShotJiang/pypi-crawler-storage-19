"""Tests for PromptBuilder.

This module contains tests for the PromptBuilder class,
covering section combining, context injection, and token estimation.
"""

from datetime import UTC, datetime

from digital_valerii_shared.agent.personality import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    MemoryReference,
    PersonalityConfig,
    PersonalityPrompt,
    PersonalitySection,
    PersonReference,
    ProjectReference,
)
from digital_valerii_shared.agent.personality.prompts import PromptBuilder


class TestPromptBuilderCombineSections:
    """Tests for combine_sections method."""

    def test_combine_sections_single(self) -> None:
        """Test combining a single section."""
        builder = PromptBuilder()
        sections = {PersonalitySection.BASE: "Base content"}
        result = builder.combine_sections(sections)

        assert result == "Base content"

    def test_combine_sections_multiple(self) -> None:
        """Test combining multiple sections."""
        builder = PromptBuilder()
        sections = {
            PersonalitySection.BASE: "Base content",
            PersonalitySection.COMMUNICATION: "Communication content",
        }
        result = builder.combine_sections(sections)

        assert "Base content" in result
        assert "Communication content" in result
        assert "---" in result  # Separator

    def test_combine_sections_respects_order(self) -> None:
        """Test that sections are combined in specified order."""
        builder = PromptBuilder()
        sections = {
            PersonalitySection.COMMUNICATION: "Second",
            PersonalitySection.BASE: "First",
        }
        order = (PersonalitySection.BASE, PersonalitySection.COMMUNICATION)
        result = builder.combine_sections(sections, order=order)

        assert result.index("First") < result.index("Second")

    def test_combine_sections_empty(self) -> None:
        """Test combining empty sections dict."""
        builder = PromptBuilder()
        result = builder.combine_sections({})

        assert result == ""


class TestPromptBuilderInjectContext:
    """Tests for inject_context method."""

    def test_inject_context_date(self) -> None:
        """Test injecting current date."""
        builder = PromptBuilder()
        context = DynamicContext(
            current_date=datetime(2024, 1, 15, 12, 0, 0, tzinfo=UTC)
        )
        prompt = "Today is {{current_date}}"
        result = builder.inject_context(prompt, context)

        assert "2024-01-15" in result

    def test_inject_context_projects(self) -> None:
        """Test injecting projects."""
        builder = PromptBuilder()
        context = DynamicContext(
            projects=(ProjectReference(name="Test Project", client="ACME"),)
        )
        prompt = "Projects: {{projects}}"
        result = builder.inject_context(prompt, context)

        assert "Test Project" in result
        assert "ACME" in result

    def test_inject_context_people(self) -> None:
        """Test injecting people."""
        builder = PromptBuilder()
        context = DynamicContext(
            people=(PersonReference(name="John", relation="colleague"),)
        )
        prompt = "People: {{people}}"
        result = builder.inject_context(prompt, context)

        assert "John" in result
        assert "colleague" in result

    def test_inject_context_unknown_placeholder(self) -> None:
        """Test that unknown placeholders are preserved."""
        builder = PromptBuilder()
        context = DynamicContext()
        prompt = "Unknown: {{unknown_placeholder}}"
        result = builder.inject_context(prompt, context)

        assert "{{unknown_placeholder}}" in result

    def test_inject_context_empty_projects(self) -> None:
        """Test injecting when no projects exist."""
        builder = PromptBuilder()
        context = DynamicContext(projects=())
        prompt = "Projects: {{projects}}"
        result = builder.inject_context(prompt, context)

        assert "No active projects" in result


class TestPromptBuilderEstimateTokens:
    """Tests for estimate_tokens method."""

    def test_estimate_tokens_english(self) -> None:
        """Test token estimation for English text."""
        builder = PromptBuilder()
        text = "This is a test"  # 14 chars, ~3-4 tokens
        tokens = builder.estimate_tokens(text, LanguageMode.ENGLISH)

        assert 2 <= tokens <= 5

    def test_estimate_tokens_ukrainian(self) -> None:
        """Test token estimation for Ukrainian text."""
        builder = PromptBuilder()
        text = "Це тест"  # Ukrainian text
        tokens = builder.estimate_tokens(text, LanguageMode.UKRAINIAN)

        assert tokens > 0

    def test_estimate_tokens_auto(self) -> None:
        """Test automatic language detection for token estimation."""
        builder = PromptBuilder()
        english = builder.estimate_tokens("Hello world", LanguageMode.AUTO)
        ukrainian = builder.estimate_tokens("Привіт світ", LanguageMode.AUTO)

        assert english > 0
        assert ukrainian > 0

    def test_estimate_tokens_empty(self) -> None:
        """Test token estimation for empty text."""
        builder = PromptBuilder()
        tokens = builder.estimate_tokens("")

        assert tokens == 0


class TestPromptBuilderBuildPrompt:
    """Tests for build_prompt method."""

    def test_build_prompt_returns_personality_prompt(self) -> None:
        """Test that build_prompt returns PersonalityPrompt."""
        builder = PromptBuilder()
        sections = {PersonalitySection.BASE: "Content"}
        config = PersonalityConfig()
        result = builder.build_prompt(sections, config)

        assert isinstance(result, PersonalityPrompt)

    def test_build_prompt_with_context(self) -> None:
        """Test building prompt with context injection."""
        builder = PromptBuilder()
        sections = {PersonalitySection.BASE: "Date: {{current_date}}"}
        config = PersonalityConfig()
        context = DynamicContext()
        result = builder.build_prompt(sections, config, context)

        assert result.context_injected is True
        assert "{{current_date}}" not in result.content

    def test_build_prompt_without_context(self) -> None:
        """Test building prompt without context."""
        builder = PromptBuilder()
        sections = {PersonalitySection.BASE: "Content"}
        config = PersonalityConfig()
        result = builder.build_prompt(sections, config, None)

        assert result.context_injected is False

    def test_build_prompt_respects_sections_config(self) -> None:
        """Test that only configured sections are included."""
        builder = PromptBuilder()
        sections = {
            PersonalitySection.BASE: "Base",
            PersonalitySection.EXAMPLES: "Examples",
        }
        config = PersonalityConfig(sections=(PersonalitySection.BASE,))
        result = builder.build_prompt(sections, config)

        assert PersonalitySection.BASE in result.sections_included
        assert PersonalitySection.EXAMPLES not in result.sections_included

    def test_build_prompt_excludes_examples(self) -> None:
        """Test that examples can be excluded."""
        builder = PromptBuilder()
        sections = {
            PersonalitySection.BASE: "Base",
            PersonalitySection.EXAMPLES: "Examples",
        }
        config = PersonalityConfig(include_examples=False)
        result = builder.build_prompt(sections, config)

        assert "Examples" not in result.content


class TestPromptBuilderModeInstructions:
    """Tests for mode instruction handling."""

    def test_add_mode_instructions_assessment(self) -> None:
        """Test adding assessment mode instructions."""
        builder = PromptBuilder()
        result = builder.add_mode_instructions("Base", ConversationMode.ASSESSMENT)

        assert "ASSESSMENT" in result
        assert "evidence" in result.lower() or "assessment" in result.lower()

    def test_add_mode_instructions_casual(self) -> None:
        """Test adding casual mode instructions."""
        builder = PromptBuilder()
        result = builder.add_mode_instructions("Base", ConversationMode.CASUAL)

        assert "CASUAL" in result

    def test_add_mode_instructions_technical(self) -> None:
        """Test adding technical mode instructions."""
        builder = PromptBuilder()
        result = builder.add_mode_instructions("Base", ConversationMode.TECHNICAL)

        assert "TECHNICAL" in result

    def test_add_mode_instructions_meeting(self) -> None:
        """Test adding meeting mode instructions."""
        builder = PromptBuilder()
        result = builder.add_mode_instructions("Base", ConversationMode.MEETING)

        assert "MEETING" in result


class TestPromptBuilderMemories:
    """Tests for memory handling in context injection."""

    def test_inject_memories(self) -> None:
        """Test injecting memories into context."""
        builder = PromptBuilder()
        context = DynamicContext(
            memories=(
                MemoryReference(
                    content="Important memory",
                    timestamp=datetime.now(tz=UTC),
                    relevance=0.9,
                ),
            )
        )
        prompt = "Memories: {{memories}}"
        result = builder.inject_context(prompt, context)

        assert "Important memory" in result

    def test_inject_memories_sorted_by_relevance(self) -> None:
        """Test that memories are sorted by relevance."""
        builder = PromptBuilder()
        now = datetime.now(tz=UTC)
        context = DynamicContext(
            memories=(
                MemoryReference(content="Low relevance", timestamp=now, relevance=0.3),
                MemoryReference(content="High relevance", timestamp=now, relevance=0.9),
            )
        )
        prompt = "{{memories}}"
        result = builder.inject_context(prompt, context)

        # High relevance should come before low relevance
        assert result.index("High relevance") < result.index("Low relevance")


class TestAutoModeTruncation:
    """Tests for AUTO mode truncation using detected character ratio."""

    def test_truncate_ukrainian_content_uses_correct_ratio(self) -> None:
        """Test that Ukrainian content is truncated using correct ratio."""
        builder = PromptBuilder()
        # Create Ukrainian-heavy content (about 200 chars)
        ukrainian_text = "Привіт світ! " * 20  # ~260 chars of Ukrainian

        # Truncate to 50 tokens
        truncated, tokens = builder.truncate_to_budget(
            ukrainian_text, max_tokens=50, language=LanguageMode.AUTO
        )

        # Should use Ukrainian ratio (~2 chars/token), so ~100 chars
        # The truncated content should be shorter than original
        assert len(truncated) < len(ukrainian_text)
        assert tokens <= 50

    def test_truncate_english_content_uses_correct_ratio(self) -> None:
        """Test that English content is truncated using correct ratio."""
        builder = PromptBuilder()
        # Create English content (about 200 chars)
        english_text = "Hello world! " * 20  # ~260 chars of English

        # Truncate to 50 tokens
        truncated, tokens = builder.truncate_to_budget(
            english_text, max_tokens=50, language=LanguageMode.AUTO
        )

        # Should use English ratio (~4 chars/token), so ~200 chars
        assert tokens <= 50

    def test_truncate_mixed_content(self) -> None:
        """Test truncation of mixed Ukrainian/English content."""
        builder = PromptBuilder()
        # Mixed content
        mixed_text = "Hello world! Привіт світ! " * 15

        truncated, tokens = builder.truncate_to_budget(
            mixed_text, max_tokens=30, language=LanguageMode.AUTO
        )

        assert tokens <= 30
        assert "[Content truncated" in truncated

    def test_no_truncation_when_under_budget(self) -> None:
        """Test that content under budget is not truncated."""
        builder = PromptBuilder()
        short_text = "Short text"

        truncated, tokens = builder.truncate_to_budget(
            short_text, max_tokens=100, language=LanguageMode.AUTO
        )

        assert truncated == short_text
        assert "[Content truncated" not in truncated
