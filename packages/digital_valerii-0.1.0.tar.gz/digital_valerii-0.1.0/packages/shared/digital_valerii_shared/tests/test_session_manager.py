"""Tests for Unified Session Manager service."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from packages.shared.digital_valerii_shared.config import DatabaseSettings
from packages.shared.digital_valerii_shared.database import IsolatedDatabase
from packages.shared.digital_valerii_shared.services.session_manager import (
    AgentResponse,
    ChannelType,
    CheckpointType,
    MessageStatus,
    QueuedMessage,
    SessionCheckpoint,
    SessionNotFoundError,
    SessionStatus,
    UnifiedSessionManager,
    UserSession,
)


class TestEnums:
    """Tests for session manager enums."""

    def test_session_status_values(self) -> None:
        """Test SessionStatus enum has correct values."""
        assert SessionStatus.ACTIVE.value == "active"
        assert SessionStatus.PAUSED.value == "paused"
        assert SessionStatus.ARCHIVED.value == "archived"

    def test_channel_type_values(self) -> None:
        """Test ChannelType enum has correct values."""
        assert ChannelType.WEB.value == "web"
        assert ChannelType.SLACK.value == "slack"
        assert ChannelType.MEETING.value == "meeting"
        assert ChannelType.CLI.value == "cli"

    def test_message_status_values(self) -> None:
        """Test MessageStatus enum has correct values."""
        assert MessageStatus.PENDING.value == "pending"
        assert MessageStatus.PROCESSING.value == "processing"
        assert MessageStatus.COMPLETED.value == "completed"
        assert MessageStatus.FAILED.value == "failed"

    def test_checkpoint_type_values(self) -> None:
        """Test CheckpointType enum has correct values."""
        assert CheckpointType.PRE_COMPACT.value == "pre_compact"
        assert CheckpointType.MANUAL.value == "manual"
        assert CheckpointType.RECOVERY.value == "recovery"


class TestModels:
    """Tests for Pydantic models."""

    def test_user_session_extra_forbid(self) -> None:
        """Test UserSession rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            UserSession(  # type: ignore[call-arg]
                id=uuid4(),
                user_id=uuid4(),
                last_activity_at=now,
                created_at=now,
                updated_at=now,
                extra_field="not allowed",
            )

    def test_user_session_valid(self) -> None:
        """Test UserSession accepts valid data."""
        now = datetime.now(UTC)
        session = UserSession(
            id=uuid4(),
            user_id=uuid4(),
            sdk_session_id="sdk-123",
            status=SessionStatus.ACTIVE,
            last_channel="web",
            last_activity_at=now,
            compact_count=5,
            checkpoint={"key": "value"},
            created_at=now,
            updated_at=now,
        )
        assert session.status == SessionStatus.ACTIVE
        assert session.compact_count == 5

    def test_session_checkpoint_extra_forbid(self) -> None:
        """Test SessionCheckpoint rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            SessionCheckpoint(  # type: ignore[call-arg]
                id=uuid4(),
                user_session_id=uuid4(),
                checkpoint_type=CheckpointType.PRE_COMPACT,
                created_at=now,
                extra_field="not allowed",
            )

    def test_session_checkpoint_valid(self) -> None:
        """Test SessionCheckpoint accepts valid data."""
        now = datetime.now(UTC)
        checkpoint = SessionCheckpoint(
            id=uuid4(),
            user_session_id=uuid4(),
            checkpoint_type=CheckpointType.PRE_COMPACT,
            summary="Test summary",
            working_memory={"topics": ["test"]},
            active_context={"project": "test-project"},
            message_count=100,
            created_at=now,
        )
        assert checkpoint.checkpoint_type == CheckpointType.PRE_COMPACT
        assert checkpoint.summary == "Test summary"

    def test_queued_message_extra_forbid(self) -> None:
        """Test QueuedMessage rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            QueuedMessage(  # type: ignore[call-arg]
                id=uuid4(),
                user_session_id=uuid4(),
                channel="web",
                content="Hello",
                created_at=now,
                extra_field="not allowed",
            )

    def test_queued_message_valid(self) -> None:
        """Test QueuedMessage accepts valid data."""
        now = datetime.now(UTC)
        message = QueuedMessage(
            id=uuid4(),
            user_session_id=uuid4(),
            channel="slack",
            content="Test message",
            metadata={"thread_ts": "123.456"},
            priority=5,
            status=MessageStatus.PENDING,
            created_at=now,
        )
        assert message.channel == "slack"
        assert message.priority == 5

    def test_agent_response_extra_forbid(self) -> None:
        """Test AgentResponse rejects extra fields."""
        with pytest.raises(ValueError):
            AgentResponse(  # type: ignore[call-arg]
                message_id=uuid4(),
                content="Response",
                channel="web",
                extra_field="not allowed",
            )

    def test_agent_response_valid(self) -> None:
        """Test AgentResponse accepts valid data."""
        response = AgentResponse(
            message_id=uuid4(),
            content="Test response",
            channel="web",
            metadata={"key": "value"},
        )
        assert response.content == "Test response"


@pytest.mark.asyncio
class TestUnifiedSessionManager:
    """Tests for UnifiedSessionManager service."""

    async def test_get_or_create_session_creates_new(self) -> None:
        """Test get_or_create_session creates new session for user."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            user_session = await manager.get_or_create_session(user_id)

            assert user_session.user_id == user_id
            assert user_session.status == SessionStatus.ACTIVE
            assert user_session.id is not None
            assert user_session.compact_count == 0

        await db.close()

    async def test_get_or_create_session_returns_existing(self) -> None:
        """Test get_or_create_session returns existing active session."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # Create session
            session1 = await manager.get_or_create_session(user_id)

            # Get same session
            session2 = await manager.get_or_create_session(user_id)

            assert session1.id == session2.id

        await db.close()

    async def test_get_session_returns_none_when_no_session(self) -> None:
        """Test get_session returns None when no active session."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            result = await manager.get_session(user_id)

            assert result is None

        await db.close()

    async def test_get_session_returns_active_session(self) -> None:
        """Test get_session returns active session."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            created = await manager.get_or_create_session(user_id)
            fetched = await manager.get_session(user_id)

            assert fetched is not None
            assert fetched.id == created.id

        await db.close()

    async def test_update_session_activity_updates_channel(self) -> None:
        """Test update_session_activity updates last_channel."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            await manager.update_session_activity(user_id, "slack")
            updated = await manager.get_session(user_id)

            assert updated is not None
            assert updated.last_channel == "slack"

        await db.close()

    async def test_update_session_activity_with_sdk_session(self) -> None:
        """Test update_session_activity updates sdk_session_id."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            await manager.update_session_activity(
                user_id, "web", sdk_session_id="sdk-session-123"
            )
            updated = await manager.get_session(user_id)

            assert updated is not None
            assert updated.sdk_session_id == "sdk-session-123"

        await db.close()

    async def test_enqueue_message_creates_message(self) -> None:
        """Test enqueue_message adds message to queue."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            message_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Hello, world!",
                metadata={"key": "value"},
            )

            assert message_id is not None

            # Verify message is pending
            pending = await manager.get_next_pending_message(user_id)
            assert pending is not None
            assert pending.id == message_id
            assert pending.content == "Hello, world!"
            assert pending.channel == "web"

        await db.close()

    async def test_enqueue_message_with_priority(self) -> None:
        """Test enqueue_message respects priority ordering."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # Enqueue low priority first
            await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Low priority",
                priority=1,
            )

            # Enqueue high priority second
            high_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="High priority",
                priority=10,
            )

            # Should get high priority first
            next_msg = await manager.get_next_pending_message(user_id)
            assert next_msg is not None
            assert next_msg.id == high_id
            assert next_msg.content == "High priority"

        await db.close()

    async def test_get_next_pending_message_returns_none_when_empty(self) -> None:
        """Test get_next_pending_message returns None for empty queue."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            # Create session but no messages
            await manager.get_or_create_session(user_id)

            result = await manager.get_next_pending_message(user_id)
            assert result is None

        await db.close()

    async def test_mark_message_processing(self) -> None:
        """Test mark_message_processing updates status."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            message_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Test",
            )

            await manager.mark_message_processing(message_id)

            # Message should no longer be pending
            pending = await manager.get_next_pending_message(user_id)
            assert pending is None

        await db.close()

    async def test_complete_message_success(self) -> None:
        """Test complete_message marks as completed."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            message_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Test",
            )

            await manager.mark_message_processing(message_id)
            await manager.complete_message(message_id, success=True)

            # Message should be gone from pending
            pending = await manager.get_next_pending_message(user_id)
            assert pending is None

        await db.close()

    async def test_complete_message_failure(self) -> None:
        """Test complete_message can mark as failed."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            message_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Test",
            )

            await manager.mark_message_processing(message_id)
            await manager.complete_message(message_id, success=False)

            # Message should be gone from pending (failed, not pending)
            pending = await manager.get_next_pending_message(user_id)
            assert pending is None

        await db.close()

    async def test_process_next_message(self) -> None:
        """Test process_next_message processes and returns response."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.enqueue_message(
                user_id=user_id,
                channel="slack",
                content="Hello!",
                metadata={"thread": "123"},
            )

            response = await manager.process_next_message(user_id)

            assert response is not None
            assert isinstance(response, AgentResponse)
            assert response.channel == "slack"
            assert "Hello!" in response.content

            # Queue should be empty now
            next_pending = await manager.get_next_pending_message(user_id)
            assert next_pending is None

        await db.close()

    async def test_process_next_message_empty_queue(self) -> None:
        """Test process_next_message returns None for empty queue."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            response = await manager.process_next_message(user_id)
            assert response is None

        await db.close()

    async def test_start_new_session_archives_current(self) -> None:
        """Test start_new_session archives current and creates new."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # Create first session
            first = await manager.get_or_create_session(user_id)
            first_id = first.id

            # Start new session
            second = await manager.start_new_session(user_id)

            assert second.id != first_id
            assert second.status == SessionStatus.ACTIVE
            assert second.compact_count == 0

            # Only one active session should exist
            active = await manager.get_session(user_id)
            assert active is not None
            assert active.id == second.id

        await db.close()

    async def test_save_checkpoint_creates_checkpoint(self) -> None:
        """Test save_checkpoint creates checkpoint record."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            checkpoint_id = await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="pre_compact",
                context={
                    "summary": "Test summary",
                    "working_memory": {"topics": ["project-x"]},
                    "active_context": {"project": "test"},
                    "message_count": 50,
                },
            )

            assert checkpoint_id is not None

            # Verify checkpoint can be retrieved
            latest = await manager.get_latest_checkpoint(user_id)
            assert latest is not None
            assert latest.id == checkpoint_id
            assert latest.summary == "Test summary"
            assert latest.checkpoint_type == CheckpointType.PRE_COMPACT

        await db.close()

    async def test_save_checkpoint_increments_compact_count(self) -> None:
        """Test save_checkpoint with pre_compact increments compact_count."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            # Save pre_compact checkpoint
            await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="pre_compact",
                context={"summary": "First compact"},
            )

            # Check compact count increased
            user_session = await manager.get_session(user_id)
            assert user_session is not None
            assert user_session.compact_count == 1

            # Save another
            await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="pre_compact",
                context={"summary": "Second compact"},
            )

            user_session = await manager.get_session(user_id)
            assert user_session is not None
            assert user_session.compact_count == 2

        await db.close()

    async def test_save_checkpoint_raises_when_no_session(self) -> None:
        """Test save_checkpoint raises SessionNotFoundError when no session."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            with pytest.raises(SessionNotFoundError) as exc_info:
                await manager.save_checkpoint(
                    user_id=user_id,
                    checkpoint_type="manual",
                    context={"summary": "Test"},
                )

            assert exc_info.value.user_id == user_id

        await db.close()

    async def test_get_latest_checkpoint_returns_most_recent(self) -> None:
        """Test get_latest_checkpoint returns most recent checkpoint."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            # Save first checkpoint
            await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="manual",
                context={"summary": "First"},
            )

            # Save second checkpoint
            second_id = await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="manual",
                context={"summary": "Second"},
            )

            latest = await manager.get_latest_checkpoint(user_id)
            assert latest is not None
            assert latest.id == second_id
            assert latest.summary == "Second"

        await db.close()

    async def test_get_latest_checkpoint_returns_none_when_no_checkpoints(self) -> None:
        """Test get_latest_checkpoint returns None when no checkpoints exist."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            latest = await manager.get_latest_checkpoint(user_id)
            assert latest is None

        await db.close()

    async def test_get_queue_length_returns_pending_count(self) -> None:
        """Test get_queue_length returns correct count of pending messages."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # Initially empty
            await manager.get_or_create_session(user_id)
            assert await manager.get_queue_length(user_id) == 0

            # Add messages
            await manager.enqueue_message(user_id, "web", "Message 1")
            await manager.enqueue_message(user_id, "web", "Message 2")
            await manager.enqueue_message(user_id, "web", "Message 3")

            assert await manager.get_queue_length(user_id) == 3

            # Process one
            await manager.process_next_message(user_id)

            assert await manager.get_queue_length(user_id) == 2

        await db.close()

    async def test_get_queue_length_returns_zero_when_no_session(self) -> None:
        """Test get_queue_length returns 0 when no session exists."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            count = await manager.get_queue_length(user_id)
            assert count == 0

        await db.close()


@pytest.mark.asyncio
class TestUserIsolation:
    """Tests verifying user data isolation."""

    async def test_sessions_are_user_isolated(self) -> None:
        """Test that sessions are isolated between users."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user1 = uuid4()
        user2 = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            session1 = await manager.get_or_create_session(user1)
            session2 = await manager.get_or_create_session(user2)

            assert session1.id != session2.id
            assert session1.user_id == user1
            assert session2.user_id == user2

            # User1 should only see their session
            fetched1 = await manager.get_session(user1)
            assert fetched1 is not None
            assert fetched1.id == session1.id

        await db.close()

    async def test_messages_are_user_isolated(self) -> None:
        """Test that message queues are isolated between users."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user1 = uuid4()
        user2 = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # User1 enqueues message
            await manager.enqueue_message(user1, "web", "User1 message")

            # User2 enqueues message
            await manager.enqueue_message(user2, "web", "User2 message")

            # Each user should only see their own messages
            msg1 = await manager.get_next_pending_message(user1)
            msg2 = await manager.get_next_pending_message(user2)

            assert msg1 is not None
            assert msg2 is not None
            assert msg1.content == "User1 message"
            assert msg2.content == "User2 message"

        await db.close()

    async def test_checkpoints_are_user_isolated(self) -> None:
        """Test that checkpoints are isolated between users."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user1 = uuid4()
        user2 = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)

            # Create sessions
            await manager.get_or_create_session(user1)
            await manager.get_or_create_session(user2)

            # Save checkpoints
            await manager.save_checkpoint(
                user1, "manual", {"summary": "User1 checkpoint"}
            )
            await manager.save_checkpoint(
                user2, "manual", {"summary": "User2 checkpoint"}
            )

            # Each user should only see their own checkpoint
            cp1 = await manager.get_latest_checkpoint(user1)
            cp2 = await manager.get_latest_checkpoint(user2)

            assert cp1 is not None
            assert cp2 is not None
            assert cp1.summary == "User1 checkpoint"
            assert cp2.summary == "User2 checkpoint"

        await db.close()


@pytest.mark.asyncio
class TestTimestamps:
    """Tests for UTC timestamp handling."""

    async def test_session_timestamps_are_utc(self) -> None:
        """Test that session timestamps are in UTC."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        before = datetime.now(UTC)

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            user_session = await manager.get_or_create_session(user_id)

            after = datetime.now(UTC)

            # Make timestamps offset-aware for comparison
            created = user_session.created_at.replace(tzinfo=UTC)
            assert before <= created <= after

        await db.close()

    async def test_checkpoint_timestamps_are_utc(self) -> None:
        """Test that checkpoint timestamps are in UTC."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        user_id = uuid4()

        async with db.session() as session:
            manager = UnifiedSessionManager(session)
            await manager.get_or_create_session(user_id)

            before = datetime.now(UTC)

            await manager.save_checkpoint(
                user_id=user_id,
                checkpoint_type="manual",
                context={"summary": "Test"},
            )

            after = datetime.now(UTC)

            checkpoint = await manager.get_latest_checkpoint(user_id)
            assert checkpoint is not None

            # Make timestamp offset-aware for comparison
            created = checkpoint.created_at.replace(tzinfo=UTC)
            assert before <= created <= after

        await db.close()
