"""Tests for parallel workflow pattern.

Component 4.11: Orchestration Patterns
"""

import asyncio

import pytest
from digital_valerii_shared.workflows.base import (
    Aggregator,
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)
from digital_valerii_shared.workflows.parallel import ParallelWorkflow


class AddValueStep(WorkflowStep):
    """Test step that adds a value to context."""

    def __init__(self, key: str, value: str, delay: float = 0):
        self.key = key
        self.value = value
        self.delay = delay

    @property
    def name(self) -> str:
        return f"AddValue_{self.key}"

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        if self.delay:
            await asyncio.sleep(self.delay)
        context.data[self.key] = self.value
        return context


class FailingStep(WorkflowStep):
    """Test step that always fails."""

    def __init__(self, name_suffix: str = ""):
        self._name_suffix = name_suffix

    @property
    def name(self) -> str:
        return f"FailingStep{self._name_suffix}"

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        raise ValueError("Intentional failure")


class SumAggregator(Aggregator):
    """Test aggregator that sums numeric values."""

    async def aggregate(
        self, results: list[WorkflowContext], context: WorkflowContext
    ) -> WorkflowContext:
        total = sum(r.data.get("value", 0) for r in results)
        context.data["sum"] = total
        return context


class TestParallelWorkflow:
    """Tests for ParallelWorkflow."""

    @pytest.mark.asyncio
    async def test_empty_workflow(self) -> None:
        """Test workflow with no steps."""
        workflow = ParallelWorkflow([])
        result = await workflow.run()

        assert result.data == {}
        assert result.history == []

    @pytest.mark.asyncio
    async def test_single_step(self) -> None:
        """Test workflow with single step."""
        workflow = ParallelWorkflow([AddValueStep("key", "value")])
        result = await workflow.run()

        assert result.data == {"key": "value"}
        assert len(result.history) == 1
        assert result.history[0]["status"] == "completed"

    @pytest.mark.asyncio
    async def test_all_steps_succeed(self) -> None:
        """Test all steps succeeding in parallel."""
        workflow = ParallelWorkflow(
            [
                AddValueStep("first", "1"),
                AddValueStep("second", "2"),
                AddValueStep("third", "3"),
            ]
        )
        result = await workflow.run()

        assert result.data == {"first": "1", "second": "2", "third": "3"}
        assert len(result.history) == 3
        assert all(h["status"] == "completed" for h in result.history)

    @pytest.mark.asyncio
    async def test_steps_run_concurrently(self) -> None:
        """Test that steps actually run in parallel."""
        # If sequential, this would take 0.3s. In parallel, ~0.1s
        import time

        workflow = ParallelWorkflow(
            [
                AddValueStep("a", "1", delay=0.1),
                AddValueStep("b", "2", delay=0.1),
                AddValueStep("c", "3", delay=0.1),
            ]
        )

        start = time.time()
        await workflow.run()
        elapsed = time.time() - start

        # Should complete in ~0.1s, not 0.3s
        assert elapsed < 0.25

    @pytest.mark.asyncio
    async def test_partial_failure_without_fail_fast(self) -> None:
        """Test partial failure with fail_fast=False."""
        workflow = ParallelWorkflow(
            [
                AddValueStep("success", "value"),
                FailingStep(),
            ],
            fail_fast=False,
        )
        result = await workflow.run()

        # Should have success data
        assert result.data["success"] == "value"
        # Should have error info
        assert result.data["partial_failure"] is True
        assert len(result.data["errors"]) == 1
        assert result.data["errors"][0]["step"] == "FailingStep"

    @pytest.mark.asyncio
    async def test_fail_fast_raises_immediately(self) -> None:
        """Test fail_fast=True raises error."""
        workflow = ParallelWorkflow(
            [
                AddValueStep("success", "value"),
                FailingStep(),
            ],
            fail_fast=True,
        )

        with pytest.raises(WorkflowError) as exc_info:
            await workflow.run()

        # True fail-fast with TaskGroup includes error type in message
        assert "fail_fast" in str(exc_info.value)
        assert "ValueError" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_all_steps_fail(self) -> None:
        """Test all steps failing."""
        workflow = ParallelWorkflow(
            [
                FailingStep("1"),
                FailingStep("2"),
            ],
            fail_fast=False,
        )
        result = await workflow.run()

        assert result.data["partial_failure"] is True
        assert len(result.data["errors"]) == 2

    @pytest.mark.asyncio
    async def test_custom_aggregator(self) -> None:
        """Test custom aggregator is used."""

        class NumberStep(WorkflowStep):
            def __init__(self, value: int):
                self._value = value

            @property
            def name(self) -> str:
                return f"Number_{self._value}"

            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                context.data["value"] = self._value
                return context

        workflow = ParallelWorkflow(
            [NumberStep(10), NumberStep(20), NumberStep(30)],
            aggregator=SumAggregator(),
        )
        result = await workflow.run()

        assert result.data["sum"] == 60

    @pytest.mark.asyncio
    async def test_initial_context_copied(self) -> None:
        """Test each step gets a copy of context, not the original."""
        initial = WorkflowContext(data={"shared": "initial"})

        class ModifyStep(WorkflowStep):
            def __init__(self, key: str):
                self._key = key

            @property
            def name(self) -> str:
                return f"Modify_{self._key}"

            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                # Modify shared data - should not affect other steps
                context.data["shared"] = self._key
                context.data[self._key] = "done"
                return context

        workflow = ParallelWorkflow(
            [ModifyStep("a"), ModifyStep("b")],
        )
        result = await workflow.run(initial)

        # Both steps modified 'shared', last one wins in merge
        assert result.data["a"] == "done"
        assert result.data["b"] == "done"

    @pytest.mark.asyncio
    async def test_workflow_name(self) -> None:
        """Test custom workflow name."""
        workflow = ParallelWorkflow([], name="CustomParallel")
        assert workflow.name == "CustomParallel"

    @pytest.mark.asyncio
    async def test_history_records_all_steps(self) -> None:
        """Test history records all step results."""
        workflow = ParallelWorkflow(
            [
                AddValueStep("a", "1"),
                FailingStep(),
                AddValueStep("b", "2"),
            ],
            fail_fast=False,
        )
        result = await workflow.run()

        assert len(result.history) == 3
        statuses = [h["status"] for h in result.history]
        assert statuses.count("completed") == 2
        assert statuses.count("failed") == 1
