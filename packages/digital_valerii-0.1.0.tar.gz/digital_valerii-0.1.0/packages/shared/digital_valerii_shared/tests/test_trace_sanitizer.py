"""Tests for TraceSanitizer.

Component 6.5: AgentOps Framework
"""

import pytest
from digital_valerii_shared.agentops.sanitizer import TraceSanitizer


class TestTraceSanitizer:
    """Tests for TraceSanitizer PII redaction."""

    @pytest.fixture
    def sanitizer(self) -> TraceSanitizer:
        """Create sanitizer instance."""
        return TraceSanitizer()

    def test_email_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test email addresses are redacted."""
        data = {"message": "Contact user@example.com for help"}
        result = sanitizer.sanitize(data)
        assert result["message"] == "Contact [EMAIL] for help"

    def test_multiple_emails(self, sanitizer: TraceSanitizer) -> None:
        """Test multiple emails in same string."""
        data = {"text": "From: alice@test.com To: bob@example.org"}
        result = sanitizer.sanitize(data)
        assert "[EMAIL]" in result["text"]
        assert "alice@test.com" not in result["text"]
        assert "bob@example.org" not in result["text"]

    def test_phone_number_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test phone numbers are redacted."""
        # Various formats
        data = {
            "phone1": "Call 555-123-4567",
            "phone2": "Phone: 555.123.4567",
            "phone3": "Tel: 5551234567",
        }
        result = sanitizer.sanitize(data)
        assert result["phone1"] == "Call [PHONE]"
        assert result["phone2"] == "Phone: [PHONE]"
        assert result["phone3"] == "Tel: [PHONE]"

    def test_ssn_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test SSN is redacted."""
        data = {"ssn": "SSN: 123-45-6789"}
        result = sanitizer.sanitize(data)
        assert result["ssn"] == "SSN: [SSN]"

    def test_card_number_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test credit card numbers are redacted."""
        data = {
            "card1": "Card: 1234567890123456",
            "card2": "Card: 1234-5678-9012-3456",
            "card3": "Card: 1234 5678 9012 3456",
        }
        result = sanitizer.sanitize(data)
        assert "1234567890123456" not in result["card1"]
        assert "[CARD_NUMBER]" in result["card1"]
        assert "[CARD_NUMBER]" in result["card2"]
        assert "[CARD_NUMBER]" in result["card3"]

    def test_password_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test passwords are redacted."""
        data = {
            "pw1": "password: mysecret123",
            "pw2": 'password="super_secret"',
            "pw3": "PASSWORD = 'test123'",
        }
        result = sanitizer.sanitize(data)
        assert "mysecret123" not in result["pw1"]
        assert "password=[REDACTED]" in result["pw1"]
        assert "super_secret" not in result["pw2"]
        assert "test123" not in result["pw3"]

    def test_api_key_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test API keys are redacted."""
        data = {
            "key1": "api_key: sk-1234567890abcdef",
            "key2": 'api-key="AKIAIOSFODNN7EXAMPLE"',
            "key3": "apikey = my_secret_key_123",
        }
        result = sanitizer.sanitize(data)
        assert "sk-1234567890abcdef" not in result["key1"]
        assert "api_key=[REDACTED]" in result["key1"]
        assert "AKIAIOSFODNN7EXAMPLE" not in result["key2"]
        assert "my_secret_key_123" not in result["key3"]

    def test_token_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test tokens are redacted."""
        data = {
            "tok1": "token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
            "tok2": 'access_token="bearer_abc123"',
        }
        result = sanitizer.sanitize(data)
        assert "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" not in result["tok1"]
        assert "token=[REDACTED]" in result["tok1"]
        assert "bearer_abc123" not in result["tok2"]

    def test_secret_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test secrets are redacted."""
        data = {"sec": "secret: my_app_secret_value"}
        result = sanitizer.sanitize(data)
        assert "my_app_secret_value" not in result["sec"]
        assert "secret=[REDACTED]" in result["sec"]

    def test_nested_dict_sanitization(self, sanitizer: TraceSanitizer) -> None:
        """Test nested dictionaries are sanitized."""
        data = {
            "user": {
                "email": "test@example.com",
                "profile": {
                    "phone": "555-123-4567",
                },
            }
        }
        result = sanitizer.sanitize(data)
        assert result["user"]["email"] == "[EMAIL]"
        assert result["user"]["profile"]["phone"] == "[PHONE]"

    def test_list_sanitization(self, sanitizer: TraceSanitizer) -> None:
        """Test lists are sanitized."""
        data = {
            "emails": ["user1@test.com", "user2@test.com"],
            "mixed": [
                {"email": "nested@test.com"},
                "plain text",
                555,
            ],
        }
        result = sanitizer.sanitize(data)
        assert result["emails"] == ["[EMAIL]", "[EMAIL]"]
        assert result["mixed"][0]["email"] == "[EMAIL]"
        assert result["mixed"][1] == "plain text"
        assert result["mixed"][2] == 555

    def test_none_handling(self, sanitizer: TraceSanitizer) -> None:
        """Test None values are handled."""
        data = {"value": None, "nested": {"inner": None}}
        result = sanitizer.sanitize(data)
        assert result["value"] is None
        assert result["nested"]["inner"] is None

    def test_tuple_sanitization(self, sanitizer: TraceSanitizer) -> None:
        """Test tuples are sanitized."""
        data = {"coords": ("user@test.com", "555-123-4567")}
        result = sanitizer.sanitize(data)
        assert result["coords"] == ("[EMAIL]", "[PHONE]")

    def test_numbers_unchanged(self, sanitizer: TraceSanitizer) -> None:
        """Test numbers pass through unchanged."""
        data = {"int": 42, "float": 3.14, "bool": True}
        result = sanitizer.sanitize(data)
        assert result["int"] == 42
        assert result["float"] == 3.14
        assert result["bool"] is True

    def test_empty_dict(self, sanitizer: TraceSanitizer) -> None:
        """Test empty dict returns empty dict."""
        result = sanitizer.sanitize({})
        assert result == {}

    def test_no_pii_unchanged(self, sanitizer: TraceSanitizer) -> None:
        """Test text without PII is unchanged."""
        data = {"message": "Hello, this is a normal message"}
        result = sanitizer.sanitize(data)
        assert result["message"] == "Hello, this is a normal message"

    def test_additional_patterns(self) -> None:
        """Test custom additional patterns."""
        custom_patterns = [
            (r"CUSTOM-\d{4}", "[CUSTOM_ID]"),
        ]
        sanitizer = TraceSanitizer(additional_patterns=custom_patterns)
        data = {"id": "CUSTOM-1234"}
        result = sanitizer.sanitize(data)
        assert result["id"] == "[CUSTOM_ID]"

    def test_credential_redaction(self, sanitizer: TraceSanitizer) -> None:
        """Test credentials are redacted."""
        data = {
            "cred1": "credential: user:pass",
            "cred2": 'credentials="admin:secret123"',
        }
        result = sanitizer.sanitize(data)
        assert "user:pass" not in result["cred1"]
        assert "credential=[REDACTED]" in result["cred1"]
        assert "admin:secret123" not in result["cred2"]

    def test_case_insensitive_patterns(self, sanitizer: TraceSanitizer) -> None:
        """Test patterns are case insensitive for credentials."""
        data = {
            "upper": "PASSWORD: mypass",
            "mixed": "Token: abc123",
            "lower": "secret: xyz789",
        }
        result = sanitizer.sanitize(data)
        assert "mypass" not in result["upper"]
        assert "abc123" not in result["mixed"]
        assert "xyz789" not in result["lower"]

    # ==========================================================================
    # FIX-6.5.1: Key-based secret redaction tests
    # ==========================================================================

    def test_redacts_token_key(self, sanitizer: TraceSanitizer) -> None:
        """Test values under 'token' key are redacted."""
        data = {"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"}
        result = sanitizer.sanitize(data)
        assert result["token"] == "[REDACTED]"

    def test_redacts_api_key_key(self, sanitizer: TraceSanitizer) -> None:
        """Test values under 'api_key' key are redacted."""
        data = {"api_key": "sk-1234567890abcdef"}
        result = sanitizer.sanitize(data)
        assert result["api_key"] == "[REDACTED]"

    def test_redacts_nested_sensitive_keys(self, sanitizer: TraceSanitizer) -> None:
        """Test sensitive keys in nested structures are redacted."""
        data = {
            "config": {
                "secret": "my_secret_value",
                "password": "supersecure123",
                "normal": "visible",
            },
            "auth": {
                "access_token": "bearer_abc123",
                "refresh_token": "refresh_xyz",
            },
        }
        result = sanitizer.sanitize(data)
        assert result["config"]["secret"] == "[REDACTED]"
        assert result["config"]["password"] == "[REDACTED]"
        assert result["config"]["normal"] == "visible"
        assert result["auth"]["access_token"] == "[REDACTED]"
        assert result["auth"]["refresh_token"] == "[REDACTED]"

    def test_redacts_sensitive_keys_case_insensitive(
        self, sanitizer: TraceSanitizer
    ) -> None:
        """Test sensitive key detection is case-insensitive."""
        data = {
            "TOKEN": "value1",
            "Token": "value2",
            "SECRET_KEY": "value3",
        }
        result = sanitizer.sanitize(data)
        # Keys are checked case-insensitively
        assert result["TOKEN"] == "[REDACTED]"
        assert result["Token"] == "[REDACTED]"
        assert result["SECRET_KEY"] == "[REDACTED]"

    def test_redacts_all_sensitive_key_variants(
        self, sanitizer: TraceSanitizer
    ) -> None:
        """Test all sensitive key variants are redacted."""
        data = {
            "password": "pass1",
            "token": "tok1",
            "access_token": "acc1",
            "refresh_token": "ref1",
            "apikey": "api1",
            "secret": "sec1",
            "credential": "cred1",
            "credentials": "creds1",
            "authorization": "auth1",
            "auth_token": "authtok1",
            "bearer": "bearer1",
            "private_key": "priv1",
            "secret_key": "seckey1",
        }
        result = sanitizer.sanitize(data)
        for key in data:
            assert result[key] == "[REDACTED]", f"Key '{key}' was not redacted"

    # ==========================================================================
    # FIX-6.5.4: Depth and cycle guard tests
    # ==========================================================================

    def test_depth_guard_truncates_deep_nesting(
        self, sanitizer: TraceSanitizer
    ) -> None:
        """Test deeply nested structures are truncated at MAX_DEPTH."""
        # Create a deeply nested structure (deeper than MAX_DEPTH=50)
        data: dict = {"level": 0}
        current = data
        for i in range(60):
            current["nested"] = {"level": i + 1}
            current = current["nested"]
        current["deepest"] = "should_be_truncated"

        result = sanitizer.sanitize(data)

        # Navigate to find the truncation point
        current = result
        depth = 0
        while isinstance(current, dict) and "nested" in current:
            current = current["nested"]
            depth += 1
            if current == "[TRUNCATED:DEPTH]":
                break

        # Should have truncated somewhere
        assert "[TRUNCATED:DEPTH]" in str(result) or depth <= 51

    def test_cycle_guard_truncates_circular_reference(
        self, sanitizer: TraceSanitizer
    ) -> None:
        """Test circular references are detected and truncated."""
        # Create a circular reference
        data: dict = {"name": "parent", "children": []}
        child: dict = {"name": "child", "parent": data}
        data["children"].append(child)

        result = sanitizer.sanitize(data)

        # The circular reference should be truncated
        assert "[TRUNCATED:CYCLE]" in str(result)

    def test_self_referencing_dict_handled(self, sanitizer: TraceSanitizer) -> None:
        """Test self-referencing dict doesn't cause infinite loop."""
        data: dict = {"self": None}
        data["self"] = data

        result = sanitizer.sanitize(data)

        assert "[TRUNCATED:CYCLE]" in str(result)
