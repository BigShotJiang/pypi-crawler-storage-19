"""Tests for Agent Core Models.

This module contains tests for the core agent models using Claude Agent SDK,
including AgentStatus, AgentMessage, AgentResponse, and exceptions.
"""

import pytest
from digital_valerii_shared.agent.core import (
    AgentError,
    AgentHookError,
    AgentMessage,
    AgentResponse,
    AgentSessionError,
    AgentStatus,
)
from pydantic import ValidationError


class TestAgentStatus:
    """Tests for AgentStatus enum."""

    def test_status_values(self) -> None:
        """Test that all expected status values exist."""
        assert AgentStatus.COMPLETE == "complete"
        assert AgentStatus.STREAMING == "streaming"
        assert AgentStatus.ERROR == "error"

    def test_status_count(self) -> None:
        """Test that there are exactly 3 status values."""
        assert len(AgentStatus) == 3

    def test_status_is_string(self) -> None:
        """Test that status values are strings."""
        for status in AgentStatus:
            assert isinstance(status.value, str)


class TestAgentMessage:
    """Tests for AgentMessage model."""

    def test_message_creation(self) -> None:
        """Test creating an AgentMessage."""
        msg = AgentMessage(type="text", content="Hello world")
        assert msg.type == "text"
        assert msg.content == "Hello world"
        assert msg.metadata == {}

    def test_message_with_metadata(self) -> None:
        """Test creating an AgentMessage with metadata."""
        msg = AgentMessage(
            type="tool_use",
            content="Searching...",
            metadata={"tool_name": "WebSearch"},
        )
        assert msg.type == "tool_use"
        assert msg.metadata["tool_name"] == "WebSearch"

    def test_message_types(self) -> None:
        """Test different message types."""
        types = ["text", "tool_use", "tool_result", "system"]
        for msg_type in types:
            msg = AgentMessage(type=msg_type, content="test")
            assert msg.type == msg_type

    def test_message_frozen(self) -> None:
        """Test that AgentMessage is immutable."""
        msg = AgentMessage(type="text", content="Hello")
        with pytest.raises(ValidationError):
            msg.content = "Modified"

    def test_message_extra_forbid(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValidationError):
            AgentMessage(
                type="text",
                content="Hello",
                extra="not allowed",  # type: ignore[call-arg]
            )


class TestAgentResponse:
    """Tests for AgentResponse model."""

    def test_response_minimal(self) -> None:
        """Test creating a minimal AgentResponse."""
        response = AgentResponse(
            status=AgentStatus.COMPLETE,
            message="Hello",
            session_id="session-123",
        )
        assert response.status == AgentStatus.COMPLETE
        assert response.message == "Hello"
        assert response.session_id == "session-123"
        assert response.tokens_used == 0
        assert response.tools_used == ()
        assert response.error is None

    def test_response_full(self) -> None:
        """Test creating a full AgentResponse."""
        response = AgentResponse(
            status=AgentStatus.COMPLETE,
            message="Response text",
            session_id="session-456",
            tokens_used=1500,
            tools_used=("Read", "WebSearch"),
        )
        assert response.tokens_used == 1500
        assert response.tools_used == ("Read", "WebSearch")
        assert len(response.tools_used) == 2

    def test_response_streaming(self) -> None:
        """Test creating a streaming AgentResponse."""
        response = AgentResponse(
            status=AgentStatus.STREAMING,
            message="Partial...",
            session_id="session-789",
        )
        assert response.status == AgentStatus.STREAMING

    def test_response_error(self) -> None:
        """Test creating an error AgentResponse."""
        response = AgentResponse(
            status=AgentStatus.ERROR,
            message="",
            session_id="session-err",
            error="Something went wrong",
        )
        assert response.status == AgentStatus.ERROR
        assert response.error == "Something went wrong"

    def test_response_frozen(self) -> None:
        """Test that AgentResponse is immutable."""
        response = AgentResponse(
            status=AgentStatus.COMPLETE,
            message="test",
            session_id="session-1",
        )
        with pytest.raises(ValidationError):
            response.message = "modified"

    def test_response_extra_forbid(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValidationError):
            AgentResponse(
                status=AgentStatus.COMPLETE,
                message="test",
                session_id="session-1",
                extra="not allowed",  # type: ignore[call-arg]
            )


class TestAgentExceptions:
    """Tests for agent exception classes."""

    def test_agent_error_base(self) -> None:
        """Test AgentError is an Exception."""
        error = AgentError("Base error")
        assert isinstance(error, Exception)
        assert str(error) == "Base error"

    def test_agent_session_error_inherits(self) -> None:
        """Test AgentSessionError inherits from AgentError."""
        error = AgentSessionError("Session error")
        assert isinstance(error, AgentError)
        assert isinstance(error, Exception)

    def test_agent_hook_error_inherits(self) -> None:
        """Test AgentHookError inherits from AgentError."""
        error = AgentHookError("Hook failed")
        assert isinstance(error, AgentError)
        assert isinstance(error, Exception)

    def test_exceptions_can_be_raised(self) -> None:
        """Test that exceptions can be raised and caught."""
        with pytest.raises(AgentError):
            raise AgentError("test")

        with pytest.raises(AgentSessionError):
            raise AgentSessionError("test")

        with pytest.raises(AgentHookError):
            raise AgentHookError("test")

    def test_exception_messages(self) -> None:
        """Test that exception messages are preserved."""
        msg = "Custom error message"
        assert str(AgentError(msg)) == msg
        assert str(AgentSessionError(msg)) == msg
        assert str(AgentHookError(msg)) == msg
