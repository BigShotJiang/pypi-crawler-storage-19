"""Tests for RateLimiter service."""

import asyncio
import os
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from packages.shared.digital_valerii_shared.services.rate_limiter import (
    DEFAULT_RATE_LIMITS,
    WINDOW_SECONDS,
    RateLimitConfig,
    RateLimiter,
    RateLimitError,
    RateLimitExceeded,
    RateLimitResult,
    RateLimitStatus,
    RateLimitTimeout,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_redis():
    """Create a mock RedisService."""
    redis = MagicMock()
    redis.client = AsyncMock()
    redis.client.zremrangebyscore = AsyncMock()
    redis.client.zcard = AsyncMock(return_value=0)
    redis.client.zadd = AsyncMock()
    redis.client.zrem = AsyncMock()
    redis.client.zrange = AsyncMock(return_value=[])  # Default empty for oldest entry
    redis.client.get = AsyncMock(return_value=None)
    redis.client.incrby = AsyncMock(return_value=0)
    redis.client.expire = AsyncMock()
    redis.client.delete = AsyncMock()
    redis.client.register_script = MagicMock(return_value=AsyncMock())
    return redis


@pytest.fixture
def rate_limiter(mock_redis):
    """Create RateLimiter with mock Redis."""
    return RateLimiter(mock_redis)


@pytest.fixture
def custom_config():
    """Create custom rate limit config."""
    return {
        "test_service": RateLimitConfig(rpm=100, tpm=10000),
        "simple_service": RateLimitConfig(rpm=50),
    }


@pytest.fixture
def rate_limiter_custom(mock_redis, custom_config):
    """Create RateLimiter with custom config."""
    return RateLimiter(mock_redis, configs=custom_config)


# =============================================================================
# TestPydanticModels
# =============================================================================


class TestPydanticModels:
    """Tests for Pydantic model validation."""

    def test_rate_limit_config_valid(self):
        """Test valid RateLimitConfig."""
        config = RateLimitConfig(rpm=100, tpm=10000)
        assert config.rpm == 100
        assert config.tpm == 10000
        assert config.burst_multiplier == 1.0

    def test_rate_limit_config_rpm_only(self):
        """Test RateLimitConfig with only RPM."""
        config = RateLimitConfig(rpm=50)
        assert config.rpm == 50
        assert config.tpm is None

    def test_rate_limit_config_burst_multiplier(self):
        """Test RateLimitConfig with burst multiplier."""
        config = RateLimitConfig(rpm=100, burst_multiplier=1.5)
        assert config.burst_multiplier == 1.5

    def test_rate_limit_config_forbids_extra(self):
        """Test that extra fields are forbidden."""
        with pytest.raises(ValueError, match="extra"):
            RateLimitConfig(rpm=100, unknown_field="test")

    def test_rate_limit_config_rpm_must_be_positive(self):
        """Test RPM must be positive."""
        with pytest.raises(ValueError):
            RateLimitConfig(rpm=0)

    def test_rate_limit_result_valid(self):
        """Test valid RateLimitResult."""
        result = RateLimitResult(
            allowed=True,
            remaining_requests=50,
            remaining_tokens=5000,
            reset_at=datetime.now(tz=UTC),
        )
        assert result.allowed is True
        assert result.retry_after is None

    def test_rate_limit_result_not_allowed(self):
        """Test RateLimitResult when not allowed."""
        result = RateLimitResult(
            allowed=False,
            remaining_requests=0,
            reset_at=datetime.now(tz=UTC),
            retry_after=30.5,
        )
        assert result.allowed is False
        assert result.retry_after == 30.5

    def test_rate_limit_status_valid(self):
        """Test valid RateLimitStatus."""
        status = RateLimitStatus(
            service="anthropic",
            rpm_limit=4000,
            rpm_used=100,
            rpm_remaining=3900,
            tpm_limit=400000,
            tpm_used=50000,
            tpm_remaining=350000,
            window_resets_at=datetime.now(tz=UTC),
        )
        assert status.service == "anthropic"
        assert status.rpm_remaining == 3900

    def test_rate_limit_status_no_tpm(self):
        """Test RateLimitStatus without TPM."""
        status = RateLimitStatus(
            service="slack",
            rpm_limit=100,
            rpm_used=10,
            rpm_remaining=90,
            window_resets_at=datetime.now(tz=UTC),
        )
        assert status.tpm_limit is None
        assert status.tpm_used is None


# =============================================================================
# TestExceptions
# =============================================================================


class TestExceptions:
    """Tests for exception classes."""

    def test_rate_limit_error_is_base(self):
        """Test RateLimitError is base exception."""
        error = RateLimitError("Test error")
        assert isinstance(error, Exception)
        assert str(error) == "Test error"

    def test_rate_limit_exceeded_message(self):
        """Test RateLimitExceeded message format."""
        error = RateLimitExceeded("anthropic", 30.5)
        assert error.service == "anthropic"
        assert error.retry_after == 30.5
        assert "anthropic" in str(error)
        assert "30.50s" in str(error)

    def test_rate_limit_exceeded_inherits(self):
        """Test RateLimitExceeded inherits from RateLimitError."""
        error = RateLimitExceeded("test", 10.0)
        assert isinstance(error, RateLimitError)

    def test_rate_limit_timeout_message(self):
        """Test RateLimitTimeout message format."""
        error = RateLimitTimeout("voyage", 60.0)
        assert error.service == "voyage"
        assert error.timeout == 60.0
        assert "voyage" in str(error)
        assert "60.00s" in str(error)

    def test_rate_limit_timeout_inherits(self):
        """Test RateLimitTimeout inherits from RateLimitError."""
        error = RateLimitTimeout("test", 30.0)
        assert isinstance(error, RateLimitError)


# =============================================================================
# TestRateLimiterCore
# =============================================================================


class TestRateLimiterCore:
    """Tests for RateLimiter core functionality."""

    def test_init_with_defaults(self, mock_redis):
        """Test initialization with default configs."""
        limiter = RateLimiter(mock_redis)
        assert "anthropic" in limiter.get_configured_services()
        assert "voyage" in limiter.get_configured_services()

    def test_init_with_custom_config(self, mock_redis, custom_config):
        """Test initialization with custom configs."""
        limiter = RateLimiter(mock_redis, configs=custom_config)
        services = limiter.get_configured_services()
        assert "test_service" in services
        assert "anthropic" not in services

    def test_get_config_exists(self, rate_limiter):
        """Test getting existing config."""
        config = rate_limiter.get_config("anthropic")
        assert config is not None
        assert config.rpm == 4000

    def test_get_config_not_found(self, rate_limiter):
        """Test getting non-existent config."""
        config = rate_limiter.get_config("unknown_service")
        assert config is None

    def test_add_config(self, rate_limiter):
        """Test adding new config."""
        new_config = RateLimitConfig(rpm=200)
        rate_limiter.add_config("new_service", new_config)
        assert "new_service" in rate_limiter.get_configured_services()

    def test_remove_config(self, rate_limiter):
        """Test removing config."""
        result = rate_limiter.remove_config("anthropic")
        assert result is True
        assert "anthropic" not in rate_limiter.get_configured_services()

    def test_remove_config_not_found(self, rate_limiter):
        """Test removing non-existent config."""
        result = rate_limiter.remove_config("unknown")
        assert result is False

    async def test_health_check(self, rate_limiter, mock_redis):
        """Test health check returns status for all services."""
        # Setup mock for zcard
        mock_redis.client.zcard = AsyncMock(return_value=10)

        status = await rate_limiter.health_check()
        assert isinstance(status, dict)
        # Should have at least anthropic from defaults
        assert len(status) > 0


# =============================================================================
# TestConfiguration
# =============================================================================


class TestConfiguration:
    """Tests for configuration loading."""

    def test_default_limits_match_architecture(self):
        """Test default limits match ARCHITECTURE.md."""
        assert DEFAULT_RATE_LIMITS["anthropic"].rpm == 4000
        assert DEFAULT_RATE_LIMITS["anthropic"].tpm == 400000
        assert DEFAULT_RATE_LIMITS["voyage"].rpm == 300
        assert DEFAULT_RATE_LIMITS["voyage"].tpm == 1000000
        assert DEFAULT_RATE_LIMITS["microsoft_graph"].rpm == 10000
        assert DEFAULT_RATE_LIMITS["slack"].rpm == 100
        assert DEFAULT_RATE_LIMITS["heygen"].rpm == 60

    def test_env_var_override_rpm(self, mock_redis):
        """Test environment variable overrides RPM."""
        with patch.dict(os.environ, {"RATE_LIMIT_ANTHROPIC_RPM": "5000"}):
            limiter = RateLimiter(mock_redis)
            config = limiter.get_config("anthropic")
            assert config.rpm == 5000
            # TPM should remain default
            assert config.tpm == 400000

    def test_env_var_override_tpm(self, mock_redis):
        """Test environment variable overrides TPM."""
        with patch.dict(os.environ, {"RATE_LIMIT_VOYAGE_TPM": "2000000"}):
            limiter = RateLimiter(mock_redis)
            config = limiter.get_config("voyage")
            assert config.tpm == 2000000
            # RPM should remain default
            assert config.rpm == 300

    def test_env_var_override_both(self, mock_redis):
        """Test environment variable overrides both RPM and TPM."""
        with patch.dict(
            os.environ,
            {"RATE_LIMIT_ANTHROPIC_RPM": "6000", "RATE_LIMIT_ANTHROPIC_TPM": "600000"},
        ):
            limiter = RateLimiter(mock_redis)
            config = limiter.get_config("anthropic")
            assert config.rpm == 6000
            assert config.tpm == 600000

    def test_custom_config_no_env_override(self, mock_redis, custom_config):
        """Test custom config can also be overridden."""
        with patch.dict(os.environ, {"RATE_LIMIT_TEST_SERVICE_RPM": "200"}):
            limiter = RateLimiter(mock_redis, configs=custom_config)
            config = limiter.get_config("test_service")
            assert config.rpm == 200


# =============================================================================
# TestSlidingWindow
# =============================================================================


class TestSlidingWindow:
    """Tests for sliding window algorithm."""

    async def test_check_allows_within_limit(self, rate_limiter_custom, mock_redis):
        """Test check allows requests within limit."""
        mock_redis.client.zcard = AsyncMock(return_value=10)

        result = await rate_limiter_custom.check("test_service")

        assert result.allowed is True
        assert result.remaining_requests == 90  # 100 - 10

    async def test_check_blocks_at_limit(self, rate_limiter_custom, mock_redis):
        """Test check blocks when at limit."""
        import time

        mock_redis.client.zcard = AsyncMock(return_value=100)
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30  # Entry from 30s ago
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        assert result.allowed is False
        assert result.remaining_requests == 0
        assert result.retry_after is not None

    async def test_check_cleans_old_entries(self, rate_limiter_custom, mock_redis):
        """Test that old entries are cleaned during check."""
        await rate_limiter_custom.check("test_service")

        # Should have called zremrangebyscore to clean old entries
        mock_redis.client.zremrangebyscore.assert_called()

    async def test_check_unknown_service_raises(self, rate_limiter_custom):
        """Test check raises for unknown service."""
        with pytest.raises(RateLimitError, match="No rate limit configuration"):
            await rate_limiter_custom.check("unknown_service")

    async def test_sliding_window_no_boundary_burst(
        self, rate_limiter_custom, mock_redis
    ):
        """Test sliding window prevents burst at boundaries."""
        import time

        # Simulate being right at the limit
        mock_redis.client.zcard = AsyncMock(return_value=100)
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        # Should not allow, even at window boundary
        assert result.allowed is False

    async def test_check_reset_time_is_future(self, rate_limiter_custom, mock_redis):
        """Test reset time is in the future."""
        import time

        mock_redis.client.zcard = AsyncMock(return_value=0)
        # Mock oldest entry to ensure realistic reset_at
        oldest_timestamp = time.time() - 10  # Entry from 10s ago
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        assert result.reset_at > datetime.now(tz=UTC)

    async def test_check_retry_after_calculation(self, rate_limiter_custom, mock_redis):
        """Test retry_after is calculated correctly."""
        import time

        mock_redis.client.zcard = AsyncMock(return_value=100)
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30  # Entry from 30s ago
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        assert result.retry_after is not None
        assert 0 < result.retry_after <= WINDOW_SECONDS

    async def test_check_redis_error_handling(self, rate_limiter_custom, mock_redis):
        """Test Redis errors are wrapped properly."""
        from redis.exceptions import RedisError as BaseRedisError

        mock_redis.client.zcard = AsyncMock(
            side_effect=BaseRedisError("Connection lost")
        )

        with pytest.raises(RateLimitError, match="Redis error"):
            await rate_limiter_custom.check("test_service")


# =============================================================================
# TestTokenBucket
# =============================================================================


class TestTokenBucket:
    """Tests for TPM (token bucket) tracking."""

    async def test_check_with_tokens(self, rate_limiter_custom, mock_redis):
        """Test check considers token count."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.get = AsyncMock(return_value="5000")

        result = await rate_limiter_custom.check("test_service", tokens=1000)

        assert result.allowed is True
        assert result.remaining_tokens == 5000  # 10000 - 5000

    async def test_check_token_limit_blocks(self, rate_limiter_custom, mock_redis):
        """Test check blocks when token limit exceeded."""
        import time

        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.get = AsyncMock(return_value="9500")
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service", tokens=1000)

        # 9500 + 1000 > 10000, should block
        assert result.allowed is False

    async def test_check_no_tpm_config(self, rate_limiter_custom, mock_redis):
        """Test check works without TPM config."""
        mock_redis.client.zcard = AsyncMock(return_value=0)

        result = await rate_limiter_custom.check("simple_service")

        assert result.allowed is True
        assert result.remaining_tokens is None

    async def test_token_count_zero_when_no_key(self, rate_limiter_custom, mock_redis):
        """Test token count is 0 when key doesn't exist."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.get = AsyncMock(return_value=None)

        result = await rate_limiter_custom.check("test_service")

        assert result.remaining_tokens == 10000  # Full limit available

    async def test_both_rpm_and_tpm_must_allow(self, rate_limiter_custom, mock_redis):
        """Test both RPM and TPM must allow for request to pass."""
        import time

        # RPM allows (under limit)
        mock_redis.client.zcard = AsyncMock(return_value=10)
        # TPM blocks (over limit)
        mock_redis.client.get = AsyncMock(return_value="10000")
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service", tokens=100)

        assert result.allowed is False

    async def test_remaining_tokens_calculation(self, rate_limiter_custom, mock_redis):
        """Test remaining tokens calculation."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.get = AsyncMock(return_value="3500")

        result = await rate_limiter_custom.check("test_service")

        assert result.remaining_tokens == 6500  # 10000 - 3500


# =============================================================================
# TestAcquire
# =============================================================================


class TestAcquire:
    """Tests for acquire methods."""

    async def test_acquire_success(self, rate_limiter_custom, mock_redis):
        """Test successful acquire."""
        # Mock sliding window script to return allowed
        script_mock = AsyncMock(return_value=[1, 1])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        result = await rate_limiter_custom.acquire("simple_service")

        assert result is True

    async def test_acquire_raises_when_exceeded(self, rate_limiter_custom, mock_redis):
        """Test acquire raises when limit exceeded."""
        # Mock sliding window script to return not allowed
        script_mock = AsyncMock(return_value=[0, 100])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        with pytest.raises(RateLimitExceeded) as exc_info:
            await rate_limiter_custom.acquire("simple_service")

        assert exc_info.value.service == "simple_service"
        assert exc_info.value.retry_after > 0

    async def test_acquire_with_tokens(self, rate_limiter_custom, mock_redis):
        """Test acquire with token count."""
        # Both scripts return allowed
        script_mock = AsyncMock(return_value=[1, 1])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        result = await rate_limiter_custom.acquire("test_service", tokens=500)

        assert result is True

    async def test_acquire_rollback_on_tpm_failure(
        self, rate_limiter_custom, mock_redis
    ):
        """Test RPM is rolled back when TPM fails."""
        call_count = [0]

        async def script_mock_fn(*_args, **_kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                return [1, 1]  # RPM allowed
            else:
                return [0, 10000]  # TPM blocked

        script_mock = AsyncMock(side_effect=script_mock_fn)
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        with pytest.raises(RateLimitExceeded):
            await rate_limiter_custom.acquire("test_service", tokens=1000)

        # Should have tried to remove the RPM entry
        mock_redis.client.zrem.assert_called()

    async def test_wait_and_acquire_success(self, rate_limiter_custom, mock_redis):
        """Test wait_and_acquire succeeds immediately when allowed."""
        script_mock = AsyncMock(return_value=[1, 1])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        result = await rate_limiter_custom.wait_and_acquire(
            "simple_service", timeout=5.0
        )

        assert result is True

    async def test_wait_and_acquire_waits_then_succeeds(
        self, rate_limiter_custom, mock_redis
    ):
        """Test wait_and_acquire waits and eventually succeeds."""
        call_count = [0]

        async def script_mock_fn(*_args, **_kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                return [0, 100]  # Not allowed first two times
            return [1, 1]  # Allowed on third try

        script_mock = AsyncMock(side_effect=script_mock_fn)
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        result = await rate_limiter_custom.wait_and_acquire(
            "simple_service", timeout=10.0
        )

        assert result is True
        assert call_count[0] == 3

    async def test_wait_and_acquire_timeout(self, rate_limiter_custom, mock_redis):
        """Test wait_and_acquire raises on timeout."""
        # Always return not allowed
        script_mock = AsyncMock(return_value=[0, 100])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        with pytest.raises(RateLimitTimeout) as exc_info:
            await rate_limiter_custom.wait_and_acquire("simple_service", timeout=0.5)

        assert exc_info.value.service == "simple_service"
        assert exc_info.value.timeout == 0.5


# =============================================================================
# TestStatus
# =============================================================================


class TestStatus:
    """Tests for get_status method."""

    async def test_get_status_basic(self, rate_limiter_custom, mock_redis):
        """Test get_status returns correct values."""
        mock_redis.client.zcard = AsyncMock(return_value=25)
        mock_redis.client.get = AsyncMock(return_value="2500")

        status = await rate_limiter_custom.get_status("test_service")

        assert status.service == "test_service"
        assert status.rpm_limit == 100
        assert status.rpm_used == 25
        assert status.rpm_remaining == 75
        assert status.tpm_limit == 10000
        assert status.tpm_used == 2500
        assert status.tpm_remaining == 7500

    async def test_get_status_no_tpm(self, rate_limiter_custom, mock_redis):
        """Test get_status for service without TPM."""
        mock_redis.client.zcard = AsyncMock(return_value=10)

        status = await rate_limiter_custom.get_status("simple_service")

        assert status.tpm_limit is None
        assert status.tpm_used is None
        assert status.tpm_remaining is None

    async def test_get_status_unknown_service(self, rate_limiter_custom):
        """Test get_status raises for unknown service."""
        with pytest.raises(RateLimitError, match="No rate limit configuration"):
            await rate_limiter_custom.get_status("unknown")

    async def test_get_status_window_reset(self, rate_limiter_custom, mock_redis):
        """Test get_status includes window reset time."""
        mock_redis.client.zcard = AsyncMock(return_value=0)

        status = await rate_limiter_custom.get_status("simple_service")

        assert status.window_resets_at is not None
        assert status.window_resets_at > datetime.now(tz=UTC)


# =============================================================================
# TestReset
# =============================================================================


class TestReset:
    """Tests for reset method."""

    async def test_reset_clears_rpm(self, rate_limiter_custom, mock_redis):
        """Test reset clears RPM counter."""
        await rate_limiter_custom.reset("test_service")

        # Should have called delete on RPM key
        calls = mock_redis.client.delete.call_args_list
        assert any("rpm" in str(call) for call in calls)

    async def test_reset_clears_tpm(self, rate_limiter_custom, mock_redis):
        """Test reset clears TPM counter when configured."""
        await rate_limiter_custom.reset("test_service")

        # Should have called delete on TPM key
        calls = mock_redis.client.delete.call_args_list
        assert any("tpm" in str(call) for call in calls)

    async def test_reset_no_tpm(self, rate_limiter_custom, mock_redis):
        """Test reset works for service without TPM."""
        mock_redis.client.delete = AsyncMock()

        await rate_limiter_custom.reset("simple_service")

        # Should only delete RPM, not TPM
        assert mock_redis.client.delete.call_count == 1

    async def test_reset_unknown_service(self, rate_limiter_custom):
        """Test reset raises for unknown service."""
        with pytest.raises(RateLimitError, match="No rate limit configuration"):
            await rate_limiter_custom.reset("unknown")


# =============================================================================
# TestBurstMultiplier
# =============================================================================


class TestBurstMultiplier:
    """Tests for burst multiplier functionality."""

    async def test_burst_multiplier_increases_limit(self, mock_redis):
        """Test burst multiplier increases effective limit."""
        config = {"burst_test": RateLimitConfig(rpm=100, burst_multiplier=1.5)}
        limiter = RateLimiter(mock_redis, configs=config)

        # At 100 requests, should still be allowed with 1.5x burst
        mock_redis.client.zcard = AsyncMock(return_value=100)

        result = await limiter.check("burst_test")

        # 100 * 1.5 = 150, so 100 < 150, should be allowed
        assert result.allowed is True

    async def test_burst_multiplier_blocks_at_burst_limit(self, mock_redis):
        """Test burst multiplier still blocks at burst limit."""
        import time

        config = {"burst_test": RateLimitConfig(rpm=100, burst_multiplier=1.5)}
        limiter = RateLimiter(mock_redis, configs=config)

        # At 150 requests, should be blocked (burst limit)
        mock_redis.client.zcard = AsyncMock(return_value=150)
        # Mock oldest entry for retry_after calculation
        oldest_timestamp = time.time() - 30
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await limiter.check("burst_test")

        assert result.allowed is False


# =============================================================================
# TestConcurrency
# =============================================================================


class TestConcurrency:
    """Tests for concurrent access patterns."""

    async def test_concurrent_checks(self, rate_limiter_custom, mock_redis):
        """Test multiple concurrent checks work correctly."""
        mock_redis.client.zcard = AsyncMock(return_value=10)

        # Run 10 concurrent checks
        tasks = [rate_limiter_custom.check("test_service") for _ in range(10)]
        results = await asyncio.gather(*tasks)

        assert all(r.allowed for r in results)

    async def test_scripts_registered_once(self, rate_limiter_custom, mock_redis):
        """Test Lua scripts are only registered once."""
        script_mock = AsyncMock(return_value=[1, 1])
        mock_redis.client.register_script = MagicMock(return_value=script_mock)

        # Multiple acquires should only register scripts once
        await rate_limiter_custom.acquire("simple_service")
        await rate_limiter_custom.acquire("simple_service")
        await rate_limiter_custom.acquire("simple_service")

        # Should have registered 2 scripts (sliding window + token increment)
        assert mock_redis.client.register_script.call_count == 2


# =============================================================================
# TestRound2TokenValidation
# =============================================================================


class TestRound2TokenValidation:
    """Tests for token validation (MEDIUM-1 fix)."""

    async def test_check_negative_tokens_raises(self, rate_limiter_custom):
        """Test check raises ValueError for negative tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.check("test_service", tokens=-5)

    async def test_check_zero_tokens_raises(self, rate_limiter_custom):
        """Test check raises ValueError for zero tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.check("test_service", tokens=0)

    async def test_acquire_negative_tokens_raises(self, rate_limiter_custom):
        """Test acquire raises ValueError for negative tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.acquire("test_service", tokens=-10)

    async def test_acquire_zero_tokens_raises(self, rate_limiter_custom):
        """Test acquire raises ValueError for zero tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.acquire("test_service", tokens=0)

    async def test_wait_and_acquire_negative_tokens_raises(self, rate_limiter_custom):
        """Test wait_and_acquire raises ValueError for negative tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.wait_and_acquire("test_service", tokens=-1)

    async def test_wait_and_acquire_zero_tokens_raises(self, rate_limiter_custom):
        """Test wait_and_acquire raises ValueError for zero tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.wait_and_acquire("test_service", tokens=0)

    async def test_check_float_tokens_raises(self, rate_limiter_custom):
        """Test check raises ValueError for float tokens."""
        with pytest.raises(ValueError, match="positive integer"):
            await rate_limiter_custom.check("test_service", tokens=1.5)  # type: ignore[arg-type]


# =============================================================================
# TestRound2SlidingWindowAccuracy
# =============================================================================


class TestRound2SlidingWindowAccuracy:
    """Tests for sliding window retry_after accuracy (MEDIUM-2 fix)."""

    async def test_retry_after_from_oldest_entry(self, rate_limiter_custom, mock_redis):
        """Test retry_after is calculated from oldest ZSET entry."""
        # Service is at limit
        mock_redis.client.zcard = AsyncMock(return_value=100)

        # Oldest entry was added 30 seconds ago
        import time

        now = time.time()
        oldest_timestamp = now - 30
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        assert result.allowed is False
        # retry_after should be ~30 seconds (60 - 30 = when oldest expires)
        assert result.retry_after is not None
        assert 29 <= result.retry_after <= 31  # Allow small timing variance

    async def test_reset_at_from_oldest_entry(self, rate_limiter_custom, mock_redis):
        """Test reset_at is calculated from oldest ZSET entry."""
        mock_redis.client.zcard = AsyncMock(return_value=50)

        import time

        now = time.time()
        oldest_timestamp = now - 45
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        result = await rate_limiter_custom.check("test_service")

        # reset_at should be oldest_timestamp + 60 seconds
        expected_reset = oldest_timestamp + 60
        actual_reset = result.reset_at.timestamp()
        assert abs(actual_reset - expected_reset) < 1.0  # Within 1 second

    async def test_retry_after_fallback_when_no_entries(
        self, rate_limiter_custom, mock_redis
    ):
        """Test retry_after uses fallback when no ZSET entries (edge case)."""
        # At limit but no entries returned (shouldn't happen but handle gracefully)
        mock_redis.client.zcard = AsyncMock(return_value=100)
        mock_redis.client.zrange = AsyncMock(return_value=[])
        mock_redis.client.get = AsyncMock(return_value="10000")  # TPM at limit too

        result = await rate_limiter_custom.check("test_service")

        assert result.allowed is False
        # Should have fallback retry_after
        assert result.retry_after is not None
        assert 0 < result.retry_after <= 60


# =============================================================================
# TestRound2MalformedData
# =============================================================================


class TestRound2MalformedData:
    """Tests for malformed Redis data handling (LOW-1 fix)."""

    async def test_malformed_tpm_counter_check_raises(
        self, rate_limiter_custom, mock_redis
    ):
        """Test check raises RateLimitError for malformed TPM counter."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.zrange = AsyncMock(return_value=[])
        # Malformed TPM counter
        mock_redis.client.get = AsyncMock(return_value="not_a_number")

        with pytest.raises(RateLimitError, match="Malformed TPM counter"):
            await rate_limiter_custom.check("test_service")

    async def test_malformed_tpm_counter_status_raises(
        self, rate_limiter_custom, mock_redis
    ):
        """Test get_status raises RateLimitError for malformed TPM counter."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        # Malformed TPM counter
        mock_redis.client.get = AsyncMock(return_value="abc123")

        with pytest.raises(RateLimitError, match="Malformed TPM counter"):
            await rate_limiter_custom.get_status("test_service")

    async def test_empty_string_tpm_counter_treated_as_zero(
        self, rate_limiter_custom, mock_redis
    ):
        """Test empty string TPM counter is treated as zero (valid)."""
        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.zrange = AsyncMock(return_value=[])
        # Empty string should be treated as 0 (falsy)
        mock_redis.client.get = AsyncMock(return_value="")

        result = await rate_limiter_custom.check("test_service")

        assert result.allowed is True
        assert result.remaining_tokens == 10000  # Full limit available


# =============================================================================
# TestRound3AcquireAndStatusAccuracy
# =============================================================================


class TestRound3AcquireAndStatusAccuracy:
    """Tests for acquire() and get_status() sliding window accuracy (Round 3 fixes)."""

    async def test_acquire_retry_after_from_oldest_entry(
        self, rate_limiter_custom, mock_redis
    ):
        """Test acquire() calculates retry_after from oldest ZSET entry."""
        import time

        now = time.time()
        oldest_timestamp = now - 30  # Entry from 30s ago

        # Mark scripts as registered so they don't get overwritten
        rate_limiter_custom._scripts_registered = True
        # Simulate RPM at limit (script returns not allowed)
        rate_limiter_custom._sliding_window_script = AsyncMock(return_value=[0, 100])
        # Mock oldest entry lookup
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        with pytest.raises(RateLimitExceeded) as exc_info:
            await rate_limiter_custom.acquire("test_service")

        # retry_after should be ~30 seconds (60 - 30 = when oldest expires)
        assert 29 <= exc_info.value.retry_after <= 31

    async def test_acquire_tpm_failure_retry_after_accurate(
        self, rate_limiter_custom, mock_redis
    ):
        """Test acquire() TPM failure path uses accurate retry_after."""
        import time

        now = time.time()
        oldest_timestamp = now - 45  # Entry from 45s ago

        # Mark scripts as registered so they don't get overwritten
        rate_limiter_custom._scripts_registered = True
        # RPM succeeds
        rate_limiter_custom._sliding_window_script = AsyncMock(return_value=[1, 50])
        # TPM fails
        rate_limiter_custom._token_increment_script = AsyncMock(return_value=[0, 10000])
        # Mock zrem for rollback
        mock_redis.client.zrem = AsyncMock()
        # Mock oldest entry lookup
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        with pytest.raises(RateLimitExceeded) as exc_info:
            await rate_limiter_custom.acquire("test_service", tokens=1000)

        # retry_after should be ~15 seconds (60 - 45 = when oldest expires)
        assert 14 <= exc_info.value.retry_after <= 16
        # Verify rollback was called
        mock_redis.client.zrem.assert_called_once()

    async def test_wait_and_acquire_uses_accurate_retry(
        self, rate_limiter_custom, mock_redis
    ):
        """Test wait_and_acquire inherits accurate retry_after from acquire()."""
        import time

        # Mark scripts as registered so they don't get overwritten
        rate_limiter_custom._scripts_registered = True

        now = time.time()
        oldest_timestamp = now - 58  # Entry from 58s ago, will expire in ~2s

        call_count = 0

        async def mock_sliding_script(*_args, **_kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # First call: blocked
                return [0, 100]
            else:
                # Subsequent calls: allowed
                return [1, 50]

        rate_limiter_custom._sliding_window_script = mock_sliding_script
        # Also mock TPM script since test_service has TPM configured
        rate_limiter_custom._token_increment_script = AsyncMock(return_value=[1, 1000])
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        # Should succeed after waiting (with small timeout to not wait full 60s)
        start = time.time()
        result = await rate_limiter_custom.wait_and_acquire("test_service", timeout=5.0)
        elapsed = time.time() - start

        assert result is True
        # Should have waited ~2 seconds (the accurate retry_after), not 60
        assert elapsed < 4  # Allow some slack for test execution

    async def test_get_status_window_resets_at_accurate(
        self, rate_limiter_custom, mock_redis
    ):
        """Test get_status() window_resets_at from oldest ZSET entry."""
        import time

        now = time.time()
        oldest_timestamp = now - 20  # Entry from 20s ago

        mock_redis.client.zcard = AsyncMock(return_value=50)
        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )
        mock_redis.client.get = AsyncMock(return_value="5000")

        status = await rate_limiter_custom.get_status("test_service")

        # window_resets_at should be oldest_timestamp + 60 seconds
        expected_reset = oldest_timestamp + 60
        actual_reset = status.window_resets_at.timestamp()
        assert abs(actual_reset - expected_reset) < 1.0  # Within 1 second

    async def test_get_status_no_entries_future_reset(
        self, rate_limiter_custom, mock_redis
    ):
        """Test get_status() with no entries uses now + window_seconds."""
        import time

        now = time.time()

        mock_redis.client.zcard = AsyncMock(return_value=0)
        mock_redis.client.zrange = AsyncMock(return_value=[])  # No entries
        mock_redis.client.get = AsyncMock(return_value="0")

        status = await rate_limiter_custom.get_status("test_service")

        # window_resets_at should be approximately now + 60 seconds
        expected_reset = now + 60
        actual_reset = status.window_resets_at.timestamp()
        assert abs(actual_reset - expected_reset) < 2.0  # Within 2 seconds

    async def test_helper_get_oldest_entry_timestamp(
        self, rate_limiter_custom, mock_redis
    ):
        """Test _get_oldest_entry_timestamp helper method."""
        import time

        now = time.time()
        oldest_timestamp = now - 30

        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        rpm_key = rate_limiter_custom._make_rpm_key("test_service")
        result = await rate_limiter_custom._get_oldest_entry_timestamp(rpm_key)

        assert result == oldest_timestamp

    async def test_helper_get_oldest_entry_timestamp_empty(
        self, rate_limiter_custom, mock_redis
    ):
        """Test _get_oldest_entry_timestamp returns None for empty set."""
        mock_redis.client.zrange = AsyncMock(return_value=[])

        rpm_key = rate_limiter_custom._make_rpm_key("test_service")
        result = await rate_limiter_custom._get_oldest_entry_timestamp(rpm_key)

        assert result is None

    async def test_helper_calculate_retry_after(self, rate_limiter_custom, mock_redis):
        """Test _calculate_retry_after helper method."""
        import time

        now = time.time()
        oldest_timestamp = now - 40

        mock_redis.client.zrange = AsyncMock(
            return_value=[("req_id", oldest_timestamp)]
        )

        rpm_key = rate_limiter_custom._make_rpm_key("test_service")
        retry_after = await rate_limiter_custom._calculate_retry_after(rpm_key, now)

        # Should be ~20 seconds (60 - 40)
        assert 19 <= retry_after <= 21
