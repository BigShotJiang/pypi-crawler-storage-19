"""Tests for background workers and job definitions."""

import signal
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import ValidationError

from packages.shared.digital_valerii_shared.models.jobs import (
    CleanupExpiredApprovalsResult,
    CleanupOrphanedOutboxResult,
    CrossStoreDeletionPayload,
    CrossStoreDeletionResult,
    ExtractLessonsPayload,
    ExtractLessonsResult,
    GenerateEmbeddingsPayload,
    GenerateEmbeddingsResult,
    HardDeleteExpiredResult,
    ProcessMeetingTranscriptPayload,
    ProcessMeetingTranscriptResult,
    SyncQdrantOutboxPayload,
    SyncQdrantOutboxResult,
)
from packages.shared.digital_valerii_shared.workers.jobs import (
    cleanup_expired_approvals,
    cleanup_orphaned_outbox,
    cross_store_deletion,
    extract_lessons,
    generate_embeddings,
    hard_delete_expired,
    process_meeting_transcript,
    sync_qdrant_outbox,
)
from packages.shared.digital_valerii_shared.workers.worker import (
    BackgroundWorker,
    WorkerHealthMetrics,
    get_health_metrics,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def worker():
    """Create a BackgroundWorker instance."""
    return BackgroundWorker()


@pytest.fixture
def health_metrics():
    """Create a WorkerHealthMetrics instance."""
    return WorkerHealthMetrics()


@pytest.fixture
def mock_ctx():
    """Create a mock arq context."""
    return {
        "db": AsyncMock(),
        "redis": AsyncMock(),
        "qdrant": AsyncMock(),
        "embedding_service": AsyncMock(),
        "health_metrics": WorkerHealthMetrics(),
    }


# =============================================================================
# Worker Health Metrics Tests
# =============================================================================


class TestWorkerHealthMetrics:
    """Tests for WorkerHealthMetrics."""

    def test_initial_state(self, health_metrics):
        """Test initial metrics state."""
        assert health_metrics.jobs_completed == 0
        assert health_metrics.jobs_failed == 0
        assert health_metrics.total_duration_ms == 0.0
        assert health_metrics.last_job_at is None

    def test_record_successful_job(self, health_metrics):
        """Test recording successful job."""
        health_metrics.record_job(success=True, duration_ms=100.0)

        assert health_metrics.jobs_completed == 1
        assert health_metrics.jobs_failed == 0
        assert health_metrics.total_duration_ms == 100.0
        assert health_metrics.last_job_at is not None

    def test_record_failed_job(self, health_metrics):
        """Test recording failed job."""
        health_metrics.record_job(success=False, duration_ms=50.0)

        assert health_metrics.jobs_completed == 0
        assert health_metrics.jobs_failed == 1
        assert health_metrics.total_duration_ms == 50.0

    def test_record_multiple_jobs(self, health_metrics):
        """Test recording multiple jobs."""
        health_metrics.record_job(success=True, duration_ms=100.0)
        health_metrics.record_job(success=True, duration_ms=200.0)
        health_metrics.record_job(success=False, duration_ms=50.0)

        assert health_metrics.jobs_completed == 2
        assert health_metrics.jobs_failed == 1
        assert health_metrics.total_duration_ms == 350.0

    def test_to_dict(self, health_metrics):
        """Test converting metrics to dictionary."""
        health_metrics.record_job(success=True, duration_ms=100.0)

        result = health_metrics.to_dict()

        assert result["status"] == "healthy"
        assert result["jobs_completed"] == 1
        assert result["jobs_failed"] == 0
        assert result["total_jobs"] == 1
        assert result["avg_duration_ms"] == 100.0
        assert "uptime_seconds" in result

    def test_to_dict_no_jobs(self, health_metrics):
        """Test to_dict with no jobs."""
        result = health_metrics.to_dict()

        assert result["total_jobs"] == 0
        assert result["avg_duration_ms"] == 0.0
        assert result["last_job_at"] is None

    def test_get_health_metrics(self):
        """Test global health metrics getter."""
        metrics = get_health_metrics()

        assert isinstance(metrics, WorkerHealthMetrics)


# =============================================================================
# Background Worker Tests
# =============================================================================


class TestBackgroundWorker:
    """Tests for BackgroundWorker class."""

    async def test_startup(self, worker):
        """Test worker startup."""
        await worker.startup()

        # Signal handlers should be registered (hard to test directly)
        assert worker._shutdown_requested is False

    async def test_shutdown(self, worker):
        """Test worker shutdown."""
        await worker.startup()
        await worker.shutdown()

        assert worker._shutdown_requested is True

    def test_ctx_property(self, worker):
        """Test worker context property."""
        worker.db = MagicMock()
        worker.redis = MagicMock()

        ctx = worker.ctx

        assert "db" in ctx
        assert "redis" in ctx
        assert "qdrant" in ctx
        assert "embedding_service" in ctx
        assert "health_metrics" in ctx

    def test_track_job_start(self, worker):
        """Test tracking job start."""
        worker.track_job_start("job-123")

        assert "job-123" in worker._current_jobs

    def test_track_job_end(self, worker):
        """Test tracking job end."""
        worker._current_jobs.add("job-123")

        worker.track_job_end("job-123")

        assert "job-123" not in worker._current_jobs

    def test_is_shutting_down(self, worker):
        """Test shutdown flag."""
        assert worker.is_shutting_down is False

        worker._shutdown_requested = True

        assert worker.is_shutting_down is True

    def test_health_check(self, worker):
        """Test health check method."""
        worker._current_jobs.add("job-1")
        worker._current_jobs.add("job-2")

        result = worker.health_check()

        assert result["in_progress_jobs"] == 2
        assert result["shutdown_requested"] is False
        assert "status" in result

    def test_handle_shutdown_signal(self, worker):
        """Test shutdown signal handling."""
        worker._handle_shutdown_signal(signal.SIGTERM, None)

        assert worker._shutdown_requested is True


# =============================================================================
# Job Definition Tests - extract_lessons
# =============================================================================


class TestExtractLessonsJob:
    """Tests for extract_lessons job."""

    async def test_extract_lessons_success(self, mock_ctx):
        """Test successful lesson extraction."""
        payload = {"context_id": "ctx-123"}

        result = await extract_lessons(mock_ctx, payload)

        assert result["status"] == "completed"
        assert "lessons_extracted" in result

    async def test_extract_lessons_invalid_payload(self, mock_ctx):
        """Test lesson extraction with invalid payload."""
        payload = {}  # Missing context_id

        with pytest.raises(ValidationError):
            await extract_lessons(mock_ctx, payload)


# =============================================================================
# Job Definition Tests - sync_qdrant_outbox
# =============================================================================


class TestSyncQdrantOutboxJob:
    """Tests for sync_qdrant_outbox job."""

    async def test_sync_outbox_success(self, mock_ctx):
        """Test successful outbox sync."""
        payload = {"limit": 50}

        result = await sync_qdrant_outbox(mock_ctx, payload)

        assert "synced" in result
        assert "failed" in result

    async def test_sync_outbox_default_payload(self, mock_ctx):
        """Test outbox sync with no payload."""
        result = await sync_qdrant_outbox(mock_ctx, None)

        assert "synced" in result

    async def test_sync_outbox_empty_payload(self, mock_ctx):
        """Test outbox sync with empty payload."""
        result = await sync_qdrant_outbox(mock_ctx, {})

        assert "synced" in result


# =============================================================================
# Job Definition Tests - generate_embeddings
# =============================================================================


class TestGenerateEmbeddingsJob:
    """Tests for generate_embeddings job."""

    async def test_generate_embeddings_success(self, mock_ctx):
        """Test successful embedding generation."""
        payload = {"content_ids": ["id-1", "id-2"]}

        result = await generate_embeddings(mock_ctx, payload)

        assert "embeddings_generated" in result

    async def test_generate_embeddings_single_id(self, mock_ctx):
        """Test embedding generation with single ID."""
        payload = {"content_ids": ["id-1"]}

        result = await generate_embeddings(mock_ctx, payload)

        assert "embeddings_generated" in result

    async def test_generate_embeddings_invalid_payload(self, mock_ctx):
        """Test embedding generation with invalid payload."""
        payload = {"content_ids": []}  # Empty list

        with pytest.raises(ValidationError):
            await generate_embeddings(mock_ctx, payload)


# =============================================================================
# Job Definition Tests - process_meeting_transcript
# =============================================================================


class TestProcessMeetingTranscriptJob:
    """Tests for process_meeting_transcript job."""

    async def test_process_transcript_success(self, mock_ctx):
        """Test successful transcript processing."""
        payload = {
            "meeting_id": "meeting-123",
            "transcript": "This is the meeting transcript content.",
        }

        result = await process_meeting_transcript(mock_ctx, payload)

        assert "event_id" in result
        assert "summary_length" in result
        assert "action_items_count" in result

    async def test_process_transcript_invalid_payload(self, mock_ctx):
        """Test transcript processing with missing meeting_id."""
        payload = {"transcript": "Some text"}

        with pytest.raises(ValidationError):
            await process_meeting_transcript(mock_ctx, payload)

    async def test_process_transcript_empty_transcript(self, mock_ctx):
        """Test transcript processing with empty transcript."""
        payload = {"meeting_id": "meeting-123", "transcript": ""}

        with pytest.raises(ValidationError):
            await process_meeting_transcript(mock_ctx, payload)


# =============================================================================
# Job Definition Tests - cross_store_deletion
# =============================================================================


class TestCrossStoreDeletionJob:
    """Tests for cross_store_deletion job."""

    async def test_cross_store_deletion_success(self, mock_ctx):
        """Test successful cross-store deletion."""
        payload = {
            "entity_type": "event",
            "entity_id": "event-123",
            "reason": "user_request",
        }

        result = await cross_store_deletion(mock_ctx, payload)

        assert result["entity_type"] == "event"
        assert "deleted_from" in result
        assert result["complete"] is True

    async def test_cross_store_deletion_default_reason(self, mock_ctx):
        """Test cross-store deletion with default reason."""
        payload = {
            "entity_type": "conversation",
            "entity_id": "conv-456",
        }

        result = await cross_store_deletion(mock_ctx, payload)

        assert result["entity_type"] == "conversation"

    async def test_cross_store_deletion_audit_log(self, mock_ctx):
        """Test cross-store deletion creates audit entry."""
        payload = {
            "entity_type": "message",
            "entity_id": "msg-789",
            "reason": "gdpr_request",
        }

        result = await cross_store_deletion(mock_ctx, payload)

        # Should include all stores
        assert "postgres" in result["deleted_from"]
        assert "qdrant" in result["deleted_from"]
        assert "redis" in result["deleted_from"]


# =============================================================================
# Job Definition Tests - hard_delete_expired
# =============================================================================


class TestHardDeleteExpiredJob:
    """Tests for hard_delete_expired job."""

    async def test_hard_delete_success(self, mock_ctx):
        """Test successful hard delete."""
        result = await hard_delete_expired(mock_ctx, None)

        assert "events" in result
        assert "conversations" in result
        assert "messages" in result
        assert "lessons" in result

    async def test_hard_delete_with_payload(self, mock_ctx):
        """Test hard delete with payload (should be ignored)."""
        result = await hard_delete_expired(mock_ctx, {"ignored": "param"})

        assert "events" in result


# =============================================================================
# Job Definition Tests - cleanup_orphaned_outbox
# =============================================================================


class TestCleanupOrphanedOutboxJob:
    """Tests for cleanup_orphaned_outbox job."""

    async def test_cleanup_orphaned_success(self, mock_ctx):
        """Test successful orphaned outbox cleanup."""
        result = await cleanup_orphaned_outbox(mock_ctx, None)

        assert "deleted_count" in result

    async def test_cleanup_orphaned_none_found(self, mock_ctx):
        """Test cleanup when no orphaned entries found."""
        result = await cleanup_orphaned_outbox(mock_ctx, {})

        assert result["deleted_count"] == 0


# =============================================================================
# Job Definition Tests - cleanup_expired_approvals
# =============================================================================


class TestCleanupExpiredApprovalsJob:
    """Tests for cleanup_expired_approvals job."""

    async def test_cleanup_approvals_success(self, mock_ctx):
        """Test successful approvals cleanup."""
        result = await cleanup_expired_approvals(mock_ctx, None)

        assert "expired_count" in result

    async def test_cleanup_approvals_none_expired(self, mock_ctx):
        """Test cleanup when no expired approvals."""
        result = await cleanup_expired_approvals(mock_ctx, {})

        assert result["expired_count"] == 0


# =============================================================================
# Payload Model Tests
# =============================================================================


class TestPayloadModels:
    """Tests for job payload Pydantic models."""

    def test_extract_lessons_payload(self):
        """Test ExtractLessonsPayload model."""
        payload = ExtractLessonsPayload(context_id="ctx-123")

        assert payload.context_id == "ctx-123"

    def test_sync_qdrant_outbox_payload_defaults(self):
        """Test SyncQdrantOutboxPayload defaults."""
        payload = SyncQdrantOutboxPayload()

        assert payload.limit == 100

    def test_sync_qdrant_outbox_payload_custom(self):
        """Test SyncQdrantOutboxPayload with custom limit."""
        payload = SyncQdrantOutboxPayload(limit=50)

        assert payload.limit == 50

    def test_generate_embeddings_payload(self):
        """Test GenerateEmbeddingsPayload model."""
        payload = GenerateEmbeddingsPayload(content_ids=["id-1", "id-2"])

        assert len(payload.content_ids) == 2

    def test_process_meeting_transcript_payload(self):
        """Test ProcessMeetingTranscriptPayload model."""
        payload = ProcessMeetingTranscriptPayload(
            meeting_id="meeting-123",
            transcript="Transcript text",
        )

        assert payload.meeting_id == "meeting-123"
        assert payload.transcript == "Transcript text"

    def test_cross_store_deletion_payload(self):
        """Test CrossStoreDeletionPayload model."""
        payload = CrossStoreDeletionPayload(
            entity_type="event",
            entity_id="event-123",
        )

        assert payload.entity_type == "event"
        assert payload.reason == "user_request"  # default

    def test_cross_store_deletion_custom_reason(self):
        """Test CrossStoreDeletionPayload with custom reason."""
        payload = CrossStoreDeletionPayload(
            entity_type="event",
            entity_id="event-123",
            reason="gdpr_deletion",
        )

        assert payload.reason == "gdpr_deletion"


# =============================================================================
# Result Model Tests
# =============================================================================


class TestResultModels:
    """Tests for job result Pydantic models."""

    def test_extract_lessons_result(self):
        """Test ExtractLessonsResult model."""
        result = ExtractLessonsResult(status="completed", lessons_extracted=5)

        assert result.status == "completed"
        assert result.lessons_extracted == 5

    def test_sync_qdrant_outbox_result(self):
        """Test SyncQdrantOutboxResult model."""
        result = SyncQdrantOutboxResult(synced=10, failed=2)

        assert result.synced == 10
        assert result.failed == 2

    def test_generate_embeddings_result(self):
        """Test GenerateEmbeddingsResult model."""
        result = GenerateEmbeddingsResult(embeddings_generated=50)

        assert result.embeddings_generated == 50

    def test_process_meeting_transcript_result(self):
        """Test ProcessMeetingTranscriptResult model."""
        result = ProcessMeetingTranscriptResult(
            event_id="event-123",
            summary_length=500,
            action_items_count=3,
        )

        assert result.event_id == "event-123"
        assert result.summary_length == 500
        assert result.action_items_count == 3

    def test_cross_store_deletion_result(self):
        """Test CrossStoreDeletionResult model."""
        result = CrossStoreDeletionResult(
            entity_type="event",
            deleted_from=["postgres", "qdrant"],
            complete=True,
        )

        assert result.entity_type == "event"
        assert len(result.deleted_from) == 2
        assert result.complete is True

    def test_hard_delete_expired_result(self):
        """Test HardDeleteExpiredResult model."""
        result = HardDeleteExpiredResult(
            events=10,
            conversations=5,
            messages=100,
            lessons=3,
        )

        assert result.events == 10
        assert result.conversations == 5
        assert result.messages == 100
        assert result.lessons == 3

    def test_cleanup_orphaned_outbox_result(self):
        """Test CleanupOrphanedOutboxResult model."""
        result = CleanupOrphanedOutboxResult(deleted_count=15)

        assert result.deleted_count == 15

    def test_cleanup_expired_approvals_result(self):
        """Test CleanupExpiredApprovalsResult model."""
        result = CleanupExpiredApprovalsResult(expired_count=8)

        assert result.expired_count == 8

    def test_result_models_frozen(self):
        """Test result models are frozen."""
        result = ExtractLessonsResult(status="completed", lessons_extracted=5)

        with pytest.raises(ValidationError):
            result.lessons_extracted = 10


# =============================================================================
# Round 2 - Job Tracking Hooks Tests (MEDIUM-3)
# =============================================================================


class TestJobTrackingHooks:
    """Tests for on_job_start and on_job_end hooks."""

    async def test_on_job_start_tracks_job(self, worker):
        """Test on_job_start adds job to tracking set."""
        from packages.shared.digital_valerii_shared.workers.worker import on_job_start

        ctx = {"worker": worker, "job_id": "job-123"}

        await on_job_start(ctx)

        assert "job-123" in worker._current_jobs

    async def test_on_job_end_removes_job(self, worker):
        """Test on_job_end removes job from tracking set."""
        from packages.shared.digital_valerii_shared.workers.worker import on_job_end

        worker._current_jobs.add("job-456")
        ctx = {"worker": worker, "job_id": "job-456"}

        await on_job_end(ctx)

        assert "job-456" not in worker._current_jobs

    async def test_on_job_start_no_worker(self):
        """Test on_job_start handles missing worker gracefully."""
        from packages.shared.digital_valerii_shared.workers.worker import on_job_start

        ctx = {"job_id": "job-789"}

        # Should not raise
        await on_job_start(ctx)

    async def test_on_job_end_no_job_id(self, worker):
        """Test on_job_end handles missing job_id gracefully."""
        from packages.shared.digital_valerii_shared.workers.worker import on_job_end

        ctx = {"worker": worker}

        # Should not raise
        await on_job_end(ctx)

    async def test_hooks_full_lifecycle(self, worker):
        """Test job tracking through full start/end lifecycle."""
        from packages.shared.digital_valerii_shared.workers.worker import (
            on_job_end,
            on_job_start,
        )

        ctx = {"worker": worker, "job_id": "job-lifecycle"}

        # Job starts
        await on_job_start(ctx)
        assert worker._current_jobs == {"job-lifecycle"}

        # Job ends
        await on_job_end(ctx)
        assert worker._current_jobs == set()

    async def test_multiple_concurrent_jobs_tracked(self, worker):
        """Test tracking multiple concurrent jobs."""
        from packages.shared.digital_valerii_shared.workers.worker import (
            on_job_end,
            on_job_start,
        )

        ctx1 = {"worker": worker, "job_id": "job-1"}
        ctx2 = {"worker": worker, "job_id": "job-2"}
        ctx3 = {"worker": worker, "job_id": "job-3"}

        await on_job_start(ctx1)
        await on_job_start(ctx2)
        await on_job_start(ctx3)

        assert len(worker._current_jobs) == 3

        await on_job_end(ctx2)
        assert len(worker._current_jobs) == 2
        assert "job-2" not in worker._current_jobs


class TestWorkerSettingsArqUrlParsing:
    """Tests for get_arq_redis_settings URL parsing in worker.py."""

    def test_get_arq_redis_settings_with_tls(self):
        """Test rediss:// URL parsing in worker settings."""
        from unittest.mock import MagicMock, patch

        from packages.shared.digital_valerii_shared.config import RedisSettings

        # Create mock settings with TLS URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "rediss://secure.redis.io:6380/1"

        with patch(
            "packages.shared.digital_valerii_shared.workers.worker.RedisSettings",
            return_value=mock_settings,
        ):
            from packages.shared.digital_valerii_shared.workers.worker import (
                get_arq_redis_settings,
            )

            settings = get_arq_redis_settings()

            assert settings.ssl is True
            assert settings.host == "secure.redis.io"
            assert settings.port == 6380
            assert settings.database == 1

    def test_get_arq_redis_settings_with_acl(self):
        """Test username:password URL parsing in worker settings."""
        from unittest.mock import MagicMock, patch

        from packages.shared.digital_valerii_shared.config import RedisSettings

        # Create mock settings with ACL URL
        mock_settings = MagicMock(spec=RedisSettings)
        mock_settings.url = "redis://user:pass@localhost:6379/0"

        with patch(
            "packages.shared.digital_valerii_shared.workers.worker.RedisSettings",
            return_value=mock_settings,
        ):
            from packages.shared.digital_valerii_shared.workers.worker import (
                get_arq_redis_settings,
            )

            settings = get_arq_redis_settings()

            assert settings.username == "user"
            assert settings.password == "pass"
            assert settings.ssl is False
