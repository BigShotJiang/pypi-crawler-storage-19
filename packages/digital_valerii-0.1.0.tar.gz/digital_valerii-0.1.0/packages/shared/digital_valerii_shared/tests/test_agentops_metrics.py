"""Tests for AgentOps Prometheus metrics.

Component 6.5: AgentOps Framework
"""

import pytest
from digital_valerii_shared.agentops.metrics import (
    ALLOWED_BLOCK_REASONS,
    ALLOWED_ERROR_TYPES,
    ALLOWED_OUTCOMES,
    ALLOWED_RISK_LEVELS,
    KNOWN_MODELS,
    KNOWN_TOOLS,
    MetricsRecorder,
    _normalize_label,
    active_sessions,
    agent_requests_total,
    approval_requests_total,
    blocked_actions_total,
    estimated_cost_usd,
    tokens_used_total,
    tool_approval_rate,
    tool_calls_total,
)


class TestMetricsRecorder:
    """Tests for MetricsRecorder helper class."""

    @pytest.fixture
    def recorder(self) -> MetricsRecorder:
        """Create recorder instance."""
        return MetricsRecorder()

    def test_record_request_success(self, recorder: MetricsRecorder) -> None:
        """Test recording successful request."""
        initial = agent_requests_total.labels(
            outcome="success", error_type="none"
        )._value.get()
        recorder.record_request("success")
        after = agent_requests_total.labels(
            outcome="success", error_type="none"
        )._value.get()
        assert after == initial + 1

    def test_record_request_failure(self, recorder: MetricsRecorder) -> None:
        """Test recording failed request with error type."""
        # Use allowed error type from FIX-6.5.3
        initial = agent_requests_total.labels(
            outcome="failure", error_type="validation"
        )._value.get()
        recorder.record_request("failure", error_type="validation")
        after = agent_requests_total.labels(
            outcome="failure", error_type="validation"
        )._value.get()
        assert after == initial + 1

    def test_record_duration(self, recorder: MetricsRecorder) -> None:
        """Test recording request duration."""
        # Just verify it doesn't raise
        recorder.record_duration(2.5)
        recorder.record_duration(0.1)

    def test_record_tokens(self, recorder: MetricsRecorder) -> None:
        """Test recording token usage."""
        # Use known model from FIX-6.5.3
        initial_input = tokens_used_total.labels(
            model="claude-3-haiku", type="input"
        )._value.get()
        initial_output = tokens_used_total.labels(
            model="claude-3-haiku", type="output"
        )._value.get()

        recorder.record_tokens("claude-3-haiku", input_tokens=500, output_tokens=200)

        after_input = tokens_used_total.labels(
            model="claude-3-haiku", type="input"
        )._value.get()
        after_output = tokens_used_total.labels(
            model="claude-3-haiku", type="output"
        )._value.get()

        assert after_input == initial_input + 500
        assert after_output == initial_output + 200

    def test_record_tool_call(self, recorder: MetricsRecorder) -> None:
        """Test recording tool calls."""
        initial = tool_calls_total.labels(
            tool_name="search", outcome="success"
        )._value.get()
        recorder.record_tool_call("search", "success")
        after = tool_calls_total.labels(
            tool_name="search", outcome="success"
        )._value.get()
        assert after == initial + 1

    def test_record_tool_approval_rate(self, recorder: MetricsRecorder) -> None:
        """Test setting tool approval rate."""
        # Use known tool from FIX-6.5.3, "delete" normalizes to "other"
        recorder.record_tool_approval_rate("file", 0.85)
        rate = tool_approval_rate.labels(tool_name="file")._value.get()
        assert rate == 0.85

    def test_record_memory_recall(self, recorder: MetricsRecorder) -> None:
        """Test recording memory recall duration."""
        # Just verify it doesn't raise
        recorder.record_memory_recall(0.25)

    def test_record_cost(self, recorder: MetricsRecorder) -> None:
        """Test recording estimated cost."""
        initial = estimated_cost_usd.labels(model="claude-3-opus")._value.get()
        recorder.record_cost("claude-3-opus", 0.025)
        after = estimated_cost_usd.labels(model="claude-3-opus")._value.get()
        assert after == initial + 0.025

    def test_record_approval_request(self, recorder: MetricsRecorder) -> None:
        """Test recording approval requests."""
        initial = approval_requests_total.labels(risk_level="high")._value.get()
        recorder.record_approval_request("high")
        after = approval_requests_total.labels(risk_level="high")._value.get()
        assert after == initial + 1

    def test_record_blocked_action(self, recorder: MetricsRecorder) -> None:
        """Test recording blocked actions."""
        # Use known tool and allowed reason from FIX-6.5.3b
        initial = blocked_actions_total.labels(
            tool_name="code", reason="policy_violation"
        )._value.get()
        recorder.record_blocked_action("code", "policy_violation")
        after = blocked_actions_total.labels(
            tool_name="code", reason="policy_violation"
        )._value.get()
        assert after == initial + 1

    def test_set_active_sessions(self, recorder: MetricsRecorder) -> None:
        """Test setting active session count."""
        recorder.set_active_sessions(10)
        assert active_sessions._value.get() == 10

    def test_increment_active_sessions(self, recorder: MetricsRecorder) -> None:
        """Test incrementing active sessions."""
        recorder.set_active_sessions(5)
        recorder.increment_active_sessions()
        assert active_sessions._value.get() == 6

    def test_decrement_active_sessions(self, recorder: MetricsRecorder) -> None:
        """Test decrementing active sessions."""
        recorder.set_active_sessions(5)
        recorder.decrement_active_sessions()
        assert active_sessions._value.get() == 4


class TestMetricLabels:
    """Tests for metric label correctness."""

    def test_agent_requests_total_labels(self) -> None:
        """Test agent_requests_total has correct labels."""
        labels = agent_requests_total._labelnames
        assert "outcome" in labels
        assert "error_type" in labels

    def test_tokens_used_total_labels(self) -> None:
        """Test tokens_used_total has correct labels."""
        labels = tokens_used_total._labelnames
        assert "model" in labels
        assert "type" in labels

    def test_tool_calls_total_labels(self) -> None:
        """Test tool_calls_total has correct labels."""
        labels = tool_calls_total._labelnames
        assert "tool_name" in labels
        assert "outcome" in labels

    def test_blocked_actions_total_labels(self) -> None:
        """Test blocked_actions_total has correct labels."""
        labels = blocked_actions_total._labelnames
        assert "tool_name" in labels
        assert "reason" in labels

    def test_approval_requests_total_labels(self) -> None:
        """Test approval_requests_total has correct labels."""
        labels = approval_requests_total._labelnames
        assert "risk_level" in labels


# =============================================================================
# FIX-6.5.3: Label normalization tests
# =============================================================================


class TestLabelNormalization:
    """Tests for label normalization to prevent cardinality explosion."""

    def test_normalize_label_known_value(self) -> None:
        """Test normalize returns known value unchanged."""
        result = _normalize_label("success", ALLOWED_OUTCOMES)
        assert result == "success"

    def test_normalize_label_unknown_value(self) -> None:
        """Test normalize returns fallback for unknown value."""
        result = _normalize_label("unknown_outcome", ALLOWED_OUTCOMES)
        assert result == "other"

    def test_normalize_label_custom_fallback(self) -> None:
        """Test normalize uses custom fallback."""
        result = _normalize_label("unknown", ALLOWED_OUTCOMES, fallback="default")
        assert result == "default"

    def test_normalize_label_case_insensitive(self) -> None:
        """Test normalize is case-insensitive."""
        result = _normalize_label("SUCCESS", ALLOWED_OUTCOMES)
        assert result == "success"

    def test_normalize_label_strips_whitespace(self) -> None:
        """Test normalize strips whitespace."""
        result = _normalize_label("  success  ", ALLOWED_OUTCOMES)
        assert result == "success"

    def test_record_request_normalizes_labels(self) -> None:
        """Test record_request normalizes outcome and error_type."""
        recorder = MetricsRecorder()
        # Get initial values for the normalized labels
        initial_success = agent_requests_total.labels(
            outcome="success", error_type="none"
        )._value.get()
        initial_other = agent_requests_total.labels(
            outcome="other", error_type="other"
        )._value.get()

        # Record with known labels
        recorder.record_request("success", "none")
        after_success = agent_requests_total.labels(
            outcome="success", error_type="none"
        )._value.get()
        assert after_success == initial_success + 1

        # Record with unknown labels (should normalize to "other")
        recorder.record_request("UNKNOWN_OUTCOME", "UNKNOWN_ERROR")
        after_other = agent_requests_total.labels(
            outcome="other", error_type="other"
        )._value.get()
        assert after_other == initial_other + 1

    def test_record_tokens_normalizes_model(self) -> None:
        """Test record_tokens normalizes model name."""
        recorder = MetricsRecorder()
        # Record with known model
        initial = tokens_used_total.labels(
            model="claude-3-sonnet", type="input"
        )._value.get()
        recorder.record_tokens("claude-3-sonnet", input_tokens=100, output_tokens=50)
        after = tokens_used_total.labels(
            model="claude-3-sonnet", type="input"
        )._value.get()
        assert after == initial + 100

        # Record with unknown model (should normalize to "other")
        initial_other = tokens_used_total.labels(
            model="other", type="input"
        )._value.get()
        recorder.record_tokens("some-custom-model", input_tokens=200, output_tokens=100)
        after_other = tokens_used_total.labels(model="other", type="input")._value.get()
        assert after_other == initial_other + 200

    def test_record_tool_call_normalizes_labels(self) -> None:
        """Test record_tool_call normalizes tool_name and outcome."""
        recorder = MetricsRecorder()
        # Record with known tool
        initial = tool_calls_total.labels(
            tool_name="search", outcome="success"
        )._value.get()
        recorder.record_tool_call("search", "success")
        after = tool_calls_total.labels(
            tool_name="search", outcome="success"
        )._value.get()
        assert after == initial + 1

        # Record with unknown tool (should normalize to "other")
        initial_other = tool_calls_total.labels(
            tool_name="other", outcome="other"
        )._value.get()
        recorder.record_tool_call("custom_tool", "weird_outcome")
        after_other = tool_calls_total.labels(
            tool_name="other", outcome="other"
        )._value.get()
        assert after_other == initial_other + 1

    def test_record_blocked_action_normalizes_reason(self) -> None:
        """Test record_blocked_action normalizes reason to allowed values (FIX-6.5.3b)."""
        recorder = MetricsRecorder()

        # Known reason passes through
        initial_known = blocked_actions_total.labels(
            tool_name="email", reason="policy_violation"
        )._value.get()
        recorder.record_blocked_action("email", "policy_violation")
        after_known = blocked_actions_total.labels(
            tool_name="email", reason="policy_violation"
        )._value.get()
        assert after_known == initial_known + 1

        # Unknown reason normalizes to "unknown"
        initial_unknown = blocked_actions_total.labels(
            tool_name="email", reason="unknown"
        )._value.get()
        recorder.record_blocked_action("email", "some random reason with PII data")
        after_unknown = blocked_actions_total.labels(
            tool_name="email", reason="unknown"
        )._value.get()
        assert after_unknown == initial_unknown + 1

    def test_allowed_sets_not_empty(self) -> None:
        """Test that all allowed sets have values."""
        assert len(ALLOWED_OUTCOMES) > 0
        assert len(ALLOWED_ERROR_TYPES) > 0
        assert len(ALLOWED_RISK_LEVELS) > 0
        assert len(ALLOWED_BLOCK_REASONS) > 0
        assert len(KNOWN_TOOLS) > 0
        assert len(KNOWN_MODELS) > 0
