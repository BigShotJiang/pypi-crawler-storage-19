"""Unit tests for SQLAlchemy models."""

from datetime import UTC, datetime

from packages.shared.digital_valerii_shared.models import (
    Base,
    Conversation,
    Event,
    EventParticipant,
    Lesson,
    Message,
    Person,
    Project,
    SoftDeleteMixin,
    TimestampMixin,
)


class TestBase:
    """Tests for Base class."""

    def test_base_has_metadata(self) -> None:
        """Test that Base has SQLAlchemy metadata."""
        assert hasattr(Base, "metadata")
        assert Base.metadata is not None


class TestTimestampMixin:
    """Tests for TimestampMixin."""

    def test_mixin_has_created_at(self) -> None:
        """Test that TimestampMixin defines created_at."""
        assert hasattr(TimestampMixin, "created_at")

    def test_mixin_has_updated_at(self) -> None:
        """Test that TimestampMixin defines updated_at."""
        assert hasattr(TimestampMixin, "updated_at")


class TestSoftDeleteMixin:
    """Tests for SoftDeleteMixin."""

    def test_mixin_has_deleted_at(self) -> None:
        """Test that SoftDeleteMixin defines deleted_at."""
        assert hasattr(SoftDeleteMixin, "deleted_at")

    def test_is_deleted_false_when_none(self) -> None:
        """Test is_deleted returns False when deleted_at is None."""

        class TestModel(SoftDeleteMixin):
            deleted_at = None

        model = TestModel()
        assert model.is_deleted is False

    def test_is_deleted_true_when_set(self) -> None:
        """Test is_deleted returns True when deleted_at is set."""

        class TestModel(SoftDeleteMixin):
            deleted_at = datetime.now(UTC)

        model = TestModel()
        assert model.is_deleted is True

    def test_soft_delete_sets_deleted_at(self) -> None:
        """Test soft_delete sets deleted_at timestamp."""

        class TestModel(SoftDeleteMixin):
            deleted_at = None

        model = TestModel()
        assert model.deleted_at is None

        model.soft_delete()
        assert model.deleted_at is not None
        assert isinstance(model.deleted_at, datetime)

    def test_restore_clears_deleted_at(self) -> None:
        """Test restore clears deleted_at."""

        class TestModel(SoftDeleteMixin):
            deleted_at = datetime.now(UTC)

        model = TestModel()
        assert model.is_deleted is True

        model.restore()
        assert model.deleted_at is None
        assert model.is_deleted is False


class TestPersonModel:
    """Tests for Person model."""

    def test_tablename(self) -> None:
        """Test Person has correct table name."""
        assert Person.__tablename__ == "people"

    def test_has_uuid_primary_key(self) -> None:
        """Test Person has UUID primary key."""
        assert "id" in Person.__table__.columns
        assert Person.__table__.columns["id"].primary_key

    def test_inherits_timestamp_mixin(self) -> None:
        """Test Person inherits TimestampMixin."""
        assert issubclass(Person, TimestampMixin)

    def test_inherits_soft_delete_mixin(self) -> None:
        """Test Person inherits SoftDeleteMixin."""
        assert issubclass(Person, SoftDeleteMixin)

    def test_has_required_columns(self) -> None:
        """Test Person has all required columns."""
        columns = Person.__table__.columns.keys()
        assert "name" in columns
        assert "email" in columns
        assert "phone" in columns
        assert "company" in columns
        assert "role" in columns
        assert "notes" in columns
        assert "relationship_type" in columns
        assert "last_interaction" in columns


class TestProjectModel:
    """Tests for Project model."""

    def test_tablename(self) -> None:
        """Test Project has correct table name."""
        assert Project.__tablename__ == "projects"

    def test_has_uuid_primary_key(self) -> None:
        """Test Project has UUID primary key."""
        assert "id" in Project.__table__.columns
        assert Project.__table__.columns["id"].primary_key

    def test_inherits_mixins(self) -> None:
        """Test Project inherits required mixins."""
        assert issubclass(Project, TimestampMixin)
        assert issubclass(Project, SoftDeleteMixin)

    def test_has_required_columns(self) -> None:
        """Test Project has all required columns."""
        columns = Project.__table__.columns.keys()
        assert "name" in columns
        assert "description" in columns
        assert "status" in columns
        assert "priority" in columns
        assert "tags" in columns
        assert "metadata" in columns


class TestEventModel:
    """Tests for Event model."""

    def test_tablename(self) -> None:
        """Test Event has correct table name."""
        assert Event.__tablename__ == "events"

    def test_has_uuid_primary_key(self) -> None:
        """Test Event has UUID primary key."""
        assert "id" in Event.__table__.columns
        assert Event.__table__.columns["id"].primary_key

    def test_inherits_soft_delete_mixin(self) -> None:
        """Test Event inherits SoftDeleteMixin."""
        assert issubclass(Event, SoftDeleteMixin)

    def test_has_required_columns(self) -> None:
        """Test Event has all required columns."""
        columns = Event.__table__.columns.keys()
        assert "type" in columns
        assert "title" in columns
        assert "summary" in columns
        assert "content" in columns
        assert "importance" in columns
        assert "emotional_valence" in columns
        assert "occurred_at" in columns
        assert "source" in columns
        assert "project_id" in columns
        assert "conversation_id" in columns


class TestEventParticipantModel:
    """Tests for EventParticipant model."""

    def test_tablename(self) -> None:
        """Test EventParticipant has correct table name."""
        assert EventParticipant.__tablename__ == "event_participants"

    def test_has_uuid_primary_key(self) -> None:
        """Test EventParticipant has UUID primary key."""
        assert "id" in EventParticipant.__table__.columns
        assert EventParticipant.__table__.columns["id"].primary_key

    def test_has_foreign_keys(self) -> None:
        """Test EventParticipant has foreign keys."""
        columns = EventParticipant.__table__.columns.keys()
        assert "event_id" in columns
        assert "person_id" in columns


class TestLessonModel:
    """Tests for Lesson model."""

    def test_tablename(self) -> None:
        """Test Lesson has correct table name."""
        assert Lesson.__tablename__ == "lessons"

    def test_has_uuid_primary_key(self) -> None:
        """Test Lesson has UUID primary key."""
        assert "id" in Lesson.__table__.columns
        assert Lesson.__table__.columns["id"].primary_key

    def test_inherits_mixins(self) -> None:
        """Test Lesson inherits required mixins."""
        assert issubclass(Lesson, TimestampMixin)
        assert issubclass(Lesson, SoftDeleteMixin)

    def test_has_required_columns(self) -> None:
        """Test Lesson has all required columns."""
        columns = Lesson.__table__.columns.keys()
        assert "content" in columns
        assert "category" in columns
        assert "confidence" in columns
        assert "source_event_id" in columns
        assert "applies_to" in columns


class TestConversationModel:
    """Tests for Conversation model."""

    def test_tablename(self) -> None:
        """Test Conversation has correct table name."""
        assert Conversation.__tablename__ == "conversations"

    def test_has_uuid_primary_key(self) -> None:
        """Test Conversation has UUID primary key."""
        assert "id" in Conversation.__table__.columns
        assert Conversation.__table__.columns["id"].primary_key

    def test_inherits_mixins(self) -> None:
        """Test Conversation inherits required mixins."""
        assert issubclass(Conversation, TimestampMixin)
        assert issubclass(Conversation, SoftDeleteMixin)

    def test_has_required_columns(self) -> None:
        """Test Conversation has all required columns."""
        columns = Conversation.__table__.columns.keys()
        assert "title" in columns
        assert "interface" in columns
        assert "status" in columns
        assert "started_at" in columns
        assert "ended_at" in columns


class TestMessageModel:
    """Tests for Message model."""

    def test_tablename(self) -> None:
        """Test Message has correct table name."""
        assert Message.__tablename__ == "messages"

    def test_has_uuid_primary_key(self) -> None:
        """Test Message has UUID primary key."""
        assert "id" in Message.__table__.columns
        assert Message.__table__.columns["id"].primary_key

    def test_has_required_columns(self) -> None:
        """Test Message has all required columns."""
        columns = Message.__table__.columns.keys()
        assert "conversation_id" in columns
        assert "role" in columns
        assert "content" in columns
        assert "tool_calls" in columns
        assert "tool_results" in columns
        assert "tokens_input" in columns
        assert "tokens_output" in columns
        assert "model" in columns
