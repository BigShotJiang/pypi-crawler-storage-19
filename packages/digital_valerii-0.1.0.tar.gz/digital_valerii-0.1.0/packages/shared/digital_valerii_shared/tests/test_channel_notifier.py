"""Tests for Channel Notifier service."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from packages.shared.digital_valerii_shared.services.channel_notifier import (
    ChannelName,
    ChannelNotifier,
    CLIChannelSender,
    MeetingChannelSender,
    Notification,
    NotificationResult,
    NotificationType,
    SlackChannelSender,
    WebChannelSender,
)


class TestEnums:
    """Tests for notification enums."""

    def test_notification_type_values(self) -> None:
        """Test NotificationType enum has correct values."""
        assert NotificationType.INFO.value == "info"
        assert NotificationType.COMPACT_START.value == "compact_start"
        assert NotificationType.COMPACT_END.value == "compact_end"
        assert NotificationType.ERROR.value == "error"
        assert NotificationType.WARNING.value == "warning"

    def test_channel_name_values(self) -> None:
        """Test ChannelName enum has correct values."""
        assert ChannelName.WEB.value == "web"
        assert ChannelName.SLACK.value == "slack"
        assert ChannelName.CLI.value == "cli"
        assert ChannelName.MEETING.value == "meeting"


class TestModels:
    """Tests for Pydantic models."""

    def test_notification_extra_forbid(self) -> None:
        """Test Notification rejects extra fields."""
        with pytest.raises(ValueError):
            Notification(  # type: ignore[call-arg]
                user_id=uuid4(),
                channel=ChannelName.WEB,
                message="Test",
                extra_field="not allowed",
            )

    def test_notification_valid(self) -> None:
        """Test Notification accepts valid data."""
        user_id = uuid4()
        notification = Notification(
            user_id=user_id,
            channel=ChannelName.SLACK,
            message="Hello",
            notification_type=NotificationType.COMPACT_START,
            metadata={"thread_ts": "123.456"},
        )
        assert notification.user_id == user_id
        assert notification.channel == ChannelName.SLACK
        assert notification.notification_type == NotificationType.COMPACT_START

    def test_notification_defaults(self) -> None:
        """Test Notification default values."""
        notification = Notification(
            user_id=uuid4(),
            channel=ChannelName.WEB,
            message="Test",
        )
        assert notification.notification_type == NotificationType.INFO
        assert notification.metadata == {}
        assert notification.timestamp is not None

    def test_notification_result_extra_forbid(self) -> None:
        """Test NotificationResult rejects extra fields."""
        with pytest.raises(ValueError):
            NotificationResult(  # type: ignore[call-arg]
                success=True,
                channel=ChannelName.WEB,
                extra_field="not allowed",
            )

    def test_notification_result_valid(self) -> None:
        """Test NotificationResult accepts valid data."""
        result = NotificationResult(
            success=True,
            channel=ChannelName.SLACK,
        )
        assert result.success is True
        assert result.channel == ChannelName.SLACK
        assert result.error is None

    def test_notification_result_with_error(self) -> None:
        """Test NotificationResult with error."""
        result = NotificationResult(
            success=False,
            channel=ChannelName.CLI,
            error="Connection failed",
        )
        assert result.success is False
        assert result.error == "Connection failed"


@pytest.mark.asyncio
class TestWebChannelSender:
    """Tests for WebChannelSender."""

    async def test_send_queues_notification(self) -> None:
        """Test send adds notification to queue."""
        queue: list[dict] = []
        sender = WebChannelSender(notification_queue=queue)
        user_id = uuid4()

        result = await sender.send(
            user_id=user_id,
            message="Test message",
            notification_type=NotificationType.INFO,
            metadata={"key": "value"},
        )

        assert result.success is True
        assert result.channel == ChannelName.WEB
        assert len(queue) == 1
        assert queue[0]["user_id"] == str(user_id)
        assert queue[0]["message"] == "Test message"
        assert queue[0]["type"] == "info"

    async def test_get_pending_notifications(self) -> None:
        """Test get_pending_notifications returns user's notifications."""
        queue: list[dict] = []
        sender = WebChannelSender(notification_queue=queue)
        user1 = uuid4()
        user2 = uuid4()

        await sender.send(user1, "Message 1", NotificationType.INFO, {})
        await sender.send(user2, "Message 2", NotificationType.INFO, {})
        await sender.send(user1, "Message 3", NotificationType.INFO, {})

        user1_notifications = sender.get_pending_notifications(user1)
        assert len(user1_notifications) == 2
        assert all(n["user_id"] == str(user1) for n in user1_notifications)

    async def test_clear_notifications(self) -> None:
        """Test clear_notifications removes user's notifications."""
        queue: list[dict] = []
        sender = WebChannelSender(notification_queue=queue)
        user1 = uuid4()
        user2 = uuid4()

        await sender.send(user1, "Message 1", NotificationType.INFO, {})
        await sender.send(user2, "Message 2", NotificationType.INFO, {})
        await sender.send(user1, "Message 3", NotificationType.INFO, {})

        cleared = sender.clear_notifications(user1)

        assert cleared == 2
        assert len(queue) == 1
        assert queue[0]["user_id"] == str(user2)


@pytest.mark.asyncio
class TestSlackChannelSender:
    """Tests for SlackChannelSender."""

    async def test_send_queues_message(self) -> None:
        """Test send adds message to queue."""
        queue: list[dict] = []
        sender = SlackChannelSender(message_queue=queue)
        user_id = uuid4()

        result = await sender.send(
            user_id=user_id,
            message="Slack message",
            notification_type=NotificationType.COMPACT_START,
            metadata={"channel_id": "C123", "thread_ts": "123.456"},
        )

        assert result.success is True
        assert result.channel == ChannelName.SLACK
        assert len(queue) == 1
        assert queue[0]["channel_id"] == "C123"
        assert queue[0]["thread_ts"] == "123.456"


@pytest.mark.asyncio
class TestCLIChannelSender:
    """Tests for CLIChannelSender."""

    async def test_send_to_buffer(self) -> None:
        """Test send outputs to buffer."""
        buffer: list[str] = []
        sender = CLIChannelSender(output_buffer=buffer)
        user_id = uuid4()

        result = await sender.send(
            user_id=user_id,
            message="CLI message",
            notification_type=NotificationType.INFO,
            metadata={},
        )

        assert result.success is True
        assert result.channel == ChannelName.CLI
        assert len(buffer) == 1
        assert buffer[0] == "CLI message"

    async def test_error_format(self) -> None:
        """Test error messages are formatted with [ERROR] prefix."""
        buffer: list[str] = []
        sender = CLIChannelSender(output_buffer=buffer)

        await sender.send(
            user_id=uuid4(),
            message="Something went wrong",
            notification_type=NotificationType.ERROR,
            metadata={},
        )

        assert buffer[0] == "[ERROR] Something went wrong"

    async def test_warning_format(self) -> None:
        """Test warning messages are formatted with [WARNING] prefix."""
        buffer: list[str] = []
        sender = CLIChannelSender(output_buffer=buffer)

        await sender.send(
            user_id=uuid4(),
            message="Be careful",
            notification_type=NotificationType.WARNING,
            metadata={},
        )

        assert buffer[0] == "[WARNING] Be careful"

    async def test_compact_format(self) -> None:
        """Test compact messages are formatted with [INFO] prefix."""
        buffer: list[str] = []
        sender = CLIChannelSender(output_buffer=buffer)

        await sender.send(
            user_id=uuid4(),
            message="Compacting...",
            notification_type=NotificationType.COMPACT_START,
            metadata={},
        )

        assert buffer[0] == "[INFO] Compacting..."


@pytest.mark.asyncio
class TestMeetingChannelSender:
    """Tests for MeetingChannelSender."""

    async def test_send_queues_message(self) -> None:
        """Test send adds message to queue."""
        queue: list[dict] = []
        sender = MeetingChannelSender(output_queue=queue)
        user_id = uuid4()

        result = await sender.send(
            user_id=user_id,
            message="Meeting message",
            notification_type=NotificationType.COMPACT_END,
            metadata={"meeting_id": "meeting-123"},
        )

        assert result.success is True
        assert result.channel == ChannelName.MEETING
        assert len(queue) == 1
        assert queue[0]["meeting_id"] == "meeting-123"


@pytest.mark.asyncio
class TestChannelNotifier:
    """Tests for ChannelNotifier service."""

    async def test_notify_web(self) -> None:
        """Test notify sends to web channel."""
        web_queue: list[dict] = []
        senders = {
            ChannelName.WEB: WebChannelSender(notification_queue=web_queue),
        }
        notifier = ChannelNotifier(senders=senders)
        user_id = uuid4()

        result = await notifier.notify(
            user_id=user_id,
            channel="web",
            message="Web notification",
            message_type="info",
        )

        assert result.success is True
        assert len(web_queue) == 1

    async def test_notify_slack(self) -> None:
        """Test notify sends to Slack channel."""
        slack_queue: list[dict] = []
        senders = {
            ChannelName.SLACK: SlackChannelSender(message_queue=slack_queue),
        }
        notifier = ChannelNotifier(senders=senders)
        user_id = uuid4()

        result = await notifier.notify(
            user_id=user_id,
            channel="slack",
            message="Slack notification",
            metadata={"channel_id": "C123"},
        )

        assert result.success is True
        assert len(slack_queue) == 1
        assert slack_queue[0]["channel_id"] == "C123"

    async def test_notify_cli(self) -> None:
        """Test notify sends to CLI channel."""
        cli_buffer: list[str] = []
        senders = {
            ChannelName.CLI: CLIChannelSender(output_buffer=cli_buffer),
        }
        notifier = ChannelNotifier(senders=senders)

        result = await notifier.notify(
            user_id=uuid4(),
            channel="cli",
            message="CLI notification",
        )

        assert result.success is True
        assert len(cli_buffer) == 1

    async def test_notify_unknown_channel_falls_back_to_web(self) -> None:
        """Test notify falls back to web for unknown channel."""
        web_queue: list[dict] = []
        senders = {
            ChannelName.WEB: WebChannelSender(notification_queue=web_queue),
        }
        notifier = ChannelNotifier(senders=senders)

        result = await notifier.notify(
            user_id=uuid4(),
            channel="unknown_channel",
            message="Fallback message",
        )

        assert result.success is True
        assert result.channel == ChannelName.WEB
        assert len(web_queue) == 1

    async def test_notify_compact_start(self) -> None:
        """Test notify_compact_start convenience method."""
        web_queue: list[dict] = []
        senders = {
            ChannelName.WEB: WebChannelSender(notification_queue=web_queue),
        }
        notifier = ChannelNotifier(senders=senders)

        result = await notifier.notify_compact_start(
            user_id=uuid4(),
            channel="web",
            message="Compacting...",
        )

        assert result.success is True
        assert web_queue[0]["type"] == "compact_start"

    async def test_notify_compact_end(self) -> None:
        """Test notify_compact_end convenience method."""
        web_queue: list[dict] = []
        senders = {
            ChannelName.WEB: WebChannelSender(notification_queue=web_queue),
        }
        notifier = ChannelNotifier(senders=senders)

        result = await notifier.notify_compact_end(
            user_id=uuid4(),
            channel="web",
            message="Done!",
        )

        assert result.success is True
        assert web_queue[0]["type"] == "compact_end"

    async def test_get_sender(self) -> None:
        """Test get_sender returns correct sender."""
        web_sender = WebChannelSender()
        slack_sender = SlackChannelSender()
        senders = {
            ChannelName.WEB: web_sender,
            ChannelName.SLACK: slack_sender,
        }
        notifier = ChannelNotifier(senders=senders)

        assert notifier.get_sender(ChannelName.WEB) is web_sender
        assert notifier.get_sender(ChannelName.SLACK) is slack_sender
        assert notifier.get_sender(ChannelName.CLI) is None

    async def test_notify_no_sender_for_channel(self) -> None:
        """Test notify returns failure when no sender configured."""
        senders = {
            ChannelName.WEB: WebChannelSender(),
        }
        notifier = ChannelNotifier(senders=senders)

        result = await notifier.notify(
            user_id=uuid4(),
            channel="cli",
            message="No sender",
        )

        assert result.success is False
        assert "No sender configured" in result.error

    async def test_default_senders_initialized(self) -> None:
        """Test notifier initializes default senders."""
        notifier = ChannelNotifier()

        assert notifier.get_sender(ChannelName.WEB) is not None
        assert notifier.get_sender(ChannelName.SLACK) is not None
        assert notifier.get_sender(ChannelName.CLI) is not None
        assert notifier.get_sender(ChannelName.MEETING) is not None


@pytest.mark.asyncio
class TestChannelNotifierWithSessionManager:
    """Tests for ChannelNotifier with SessionManager integration."""

    async def test_get_user_channel_without_session_manager(self) -> None:
        """Test get_user_channel returns None without session manager."""
        notifier = ChannelNotifier(session_manager=None)
        user_id = uuid4()

        channel = await notifier.get_user_channel(user_id)

        assert channel is None

    async def test_get_user_channel_with_session_manager(self) -> None:
        """Test get_user_channel returns channel from session."""
        from unittest.mock import AsyncMock, MagicMock

        mock_session_manager = AsyncMock()
        mock_session = MagicMock()
        mock_session.last_channel = "slack"
        mock_session_manager.get_session.return_value = mock_session

        notifier = ChannelNotifier(session_manager=mock_session_manager)
        user_id = uuid4()

        channel = await notifier.get_user_channel(user_id)

        assert channel == "slack"
        mock_session_manager.get_session.assert_called_once_with(user_id)

    async def test_get_user_channel_no_session(self) -> None:
        """Test get_user_channel returns None when no session."""
        from unittest.mock import AsyncMock

        mock_session_manager = AsyncMock()
        mock_session_manager.get_session.return_value = None

        notifier = ChannelNotifier(session_manager=mock_session_manager)
        user_id = uuid4()

        channel = await notifier.get_user_channel(user_id)

        assert channel is None
