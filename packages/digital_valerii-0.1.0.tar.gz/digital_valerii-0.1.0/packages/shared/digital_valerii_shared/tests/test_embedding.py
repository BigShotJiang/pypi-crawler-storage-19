"""Tests for Voyage embedding service."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from pydantic import ValidationError

from packages.shared.digital_valerii_shared.config import EmbeddingSettings
from packages.shared.digital_valerii_shared.services.embedding import (
    EmbeddingAPIError,
    EmbeddingError,
    EmbeddingInputType,
    EmbeddingRateLimitError,
    EmbeddingResult,
    EmbeddingService,
    EmbeddingTokenLimitError,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def set_voyage_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Set VOYAGE_API_KEY env var for all tests."""
    monkeypatch.setenv("VOYAGE_API_KEY", "test-api-key")


@pytest.fixture
def settings() -> EmbeddingSettings:
    """Create test settings."""
    return EmbeddingSettings()


@pytest.fixture
def mock_redis() -> AsyncMock:
    """Create mock Redis service."""
    mock = AsyncMock()
    mock.get_json = AsyncMock(return_value=None)
    mock.set_json = AsyncMock()
    return mock


@pytest.fixture
def mock_voyage_response() -> MagicMock:
    """Create mock Voyage API response."""
    response = MagicMock()
    response.embeddings = [[0.1] * 1536]
    response.total_tokens = 10
    return response


@pytest.fixture
def mock_voyage_client(mock_voyage_response: MagicMock) -> MagicMock:
    """Create mock Voyage client."""
    client = MagicMock()
    client.embed = MagicMock(return_value=mock_voyage_response)
    return client


@pytest.fixture
def service(
    settings: EmbeddingSettings, mock_voyage_client: MagicMock
) -> EmbeddingService:
    """Create service with mocked Voyage client."""
    with patch(
        "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
    ) as mock:
        mock.return_value = mock_voyage_client
        svc = EmbeddingService(settings)
        svc._client = mock_voyage_client
        return svc


@pytest.fixture
def service_with_redis(
    settings: EmbeddingSettings,
    mock_voyage_client: MagicMock,
    mock_redis: AsyncMock,
) -> EmbeddingService:
    """Create service with mocked Voyage client and Redis."""
    with patch(
        "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
    ) as mock:
        mock.return_value = mock_voyage_client
        svc = EmbeddingService(settings, redis=mock_redis)
        svc._client = mock_voyage_client
        return svc


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_embedding_result_creation(self) -> None:
        """Test EmbeddingResult creation."""
        result = EmbeddingResult(
            embedding=[0.1, 0.2, 0.3],
            model="voyage-large-2",
            input_type=EmbeddingInputType.DOCUMENT,
            tokens_used=10,
            cached=False,
        )
        assert result.embedding == [0.1, 0.2, 0.3]
        assert result.model == "voyage-large-2"
        assert result.input_type == EmbeddingInputType.DOCUMENT
        assert result.tokens_used == 10
        assert result.cached is False

    def test_embedding_result_frozen(self) -> None:
        """Test EmbeddingResult is immutable."""
        result = EmbeddingResult(
            embedding=[0.1],
            model="voyage-large-2",
            input_type=EmbeddingInputType.QUERY,
            tokens_used=5,
        )
        with pytest.raises(ValidationError):
            result.model = "different"

    def test_embedding_input_type_values(self) -> None:
        """Test EmbeddingInputType enum values."""
        assert EmbeddingInputType.DOCUMENT == "document"
        assert EmbeddingInputType.QUERY == "query"


# =============================================================================
# Exception Tests
# =============================================================================


class TestExceptions:
    """Tests for exception hierarchy."""

    def test_embedding_api_error_inheritance(self) -> None:
        """Test EmbeddingAPIError inherits from EmbeddingError."""
        error = EmbeddingAPIError("API failed")
        assert isinstance(error, EmbeddingError)

    def test_embedding_rate_limit_error_inheritance(self) -> None:
        """Test EmbeddingRateLimitError inherits from EmbeddingError."""
        error = EmbeddingRateLimitError("Rate limited")
        assert isinstance(error, EmbeddingError)

    def test_embedding_token_limit_error_inheritance(self) -> None:
        """Test EmbeddingTokenLimitError inherits from EmbeddingError."""
        error = EmbeddingTokenLimitError("Too many tokens")
        assert isinstance(error, EmbeddingError)


# =============================================================================
# Core Method Tests
# =============================================================================


class TestEmbed:
    """Tests for embed() method."""

    @pytest.mark.asyncio
    async def test_embed_single_text(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test basic embedding generation."""
        result = await service.embed("Hello world")

        assert len(result) == 1536
        mock_voyage_client.embed.assert_called_once()

    @pytest.mark.asyncio
    async def test_embed_returns_correct_dimensions(
        self, service: EmbeddingService
    ) -> None:
        """Test embedding returns correct dimensions."""
        result = await service.embed("Test text")

        assert len(result) == 1536
        assert all(isinstance(x, float) for x in result)

    @pytest.mark.asyncio
    async def test_embed_normalizes_whitespace(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test embedding normalizes whitespace."""
        await service.embed("  Hello   world  ")

        call_args = mock_voyage_client.embed.call_args
        assert call_args[1]["texts"] == ["Hello world"]

    @pytest.mark.asyncio
    async def test_embed_with_cache_hit(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test embed returns cached result."""
        cached_embedding = [0.5] * 1536
        mock_redis.get_json = AsyncMock(return_value=cached_embedding)

        result = await service_with_redis.embed("Cached text")

        assert result == cached_embedding
        # API should not be called
        service_with_redis._client.embed.assert_not_called()

    @pytest.mark.asyncio
    async def test_embed_with_cache_miss(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test embed calls API on cache miss."""
        mock_redis.get_json = AsyncMock(return_value=None)

        result = await service_with_redis.embed("New text")

        assert len(result) == 1536
        service_with_redis._client.embed.assert_called_once()

    @pytest.mark.asyncio
    async def test_embed_caches_result(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test embed stores result in cache."""
        mock_redis.get_json = AsyncMock(return_value=None)

        await service_with_redis.embed("Text to cache")

        mock_redis.set_json.assert_called_once()


class TestEmbedBatch:
    """Tests for embed_batch() method."""

    @pytest.mark.asyncio
    async def test_embed_batch_multiple_texts(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test batch processing multiple texts."""
        mock_voyage_client.embed.return_value.embeddings = [[0.1] * 1536, [0.2] * 1536]

        result = await service.embed_batch(["Text 1", "Text 2"])

        assert len(result) == 2
        assert len(result[0]) == 1536
        assert len(result[1]) == 1536

    @pytest.mark.asyncio
    async def test_embed_batch_empty_list(self, service: EmbeddingService) -> None:
        """Test batch with empty list."""
        result = await service.embed_batch([])

        assert result == []

    @pytest.mark.asyncio
    async def test_embed_batch_respects_size_limit(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test batch splits at batch size limit."""
        # Create 150 texts (exceeds 128 limit)
        texts = [f"Text {i}" for i in range(150)]
        mock_voyage_client.embed.return_value.embeddings = [[0.1] * 1536] * 128

        # Mock to return correct number for each batch
        def mock_embed(**kwargs):
            response = MagicMock()
            response.embeddings = [[0.1] * 1536] * len(kwargs["texts"])
            response.total_tokens = 10 * len(kwargs["texts"])
            return response

        mock_voyage_client.embed = mock_embed

        result = await service.embed_batch(texts)

        assert len(result) == 150

    @pytest.mark.asyncio
    async def test_embed_batch_partial_cache(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test batch with some cached results."""
        cached_embedding = [0.5] * 1536

        # First text cached, second not
        mock_redis.get_json = AsyncMock(side_effect=[cached_embedding, None])

        result = await service_with_redis.embed_batch(["Cached", "Not cached"])

        assert len(result) == 2
        # Only one API call for uncached text
        assert service_with_redis._client.embed.call_count == 1


class TestEmbedWithMetadata:
    """Tests for embed_with_metadata() method."""

    @pytest.mark.asyncio
    async def test_embed_with_metadata_document(
        self, service: EmbeddingService
    ) -> None:
        """Test embedding with document input type."""
        result = await service.embed_with_metadata(
            "Document text", EmbeddingInputType.DOCUMENT
        )

        assert isinstance(result, EmbeddingResult)
        assert result.input_type == EmbeddingInputType.DOCUMENT
        assert result.cached is False

    @pytest.mark.asyncio
    async def test_embed_with_metadata_query(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test embedding with query input type."""
        result = await service.embed_with_metadata(
            "Query text", EmbeddingInputType.QUERY
        )

        assert result.input_type == EmbeddingInputType.QUERY
        call_args = mock_voyage_client.embed.call_args
        assert call_args[1]["input_type"] == EmbeddingInputType.QUERY

    @pytest.mark.asyncio
    async def test_embed_with_metadata_cached(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test metadata shows cached=True for cache hit."""
        mock_redis.get_json = AsyncMock(return_value=[0.5] * 1536)

        result = await service_with_redis.embed_with_metadata("Cached")

        assert result.cached is True


# =============================================================================
# Token Counting Tests
# =============================================================================


class TestTokenCounting:
    """Tests for token counting."""

    def test_count_tokens(self, service: EmbeddingService) -> None:
        """Test token estimation."""
        count = service.count_tokens("Hello world")

        assert isinstance(count, int)
        assert count > 0

    def test_count_tokens_empty(self, service: EmbeddingService) -> None:
        """Test token count for empty string."""
        count = service.count_tokens("")

        assert count == 0

    @pytest.mark.asyncio
    async def test_token_limit_exceeded(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test error when text exceeds token limit."""
        # Create settings with very low token limit
        monkeypatch.setenv("EMBEDDING_MAX_TOKENS", "5")
        limited_settings = EmbeddingSettings()

        with patch(
            "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
        ):
            svc = EmbeddingService(limited_settings)

        with pytest.raises(EmbeddingTokenLimitError, match="exceeds token limit"):
            await svc.embed("This text has many tokens and will exceed the limit")


# =============================================================================
# Error Handling Tests
# =============================================================================


class TestErrorHandling:
    """Tests for error handling."""

    @pytest.mark.asyncio
    async def test_api_error_handling(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test EmbeddingAPIError on API failure."""
        mock_voyage_client.embed.side_effect = Exception("API Error")

        with pytest.raises(EmbeddingAPIError, match="Voyage API error"):
            await service.embed("Test")

    @pytest.mark.asyncio
    async def test_rate_limit_error(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test EmbeddingRateLimitError on rate limit."""
        import voyageai.error

        mock_voyage_client.embed.side_effect = voyageai.error.RateLimitError(
            "Rate limited"
        )

        with pytest.raises(EmbeddingRateLimitError, match="Rate limit exceeded"):
            await service.embed("Test")


# =============================================================================
# Health Check Tests
# =============================================================================


class TestHealthCheck:
    """Tests for health check."""

    @pytest.mark.asyncio
    async def test_health_check_success(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test health check when API is accessible."""
        result = await service.health_check()

        assert result is True
        mock_voyage_client.embed.assert_called()

    @pytest.mark.asyncio
    async def test_health_check_failure(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test health check when API is down."""
        mock_voyage_client.embed.side_effect = Exception("Connection failed")

        result = await service.health_check()

        assert result is False


# =============================================================================
# Edge Cases Tests
# =============================================================================


class TestEdgeCases:
    """Tests for edge cases."""

    @pytest.mark.asyncio
    async def test_empty_text_handling(self, service: EmbeddingService) -> None:
        """Test handling of empty text."""
        result = await service.embed("")

        assert len(result) == 1536

    @pytest.mark.asyncio
    async def test_whitespace_normalization(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test consistent hashing with whitespace."""
        await service.embed("hello  world")
        await service.embed("hello world")

        # Both should normalize to same text
        calls = mock_voyage_client.embed.call_args_list
        assert calls[0][1]["texts"] == calls[1][1]["texts"]

    def test_cache_key_generation(self, service: EmbeddingService) -> None:
        """Test cache key format."""
        key = service._cache_key("test text", EmbeddingInputType.DOCUMENT)

        assert key.startswith("embed:")
        # Format: embed:{model}:{input_type}:{hash}
        parts = key.split(":")
        assert len(parts) == 4

    def test_cache_key_consistency(self, service: EmbeddingService) -> None:
        """Test same text produces same cache key."""
        key1 = service._cache_key("same text", EmbeddingInputType.DOCUMENT)
        key2 = service._cache_key("same text", EmbeddingInputType.DOCUMENT)

        assert key1 == key2

    def test_cache_key_uniqueness(self, service: EmbeddingService) -> None:
        """Test different text produces different cache key."""
        key1 = service._cache_key("text one", EmbeddingInputType.DOCUMENT)
        key2 = service._cache_key("text two", EmbeddingInputType.DOCUMENT)

        assert key1 != key2

    @pytest.mark.asyncio
    async def test_cache_failure_does_not_break_embed(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test embedding works even if cache fails."""
        mock_redis.get_json = AsyncMock(side_effect=Exception("Cache error"))
        mock_redis.set_json = AsyncMock(side_effect=Exception("Cache error"))

        # Should still work despite cache errors
        result = await service_with_redis.embed("Test text")

        assert len(result) == 1536


# =============================================================================
# Settings Tests
# =============================================================================


class TestSettings:
    """Tests for EmbeddingSettings."""

    def test_settings_defaults(self) -> None:
        """Test default settings values."""
        # Uses the autouse fixture which sets VOYAGE_API_KEY
        settings = EmbeddingSettings()

        assert settings.api_key == "test-api-key"
        assert settings.model == "voyage-large-2"
        assert settings.dimensions == 1536
        assert settings.max_tokens == 16000
        assert settings.batch_size == 128
        assert settings.timeout == 30.0
        assert settings.cache_ttl == 86400

    def test_settings_requires_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test that api_key is required."""
        from pydantic import ValidationError

        # Remove the autouse-set env var
        monkeypatch.delenv("VOYAGE_API_KEY", raising=False)
        with pytest.raises(ValidationError):
            EmbeddingSettings()


# =============================================================================
# Round 2 Fixes Tests
# =============================================================================


class TestRound2CacheKeyFixes:
    """Tests for cache key fixes (HIGH-1)."""

    def test_cache_key_includes_model(
        self, service: EmbeddingService, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test cache key changes with different models."""
        key1 = service._cache_key("test text", EmbeddingInputType.DOCUMENT)

        # Simulate different model
        monkeypatch.setenv("EMBEDDING_MODEL", "voyage-2")
        service.settings = EmbeddingSettings()
        key2 = service._cache_key("test text", EmbeddingInputType.DOCUMENT)

        # Restore
        monkeypatch.setenv("EMBEDDING_MODEL", "voyage-large-2")
        service.settings = EmbeddingSettings()

        assert key1 != key2
        assert "voyage-large-2" in key1
        assert "voyage-2" in key2

    def test_cache_key_includes_input_type(self, service: EmbeddingService) -> None:
        """Test cache key changes with different input types."""
        key_doc = service._cache_key("test text", EmbeddingInputType.DOCUMENT)
        key_query = service._cache_key("test text", EmbeddingInputType.QUERY)

        assert key_doc != key_query
        assert "document" in key_doc
        assert "query" in key_query

    def test_cache_key_format(self, service: EmbeddingService) -> None:
        """Test cache key has expected format: embed:{model}:{input_type}:{hash}."""
        key = service._cache_key("test", EmbeddingInputType.DOCUMENT)

        parts = key.split(":")
        assert len(parts) == 4
        assert parts[0] == "embed"
        assert parts[1] == "voyage-large-2"
        assert parts[2] == "document"
        assert len(parts[3]) == 16  # 16 char hash


class TestRound2DimensionValidation:
    """Tests for dimension validation fixes (HIGH-2, MEDIUM-3)."""

    @pytest.mark.asyncio
    async def test_embed_validates_dimensions(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test embed raises on dimension mismatch."""
        # Return wrong dimensions
        mock_voyage_client.embed.return_value.embeddings = [[0.1] * 512]
        service._client = mock_voyage_client

        with pytest.raises(EmbeddingAPIError, match="Dimension mismatch"):
            await service.embed("Test text")

    @pytest.mark.asyncio
    async def test_embed_batch_validates_response_length(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test batch raises on response length mismatch."""
        # Return fewer embeddings than requested
        mock_voyage_client.embed.return_value.embeddings = [[0.1] * 1536]  # Only 1
        service._client = mock_voyage_client

        with pytest.raises(EmbeddingAPIError, match="Batch size mismatch"):
            await service.embed_batch(["Text 1", "Text 2", "Text 3"])

    @pytest.mark.asyncio
    async def test_embed_batch_validates_dimensions_per_item(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test batch validates dimensions for each embedding."""
        # Return correct count but wrong dimensions for one
        mock_voyage_client.embed.return_value.embeddings = [
            [0.1] * 1536,
            [0.2] * 512,  # Wrong dimensions
        ]
        service._client = mock_voyage_client

        with pytest.raises(EmbeddingAPIError, match="Dimension mismatch"):
            await service.embed_batch(["Text 1", "Text 2"])


class TestRound2ExecutorUsage:
    """Tests for executor usage (MEDIUM-1)."""

    @pytest.mark.asyncio
    async def test_embed_runs_in_executor(
        self, service: EmbeddingService, mock_voyage_client: MagicMock
    ) -> None:
        """Test embed uses run_in_executor for non-blocking calls."""
        import asyncio
        from functools import partial

        with patch.object(asyncio, "get_running_loop") as mock_loop:
            mock_executor = AsyncMock()
            mock_executor.return_value = mock_voyage_client.embed.return_value
            mock_loop.return_value.run_in_executor = mock_executor

            await service.embed("Test text")

            # Check that run_in_executor was called with embed (structlog also uses it)
            calls = mock_loop.return_value.run_in_executor.call_args_list
            embed_calls = [c for c in calls if isinstance(c[0][1], partial)]
            assert (
                len(embed_calls) >= 1
            ), "Expected at least one embed call via executor"


class TestRound2BatchSizeClamping:
    """Tests for batch size clamping (LOW-2)."""

    def test_batch_size_clamped_to_128(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test batch_size is clamped to max 128."""
        monkeypatch.setenv("EMBEDDING_BATCH_SIZE", "200")
        settings = EmbeddingSettings()

        with patch(
            "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
        ):
            svc = EmbeddingService(settings)

        assert svc._effective_batch_size == 128

    def test_batch_size_preserved_when_under_limit(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test batch_size preserved when under 128."""
        monkeypatch.setenv("EMBEDDING_BATCH_SIZE", "50")
        settings = EmbeddingSettings()

        with patch(
            "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
        ):
            svc = EmbeddingService(settings)

        assert svc._effective_batch_size == 50


class TestRound2CacheValidation:
    """Tests for cache validation (LOW-3)."""

    @pytest.mark.asyncio
    async def test_cache_validation_rejects_wrong_dimensions(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test cache ignores values with wrong dimensions."""
        # Cache has wrong dimensions (512 instead of 1536)
        mock_redis.get_json = AsyncMock(return_value=[0.5] * 512)

        result = await service_with_redis._get_cached(
            "test", EmbeddingInputType.DOCUMENT
        )

        assert result is None

    @pytest.mark.asyncio
    async def test_cache_validation_rejects_non_list(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test cache ignores non-list values."""
        mock_redis.get_json = AsyncMock(return_value="not a list")

        result = await service_with_redis._get_cached(
            "test", EmbeddingInputType.DOCUMENT
        )

        assert result is None

    @pytest.mark.asyncio
    async def test_cache_validation_rejects_wrong_types(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test cache ignores lists with wrong element types."""
        # List with strings instead of floats
        mock_redis.get_json = AsyncMock(return_value=["a"] * 1536)

        result = await service_with_redis._get_cached(
            "test", EmbeddingInputType.DOCUMENT
        )

        assert result is None

    @pytest.mark.asyncio
    async def test_cache_validation_accepts_valid_embedding(
        self, service_with_redis: EmbeddingService, mock_redis: AsyncMock
    ) -> None:
        """Test cache accepts valid embeddings."""
        valid_embedding = [0.5] * 1536
        mock_redis.get_json = AsyncMock(return_value=valid_embedding)

        result = await service_with_redis._get_cached(
            "test", EmbeddingInputType.DOCUMENT
        )

        assert result == valid_embedding


class TestRound2TokenBuffer:
    """Tests for token limit buffer (LOW-1)."""

    @pytest.mark.asyncio
    async def test_token_limit_uses_90_percent_buffer(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test token limit applies 90% buffer."""
        # Create settings with 100 max tokens
        # Buffer = 90, so text with ~95 tokens should fail
        monkeypatch.setenv("EMBEDDING_MAX_TOKENS", "100")
        settings = EmbeddingSettings()

        with patch(
            "packages.shared.digital_valerii_shared.services.embedding.voyageai.Client"
        ):
            svc = EmbeddingService(settings)

        # Create text that would be ~95 tokens (over 90% buffer)
        long_text = "word " * 95

        with pytest.raises(
            EmbeddingTokenLimitError, match="likely exceeds token limit"
        ):
            await svc.embed(long_text)
