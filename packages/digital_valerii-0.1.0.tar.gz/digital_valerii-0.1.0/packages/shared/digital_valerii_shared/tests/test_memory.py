"""Tests for MemoryManager service."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from pydantic import ValidationError

from packages.shared.digital_valerii_shared.models import Event, Lesson, Person, Project
from packages.shared.digital_valerii_shared.services.embedding import EmbeddingError
from packages.shared.digital_valerii_shared.services.memory import (
    DECAY_CONFIGS,
    DEFAULT_DECAY_CONFIG,
    MAX_WORKING_MEMORY_MESSAGES,
    RECALL_CACHE_TTL,
    Context,
    DecayConfig,
    LessonSummary,
    MemoryContext,
    MemoryError,
    MemoryManager,
    MemoryNotFoundError,
    MemoryRecallError,
    MemoryStoreError,
    PersonSummary,
    ProjectSummary,
    RankedEvent,
)
from packages.shared.digital_valerii_shared.services.qdrant import (
    QdrantError,
    SearchResult,
)
from packages.shared.digital_valerii_shared.services.redis import RedisError

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_db():
    """Create a mock Database."""
    db = MagicMock()
    db.session = MagicMock()
    db.health_check = AsyncMock(return_value=True)
    return db


@pytest.fixture
def mock_qdrant():
    """Create a mock QdrantService."""
    qdrant = MagicMock()
    qdrant.search = AsyncMock(return_value=[])
    qdrant.upsert = AsyncMock()
    qdrant.health_check = AsyncMock(return_value=True)
    return qdrant


@pytest.fixture
def mock_redis():
    """Create a mock RedisService."""
    redis = MagicMock()
    redis.get = AsyncMock(return_value=None)
    redis.set = AsyncMock()
    redis.cache_get = AsyncMock(return_value=None)
    redis.cache_set = AsyncMock()
    redis.get_working_memory = AsyncMock(return_value=None)
    redis.update_working_memory = AsyncMock()
    redis.delete_working_memory = AsyncMock()
    redis.health_check = AsyncMock(return_value=True)
    return redis


@pytest.fixture
def mock_embedding():
    """Create a mock EmbeddingService."""
    embedding = MagicMock()
    embedding.embed = AsyncMock(return_value=[0.1] * 1536)
    embedding.health_check = AsyncMock(return_value=True)
    return embedding


@pytest.fixture
def memory_manager(mock_db, mock_qdrant, mock_redis, mock_embedding):
    """Create a MemoryManager with mocked dependencies."""
    return MemoryManager(
        db=mock_db,
        qdrant=mock_qdrant,
        redis=mock_redis,
        embedding=mock_embedding,
    )


@pytest.fixture
def sample_context():
    """Create a sample context."""
    return Context(
        session_id="test-session-123",
        conversation_id="conv-456",
        message_index=0,
        interface="cli",
    )


@pytest.fixture
def sample_event():
    """Create a sample event."""
    return Event(
        id=uuid4(),
        type="conversation",
        title="Test meeting",
        summary="Discussed project progress",
        content="Full content here",
        importance=0.7,
        occurred_at=datetime.now(UTC),
        source="cli",
    )


@pytest.fixture
def sample_person():
    """Create a sample person."""
    person = Person(
        id=uuid4(),
        name="John Doe",
        email="john@example.com",
        company="Acme Corp",
        relationship_type="colleague",
    )
    return person


@pytest.fixture
def sample_project():
    """Create a sample project."""
    return Project(
        id=uuid4(),
        name="Test Project",
        description="A test project",
        status="active",
    )


@pytest.fixture
def sample_lesson():
    """Create a sample lesson."""
    return Lesson(
        id=uuid4(),
        content="Always test your code",
        category="development",
        confidence=0.9,
        source_event_id=uuid4(),
    )


# =============================================================================
# Core Tests
# =============================================================================


class TestMemoryManagerCore:
    """Tests for MemoryManager initialization and health check."""

    def test_memory_manager_initialization(
        self, mock_db, mock_qdrant, mock_redis, mock_embedding
    ):
        """Test MemoryManager initializes with all dependencies."""
        manager = MemoryManager(
            db=mock_db,
            qdrant=mock_qdrant,
            redis=mock_redis,
            embedding=mock_embedding,
        )
        assert manager._db is mock_db
        assert manager._qdrant is mock_qdrant
        assert manager._redis is mock_redis
        assert manager._embedding is mock_embedding

    async def test_health_check_all_healthy(self, memory_manager):
        """Test health check when all backends are healthy."""
        result = await memory_manager.health_check()
        assert result == {
            "database": True,
            "qdrant": True,
            "redis": True,
            "embedding": True,
        }

    async def test_health_check_partial_failure(
        self, mock_db, mock_qdrant, mock_redis, mock_embedding
    ):
        """Test health check when some backends fail."""
        mock_redis.health_check.return_value = False
        mock_embedding.health_check.return_value = False

        manager = MemoryManager(
            db=mock_db,
            qdrant=mock_qdrant,
            redis=mock_redis,
            embedding=mock_embedding,
        )
        result = await manager.health_check()

        assert result["database"] is True
        assert result["qdrant"] is True
        assert result["redis"] is False
        assert result["embedding"] is False

    def test_decay_config_dataclass(self):
        """Test DecayConfig is frozen and has correct fields."""
        config = DecayConfig(
            half_life_days=180, min_retention_days=7, boost_on_recall=0.1
        )
        assert config.half_life_days == 180
        assert config.min_retention_days == 7
        assert config.boost_on_recall == 0.1

        # Test frozen
        with pytest.raises(AttributeError):
            config.half_life_days = 200

    def test_decay_configs_predefined(self):
        """Test predefined decay configs exist."""
        assert "conversation" in DECAY_CONFIGS
        assert "meeting" in DECAY_CONFIGS
        assert "lesson" in DECAY_CONFIGS
        assert "project_milestone" in DECAY_CONFIGS

    def test_default_decay_config(self):
        """Test default decay config exists."""
        assert DEFAULT_DECAY_CONFIG is not None
        assert DEFAULT_DECAY_CONFIG.half_life_days == 180

    def test_constants_defined(self):
        """Test module constants are defined."""
        assert RECALL_CACHE_TTL == 300
        assert MAX_WORKING_MEMORY_MESSAGES == 20


# =============================================================================
# Pydantic Model Tests
# =============================================================================


class TestPydanticModels:
    """Tests for Pydantic models."""

    def test_context_creation(self):
        """Test Context model creation."""
        ctx = Context(session_id="sess-123", message_index=5)
        assert ctx.session_id == "sess-123"
        assert ctx.message_index == 5
        assert ctx.interface == "cli"
        assert ctx.conversation_id is None

    def test_context_extra_forbid(self):
        """Test Context forbids extra fields."""
        with pytest.raises(ValidationError):
            Context(session_id="sess-123", unknown_field="value")

    def test_ranked_event_creation(self):
        """Test RankedEvent model creation."""
        event = RankedEvent(
            event_id=uuid4(),
            event_type="meeting",
            title="Test",
            occurred_at=datetime.now(UTC),
            importance=0.8,
            vector_score=0.9,
            time_decay=0.7,
            final_score=0.85,
        )
        assert event.event_type == "meeting"
        assert event.importance == 0.8

    def test_person_summary_creation(self):
        """Test PersonSummary model creation."""
        person = PersonSummary(
            id=uuid4(),
            name="Jane",
            email="jane@example.com",
        )
        assert person.name == "Jane"

    def test_project_summary_creation(self):
        """Test ProjectSummary model creation."""
        project = ProjectSummary(
            id=uuid4(),
            name="Project X",
            status="active",
        )
        assert project.name == "Project X"

    def test_lesson_summary_creation(self):
        """Test LessonSummary model creation."""
        lesson = LessonSummary(
            id=uuid4(),
            content="Important lesson",
            confidence=0.95,
        )
        assert lesson.confidence == 0.95

    def test_memory_context_creation(self):
        """Test MemoryContext model creation."""
        ctx = MemoryContext(query="test query")
        assert ctx.query == "test query"
        assert ctx.events == []
        assert ctx.people == []
        assert ctx.cached is False

    def test_memory_context_extra_forbid(self):
        """Test MemoryContext forbids extra fields."""
        with pytest.raises(ValidationError):
            MemoryContext(query="test", extra_field=True)


# =============================================================================
# Recall Tests
# =============================================================================


class TestRecall:
    """Tests for recall() method."""

    async def test_recall_empty_query(self, memory_manager, sample_context):
        """Test recall with empty query returns empty context."""
        result = await memory_manager.recall("", sample_context)
        assert result.events == []
        assert result.query == ""
        assert result.cached is False

    async def test_recall_whitespace_query(self, memory_manager, sample_context):
        """Test recall with whitespace query returns empty context."""
        result = await memory_manager.recall("   ", sample_context)
        assert result.events == []

    async def test_recall_uses_cache(self, memory_manager, mock_redis, sample_context):
        """Test recall returns cached result when available."""
        cached_data = {
            "events": [],
            "people": [],
            "projects": [],
            "lessons": [],
            "query": "cached query",
            "cached": False,
        }
        mock_redis.cache_get.return_value = cached_data

        result = await memory_manager.recall("cached query", sample_context)

        assert result.cached is True
        assert result.query == "cached query"

    async def test_recall_no_search_results(
        self, memory_manager, mock_qdrant, sample_context
    ):
        """Test recall when Qdrant returns no results."""
        mock_qdrant.search.return_value = []

        result = await memory_manager.recall("find nothing", sample_context)

        assert result.events == []
        assert result.cached is False

    async def test_recall_handles_embedding_error(
        self, memory_manager, mock_embedding, sample_context
    ):
        """Test recall raises MemoryRecallError on embedding failure."""
        mock_embedding.embed.side_effect = EmbeddingError("API error")

        with pytest.raises(MemoryRecallError, match="Failed to embed query"):
            await memory_manager.recall("test query", sample_context)

    async def test_recall_handles_qdrant_error(
        self, memory_manager, mock_qdrant, sample_context
    ):
        """Test recall raises MemoryRecallError on Qdrant failure."""
        mock_qdrant.search.side_effect = QdrantError("Search failed")

        with pytest.raises(MemoryRecallError, match="Vector search failed"):
            await memory_manager.recall("test query", sample_context)

    async def test_recall_caches_result(
        self, memory_manager, mock_redis, mock_qdrant, sample_context
    ):
        """Test recall caches the result."""
        mock_qdrant.search.return_value = []

        await memory_manager.recall("new query", sample_context)

        mock_redis.cache_set.assert_called_once()

    async def test_recall_generates_embedding(
        self, memory_manager, mock_embedding, sample_context
    ):
        """Test recall generates embedding for query."""
        await memory_manager.recall("test query", sample_context)

        mock_embedding.embed.assert_called_once_with("test query")

    async def test_recall_limit_parameter(
        self, memory_manager, mock_qdrant, sample_context
    ):
        """Test recall respects limit parameter."""
        await memory_manager.recall("test", sample_context, limit=5)

        # Should request limit * 2 for ranking
        call_args = mock_qdrant.search.call_args
        assert call_args.kwargs["limit"] == 10


class TestTimeDecayRanking:
    """Tests for time decay ranking algorithm."""

    def test_rank_recent_event_no_decay(self, memory_manager):
        """Test recent events have time_decay near 1.0."""
        event = MagicMock()
        event.id = uuid4()
        event.type = "conversation"
        event.title = "Recent"
        event.summary = "Summary"
        event.occurred_at = datetime.now(UTC)
        event.importance = 0.5

        search_results = [SearchResult(id=event.id, score=0.9, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 1
        assert ranked[0].time_decay >= 0.99

    def test_rank_old_event_with_decay(self, memory_manager):
        """Test old events have lower time_decay."""
        from datetime import timedelta

        event = MagicMock()
        event.id = uuid4()
        event.type = "conversation"
        event.title = "Old"
        event.summary = "Summary"
        # 365 days old
        event.occurred_at = datetime.now(UTC) - timedelta(days=365)
        event.importance = 0.5

        search_results = [SearchResult(id=event.id, score=0.9, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 1
        # Conversation half-life is 180 days, so 365 days should decay significantly
        assert ranked[0].time_decay < 0.5

    def test_rank_uses_event_type_decay_config(self, memory_manager):
        """Test ranking uses correct decay config for event type."""
        event = MagicMock()
        event.id = uuid4()
        event.type = "lesson"  # Has 730 day half-life
        event.title = "Lesson"
        event.summary = "Summary"
        event.occurred_at = datetime.now(UTC)
        event.importance = 0.5

        search_results = [SearchResult(id=event.id, score=0.9, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 1
        assert ranked[0].event_type == "lesson"

    def test_rank_missing_event_skipped(self, memory_manager):
        """Test events not in dict are skipped."""
        search_results = [
            SearchResult(id=uuid4(), score=0.9, payload={}),
        ]
        events = {}  # Empty

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 0

    def test_rank_sorts_by_final_score(self, memory_manager):
        """Test results are sorted by final score descending."""
        event1 = MagicMock()
        event1.id = uuid4()
        event1.type = "conversation"
        event1.title = "Low"
        event1.summary = "Summary"
        event1.occurred_at = datetime.now(UTC)
        event1.importance = 0.3

        event2 = MagicMock()
        event2.id = uuid4()
        event2.type = "conversation"
        event2.title = "High"
        event2.summary = "Summary"
        event2.occurred_at = datetime.now(UTC)
        event2.importance = 0.9

        search_results = [
            SearchResult(id=event1.id, score=0.5, payload={}),
            SearchResult(id=event2.id, score=0.8, payload={}),
        ]
        events = {event1.id: event1, event2.id: event2}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 2
        assert ranked[0].final_score > ranked[1].final_score


# =============================================================================
# Store Tests
# =============================================================================


class TestStore:
    """Tests for store() method."""

    async def test_store_creates_event(self, memory_manager, mock_db, sample_context):
        """Test store creates an event in database."""
        # Mock the session context manager
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_session.get = AsyncMock(return_value=None)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.store(
            user_message="Hello",
            agent_response="Hi there",
            context=sample_context,
        )

        assert result is not None
        mock_session.add.assert_called_once()

    async def test_store_idempotency(
        self, memory_manager, mock_redis, mock_db, sample_context
    ):
        """Test store is idempotent with same message."""
        existing_id = uuid4()
        mock_redis.get.return_value = str(existing_id)

        mock_event = MagicMock()
        mock_event.id = existing_id

        mock_session = AsyncMock()
        mock_session.get = AsyncMock(return_value=mock_event)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.store(
            user_message="Duplicate",
            agent_response="Response",
            context=sample_context,
        )

        assert result.id == existing_id

    async def test_store_generates_embedding(
        self, memory_manager, mock_embedding, mock_db, sample_context
    ):
        """Test store generates embedding for content."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        await memory_manager.store(
            user_message="Hello",
            agent_response="World",
            context=sample_context,
        )

        mock_embedding.embed.assert_called_once()
        call_arg = mock_embedding.embed.call_args[0][0]
        assert "Hello" in call_arg
        assert "World" in call_arg

    async def test_store_upserts_to_qdrant(
        self, memory_manager, mock_qdrant, mock_db, sample_context
    ):
        """Test store upserts vector to Qdrant."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        await memory_manager.store(
            user_message="Hello",
            agent_response="World",
            context=sample_context,
        )

        mock_qdrant.upsert.assert_called_once()
        call_kwargs = mock_qdrant.upsert.call_args.kwargs
        assert call_kwargs["collection"] == "memories"

    async def test_store_handles_embedding_error(
        self, memory_manager, mock_embedding, sample_context
    ):
        """Test store raises MemoryStoreError on embedding failure."""
        mock_embedding.embed.side_effect = EmbeddingError("API error")

        with pytest.raises(MemoryStoreError, match="Failed to embed content"):
            await memory_manager.store(
                user_message="Test",
                agent_response="Response",
                context=sample_context,
            )

    async def test_store_handles_qdrant_error(
        self, memory_manager, mock_qdrant, mock_db, sample_context
    ):
        """Test store raises MemoryStoreError on Qdrant failure."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        # Return False to propagate exception (True would suppress it)
        mock_db.session.return_value.__aexit__ = AsyncMock(return_value=False)

        mock_qdrant.upsert.side_effect = QdrantError("Storage failed")

        with pytest.raises(MemoryStoreError, match="Failed to store vector"):
            await memory_manager.store(
                user_message="Test",
                agent_response="Response",
                context=sample_context,
            )

    async def test_store_with_custom_event_type(
        self, memory_manager, mock_db, sample_context
    ):
        """Test store with custom event type."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        await memory_manager.store(
            user_message="Meeting notes",
            agent_response="Summary",
            context=sample_context,
            event_type="meeting",
            importance=0.9,
        )

        add_call = mock_session.add.call_args[0][0]
        assert add_call.type == "meeting"
        assert add_call.importance == 0.9


# =============================================================================
# Working Memory Tests
# =============================================================================


class TestWorkingMemory:
    """Tests for working memory operations."""

    async def test_get_working_memory_exists(self, memory_manager, mock_redis):
        """Test get_working_memory returns data when it exists."""
        mock_redis.get_working_memory.return_value = {
            "session_id": "test-session",
            "messages": [{"role": "user", "content": "Hello"}],
            "context": {},
            "updated_at": datetime.now(UTC).isoformat(),
        }

        result = await memory_manager.get_working_memory("test-session")

        assert result is not None
        assert result.session_id == "test-session"
        assert len(result.messages) == 1

    async def test_get_working_memory_not_exists(self, memory_manager, mock_redis):
        """Test get_working_memory returns None when not exists."""
        mock_redis.get_working_memory.return_value = None

        result = await memory_manager.get_working_memory("unknown-session")

        assert result is None

    async def test_get_working_memory_handles_error(self, memory_manager, mock_redis):
        """Test get_working_memory returns None on Redis error."""
        mock_redis.get_working_memory.side_effect = RedisError("Connection lost")

        result = await memory_manager.get_working_memory("test-session")

        assert result is None

    async def test_update_working_memory(self, memory_manager, mock_redis):
        """Test update_working_memory updates Redis."""
        await memory_manager.update_working_memory(
            session_id="test-session",
            messages=[{"role": "user", "content": "Hello"}],
        )

        mock_redis.update_working_memory.assert_called_once()

    async def test_update_working_memory_merges_context(
        self, memory_manager, mock_redis
    ):
        """Test update_working_memory merges context."""
        mock_redis.get_working_memory.return_value = {
            "context": {"key1": "value1"},
        }

        await memory_manager.update_working_memory(
            session_id="test-session",
            context={"key2": "value2"},
        )

        call_args = mock_redis.update_working_memory.call_args
        updates = call_args[0][1]
        assert "key1" in updates["context"]
        assert "key2" in updates["context"]

    async def test_clear_working_memory(self, memory_manager, mock_redis):
        """Test clear_working_memory deletes from Redis."""
        await memory_manager.clear_working_memory("test-session")

        mock_redis.delete_working_memory.assert_called_once_with("test-session")

    async def test_add_message_to_working_memory(self, memory_manager, mock_redis):
        """Test add_message_to_working_memory adds message."""
        mock_redis.get_working_memory.return_value = {
            "messages": [],
        }

        await memory_manager.add_message_to_working_memory(
            session_id="test-session",
            role="user",
            content="Hello",
        )

        call_args = mock_redis.update_working_memory.call_args
        updates = call_args[0][1]
        assert len(updates["messages"]) == 1
        assert updates["messages"][0]["role"] == "user"
        assert updates["messages"][0]["content"] == "Hello"

    async def test_add_message_trims_on_limit(self, memory_manager, mock_redis):
        """Test add_message_to_working_memory trims when exceeding limit."""
        # Create messages at the limit
        existing_messages = [
            {"role": "user", "content": f"Message {i}"}
            for i in range(MAX_WORKING_MEMORY_MESSAGES)
        ]
        mock_redis.get_working_memory.return_value = {
            "messages": existing_messages,
        }

        await memory_manager.add_message_to_working_memory(
            session_id="test-session",
            role="user",
            content="New message",
        )

        call_args = mock_redis.update_working_memory.call_args
        updates = call_args[0][1]
        assert len(updates["messages"]) == MAX_WORKING_MEMORY_MESSAGES
        assert updates["messages"][-1]["content"] == "New message"


# =============================================================================
# People/Projects Tests
# =============================================================================


class TestPeopleProjects:
    """Tests for people and project operations."""

    async def test_get_person_exists(self, memory_manager, mock_db, sample_person):
        """Test get_person returns person when found."""
        person_id = sample_person.id

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_person

        mock_session = AsyncMock()
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.get_person(person_id)

        assert result is not None
        assert result.id == person_id

    async def test_get_person_not_found(self, memory_manager, mock_db):
        """Test get_person returns None when not found."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None

        mock_session = AsyncMock()
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.get_person(uuid4())

        assert result is None

    async def test_get_project_exists(self, memory_manager, mock_db, sample_project):
        """Test get_project returns project when found."""
        project_id = sample_project.id

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_project

        mock_session = AsyncMock()
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.get_project(project_id)

        assert result is not None
        assert result.id == project_id

    async def test_search_people_empty_query(self, memory_manager):
        """Test search_people returns empty for blank query."""
        result = await memory_manager.search_people("")

        assert result == []

    async def test_search_people_with_results(
        self, memory_manager, mock_db, sample_person
    ):
        """Test search_people returns matching people."""
        mock_scalars = MagicMock()
        mock_scalars.all.return_value = [sample_person]
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars

        mock_session = AsyncMock()
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.search_people("John")

        assert len(result) == 1
        assert result[0].name == "John Doe"

    async def test_search_projects_empty_query(self, memory_manager):
        """Test search_projects returns empty for blank query."""
        result = await memory_manager.search_projects("   ")

        assert result == []

    async def test_search_projects_with_results(
        self, memory_manager, mock_db, sample_project
    ):
        """Test search_projects returns matching projects."""
        mock_scalars = MagicMock()
        mock_scalars.all.return_value = [sample_project]
        mock_result = MagicMock()
        mock_result.scalars.return_value = mock_scalars

        mock_session = AsyncMock()
        mock_session.execute = AsyncMock(return_value=mock_result)
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock()

        result = await memory_manager.search_projects("Test")

        assert len(result) == 1
        assert result[0].name == "Test Project"


# =============================================================================
# Cache Tests
# =============================================================================


class TestCaching:
    """Tests for caching operations."""

    def test_get_cache_key_deterministic(self, memory_manager):
        """Test cache key is deterministic."""
        key1 = memory_manager._get_cache_key("test query", "session-1", 10)
        key2 = memory_manager._get_cache_key("test query", "session-1", 10)

        assert key1 == key2

    def test_get_cache_key_different_for_different_queries(self, memory_manager):
        """Test different queries produce different keys."""
        key1 = memory_manager._get_cache_key("query1", "session-1", 10)
        key2 = memory_manager._get_cache_key("query2", "session-1", 10)

        assert key1 != key2

    def test_get_cache_key_different_for_different_sessions(self, memory_manager):
        """Test different sessions produce different keys."""
        key1 = memory_manager._get_cache_key("query", "session-1", 10)
        key2 = memory_manager._get_cache_key("query", "session-2", 10)

        assert key1 != key2

    async def test_get_cached_recall_returns_none_on_miss(
        self, memory_manager, mock_redis
    ):
        """Test _get_cached_recall returns None on cache miss."""
        mock_redis.cache_get.return_value = None

        result = await memory_manager._get_cached_recall("some-key")

        assert result is None

    async def test_get_cached_recall_returns_context_on_hit(
        self, memory_manager, mock_redis
    ):
        """Test _get_cached_recall returns MemoryContext on hit."""
        mock_redis.cache_get.return_value = {
            "events": [],
            "people": [],
            "projects": [],
            "lessons": [],
            "query": "cached",
            "cached": False,
        }

        result = await memory_manager._get_cached_recall("some-key")

        assert result is not None
        assert result.cached is True

    async def test_cache_recall_sets_cache(self, memory_manager, mock_redis):
        """Test _cache_recall sets cache with TTL."""
        context = MemoryContext(query="test")

        await memory_manager._cache_recall("cache-key", context)

        mock_redis.cache_set.assert_called_once()
        call_kwargs = mock_redis.cache_set.call_args.kwargs
        assert call_kwargs["ttl"] == RECALL_CACHE_TTL


# =============================================================================
# Exception Tests
# =============================================================================


class TestExceptions:
    """Tests for exception hierarchy."""

    def test_memory_error_is_base(self):
        """Test MemoryError is the base exception."""
        assert issubclass(MemoryRecallError, MemoryError)
        assert issubclass(MemoryStoreError, MemoryError)
        assert issubclass(MemoryNotFoundError, MemoryError)

    def test_memory_recall_error_message(self):
        """Test MemoryRecallError carries message."""
        error = MemoryRecallError("Something went wrong")
        assert str(error) == "Something went wrong"

    def test_memory_store_error_message(self):
        """Test MemoryStoreError carries message."""
        error = MemoryStoreError("Store failed")
        assert str(error) == "Store failed"

    def test_memory_not_found_error_message(self):
        """Test MemoryNotFoundError carries message."""
        error = MemoryNotFoundError("Not found")
        assert str(error) == "Not found"


# =============================================================================
# Idempotency Tests
# =============================================================================


class TestIdempotency:
    """Tests for idempotency key generation."""

    def test_generate_idempotency_key_deterministic(
        self, memory_manager, sample_context
    ):
        """Test idempotency key is deterministic."""
        key1 = memory_manager._generate_idempotency_key("message", sample_context)
        key2 = memory_manager._generate_idempotency_key("message", sample_context)

        assert key1 == key2

    def test_generate_idempotency_key_different_messages(
        self, memory_manager, sample_context
    ):
        """Test different messages produce different keys."""
        key1 = memory_manager._generate_idempotency_key("message1", sample_context)
        key2 = memory_manager._generate_idempotency_key("message2", sample_context)

        assert key1 != key2

    def test_generate_idempotency_key_different_sessions(self, memory_manager):
        """Test different sessions produce different keys."""
        ctx1 = Context(session_id="session-1")
        ctx2 = Context(session_id="session-2")

        key1 = memory_manager._generate_idempotency_key("message", ctx1)
        key2 = memory_manager._generate_idempotency_key("message", ctx2)

        assert key1 != key2

    def test_generate_idempotency_key_length(self, memory_manager, sample_context):
        """Test idempotency key has expected length."""
        key = memory_manager._generate_idempotency_key("message", sample_context)

        assert len(key) == 32  # SHA256 truncated to 32 chars


# =============================================================================
# Round 2 Fixes Tests
# =============================================================================


class TestRound2Rollback:
    """Tests for DB rollback on Qdrant failure (HIGH-1)."""

    async def test_store_rollback_on_qdrant_failure(
        self, memory_manager, mock_db, mock_qdrant, sample_context
    ):
        """Test that DB is rolled back when Qdrant upsert fails."""
        # Setup mock session
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()

        # Track whether __aexit__ was called with exception info
        exit_calls = []

        async def track_exit(_self, exc_type, exc_val, exc_tb):
            exit_calls.append((exc_type, exc_val, exc_tb))
            return False  # Propagate exception

        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = track_exit

        # Make Qdrant fail
        mock_qdrant.upsert.side_effect = QdrantError("Vector storage failed")

        # Should raise MemoryStoreError
        with pytest.raises(MemoryStoreError, match="Failed to store vector"):
            await memory_manager.store(
                user_message="Test",
                agent_response="Response",
                context=sample_context,
            )

        # Session add was called but should have been rolled back via exception
        mock_session.add.assert_called_once()
        assert len(exit_calls) == 1
        # __aexit__ receives exception info for rollback
        assert exit_calls[0][0] is not None

    async def test_store_embedding_failure_no_db_write(
        self, memory_manager, mock_db, mock_embedding, sample_context
    ):
        """Test that embedding failure happens before any DB write."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()

        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        mock_db.session.return_value.__aexit__ = AsyncMock(return_value=False)

        # Make embedding fail
        mock_embedding.embed.side_effect = EmbeddingError("API error")

        with pytest.raises(MemoryStoreError, match="Failed to embed content"):
            await memory_manager.store(
                user_message="Test",
                agent_response="Response",
                context=sample_context,
            )

        # Session.add should never be called since embedding fails first
        mock_session.add.assert_not_called()

    async def test_store_no_idempotency_mark_on_qdrant_failure(
        self, memory_manager, mock_db, mock_qdrant, mock_redis, sample_context
    ):
        """Test idempotency key not set when Qdrant fails."""
        mock_session = AsyncMock()
        mock_session.add = MagicMock()
        mock_session.flush = AsyncMock()
        mock_db.session.return_value.__aenter__ = AsyncMock(return_value=mock_session)
        # Return False to propagate exception
        mock_db.session.return_value.__aexit__ = AsyncMock(return_value=False)

        mock_qdrant.upsert.side_effect = QdrantError("Vector storage failed")

        with pytest.raises(MemoryStoreError):
            await memory_manager.store(
                user_message="Test",
                agent_response="Response",
                context=sample_context,
            )

        # redis.set should not be called for idempotency marker
        mock_redis.set.assert_not_called()


class TestRound2CacheKeyLimit:
    """Tests for limit in cache key (MEDIUM-1)."""

    def test_cache_key_includes_limit(self, memory_manager):
        """Test that limit is included in cache key."""
        key_limit_5 = memory_manager._get_cache_key("query", "session-1", 5)
        key_limit_10 = memory_manager._get_cache_key("query", "session-1", 10)

        assert key_limit_5 != key_limit_10

    def test_cache_key_same_limit_same_key(self, memory_manager):
        """Test same limit produces same key."""
        key1 = memory_manager._get_cache_key("query", "session-1", 15)
        key2 = memory_manager._get_cache_key("query", "session-1", 15)

        assert key1 == key2

    async def test_recall_different_limits_separate_cache(
        self, memory_manager, mock_redis, mock_qdrant, sample_context
    ):
        """Test recall with different limits uses separate cache entries."""
        mock_qdrant.search.return_value = []

        # Call recall with limit=5
        await memory_manager.recall("test query", sample_context, limit=5)

        # Call recall with limit=10
        await memory_manager.recall("test query", sample_context, limit=10)

        # cache_set should be called twice (different keys)
        assert mock_redis.cache_set.call_count == 2


class TestRound2NullImportance:
    """Tests for null importance handling (MEDIUM-2)."""

    def test_rank_null_importance_defaults_to_half(self, memory_manager):
        """Test null importance defaults to 0.5 in ranking."""
        event = MagicMock()
        event.id = uuid4()
        event.type = "conversation"
        event.title = "Test"
        event.summary = "Summary"
        event.occurred_at = datetime.now(UTC)
        event.importance = None  # Null importance

        search_results = [SearchResult(id=event.id, score=0.8, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 1
        assert ranked[0].importance == 0.5  # Should default to 0.5

    def test_rank_zero_importance_preserved(self, memory_manager):
        """Test zero importance is preserved (not treated as null)."""
        event = MagicMock()
        event.id = uuid4()
        event.type = "conversation"
        event.title = "Test"
        event.summary = "Summary"
        event.occurred_at = datetime.now(UTC)
        event.importance = 0.0  # Explicit zero

        search_results = [SearchResult(id=event.id, score=0.8, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        assert len(ranked) == 1
        assert ranked[0].importance == 0.0  # Should stay 0.0

    def test_rank_null_importance_correct_score(self, memory_manager):
        """Test final score is correctly calculated with null importance."""
        from packages.shared.digital_valerii_shared.services.memory import (
            IMPORTANCE_WEIGHT,
            TIME_DECAY_WEIGHT,
            VECTOR_SCORE_WEIGHT,
        )

        event = MagicMock()
        event.id = uuid4()
        event.type = "conversation"
        event.title = "Test"
        event.summary = "Summary"
        event.occurred_at = datetime.now(UTC)
        event.importance = None

        vector_score = 0.8
        search_results = [SearchResult(id=event.id, score=vector_score, payload={})]
        events = {event.id: event}

        ranked = memory_manager._rank_by_relevance(
            search_results, events, datetime.now(UTC)
        )

        # Recent event: time_decay ~ 1.0, importance = 0.5 (default)
        expected_score = (
            vector_score * VECTOR_SCORE_WEIGHT
            + 0.5 * IMPORTANCE_WEIGHT
            + 1.0 * TIME_DECAY_WEIGHT
        )
        assert ranked[0].final_score == pytest.approx(expected_score, rel=0.01)
