"""Tests for workflow base classes.

Component 4.11: Orchestration Patterns
"""

from uuid import uuid4

import pytest
from digital_valerii_shared.workflows.base import (
    MergeAggregator,
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)


class TestWorkflowContext:
    """Tests for WorkflowContext."""

    def test_default_values(self) -> None:
        """Test default values are set correctly."""
        ctx = WorkflowContext()

        assert ctx.workflow_id is not None
        assert ctx.user_id is None
        assert ctx.project_id is None
        assert ctx.data == {}
        assert ctx.history == []

    def test_custom_values(self) -> None:
        """Test custom values are preserved."""
        workflow_id = uuid4()
        user_id = uuid4()
        project_id = uuid4()
        data = {"key": "value"}

        ctx = WorkflowContext(
            workflow_id=workflow_id,
            user_id=user_id,
            project_id=project_id,
            data=data,
        )

        assert ctx.workflow_id == workflow_id
        assert ctx.user_id == user_id
        assert ctx.project_id == project_id
        assert ctx.data == {"key": "value"}

    def test_record_step_completed(self) -> None:
        """Test recording a completed step."""
        ctx = WorkflowContext()
        ctx.record_step("TestStep", status="completed")

        assert len(ctx.history) == 1
        assert ctx.history[0]["step"] == "TestStep"
        assert ctx.history[0]["status"] == "completed"
        assert ctx.history[0]["error"] is None
        assert "completed_at" in ctx.history[0]

    def test_record_step_failed(self) -> None:
        """Test recording a failed step."""
        ctx = WorkflowContext()
        ctx.record_step("FailedStep", status="failed", error="Something went wrong")

        assert len(ctx.history) == 1
        assert ctx.history[0]["step"] == "FailedStep"
        assert ctx.history[0]["status"] == "failed"
        assert ctx.history[0]["error"] == "Something went wrong"

    def test_record_multiple_steps(self) -> None:
        """Test recording multiple steps."""
        ctx = WorkflowContext()
        ctx.record_step("Step1")
        ctx.record_step("Step2")
        ctx.record_step("Step3", status="failed", error="Error")

        assert len(ctx.history) == 3
        assert ctx.history[0]["step"] == "Step1"
        assert ctx.history[1]["step"] == "Step2"
        assert ctx.history[2]["step"] == "Step3"


class TestWorkflowStep:
    """Tests for WorkflowStep base class."""

    def test_name_property(self) -> None:
        """Test that name property returns class name."""

        class CustomStep(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                return context

        step = CustomStep()
        assert step.name == "CustomStep"

    @pytest.mark.asyncio
    async def test_execute_must_be_implemented(self) -> None:
        """Test that execute is abstract."""
        # WorkflowStep cannot be instantiated directly
        with pytest.raises(TypeError):
            WorkflowStep()


class TestMergeAggregator:
    """Tests for MergeAggregator."""

    @pytest.mark.asyncio
    async def test_merge_empty_results(self) -> None:
        """Test merging empty results."""
        aggregator = MergeAggregator()
        ctx = WorkflowContext(data={"original": "data"})

        result = await aggregator.aggregate([], ctx)

        assert result.data == {"original": "data"}

    @pytest.mark.asyncio
    async def test_merge_single_result(self) -> None:
        """Test merging single result."""
        aggregator = MergeAggregator()
        ctx = WorkflowContext(data={"original": "data"})
        result1 = WorkflowContext(data={"new": "value"})

        result = await aggregator.aggregate([result1], ctx)

        assert result.data == {"original": "data", "new": "value"}

    @pytest.mark.asyncio
    async def test_merge_multiple_results(self) -> None:
        """Test merging multiple results."""
        aggregator = MergeAggregator()
        ctx = WorkflowContext(data={"original": "data"})
        result1 = WorkflowContext(data={"key1": "value1"})
        result2 = WorkflowContext(data={"key2": "value2"})
        result3 = WorkflowContext(data={"key3": "value3"})

        result = await aggregator.aggregate([result1, result2, result3], ctx)

        assert result.data == {
            "original": "data",
            "key1": "value1",
            "key2": "value2",
            "key3": "value3",
        }

    @pytest.mark.asyncio
    async def test_merge_overwrites_duplicate_keys(self) -> None:
        """Test that later results overwrite earlier keys."""
        aggregator = MergeAggregator()
        ctx = WorkflowContext(data={"key": "original"})
        result1 = WorkflowContext(data={"key": "first"})
        result2 = WorkflowContext(data={"key": "second"})

        result = await aggregator.aggregate([result1, result2], ctx)

        # Last result wins
        assert result.data["key"] == "second"


class TestWorkflowError:
    """Tests for WorkflowError."""

    def test_workflow_error_message(self) -> None:
        """Test WorkflowError can be raised with message."""
        with pytest.raises(WorkflowError) as exc_info:
            raise WorkflowError("Test error message")

        assert str(exc_info.value) == "Test error message"

    def test_workflow_error_is_exception(self) -> None:
        """Test WorkflowError is an Exception subclass."""
        assert issubclass(WorkflowError, Exception)
