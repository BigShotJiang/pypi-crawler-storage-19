"""Unit tests for Pydantic schemas."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from pydantic import ValidationError

from packages.shared.digital_valerii_shared.schemas import (
    ConversationCreate,
    EventCreate,
    LessonCreate,
    MessageCreate,
    PersonCreate,
    ProjectCreate,
)


class TestStrictValidation:
    """Tests for strict validation (extra='forbid')."""

    def test_person_create_rejects_unknown_fields(self) -> None:
        """Test PersonCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            PersonCreate(name="Test", unknown_field="value")

        assert "extra_forbidden" in str(exc_info.value)

    def test_project_create_rejects_unknown_fields(self) -> None:
        """Test ProjectCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            ProjectCreate(name="Test", unknown_field="value")

        assert "extra_forbidden" in str(exc_info.value)

    def test_event_create_rejects_unknown_fields(self) -> None:
        """Test EventCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            EventCreate(
                type="meeting",
                occurred_at=datetime.now(UTC),
                unknown_field="value",
            )

        assert "extra_forbidden" in str(exc_info.value)

    def test_lesson_create_rejects_unknown_fields(self) -> None:
        """Test LessonCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            LessonCreate(content="Test lesson", unknown_field="value")

        assert "extra_forbidden" in str(exc_info.value)

    def test_conversation_create_rejects_unknown_fields(self) -> None:
        """Test ConversationCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            ConversationCreate(unknown_field="value")

        assert "extra_forbidden" in str(exc_info.value)

    def test_message_create_rejects_unknown_fields(self) -> None:
        """Test MessageCreate rejects unknown fields."""
        with pytest.raises(ValidationError) as exc_info:
            MessageCreate(
                conversation_id=uuid4(),
                role="user",
                content="Hello",
                unknown_field="value",
            )

        assert "extra_forbidden" in str(exc_info.value)


class TestPersonSchemas:
    """Tests for Person schemas."""

    def test_person_create_valid(self) -> None:
        """Test valid PersonCreate."""
        person = PersonCreate(
            name="John Doe",
            email="john@example.com",
            company="Acme Inc",
        )
        assert person.name == "John Doe"
        assert person.email == "john@example.com"
        assert person.company == "Acme Inc"

    def test_person_create_strips_whitespace(self) -> None:
        """Test PersonCreate strips whitespace from strings."""
        person = PersonCreate(name="  John Doe  ")
        assert person.name == "John Doe"

    def test_person_create_name_required(self) -> None:
        """Test PersonCreate requires name."""
        with pytest.raises(ValidationError):
            PersonCreate()


class TestProjectSchemas:
    """Tests for Project schemas."""

    def test_project_create_valid(self) -> None:
        """Test valid ProjectCreate."""
        project = ProjectCreate(
            name="My Project",
            description="A test project",
            status="active",
            tags=["python", "ai"],
        )
        assert project.name == "My Project"
        assert project.status == "active"
        assert project.tags == ["python", "ai"]

    def test_project_create_default_status(self) -> None:
        """Test ProjectCreate default status."""
        project = ProjectCreate(name="My Project")
        assert project.status == "active"


class TestEventSchemas:
    """Tests for Event schemas."""

    def test_event_create_valid(self) -> None:
        """Test valid EventCreate."""
        occurred_at = datetime.now(UTC)
        event = EventCreate(
            type="meeting",
            title="Team Standup",
            occurred_at=occurred_at,
            importance=0.8,
        )
        assert event.type == "meeting"
        assert event.title == "Team Standup"
        assert event.importance == 0.8

    def test_event_create_default_importance(self) -> None:
        """Test EventCreate default importance."""
        event = EventCreate(
            type="conversation",
            occurred_at=datetime.now(UTC),
        )
        assert event.importance == 0.5


class TestLessonSchemas:
    """Tests for Lesson schemas."""

    def test_lesson_create_valid(self) -> None:
        """Test valid LessonCreate."""
        lesson = LessonCreate(
            content="User prefers morning meetings",
            category="preference",
            confidence=0.9,
        )
        assert lesson.content == "User prefers morning meetings"
        assert lesson.category == "preference"
        assert lesson.confidence == 0.9

    def test_lesson_create_default_confidence(self) -> None:
        """Test LessonCreate default confidence."""
        lesson = LessonCreate(content="A lesson")
        assert lesson.confidence == 0.5


class TestConversationSchemas:
    """Tests for Conversation schemas."""

    def test_conversation_create_valid(self) -> None:
        """Test valid ConversationCreate."""
        conv = ConversationCreate(
            title="Project Discussion",
            interface="web",
        )
        assert conv.title == "Project Discussion"
        assert conv.interface == "web"

    def test_conversation_create_default_interface(self) -> None:
        """Test ConversationCreate default interface."""
        conv = ConversationCreate()
        assert conv.interface == "cli"


class TestMessageSchemas:
    """Tests for Message schemas."""

    def test_message_create_valid(self) -> None:
        """Test valid MessageCreate."""
        conv_id = uuid4()
        msg = MessageCreate(
            conversation_id=conv_id,
            role="user",
            content="Hello, how are you?",
        )
        assert msg.conversation_id == conv_id
        assert msg.role == "user"
        assert msg.content == "Hello, how are you?"

    def test_message_create_required_fields(self) -> None:
        """Test MessageCreate requires all mandatory fields."""
        with pytest.raises(ValidationError):
            MessageCreate(role="user", content="Hello")  # missing conversation_id

        with pytest.raises(ValidationError):
            MessageCreate(conversation_id=uuid4(), content="Hello")  # missing role

        with pytest.raises(ValidationError):
            MessageCreate(conversation_id=uuid4(), role="user")  # missing content
