"""Pytest configuration for shared package tests."""

# Note: Package is installed via poetry, no sys.path manipulation needed
