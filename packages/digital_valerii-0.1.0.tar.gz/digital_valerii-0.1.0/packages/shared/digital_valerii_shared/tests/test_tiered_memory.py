"""Tests for Tiered Memory Manager service.

Component 4.9: Long-term Memory Architecture
"""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from digital_valerii_shared.models.archive import (
    ArchiveIndexEntry,
    ArchivedEvent,
    StrategicMemory,
    TieredMemoryContext,
    YearDetectionResult,
)
from digital_valerii_shared.services.tiered_memory import (
    TieredMemoryManager,
    YearPattern,
    YEAR_PATTERNS,
)


class TestYearPattern:
    """Tests for YearPattern class."""

    def test_year_pattern_initialization(self) -> None:
        """Test YearPattern initializes correctly."""
        pattern = YearPattern(
            pattern=r"(\d{4})",
            extractor=lambda m: [int(m.group(1))],
            description="Test pattern",
        )
        assert pattern.description == "Test pattern"
        assert pattern.regex is not None

    def test_year_pattern_match(self) -> None:
        """Test YearPattern can match text."""
        pattern = YearPattern(
            pattern=r"in\s+(\d{4})",
            extractor=lambda m: [int(m.group(1))],
            description="English: in YYYY",
        )
        match = pattern.regex.search("What happened in 2022?")
        assert match is not None
        years = pattern.extractor(match)
        assert years == [2022]

    def test_year_pattern_case_insensitive(self) -> None:
        """Test YearPattern is case insensitive."""
        pattern = YearPattern(
            pattern=r"YEAR\s+(\d{4})",
            extractor=lambda m: [int(m.group(1))],
            description="Test case",
        )
        match = pattern.regex.search("year 2023")
        assert match is not None


class TestYearPatternsCollection:
    """Tests for the YEAR_PATTERNS collection."""

    def test_year_patterns_not_empty(self) -> None:
        """Test YEAR_PATTERNS contains patterns."""
        assert len(YEAR_PATTERNS) > 0

    def test_year_patterns_are_year_pattern_instances(self) -> None:
        """Test all items are YearPattern instances."""
        for pattern in YEAR_PATTERNS:
            assert isinstance(pattern, YearPattern)

    def test_year_patterns_have_descriptions(self) -> None:
        """Test all patterns have descriptions."""
        for pattern in YEAR_PATTERNS:
            assert pattern.description
            assert len(pattern.description) > 0

    def test_year_patterns_bilingual(self) -> None:
        """Test patterns include both Ukrainian and English."""
        descriptions = [p.description for p in YEAR_PATTERNS]
        has_ukrainian = any("Ukrainian" in d or "року" in d for d in descriptions)
        has_english = any("English" in d for d in descriptions)
        assert has_ukrainian, "Should have Ukrainian patterns"
        assert has_english, "Should have English patterns"


class TestYearDetectionResultModel:
    """Tests for YearDetectionResult model."""

    def test_year_detection_result_defaults(self) -> None:
        """Test YearDetectionResult has correct defaults."""
        result = YearDetectionResult()
        assert result.years == []
        assert result.patterns_matched == []

    def test_year_detection_result_with_data(self) -> None:
        """Test YearDetectionResult with actual data."""
        result = YearDetectionResult(
            years=[2022, 2023],
            patterns_matched=["English: in 2022", "English: in 2023"],
        )
        assert len(result.years) == 2
        assert 2022 in result.years

    def test_year_detection_result_extra_forbid(self) -> None:
        """Test YearDetectionResult rejects extra fields."""
        with pytest.raises(ValueError):
            YearDetectionResult(extra_field="not allowed")  # type: ignore[call-arg]


class TestTieredMemoryContextModel:
    """Tests for TieredMemoryContext model."""

    def test_tiered_memory_context_defaults(self) -> None:
        """Test TieredMemoryContext has correct defaults."""
        context = TieredMemoryContext(query="test query")
        assert context.query == "test query"
        assert context.active_events == []
        assert context.archived_events == []
        assert context.strategic_memories == []
        assert context.years_searched == []
        assert context.cached is False

    def test_tiered_memory_context_with_data(self) -> None:
        """Test TieredMemoryContext with data."""
        now = datetime.now(UTC)
        archived = ArchivedEvent(
            id=uuid4(),
            year=2022,
            user_id=uuid4(),
            original_id=uuid4(),
            event_type="conversation",
            archived_at=now,
        )
        context = TieredMemoryContext(
            query="project discussions",
            active_events=[{"id": str(uuid4()), "type": "meeting"}],
            archived_events=[archived],
            years_searched=[2024, 2022],
            cached=True,
        )
        assert len(context.active_events) == 1
        assert len(context.archived_events) == 1
        assert context.cached is True

    def test_tiered_memory_context_extra_forbid(self) -> None:
        """Test TieredMemoryContext rejects extra fields."""
        with pytest.raises(ValueError):
            TieredMemoryContext(
                query="test",
                extra_field="not allowed",  # type: ignore[call-arg]
            )


class TestTieredMemoryManagerInit:
    """Tests for TieredMemoryManager initialization."""

    def test_tiered_memory_manager_init(self) -> None:
        """Test TieredMemoryManager initializes correctly."""
        memory_manager = MagicMock()
        archive_manager = MagicMock()

        manager = TieredMemoryManager(
            memory_manager=memory_manager,
            archive_manager=archive_manager,
        )

        assert manager._memory is memory_manager
        assert manager._archive is archive_manager
        assert manager._current_year == datetime.now().year


class TestTieredMemoryManagerYearDetection:
    """Tests for TieredMemoryManager year detection."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.memory_manager = MagicMock()
        self.archive_manager = MagicMock()
        self.manager = TieredMemoryManager(
            memory_manager=self.memory_manager,
            archive_manager=self.archive_manager,
        )

    def test_detect_years_explicit_english(self) -> None:
        """Test detecting explicit year in English."""
        result = self.manager.detect_years_from_query("What happened in 2022?")
        assert 2022 in result.years

    def test_detect_years_explicit_ukrainian(self) -> None:
        """Test detecting explicit year in Ukrainian."""
        result = self.manager.detect_years_from_query("Що було у 2022 році?")
        assert 2022 in result.years

    def test_detect_years_multiple(self) -> None:
        """Test detecting multiple years."""
        result = self.manager.detect_years_from_query(
            "Compare events from 2021 and 2022"
        )
        assert 2021 in result.years
        assert 2022 in result.years

    def test_detect_years_relative_last_year(self) -> None:
        """Test detecting 'last year' reference."""
        result = self.manager.detect_years_from_query("What did we do last year?")
        current_year = datetime.now().year
        assert (current_year - 1) in result.years

    def test_detect_years_relative_ukrainian_last_year(self) -> None:
        """Test detecting Ukrainian 'минулого року' (last year)."""
        result = self.manager.detect_years_from_query("Що було минулого року?")
        current_year = datetime.now().year
        assert (current_year - 1) in result.years

    def test_detect_years_n_years_ago(self) -> None:
        """Test detecting 'N years ago' pattern."""
        result = self.manager.detect_years_from_query("What happened 3 years ago?")
        current_year = datetime.now().year
        assert (current_year - 3) in result.years

    def test_detect_years_no_match(self) -> None:
        """Test query with no year references."""
        result = self.manager.detect_years_from_query("Tell me about the project")
        assert len(result.years) == 0

    def test_detect_years_filters_invalid(self) -> None:
        """Test that invalid years are filtered out."""
        result = self.manager.detect_years_from_query("Product code 9999")
        # 9999 is outside valid range (2000-2100)
        assert 9999 not in result.years

    def test_detect_years_returns_patterns_matched(self) -> None:
        """Test that patterns_matched is populated."""
        result = self.manager.detect_years_from_query("What happened in 2022?")
        assert len(result.patterns_matched) > 0


@pytest.mark.asyncio
class TestTieredMemoryManagerRecall:
    """Tests for TieredMemoryManager recall method."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.memory_manager = MagicMock()
        self.archive_manager = MagicMock()
        self.manager = TieredMemoryManager(
            memory_manager=self.memory_manager,
            archive_manager=self.archive_manager,
        )

    async def test_recall_active_only(self) -> None:
        """Test recall searches active memory."""
        # Mock active memory recall
        self.memory_manager.recall = AsyncMock(
            return_value=MagicMock(events=[])
        )

        result = await self.manager.recall(
            query="recent meetings",
            user_id=uuid4(),
            auto_detect_years=False,
        )

        assert isinstance(result, TieredMemoryContext)
        self.memory_manager.recall.assert_called_once()

    async def test_recall_with_explicit_archives(self) -> None:
        """Test recall with explicit archive years."""
        self.memory_manager.recall = AsyncMock(
            return_value=MagicMock(events=[])
        )
        self.archive_manager.search_archive = AsyncMock(return_value=[])
        self.archive_manager.get_strategic_memories = AsyncMock(return_value=[])

        result = await self.manager.recall(
            query="project discussions",
            user_id=uuid4(),
            include_archives=[2022, 2023],
        )

        # Should have searched archives
        assert 2022 in result.years_searched or self.archive_manager.search_archive.called

    async def test_recall_returns_tiered_context(self) -> None:
        """Test recall returns TieredMemoryContext."""
        self.memory_manager.recall = AsyncMock(
            return_value=MagicMock(events=[])
        )

        result = await self.manager.recall(
            query="test query",
            user_id=uuid4(),
        )

        assert isinstance(result, TieredMemoryContext)
        assert result.query == "test query"


@pytest.mark.asyncio
class TestTieredMemoryManagerStats:
    """Tests for TieredMemoryManager statistics methods."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.memory_manager = MagicMock()
        self.archive_manager = MagicMock()
        self.manager = TieredMemoryManager(
            memory_manager=self.memory_manager,
            archive_manager=self.archive_manager,
        )

    async def test_get_available_years(self) -> None:
        """Test get_available_years returns years list."""
        now = datetime.now(UTC)
        self.archive_manager.get_archive_index = AsyncMock(
            return_value=[
                ArchiveIndexEntry(
                    year=2022,
                    user_id=uuid4(),
                    archived_at=now,
                    event_count=100,
                    summary="Test archive 2022",
                    qdrant_collection="archive_2022",
                ),
                ArchiveIndexEntry(
                    year=2023,
                    user_id=uuid4(),
                    archived_at=now,
                    event_count=150,
                    summary="Test archive 2023",
                    qdrant_collection="archive_2023",
                ),
            ]
        )

        years = await self.manager.get_available_years(uuid4())

        assert isinstance(years, list)
        assert 2022 in years
        assert 2023 in years
        # Should include current year
        assert datetime.now().year in years

    async def test_get_memory_stats(self) -> None:
        """Test get_memory_stats returns stats dict."""
        now = datetime.now(UTC)
        self.archive_manager.get_archive_index = AsyncMock(
            return_value=[
                ArchiveIndexEntry(
                    year=2022,
                    user_id=uuid4(),
                    archived_at=now,
                    event_count=100,
                    summary="Test",
                    qdrant_collection="archive_2022",
                ),
            ]
        )

        stats = await self.manager.get_memory_stats(uuid4())

        assert "current_year" in stats
        assert "tiers" in stats
        assert stats["current_year"] == datetime.now().year

    async def test_get_available_years_sorted_descending(self) -> None:
        """Test get_available_years returns years sorted descending."""
        now = datetime.now(UTC)
        self.archive_manager.get_archive_index = AsyncMock(
            return_value=[
                ArchiveIndexEntry(
                    year=2020,
                    user_id=uuid4(),
                    archived_at=now,
                    event_count=50,
                    summary="Test 2020",
                    qdrant_collection="archive_2020",
                ),
                ArchiveIndexEntry(
                    year=2022,
                    user_id=uuid4(),
                    archived_at=now,
                    event_count=100,
                    summary="Test 2022",
                    qdrant_collection="archive_2022",
                ),
            ]
        )

        years = await self.manager.get_available_years(uuid4())

        # Should be sorted descending
        assert years == sorted(years, reverse=True)
