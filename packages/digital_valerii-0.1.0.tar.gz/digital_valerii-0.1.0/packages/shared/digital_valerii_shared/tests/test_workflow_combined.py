"""Tests for combined workflow patterns.

Component 4.11: Orchestration Patterns
"""

import asyncio

import pytest
from digital_valerii_shared.workflows.base import WorkflowContext, WorkflowStep
from digital_valerii_shared.workflows.combined import (
    LoopWorkflowStep,
    ParallelWorkflowStep,
)
from digital_valerii_shared.workflows.sequential import SequentialWorkflow


class AddValueStep(WorkflowStep):
    """Test step that adds a value to context."""

    def __init__(self, key: str, value: str, delay: float = 0):
        self.key = key
        self.value = value
        self.delay = delay

    @property
    def name(self) -> str:
        return f"AddValue_{self.key}"

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        if self.delay:
            await asyncio.sleep(self.delay)
        context.data[self.key] = self.value
        return context


class IncrementStep(WorkflowStep):
    """Test step that increments a counter."""

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data["counter"] = context.data.get("counter", 0) + 1
        return context


class RefineScoreStep(WorkflowStep):
    """Test step that increases score each iteration."""

    def __init__(self, increment: float = 0.2):
        self.increment = increment

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data["score"] = context.data.get("score", 0.0) + self.increment
        return context


class TestParallelWorkflowStep:
    """Tests for ParallelWorkflowStep."""

    @pytest.mark.asyncio
    async def test_parallel_in_sequential(self) -> None:
        """Test parallel step inside sequential workflow."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("start", "begin"),
                ParallelWorkflowStep(
                    [
                        AddValueStep("a", "1"),
                        AddValueStep("b", "2"),
                        AddValueStep("c", "3"),
                    ]
                ),
                AddValueStep("end", "finish"),
            ]
        )
        result = await workflow.run()

        assert result.data["start"] == "begin"
        assert result.data["a"] == "1"
        assert result.data["b"] == "2"
        assert result.data["c"] == "3"
        assert result.data["end"] == "finish"

    @pytest.mark.asyncio
    async def test_parallel_step_name(self) -> None:
        """Test custom step name."""
        step = ParallelWorkflowStep([], name="CustomParallel")
        assert step.name == "CustomParallel"

    @pytest.mark.asyncio
    async def test_parallel_runs_concurrently(self) -> None:
        """Test parallel step runs tasks concurrently."""
        import time

        workflow = SequentialWorkflow(
            [
                ParallelWorkflowStep(
                    [
                        AddValueStep("a", "1", delay=0.1),
                        AddValueStep("b", "2", delay=0.1),
                        AddValueStep("c", "3", delay=0.1),
                    ]
                ),
            ]
        )

        start = time.time()
        await workflow.run()
        elapsed = time.time() - start

        # Should complete in ~0.1s, not 0.3s
        assert elapsed < 0.25

    @pytest.mark.asyncio
    async def test_parallel_with_fail_fast(self) -> None:
        """Test parallel step with fail_fast option."""

        class FailingStep(WorkflowStep):
            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                raise ValueError("Intentional failure")

        workflow = SequentialWorkflow(
            [
                ParallelWorkflowStep(
                    [AddValueStep("ok", "value"), FailingStep()],
                    fail_fast=True,
                ),
            ]
        )

        from digital_valerii_shared.workflows.base import WorkflowError

        with pytest.raises(WorkflowError):
            await workflow.run()


class TestLoopWorkflowStep:
    """Tests for LoopWorkflowStep."""

    @pytest.mark.asyncio
    async def test_loop_in_sequential(self) -> None:
        """Test loop step inside sequential workflow."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("start", "begin"),
                LoopWorkflowStep(
                    steps=[IncrementStep()],
                    condition=lambda ctx: ctx.data.get("counter", 0) >= 3,
                    max_iterations=10,
                ),
                AddValueStep("end", "finish"),
            ]
        )
        result = await workflow.run()

        assert result.data["start"] == "begin"
        assert result.data["counter"] == 3
        assert result.data["loop_completed"] is True
        assert result.data["end"] == "finish"

    @pytest.mark.asyncio
    async def test_loop_step_name(self) -> None:
        """Test custom step name."""
        step = LoopWorkflowStep(
            steps=[],
            condition=lambda _ctx: True,
            name="CustomLoop",
        )
        assert step.name == "CustomLoop"

    @pytest.mark.asyncio
    async def test_loop_max_iterations(self) -> None:
        """Test loop stops at max iterations."""
        workflow = SequentialWorkflow(
            [
                LoopWorkflowStep(
                    steps=[IncrementStep()],
                    condition=lambda _ctx: False,  # Never met
                    max_iterations=5,
                ),
            ]
        )
        result = await workflow.run()

        assert result.data["counter"] == 5
        assert result.data["loop_completed"] is False

    @pytest.mark.asyncio
    async def test_refinement_pattern(self) -> None:
        """Test iterative refinement pattern."""
        workflow = SequentialWorkflow(
            [
                AddValueStep("initial", "draft"),
                LoopWorkflowStep(
                    steps=[RefineScoreStep(increment=0.25)],
                    condition=lambda ctx: ctx.data.get("score", 0) >= 0.85,
                    max_iterations=10,
                ),
                AddValueStep("final", "done"),
            ]
        )
        result = await workflow.run()

        assert result.data["score"] >= 0.85
        assert result.data["iterations"] == 4  # 0.25 * 4 = 1.0
        assert result.data["final"] == "done"


class TestCombinedPatterns:
    """Tests for complex combined patterns."""

    @pytest.mark.asyncio
    async def test_parallel_then_loop(self) -> None:
        """Test parallel followed by loop in sequential."""
        workflow = SequentialWorkflow(
            [
                ParallelWorkflowStep(
                    [
                        AddValueStep("a", "1"),
                        AddValueStep("b", "2"),
                    ]
                ),
                LoopWorkflowStep(
                    steps=[IncrementStep()],
                    condition=lambda ctx: ctx.data.get("counter", 0) >= 2,
                    max_iterations=5,
                ),
            ]
        )
        result = await workflow.run()

        # Parallel results
        assert result.data["a"] == "1"
        assert result.data["b"] == "2"
        # Loop results
        assert result.data["counter"] == 2
        assert result.data["loop_completed"] is True

    @pytest.mark.asyncio
    async def test_multiple_parallel_steps(self) -> None:
        """Test multiple parallel steps in sequence."""
        workflow = SequentialWorkflow(
            [
                ParallelWorkflowStep(
                    [
                        AddValueStep("first_a", "1a"),
                        AddValueStep("first_b", "1b"),
                    ]
                ),
                AddValueStep("middle", "m"),
                ParallelWorkflowStep(
                    [
                        AddValueStep("second_a", "2a"),
                        AddValueStep("second_b", "2b"),
                    ]
                ),
            ]
        )
        result = await workflow.run()

        assert result.data["first_a"] == "1a"
        assert result.data["first_b"] == "1b"
        assert result.data["middle"] == "m"
        assert result.data["second_a"] == "2a"
        assert result.data["second_b"] == "2b"
