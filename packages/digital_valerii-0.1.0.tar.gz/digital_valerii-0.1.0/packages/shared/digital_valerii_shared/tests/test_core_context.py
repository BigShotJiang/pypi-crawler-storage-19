"""Tests for Agent Core Context.

This module contains tests for the simplified context management,
including ConversationContext and InterfaceType.
"""

from uuid import UUID, uuid4

import pytest
from digital_valerii_shared.agent.core import ConversationContext, InterfaceType
from digital_valerii_shared.agent.personality import LanguageMode
from pydantic import ValidationError


class TestInterfaceType:
    """Tests for InterfaceType enum."""

    def test_interface_type_values(self) -> None:
        """Test that all expected interface types exist."""
        assert InterfaceType.CLI == "cli"
        assert InterfaceType.WEB == "web"
        assert InterfaceType.SLACK == "slack"
        assert InterfaceType.MEETING == "meeting"
        assert InterfaceType.API == "api"

    def test_interface_type_count(self) -> None:
        """Test that there are exactly 5 interface types."""
        assert len(InterfaceType) == 5

    def test_interface_type_is_string(self) -> None:
        """Test that interface type values are strings."""
        for interface in InterfaceType:
            assert isinstance(interface.value, str)


class TestConversationContext:
    """Tests for ConversationContext model."""

    def test_context_creation_minimal(self) -> None:
        """Test creating a minimal ConversationContext."""
        context = ConversationContext()
        assert context.conversation_id is not None
        assert isinstance(context.conversation_id, UUID)
        assert context.interface == InterfaceType.CLI
        assert context.language == LanguageMode.AUTO
        assert context.user_id is None
        assert context.session_id is None
        assert context.current_topic is None
        assert context.active_project_id is None
        assert context.active_people_ids == ()
        assert context.metadata == {}

    def test_context_creation_with_id(self) -> None:
        """Test creating ConversationContext with specific ID."""
        conv_id = uuid4()
        context = ConversationContext(conversation_id=conv_id)
        assert context.conversation_id == conv_id

    def test_context_creation_full(self) -> None:
        """Test creating a full ConversationContext."""
        conv_id = uuid4()
        user_id = uuid4()
        project_id = uuid4()
        person_id = uuid4()

        context = ConversationContext(
            conversation_id=conv_id,
            interface=InterfaceType.SLACK,
            language=LanguageMode.UKRAINIAN,
            user_id=user_id,
            session_id="session-123",
            current_topic="Security audit",
            active_project_id=project_id,
            active_people_ids=(person_id,),
            metadata={"key": "value"},
        )

        assert context.conversation_id == conv_id
        assert context.interface == InterfaceType.SLACK
        assert context.language == LanguageMode.UKRAINIAN
        assert context.user_id == user_id
        assert context.session_id == "session-123"
        assert context.current_topic == "Security audit"
        assert context.active_project_id == project_id
        assert context.active_people_ids == (person_id,)
        assert context.metadata == {"key": "value"}

    def test_update_session(self) -> None:
        """Test updating session ID."""
        context = ConversationContext()
        assert context.session_id is None

        context.update_session("new-session-id")
        assert context.session_id == "new-session-id"

    def test_clear_session(self) -> None:
        """Test clearing session ID."""
        context = ConversationContext(session_id="session-123")
        assert context.session_id == "session-123"

        context.clear_session()
        assert context.session_id is None

    def test_has_session(self) -> None:
        """Test has_session method."""
        context = ConversationContext()
        assert context.has_session() is False

        context.update_session("session-123")
        assert context.has_session() is True

        context.clear_session()
        assert context.has_session() is False

    def test_set_topic(self) -> None:
        """Test setting current topic."""
        context = ConversationContext()
        assert context.current_topic is None

        context.set_topic("New topic")
        assert context.current_topic == "New topic"

        context.set_topic(None)
        assert context.current_topic is None

    def test_set_active_project(self) -> None:
        """Test setting active project."""
        context = ConversationContext()
        project_id = uuid4()

        context.set_active_project(project_id)
        assert context.active_project_id == project_id

        context.set_active_project(None)
        assert context.active_project_id is None

    def test_set_active_people(self) -> None:
        """Test setting active people."""
        context = ConversationContext()
        person1 = uuid4()
        person2 = uuid4()

        context.set_active_people((person1, person2))
        assert context.active_people_ids == (person1, person2)

        context.set_active_people(())
        assert context.active_people_ids == ()

    def test_add_metadata(self) -> None:
        """Test adding metadata."""
        context = ConversationContext()
        context.add_metadata("key1", "value1")
        context.add_metadata("key2", {"nested": True})

        assert context.metadata["key1"] == "value1"
        assert context.metadata["key2"] == {"nested": True}

    def test_get_metadata(self) -> None:
        """Test getting metadata."""
        context = ConversationContext(metadata={"existing": "value"})

        assert context.get_metadata("existing") == "value"
        assert context.get_metadata("missing") is None
        assert context.get_metadata("missing", "default") == "default"

    def test_context_extra_forbid(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValidationError):
            ConversationContext(
                extra_field="not allowed",  # type: ignore[call-arg]
            )

    def test_context_mutable(self) -> None:
        """Test that context is mutable (not frozen)."""
        context = ConversationContext()
        # Should be able to update session
        context.session_id = "direct-update"
        assert context.session_id == "direct-update"

    def test_multiple_interface_types(self) -> None:
        """Test creating context with different interface types."""
        for interface in InterfaceType:
            context = ConversationContext(interface=interface)
            assert context.interface == interface
