"""Tests for Archive Manager service.

Component 4.9: Long-term Memory Architecture
"""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from digital_valerii_shared.models.archive import (
    ArchiveIndexEntry,
    ArchiveProgress,
    ArchiveResult,
    ArchivedEvent,
    MemoryType,
    StrategicMemory,
)
from digital_valerii_shared.services.archive_manager import (
    ArchiveError,
    ArchiveExistsError,
    ArchiveInProgressError,
    ArchiveManager,
    ArchiveNotFoundError,
    ArchiveStats,
)


class TestArchiveExceptions:
    """Tests for archive exception classes."""

    def test_archive_error_is_exception(self) -> None:
        """Test ArchiveError is an Exception."""
        assert issubclass(ArchiveError, Exception)

    def test_archive_not_found_error_inherits(self) -> None:
        """Test ArchiveNotFoundError inherits from ArchiveError."""
        assert issubclass(ArchiveNotFoundError, ArchiveError)

    def test_archive_exists_error_inherits(self) -> None:
        """Test ArchiveExistsError inherits from ArchiveError."""
        assert issubclass(ArchiveExistsError, ArchiveError)

    def test_archive_in_progress_error_inherits(self) -> None:
        """Test ArchiveInProgressError inherits from ArchiveError."""
        assert issubclass(ArchiveInProgressError, ArchiveError)

    def test_archive_error_message(self) -> None:
        """Test ArchiveError can carry a message."""
        error = ArchiveError("Test error message")
        assert str(error) == "Test error message"


class TestArchiveStatsModel:
    """Tests for ArchiveStats internal model."""

    def test_archive_stats_defaults(self) -> None:
        """Test ArchiveStats has correct defaults."""
        stats = ArchiveStats()
        assert stats.event_count == 0
        assert stats.message_count == 0
        assert stats.project_count == 0
        assert stats.people_count == 0
        assert stats.lesson_count == 0
        assert stats.decision_count == 0
        assert stats.event_types == {}
        assert stats.months_active == []

    def test_archive_stats_with_data(self) -> None:
        """Test ArchiveStats with actual data."""
        stats = ArchiveStats(
            event_count=100,
            message_count=50,
            project_count=5,
            people_count=20,
            lesson_count=10,
            decision_count=15,
            event_types={"conversation": 50, "meeting": 30, "email": 20},
            months_active=[1, 3, 5, 7, 9, 11],
        )
        assert stats.event_count == 100
        assert stats.event_types["conversation"] == 50
        assert len(stats.months_active) == 6

    def test_archive_stats_extra_forbid(self) -> None:
        """Test ArchiveStats rejects extra fields."""
        with pytest.raises(ValueError):
            ArchiveStats(extra_field="not allowed")  # type: ignore[call-arg]


class TestArchiveIndexEntryModel:
    """Tests for ArchiveIndexEntry model."""

    def test_archive_index_entry_valid(self) -> None:
        """Test ArchiveIndexEntry with valid data."""
        now = datetime.now(UTC)
        user_id = uuid4()
        entry = ArchiveIndexEntry(
            year=2023,
            user_id=user_id,
            archived_at=now,
            event_count=500,
            message_count=200,
            project_count=10,
            people_count=50,
            lesson_count=25,
            decision_count=15,
            summary="Annual archive for 2023 with key projects and milestones",
            key_achievements=["Completed Project X", "Hired 10 new team members"],
            qdrant_collection="archive_2023_abc12345",
            size_bytes=1024000,
        )
        assert entry.year == 2023
        assert entry.user_id == user_id
        assert entry.event_count == 500
        assert len(entry.key_achievements) == 2

    def test_archive_index_entry_extra_forbid(self) -> None:
        """Test ArchiveIndexEntry rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            ArchiveIndexEntry(  # type: ignore[call-arg]
                year=2023,
                user_id=uuid4(),
                archived_at=now,
                event_count=100,
                summary="Test",
                qdrant_collection="test",
                extra_field="not allowed",
            )

    def test_archive_index_entry_year_validation(self) -> None:
        """Test ArchiveIndexEntry year range validation."""
        now = datetime.now(UTC)
        # Valid range: 2000-2100
        with pytest.raises(ValueError):
            ArchiveIndexEntry(
                year=1999,
                user_id=uuid4(),
                archived_at=now,
                event_count=100,
                summary="Test",
                qdrant_collection="test",
            )

        with pytest.raises(ValueError):
            ArchiveIndexEntry(
                year=2101,
                user_id=uuid4(),
                archived_at=now,
                event_count=100,
                summary="Test",
                qdrant_collection="test",
            )


class TestArchivedEventModel:
    """Tests for ArchivedEvent model."""

    def test_archived_event_valid(self) -> None:
        """Test ArchivedEvent with valid data."""
        now = datetime.now(UTC)
        user_id = uuid4()
        event_id = uuid4()
        archived = ArchivedEvent(
            id=event_id,
            year=2023,
            user_id=user_id,
            original_id=event_id,
            event_type="conversation",
            title="Meeting with team",
            content="Discussed project roadmap",
            occurred_at=now,
            source="slack",
            importance=0.8,
            archived_at=now,
        )
        assert archived.id == event_id
        assert archived.year == 2023
        assert archived.event_type == "conversation"

    def test_archived_event_extra_forbid(self) -> None:
        """Test ArchivedEvent rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            ArchivedEvent(  # type: ignore[call-arg]
                id=uuid4(),
                year=2023,
                user_id=uuid4(),
                original_id=uuid4(),
                event_type="test",
                archived_at=now,
                extra_field="not allowed",
            )


class TestArchiveResultModel:
    """Tests for ArchiveResult model."""

    def test_archive_result_valid(self) -> None:
        """Test ArchiveResult with valid data."""
        result = ArchiveResult(
            year=2023,
            events_archived=500,
            strategic_memories_created=15,
            qdrant_collection="archive_2023_abc12345",
            summary="Successfully archived 2023 memories",
            key_achievements=["Project completion", "Team expansion"],
            duration_seconds=45.5,
        )
        assert result.year == 2023
        assert result.events_archived == 500
        assert result.duration_seconds == 45.5

    def test_archive_result_extra_forbid(self) -> None:
        """Test ArchiveResult rejects extra fields."""
        with pytest.raises(ValueError):
            ArchiveResult(  # type: ignore[call-arg]
                year=2023,
                events_archived=100,
                strategic_memories_created=5,
                qdrant_collection="test",
                summary="Test",
                duration_seconds=10.0,
                extra_field="not allowed",
            )


class TestArchiveProgressModel:
    """Tests for ArchiveProgress model."""

    def test_archive_progress_valid(self) -> None:
        """Test ArchiveProgress with valid data."""
        progress = ArchiveProgress(
            year=2023,
            phase="migrating",
            events_processed=250,
            events_total=500,
            percent_complete=50.0,
        )
        assert progress.phase == "migrating"
        assert progress.percent_complete == 50.0

    def test_archive_progress_percent_validation(self) -> None:
        """Test ArchiveProgress percent range validation."""
        # Valid: 0-100
        progress = ArchiveProgress(
            year=2023,
            phase="complete",
            events_processed=500,
            events_total=500,
            percent_complete=100.0,
        )
        assert progress.percent_complete == 100.0

        # Invalid: > 100
        with pytest.raises(ValueError):
            ArchiveProgress(
                year=2023,
                phase="error",
                events_processed=500,
                events_total=500,
                percent_complete=101.0,
            )


class TestStrategicMemoryModel:
    """Tests for StrategicMemory model."""

    def test_strategic_memory_valid(self) -> None:
        """Test StrategicMemory with valid data."""
        now = datetime.now(UTC)
        memory = StrategicMemory(
            id=uuid4(),
            user_id=uuid4(),
            year=2023,
            memory_type=MemoryType.PROJECT,
            title="Project Alpha Launch",
            summary="Successfully launched Project Alpha with 100% on-time delivery",
            keywords=["project", "launch", "alpha", "success"],
            importance=0.95,
            created_at=now,
        )
        assert memory.memory_type == MemoryType.PROJECT
        assert memory.importance == 0.95
        assert len(memory.keywords) == 4

    def test_strategic_memory_types(self) -> None:
        """Test all MemoryType enum values."""
        assert MemoryType.PROJECT.value == "project"
        assert MemoryType.PERSON.value == "person"
        assert MemoryType.LESSON.value == "lesson"
        assert MemoryType.DECISION.value == "decision"
        assert MemoryType.MILESTONE.value == "milestone"

    def test_strategic_memory_extra_forbid(self) -> None:
        """Test StrategicMemory rejects extra fields."""
        now = datetime.now(UTC)
        with pytest.raises(ValueError):
            StrategicMemory(  # type: ignore[call-arg]
                id=uuid4(),
                user_id=uuid4(),
                year=2023,
                memory_type=MemoryType.LESSON,
                title="Test",
                summary="Test lesson summary",
                created_at=now,
                extra_field="not allowed",
            )

    def test_strategic_memory_importance_validation(self) -> None:
        """Test StrategicMemory importance range validation."""
        now = datetime.now(UTC)
        # Valid: 0.0-1.0
        memory = StrategicMemory(
            id=uuid4(),
            user_id=uuid4(),
            year=2023,
            memory_type=MemoryType.DECISION,
            title="Test",
            summary="Test summary",
            importance=1.0,
            created_at=now,
        )
        assert memory.importance == 1.0

        # Invalid: > 1.0
        with pytest.raises(ValueError):
            StrategicMemory(
                id=uuid4(),
                user_id=uuid4(),
                year=2023,
                memory_type=MemoryType.DECISION,
                title="Test",
                summary="Test summary",
                importance=1.5,
                created_at=now,
            )
