"""Tests for Year Detection patterns.

Component 4.9: Long-term Memory Architecture
Comprehensive tests for Ukrainian/English bilingual year detection.
"""

from datetime import datetime
from unittest.mock import MagicMock

import pytest

from digital_valerii_shared.services.tiered_memory import (
    TieredMemoryManager,
    YearPattern,
    YEAR_PATTERNS,
    _current_year,
)


class TestCurrentYearFunction:
    """Tests for _current_year helper function."""

    def test_current_year_returns_integer(self) -> None:
        """Test _current_year returns an integer."""
        result = _current_year()
        assert isinstance(result, int)

    def test_current_year_matches_datetime(self) -> None:
        """Test _current_year matches datetime.now().year."""
        result = _current_year()
        assert result == datetime.now().year

    def test_current_year_in_valid_range(self) -> None:
        """Test _current_year is in valid range."""
        result = _current_year()
        assert 2000 <= result <= 2100


class TestYearPatternClass:
    """Tests for YearPattern class."""

    def test_year_pattern_regex_compiled(self) -> None:
        """Test YearPattern compiles regex on init."""
        pattern = YearPattern(
            pattern=r"(\d{4})",
            extractor=lambda m: [int(m.group(1))],
            description="Test",
        )
        assert hasattr(pattern.regex, "search")
        assert hasattr(pattern.regex, "finditer")

    def test_year_pattern_case_insensitive(self) -> None:
        """Test YearPattern uses case-insensitive matching."""
        pattern = YearPattern(
            pattern=r"year\s+(\d{4})",
            extractor=lambda m: [int(m.group(1))],
            description="Test case insensitivity",
        )
        # Should match both cases
        assert pattern.regex.search("YEAR 2023") is not None
        assert pattern.regex.search("year 2023") is not None
        assert pattern.regex.search("Year 2023") is not None

    def test_year_pattern_extractor_called(self) -> None:
        """Test extractor function is called with match."""
        extractor_called = [False]

        def track_extractor(m):
            extractor_called[0] = True
            return [int(m.group(1))]

        pattern = YearPattern(
            pattern=r"(\d{4})",
            extractor=track_extractor,
            description="Test extractor",
        )
        match = pattern.regex.search("2023")
        pattern.extractor(match)
        assert extractor_called[0]


class TestExplicitYearPatterns:
    """Tests for explicit year mention patterns."""

    def setup_method(self) -> None:
        """Set up test manager."""
        self.manager = TieredMemoryManager(
            memory_manager=MagicMock(),
            archive_manager=MagicMock(),
        )

    def test_detect_in_yyyy(self) -> None:
        """Test 'in YYYY' pattern detection."""
        result = self.manager.detect_years_from_query("What happened in 2022?")
        assert 2022 in result.years

    def test_detect_from_yyyy(self) -> None:
        """Test 'from YYYY' pattern detection."""
        result = self.manager.detect_years_from_query("Data from 2021")
        assert 2021 in result.years

    def test_detect_during_yyyy(self) -> None:
        """Test 'during YYYY' pattern detection."""
        result = self.manager.detect_years_from_query("Events during 2020")
        assert 2020 in result.years

    def test_detect_standalone_year(self) -> None:
        """Test standalone year detection."""
        result = self.manager.detect_years_from_query("2023 annual report")
        assert 2023 in result.years

    def test_detect_ukrainian_u_roku(self) -> None:
        """Test Ukrainian 'у YYYY році' pattern."""
        result = self.manager.detect_years_from_query("Що було у 2022 році?")
        assert 2022 in result.years

    def test_detect_ukrainian_v_rotsi(self) -> None:
        """Test Ukrainian 'в YYYY' pattern."""
        result = self.manager.detect_years_from_query("В 2021 ми зробили")
        assert 2021 in result.years

    def test_detect_ukrainian_roku(self) -> None:
        """Test Ukrainian 'YYYY року' pattern."""
        result = self.manager.detect_years_from_query("2020 року було")
        assert 2020 in result.years


class TestRelativeYearPatternsEnglish:
    """Tests for English relative year patterns."""

    def setup_method(self) -> None:
        """Set up test manager."""
        self.manager = TieredMemoryManager(
            memory_manager=MagicMock(),
            archive_manager=MagicMock(),
        )
        self.current = _current_year()

    def test_detect_last_year(self) -> None:
        """Test 'last year' detection."""
        result = self.manager.detect_years_from_query("What did we do last year?")
        assert (self.current - 1) in result.years

    def test_detect_this_year(self) -> None:
        """Test 'this year' detection."""
        result = self.manager.detect_years_from_query("Projects this year")
        assert self.current in result.years

    def test_detect_year_before_last(self) -> None:
        """Test 'year before last' detection."""
        result = self.manager.detect_years_from_query("The year before last")
        assert (self.current - 2) in result.years

    def test_detect_n_years_ago(self) -> None:
        """Test 'N years ago' pattern."""
        result = self.manager.detect_years_from_query("What happened 3 years ago?")
        assert (self.current - 3) in result.years

    def test_detect_1_year_ago(self) -> None:
        """Test '1 year ago' singular form."""
        result = self.manager.detect_years_from_query("Started 1 year ago")
        assert (self.current - 1) in result.years

    def test_detect_past_n_years(self) -> None:
        """Test 'past N years' pattern."""
        result = self.manager.detect_years_from_query("Over the past 3 years")
        expected_years = list(range(self.current - 2, self.current + 1))
        for year in expected_years:
            assert year in result.years


class TestRelativeYearPatternsUkrainian:
    """Tests for Ukrainian relative year patterns."""

    def setup_method(self) -> None:
        """Set up test manager."""
        self.manager = TieredMemoryManager(
            memory_manager=MagicMock(),
            archive_manager=MagicMock(),
        )
        self.current = _current_year()

    def test_detect_mynuloho_roku(self) -> None:
        """Test Ukrainian 'минулого року' (last year)."""
        result = self.manager.detect_years_from_query("Що було минулого року?")
        assert (self.current - 1) in result.years

    def test_detect_mynulyi_rik(self) -> None:
        """Test Ukrainian 'минулий рік' (last year alt)."""
        result = self.manager.detect_years_from_query("Минулий рік був важким")
        assert (self.current - 1) in result.years

    def test_detect_pozamynuloho_roku(self) -> None:
        """Test Ukrainian 'позаминулого року' (year before last)."""
        result = self.manager.detect_years_from_query("Позаминулого року ми почали")
        assert (self.current - 2) in result.years

    def test_detect_tsoho_roku(self) -> None:
        """Test Ukrainian 'цього року' (this year)."""
        result = self.manager.detect_years_from_query("Цього року ми зробимо")
        assert self.current in result.years

    def test_detect_n_rokiv_tomu(self) -> None:
        """Test Ukrainian 'N років тому' (N years ago)."""
        result = self.manager.detect_years_from_query("5 років тому почався проект")
        assert (self.current - 5) in result.years

    def test_detect_ostanni_n_rokiv(self) -> None:
        """Test Ukrainian 'останні N років' (past N years)."""
        # Pattern expects "років" not "роки"
        result = self.manager.detect_years_from_query("За останні 3 років")
        expected_years = list(range(self.current - 2, self.current + 1))
        for year in expected_years:
            assert year in result.years


class TestYearDetectionEdgeCases:
    """Tests for edge cases in year detection."""

    def setup_method(self) -> None:
        """Set up test manager."""
        self.manager = TieredMemoryManager(
            memory_manager=MagicMock(),
            archive_manager=MagicMock(),
        )

    def test_no_years_in_query(self) -> None:
        """Test query with no year references."""
        result = self.manager.detect_years_from_query("Tell me about the project")
        assert len(result.years) == 0
        assert len(result.patterns_matched) == 0

    def test_invalid_year_filtered(self) -> None:
        """Test that years outside 2000-2100 are filtered."""
        result = self.manager.detect_years_from_query("Product code 9999")
        assert 9999 not in result.years

    def test_year_1999_filtered(self) -> None:
        """Test that year 1999 is filtered out."""
        result = self.manager.detect_years_from_query("In 1999 we started")
        assert 1999 not in result.years

    def test_multiple_years_detected(self) -> None:
        """Test detection of multiple years in one query."""
        result = self.manager.detect_years_from_query(
            "Compare 2020, 2021, and 2022 data"
        )
        assert 2020 in result.years
        assert 2021 in result.years
        assert 2022 in result.years
        assert len(result.years) >= 3

    def test_duplicate_years_deduplicated(self) -> None:
        """Test that same year mentioned twice is deduplicated."""
        result = self.manager.detect_years_from_query(
            "In 2022 we started, and in 2022 we finished"
        )
        # Should only have one 2022
        assert result.years.count(2022) == 1

    def test_years_sorted(self) -> None:
        """Test that detected years are sorted."""
        result = self.manager.detect_years_from_query(
            "From 2023 back to 2020 and 2021"
        )
        assert result.years == sorted(result.years)

    def test_patterns_matched_populated(self) -> None:
        """Test that patterns_matched is populated."""
        result = self.manager.detect_years_from_query("What happened in 2022?")
        assert len(result.patterns_matched) > 0

    def test_patterns_matched_not_duplicated(self) -> None:
        """Test that patterns_matched doesn't contain duplicates."""
        result = self.manager.detect_years_from_query(
            "In 2022 and in 2023"
        )
        # Each pattern description should appear only once
        unique_patterns = set(result.patterns_matched)
        assert len(unique_patterns) == len(result.patterns_matched)


class TestYearPatternsCollection:
    """Tests for the global YEAR_PATTERNS collection."""

    def test_has_explicit_year_patterns(self) -> None:
        """Test collection has explicit year patterns."""
        descriptions = [p.description for p in YEAR_PATTERNS]
        has_in_pattern = any("in" in d.lower() for d in descriptions)
        assert has_in_pattern

    def test_has_relative_year_patterns(self) -> None:
        """Test collection has relative year patterns."""
        descriptions = [p.description for p in YEAR_PATTERNS]
        has_last_year = any("last year" in d.lower() or "минулого" in d for d in descriptions)
        assert has_last_year

    def test_has_range_patterns(self) -> None:
        """Test collection has range patterns (past N years)."""
        descriptions = [p.description for p in YEAR_PATTERNS]
        has_range = any("past" in d.lower() or "останні" in d for d in descriptions)
        assert has_range

    def test_patterns_count(self) -> None:
        """Test there are sufficient patterns."""
        assert len(YEAR_PATTERNS) >= 10, "Should have at least 10 patterns"

    def test_all_patterns_have_descriptions(self) -> None:
        """Test all patterns have non-empty descriptions."""
        for pattern in YEAR_PATTERNS:
            assert pattern.description is not None
            assert len(pattern.description) > 0
