"""Tests for DigitalValeriiAgent.

This module contains tests for the main agent class
that wraps Claude Agent SDK.
"""

from collections.abc import AsyncIterator
from unittest.mock import AsyncMock, MagicMock

import pytest
from digital_valerii_shared.agent.core import (
    AgentError,
    AgentMessage,
    AgentStatus,
    ConversationContext,
    DigitalValeriiAgent,
    InterfaceType,
)
from digital_valerii_shared.agent.personality import PersonalityManager


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    manager = MagicMock()
    manager.recall = AsyncMock(return_value=[])
    manager.store = AsyncMock(return_value=None)
    return manager


@pytest.fixture
def personality_manager() -> PersonalityManager:
    """Create a PersonalityManager instance."""
    return PersonalityManager()


async def mock_query_function(
    _prompt: str, _options: dict
) -> AsyncIterator[AgentMessage]:
    """Mock query function for testing."""
    yield AgentMessage(type="text", content="Test response")
    yield AgentMessage(
        type="session",
        content="",
        metadata={"session_id": "test-session-123", "tokens_used": 100},
    )


@pytest.fixture
def agent(personality_manager: PersonalityManager) -> DigitalValeriiAgent:
    """Create an agent without memory."""
    return DigitalValeriiAgent(
        personality_manager=personality_manager,
        query_function=mock_query_function,
    )


@pytest.fixture
def agent_with_memory(
    personality_manager: PersonalityManager,
    mock_memory_manager: MagicMock,
) -> DigitalValeriiAgent:
    """Create an agent with memory."""
    return DigitalValeriiAgent(
        personality_manager=personality_manager,
        memory_manager=mock_memory_manager,
        query_function=mock_query_function,
    )


class TestDigitalValeriiAgentInit:
    """Tests for agent initialization."""

    def test_init_minimal(self) -> None:
        """Test minimal initialization."""
        agent = DigitalValeriiAgent()
        assert agent.personality is not None
        assert agent.memory is None
        assert agent.get_session_id() is None

    def test_init_with_personality(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test initialization with personality manager."""
        agent = DigitalValeriiAgent(personality_manager=personality_manager)
        assert agent.personality == personality_manager

    def test_init_with_memory(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test initialization with memory manager."""
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
        )
        assert agent.memory == mock_memory_manager

    def test_init_creates_options_builder(self, agent: DigitalValeriiAgent) -> None:
        """Test that options builder is created."""
        assert agent.options_builder is not None


class TestSessionManagement:
    """Tests for session management."""

    def test_get_session_id_initial(self, agent: DigitalValeriiAgent) -> None:
        """Test initial session ID is None."""
        assert agent.get_session_id() is None

    def test_resume_session(self, agent: DigitalValeriiAgent) -> None:
        """Test resuming a session."""
        agent.resume_session("session-abc")
        assert agent.get_session_id() == "session-abc"

    def test_clear_session(self, agent: DigitalValeriiAgent) -> None:
        """Test clearing a session."""
        agent.resume_session("session-xyz")
        agent.clear_session()
        assert agent.get_session_id() is None


class TestChat:
    """Tests for chat method."""

    @pytest.mark.asyncio
    async def test_chat_returns_response(self, agent: DigitalValeriiAgent) -> None:
        """Test that chat returns an AgentResponse."""
        context = ConversationContext()

        response = await agent.chat("Hello", context)

        assert response.status == AgentStatus.COMPLETE
        assert response.message == "Test response"
        assert response.session_id == "test-session-123"

    @pytest.mark.asyncio
    async def test_chat_updates_session(self, agent: DigitalValeriiAgent) -> None:
        """Test that chat updates session ID."""
        context = ConversationContext()

        await agent.chat("Hello", context)

        assert agent.get_session_id() == "test-session-123"
        assert context.session_id == "test-session-123"

    @pytest.mark.asyncio
    async def test_chat_with_memory_enables_hooks(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that chat with memory enables hooks."""
        context = ConversationContext()

        await agent_with_memory.chat("Hello", context)

        # When memory is provided, hooks are enabled
        assert agent_with_memory._memory_hooks is not None

    @pytest.mark.asyncio
    async def test_chat_with_memory_sets_hooks_context(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that chat sets hooks context."""
        context = ConversationContext(interface=InterfaceType.API)

        await agent_with_memory.chat("Hello", context)

        # Hooks context should be set
        assert agent_with_memory._memory_hooks is not None
        assert agent_with_memory._memory_hooks._interface == "api"

    @pytest.mark.asyncio
    async def test_chat_with_custom_tools(self, agent: DigitalValeriiAgent) -> None:
        """Test chat with custom tools."""
        context = ConversationContext()

        response = await agent.chat("Hello", context, allowed_tools=["Read"])

        assert response.status == AgentStatus.COMPLETE

    @pytest.mark.asyncio
    async def test_chat_with_session_resume(self, agent: DigitalValeriiAgent) -> None:
        """Test chat with session resume from context."""
        context = ConversationContext(session_id="existing-session")

        await agent.chat("Hello", context)

        # Session should be updated from context
        assert agent.get_session_id() is not None


class TestChatStream:
    """Tests for chat_stream method."""

    @pytest.mark.asyncio
    async def test_chat_stream_yields_messages(
        self, agent: DigitalValeriiAgent
    ) -> None:
        """Test that chat_stream yields messages."""
        context = ConversationContext()
        messages = []

        async for msg in agent.chat_stream("Hello", context):
            messages.append(msg)

        assert len(messages) >= 1
        assert any(msg.type == "text" for msg in messages)

    @pytest.mark.asyncio
    async def test_chat_stream_updates_session(
        self, agent: DigitalValeriiAgent
    ) -> None:
        """Test that chat_stream updates session."""
        context = ConversationContext()

        async for _ in agent.chat_stream("Hello", context):
            pass

        assert agent.get_session_id() == "test-session-123"

    @pytest.mark.asyncio
    async def test_chat_stream_with_memory_enables_hooks(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that chat_stream with memory enables hooks."""
        context = ConversationContext()

        async for _ in agent_with_memory.chat_stream("Hello", context):
            pass

        # When memory is provided, hooks are enabled
        assert agent_with_memory._memory_hooks is not None


class TestMemoryIntegration:
    """Tests for memory integration."""

    @pytest.mark.asyncio
    async def test_memory_hooks_enabled_when_memory_provided(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that memory hooks are enabled when memory manager is provided."""
        # Hooks should be initialized
        assert agent_with_memory._memory_hooks is not None
        assert agent_with_memory.memory is not None

    @pytest.mark.asyncio
    async def test_memory_hooks_context_set_for_recall(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that hooks context is set for memory recall."""
        context = ConversationContext()

        await agent_with_memory.chat("Hello", context)

        # Hooks context should be set for recall/store
        assert agent_with_memory._memory_hooks is not None
        assert agent_with_memory._memory_hooks._conversation_id == str(
            context.conversation_id
        )

    @pytest.mark.asyncio
    async def test_chat_completes_with_memory(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that chat completes when memory is enabled."""
        context = ConversationContext()

        response = await agent_with_memory.chat("Hello", context)

        assert response.status == AgentStatus.COMPLETE

    @pytest.mark.asyncio
    async def test_chat_stream_completes_with_memory(
        self,
        agent_with_memory: DigitalValeriiAgent,
    ) -> None:
        """Test that chat_stream completes when memory is enabled."""
        context = ConversationContext()
        messages = []

        async for msg in agent_with_memory.chat_stream("Hello", context):
            messages.append(msg)

        assert len(messages) >= 1


class TestNoDuplicateMemoryOps:
    """Tests for no duplicate memory operations when hooks are enabled."""

    @pytest.mark.asyncio
    async def test_chat_no_recall_when_hooks_enabled(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that chat does not call recall when hooks are enabled."""
        # Agent with memory (has hooks)
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
            query_function=mock_query_function,
        )

        # Hooks are enabled because memory_manager is set
        assert agent._memory_hooks is not None

        context = ConversationContext()
        await agent.chat("Hello", context)

        # Direct recall should NOT be called (hooks handle it)
        mock_memory_manager.recall.assert_not_called()

    @pytest.mark.asyncio
    async def test_chat_no_store_when_hooks_enabled(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that chat does not call store when hooks are enabled."""
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
            query_function=mock_query_function,
        )

        context = ConversationContext()
        await agent.chat("Hello", context)

        # Direct store should NOT be called (hooks handle it)
        mock_memory_manager.store.assert_not_called()

    @pytest.mark.asyncio
    async def test_chat_stream_no_recall_when_hooks_enabled(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that chat_stream does not call recall when hooks are enabled."""
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
            query_function=mock_query_function,
        )

        context = ConversationContext()
        async for _ in agent.chat_stream("Hello", context):
            pass

        # Direct recall should NOT be called
        mock_memory_manager.recall.assert_not_called()

    @pytest.mark.asyncio
    async def test_chat_stream_no_store_when_hooks_enabled(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that chat_stream does not call store when hooks are enabled."""
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
            query_function=mock_query_function,
        )

        context = ConversationContext()
        async for _ in agent.chat_stream("Hello", context):
            pass

        # Direct store should NOT be called
        mock_memory_manager.store.assert_not_called()

    @pytest.mark.asyncio
    async def test_hooks_context_set_on_chat(
        self,
        personality_manager: PersonalityManager,
        mock_memory_manager: MagicMock,
    ) -> None:
        """Test that hooks context is set on chat."""
        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            memory_manager=mock_memory_manager,
            query_function=mock_query_function,
        )

        context = ConversationContext(interface=InterfaceType.SLACK)
        await agent.chat("Hello", context)

        # Verify hooks have context set
        assert agent._memory_hooks is not None
        assert agent._memory_hooks._conversation_id == str(context.conversation_id)
        assert agent._memory_hooks._interface == "slack"


class TestErrorHandling:
    """Tests for error handling."""

    @pytest.mark.asyncio
    async def test_chat_raises_agent_error(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that chat raises AgentError on failure."""

        async def failing_query(
            _prompt: str, _options: dict
        ) -> AsyncIterator[AgentMessage]:
            raise RuntimeError("Query failed")
            # Make it an async generator
            yield  # pragma: no cover

        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            query_function=failing_query,
        )
        context = ConversationContext()

        with pytest.raises(AgentError):
            await agent.chat("Hello", context)

    @pytest.mark.asyncio
    async def test_chat_stream_yields_error_on_failure(
        self, personality_manager: PersonalityManager
    ) -> None:
        """Test that chat_stream yields error message on failure."""

        async def failing_query(
            _prompt: str, _options: dict
        ) -> AsyncIterator[AgentMessage]:
            raise RuntimeError("Stream failed")
            yield  # pragma: no cover

        agent = DigitalValeriiAgent(
            personality_manager=personality_manager,
            query_function=failing_query,
        )
        context = ConversationContext()

        messages = []
        async for msg in agent.chat_stream("Hello", context):
            messages.append(msg)

        assert any(msg.type == "error" for msg in messages)


class TestInterfaceHandling:
    """Tests for different interface types."""

    @pytest.mark.asyncio
    async def test_chat_with_slack_interface(self, agent: DigitalValeriiAgent) -> None:
        """Test chat with Slack interface."""
        context = ConversationContext(interface=InterfaceType.SLACK)

        response = await agent.chat("Hey", context)

        assert response.status == AgentStatus.COMPLETE

    @pytest.mark.asyncio
    async def test_chat_with_api_interface(self, agent: DigitalValeriiAgent) -> None:
        """Test chat with API interface."""
        context = ConversationContext(interface=InterfaceType.API)

        response = await agent.chat("Query", context)

        assert response.status == AgentStatus.COMPLETE

    @pytest.mark.asyncio
    async def test_chat_with_meeting_interface(
        self, agent: DigitalValeriiAgent
    ) -> None:
        """Test chat with meeting interface."""
        context = ConversationContext(interface=InterfaceType.MEETING)

        response = await agent.chat("Summary", context)

        assert response.status == AgentStatus.COMPLETE
