"""Tests for AgentTracer.

Component 6.5: AgentOps Framework
"""

import asyncio
from collections.abc import Generator
from uuid import uuid4

import pytest
from digital_valerii_shared.agentops.models import (
    AgentTrace,
    TraceEvent,
    TraceEventType,
)
from digital_valerii_shared.agentops.sanitizer import TraceSanitizer
from digital_valerii_shared.agentops.tracer import (
    AgentTracer,
    _current_trace,
)


class MockTraceStore:
    """Mock trace store for testing."""

    def __init__(self) -> None:
        self.traces: dict[str, AgentTrace] = {}
        self.save_called = False

    async def save(self, trace: AgentTrace) -> None:
        self.traces[str(trace.id)] = trace
        self.save_called = True

    async def get(self, trace_id) -> AgentTrace | None:
        return self.traces.get(str(trace_id))

    async def list_by_session(self, session_id, limit: int = 100) -> list[AgentTrace]:
        return [t for t in self.traces.values() if t.session_id == session_id][:limit]


class TestAgentTracer:
    """Tests for AgentTracer."""

    @pytest.fixture
    def store(self) -> MockTraceStore:
        """Create mock store."""
        return MockTraceStore()

    @pytest.fixture
    def tracer(self, store: MockTraceStore) -> AgentTracer:
        """Create tracer with mock store."""
        return AgentTracer(store=store)

    @pytest.fixture(autouse=True)
    def clear_context(self) -> Generator[None, None, None]:
        """Clear context before each test."""
        _current_trace.set(None)
        yield
        _current_trace.set(None)

    def test_start_trace_creates_trace(self, tracer: AgentTracer) -> None:
        """Test start_trace creates trace in context."""
        session_id = uuid4()
        user_id = uuid4()

        trace = tracer.start_trace(session_id=session_id, user_id=user_id)

        assert trace.session_id == session_id
        assert trace.user_id == user_id
        assert tracer.get_current_trace() == trace

    def test_start_trace_sets_context(self, tracer: AgentTracer) -> None:
        """Test start_trace sets the context variable."""
        session_id = uuid4()

        tracer.start_trace(session_id=session_id)

        assert _current_trace.get() is not None

    def test_get_current_trace_returns_none_initially(
        self, tracer: AgentTracer
    ) -> None:
        """Test get_current_trace returns None without active trace."""
        assert tracer.get_current_trace() is None

    def test_add_event_adds_to_trace(self, tracer: AgentTracer) -> None:
        """Test add_event adds event to current trace."""
        session_id = uuid4()
        tracer.start_trace(session_id=session_id)

        event = tracer.add_event(
            event_type=TraceEventType.TOOL_CALL,
            data={"tool": "search", "query": "test"},
            duration_ms=150,
        )

        trace = tracer.get_current_trace()
        assert trace is not None
        assert len(trace.events) == 1
        assert trace.events[0] == event
        assert event.event_type == TraceEventType.TOOL_CALL
        assert event.duration_ms == 150

    def test_add_event_sanitizes_data(self, tracer: AgentTracer) -> None:
        """Test add_event sanitizes PII from data."""
        session_id = uuid4()
        tracer.start_trace(session_id=session_id)

        event = tracer.add_event(
            event_type=TraceEventType.PROMPT_RECEIVED,
            data={"email": "user@example.com", "query": "help me"},
        )

        assert event.data["email"] == "[EMAIL]"
        assert event.data["query"] == "help me"

    def test_add_event_raises_without_trace(self, tracer: AgentTracer) -> None:
        """Test add_event raises RuntimeError without active trace."""
        with pytest.raises(RuntimeError) as exc_info:
            tracer.add_event(
                event_type=TraceEventType.ERROR,
                data={"error": "something went wrong"},
            )

        assert "No active trace" in str(exc_info.value)

    def test_add_event_with_parent(self, tracer: AgentTracer) -> None:
        """Test add_event with parent event ID."""
        session_id = uuid4()
        tracer.start_trace(session_id=session_id)

        parent_event = tracer.add_event(
            event_type=TraceEventType.TOOL_CALL,
            data={"tool": "search"},
        )

        child_event = tracer.add_event(
            event_type=TraceEventType.TOOL_RESULT,
            data={"result": "found"},
            parent_event_id=parent_event.id,
        )

        assert child_event.parent_event_id == parent_event.id

    @pytest.mark.asyncio
    async def test_complete_trace_sets_outcome(
        self, tracer: AgentTracer, store: MockTraceStore
    ) -> None:
        """Test complete_trace sets outcome and timestamp."""
        session_id = uuid4()
        trace = tracer.start_trace(session_id=session_id)

        await tracer.complete_trace(outcome="success", total_tokens=500)

        # Wait briefly for background task
        await asyncio.sleep(0.01)

        # Check trace was saved
        assert store.save_called
        saved_trace = await store.get(trace.id)
        assert saved_trace is not None
        assert saved_trace.outcome == "success"
        assert saved_trace.completed_at is not None
        assert saved_trace.total_tokens == 500

    @pytest.mark.asyncio
    async def test_complete_trace_clears_context(self, tracer: AgentTracer) -> None:
        """Test complete_trace clears the context."""
        session_id = uuid4()
        tracer.start_trace(session_id=session_id)

        await tracer.complete_trace(outcome="success")

        assert tracer.get_current_trace() is None

    @pytest.mark.asyncio
    async def test_complete_trace_with_cost(
        self, tracer: AgentTracer, store: MockTraceStore
    ) -> None:
        """Test complete_trace records cost."""
        session_id = uuid4()
        trace = tracer.start_trace(session_id=session_id)

        await tracer.complete_trace(
            outcome="success",
            total_tokens=1000,
            total_cost_usd=0.025,
        )
        await asyncio.sleep(0.01)

        saved_trace = await store.get(trace.id)
        assert saved_trace is not None
        assert saved_trace.total_cost_usd == 0.025

    @pytest.mark.asyncio
    async def test_complete_trace_does_nothing_without_trace(
        self, tracer: AgentTracer
    ) -> None:
        """Test complete_trace is safe without active trace."""
        # Should not raise
        await tracer.complete_trace(outcome="success")

    def test_clear_trace_removes_context(self, tracer: AgentTracer) -> None:
        """Test clear_trace removes trace from context."""
        session_id = uuid4()
        tracer.start_trace(session_id=session_id)

        tracer.clear_trace()

        assert tracer.get_current_trace() is None

    @pytest.mark.asyncio
    async def test_contextvar_isolation_between_tasks(
        self, store: MockTraceStore
    ) -> None:
        """Test ContextVar isolation between concurrent tasks."""
        tracer = AgentTracer(store=store)
        traces_seen: dict[str, list[str]] = {"task1": [], "task2": []}

        async def task1() -> None:
            session_id = uuid4()
            trace = tracer.start_trace(session_id=session_id)
            traces_seen["task1"].append(str(trace.id))
            await asyncio.sleep(0.01)
            current = tracer.get_current_trace()
            if current:
                traces_seen["task1"].append(str(current.id))

        async def task2() -> None:
            session_id = uuid4()
            trace = tracer.start_trace(session_id=session_id)
            traces_seen["task2"].append(str(trace.id))
            await asyncio.sleep(0.01)
            current = tracer.get_current_trace()
            if current:
                traces_seen["task2"].append(str(current.id))

        await asyncio.gather(task1(), task2())

        # Each task should see only its own trace
        assert len(traces_seen["task1"]) == 2
        assert len(traces_seen["task2"]) == 2
        assert traces_seen["task1"][0] == traces_seen["task1"][1]
        assert traces_seen["task2"][0] == traces_seen["task2"][1]
        assert traces_seen["task1"][0] != traces_seen["task2"][0]

    def test_custom_sanitizer(self, store: MockTraceStore) -> None:
        """Test tracer accepts custom sanitizer."""
        custom_patterns = [(r"CUSTOM-\d+", "[CUSTOM]")]
        sanitizer = TraceSanitizer(additional_patterns=custom_patterns)
        tracer = AgentTracer(store=store, sanitizer=sanitizer)

        tracer.start_trace(session_id=uuid4())
        event = tracer.add_event(
            event_type=TraceEventType.PROMPT_RECEIVED,
            data={"id": "CUSTOM-12345"},
        )

        assert event.data["id"] == "[CUSTOM]"

    # ==========================================================================
    # FIX-6.5.2: Trace snapshot and error handling tests
    # ==========================================================================

    @pytest.mark.asyncio
    async def test_complete_trace_snapshots_before_save(
        self, store: MockTraceStore
    ) -> None:
        """Test complete_trace creates a snapshot to avoid race conditions."""
        tracer = AgentTracer(store=store)
        session_id = uuid4()

        trace = tracer.start_trace(session_id=session_id)
        trace_id = trace.id

        tracer.add_event(
            event_type=TraceEventType.TOOL_CALL,
            data={"tool": "search"},
        )

        # Complete the trace
        await tracer.complete_trace(outcome="success", total_tokens=100)

        # Wait for save to complete
        await asyncio.sleep(0.01)

        # Verify trace was saved
        saved_trace = await store.get(trace_id)
        assert saved_trace is not None
        assert saved_trace.outcome == "success"
        assert saved_trace.total_tokens == 100
        assert len(saved_trace.events) == 1

        # Verify current context is cleared before save
        assert tracer.get_current_trace() is None

    @pytest.mark.asyncio
    async def test_save_trace_logs_errors(self, caplog) -> None:
        """Test _save_trace logs errors without raising."""

        class FailingStore:
            """Store that always fails."""

            async def save(self, trace: AgentTrace) -> None:
                raise RuntimeError("Simulated save failure")

            async def get(self, trace_id) -> AgentTrace | None:
                return None

            async def list_by_session(
                self, session_id, limit: int = 100
            ) -> list[AgentTrace]:
                return []

        tracer = AgentTracer(store=FailingStore())
        session_id = uuid4()

        tracer.start_trace(session_id=session_id)
        tracer.add_event(
            event_type=TraceEventType.PROMPT_RECEIVED,
            data={"query": "test"},
        )

        # This should not raise even though save fails
        await tracer.complete_trace(outcome="success")

        # Wait for the background task
        await asyncio.sleep(0.02)

        # Verify error was logged (checking caplog)
        assert any(
            "Failed to save trace" in record.message for record in caplog.records
        )

    @pytest.mark.asyncio
    async def test_snapshot_prevents_mutation_after_complete(
        self, store: MockTraceStore
    ) -> None:
        """Test that mutations after complete_trace don't affect saved trace."""
        tracer = AgentTracer(store=store)
        session_id = uuid4()

        trace = tracer.start_trace(session_id=session_id)
        trace_id = trace.id

        tracer.add_event(
            event_type=TraceEventType.TOOL_CALL,
            data={"tool": "original"},
        )

        # Complete the trace
        await tracer.complete_trace(outcome="success", total_tokens=50)

        # Try to mutate the original trace after completion
        # (This simulates a race condition where concurrent code modifies the trace)
        trace.total_tokens = 999
        trace.events.append(
            TraceEvent(
                trace_id=trace_id,
                event_type=TraceEventType.ERROR,
                data={"error": "late addition"},
            )
        )

        # Wait for save to complete
        await asyncio.sleep(0.01)

        # Verify saved trace was NOT affected by post-complete mutations
        saved_trace = await store.get(trace_id)
        assert saved_trace is not None
        assert saved_trace.total_tokens == 50  # Original value, not 999
        assert len(saved_trace.events) == 1  # Original event count
