"""Tests for PersonalityManager.

This module contains comprehensive tests for the PersonalityManager class,
covering initialization, prompt building, mode handling, and caching.
"""

from pathlib import Path

from digital_valerii_shared.agent.personality import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    PersonalityManager,
    PersonalityPrompt,
    PersonalitySection,
    PersonReference,
    ProjectReference,
)


class TestPersonalityManagerInit:
    """Tests for PersonalityManager initialization."""

    def test_init_default_content_dir(self) -> None:
        """Test initialization with default content directory."""
        manager = PersonalityManager()
        assert manager.loader is not None
        assert manager.builder is not None

    def test_init_custom_content_dir(self, tmp_path: Path) -> None:
        """Test initialization with custom content directory."""
        manager = PersonalityManager(content_dir=tmp_path)
        assert manager.loader.content_dir == tmp_path

    def test_loader_property(self) -> None:
        """Test that loader property returns PersonalityLoader."""
        manager = PersonalityManager()
        from digital_valerii_shared.agent.personality.loader import PersonalityLoader

        assert isinstance(manager.loader, PersonalityLoader)

    def test_builder_property(self) -> None:
        """Test that builder property returns PromptBuilder."""
        manager = PersonalityManager()
        from digital_valerii_shared.agent.personality.prompts import PromptBuilder

        assert isinstance(manager.builder, PromptBuilder)


class TestPersonalityManagerPreload:
    """Tests for preloading functionality."""

    def test_preload_loads_all_sections(self) -> None:
        """Test that preload loads all sections into cache."""
        manager = PersonalityManager()
        manager.preload()

        # Check all sections are cached
        for section in PersonalitySection:
            assert manager.loader.is_cached(section)

    def test_preload_idempotent(self) -> None:
        """Test that calling preload multiple times is safe."""
        manager = PersonalityManager()
        manager.preload()
        manager.preload()  # Should not raise

        for section in PersonalitySection:
            assert manager.loader.is_cached(section)


class TestPersonalityManagerBuildPrompt:
    """Tests for build_system_prompt method."""

    def test_build_system_prompt_default(self) -> None:
        """Test building system prompt with defaults."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt()

        assert isinstance(prompt, PersonalityPrompt)
        assert prompt.content
        assert prompt.mode == ConversationMode.CONSULTING
        assert prompt.language == LanguageMode.AUTO
        assert prompt.estimated_tokens > 0

    def test_build_system_prompt_assessment_mode(self) -> None:
        """Test building prompt for assessment mode."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(mode=ConversationMode.ASSESSMENT)

        assert prompt.mode == ConversationMode.ASSESSMENT
        assert "ASSESSMENT" in prompt.content

    def test_build_system_prompt_casual_mode(self) -> None:
        """Test building prompt for casual mode."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(mode=ConversationMode.CASUAL)

        assert prompt.mode == ConversationMode.CASUAL
        assert "CASUAL" in prompt.content

    def test_build_system_prompt_with_language(self) -> None:
        """Test building prompt with specific language."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(language=LanguageMode.ENGLISH)

        assert prompt.language == LanguageMode.ENGLISH

    def test_build_system_prompt_with_context(self) -> None:
        """Test building prompt with dynamic context."""
        manager = PersonalityManager()
        context = DynamicContext(
            projects=(ProjectReference(name="Test Project", client="Test Client"),),
            people=(PersonReference(name="John Doe", relation="colleague"),),
        )
        prompt = manager.build_system_prompt(context=context)

        assert prompt.context_injected is True

    def test_build_system_prompt_limited_sections(self) -> None:
        """Test building prompt with limited sections."""
        manager = PersonalityManager()
        sections = (PersonalitySection.BASE, PersonalitySection.COMMUNICATION)
        prompt = manager.build_system_prompt(sections=sections)

        assert PersonalitySection.BASE in prompt.sections_included
        assert PersonalitySection.COMMUNICATION in prompt.sections_included
        assert PersonalitySection.KNOWLEDGE not in prompt.sections_included

    def test_build_system_prompt_exclude_examples(self) -> None:
        """Test building prompt without examples."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(include_examples=False)

        assert PersonalitySection.EXAMPLES not in prompt.sections_included

    def test_build_system_prompt_without_mode_instructions(self) -> None:
        """Test building prompt without mode instructions."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(include_mode_instructions=False)

        assert "Current Mode:" not in prompt.content

    def test_build_system_prompt_max_tokens(self) -> None:
        """Test that prompt respects max_tokens limit."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(max_tokens=1000)

        # Should not exceed the limit
        assert prompt.estimated_tokens <= 1000


class TestPersonalityManagerConvenienceMethods:
    """Tests for convenience prompt building methods."""

    def test_build_assessment_prompt(self) -> None:
        """Test building assessment prompt."""
        manager = PersonalityManager()
        prompt = manager.build_assessment_prompt()

        assert prompt.mode == ConversationMode.ASSESSMENT
        assert prompt.language == LanguageMode.ENGLISH

    def test_build_casual_prompt(self) -> None:
        """Test building casual prompt."""
        manager = PersonalityManager()
        prompt = manager.build_casual_prompt()

        assert prompt.mode == ConversationMode.CASUAL
        # Should have fewer sections than full prompt
        assert len(prompt.sections_included) <= 3

    def test_build_technical_prompt(self) -> None:
        """Test building technical prompt."""
        manager = PersonalityManager()
        prompt = manager.build_technical_prompt()

        assert prompt.mode == ConversationMode.TECHNICAL
        assert PersonalitySection.KNOWLEDGE in prompt.sections_included


class TestPersonalityManagerValidation:
    """Tests for validation functionality."""

    def test_validate_returns_tuple(self) -> None:
        """Test that validate returns proper tuple."""
        manager = PersonalityManager()
        result = manager.validate()

        assert isinstance(result, tuple)
        assert len(result) == 2
        assert isinstance(result[0], bool)
        assert isinstance(result[1], list)

    def test_validate_with_valid_content(self) -> None:
        """Test validation with valid content directory."""
        manager = PersonalityManager()
        is_valid, missing = manager.validate()

        # With bundled content, should be valid
        assert is_valid is True
        assert len(missing) == 0

    def test_validate_with_missing_content(self, tmp_path: Path) -> None:
        """Test validation with missing content files."""
        manager = PersonalityManager(content_dir=tmp_path)
        is_valid, missing = manager.validate()

        assert is_valid is False
        assert len(missing) == 5  # All 5 content files missing


class TestPersonalityManagerCaching:
    """Tests for caching functionality."""

    def test_clear_cache(self) -> None:
        """Test clearing the cache."""
        manager = PersonalityManager()
        manager.preload()
        manager.clear_cache()

        # After clear, preloaded should be False
        stats = manager.get_stats()
        assert stats["preloaded"] is False

    def test_get_section_content(self) -> None:
        """Test getting raw section content."""
        manager = PersonalityManager()
        content = manager.get_section_content(PersonalitySection.BASE)

        assert content
        assert "Digital Valerii" in content


class TestPersonalityManagerStats:
    """Tests for statistics functionality."""

    def test_get_stats_structure(self) -> None:
        """Test that get_stats returns proper structure."""
        manager = PersonalityManager()
        stats = manager.get_stats()

        assert "available_sections" in stats
        assert "total_sections" in stats
        assert "is_valid" in stats
        assert "missing_files" in stats
        assert "preloaded" in stats

    def test_get_stats_values(self) -> None:
        """Test that get_stats returns correct values."""
        manager = PersonalityManager()
        stats = manager.get_stats()

        assert stats["total_sections"] == 5
        assert stats["available_sections"] == 5
        assert stats["is_valid"] is True
        assert stats["missing_files"] == 0

    def test_get_stats_after_preload(self) -> None:
        """Test stats after preloading."""
        manager = PersonalityManager()
        manager.preload()
        stats = manager.get_stats()

        assert stats["preloaded"] is True


class TestPlaceholderInjection:
    """Tests for placeholder presence and injection."""

    def test_content_files_contain_placeholders(self) -> None:
        """Test that at least one content file contains placeholders."""
        manager = PersonalityManager()
        manager.preload()

        # Check that at least one section has placeholders
        has_placeholder = False
        for section in PersonalitySection:
            content = manager.get_section_content(section)
            if "{{" in content:
                has_placeholder = True
                break

        assert has_placeholder, "No content files contain {{...}} placeholders"

    def test_placeholders_replaced_with_context(self) -> None:
        """Test that placeholders are replaced when context is provided."""
        manager = PersonalityManager()
        context = DynamicContext(
            projects=(ProjectReference(name="Test Assessment", client="ACME Corp"),),
            people=(PersonReference(name="Alice", relation="CISO"),),
        )
        prompt = manager.build_system_prompt(context=context)

        # The placeholders should be replaced with actual values
        assert "{{projects}}" not in prompt.content
        assert "{{people}}" not in prompt.content
        # And the actual values should be present
        assert "Test Assessment" in prompt.content or "ACME" in prompt.content

    def test_custom_context_placeholder_injected(self) -> None:
        """Test that custom_context placeholder is replaced."""
        manager = PersonalityManager()
        context = DynamicContext(
            custom_context="This is a special audit for regulatory compliance."
        )
        prompt = manager.build_system_prompt(context=context)

        assert "{{custom_context}}" not in prompt.content
        assert "regulatory compliance" in prompt.content


class TestTokenBudgetWithModeInstructions:
    """Tests for token budget enforcement after mode instructions."""

    def test_prompt_respects_budget_after_mode_instructions(self) -> None:
        """Test that final prompt respects max_tokens even with mode instructions."""
        manager = PersonalityManager()
        # Use minimum allowed token budget (500) - content + mode instructions
        # should still respect this budget
        prompt = manager.build_system_prompt(
            mode=ConversationMode.ASSESSMENT,
            max_tokens=500,
            include_mode_instructions=True,
        )

        # Should not exceed the budget
        assert prompt.estimated_tokens <= 500

    def test_prompt_truncated_shows_indicator(self) -> None:
        """Test that truncated prompts show truncation indicator."""
        manager = PersonalityManager()
        # Use minimum budget - with full content this will cause truncation
        prompt = manager.build_system_prompt(
            max_tokens=500,  # Minimum allowed, will force truncation
            include_mode_instructions=True,
        )

        # Content should be truncated (full content + mode is > 500 tokens)
        assert prompt.estimated_tokens <= 500
        assert "[Content truncated" in prompt.content

    def test_large_budget_not_truncated(self) -> None:
        """Test that prompts with large budget are not truncated."""
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(
            max_tokens=16000,  # Large budget
            include_mode_instructions=True,
        )

        # Should not be truncated
        assert "[Content truncated" not in prompt.content
