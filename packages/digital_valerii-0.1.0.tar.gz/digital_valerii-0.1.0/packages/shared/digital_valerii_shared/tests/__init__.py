"""Tests for digital_valerii_shared package."""
