"""Tests for License Guard.

Component 4.10: Licensing & Protection System
"""

import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from digital_valerii_shared.licensing.cache import LicenseCache
from digital_valerii_shared.licensing.client import LicenseClient
from digital_valerii_shared.licensing.exceptions import LicenseError
from digital_valerii_shared.licensing.guard import LicenseGuard
from digital_valerii_shared.licensing.models import (
    LicenseResponse,
    LicenseStatus,
)

# ============================================================================
# LicenseCache Tests
# ============================================================================


class TestLicenseCache:
    """Tests for LicenseCache."""

    @pytest.fixture
    def temp_cache_dir(self):
        """Create temporary cache directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def cache(self, temp_cache_dir):
        """Create cache instance."""
        return LicenseCache("test-client", cache_dir=temp_cache_dir)

    def test_empty_cache_returns_none(self, cache):
        """Test empty cache returns None."""
        assert cache.get() is None

    def test_set_and_get_license(self, cache):
        """Test setting and getting license."""
        response = LicenseResponse(
            valid=True,
            expires=datetime.now(UTC) + timedelta(days=30),
            features=["basic", "api"],
            tier="professional",
        )
        cache.set(response)

        cached = cache.get()
        assert cached is not None
        assert cached.valid is True
        assert cached.tier == "professional"

    def test_cache_persists_to_disk(self, cache, temp_cache_dir):
        """Test cache persists to disk."""
        response = LicenseResponse(valid=True, tier="starter")
        cache.set(response)

        # Create new cache instance
        new_cache = LicenseCache("test-client", cache_dir=temp_cache_dir)
        cached = new_cache.get()

        assert cached is not None
        assert cached.valid is True

    def test_cache_clear(self, cache):
        """Test clearing cache."""
        response = LicenseResponse(valid=True)
        cache.set(response)
        assert cache.get() is not None

        cache.clear()
        assert cache.get() is None

    def test_unreachable_counter(self, cache):
        """Test server unreachable counter."""
        response = LicenseResponse(valid=True)
        cache.set(response)

        assert not cache.should_require_fresh()

        cache.increment_unreachable()
        cache.increment_unreachable()
        cache.increment_unreachable()

        assert cache.should_require_fresh()

    def test_reset_unreachable(self, cache):
        """Test resetting unreachable counter."""
        response = LicenseResponse(valid=True)
        cache.set(response)

        cache.increment_unreachable()
        cache.increment_unreachable()
        cache.increment_unreachable()
        assert cache.should_require_fresh()

        cache.reset_unreachable()
        assert not cache.should_require_fresh()


# ============================================================================
# LicenseGuard Tests
# ============================================================================


class TestLicenseGuard:
    """Tests for LicenseGuard."""

    @pytest.fixture
    def temp_cache_dir(self):
        """Create temporary cache directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def guard(self, temp_cache_dir):
        """Create guard instance with mocked cache."""
        guard = LicenseGuard(
            agent_id="test-agent-001",
            client_id="test-client-001",
            server_url="http://localhost:8000",
        )
        guard._cache = LicenseCache("test-client-001", cache_dir=temp_cache_dir)
        return guard

    @pytest.mark.asyncio
    async def test_validate_success(self, guard):
        """Test successful validation."""
        mock_response = LicenseResponse(
            valid=True,
            expires=datetime.now(UTC) + timedelta(days=30),
            tier="professional",
            features=["basic", "api"],
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            result = await guard.validate()

        assert result is True
        assert guard.get_tier() == "professional"
        assert "basic" in guard.get_features()

    @pytest.mark.asyncio
    async def test_validate_invalid_license(self, guard):
        """Test validation with invalid license."""
        mock_response = LicenseResponse(
            valid=False,
            message="License not found",
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            result = await guard.validate()

        assert result is False

    @pytest.mark.asyncio
    async def test_validate_uses_cache(self, guard):
        """Test validation uses cache on second call."""
        mock_response = LicenseResponse(
            valid=True,
            tier="starter",
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response

            # First call hits server
            await guard.validate()
            assert mock.call_count == 1

            # Second call uses cache
            await guard.validate()
            assert mock.call_count == 1  # Still 1

    @pytest.mark.asyncio
    async def test_before_ai_call_success(self, guard):
        """Test before_ai_call with valid license."""
        mock_response = LicenseResponse(valid=True)

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            # Should not raise
            await guard.before_ai_call()

    @pytest.mark.asyncio
    async def test_before_ai_call_invalid_raises(self, guard):
        """Test before_ai_call raises with invalid license."""
        mock_response = LicenseResponse(
            valid=False,
            message="License expired",
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response

            with pytest.raises(LicenseError) as exc_info:
                await guard.before_ai_call()

            # Message comes from cached response (License expired)
            assert "expired" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_get_status_valid(self, guard):
        """Test get_status returns valid."""
        mock_response = LicenseResponse(valid=True)

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            await guard.validate()

        assert guard.get_status() == LicenseStatus.VALID

    @pytest.mark.asyncio
    async def test_get_status_grace_period(self, guard):
        """Test get_status returns grace period."""
        mock_response = LicenseResponse(
            valid=True,
            in_grace_period=True,
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            await guard.validate()

        assert guard.get_status() == LicenseStatus.GRACE_PERIOD

    @pytest.mark.asyncio
    async def test_get_worker_count(self, guard):
        """Test get_worker_count returns count."""
        mock_response = LicenseResponse(
            valid=True,
            worker_count=10,
        )

        with patch.object(
            guard._client, "validate_license", new_callable=AsyncMock
        ) as mock:
            mock.return_value = mock_response
            await guard.validate()

        assert guard.get_worker_count() == 10


# ============================================================================
# LicenseClient Tests
# ============================================================================


class TestLicenseClient:
    """Tests for LicenseClient."""

    @pytest.fixture
    def client(self):
        """Create client instance."""
        return LicenseClient(server_url="http://localhost:8000", timeout=5.0)

    @pytest.mark.asyncio
    async def test_validate_license_success(self, client):
        """Test successful license validation."""
        from unittest.mock import MagicMock

        mock_response_data = {
            "valid": True,
            "expires": (datetime.now(UTC) + timedelta(days=30)).isoformat(),
            "tier": "professional",
            "features": ["basic", "api"],
        }

        # Create a mock response with synchronous json() method
        mock_http_response = MagicMock()
        mock_http_response.status_code = 200
        mock_http_response.json.return_value = mock_response_data

        with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock:
            mock.return_value = mock_http_response

            response = await client.validate_license(
                agent_id="test-agent",
                client_id="test-client",
            )

        assert response.valid is True
        assert response.tier == "professional"

    @pytest.mark.asyncio
    async def test_send_heartbeat_success(self, client):
        """Test successful heartbeat."""
        from unittest.mock import MagicMock

        mock_response_data = {
            "continue_operation": True,
            "message": None,
        }

        # Create a mock response with synchronous json() method
        mock_http_response = MagicMock()
        mock_http_response.status_code = 200
        mock_http_response.json.return_value = mock_response_data

        with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock:
            mock.return_value = mock_http_response

            response = await client.send_heartbeat(
                agent_id="test-agent",
                usage_metrics={"requests": 100},
            )

        assert response.continue_operation is True
