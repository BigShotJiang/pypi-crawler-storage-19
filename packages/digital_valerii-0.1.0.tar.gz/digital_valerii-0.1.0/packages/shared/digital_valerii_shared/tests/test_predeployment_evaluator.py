"""Tests for PreDeploymentEvaluator.

Component 6.5: AgentOps Framework
"""

import pytest
from digital_valerii_shared.agentops.evaluation import (
    EvaluationResult,
    PreDeploymentEvaluator,
)


class MockTestSuite:
    """Mock test suite for testing evaluator."""

    def __init__(
        self,
        functional_score: float = 0.98,
        trajectory_score: float = 0.85,
        latency_p95: float = 5.0,
        safety_passed: bool = True,
    ):
        self.functional_score = functional_score
        self.trajectory_score = trajectory_score
        self.latency_p95 = latency_p95
        self.safety_passed = safety_passed

    async def run_functional_tests(self) -> float:
        return self.functional_score

    async def run_trajectory_tests(self) -> float:
        return self.trajectory_score

    async def run_latency_tests(self) -> float:
        return self.latency_p95

    async def run_safety_tests(self) -> bool:
        return self.safety_passed


class TestEvaluationResult:
    """Tests for EvaluationResult dataclass."""

    def test_create_result(self) -> None:
        """Test creating an evaluation result."""
        result = EvaluationResult(
            passed=True,
            score=95.0,
            metrics={"test": 0.95},
            failed_checks=[],
            recommendations=[],
        )
        assert result.passed is True
        assert result.score == 95.0
        assert result.metrics == {"test": 0.95}

    def test_default_lists(self) -> None:
        """Test default empty lists."""
        result = EvaluationResult(passed=True, score=100.0)
        assert result.metrics == {}
        assert result.failed_checks == []
        assert result.recommendations == []


class TestPreDeploymentEvaluator:
    """Tests for PreDeploymentEvaluator."""

    @pytest.fixture
    def evaluator(self) -> PreDeploymentEvaluator:
        """Create evaluator with default thresholds."""
        return PreDeploymentEvaluator()

    @pytest.mark.asyncio
    async def test_evaluate_all_passing(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with all checks passing."""
        suite = MockTestSuite(
            functional_score=0.98,
            trajectory_score=0.85,
            latency_p95=5.0,
            safety_passed=True,
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is True
        assert result.score > 90
        assert len(result.failed_checks) == 0
        assert result.metrics["functional_pass_rate"] == 0.98
        assert result.metrics["trajectory_score"] == 0.85
        assert result.metrics["latency_p95"] == 5.0
        assert result.metrics["safety_passed"] is True

    @pytest.mark.asyncio
    async def test_evaluate_functional_failure(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with functional test failure."""
        suite = MockTestSuite(
            functional_score=0.80,  # Below 95%
            trajectory_score=0.85,
            latency_p95=5.0,
            safety_passed=True,
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is False
        assert len(result.failed_checks) == 1
        assert "Functional tests" in result.failed_checks[0]
        assert "Review and fix failing unit tests" in result.recommendations

    @pytest.mark.asyncio
    async def test_evaluate_trajectory_failure(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with trajectory failure."""
        suite = MockTestSuite(
            functional_score=0.98,
            trajectory_score=0.50,  # Below 0.8
            latency_p95=5.0,
            safety_passed=True,
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is False
        assert len(result.failed_checks) == 1
        assert "Trajectory quality" in result.failed_checks[0]
        assert "Improve agent reasoning patterns" in result.recommendations

    @pytest.mark.asyncio
    async def test_evaluate_latency_failure(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with latency failure."""
        suite = MockTestSuite(
            functional_score=0.98,
            trajectory_score=0.85,
            latency_p95=15.0,  # Above 10s
            safety_passed=True,
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is False
        assert len(result.failed_checks) == 1
        assert "P95 latency" in result.failed_checks[0]
        assert "Optimize slow operations or add caching" in result.recommendations

    @pytest.mark.asyncio
    async def test_evaluate_safety_failure(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with safety failure."""
        suite = MockTestSuite(
            functional_score=0.98,
            trajectory_score=0.85,
            latency_p95=5.0,
            safety_passed=False,  # Safety failed
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is False
        assert len(result.failed_checks) == 1
        assert "Safety tests failed" in result.failed_checks[0]
        assert "Review safety policies and guardrails" in result.recommendations

    @pytest.mark.asyncio
    async def test_evaluate_multiple_failures(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test evaluation with multiple failures."""
        suite = MockTestSuite(
            functional_score=0.50,
            trajectory_score=0.50,
            latency_p95=20.0,
            safety_passed=False,
        )
        result = await evaluator.evaluate(suite)

        assert result.passed is False
        assert len(result.failed_checks) == 4
        assert len(result.recommendations) == 4

    @pytest.mark.asyncio
    async def test_score_calculation(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test score calculation with known values."""
        suite = MockTestSuite(
            functional_score=1.0,  # 40 points
            trajectory_score=1.0,  # 30 points
            latency_p95=5.0,  # 15 points (passes)
            safety_passed=True,  # 15 points
        )
        result = await evaluator.evaluate(suite)

        # Perfect score = 40 + 30 + 15 + 15 = 100
        assert result.score == 100.0

    @pytest.mark.asyncio
    async def test_score_with_latency_penalty(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test score calculation with latency penalty."""
        suite = MockTestSuite(
            functional_score=1.0,
            trajectory_score=1.0,
            latency_p95=15.0,  # Over threshold, gets 0.5 * 15 = 7.5
            safety_passed=True,
        )
        result = await evaluator.evaluate(suite)

        # Score = 40 + 30 + 7.5 + 15 = 92.5
        assert result.score == 92.5

    @pytest.mark.asyncio
    async def test_score_with_safety_failure(
        self, evaluator: PreDeploymentEvaluator
    ) -> None:
        """Test score calculation with safety failure (0 points)."""
        suite = MockTestSuite(
            functional_score=1.0,
            trajectory_score=1.0,
            latency_p95=5.0,
            safety_passed=False,  # 0 points
        )
        result = await evaluator.evaluate(suite)

        # Score = 40 + 30 + 15 + 0 = 85
        assert result.score == 85.0

    def test_custom_thresholds(self) -> None:
        """Test evaluator with custom thresholds."""
        evaluator = PreDeploymentEvaluator(
            pass_rate=0.90,
            max_latency=5.0,
            min_trajectory=0.7,
        )
        assert evaluator.pass_rate == 0.90
        assert evaluator.max_latency == 5.0
        assert evaluator.min_trajectory == 0.7

    @pytest.mark.asyncio
    async def test_custom_thresholds_affect_evaluation(self) -> None:
        """Test custom thresholds change pass/fail."""
        # With stricter latency threshold
        strict_evaluator = PreDeploymentEvaluator(max_latency=3.0)
        suite = MockTestSuite(latency_p95=5.0)  # Would pass default

        result = await strict_evaluator.evaluate(suite)

        assert result.passed is False
        assert "P95 latency" in result.failed_checks[0]

    def test_default_thresholds(self) -> None:
        """Test default threshold values."""
        evaluator = PreDeploymentEvaluator()
        assert evaluator.pass_rate == 0.95
        assert evaluator.max_latency == 10.0
        assert evaluator.min_trajectory == 0.8


class TestRecommendations:
    """Tests for recommendation generation."""

    @pytest.fixture
    def evaluator(self) -> PreDeploymentEvaluator:
        return PreDeploymentEvaluator()

    def test_functional_recommendation(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test functional failure generates correct recommendation."""
        recommendations = evaluator._generate_recommendations(
            ["Functional tests: 80% (required: 95%)"]
        )
        assert "Review and fix failing unit tests" in recommendations

    def test_trajectory_recommendation(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test trajectory failure generates correct recommendation."""
        recommendations = evaluator._generate_recommendations(
            ["Trajectory quality: 0.50 (required: 0.8)"]
        )
        assert "Improve agent reasoning patterns" in recommendations

    def test_latency_recommendation(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test latency failure generates correct recommendation."""
        recommendations = evaluator._generate_recommendations(
            ["P95 latency: 15.0s (max: 10.0s)"]
        )
        assert "Optimize slow operations or add caching" in recommendations

    def test_safety_recommendation(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test safety failure generates correct recommendation."""
        recommendations = evaluator._generate_recommendations(["Safety tests failed"])
        assert "Review safety policies and guardrails" in recommendations

    def test_empty_recommendations(self, evaluator: PreDeploymentEvaluator) -> None:
        """Test no recommendations for no failures."""
        recommendations = evaluator._generate_recommendations([])
        assert recommendations == []
