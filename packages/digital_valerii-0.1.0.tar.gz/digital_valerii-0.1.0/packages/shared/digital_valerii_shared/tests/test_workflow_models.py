"""Tests for workflow persistence models.

Component 4.11: Orchestration Patterns
"""

from datetime import UTC, datetime
from uuid import uuid4

from digital_valerii_shared.models import (
    WorkflowExecution,
    WorkflowStepRecord,
)


class TestWorkflowExecution:
    """Tests for WorkflowExecution model."""

    def test_create_execution(self) -> None:
        """Test creating a workflow execution."""
        user_id = uuid4()
        execution = WorkflowExecution(
            user_id=user_id,
            workflow_type="SequentialWorkflow",
            status="running",
            context={"input": "test"},
        )

        assert execution.user_id == user_id
        assert execution.workflow_type == "SequentialWorkflow"
        assert execution.status == "running"
        assert execution.context == {"input": "test"}
        assert execution.project_id is None
        assert execution.result is None
        assert execution.error is None

    def test_create_with_project(self) -> None:
        """Test creating execution with project scope."""
        user_id = uuid4()
        project_id = uuid4()
        execution = WorkflowExecution(
            user_id=user_id,
            project_id=project_id,
            workflow_type="ParallelWorkflow",
            status="completed",
            context={},
            result={"output": "done"},
        )

        assert execution.project_id == project_id
        assert execution.result == {"output": "done"}

    def test_repr(self) -> None:
        """Test string representation."""
        execution = WorkflowExecution(
            id=uuid4(),
            user_id=uuid4(),
            workflow_type="LoopWorkflow",
            status="failed",
        )
        repr_str = repr(execution)

        assert "WorkflowExecution" in repr_str
        assert "LoopWorkflow" in repr_str
        assert "failed" in repr_str


class TestWorkflowStepRecord:
    """Tests for WorkflowStepRecord model."""

    def test_create_step_record(self) -> None:
        """Test creating a workflow step record."""
        execution_id = uuid4()
        user_id = uuid4()
        step = WorkflowStepRecord(
            execution_id=execution_id,
            user_id=user_id,
            step_name="ProcessStep",
            step_order=1,
            status="pending",
        )

        assert step.execution_id == execution_id
        assert step.user_id == user_id
        assert step.step_name == "ProcessStep"
        assert step.step_order == 1
        assert step.status == "pending"
        assert step.started_at is None
        assert step.completed_at is None

    def test_step_with_data(self) -> None:
        """Test step with input/output data."""
        step = WorkflowStepRecord(
            execution_id=uuid4(),
            user_id=uuid4(),
            step_name="TransformStep",
            step_order=2,
            status="completed",
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
            input_data={"raw": "data"},
            output_data={"processed": "result"},
        )

        assert step.input_data == {"raw": "data"}
        assert step.output_data == {"processed": "result"}
        assert step.started_at is not None
        assert step.completed_at is not None

    def test_step_with_error(self) -> None:
        """Test step with error state."""
        step = WorkflowStepRecord(
            execution_id=uuid4(),
            user_id=uuid4(),
            step_name="FailingStep",
            step_order=3,
            status="failed",
            error="Connection timeout",
        )

        assert step.status == "failed"
        assert step.error == "Connection timeout"

    def test_repr(self) -> None:
        """Test string representation."""
        step = WorkflowStepRecord(
            id=uuid4(),
            execution_id=uuid4(),
            user_id=uuid4(),
            step_name="TestStep",
            step_order=1,
            status="running",
        )
        repr_str = repr(step)

        assert "WorkflowStepRecord" in repr_str
        assert "TestStep" in repr_str
        assert "running" in repr_str
