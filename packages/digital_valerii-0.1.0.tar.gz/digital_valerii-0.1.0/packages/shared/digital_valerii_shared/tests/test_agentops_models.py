"""Tests for AgentOps data models.

Component 6.5: AgentOps Framework
"""

from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from digital_valerii_shared.agentops.models import (
    AgentTrace,
    TraceEvent,
    TraceEventType,
)


class TestTraceEventType:
    """Tests for TraceEventType enum."""

    def test_enum_values(self) -> None:
        """Test all enum values exist."""
        assert TraceEventType.PROMPT_RECEIVED.value == "prompt_received"
        assert TraceEventType.MEMORY_RECALL.value == "memory_recall"
        assert TraceEventType.TOOL_CALL.value == "tool_call"
        assert TraceEventType.TOOL_RESULT.value == "tool_result"
        assert TraceEventType.DECISION_POINT.value == "decision_point"
        assert TraceEventType.APPROVAL_REQUEST.value == "approval_request"
        assert TraceEventType.APPROVAL_RESPONSE.value == "approval_response"
        assert TraceEventType.RESPONSE_GENERATED.value == "response_generated"
        assert TraceEventType.ERROR.value == "error"

    def test_string_inheritance(self) -> None:
        """Test enum inherits from str."""
        assert isinstance(TraceEventType.TOOL_CALL, str)
        assert TraceEventType.TOOL_CALL == "tool_call"


class TestTraceEvent:
    """Tests for TraceEvent dataclass."""

    def test_default_creation(self) -> None:
        """Test event creation with defaults."""
        event = TraceEvent()

        assert isinstance(event.id, UUID)
        assert event.trace_id is None
        assert event.event_type is None
        assert isinstance(event.timestamp, datetime)
        assert event.duration_ms == 0
        assert event.data == {}
        assert event.parent_event_id is None

    def test_creation_with_values(self) -> None:
        """Test event creation with custom values."""
        trace_id = uuid4()
        parent_id = uuid4()
        data = {"tool": "search", "query": "test"}

        event = TraceEvent(
            trace_id=trace_id,
            event_type=TraceEventType.TOOL_CALL,
            duration_ms=150,
            data=data,
            parent_event_id=parent_id,
        )

        assert event.trace_id == trace_id
        assert event.event_type == TraceEventType.TOOL_CALL
        assert event.duration_ms == 150
        assert event.data == data
        assert event.parent_event_id == parent_id

    def test_timestamp_is_utc(self) -> None:
        """Test timestamp is in UTC."""
        event = TraceEvent()
        assert event.timestamp.tzinfo == UTC


class TestAgentTrace:
    """Tests for AgentTrace dataclass."""

    def test_default_creation(self) -> None:
        """Test trace creation with defaults."""
        trace = AgentTrace()

        assert isinstance(trace.id, UUID)
        assert trace.session_id is None
        assert trace.user_id is None
        assert isinstance(trace.started_at, datetime)
        assert trace.completed_at is None
        assert trace.events == []
        assert trace.outcome is None
        assert trace.total_tokens == 0
        assert trace.total_cost_usd == 0.0

    def test_creation_with_values(self) -> None:
        """Test trace creation with custom values."""
        session_id = uuid4()
        user_id = uuid4()

        trace = AgentTrace(
            session_id=session_id,
            user_id=user_id,
            outcome="success",
            total_tokens=1500,
            total_cost_usd=0.025,
        )

        assert trace.session_id == session_id
        assert trace.user_id == user_id
        assert trace.outcome == "success"
        assert trace.total_tokens == 1500
        assert trace.total_cost_usd == 0.025

    def test_add_event(self) -> None:
        """Test adding event to trace."""
        trace = AgentTrace()
        event = TraceEvent(event_type=TraceEventType.TOOL_CALL)

        trace.add_event(event)

        assert len(trace.events) == 1
        assert trace.events[0] == event
        assert event.trace_id == trace.id

    def test_add_multiple_events(self) -> None:
        """Test adding multiple events."""
        trace = AgentTrace()

        trace.add_event(TraceEvent(event_type=TraceEventType.PROMPT_RECEIVED))
        trace.add_event(TraceEvent(event_type=TraceEventType.MEMORY_RECALL))
        trace.add_event(TraceEvent(event_type=TraceEventType.RESPONSE_GENERATED))

        assert len(trace.events) == 3

    def test_get_events_by_type(self) -> None:
        """Test filtering events by type."""
        trace = AgentTrace()

        trace.add_event(TraceEvent(event_type=TraceEventType.TOOL_CALL))
        trace.add_event(TraceEvent(event_type=TraceEventType.TOOL_RESULT))
        trace.add_event(TraceEvent(event_type=TraceEventType.TOOL_CALL))

        tool_calls = trace.get_events_by_type(TraceEventType.TOOL_CALL)
        assert len(tool_calls) == 2

        tool_results = trace.get_events_by_type(TraceEventType.TOOL_RESULT)
        assert len(tool_results) == 1

    def test_get_events_by_type_empty(self) -> None:
        """Test filtering when no events match."""
        trace = AgentTrace()
        trace.add_event(TraceEvent(event_type=TraceEventType.TOOL_CALL))

        errors = trace.get_events_by_type(TraceEventType.ERROR)
        assert errors == []

    def test_duration_ms_completed(self) -> None:
        """Test duration calculation for completed trace."""
        trace = AgentTrace()
        trace.completed_at = trace.started_at + timedelta(seconds=2.5)

        duration = trace.duration_ms()
        assert duration == 2500

    def test_duration_ms_not_completed(self) -> None:
        """Test duration is None for incomplete trace."""
        trace = AgentTrace()
        assert trace.duration_ms() is None

    def test_started_at_is_utc(self) -> None:
        """Test started_at is in UTC."""
        trace = AgentTrace()
        assert trace.started_at.tzinfo == UTC

    def test_events_isolation(self) -> None:
        """Test events list is isolated per trace."""
        trace1 = AgentTrace()
        trace2 = AgentTrace()

        trace1.add_event(TraceEvent(event_type=TraceEventType.ERROR))

        assert len(trace1.events) == 1
        assert len(trace2.events) == 0
