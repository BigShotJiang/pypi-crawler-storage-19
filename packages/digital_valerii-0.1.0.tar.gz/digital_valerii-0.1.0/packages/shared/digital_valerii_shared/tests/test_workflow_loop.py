"""Tests for loop workflow pattern.

Component 4.11: Orchestration Patterns
"""

import pytest
from digital_valerii_shared.workflows.base import (
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)
from digital_valerii_shared.workflows.loop import LoopWorkflow


class IncrementStep(WorkflowStep):
    """Test step that increments a counter."""

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data["counter"] = context.data.get("counter", 0) + 1
        return context


class RefineStep(WorkflowStep):
    """Test step that increases a score each iteration."""

    def __init__(self, increment: float = 0.2):
        self.increment = increment

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        context.data["score"] = context.data.get("score", 0.0) + self.increment
        return context


class FailingStep(WorkflowStep):
    """Test step that fails after N executions."""

    def __init__(self, fail_after: int = 2):
        self.fail_after = fail_after
        self.executions = 0

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        self.executions += 1
        if self.executions >= self.fail_after:
            raise ValueError("Intentional failure")
        context.data["attempts"] = self.executions
        return context


class TestLoopWorkflow:
    """Tests for LoopWorkflow."""

    @pytest.mark.asyncio
    async def test_condition_met_after_iterations(self) -> None:
        """Test loop stops when condition is met."""
        workflow = LoopWorkflow(
            steps=[IncrementStep()],
            condition=lambda ctx: ctx.data.get("counter", 0) >= 3,
            max_iterations=10,
        )
        result = await workflow.run()

        assert result.data["counter"] == 3
        assert result.data["loop_completed"] is True
        assert result.data["iterations"] == 3

    @pytest.mark.asyncio
    async def test_max_iterations_reached(self) -> None:
        """Test loop stops at max iterations."""
        workflow = LoopWorkflow(
            steps=[IncrementStep()],
            condition=lambda ctx: ctx.data.get("counter", 0) >= 100,  # Never met
            max_iterations=5,
        )
        result = await workflow.run()

        assert result.data["counter"] == 5
        assert result.data["loop_completed"] is False
        assert result.data["iterations"] == 5

    @pytest.mark.asyncio
    async def test_condition_met_on_first_iteration(self) -> None:
        """Test loop completes on first iteration if condition is met."""
        # Start with counter already at threshold
        initial = WorkflowContext(data={"counter": 3})
        workflow = LoopWorkflow(
            steps=[IncrementStep()],
            condition=lambda ctx: ctx.data.get("counter", 0) >= 3,
            max_iterations=10,
        )
        result = await workflow.run(initial)

        # Should run once (counter becomes 4) then condition is met
        assert result.data["counter"] == 4
        assert result.data["loop_completed"] is True
        assert result.data["iterations"] == 1

    @pytest.mark.asyncio
    async def test_step_failure_during_iteration(self) -> None:
        """Test step failure stops the loop."""
        failing_step = FailingStep(fail_after=2)
        workflow = LoopWorkflow(
            steps=[IncrementStep(), failing_step],
            condition=lambda _ctx: False,  # Never stop
            max_iterations=10,
        )

        with pytest.raises(WorkflowError) as exc_info:
            await workflow.run()

        assert "iteration 2" in str(exc_info.value)
        assert "FailingStep" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_history_records_iterations(self) -> None:
        """Test history records each iteration's steps."""
        workflow = LoopWorkflow(
            steps=[IncrementStep()],
            condition=lambda ctx: ctx.data.get("counter", 0) >= 3,
            max_iterations=10,
        )
        result = await workflow.run()

        assert len(result.history) == 3
        assert "iter=1" in result.history[0]["step"]
        assert "iter=2" in result.history[1]["step"]
        assert "iter=3" in result.history[2]["step"]

    @pytest.mark.asyncio
    async def test_multiple_steps_per_iteration(self) -> None:
        """Test multiple steps execute each iteration."""

        class AppendStep(WorkflowStep):
            def __init__(self, value: str):
                self._value = value

            @property
            def name(self) -> str:
                return f"Append_{self._value}"

            async def execute(self, context: WorkflowContext) -> WorkflowContext:
                items = context.data.get("items", [])
                items.append(self._value)
                context.data["items"] = items
                return context

        workflow = LoopWorkflow(
            steps=[AppendStep("a"), AppendStep("b"), IncrementStep()],
            condition=lambda ctx: ctx.data.get("counter", 0) >= 2,
            max_iterations=10,
        )
        result = await workflow.run()

        assert result.data["items"] == ["a", "b", "a", "b"]
        assert result.data["counter"] == 2

    @pytest.mark.asyncio
    async def test_refinement_pattern(self) -> None:
        """Test iterative refinement until quality threshold."""
        workflow = LoopWorkflow(
            steps=[RefineStep(increment=0.25)],
            condition=lambda ctx: ctx.data.get("score", 0) >= 0.85,
            max_iterations=10,
        )
        result = await workflow.run()

        assert result.data["score"] >= 0.85
        assert result.data["loop_completed"] is True
        assert result.data["iterations"] == 4  # 0.25 * 4 = 1.0

    @pytest.mark.asyncio
    async def test_workflow_name(self) -> None:
        """Test custom workflow name."""
        workflow = LoopWorkflow(
            steps=[],
            condition=lambda _ctx: True,
            name="CustomLoop",
        )
        assert workflow.name == "CustomLoop"

    @pytest.mark.asyncio
    async def test_empty_steps(self) -> None:
        """Test loop with no steps."""
        call_count = 0

        def condition(_ctx: WorkflowContext) -> bool:
            nonlocal call_count
            call_count += 1
            return call_count >= 3

        workflow = LoopWorkflow(
            steps=[],
            condition=condition,
            max_iterations=10,
        )
        result = await workflow.run()

        assert result.data["loop_completed"] is True
        assert result.data["iterations"] == 3

    @pytest.mark.asyncio
    async def test_max_iterations_one(self) -> None:
        """Test with max_iterations=1."""
        workflow = LoopWorkflow(
            steps=[IncrementStep()],
            condition=lambda _ctx: False,  # Never met
            max_iterations=1,
        )
        result = await workflow.run()

        assert result.data["counter"] == 1
        assert result.data["loop_completed"] is False
        assert result.data["iterations"] == 1
