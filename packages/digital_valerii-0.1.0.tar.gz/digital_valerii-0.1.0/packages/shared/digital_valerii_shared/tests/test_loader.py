"""Tests for PersonalityLoader.

This module contains tests for the PersonalityLoader class,
covering file loading, caching, and error handling.
"""

from pathlib import Path

import pytest
from digital_valerii_shared.agent.personality import (
    ContentNotFoundError,
    PersonalityLoader,
    PersonalitySection,
)


class TestPersonalityLoaderInit:
    """Tests for PersonalityLoader initialization."""

    def test_init_default_content_dir(self) -> None:
        """Test initialization with default content directory."""
        loader = PersonalityLoader()
        assert loader.content_dir.exists()
        assert loader.content_dir.name == "content"

    def test_init_custom_content_dir(self, tmp_path: Path) -> None:
        """Test initialization with custom content directory."""
        loader = PersonalityLoader(content_dir=tmp_path)
        assert loader.content_dir == tmp_path

    def test_content_dir_property(self) -> None:
        """Test content_dir property is read-only Path."""
        loader = PersonalityLoader()
        assert isinstance(loader.content_dir, Path)


class TestPersonalityLoaderLoadSection:
    """Tests for load_section method."""

    def test_load_section_base(self) -> None:
        """Test loading base section."""
        loader = PersonalityLoader()
        content = loader.load_section(PersonalitySection.BASE)

        assert content
        assert "Digital Valerii" in content

    def test_load_section_communication(self) -> None:
        """Test loading communication section."""
        loader = PersonalityLoader()
        content = loader.load_section(PersonalitySection.COMMUNICATION)

        assert content
        assert "Tone" in content or "Communication" in content

    def test_load_section_knowledge(self) -> None:
        """Test loading knowledge section."""
        loader = PersonalityLoader()
        content = loader.load_section(PersonalitySection.KNOWLEDGE)

        assert content
        assert "ISO" in content or "NIST" in content

    def test_load_section_behaviors(self) -> None:
        """Test loading behaviors section."""
        loader = PersonalityLoader()
        content = loader.load_section(PersonalitySection.BEHAVIORS)

        assert content
        assert "KPI" in content or "Interview" in content

    def test_load_section_examples(self) -> None:
        """Test loading examples section."""
        loader = PersonalityLoader()
        content = loader.load_section(PersonalitySection.EXAMPLES)

        assert content
        assert "Example" in content or "Response" in content

    def test_load_section_caches_result(self) -> None:
        """Test that loaded content is cached."""
        loader = PersonalityLoader()
        loader.load_section(PersonalitySection.BASE)

        assert loader.is_cached(PersonalitySection.BASE)

    def test_load_section_returns_cached(self) -> None:
        """Test that cached content is returned on subsequent calls."""
        loader = PersonalityLoader()
        content1 = loader.load_section(PersonalitySection.BASE)
        content2 = loader.load_section(PersonalitySection.BASE)

        assert content1 == content2

    def test_load_section_not_found(self, tmp_path: Path) -> None:
        """Test loading section from empty directory raises error."""
        loader = PersonalityLoader(content_dir=tmp_path)

        with pytest.raises(ContentNotFoundError) as exc_info:
            loader.load_section(PersonalitySection.BASE)

        assert "base.md" in str(exc_info.value)


class TestPersonalityLoaderLoadSections:
    """Tests for load_sections method."""

    def test_load_sections_multiple(self) -> None:
        """Test loading multiple sections at once."""
        loader = PersonalityLoader()
        sections = (PersonalitySection.BASE, PersonalitySection.COMMUNICATION)
        result = loader.load_sections(sections)

        assert len(result) == 2
        assert PersonalitySection.BASE in result
        assert PersonalitySection.COMMUNICATION in result

    def test_load_sections_empty(self) -> None:
        """Test loading empty tuple of sections."""
        loader = PersonalityLoader()
        result = loader.load_sections(())

        assert result == {}


class TestPersonalityLoaderLoadAll:
    """Tests for load_all method."""

    def test_load_all_returns_all_sections(self) -> None:
        """Test that load_all returns all sections."""
        loader = PersonalityLoader()
        result = loader.load_all()

        assert len(result) == 5
        for section in PersonalitySection:
            assert section in result


class TestPersonalityLoaderCache:
    """Tests for caching functionality."""

    def test_clear_cache(self) -> None:
        """Test clearing the cache."""
        loader = PersonalityLoader()
        loader.load_section(PersonalitySection.BASE)
        assert loader.is_cached(PersonalitySection.BASE)

        loader.clear_cache()
        assert not loader.is_cached(PersonalitySection.BASE)

    def test_is_cached_false_initially(self) -> None:
        """Test that sections are not cached initially."""
        loader = PersonalityLoader()
        assert not loader.is_cached(PersonalitySection.BASE)


class TestPersonalityLoaderValidation:
    """Tests for validation functionality."""

    def test_get_available_sections(self) -> None:
        """Test getting list of available sections."""
        loader = PersonalityLoader()
        available = loader.get_available_sections()

        assert len(available) == 5
        for section in PersonalitySection:
            assert section in available

    def test_get_available_sections_empty_dir(self, tmp_path: Path) -> None:
        """Test available sections with empty directory."""
        loader = PersonalityLoader(content_dir=tmp_path)
        available = loader.get_available_sections()

        assert available == []

    def test_validate_content_directory_valid(self) -> None:
        """Test validation with valid content directory."""
        loader = PersonalityLoader()
        is_valid, missing = loader.validate_content_directory()

        assert is_valid is True
        assert missing == []

    def test_validate_content_directory_invalid(self, tmp_path: Path) -> None:
        """Test validation with missing files."""
        loader = PersonalityLoader(content_dir=tmp_path)
        is_valid, missing = loader.validate_content_directory()

        assert is_valid is False
        assert len(missing) == 5

    def test_validate_content_directory_partial(self, tmp_path: Path) -> None:
        """Test validation with some files present."""
        # Create only base.md
        (tmp_path / "base.md").write_text("# Base content")
        loader = PersonalityLoader(content_dir=tmp_path)
        is_valid, missing = loader.validate_content_directory()

        assert is_valid is False
        assert len(missing) == 4
        assert "base.md" not in missing


class TestPersonalityLoaderSectionFiles:
    """Tests for SECTION_FILES mapping."""

    def test_section_files_complete(self) -> None:
        """Test that all sections have file mappings."""
        for section in PersonalitySection:
            assert section in PersonalityLoader.SECTION_FILES

    def test_section_files_format(self) -> None:
        """Test that all file names end with .md."""
        for filename in PersonalityLoader.SECTION_FILES.values():
            assert filename.endswith(".md")
