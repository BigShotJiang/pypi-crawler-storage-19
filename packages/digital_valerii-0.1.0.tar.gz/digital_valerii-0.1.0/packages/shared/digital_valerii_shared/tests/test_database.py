"""Tests for database connection management."""

import pytest
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from packages.shared.digital_valerii_shared.config import DatabaseSettings
from packages.shared.digital_valerii_shared.database import Database, IsolatedDatabase


class TestDatabaseSettings:
    """Tests for DatabaseSettings."""

    def test_default_values(self) -> None:
        """Test default settings values."""
        settings = DatabaseSettings()
        assert settings.pool_size == 5
        assert settings.max_overflow == 10
        assert settings.echo is False
        assert "postgresql+asyncpg" in settings.url

    def test_custom_values_via_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Test settings from environment variables."""
        monkeypatch.setenv(
            "DATABASE_URL", "postgresql+asyncpg://user:pass@host:5432/db"
        )
        monkeypatch.setenv("DB_POOL_SIZE", "10")
        monkeypatch.setenv("DB_MAX_OVERFLOW", "20")
        monkeypatch.setenv("DB_ECHO", "true")

        settings = DatabaseSettings()
        assert settings.pool_size == 10
        assert settings.max_overflow == 20
        assert settings.echo is True
        assert settings.url == "postgresql+asyncpg://user:pass@host:5432/db"


class TestDatabaseClass:
    """Tests for Database class structure."""

    def test_init(self) -> None:
        """Test Database initialization."""
        settings = DatabaseSettings()
        db = Database(settings)
        assert db.settings == settings
        assert db._engine is None
        assert db._session_factory is None

    def test_engine_property_creates_engine(self) -> None:
        """Test engine property creates AsyncEngine."""
        settings = DatabaseSettings()
        db = Database(settings)
        engine = db.engine
        assert isinstance(engine, AsyncEngine)
        assert db._engine is engine
        # Second access should return same engine
        assert db.engine is engine

    def test_session_factory_property(self) -> None:
        """Test session_factory property creates factory."""
        settings = DatabaseSettings()
        db = Database(settings)
        factory = db.session_factory
        assert isinstance(factory, async_sessionmaker)
        assert db._session_factory is factory
        # Second access should return same factory
        assert db.session_factory is factory


class TestIsolatedDatabaseClass:
    """Tests for IsolatedDatabase class."""

    def test_uses_null_pool(self) -> None:
        """Test IsolatedDatabase uses NullPool."""
        from sqlalchemy.pool import NullPool

        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)
        engine = db.engine
        assert isinstance(engine, AsyncEngine)
        # Verify NullPool is used
        assert isinstance(engine.pool, NullPool)


@pytest.mark.asyncio
class TestDatabaseIntegration:
    """Integration tests for database operations."""

    async def test_session_context_manager(self) -> None:
        """Test session context manager provides session."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        async with db.session() as session:
            assert isinstance(session, AsyncSession)
            result = await session.execute(text("SELECT 1"))
            assert result.scalar() == 1

        await db.close()

    async def test_session_commits_on_success(self) -> None:
        """Test session commits on successful exit."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        async with db.session() as session:
            await session.execute(text("SELECT 1"))
            # Should not raise, commit happens on exit

        await db.close()

    async def test_session_rollback_on_exception(self) -> None:
        """Test session rolls back on exception."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        with pytest.raises(ValueError, match="test error"):
            async with db.session() as session:
                await session.execute(text("SELECT 1"))
                raise ValueError("test error")

        await db.close()

    async def test_health_check_success(self) -> None:
        """Test health check returns True when connected."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        result = await db.health_check()
        assert result is True

        await db.close()

    async def test_health_check_failure(self) -> None:
        """Test health check returns False on connection failure."""
        from unittest.mock import AsyncMock, patch

        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        # Mock the session to raise an exception
        with patch.object(db, "session") as mock_session:
            mock_cm = AsyncMock()
            mock_cm.__aenter__.side_effect = Exception("Connection refused")
            mock_session.return_value = mock_cm

            result = await db.health_check()
            assert result is False

    async def test_close_disposes_engine(self) -> None:
        """Test close disposes engine and resets factory."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        # Create engine and factory
        _ = db.engine
        _ = db.session_factory

        await db.close()

        assert db._engine is None
        assert db._session_factory is None

    async def test_close_idempotent(self) -> None:
        """Test close can be called multiple times safely."""
        settings = DatabaseSettings()
        db = IsolatedDatabase(settings)

        await db.close()
        await db.close()  # Should not raise
