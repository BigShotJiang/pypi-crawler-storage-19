"""Browser automation module.

Provides headless browser automation via Playwright MCP for web scraping,
form filling, screenshots, and PDF generation.
"""

from .exceptions import (
    BrowserElementNotFoundError,
    BrowserError,
    BrowserNavigationError,
    BrowserTimeoutError,
)
from .models import (
    BrowserAction,
    BrowserState,
    ClickRequest,
    FillRequest,
    NavigateRequest,
    PDFRequest,
    PDFResult,
    ScreenshotRequest,
    ScreenshotResult,
)
from .service import BrowserService

__all__ = [
    # Service
    "BrowserService",
    # Models
    "BrowserAction",
    "BrowserState",
    "ClickRequest",
    "FillRequest",
    "NavigateRequest",
    "PDFRequest",
    "PDFResult",
    "ScreenshotRequest",
    "ScreenshotResult",
    # Exceptions
    "BrowserError",
    "BrowserTimeoutError",
    "BrowserNavigationError",
    "BrowserElementNotFoundError",
]
