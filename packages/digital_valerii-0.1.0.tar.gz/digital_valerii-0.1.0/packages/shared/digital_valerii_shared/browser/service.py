"""Browser automation service."""

from typing import Any, Protocol

import structlog

from .exceptions import BrowserError, BrowserTimeoutError
from .models import (
    BrowserState,
    ClickRequest,
    FillRequest,
    NavigateRequest,
    PDFRequest,
    PDFResult,
    ScreenshotRequest,
    ScreenshotResult,
)

logger = structlog.get_logger(__name__)


class MCPClient(Protocol):
    """Protocol for MCP client interface."""

    async def call_tool(self, tool_name: str, params: dict[str, Any]) -> dict[str, Any]:
        """Call an MCP tool."""
        ...


class BrowserService:
    """Service for browser automation via Playwright MCP.

    This service wraps Playwright MCP tool calls with validation,
    error handling, and logging.
    """

    def __init__(self, mcp_client: MCPClient) -> None:
        """Initialize browser service.

        Args:
            mcp_client: MCP client for Playwright server.
        """
        self._mcp = mcp_client
        self._state = BrowserState()

    @property
    def state(self) -> BrowserState:
        """Get current browser state."""
        return self._state

    async def navigate(self, request: NavigateRequest) -> BrowserState:
        """Navigate to URL.

        Args:
            request: Navigation request.

        Returns:
            Updated browser state.
        """
        await logger.ainfo(
            "Navigating to URL",
            url=str(request.url),
            wait_until=request.wait_until,
        )

        try:
            result = await self._mcp.call_tool(
                "playwright_navigate",
                {
                    "url": str(request.url),
                    "waitUntil": request.wait_until,
                    "timeout": request.timeout_ms,
                },
            )

            self._state = BrowserState(
                url=str(request.url),
                title=result.get("title"),
                is_ready=True,
            )

            return self._state

        except Exception as e:
            await logger.aerror("Navigation failed", error=str(e))
            raise BrowserError(f"Navigation failed: {e}") from e

    async def click(self, request: ClickRequest) -> None:
        """Click an element.

        Args:
            request: Click request.
        """
        await logger.ainfo("Clicking element", selector=request.selector)

        try:
            await self._mcp.call_tool(
                "playwright_click",
                {
                    "selector": request.selector,
                    "timeout": request.timeout_ms,
                },
            )
        except Exception as e:
            await logger.aerror("Click failed", selector=request.selector, error=str(e))
            raise BrowserError(f"Click failed: {e}") from e

    async def fill(self, request: FillRequest) -> None:
        """Fill a form field.

        Args:
            request: Fill request.
        """
        await logger.ainfo(
            "Filling form field",
            selector=request.selector,
            value_length=len(request.value),
        )

        try:
            await self._mcp.call_tool(
                "playwright_fill",
                {
                    "selector": request.selector,
                    "value": request.value,
                    "timeout": request.timeout_ms,
                },
            )
        except Exception as e:
            await logger.aerror("Fill failed", selector=request.selector, error=str(e))
            raise BrowserError(f"Fill failed: {e}") from e

    async def screenshot(self, request: ScreenshotRequest) -> ScreenshotResult:
        """Take a screenshot.

        Args:
            request: Screenshot request.

        Returns:
            Screenshot result with image data.
        """
        await logger.ainfo(
            "Taking screenshot",
            full_page=request.full_page,
            selector=request.selector,
        )

        try:
            params: dict[str, Any] = {
                "fullPage": request.full_page,
                "type": request.format,
            }

            if request.selector:
                params["selector"] = request.selector

            if request.format == "jpeg":
                params["quality"] = request.quality

            result = await self._mcp.call_tool("playwright_screenshot", params)

            return ScreenshotResult(
                data=result.get("data", b""),
                format=request.format,
                width=result.get("width", 0),
                height=result.get("height", 0),
            )

        except Exception as e:
            await logger.aerror("Screenshot failed", error=str(e))
            raise BrowserError(f"Screenshot failed: {e}") from e

    async def get_text(self, selector: str) -> str:
        """Get text content of element.

        Args:
            selector: CSS or XPath selector.

        Returns:
            Text content.
        """
        try:
            result = await self._mcp.call_tool(
                "playwright_get_text", {"selector": selector}
            )
            return result.get("text", "")
        except Exception as e:
            await logger.aerror("Get text failed", selector=selector, error=str(e))
            raise BrowserError(f"Get text failed: {e}") from e

    async def get_html(self, selector: str | None = None) -> str:
        """Get HTML content.

        Args:
            selector: Optional element selector (None for full page).

        Returns:
            HTML content.
        """
        try:
            params = {"selector": selector} if selector else {}
            result = await self._mcp.call_tool("playwright_get_html", params)
            return result.get("html", "")
        except Exception as e:
            await logger.aerror("Get HTML failed", error=str(e))
            raise BrowserError(f"Get HTML failed: {e}") from e

    async def wait_for_selector(
        self,
        selector: str,
        timeout_ms: int = 30000,
    ) -> None:
        """Wait for element to appear.

        Args:
            selector: CSS or XPath selector.
            timeout_ms: Maximum wait time.
        """
        try:
            await self._mcp.call_tool(
                "playwright_wait_for_selector",
                {
                    "selector": selector,
                    "timeout": timeout_ms,
                },
            )
        except Exception as e:
            await logger.aerror(
                "Wait for selector failed",
                selector=selector,
                error=str(e),
            )
            raise BrowserTimeoutError(f"Element not found: {selector}") from e

    async def generate_pdf(self, request: PDFRequest) -> PDFResult:
        """Generate PDF from URL.

        Args:
            request: PDF generation request.

        Returns:
            PDF result with data.
        """
        await logger.ainfo(
            "Generating PDF",
            url=str(request.url),
            format=request.format,
            landscape=request.landscape,
        )

        try:
            # First navigate to the URL
            await self.navigate(
                NavigateRequest(
                    url=request.url,
                    wait_until="networkidle",
                )
            )

            # Generate PDF
            result = await self._mcp.call_tool(
                "playwright_pdf",
                {
                    "format": request.format,
                    "landscape": request.landscape,
                    "printBackground": request.print_background,
                    "margin": {
                        "top": request.margin_top,
                        "bottom": request.margin_bottom,
                        "left": request.margin_left,
                        "right": request.margin_right,
                    },
                },
            )

            pdf_data = result.get("data", b"")

            return PDFResult(
                data=pdf_data,
                page_count=result.get("pageCount", 1),
                size_bytes=len(pdf_data),
            )

        except BrowserError:
            raise
        except Exception as e:
            await logger.aerror(
                "PDF generation failed", url=str(request.url), error=str(e)
            )
            raise BrowserError(f"PDF generation failed: {e}") from e
