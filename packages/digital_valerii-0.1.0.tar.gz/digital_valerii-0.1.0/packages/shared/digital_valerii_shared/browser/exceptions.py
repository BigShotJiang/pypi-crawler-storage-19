"""Browser automation exceptions."""


class BrowserError(Exception):
    """Base exception for browser operations."""

    def __init__(self, message: str = "Browser operation failed") -> None:
        self.message = message
        super().__init__(message)


class BrowserTimeoutError(BrowserError):
    """Raised when browser operation times out."""

    def __init__(self, message: str = "Browser operation timed out") -> None:
        super().__init__(message)


class BrowserNavigationError(BrowserError):
    """Raised when navigation fails."""

    def __init__(self, url: str, reason: str = "Unknown") -> None:
        self.url = url
        self.reason = reason
        super().__init__(f"Navigation to {url} failed: {reason}")


class BrowserElementNotFoundError(BrowserError):
    """Raised when element is not found."""

    def __init__(self, selector: str) -> None:
        self.selector = selector
        super().__init__(f"Element not found: {selector}")
