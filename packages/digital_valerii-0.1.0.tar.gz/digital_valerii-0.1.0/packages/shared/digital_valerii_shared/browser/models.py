"""Browser automation models."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, HttpUrl


class BrowserAction(str, Enum):
    """Available browser actions."""

    NAVIGATE = "navigate"
    CLICK = "click"
    FILL = "fill"
    SCREENSHOT = "screenshot"
    GET_TEXT = "get_text"
    GET_HTML = "get_html"
    WAIT = "wait"
    PDF = "pdf"


class NavigateRequest(BaseModel):
    """Request to navigate to URL."""

    model_config = ConfigDict(extra="forbid")

    url: HttpUrl = Field(..., description="URL to navigate to")
    wait_until: str = Field(
        default="domcontentloaded",
        description="Wait condition: load, domcontentloaded, networkidle",
    )
    timeout_ms: int = Field(default=30000, ge=1000, le=120000)


class ClickRequest(BaseModel):
    """Request to click an element."""

    model_config = ConfigDict(extra="forbid")

    selector: str = Field(..., description="CSS or XPath selector")
    timeout_ms: int = Field(default=5000, ge=1000, le=30000)


class FillRequest(BaseModel):
    """Request to fill a form field."""

    model_config = ConfigDict(extra="forbid")

    selector: str = Field(..., description="CSS or XPath selector")
    value: str = Field(..., description="Value to fill")
    timeout_ms: int = Field(default=5000, ge=1000, le=30000)


class ScreenshotRequest(BaseModel):
    """Request for screenshot."""

    model_config = ConfigDict(extra="forbid")

    full_page: bool = Field(default=False)
    selector: str | None = Field(default=None, description="Element selector")
    format: str = Field(default="png", pattern="^(png|jpeg)$")
    quality: int = Field(default=80, ge=1, le=100)


class ScreenshotResult(BaseModel):
    """Screenshot result."""

    model_config = ConfigDict(extra="forbid")

    data: bytes = Field(..., description="Image data")
    format: str
    width: int
    height: int


class PDFRequest(BaseModel):
    """Request for PDF generation."""

    model_config = ConfigDict(extra="forbid")

    url: HttpUrl = Field(..., description="URL to convert to PDF")
    format: str = Field(default="A4", pattern="^(A4|Letter|Legal)$")
    landscape: bool = Field(default=False)
    print_background: bool = Field(default=True)
    margin_top: str = Field(default="1cm")
    margin_bottom: str = Field(default="1cm")
    margin_left: str = Field(default="1cm")
    margin_right: str = Field(default="1cm")


class PDFResult(BaseModel):
    """PDF generation result."""

    model_config = ConfigDict(extra="forbid")

    data: bytes = Field(..., description="PDF data")
    page_count: int
    size_bytes: int


class BrowserState(BaseModel):
    """Current browser state."""

    model_config = ConfigDict(extra="forbid")

    url: str | None = Field(default=None)
    title: str | None = Field(default=None)
    is_ready: bool = Field(default=False)
