"""Tests for browser automation models."""

import pytest
from digital_valerii_shared.browser.models import (
    BrowserAction,
    BrowserState,
    ClickRequest,
    FillRequest,
    NavigateRequest,
    PDFRequest,
    PDFResult,
    ScreenshotRequest,
    ScreenshotResult,
)
from pydantic import ValidationError


class TestBrowserAction:
    """Tests for BrowserAction enum."""

    def test_all_actions_defined(self):
        """Should have all expected browser actions."""
        assert BrowserAction.NAVIGATE == "navigate"
        assert BrowserAction.CLICK == "click"
        assert BrowserAction.FILL == "fill"
        assert BrowserAction.SCREENSHOT == "screenshot"
        assert BrowserAction.GET_TEXT == "get_text"
        assert BrowserAction.GET_HTML == "get_html"
        assert BrowserAction.WAIT == "wait"
        assert BrowserAction.PDF == "pdf"


class TestNavigateRequest:
    """Tests for NavigateRequest model."""

    def test_valid_navigation(self):
        """Should create valid navigation request."""
        request = NavigateRequest(url="https://example.com")
        assert str(request.url) == "https://example.com/"
        assert request.wait_until == "domcontentloaded"
        assert request.timeout_ms == 30000

    def test_custom_wait_until(self):
        """Should accept custom wait_until value."""
        request = NavigateRequest(url="https://example.com", wait_until="networkidle")
        assert request.wait_until == "networkidle"

    def test_custom_timeout(self):
        """Should accept custom timeout."""
        request = NavigateRequest(url="https://example.com", timeout_ms=60000)
        assert request.timeout_ms == 60000

    def test_invalid_url(self):
        """Should reject invalid URL."""
        with pytest.raises(ValidationError):
            NavigateRequest(url="not-a-url")

    def test_timeout_too_low(self):
        """Should reject timeout below minimum."""
        with pytest.raises(ValidationError):
            NavigateRequest(url="https://example.com", timeout_ms=500)

    def test_timeout_too_high(self):
        """Should reject timeout above maximum."""
        with pytest.raises(ValidationError):
            NavigateRequest(url="https://example.com", timeout_ms=200000)

    def test_extra_field_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            NavigateRequest(url="https://example.com", extra_field="value")


class TestClickRequest:
    """Tests for ClickRequest model."""

    def test_valid_click(self):
        """Should create valid click request."""
        request = ClickRequest(selector="#submit-button")
        assert request.selector == "#submit-button"
        assert request.timeout_ms == 5000

    def test_xpath_selector(self):
        """Should accept XPath selector."""
        request = ClickRequest(selector="//button[@type='submit']")
        assert request.selector == "//button[@type='submit']"

    def test_custom_timeout(self):
        """Should accept custom timeout."""
        request = ClickRequest(selector=".btn", timeout_ms=10000)
        assert request.timeout_ms == 10000

    def test_extra_field_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            ClickRequest(selector=".btn", extra="value")


class TestFillRequest:
    """Tests for FillRequest model."""

    def test_valid_fill(self):
        """Should create valid fill request."""
        request = FillRequest(selector="#email", value="test@example.com")
        assert request.selector == "#email"
        assert request.value == "test@example.com"
        assert request.timeout_ms == 5000

    def test_empty_value_allowed(self):
        """Should allow empty value to clear field."""
        request = FillRequest(selector="#field", value="")
        assert request.value == ""

    def test_extra_field_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            FillRequest(selector="#field", value="test", extra="value")


class TestScreenshotRequest:
    """Tests for ScreenshotRequest model."""

    def test_default_screenshot(self):
        """Should create default screenshot request."""
        request = ScreenshotRequest()
        assert request.full_page is False
        assert request.selector is None
        assert request.format == "png"
        assert request.quality == 80

    def test_full_page_screenshot(self):
        """Should create full page screenshot request."""
        request = ScreenshotRequest(full_page=True)
        assert request.full_page is True

    def test_element_screenshot(self):
        """Should create element screenshot request."""
        request = ScreenshotRequest(selector="#content")
        assert request.selector == "#content"

    def test_jpeg_format(self):
        """Should accept jpeg format."""
        request = ScreenshotRequest(format="jpeg", quality=90)
        assert request.format == "jpeg"
        assert request.quality == 90

    def test_invalid_format(self):
        """Should reject invalid format."""
        with pytest.raises(ValidationError):
            ScreenshotRequest(format="gif")

    def test_quality_bounds(self):
        """Should enforce quality bounds."""
        with pytest.raises(ValidationError):
            ScreenshotRequest(quality=0)
        with pytest.raises(ValidationError):
            ScreenshotRequest(quality=101)


class TestScreenshotResult:
    """Tests for ScreenshotResult model."""

    def test_valid_result(self):
        """Should create valid screenshot result."""
        result = ScreenshotResult(
            data=b"image-data",
            format="png",
            width=1920,
            height=1080,
        )
        assert result.data == b"image-data"
        assert result.format == "png"
        assert result.width == 1920
        assert result.height == 1080


class TestPDFRequest:
    """Tests for PDFRequest model."""

    def test_default_pdf(self):
        """Should create default PDF request."""
        request = PDFRequest(url="https://example.com")
        assert str(request.url) == "https://example.com/"
        assert request.format == "A4"
        assert request.landscape is False
        assert request.print_background is True
        assert request.margin_top == "1cm"

    def test_landscape_pdf(self):
        """Should create landscape PDF request."""
        request = PDFRequest(url="https://example.com", landscape=True)
        assert request.landscape is True

    def test_letter_format(self):
        """Should accept Letter format."""
        request = PDFRequest(url="https://example.com", format="Letter")
        assert request.format == "Letter"

    def test_legal_format(self):
        """Should accept Legal format."""
        request = PDFRequest(url="https://example.com", format="Legal")
        assert request.format == "Legal"

    def test_invalid_format(self):
        """Should reject invalid format."""
        with pytest.raises(ValidationError):
            PDFRequest(url="https://example.com", format="A3")

    def test_custom_margins(self):
        """Should accept custom margins."""
        request = PDFRequest(
            url="https://example.com",
            margin_top="2cm",
            margin_bottom="2cm",
            margin_left="1.5cm",
            margin_right="1.5cm",
        )
        assert request.margin_top == "2cm"
        assert request.margin_bottom == "2cm"


class TestPDFResult:
    """Tests for PDFResult model."""

    def test_valid_result(self):
        """Should create valid PDF result."""
        result = PDFResult(
            data=b"pdf-data",
            page_count=5,
            size_bytes=12345,
        )
        assert result.data == b"pdf-data"
        assert result.page_count == 5
        assert result.size_bytes == 12345


class TestBrowserState:
    """Tests for BrowserState model."""

    def test_default_state(self):
        """Should create default browser state."""
        state = BrowserState()
        assert state.url is None
        assert state.title is None
        assert state.is_ready is False

    def test_ready_state(self):
        """Should create ready browser state."""
        state = BrowserState(
            url="https://example.com",
            title="Example Domain",
            is_ready=True,
        )
        assert state.url == "https://example.com"
        assert state.title == "Example Domain"
        assert state.is_ready is True
