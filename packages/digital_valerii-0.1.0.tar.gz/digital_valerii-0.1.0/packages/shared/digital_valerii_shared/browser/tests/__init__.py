"""Browser automation tests."""
