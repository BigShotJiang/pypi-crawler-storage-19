"""Tests for BrowserService."""

from unittest.mock import AsyncMock

import pytest
from digital_valerii_shared.browser.exceptions import BrowserError, BrowserTimeoutError
from digital_valerii_shared.browser.models import (
    BrowserState,
    ClickRequest,
    FillRequest,
    NavigateRequest,
    PDFRequest,
    ScreenshotRequest,
)
from digital_valerii_shared.browser.service import BrowserService


@pytest.fixture
def mock_mcp_client():
    """Create mock MCP client."""
    client = AsyncMock()
    client.call_tool = AsyncMock()
    return client


@pytest.fixture
def browser_service(mock_mcp_client):
    """Create BrowserService with mock client."""
    return BrowserService(mcp_client=mock_mcp_client)


class TestBrowserServiceInit:
    """Tests for BrowserService initialization."""

    def test_init(self, mock_mcp_client):
        """Should initialize with MCP client."""
        service = BrowserService(mcp_client=mock_mcp_client)
        assert service._mcp == mock_mcp_client
        assert service.state.is_ready is False

    def test_state_property(self, browser_service):
        """Should return browser state."""
        assert isinstance(browser_service.state, BrowserState)


class TestNavigate:
    """Tests for navigate method."""

    @pytest.mark.asyncio
    async def test_navigate_success(self, browser_service, mock_mcp_client):
        """Should navigate to URL successfully."""
        mock_mcp_client.call_tool.return_value = {"title": "Example Domain"}

        request = NavigateRequest(url="https://example.com")
        result = await browser_service.navigate(request)

        assert result.url == "https://example.com/"
        assert result.title == "Example Domain"
        assert result.is_ready is True
        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_navigate",
            {
                "url": "https://example.com/",
                "waitUntil": "domcontentloaded",
                "timeout": 30000,
            },
        )

    @pytest.mark.asyncio
    async def test_navigate_updates_state(self, browser_service, mock_mcp_client):
        """Should update browser state after navigation."""
        mock_mcp_client.call_tool.return_value = {"title": "Test Page"}

        request = NavigateRequest(url="https://test.com")
        await browser_service.navigate(request)

        assert browser_service.state.url == "https://test.com/"
        assert browser_service.state.is_ready is True

    @pytest.mark.asyncio
    async def test_navigate_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on navigation failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Network error")

        request = NavigateRequest(url="https://example.com")
        with pytest.raises(BrowserError, match="Navigation failed"):
            await browser_service.navigate(request)


class TestClick:
    """Tests for click method."""

    @pytest.mark.asyncio
    async def test_click_success(self, browser_service, mock_mcp_client):
        """Should click element successfully."""
        mock_mcp_client.call_tool.return_value = {}

        request = ClickRequest(selector="#button")
        await browser_service.click(request)

        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_click",
            {"selector": "#button", "timeout": 5000},
        )

    @pytest.mark.asyncio
    async def test_click_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on click failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Element not found")

        request = ClickRequest(selector="#missing")
        with pytest.raises(BrowserError, match="Click failed"):
            await browser_service.click(request)


class TestFill:
    """Tests for fill method."""

    @pytest.mark.asyncio
    async def test_fill_success(self, browser_service, mock_mcp_client):
        """Should fill form field successfully."""
        mock_mcp_client.call_tool.return_value = {}

        request = FillRequest(selector="#email", value="test@example.com")
        await browser_service.fill(request)

        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_fill",
            {
                "selector": "#email",
                "value": "test@example.com",
                "timeout": 5000,
            },
        )

    @pytest.mark.asyncio
    async def test_fill_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on fill failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Field not editable")

        request = FillRequest(selector="#readonly", value="test")
        with pytest.raises(BrowserError, match="Fill failed"):
            await browser_service.fill(request)


class TestScreenshot:
    """Tests for screenshot method."""

    @pytest.mark.asyncio
    async def test_screenshot_success(self, browser_service, mock_mcp_client):
        """Should take screenshot successfully."""
        mock_mcp_client.call_tool.return_value = {
            "data": b"image-data",
            "width": 1920,
            "height": 1080,
        }

        request = ScreenshotRequest(full_page=True)
        result = await browser_service.screenshot(request)

        assert result.data == b"image-data"
        assert result.width == 1920
        assert result.height == 1080
        assert result.format == "png"

    @pytest.mark.asyncio
    async def test_screenshot_with_selector(self, browser_service, mock_mcp_client):
        """Should take element screenshot."""
        mock_mcp_client.call_tool.return_value = {
            "data": b"element-image",
            "width": 500,
            "height": 300,
        }

        request = ScreenshotRequest(selector="#content")
        await browser_service.screenshot(request)

        call_args = mock_mcp_client.call_tool.call_args
        assert call_args[0][1]["selector"] == "#content"

    @pytest.mark.asyncio
    async def test_screenshot_jpeg_quality(self, browser_service, mock_mcp_client):
        """Should include quality for JPEG format."""
        mock_mcp_client.call_tool.return_value = {
            "data": b"jpeg-image",
            "width": 800,
            "height": 600,
        }

        request = ScreenshotRequest(format="jpeg", quality=90)
        await browser_service.screenshot(request)

        call_args = mock_mcp_client.call_tool.call_args
        assert call_args[0][1]["quality"] == 90

    @pytest.mark.asyncio
    async def test_screenshot_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on screenshot failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Page not loaded")

        request = ScreenshotRequest()
        with pytest.raises(BrowserError, match="Screenshot failed"):
            await browser_service.screenshot(request)


class TestGetText:
    """Tests for get_text method."""

    @pytest.mark.asyncio
    async def test_get_text_success(self, browser_service, mock_mcp_client):
        """Should get text content successfully."""
        mock_mcp_client.call_tool.return_value = {"text": "Hello World"}

        result = await browser_service.get_text("#heading")

        assert result == "Hello World"
        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_get_text",
            {"selector": "#heading"},
        )

    @pytest.mark.asyncio
    async def test_get_text_empty(self, browser_service, mock_mcp_client):
        """Should return empty string for empty element."""
        mock_mcp_client.call_tool.return_value = {"text": ""}

        result = await browser_service.get_text("#empty")
        assert result == ""

    @pytest.mark.asyncio
    async def test_get_text_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Element not found")

        with pytest.raises(BrowserError, match="Get text failed"):
            await browser_service.get_text("#missing")


class TestGetHTML:
    """Tests for get_html method."""

    @pytest.mark.asyncio
    async def test_get_html_full_page(self, browser_service, mock_mcp_client):
        """Should get full page HTML."""
        mock_mcp_client.call_tool.return_value = {"html": "<html><body></body></html>"}

        result = await browser_service.get_html()

        assert result == "<html><body></body></html>"
        mock_mcp_client.call_tool.assert_called_once_with("playwright_get_html", {})

    @pytest.mark.asyncio
    async def test_get_html_element(self, browser_service, mock_mcp_client):
        """Should get element HTML."""
        mock_mcp_client.call_tool.return_value = {"html": "<div>Content</div>"}

        result = await browser_service.get_html("#content")

        assert result == "<div>Content</div>"
        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_get_html",
            {"selector": "#content"},
        )

    @pytest.mark.asyncio
    async def test_get_html_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserError on failure."""
        mock_mcp_client.call_tool.side_effect = Exception("Parse error")

        with pytest.raises(BrowserError, match="Get HTML failed"):
            await browser_service.get_html()


class TestWaitForSelector:
    """Tests for wait_for_selector method."""

    @pytest.mark.asyncio
    async def test_wait_success(self, browser_service, mock_mcp_client):
        """Should wait for selector successfully."""
        mock_mcp_client.call_tool.return_value = {}

        await browser_service.wait_for_selector("#loading-done")

        mock_mcp_client.call_tool.assert_called_once_with(
            "playwright_wait_for_selector",
            {"selector": "#loading-done", "timeout": 30000},
        )

    @pytest.mark.asyncio
    async def test_wait_custom_timeout(self, browser_service, mock_mcp_client):
        """Should use custom timeout."""
        mock_mcp_client.call_tool.return_value = {}

        await browser_service.wait_for_selector("#element", timeout_ms=10000)

        call_args = mock_mcp_client.call_tool.call_args
        assert call_args[0][1]["timeout"] == 10000

    @pytest.mark.asyncio
    async def test_wait_timeout_error(self, browser_service, mock_mcp_client):
        """Should raise BrowserTimeoutError on timeout."""
        mock_mcp_client.call_tool.side_effect = Exception("Timeout")

        with pytest.raises(BrowserTimeoutError, match="Element not found"):
            await browser_service.wait_for_selector("#never-appears")


class TestGeneratePDF:
    """Tests for generate_pdf method."""

    @pytest.mark.asyncio
    async def test_generate_pdf_success(self, browser_service, mock_mcp_client):
        """Should generate PDF successfully."""
        # Mock navigation and PDF generation
        mock_mcp_client.call_tool.side_effect = [
            {"title": "Test Page"},  # navigate call
            {"data": b"pdf-data", "pageCount": 3},  # pdf call
        ]

        request = PDFRequest(url="https://example.com")
        result = await browser_service.generate_pdf(request)

        assert result.data == b"pdf-data"
        assert result.page_count == 3
        assert result.size_bytes == 8  # len(b"pdf-data")

    @pytest.mark.asyncio
    async def test_generate_pdf_landscape(self, browser_service, mock_mcp_client):
        """Should generate landscape PDF."""
        mock_mcp_client.call_tool.side_effect = [
            {"title": "Test Page"},
            {"data": b"landscape-pdf", "pageCount": 1},
        ]

        request = PDFRequest(url="https://example.com", landscape=True)
        await browser_service.generate_pdf(request)

        # Check PDF call parameters
        pdf_call = mock_mcp_client.call_tool.call_args_list[1]
        assert pdf_call[0][1]["landscape"] is True

    @pytest.mark.asyncio
    async def test_generate_pdf_custom_margins(self, browser_service, mock_mcp_client):
        """Should use custom margins."""
        mock_mcp_client.call_tool.side_effect = [
            {"title": "Test Page"},
            {"data": b"pdf-data", "pageCount": 1},
        ]

        request = PDFRequest(
            url="https://example.com",
            margin_top="2cm",
            margin_bottom="2cm",
        )
        await browser_service.generate_pdf(request)

        pdf_call = mock_mcp_client.call_tool.call_args_list[1]
        assert pdf_call[0][1]["margin"]["top"] == "2cm"
        assert pdf_call[0][1]["margin"]["bottom"] == "2cm"

    @pytest.mark.asyncio
    async def test_generate_pdf_navigation_error(
        self, browser_service, mock_mcp_client
    ):
        """Should propagate navigation errors."""
        mock_mcp_client.call_tool.side_effect = Exception("Network error")

        request = PDFRequest(url="https://example.com")
        with pytest.raises(BrowserError, match="Navigation failed"):
            await browser_service.generate_pdf(request)

    @pytest.mark.asyncio
    async def test_generate_pdf_generation_error(
        self, browser_service, mock_mcp_client
    ):
        """Should handle PDF generation errors."""
        mock_mcp_client.call_tool.side_effect = [
            {"title": "Test Page"},  # navigate succeeds
            Exception("PDF generation failed"),  # pdf fails
        ]

        request = PDFRequest(url="https://example.com")
        with pytest.raises(BrowserError, match="PDF generation failed"):
            await browser_service.generate_pdf(request)
