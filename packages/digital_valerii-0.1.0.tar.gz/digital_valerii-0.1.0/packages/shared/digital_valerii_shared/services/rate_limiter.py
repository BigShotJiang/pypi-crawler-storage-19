"""Rate limiting service using Redis sliding window algorithm.

Provides rate limiting for external API calls with support for:
- Requests per minute (RPM) limits using sliding window
- Tokens per minute (TPM) limits using atomic counters
- Configuration via environment variables
- Atomic operations via Lua scripts
"""

import asyncio
import os
import time
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

import structlog
from pydantic import BaseModel, ConfigDict, Field
from redis.exceptions import RedisError as BaseRedisError

from .redis import RedisNamespace, RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class RateLimitError(Exception):
    """Base exception for rate limit operations."""

    pass


class RateLimitExceeded(RateLimitError):
    """Raised when rate limit is exceeded."""

    def __init__(self, service: str, retry_after: float) -> None:
        """Initialize with service name and retry delay.

        Args:
            service: Name of the rate-limited service.
            retry_after: Seconds to wait before retrying.
        """
        self.service = service
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded for {service}. Retry after {retry_after:.2f}s"
        )


class RateLimitTimeout(RateLimitError):
    """Raised when wait_and_acquire times out."""

    def __init__(self, service: str, timeout: float) -> None:
        """Initialize with service name and timeout.

        Args:
            service: Name of the rate-limited service.
            timeout: The timeout that was exceeded.
        """
        self.service = service
        self.timeout = timeout
        super().__init__(
            f"Timed out waiting for rate limit on {service} after {timeout:.2f}s"
        )


# =============================================================================
# Pydantic Models
# =============================================================================


class RateLimitConfig(BaseModel):
    """Configuration for a single service's rate limits."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    rpm: int = Field(..., gt=0, description="Requests per minute limit")
    tpm: int | None = Field(
        default=None, gt=0, description="Tokens per minute limit (optional)"
    )
    burst_multiplier: float = Field(
        default=1.0, ge=1.0, le=2.0, description="Allow burst above limit temporarily"
    )


class RateLimitResult(BaseModel):
    """Result of a rate limit check."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    allowed: bool = Field(..., description="Whether the request is allowed")
    remaining_requests: int = Field(
        ..., ge=0, description="Remaining requests in current window"
    )
    remaining_tokens: int | None = Field(
        default=None, ge=0, description="Remaining tokens in current window"
    )
    reset_at: datetime = Field(..., description="When the rate limit window resets")
    retry_after: float | None = Field(
        default=None, ge=0, description="Seconds to wait if not allowed"
    )


class RateLimitStatus(BaseModel):
    """Status of rate limits for a service."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    service: str = Field(..., description="Service name")
    rpm_limit: int = Field(..., gt=0, description="RPM limit configured")
    rpm_used: int = Field(..., ge=0, description="RPM currently used")
    rpm_remaining: int = Field(..., ge=0, description="RPM remaining")
    tpm_limit: int | None = Field(default=None, description="TPM limit configured")
    tpm_used: int | None = Field(default=None, description="TPM currently used")
    tpm_remaining: int | None = Field(default=None, description="TPM remaining")
    window_resets_at: datetime = Field(..., description="When the window resets")


# =============================================================================
# Default Configurations (from ARCHITECTURE.md Section 6.3)
# =============================================================================


DEFAULT_RATE_LIMITS: dict[str, RateLimitConfig] = {
    "anthropic": RateLimitConfig(rpm=4000, tpm=400000),
    "voyage": RateLimitConfig(rpm=300, tpm=1000000),
    "microsoft_graph": RateLimitConfig(rpm=10000),
    "slack": RateLimitConfig(rpm=100),
    "elevenlabs": RateLimitConfig(rpm=100),
    "heygen": RateLimitConfig(rpm=60),
}


# =============================================================================
# Lua Scripts for Atomic Operations
# =============================================================================


# Atomic sliding window check and add for RPM
# KEYS[1] = rate limit key (sorted set)
# ARGV[1] = current timestamp (seconds with ms precision)
# ARGV[2] = window start timestamp
# ARGV[3] = limit
# ARGV[4] = request ID
# Returns: {allowed (0/1), current_count}
SLIDING_WINDOW_SCRIPT = """
local key = KEYS[1]
local now = tonumber(ARGV[1])
local window_start = tonumber(ARGV[2])
local limit = tonumber(ARGV[3])
local request_id = ARGV[4]

-- Remove entries outside the window
redis.call('ZREMRANGEBYSCORE', key, 0, window_start)

-- Count current entries
local count = redis.call('ZCARD', key)

if count < limit then
    -- Add new entry with timestamp as score
    redis.call('ZADD', key, now, request_id)
    -- Set TTL on key (window_seconds + buffer)
    redis.call('EXPIRE', key, 70)
    return {1, count + 1}
else
    return {0, count}
end
"""

# Atomic token increment with limit check
# KEYS[1] = token counter key
# ARGV[1] = tokens to add
# ARGV[2] = limit
# ARGV[3] = ttl (seconds)
# Returns: {allowed (0/1), new_count}
TOKEN_INCREMENT_SCRIPT = """
local key = KEYS[1]
local tokens = tonumber(ARGV[1])
local limit = tonumber(ARGV[2])
local ttl = tonumber(ARGV[3])

local current = tonumber(redis.call('GET', key) or 0)

if current + tokens <= limit then
    local new_count = redis.call('INCRBY', key, tokens)
    -- Set TTL if this is a new key or refresh it
    if new_count == tokens then
        redis.call('EXPIRE', key, ttl)
    end
    return {1, new_count}
else
    return {0, current}
end
"""


# =============================================================================
# Constants
# =============================================================================


WINDOW_SECONDS = 60  # 1 minute window
WINDOW_TTL = 70  # TTL with buffer


# =============================================================================
# RateLimiter Service
# =============================================================================


class RateLimiter:
    """Rate limiter using Redis sliding window algorithm.

    Provides rate limiting for external API calls with support for both
    RPM (requests per minute) and TPM (tokens per minute) limits.

    Features:
    - Sliding window algorithm for accurate rate limiting
    - Token tracking for LLM API calls
    - Configuration via environment variables
    - Atomic Redis operations via Lua scripts
    - Health check integration

    Example:
        redis = RedisService(settings)
        await redis.connect()

        limiter = RateLimiter(redis)

        # Check if request is allowed
        result = await limiter.check("anthropic", tokens=1000)
        if result.allowed:
            # Make API call
            pass

        # Or use acquire which raises on limit exceeded
        try:
            await limiter.acquire("anthropic", tokens=1000)
            # Make API call
        except RateLimitExceeded as e:
            await asyncio.sleep(e.retry_after)

        # Or wait until allowed
        await limiter.wait_and_acquire("anthropic", tokens=1000, timeout=30.0)
    """

    def __init__(
        self,
        redis: RedisService,
        configs: dict[str, RateLimitConfig] | None = None,
    ) -> None:
        """Initialize rate limiter with Redis service.

        Args:
            redis: Connected RedisService instance.
            configs: Custom rate limit configurations. If None, uses defaults
                     with environment variable overrides.
        """
        self._redis = redis
        self._configs = self._load_configs(configs)
        self._sliding_window_script: Any = None
        self._token_increment_script: Any = None
        self._scripts_registered = False

    def _load_configs(
        self, custom_configs: dict[str, RateLimitConfig] | None
    ) -> dict[str, RateLimitConfig]:
        """Load configurations with environment variable overrides.

        Environment variables format:
        - RATE_LIMIT_{SERVICE}_RPM: Override RPM limit
        - RATE_LIMIT_{SERVICE}_TPM: Override TPM limit

        Args:
            custom_configs: Custom configurations to use as base.

        Returns:
            Final configuration dictionary.
        """
        base_configs = (
            custom_configs if custom_configs is not None else DEFAULT_RATE_LIMITS.copy()
        )
        final_configs: dict[str, RateLimitConfig] = {}

        for service, config in base_configs.items():
            # Check for environment variable overrides
            rpm_override = os.environ.get(f"RATE_LIMIT_{service.upper()}_RPM")
            tpm_override = os.environ.get(f"RATE_LIMIT_{service.upper()}_TPM")

            if rpm_override is not None or tpm_override is not None:
                # Create new config with overrides
                new_rpm = int(rpm_override) if rpm_override else config.rpm
                new_tpm = int(tpm_override) if tpm_override else config.tpm

                final_configs[service] = RateLimitConfig(
                    rpm=new_rpm,
                    tpm=new_tpm,
                    burst_multiplier=config.burst_multiplier,
                )
            else:
                final_configs[service] = config

        return final_configs

    async def _ensure_scripts_registered(self) -> None:
        """Register Lua scripts if not already done."""
        if self._scripts_registered:
            return

        client = self._redis.client
        self._sliding_window_script = client.register_script(SLIDING_WINDOW_SCRIPT)
        self._token_increment_script = client.register_script(TOKEN_INCREMENT_SCRIPT)
        self._scripts_registered = True

    def _get_config(self, service: str) -> RateLimitConfig:
        """Get configuration for a service.

        Args:
            service: Service name.

        Returns:
            Rate limit configuration.

        Raises:
            RateLimitError: If service is not configured.
        """
        config = self._configs.get(service)
        if config is None:
            raise RateLimitError(f"No rate limit configuration for service: {service}")
        return config

    def _make_rpm_key(self, service: str) -> str:
        """Create Redis key for RPM tracking.

        Args:
            service: Service name.

        Returns:
            Full Redis key.
        """
        return f"{RedisNamespace.RATE_LIMIT.value}{service}:rpm"

    def _make_tpm_key(self, service: str) -> str:
        """Create Redis key for TPM tracking.

        Args:
            service: Service name.

        Returns:
            Full Redis key.
        """
        return f"{RedisNamespace.RATE_LIMIT.value}{service}:tpm"

    def _get_window_reset_time(self) -> datetime:
        """Calculate when the current window resets.

        Returns:
            DateTime when window resets (now + remaining seconds).
        """
        now = time.time()
        # Window resets at the next minute boundary
        seconds_into_window = now % WINDOW_SECONDS
        seconds_until_reset = WINDOW_SECONDS - seconds_into_window
        reset_timestamp = now + seconds_until_reset
        return datetime.fromtimestamp(reset_timestamp, tz=UTC)

    async def _get_oldest_entry_timestamp(self, rpm_key: str) -> float | None:
        """Get timestamp of oldest entry in sliding window.

        Args:
            rpm_key: Redis key for RPM sorted set.

        Returns:
            Oldest entry timestamp, or None if no entries.
        """
        client = self._redis.client
        oldest_entries = await client.zrange(rpm_key, 0, 0, withscores=True)

        if oldest_entries:
            return oldest_entries[0][1]
        return None

    async def _calculate_retry_after(self, rpm_key: str, now: float) -> float:
        """Calculate accurate retry_after from oldest ZSET entry.

        Args:
            rpm_key: Redis key for RPM sorted set.
            now: Current timestamp.

        Returns:
            Seconds until a slot opens (minimum 0.1).
        """
        oldest_timestamp = await self._get_oldest_entry_timestamp(rpm_key)

        if oldest_timestamp is not None:
            return max(0.1, (oldest_timestamp + WINDOW_SECONDS) - now)
        else:
            # Fallback to minute boundary
            return WINDOW_SECONDS - (now % WINDOW_SECONDS)

    async def check(self, service: str, tokens: int = 1) -> RateLimitResult:
        """Check if a request is within rate limits without consuming quota.

        Args:
            service: Service name to check.
            tokens: Number of tokens for this request (must be positive).

        Returns:
            RateLimitResult with allowed status and remaining quota.

        Raises:
            ValueError: If tokens is not a positive integer.
            RateLimitError: If service is not configured or Redis error.
        """
        if not isinstance(tokens, int) or tokens < 1:
            raise ValueError(f"tokens must be a positive integer, got: {tokens}")

        await self._ensure_scripts_registered()
        config = self._get_config(service)

        try:
            # Check RPM using sliding window
            rpm_key = self._make_rpm_key(service)
            now = time.time()
            window_start = now - WINDOW_SECONDS

            client = self._redis.client

            # Get current RPM count (without adding)
            await client.zremrangebyscore(rpm_key, 0, window_start)
            rpm_count = await client.zcard(rpm_key)
            rpm_limit = int(config.rpm * config.burst_multiplier)
            rpm_allowed = rpm_count < rpm_limit
            rpm_remaining = max(0, rpm_limit - rpm_count)

            # Get oldest entry for accurate retry_after calculation
            oldest_entries = await client.zrange(rpm_key, 0, 0, withscores=True)

            # Check TPM if configured
            tpm_allowed = True
            tpm_remaining: int | None = None

            if config.tpm is not None:
                tpm_key = self._make_tpm_key(service)
                tpm_count_str = await client.get(tpm_key)
                try:
                    tpm_count = int(tpm_count_str) if tpm_count_str else 0
                except (TypeError, ValueError) as e:
                    raise RateLimitError(
                        f"Malformed TPM counter for {service}: {tpm_count_str}"
                    ) from e
                tpm_limit = int(config.tpm * config.burst_multiplier)
                tpm_allowed = (tpm_count + tokens) <= tpm_limit
                tpm_remaining = max(0, tpm_limit - tpm_count)

            # Both must be allowed
            allowed = rpm_allowed and tpm_allowed

            # Calculate retry_after from oldest entry for sliding window accuracy
            retry_after: float | None = None
            if not allowed and oldest_entries:
                oldest_timestamp = oldest_entries[0][1]  # Score is timestamp
                # When oldest entry expires, a slot opens
                retry_after = max(0.0, (oldest_timestamp + WINDOW_SECONDS) - now)
            elif not allowed:
                # Fallback if no entries (shouldn't happen when blocked)
                retry_after = WINDOW_SECONDS - (now % WINDOW_SECONDS)

            # Calculate reset_at from oldest entry for sliding window accuracy
            if oldest_entries:
                oldest_timestamp = oldest_entries[0][1]
                reset_timestamp = oldest_timestamp + WINDOW_SECONDS
            else:
                reset_timestamp = now + WINDOW_SECONDS

            return RateLimitResult(
                allowed=allowed,
                remaining_requests=rpm_remaining,
                remaining_tokens=tpm_remaining,
                reset_at=datetime.fromtimestamp(reset_timestamp, tz=UTC),
                retry_after=retry_after,
            )

        except RateLimitError:
            raise
        except BaseRedisError as e:
            raise RateLimitError(
                f"Redis error checking rate limit for {service}: {e}"
            ) from e

    async def acquire(self, service: str, tokens: int = 1) -> bool:
        """Acquire rate limit quota, consuming it if allowed.

        Args:
            service: Service name to acquire quota for.
            tokens: Number of tokens for this request (must be positive).

        Returns:
            True if quota was acquired.

        Raises:
            ValueError: If tokens is not a positive integer.
            RateLimitExceeded: If rate limit is exceeded.
            RateLimitError: If service is not configured or Redis error.
        """
        if not isinstance(tokens, int) or tokens < 1:
            raise ValueError(f"tokens must be a positive integer, got: {tokens}")

        await self._ensure_scripts_registered()
        config = self._get_config(service)

        try:
            now = time.time()
            window_start = now - WINDOW_SECONDS
            request_id = str(uuid4())

            rpm_key = self._make_rpm_key(service)
            rpm_limit = int(config.rpm * config.burst_multiplier)

            # Atomically check and add RPM
            rpm_result = await self._sliding_window_script(
                keys=[rpm_key],
                args=[str(now), str(window_start), str(rpm_limit), request_id],
            )
            rpm_allowed = rpm_result[0] == 1

            if not rpm_allowed:
                # Calculate accurate retry_after from oldest ZSET entry
                retry_after = await self._calculate_retry_after(rpm_key, now)
                raise RateLimitExceeded(service, retry_after)

            # Check and add TPM if configured
            if config.tpm is not None:
                tpm_key = self._make_tpm_key(service)
                tpm_limit = int(config.tpm * config.burst_multiplier)

                tpm_result = await self._token_increment_script(
                    keys=[tpm_key],
                    args=[str(tokens), str(tpm_limit), str(WINDOW_TTL)],
                )
                tpm_allowed = tpm_result[0] == 1

                if not tpm_allowed:
                    # Rollback RPM (remove the entry we just added)
                    client = self._redis.client
                    await client.zrem(rpm_key, request_id)

                    # Calculate accurate retry_after from oldest ZSET entry
                    retry_after = await self._calculate_retry_after(rpm_key, now)
                    raise RateLimitExceeded(service, retry_after)

            await logger.adebug(
                "Rate limit acquired",
                service=service,
                tokens=tokens,
            )
            return True

        except RateLimitExceeded:
            raise
        except BaseRedisError as e:
            raise RateLimitError(
                f"Redis error acquiring rate limit for {service}: {e}"
            ) from e

    async def wait_and_acquire(
        self,
        service: str,
        tokens: int = 1,
        timeout: float = 30.0,
    ) -> bool:
        """Wait until rate limit allows, then acquire quota.

        Args:
            service: Service name to acquire quota for.
            tokens: Number of tokens for this request (must be positive).
            timeout: Maximum time to wait in seconds.

        Returns:
            True if quota was acquired.

        Raises:
            ValueError: If tokens is not a positive integer.
            RateLimitTimeout: If timeout is exceeded.
            RateLimitError: If service is not configured or Redis error.
        """
        if not isinstance(tokens, int) or tokens < 1:
            raise ValueError(f"tokens must be a positive integer, got: {tokens}")

        start_time = time.time()

        while True:
            try:
                await self.acquire(service, tokens)
                return True
            except RateLimitExceeded as e:
                elapsed = time.time() - start_time
                remaining_timeout = timeout - elapsed

                if remaining_timeout <= 0:
                    raise RateLimitTimeout(service, timeout) from e

                # Wait for retry_after or remaining timeout, whichever is smaller
                wait_time = min(e.retry_after, remaining_timeout, 1.0)
                await asyncio.sleep(wait_time)

    async def get_status(self, service: str) -> RateLimitStatus:
        """Get current rate limit status for a service.

        Args:
            service: Service name to check.

        Returns:
            RateLimitStatus with current usage.

        Raises:
            RateLimitError: If service is not configured or Redis error.
        """
        config = self._get_config(service)

        try:
            client = self._redis.client
            now = time.time()
            window_start = now - WINDOW_SECONDS

            # Get RPM count
            rpm_key = self._make_rpm_key(service)
            await client.zremrangebyscore(rpm_key, 0, window_start)
            rpm_used = await client.zcard(rpm_key)
            rpm_remaining = max(0, config.rpm - rpm_used)

            # Get oldest entry for accurate window_resets_at
            oldest_timestamp = await self._get_oldest_entry_timestamp(rpm_key)
            if oldest_timestamp is not None:
                reset_timestamp = oldest_timestamp + WINDOW_SECONDS
            else:
                # No entries = window resets in future
                reset_timestamp = now + WINDOW_SECONDS
            window_resets_at = datetime.fromtimestamp(reset_timestamp, tz=UTC)

            # Get TPM count if configured
            tpm_used: int | None = None
            tpm_remaining: int | None = None

            if config.tpm is not None:
                tpm_key = self._make_tpm_key(service)
                tpm_count_str = await client.get(tpm_key)
                try:
                    tpm_used = int(tpm_count_str) if tpm_count_str else 0
                except (TypeError, ValueError) as e:
                    raise RateLimitError(
                        f"Malformed TPM counter for {service}: {tpm_count_str}"
                    ) from e
                tpm_remaining = max(0, config.tpm - tpm_used)

            return RateLimitStatus(
                service=service,
                rpm_limit=config.rpm,
                rpm_used=rpm_used,
                rpm_remaining=rpm_remaining,
                tpm_limit=config.tpm,
                tpm_used=tpm_used,
                tpm_remaining=tpm_remaining,
                window_resets_at=window_resets_at,
            )

        except RateLimitError:
            raise
        except BaseRedisError as e:
            raise RateLimitError(
                f"Redis error getting status for {service}: {e}"
            ) from e

    async def reset(self, service: str) -> None:
        """Reset rate limit counters for a service.

        Args:
            service: Service name to reset.

        Raises:
            RateLimitError: If service is not configured or Redis error.
        """
        config = self._get_config(service)

        try:
            client = self._redis.client
            rpm_key = self._make_rpm_key(service)

            # Delete RPM sorted set
            await client.delete(rpm_key)

            # Delete TPM counter if configured
            if config.tpm is not None:
                tpm_key = self._make_tpm_key(service)
                await client.delete(tpm_key)

            await logger.ainfo("Rate limit reset", service=service)

        except BaseRedisError as e:
            raise RateLimitError(
                f"Redis error resetting rate limit for {service}: {e}"
            ) from e

    async def health_check(self) -> dict[str, RateLimitStatus]:
        """Get rate limit status for all configured services.

        Returns:
            Dictionary mapping service names to their status.
        """
        result: dict[str, RateLimitStatus] = {}

        for service in self._configs:
            try:
                result[service] = await self.get_status(service)
            except RateLimitError:
                # Skip services that fail to get status
                continue

        return result

    def get_configured_services(self) -> list[str]:
        """Get list of configured service names.

        Returns:
            List of service names with rate limit configurations.
        """
        return list(self._configs.keys())

    def get_config(self, service: str) -> RateLimitConfig | None:
        """Get configuration for a service.

        Args:
            service: Service name.

        Returns:
            Configuration if found, None otherwise.
        """
        return self._configs.get(service)

    def add_config(self, service: str, config: RateLimitConfig) -> None:
        """Add or update configuration for a service.

        Args:
            service: Service name.
            config: Rate limit configuration.
        """
        self._configs[service] = config

    def remove_config(self, service: str) -> bool:
        """Remove configuration for a service.

        Args:
            service: Service name.

        Returns:
            True if removed, False if not found.
        """
        if service in self._configs:
            del self._configs[service]
            return True
        return False
