"""Archive Manager service for long-term memory archiving.

Component 4.9: Long-term Memory Architecture
Manages tiered memory with annual archiving and strategic memory extraction.
"""

import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import delete, func, insert, select, text

from ..database import Database
from ..models import Event
from ..models.archive import (
    ArchiveIndexEntry,
    ArchiveProgress,
    ArchiveResult,
    ArchivedEvent,
    MemoryType,
    StrategicMemory,
    YearlySummary,
)

if TYPE_CHECKING:
    from .embedding import EmbeddingService
    from .qdrant import QdrantService
    from .strategic_extractor import StrategicMemoryExtractor

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class ArchiveError(Exception):
    """Base exception for archive operations."""

    pass


class ArchiveNotFoundError(ArchiveError):
    """Raised when an archive is not found."""

    pass


class ArchiveExistsError(ArchiveError):
    """Raised when trying to archive a year that already exists."""

    pass


class ArchiveInProgressError(ArchiveError):
    """Raised when an archive operation is already in progress."""

    pass


# =============================================================================
# Internal Models
# =============================================================================


class ArchiveStats(BaseModel):
    """Statistics for an archived year."""

    model_config = ConfigDict(extra="forbid")

    event_count: int = Field(default=0, ge=0)
    message_count: int = Field(default=0, ge=0)
    project_count: int = Field(default=0, ge=0)
    people_count: int = Field(default=0, ge=0)
    lesson_count: int = Field(default=0, ge=0)
    decision_count: int = Field(default=0, ge=0)
    event_types: dict[str, int] = Field(default_factory=dict)
    months_active: list[int] = Field(default_factory=list)


# =============================================================================
# Constants
# =============================================================================

# Batch size for processing events
ARCHIVE_BATCH_SIZE = 100

# Maximum years allowed to archive at once
MAX_ARCHIVE_YEARS_AHEAD = 10


# =============================================================================
# ArchiveManager
# =============================================================================


class ArchiveManager:
    """Manages long-term memory archiving.

    Provides functionality for:
    - Archiving a full year's memories to cold storage
    - Managing archive index (metadata about archives)
    - Searching within archived years
    - Deleting archives and restoring to active memory

    Example:
        manager = ArchiveManager(db, qdrant, embedding)

        # Archive 2023
        result = await manager.archive_year(2023, user_id)

        # Search 2023 archive
        events = await manager.search_archive(2023, "project meeting", user_id)

        # List all archives
        archives = await manager.get_archive_index(user_id)
    """

    def __init__(
        self,
        db: Database,
        qdrant: "QdrantService",
        embedding: "EmbeddingService",
        strategic_extractor: "StrategicMemoryExtractor | None" = None,
    ) -> None:
        """Initialize the Archive Manager.

        Args:
            db: Database connection manager.
            qdrant: Qdrant vector database service.
            embedding: Embedding service for vector generation.
            strategic_extractor: Optional strategic memory extractor.
        """
        self._db = db
        self._qdrant = qdrant
        self._embedding = embedding
        self._strategic_extractor = strategic_extractor
        self._in_progress: set[tuple[int, UUID]] = set()

    def set_strategic_extractor(
        self, extractor: "StrategicMemoryExtractor"
    ) -> None:
        """Set the strategic memory extractor.

        Args:
            extractor: Strategic memory extractor instance.
        """
        self._strategic_extractor = extractor

    # =========================================================================
    # Archive Operations
    # =========================================================================

    async def archive_year(
        self,
        year: int,
        user_id: UUID,
        progress_callback: Any = None,
    ) -> ArchiveResult:
        """Archive a full year's memories for a user.

        This operation:
        1. Validates the year can be archived
        2. Extracts strategic memories (projects, people, lessons, decisions)
        3. Moves events to archived_events table
        4. Migrates vectors to archive collection in Qdrant
        5. Creates archive index entry with summary

        Args:
            year: The year to archive.
            user_id: User UUID.
            progress_callback: Optional callback for progress updates.

        Returns:
            ArchiveResult with operation details.

        Raises:
            ArchiveExistsError: If year already archived.
            ArchiveInProgressError: If archive operation in progress.
            ArchiveError: If archiving fails.
        """
        start_time = time.time()
        archive_key = (year, user_id)

        # Check if already in progress
        if archive_key in self._in_progress:
            raise ArchiveInProgressError(f"Archive for {year} already in progress")

        self._in_progress.add(archive_key)

        try:
            # Check if already archived
            existing = await self.get_archive(year, user_id)
            if existing:
                raise ArchiveExistsError(f"Year {year} already archived")

            # Validate year
            current_year = datetime.now(UTC).year
            if year > current_year:
                raise ArchiveError(f"Cannot archive future year {year}")
            if year < current_year - MAX_ARCHIVE_YEARS_AHEAD:
                raise ArchiveError(f"Year {year} is too far in the past")

            await logger.ainfo(
                "Starting archive operation",
                year=year,
                user_id=str(user_id),
            )

            # Step 1: Count and collect events for the year
            events = await self._get_events_for_year(year, user_id)
            total_events = len(events)

            if total_events == 0:
                raise ArchiveError(f"No events found for year {year}")

            if progress_callback:
                await progress_callback(
                    ArchiveProgress(
                        year=year,
                        phase="extracting",
                        events_processed=0,
                        events_total=total_events,
                        percent_complete=0.0,
                    )
                )

            # Step 2: Extract strategic memories (if extractor available)
            strategic_memories_created = 0
            summary = f"Archive for year {year}"
            key_achievements: list[str] = []

            if self._strategic_extractor:
                yearly_summary = await self._strategic_extractor.generate_yearly_summary(
                    year=year,
                    user_id=user_id,
                    events=events,
                )
                summary = yearly_summary.summary
                key_achievements = yearly_summary.key_achievements

                # Extract and save strategic memories
                strategic_memories = await self._strategic_extractor.extract_for_year(
                    year=year,
                    user_id=user_id,
                    events=events,
                )
                strategic_memories_created = await self._save_strategic_memories(
                    strategic_memories, user_id
                )

            # Step 3: Create archive collection in Qdrant
            collection_name = await self._create_archive_collection(year, user_id)

            if progress_callback:
                await progress_callback(
                    ArchiveProgress(
                        year=year,
                        phase="migrating",
                        events_processed=0,
                        events_total=total_events,
                        percent_complete=25.0,
                    )
                )

            # Step 4: Move events to archived_events table
            events_archived = await self._move_events_to_archive(
                year=year,
                user_id=user_id,
                events=events,
                collection_name=collection_name,
                progress_callback=progress_callback,
            )

            if progress_callback:
                await progress_callback(
                    ArchiveProgress(
                        year=year,
                        phase="summarizing",
                        events_processed=events_archived,
                        events_total=total_events,
                        percent_complete=90.0,
                    )
                )

            # Step 5: Calculate stats
            stats = await self._calculate_archive_stats(year, user_id, events)

            # Step 6: Create archive index entry
            await self._create_archive_index(
                year=year,
                user_id=user_id,
                stats=stats,
                summary=summary,
                key_achievements=key_achievements,
                collection_name=collection_name,
            )

            # Step 7: Soft-delete original events
            await self._soft_delete_original_events(year, user_id)

            duration = time.time() - start_time

            if progress_callback:
                await progress_callback(
                    ArchiveProgress(
                        year=year,
                        phase="complete",
                        events_processed=events_archived,
                        events_total=total_events,
                        percent_complete=100.0,
                    )
                )

            await logger.ainfo(
                "Archive operation complete",
                year=year,
                user_id=str(user_id),
                events_archived=events_archived,
                strategic_memories=strategic_memories_created,
                duration_seconds=duration,
            )

            return ArchiveResult(
                year=year,
                events_archived=events_archived,
                strategic_memories_created=strategic_memories_created,
                qdrant_collection=collection_name,
                summary=summary,
                key_achievements=key_achievements,
                duration_seconds=duration,
            )

        except Exception as e:
            await logger.aerror(
                "Archive operation failed",
                year=year,
                user_id=str(user_id),
                error=str(e),
            )
            raise

        finally:
            self._in_progress.discard(archive_key)

    async def get_archive_index(
        self,
        user_id: UUID,
    ) -> list[ArchiveIndexEntry]:
        """Get list of available archives for a user.

        Args:
            user_id: User UUID.

        Returns:
            List of archive index entries, sorted by year descending.
        """
        async with self._db.session() as session:
            stmt = text("""
                SELECT year, user_id, archived_at, event_count, message_count,
                       project_count, people_count, lesson_count, decision_count,
                       summary, key_achievements, qdrant_collection, size_bytes
                FROM archive_index
                WHERE user_id = :user_id
                ORDER BY year DESC
            """)
            result = await session.execute(stmt, {"user_id": user_id})
            rows = result.fetchall()

            return [
                ArchiveIndexEntry(
                    year=row.year,
                    user_id=row.user_id,
                    archived_at=row.archived_at,
                    event_count=row.event_count,
                    message_count=row.message_count or 0,
                    project_count=row.project_count or 0,
                    people_count=row.people_count or 0,
                    lesson_count=row.lesson_count or 0,
                    decision_count=row.decision_count or 0,
                    summary=row.summary,
                    key_achievements=row.key_achievements or [],
                    qdrant_collection=row.qdrant_collection,
                    size_bytes=row.size_bytes or 0,
                )
                for row in rows
            ]

    async def get_archive(
        self,
        year: int,
        user_id: UUID,
    ) -> ArchiveIndexEntry | None:
        """Get a specific archive by year.

        Args:
            year: The year to get.
            user_id: User UUID.

        Returns:
            ArchiveIndexEntry if found, None otherwise.
        """
        async with self._db.session() as session:
            stmt = text("""
                SELECT year, user_id, archived_at, event_count, message_count,
                       project_count, people_count, lesson_count, decision_count,
                       summary, key_achievements, qdrant_collection, size_bytes
                FROM archive_index
                WHERE year = :year AND user_id = :user_id
            """)
            result = await session.execute(stmt, {"year": year, "user_id": user_id})
            row = result.fetchone()

            if not row:
                return None

            return ArchiveIndexEntry(
                year=row.year,
                user_id=row.user_id,
                archived_at=row.archived_at,
                event_count=row.event_count,
                message_count=row.message_count or 0,
                project_count=row.project_count or 0,
                people_count=row.people_count or 0,
                lesson_count=row.lesson_count or 0,
                decision_count=row.decision_count or 0,
                summary=row.summary,
                key_achievements=row.key_achievements or [],
                qdrant_collection=row.qdrant_collection,
                size_bytes=row.size_bytes or 0,
            )

    async def search_archive(
        self,
        year: int,
        query: str,
        user_id: UUID,
        limit: int = 20,
        event_types: list[str] | None = None,
    ) -> list[ArchivedEvent]:
        """Search within a specific year's archive.

        Uses semantic search via Qdrant, then retrieves full event data
        from archived_events table.

        Args:
            year: Year to search.
            query: Search query string.
            user_id: User UUID.
            limit: Maximum results to return.
            event_types: Optional filter for event types.

        Returns:
            List of archived events matching the query.

        Raises:
            ArchiveNotFoundError: If archive doesn't exist.
        """
        # Verify archive exists
        archive = await self.get_archive(year, user_id)
        if not archive:
            raise ArchiveNotFoundError(f"No archive found for year {year}")

        # Generate query embedding
        query_embedding = await self._embedding.embed(query)

        # Search archive collection using archive-specific method
        filter_conditions: dict[str, Any] = {"user_id": str(user_id)}
        if event_types:
            filter_conditions["event_type"] = {"$in": event_types}

        search_results = await self._qdrant.search_archive_collection(
            collection_name=archive.qdrant_collection,
            query_vector=query_embedding,
            limit=limit,
            filter_conditions=filter_conditions,
        )

        if not search_results:
            return []

        # Retrieve full event data from PostgreSQL
        event_ids = [r.id for r in search_results]
        return await self._get_archived_events_by_ids(year, event_ids, user_id)

    async def delete_archive(
        self,
        year: int,
        user_id: UUID,
        restore_to_active: bool = False,
    ) -> bool:
        """Delete a year's archive.

        Args:
            year: Year to delete.
            user_id: User UUID.
            restore_to_active: If True, restore events to active memory.

        Returns:
            True if deleted successfully.

        Raises:
            ArchiveNotFoundError: If archive doesn't exist.
        """
        archive = await self.get_archive(year, user_id)
        if not archive:
            raise ArchiveNotFoundError(f"No archive found for year {year}")

        await logger.ainfo(
            "Deleting archive",
            year=year,
            user_id=str(user_id),
            restore=restore_to_active,
        )

        try:
            if restore_to_active:
                # Restore events from archive to active
                await self._restore_events_to_active(year, user_id)

            # Delete Qdrant archive collection using archive-specific method
            await self._qdrant.delete_archive_collection(archive.qdrant_collection)

            # Delete archived events
            async with self._db.session() as session:
                await session.execute(
                    text("""
                        DELETE FROM archived_events
                        WHERE year = :year AND user_id = :user_id
                    """),
                    {"year": year, "user_id": user_id},
                )

            # Delete strategic memories for this year
            async with self._db.session() as session:
                await session.execute(
                    text("""
                        DELETE FROM strategic_memories
                        WHERE year = :year AND user_id = :user_id
                    """),
                    {"year": year, "user_id": user_id},
                )

            # Delete archive index entry
            async with self._db.session() as session:
                await session.execute(
                    text("""
                        DELETE FROM archive_index
                        WHERE year = :year AND user_id = :user_id
                    """),
                    {"year": year, "user_id": user_id},
                )

            await logger.ainfo(
                "Archive deleted successfully",
                year=year,
                user_id=str(user_id),
            )

            return True

        except Exception as e:
            await logger.aerror(
                "Failed to delete archive",
                year=year,
                user_id=str(user_id),
                error=str(e),
            )
            raise ArchiveError(f"Failed to delete archive: {e}") from e

    # =========================================================================
    # Strategic Memory Operations
    # =========================================================================

    async def get_strategic_memories(
        self,
        user_id: UUID,
        year: int | None = None,
        memory_type: MemoryType | None = None,
        limit: int = 50,
    ) -> list[StrategicMemory]:
        """Get strategic memories for a user.

        Args:
            user_id: User UUID.
            year: Optional year filter.
            memory_type: Optional memory type filter.
            limit: Maximum results.

        Returns:
            List of strategic memories.
        """
        async with self._db.session() as session:
            query = """
                SELECT id, user_id, year, memory_type, entity_id, title, summary,
                       keywords, importance, related_entities, metadata, created_at
                FROM strategic_memories
                WHERE user_id = :user_id
            """
            params: dict[str, Any] = {"user_id": user_id}

            if year:
                query += " AND year = :year"
                params["year"] = year

            if memory_type:
                query += " AND memory_type = :memory_type"
                params["memory_type"] = memory_type.value

            query += " ORDER BY importance DESC, created_at DESC LIMIT :limit"
            params["limit"] = limit

            result = await session.execute(text(query), params)
            rows = result.fetchall()

            return [
                StrategicMemory(
                    id=row.id,
                    user_id=row.user_id,
                    year=row.year,
                    memory_type=MemoryType(row.memory_type),
                    entity_id=row.entity_id,
                    title=row.title,
                    summary=row.summary,
                    keywords=row.keywords or [],
                    importance=row.importance,
                    related_entities=row.related_entities,
                    metadata=row.metadata,
                    created_at=row.created_at,
                )
                for row in rows
            ]

    # =========================================================================
    # Partition Management
    # =========================================================================

    async def ensure_partition_exists(self, year: int) -> None:
        """Ensure a partition exists for the given year.

        Creates a new partition table if it doesn't exist.

        Args:
            year: Year to create partition for.
        """
        async with self._db.session() as session:
            partition_name = f"archived_events_{year}"

            # Check if partition exists
            check_stmt = text("""
                SELECT 1 FROM pg_tables
                WHERE schemaname = 'public' AND tablename = :partition_name
            """)
            result = await session.execute(check_stmt, {"partition_name": partition_name})

            if result.fetchone():
                return  # Partition already exists

            # Create partition
            create_stmt = text(f"""
                CREATE TABLE {partition_name}
                PARTITION OF archived_events
                FOR VALUES IN ({year})
            """)
            await session.execute(create_stmt)

            await logger.ainfo(
                "Created archive partition",
                partition=partition_name,
                year=year,
            )

    # =========================================================================
    # Private Helper Methods
    # =========================================================================

    async def _get_events_for_year(
        self,
        year: int,
        user_id: UUID,
    ) -> list[Event]:
        """Get all events for a specific year."""
        async with self._db.session() as session:
            stmt = (
                select(Event)
                .where(Event.user_id == user_id)
                .where(func.extract("year", Event.occurred_at) == year)
                .where(Event.deleted_at.is_(None))
                .order_by(Event.occurred_at)
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def _create_archive_collection(
        self,
        year: int,
        user_id: UUID,
    ) -> str:
        """Create a Qdrant collection for the archive year."""
        # Use the proper Qdrant service method
        collection_name = await self._qdrant.create_archive_collection(year, user_id)

        await logger.ainfo(
            "Archive collection ready",
            collection=collection_name,
        )

        return collection_name

    async def _move_events_to_archive(
        self,
        year: int,
        user_id: UUID,
        events: list[Event],
        collection_name: str,
        progress_callback: Any = None,
    ) -> int:
        """Move events to archived_events table and Qdrant archive collection."""
        # Ensure partition exists
        await self.ensure_partition_exists(year)

        archived_count = 0

        for i in range(0, len(events), ARCHIVE_BATCH_SIZE):
            batch = events[i : i + ARCHIVE_BATCH_SIZE]

            # Insert into archived_events
            async with self._db.session() as session:
                for event in batch:
                    stmt = text("""
                        INSERT INTO archived_events
                        (id, user_id, year, original_id, event_type, title, content,
                         occurred_at, source, conversation_id, importance, metadata,
                         embedding_id, archived_at)
                        VALUES
                        (:id, :user_id, :year, :original_id, :event_type, :title,
                         :content, :occurred_at, :source, :conversation_id, :importance,
                         :metadata, :embedding_id, :archived_at)
                    """)
                    await session.execute(
                        stmt,
                        {
                            "id": event.id,
                            "user_id": user_id,
                            "year": year,
                            "original_id": event.id,
                            "event_type": event.type,
                            "title": event.title,
                            "content": event.content or event.summary,
                            "occurred_at": event.occurred_at,
                            "source": event.source,
                            "conversation_id": event.conversation_id,
                            "importance": event.importance,
                            "metadata": event.metadata_,
                            "embedding_id": str(event.id),
                            "archived_at": datetime.now(UTC),
                        },
                    )

            archived_count += len(batch)

            # Migrate vectors to archive collection
            vector_ids = [e.id for e in batch]
            await self._qdrant.migrate_vectors_to_archive(
                source_collection="memories",
                target_collection=collection_name,
                vector_ids=vector_ids,
            )

            if progress_callback:
                percent = 25.0 + (archived_count / len(events) * 65.0)
                await progress_callback(
                    ArchiveProgress(
                        year=year,
                        phase="migrating",
                        events_processed=archived_count,
                        events_total=len(events),
                        percent_complete=percent,
                    )
                )

        return archived_count

    async def _save_strategic_memories(
        self,
        memories: list[StrategicMemory],
        user_id: UUID,
    ) -> int:
        """Save strategic memories to database."""
        if not memories:
            return 0

        async with self._db.session() as session:
            for memory in memories:
                stmt = text("""
                    INSERT INTO strategic_memories
                    (id, user_id, year, memory_type, entity_id, title, summary,
                     keywords, importance, related_entities, metadata, created_at)
                    VALUES
                    (:id, :user_id, :year, :memory_type, :entity_id, :title,
                     :summary, :keywords, :importance, :related_entities,
                     :metadata, :created_at)
                """)
                await session.execute(
                    stmt,
                    {
                        "id": memory.id,
                        "user_id": user_id,
                        "year": memory.year,
                        "memory_type": memory.memory_type.value,
                        "entity_id": memory.entity_id,
                        "title": memory.title,
                        "summary": memory.summary,
                        "keywords": memory.keywords,
                        "importance": memory.importance,
                        "related_entities": memory.related_entities,
                        "metadata": memory.metadata,
                        "created_at": memory.created_at,
                    },
                )

        return len(memories)

    async def _calculate_archive_stats(
        self,
        year: int,
        user_id: UUID,
        events: list[Event],
    ) -> ArchiveStats:
        """Calculate statistics for the archive."""
        event_types: dict[str, int] = {}
        months_active: set[int] = set()

        for event in events:
            event_types[event.type] = event_types.get(event.type, 0) + 1
            if event.occurred_at:
                months_active.add(event.occurred_at.month)

        return ArchiveStats(
            event_count=len(events),
            message_count=event_types.get("message", 0),
            project_count=event_types.get("project", 0),
            people_count=event_types.get("person", 0),
            lesson_count=event_types.get("lesson", 0),
            decision_count=event_types.get("decision", 0),
            event_types=event_types,
            months_active=sorted(months_active),
        )

    async def _create_archive_index(
        self,
        year: int,
        user_id: UUID,
        stats: ArchiveStats,
        summary: str,
        key_achievements: list[str],
        collection_name: str,
    ) -> None:
        """Create archive index entry."""
        async with self._db.session() as session:
            stmt = text("""
                INSERT INTO archive_index
                (year, user_id, archived_at, event_count, message_count,
                 project_count, people_count, lesson_count, decision_count,
                 summary, key_achievements, stats, qdrant_collection, size_bytes)
                VALUES
                (:year, :user_id, :archived_at, :event_count, :message_count,
                 :project_count, :people_count, :lesson_count, :decision_count,
                 :summary, :key_achievements, :stats, :qdrant_collection, :size_bytes)
            """)
            await session.execute(
                stmt,
                {
                    "year": year,
                    "user_id": user_id,
                    "archived_at": datetime.now(UTC),
                    "event_count": stats.event_count,
                    "message_count": stats.message_count,
                    "project_count": stats.project_count,
                    "people_count": stats.people_count,
                    "lesson_count": stats.lesson_count,
                    "decision_count": stats.decision_count,
                    "summary": summary,
                    "key_achievements": key_achievements,
                    "stats": stats.model_dump(),
                    "qdrant_collection": collection_name,
                    "size_bytes": 0,  # Will be calculated later
                },
            )

    async def _soft_delete_original_events(
        self,
        year: int,
        user_id: UUID,
    ) -> None:
        """Soft delete original events after archiving."""
        async with self._db.session() as session:
            stmt = text("""
                UPDATE events
                SET deleted_at = :deleted_at
                WHERE user_id = :user_id
                AND EXTRACT(year FROM occurred_at) = :year
                AND deleted_at IS NULL
            """)
            await session.execute(
                stmt,
                {
                    "deleted_at": datetime.now(UTC),
                    "user_id": user_id,
                    "year": year,
                },
            )

    async def _get_archived_events_by_ids(
        self,
        year: int,
        event_ids: list[UUID],
        user_id: UUID,
    ) -> list[ArchivedEvent]:
        """Get archived events by IDs."""
        if not event_ids:
            return []

        async with self._db.session() as session:
            # Convert UUIDs to strings for the query
            id_list = ", ".join(f"'{str(id)}'::uuid" for id in event_ids)
            stmt = text(f"""
                SELECT id, year, user_id, original_id, event_type, title, content,
                       occurred_at, source, conversation_id, importance, embedding_id,
                       archived_at
                FROM archived_events
                WHERE year = :year
                AND user_id = :user_id
                AND id IN ({id_list})
            """)
            result = await session.execute(stmt, {"year": year, "user_id": user_id})
            rows = result.fetchall()

            return [
                ArchivedEvent(
                    id=row.id,
                    year=row.year,
                    user_id=row.user_id,
                    original_id=row.original_id,
                    event_type=row.event_type,
                    title=row.title,
                    content=row.content,
                    occurred_at=row.occurred_at,
                    source=row.source,
                    conversation_id=row.conversation_id,
                    importance=row.importance,
                    embedding_id=row.embedding_id,
                    archived_at=row.archived_at,
                )
                for row in rows
            ]

    async def _restore_events_to_active(
        self,
        year: int,
        user_id: UUID,
    ) -> int:
        """Restore archived events back to active memory."""
        async with self._db.session() as session:
            # Undelete original events
            stmt = text("""
                UPDATE events
                SET deleted_at = NULL
                WHERE user_id = :user_id
                AND EXTRACT(year FROM occurred_at) = :year
                AND deleted_at IS NOT NULL
            """)
            result = await session.execute(
                stmt,
                {"user_id": user_id, "year": year},
            )
            return result.rowcount or 0
