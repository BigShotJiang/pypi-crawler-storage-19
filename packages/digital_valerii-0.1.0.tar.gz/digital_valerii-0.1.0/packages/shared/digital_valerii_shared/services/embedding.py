"""Embedding service for generating vector embeddings using Voyage AI."""

import asyncio
import hashlib
from enum import StrEnum
from functools import partial
from typing import TYPE_CHECKING

import structlog
import tiktoken
import voyageai
from pydantic import BaseModel, ConfigDict

from ..config import EmbeddingSettings

if TYPE_CHECKING:
    from .redis import RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Constants
# =============================================================================

# Maximum batch size for Voyage API
MAX_VOYAGE_BATCH_SIZE = 128

# Token limit buffer to account for tokenization differences
TOKEN_LIMIT_BUFFER = 0.9  # 90% of max


# =============================================================================
# Exceptions
# =============================================================================


class EmbeddingError(Exception):
    """Base exception for embedding operations."""

    pass


class EmbeddingAPIError(EmbeddingError):
    """Raised when Voyage API returns an error."""

    pass


class EmbeddingRateLimitError(EmbeddingError):
    """Raised when rate limit is exceeded."""

    pass


class EmbeddingTokenLimitError(EmbeddingError):
    """Raised when text exceeds token limit."""

    pass


# =============================================================================
# Enums
# =============================================================================


class EmbeddingInputType(StrEnum):
    """Voyage input type for optimized embeddings."""

    DOCUMENT = "document"
    QUERY = "query"


# =============================================================================
# Models
# =============================================================================


class EmbeddingResult(BaseModel):
    """Embedding result with metadata."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    embedding: list[float]
    model: str
    input_type: EmbeddingInputType
    tokens_used: int
    cached: bool = False


# =============================================================================
# EmbeddingService
# =============================================================================


class EmbeddingService:
    """Async Voyage embedding service with caching.

    Provides text embedding generation using Voyage AI API with optional
    Redis caching for improved performance.

    Features:
    - Single text and batch embedding
    - Redis cache integration (optional)
    - Token counting with tiktoken
    - Batch size limits enforcement
    - Metadata tracking
    - Non-blocking API calls via thread executor

    Example:
        settings = EmbeddingSettings(api_key="your-key")
        service = EmbeddingService(settings, redis=redis_service)

        # Single embedding
        embedding = await service.embed("Hello world")

        # Batch embedding
        embeddings = await service.embed_batch(["text1", "text2", "text3"])

        # With metadata
        result = await service.embed_with_metadata("query text", EmbeddingInputType.QUERY)
    """

    def __init__(
        self,
        settings: EmbeddingSettings,
        redis: "RedisService | None" = None,
    ) -> None:
        """Initialize the embedding service.

        Args:
            settings: Embedding service settings.
            redis: Optional Redis service for caching embeddings.
        """
        self.settings = settings
        self._redis = redis
        # Apply timeout to Voyage client
        self._client = voyageai.Client(
            api_key=settings.api_key,
            timeout=settings.timeout,
        )
        self._tokenizer = tiktoken.get_encoding("cl100k_base")
        # Clamp batch_size to provider max
        self._effective_batch_size = min(settings.batch_size, MAX_VOYAGE_BATCH_SIZE)

    # =========================================================================
    # Core Methods
    # =========================================================================

    async def embed(self, text: str) -> list[float]:
        """Generate embedding for single text.

        Args:
            text: Text to embed.

        Returns:
            List of floats representing the embedding vector.

        Raises:
            EmbeddingTokenLimitError: If text exceeds token limit.
            EmbeddingAPIError: If API call fails or dimensions mismatch.
            EmbeddingRateLimitError: If rate limit exceeded.
        """
        # Normalize text
        normalized = self._normalize_text(text)
        input_type = EmbeddingInputType.DOCUMENT

        # Check token limit with buffer
        token_count = self.count_tokens(normalized)
        effective_limit = int(self.settings.max_tokens * TOKEN_LIMIT_BUFFER)
        if token_count > effective_limit:
            raise EmbeddingTokenLimitError(
                f"Text likely exceeds token limit: ~{token_count} tokens "
                f"(limit: {self.settings.max_tokens}, buffer: 90%)"
            )

        # Check cache first
        cached = await self._get_cached(normalized, input_type)
        if cached is not None:
            await logger.adebug("Cache hit for embedding", text_len=len(normalized))
            return cached

        # Call API in thread executor (non-blocking)
        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                partial(
                    self._client.embed,
                    texts=[normalized],
                    model=self.settings.model,
                    input_type=input_type,
                ),
            )
            embedding = response.embeddings[0]

            # Validate dimensions
            if len(embedding) != self.settings.dimensions:
                raise EmbeddingAPIError(
                    f"Dimension mismatch: expected {self.settings.dimensions}, "
                    f"got {len(embedding)}"
                )

            # Cache result
            await self._set_cached(normalized, embedding, input_type)

            await logger.adebug(
                "Generated embedding",
                text_len=len(normalized),
                tokens=response.total_tokens,
            )
            return embedding

        except voyageai.error.RateLimitError as e:
            raise EmbeddingRateLimitError(f"Rate limit exceeded: {e}") from e
        except EmbeddingAPIError:
            raise
        except Exception as e:
            raise EmbeddingAPIError(f"Voyage API error: {e}") from e

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts efficiently.

        Checks cache first, only embeds uncached texts.
        Respects batch size limits (128 per request).

        Args:
            texts: List of texts to embed.

        Returns:
            List of embedding vectors in same order as input.

        Raises:
            EmbeddingTokenLimitError: If any text exceeds token limit.
            EmbeddingAPIError: If API call fails or validation errors.
            EmbeddingRateLimitError: If rate limit exceeded.
        """
        if not texts:
            return []

        # Normalize all texts
        normalized = [self._normalize_text(t) for t in texts]
        input_type = EmbeddingInputType.DOCUMENT

        # Check token limits with buffer
        effective_limit = int(self.settings.max_tokens * TOKEN_LIMIT_BUFFER)
        for i, text in enumerate(normalized):
            token_count = self.count_tokens(text)
            if token_count > effective_limit:
                raise EmbeddingTokenLimitError(
                    f"Text at index {i} likely exceeds token limit: ~{token_count} tokens "
                    f"(limit: {self.settings.max_tokens}, buffer: 90%)"
                )

        # Check cache for each text
        results: list[list[float] | None] = [None] * len(normalized)
        uncached_indices: list[int] = []
        uncached_texts: list[str] = []

        for i, text in enumerate(normalized):
            cached = await self._get_cached(text, input_type)
            if cached is not None:
                results[i] = cached
            else:
                uncached_indices.append(i)
                uncached_texts.append(text)

        if not uncached_texts:
            await logger.adebug("All embeddings from cache", count=len(texts))
            return [r for r in results if r is not None]

        # Process uncached texts in batches
        try:
            batch_size = self._effective_batch_size
            all_embeddings: list[list[float]] = []
            loop = asyncio.get_running_loop()

            for batch_start in range(0, len(uncached_texts), batch_size):
                batch_end = min(batch_start + batch_size, len(uncached_texts))
                batch = uncached_texts[batch_start:batch_end]

                # Run in executor (non-blocking)
                response = await loop.run_in_executor(
                    None,
                    partial(
                        self._client.embed,
                        texts=batch,
                        model=self.settings.model,
                        input_type=input_type,
                    ),
                )

                # Validate response length
                if len(response.embeddings) != len(batch):
                    raise EmbeddingAPIError(
                        f"Batch size mismatch: sent {len(batch)}, "
                        f"received {len(response.embeddings)}"
                    )

                # Validate dimensions for each embedding
                for emb in response.embeddings:
                    if len(emb) != self.settings.dimensions:
                        raise EmbeddingAPIError(
                            f"Dimension mismatch: expected {self.settings.dimensions}, "
                            f"got {len(emb)}"
                        )

                all_embeddings.extend(response.embeddings)

            # Store results and cache
            for i, embedding in enumerate(all_embeddings):
                original_index = uncached_indices[i]
                results[original_index] = embedding
                await self._set_cached(uncached_texts[i], embedding, input_type)

            await logger.adebug(
                "Generated batch embeddings",
                total=len(texts),
                cached=len(texts) - len(uncached_texts),
                generated=len(uncached_texts),
            )

            return [r for r in results if r is not None]

        except voyageai.error.RateLimitError as e:
            raise EmbeddingRateLimitError(f"Rate limit exceeded: {e}") from e
        except EmbeddingAPIError:
            raise
        except Exception as e:
            raise EmbeddingAPIError(f"Voyage API error: {e}") from e

    async def embed_with_metadata(
        self,
        text: str,
        input_type: EmbeddingInputType = EmbeddingInputType.DOCUMENT,
    ) -> EmbeddingResult:
        """Generate embedding with usage metadata.

        Args:
            text: Text to embed.
            input_type: Type of input for optimization.

        Returns:
            EmbeddingResult with embedding and metadata.

        Raises:
            EmbeddingTokenLimitError: If text exceeds token limit.
            EmbeddingAPIError: If API call fails or dimensions mismatch.
            EmbeddingRateLimitError: If rate limit exceeded.
        """
        # Normalize text
        normalized = self._normalize_text(text)

        # Check token limit with buffer
        token_count = self.count_tokens(normalized)
        effective_limit = int(self.settings.max_tokens * TOKEN_LIMIT_BUFFER)
        if token_count > effective_limit:
            raise EmbeddingTokenLimitError(
                f"Text likely exceeds token limit: ~{token_count} tokens "
                f"(limit: {self.settings.max_tokens}, buffer: 90%)"
            )

        # Check cache first (with input_type)
        cached = await self._get_cached(normalized, input_type)
        if cached is not None:
            return EmbeddingResult(
                embedding=cached,
                model=self.settings.model,
                input_type=input_type,
                tokens_used=token_count,
                cached=True,
            )

        # Call API in thread executor (non-blocking)
        try:
            loop = asyncio.get_running_loop()
            response = await loop.run_in_executor(
                None,
                partial(
                    self._client.embed,
                    texts=[normalized],
                    model=self.settings.model,
                    input_type=input_type,
                ),
            )
            embedding = response.embeddings[0]

            # Validate dimensions
            if len(embedding) != self.settings.dimensions:
                raise EmbeddingAPIError(
                    f"Dimension mismatch: expected {self.settings.dimensions}, "
                    f"got {len(embedding)}"
                )

            # Cache result (with input_type)
            await self._set_cached(normalized, embedding, input_type)

            return EmbeddingResult(
                embedding=embedding,
                model=self.settings.model,
                input_type=input_type,
                tokens_used=response.total_tokens,
                cached=False,
            )

        except voyageai.error.RateLimitError as e:
            raise EmbeddingRateLimitError(f"Rate limit exceeded: {e}") from e
        except EmbeddingAPIError:
            raise
        except Exception as e:
            raise EmbeddingAPIError(f"Voyage API error: {e}") from e

    # =========================================================================
    # Cache Methods
    # =========================================================================

    def _cache_key(
        self,
        text: str,
        input_type: EmbeddingInputType = EmbeddingInputType.DOCUMENT,
    ) -> str:
        """Generate cache key from text hash, model, and input type.

        Args:
            text: Text to hash.
            input_type: Embedding input type.

        Returns:
            Cache key in format "embed:{model}:{input_type}:{hash[:16]}".
        """
        text_hash = hashlib.sha256(text.encode()).hexdigest()[:16]
        return f"embed:{self.settings.model}:{input_type}:{text_hash}"

    async def _get_cached(
        self,
        text: str,
        input_type: EmbeddingInputType = EmbeddingInputType.DOCUMENT,
    ) -> list[float] | None:
        """Get embedding from cache if exists.

        Validates cache structure including dimensions.

        Args:
            text: Text to look up.
            input_type: Embedding input type.

        Returns:
            Cached embedding or None if not cached or invalid.
        """
        if self._redis is None:
            return None

        try:
            from .redis import RedisNamespace

            key = self._cache_key(text, input_type)
            result = await self._redis.get_json(key, RedisNamespace.CACHE)

            # Validate cached value
            if result is None:
                return None
            if not isinstance(result, list):
                return None
            if len(result) != self.settings.dimensions:
                # Cached with different dimensions - invalidate
                await logger.awarning(
                    "Cache dimension mismatch, ignoring",
                    expected=self.settings.dimensions,
                    got=len(result),
                )
                return None
            if not all(isinstance(x, int | float) for x in result):
                return None

            return result
        except Exception as e:
            await logger.awarning("Cache get failed", error=str(e))
            return None

    async def _set_cached(
        self,
        text: str,
        embedding: list[float],
        input_type: EmbeddingInputType = EmbeddingInputType.DOCUMENT,
    ) -> None:
        """Store embedding in cache.

        Args:
            text: Original text.
            embedding: Embedding vector to cache.
            input_type: Embedding input type.
        """
        if self._redis is None:
            return

        try:
            from .redis import RedisNamespace

            key = self._cache_key(text, input_type)
            await self._redis.set_json(
                key,
                embedding,
                RedisNamespace.CACHE,
                ttl=self.settings.cache_ttl,
            )
        except Exception as e:
            await logger.awarning("Cache set failed", error=str(e))

    # =========================================================================
    # Utility Methods
    # =========================================================================

    async def health_check(self) -> bool:
        """Check Voyage API connectivity.

        Returns:
            True if API is accessible, False otherwise.
        """
        try:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(
                None,
                partial(
                    self._client.embed,
                    texts=["test"],
                    model=self.settings.model,
                ),
            )
            return True
        except Exception:
            return False

    def count_tokens(self, text: str) -> int:
        """Estimate token count for text.

        Uses tiktoken cl100k_base as approximation for Voyage.
        Note: This is an estimate; actual Voyage tokenization may differ.

        Args:
            text: Text to count tokens for.

        Returns:
            Estimated token count.
        """
        return len(self._tokenizer.encode(text))

    def _normalize_text(self, text: str) -> str:
        """Normalize text for consistent hashing.

        Args:
            text: Text to normalize.

        Returns:
            Normalized text with trimmed whitespace.
        """
        return " ".join(text.split())
