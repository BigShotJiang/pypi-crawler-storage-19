"""Compact Handler - Manages auto-compact with user notification and context preservation."""

from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from .session_manager import CheckpointType, UnifiedSessionManager

logger = structlog.get_logger(__name__)


# =============================================================================
# Enums
# =============================================================================


class InterfaceType(str, Enum):
    """Interface types for channel-specific messaging."""

    WEB = "web"
    SLACK = "slack"
    MEETING = "meeting"
    CLI = "cli"


# =============================================================================
# Models
# =============================================================================


class CompactMessages(BaseModel):
    """Compact notification messages for a channel."""

    model_config = ConfigDict(extra="forbid")

    pre: str = Field(description="Message before compact")
    post: str = Field(description="Message after compact")


class ConversationContext(BaseModel):
    """Context about the current conversation."""

    model_config = ConfigDict(extra="forbid")

    user_id: UUID
    channel: InterfaceType
    sdk_session_id: str | None = None
    current_summary: str | None = None
    working_memory: dict[str, Any] = Field(default_factory=dict)
    active_context: dict[str, Any] = Field(default_factory=dict)
    message_count: int = 0


class CompactResult(BaseModel):
    """Result from compact operation."""

    model_config = ConfigDict(extra="forbid")

    checkpoint_id: UUID | None = None
    pre_message: str
    post_message: str
    summary: str | None = None


# =============================================================================
# Constants
# =============================================================================


# Channel-specific compact messages (in Ukrainian as per project language)
COMPACT_MESSAGES: dict[InterfaceType, CompactMessages] = {
    InterfaceType.MEETING: CompactMessages(
        pre="Вибачте, дайте мені хвилинку впорядкувати думки...",
        post="Дякую за терпіння! На чому ми зупинились?",
    ),
    InterfaceType.SLACK: CompactMessages(
        pre="Один момент, організую думки...",
        post="Готово! Продовжуємо...",
    ),
    InterfaceType.WEB: CompactMessages(
        pre="Впорядковую контекст...",
        post="Готово! Продовжуємо нашу розмову.",
    ),
    InterfaceType.CLI: CompactMessages(
        pre="[Компактування контексту...]",
        post="[Готово] Продовжуємо.",
    ),
}


# =============================================================================
# Service
# =============================================================================


class CompactHandler:
    """Handles auto-compact with user notification and context preservation.

    Provides:
    - Channel-appropriate notification messages
    - Pre-compact context preservation (checkpoint)
    - Post-compact context restoration hints

    Example:
        handler = CompactHandler(session_manager)
        context = ConversationContext(user_id=user_id, channel=InterfaceType.WEB)

        # Before auto-compact
        result = await handler.on_pre_compact(context, compact_metadata)
        # Send result.pre_message to user

        # After auto-compact (via SessionStart)
        await handler.on_post_compact(context, source="auto_compact")
        # Send post_message to user
    """

    def __init__(self, session_manager: UnifiedSessionManager) -> None:
        """Initialize compact handler.

        Args:
            session_manager: Session manager for checkpoint operations.
        """
        self._session_manager = session_manager

    async def on_pre_compact(
        self,
        context: ConversationContext,
        compact_metadata: dict[str, Any] | None = None,
    ) -> CompactResult:
        """Hook called before auto-compact.

        Saves session checkpoint and returns channel-appropriate messages.

        Args:
            context: Current conversation context.
            compact_metadata: Optional metadata from compact event.

        Returns:
            CompactResult with checkpoint info and messages.
        """
        messages = self.get_messages_for_channel(context.channel)

        # Prepare checkpoint context
        checkpoint_context: dict[str, Any] = {
            "summary": context.current_summary,
            "working_memory": context.working_memory,
            "active_context": context.active_context,
            "message_count": context.message_count,
            "compact_metadata": compact_metadata,
            "timestamp": datetime.now(UTC).isoformat(),
        }

        # Save checkpoint
        checkpoint_id = await self._session_manager.save_checkpoint(
            user_id=context.user_id,
            checkpoint_type=CheckpointType.PRE_COMPACT.value,
            context=checkpoint_context,
        )

        await logger.ainfo(
            "Pre-compact checkpoint saved",
            user_id=str(context.user_id),
            channel=context.channel.value,
            checkpoint_id=str(checkpoint_id),
            message_count=context.message_count,
        )

        return CompactResult(
            checkpoint_id=checkpoint_id,
            pre_message=messages.pre,
            post_message=messages.post,
            summary=context.current_summary,
        )

    async def on_post_compact(
        self,
        context: ConversationContext,
        source: str = "auto_compact",
    ) -> str:
        """Hook called after compact completes (via SessionStart).

        Retrieves latest checkpoint and returns post-compact message.

        Args:
            context: Current conversation context.
            source: Source of compact (auto_compact, manual, etc.).

        Returns:
            Post-compact message to send to user.
        """
        messages = self.get_messages_for_channel(context.channel)

        # Get latest checkpoint for context restoration hints
        checkpoint = await self._session_manager.get_latest_checkpoint(context.user_id)

        await logger.ainfo(
            "Post-compact handler called",
            user_id=str(context.user_id),
            channel=context.channel.value,
            source=source,
            has_checkpoint=checkpoint is not None,
        )

        return messages.post

    async def get_context_summary_for_injection(
        self,
        user_id: UUID,
    ) -> dict[str, Any] | None:
        """Get context summary to inject after compact.

        Retrieves the latest checkpoint and formats it for injection
        into the new session context.

        Args:
            user_id: User UUID.

        Returns:
            Context summary dict or None if no checkpoint.
        """
        checkpoint = await self._session_manager.get_latest_checkpoint(user_id)
        if not checkpoint:
            return None

        return {
            "summary": checkpoint.summary,
            "working_memory": checkpoint.working_memory,
            "active_context": checkpoint.active_context,
            "previous_message_count": checkpoint.message_count,
            "checkpoint_type": checkpoint.checkpoint_type.value,
            "checkpoint_time": checkpoint.created_at.isoformat(),
        }

    def get_messages_for_channel(self, channel: InterfaceType) -> CompactMessages:
        """Get compact messages for a specific channel.

        Args:
            channel: Interface type.

        Returns:
            CompactMessages for the channel.
        """
        return COMPACT_MESSAGES.get(
            channel,
            COMPACT_MESSAGES[InterfaceType.WEB],  # Default to web messages
        )

    def get_pre_message(self, channel: InterfaceType) -> str:
        """Get pre-compact message for a channel.

        Args:
            channel: Interface type.

        Returns:
            Pre-compact message string.
        """
        return self.get_messages_for_channel(channel).pre

    def get_post_message(self, channel: InterfaceType) -> str:
        """Get post-compact message for a channel.

        Args:
            channel: Interface type.

        Returns:
            Post-compact message string.
        """
        return self.get_messages_for_channel(channel).post


# =============================================================================
# Helper Functions
# =============================================================================


def get_compact_messages() -> dict[str, dict[str, str]]:
    """Get all compact messages as a simple dict.

    Returns:
        Dict mapping channel names to message dicts.
    """
    return {
        channel.value: {"pre": messages.pre, "post": messages.post}
        for channel, messages in COMPACT_MESSAGES.items()
    }
