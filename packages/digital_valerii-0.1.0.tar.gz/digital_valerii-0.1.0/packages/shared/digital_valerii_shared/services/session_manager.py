"""Unified Session Manager - One continuous session per user across all channels."""

from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

import structlog
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = structlog.get_logger(__name__)

# Processing timeout for stuck messages (5 minutes)
MESSAGE_PROCESSING_TIMEOUT_SECONDS = 300


# =============================================================================
# Enums
# =============================================================================


class SessionStatus(str, Enum):
    """User session status."""

    ACTIVE = "active"
    PAUSED = "paused"
    ARCHIVED = "archived"


class ChannelType(str, Enum):
    """Communication channel types."""

    WEB = "web"
    SLACK = "slack"
    MEETING = "meeting"
    CLI = "cli"


class MessageStatus(str, Enum):
    """Message queue status."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class CheckpointType(str, Enum):
    """Session checkpoint types."""

    PRE_COMPACT = "pre_compact"
    MANUAL = "manual"
    RECOVERY = "recovery"


# =============================================================================
# Models
# =============================================================================


class UserSession(BaseModel):
    """User session model."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    user_id: UUID
    sdk_session_id: str | None = None
    status: SessionStatus = SessionStatus.ACTIVE
    last_channel: str | None = None
    last_activity_at: datetime
    compact_count: int = 0
    checkpoint: dict | None = None
    created_at: datetime
    updated_at: datetime


class SessionCheckpoint(BaseModel):
    """Session checkpoint model."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    user_session_id: UUID
    checkpoint_type: CheckpointType
    summary: str | None = None
    working_memory: dict | None = None
    active_context: dict | None = None
    message_count: int | None = None
    created_at: datetime


class QueuedMessage(BaseModel):
    """Queued message model."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    user_session_id: UUID
    channel: str
    content: str
    metadata: dict = Field(default_factory=dict)
    priority: int = 0
    status: MessageStatus = MessageStatus.PENDING
    created_at: datetime
    processed_at: datetime | None = None


class AgentResponse(BaseModel):
    """Response from agent processing."""

    model_config = ConfigDict(extra="forbid")

    message_id: UUID
    content: str
    channel: str
    metadata: dict = Field(default_factory=dict)


# =============================================================================
# Exceptions
# =============================================================================


class SessionError(Exception):
    """Base exception for session errors."""

    pass


class SessionNotFoundError(SessionError):
    """Session not found."""

    def __init__(self, user_id: UUID) -> None:
        self.user_id = user_id
        super().__init__(f"No active session found for user: {user_id}")


class MessageNotFoundError(SessionError):
    """Message not found in queue."""

    def __init__(self, message_id: UUID) -> None:
        self.message_id = message_id
        super().__init__(f"Message not found: {message_id}")


# =============================================================================
# Service
# =============================================================================


class UnifiedSessionManager:
    """Manages one continuous session per user across all channels.

    Provides:
    - Single session per user (not per conversation)
    - Cross-channel message queue with sequential processing
    - Checkpoint management for auto-compact recovery
    - Explicit session reset via /new command

    Example:
        async with session_factory() as db:
            manager = UnifiedSessionManager(db)
            session = await manager.get_or_create_session(user_id)
            message_id = await manager.enqueue_message(
                user_id=user_id,
                channel="web",
                content="Hello!"
            )
    """

    def __init__(self, session: AsyncSession) -> None:
        """Initialize session manager.

        Args:
            session: Database session for operations.
        """
        self._session = session

    async def get_or_create_session(self, user_id: UUID) -> UserSession:
        """Get existing active session or create new one for user atomically.

        Uses FOR UPDATE to prevent race conditions and ON CONFLICT to handle
        concurrent session creation attempts.

        Args:
            user_id: User UUID.

        Returns:
            UserSession (active session for user).
        """
        now = datetime.now(UTC)

        # Try to get existing active session with lock
        stmt = text("""
            SELECT
                id, user_id, sdk_session_id, status, last_channel,
                last_activity_at, compact_count, checkpoint,
                created_at, updated_at
            FROM user_sessions
            WHERE user_id = :user_id AND status = 'active'
            FOR UPDATE
            LIMIT 1
        """)
        result = await self._session.execute(stmt, {"user_id": str(user_id)})
        row = result.fetchone()

        if row:
            await self._session.commit()
            return self._row_to_session(row)

        # Create new session with conflict handling
        session_id = uuid4()

        stmt = text("""
            INSERT INTO user_sessions (id, user_id, status, last_activity_at, created_at, updated_at)
            VALUES (:id, :user_id, 'active', :now, :now, :now)
            ON CONFLICT (user_id) WHERE status = 'active'
            DO UPDATE SET updated_at = EXCLUDED.updated_at
            RETURNING id, user_id, sdk_session_id, status, last_channel,
                      last_activity_at, compact_count, checkpoint, created_at, updated_at
        """)
        result = await self._session.execute(
            stmt,
            {"id": str(session_id), "user_id": str(user_id), "now": now},
        )
        await self._session.commit()
        row = result.fetchone()

        await logger.ainfo(
            "Created or retrieved user session",
            session_id=str(row[0]) if row else str(session_id),
            user_id=str(user_id),
        )

        return self._row_to_session(row)

    async def get_session(self, user_id: UUID) -> UserSession | None:
        """Get active session for user.

        Args:
            user_id: User UUID.

        Returns:
            UserSession or None if no active session.
        """
        stmt = text("""
            SELECT
                id, user_id, sdk_session_id, status, last_channel,
                last_activity_at, compact_count, checkpoint,
                created_at, updated_at
            FROM user_sessions
            WHERE user_id = :user_id AND status = 'active'
            LIMIT 1
        """)
        result = await self._session.execute(stmt, {"user_id": str(user_id)})
        row = result.fetchone()

        return self._row_to_session(row) if row else None

    async def update_session_activity(
        self,
        user_id: UUID,
        channel: str,
        sdk_session_id: str | None = None,
    ) -> None:
        """Update session last activity.

        Args:
            user_id: User UUID.
            channel: Current channel.
            sdk_session_id: Optional SDK session ID to update.
        """
        now = datetime.now(UTC)
        if sdk_session_id:
            stmt = text("""
                UPDATE user_sessions
                SET last_activity_at = :now, last_channel = :channel,
                    sdk_session_id = :sdk_session_id, updated_at = :now
                WHERE user_id = :user_id AND status = 'active'
            """)
            await self._session.execute(
                stmt,
                {
                    "user_id": str(user_id),
                    "now": now,
                    "channel": channel,
                    "sdk_session_id": sdk_session_id,
                },
            )
        else:
            stmt = text("""
                UPDATE user_sessions
                SET last_activity_at = :now, last_channel = :channel, updated_at = :now
                WHERE user_id = :user_id AND status = 'active'
            """)
            await self._session.execute(
                stmt,
                {"user_id": str(user_id), "now": now, "channel": channel},
            )
        await self._session.commit()

    async def enqueue_message(
        self,
        user_id: UUID,
        channel: str,
        content: str,
        metadata: dict | None = None,
        priority: int = 0,
        sdk_session_id: str | None = None,
    ) -> UUID:
        """Add message to user's queue from any channel.

        Args:
            user_id: User UUID.
            channel: Channel name (web, slack, meeting, cli).
            content: Message content.
            metadata: Optional channel-specific metadata.
            priority: Message priority (higher = process first).
            sdk_session_id: Optional SDK session ID to track.

        Returns:
            UUID of queued message.
        """
        # Ensure session exists
        session = await self.get_or_create_session(user_id)

        # Update activity with SDK session ID if provided
        await self.update_session_activity(user_id, channel, sdk_session_id)

        # Create message
        message_id = uuid4()
        now = datetime.now(UTC)

        stmt = text("""
            INSERT INTO message_queue (
                id, user_session_id, channel, content, metadata, priority, status, created_at
            )
            VALUES (:id, :session_id, :channel, :content, :metadata::jsonb, :priority, 'pending', :now)
        """)
        await self._session.execute(
            stmt,
            {
                "id": str(message_id),
                "session_id": str(session.id),
                "channel": channel,
                "content": content,
                "metadata": _to_json(metadata or {}),
                "priority": priority,
                "now": now,
            },
        )
        await self._session.commit()

        await logger.ainfo(
            "Message enqueued",
            message_id=str(message_id),
            user_id=str(user_id),
            channel=channel,
        )

        return message_id

    async def get_next_pending_message(self, user_id: UUID) -> QueuedMessage | None:
        """Get next pending message for user (highest priority, oldest first).

        Note: This method is NOT atomic. For concurrent workers, use claim_next_message().

        Args:
            user_id: User UUID.

        Returns:
            QueuedMessage or None if queue empty.
        """
        session = await self.get_session(user_id)
        if not session:
            return None

        stmt = text("""
            SELECT
                id, user_session_id, channel, content, metadata,
                priority, status, created_at, processed_at
            FROM message_queue
            WHERE user_session_id = :session_id AND status = 'pending'
            ORDER BY priority DESC, created_at ASC
            LIMIT 1
        """)
        result = await self._session.execute(stmt, {"session_id": str(session.id)})
        row = result.fetchone()

        return self._row_to_message(row) if row else None

    async def claim_next_message(self, user_id: UUID) -> QueuedMessage | None:
        """Atomically claim next pending message for user.

        Uses FOR UPDATE SKIP LOCKED to prevent multiple workers from
        processing the same message. This is the preferred method for
        concurrent message processing.

        Args:
            user_id: User UUID.

        Returns:
            QueuedMessage (already marked as processing) or None if queue empty.
        """
        session = await self.get_session(user_id)
        if not session:
            return None

        now = datetime.now(UTC)

        # Single atomic query: select + update in one transaction
        stmt = text("""
            UPDATE message_queue
            SET status = 'processing', processed_at = :now
            WHERE id = (
                SELECT id FROM message_queue
                WHERE user_session_id = :session_id
                AND status = 'pending'
                ORDER BY priority DESC, created_at ASC
                FOR UPDATE SKIP LOCKED
                LIMIT 1
            )
            RETURNING id, user_session_id, channel, content, metadata,
                      priority, status, created_at, processed_at
        """)
        result = await self._session.execute(
            stmt,
            {"session_id": str(session.id), "now": now},
        )
        await self._session.commit()
        row = result.fetchone()

        if row:
            await logger.adebug(
                "Claimed message for processing",
                message_id=str(row[0]),
                user_id=str(user_id),
            )

        return self._row_to_message(row) if row else None

    async def mark_message_processing(self, message_id: UUID) -> None:
        """Mark message as processing.

        Args:
            message_id: Message UUID.
        """
        stmt = text("""
            UPDATE message_queue
            SET status = 'processing'
            WHERE id = :id
        """)
        await self._session.execute(stmt, {"id": str(message_id)})
        await self._session.commit()

    async def complete_message(
        self,
        message_id: UUID,
        success: bool = True,
    ) -> None:
        """Mark message as completed or failed.

        Args:
            message_id: Message UUID.
            success: Whether processing succeeded.
        """
        now = datetime.now(UTC)
        status = (
            MessageStatus.COMPLETED.value if success else MessageStatus.FAILED.value
        )

        stmt = text("""
            UPDATE message_queue
            SET status = :status, processed_at = :now
            WHERE id = :id
        """)
        await self._session.execute(
            stmt,
            {"id": str(message_id), "status": status, "now": now},
        )
        await self._session.commit()

    async def process_next_message(self, user_id: UUID) -> AgentResponse | None:
        """Process next message in user's queue.

        Note: This is a placeholder for actual agent processing.
        In real implementation, this would call the Claude agent.

        Args:
            user_id: User UUID.

        Returns:
            AgentResponse or None if queue empty.
        """
        message = await self.get_next_pending_message(user_id)
        if not message:
            return None

        await self.mark_message_processing(message.id)

        # TODO: Actual agent processing would happen here
        # For now, return a placeholder response
        response = AgentResponse(
            message_id=message.id,
            content=f"Processed: {message.content}",
            channel=message.channel,
            metadata=message.metadata,
        )

        await self.complete_message(message.id, success=True)

        return response

    async def start_new_session(self, user_id: UUID) -> UserSession:
        """Explicit /new command - archive current, start fresh.

        Also cancels any pending messages from the old session to prevent
        orphaned messages in the queue.

        Args:
            user_id: User UUID.

        Returns:
            New UserSession.
        """
        now = datetime.now(UTC)

        # Get current active session with lock
        stmt = text("""
            SELECT id FROM user_sessions
            WHERE user_id = :user_id AND status = 'active'
            FOR UPDATE
        """)
        result = await self._session.execute(stmt, {"user_id": str(user_id)})
        old_session = result.fetchone()

        cancelled_count = 0
        if old_session:
            old_session_id = old_session[0]

            # Cancel pending messages (don't delete, keep audit trail)
            stmt = text("""
                UPDATE message_queue
                SET status = 'cancelled'
                WHERE user_session_id = :session_id
                AND status = 'pending'
            """)
            result = await self._session.execute(
                stmt,
                {"session_id": str(old_session_id)},
            )
            cancelled_count = result.rowcount

            # Archive old session
            stmt = text("""
                UPDATE user_sessions
                SET status = 'archived', updated_at = :now
                WHERE id = :session_id
            """)
            await self._session.execute(
                stmt,
                {"session_id": str(old_session_id), "now": now},
            )

        # Create new session
        session_id = uuid4()

        stmt = text("""
            INSERT INTO user_sessions (id, user_id, status, last_activity_at, created_at, updated_at)
            VALUES (:id, :user_id, 'active', :now, :now, :now)
            RETURNING id, user_id, sdk_session_id, status, last_channel,
                      last_activity_at, compact_count, checkpoint, created_at, updated_at
        """)
        result = await self._session.execute(
            stmt,
            {"id": str(session_id), "user_id": str(user_id), "now": now},
        )
        await self._session.commit()
        row = result.fetchone()

        await logger.ainfo(
            "Started new session (archived previous)",
            session_id=str(session_id),
            user_id=str(user_id),
            cancelled_messages=cancelled_count,
        )

        return self._row_to_session(row)

    async def save_checkpoint(
        self,
        user_id: UUID,
        checkpoint_type: str,
        context: dict,
    ) -> UUID:
        """Save session checkpoint (called by CompactHandler).

        Args:
            user_id: User UUID.
            checkpoint_type: Type of checkpoint (pre_compact, manual, recovery).
            context: Context data to save (summary, working_memory, etc.).

        Returns:
            Checkpoint UUID.
        """
        session = await self.get_session(user_id)
        if not session:
            raise SessionNotFoundError(user_id)

        checkpoint_id = uuid4()
        now = datetime.now(UTC)

        stmt = text("""
            INSERT INTO session_checkpoints (
                id, user_session_id, checkpoint_type, summary,
                working_memory, active_context, message_count, created_at
            )
            VALUES (
                :id, :session_id, :checkpoint_type, :summary,
                :working_memory::jsonb, :active_context::jsonb, :message_count, :now
            )
        """)
        await self._session.execute(
            stmt,
            {
                "id": str(checkpoint_id),
                "session_id": str(session.id),
                "checkpoint_type": checkpoint_type,
                "summary": context.get("summary"),
                "working_memory": _to_json(context.get("working_memory")),
                "active_context": _to_json(context.get("active_context")),
                "message_count": context.get("message_count"),
                "now": now,
            },
        )

        # Increment compact count if pre_compact
        if checkpoint_type == CheckpointType.PRE_COMPACT.value:
            stmt = text("""
                UPDATE user_sessions
                SET compact_count = compact_count + 1, updated_at = :now
                WHERE id = :session_id
            """)
            await self._session.execute(
                stmt,
                {"session_id": str(session.id), "now": now},
            )

        await self._session.commit()

        await logger.ainfo(
            "Saved session checkpoint",
            checkpoint_id=str(checkpoint_id),
            user_id=str(user_id),
            checkpoint_type=checkpoint_type,
        )

        return checkpoint_id

    async def get_latest_checkpoint(self, user_id: UUID) -> SessionCheckpoint | None:
        """Retrieve most recent checkpoint for user.

        Args:
            user_id: User UUID.

        Returns:
            SessionCheckpoint or None.
        """
        session = await self.get_session(user_id)
        if not session:
            return None

        stmt = text("""
            SELECT
                id, user_session_id, checkpoint_type, summary,
                working_memory, active_context, message_count, created_at
            FROM session_checkpoints
            WHERE user_session_id = :session_id
            ORDER BY created_at DESC
            LIMIT 1
        """)
        result = await self._session.execute(stmt, {"session_id": str(session.id)})
        row = result.fetchone()

        return self._row_to_checkpoint(row) if row else None

    async def get_queue_length(self, user_id: UUID) -> int:
        """Get number of pending messages in user's queue.

        Args:
            user_id: User UUID.

        Returns:
            Number of pending messages.
        """
        session = await self.get_session(user_id)
        if not session:
            return 0

        stmt = text("""
            SELECT COUNT(*) FROM message_queue
            WHERE user_session_id = :session_id AND status = 'pending'
        """)
        result = await self._session.execute(stmt, {"session_id": str(session.id)})
        return result.scalar() or 0

    async def requeue_stuck_messages(self) -> int:
        """Reset messages stuck in processing state back to pending.

        Messages are considered stuck if they've been in 'processing' state
        longer than MESSAGE_PROCESSING_TIMEOUT_SECONDS (default: 5 minutes).

        Call this periodically (e.g., every minute) from a background job.

        Returns:
            Number of messages requeued.
        """
        stmt = text("""
            UPDATE message_queue
            SET status = 'pending', processed_at = NULL
            WHERE status = 'processing'
            AND processed_at < NOW() - INTERVAL '1 second' * :timeout
        """)
        result = await self._session.execute(
            stmt,
            {"timeout": MESSAGE_PROCESSING_TIMEOUT_SECONDS},
        )
        await self._session.commit()

        count = result.rowcount
        if count > 0:
            await logger.awarning(
                "Requeued stuck messages",
                count=count,
                timeout_seconds=MESSAGE_PROCESSING_TIMEOUT_SECONDS,
            )

        return count

    # =========================================================================
    # Helpers
    # =========================================================================

    def _row_to_session(self, row: tuple) -> UserSession:
        """Convert database row to UserSession."""
        import json

        checkpoint = row[7]
        if checkpoint and isinstance(checkpoint, str):
            checkpoint = json.loads(checkpoint)

        return UserSession(
            id=UUID(str(row[0])),
            user_id=UUID(str(row[1])),
            sdk_session_id=row[2],
            status=SessionStatus(row[3]),
            last_channel=row[4],
            last_activity_at=row[5],
            compact_count=row[6] or 0,
            checkpoint=checkpoint,
            created_at=row[8],
            updated_at=row[9],
        )

    def _row_to_message(self, row: tuple) -> QueuedMessage:
        """Convert database row to QueuedMessage."""
        import json

        metadata = row[4]
        if metadata and isinstance(metadata, str):
            metadata = json.loads(metadata)

        return QueuedMessage(
            id=UUID(str(row[0])),
            user_session_id=UUID(str(row[1])),
            channel=row[2],
            content=row[3],
            metadata=metadata or {},
            priority=row[5],
            status=MessageStatus(row[6]),
            created_at=row[7],
            processed_at=row[8],
        )

    def _row_to_checkpoint(self, row: tuple) -> SessionCheckpoint:
        """Convert database row to SessionCheckpoint."""
        import json

        working_memory = row[4]
        if working_memory and isinstance(working_memory, str):
            working_memory = json.loads(working_memory)

        active_context = row[5]
        if active_context and isinstance(active_context, str):
            active_context = json.loads(active_context)

        return SessionCheckpoint(
            id=UUID(str(row[0])),
            user_session_id=UUID(str(row[1])),
            checkpoint_type=CheckpointType(row[2]),
            summary=row[3],
            working_memory=working_memory,
            active_context=active_context,
            message_count=row[6],
            created_at=row[7],
        )


def _to_json(data: Any) -> str | None:
    """Convert data to JSON string."""
    import json

    if data is None:
        return None
    return json.dumps(data, default=str)
