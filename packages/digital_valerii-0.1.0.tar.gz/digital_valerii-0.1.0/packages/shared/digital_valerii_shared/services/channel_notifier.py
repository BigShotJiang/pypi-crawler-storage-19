"""Channel Notifier - Send notifications to users via their current channel."""

from abc import ABC, abstractmethod
from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from .session_manager import UnifiedSessionManager

logger = structlog.get_logger(__name__)


# =============================================================================
# Enums
# =============================================================================


class NotificationType(str, Enum):
    """Types of notifications."""

    INFO = "info"
    COMPACT_START = "compact_start"
    COMPACT_END = "compact_end"
    ERROR = "error"
    WARNING = "warning"


class ChannelName(str, Enum):
    """Available notification channels."""

    WEB = "web"
    SLACK = "slack"
    CLI = "cli"
    MEETING = "meeting"


# =============================================================================
# Models
# =============================================================================


class Notification(BaseModel):
    """Notification to send to user."""

    model_config = ConfigDict(extra="forbid")

    user_id: UUID
    channel: ChannelName
    message: str
    notification_type: NotificationType = NotificationType.INFO
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))


class NotificationResult(BaseModel):
    """Result of notification delivery."""

    model_config = ConfigDict(extra="forbid")

    success: bool
    channel: ChannelName
    error: str | None = None


# =============================================================================
# Protocols and Interfaces
# =============================================================================


class ChannelSender(Protocol):
    """Protocol for channel-specific notification senders."""

    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Send notification via this channel."""
        ...


class BaseChannelSender(ABC):
    """Base class for channel senders."""

    @property
    @abstractmethod
    def channel_name(self) -> ChannelName:
        """Return the channel name."""
        ...

    @abstractmethod
    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Send notification via this channel."""
        ...


# =============================================================================
# Channel Implementations
# =============================================================================


class WebChannelSender(BaseChannelSender):
    """Web channel sender - queues notifications for WebSocket or polling.

    In practice, web notifications are typically:
    1. Pushed via WebSocket connection
    2. Included in API response headers
    3. Queued for polling by frontend
    """

    @property
    def channel_name(self) -> ChannelName:
        return ChannelName.WEB

    def __init__(self, notification_queue: list[dict[str, Any]] | None = None) -> None:
        """Initialize web sender.

        Args:
            notification_queue: Optional queue to push notifications to.
        """
        self._queue = notification_queue if notification_queue is not None else []

    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Queue notification for web delivery."""
        try:
            notification_data = {
                "user_id": str(user_id),
                "message": message,
                "type": notification_type.value,
                "metadata": metadata,
                "timestamp": datetime.now(UTC).isoformat(),
            }
            self._queue.append(notification_data)

            await logger.ainfo(
                "Web notification queued",
                user_id=str(user_id),
                notification_type=notification_type.value,
            )

            return NotificationResult(success=True, channel=self.channel_name)
        except Exception as e:
            return NotificationResult(
                success=False,
                channel=self.channel_name,
                error=str(e),
            )

    def get_pending_notifications(self, user_id: UUID) -> list[dict[str, Any]]:
        """Get pending notifications for a user.

        Args:
            user_id: User UUID.

        Returns:
            List of pending notification dicts.
        """
        user_id_str = str(user_id)
        return [n for n in self._queue if n.get("user_id") == user_id_str]

    def clear_notifications(self, user_id: UUID) -> int:
        """Clear notifications for a user.

        Args:
            user_id: User UUID.

        Returns:
            Number of notifications cleared.
        """
        user_id_str = str(user_id)
        original_len = len(self._queue)
        self._queue[:] = [n for n in self._queue if n.get("user_id") != user_id_str]
        return original_len - len(self._queue)


class SlackChannelSender(BaseChannelSender):
    """Slack channel sender - uses Slack API to send messages.

    In practice, this would integrate with Slack's Web API.
    For now, it queues messages for the Slack integration to process.
    """

    @property
    def channel_name(self) -> ChannelName:
        return ChannelName.SLACK

    def __init__(self, message_queue: list[dict[str, Any]] | None = None) -> None:
        """Initialize Slack sender.

        Args:
            message_queue: Optional queue for Slack messages.
        """
        self._queue = message_queue if message_queue is not None else []

    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Queue message for Slack delivery."""
        try:
            message_data = {
                "user_id": str(user_id),
                "message": message,
                "type": notification_type.value,
                "channel_id": metadata.get("channel_id"),
                "thread_ts": metadata.get("thread_ts"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
            self._queue.append(message_data)

            await logger.ainfo(
                "Slack notification queued",
                user_id=str(user_id),
                notification_type=notification_type.value,
                channel_id=metadata.get("channel_id"),
            )

            return NotificationResult(success=True, channel=self.channel_name)
        except Exception as e:
            return NotificationResult(
                success=False,
                channel=self.channel_name,
                error=str(e),
            )


class CLIChannelSender(BaseChannelSender):
    """CLI channel sender - outputs to stdout/stderr."""

    @property
    def channel_name(self) -> ChannelName:
        return ChannelName.CLI

    def __init__(self, output_buffer: list[str] | None = None) -> None:
        """Initialize CLI sender.

        Args:
            output_buffer: Optional buffer for testing (instead of stdout).
        """
        self._buffer = output_buffer

    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Output notification to CLI."""
        try:
            # Format message based on type
            if notification_type == NotificationType.ERROR:
                formatted = f"[ERROR] {message}"
            elif notification_type == NotificationType.WARNING:
                formatted = f"[WARNING] {message}"
            elif notification_type == NotificationType.COMPACT_START:
                formatted = f"[INFO] {message}"
            elif notification_type == NotificationType.COMPACT_END:
                formatted = f"[INFO] {message}"
            else:
                formatted = message

            if self._buffer is not None:
                self._buffer.append(formatted)
            else:
                print(formatted)

            await logger.ainfo(
                "CLI notification sent",
                user_id=str(user_id),
                notification_type=notification_type.value,
            )

            return NotificationResult(success=True, channel=self.channel_name)
        except Exception as e:
            return NotificationResult(
                success=False,
                channel=self.channel_name,
                error=str(e),
            )


class MeetingChannelSender(BaseChannelSender):
    """Meeting channel sender - placeholder for future voice output.

    This is a placeholder implementation. In the future, this would
    integrate with text-to-speech services for meeting contexts.
    """

    @property
    def channel_name(self) -> ChannelName:
        return ChannelName.MEETING

    def __init__(self, output_queue: list[dict[str, Any]] | None = None) -> None:
        """Initialize meeting sender.

        Args:
            output_queue: Optional queue for meeting messages.
        """
        self._queue = output_queue if output_queue is not None else []

    async def send(
        self,
        user_id: UUID,
        message: str,
        notification_type: NotificationType,
        metadata: dict[str, Any],
    ) -> NotificationResult:
        """Queue message for meeting output (future: voice)."""
        try:
            message_data = {
                "user_id": str(user_id),
                "message": message,
                "type": notification_type.value,
                "meeting_id": metadata.get("meeting_id"),
                "timestamp": datetime.now(UTC).isoformat(),
            }
            self._queue.append(message_data)

            await logger.ainfo(
                "Meeting notification queued",
                user_id=str(user_id),
                notification_type=notification_type.value,
            )

            return NotificationResult(success=True, channel=self.channel_name)
        except Exception as e:
            return NotificationResult(
                success=False,
                channel=self.channel_name,
                error=str(e),
            )


# =============================================================================
# Main Service
# =============================================================================


class ChannelNotifier:
    """Send notifications to users via their current channel.

    Provides unified notification interface across all channels:
    - Web: WebSocket push or polling
    - Slack: Bot messages
    - CLI: stdout/stderr
    - Meeting: Voice output (future)

    Example:
        notifier = ChannelNotifier(session_manager)
        await notifier.notify(
            user_id=user_id,
            channel="web",
            message="Context saved",
            message_type="compact_start"
        )
    """

    def __init__(
        self,
        session_manager: UnifiedSessionManager | None = None,
        senders: dict[ChannelName, BaseChannelSender] | None = None,
    ) -> None:
        """Initialize channel notifier.

        Args:
            session_manager: Session manager for getting user channel.
            senders: Optional custom channel senders.
        """
        self._session_manager = session_manager

        # Initialize default senders if not provided
        if senders is not None:
            self._senders = senders
        else:
            self._senders = {
                ChannelName.WEB: WebChannelSender(),
                ChannelName.SLACK: SlackChannelSender(),
                ChannelName.CLI: CLIChannelSender(),
                ChannelName.MEETING: MeetingChannelSender(),
            }

    async def notify(
        self,
        user_id: UUID,
        channel: str,
        message: str,
        message_type: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> NotificationResult:
        """Send notification via appropriate channel.

        Args:
            user_id: User UUID.
            channel: Channel name (web, slack, cli, meeting).
            message: Notification message.
            message_type: Type of notification (info, compact_start, etc.).
            metadata: Optional channel-specific metadata.

        Returns:
            NotificationResult indicating success/failure.
        """
        try:
            channel_enum = ChannelName(channel)
        except ValueError:
            await logger.awarning(
                "Unknown channel, falling back to web",
                channel=channel,
                user_id=str(user_id),
            )
            channel_enum = ChannelName.WEB

        try:
            notification_type = NotificationType(message_type)
        except ValueError:
            notification_type = NotificationType.INFO

        sender = self._senders.get(channel_enum)
        if sender is None:
            return NotificationResult(
                success=False,
                channel=channel_enum,
                error=f"No sender configured for channel: {channel}",
            )

        return await sender.send(
            user_id=user_id,
            message=message,
            notification_type=notification_type,
            metadata=metadata or {},
        )

    async def get_user_channel(self, user_id: UUID) -> str | None:
        """Get user's current active channel.

        Args:
            user_id: User UUID.

        Returns:
            Channel name or None if no active session.
        """
        if self._session_manager is None:
            return None

        session = await self._session_manager.get_session(user_id)
        if session is None:
            return None

        return session.last_channel

    async def notify_compact_start(
        self,
        user_id: UUID,
        channel: str,
        message: str,
        metadata: dict[str, Any] | None = None,
    ) -> NotificationResult:
        """Send compact start notification.

        Args:
            user_id: User UUID.
            channel: Channel name.
            message: Pre-compact message.
            metadata: Optional metadata.

        Returns:
            NotificationResult.
        """
        return await self.notify(
            user_id=user_id,
            channel=channel,
            message=message,
            message_type=NotificationType.COMPACT_START.value,
            metadata=metadata,
        )

    async def notify_compact_end(
        self,
        user_id: UUID,
        channel: str,
        message: str,
        metadata: dict[str, Any] | None = None,
    ) -> NotificationResult:
        """Send compact end notification.

        Args:
            user_id: User UUID.
            channel: Channel name.
            message: Post-compact message.
            metadata: Optional metadata.

        Returns:
            NotificationResult.
        """
        return await self.notify(
            user_id=user_id,
            channel=channel,
            message=message,
            message_type=NotificationType.COMPACT_END.value,
            metadata=metadata,
        )

    def get_sender(self, channel: ChannelName) -> BaseChannelSender | None:
        """Get sender for a specific channel.

        Args:
            channel: Channel name.

        Returns:
            Channel sender or None.
        """
        return self._senders.get(channel)
