"""Strategic Memory Extractor for AI-powered memory extraction.

Component 4.9: Long-term Memory Architecture
Uses Claude to extract strategic memories from a year's events.
"""

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

import structlog
from pydantic import BaseModel, ConfigDict, Field

from ..models import Event
from ..models.archive import (
    MemoryType,
    StrategicMemory,
    YearlySummary,
)

if TYPE_CHECKING:
    import anthropic

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class StrategicExtractionError(Exception):
    """Error during strategic memory extraction."""

    pass


# =============================================================================
# Prompt Templates
# =============================================================================


YEARLY_SUMMARY_PROMPT = """Summarize the year {year} for this user based on their activities:

**Statistics:**
- Events recorded: {event_count}
- Event types: {event_types}
- Months active: {months_active}

**Sample events (most recent):**
{sample_events}

Generate a JSON response with these fields:
1. "summary": A 2-3 paragraph summary of the year in the user's language (based on content language)
2. "key_achievements": Top 5 achievements as a list of strings
3. "lessons_learned": Top 5 lessons or insights as a list of strings
4. "key_relationships": Important relationships or collaborations formed as a list of strings

Respond ONLY with valid JSON, no additional text.
"""

STRATEGIC_EXTRACTION_PROMPT = """Extract strategic memories from this year's events.

**Year:** {year}

**Events to analyze:**
{events_json}

Extract the following strategic memories:
1. **Projects** - Major projects or initiatives
2. **People** - Key relationships and collaborators
3. **Lessons** - Important lessons learned
4. **Decisions** - Significant decisions made
5. **Milestones** - Notable achievements or milestones

For each memory, provide:
- memory_type: "project", "person", "lesson", "decision", or "milestone"
- title: Short descriptive title
- summary: Detailed summary (2-3 sentences)
- keywords: Relevant keywords as a list
- importance: Score from 0.0 to 1.0 (higher = more important)
- related_entities: Optional dict with related entity IDs

Respond with a JSON object containing a "memories" array.
Example:
{{
    "memories": [
        {{
            "memory_type": "project",
            "title": "Website Redesign",
            "summary": "Led the complete redesign of company website...",
            "keywords": ["website", "design", "frontend"],
            "importance": 0.8,
            "related_entities": {{"project_id": "uuid-here"}}
        }}
    ]
}}

Respond ONLY with valid JSON.
"""


# =============================================================================
# Internal Models
# =============================================================================


class ExtractedMemory(BaseModel):
    """Raw memory extracted from AI response."""

    model_config = ConfigDict(extra="forbid")

    memory_type: str
    title: str
    summary: str
    keywords: list[str] = Field(default_factory=list)
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    related_entities: dict[str, Any] | None = None


# =============================================================================
# StrategicMemoryExtractor
# =============================================================================


class StrategicMemoryExtractor:
    """Extract strategic memories from a year's data using AI.

    Uses Claude to analyze events and extract:
    - Projects (with summaries)
    - Key people (with relationship context)
    - Lessons learned
    - Key decisions
    - Milestones

    Example:
        extractor = StrategicMemoryExtractor()

        # Extract memories for a year
        memories = await extractor.extract_for_year(
            year=2023,
            user_id=user_id,
            events=events,
        )

        # Generate yearly summary
        summary = await extractor.generate_yearly_summary(
            year=2023,
            user_id=user_id,
            events=events,
        )
    """

    def __init__(
        self,
        client: "anthropic.Anthropic | anthropic.AsyncAnthropic | None" = None,
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 4096,
    ) -> None:
        """Initialize strategic memory extractor.

        Args:
            client: Anthropic client (creates default if None).
            model: Model to use for extraction.
            max_tokens: Maximum tokens for response.
        """
        self._client = client
        self._model = model
        self._max_tokens = max_tokens

    def _get_client(self) -> "anthropic.Anthropic":
        """Get or create Anthropic client (sync).

        Returns:
            Anthropic client.

        Raises:
            RuntimeError: If no API key configured.
        """
        if self._client is None:
            import anthropic

            self._client = anthropic.Anthropic()
        return self._client

    def _get_async_client(self) -> "anthropic.AsyncAnthropic":
        """Get or create async Anthropic client.

        Returns:
            AsyncAnthropic client.

        Raises:
            RuntimeError: If no API key configured.
        """
        import anthropic

        # Check if we have an async client already
        if self._client is not None and isinstance(self._client, anthropic.AsyncAnthropic):
            return self._client
        # Create new async client (don't cache to avoid mixing sync/async)
        return anthropic.AsyncAnthropic()

    async def extract_for_year(
        self,
        year: int,
        user_id: UUID,
        events: list[Event],
        batch_size: int = 50,
    ) -> list[StrategicMemory]:
        """Extract strategic memories from a year's events.

        Processes events in batches to handle large datasets.

        Args:
            year: Year being processed.
            user_id: User UUID.
            events: List of events to analyze.
            batch_size: Number of events per batch.

        Returns:
            List of extracted strategic memories.

        Raises:
            StrategicExtractionError: If extraction fails.
        """
        if not events:
            return []

        await logger.ainfo(
            "Starting strategic extraction",
            year=year,
            user_id=str(user_id),
            event_count=len(events),
        )

        all_memories: list[StrategicMemory] = []

        try:
            # Process events in batches
            for i in range(0, len(events), batch_size):
                batch = events[i : i + batch_size]
                batch_memories = await self._extract_batch(
                    year=year,
                    user_id=user_id,
                    events=batch,
                )
                all_memories.extend(batch_memories)

            # Deduplicate by title
            seen_titles: set[str] = set()
            unique_memories: list[StrategicMemory] = []
            for memory in all_memories:
                title_key = memory.title.lower().strip()
                if title_key not in seen_titles:
                    seen_titles.add(title_key)
                    unique_memories.append(memory)

            await logger.ainfo(
                "Strategic extraction complete",
                year=year,
                user_id=str(user_id),
                memories_extracted=len(unique_memories),
            )

            return unique_memories

        except Exception as e:
            await logger.aerror(
                "Strategic extraction failed",
                year=year,
                user_id=str(user_id),
                error=str(e),
            )
            raise StrategicExtractionError(f"Extraction failed: {e}") from e

    async def generate_yearly_summary(
        self,
        year: int,
        user_id: UUID,
        events: list[Event],
        sample_size: int = 20,
    ) -> YearlySummary:
        """Generate AI-powered yearly summary.

        Args:
            year: Year to summarize.
            user_id: User UUID.
            events: Events from the year.
            sample_size: Number of sample events to include.

        Returns:
            YearlySummary with AI-generated content.

        Raises:
            StrategicExtractionError: If generation fails.
        """
        if not events:
            return YearlySummary(
                year=year,
                summary=f"No events recorded for year {year}.",
                key_achievements=[],
                lessons_learned=[],
                key_relationships=[],
            )

        await logger.ainfo(
            "Generating yearly summary",
            year=year,
            user_id=str(user_id),
            event_count=len(events),
        )

        try:
            # Calculate statistics
            event_types: dict[str, int] = {}
            months_active: set[int] = set()

            for event in events:
                event_types[event.type] = event_types.get(event.type, 0) + 1
                if event.occurred_at:
                    months_active.add(event.occurred_at.month)

            # Get sample events (most recent)
            sample_events = sorted(
                events,
                key=lambda e: e.occurred_at or datetime.min.replace(tzinfo=UTC),
                reverse=True,
            )[:sample_size]

            sample_text = self._format_sample_events(sample_events)

            # Build prompt
            prompt = YEARLY_SUMMARY_PROMPT.format(
                year=year,
                event_count=len(events),
                event_types=json.dumps(event_types),
                months_active=sorted(months_active),
                sample_events=sample_text,
            )

            # Call Claude
            response = await self._call_claude(prompt)

            # Parse response
            summary_data = self._parse_json_response(response)

            return YearlySummary(
                year=year,
                summary=summary_data.get("summary", f"Summary for year {year}"),
                key_achievements=summary_data.get("key_achievements", []),
                lessons_learned=summary_data.get("lessons_learned", []),
                key_relationships=summary_data.get("key_relationships", []),
            )

        except Exception as e:
            await logger.aerror(
                "Yearly summary generation failed",
                year=year,
                user_id=str(user_id),
                error=str(e),
            )
            # Return minimal summary on error
            return YearlySummary(
                year=year,
                summary=f"Year {year} contained {len(events)} events.",
                key_achievements=[],
                lessons_learned=[],
                key_relationships=[],
            )

    async def _extract_batch(
        self,
        year: int,
        user_id: UUID,
        events: list[Event],
    ) -> list[StrategicMemory]:
        """Extract memories from a batch of events."""
        events_json = self._format_events_for_prompt(events)

        prompt = STRATEGIC_EXTRACTION_PROMPT.format(
            year=year,
            events_json=events_json,
        )

        response = await self._call_claude(prompt)
        data = self._parse_json_response(response)

        memories: list[StrategicMemory] = []
        raw_memories = data.get("memories", [])

        for raw in raw_memories:
            try:
                # Validate memory type
                memory_type_str = raw.get("memory_type", "lesson").lower()
                try:
                    memory_type = MemoryType(memory_type_str)
                except ValueError:
                    memory_type = MemoryType.LESSON  # Default

                # Create strategic memory
                memory = StrategicMemory(
                    id=uuid4(),
                    user_id=user_id,
                    year=year,
                    memory_type=memory_type,
                    entity_id=None,  # Will be linked later if needed
                    title=raw.get("title", "Untitled")[:255],
                    summary=raw.get("summary", ""),
                    keywords=raw.get("keywords", [])[:20],  # Limit keywords
                    importance=min(max(float(raw.get("importance", 0.5)), 0.0), 1.0),
                    related_entities=raw.get("related_entities"),
                    metadata=None,
                    created_at=datetime.now(UTC),
                )
                memories.append(memory)

            except Exception as e:
                await logger.awarning(
                    "Failed to parse extracted memory",
                    error=str(e),
                    raw_memory=raw,
                )

        return memories

    async def _call_claude(self, prompt: str) -> str:
        """Call Claude API with prompt.

        Args:
            prompt: User prompt.

        Returns:
            Response text.

        Raises:
            StrategicExtractionError: If API call fails.
        """
        try:
            # Use async client to avoid blocking the event loop (FIX-4.9.5)
            client = self._get_async_client()

            response = await client.messages.create(
                model=self._model,
                max_tokens=self._max_tokens,
                messages=[{"role": "user", "content": prompt}],
                system="You are a memory analyst helping to extract and summarize key information from personal events. Always respond with valid JSON.",
            )

            # Extract text from response
            response_text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    response_text += block.text

            return response_text

        except Exception as e:
            raise StrategicExtractionError(f"Claude API call failed: {e}") from e

    def _format_events_for_prompt(self, events: list[Event]) -> str:
        """Format events for inclusion in prompt."""
        formatted: list[dict[str, Any]] = []

        for event in events:
            formatted.append({
                "type": event.type,
                "title": event.title,
                "summary": event.summary or event.content[:200] if event.content else None,
                "occurred_at": event.occurred_at.isoformat() if event.occurred_at else None,
                "importance": event.importance,
            })

        return json.dumps(formatted, indent=2, default=str)

    def _format_sample_events(self, events: list[Event]) -> str:
        """Format sample events for display."""
        lines: list[str] = []

        for event in events:
            date_str = event.occurred_at.strftime("%Y-%m-%d") if event.occurred_at else "Unknown"
            title = event.title or event.type
            summary = (event.summary or event.content or "")[:100]
            lines.append(f"- [{date_str}] {title}: {summary}")

        return "\n".join(lines)

    def _parse_json_response(self, response: str) -> dict:
        """Parse JSON from Claude response.

        Handles responses wrapped in markdown code blocks.

        Args:
            response: Raw response text.

        Returns:
            Parsed JSON dict.
        """
        # Try to find JSON in response
        text = response.strip()

        # Remove markdown code blocks if present
        if text.startswith("```json"):
            text = text[7:]
        elif text.startswith("```"):
            text = text[3:]

        if text.endswith("```"):
            text = text[:-3]

        text = text.strip()

        # Find JSON object
        json_start = text.find("{")
        json_end = text.rfind("}") + 1

        if json_start >= 0 and json_end > json_start:
            json_str = text[json_start:json_end]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                pass

        # Return empty dict if parsing fails
        return {}
