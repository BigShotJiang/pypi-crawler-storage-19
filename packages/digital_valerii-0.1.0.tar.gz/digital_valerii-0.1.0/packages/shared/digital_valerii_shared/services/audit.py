"""Audit logging service for tracking system actions."""

from datetime import UTC, date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from ..models.audit_log import AuditLog


def _json_safe(value: Any) -> Any:
    """Convert non-JSON-serializable values to strings.

    Args:
        value: Any value that may need JSON serialization.

    Returns:
        JSON-serializable version of the value.
    """
    if isinstance(value, UUID | Decimal):
        return str(value)
    if isinstance(value, datetime | date):
        return value.isoformat()
    if isinstance(value, list | tuple):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    return value


class AuditService:
    """Service for creating audit log entries.

    Provides methods for logging various types of system actions
    including entity changes, tool usage, and API calls.
    """

    def __init__(self, session: AsyncSession) -> None:
        """Initialize the audit service.

        Args:
            session: Database session for creating log entries.
        """
        self.session = session

    async def log(
        self,
        action: str,
        resource: str,
        *,
        user_id: UUID | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditLog:
        """Create an audit log entry.

        Args:
            action: Action type (login, create, update, delete, tool_use, etc.)
            resource: Resource identifier (user:123, project:456, tool:calendar)
            user_id: ID of the user performing the action.
            ip_address: Client IP address.
            user_agent: Client user agent string.
            details: Additional context as JSON.

        Returns:
            Created AuditLog entry.
        """
        entry = AuditLog(
            timestamp=datetime.now(UTC),
            user_id=user_id,
            action=action,
            resource=resource,
            ip_address=ip_address,
            user_agent=user_agent,
            details=details,
        )
        self.session.add(entry)
        await self.session.flush()
        return entry

    async def log_entity_change(
        self,
        action: str,
        entity_type: str,
        entity_id: UUID,
        *,
        user_id: UUID | None = None,
        changes: dict[str, tuple[Any, Any]] | None = None,
        **kwargs: Any,
    ) -> AuditLog:
        """Log an entity change (create/update/delete).

        Args:
            action: One of 'create', 'update', or 'delete'.
            entity_type: Type of entity (person, project, event, etc.)
            entity_id: ID of the entity.
            user_id: User performing the action.
            changes: Dict of {field: (old_value, new_value)} for updates.
            **kwargs: Additional arguments passed to log().

        Returns:
            Created AuditLog entry.
        """
        details: dict[str, Any] = {"entity_type": entity_type}
        if changes:
            details["changes"] = {
                field: {"old": _json_safe(old), "new": _json_safe(new)}
                for field, (old, new) in changes.items()
            }

        return await self.log(
            action=action,
            resource=f"{entity_type}:{entity_id}",
            user_id=user_id,
            details=details,
            **kwargs,
        )

    async def log_tool_use(
        self,
        tool_name: str,
        *,
        user_id: UUID | None = None,
        parameters: dict[str, Any] | None = None,
        approved: bool = True,
        result: str | None = None,
        **kwargs: Any,
    ) -> AuditLog:
        """Log tool usage for security tracking.

        Args:
            tool_name: Name of the tool used.
            user_id: User who initiated the tool use.
            parameters: Tool parameters (should be sanitized of sensitive data).
            approved: Whether the action was approved.
            result: Result status (success, failure, blocked).
            **kwargs: Additional arguments passed to log().

        Returns:
            Created AuditLog entry.
        """
        details: dict[str, Any] = {
            "parameters": parameters or {},
            "approved": approved,
        }
        if result is not None:
            details["result"] = result

        return await self.log(
            action="tool_use",
            resource=f"tool:{tool_name}",
            user_id=user_id,
            details=details,
            **kwargs,
        )
