"""Redis-based job queue service using arq for async job processing."""

from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlparse

import structlog
from arq import create_pool
from arq.connections import ArqRedis
from arq.connections import RedisSettings as ArqRedisSettings
from arq.jobs import Job
from arq.jobs import JobStatus as ArqJobStatus
from redis.exceptions import RedisError as BaseRedisError

from packages.shared.digital_valerii_shared.config import RedisSettings
from packages.shared.digital_valerii_shared.models.jobs import (
    JobPriority,
    JobResult,
    JobStatus,
    QueueStats,
)

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class JobQueueError(Exception):
    """Base exception for job queue operations."""

    pass


class JobNotFoundError(JobQueueError):
    """Job ID not found."""

    pass


class JobEnqueueError(JobQueueError):
    """Failed to enqueue job."""

    pass


class JobConnectionError(JobQueueError):
    """Failed to connect to job queue."""

    pass


# =============================================================================
# Queue Key Constants
# =============================================================================

QUEUE_KEYS = {
    JobPriority.HIGH: "dv:jobs:high",
    JobPriority.DEFAULT: "dv:jobs:default",
    JobPriority.LOW: "dv:jobs:low",
    JobPriority.SCHEDULED: "dv:jobs:scheduled",
}

# Job metadata key prefix
JOB_METADATA_PREFIX = "dv:job:meta:"


# =============================================================================
# JobQueue Service
# =============================================================================


class JobQueue:
    """Redis-based job queue using arq for async job processing.

    Provides job enqueueing, status tracking, cancellation, and queue statistics.

    Queue Types:
    - HIGH: Critical jobs (sync_qdrant_outbox, cross_store_deletion)
    - DEFAULT: Normal jobs (generate_embeddings, process_meeting_transcript)
    - LOW: Background jobs (extract_lessons, cleanup tasks)
    - SCHEDULED: Cron-scheduled jobs

    Example:
        queue = JobQueue()
        await queue.connect()

        # Enqueue a job
        job_id = await queue.enqueue(
            "generate_embeddings",
            {"content_ids": ["uuid1", "uuid2"]},
            priority=JobPriority.DEFAULT,
        )

        # Check job status
        result = await queue.get_job_status(job_id)
        print(f"Status: {result.status}")

        # Cancel if needed
        await queue.cancel_job(job_id)

        await queue.disconnect()
    """

    def __init__(self, settings: RedisSettings | None = None) -> None:
        """Initialize the job queue.

        Args:
            settings: Redis connection settings. If None, uses defaults.
        """
        self.settings = settings or RedisSettings()
        self._pool: ArqRedis | None = None

    @property
    def pool(self) -> ArqRedis:
        """Get the arq Redis pool.

        Raises:
            JobConnectionError: If not connected.
        """
        if self._pool is None:
            raise JobConnectionError("Job queue not connected. Call connect() first.")
        return self._pool

    def _get_arq_settings(self) -> ArqRedisSettings:
        """Convert RedisSettings to arq RedisSettings.

        Properly handles:
        - redis:// and rediss:// (TLS) schemes
        - username:password authentication (ACL)
        - database selection
        """
        url = self.settings.url
        parsed = urlparse(url)

        # Determine if SSL/TLS is required
        ssl = parsed.scheme == "rediss"

        # Extract components
        host = parsed.hostname or "localhost"
        port = parsed.port or 6379
        database = int(parsed.path.lstrip("/") or 0) if parsed.path else 0
        password = parsed.password
        username = parsed.username  # For Redis ACL

        return ArqRedisSettings(
            host=host,
            port=port,
            database=database,
            password=password,
            username=username,
            ssl=ssl,
            conn_timeout=int(self.settings.socket_connect_timeout),
            conn_retries=3,
        )

    async def connect(self) -> None:
        """Establish connection to Redis for job queue.

        Creates an arq connection pool and verifies connectivity.

        Raises:
            JobConnectionError: If connection fails.
        """
        if self._pool is not None:
            return

        pool = None
        try:
            arq_settings = self._get_arq_settings()
            pool = await create_pool(arq_settings)

            # Test connection
            await pool.ping()

            self._pool = pool
            await logger.ainfo("Job queue connected", url=self.settings.url)
        except Exception as e:
            if pool:
                await pool.close()
            raise JobConnectionError(f"Failed to connect to job queue: {e}") from e

    async def disconnect(self) -> None:
        """Close the job queue connection."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
            await logger.ainfo("Job queue connection closed")

    async def health_check(self) -> bool:
        """Check if job queue is reachable.

        Returns:
            True if healthy, False otherwise.
        """
        try:
            if self._pool is None:
                return False
            await self._pool.ping()
            return True
        except Exception:
            return False

    # =========================================================================
    # Job Operations
    # =========================================================================

    async def enqueue(
        self,
        job_name: str,
        payload: dict,
        priority: JobPriority = JobPriority.DEFAULT,
        delay_seconds: int | None = None,
    ) -> str:
        """Enqueue a job for processing.

        Args:
            job_name: Name of the job function to execute.
            payload: Job-specific data.
            priority: Queue priority level.
            delay_seconds: Delay before job execution.

        Returns:
            Job ID for tracking.

        Raises:
            JobEnqueueError: If enqueueing fails.
        """
        try:
            # Get the queue name for the priority
            queue_name = QUEUE_KEYS.get(priority, QUEUE_KEYS[JobPriority.DEFAULT])

            # Prepare job options
            job_kwargs = {
                "_queue_name": queue_name,
            }

            if delay_seconds is not None and delay_seconds > 0:
                job_kwargs["_defer_by"] = delay_seconds

            # Enqueue using arq
            job = await self.pool.enqueue_job(
                job_name,
                payload,
                **job_kwargs,
            )

            if job is None:
                raise JobEnqueueError(f"Failed to enqueue job {job_name}: job is None")

            job_id = job.job_id

            # Store job metadata for tracking
            metadata = {
                "job_name": job_name,
                "priority": priority.value,
                "created_at": datetime.now(UTC).isoformat(),
                "status": JobStatus.QUEUED.value,
            }
            await self.pool.set(
                f"{JOB_METADATA_PREFIX}{job_id}",
                str(metadata),
                ex=86400,  # 24 hour TTL for metadata
            )

            await logger.ainfo(
                "Job enqueued",
                job_id=job_id,
                job_name=job_name,
                priority=priority.value,
                delay=delay_seconds,
            )

            return job_id

        except JobEnqueueError:
            raise
        except Exception as e:
            raise JobEnqueueError(f"Failed to enqueue job {job_name}: {e}") from e

    async def get_job_status(self, job_id: str) -> JobResult:
        """Get the status of a job.

        Args:
            job_id: The job identifier.

        Returns:
            JobResult with current status.

        Raises:
            JobNotFoundError: If job doesn't exist.
            JobQueueError: If status check fails.
        """
        try:
            job = Job(job_id, self.pool)
            job_info = await job.info()

            if job_info is None:
                raise JobNotFoundError(f"Job {job_id} not found")

            # Map arq status to our status
            status = self._map_arq_status(job_info.status)

            # Get result or error
            result = None
            error = None
            completed_at = None

            if status == JobStatus.COMPLETE:
                result = job_info.result if isinstance(job_info.result, dict) else {}
                completed_at = job_info.finish_time
            elif status == JobStatus.FAILED:
                error = str(job_info.result) if job_info.result else "Unknown error"
                completed_at = job_info.finish_time

            # Use enqueue_time as created_at
            created_at = job_info.enqueue_time or datetime.now(UTC)

            return JobResult(
                job_id=job_id,
                status=status,
                result=result,
                error=error,
                created_at=created_at,
                completed_at=completed_at,
            )

        except JobNotFoundError:
            raise
        except Exception as e:
            raise JobQueueError(f"Failed to get job status for {job_id}: {e}") from e

    def _map_arq_status(self, arq_status: ArqJobStatus | None) -> JobStatus:
        """Map arq job status to our JobStatus enum.

        Args:
            arq_status: The arq job status.

        Returns:
            Corresponding JobStatus.
        """
        if arq_status is None:
            return JobStatus.QUEUED

        status_map = {
            ArqJobStatus.deferred: JobStatus.DEFERRED,
            ArqJobStatus.queued: JobStatus.QUEUED,
            ArqJobStatus.in_progress: JobStatus.IN_PROGRESS,
            ArqJobStatus.complete: JobStatus.COMPLETE,
            ArqJobStatus.not_found: JobStatus.FAILED,
        }
        return status_map.get(arq_status, JobStatus.QUEUED)

    async def cancel_job(self, job_id: str) -> bool:
        """Cancel a queued job.

        Can only cancel jobs that haven't started processing.

        Args:
            job_id: The job identifier.

        Returns:
            True if job was cancelled, False if already running or complete.

        Raises:
            JobNotFoundError: If job doesn't exist.
            JobQueueError: If cancellation fails.
        """
        try:
            job = Job(job_id, self.pool)
            job_info = await job.info()

            if job_info is None:
                raise JobNotFoundError(f"Job {job_id} not found")

            # Can only cancel if queued or deferred
            if job_info.status not in (ArqJobStatus.queued, ArqJobStatus.deferred):
                return False

            # Abort the job
            await job.abort()

            await logger.ainfo("Job cancelled", job_id=job_id)
            return True

        except JobNotFoundError:
            raise
        except Exception as e:
            raise JobQueueError(f"Failed to cancel job {job_id}: {e}") from e

    async def get_queue_stats(self) -> QueueStats:
        """Get statistics for all queues.

        Returns:
            QueueStats with job counts per queue.

        Raises:
            JobQueueError: If stats retrieval fails.
        """
        try:
            high = await self._get_queue_length(QUEUE_KEYS[JobPriority.HIGH])
            default = await self._get_queue_length(QUEUE_KEYS[JobPriority.DEFAULT])
            low = await self._get_queue_length(QUEUE_KEYS[JobPriority.LOW])
            scheduled = await self._get_queue_length(QUEUE_KEYS[JobPriority.SCHEDULED])

            total = high + default + low + scheduled

            return QueueStats(
                high_priority=high,
                default=default,
                low_priority=low,
                scheduled=scheduled,
                total=total,
            )

        except BaseRedisError as e:
            raise JobQueueError(f"Failed to get queue stats: {e}") from e

    async def _get_queue_length(self, queue_key: str) -> int:
        """Get the length of a specific queue.

        arq uses sorted sets (ZSET) for queues, not lists.

        Args:
            queue_key: The Redis key for the queue.

        Returns:
            Number of jobs in the queue. Returns 0 on Redis errors (logged).
        """
        try:
            length = await self.pool.zcard(queue_key)
            return length if length else 0
        except BaseRedisError as e:
            await logger.awarning(
                "Failed to get queue length",
                queue_key=queue_key,
                error=str(e),
            )
            return 0

    # =========================================================================
    # Batch Operations
    # =========================================================================

    async def enqueue_batch(
        self,
        jobs: list[dict[str, Any]],
        priority: JobPriority = JobPriority.DEFAULT,
    ) -> list[str]:
        """Enqueue multiple jobs.

        Args:
            jobs: List of job dicts with 'job_name' and 'payload'.
            priority: Queue priority for all jobs.

        Returns:
            List of job IDs.

        Raises:
            JobEnqueueError: If any job fails to enqueue.
        """
        job_ids = []
        for job in jobs:
            job_id = await self.enqueue(
                job["job_name"],
                job.get("payload", {}),
                priority=priority,
                delay_seconds=job.get("delay_seconds"),
            )
            job_ids.append(job_id)
        return job_ids

    async def get_pending_jobs(
        self,
        priority: JobPriority | None = None,
        limit: int = 100,
    ) -> list[str]:
        """Get IDs of pending jobs.

        arq uses sorted sets (ZSET) for queues, so we use ZRANGE.

        Args:
            priority: Optional priority filter. None returns all.
            limit: Maximum number of job IDs to return.

        Returns:
            List of job IDs.
        """
        job_ids: list[str] = []

        if priority is not None:
            queues = [QUEUE_KEYS[priority]]
        else:
            queues = list(QUEUE_KEYS.values())

        for queue_key in queues:
            if len(job_ids) >= limit:
                break
            try:
                remaining = limit - len(job_ids)
                # ZRANGE for sorted sets (returns members only, not scores)
                ids = await self.pool.zrange(queue_key, 0, remaining - 1)
                job_ids.extend(ids or [])
            except Exception:
                continue

        return job_ids[:limit]
