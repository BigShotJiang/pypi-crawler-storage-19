"""Unified memory manager for Digital Valerii.

Orchestrates PostgreSQL, Qdrant, and Redis for hybrid memory operations.
Provides semantic search, working memory management, and time-decay ranking.
"""

import contextlib
import hashlib
import math
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

import structlog
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from ..database import Database
from ..models import Event, EventParticipant, Lesson, Person, Project
from .embedding import EmbeddingError, EmbeddingService
from .qdrant import QdrantError, QdrantService, SearchResult
from .redis import RedisError, RedisNamespace, RedisService, WorkingMemory

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession
    from .tiered_memory import TieredMemoryManager

logger = structlog.get_logger(__name__)


# =============================================================================
# Constants
# =============================================================================

# Cache configuration
RECALL_CACHE_TTL = 300  # 5 minutes

# Working memory limits
MAX_WORKING_MEMORY_MESSAGES = 20

# Ranking weights
VECTOR_SCORE_WEIGHT = 0.7
IMPORTANCE_WEIGHT = 0.2
TIME_DECAY_WEIGHT = 0.1


# =============================================================================
# Decay Configuration
# =============================================================================


@dataclass(frozen=True)
class DecayConfig:
    """Time decay configuration per event type."""

    half_life_days: int  # Days until importance halves
    min_retention_days: int  # Never decay below this age
    boost_on_recall: float  # Boost when recalled


DECAY_CONFIGS: dict[str, DecayConfig] = {
    "conversation": DecayConfig(180, 7, 0.1),
    "meeting": DecayConfig(365, 30, 0.15),
    "lesson": DecayConfig(730, 90, 0.2),
    "project_milestone": DecayConfig(545, 60, 0.15),
    "email": DecayConfig(180, 7, 0.1),
    "call": DecayConfig(180, 14, 0.1),
}

DEFAULT_DECAY_CONFIG = DecayConfig(180, 7, 0.1)


# =============================================================================
# Exceptions
# =============================================================================


class MemoryError(Exception):
    """Base exception for memory operations."""

    pass


class MemoryRecallError(MemoryError):
    """Raised when recall fails."""

    pass


class MemoryStoreError(MemoryError):
    """Raised when store fails."""

    pass


class MemoryNotFoundError(MemoryError):
    """Raised when requested memory doesn't exist."""

    pass


# =============================================================================
# Pydantic Models
# =============================================================================


class RankedEvent(BaseModel):
    """Event with computed ranking score."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    event_id: UUID
    event_type: str
    title: str | None = None
    summary: str | None = None
    occurred_at: datetime
    importance: float
    vector_score: float  # From Qdrant similarity
    time_decay: float  # Based on age
    final_score: float  # Combined ranking


class Context(BaseModel):
    """Current interaction context."""

    model_config = ConfigDict(extra="forbid")

    session_id: str
    conversation_id: str | None = None
    message_index: int = 0
    interface: str = "cli"  # cli, web, slack, meeting


class PersonSummary(BaseModel):
    """Person summary for memory context."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    name: str
    email: str | None = None
    company: str | None = None
    relationship_type: str | None = None


class ProjectSummary(BaseModel):
    """Project summary for memory context."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    name: str
    status: str
    description: str | None = None


class LessonSummary(BaseModel):
    """Lesson summary for memory context."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    content: str
    category: str | None = None
    confidence: float


class MemoryContext(BaseModel):
    """Recall result with ranked memories."""

    model_config = ConfigDict(extra="forbid")

    events: list[RankedEvent] = Field(default_factory=list)
    people: list[PersonSummary] = Field(default_factory=list)
    projects: list[ProjectSummary] = Field(default_factory=list)
    lessons: list[LessonSummary] = Field(default_factory=list)
    query: str
    cached: bool = False


# =============================================================================
# MemoryManager
# =============================================================================


class MemoryManager:
    """Unified memory manager combining all storage backends.

    Features:
    - Hybrid search (vector + structured)
    - Working memory management
    - Recall with time decay ranking
    - Store with idempotency
    - Caching for performance

    Example:
        manager = MemoryManager(db, qdrant, redis, embedding)

        # Recall relevant memories
        context = await manager.recall("What did we discuss about the project?", ctx)

        # Store new interaction
        event = await manager.store("user message", "agent response", ctx)

        # Get working memory
        wm = await manager.get_working_memory("session123")
    """

    def __init__(
        self,
        db: Database,
        qdrant: QdrantService,
        redis: RedisService,
        embedding: EmbeddingService,
    ) -> None:
        """Initialize the memory manager.

        Args:
            db: Database connection for structured data.
            qdrant: Qdrant service for vector search.
            redis: Redis service for caching and working memory.
            embedding: Embedding service for text embeddings.
        """
        self._db = db
        self._qdrant = qdrant
        self._redis = redis
        self._embedding = embedding
        self._tiered: "TieredMemoryManager | None" = None

    # =========================================================================
    # Tiered Memory Integration (Component 4.9)
    # =========================================================================

    def set_tiered_manager(self, tiered: "TieredMemoryManager") -> None:
        """Set tiered memory manager for archive support.

        Args:
            tiered: TieredMemoryManager instance.
        """
        self._tiered = tiered

    async def recall_with_archives(
        self,
        query: str,
        user_id: UUID,
        include_archives: list[int] | None = None,
        auto_detect_years: bool = True,
        limit: int = 20,
    ) -> MemoryContext:
        """Enhanced recall that includes archive search.

        Searches across current active memory and relevant archives
        based on year detection in the query.

        Args:
            query: Search query.
            user_id: User UUID.
            include_archives: Explicit years to include.
            auto_detect_years: Auto-detect years from query.
            limit: Maximum results to return.

        Returns:
            MemoryContext with results from active and archive memory.

        Raises:
            MemoryRecallError: If recall fails.
        """
        if not self._tiered:
            # Fall back to regular recall if no tiered manager
            from .redis import WorkingMemory

            # Create minimal context for basic recall
            session_id = str(user_id)
            context = Context(session_id=session_id)
            return await self.recall(query, context, limit=limit)

        try:
            # Use tiered memory manager for cross-tier search
            tiered_context = await self._tiered.recall(
                query=query,
                user_id=user_id,
                include_archives=include_archives,
                auto_detect_years=auto_detect_years,
                limit=limit,
                include_strategic=True,
            )

            # Convert TieredMemoryContext to MemoryContext
            # Extract active events as RankedEvents (active_events are dicts)
            ranked_events: list[RankedEvent] = []
            for event in tiered_context.active_events:
                # Use dict.get() since active_events are dicts
                event_id = event.get("id") or event.get("event_id")
                occurred_at_raw = event.get("occurred_at")
                occurred_at = (
                    datetime.fromisoformat(occurred_at_raw)
                    if isinstance(occurred_at_raw, str)
                    else occurred_at_raw
                )
                ranked_events.append(
                    RankedEvent(
                        event_id=UUID(event_id) if isinstance(event_id, str) else event_id,
                        event_type=event.get("type") or event.get("event_type", "unknown"),
                        title=event.get("title"),
                        summary=event.get("summary"),
                        occurred_at=occurred_at or datetime.now(UTC),
                        importance=event.get("importance", 0.5),
                        vector_score=event.get("score") or event.get("vector_score", 0.5),
                        time_decay=event.get("time_decay", 0.0),
                        final_score=event.get("score") or event.get("final_score", 0.5),
                    )
                )

            # Add archived events as RankedEvents
            for archived in tiered_context.archived_events:
                # ArchivedEvent has content not summary, and no relevance_score
                relevance_score = getattr(archived, "relevance_score", None) or 0.5
                ranked_events.append(
                    RankedEvent(
                        event_id=archived.id,
                        event_type=archived.event_type,
                        title=archived.title,
                        summary=archived.content,  # Use content as summary
                        occurred_at=archived.occurred_at or datetime.now(UTC),
                        importance=archived.importance or 0.5,
                        vector_score=relevance_score,
                        time_decay=0.0,  # Already decayed in archive
                        final_score=relevance_score,
                    )
                )

            # Sort by final score and limit
            ranked_events.sort(key=lambda e: e.final_score, reverse=True)
            ranked_events = ranked_events[:limit]

            return MemoryContext(
                events=ranked_events,
                people=[],  # Not available in tiered context
                projects=[],  # Not available in tiered context
                lessons=[],  # Not available in tiered context
                query=query,
                cached=False,
            )

        except Exception as e:
            raise MemoryRecallError(f"Archive recall failed: {e}") from e

    # =========================================================================
    # Recall Methods
    # =========================================================================

    async def recall(
        self,
        query: str,
        context: Context,
        limit: int = 10,
    ) -> MemoryContext:
        """Recall relevant memories using hybrid search.

        Steps:
        1. Check cache
        2. Generate query embedding
        3. Vector search in Qdrant
        4. Get related structured data
        5. Rank with time decay
        6. Cache and return

        Args:
            query: Search query.
            context: Current interaction context.
            limit: Maximum number of events to return.

        Returns:
            MemoryContext with ranked results.

        Raises:
            MemoryRecallError: If recall fails.
        """
        if not query.strip():
            return MemoryContext(query=query, cached=False)

        # Check cache (include limit in key to avoid wrong cache hits)
        cache_key = self._get_cache_key(query, context.session_id, limit)
        cached = await self._get_cached_recall(cache_key)
        if cached is not None:
            await logger.adebug("Recall cache hit", query_len=len(query))
            return cached

        try:
            # Generate query embedding
            query_embedding = await self._embedding.embed(query)

            # Vector search in Qdrant
            search_results = await self._qdrant.search(
                collection="memories",
                query_vector=query_embedding,
                limit=limit * 2,  # Get more for ranking
            )

            if not search_results:
                result = MemoryContext(query=query, cached=False)
                await self._cache_recall(cache_key, result)
                return result

            # Get event IDs from search results
            event_ids = [r.id for r in search_results]

            # Get related data from PostgreSQL
            async with self._db.session() as session:
                events = await self._get_events_by_ids(session, event_ids)
                people = await self._get_related_people(session, event_ids)
                projects = await self._get_related_projects(session, event_ids)
                lessons = await self._get_related_lessons(session, event_ids)

            # Rank events with time decay
            query_time = datetime.now(UTC)
            ranked_events = self._rank_by_relevance(search_results, events, query_time)[
                :limit
            ]

            # Build result
            result = MemoryContext(
                events=ranked_events,
                people=[
                    PersonSummary(
                        id=p.id,
                        name=p.name,
                        email=p.email,
                        company=p.company,
                        relationship_type=p.relationship_type,
                    )
                    for p in people
                ],
                projects=[
                    ProjectSummary(
                        id=p.id,
                        name=p.name,
                        status=p.status,
                        description=p.description,
                    )
                    for p in projects
                ],
                lessons=[
                    LessonSummary(
                        id=ls.id,
                        content=ls.content,
                        category=ls.category,
                        confidence=ls.confidence,
                    )
                    for ls in lessons
                ],
                query=query,
                cached=False,
            )

            # Cache result
            await self._cache_recall(cache_key, result)

            await logger.ainfo(
                "Memory recall completed",
                query_len=len(query),
                events=len(ranked_events),
                people=len(people),
                projects=len(projects),
                lessons=len(lessons),
            )

            return result

        except EmbeddingError as e:
            raise MemoryRecallError(f"Failed to embed query: {e}") from e
        except QdrantError as e:
            raise MemoryRecallError(f"Vector search failed: {e}") from e
        except Exception as e:
            raise MemoryRecallError(f"Recall failed: {e}") from e

    def _rank_by_relevance(
        self,
        search_results: list[SearchResult],
        events: dict[UUID, Event],
        query_time: datetime,
    ) -> list[RankedEvent]:
        """Rank events with time decay.

        Formula:
            time_decay = exp(-age_days / half_life_days)
            final_score = vector_score * 0.7 + importance * 0.2 + time_decay * 0.1

        Args:
            search_results: Results from Qdrant search.
            events: Events indexed by ID.
            query_time: Current time for decay calculation.

        Returns:
            List of ranked events sorted by final score.
        """
        ranked: list[RankedEvent] = []

        for result in search_results:
            event = events.get(result.id)
            if event is None:
                continue

            # Get decay config for event type
            decay_config = DECAY_CONFIGS.get(event.type, DEFAULT_DECAY_CONFIG)

            # Calculate time decay
            age_days = (query_time - event.occurred_at).total_seconds() / 86400
            if age_days < decay_config.min_retention_days:
                time_decay = 1.0
            else:
                time_decay = math.exp(-age_days / decay_config.half_life_days)

            # Get importance with default for null values
            importance = event.importance if event.importance is not None else 0.5

            # Calculate final score
            final_score = (
                result.score * VECTOR_SCORE_WEIGHT
                + importance * IMPORTANCE_WEIGHT
                + time_decay * TIME_DECAY_WEIGHT
            )

            ranked.append(
                RankedEvent(
                    event_id=event.id,
                    event_type=event.type,
                    title=event.title,
                    summary=event.summary,
                    occurred_at=event.occurred_at,
                    importance=importance,
                    vector_score=result.score,
                    time_decay=time_decay,
                    final_score=final_score,
                )
            )

        # Sort by final score descending
        ranked.sort(key=lambda e: e.final_score, reverse=True)
        return ranked

    async def _get_events_by_ids(
        self,
        session: "AsyncSession",
        event_ids: list[UUID],
    ) -> dict[UUID, Event]:
        """Get events by IDs with eager loading."""
        if not event_ids:
            return {}

        stmt = (
            select(Event)
            .where(Event.id.in_(event_ids))
            .where(Event.deleted_at.is_(None))
            .options(
                selectinload(Event.participants).selectinload(EventParticipant.person)
            )
        )
        result = await session.execute(stmt)
        events = result.scalars().unique().all()
        return {e.id: e for e in events}

    async def _get_related_people(
        self,
        session: "AsyncSession",
        event_ids: list[UUID],
    ) -> list[Person]:
        """Get people related to events with selectinload to prevent N+1."""
        if not event_ids:
            return []

        stmt = (
            select(Person)
            .join(EventParticipant)
            .where(EventParticipant.event_id.in_(event_ids))
            .where(Person.deleted_at.is_(None))
            .options(selectinload(Person.event_participations))
        )
        result = await session.execute(stmt)
        return list(result.scalars().unique())

    async def _get_related_projects(
        self,
        session: "AsyncSession",
        event_ids: list[UUID],
    ) -> list[Project]:
        """Get projects related to events."""
        if not event_ids:
            return []

        stmt = (
            select(Project)
            .join(Event, Event.project_id == Project.id)
            .where(Event.id.in_(event_ids))
            .where(Project.deleted_at.is_(None))
        )
        result = await session.execute(stmt)
        return list(result.scalars().unique())

    async def _get_related_lessons(
        self,
        session: "AsyncSession",
        event_ids: list[UUID],
    ) -> list[Lesson]:
        """Get lessons derived from events."""
        if not event_ids:
            return []

        stmt = (
            select(Lesson)
            .where(Lesson.source_event_id.in_(event_ids))
            .where(Lesson.deleted_at.is_(None))
        )
        result = await session.execute(stmt)
        return list(result.scalars().unique())

    # =========================================================================
    # Store Methods
    # =========================================================================

    async def store(
        self,
        user_message: str,
        agent_response: str,
        context: Context,
        event_type: str = "conversation",
        importance: float = 0.5,
    ) -> Event:
        """Store an interaction with idempotency.

        Args:
            user_message: User's message.
            agent_response: Agent's response.
            context: Current interaction context.
            event_type: Type of event.
            importance: Importance score (0.0 to 1.0).

        Returns:
            Created or existing Event.

        Raises:
            MemoryStoreError: If store fails.
        """
        # Generate idempotency key
        idem_key = self._generate_idempotency_key(user_message, context)

        # Check if already processed
        existing_id = await self._check_idempotency(idem_key)
        if existing_id is not None:
            await logger.adebug("Store idempotency hit", idem_key=idem_key)
            async with self._db.session() as session:
                event = await session.get(Event, existing_id)
                if event is not None:
                    return event

        try:
            # Generate embedding BEFORE any DB work (fail early)
            content = f"User: {user_message}\nAssistant: {agent_response}"
            embedding = await self._embedding.embed(content)

            # Create event
            event = Event(
                id=uuid4(),
                type=event_type,
                title=user_message[:100] if user_message else None,
                summary=agent_response[:500] if agent_response else None,
                content=content,
                importance=importance,
                occurred_at=datetime.now(UTC),
                source=context.interface,
                metadata_={"session_id": context.session_id},
            )

            # Store in DB and Qdrant atomically (rollback DB if Qdrant fails)
            async with self._db.session() as session:
                session.add(event)
                await session.flush()
                event_id = event.id

                try:
                    # Try Qdrant upsert within DB transaction context
                    await self._qdrant.upsert(
                        collection="memories",
                        id=event_id,
                        vector=embedding,
                        payload={
                            "type": event_type,
                            "timestamp": event.occurred_at.isoformat(),
                            "importance": importance,
                        },
                    )
                except QdrantError as e:
                    # Rollback DB transaction by raising within session context
                    raise MemoryStoreError(f"Failed to store vector: {e}") from e

                # Session commits on successful exit

            # Mark as processed only after both DB and Qdrant succeed
            await self._mark_processed(idem_key, event_id)

            await logger.ainfo(
                "Memory stored",
                event_id=str(event_id),
                event_type=event_type,
            )

            return event

        except EmbeddingError as e:
            raise MemoryStoreError(f"Failed to embed content: {e}") from e
        except MemoryStoreError:
            raise
        except Exception as e:
            raise MemoryStoreError(f"Store failed: {e}") from e

    def _generate_idempotency_key(
        self,
        message: str,
        context: Context,
    ) -> str:
        """Generate key to prevent duplicate stores."""
        content = f"{context.session_id}:{context.message_index}:{message[:100]}"
        return hashlib.sha256(content.encode()).hexdigest()[:32]

    async def _check_idempotency(self, key: str) -> UUID | None:
        """Check if this message was already stored."""
        try:
            result = await self._redis.get(f"idem:{key}", RedisNamespace.CACHE)
            if result is not None:
                return UUID(result)
            return None
        except (RedisError, ValueError):
            return None

    async def _mark_processed(self, key: str, event_id: UUID) -> None:
        """Mark message as processed."""
        with contextlib.suppress(RedisError):
            await self._redis.set(
                f"idem:{key}",
                str(event_id),
                RedisNamespace.CACHE,
                ttl=3600,  # 1 hour
            )

    # =========================================================================
    # Working Memory Methods
    # =========================================================================

    async def get_working_memory(
        self,
        session_id: str,
    ) -> WorkingMemory | None:
        """Get current session context from Redis.

        Args:
            session_id: Session identifier.

        Returns:
            WorkingMemory if exists, None otherwise.
        """
        try:
            data = await self._redis.get_working_memory(session_id)
            if data is None:
                return None
            return WorkingMemory(**data)
        except RedisError:
            return None

    async def update_working_memory(
        self,
        session_id: str,
        messages: list[dict[str, Any]] | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Update session context in Redis.

        Args:
            session_id: Session identifier.
            messages: Optional messages to set.
            context: Optional context to merge.
        """
        try:
            updates: dict[str, Any] = {
                "session_id": session_id,
                "updated_at": datetime.now(UTC).isoformat(),
            }

            if messages is not None:
                updates["messages"] = messages

            if context is not None:
                existing = await self._redis.get_working_memory(session_id) or {}
                existing_context = existing.get("context", {})
                existing_context.update(context)
                updates["context"] = existing_context

            await self._redis.update_working_memory(session_id, updates)
        except RedisError as e:
            await logger.awarning("Failed to update working memory", error=str(e))

    async def clear_working_memory(
        self,
        session_id: str,
    ) -> None:
        """Clear session context on logout/timeout.

        Args:
            session_id: Session identifier.
        """
        with contextlib.suppress(RedisError):
            await self._redis.delete_working_memory(session_id)

    async def add_message_to_working_memory(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Add message to current conversation context.

        Args:
            session_id: Session identifier.
            role: Message role ("user" or "assistant").
            content: Message content.
            metadata: Optional message metadata.
        """
        try:
            existing = await self._redis.get_working_memory(session_id) or {}
            messages = existing.get("messages", [])

            # Add new message
            messages.append(
                {
                    "role": role,
                    "content": content,
                    "metadata": metadata or {},
                    "timestamp": datetime.now(UTC).isoformat(),
                }
            )

            # Trim if exceeds limit
            if len(messages) > MAX_WORKING_MEMORY_MESSAGES:
                messages = messages[-MAX_WORKING_MEMORY_MESSAGES:]

            await self.update_working_memory(session_id, messages=messages)
        except RedisError as e:
            await logger.awarning(
                "Failed to add message to working memory", error=str(e)
            )

    # =========================================================================
    # People/Project Methods
    # =========================================================================

    async def get_person(self, person_id: UUID) -> Person | None:
        """Get person with eager loading.

        Args:
            person_id: Person UUID.

        Returns:
            Person if found, None otherwise.
        """
        async with self._db.session() as session:
            stmt = (
                select(Person)
                .where(Person.id == person_id)
                .where(Person.deleted_at.is_(None))
                .options(selectinload(Person.event_participations))
            )
            result = await session.execute(stmt)
            return result.scalar_one_or_none()

    async def get_project(self, project_id: UUID) -> Project | None:
        """Get project with eager loading.

        Args:
            project_id: Project UUID.

        Returns:
            Project if found, None otherwise.
        """
        async with self._db.session() as session:
            stmt = (
                select(Project)
                .where(Project.id == project_id)
                .where(Project.deleted_at.is_(None))
            )
            result = await session.execute(stmt)
            return result.scalar_one_or_none()

    async def search_people(
        self,
        query: str,
        limit: int = 10,
    ) -> list[Person]:
        """Search people by name or organization.

        Args:
            query: Search query.
            limit: Maximum results.

        Returns:
            List of matching people.
        """
        if not query.strip():
            return []

        async with self._db.session() as session:
            pattern = f"%{query}%"
            stmt = (
                select(Person)
                .where(Person.deleted_at.is_(None))
                .where(
                    (Person.name.ilike(pattern))
                    | (Person.company.ilike(pattern))
                    | (Person.email.ilike(pattern))
                )
                .limit(limit)
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def search_projects(
        self,
        query: str,
        limit: int = 10,
    ) -> list[Project]:
        """Search projects by name.

        Args:
            query: Search query.
            limit: Maximum results.

        Returns:
            List of matching projects.
        """
        if not query.strip():
            return []

        async with self._db.session() as session:
            pattern = f"%{query}%"
            stmt = (
                select(Project)
                .where(Project.deleted_at.is_(None))
                .where(
                    (Project.name.ilike(pattern)) | (Project.description.ilike(pattern))
                )
                .limit(limit)
            )
            result = await session.execute(stmt)
            return list(result.scalars().all())

    # =========================================================================
    # Cache Methods
    # =========================================================================

    def _get_cache_key(self, query: str, session_id: str, limit: int) -> str:
        """Generate deterministic cache key including limit."""
        content = f"{session_id}:{limit}:{query}"
        return f"recall:{hashlib.sha256(content.encode()).hexdigest()[:16]}"

    async def _get_cached_recall(self, key: str) -> MemoryContext | None:
        """Get cached recall result."""
        try:
            data = await self._redis.cache_get(key)
            if data is None:
                return None
            # Mark as cached
            data["cached"] = True
            return MemoryContext(**data)
        except (RedisError, Exception):
            return None

    async def _cache_recall(self, key: str, result: MemoryContext) -> None:
        """Cache recall result."""
        with contextlib.suppress(RedisError):
            await self._redis.cache_set(
                key,
                result.model_dump(mode="json"),
                ttl=RECALL_CACHE_TTL,
            )

    # =========================================================================
    # Health Check
    # =========================================================================

    async def health_check(self) -> dict[str, bool]:
        """Check health of all backends.

        Returns:
            Dictionary with health status of each backend.
        """
        return {
            "database": await self._db.health_check(),
            "qdrant": await self._qdrant.health_check(),
            "redis": await self._redis.health_check(),
            "embedding": await self._embedding.health_check(),
        }
