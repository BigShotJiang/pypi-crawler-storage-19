"""Redis cache service for session and working memory management."""

import asyncio
import json
import secrets
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field
from redis.asyncio import ConnectionPool, Redis
from redis.exceptions import ConnectionError as RedisConnError
from redis.exceptions import RedisError as BaseRedisError

from ..config import RedisSettings

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class RedisError(Exception):
    """Base exception for Redis operations."""

    pass


class RedisConnectionError(RedisError):
    """Raised when connection to Redis fails."""

    pass


class RedisKeyError(RedisError):
    """Raised when key operations fail."""

    pass


class RedisLockError(RedisError):
    """Raised when lock operations fail."""

    pass


class RedisSerializationError(RedisError):
    """Raised when serialization/deserialization fails."""

    pass


# =============================================================================
# Enums
# =============================================================================


class RedisNamespace(str, Enum):
    """Redis key prefixes for namespacing."""

    SESSIONS = "dv:sessions:"
    CACHE = "dv:cache:"
    RATE_LIMIT = "dv:rate:"
    LOCKS = "dv:lock:"
    WORKING_MEMORY = "dv:wm:"
    JOBS = "dv:jobs:"
    OUTBOX = "dv:outbox:"
    APPROVALS = "dv:approval:"


# =============================================================================
# Pydantic Models
# =============================================================================


class SessionData(BaseModel):
    """Session data structure."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    user_id: str
    created_at: datetime
    last_activity: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkingMemory(BaseModel):
    """Working memory for conversation context."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    session_id: str
    conversation_id: str | None = None
    messages: list[dict[str, Any]] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)
    updated_at: datetime


# =============================================================================
# Lua Scripts for Atomic Operations
# =============================================================================

# Release lock only if token matches
RELEASE_LOCK_SCRIPT = """
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
"""

# Extend lock only if token matches
EXTEND_LOCK_SCRIPT = """
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("expire", KEYS[1], ARGV[2])
else
    return 0
end
"""

# Safety limit for SCAN iterations
MAX_SCAN_ITERATIONS = 1000


# =============================================================================
# RedisService
# =============================================================================


class RedisService:
    """Async Redis client wrapper with namespacing and connection management.

    Provides session management, working memory, caching, and distributed locks.

    Namespaces:
    - SESSIONS: User session data (24h TTL)
    - WORKING_MEMORY: Current conversation context (1h TTL)
    - CACHE: General cache (5min TTL)
    - RATE_LIMIT: Sliding window counters
    - LOCKS: Distributed locks (30s TTL)
    - JOBS: Background job queues
    - OUTBOX: Outbox processing state
    - APPROVALS: Pending tool approvals (5min TTL)

    Example:
        settings = RedisSettings()
        service = RedisService(settings)
        await service.connect()

        # Session management
        await service.set_session("session123", {"user_id": "user1", ...})
        session = await service.get_session("session123")

        # Distributed lock
        token = await service.acquire_lock("resource-lock")
        if token:
            try:
                # Do work...
            finally:
                await service.release_lock("resource-lock", token)

        await service.close()
    """

    def __init__(self, settings: RedisSettings | None = None) -> None:
        """Initialize the Redis service.

        Args:
            settings: Redis connection settings. If None, uses defaults.
        """
        self.settings = settings or RedisSettings()
        self._client: Redis | None = None
        self._pool: ConnectionPool | None = None
        self._release_script: Any = None
        self._extend_script: Any = None

    @property
    def client(self) -> Redis:
        """Get the Redis client.

        Raises:
            RedisConnectionError: If not connected.
        """
        if self._client is None:
            raise RedisConnectionError(
                "Redis client not connected. Call connect() first."
            )
        return self._client

    async def connect(self) -> None:
        """Establish connection to Redis.

        Creates a connection pool and registers Lua scripts.
        Uses local variables and only commits state on success.

        Raises:
            RedisConnectionError: If connection fails.
        """
        if self._client is not None:
            return

        pool = None
        client = None
        try:
            pool = ConnectionPool.from_url(
                self.settings.url,
                max_connections=self.settings.max_connections,
                socket_timeout=self.settings.socket_timeout,
                socket_connect_timeout=self.settings.socket_connect_timeout,
                decode_responses=self.settings.decode_responses,
            )
            client = Redis(connection_pool=pool)

            # Test connection before committing state
            await client.ping()

            # Register Lua scripts
            release_script = client.register_script(RELEASE_LOCK_SCRIPT)
            extend_script = client.register_script(EXTEND_LOCK_SCRIPT)

            # Only set instance state after all success
            self._pool = pool
            self._client = client
            self._release_script = release_script
            self._extend_script = extend_script

            await logger.ainfo("Redis connected", url=self.settings.url)
        except RedisConnError as e:
            # Cleanup on failure
            if client:
                await client.aclose()
            raise RedisConnectionError(f"Failed to connect to Redis: {e}") from e
        except BaseRedisError as e:
            # Cleanup on failure
            if client:
                await client.aclose()
            raise RedisConnectionError(f"Redis connection error: {e}") from e

    async def close(self) -> None:
        """Close the Redis connection."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None
            self._pool = None
            self._release_script = None
            self._extend_script = None
            await logger.ainfo("Redis connection closed")

    async def health_check(self) -> bool:
        """Check if Redis is reachable and healthy.

        Returns:
            True if healthy, False otherwise.
        """
        try:
            if self._client is None:
                return False
            await self._client.ping()
            return True
        except Exception:
            return False

    # =========================================================================
    # Generic Operations
    # =========================================================================

    def _make_key(self, key: str, namespace: RedisNamespace) -> str:
        """Create a namespaced key.

        Args:
            key: The base key name.
            namespace: The namespace to prefix.

        Returns:
            Full key with namespace prefix.
        """
        return f"{namespace.value}{key}"

    async def get(self, key: str, namespace: RedisNamespace) -> str | None:
        """Get a string value by key.

        Args:
            key: The key to retrieve.
            namespace: The namespace for the key.

        Returns:
            The value if found, None otherwise.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            return await self.client.get(full_key)
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to get key {full_key}: {e}") from e

    async def set(
        self,
        key: str,
        value: str,
        namespace: RedisNamespace,
        ttl: int | None = None,
    ) -> None:
        """Set a string value.

        Args:
            key: The key to set.
            value: The string value.
            namespace: The namespace for the key.
            ttl: Time to live in seconds. If None, key doesn't expire.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            if ttl is not None:
                await self.client.set(full_key, value, ex=ttl)
            else:
                await self.client.set(full_key, value)
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to set key {full_key}: {e}") from e

    async def delete(self, key: str, namespace: RedisNamespace) -> bool:
        """Delete a key.

        Args:
            key: The key to delete.
            namespace: The namespace for the key.

        Returns:
            True if key was deleted, False if it didn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            result = await self.client.delete(full_key)
            return result > 0
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to delete key {full_key}: {e}") from e

    async def exists(self, key: str, namespace: RedisNamespace) -> bool:
        """Check if a key exists.

        Args:
            key: The key to check.
            namespace: The namespace for the key.

        Returns:
            True if key exists, False otherwise.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            result = await self.client.exists(full_key)
            return result > 0
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to check key existence {full_key}: {e}") from e

    async def keys(self, pattern: str, namespace: RedisNamespace) -> list[str]:
        """Find keys matching a pattern using non-blocking SCAN.

        Args:
            pattern: Glob-style pattern (e.g., "user:*").
            namespace: The namespace for the keys.

        Returns:
            List of matching keys (without namespace prefix).

        Raises:
            RedisKeyError: If operation fails or iteration limit exceeded.
        """
        full_pattern = self._make_key(pattern, namespace)
        try:
            keys_found: list[str] = []
            cursor = 0
            iterations = 0

            while True:
                cursor, batch = await self.client.scan(
                    cursor=cursor,
                    match=full_pattern,
                    count=100,  # Hint for batch size
                )
                keys_found.extend(batch)
                iterations += 1

                if cursor == 0:  # Scan complete
                    break

                if iterations >= MAX_SCAN_ITERATIONS:
                    raise RedisKeyError(
                        f"Key scan exceeded {MAX_SCAN_ITERATIONS} iterations for pattern {pattern}"
                    )

            # Strip namespace prefix from results
            prefix_len = len(namespace.value)
            return [
                k[prefix_len:] if isinstance(k, str) else k.decode()[prefix_len:]
                for k in keys_found
            ]
        except BaseRedisError as e:
            raise RedisKeyError(
                f"Failed to scan keys with pattern {full_pattern}: {e}"
            ) from e

    async def ttl(self, key: str, namespace: RedisNamespace) -> int:
        """Get the TTL of a key.

        Args:
            key: The key to check.
            namespace: The namespace for the key.

        Returns:
            TTL in seconds, -1 if no TTL, -2 if key doesn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            return await self.client.ttl(full_key)
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to get TTL for {full_key}: {e}") from e

    # =========================================================================
    # JSON Operations
    # =========================================================================

    def _json_safe(self, value: Any) -> Any:
        """Convert non-JSON-serializable values recursively."""
        if isinstance(value, UUID):
            return str(value)
        if isinstance(value, datetime | date):
            return value.isoformat()
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, dict):
            return {k: self._json_safe(v) for k, v in value.items()}
        if isinstance(value, list | tuple):
            return [self._json_safe(v) for v in value]
        return value

    async def get_json(
        self, key: str, namespace: RedisNamespace
    ) -> dict[str, Any] | list[Any] | None:
        """Get a JSON value by key.

        Args:
            key: The key to retrieve.
            namespace: The namespace for the key.

        Returns:
            Parsed JSON value if found, None otherwise.

        Raises:
            RedisKeyError: If operation fails.
            RedisSerializationError: If JSON parsing fails.
        """
        value = await self.get(key, namespace)
        if value is None:
            return None

        try:
            return json.loads(value)
        except json.JSONDecodeError as e:
            raise RedisSerializationError(
                f"Failed to parse JSON for key {key}: {e}"
            ) from e

    async def set_json(
        self,
        key: str,
        value: dict[str, Any] | list[Any],
        namespace: RedisNamespace,
        ttl: int | None = None,
    ) -> None:
        """Set a JSON value.

        Args:
            key: The key to set.
            value: The value to serialize as JSON.
            namespace: The namespace for the key.
            ttl: Time to live in seconds.

        Raises:
            RedisKeyError: If operation fails.
            RedisSerializationError: If JSON serialization fails.
        """
        try:
            json_str = json.dumps(self._json_safe(value))
        except (TypeError, ValueError) as e:
            raise RedisSerializationError(
                f"Failed to serialize JSON for key {key}: {e}"
            ) from e

        await self.set(key, json_str, namespace, ttl)

    # =========================================================================
    # Session Management
    # =========================================================================

    async def get_session(self, session_id: str) -> dict[str, Any] | None:
        """Get session data.

        Args:
            session_id: The session identifier.

        Returns:
            Session data dict if found, None otherwise.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.get_json(session_id, RedisNamespace.SESSIONS)

    async def set_session(self, session_id: str, data: dict[str, Any]) -> None:
        """Set session data.

        Args:
            session_id: The session identifier.
            data: Session data to store.

        Raises:
            RedisKeyError: If operation fails.
        """
        await self.set_json(
            session_id,
            data,
            RedisNamespace.SESSIONS,
            ttl=self.settings.session_ttl,
        )

    async def delete_session(self, session_id: str) -> bool:
        """Delete a session.

        Args:
            session_id: The session identifier.

        Returns:
            True if session was deleted, False if it didn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.delete(session_id, RedisNamespace.SESSIONS)

    async def extend_session(self, session_id: str) -> bool:
        """Extend session TTL.

        Args:
            session_id: The session identifier.

        Returns:
            True if session was extended, False if it doesn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(session_id, RedisNamespace.SESSIONS)
        try:
            result = await self.client.expire(full_key, self.settings.session_ttl)
            return bool(result)
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to extend session {session_id}: {e}") from e

    # =========================================================================
    # Working Memory
    # =========================================================================

    async def get_working_memory(self, session_id: str) -> dict[str, Any] | None:
        """Get working memory for a session.

        Args:
            session_id: The session identifier.

        Returns:
            Working memory data if found, None otherwise.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.get_json(session_id, RedisNamespace.WORKING_MEMORY)

    async def set_working_memory(self, session_id: str, data: dict[str, Any]) -> None:
        """Set working memory for a session.

        Args:
            session_id: The session identifier.
            data: Working memory data to store.

        Raises:
            RedisKeyError: If operation fails.
        """
        await self.set_json(
            session_id,
            data,
            RedisNamespace.WORKING_MEMORY,
            ttl=self.settings.working_memory_ttl,
        )

    async def update_working_memory(
        self, session_id: str, updates: dict[str, Any]
    ) -> None:
        """Update working memory with new values.

        Merges updates into existing working memory. Creates new if doesn't exist.

        Args:
            session_id: The session identifier.
            updates: Dictionary of updates to merge.

        Raises:
            RedisKeyError: If operation fails.
        """
        existing = await self.get_working_memory(session_id) or {}
        existing.update(updates)
        await self.set_working_memory(session_id, existing)

    async def delete_working_memory(self, session_id: str) -> bool:
        """Delete working memory for a session.

        Args:
            session_id: The session identifier.

        Returns:
            True if deleted, False if it didn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.delete(session_id, RedisNamespace.WORKING_MEMORY)

    # =========================================================================
    # Cache Operations
    # =========================================================================

    async def cache_get(self, key: str) -> Any | None:
        """Get a cached value.

        Args:
            key: The cache key.

        Returns:
            Cached value (parsed from JSON) if found, None otherwise.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.get_json(key, RedisNamespace.CACHE)

    async def cache_set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set a cached value.

        Args:
            key: The cache key.
            value: Value to cache (will be JSON serialized).
            ttl: Time to live in seconds. Defaults to cache_ttl from settings.

        Raises:
            RedisKeyError: If operation fails.
        """
        cache_ttl = ttl if ttl is not None else self.settings.cache_ttl
        await self.set_json(key, value, RedisNamespace.CACHE, ttl=cache_ttl)

    async def cache_delete(self, key: str) -> bool:
        """Delete a cached value.

        Args:
            key: The cache key.

        Returns:
            True if deleted, False if it didn't exist.

        Raises:
            RedisKeyError: If operation fails.
        """
        return await self.delete(key, RedisNamespace.CACHE)

    async def cache_invalidate_pattern(self, pattern: str) -> int:
        """Invalidate all cache keys matching a pattern.

        Uses SCAN (non-blocking) and pipeline for efficient batch deletion.

        Args:
            pattern: Glob-style pattern (e.g., "user:*").

        Returns:
            Number of keys deleted.

        Raises:
            RedisKeyError: If operation fails.
        """
        # Get keys using non-blocking SCAN
        matching_keys = await self.keys(pattern, RedisNamespace.CACHE)
        if not matching_keys:
            return 0

        # Use pipeline for batch delete
        try:
            full_keys = [self._make_key(k, RedisNamespace.CACHE) for k in matching_keys]
            async with self.client.pipeline(transaction=False) as pipe:
                for key in full_keys:
                    pipe.delete(key)
                results = await pipe.execute()
            return sum(1 for r in results if r > 0)
        except BaseRedisError as e:
            raise RedisKeyError(
                f"Failed to invalidate cache pattern {pattern}: {e}"
            ) from e

    # =========================================================================
    # Distributed Locks
    # =========================================================================

    async def acquire_lock(
        self,
        lock_name: str,
        ttl: int | None = None,
        blocking: bool = False,
        timeout: float | None = None,
    ) -> str | None:
        """Acquire a distributed lock.

        Args:
            lock_name: Name of the lock to acquire.
            ttl: Lock TTL in seconds. Defaults to lock_ttl from settings.
            blocking: If True, wait for lock to become available.
            timeout: Maximum time to wait for lock (only if blocking=True).

        Returns:
            Lock token if acquired, None if lock is held by another process.

        Raises:
            RedisLockError: If lock operation fails.
        """
        lock_key = self._make_key(lock_name, RedisNamespace.LOCKS)
        lock_ttl = ttl if ttl is not None else self.settings.lock_ttl
        lock_token = secrets.token_urlsafe(16)

        try:
            if not blocking:
                # Non-blocking: try once
                acquired = await self.client.set(
                    lock_key, lock_token, nx=True, ex=lock_ttl
                )
                return lock_token if acquired else None

            # Blocking: retry until acquired or timeout
            start_time = asyncio.get_event_loop().time()
            while True:
                acquired = await self.client.set(
                    lock_key, lock_token, nx=True, ex=lock_ttl
                )
                if acquired:
                    return lock_token

                # Check timeout
                if timeout is not None:
                    elapsed = asyncio.get_event_loop().time() - start_time
                    if elapsed >= timeout:
                        return None

                # Wait before retry
                await asyncio.sleep(0.05)

        except BaseRedisError as e:
            raise RedisLockError(f"Failed to acquire lock {lock_name}: {e}") from e

    async def release_lock(self, lock_name: str, lock_token: str) -> bool:
        """Release a distributed lock.

        Only releases if the token matches (atomic operation via Lua script).

        Args:
            lock_name: Name of the lock to release.
            lock_token: Token returned by acquire_lock.

        Returns:
            True if lock was released, False if token didn't match.

        Raises:
            RedisLockError: If lock operation fails.
        """
        if self._release_script is None:
            raise RedisLockError("Redis not connected or scripts not registered")

        lock_key = self._make_key(lock_name, RedisNamespace.LOCKS)

        try:
            result = await self._release_script(keys=[lock_key], args=[lock_token])
            return bool(result)
        except BaseRedisError as e:
            raise RedisLockError(f"Failed to release lock {lock_name}: {e}") from e

    async def extend_lock(
        self, lock_name: str, lock_token: str, ttl: int | None = None
    ) -> bool:
        """Extend a lock's TTL.

        Only extends if the token matches (atomic operation via Lua script).

        Args:
            lock_name: Name of the lock to extend.
            lock_token: Token returned by acquire_lock.
            ttl: New TTL in seconds. Defaults to lock_ttl from settings.

        Returns:
            True if lock was extended, False if token didn't match.

        Raises:
            RedisLockError: If lock operation fails.
        """
        if self._extend_script is None:
            raise RedisLockError("Redis not connected or scripts not registered")

        lock_key = self._make_key(lock_name, RedisNamespace.LOCKS)
        lock_ttl = ttl if ttl is not None else self.settings.lock_ttl

        try:
            result = await self._extend_script(
                keys=[lock_key], args=[lock_token, str(lock_ttl)]
            )
            return bool(result)
        except BaseRedisError as e:
            raise RedisLockError(f"Failed to extend lock {lock_name}: {e}") from e

    # =========================================================================
    # Rate Limiting Helpers
    # =========================================================================

    async def increment(
        self, key: str, namespace: RedisNamespace, ttl: int | None = None
    ) -> int:
        """Increment a counter.

        Args:
            key: The counter key.
            namespace: The namespace for the key.
            ttl: TTL to set if key is new.

        Returns:
            The new counter value.

        Raises:
            RedisKeyError: If operation fails.
        """
        full_key = self._make_key(key, namespace)
        try:
            value = await self.client.incr(full_key)
            if ttl is not None and value == 1:
                # Set TTL on first increment
                await self.client.expire(full_key, ttl)
            return value
        except BaseRedisError as e:
            raise RedisKeyError(f"Failed to increment {full_key}: {e}") from e

    async def get_counter(self, key: str, namespace: RedisNamespace) -> int:
        """Get a counter value.

        Args:
            key: The counter key.
            namespace: The namespace for the key.

        Returns:
            Counter value, 0 if key doesn't exist.

        Raises:
            RedisKeyError: If operation fails or value is not a valid integer.
        """
        value = await self.get(key, namespace)
        if value is None:
            return 0
        try:
            return int(value)
        except ValueError as e:
            raise RedisKeyError(f"Counter {key} has invalid value: {value}") from e
