"""Tiered Memory Manager for unified memory access across tiers.

Component 4.9: Long-term Memory Architecture
Provides unified interface for Working -> Active -> Archive memory tiers.
"""

import re
from collections.abc import Callable
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog

from ..models.archive import (
    ArchivedEvent,
    StrategicMemory,
    TieredMemoryContext,
    YearDetectionResult,
)

if TYPE_CHECKING:
    from .archive_manager import ArchiveManager
    from .memory import MemoryManager

from .memory import Context

logger = structlog.get_logger(__name__)


# =============================================================================
# Year Detection Patterns (Bilingual: Ukrainian + English)
# =============================================================================


class YearPattern:
    """Pattern for detecting years in queries."""

    def __init__(
        self,
        pattern: str,
        extractor: Callable[[re.Match], list[int]],
        description: str,
    ) -> None:
        """Initialize year pattern.

        Args:
            pattern: Regex pattern.
            extractor: Function to extract years from match.
            description: Human-readable description.
        """
        self.regex = re.compile(pattern, re.IGNORECASE)
        self.extractor = extractor
        self.description = description


def _current_year() -> int:
    """Get current year."""
    return datetime.now().year


# Year detection patterns - ordered by specificity
YEAR_PATTERNS: list[YearPattern] = [
    # Explicit year mentions
    YearPattern(
        r"у\s+(\d{4})\s*(?:році)?",
        lambda m: [int(m.group(1))],
        "Ukrainian: у 2022 році",
    ),
    YearPattern(
        r"в\s+(\d{4})\s*(?:році)?",
        lambda m: [int(m.group(1))],
        "Ukrainian: в 2022 році",
    ),
    YearPattern(
        r"(\d{4})\s+року",
        lambda m: [int(m.group(1))],
        "Ukrainian: 2022 року",
    ),
    YearPattern(
        r"in\s+(\d{4})",
        lambda m: [int(m.group(1))],
        "English: in 2022",
    ),
    YearPattern(
        r"from\s+(\d{4})",
        lambda m: [int(m.group(1))],
        "English: from 2022",
    ),
    YearPattern(
        r"during\s+(\d{4})",
        lambda m: [int(m.group(1))],
        "English: during 2022",
    ),
    # Standalone year (4 digits, not part of other numbers)
    YearPattern(
        r"(?<!\d)(\d{4})(?!\d)",
        lambda m: [int(m.group(1))] if 2000 <= int(m.group(1)) <= 2100 else [],
        "Standalone year: 2022",
    ),
    # Relative year references - Ukrainian
    YearPattern(
        r"минулого\s+року",
        lambda _m: [_current_year() - 1],
        "Ukrainian: минулого року (last year)",
    ),
    YearPattern(
        r"минулий\s+рік",
        lambda _m: [_current_year() - 1],
        "Ukrainian: минулий рік (last year)",
    ),
    YearPattern(
        r"позаминулого\s+року",
        lambda _m: [_current_year() - 2],
        "Ukrainian: позаминулого року (year before last)",
    ),
    YearPattern(
        r"цього\s+року",
        lambda _m: [_current_year()],
        "Ukrainian: цього року (this year)",
    ),
    YearPattern(
        r"(\d+)\s+років?\s+тому",
        lambda m: [_current_year() - int(m.group(1))],
        "Ukrainian: N років тому (N years ago)",
    ),
    # Relative year references - English
    YearPattern(
        r"last\s+year",
        lambda _m: [_current_year() - 1],
        "English: last year",
    ),
    YearPattern(
        r"this\s+year",
        lambda _m: [_current_year()],
        "English: this year",
    ),
    YearPattern(
        r"year\s+before\s+last",
        lambda _m: [_current_year() - 2],
        "English: year before last",
    ),
    YearPattern(
        r"(\d+)\s+years?\s+ago",
        lambda m: [_current_year() - int(m.group(1))],
        "English: N years ago",
    ),
    YearPattern(
        r"past\s+(\d+)\s+years?",
        lambda m: list(
            range(_current_year() - int(m.group(1)) + 1, _current_year() + 1)
        ),
        "English: past N years",
    ),
    YearPattern(
        r"останні\s+(\d+)\s+років?",
        lambda m: list(
            range(_current_year() - int(m.group(1)) + 1, _current_year() + 1)
        ),
        "Ukrainian: останні N років (past N years)",
    ),
]


# =============================================================================
# TieredMemoryManager
# =============================================================================


class TieredMemoryManager:
    """Unified interface for tiered memory access.

    Provides seamless access across memory tiers:
    - Working Memory (Redis, 1hr TTL) - Current conversation
    - Active Memory (PostgreSQL + Qdrant "active") - Current year
    - Archive Memory (PostgreSQL + Qdrant "archive_YYYY") - Past years

    Features:
    - Automatic year detection in queries (UK/EN)
    - Smart tier selection based on query context
    - Unified search results with source tracking

    Example:
        manager = TieredMemoryManager(memory_manager, archive_manager)

        # Query that spans tiers
        context = await manager.recall(
            query="Що обговорювали про проект у 2022 році?",
            user_id=user_id,
            auto_detect_years=True,
        )
        # Will search active + archive_2022

        # Explicit archive search
        context = await manager.recall(
            query="project meetings",
            user_id=user_id,
            include_archives=[2022, 2023],
        )
    """

    def __init__(
        self,
        memory_manager: "MemoryManager",
        archive_manager: "ArchiveManager",
    ) -> None:
        """Initialize tiered memory manager.

        Args:
            memory_manager: Active memory manager.
            archive_manager: Archive manager for cold storage.
        """
        self._memory = memory_manager
        self._archive = archive_manager
        self._current_year = datetime.now().year

    async def recall(
        self,
        query: str,
        user_id: UUID,
        include_archives: list[int] | None = None,
        auto_detect_years: bool = True,
        limit: int = 20,
        include_strategic: bool = True,
    ) -> TieredMemoryContext:
        """Smart memory recall with automatic tier selection.

        Automatically determines which memory tiers to search based on:
        1. Explicit archive list (include_archives)
        2. Year references in query (if auto_detect_years=True)
        3. Default: active memory only

        Args:
            query: Search query string.
            user_id: User UUID.
            include_archives: Optional explicit list of years to search.
            auto_detect_years: Whether to detect years from query.
            limit: Maximum results per tier.
            include_strategic: Whether to include strategic memories.

        Returns:
            TieredMemoryContext with results from all searched tiers.

        Examples:
            - "Що обговорювали вчора?" -> Active only
            - "Проект з банком у 2022" -> Active + archive_2022
            - "Усі проекти за останні 3 роки" -> Active + multiple archives
        """
        await logger.ainfo(
            "Tiered recall started",
            query=query[:50],
            user_id=str(user_id),
            auto_detect=auto_detect_years,
            explicit_archives=include_archives,
        )

        # Determine which years to search
        years_to_search: list[int] = []

        if include_archives:
            # Explicit archive list provided
            years_to_search = include_archives
        elif auto_detect_years:
            # Auto-detect years from query
            detection = self._detect_years(query)
            years_to_search = detection.years

        # Filter out current year (already in active) and future years
        archive_years = [
            y for y in years_to_search if y < self._current_year and y >= 2000
        ]

        # Results containers
        active_events: list[dict] = []
        archived_events: list[ArchivedEvent] = []
        strategic_memories: list[StrategicMemory] = []

        # Step 1: Search active memory
        try:
            # Create Context from user_id for MemoryManager.recall
            context = Context(session_id=str(user_id))
            active_result = await self._memory.recall(
                query=query,
                context=context,
                limit=limit,
            )
            # Convert to dict format for consistency
            active_events = [
                {
                    "id": str(e.event_id),
                    "type": e.event_type,
                    "title": e.title,
                    "summary": e.summary,
                    "occurred_at": e.occurred_at.isoformat() if e.occurred_at else None,
                    "importance": e.importance,
                    "score": e.final_score,
                    "source": "active",
                }
                for e in active_result.events
            ]
        except Exception as e:
            await logger.awarning(
                "Active memory search failed",
                error=str(e),
            )

        # Step 2: Search archive years
        for year in archive_years:
            try:
                archive_results = await self._archive.search_archive(
                    year=year,
                    query=query,
                    user_id=user_id,
                    limit=limit,
                )
                archived_events.extend(archive_results)
            except Exception as e:
                await logger.awarning(
                    "Archive search failed",
                    year=year,
                    error=str(e),
                )

        # Step 3: Get strategic memories (if requested)
        if include_strategic and archive_years:
            for year in archive_years:
                try:
                    memories = await self._archive.get_strategic_memories(
                        user_id=user_id,
                        year=year,
                        limit=10,
                    )
                    strategic_memories.extend(memories)
                except Exception as e:
                    await logger.awarning(
                        "Strategic memory retrieval failed",
                        year=year,
                        error=str(e),
                    )

        # Build result
        years_searched = [self._current_year] + archive_years

        await logger.ainfo(
            "Tiered recall complete",
            query=query[:50],
            active_count=len(active_events),
            archived_count=len(archived_events),
            strategic_count=len(strategic_memories),
            years_searched=years_searched,
        )

        return TieredMemoryContext(
            query=query,
            active_events=active_events,
            archived_events=archived_events,
            strategic_memories=strategic_memories,
            years_searched=years_searched,
            cached=False,
        )

    def _detect_years(self, query: str) -> YearDetectionResult:
        """Detect year references in Ukrainian/English queries.

        Patterns supported:
        - "у 2022 році", "in 2022" -> [2022]
        - "минулого року", "last year" -> [current_year - 1]
        - "5 років тому", "5 years ago" -> [current_year - 5]
        - "за останні 3 роки", "past 3 years" -> [Y-2, Y-1, Y]

        Args:
            query: Query string to analyze.

        Returns:
            YearDetectionResult with detected years and matched patterns.
        """
        detected_years: set[int] = set()
        patterns_matched: list[str] = []

        for pattern in YEAR_PATTERNS:
            for match in pattern.regex.finditer(query):
                years = pattern.extractor(match)
                # Filter valid years
                valid_years = [y for y in years if 2000 <= y <= 2100]
                if valid_years:
                    detected_years.update(valid_years)
                    if pattern.description not in patterns_matched:
                        patterns_matched.append(pattern.description)

        return YearDetectionResult(
            years=sorted(detected_years),
            patterns_matched=patterns_matched,
        )

    async def get_available_years(
        self,
        user_id: UUID,
    ) -> list[int]:
        """Get list of years with available data (active + archived).

        Args:
            user_id: User UUID.

        Returns:
            List of years with data, sorted descending.
        """
        years: set[int] = {self._current_year}

        # Get archived years
        try:
            archives = await self._archive.get_archive_index(user_id)
            for archive in archives:
                years.add(archive.year)
        except Exception as e:
            await logger.awarning(
                "Failed to get archive index",
                error=str(e),
            )

        return sorted(years, reverse=True)

    async def get_memory_stats(
        self,
        user_id: UUID,
    ) -> dict[str, Any]:
        """Get statistics across all memory tiers.

        Args:
            user_id: User UUID.

        Returns:
            Dict with memory statistics.
        """
        stats: dict[str, Any] = {
            "current_year": self._current_year,
            "tiers": {
                "working": {"type": "redis", "ttl_hours": 1},
                "active": {"type": "postgresql+qdrant", "year": self._current_year},
                "archives": [],
            },
        }

        try:
            archives = await self._archive.get_archive_index(user_id)
            stats["tiers"]["archives"] = [
                {
                    "year": a.year,
                    "event_count": a.event_count,
                    "archived_at": a.archived_at.isoformat(),
                    "collection": a.qdrant_collection,
                }
                for a in archives
            ]
            stats["total_archived_years"] = len(archives)
            stats["total_archived_events"] = sum(a.event_count for a in archives)
        except Exception as e:
            await logger.awarning(
                "Failed to get archive stats",
                error=str(e),
            )

        return stats

    def detect_years_from_query(self, query: str) -> YearDetectionResult:
        """Public method for year detection (for testing/API use).

        Args:
            query: Query string.

        Returns:
            YearDetectionResult with detected years.
        """
        return self._detect_years(query)
