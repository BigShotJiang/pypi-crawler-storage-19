"""Qdrant vector database service for semantic search operations."""

import asyncio
from datetime import date, datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict
from qdrant_client import AsyncQdrantClient
from qdrant_client.http import models as qdrant_models
from qdrant_client.http.exceptions import UnexpectedResponse

from ..config import QdrantSettings

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class QdrantError(Exception):
    """Base exception for Qdrant operations."""

    pass


class QdrantConnectionError(QdrantError):
    """Raised when connection to Qdrant fails."""

    pass


class QdrantCollectionError(QdrantError):
    """Raised when collection operations fail."""

    pass


class QdrantVectorError(QdrantError):
    """Raised when vector operations fail."""

    pass


# =============================================================================
# Pydantic Models
# =============================================================================


class VectorPoint(BaseModel):
    """A vector point with payload."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    vector: list[float]
    payload: dict[str, Any]


class SearchResult(BaseModel):
    """Search result with score."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    score: float
    payload: dict[str, Any]


class CollectionInfo(BaseModel):
    """Collection metadata."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    name: str
    vectors_count: int
    points_count: int


# =============================================================================
# Collection Definitions
# =============================================================================

COLLECTION_CONFIGS: dict[str, dict[str, Any]] = {
    "memories": {
        "size": 1536,
        "distance": qdrant_models.Distance.COSINE,
        "payload_indexes": [
            ("type", qdrant_models.PayloadSchemaType.KEYWORD),
            ("timestamp", qdrant_models.PayloadSchemaType.DATETIME),
            ("importance", qdrant_models.PayloadSchemaType.FLOAT),
        ],
    },
    "lessons": {
        "size": 1536,
        "distance": qdrant_models.Distance.COSINE,
        "payload_indexes": [
            ("category", qdrant_models.PayloadSchemaType.KEYWORD),
            ("confidence", qdrant_models.PayloadSchemaType.FLOAT),
        ],
    },
    "conversations": {
        "size": 1536,
        "distance": qdrant_models.Distance.COSINE,
        "payload_indexes": [
            ("started_at", qdrant_models.PayloadSchemaType.DATETIME),
            ("message_count", qdrant_models.PayloadSchemaType.INTEGER),
        ],
    },
}

# Filter validation constants
ALLOWED_FILTER_FIELDS: dict[str, set[str]] = {
    "memories": {"type", "timestamp", "importance", "person_ids", "project_id"},
    "lessons": {"category", "confidence", "source_event_ids"},
    "conversations": {"started_at", "message_count", "participant_ids"},
}
MAX_IN_LIST_SIZE = 100


# =============================================================================
# QdrantService
# =============================================================================


class QdrantService:
    """Async Qdrant client wrapper for vector operations.

    Collections:
    - memories: Event embeddings for semantic search
    - lessons: Extracted insights
    - conversations: Conversation summaries

    Example:
        settings = QdrantSettings()
        service = QdrantService(settings)
        await service.initialize()

        # Upsert a vector
        await service.upsert(
            collection="memories",
            id=uuid4(),
            vector=[0.1, 0.2, ...],
            payload={"type": "meeting", "importance": 0.8}
        )

        # Search for similar vectors
        results = await service.search(
            collection="memories",
            query_vector=[0.1, 0.2, ...],
            limit=10
        )
    """

    def __init__(self, settings: QdrantSettings | None = None) -> None:
        """Initialize the Qdrant service.

        Args:
            settings: Qdrant connection settings. If None, uses defaults.
        """
        self.settings = settings or QdrantSettings()
        self._client: AsyncQdrantClient | None = None
        self._initialized = False

    @property
    def client(self) -> AsyncQdrantClient:
        """Get the Qdrant client, creating it if necessary."""
        if self._client is None:
            self._client = AsyncQdrantClient(
                url=self.settings.url,
                api_key=self.settings.api_key,
                timeout=self.settings.timeout,
            )
        return self._client

    def _collection_name(self, name: str) -> str:
        """Get the full collection name with prefix."""
        return f"{self.settings.collection_prefix}{name}"

    async def initialize(self) -> None:
        """Create collections if they don't exist.

        Creates all required collections with proper vector configuration
        and payload indexes.

        Raises:
            QdrantConnectionError: If connection to Qdrant fails.
            QdrantCollectionError: If collection creation fails.
        """
        if self._initialized:
            return

        try:
            for name, config in COLLECTION_CONFIGS.items():
                collection_name = self._collection_name(name)
                await self._ensure_collection(collection_name, config)
            self._initialized = True
            await logger.ainfo("Qdrant collections initialized")
        except UnexpectedResponse as e:
            raise QdrantConnectionError(f"Failed to connect to Qdrant: {e}") from e
        except Exception as e:
            raise QdrantCollectionError(f"Failed to initialize collections: {e}") from e

    async def _ensure_collection(
        self, collection_name: str, config: dict[str, Any]
    ) -> None:
        """Ensure a collection exists with proper configuration."""
        collections = await self.client.get_collections()
        exists = any(c.name == collection_name for c in collections.collections)

        if not exists:
            await self.client.create_collection(
                collection_name=collection_name,
                vectors_config=qdrant_models.VectorParams(
                    size=config["size"],
                    distance=config["distance"],
                ),
            )
            await logger.ainfo("Created collection", collection=collection_name)

            # Create payload indexes
            for field_name, field_type in config.get("payload_indexes", []):
                await self.client.create_payload_index(
                    collection_name=collection_name,
                    field_name=field_name,
                    field_schema=field_type,
                )
            await logger.ainfo(
                "Created payload indexes",
                collection=collection_name,
                indexes=[idx[0] for idx in config.get("payload_indexes", [])],
            )

    async def upsert(
        self,
        collection: str,
        id: UUID,
        vector: list[float],
        payload: dict[str, Any],
    ) -> None:
        """Insert or update a vector.

        Args:
            collection: Collection name (memories, lessons, conversations).
            id: Unique identifier for the vector.
            vector: Vector embedding.
            payload: Metadata to store with the vector.

        Raises:
            QdrantVectorError: If upsert operation fails.
        """
        collection_name = self._collection_name(collection)

        try:
            await self.client.upsert(
                collection_name=collection_name,
                points=[
                    qdrant_models.PointStruct(
                        id=str(id),
                        vector=vector,
                        payload=self._serialize_payload(payload),
                    )
                ],
            )
            await logger.adebug(
                "Upserted vector",
                collection=collection,
                id=str(id),
            )
        except Exception as e:
            raise QdrantVectorError(f"Failed to upsert vector: {e}") from e

    async def upsert_batch(
        self,
        collection: str,
        points: list[VectorPoint],
    ) -> None:
        """Insert or update multiple vectors in a batch.

        Args:
            collection: Collection name.
            points: List of VectorPoint objects to upsert.

        Raises:
            QdrantVectorError: If batch upsert fails.
        """
        if not points:
            return

        collection_name = self._collection_name(collection)

        try:
            await self.client.upsert(
                collection_name=collection_name,
                points=[
                    qdrant_models.PointStruct(
                        id=str(p.id),
                        vector=p.vector,
                        payload=self._serialize_payload(p.payload),
                    )
                    for p in points
                ],
            )
            await logger.adebug(
                "Upserted batch",
                collection=collection,
                count=len(points),
            )
        except Exception as e:
            raise QdrantVectorError(f"Failed to upsert batch: {e}") from e

    async def search(
        self,
        collection: str,
        query_vector: list[float],
        limit: int = 10,
        filters: dict[str, Any] | None = None,
        score_threshold: float | None = None,
    ) -> list[SearchResult]:
        """Search for similar vectors.

        Args:
            collection: Collection name.
            query_vector: Query vector embedding.
            limit: Maximum number of results to return.
            filters: Optional filters to apply.
            score_threshold: Minimum score threshold.

        Returns:
            List of search results sorted by similarity.

        Raises:
            QdrantVectorError: If search fails.
        """
        collection_name = self._collection_name(collection)

        try:
            qdrant_filter = self._build_filter(filters, collection) if filters else None

            results = await self.client.search(
                collection_name=collection_name,
                query_vector=query_vector,
                limit=limit,
                query_filter=qdrant_filter,
                score_threshold=score_threshold,
            )

            return [
                SearchResult(
                    id=UUID(str(r.id)),
                    score=r.score,
                    payload=r.payload or {},
                )
                for r in results
            ]
        except Exception as e:
            raise QdrantVectorError(f"Search failed: {e}") from e

    async def delete(
        self,
        collection: str,
        ids: list[UUID],
    ) -> None:
        """Delete vectors by IDs.

        Args:
            collection: Collection name.
            ids: List of vector IDs to delete.

        Raises:
            QdrantVectorError: If delete fails.
        """
        if not ids:
            return

        collection_name = self._collection_name(collection)

        try:
            await self.client.delete(
                collection_name=collection_name,
                points_selector=qdrant_models.PointIdsList(
                    points=[str(id) for id in ids],
                ),
            )
            await logger.adebug(
                "Deleted vectors",
                collection=collection,
                count=len(ids),
            )
        except Exception as e:
            raise QdrantVectorError(f"Failed to delete vectors: {e}") from e

    async def get(
        self,
        collection: str,
        id: UUID,
    ) -> VectorPoint | None:
        """Get a single vector by ID.

        Args:
            collection: Collection name.
            id: Vector ID to retrieve.

        Returns:
            VectorPoint if found, None otherwise.

        Raises:
            QdrantVectorError: If retrieval fails.
        """
        collection_name = self._collection_name(collection)

        try:
            results = await self.client.retrieve(
                collection_name=collection_name,
                ids=[str(id)],
                with_vectors=True,
                with_payload=True,
            )

            if not results:
                return None

            point = results[0]
            return VectorPoint(
                id=UUID(str(point.id)),
                vector=point.vector if isinstance(point.vector, list) else [],
                payload=point.payload or {},
            )
        except Exception as e:
            raise QdrantVectorError(f"Failed to get vector: {e}") from e

    async def get_collection_info(self, collection: str) -> CollectionInfo | None:
        """Get collection metadata.

        Args:
            collection: Collection name.

        Returns:
            CollectionInfo if collection exists, None otherwise.
        """
        collection_name = self._collection_name(collection)

        try:
            info = await self.client.get_collection(collection_name=collection_name)
            return CollectionInfo(
                name=collection,
                vectors_count=info.vectors_count or 0,
                points_count=info.points_count or 0,
            )
        except UnexpectedResponse:
            return None
        except Exception as e:
            raise QdrantVectorError(f"Failed to get collection info: {e}") from e

    async def health_check(self) -> bool:
        """Check if Qdrant is reachable and healthy.

        Returns:
            True if healthy, False otherwise.
        """
        try:
            # Simple health check by listing collections
            await self.client.get_collections()
            return True
        except Exception:
            return False

    async def close(self) -> None:
        """Close the Qdrant client connection."""
        if self._client is not None:
            await self._client.close()
            self._client = None
            self._initialized = False
            await logger.ainfo("Qdrant client closed")

    async def delete_collection(self, collection: str) -> None:
        """Delete a collection.

        Args:
            collection: Collection name to delete.

        Raises:
            QdrantCollectionError: If deletion fails.
        """
        collection_name = self._collection_name(collection)

        try:
            await self.client.delete_collection(collection_name=collection_name)
            await logger.ainfo("Deleted collection", collection=collection_name)
        except Exception as e:
            raise QdrantCollectionError(f"Failed to delete collection: {e}") from e

    # =========================================================================
    # Archive Collection Support (Component 4.9)
    # =========================================================================

    async def create_archive_collection(
        self,
        year: int,
        user_id: UUID,
    ) -> str:
        """Create a new archive collection for a year.

        Creates a collection with the same vector configuration as "memories"
        but named specifically for the archive year and user.

        Args:
            year: Archive year.
            user_id: User UUID (first 8 hex chars used in name).

        Returns:
            Collection name that was created.

        Raises:
            QdrantCollectionError: If creation fails.
        """
        collection_name = f"archive_{year}_{user_id.hex[:8]}"

        try:
            # Check if already exists
            collections = await self.client.get_collections()
            exists = any(c.name == collection_name for c in collections.collections)

            if exists:
                await logger.ainfo(
                    "Archive collection already exists",
                    collection=collection_name,
                )
                return collection_name

            # Use same config as memories collection
            config = COLLECTION_CONFIGS["memories"]

            await self.client.create_collection(
                collection_name=collection_name,
                vectors_config=qdrant_models.VectorParams(
                    size=config["size"],
                    distance=config["distance"],
                ),
            )

            # Create payload indexes
            for field_name, field_type in config.get("payload_indexes", []):
                await self.client.create_payload_index(
                    collection_name=collection_name,
                    field_name=field_name,
                    field_schema=field_type,
                )

            # Add user_id index for archive collections
            await self.client.create_payload_index(
                collection_name=collection_name,
                field_name="user_id",
                field_schema=qdrant_models.PayloadSchemaType.KEYWORD,
            )

            await logger.ainfo(
                "Created archive collection",
                collection=collection_name,
                year=year,
            )

            return collection_name

        except Exception as e:
            raise QdrantCollectionError(
                f"Failed to create archive collection: {e}"
            ) from e

    async def migrate_vectors_to_archive(
        self,
        source_collection: str,
        target_collection: str,
        vector_ids: list[UUID],
        batch_size: int = 100,
    ) -> int:
        """Move vectors from active to archive collection.

        Retrieves vectors from source, upserts to target, then deletes
        from source. Processes in batches for large migrations.

        Args:
            source_collection: Source collection name.
            target_collection: Target archive collection name.
            vector_ids: List of vector IDs to migrate.
            batch_size: Number of vectors per batch.

        Returns:
            Number of vectors migrated.

        Raises:
            QdrantVectorError: If migration fails.
        """
        if not vector_ids:
            return 0

        source_name = self._collection_name(source_collection)
        migrated = 0

        try:
            for i in range(0, len(vector_ids), batch_size):
                batch_ids = vector_ids[i : i + batch_size]

                # Retrieve vectors from source
                points = await self.client.retrieve(
                    collection_name=source_name,
                    ids=[str(id) for id in batch_ids],
                    with_vectors=True,
                    with_payload=True,
                )

                if not points:
                    continue

                # Upsert to target (archive collection uses full name, not prefixed)
                await self.client.upsert(
                    collection_name=target_collection,
                    points=[
                        qdrant_models.PointStruct(
                            id=str(p.id),
                            vector=p.vector if isinstance(p.vector, list) else [],
                            payload=p.payload or {},
                        )
                        for p in points
                    ],
                )

                # Delete from source
                await self.client.delete(
                    collection_name=source_name,
                    points_selector=qdrant_models.PointIdsList(
                        points=[str(id) for id in batch_ids],
                    ),
                )

                migrated += len(points)

            await logger.ainfo(
                "Migrated vectors to archive",
                source=source_collection,
                target=target_collection,
                count=migrated,
            )

            return migrated

        except Exception as e:
            raise QdrantVectorError(f"Failed to migrate vectors: {e}") from e

    async def search_archive_collection(
        self,
        collection_name: str,
        query_vector: list[float],
        limit: int = 20,
        filter_conditions: dict[str, Any] | None = None,
        score_threshold: float | None = None,
    ) -> list[SearchResult]:
        """Search within an archive collection.

        Unlike regular search, this uses the full collection name directly
        (archive collections are not prefixed).

        Args:
            collection_name: Full archive collection name.
            query_vector: Query vector embedding.
            limit: Maximum results.
            filter_conditions: Optional filters.
            score_threshold: Minimum score.

        Returns:
            List of search results.

        Raises:
            QdrantVectorError: If search fails.
        """
        try:
            qdrant_filter = None
            if filter_conditions:
                qdrant_filter = self._build_filter(filter_conditions)

            results = await self.client.search(
                collection_name=collection_name,
                query_vector=query_vector,
                limit=limit,
                query_filter=qdrant_filter,
                score_threshold=score_threshold,
            )

            return [
                SearchResult(
                    id=UUID(str(r.id)),
                    score=r.score,
                    payload=r.payload or {},
                )
                for r in results
            ]

        except Exception as e:
            raise QdrantVectorError(f"Archive search failed: {e}") from e

    async def delete_archive_collection(
        self,
        collection_name: str,
    ) -> bool:
        """Delete an archive collection.

        Uses full collection name directly (not prefixed).

        Args:
            collection_name: Full archive collection name.

        Returns:
            True if deleted.

        Raises:
            QdrantCollectionError: If deletion fails.
        """
        try:
            await self.client.delete_collection(collection_name=collection_name)
            await logger.ainfo("Deleted archive collection", collection=collection_name)
            return True
        except Exception as e:
            raise QdrantCollectionError(
                f"Failed to delete archive collection: {e}"
            ) from e

    async def list_archive_collections(
        self,
        user_id: UUID | None = None,
    ) -> list[str]:
        """List all archive collections.

        Args:
            user_id: Optional filter by user (matches user hex prefix).

        Returns:
            List of archive collection names.
        """
        try:
            collections = await self.client.get_collections()

            archive_collections = [
                c.name
                for c in collections.collections
                if c.name.startswith("archive_")
            ]

            # Filter by user if provided
            if user_id:
                user_prefix = user_id.hex[:8]
                archive_collections = [
                    c for c in archive_collections
                    if c.endswith(user_prefix)
                ]

            return sorted(archive_collections)

        except Exception as e:
            await logger.awarning(
                "Failed to list archive collections",
                error=str(e),
            )
            return []

    async def get_archive_collection_info(
        self,
        collection_name: str,
    ) -> CollectionInfo | None:
        """Get info for an archive collection.

        Args:
            collection_name: Full archive collection name.

        Returns:
            CollectionInfo if exists, None otherwise.
        """
        try:
            info = await self.client.get_collection(collection_name=collection_name)
            return CollectionInfo(
                name=collection_name,
                vectors_count=info.vectors_count or 0,
                points_count=info.points_count or 0,
            )
        except UnexpectedResponse:
            return None
        except Exception as e:
            raise QdrantVectorError(
                f"Failed to get archive collection info: {e}"
            ) from e

    def _serialize_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Recursively serialize payload for Qdrant storage."""
        return self._json_safe(payload)

    def _json_safe(self, value: Any) -> Any:
        """Convert non-JSON-serializable values recursively."""
        if isinstance(value, UUID):
            return str(value)
        if isinstance(value, datetime | date):
            return value.isoformat()
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, dict):
            return {k: self._json_safe(v) for k, v in value.items()}
        if isinstance(value, list | tuple):
            return [self._json_safe(v) for v in value]
        return value

    def _build_filter(
        self,
        filters: dict[str, Any],
        collection: str | None = None,
    ) -> qdrant_models.Filter | None:
        """Build a Qdrant filter from a dictionary.

        Supports simple key-value filters and special operators:
        - $gte, $lte, $gt, $lt for range queries
        - $in for matching any value in a list

        Args:
            filters: Dictionary of filters.
            collection: Collection name for field validation.

        Returns:
            Qdrant Filter object.

        Raises:
            QdrantVectorError: If filter field is invalid or $in list too large.
        """
        if not filters:
            return None

        conditions = []
        allowed_fields = ALLOWED_FILTER_FIELDS.get(collection) if collection else None

        for key, value in filters.items():
            # Validate field if allowlist provided
            if allowed_fields and key not in allowed_fields:
                raise QdrantVectorError(f"Invalid filter field: {key}")

            if isinstance(value, dict):
                # Check $in list size
                if "$in" in value:
                    if len(value["$in"]) > MAX_IN_LIST_SIZE:
                        raise QdrantVectorError(
                            f"$in list exceeds max size of {MAX_IN_LIST_SIZE}"
                        )
                    conditions.append(
                        qdrant_models.FieldCondition(
                            key=key,
                            match=qdrant_models.MatchAny(any=value["$in"]),
                        )
                    )
                # Handle range operators
                elif any(op in value for op in ("$gte", "$lte", "$gt", "$lt")):
                    conditions.append(
                        qdrant_models.FieldCondition(
                            key=key,
                            range=qdrant_models.Range(
                                gte=value.get("$gte"),
                                lte=value.get("$lte"),
                                gt=value.get("$gt"),
                                lt=value.get("$lt"),
                            ),
                        )
                    )
            else:
                # Simple equality match
                conditions.append(
                    qdrant_models.FieldCondition(
                        key=key,
                        match=qdrant_models.MatchValue(value=value),
                    )
                )

        return qdrant_models.Filter(must=conditions) if conditions else None


# =============================================================================
# Retry Helper
# =============================================================================


async def with_retry(
    func,
    max_retries: int = 3,
    base_delay: float = 0.5,
    max_delay: float = 10.0,
):
    """Execute a function with exponential backoff retry.

    Args:
        func: Async function to execute.
        max_retries: Maximum number of retry attempts.
        base_delay: Initial delay between retries in seconds.
        max_delay: Maximum delay between retries in seconds.

    Returns:
        Result of the function call.

    Raises:
        The last exception if all retries fail.
    """
    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            return await func()
        except (QdrantConnectionError, QdrantVectorError, QdrantCollectionError) as e:
            last_exception = e
            if attempt < max_retries:
                delay = min(base_delay * (2**attempt), max_delay)
                await logger.awarning(
                    "Qdrant operation failed, retrying",
                    attempt=attempt + 1,
                    max_retries=max_retries,
                    delay=delay,
                    error=str(e),
                )
                await asyncio.sleep(delay)
            else:
                raise

    raise last_exception  # Should never reach here
