"""Agent package for Digital Valerii.

This package contains agent-related functionality including
the personality system for authentic response generation
and the core agent using Claude Agent SDK.
"""

from .core import (
    AgentError,
    AgentHookError,
    AgentMessage,
    AgentOptionsBuilder,
    AgentResponse,
    AgentSessionError,
    AgentStatus,
    ConversationContext,
    DigitalValeriiAgent,
    InterfaceType,
    MemoryHooks,
    MemoryManager,
)
from .personality import (
    PersonalityManager,
)
from .personality.models import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    MemoryReference,
    PersonalityConfig,
    PersonalityPrompt,
    PersonalitySection,
    PersonReference,
    ProjectReference,
)

__all__ = [
    # Main Agent
    "DigitalValeriiAgent",
    # Agent Context
    "ConversationContext",
    "InterfaceType",
    # Agent Hooks
    "MemoryHooks",
    "MemoryManager",
    # Agent Options
    "AgentOptionsBuilder",
    # Agent Models
    "AgentMessage",
    "AgentResponse",
    "AgentStatus",
    # Agent Exceptions
    "AgentError",
    "AgentHookError",
    "AgentSessionError",
    # Personality Manager
    "PersonalityManager",
    # Personality Enums
    "PersonalitySection",
    "LanguageMode",
    "ConversationMode",
    # Personality Models
    "DynamicContext",
    "PersonalityConfig",
    "PersonalityPrompt",
    "PersonReference",
    "ProjectReference",
    "MemoryReference",
]
