"""Pydantic models for the personality system.

This module defines all data models used by the personality system,
including enums for configuration options and models for dynamic context.
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class PersonalitySection(str, Enum):
    """Sections of the personality system."""

    BASE = "base"
    COMMUNICATION = "communication"
    KNOWLEDGE = "knowledge"
    BEHAVIORS = "behaviors"
    EXAMPLES = "examples"


class LanguageMode(str, Enum):
    """Language modes for responses."""

    UKRAINIAN = "ukrainian"
    ENGLISH = "english"
    AUTO = "auto"


class ConversationMode(str, Enum):
    """Modes for different conversation contexts."""

    ASSESSMENT = "assessment"
    CONSULTING = "consulting"
    TECHNICAL = "technical"
    CASUAL = "casual"
    MEETING = "meeting"


class PersonReference(BaseModel):
    """Reference to a person in dynamic context."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str = Field(..., min_length=1, description="Person's name")
    relation: str = Field(..., min_length=1, description="Relationship type")
    context: str | None = Field(None, description="Additional context about the person")


class ProjectReference(BaseModel):
    """Reference to an active project."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str = Field(..., min_length=1, description="Project name")
    client: str | None = Field(None, description="Client name if applicable")
    status: str = Field("active", description="Project status")
    description: str | None = Field(None, description="Brief project description")


class MemoryReference(BaseModel):
    """Reference to a relevant memory or past interaction."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    content: str = Field(..., min_length=1, description="Memory content")
    timestamp: datetime = Field(..., description="When this memory was created")
    relevance: float = Field(
        ..., ge=0.0, le=1.0, description="Relevance score from 0 to 1"
    )


class DynamicContext(BaseModel):
    """Dynamic context injected into personality prompts at runtime."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    current_date: datetime = Field(
        default_factory=datetime.utcnow, description="Current date and time (UTC)"
    )
    projects: tuple[ProjectReference, ...] = Field(
        default=(), description="Active projects"
    )
    people: tuple[PersonReference, ...] = Field(
        default=(), description="Relevant people in context"
    )
    memories: tuple[MemoryReference, ...] = Field(
        default=(), description="Relevant memories from past interactions"
    )
    custom_context: str | None = Field(
        None, description="Additional custom context to inject"
    )


class PersonalityConfig(BaseModel):
    """Configuration for personality prompt building."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    sections: tuple[PersonalitySection, ...] = Field(
        default=(
            PersonalitySection.BASE,
            PersonalitySection.COMMUNICATION,
            PersonalitySection.KNOWLEDGE,
            PersonalitySection.BEHAVIORS,
            PersonalitySection.EXAMPLES,
        ),
        description="Which personality sections to include",
    )
    language: LanguageMode = Field(
        default=LanguageMode.AUTO, description="Preferred language mode"
    )
    mode: ConversationMode = Field(
        default=ConversationMode.CONSULTING, description="Conversation mode"
    )
    max_tokens: int = Field(
        default=4000,
        ge=500,
        le=16000,
        description="Maximum tokens for personality prompt",
    )
    include_examples: bool = Field(
        default=True, description="Whether to include example responses"
    )


class PersonalityPrompt(BaseModel):
    """A built personality prompt ready for use."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    content: str = Field(..., min_length=1, description="The full prompt content")
    sections_included: tuple[PersonalitySection, ...] = Field(
        ..., description="Which sections were included"
    )
    estimated_tokens: int = Field(..., ge=0, description="Estimated token count")
    language: LanguageMode = Field(..., description="Language mode used")
    mode: ConversationMode = Field(..., description="Conversation mode used")
    context_injected: bool = Field(
        ..., description="Whether dynamic context was injected"
    )
