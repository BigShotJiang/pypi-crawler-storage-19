# Domain Knowledge - Digital Valerii

## Primary Frameworks

### ISO 27001:2022
- International standard for ISMS
- Clauses 4-10: Management system requirements
- Annex A: 93 controls in 4 themes (Organizational, People, Physical, Technological)
- Certification: Stage 1/2 audits, annual surveillance, 3-year recertification

### NIST CSF 2.0
- Core Functions: GOVERN, IDENTIFY, PROTECT, DETECT, RESPOND, RECOVER
- Maturity Levels 1-5 (Initial to Optimizing)
- Target: Level 3.5-4.0 for most enterprises
- Gap to Level 4: Usually lack of KPIs and metrics

### NIST SP 800-171
- Protecting CUI in non-federal systems
- 14 control families, 110 security requirements
- Required for defense contractors and research institutions

### CIS Controls v8
- Prioritized cybersecurity best practices
- Implementation Groups: IG1 (basic), IG2 (growing), IG3 (mature)
- Start with IG1 - if you can't do basic hygiene, don't try advanced controls

### PCI DSS 4.0
- 12 requirements for payment card security
- Changes: Customized approach, enhanced authentication, stronger encryption

## Assessment Methodology

**Phase 1: Preparation** - Documentation request, stakeholder identification, scope definition
**Phase 2: Documentation Analysis** - Review docs, map to framework, identify gaps
**Phase 3: Interviews** - Validate documentation vs reality, collect evidence
**Phase 4: Analysis & Reporting** - Score domains, prioritize findings, develop roadmap
**Phase 5: Delivery** - Present findings, discuss recommendations

## Key Interview Domains

- Governance (GV) - Policy, board oversight, risk tolerance
- Risk Management (ID.RM) - Methodology, risk register, treatment plans
- Data Protection (PR.DS) - Classification, encryption, DLP, backups
- Access Management (PR.AC) - Provisioning, reviews, PAM
- Incident Management (RS) - Detection, playbooks, MTTD/MTTR
- Disaster Recovery (RC) - BIA, RTO/RPO, test coverage
- Third-Party Risk (ID.SC) - Vendor assessment, monitoring

## Technical Knowledge

**Encryption:** AES-256 at rest, TLS 1.2+ in transit, HSM for key management
**Identity:** Azure AD/Okta, SAML/OIDC, MFA required, PAM solutions
**Security Operations:** SIEM (Splunk, Sentinel), EDR (CrowdStrike, Defender), SOAR
**Vulnerability Management:** Risk-based prioritization, SLA tracking, AI-enabled prioritization

## Assessment Principles

1. Evidence over claims - "Show me" not "tell me"
2. Process over tools - Tools enable, but process matters more
3. KPIs or it didn't happen - If you can't measure, you can't improve
4. Business context first - Technical gaps mean nothing without business impact
5. Practical recommendations - What can they actually implement?
