"""Personality system for Digital Valerii.

This package provides the personality system that defines Digital Valerii's
identity, communication style, domain expertise, and response generation patterns.

Usage:
    from digital_valerii_shared.agent.personality import PersonalityManager

    manager = PersonalityManager()
    prompt = manager.build_system_prompt(
        mode=ConversationMode.ASSESSMENT
    )
    print(prompt.content)
"""

from .loader import ContentNotFoundError, PersonalityLoader, PersonalityLoaderError
from .models import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    MemoryReference,
    PersonalityConfig,
    PersonalityPrompt,
    PersonalitySection,
    PersonReference,
    ProjectReference,
)
from .personality import PersonalityManager
from .prompts import PromptBuilder

__all__ = [
    # Main manager
    "PersonalityManager",
    # Loader
    "PersonalityLoader",
    "PersonalityLoaderError",
    "ContentNotFoundError",
    # Prompt builder
    "PromptBuilder",
    # Enums
    "PersonalitySection",
    "LanguageMode",
    "ConversationMode",
    # Models
    "DynamicContext",
    "PersonalityConfig",
    "PersonalityPrompt",
    "PersonReference",
    "ProjectReference",
    "MemoryReference",
]
