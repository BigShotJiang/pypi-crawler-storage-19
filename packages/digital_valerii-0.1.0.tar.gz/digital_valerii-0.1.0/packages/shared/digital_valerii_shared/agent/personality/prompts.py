"""Prompt building functionality for the personality system.

This module handles combining personality sections, injecting dynamic
context, and managing token budgets for prompts.
"""

import logging
import re

from .models import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    PersonalityConfig,
    PersonalityPrompt,
    PersonalitySection,
)

logger = logging.getLogger(__name__)

# Token estimation ratios (approximate)
CHARS_PER_TOKEN_ENGLISH = 4
CHARS_PER_TOKEN_UKRAINIAN = 2
DEFAULT_CHARS_PER_TOKEN = 3.5


class PromptBuilder:
    """Builds personality prompts from sections and dynamic context.

    This class is responsible for combining personality sections,
    injecting dynamic context placeholders, and estimating token usage.
    """

    # Placeholder patterns for dynamic context injection
    PLACEHOLDER_PATTERN = re.compile(r"\{\{(\w+)\}\}")

    def __init__(self) -> None:
        """Initialize the prompt builder."""
        self._section_separator = "\n\n---\n\n"

    def combine_sections(
        self,
        sections: dict[PersonalitySection, str],
        order: tuple[PersonalitySection, ...] | None = None,
    ) -> str:
        """Combine multiple personality sections into a single prompt.

        Args:
            sections: Dictionary mapping sections to their content.
            order: Optional tuple specifying section order. If not provided,
                   uses the natural enum order.

        Returns:
            Combined prompt string with sections separated.
        """
        if order is None:
            # Use natural enum order
            order = tuple(PersonalitySection)

        parts = []
        for section in order:
            if section in sections:
                parts.append(sections[section])

        combined = self._section_separator.join(parts)
        logger.debug(
            f"Combined {len(parts)} sections into prompt ({len(combined)} chars)"
        )
        return combined

    def inject_context(self, prompt: str, context: DynamicContext) -> str:
        """Inject dynamic context into a prompt.

        Replaces placeholders like {{current_date}}, {{projects}}, etc.
        with actual values from the context.

        Args:
            prompt: The prompt string with placeholders.
            context: The dynamic context to inject.

        Returns:
            Prompt string with placeholders replaced.
        """
        replacements = self._build_replacements(context)

        def replace_placeholder(match: re.Match[str]) -> str:
            key = match.group(1)
            if key in replacements:
                return replacements[key]
            # Leave unknown placeholders as-is
            logger.debug(f"Unknown placeholder: {{{{{key}}}}}")
            return match.group(0)

        result = self.PLACEHOLDER_PATTERN.sub(replace_placeholder, prompt)
        logger.debug(
            f"Injected context, replaced {len(replacements)} placeholder types"
        )
        return result

    def _build_replacements(self, context: DynamicContext) -> dict[str, str]:
        """Build replacement dictionary from context.

        Args:
            context: The dynamic context.

        Returns:
            Dictionary mapping placeholder names to replacement strings.
        """
        replacements: dict[str, str] = {}

        # Date/time
        replacements["current_date"] = context.current_date.strftime("%Y-%m-%d")
        replacements["current_time"] = context.current_date.strftime("%H:%M UTC")
        replacements["current_day"] = context.current_date.strftime("%A")

        # Projects
        if context.projects:
            project_lines = []
            for p in context.projects:
                line = f"- {p.name}"
                if p.client:
                    line += f" ({p.client})"
                if p.description:
                    line += f": {p.description}"
                project_lines.append(line)
            replacements["projects"] = "\n".join(project_lines)
            replacements["active_project"] = context.projects[0].name
        else:
            replacements["projects"] = "(No active projects)"
            replacements["active_project"] = "(None)"

        # People
        if context.people:
            people_lines = []
            for person in context.people:
                line = f"- {person.name} ({person.relation})"
                if person.context:
                    line += f": {person.context}"
                people_lines.append(line)
            replacements["people"] = "\n".join(people_lines)
        else:
            replacements["people"] = "(No people in context)"

        # Memories
        if context.memories:
            memory_lines = []
            for m in sorted(context.memories, key=lambda x: x.relevance, reverse=True):
                memory_lines.append(f"- {m.content}")
            replacements["memories"] = "\n".join(memory_lines)
            replacements["recent_memories"] = "\n".join(memory_lines[:3])
        else:
            replacements["memories"] = "(No relevant memories)"
            replacements["recent_memories"] = "(No recent memories)"

        # Custom context
        if context.custom_context:
            replacements["custom_context"] = context.custom_context
        else:
            replacements["custom_context"] = ""

        return replacements

    def estimate_tokens(
        self, text: str, language: LanguageMode = LanguageMode.AUTO
    ) -> int:
        """Estimate token count for text.

        Uses approximate ratios based on language. English text averages
        ~4 characters per token, Ukrainian ~2 characters per token.

        Args:
            text: The text to estimate tokens for.
            language: The language mode to use for estimation.

        Returns:
            Estimated token count.
        """
        if not text:
            return 0

        chars_per_token: float
        if language == LanguageMode.ENGLISH:
            chars_per_token = CHARS_PER_TOKEN_ENGLISH
        elif language == LanguageMode.UKRAINIAN:
            chars_per_token = CHARS_PER_TOKEN_UKRAINIAN
        else:
            # AUTO mode - estimate based on character analysis
            chars_per_token = self._detect_chars_per_token(text)

        return max(1, int(len(text) / chars_per_token))

    def _detect_chars_per_token(self, text: str) -> float:
        """Detect approximate chars per token based on text content.

        Args:
            text: The text to analyze.

        Returns:
            Estimated characters per token ratio.
        """
        # Check for Cyrillic characters (Ukrainian)
        cyrillic_count = sum(1 for c in text if "\u0400" <= c <= "\u04ff")
        total_alpha = sum(1 for c in text if c.isalpha())

        if total_alpha == 0:
            return DEFAULT_CHARS_PER_TOKEN

        cyrillic_ratio = cyrillic_count / total_alpha

        # Blend between Ukrainian and English ratios
        if cyrillic_ratio > 0.5:
            return CHARS_PER_TOKEN_UKRAINIAN
        elif cyrillic_ratio > 0.2:
            # Mixed content
            return (CHARS_PER_TOKEN_ENGLISH + CHARS_PER_TOKEN_UKRAINIAN) / 2
        else:
            return CHARS_PER_TOKEN_ENGLISH

    def build_prompt(
        self,
        sections: dict[PersonalitySection, str],
        config: PersonalityConfig,
        context: DynamicContext | None = None,
    ) -> PersonalityPrompt:
        """Build a complete personality prompt.

        Combines sections, injects context, and validates against token budget.

        Args:
            sections: Dictionary mapping sections to their content.
            config: Configuration for prompt building.
            context: Optional dynamic context to inject.

        Returns:
            A PersonalityPrompt object with the built prompt.
        """
        # Filter to only requested sections
        filtered_sections = {
            section: content
            for section, content in sections.items()
            if section in config.sections
        }

        # Handle examples inclusion
        if not config.include_examples:
            filtered_sections.pop(PersonalitySection.EXAMPLES, None)

        # Combine sections
        combined = self.combine_sections(filtered_sections, order=config.sections)

        # Inject context if provided
        context_injected = False
        if context is not None:
            combined = self.inject_context(combined, context)
            context_injected = True

        # Estimate tokens
        estimated_tokens = self.estimate_tokens(combined, config.language)

        # Truncate if over budget (simple truncation for now)
        if estimated_tokens > config.max_tokens:
            logger.warning(
                f"Prompt exceeds token budget ({estimated_tokens} > {config.max_tokens}). "
                "Consider reducing sections."
            )
            # Calculate approximate character limit
            if config.language == LanguageMode.ENGLISH:
                char_limit = config.max_tokens * CHARS_PER_TOKEN_ENGLISH
            elif config.language == LanguageMode.UKRAINIAN:
                char_limit = config.max_tokens * CHARS_PER_TOKEN_UKRAINIAN
            else:
                detected_ratio = self._detect_chars_per_token(combined)
                char_limit = int(config.max_tokens * detected_ratio)

            combined = (
                combined[:char_limit] + "\n\n[Content truncated due to token limit]"
            )
            estimated_tokens = config.max_tokens

        sections_included = tuple(s for s in config.sections if s in filtered_sections)

        return PersonalityPrompt(
            content=combined,
            sections_included=sections_included,
            estimated_tokens=estimated_tokens,
            language=config.language,
            mode=config.mode,
            context_injected=context_injected,
        )

    def add_mode_instructions(self, prompt: str, mode: ConversationMode) -> str:
        """Add mode-specific instructions to a prompt.

        Args:
            prompt: The base prompt.
            mode: The conversation mode.

        Returns:
            Prompt with mode-specific instructions appended.
        """
        instructions = self._get_mode_instructions(mode)
        if instructions:
            return (
                f"{prompt}\n\n## Current Mode: {mode.value.upper()}\n\n{instructions}"
            )
        return prompt

    def _get_mode_instructions(self, mode: ConversationMode) -> str:
        """Get mode-specific instructions.

        Args:
            mode: The conversation mode.

        Returns:
            Mode-specific instruction string.
        """
        mode_instructions = {
            ConversationMode.ASSESSMENT: (
                "You are conducting a cybersecurity assessment. "
                "Use structured interview techniques, ask for evidence, "
                "and document findings with business impact."
            ),
            ConversationMode.CONSULTING: (
                "You are in a consulting engagement. Balance technical depth "
                "with business communication. Provide actionable recommendations."
            ),
            ConversationMode.TECHNICAL: (
                "Focus on technical accuracy and depth. Use precise terminology. "
                "Provide detailed explanations with examples when helpful."
            ),
            ConversationMode.CASUAL: (
                "This is a casual conversation. Be friendly and relaxed. "
                "Use Ukrainian if the other person speaks Ukrainian. "
                "Share personal experiences when appropriate."
            ),
            ConversationMode.MEETING: (
                "You are in a meeting context. Be concise, focused, and "
                "action-oriented. Track decisions and action items."
            ),
        }
        return mode_instructions.get(mode, "")

    def truncate_to_budget(
        self,
        content: str,
        max_tokens: int,
        language: LanguageMode = LanguageMode.AUTO,
    ) -> tuple[str, int]:
        """Truncate content to fit within token budget.

        Args:
            content: The content to truncate.
            max_tokens: Maximum allowed tokens.
            language: Language mode for token estimation.

        Returns:
            Tuple of (truncated_content, estimated_tokens).
        """
        estimated_tokens = self.estimate_tokens(content, language)

        if estimated_tokens <= max_tokens:
            return content, estimated_tokens

        # Calculate character limit based on language
        if language == LanguageMode.ENGLISH:
            char_limit = max_tokens * CHARS_PER_TOKEN_ENGLISH
        elif language == LanguageMode.UKRAINIAN:
            char_limit = max_tokens * CHARS_PER_TOKEN_UKRAINIAN
        else:
            detected_ratio = self._detect_chars_per_token(content)
            char_limit = int(max_tokens * detected_ratio)

        truncated = content[:char_limit] + "\n\n[Content truncated due to token limit]"
        return truncated, max_tokens
