"""Personality content loader.

This module handles loading and caching personality markdown files
from the content directory.
"""

import logging
from pathlib import Path

from .models import PersonalitySection

logger = logging.getLogger(__name__)


class PersonalityLoaderError(Exception):
    """Base exception for personality loader errors."""

    pass


class ContentNotFoundError(PersonalityLoaderError):
    """Raised when a personality content file is not found."""

    pass


class PersonalityLoader:
    """Loads and caches personality content from markdown files.

    This class is responsible for reading personality content files
    from the content directory and caching them for efficient access.

    Attributes:
        content_dir: Path to the directory containing content files.
    """

    SECTION_FILES: dict[PersonalitySection, str] = {
        PersonalitySection.BASE: "base.md",
        PersonalitySection.COMMUNICATION: "communication.md",
        PersonalitySection.KNOWLEDGE: "knowledge.md",
        PersonalitySection.BEHAVIORS: "behaviors.md",
        PersonalitySection.EXAMPLES: "examples.md",
    }

    def __init__(self, content_dir: Path | None = None) -> None:
        """Initialize the personality loader.

        Args:
            content_dir: Path to content directory. Defaults to the
                        bundled content directory.
        """
        if content_dir is None:
            # Use the bundled content directory relative to this file
            self._content_dir = Path(__file__).parent / "content"
        else:
            self._content_dir = Path(content_dir)

        self._cache: dict[PersonalitySection, str] = {}
        logger.debug(
            f"PersonalityLoader initialized with content_dir: {self._content_dir}"
        )

    @property
    def content_dir(self) -> Path:
        """Get the content directory path."""
        return self._content_dir

    def load_section(self, section: PersonalitySection) -> str:
        """Load a single personality section.

        Args:
            section: The section to load.

        Returns:
            The content of the section as a string.

        Raises:
            ContentNotFoundError: If the content file is not found.
        """
        # Check cache first
        if section in self._cache:
            logger.debug(f"Returning cached content for section: {section.value}")
            return self._cache[section]

        filename = self.SECTION_FILES.get(section)
        if filename is None:
            raise ContentNotFoundError(f"Unknown section: {section}")

        file_path = self._content_dir / filename

        if not file_path.exists():
            raise ContentNotFoundError(
                f"Content file not found: {file_path}. "
                f"Ensure the content directory contains {filename}"
            )

        try:
            content = file_path.read_text(encoding="utf-8")
            self._cache[section] = content
            logger.debug(
                f"Loaded and cached section: {section.value} ({len(content)} chars)"
            )
            return content
        except OSError as e:
            raise ContentNotFoundError(
                f"Failed to read content file {file_path}: {e}"
            ) from e

    def load_sections(
        self, sections: tuple[PersonalitySection, ...]
    ) -> dict[PersonalitySection, str]:
        """Load multiple personality sections.

        Args:
            sections: Tuple of sections to load.

        Returns:
            Dictionary mapping sections to their content.

        Raises:
            ContentNotFoundError: If any content file is not found.
        """
        result: dict[PersonalitySection, str] = {}
        for section in sections:
            result[section] = self.load_section(section)
        return result

    def load_all(self) -> dict[PersonalitySection, str]:
        """Load all personality sections.

        Returns:
            Dictionary mapping all sections to their content.

        Raises:
            ContentNotFoundError: If any content file is not found.
        """
        return self.load_sections(tuple(PersonalitySection))

    def clear_cache(self) -> None:
        """Clear the content cache."""
        self._cache.clear()
        logger.debug("Content cache cleared")

    def is_cached(self, section: PersonalitySection) -> bool:
        """Check if a section is cached.

        Args:
            section: The section to check.

        Returns:
            True if the section is cached, False otherwise.
        """
        return section in self._cache

    def get_available_sections(self) -> list[PersonalitySection]:
        """Get list of sections that have content files available.

        Returns:
            List of sections with available content files.
        """
        available = []
        for section, filename in self.SECTION_FILES.items():
            file_path = self._content_dir / filename
            if file_path.exists():
                available.append(section)
        return available

    def validate_content_directory(self) -> tuple[bool, list[str]]:
        """Validate that all required content files exist.

        Returns:
            Tuple of (is_valid, list_of_missing_files).
        """
        missing = []
        for _section, filename in self.SECTION_FILES.items():
            file_path = self._content_dir / filename
            if not file_path.exists():
                missing.append(filename)

        return len(missing) == 0, missing
