"""Main personality manager for Digital Valerii.

This module provides the PersonalityManager class which orchestrates
the loading, building, and management of personality prompts.
"""

import logging
from pathlib import Path

from .loader import PersonalityLoader
from .models import (
    ConversationMode,
    DynamicContext,
    LanguageMode,
    PersonalityConfig,
    PersonalityPrompt,
    PersonalitySection,
)
from .prompts import PromptBuilder

logger = logging.getLogger(__name__)


class PersonalityManager:
    """Manages personality prompts for Digital Valerii.

    This is the main entry point for the personality system. It coordinates
    between the loader and prompt builder to create system prompts.

    Example:
        manager = PersonalityManager()
        prompt = manager.build_system_prompt(
            mode=ConversationMode.ASSESSMENT,
            context=DynamicContext(projects=[...])
        )
        print(prompt.content)
    """

    def __init__(self, content_dir: Path | None = None) -> None:
        """Initialize the personality manager.

        Args:
            content_dir: Optional path to content directory.
                        Uses bundled content if not specified.
        """
        self._loader = PersonalityLoader(content_dir)
        self._builder = PromptBuilder()
        self._preloaded = False
        logger.info("PersonalityManager initialized")

    @property
    def loader(self) -> PersonalityLoader:
        """Get the personality loader."""
        return self._loader

    @property
    def builder(self) -> PromptBuilder:
        """Get the prompt builder."""
        return self._builder

    def preload(self) -> None:
        """Preload all personality sections into cache.

        This is useful for warming up the cache at application startup
        to avoid first-request latency.
        """
        if self._preloaded:
            logger.debug("Content already preloaded, skipping")
            return

        logger.info("Preloading personality content...")
        self._loader.load_all()
        self._preloaded = True
        logger.info("Personality content preloaded successfully")

    def build_system_prompt(
        self,
        mode: ConversationMode = ConversationMode.CONSULTING,
        language: LanguageMode = LanguageMode.AUTO,
        context: DynamicContext | None = None,
        sections: tuple[PersonalitySection, ...] | None = None,
        max_tokens: int = 4000,
        include_examples: bool = True,
        include_mode_instructions: bool = True,
    ) -> PersonalityPrompt:
        """Build a complete system prompt for the specified mode.

        This is the main method for generating personality prompts.
        It loads required sections, injects context, and returns
        a ready-to-use prompt.

        Args:
            mode: The conversation mode (ASSESSMENT, CONSULTING, etc.)
            language: The preferred language mode.
            context: Optional dynamic context to inject.
            sections: Optional tuple of sections to include.
                     Defaults to all sections.
            max_tokens: Maximum tokens for the prompt.
            include_examples: Whether to include example responses.
            include_mode_instructions: Whether to add mode-specific instructions.

        Returns:
            A PersonalityPrompt object containing the built prompt.

        Example:
            prompt = manager.build_system_prompt(
                mode=ConversationMode.ASSESSMENT,
                context=DynamicContext(
                    projects=(ProjectReference(name="Client X Audit"),)
                )
            )
        """
        # Build configuration
        if sections is None:
            sections = tuple(PersonalitySection)

        config = PersonalityConfig(
            sections=sections,
            language=language,
            mode=mode,
            max_tokens=max_tokens,
            include_examples=include_examples,
        )

        # Load required sections
        section_content = self._loader.load_sections(config.sections)

        # Build the prompt
        prompt = self._builder.build_prompt(section_content, config, context)

        # Add mode instructions if requested
        if include_mode_instructions:
            enhanced_content = self._builder.add_mode_instructions(prompt.content, mode)

            # Re-check and enforce token budget after adding mode instructions
            enhanced_content, enhanced_tokens = self._builder.truncate_to_budget(
                enhanced_content, max_tokens, language
            )

            # Create new prompt with enhanced content
            prompt = PersonalityPrompt(
                content=enhanced_content,
                sections_included=prompt.sections_included,
                estimated_tokens=enhanced_tokens,
                language=prompt.language,
                mode=prompt.mode,
                context_injected=prompt.context_injected,
            )

        logger.info(
            f"Built system prompt: mode={mode.value}, "
            f"sections={len(prompt.sections_included)}, "
            f"tokens~{prompt.estimated_tokens}"
        )

        return prompt

    def build_assessment_prompt(
        self,
        context: DynamicContext | None = None,
        max_tokens: int = 4000,
    ) -> PersonalityPrompt:
        """Build a prompt specifically for assessment interviews.

        This is a convenience method that configures the prompt
        for cybersecurity assessment contexts.

        Args:
            context: Optional dynamic context to inject.
            max_tokens: Maximum tokens for the prompt.

        Returns:
            A PersonalityPrompt configured for assessments.
        """
        return self.build_system_prompt(
            mode=ConversationMode.ASSESSMENT,
            language=LanguageMode.ENGLISH,
            context=context,
            max_tokens=max_tokens,
            include_examples=True,
            include_mode_instructions=True,
        )

    def build_casual_prompt(
        self,
        context: DynamicContext | None = None,
        language: LanguageMode = LanguageMode.AUTO,
        max_tokens: int = 2000,
    ) -> PersonalityPrompt:
        """Build a prompt for casual conversations.

        This is a convenience method that configures the prompt
        for casual, personal conversations.

        Args:
            context: Optional dynamic context to inject.
            language: Preferred language mode.
            max_tokens: Maximum tokens for the prompt.

        Returns:
            A PersonalityPrompt configured for casual conversation.
        """
        # For casual mode, focus on base and communication, skip heavy knowledge
        sections = (
            PersonalitySection.BASE,
            PersonalitySection.COMMUNICATION,
            PersonalitySection.EXAMPLES,
        )

        return self.build_system_prompt(
            mode=ConversationMode.CASUAL,
            language=language,
            context=context,
            sections=sections,
            max_tokens=max_tokens,
            include_examples=True,
            include_mode_instructions=True,
        )

    def build_technical_prompt(
        self,
        context: DynamicContext | None = None,
        max_tokens: int = 4000,
    ) -> PersonalityPrompt:
        """Build a prompt for technical discussions.

        This is a convenience method that emphasizes technical knowledge.

        Args:
            context: Optional dynamic context to inject.
            max_tokens: Maximum tokens for the prompt.

        Returns:
            A PersonalityPrompt configured for technical discussions.
        """
        # For technical mode, emphasize knowledge and behaviors
        sections = (
            PersonalitySection.BASE,
            PersonalitySection.COMMUNICATION,
            PersonalitySection.KNOWLEDGE,
            PersonalitySection.BEHAVIORS,
        )

        return self.build_system_prompt(
            mode=ConversationMode.TECHNICAL,
            language=LanguageMode.ENGLISH,
            context=context,
            sections=sections,
            max_tokens=max_tokens,
            include_examples=False,  # Skip examples for technical mode
            include_mode_instructions=True,
        )

    def get_section_content(self, section: PersonalitySection) -> str:
        """Get the raw content of a specific section.

        Args:
            section: The section to retrieve.

        Returns:
            The raw content of the section.
        """
        return self._loader.load_section(section)

    def validate(self) -> tuple[bool, list[str]]:
        """Validate that all required content files exist.

        Returns:
            Tuple of (is_valid, list_of_missing_files).
        """
        return self._loader.validate_content_directory()

    def clear_cache(self) -> None:
        """Clear the content cache."""
        self._loader.clear_cache()
        self._preloaded = False
        logger.debug("PersonalityManager cache cleared")

    def get_stats(self) -> dict[str, int | bool]:
        """Get statistics about the personality system.

        Returns:
            Dictionary with stats like cached sections count,
            content directory status, etc.
        """
        available = self._loader.get_available_sections()
        is_valid, missing = self.validate()

        return {
            "available_sections": len(available),
            "total_sections": len(PersonalitySection),
            "is_valid": is_valid,
            "missing_files": len(missing),
            "preloaded": self._preloaded,
        }
