"""Memory hooks for Claude Agent SDK integration.

This module provides hooks for integrating memory recall and store
functionality with the Claude Agent SDK lifecycle.
"""

import logging
from typing import Any, Protocol, runtime_checkable

from ..personality.models import MemoryReference

logger = logging.getLogger(__name__)


@runtime_checkable
class MemoryManager(Protocol):
    """Protocol for memory manager interface.

    This defines the expected interface for the memory manager
    that will be implemented in Component 1.5.
    """

    async def recall(
        self,
        query: str,
        conversation_id: str | None = None,
        user_id: str | None = None,
        limit: int = 10,
    ) -> list[MemoryReference]:
        """Recall relevant memories for the query."""
        ...

    async def store(
        self,
        message: str,
        response: str,
        conversation_id: str | None = None,
        interface: str | None = None,
    ) -> None:
        """Store an interaction in memory."""
        ...


class MemoryHooks:
    """Hooks for memory integration with Claude Agent SDK.

    Provides SessionStart and Stop hooks to integrate memory
    recall and storage with the agent lifecycle.
    """

    def __init__(self, memory_manager: MemoryManager) -> None:
        """Initialize memory hooks.

        Args:
            memory_manager: The memory manager for recall/store operations.
        """
        self._memory = memory_manager
        self._last_prompt: str | None = None
        self._recalled_memories: list[MemoryReference] = []
        self._conversation_id: str | None = None
        self._interface: str | None = None
        logger.info("MemoryHooks initialized")

    @property
    def recalled_memories(self) -> list[MemoryReference]:
        """Get the last recalled memories."""
        return self._recalled_memories

    def set_context(
        self,
        conversation_id: str | None = None,
        interface: str | None = None,
    ) -> None:
        """Set context for memory operations.

        Args:
            conversation_id: The conversation ID for memory context.
            interface: The interface type for memory context.
        """
        self._conversation_id = conversation_id
        self._interface = interface

    async def on_session_start(
        self,
        input_data: dict[str, Any],
        tool_use_id: str,  # noqa: ARG002 - part of hook API
        context: dict[str, Any],  # noqa: ARG002 - part of hook API
    ) -> dict[str, Any]:
        """Called when session starts - recall memories.

        Args:
            input_data: Input data from the SDK.
            tool_use_id: The tool use ID (part of hook API).
            context: Additional context (part of hook API).

        Returns:
            Modified input data with memory context.
        """
        try:
            # Extract the prompt from input data
            prompt = input_data.get("prompt", "")
            self._last_prompt = prompt

            if not prompt:
                logger.debug("No prompt to recall memories for")
                return {}

            # Recall memories based on the prompt
            self._recalled_memories = await self._memory.recall(
                query=prompt,
                conversation_id=self._conversation_id,
                limit=10,
            )

            logger.info(f"Recalled {len(self._recalled_memories)} memories")

            # Return memory context to be injected
            if self._recalled_memories:
                memory_context = self._format_memories_for_context()
                return {"memory_context": memory_context}

            return {}

        except Exception as e:
            # Best-effort: log warning and continue without memories
            logger.warning(f"Memory recall failed (best-effort): {e}")
            self._recalled_memories = []
            return {}

    async def on_stop(
        self,
        input_data: dict[str, Any],  # noqa: ARG002 - part of hook API
        tool_use_id: str,  # noqa: ARG002 - part of hook API
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Called when agent stops - store interaction.

        Args:
            input_data: Input data from the SDK (part of hook API).
            tool_use_id: The tool use ID (part of hook API).
            context: Additional context containing the response.

        Returns:
            Empty dict (no modifications needed).
        """
        try:
            # Extract response from context
            response = context.get("response", "")
            message = self._last_prompt or ""

            if not message or not response:
                logger.debug("No message or response to store")
                return {}

            # Store the interaction
            await self._memory.store(
                message=message,
                response=response,
                conversation_id=self._conversation_id,
                interface=self._interface,
            )

            logger.info("Interaction stored in memory")
            return {}

        except Exception as e:
            logger.error(f"Error in on_stop hook: {e}")
            # Don't raise here - storing memory shouldn't block response
            return {}

    def _format_memories_for_context(self) -> str:
        """Format recalled memories for context injection.

        Returns:
            Formatted string of memories.
        """
        if not self._recalled_memories:
            return ""

        lines = ["Relevant memories from previous conversations:"]
        for memory in sorted(
            self._recalled_memories, key=lambda m: m.relevance, reverse=True
        ):
            lines.append(f"- {memory.content}")

        return "\n".join(lines)

    def get_hook_config(self) -> dict[str, Any]:
        """Get hooks configuration for ClaudeAgentOptions.

        Returns:
            Dictionary with hook configuration.
        """
        # Note: The actual structure depends on Claude Agent SDK API
        # This is a placeholder that will be updated based on SDK docs
        return {
            "SessionStart": {
                "handler": self.on_session_start,
                "matcher": ".*",
            },
            "Stop": {
                "handler": self.on_stop,
                "matcher": ".*",
            },
        }

    def clear(self) -> None:
        """Clear the hook state."""
        self._last_prompt = None
        self._recalled_memories = []
        self._conversation_id = None
        self._interface = None
