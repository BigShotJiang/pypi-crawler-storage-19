"""Adapters for integrating external services with Agent Core.

This module provides adapters to make external services compatible
with the Agent Core interfaces.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from digital_valerii_shared.agent.personality.models import MemoryReference

if TYPE_CHECKING:
    from digital_valerii_shared.services.memory import (
        MemoryContext,
    )
    from digital_valerii_shared.services.memory import (
        MemoryManager as RealMemoryManager,
    )

logger = logging.getLogger(__name__)


class MemoryManagerAdapter:
    """Adapter to make Component 1.5 MemoryManager compatible with Agent Core.

    The Component 1.5 MemoryManager uses:
    - Context object for session/conversation info
    - MemoryContext for recall results (with events, people, projects, lessons)

    Agent Core expects:
    - Simple keyword args for recall/store
    - list[MemoryReference] for recall results

    This adapter bridges these differences.

    Example:
        from digital_valerii_shared.services.memory import MemoryManager
        from digital_valerii_shared.agent.core.adapters import MemoryManagerAdapter

        real_manager = MemoryManager(db, qdrant, redis, embedding)
        adapter = MemoryManagerAdapter(real_manager)

        # Now adapter can be used with Agent Core
        agent = DigitalValeriiAgent(memory_manager=adapter)
    """

    def __init__(self, memory_manager: RealMemoryManager) -> None:
        """Initialize adapter with real memory manager.

        Args:
            memory_manager: Component 1.5 MemoryManager instance.
        """
        self._memory = memory_manager

    async def recall(
        self,
        query: str,
        conversation_id: str | None = None,
        user_id: str | None = None,  # noqa: ARG002 - part of adapter interface
        limit: int = 10,
    ) -> list[MemoryReference]:
        """Recall relevant memories, adapting to Agent Core interface.

        Args:
            query: Search query.
            conversation_id: Optional conversation ID.
            user_id: Optional user ID (not used by Component 1.5).
            limit: Maximum memories to return.

        Returns:
            List of MemoryReference objects.
        """
        # Import here to avoid circular imports and optional dependency
        from digital_valerii_shared.services.memory import Context

        # Create Context for Component 1.5
        context = Context(
            session_id=conversation_id or "default",
            conversation_id=conversation_id,
            message_index=0,
            interface="agent",
        )

        try:
            # Call real memory manager
            memory_context = await self._memory.recall(
                query=query,
                context=context,
                limit=limit,
            )

            # Convert to list[MemoryReference]
            return self._convert_to_references(memory_context)

        except Exception as e:
            logger.warning(f"Memory recall failed: {e}")
            return []

    async def store(
        self,
        message: str,
        response: str,
        conversation_id: str | None = None,
        interface: str | None = None,
    ) -> None:
        """Store interaction, adapting to Agent Core interface.

        Args:
            message: User's message.
            response: Agent's response.
            conversation_id: Optional conversation ID.
            interface: Optional interface type.
        """
        # Import here to avoid circular imports
        from digital_valerii_shared.services.memory import Context

        # Create Context for Component 1.5
        context = Context(
            session_id=conversation_id or "default",
            conversation_id=conversation_id,
            message_index=0,
            interface=interface or "agent",
        )

        try:
            await self._memory.store(
                user_message=message,
                agent_response=response,
                context=context,
                event_type="conversation",
            )
        except Exception as e:
            logger.warning(f"Memory store failed: {e}")

    def _convert_to_references(
        self, memory_context: MemoryContext
    ) -> list[MemoryReference]:
        """Convert Component 1.5 MemoryContext to list[MemoryReference].

        Extracts content from events, people, projects, and lessons.

        Args:
            memory_context: MemoryContext from Component 1.5.

        Returns:
            List of MemoryReference objects sorted by relevance.
        """
        references: list[MemoryReference] = []

        # Convert events to references
        for event in memory_context.events:
            content = self._format_event_content(event)
            references.append(
                MemoryReference(
                    content=content,
                    timestamp=event.occurred_at,
                    relevance=event.final_score,
                )
            )

        # Convert people mentions to references (lower relevance)
        for person in memory_context.people:
            content = self._format_person_content(person)
            references.append(
                MemoryReference(
                    content=content,
                    timestamp=datetime.now(tz=UTC),
                    relevance=0.5,  # Default relevance for people
                )
            )

        # Convert projects to references
        for project in memory_context.projects:
            content = self._format_project_content(project)
            references.append(
                MemoryReference(
                    content=content,
                    timestamp=datetime.now(tz=UTC),
                    relevance=0.6,  # Default relevance for projects
                )
            )

        # Convert lessons to references (high relevance)
        for lesson in memory_context.lessons:
            references.append(
                MemoryReference(
                    content=lesson.content,
                    timestamp=datetime.now(tz=UTC),
                    relevance=lesson.confidence,
                )
            )

        # Sort by relevance descending
        references.sort(key=lambda r: r.relevance, reverse=True)

        return references

    def _format_event_content(self, event: Any) -> str:
        """Format event into readable content.

        Args:
            event: RankedEvent from Component 1.5.

        Returns:
            Formatted string.
        """
        parts = []
        if event.title:
            parts.append(event.title)
        if event.summary:
            parts.append(event.summary)
        if not parts:
            parts.append(f"Event: {event.event_type}")
        return " - ".join(parts)

    def _format_person_content(self, person: Any) -> str:
        """Format person into readable content.

        Args:
            person: PersonSummary from Component 1.5.

        Returns:
            Formatted string.
        """
        parts = [f"Person: {person.name}"]
        if person.company:
            parts.append(f"at {person.company}")
        if person.relationship_type:
            parts.append(f"({person.relationship_type})")
        return " ".join(parts)

    def _format_project_content(self, project: Any) -> str:
        """Format project into readable content.

        Args:
            project: ProjectSummary from Component 1.5.

        Returns:
            Formatted string.
        """
        parts = [f"Project: {project.name}"]
        if project.status:
            parts.append(f"[{project.status}]")
        if project.description:
            parts.append(f"- {project.description[:100]}")
        return " ".join(parts)
