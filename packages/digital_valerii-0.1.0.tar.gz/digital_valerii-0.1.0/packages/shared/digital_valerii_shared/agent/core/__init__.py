"""Agent core module for Digital Valerii.

This module provides the core agent functionality using Claude Agent SDK,
including the main agent class, context management, hooks, and options builder.
"""

from .adapters import MemoryManagerAdapter
from .agent import DigitalValeriiAgent
from .context import ConversationContext, InterfaceType
from .hooks import MemoryHooks, MemoryManager
from .models import (
    AgentError,
    AgentHookError,
    AgentMessage,
    AgentResponse,
    AgentSessionError,
    AgentStatus,
)
from .options import AgentOptionsBuilder, MCPServerConfig

__all__ = [
    # Main agent
    "DigitalValeriiAgent",
    # Context
    "ConversationContext",
    "InterfaceType",
    # Adapters
    "MemoryManagerAdapter",
    # Hooks
    "MemoryHooks",
    "MemoryManager",
    # Options
    "AgentOptionsBuilder",
    "MCPServerConfig",
    # Models
    "AgentMessage",
    "AgentResponse",
    "AgentStatus",
    # Exceptions
    "AgentError",
    "AgentHookError",
    "AgentSessionError",
]
