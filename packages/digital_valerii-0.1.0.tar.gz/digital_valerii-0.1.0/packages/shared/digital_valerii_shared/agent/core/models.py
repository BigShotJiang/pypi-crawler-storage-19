"""Agent core models for Digital Valerii.

This module defines the core data models for the agent system
using Claude Agent SDK, including response models and exceptions.
"""

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class AgentStatus(str, Enum):
    """Status of agent response."""

    COMPLETE = "complete"
    STREAMING = "streaming"
    ERROR = "error"


class AgentMessage(BaseModel):
    """A message from the agent (for streaming).

    Represents individual messages during streaming response.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    type: str  # "text", "tool_use", "tool_result", "system"
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class AgentResponse(BaseModel):
    """Final response from the agent.

    Contains the complete response after agent query completion,
    including session information and usage statistics.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: AgentStatus
    message: str
    session_id: str
    tokens_used: int = 0
    tools_used: tuple[str, ...] = Field(default=())
    error: str | None = None


# Exceptions


class AgentError(Exception):
    """Base exception for agent errors."""

    pass


class AgentSessionError(AgentError):
    """Raised for session-related errors."""

    pass


class AgentHookError(AgentError):
    """Raised when a hook fails."""

    pass
