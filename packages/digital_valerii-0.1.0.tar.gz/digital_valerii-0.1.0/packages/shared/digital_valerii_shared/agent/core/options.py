"""Agent options builder for Claude Agent SDK.

This module provides the AgentOptionsBuilder class for creating
ClaudeAgentOptions with personality, memory, and MCP integration.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any

from ..personality import (
    ConversationMode,
    DynamicContext,
    MemoryReference,
    PersonalityManager,
    PersonReference,
    ProjectReference,
)
from .context import ConversationContext, InterfaceType
from .hooks import MemoryHooks

logger = logging.getLogger(__name__)


# =============================================================================
# MCP Server Configuration
# =============================================================================


class MCPServerConfig:
    """Configuration for MCP servers.

    Controls which MCP servers are enabled and their environment variables.
    """

    def __init__(
        self,
        enable_memory: bool = True,
        enable_browser: bool = False,
        enable_local_office: bool = False,
    ) -> None:
        """Initialize MCP server configuration.

        Args:
            enable_memory: Enable custom memory MCP server.
            enable_browser: Enable Playwright browser MCP.
            enable_local_office: Enable macOS Office AppleScript MCP.
        """
        self.enable_memory = enable_memory
        self.enable_browser = enable_browser
        self.enable_local_office = enable_local_office

    def build_server_list(self) -> list[dict[str, Any]]:
        """Build list of MCP server configurations.

        Returns:
            List of server configuration dictionaries.
        """
        servers: list[dict[str, Any]] = []

        # Memory MCP (always enabled by default)
        if self.enable_memory:
            servers.append(self._build_memory_mcp())

        # Playwright browser MCP
        if self.enable_browser:
            servers.append(self._build_playwright_mcp())

        # Local Office MCP (macOS only)
        if self.enable_local_office and self._is_macos():
            servers.append(self._build_office_mcp())

        return servers

    def _build_memory_mcp(self) -> dict[str, Any]:
        """Build memory MCP server configuration."""
        return {
            "name": "memory_mcp",
            "command": "python",
            "args": ["-m", "digital_valerii_shared.mcp.memory_server"],
            "env": {
                "DATABASE_URL": os.environ.get("DATABASE_URL", ""),
                "QDRANT_URL": os.environ.get("QDRANT_URL", ""),
                "REDIS_URL": os.environ.get("REDIS_URL", ""),
                "OPENAI_API_KEY": os.environ.get("OPENAI_API_KEY", ""),
            },
        }

    def _build_playwright_mcp(self) -> dict[str, Any]:
        """Build Playwright browser MCP configuration."""
        return {
            "name": "playwright",
            "command": "npx",
            "args": ["@playwright/mcp@latest"],
        }

    def _build_office_mcp(self) -> dict[str, Any]:
        """Build macOS Office MCP configuration."""
        # Uses macos-office365-mcp-server package
        return {
            "name": "office",
            "command": "python",
            "args": ["-m", "macos_office365_mcp.server"],
        }

    @staticmethod
    def _is_macos() -> bool:
        """Check if running on macOS."""
        return sys.platform == "darwin"


class AgentOptionsBuilder:
    """Builds agent options for DigitalValeriiAgent.

    Creates configuration for Claude Agent SDK queries with
    personality prompts, tools, hooks, and MCP servers.
    """

    # Default tools for Digital Valerii
    DEFAULT_TOOLS = ["Read", "Glob", "Grep", "WebSearch", "WebFetch"]

    # Tools that require approval (for future Component 2.7)
    APPROVAL_TOOLS = ["Bash", "Write", "Edit"]

    # Interface to conversation mode mapping
    INTERFACE_MODE_MAP: dict[InterfaceType, ConversationMode] = {
        InterfaceType.CLI: ConversationMode.CONSULTING,
        InterfaceType.WEB: ConversationMode.CONSULTING,
        InterfaceType.SLACK: ConversationMode.CASUAL,
        InterfaceType.MEETING: ConversationMode.MEETING,
        InterfaceType.API: ConversationMode.TECHNICAL,
    }

    def __init__(
        self,
        personality_manager: PersonalityManager,
        memory_hooks: MemoryHooks | None = None,
        mcp_config: MCPServerConfig | None = None,
    ) -> None:
        """Initialize options builder.

        Args:
            personality_manager: Manager for personality prompts.
            memory_hooks: Optional memory hooks for integration.
            mcp_config: Optional MCP server configuration.
        """
        self._personality = personality_manager
        self._memory_hooks = memory_hooks
        self._mcp_config = mcp_config or MCPServerConfig()
        logger.info("AgentOptionsBuilder initialized")

    @property
    def personality(self) -> PersonalityManager:
        """Get the personality manager."""
        return self._personality

    @property
    def memory_hooks(self) -> MemoryHooks | None:
        """Get the memory hooks."""
        return self._memory_hooks

    @property
    def mcp_config(self) -> MCPServerConfig:
        """Get the MCP server configuration."""
        return self._mcp_config

    def build(
        self,
        context: ConversationContext,
        memories: list[MemoryReference] | None = None,
        allowed_tools: list[str] | None = None,
        include_subagents: bool = False,
        include_mcp_servers: bool = True,
    ) -> dict[str, Any]:
        """Build options for a query.

        Args:
            context: Conversation context.
            memories: Recalled memories to inject.
            allowed_tools: Override default tools.
            include_subagents: Include specialized subagents.
            include_mcp_servers: Include MCP server configurations.

        Returns:
            Dictionary of options for Claude Agent SDK.
        """
        # Build dynamic context
        dynamic_context = self._build_dynamic_context(context, memories or [])

        # Get conversation mode from interface
        mode = self._get_mode(context.interface)

        # Build system prompt with personality
        prompt = self._personality.build_system_prompt(
            mode=mode,
            language=context.language,
            context=dynamic_context,
        )

        # Build options dictionary
        options: dict[str, Any] = {
            "system_prompt": prompt.content,
            "allowed_tools": allowed_tools or self.DEFAULT_TOOLS,
        }

        # Add hooks if available
        if self._memory_hooks:
            options["hooks"] = self._memory_hooks.get_hook_config()

        # Add session resume if continuing
        if context.session_id:
            options["resume"] = context.session_id

        # Add subagents if requested
        if include_subagents:
            options["agents"] = self._get_subagent_definitions()

        # Add MCP servers if requested
        if include_mcp_servers:
            mcp_servers = self._mcp_config.build_server_list()
            if mcp_servers:
                options["mcp_servers"] = mcp_servers

        logger.debug(
            f"Built options: mode={mode.value}, "
            f"tools={len(options['allowed_tools'])}, "
            f"mcp_servers={len(options.get('mcp_servers', []))}, "
            f"resume={context.session_id is not None}"
        )

        return options

    def build_system_prompt(
        self,
        context: ConversationContext,
        memories: list[MemoryReference] | None = None,
    ) -> str:
        """Build just the system prompt.

        Args:
            context: Conversation context.
            memories: Recalled memories to inject.

        Returns:
            The system prompt string.
        """
        dynamic_context = self._build_dynamic_context(context, memories or [])
        mode = self._get_mode(context.interface)

        prompt = self._personality.build_system_prompt(
            mode=mode,
            language=context.language,
            context=dynamic_context,
        )

        return prompt.content

    def _get_mode(self, interface: InterfaceType) -> ConversationMode:
        """Map interface to conversation mode.

        Args:
            interface: The interface type.

        Returns:
            The corresponding conversation mode.
        """
        return self.INTERFACE_MODE_MAP.get(interface, ConversationMode.CONSULTING)

    def _build_dynamic_context(
        self,
        context: ConversationContext,
        memories: list[MemoryReference],
    ) -> DynamicContext:
        """Build dynamic context from conversation state.

        Args:
            context: Conversation context.
            memories: Recalled memories.

        Returns:
            DynamicContext for prompt injection.
        """
        # Build project references from metadata
        projects: tuple[ProjectReference, ...] = ()
        if context.active_project_id and "projects" in context.metadata:
            project_data = context.metadata.get("projects", [])
            if project_data:
                projects = tuple(
                    ProjectReference(
                        name=p.get("name", "Unknown"),
                        client=p.get("client"),
                        description=p.get("description"),
                    )
                    for p in project_data
                )

        # Build people references from metadata
        people: tuple[PersonReference, ...] = ()
        if context.active_people_ids and "people" in context.metadata:
            people_data = context.metadata.get("people", [])
            if people_data:
                people = tuple(
                    PersonReference(
                        name=p.get("name", "Unknown"),
                        relation=p.get("relation", "contact"),
                        context=p.get("context"),
                    )
                    for p in people_data
                )

        return DynamicContext(
            projects=projects,
            people=people,
            memories=tuple(memories),
            custom_context=context.current_topic,
        )

    def _get_subagent_definitions(self) -> dict[str, dict[str, Any]]:
        """Define specialized subagents.

        Returns:
            Dictionary of subagent definitions.
        """
        return {
            "memory-search": {
                "description": "Search Digital Valerii's memories and knowledge.",
                "prompt": "Search memories for relevant information. Be thorough.",
                "tools": ["Read", "Grep"],
            },
            "assessment-helper": {
                "description": "Help with cybersecurity maturity assessments.",
                "prompt": "Assist with structured assessment interviews.",
                "tools": ["Read", "Grep", "WebSearch"],
            },
        }

    def get_default_tools(self) -> list[str]:
        """Get the default allowed tools.

        Returns:
            List of default tool names.
        """
        return self.DEFAULT_TOOLS.copy()

    def get_approval_tools(self) -> list[str]:
        """Get tools that require approval.

        Returns:
            List of tool names requiring approval.
        """
        return self.APPROVAL_TOOLS.copy()

    def get_mcp_servers(self) -> list[dict[str, Any]]:
        """Get the configured MCP servers.

        Returns:
            List of MCP server configurations.
        """
        return self._mcp_config.build_server_list()
