"""Conversation context management for Digital Valerii.

This module provides the ConversationContext class for managing
conversation metadata. Claude Agent SDK handles message history
via sessions internally.
"""

from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from ..personality.models import LanguageMode


class InterfaceType(str, Enum):
    """Interface types for the agent."""

    CLI = "cli"
    WEB = "web"
    SLACK = "slack"
    MEETING = "meeting"
    API = "api"


class ConversationContext(BaseModel):
    """Context for a conversation with the agent.

    Manages conversation metadata. Claude Agent SDK handles
    message history internally via sessions.
    """

    model_config = ConfigDict(extra="forbid")

    conversation_id: UUID = Field(default_factory=uuid4)
    interface: InterfaceType = InterfaceType.CLI
    language: LanguageMode = LanguageMode.AUTO
    user_id: UUID | None = None

    # Session management (SDK handles message history)
    session_id: str | None = None

    # Working memory
    current_topic: str | None = None
    active_project_id: UUID | None = None
    active_people_ids: tuple[UUID, ...] = Field(default=())

    # Metadata for additional context
    metadata: dict[str, Any] = Field(default_factory=dict)

    def update_session(self, session_id: str) -> None:
        """Update the session ID.

        Args:
            session_id: The new session ID from Claude Agent SDK.
        """
        self.session_id = session_id

    def clear_session(self) -> None:
        """Clear the session ID for a new conversation."""
        self.session_id = None

    def set_topic(self, topic: str | None) -> None:
        """Set the current conversation topic.

        Args:
            topic: The current topic or None to clear.
        """
        self.current_topic = topic

    def set_active_project(self, project_id: UUID | None) -> None:
        """Set the active project ID.

        Args:
            project_id: The active project ID or None to clear.
        """
        self.active_project_id = project_id

    def set_active_people(self, people_ids: tuple[UUID, ...]) -> None:
        """Set the active people IDs.

        Args:
            people_ids: Tuple of active people UUIDs.
        """
        self.active_people_ids = people_ids

    def add_metadata(self, key: str, value: Any) -> None:
        """Add metadata to the context.

        Args:
            key: Metadata key.
            value: Metadata value.
        """
        self.metadata[key] = value

    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get metadata from the context.

        Args:
            key: Metadata key.
            default: Default value if key not found.

        Returns:
            The metadata value or default.
        """
        return self.metadata.get(key, default)

    def has_session(self) -> bool:
        """Check if a session is active.

        Returns:
            True if session_id is set.
        """
        return self.session_id is not None
