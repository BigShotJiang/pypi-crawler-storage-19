"""Main agent class for Digital Valerii.

This module provides the DigitalValeriiAgent class which wraps
Claude Agent SDK with personality and memory integration.
"""

import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from digital_valerii_shared.agent.core.context import ConversationContext
from digital_valerii_shared.agent.core.hooks import MemoryHooks, MemoryManager
from digital_valerii_shared.agent.core.models import (
    AgentError,
    AgentMessage,
    AgentResponse,
    AgentStatus,
)
from digital_valerii_shared.agent.core.options import AgentOptionsBuilder
from digital_valerii_shared.agent.personality import MemoryReference, PersonalityManager

if TYPE_CHECKING:
    from digital_valerii_shared.licensing.guard import LicenseGuard

logger = logging.getLogger(__name__)


# Type alias for SDK query function (will be imported when SDK is available)
QueryFunction = Any


class DigitalValeriiAgent:
    """Main agent class for Digital Valerii.

    Wraps Claude Agent SDK with personality and memory integration.
    Provides both blocking and streaming interfaces for agent queries.
    """

    def __init__(
        self,
        personality_manager: PersonalityManager | None = None,
        memory_manager: MemoryManager | None = None,
        query_function: QueryFunction | None = None,
        license_guard: "LicenseGuard | None" = None,
    ) -> None:
        """Initialize agent with dependency injection.

        Args:
            personality_manager: Manager for personality prompts.
            memory_manager: Optional manager for memory operations.
            query_function: Optional SDK query function (for testing).
            license_guard: Optional license guard for validating AI operations.
        """
        self._personality = personality_manager or PersonalityManager()
        self._memory = memory_manager
        self._query_function = query_function
        self._license_guard = license_guard
        self._current_session_id: str | None = None

        # Initialize memory hooks if memory manager provided
        self._memory_hooks: MemoryHooks | None = None
        if memory_manager:
            self._memory_hooks = MemoryHooks(memory_manager)

        # Initialize options builder
        self._options_builder = AgentOptionsBuilder(
            personality_manager=self._personality,
            memory_hooks=self._memory_hooks,
        )

        logger.info("DigitalValeriiAgent initialized")

    @property
    def personality(self) -> PersonalityManager:
        """Get the personality manager."""
        return self._personality

    @property
    def memory(self) -> MemoryManager | None:
        """Get the memory manager."""
        return self._memory

    @property
    def options_builder(self) -> AgentOptionsBuilder:
        """Get the options builder."""
        return self._options_builder

    def get_session_id(self) -> str | None:
        """Get current session ID.

        Returns:
            The current session ID or None if no session active.
        """
        return self._current_session_id

    def resume_session(self, session_id: str) -> None:
        """Resume a previous session.

        Args:
            session_id: The session ID to resume.
        """
        self._current_session_id = session_id
        logger.info(f"Session resumed: {session_id[:8]}...")

    def clear_session(self) -> None:
        """Clear the current session."""
        self._current_session_id = None
        if self._memory_hooks:
            self._memory_hooks.clear()
        logger.info("Session cleared")

    async def chat(
        self,
        message: str,
        context: ConversationContext,
        allowed_tools: list[str] | None = None,
    ) -> AgentResponse:
        """Process user message and return response.

        Flow:
        1. Validate license (if license guard configured)
        2. Recall relevant memories (via hooks)
        3. Build system prompt with personality + context
        4. Run Claude Agent SDK query with hooks
        5. Store interaction in memory (via hooks)
        6. Return response

        Args:
            message: The user's message.
            context: Conversation context.
            allowed_tools: Optional list of allowed tools.

        Returns:
            AgentResponse with status, message, and session info.

        Raises:
            AgentError: If processing fails.
            LicenseError: If license is invalid or expired.
        """
        try:
            # License check BEFORE any AI call
            if self._license_guard:
                await self._license_guard.before_ai_call()

            # Set up memory hooks context
            if self._memory_hooks:
                self._memory_hooks.set_context(
                    conversation_id=str(context.conversation_id),
                    interface=context.interface.value,
                )

            # Recall memories ONLY if no hooks (hooks will do it via on_session_start)
            memories: list[MemoryReference] = []
            if not self._memory_hooks and self._memory:
                memories = await self._recall_memories(message, context)

            # Build options for query
            options = self._options_builder.build(
                context=context,
                memories=memories,  # Empty if hooks enabled (hooks inject memories)
                allowed_tools=allowed_tools,
            )

            # If resuming session, use context session_id
            if context.session_id and not self._current_session_id:
                self._current_session_id = context.session_id

            # Execute query and collect response
            response_text = ""
            tools_used: list[str] = []
            tokens_used = 0
            new_session_id = self._current_session_id or ""

            async for msg in self._execute_query(message, options):
                if msg.type == "text":
                    response_text += msg.content
                elif msg.type == "tool_use":
                    tool_name = msg.metadata.get("tool_name", "unknown")
                    if tool_name not in tools_used:
                        tools_used.append(tool_name)
                elif msg.type == "session":
                    new_session_id = msg.metadata.get("session_id", new_session_id)
                    tokens_used = msg.metadata.get("tokens_used", 0)

            # Update session ID
            self._current_session_id = new_session_id
            context.update_session(new_session_id)

            # Store interaction ONLY if no hooks (hooks will do it via on_stop)
            if not self._memory_hooks:
                await self._store_interaction(message, response_text, context)

            return AgentResponse(
                status=AgentStatus.COMPLETE,
                message=response_text,
                session_id=new_session_id,
                tokens_used=tokens_used,
                tools_used=tuple(tools_used),
            )

        except Exception as e:
            logger.exception(f"Error in chat: {e}")
            raise AgentError(f"Failed to process message: {e}") from e

    async def chat_stream(
        self,
        message: str,
        context: ConversationContext,
        allowed_tools: list[str] | None = None,
    ) -> AsyncIterator[AgentMessage]:
        """Stream response messages as they arrive.

        Args:
            message: The user's message.
            context: Conversation context.
            allowed_tools: Optional list of allowed tools.

        Yields:
            AgentMessage objects as they arrive.

        Raises:
            AgentError: If processing fails.
            LicenseError: If license is invalid or expired.
        """
        try:
            # License check BEFORE any AI call
            if self._license_guard:
                await self._license_guard.before_ai_call()

            # Set up memory hooks context
            if self._memory_hooks:
                self._memory_hooks.set_context(
                    conversation_id=str(context.conversation_id),
                    interface=context.interface.value,
                )

            # Recall memories ONLY if no hooks (hooks will do it via on_session_start)
            memories: list[MemoryReference] = []
            if not self._memory_hooks and self._memory:
                memories = await self._recall_memories(message, context)

            # Build options
            options = self._options_builder.build(
                context=context,
                memories=memories,  # Empty if hooks enabled
                allowed_tools=allowed_tools,
            )

            # Stream messages
            response_text = ""
            async for msg in self._execute_query(message, options):
                if msg.type == "text":
                    response_text += msg.content
                elif msg.type == "session":
                    new_session_id = msg.metadata.get("session_id", "")
                    self._current_session_id = new_session_id
                    context.update_session(new_session_id)

                yield msg

            # Store interaction ONLY if no hooks (hooks will do it via on_stop)
            if not self._memory_hooks:
                await self._store_interaction(message, response_text, context)

        except Exception as e:
            logger.exception(f"Error in chat_stream: {e}")
            yield AgentMessage(
                type="error",
                content=str(e),
                metadata={"error_type": type(e).__name__},
            )

    async def _execute_query(
        self,
        prompt: str,
        options: dict[str, Any],
    ) -> AsyncIterator[AgentMessage]:
        """Execute a query using Claude Agent SDK.

        Args:
            prompt: The user's prompt.
            options: Query options.

        Yields:
            AgentMessage objects from the SDK.
        """
        # If a custom query function is provided (for testing)
        if self._query_function:
            async for msg in self._query_function(prompt, options):
                yield msg
            return

        # Placeholder for actual SDK integration
        # When SDK is available, this will use:
        # from claude_agent_sdk import query
        # async for message in query(prompt=prompt, options=ClaudeAgentOptions(**options)):
        #     yield self._convert_sdk_message(message)

        # For now, yield a placeholder message
        logger.warning("Claude Agent SDK not available - using placeholder")
        yield AgentMessage(
            type="text",
            content="[SDK not configured - placeholder response]",
            metadata={},
        )
        yield AgentMessage(
            type="session",
            content="",
            metadata={
                "session_id": self._current_session_id or "placeholder",
                "tokens_used": 0,
            },
        )

    async def _recall_memories(
        self,
        message: str,
        context: ConversationContext,
    ) -> list[MemoryReference]:
        """Recall relevant memories for the message.

        Args:
            message: The user's message.
            context: Conversation context.

        Returns:
            List of relevant memories.
        """
        if not self._memory:
            return []

        try:
            memories = await self._memory.recall(
                query=message,
                conversation_id=str(context.conversation_id),
                user_id=str(context.user_id) if context.user_id else None,
            )
            logger.debug(f"Recalled {len(memories)} memories")
            return memories  # type: ignore[no-any-return]
        except Exception as e:
            logger.warning(f"Memory recall failed: {e}")
            return []

    async def _store_interaction(
        self,
        message: str,
        response: str,
        context: ConversationContext,
    ) -> None:
        """Store the interaction in memory.

        Args:
            message: The user's message.
            response: The agent's response.
            context: Conversation context.
        """
        if not self._memory:
            return

        try:
            await self._memory.store(
                message=message,
                response=response,
                conversation_id=str(context.conversation_id),
                interface=context.interface.value,
            )
            logger.debug("Interaction stored in memory")
        except Exception as e:
            logger.warning(f"Memory store failed: {e}")

    def _convert_sdk_message(self, sdk_message: Any) -> AgentMessage:
        """Convert SDK message to AgentMessage.

        Args:
            sdk_message: Message from Claude Agent SDK.

        Returns:
            Converted AgentMessage.
        """
        # This will be implemented when SDK is available
        # For now, return a placeholder
        if hasattr(sdk_message, "result"):
            return AgentMessage(
                type="text",
                content=sdk_message.result,
                metadata={},
            )
        return AgentMessage(
            type="system",
            content=str(sdk_message),
            metadata={},
        )
