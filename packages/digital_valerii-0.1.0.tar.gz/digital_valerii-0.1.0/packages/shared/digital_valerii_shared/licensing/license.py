"""License dataclass and serialization.

Component 4.10: Licensing & Protection System
"""

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from uuid import UUID, uuid4

from .crypto import decode_signature, encode_signature


@dataclass
class License:
    """Cryptographically signed license."""

    # Identity
    license_id: UUID
    client_id: str  # "ey-ukraine" or "client-acme"
    client_name: str

    # Validity
    issued_at: datetime
    expires_at: datetime
    grace_period_days: int = 14

    # Features
    worker_count: int = 1
    features: list[str] = field(default_factory=list)
    tier: str = "standard"

    # Restrictions
    allowed_domains: list[str] = field(default_factory=list)
    rate_limits: dict = field(default_factory=dict)

    # Cryptographic
    signature: bytes = b""
    monthly_signature: bytes = b""

    @classmethod
    def create(
        cls,
        client_id: str,
        client_name: str,
        expires_at: datetime,
        tier: str = "standard",
        worker_count: int = 1,
        features: list[str] | None = None,
        grace_period_days: int = 14,
    ) -> "License":
        """Create a new license.

        Args:
            client_id: Client identifier.
            client_name: Client display name.
            expires_at: Expiration datetime.
            tier: License tier.
            worker_count: Allowed worker count.
            features: List of features.
            grace_period_days: Grace period after expiry.

        Returns:
            New License instance.
        """
        return cls(
            license_id=uuid4(),
            client_id=client_id,
            client_name=client_name,
            issued_at=datetime.now(UTC),
            expires_at=expires_at,
            grace_period_days=grace_period_days,
            worker_count=worker_count,
            features=features or [],
            tier=tier,
        )

    @property
    def is_valid(self) -> bool:
        """Check if license is currently valid."""
        now = datetime.now(UTC)
        return now < self.expires_at

    @property
    def is_in_grace_period(self) -> bool:
        """Check if license is in grace period."""
        now = datetime.now(UTC)
        from datetime import timedelta

        grace_end = self.expires_at + timedelta(days=self.grace_period_days)
        return self.expires_at <= now < grace_end

    @property
    def is_expired(self) -> bool:
        """Check if license is expired (past grace period)."""
        now = datetime.now(UTC)
        from datetime import timedelta

        grace_end = self.expires_at + timedelta(days=self.grace_period_days)
        return now >= grace_end

    @property
    def days_until_expiry(self) -> int:
        """Get days until license expires."""
        now = datetime.now(UTC)
        delta = self.expires_at - now
        return max(0, delta.days)

    def to_signable_data(self) -> bytes:
        """Get canonical data for signing.

        Returns:
            Bytes to sign (excludes signature fields).
        """
        data = {
            "license_id": str(self.license_id),
            "client_id": self.client_id,
            "client_name": self.client_name,
            "issued_at": self.issued_at.isoformat(),
            "expires_at": self.expires_at.isoformat(),
            "grace_period_days": self.grace_period_days,
            "worker_count": self.worker_count,
            "features": sorted(self.features),
            "tier": self.tier,
            "allowed_domains": sorted(self.allowed_domains),
            "rate_limits": self.rate_limits,
        }
        # Canonical JSON encoding
        return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization.

        Returns:
            Dictionary representation.
        """
        return {
            "license_id": str(self.license_id),
            "client_id": self.client_id,
            "client_name": self.client_name,
            "issued_at": self.issued_at.isoformat(),
            "expires_at": self.expires_at.isoformat(),
            "grace_period_days": self.grace_period_days,
            "worker_count": self.worker_count,
            "features": self.features,
            "tier": self.tier,
            "allowed_domains": self.allowed_domains,
            "rate_limits": self.rate_limits,
            "signature": encode_signature(self.signature) if self.signature else "",
            "monthly_signature": encode_signature(self.monthly_signature)
            if self.monthly_signature
            else "",
        }

    def to_json(self) -> str:
        """Serialize to JSON string.

        Returns:
            JSON string.
        """
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_dict(cls, data: dict) -> "License":
        """Create from dictionary.

        Args:
            data: Dictionary representation.

        Returns:
            License instance.
        """
        signature = b""
        if data.get("signature"):
            signature = decode_signature(data["signature"])

        monthly_signature = b""
        if data.get("monthly_signature"):
            monthly_signature = decode_signature(data["monthly_signature"])

        return cls(
            license_id=UUID(data["license_id"]),
            client_id=data["client_id"],
            client_name=data["client_name"],
            issued_at=datetime.fromisoformat(data["issued_at"]),
            expires_at=datetime.fromisoformat(data["expires_at"]),
            grace_period_days=data.get("grace_period_days", 14),
            worker_count=data.get("worker_count", 1),
            features=data.get("features", []),
            tier=data.get("tier", "standard"),
            allowed_domains=data.get("allowed_domains", []),
            rate_limits=data.get("rate_limits", {}),
            signature=signature,
            monthly_signature=monthly_signature,
        )

    @classmethod
    def from_json(cls, json_str: str) -> "License":
        """Deserialize from JSON string.

        Args:
            json_str: JSON string.

        Returns:
            License instance.
        """
        data = json.loads(json_str)
        return cls.from_dict(data)
