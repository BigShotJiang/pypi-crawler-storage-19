"""License Guard for validating licenses before AI operations.

Component 4.10: Licensing & Protection System
"""

import time
from datetime import datetime

import structlog

from .cache import LicenseCache
from .client import LicenseClient
from .exceptions import (
    LicenseError,
    LicenseServerError,
)
from .models import LicenseStatus

logger = structlog.get_logger(__name__)


class LicenseGuard:
    """Validates license before allowing AI operations.

    This is the main protection mechanism that MUST be called
    before every AI operation to ensure only licensed agents
    can use Digital Valerii.
    """

    CACHE_TTL = 86400  # 24 hours
    LICENSE_SERVER = "https://license.tripletree.ca"
    HEARTBEAT_INTERVAL = 3600  # 1 hour

    def __init__(
        self,
        agent_id: str,
        client_id: str,
        server_url: str | None = None,
        cache_ttl: int = CACHE_TTL,
    ):
        """Initialize License Guard.

        Args:
            agent_id: Unique identifier for this agent instance.
            client_id: Client identifier (matches license).
            server_url: Optional custom license server URL.
            cache_ttl: Cache time-to-live in seconds.
        """
        self._agent_id = agent_id
        self._client_id = client_id
        self._cache = LicenseCache(client_id, ttl_seconds=cache_ttl)
        self._client = LicenseClient(server_url or self.LICENSE_SERVER)
        self._last_heartbeat: float = 0
        self._validated = False

    @property
    def agent_id(self) -> str:
        """Get agent identifier."""
        return self._agent_id

    @property
    def client_id(self) -> str:
        """Get client identifier."""
        return self._client_id

    async def validate(self) -> bool:
        """Check if agent is licensed to operate.

        Returns:
            True if license is valid.
        """
        # Check cache first
        cached = self._cache.get()
        if cached and cached.valid:
            logger.debug(
                "Using cached license",
                client_id=self._client_id,
                remaining_ttl=self._cache.get_remaining_ttl(),
            )
            self._validated = True
            return True

        # Call license server
        try:
            response = await self._client.validate_license(
                agent_id=self._agent_id,
                client_id=self._client_id,
            )

            # Cache the response
            self._cache.set(response)
            self._cache.reset_unreachable()

            if response.valid:
                self._validated = True
                logger.info(
                    "License validated",
                    client_id=self._client_id,
                    tier=response.tier,
                    expires=response.expires.isoformat() if response.expires else None,
                )
                return True
            else:
                logger.warning(
                    "License invalid",
                    client_id=self._client_id,
                    message=response.message,
                )
                return False

        except LicenseServerError:
            # Network failure - use cached if available
            self._cache.increment_unreachable()

            if cached and not self._cache.should_require_fresh():
                logger.warning(
                    "License server unreachable, using cached license",
                    client_id=self._client_id,
                    unreachable_count=self._cache._memory_cache.server_unreachable_count
                    if self._cache._memory_cache
                    else 0,
                )
                self._validated = cached.valid
                return cached.valid

            logger.error(
                "License server unreachable and cache expired",
                client_id=self._client_id,
            )
            return False

    async def before_ai_call(self) -> None:
        """MUST be called before every AI operation.

        Raises:
            LicenseError: If license is invalid or expired.
            LicenseExpiredError: If license has expired.
            LicenseInvalidError: If license is not found.
        """
        if not await self.validate():
            cached = self._cache.get()
            if cached and cached.message:
                message = cached.message
            else:
                message = "License invalid or expired. Contact Triple Tree to renew."

            raise LicenseError(message)

        # Send periodic heartbeat
        await self._maybe_send_heartbeat()

    async def _maybe_send_heartbeat(self) -> None:
        """Send heartbeat if interval has passed."""
        now = time.time()
        if now - self._last_heartbeat >= self.HEARTBEAT_INTERVAL:
            try:
                response = await self._client.send_heartbeat(
                    agent_id=self._agent_id,
                    usage_metrics=None,  # Could add metrics here
                )

                if not response.continue_operation:
                    logger.warning(
                        "License server requested stop",
                        message=response.message,
                    )
                    # Clear cache to force revalidation
                    self._cache.clear()
                    self._validated = False

                self._last_heartbeat = now

            except Exception as e:
                logger.warning("Heartbeat failed", error=str(e))

    def get_status(self) -> LicenseStatus:
        """Get current license status.

        Returns:
            Current license status.
        """
        cached = self._cache.get()
        if not cached:
            return LicenseStatus.INVALID

        if not cached.valid:
            if cached.message and "revoked" in cached.message.lower():
                return LicenseStatus.REVOKED
            elif cached.message and "expired" in cached.message.lower():
                return LicenseStatus.EXPIRED
            return LicenseStatus.INVALID

        if cached.in_grace_period:
            return LicenseStatus.GRACE_PERIOD

        return LicenseStatus.VALID

    def get_features(self) -> list[str]:
        """Get licensed features.

        Returns:
            List of feature names.
        """
        cached = self._cache.get()
        return cached.features if cached else []

    def get_tier(self) -> str | None:
        """Get license tier.

        Returns:
            Tier name or None.
        """
        cached = self._cache.get()
        return cached.tier if cached else None

    def get_worker_count(self) -> int:
        """Get allowed worker count.

        Returns:
            Maximum worker count.
        """
        cached = self._cache.get()
        return cached.worker_count if cached and cached.worker_count else 1

    def get_expiry(self) -> datetime | None:
        """Get license expiry datetime.

        Returns:
            Expiry datetime or None.
        """
        cached = self._cache.get()
        return cached.expires if cached else None

    async def close(self) -> None:
        """Close the license guard and cleanup."""
        await self._client.close()
