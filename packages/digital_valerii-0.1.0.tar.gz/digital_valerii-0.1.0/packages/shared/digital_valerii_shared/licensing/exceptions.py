"""License Guard exceptions.

Component 4.10: Licensing & Protection System
"""


class LicenseError(Exception):
    """Base exception for license operations."""

    def __init__(self, message: str = "License error occurred"):
        self.message = message
        super().__init__(self.message)


class LicenseInvalidError(LicenseError):
    """License is invalid or not found."""

    def __init__(self, message: str = "License invalid or not found"):
        super().__init__(message)


class LicenseExpiredError(LicenseError):
    """License has expired."""

    def __init__(self, message: str = "License has expired"):
        super().__init__(message)


class LicenseRevokedError(LicenseError):
    """License has been revoked."""

    def __init__(self, message: str = "License has been revoked"):
        super().__init__(message)


class LicenseServerError(LicenseError):
    """Error communicating with license server."""

    def __init__(self, message: str = "License server unavailable"):
        super().__init__(message)


class LicenseSignatureError(LicenseError):
    """License signature verification failed."""

    def __init__(self, message: str = "License signature verification failed"):
        super().__init__(message)
