"""Ed25519 cryptographic operations for license signing.

Component 4.10: Licensing & Protection System
"""

import base64

from .exceptions import LicenseSignatureError


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate Ed25519 keypair.

    Returns:
        Tuple of (public_key, private_key) as bytes.

    Raises:
        LicenseSignatureError: If PyNaCl not installed.
    """
    try:
        from nacl.signing import SigningKey

        signing_key = SigningKey.generate()
        return bytes(signing_key.verify_key), bytes(signing_key)
    except ImportError as e:
        raise LicenseSignatureError(
            "PyNaCl not installed. Run: pip install pynacl"
        ) from e


def sign_data(data: bytes, private_key: bytes) -> bytes:
    """Sign data with Ed25519 private key.

    Args:
        data: Data to sign.
        private_key: Ed25519 private key (32 bytes).

    Returns:
        Signature bytes (64 bytes).

    Raises:
        LicenseSignatureError: If signing fails.
    """
    try:
        from nacl.signing import SigningKey

        signing_key = SigningKey(private_key)
        signed = signing_key.sign(data)
        return bytes(signed.signature)
    except ImportError as e:
        raise LicenseSignatureError(
            "PyNaCl not installed. Run: pip install pynacl"
        ) from e
    except Exception as e:
        raise LicenseSignatureError(f"Signing failed: {e}") from e


def verify_signature(data: bytes, signature: bytes, public_key: bytes) -> bool:
    """Verify Ed25519 signature.

    Args:
        data: Original data.
        signature: Signature to verify (64 bytes).
        public_key: Ed25519 public key (32 bytes).

    Returns:
        True if signature is valid.

    Raises:
        LicenseSignatureError: If PyNaCl not installed.
    """
    try:
        from nacl.signing import VerifyKey

        verify_key = VerifyKey(public_key)
        verify_key.verify(data, signature)
        return True
    except ImportError as e:
        raise LicenseSignatureError(
            "PyNaCl not installed. Run: pip install pynacl"
        ) from e
    except Exception:
        return False


def encode_key(key: bytes) -> str:
    """Encode key as base64 string.

    Args:
        key: Key bytes.

    Returns:
        Base64 encoded string.
    """
    return base64.b64encode(key).decode("ascii")


def decode_key(key_str: str) -> bytes:
    """Decode base64 key string.

    Args:
        key_str: Base64 encoded key.

    Returns:
        Key bytes.
    """
    return base64.b64decode(key_str)


def encode_signature(signature: bytes) -> str:
    """Encode signature as base64 string.

    Args:
        signature: Signature bytes.

    Returns:
        Base64 encoded string.
    """
    return base64.b64encode(signature).decode("ascii")


def decode_signature(signature_str: str) -> bytes:
    """Decode base64 signature string.

    Args:
        signature_str: Base64 encoded signature.

    Returns:
        Signature bytes.
    """
    return base64.b64decode(signature_str)
