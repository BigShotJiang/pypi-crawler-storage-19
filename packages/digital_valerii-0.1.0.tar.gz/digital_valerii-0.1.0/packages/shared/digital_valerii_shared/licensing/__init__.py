"""License Guard module for Digital Valerii.

Component 4.10: Licensing & Protection System
Validates licenses before AI operations.
"""

from .cache import LicenseCache
from .client import LicenseClient
from .crypto import (
    decode_key,
    decode_signature,
    encode_key,
    encode_signature,
    generate_keypair,
    sign_data,
    verify_signature,
)
from .exceptions import (
    LicenseError,
    LicenseExpiredError,
    LicenseInvalidError,
    LicenseRevokedError,
    LicenseServerError,
    LicenseSignatureError,
)
from .guard import LicenseGuard
from .license import License
from .models import LicenseResponse, LicenseStatus
from .verification import (
    check_license_features,
    check_license_tier,
    get_current_month,
    sign_license,
    sign_monthly,
    validate_license,
    verify_license_signature,
    verify_monthly_activation,
)

__all__ = [
    # Guard
    "LicenseGuard",
    # Client and Cache
    "LicenseClient",
    "LicenseCache",
    # License
    "License",
    "LicenseResponse",
    "LicenseStatus",
    # Crypto
    "generate_keypair",
    "sign_data",
    "verify_signature",
    "encode_key",
    "decode_key",
    "encode_signature",
    "decode_signature",
    # Verification
    "sign_license",
    "verify_license_signature",
    "sign_monthly",
    "verify_monthly_activation",
    "validate_license",
    "check_license_features",
    "check_license_tier",
    "get_current_month",
    # Exceptions
    "LicenseError",
    "LicenseExpiredError",
    "LicenseInvalidError",
    "LicenseRevokedError",
    "LicenseServerError",
    "LicenseSignatureError",
]
