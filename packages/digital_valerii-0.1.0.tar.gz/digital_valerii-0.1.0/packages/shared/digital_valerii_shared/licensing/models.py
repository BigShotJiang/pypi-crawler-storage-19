"""License Guard data models.

Component 4.10: Licensing & Protection System
"""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class LicenseStatus(str, Enum):
    """License status enumeration."""

    VALID = "valid"
    EXPIRED = "expired"
    REVOKED = "revoked"
    SUSPENDED = "suspended"
    GRACE_PERIOD = "grace_period"
    INVALID = "invalid"


class LicenseResponse(BaseModel):
    """Response from license validation endpoint."""

    valid: bool
    expires: datetime | None = None
    features: list[str] = Field(default_factory=list)
    tier: str | None = None
    worker_count: int | None = None
    in_grace_period: bool = False
    message: str | None = None

    model_config = {"extra": "forbid"}


class HeartbeatResponse(BaseModel):
    """Response from heartbeat endpoint."""

    continue_operation: bool
    message: str | None = None

    model_config = {"extra": "forbid"}


class CachedLicense(BaseModel):
    """Cached license data with expiry."""

    response: LicenseResponse
    cached_at: datetime
    expires_at: datetime
    server_unreachable_count: int = 0

    model_config = {"extra": "forbid"}

    @property
    def is_expired(self) -> bool:
        """Check if cache has expired."""
        return datetime.now(self.cached_at.tzinfo) > self.expires_at


class LicenseValidateRequest(BaseModel):
    """Request to validate a license."""

    agent_id: str
    client_id: str
    signature: str
    timestamp: int = Field(..., description="Unix timestamp for replay protection")

    model_config = {"extra": "forbid"}


class HeartbeatRequest(BaseModel):
    """Request for agent heartbeat."""

    agent_id: str
    usage_metrics: dict | None = None

    model_config = {"extra": "forbid"}
