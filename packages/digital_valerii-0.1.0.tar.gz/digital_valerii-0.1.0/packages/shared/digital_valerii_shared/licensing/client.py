"""License Server client.

Component 4.10: Licensing & Protection System
"""

import hashlib
import hmac
import time

import httpx
import structlog

from .exceptions import LicenseServerError
from .models import (
    HeartbeatRequest,
    HeartbeatResponse,
    LicenseResponse,
    LicenseValidateRequest,
)

logger = structlog.get_logger(__name__)


class LicenseClient:
    """Client for communicating with License Server."""

    DEFAULT_SERVER = "https://license.tripletree.ca"
    TIMEOUT = 10.0
    MAX_RETRIES = 3
    RETRY_DELAY = 1.0

    def __init__(
        self,
        server_url: str | None = None,
        timeout: float = TIMEOUT,
        shared_secret: str | None = None,
    ):
        """Initialize license client.

        Args:
            server_url: License server URL.
            timeout: Request timeout in seconds.
            shared_secret: Shared secret for HMAC request signing (required in production).
        """
        self._server_url = (server_url or self.DEFAULT_SERVER).rstrip("/")
        self._timeout = timeout
        self._shared_secret = shared_secret
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                follow_redirects=True,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _generate_signature(self, agent_id: str, client_id: str, timestamp: int) -> str:
        """Generate request signature using HMAC with shared secret.

        Args:
            agent_id: Agent identifier.
            client_id: Client identifier.
            timestamp: Unix timestamp.

        Returns:
            HMAC-SHA256 signature hex string.
        """
        message = f"{agent_id}:{client_id}:{timestamp}"

        if self._shared_secret:
            # Use HMAC with shared secret
            return hmac.new(
                self._shared_secret.encode(),
                message.encode(),
                hashlib.sha256,
            ).hexdigest()
        else:
            # Fallback for development/testing without shared secret
            logger.warning("No shared secret configured - using fallback signature")
            return hashlib.sha256(message.encode()).hexdigest()

    async def validate_license(
        self,
        agent_id: str,
        client_id: str,
    ) -> LicenseResponse:
        """Validate a license with the server.

        Args:
            agent_id: Agent identifier.
            client_id: Client identifier.

        Returns:
            LicenseResponse with validation result.

        Raises:
            LicenseServerError: If server is unreachable.
        """
        timestamp = int(time.time())
        signature = self._generate_signature(agent_id, client_id, timestamp)

        request = LicenseValidateRequest(
            agent_id=agent_id,
            client_id=client_id,
            signature=signature,
            timestamp=timestamp,
        )

        for attempt in range(self.MAX_RETRIES):
            try:
                client = await self._get_client()
                response = await client.post(
                    f"{self._server_url}/api/v1/license/validate",
                    json=request.model_dump(),
                )

                if response.status_code == 200:
                    data = response.json()
                    return LicenseResponse.model_validate(data)
                else:
                    logger.warning(
                        "License validation failed",
                        status_code=response.status_code,
                        attempt=attempt + 1,
                    )

            except httpx.TimeoutException:
                logger.warning("License server timeout", attempt=attempt + 1)
            except httpx.RequestError as e:
                logger.warning(
                    "License server request error", error=str(e), attempt=attempt + 1
                )

            if attempt < self.MAX_RETRIES - 1:
                await self._sleep(self.RETRY_DELAY * (attempt + 1))

        raise LicenseServerError("License server unreachable after retries")

    async def send_heartbeat(
        self,
        agent_id: str,
        usage_metrics: dict | None = None,
    ) -> HeartbeatResponse:
        """Send heartbeat to license server.

        Args:
            agent_id: Agent identifier.
            usage_metrics: Optional usage metrics.

        Returns:
            HeartbeatResponse with continue status.

        Raises:
            LicenseServerError: If server is unreachable.
        """
        request = HeartbeatRequest(
            agent_id=agent_id,
            usage_metrics=usage_metrics,
        )

        try:
            client = await self._get_client()
            response = await client.post(
                f"{self._server_url}/api/v1/license/heartbeat",
                json=request.model_dump(),
            )

            if response.status_code == 200:
                data = response.json()
                return HeartbeatResponse.model_validate(data)
            else:
                return HeartbeatResponse(
                    continue_operation=True,
                    message="Heartbeat status unknown",
                )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            logger.warning("Heartbeat failed", error=str(e))
            return HeartbeatResponse(
                continue_operation=True,
                message="Server unreachable, using cached status",
            )

    async def _sleep(self, seconds: float) -> None:
        """Async sleep wrapper for testing.

        Args:
            seconds: Time to sleep.
        """
        import asyncio

        await asyncio.sleep(seconds)
