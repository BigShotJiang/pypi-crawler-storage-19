"""License cache for offline operation.

Component 4.10: Licensing & Protection System
"""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import structlog

from .models import CachedLicense, LicenseResponse

logger = structlog.get_logger(__name__)


class LicenseCache:
    """Local cache for license validation results."""

    DEFAULT_TTL = 86400  # 24 hours
    MAX_UNREACHABLE_COUNT = 3  # After this, require fresh validation
    CACHE_DIR = ".dv-cache"
    CACHE_FILE = "license.json"

    def __init__(
        self,
        client_id: str,
        ttl_seconds: int = DEFAULT_TTL,
        cache_dir: str | Path | None = None,
    ):
        """Initialize license cache.

        Args:
            client_id: Client identifier for this license.
            ttl_seconds: Cache TTL in seconds.
            cache_dir: Optional custom cache directory.
        """
        self._client_id = client_id
        self._ttl = ttl_seconds
        self._cache_dir = Path(cache_dir) if cache_dir else Path.home() / self.CACHE_DIR
        self._memory_cache: CachedLicense | None = None
        self._lock_time: float = 0

    @property
    def cache_file(self) -> Path:
        """Get path to cache file."""
        return self._cache_dir / f"{self._client_id}_{self.CACHE_FILE}"

    def get(self) -> LicenseResponse | None:
        """Get cached license if valid.

        Returns:
            LicenseResponse if cache is valid, None otherwise.
        """
        # Check memory cache first
        if self._memory_cache and not self._memory_cache.is_expired:
            return self._memory_cache.response

        # Try disk cache
        cached = self._load_from_disk()
        if cached and not cached.is_expired:
            self._memory_cache = cached
            return cached.response

        return None

    def set(self, response: LicenseResponse) -> None:
        """Store license in cache.

        Args:
            response: License response to cache.
        """
        now = datetime.now(UTC)
        cached = CachedLicense(
            response=response,
            cached_at=now,
            expires_at=now + timedelta(seconds=self._ttl),
        )
        self._memory_cache = cached
        self._save_to_disk(cached)

    def increment_unreachable(self) -> int:
        """Increment server unreachable counter.

        Returns:
            Current unreachable count.
        """
        if self._memory_cache:
            self._memory_cache.server_unreachable_count += 1
            self._save_to_disk(self._memory_cache)
            return self._memory_cache.server_unreachable_count
        return 0

    def reset_unreachable(self) -> None:
        """Reset server unreachable counter."""
        if self._memory_cache:
            self._memory_cache.server_unreachable_count = 0
            self._save_to_disk(self._memory_cache)

    def should_require_fresh(self) -> bool:
        """Check if fresh validation is required.

        Returns:
            True if too many unreachable attempts.
        """
        if self._memory_cache:
            return (
                self._memory_cache.server_unreachable_count
                >= self.MAX_UNREACHABLE_COUNT
            )
        return True

    def clear(self) -> None:
        """Clear the cache."""
        self._memory_cache = None
        try:
            if self.cache_file.exists():
                self.cache_file.unlink()
        except OSError as e:
            logger.warning("Failed to clear cache file", error=str(e))

    def _load_from_disk(self) -> CachedLicense | None:
        """Load cache from disk."""
        try:
            if not self.cache_file.exists():
                return None

            data = json.loads(self.cache_file.read_text())
            return CachedLicense.model_validate(data)
        except Exception as e:
            logger.warning("Failed to load license cache", error=str(e))
            return None

    def _save_to_disk(self, cached: CachedLicense) -> None:
        """Save cache to disk."""
        try:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            self.cache_file.write_text(cached.model_dump_json())
        except Exception as e:
            logger.warning("Failed to save license cache", error=str(e))

    def get_remaining_ttl(self) -> float:
        """Get remaining time before cache expires.

        Returns:
            Seconds until cache expires, 0 if expired or no cache.
        """
        if not self._memory_cache:
            return 0

        now = datetime.now(UTC)
        remaining = (self._memory_cache.expires_at - now).total_seconds()
        return max(0, remaining)
