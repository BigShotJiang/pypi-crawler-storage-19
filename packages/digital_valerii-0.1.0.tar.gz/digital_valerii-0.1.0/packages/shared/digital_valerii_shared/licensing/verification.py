"""License verification functions.

Component 4.10: Licensing & Protection System
"""

from datetime import UTC, datetime

import structlog

from .crypto import sign_data, verify_signature
from .exceptions import LicenseExpiredError, LicenseInvalidError, LicenseSignatureError
from .license import License

logger = structlog.get_logger(__name__)


def sign_license(license: License, private_key: bytes) -> License:
    """Sign license with Ed25519 private key.

    Args:
        license: License to sign.
        private_key: Ed25519 private key (32 bytes).

    Returns:
        License with signature set.

    Raises:
        LicenseSignatureError: If signing fails.
    """
    data = license.to_signable_data()
    signature = sign_data(data, private_key)

    license.signature = signature
    logger.info(
        "License signed",
        license_id=str(license.license_id),
        client_id=license.client_id,
    )
    return license


def verify_license_signature(license: License, public_key: bytes) -> bool:
    """Verify license signature.

    Args:
        license: License to verify.
        public_key: Ed25519 public key (32 bytes).

    Returns:
        True if signature is valid.
    """
    if not license.signature:
        logger.warning(
            "License has no signature",
            license_id=str(license.license_id),
        )
        return False

    data = license.to_signable_data()
    is_valid = verify_signature(data, license.signature, public_key)

    if not is_valid:
        logger.warning(
            "License signature invalid",
            license_id=str(license.license_id),
            client_id=license.client_id,
        )

    return is_valid


def sign_monthly(month: str, private_key: bytes) -> bytes:
    """Sign monthly activation.

    Args:
        month: Month in YYYY-MM format.
        private_key: Ed25519 private key (32 bytes).

    Returns:
        Signature bytes.

    Raises:
        LicenseSignatureError: If signing fails.
    """
    data = f"monthly-activation:{month}".encode()
    signature = sign_data(data, private_key)

    logger.info("Monthly activation signed", month=month)
    return signature


def verify_monthly_activation(month: str, signature: bytes, public_key: bytes) -> bool:
    """Verify monthly activation signature.

    Args:
        month: Month in YYYY-MM format.
        signature: Signature to verify.
        public_key: Ed25519 public key (32 bytes).

    Returns:
        True if signature is valid.
    """
    data = f"monthly-activation:{month}".encode()
    is_valid = verify_signature(data, signature, public_key)

    if not is_valid:
        logger.warning("Monthly activation signature invalid", month=month)

    return is_valid


def validate_license(
    license: License,
    public_key: bytes,
    monthly_public_key: bytes | None = None,
    check_monthly: bool = True,
) -> None:
    """Validate a license completely.

    Checks:
    - Signature is valid
    - License is not expired
    - Monthly activation is valid (if required)

    Args:
        license: License to validate.
        public_key: Ed25519 public key for license verification.
        monthly_public_key: Ed25519 public key for monthly verification.
        check_monthly: Whether to check monthly activation.

    Raises:
        LicenseSignatureError: If signature is invalid.
        LicenseExpiredError: If license is expired.
        LicenseInvalidError: If license is invalid.
    """
    # Check signature
    if not verify_license_signature(license, public_key):
        raise LicenseSignatureError("License signature verification failed")

    # Check expiration
    if license.is_expired:
        raise LicenseExpiredError(
            f"License expired on {license.expires_at.isoformat()}"
        )

    # Check monthly activation
    if check_monthly and monthly_public_key:
        current_month = datetime.now(UTC).strftime("%Y-%m")
        if not license.monthly_signature:
            raise LicenseInvalidError("License missing monthly activation")

        if not verify_monthly_activation(
            current_month, license.monthly_signature, monthly_public_key
        ):
            raise LicenseSignatureError("Monthly activation verification failed")

    logger.info(
        "License validated",
        license_id=str(license.license_id),
        client_id=license.client_id,
        expires_at=license.expires_at.isoformat(),
    )


def get_current_month() -> str:
    """Get current month in YYYY-MM format.

    Returns:
        Current month string.
    """
    return datetime.now(UTC).strftime("%Y-%m")


def check_license_features(license: License, required_features: list[str]) -> bool:
    """Check if license has required features.

    Args:
        license: License to check.
        required_features: List of required feature names.

    Returns:
        True if all required features are present.
    """
    license_features = set(license.features)
    required = set(required_features)
    return required.issubset(license_features)


def check_license_tier(license: License, minimum_tier: str) -> bool:
    """Check if license meets minimum tier requirement.

    Args:
        license: License to check.
        minimum_tier: Minimum required tier.

    Returns:
        True if license tier meets requirement.
    """
    tier_order = ["starter", "standard", "professional", "enterprise"]

    try:
        license_tier_idx = tier_order.index(license.tier.lower())
        required_tier_idx = tier_order.index(minimum_tier.lower())
        return license_tier_idx >= required_tier_idx
    except ValueError:
        # Unknown tier - be permissive
        return True
