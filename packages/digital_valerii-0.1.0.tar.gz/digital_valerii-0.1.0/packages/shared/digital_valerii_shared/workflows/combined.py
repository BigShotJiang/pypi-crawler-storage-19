"""Combined workflow patterns.

Component 4.11: Orchestration Patterns
Enable nested workflow patterns (parallel inside sequential, loop inside sequential).
"""

from collections.abc import Callable

from .base import Aggregator, WorkflowContext, WorkflowStep
from .loop import LoopWorkflow
from .parallel import ParallelWorkflow


class ParallelWorkflowStep(WorkflowStep):
    """Wrapper to use ParallelWorkflow as a step in SequentialWorkflow.

    Allows running parallel tasks within a sequential pipeline.

    Example:
        pipeline = SequentialWorkflow([
            LoadDataStep(),
            ParallelWorkflowStep([
                ProcessStep("a"),
                ProcessStep("b"),
                ProcessStep("c"),
            ]),
            SaveResultsStep(),
        ])
    """

    def __init__(
        self,
        steps: list[WorkflowStep],
        aggregator: Aggregator | None = None,
        fail_fast: bool = False,
        name: str = "ParallelWorkflowStep",
    ):
        """Initialize parallel workflow step.

        Args:
            steps: Steps to execute in parallel.
            aggregator: Strategy for combining results.
            fail_fast: If True, raise immediately on first error.
            name: Step name for logging.
        """
        self._workflow = ParallelWorkflow(
            steps, aggregator=aggregator, fail_fast=fail_fast, name=name
        )
        self._name = name

    @property
    def name(self) -> str:
        """Return step name."""
        return self._name

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        """Execute parallel workflow and return result."""
        return await self._workflow.run(context)


class LoopWorkflowStep(WorkflowStep):
    """Wrapper to use LoopWorkflow as a step in SequentialWorkflow.

    Allows iterative refinement within a sequential pipeline.

    Example:
        pipeline = SequentialWorkflow([
            GenerateInitialDraftStep(),
            LoopWorkflowStep(
                steps=[RefineStep(), EvaluateStep()],
                condition=lambda ctx: ctx.data.get("quality_score", 0) >= 0.85,
                max_iterations=5,
            ),
            FinalizeStep(),
        ])
    """

    def __init__(
        self,
        steps: list[WorkflowStep],
        condition: Callable[[WorkflowContext], bool],
        max_iterations: int = 10,
        name: str = "LoopWorkflowStep",
    ):
        """Initialize loop workflow step.

        Args:
            steps: Steps to execute each iteration.
            condition: Function returning True when loop should stop.
            max_iterations: Safety limit for iterations.
            name: Step name for logging.
        """
        self._workflow = LoopWorkflow(
            steps, condition=condition, max_iterations=max_iterations, name=name
        )
        self._name = name

    @property
    def name(self) -> str:
        """Return step name."""
        return self._name

    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        """Execute loop workflow and return result."""
        return await self._workflow.run(context)
