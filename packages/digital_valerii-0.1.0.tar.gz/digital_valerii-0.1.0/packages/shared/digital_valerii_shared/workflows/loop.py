"""Loop workflow pattern.

Component 4.11: Orchestration Patterns
Execute steps repeatedly until condition is met.
"""

from collections.abc import Callable

import structlog

from .base import WorkflowContext, WorkflowError, WorkflowStep

logger = structlog.get_logger(__name__)


class LoopWorkflow:
    """Execute steps repeatedly until condition is met.

    Useful for iterative refinement, polling, or retry patterns.

    Attributes:
        steps: Steps to execute each iteration.
        condition: Function returning True when loop should STOP.
        max_iterations: Safety limit to prevent infinite loops.
        name: Workflow name for logging.
    """

    def __init__(
        self,
        steps: list[WorkflowStep],
        condition: Callable[[WorkflowContext], bool],
        max_iterations: int = 10,
        name: str = "LoopWorkflow",
    ):
        """Initialize loop workflow.

        Args:
            steps: Steps to execute each iteration.
            condition: Function returning True when loop should STOP.
            max_iterations: Safety limit to prevent infinite loops.
            name: Workflow name for logging.
        """
        self.steps = steps
        self.condition = condition
        self.max_iterations = max_iterations
        self.name = name

    async def run(
        self, initial_context: WorkflowContext | None = None
    ) -> WorkflowContext:
        """Run steps in loop until condition is met.

        Args:
            initial_context: Starting context.

        Returns:
            Final context with loop_completed and iterations metadata.

        Raises:
            WorkflowError: If any step fails during iteration.
        """
        context = initial_context or WorkflowContext()
        iteration = 0

        await logger.ainfo(
            "Loop workflow started",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
            max_iterations=self.max_iterations,
        )

        while iteration < self.max_iterations:
            iteration += 1

            await logger.ainfo(
                "Loop iteration starting",
                workflow_id=str(context.workflow_id),
                iteration=iteration,
                max_iterations=self.max_iterations,
            )

            # Run all steps
            for step in self.steps:
                try:
                    context = await step.execute(context)
                    context.record_step(
                        f"{step.name}[iter={iteration}]", status="completed"
                    )
                except Exception as e:
                    context.record_step(
                        f"{step.name}[iter={iteration}]",
                        status="failed",
                        error=str(e),
                    )
                    raise WorkflowError(
                        f"Loop iteration {iteration}, step '{step.name}' failed: {e}"
                    ) from e

            # Check termination condition
            if self.condition(context):
                context.data["loop_completed"] = True
                context.data["iterations"] = iteration

                await logger.ainfo(
                    "Loop workflow completed - condition met",
                    workflow_id=str(context.workflow_id),
                    iterations=iteration,
                )
                break
        else:
            # Max iterations reached without condition
            context.data["loop_completed"] = False
            context.data["iterations"] = iteration

            await logger.awarning(
                "Loop workflow completed - max iterations reached",
                workflow_id=str(context.workflow_id),
                iterations=iteration,
                max_iterations=self.max_iterations,
            )

        return context
