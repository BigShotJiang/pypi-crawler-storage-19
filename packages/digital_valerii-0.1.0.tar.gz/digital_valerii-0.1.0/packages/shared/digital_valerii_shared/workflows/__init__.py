"""Workflow orchestration patterns.

Component 4.11: Orchestration Patterns
Based on Google's Startup Technical Guide: AI Agents (January 2025)

Patterns:
- Sequential: Step-by-step execution
- Parallel: Concurrent tasks with aggregation
- Loop: Iterative refinement until condition
"""

from .base import (
    Aggregator,
    MergeAggregator,
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)
from .combined import LoopWorkflowStep, ParallelWorkflowStep
from .loop import LoopWorkflow
from .parallel import ParallelWorkflow
from .registry import (
    WORKFLOW_REGISTRY,
    WorkflowStepRegistry,
    get_workflow,
    list_workflows,
    register_workflow,
)
from .sequential import SequentialWorkflow

__all__ = [
    "Aggregator",
    "LoopWorkflow",
    "LoopWorkflowStep",
    "MergeAggregator",
    "ParallelWorkflow",
    "ParallelWorkflowStep",
    "SequentialWorkflow",
    "WorkflowContext",
    "WorkflowError",
    "WorkflowStep",
    # Registry
    "WORKFLOW_REGISTRY",
    "WorkflowStepRegistry",
    "get_workflow",
    "list_workflows",
    "register_workflow",
]
