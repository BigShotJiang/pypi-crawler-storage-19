"""Parallel workflow pattern.

Component 4.11: Orchestration Patterns
Execute steps concurrently and aggregate results.
"""

import asyncio

import structlog

from .base import (
    Aggregator,
    MergeAggregator,
    WorkflowContext,
    WorkflowError,
    WorkflowStep,
)

logger = structlog.get_logger(__name__)


class ParallelWorkflow:
    """Execute steps concurrently and aggregate results.

    Attributes:
        steps: List of steps to execute in parallel.
        aggregator: Strategy for combining results.
        fail_fast: If True, raise immediately on first error.
                   If False, collect errors and continue with partial results.
        name: Workflow name for logging.
    """

    def __init__(
        self,
        steps: list[WorkflowStep],
        aggregator: Aggregator | None = None,
        fail_fast: bool = False,
        name: str = "ParallelWorkflow",
    ):
        """Initialize parallel workflow.

        Args:
            steps: List of steps to execute in parallel.
            aggregator: Strategy for combining results. Defaults to MergeAggregator.
            fail_fast: If True, raise immediately on first error.
            name: Workflow name for logging.
        """
        self.steps = steps
        self.aggregator = aggregator or MergeAggregator()
        self.fail_fast = fail_fast
        self.name = name

    async def run(
        self, initial_context: WorkflowContext | None = None
    ) -> WorkflowContext:
        """Run all steps in parallel with proper error handling.

        Args:
            initial_context: Starting context. Each step gets a copy.

        Returns:
            Context with aggregated results from all successful steps.

        Raises:
            WorkflowError: If fail_fast=True and any step fails.
        """
        context = initial_context or WorkflowContext()

        await logger.ainfo(
            "Parallel workflow started",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
            step_count=len(self.steps),
            fail_fast=self.fail_fast,
        )

        if not self.steps:
            return context

        if self.fail_fast:
            # True fail-fast: cancel remaining tasks on first error
            return await self._run_fail_fast(context)
        else:
            # Collect all results/errors
            return await self._run_collect_errors(context)

    async def _run_fail_fast(self, context: WorkflowContext) -> WorkflowContext:
        """Run with true fail-fast: cancel remaining tasks on first error.

        Uses asyncio.TaskGroup which automatically cancels all pending
        tasks when any task raises an exception.
        """
        # Store results as they complete
        step_results: dict[int, WorkflowContext] = {}

        async def run_step(idx: int, step: WorkflowStep) -> None:
            """Run a step and store its result."""
            result = await step.execute(
                WorkflowContext(
                    workflow_id=context.workflow_id,
                    user_id=context.user_id,
                    project_id=context.project_id,
                    data=context.data.copy(),
                    history=[],
                )
            )
            step_results[idx] = result

        try:
            async with asyncio.TaskGroup() as tg:
                for i, step in enumerate(self.steps):
                    tg.create_task(run_step(i, step))

        except* Exception as eg:
            # TaskGroup cancels remaining tasks on first exception
            first_error = eg.exceptions[0]
            error_type = type(first_error).__name__

            # Use first step name as approximation
            step_name = self.steps[0].name if self.steps else "unknown"
            context.record_step(step_name, status="failed", error=str(first_error))

            await logger.aerror(
                "Parallel workflow fail-fast triggered",
                workflow_id=str(context.workflow_id),
                error=str(first_error),
                error_type=error_type,
            )

            raise WorkflowError(
                f"Parallel workflow failed (fail_fast): {error_type}: {first_error}"
            ) from first_error

        # All succeeded - collect results in order
        results: list[WorkflowContext] = []
        for i in range(len(self.steps)):
            result = step_results[i]
            results.append(result)
            context.record_step(self.steps[i].name, status="completed")

        context = await self.aggregator.aggregate(results, context)

        await logger.ainfo(
            "Parallel workflow completed (fail_fast)",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
            successful=len(results),
        )

        return context

    async def _run_collect_errors(self, context: WorkflowContext) -> WorkflowContext:
        """Run collecting all errors (partial failure mode)."""
        # Create task for each step with copied context
        tasks = [
            asyncio.create_task(
                step.execute(
                    WorkflowContext(
                        workflow_id=context.workflow_id,
                        user_id=context.user_id,
                        project_id=context.project_id,
                        data=context.data.copy(),
                        history=[],
                    )
                )
            )
            for step in self.steps
        ]

        # Wait for all to complete
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Separate successes and failures
        errors: list[dict[str, str]] = []
        successful_results: list[WorkflowContext] = []

        for i, result in enumerate(results):
            step_name = self.steps[i].name

            if isinstance(result, Exception):
                errors.append(
                    {
                        "step": step_name,
                        "error": str(result),
                        "type": type(result).__name__,
                    }
                )
                context.record_step(step_name, status="failed", error=str(result))
            elif isinstance(result, WorkflowContext):
                successful_results.append(result)
                context.record_step(step_name, status="completed")

        # Handle errors
        if errors:
            context.data["errors"] = errors
            context.data["partial_failure"] = True

            await logger.awarning(
                "Parallel workflow partial failure",
                workflow_id=str(context.workflow_id),
                failed_steps=len(errors),
                successful_steps=len(successful_results),
            )

        # Aggregate successful results
        context = await self.aggregator.aggregate(successful_results, context)

        await logger.ainfo(
            "Parallel workflow completed",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
            successful=len(successful_results),
            failed=len(errors),
        )

        return context
