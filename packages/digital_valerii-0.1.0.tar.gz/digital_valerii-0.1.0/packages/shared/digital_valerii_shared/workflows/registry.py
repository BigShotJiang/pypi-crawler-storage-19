"""Workflow registry for dynamic loading.

Component 4.11: Orchestration Patterns
Allows workflows to be registered and loaded by name at runtime.
"""

from typing import Any

import structlog

from .base import WorkflowStep

logger = structlog.get_logger(__name__)

# Registry mapping workflow type names to factory functions
WORKFLOW_REGISTRY: dict[str, type] = {}


def register_workflow(name: str) -> Any:
    """Decorator to register a workflow class.

    Example:
        @register_workflow("email_pipeline")
        class EmailPipelineWorkflow(SequentialWorkflow):
            ...

    Args:
        name: Unique name for this workflow type.

    Returns:
        Decorator that registers the class.
    """

    def decorator(cls: type) -> type:
        WORKFLOW_REGISTRY[name] = cls
        logger.debug("Registered workflow", workflow_name=name, cls=cls.__name__)
        return cls

    return decorator


def get_workflow(name: str) -> Any:
    """Get a workflow class by name.

    Args:
        name: Registered workflow name.

    Returns:
        Workflow class.

    Raises:
        ValueError: If workflow is not registered.
    """
    if name not in WORKFLOW_REGISTRY:
        registered = list(WORKFLOW_REGISTRY.keys())
        raise ValueError(
            f"Unknown workflow type: {name!r}. " f"Registered workflows: {registered}"
        )
    return WORKFLOW_REGISTRY[name]


def list_workflows() -> list[str]:
    """List all registered workflow names.

    Returns:
        List of registered workflow type names.
    """
    return list(WORKFLOW_REGISTRY.keys())


class WorkflowStepRegistry:
    """Registry for reusable workflow steps.

    Allows step classes to be registered and instantiated by name,
    enabling configuration-driven workflow definitions.
    """

    _steps: dict[str, type[WorkflowStep]] = {}

    @classmethod
    def register(cls, name: str) -> Any:
        """Decorator to register a step class.

        Example:
            @WorkflowStepRegistry.register("analyze_email")
            class AnalyzeEmailStep(WorkflowStep):
                ...
        """

        def decorator(step_cls: type[WorkflowStep]) -> type[WorkflowStep]:
            cls._steps[name] = step_cls
            return step_cls

        return decorator

    @classmethod
    def get(cls, name: str) -> type[WorkflowStep]:
        """Get a step class by name."""
        if name not in cls._steps:
            raise ValueError(f"Unknown step type: {name!r}")
        return cls._steps[name]

    @classmethod
    def list(cls) -> list[str]:
        """List all registered step names."""
        return list(cls._steps.keys())
