"""Sequential workflow pattern.

Component 4.11: Orchestration Patterns
Execute steps in sequence, passing context forward.
"""

import structlog

from .base import WorkflowContext, WorkflowError, WorkflowStep

logger = structlog.get_logger(__name__)


class SequentialWorkflow:
    """Execute steps in sequence, passing context forward.

    Each step receives the context from the previous step.
    If any step fails, the workflow stops and raises WorkflowError.

    Attributes:
        steps: List of steps to execute in order.
        name: Workflow name for logging.
    """

    def __init__(self, steps: list[WorkflowStep], name: str = "SequentialWorkflow"):
        """Initialize sequential workflow.

        Args:
            steps: List of steps to execute in order.
            name: Workflow name for logging.
        """
        self.steps = steps
        self.name = name

    async def run(
        self, initial_context: WorkflowContext | None = None
    ) -> WorkflowContext:
        """Run all steps in sequence.

        Args:
            initial_context: Starting context. Created if not provided.

        Returns:
            Final context after all steps complete.

        Raises:
            WorkflowError: If any step fails.
        """
        context = initial_context or WorkflowContext()

        await logger.ainfo(
            "Sequential workflow started",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
            step_count=len(self.steps),
        )

        for i, step in enumerate(self.steps):
            step_name = step.name

            try:
                await logger.ainfo(
                    "Executing step",
                    workflow_id=str(context.workflow_id),
                    step=step_name,
                    step_index=i + 1,
                    total_steps=len(self.steps),
                )

                context = await step.execute(context)
                context.record_step(step_name, status="completed")

            except Exception as e:
                await logger.aerror(
                    "Step failed",
                    workflow_id=str(context.workflow_id),
                    step=step_name,
                    error=str(e),
                )
                context.record_step(step_name, status="failed", error=str(e))
                raise WorkflowError(f"Step '{step_name}' failed: {e}") from e

        await logger.ainfo(
            "Sequential workflow completed",
            workflow_id=str(context.workflow_id),
            workflow_name=self.name,
        )

        return context
