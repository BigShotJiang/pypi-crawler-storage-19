"""Base classes for workflow orchestration.

Component 4.11: Orchestration Patterns
Based on Google's Startup Technical Guide: AI Agents (January 2025)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4


class WorkflowError(Exception):
    """Raised when workflow execution fails."""

    pass


@dataclass
class WorkflowContext:
    """Shared context passed through workflow steps.

    Attributes:
        workflow_id: Unique workflow execution ID.
        user_id: Owner of this workflow execution (multi-tenancy).
        project_id: Optional project scope.
        data: Mutable data dictionary passed between steps.
        history: Execution history for observability.
    """

    workflow_id: UUID = field(default_factory=uuid4)
    user_id: UUID | None = None  # Multi-tenancy support
    project_id: UUID | None = None  # Optional project scope
    data: dict[str, Any] = field(default_factory=dict)
    history: list[dict[str, Any]] = field(default_factory=list)

    def record_step(
        self, step_name: str, status: str = "completed", error: str | None = None
    ) -> None:
        """Record step execution in history.

        Args:
            step_name: Name of the step.
            status: Status of execution (completed, failed).
            error: Error message if step failed.
        """
        self.history.append(
            {
                "step": step_name,
                "status": status,
                "completed_at": datetime.now(UTC).isoformat(),
                "error": error,
            }
        )


class WorkflowStep(ABC):
    """Base class for workflow steps."""

    @property
    def name(self) -> str:
        """Step name for logging/tracking."""
        return self.__class__.__name__

    @abstractmethod
    async def execute(self, context: WorkflowContext) -> WorkflowContext:
        """Execute step and return updated context.

        Args:
            context: Workflow context with data and history.

        Returns:
            Updated context with step results.

        Raises:
            WorkflowError: If step execution fails.
        """
        pass


class Aggregator(ABC):
    """Base class for result aggregators in parallel workflows."""

    @abstractmethod
    async def aggregate(
        self, results: list[WorkflowContext], context: WorkflowContext
    ) -> WorkflowContext:
        """Aggregate results from parallel steps.

        Args:
            results: List of contexts from successful parallel steps.
            context: Original context to merge results into.

        Returns:
            Context with aggregated results.
        """
        pass


class MergeAggregator(Aggregator):
    """Default aggregator that merges all data dictionaries."""

    async def aggregate(
        self, results: list[WorkflowContext], context: WorkflowContext
    ) -> WorkflowContext:
        """Merge all data from parallel results.

        Args:
            results: List of contexts from successful parallel steps.
            context: Original context to merge results into.

        Returns:
            Context with merged data from all results.
        """
        for result in results:
            context.data.update(result.data)
        return context
