"""Digital Valerii Pydantic Schemas."""

from packages.shared.digital_valerii_shared.schemas.conversation import (
    ConversationCreate,
    ConversationRead,
    ConversationUpdate,
)
from packages.shared.digital_valerii_shared.schemas.event import (
    EventCreate,
    EventParticipantCreate,
    EventParticipantRead,
    EventRead,
    EventUpdate,
)
from packages.shared.digital_valerii_shared.schemas.lesson import (
    LessonCreate,
    LessonRead,
    LessonUpdate,
)
from packages.shared.digital_valerii_shared.schemas.message import (
    MessageCreate,
    MessageRead,
)
from packages.shared.digital_valerii_shared.schemas.person import (
    PersonCreate,
    PersonRead,
    PersonUpdate,
)
from packages.shared.digital_valerii_shared.schemas.project import (
    ProjectCreate,
    ProjectRead,
    ProjectUpdate,
)

__all__ = [
    # Person
    "PersonCreate",
    "PersonRead",
    "PersonUpdate",
    # Project
    "ProjectCreate",
    "ProjectRead",
    "ProjectUpdate",
    # Event
    "EventCreate",
    "EventRead",
    "EventUpdate",
    "EventParticipantCreate",
    "EventParticipantRead",
    # Lesson
    "LessonCreate",
    "LessonRead",
    "LessonUpdate",
    # Conversation
    "ConversationCreate",
    "ConversationRead",
    "ConversationUpdate",
    # Message
    "MessageCreate",
    "MessageRead",
]
