"""Project schemas for API validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class ProjectCreate(StrictBaseModel):
    """Schema for creating a project."""

    name: str
    description: str | None = None
    status: str = "active"
    priority: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    tags: list[str] | None = None
    metadata_: dict[str, Any] | None = None


class ProjectUpdate(StrictBaseModel):
    """Schema for updating a project."""

    name: str | None = None
    description: str | None = None
    status: str | None = None
    priority: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    tags: list[str] | None = None
    metadata_: dict[str, Any] | None = None


class ProjectRead(StrictBaseModel):
    """Schema for reading a project."""

    id: UUID
    name: str
    description: str | None
    status: str
    priority: str | None
    start_date: datetime | None
    end_date: datetime | None
    tags: list[str] | None
    metadata_: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
