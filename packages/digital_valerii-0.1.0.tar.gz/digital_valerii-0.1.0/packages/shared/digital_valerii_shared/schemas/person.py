"""Person schemas for API validation."""

from datetime import datetime
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class PersonCreate(StrictBaseModel):
    """Schema for creating a person."""

    name: str
    email: str | None = None
    phone: str | None = None
    company: str | None = None
    role: str | None = None
    notes: str | None = None
    relationship_type: str | None = None


class PersonUpdate(StrictBaseModel):
    """Schema for updating a person."""

    name: str | None = None
    email: str | None = None
    phone: str | None = None
    company: str | None = None
    role: str | None = None
    notes: str | None = None
    relationship_type: str | None = None
    last_interaction: datetime | None = None


class PersonRead(StrictBaseModel):
    """Schema for reading a person."""

    id: UUID
    name: str
    email: str | None
    phone: str | None
    company: str | None
    role: str | None
    notes: str | None
    relationship_type: str | None
    last_interaction: datetime | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
