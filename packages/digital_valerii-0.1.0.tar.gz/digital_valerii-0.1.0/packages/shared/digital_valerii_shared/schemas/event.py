"""Event schemas for API validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class EventParticipantCreate(StrictBaseModel):
    """Schema for creating an event participant."""

    person_id: UUID
    role: str | None = None


class EventParticipantRead(StrictBaseModel):
    """Schema for reading an event participant."""

    id: UUID
    event_id: UUID
    person_id: UUID
    role: str | None


class EventCreate(StrictBaseModel):
    """Schema for creating an event."""

    type: str
    title: str | None = None
    summary: str | None = None
    content: str | None = None
    importance: float = 0.5
    emotional_valence: float | None = None
    occurred_at: datetime
    source: str | None = None
    project_id: UUID | None = None
    conversation_id: UUID | None = None
    metadata_: dict[str, Any] | None = None
    participants: list[EventParticipantCreate] | None = None


class EventUpdate(StrictBaseModel):
    """Schema for updating an event."""

    type: str | None = None
    title: str | None = None
    summary: str | None = None
    content: str | None = None
    importance: float | None = None
    emotional_valence: float | None = None
    source: str | None = None
    project_id: UUID | None = None
    metadata_: dict[str, Any] | None = None


class EventRead(StrictBaseModel):
    """Schema for reading an event."""

    id: UUID
    type: str
    title: str | None
    summary: str | None
    content: str | None
    importance: float
    emotional_valence: float | None
    occurred_at: datetime
    source: str | None
    project_id: UUID | None
    conversation_id: UUID | None
    metadata_: dict[str, Any] | None
    created_at: datetime
    deleted_at: datetime | None
    participants: list[EventParticipantRead] | None = None
