"""Lesson schemas for API validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class LessonCreate(StrictBaseModel):
    """Schema for creating a lesson."""

    content: str
    category: str | None = None
    confidence: float = 0.5
    source_event_id: UUID | None = None
    applies_to: str | None = None
    metadata_: dict[str, Any] | None = None


class LessonUpdate(StrictBaseModel):
    """Schema for updating a lesson."""

    content: str | None = None
    category: str | None = None
    confidence: float | None = None
    applies_to: str | None = None
    metadata_: dict[str, Any] | None = None


class LessonRead(StrictBaseModel):
    """Schema for reading a lesson."""

    id: UUID
    content: str
    category: str | None
    confidence: float
    source_event_id: UUID | None
    applies_to: str | None
    metadata_: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
