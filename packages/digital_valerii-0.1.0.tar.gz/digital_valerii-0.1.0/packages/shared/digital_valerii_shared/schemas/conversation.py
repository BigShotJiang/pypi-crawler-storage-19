"""Conversation schemas for API validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class ConversationCreate(StrictBaseModel):
    """Schema for creating a conversation."""

    title: str | None = None
    interface: str = "cli"
    metadata_: dict[str, Any] | None = None


class ConversationUpdate(StrictBaseModel):
    """Schema for updating a conversation."""

    title: str | None = None
    status: str | None = None
    ended_at: datetime | None = None
    metadata_: dict[str, Any] | None = None


class ConversationRead(StrictBaseModel):
    """Schema for reading a conversation."""

    id: UUID
    title: str | None
    interface: str
    status: str
    started_at: datetime
    ended_at: datetime | None
    metadata_: dict[str, Any] | None
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None
