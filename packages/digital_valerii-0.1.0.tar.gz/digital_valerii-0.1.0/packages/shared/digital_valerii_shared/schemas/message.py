"""Message schemas for API validation."""

from datetime import datetime
from typing import Any
from uuid import UUID

from packages.shared.digital_valerii_shared.schemas.base import StrictBaseModel


class MessageCreate(StrictBaseModel):
    """Schema for creating a message."""

    conversation_id: UUID
    role: str
    content: str
    tool_calls: list[dict[str, Any]] | None = None
    tool_results: list[dict[str, Any]] | None = None
    tokens_input: int | None = None
    tokens_output: int | None = None
    model: str | None = None


class MessageRead(StrictBaseModel):
    """Schema for reading a message."""

    id: UUID
    conversation_id: UUID
    role: str
    content: str
    tool_calls: list[dict[str, Any]] | None
    tool_results: list[dict[str, Any]] | None
    tokens_input: int | None
    tokens_output: int | None
    model: str | None
    created_at: datetime
