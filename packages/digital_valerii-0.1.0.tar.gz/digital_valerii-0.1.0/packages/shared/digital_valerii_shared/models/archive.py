"""Pydantic models for long-term memory archive system.

Component 4.9: Long-term Memory Architecture
"""

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class MemoryType(str, Enum):
    """Types of strategic memories."""

    PROJECT = "project"
    PERSON = "person"
    LESSON = "lesson"
    DECISION = "decision"
    MILESTONE = "milestone"


# =============================================================================
# Archive Index Models
# =============================================================================


class ArchiveIndexEntry(BaseModel):
    """Metadata about a year's archive."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    user_id: UUID
    archived_at: datetime
    event_count: int = Field(..., ge=0)
    message_count: int = Field(default=0, ge=0)
    project_count: int = Field(default=0, ge=0)
    people_count: int = Field(default=0, ge=0)
    lesson_count: int = Field(default=0, ge=0)
    decision_count: int = Field(default=0, ge=0)
    summary: str
    key_achievements: list[str] = Field(default_factory=list)
    qdrant_collection: str
    size_bytes: int = Field(default=0, ge=0)


class ArchiveIndexCreate(BaseModel):
    """Request to create an archive index entry."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    summary: str = Field(..., min_length=10)
    key_achievements: list[str] = Field(default_factory=list)


# =============================================================================
# Strategic Memory Models
# =============================================================================


class StrategicMemory(BaseModel):
    """A strategic memory extracted during archiving."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    user_id: UUID
    year: int = Field(..., ge=2000, le=2100)
    memory_type: MemoryType
    entity_id: UUID | None = None
    title: str = Field(..., max_length=255)
    summary: str
    keywords: list[str] = Field(default_factory=list)
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    related_entities: dict | None = None
    metadata: dict | None = None
    created_at: datetime


class StrategicMemoryCreate(BaseModel):
    """Request to create a strategic memory."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    memory_type: MemoryType
    entity_id: UUID | None = None
    title: str = Field(..., min_length=1, max_length=255)
    summary: str = Field(..., min_length=10)
    keywords: list[str] = Field(default_factory=list)
    importance: float = Field(default=0.5, ge=0.0, le=1.0)
    related_entities: dict | None = None
    metadata: dict | None = None


# =============================================================================
# Archived Event Models
# =============================================================================


class ArchivedEvent(BaseModel):
    """An event that has been archived."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    year: int = Field(..., ge=2000, le=2100)
    user_id: UUID
    original_id: UUID
    event_type: str
    title: str | None = None
    content: str | None = None
    occurred_at: datetime | None = None
    source: str | None = None
    conversation_id: UUID | None = None
    importance: float | None = None
    embedding_id: str | None = None
    archived_at: datetime


class ArchivedEventCreate(BaseModel):
    """Data for creating an archived event."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    original_id: UUID
    event_type: str
    title: str | None = None
    content: str | None = None
    occurred_at: datetime | None = None
    source: str | None = None
    conversation_id: UUID | None = None
    importance: float | None = Field(default=None, ge=0.0, le=1.0)
    embedding_id: str | None = None


# =============================================================================
# Archive Operation Models
# =============================================================================


class ArchiveResult(BaseModel):
    """Result of an archive operation."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    events_archived: int = Field(..., ge=0)
    strategic_memories_created: int = Field(..., ge=0)
    qdrant_collection: str
    summary: str
    key_achievements: list[str] = Field(default_factory=list)
    duration_seconds: float = Field(..., ge=0.0)


class ArchiveProgress(BaseModel):
    """Progress update during archive operation."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    phase: str  # "extracting", "migrating", "summarizing", "complete"
    events_processed: int = Field(..., ge=0)
    events_total: int = Field(..., ge=0)
    percent_complete: float = Field(..., ge=0.0, le=100.0)


class ArchiveSearchRequest(BaseModel):
    """Request to search an archive."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(..., min_length=1, max_length=1000)
    limit: int = Field(default=20, ge=1, le=100)
    event_types: list[str] | None = None


class ArchiveSearchResult(BaseModel):
    """Result of searching an archive."""

    model_config = ConfigDict(extra="forbid")

    events: list[ArchivedEvent]
    query: str
    year: int
    total_found: int = Field(..., ge=0)
    search_duration_ms: float = Field(..., ge=0.0)


# =============================================================================
# Yearly Summary Models
# =============================================================================


class YearlySummary(BaseModel):
    """AI-generated yearly summary."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., ge=2000, le=2100)
    summary: str = Field(..., min_length=50)
    key_achievements: list[str] = Field(default_factory=list)
    lessons_learned: list[str] = Field(default_factory=list)
    key_relationships: list[str] = Field(default_factory=list)


# =============================================================================
# Tiered Memory Models
# =============================================================================


class TieredMemoryContext(BaseModel):
    """Context from tiered memory recall."""

    model_config = ConfigDict(extra="forbid")

    query: str
    active_events: list[dict] = Field(default_factory=list)
    archived_events: list[ArchivedEvent] = Field(default_factory=list)
    strategic_memories: list[StrategicMemory] = Field(default_factory=list)
    years_searched: list[int] = Field(default_factory=list)
    cached: bool = False


class YearDetectionResult(BaseModel):
    """Result of year detection from query."""

    model_config = ConfigDict(extra="forbid")

    years: list[int] = Field(default_factory=list)
    patterns_matched: list[str] = Field(default_factory=list)
