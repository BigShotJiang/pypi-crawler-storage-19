"""Lesson model for extracted insights."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import CheckConstraint, Float, ForeignKey, Index, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from packages.shared.digital_valerii_shared.models.base import (
    Base,
    SoftDeleteMixin,
    TimestampMixin,
)

if TYPE_CHECKING:
    from packages.shared.digital_valerii_shared.models.event import Event


class Lesson(Base, TimestampMixin, SoftDeleteMixin):
    """Lesson model representing extracted insights and preferences."""

    __tablename__ = "lessons"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # preference, fact, insight, decision
    confidence: Mapped[float] = mapped_column(Float, default=0.5)  # 0.0 to 1.0
    source_event_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("events.id"), nullable=True
    )
    applies_to: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # self, person:<id>, project:<id>
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSONB, nullable=True)

    # Relationships
    source_event: Mapped[Event | None] = relationship(back_populates="lessons")

    __table_args__ = (
        Index("ix_lessons_category", "category"),
        Index("ix_lessons_source_event_id", "source_event_id"),
        Index("ix_lessons_confidence", "confidence"),
        # Partial index for soft delete
        Index(
            "ix_lessons_deleted_at",
            "deleted_at",
            postgresql_where=text("deleted_at IS NULL"),
        ),
        # Bounds constraint for confidence
        CheckConstraint(
            "confidence >= 0 AND confidence <= 1",
            name="ck_lessons_confidence_range",
        ),
    )

    def __repr__(self) -> str:
        return f"<Lesson(id={self.id}, category={self.category!r})>"
