"""Project model for project tracking."""

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import ARRAY, DateTime, Index, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from packages.shared.digital_valerii_shared.models.base import (
    Base,
    SoftDeleteMixin,
    TimestampMixin,
)


class Project(Base, TimestampMixin, SoftDeleteMixin):
    """Project model for tracking projects."""

    __tablename__ = "projects"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(
        String(50), default="active"
    )  # active, completed, on_hold, archived
    priority: Mapped[str | None] = mapped_column(
        String(20), nullable=True
    )  # high, medium, low
    start_date: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    end_date: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    tags: Mapped[list[str] | None] = mapped_column(ARRAY(String), nullable=True)
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSONB, nullable=True)

    __table_args__ = (
        Index("ix_projects_status", "status"),
        Index("ix_projects_name", "name"),
        Index(
            "ix_projects_deleted_at",
            "deleted_at",
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )

    def __repr__(self) -> str:
        return f"<Project(id={self.id}, name={self.name!r}, status={self.status!r})>"
