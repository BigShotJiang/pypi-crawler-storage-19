"""Event and EventParticipant models for episodic memory."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    String,
    Text,
    UniqueConstraint,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from packages.shared.digital_valerii_shared.models.base import Base, SoftDeleteMixin

if TYPE_CHECKING:
    from packages.shared.digital_valerii_shared.models.conversation import Conversation
    from packages.shared.digital_valerii_shared.models.lesson import Lesson
    from packages.shared.digital_valerii_shared.models.person import Person
    from packages.shared.digital_valerii_shared.models.project import Project


class Event(Base, SoftDeleteMixin):
    """Event model representing episodic memory entries."""

    __tablename__ = "events"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    type: Mapped[str] = mapped_column(
        String(50), nullable=False
    )  # conversation, meeting, email, call
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    content: Mapped[str | None] = mapped_column(Text, nullable=True)  # Full transcript
    importance: Mapped[float] = mapped_column(Float, default=0.5)  # 0.0 to 1.0
    emotional_valence: Mapped[float | None] = mapped_column(
        Float, nullable=True
    )  # -1.0 to 1.0
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    source: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # cli, web, slack, meeting
    project_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("projects.id"), nullable=True
    )
    conversation_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("conversations.id"), nullable=True
    )
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSONB, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    project: Mapped[Project | None] = relationship()
    conversation: Mapped[Conversation | None] = relationship(back_populates="events")
    participants: Mapped[list[EventParticipant]] = relationship(back_populates="event")
    lessons: Mapped[list[Lesson]] = relationship(back_populates="source_event")

    __table_args__ = (
        Index("ix_events_type", "type"),
        Index("ix_events_occurred_at", "occurred_at"),
        Index("ix_events_importance", "importance"),
        Index("ix_events_project_id", "project_id"),
        Index("ix_events_conversation_id", "conversation_id"),
        # Compound indexes for hybrid search
        Index("ix_events_type_occurred_at", "type", text("occurred_at DESC")),
        Index(
            "ix_events_importance_occurred_at",
            text("importance DESC"),
            text("occurred_at DESC"),
        ),
        # Partial index for soft delete
        Index(
            "ix_events_deleted_at",
            "deleted_at",
            postgresql_where=text("deleted_at IS NULL"),
        ),
        # Bounds constraints for float fields
        CheckConstraint(
            "importance >= 0 AND importance <= 1",
            name="ck_events_importance_range",
        ),
        CheckConstraint(
            "emotional_valence IS NULL OR (emotional_valence >= -1 AND emotional_valence <= 1)",
            name="ck_events_emotional_valence_range",
        ),
    )

    def __repr__(self) -> str:
        return f"<Event(id={self.id}, type={self.type!r}, title={self.title!r})>"


class EventParticipant(Base):
    """Many-to-many relationship between events and people."""

    __tablename__ = "event_participants"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    event_id: Mapped[UUID] = mapped_column(
        ForeignKey("events.id", ondelete="CASCADE"), nullable=False
    )
    person_id: Mapped[UUID] = mapped_column(
        ForeignKey("people.id", ondelete="CASCADE"), nullable=False
    )
    role: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # speaker, attendee, mentioned

    # Relationships
    event: Mapped[Event] = relationship(back_populates="participants")
    person: Mapped[Person] = relationship(back_populates="event_participations")

    __table_args__ = (
        UniqueConstraint("event_id", "person_id", name="uq_event_person"),
        Index("ix_event_participants_event_id", "event_id"),
        Index("ix_event_participants_person_id", "person_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<EventParticipant(event_id={self.event_id}, person_id={self.person_id})>"
        )
