"""Pydantic models for background job queue system."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class JobPriority(str, Enum):
    """Job priority levels for queue routing."""

    HIGH = "high"
    DEFAULT = "default"
    LOW = "low"
    SCHEDULED = "scheduled"


class JobStatus(str, Enum):
    """Job execution status."""

    QUEUED = "queued"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    FAILED = "failed"
    DEFERRED = "deferred"


class JobRequest(BaseModel):
    """Request to enqueue a new job."""

    model_config = ConfigDict(extra="forbid")

    job_name: str = Field(..., description="Name of the job function to execute")
    payload: dict = Field(default_factory=dict, description="Job-specific data")
    priority: JobPriority = Field(
        default=JobPriority.DEFAULT, description="Job priority level"
    )
    delay_seconds: int | None = Field(
        default=None, ge=0, description="Delay before job execution"
    )


class JobResult(BaseModel):
    """Result of a job execution."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    job_id: str = Field(..., description="Unique job identifier")
    status: JobStatus = Field(..., description="Current job status")
    result: dict | None = Field(default=None, description="Job result data")
    error: str | None = Field(default=None, description="Error message if failed")
    created_at: datetime = Field(..., description="Job creation timestamp (UTC)")
    completed_at: datetime | None = Field(
        default=None, description="Job completion timestamp (UTC)"
    )


class QueueStats(BaseModel):
    """Statistics for job queues."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    high_priority: int = Field(ge=0, description="Jobs in high priority queue")
    default: int = Field(ge=0, description="Jobs in default queue")
    low_priority: int = Field(ge=0, description="Jobs in low priority queue")
    scheduled: int = Field(ge=0, description="Scheduled jobs")
    total: int = Field(ge=0, description="Total jobs across all queues")


# Job payload models for type safety
class ExtractLessonsPayload(BaseModel):
    """Payload for extract_lessons job."""

    model_config = ConfigDict(extra="forbid")

    context_id: str = Field(..., description="Context UUID for lesson extraction")


class SyncQdrantOutboxPayload(BaseModel):
    """Payload for sync_qdrant_outbox job (no required fields)."""

    model_config = ConfigDict(extra="forbid")

    limit: int = Field(default=100, ge=1, le=1000, description="Max entries to process")


class GenerateEmbeddingsPayload(BaseModel):
    """Payload for generate_embeddings job."""

    model_config = ConfigDict(extra="forbid")

    content_ids: list[str] = Field(
        ..., min_length=1, description="Content UUIDs for embedding"
    )


class ProcessMeetingTranscriptPayload(BaseModel):
    """Payload for process_meeting_transcript job."""

    model_config = ConfigDict(extra="forbid")

    meeting_id: str = Field(..., description="Meeting UUID")
    transcript: str = Field(..., min_length=1, description="Meeting transcript text")


class CrossStoreDeletionPayload(BaseModel):
    """Payload for cross_store_deletion job."""

    model_config = ConfigDict(extra="forbid")

    entity_type: str = Field(..., description="Type of entity (event, conversation...)")
    entity_id: str = Field(..., description="Entity UUID")
    reason: str = Field(default="user_request", description="Deletion reason")


# Job result models
class ExtractLessonsResult(BaseModel):
    """Result from extract_lessons job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: str = Field(default="completed")
    lessons_extracted: int = Field(ge=0)


class SyncQdrantOutboxResult(BaseModel):
    """Result from sync_qdrant_outbox job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    synced: int = Field(ge=0)
    failed: int = Field(ge=0)


class GenerateEmbeddingsResult(BaseModel):
    """Result from generate_embeddings job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    embeddings_generated: int = Field(ge=0)


class ProcessMeetingTranscriptResult(BaseModel):
    """Result from process_meeting_transcript job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    event_id: str
    summary_length: int = Field(ge=0)
    action_items_count: int = Field(ge=0)


class CrossStoreDeletionResult(BaseModel):
    """Result from cross_store_deletion job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    entity_type: str
    deleted_from: list[str] = Field(default_factory=list)
    complete: bool = Field(default=False)


class HardDeleteExpiredResult(BaseModel):
    """Result from hard_delete_expired job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    events: int = Field(ge=0)
    conversations: int = Field(ge=0)
    messages: int = Field(ge=0)
    lessons: int = Field(ge=0)


class CleanupOrphanedOutboxResult(BaseModel):
    """Result from cleanup_orphaned_outbox job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    deleted_count: int = Field(ge=0)


class CleanupExpiredApprovalsResult(BaseModel):
    """Result from cleanup_expired_approvals job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    expired_count: int = Field(ge=0)


class ExecuteScheduledTaskPayload(BaseModel):
    """Payload for execute_scheduled_task job."""

    model_config = ConfigDict(extra="forbid")

    task_id: str = Field(..., description="UUID of task_queue entry to execute")


class ExecuteScheduledTaskResult(BaseModel):
    """Result from execute_scheduled_task job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: str = Field(default="completed")
    task_type: str | None = Field(default=None)
    executed_at: str | None = Field(default=None)
    error: str | None = Field(default=None)


class RequeueStuckMessagesResult(BaseModel):
    """Result from requeue_stuck_messages job."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    requeued_count: int = Field(ge=0, description="Number of stuck messages requeued")


class AnnualArchivePayload(BaseModel):
    """Payload for annual_archive job (Component 4.9)."""

    model_config = ConfigDict(extra="forbid")

    year: int = Field(..., description="Year to archive")
    user_id: str = Field(..., description="User UUID to archive for")


class AnnualArchiveResult(BaseModel):
    """Result from annual_archive job (Component 4.9)."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    year: int
    events_archived: int = Field(ge=0)
    strategic_memories_created: int = Field(ge=0)
    archive_collection_created: bool = Field(default=False)
    status: str = Field(default="completed")
