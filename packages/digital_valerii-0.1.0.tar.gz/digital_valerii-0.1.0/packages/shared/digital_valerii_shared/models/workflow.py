"""SQLAlchemy models for workflow execution tracking.

Component 4.11: Orchestration Patterns
Database persistence with multi-tenancy support.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from packages.shared.digital_valerii_shared.models.base import Base

if TYPE_CHECKING:
    pass


class WorkflowExecution(Base):
    """Workflow execution tracking with multi-tenancy.

    Tracks each workflow run including status, timing, and results.
    Uses user_id and project_id for multi-tenant queries.
    """

    __tablename__ = "workflow_executions"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    user_id: Mapped[UUID] = mapped_column(nullable=False, index=True)
    project_id: Mapped[UUID | None] = mapped_column(nullable=True, index=True)
    workflow_type: Mapped[str] = mapped_column(String(100), nullable=False)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="running"
    )  # running, completed, failed, cancelled
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    context: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    result: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    steps: Mapped[list[WorkflowStepRecord]] = relationship(
        back_populates="execution",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("ix_workflow_executions_user_status", "user_id", "status"),
        Index("ix_workflow_executions_started_at", "started_at"),
    )

    def __repr__(self) -> str:
        return (
            f"<WorkflowExecution(id={self.id}, type={self.workflow_type!r}, "
            f"status={self.status!r})>"
        )


class WorkflowStepRecord(Base):
    """Workflow step execution tracking.

    Records individual step executions within a workflow.
    Denormalizes user_id for efficient multi-tenant queries.
    """

    __tablename__ = "workflow_steps"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    execution_id: Mapped[UUID] = mapped_column(
        ForeignKey("workflow_executions.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id: Mapped[UUID] = mapped_column(
        nullable=False, index=True
    )  # Denormalized for efficient queries
    step_name: Mapped[str] = mapped_column(String(100), nullable=False)
    step_order: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, default="pending"
    )  # pending, running, completed, failed
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    input_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    output_data: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)

    # Relationships
    execution: Mapped[WorkflowExecution] = relationship(back_populates="steps")

    __table_args__ = (Index("ix_workflow_steps_execution", "execution_id"),)

    def __repr__(self) -> str:
        return (
            f"<WorkflowStepRecord(id={self.id}, step={self.step_name!r}, "
            f"status={self.status!r})>"
        )
