"""Conversation model for chat sessions."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import DateTime, Index, String, func, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from packages.shared.digital_valerii_shared.models.base import (
    Base,
    SoftDeleteMixin,
    TimestampMixin,
)

if TYPE_CHECKING:
    from packages.shared.digital_valerii_shared.models.event import Event
    from packages.shared.digital_valerii_shared.models.message import Message


class Conversation(Base, TimestampMixin, SoftDeleteMixin):
    """Conversation model representing chat sessions."""

    __tablename__ = "conversations"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    interface: Mapped[str] = mapped_column(
        String(50), default="cli"
    )  # cli, web, slack, meeting
    status: Mapped[str] = mapped_column(
        String(20), default="active"
    )  # active, archived
    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    ended_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    metadata_: Mapped[dict | None] = mapped_column("metadata", JSONB, nullable=True)

    # Relationships
    messages: Mapped[list[Message]] = relationship(
        back_populates="conversation", order_by="Message.created_at"
    )
    events: Mapped[list[Event]] = relationship(back_populates="conversation")

    __table_args__ = (
        Index(
            "ix_conversations_deleted_at",
            "deleted_at",
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )

    def __repr__(self) -> str:
        return f"<Conversation(id={self.id}, interface={self.interface!r}, status={self.status!r})>"
