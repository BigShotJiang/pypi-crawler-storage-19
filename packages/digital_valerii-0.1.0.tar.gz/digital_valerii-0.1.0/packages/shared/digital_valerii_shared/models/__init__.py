"""Digital Valerii SQLAlchemy Models."""

from packages.shared.digital_valerii_shared.models.archive import (
    ArchivedEvent,
    ArchiveIndexEntry,
    ArchiveProgress,
    ArchiveResult,
    ArchiveSearchRequest,
    ArchiveSearchResult,
    MemoryType,
    StrategicMemory,
    TieredMemoryContext,
    YearDetectionResult,
    YearlySummary,
)
from packages.shared.digital_valerii_shared.models.audit_log import AuditLog
from packages.shared.digital_valerii_shared.models.base import (
    Base,
    SoftDeleteMixin,
    TimestampMixin,
)
from packages.shared.digital_valerii_shared.models.conversation import Conversation
from packages.shared.digital_valerii_shared.models.event import Event, EventParticipant
from packages.shared.digital_valerii_shared.models.jobs import (
    JobPriority,
    JobRequest,
    JobResult,
    JobStatus,
    QueueStats,
)
from packages.shared.digital_valerii_shared.models.lesson import Lesson
from packages.shared.digital_valerii_shared.models.message import Message
from packages.shared.digital_valerii_shared.models.person import Person
from packages.shared.digital_valerii_shared.models.project import Project
from packages.shared.digital_valerii_shared.models.workflow import (
    WorkflowExecution,
    WorkflowStepRecord,
)

__all__ = [
    # Archive models (Component 4.9)
    "ArchiveIndexEntry",
    "ArchiveProgress",
    "ArchiveResult",
    "ArchiveSearchRequest",
    "ArchiveSearchResult",
    "ArchivedEvent",
    "MemoryType",
    "StrategicMemory",
    "TieredMemoryContext",
    "YearDetectionResult",
    "YearlySummary",
    # Core models
    "AuditLog",
    "Base",
    "Conversation",
    "Event",
    "EventParticipant",
    "JobPriority",
    "JobRequest",
    "JobResult",
    "JobStatus",
    "Lesson",
    "Message",
    "Person",
    "Project",
    "QueueStats",
    "SoftDeleteMixin",
    "TimestampMixin",
    # Workflow models (Component 4.11)
    "WorkflowExecution",
    "WorkflowStepRecord",
]
