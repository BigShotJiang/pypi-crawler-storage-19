"""Person model for contacts and relationships."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import DateTime, Index, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from packages.shared.digital_valerii_shared.models.base import (
    Base,
    SoftDeleteMixin,
    TimestampMixin,
)

if TYPE_CHECKING:
    from packages.shared.digital_valerii_shared.models.event import EventParticipant


class Person(Base, TimestampMixin, SoftDeleteMixin):
    """Person model representing contacts and relationships."""

    __tablename__ = "people"

    id: Mapped[UUID] = mapped_column(primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    company: Mapped[str | None] = mapped_column(String(255), nullable=True)
    role: Mapped[str | None] = mapped_column(String(255), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    relationship_type: Mapped[str | None] = mapped_column(
        String(50), nullable=True
    )  # colleague, friend, client, etc.
    last_interaction: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Relationships
    event_participations: Mapped[list[EventParticipant]] = relationship(
        back_populates="person"
    )

    __table_args__ = (
        Index("ix_people_email", "email"),
        Index("ix_people_name", "name"),
        Index("ix_people_last_interaction", "last_interaction"),
        Index(
            "ix_people_deleted_at",
            "deleted_at",
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )

    def __repr__(self) -> str:
        return f"<Person(id={self.id}, name={self.name!r})>"
