"""Async database connection manager."""

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from .config import DatabaseSettings


class Database:
    """Async database connection manager with pooling."""

    def __init__(self, settings: "DatabaseSettings") -> None:
        """Initialize database with settings.

        Args:
            settings: Database connection settings.
        """
        self.settings = settings
        self._engine: AsyncEngine | None = None
        self._session_factory: async_sessionmaker[AsyncSession] | None = None

    @property
    def engine(self) -> AsyncEngine:
        """Get the database engine, creating it if necessary."""
        if self._engine is None:
            self._engine = create_async_engine(
                self.settings.url,
                pool_size=self.settings.pool_size,
                max_overflow=self.settings.max_overflow,
                pool_pre_ping=True,
                pool_recycle=3600,
                echo=self.settings.echo,
            )
        return self._engine

    @property
    def session_factory(self) -> async_sessionmaker[AsyncSession]:
        """Get the session factory, creating it if necessary."""
        if self._session_factory is None:
            self._session_factory = async_sessionmaker(
                bind=self.engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False,
            )
        return self._session_factory

    @asynccontextmanager
    async def session(self) -> "AsyncGenerator[AsyncSession, None]":
        """Context manager for database sessions.

        Provides a transactional scope around a series of operations.
        Commits on success, rolls back on exception.

        Yields:
            AsyncSession: Database session.
        """
        session = self.session_factory()
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

    async def health_check(self) -> bool:
        """Check database connectivity.

        Returns:
            True if database is reachable, False otherwise.
        """
        try:
            async with self.session() as session:
                await session.execute(text("SELECT 1"))
            return True
        except Exception:
            return False

    async def close(self) -> None:
        """Close the database engine and cleanup resources."""
        if self._engine is not None:
            await self._engine.dispose()
            self._engine = None
            self._session_factory = None


class IsolatedDatabase(Database):
    """Database with NullPool for testing isolation.

    Uses NullPool to ensure each connection is fresh,
    avoiding state leakage between tests.
    """

    @property
    def engine(self) -> AsyncEngine:
        """Get the test database engine with NullPool."""
        if self._engine is None:
            self._engine = create_async_engine(
                self.settings.url,
                poolclass=NullPool,
                echo=self.settings.echo,
            )
        return self._engine


# Backwards compatibility alias (avoids pytest collection warning)
TestDatabase = IsolatedDatabase
