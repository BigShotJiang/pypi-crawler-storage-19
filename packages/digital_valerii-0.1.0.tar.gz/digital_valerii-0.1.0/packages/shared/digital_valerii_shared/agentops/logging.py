"""Structured logging configuration for AgentOps.

Component 6.5: AgentOps Framework
Configures structlog for consistent, structured logging across the application.
"""

from typing import Any

import structlog
from structlog.stdlib import BoundLogger


def configure_logging(
    json_format: bool = True,
    log_level: str = "INFO",
) -> None:
    """Configure structured logging for the application.

    Sets up structlog with processors for timestamps, log levels,
    and either JSON or console output formatting.

    Args:
        json_format: If True, output logs as JSON. If False, use
                     console-friendly format.
        log_level: Minimum log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    """
    # Get numeric level
    level_map = {
        "DEBUG": 10,
        "INFO": 20,
        "WARNING": 30,
        "ERROR": 40,
        "CRITICAL": 50,
    }
    numeric_level = level_map.get(log_level.upper(), 20)

    processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    if json_format:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(numeric_level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> BoundLogger:
    """Get a structured logger for a module.

    Args:
        name: Logger name, typically __name__ of the calling module.

    Returns:
        A bound logger instance.
    """
    return structlog.get_logger(name)


def bind_context(**kwargs: Any) -> None:
    """Bind context variables for all subsequent log calls in this context.

    Bound variables will be included in all log messages from this
    context (async task, thread, etc.) until cleared.

    Args:
        **kwargs: Key-value pairs to bind to the logging context.

    Example:
        bind_context(user_id="123", session_id="abc")
        logger.info("User action")  # Will include user_id and session_id
    """
    structlog.contextvars.bind_contextvars(**kwargs)


def unbind_context(*keys: str) -> None:
    """Remove specific keys from the logging context.

    Args:
        *keys: Keys to remove from context.
    """
    structlog.contextvars.unbind_contextvars(*keys)


def clear_context() -> None:
    """Clear all bound context variables."""
    structlog.contextvars.clear_contextvars()
