"""Trace data sanitizer for PII redaction.

Component 6.5: AgentOps Framework
Sanitizes trace data before storage to prevent PII leaks.
"""

import re
from typing import Any, cast


class TraceSanitizer:
    """Sanitize trace data before storage to prevent PII leaks.

    This class provides pattern-based redaction for common PII types
    including emails, phone numbers, SSNs, credit cards, and credentials.
    Also redacts values for keys that indicate sensitive data (e.g., "token", "api_key").
    """

    # FIX-6.5.1: Keys that indicate sensitive values regardless of value content
    SENSITIVE_KEYS: set[str] = {
        "password",
        "token",
        "access_token",
        "refresh_token",
        "api_key",
        "apikey",
        "secret",
        "credential",
        "credentials",
        "authorization",
        "auth_token",
        "bearer",
        "private_key",
        "secret_key",
    }

    # FIX-6.5.4: Maximum recursion depth to prevent stack overflow
    MAX_DEPTH: int = 50

    PII_PATTERNS: list[tuple[str, str]] = [
        # Email addresses
        (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "[EMAIL]"),
        # Phone numbers (various formats)
        (r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[PHONE]"),
        # Social Security Numbers
        (r"\b\d{3}-\d{2}-\d{4}\b", "[SSN]"),
        # Credit card numbers (16 digits)
        (r"\b\d{16}\b", "[CARD_NUMBER]"),
        # Credit card with spaces/dashes
        (r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b", "[CARD_NUMBER]"),
        # Passwords
        (r'(?i)password["\'\s:=]+[^\s,}"\'\]]+', "password=[REDACTED]"),
        # API keys
        (r'(?i)api[_-]?key["\'\s:=]+[^\s,}"\'\]]+', "api_key=[REDACTED]"),
        # Tokens
        (r'(?i)token["\'\s:=]+[^\s,}"\'\]]+', "token=[REDACTED]"),
        # Secrets
        (r'(?i)secret["\'\s:=]+[^\s,}"\'\]]+', "secret=[REDACTED]"),
        # Credentials
        (r'(?i)credential[s]?["\'\s:=]+[^\s,}"\'\]]+', "credential=[REDACTED]"),
    ]

    def __init__(self, additional_patterns: list[tuple[str, str]] | None = None):
        """Initialize sanitizer with optional additional patterns.

        Args:
            additional_patterns: Additional (pattern, replacement) tuples.
        """
        self._patterns = list(self.PII_PATTERNS)
        if additional_patterns:
            self._patterns.extend(additional_patterns)

        # Pre-compile patterns for performance
        self._compiled_patterns = [
            (re.compile(pattern), replacement)
            for pattern, replacement in self._patterns
        ]

    def sanitize(self, data: dict[str, Any]) -> dict[str, Any]:
        """Redact PII patterns from trace data recursively.

        Args:
            data: Dictionary containing trace data.

        Returns:
            Sanitized copy of the data with PII redacted.
        """
        return cast(dict[str, Any], self._sanitize_value(data, depth=0, seen=None))

    def _sanitize_value(
        self,
        value: Any,
        depth: int = 0,
        seen: set[int] | None = None,
    ) -> Any:
        """Recursively sanitize any value type.

        Args:
            value: Any value to sanitize.
            depth: Current recursion depth.
            seen: Set of object ids to detect cycles.

        Returns:
            Sanitized value, or "[TRUNCATED:...]" if depth/cycle limit reached.
        """
        if seen is None:
            seen = set()

        # FIX-6.5.4: Depth guard
        if depth > self.MAX_DEPTH:
            return "[TRUNCATED:DEPTH]"

        # FIX-6.5.4: Cycle guard for mutable containers
        if isinstance(value, dict | list):
            if id(value) in seen:
                return "[TRUNCATED:CYCLE]"
            seen = seen | {id(value)}  # Create new set to avoid mutation

        if value is None:
            return None

        if isinstance(value, str):
            return self._redact_pii(value)

        # FIX-6.5.1: Check for sensitive keys in dictionaries
        if isinstance(value, dict):
            sanitized = {}
            for k, v in value.items():
                if isinstance(k, str) and k.lower() in self.SENSITIVE_KEYS:
                    sanitized[k] = "[REDACTED]"
                else:
                    sanitized[k] = self._sanitize_value(v, depth + 1, seen)
            return sanitized

        if isinstance(value, list):
            return [self._sanitize_value(item, depth + 1, seen) for item in value]

        if isinstance(value, tuple):
            return tuple(self._sanitize_value(item, depth + 1, seen) for item in value)

        # Numbers, booleans, etc. pass through unchanged
        return value

    def _redact_pii(self, text: str) -> str:
        """Apply PII redaction patterns to text.

        Args:
            text: String to redact.

        Returns:
            Redacted string.
        """
        result = text
        for pattern, replacement in self._compiled_patterns:
            result = pattern.sub(replacement, result)
        return result
