"""Agent tracing data models.

Component 6.5: AgentOps Framework
Data structures for tracing agent reasoning and tool calls.
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4


class TraceEventType(str, Enum):
    """Types of events in agent trajectory."""

    PROMPT_RECEIVED = "prompt_received"
    MEMORY_RECALL = "memory_recall"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    DECISION_POINT = "decision_point"
    APPROVAL_REQUEST = "approval_request"
    APPROVAL_RESPONSE = "approval_response"
    RESPONSE_GENERATED = "response_generated"
    ERROR = "error"


@dataclass
class TraceEvent:
    """Single event in agent trajectory.

    Represents a discrete step in the agent's reasoning process,
    including tool calls, memory queries, and decision points.
    """

    id: UUID = field(default_factory=uuid4)
    trace_id: UUID | None = None
    event_type: TraceEventType | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    duration_ms: int = 0
    data: dict[str, Any] = field(default_factory=dict)
    parent_event_id: UUID | None = None


@dataclass
class AgentTrace:
    """Complete trace of agent reasoning.

    Captures the full trajectory of an agent interaction, from
    prompt receipt through response generation, including all
    intermediate steps.

    Attributes:
        id: Unique trace identifier.
        session_id: Session this trace belongs to.
        user_id: User ID for multi-tenancy.
        started_at: When the trace started.
        completed_at: When the trace completed (None if in progress).
        events: List of trace events in order.
        outcome: Final outcome (success, failure, timeout).
        total_tokens: Total tokens consumed.
        total_cost_usd: Estimated cost in USD.
    """

    id: UUID = field(default_factory=uuid4)
    session_id: UUID | None = None
    user_id: UUID | None = None
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None
    events: list[TraceEvent] = field(default_factory=list)
    outcome: str | None = None
    total_tokens: int = 0
    total_cost_usd: float = 0.0

    def add_event(self, event: TraceEvent) -> None:
        """Add an event to this trace.

        Args:
            event: Event to add.
        """
        event.trace_id = self.id
        self.events.append(event)

    def get_events_by_type(self, event_type: TraceEventType) -> list[TraceEvent]:
        """Get all events of a specific type.

        Args:
            event_type: Type to filter by.

        Returns:
            List of matching events.
        """
        return [e for e in self.events if e.event_type == event_type]

    def duration_ms(self) -> int | None:
        """Calculate trace duration in milliseconds.

        Returns:
            Duration in ms, or None if not completed.
        """
        if self.completed_at is None:
            return None
        delta = self.completed_at - self.started_at
        return int(delta.total_seconds() * 1000)
