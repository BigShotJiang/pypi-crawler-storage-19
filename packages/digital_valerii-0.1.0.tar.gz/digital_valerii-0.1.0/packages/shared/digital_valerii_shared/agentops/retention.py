"""Trace retention policy management.

Component 6.5: AgentOps Framework
Manages trace lifecycle, sampling, and GDPR-compliant deletion.
"""

import random
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Protocol
from uuid import UUID


class TraceCategory(str, Enum):
    """Categories for trace retention.

    Different categories have different retention periods based
    on their importance for debugging, compliance, and safety.
    """

    NORMAL = "normal"
    SAFETY_VIOLATION = "safety_violation"
    ERROR = "error"


class RetentionPolicy:
    """Trace retention policy configuration.

    Defines retention periods and sampling rates for different
    trace categories and environments.

    Attributes:
        NORMAL_RETENTION_DAYS: Days to keep normal traces.
        ERROR_RETENTION_DAYS: Days to keep error traces.
        SAFETY_RETENTION_DAYS: Days to keep safety violation traces.
        PRODUCTION_SAMPLE_RATE: Sampling rate in production (0.0-1.0).
        ERROR_SAMPLE_RATE: Sampling rate for errors (always 1.0).
    """

    NORMAL_RETENTION_DAYS = 30
    ERROR_RETENTION_DAYS = 90
    SAFETY_RETENTION_DAYS = 365

    PRODUCTION_SAMPLE_RATE = 0.10  # 10% in production
    ERROR_SAMPLE_RATE = 1.00  # 100% for errors

    def get_retention_days(self, category: TraceCategory) -> int:
        """Get retention period for trace category.

        Args:
            category: The trace category.

        Returns:
            Number of days to retain the trace.
        """
        if category == TraceCategory.SAFETY_VIOLATION:
            return self.SAFETY_RETENTION_DAYS
        elif category == TraceCategory.ERROR:
            return self.ERROR_RETENTION_DAYS
        return self.NORMAL_RETENTION_DAYS

    def get_expiry_date(self, category: TraceCategory) -> datetime:
        """Get expiry date for a new trace.

        Args:
            category: The trace category.

        Returns:
            Datetime when the trace should expire.
        """
        days = self.get_retention_days(category)
        return datetime.now(UTC) + timedelta(days=days)

    def should_sample(self, is_error: bool, environment: str = "production") -> bool:
        """Determine if trace should be sampled based on environment.

        In development and staging, all traces are sampled.
        In production, normal traces are sampled at PRODUCTION_SAMPLE_RATE.
        Errors are always sampled.

        Args:
            is_error: Whether this trace contains an error.
            environment: Current environment (development, staging, production).

        Returns:
            True if the trace should be recorded.
        """
        # Always sample in dev/staging
        if environment in ("development", "staging"):
            return True

        # Always sample errors
        if is_error:
            return True

        # Production: sample at configured rate
        return random.random() < self.PRODUCTION_SAMPLE_RATE


class TraceRetentionStore(Protocol):
    """Protocol for trace storage with retention support.

    Implementations must support cleanup and GDPR deletion operations.
    """

    async def delete_expired(self) -> int:
        """Delete all expired traces.

        Returns:
            Number of traces deleted.
        """
        ...

    async def delete_by_user(self, user_id: UUID) -> int:
        """Delete all traces for a specific user (GDPR compliance).

        Args:
            user_id: User whose traces should be deleted.

        Returns:
            Number of traces deleted.
        """
        ...


class TraceRetentionService:
    """Service for managing trace retention.

    Provides cleanup and GDPR deletion capabilities for trace storage.

    Example:
        service = TraceRetentionService(store=my_store)

        # Scheduled cleanup job
        deleted = await service.cleanup_expired()

        # GDPR delete request
        deleted = await service.gdpr_delete(user_id)
    """

    def __init__(
        self,
        store: TraceRetentionStore,
        policy: RetentionPolicy | None = None,
    ):
        """Initialize retention service.

        Args:
            store: Storage backend with retention support.
            policy: Optional custom retention policy.
        """
        self._store = store
        self._policy = policy or RetentionPolicy()

    @property
    def policy(self) -> RetentionPolicy:
        """Get the current retention policy."""
        return self._policy

    async def cleanup_expired(self) -> int:
        """Delete expired traces. Run as scheduled job.

        Returns:
            Number of traces deleted.
        """
        return await self._store.delete_expired()

    async def gdpr_delete(self, user_id: UUID) -> int:
        """GDPR: Delete all traces for a user immediately.

        This should be called when a user exercises their right
        to erasure under GDPR.

        Args:
            user_id: User requesting deletion.

        Returns:
            Number of traces deleted.
        """
        return await self._store.delete_by_user(user_id)
