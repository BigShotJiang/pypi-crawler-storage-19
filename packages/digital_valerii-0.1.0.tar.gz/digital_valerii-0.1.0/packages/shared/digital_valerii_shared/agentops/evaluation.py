"""Pre-deployment evaluation framework for agents.

Component 6.5: AgentOps Framework
Evaluates agent readiness for production deployment.
"""

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class EvaluationResult:
    """Result of pre-deployment evaluation.

    Attributes:
        passed: Whether the evaluation passed all checks.
        score: Overall score (0-100).
        metrics: Individual metric values.
        failed_checks: List of failed check descriptions.
        recommendations: Suggested improvements.
    """

    passed: bool
    score: float
    metrics: dict[str, Any] = field(default_factory=dict)
    failed_checks: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)


class TestSuite(Protocol):
    """Protocol for test suites used in evaluation.

    Implementations should provide methods to run various
    categories of tests and return pass rates or scores.
    """

    async def run_functional_tests(self) -> float:
        """Run functional tests and return pass rate (0.0-1.0)."""
        ...

    async def run_trajectory_tests(self) -> float:
        """Run trajectory/reasoning quality tests (0.0-1.0)."""
        ...

    async def run_latency_tests(self) -> float:
        """Run latency tests and return P95 latency in seconds."""
        ...

    async def run_safety_tests(self) -> bool:
        """Run safety tests and return True if all pass."""
        ...


class PreDeploymentEvaluator:
    """Evaluate agent readiness for production.

    Runs a comprehensive test suite against an agent and determines
    if it meets the quality bar for deployment.

    Attributes:
        REQUIRED_PASS_RATE: Minimum functional test pass rate (default 95%).
        MAX_LATENCY_P95: Maximum acceptable P95 latency in seconds.
        MIN_TRAJECTORY_SCORE: Minimum trajectory quality score.
    """

    REQUIRED_PASS_RATE = 0.95
    MAX_LATENCY_P95 = 10.0
    MIN_TRAJECTORY_SCORE = 0.8

    def __init__(
        self,
        pass_rate: float | None = None,
        max_latency: float | None = None,
        min_trajectory: float | None = None,
    ):
        """Initialize evaluator with optional custom thresholds.

        Args:
            pass_rate: Custom functional test pass rate threshold.
            max_latency: Custom maximum P95 latency threshold.
            min_trajectory: Custom minimum trajectory score.
        """
        self.pass_rate = pass_rate if pass_rate is not None else self.REQUIRED_PASS_RATE
        self.max_latency = (
            max_latency if max_latency is not None else self.MAX_LATENCY_P95
        )
        self.min_trajectory = (
            min_trajectory if min_trajectory is not None else self.MIN_TRAJECTORY_SCORE
        )

    async def evaluate(self, test_suite: TestSuite) -> EvaluationResult:
        """Run full evaluation suite.

        Executes all test categories and calculates an overall
        score weighted by importance.

        Args:
            test_suite: Test suite implementation to run.

        Returns:
            EvaluationResult with pass/fail, score, and details.
        """
        failed_checks: list[str] = []

        # 1. Functional tests (40% weight)
        functional_score = await test_suite.run_functional_tests()
        if functional_score < self.pass_rate:
            failed_checks.append(
                f"Functional tests: {functional_score:.1%} (required: {self.pass_rate:.1%})"
            )

        # 2. Trajectory evaluation (30% weight)
        trajectory_score = await test_suite.run_trajectory_tests()
        if trajectory_score < self.min_trajectory:
            failed_checks.append(
                f"Trajectory quality: {trajectory_score:.2f} (required: {self.min_trajectory})"
            )

        # 3. Latency check (15% weight)
        latency_p95 = await test_suite.run_latency_tests()
        if latency_p95 > self.max_latency:
            failed_checks.append(
                f"P95 latency: {latency_p95:.1f}s (max: {self.max_latency}s)"
            )

        # 4. Safety check (15% weight)
        safety_passed = await test_suite.run_safety_tests()
        if not safety_passed:
            failed_checks.append("Safety tests failed")

        # Calculate overall score (weighted)
        latency_score = 1.0 if latency_p95 <= self.max_latency else 0.5
        safety_score = 1.0 if safety_passed else 0.0

        overall_score = (
            functional_score * 40
            + trajectory_score * 30
            + latency_score * 15
            + safety_score * 15
        )

        return EvaluationResult(
            passed=len(failed_checks) == 0,
            score=overall_score,
            metrics={
                "functional_pass_rate": functional_score,
                "trajectory_score": trajectory_score,
                "latency_p95": latency_p95,
                "safety_passed": safety_passed,
            },
            failed_checks=failed_checks,
            recommendations=self._generate_recommendations(failed_checks),
        )

    def _generate_recommendations(self, failed_checks: list[str]) -> list[str]:
        """Generate recommendations based on failed checks.

        Args:
            failed_checks: List of failed check descriptions.

        Returns:
            List of actionable recommendations.
        """
        recommendations: list[str] = []

        for check in failed_checks:
            if "Functional" in check:
                recommendations.append("Review and fix failing unit tests")
            elif "Trajectory" in check:
                recommendations.append("Improve agent reasoning patterns")
            elif "latency" in check:
                recommendations.append("Optimize slow operations or add caching")
            elif "Safety" in check:
                recommendations.append("Review safety policies and guardrails")

        return recommendations
