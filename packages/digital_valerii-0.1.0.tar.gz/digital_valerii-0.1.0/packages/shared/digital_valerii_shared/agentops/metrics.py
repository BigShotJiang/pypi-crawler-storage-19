"""Prometheus metrics for agent observability.

Component 6.5: AgentOps Framework
Defines and records metrics for agent performance and behavior.
"""

from prometheus_client import Counter, Gauge, Histogram

# =============================================================================
# FIX-6.5.3: Bounded label values to prevent cardinality explosion
# =============================================================================

ALLOWED_OUTCOMES: set[str] = {"success", "failure", "timeout", "cancelled"}
ALLOWED_ERROR_TYPES: set[str] = {
    "none",
    "timeout",
    "validation",
    "tool_error",
    "llm_error",
    "network",
}
ALLOWED_RISK_LEVELS: set[str] = {"low", "medium", "high", "critical"}

# FIX-6.5.3b: Reasons for blocking actions
ALLOWED_BLOCK_REASONS: set[str] = {
    "policy_violation",
    "rate_limit",
    "permission_denied",
    "safety_check",
    "approval_required",
    "approval_denied",
    "invalid_input",
    "resource_unavailable",
    "timeout",
    "unknown",
}

# Known tools - extend as needed
KNOWN_TOOLS: set[str] = {
    "search",
    "memory",
    "calendar",
    "email",
    "file",
    "browser",
    "code",
    "database",
    "api",
    "notification",
}

# Known models
KNOWN_MODELS: set[str] = {
    "claude-3-opus",
    "claude-3-sonnet",
    "claude-3-haiku",
    "claude-3.5-sonnet",
    "claude-3.5-haiku",
    "gpt-4",
    "gpt-4-turbo",
    "gpt-3.5-turbo",
}


def _normalize_label(value: str, allowed: set[str], fallback: str = "other") -> str:
    """Normalize label to allowed values to prevent cardinality explosion.

    Args:
        value: The label value to normalize.
        allowed: Set of allowed values.
        fallback: Value to use if not in allowed set.

    Returns:
        Normalized label value.
    """
    normalized = value.lower().strip()
    return normalized if normalized in allowed else fallback


# Request metrics
agent_requests_total = Counter(
    "agent_requests_total",
    "Total agent requests",
    ["outcome", "error_type"],
)

agent_request_duration = Histogram(
    "agent_request_duration_seconds",
    "Agent request duration",
    buckets=[0.5, 1, 2, 5, 10, 30, 60, 120],
)

# Token metrics (type label: input/output)
tokens_used_total = Counter(
    "tokens_used_total",
    "Total tokens consumed",
    ["model", "type"],
)

# Tool metrics
tool_calls_total = Counter(
    "tool_calls_total",
    "Total tool invocations",
    ["tool_name", "outcome"],
)

tool_approval_rate = Gauge(
    "tool_approval_rate",
    "Approval rate for tools requiring confirmation",
    ["tool_name"],
)

# Memory metrics
memory_recall_duration = Histogram(
    "memory_recall_duration_seconds",
    "Memory recall latency",
    buckets=[0.1, 0.2, 0.5, 1, 2, 5],
)

# Cost metrics
estimated_cost_usd = Counter(
    "estimated_cost_usd_total",
    "Estimated API costs",
    ["model"],
)

# Safety metrics
approval_requests_total = Counter(
    "approval_requests_total",
    "Total approval requests",
    ["risk_level"],
)

blocked_actions_total = Counter(
    "blocked_actions_total",
    "Total blocked actions",
    ["tool_name", "reason"],
)

# Session metrics
active_sessions = Gauge(
    "active_sessions",
    "Currently active sessions",
)


class MetricsRecorder:
    """Helper class for recording agent metrics.

    Provides a clean API for recording various agent metrics
    without needing to work with raw Prometheus counters/gauges.

    Example:
        recorder = MetricsRecorder()
        recorder.record_request("success")
        recorder.record_tokens("claude-3", input_tokens=500, output_tokens=200)
        recorder.record_cost("claude-3", 0.015)
    """

    def record_request(
        self,
        outcome: str,
        error_type: str = "none",
    ) -> None:
        """Record an agent request.

        Args:
            outcome: Request outcome (success, failure, timeout).
            error_type: Type of error if failed, "none" otherwise.
        """
        agent_requests_total.labels(
            outcome=_normalize_label(outcome, ALLOWED_OUTCOMES),
            error_type=_normalize_label(error_type, ALLOWED_ERROR_TYPES),
        ).inc()

    def record_duration(self, duration_seconds: float) -> None:
        """Record request duration.

        Args:
            duration_seconds: Duration in seconds.
        """
        agent_request_duration.observe(duration_seconds)

    def record_tokens(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> None:
        """Record token usage.

        Args:
            model: Model name (e.g., "claude-3-sonnet").
            input_tokens: Number of input tokens.
            output_tokens: Number of output tokens.
        """
        safe_model = _normalize_label(model, KNOWN_MODELS)
        tokens_used_total.labels(model=safe_model, type="input").inc(input_tokens)
        tokens_used_total.labels(model=safe_model, type="output").inc(output_tokens)

    def record_tool_call(self, tool_name: str, outcome: str) -> None:
        """Record a tool invocation.

        Args:
            tool_name: Name of the tool called.
            outcome: Call outcome (success, failure, timeout).
        """
        tool_calls_total.labels(
            tool_name=_normalize_label(tool_name, KNOWN_TOOLS),
            outcome=_normalize_label(outcome, ALLOWED_OUTCOMES),
        ).inc()

    def record_tool_approval_rate(self, tool_name: str, rate: float) -> None:
        """Set the approval rate for a tool.

        Args:
            tool_name: Name of the tool.
            rate: Approval rate (0.0 to 1.0).
        """
        tool_approval_rate.labels(
            tool_name=_normalize_label(tool_name, KNOWN_TOOLS)
        ).set(rate)

    def record_memory_recall(self, duration_seconds: float) -> None:
        """Record memory recall latency.

        Args:
            duration_seconds: Recall duration in seconds.
        """
        memory_recall_duration.observe(duration_seconds)

    def record_cost(self, model: str, cost_usd: float) -> None:
        """Record estimated API cost.

        Args:
            model: Model name.
            cost_usd: Cost in USD.
        """
        estimated_cost_usd.labels(model=_normalize_label(model, KNOWN_MODELS)).inc(
            cost_usd
        )

    def record_approval_request(self, risk_level: str) -> None:
        """Record an approval request.

        Args:
            risk_level: Risk level (low, medium, high, critical).
        """
        approval_requests_total.labels(
            risk_level=_normalize_label(risk_level, ALLOWED_RISK_LEVELS)
        ).inc()

    def record_blocked_action(self, tool_name: str, reason: str) -> None:
        """Record a blocked action.

        Args:
            tool_name: Name of the blocked tool.
            reason: Reason for blocking (normalized to allowed values).
        """
        blocked_actions_total.labels(
            tool_name=_normalize_label(tool_name, KNOWN_TOOLS),
            reason=_normalize_label(reason, ALLOWED_BLOCK_REASONS, fallback="unknown"),
        ).inc()

    def set_active_sessions(self, count: int) -> None:
        """Set the number of active sessions.

        Args:
            count: Number of active sessions.
        """
        active_sessions.set(count)

    def increment_active_sessions(self) -> None:
        """Increment active session count."""
        active_sessions.inc()

    def decrement_active_sessions(self) -> None:
        """Decrement active session count."""
        active_sessions.dec()
