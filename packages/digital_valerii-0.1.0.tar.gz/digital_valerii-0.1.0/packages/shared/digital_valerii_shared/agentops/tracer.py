"""Agent tracing with concurrency-safe context management.

Component 6.5: AgentOps Framework
Collects and stores agent traces using ContextVar for async safety.
"""

import asyncio
import copy
import logging
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Protocol
from uuid import UUID

from .models import AgentTrace, TraceEvent, TraceEventType
from .sanitizer import TraceSanitizer

logger = logging.getLogger(__name__)

# Thread/task-local storage for current trace
_current_trace: ContextVar[AgentTrace | None] = ContextVar(
    "current_trace", default=None
)


class TraceStore(Protocol):
    """Protocol for trace storage backends.

    Implementations may use databases, object storage, or
    observability platforms (Jaeger, Honeycomb, etc.).
    """

    async def save(self, trace: AgentTrace) -> None:
        """Save a completed trace.

        Args:
            trace: The trace to save.
        """
        ...

    async def get(self, trace_id: UUID) -> AgentTrace | None:
        """Retrieve a trace by ID.

        Args:
            trace_id: The trace ID to look up.

        Returns:
            The trace if found, None otherwise.
        """
        ...

    async def list_by_session(
        self, session_id: UUID, limit: int = 100
    ) -> list[AgentTrace]:
        """List traces for a session.

        Args:
            session_id: Session ID to filter by.
            limit: Maximum number of traces to return.

        Returns:
            List of traces for the session.
        """
        ...


class AgentTracer:
    """Collects and stores agent traces (concurrency-safe via ContextVar).

    This tracer uses Python's ContextVar to maintain separate trace
    contexts for each asyncio task, ensuring thread-safe operation
    in concurrent environments.

    Example:
        tracer = AgentTracer(store=my_store)

        trace = tracer.start_trace(session_id=session.id, user_id=user.id)

        tracer.add_event(
            TraceEventType.TOOL_CALL,
            {"tool": "search", "query": "hello"},
            duration_ms=150,
        )

        await tracer.complete_trace("success")
    """

    def __init__(
        self,
        store: TraceStore,
        sanitizer: TraceSanitizer | None = None,
    ):
        """Initialize the tracer.

        Args:
            store: Backend for persisting traces.
            sanitizer: Optional sanitizer for PII redaction.
                       Creates a default one if not provided.
        """
        self._store = store
        self._sanitizer = sanitizer or TraceSanitizer()

    def start_trace(
        self,
        session_id: UUID,
        user_id: UUID | None = None,
    ) -> AgentTrace:
        """Start a new trace for an agent interaction (context-local).

        Creates a new trace and sets it as the current trace for this
        asyncio task/context.

        Args:
            session_id: Session this trace belongs to.
            user_id: User ID for multi-tenancy.

        Returns:
            The new trace.
        """
        trace = AgentTrace(session_id=session_id, user_id=user_id)
        _current_trace.set(trace)
        return trace

    def get_current_trace(self) -> AgentTrace | None:
        """Get the current trace from context.

        Returns:
            The current trace, or None if no active trace.
        """
        return _current_trace.get()

    def add_event(
        self,
        event_type: TraceEventType,
        data: dict,
        parent_event_id: UUID | None = None,
        duration_ms: int = 0,
    ) -> TraceEvent:
        """Add event to current trace (fails fast if no active trace).

        Args:
            event_type: Type of event.
            data: Event data (will be sanitized).
            parent_event_id: Optional parent event for hierarchical tracing.
            duration_ms: Event duration in milliseconds.

        Returns:
            The created event.

        Raises:
            RuntimeError: If no active trace.
        """
        trace = _current_trace.get()
        if trace is None:
            raise RuntimeError("No active trace. Call start_trace() first.")

        # Sanitize data before storing
        sanitized_data = self._sanitizer.sanitize(data)

        event = TraceEvent(
            trace_id=trace.id,
            event_type=event_type,
            data=sanitized_data,
            parent_event_id=parent_event_id,
            duration_ms=duration_ms,
        )
        trace.events.append(event)
        return event

    async def _save_trace(self, trace: AgentTrace) -> None:
        """Save trace with error handling (FIX-6.5.2).

        Args:
            trace: The trace snapshot to save.
        """
        try:
            await self._store.save(trace)
        except Exception:
            logger.exception(
                "Failed to save trace",
                extra={"trace_id": str(trace.id)},
            )

    async def complete_trace(
        self,
        outcome: str,
        total_tokens: int = 0,
        total_cost_usd: float = 0.0,
    ) -> None:
        """Complete and store the trace asynchronously.

        Sets the outcome and completion time, then fires off a
        background task to persist the trace (non-blocking).

        FIX-6.5.2: Snapshots the trace before saving to avoid race conditions
        with concurrent tasks that may mutate the trace.

        Args:
            outcome: Outcome of the trace (success, failure, timeout).
            total_tokens: Total tokens consumed.
            total_cost_usd: Estimated cost in USD.
        """
        trace = _current_trace.get()
        if trace is None:
            return

        trace.outcome = outcome
        trace.completed_at = datetime.now(UTC)
        trace.total_tokens = total_tokens
        trace.total_cost_usd = total_cost_usd

        # FIX-6.5.2: Snapshot to avoid race conditions with concurrent mutations
        snapshot = copy.deepcopy(trace)

        # Clear context BEFORE scheduling save to prevent further mutations
        _current_trace.set(None)

        # Fire-and-forget with error handling
        asyncio.create_task(self._save_trace(snapshot))

    def clear_trace(self) -> None:
        """Clear the current trace without saving.

        Use this to abandon a trace, e.g., on errors where
        you don't want to persist incomplete data.
        """
        _current_trace.set(None)
