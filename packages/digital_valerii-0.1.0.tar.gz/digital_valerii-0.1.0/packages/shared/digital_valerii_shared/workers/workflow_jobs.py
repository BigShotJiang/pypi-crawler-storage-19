"""Workflow execution jobs for arq worker.

Component 4.11: Orchestration Patterns
Workflows run inside Arq jobs for:
- Durability: Job survives worker restart
- Observability: Arq provides job metrics
- Retry: Built-in retry with exponential backoff
- Concurrency: Worker pool manages parallelism
"""

import json
import re
import time
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession

from ..models.workflow import WorkflowExecution
from ..workflows.base import WorkflowContext
from ..workflows.registry import get_workflow

logger = structlog.get_logger(__name__)


class WorkflowJobPayload(BaseModel):
    """Validated payload for workflow job execution.

    Provides type validation and size limits to prevent
    malicious/malformed payloads from causing issues.
    """

    model_config = ConfigDict(extra="forbid")

    workflow_id: UUID
    workflow_type: str = Field(..., min_length=1, max_length=100)
    initial_data: dict[str, Any] = Field(default_factory=dict)
    user_id: UUID
    project_id: UUID | None = None

    @field_validator("initial_data")
    @classmethod
    def validate_initial_data_size(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Limit initial_data size to prevent DoS."""
        serialized = json.dumps(v)
        max_size = 1024 * 1024  # 1MB limit
        if len(serialized) > max_size:
            raise ValueError(f"initial_data exceeds {max_size} bytes")
        return v


def _sanitize_error(error: Exception) -> str:
    """Sanitize error message for external consumers.

    Removes potential secrets/PII from error messages.
    Full details are logged, but sanitized version is stored/emitted.

    Args:
        error: The exception to sanitize.

    Returns:
        Sanitized error message safe for external storage/transmission.
    """
    error_type = type(error).__name__

    # List of known safe error types that can be passed through
    safe_errors = (
        "WorkflowError",
        "ValueError",
        "TypeError",
        "KeyError",
        "AttributeError",
        "ValidationError",
    )

    if error_type in safe_errors:
        # Still sanitize: remove anything that looks like a secret
        message = str(error)
        # Remove potential API keys, tokens, passwords
        message = re.sub(
            r'(api[_-]?key|token|password|secret|credential)["\']?\s*[:=]\s*["\']?[^\s"\']+',
            r"\1=[REDACTED]",
            message,
            flags=re.IGNORECASE,
        )
        return f"{error_type}: {message}"

    # For unknown errors, only return type
    return f"{error_type}: An error occurred (details logged)"


def _record_metrics(ctx: dict[str, Any], success: bool, start_time: float) -> None:
    """Record job execution metrics."""
    health_metrics = ctx.get("health_metrics")
    if health_metrics:
        duration_ms = (time.time() - start_time) * 1000
        health_metrics.record_job(success, duration_ms)


async def execute_workflow_job(
    ctx: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Execute a workflow inside an Arq job.

    This job wraps workflow execution with:
    - Database persistence of execution state
    - Error handling and status updates
    - Event emission on completion/failure
    - Metrics recording

    Args:
        ctx: Arq context with db session, event_bus, etc.
        payload: {
            "workflow_id": "uuid",
            "workflow_type": "registered_name",
            "initial_data": {},
            "user_id": "uuid",
            "project_id": "uuid or null"
        }

    Returns:
        {"status": "completed|failed", "result": {...}, "error": "..."}
    """
    start_time = time.time()
    success = False
    db: AsyncSession = ctx["db"]

    # Validate payload INSIDE try/except to handle malformed input
    try:
        validated = WorkflowJobPayload.model_validate(payload)
    except Exception as e:
        await logger.aerror(
            "Invalid workflow payload",
            error=str(e),
            payload_keys=list(payload.keys()) if isinstance(payload, dict) else None,
        )
        _record_metrics(ctx, False, start_time)
        return {
            "status": "failed",
            "error": f"Invalid payload: {type(e).__name__}",
        }

    # Use validated fields
    workflow_id = validated.workflow_id
    workflow_type = validated.workflow_type
    initial_data = validated.initial_data
    user_id = validated.user_id
    project_id = validated.project_id

    # Create execution record
    execution = WorkflowExecution(
        id=workflow_id,
        user_id=user_id,
        project_id=project_id,
        workflow_type=workflow_type,
        status="running",
        context=initial_data,
    )
    db.add(execution)
    await db.commit()

    await logger.ainfo(
        "Starting workflow execution",
        workflow_id=str(workflow_id),
        workflow_type=workflow_type,
        user_id=str(user_id),
    )

    try:
        # Load and run workflow
        workflow_cls = get_workflow(workflow_type)
        workflow = workflow_cls()

        context = WorkflowContext(
            workflow_id=workflow_id,
            user_id=user_id,
            project_id=project_id,
            data=initial_data,
        )

        result = await workflow.run(context)

        # Update execution record
        await db.refresh(execution)
        execution.status = "completed"
        execution.completed_at = datetime.now(UTC)
        execution.result = result.data
        await db.commit()

        await logger.ainfo(
            "Workflow execution completed",
            workflow_id=str(workflow_id),
            workflow_type=workflow_type,
        )

        # Emit completion event
        event_bus = ctx.get("event_bus")
        if event_bus:
            await event_bus.emit(
                "workflow.completed",
                {
                    "workflow_id": str(workflow_id),
                    "workflow_type": workflow_type,
                    "user_id": str(user_id),
                    "result": result.data,
                },
            )

        success = True
        return {"status": "completed", "result": result.data}

    except Exception as e:
        # Log full error internally (for debugging)
        await logger.aerror(
            "Workflow execution failed",
            workflow_id=str(workflow_id),
            workflow_type=workflow_type,
            error=str(e),
            error_type=type(e).__name__,
            exc_info=True,
        )

        # Sanitize error for external consumers (DB, events, return)
        sanitized_error = _sanitize_error(e)

        # Update execution record with failure
        await db.refresh(execution)
        execution.status = "failed"
        execution.completed_at = datetime.now(UTC)
        execution.error = sanitized_error
        await db.commit()

        # Emit failure event with sanitized error
        event_bus = ctx.get("event_bus")
        if event_bus:
            await event_bus.emit(
                "workflow.failed",
                {
                    "workflow_id": str(workflow_id),
                    "workflow_type": workflow_type,
                    "user_id": str(user_id),
                    "error": sanitized_error,
                },
            )

        return {"status": "failed", "error": sanitized_error}

    finally:
        _record_metrics(ctx, success, start_time)


async def cancel_workflow_job(
    ctx: dict[str, Any],
    payload: dict[str, Any],
) -> dict[str, Any]:
    """Cancel a running workflow.

    Args:
        ctx: Arq context with db session.
        payload: {"workflow_id": "uuid", "user_id": "uuid"}

    Returns:
        {"status": "cancelled|not_found|error"}
    """
    workflow_id = UUID(payload["workflow_id"])
    user_id = UUID(payload["user_id"])
    db: AsyncSession = ctx["db"]

    from sqlalchemy import select

    result = await db.execute(
        select(WorkflowExecution).where(
            WorkflowExecution.id == workflow_id,
            WorkflowExecution.user_id == user_id,
        )
    )
    execution = result.scalar_one_or_none()

    if not execution:
        return {"status": "not_found"}

    if execution.status != "running":
        return {"status": "not_running", "current_status": execution.status}

    execution.status = "cancelled"
    execution.completed_at = datetime.now(UTC)
    await db.commit()

    await logger.ainfo(
        "Workflow cancelled",
        workflow_id=str(workflow_id),
        user_id=str(user_id),
    )

    return {"status": "cancelled"}
