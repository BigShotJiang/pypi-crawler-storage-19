"""Background worker infrastructure for Digital Valerii.

This package provides async job processing using arq:
- BackgroundWorker: Main worker class with dependency injection
- WorkerSettings: arq configuration for worker processes
- Job definitions: Individual job functions for background tasks

Usage:
    # Start worker process
    arq packages.shared.digital_valerii_shared.workers.WorkerSettings

    # Start scheduler (for cron jobs)
    arq packages.shared.digital_valerii_shared.workers.WorkerSettings --watch
"""

from packages.shared.digital_valerii_shared.workers.jobs import (
    cleanup_expired_approvals,
    cleanup_orphaned_outbox,
    cross_store_deletion,
    extract_lessons,
    generate_embeddings,
    hard_delete_expired,
    process_meeting_transcript,
    sync_qdrant_outbox,
)
from packages.shared.digital_valerii_shared.workers.worker import (
    BackgroundWorker,
    WorkerSettings,
)
from packages.shared.digital_valerii_shared.workers.workflow_jobs import (
    cancel_workflow_job,
    execute_workflow_job,
)

__all__ = [
    # Worker classes
    "BackgroundWorker",
    "WorkerSettings",
    # Job functions
    "cleanup_expired_approvals",
    "cleanup_orphaned_outbox",
    "cross_store_deletion",
    "extract_lessons",
    "generate_embeddings",
    "hard_delete_expired",
    "process_meeting_transcript",
    "sync_qdrant_outbox",
    # Workflow jobs (Component 4.11)
    "cancel_workflow_job",
    "execute_workflow_job",
]
