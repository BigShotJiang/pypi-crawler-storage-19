"""Background worker process management for arq."""

import signal
from datetime import datetime, timedelta
from typing import Any
from urllib.parse import urlparse

import structlog
from arq.connections import RedisSettings as ArqRedisSettings
from arq.cron import cron

from packages.shared.digital_valerii_shared.config import (
    RedisSettings,
)
from packages.shared.digital_valerii_shared.config import (
    WorkerSettings as WorkerConfig,
)

logger = structlog.get_logger(__name__)


# =============================================================================
# Exceptions
# =============================================================================


class WorkerError(Exception):
    """Worker process error."""

    pass


class WorkerShutdownError(WorkerError):
    """Worker shutdown error."""

    pass


# =============================================================================
# Worker Health
# =============================================================================


class WorkerHealthMetrics:
    """Tracks worker health and job execution metrics."""

    def __init__(self) -> None:
        """Initialize health metrics."""
        self.jobs_completed: int = 0
        self.jobs_failed: int = 0
        self.total_duration_ms: float = 0.0
        self.last_job_at: datetime | None = None
        self.started_at: datetime = datetime.utcnow()

    def record_job(self, success: bool, duration_ms: float) -> None:
        """Record job execution metrics.

        Args:
            success: Whether job completed successfully.
            duration_ms: Job duration in milliseconds.
        """
        if success:
            self.jobs_completed += 1
        else:
            self.jobs_failed += 1
        self.total_duration_ms += duration_ms
        self.last_job_at = datetime.utcnow()

    def to_dict(self) -> dict[str, Any]:
        """Convert metrics to dictionary.

        Returns:
            Dict with health metrics.
        """
        total_jobs = self.jobs_completed + self.jobs_failed
        avg_duration = self.total_duration_ms / total_jobs if total_jobs > 0 else 0.0

        return {
            "status": "healthy",
            "uptime_seconds": (datetime.utcnow() - self.started_at).total_seconds(),
            "jobs_completed": self.jobs_completed,
            "jobs_failed": self.jobs_failed,
            "total_jobs": total_jobs,
            "avg_duration_ms": avg_duration,
            "last_job_at": self.last_job_at.isoformat() if self.last_job_at else None,
        }


# Global health metrics instance (used by worker context)
_health_metrics = WorkerHealthMetrics()


def get_health_metrics() -> WorkerHealthMetrics:
    """Get the global health metrics instance.

    Returns:
        WorkerHealthMetrics instance.
    """
    return _health_metrics


# =============================================================================
# Background Worker
# =============================================================================


class BackgroundWorker:
    """Background worker process with dependency injection.

    Manages database, Redis, Qdrant, and embedding service connections
    for job execution. Handles graceful shutdown on SIGTERM/SIGINT.

    Example:
        worker = BackgroundWorker(db, qdrant, redis, embedding_service)
        await worker.startup()

        # Jobs use worker.ctx to access services
        # worker.ctx["db"], worker.ctx["redis"], etc.

        await worker.shutdown()
    """

    def __init__(
        self,
        db: Any = None,
        qdrant: Any = None,
        redis: Any = None,
        embedding_service: Any = None,
    ) -> None:
        """Initialize worker with service dependencies.

        Args:
            db: AsyncSession or database connection.
            qdrant: QdrantService instance.
            redis: RedisService instance.
            embedding_service: EmbeddingService instance.
        """
        self.db = db
        self.qdrant = qdrant
        self.redis = redis
        self.embedding_service = embedding_service
        self._shutdown_requested = False
        self._current_jobs: set[str] = set()

    @property
    def ctx(self) -> dict[str, Any]:
        """Get worker context with all services.

        Returns:
            Dict with service references for job functions.
        """
        return {
            "db": self.db,
            "qdrant": self.qdrant,
            "redis": self.redis,
            "embedding_service": self.embedding_service,
            "health_metrics": _health_metrics,
        }

    async def startup(self) -> None:
        """Initialize worker and setup signal handlers.

        Sets up SIGTERM and SIGINT handlers for graceful shutdown.
        """
        # Register signal handlers
        signal.signal(signal.SIGTERM, self._handle_shutdown_signal)
        signal.signal(signal.SIGINT, self._handle_shutdown_signal)

        await logger.ainfo("Background worker started")

    async def shutdown(self) -> None:
        """Graceful shutdown - wait for in-progress jobs.

        Waits for all current jobs to complete before exiting.
        Logs shutdown status.
        """
        self._shutdown_requested = True

        if self._current_jobs:
            await logger.ainfo(
                "Waiting for in-progress jobs",
                job_count=len(self._current_jobs),
            )

        # Wait for jobs to complete (handled by arq)
        await logger.ainfo(
            "Worker shutdown complete",
            jobs_completed=_health_metrics.jobs_completed,
            jobs_failed=_health_metrics.jobs_failed,
        )

    def _handle_shutdown_signal(self, signum: int, _frame: Any) -> None:
        """Handle shutdown signals.

        Args:
            signum: Signal number.
            _frame: Current stack frame (unused).
        """
        self._shutdown_requested = True
        logger.info("Shutdown signal received", signal=signum)

    def track_job_start(self, job_id: str) -> None:
        """Track job start for graceful shutdown.

        Args:
            job_id: The job identifier.
        """
        self._current_jobs.add(job_id)

    def track_job_end(self, job_id: str) -> None:
        """Track job completion.

        Args:
            job_id: The job identifier.
        """
        self._current_jobs.discard(job_id)

    @property
    def is_shutting_down(self) -> bool:
        """Check if shutdown was requested.

        Returns:
            True if shutdown signal received.
        """
        return self._shutdown_requested

    def health_check(self) -> dict[str, Any]:
        """Get worker health status.

        Returns:
            Dict with health metrics.
        """
        metrics = _health_metrics.to_dict()
        metrics["in_progress_jobs"] = len(self._current_jobs)
        metrics["shutdown_requested"] = self._shutdown_requested
        return metrics


# =============================================================================
# arq Worker Settings
# =============================================================================


def get_arq_redis_settings() -> ArqRedisSettings:
    """Get arq Redis settings from environment.

    Properly handles:
    - redis:// and rediss:// (TLS) schemes
    - username:password authentication (ACL)
    - database selection

    Returns:
        ArqRedisSettings configured from RedisSettings.
    """
    settings = RedisSettings()
    url = settings.url
    parsed = urlparse(url)

    # Determine if SSL/TLS is required
    ssl = parsed.scheme == "rediss"

    # Extract components
    host = parsed.hostname or "localhost"
    port = parsed.port or 6379
    database = int(parsed.path.lstrip("/") or 0) if parsed.path else 0
    password = parsed.password
    username = parsed.username  # For Redis ACL

    return ArqRedisSettings(
        host=host,
        port=port,
        database=database,
        password=password,
        username=username,
        ssl=ssl,
    )


async def startup(ctx: dict[str, Any]) -> None:
    """arq startup function - initialize worker context.

    Args:
        ctx: arq context dictionary.
    """
    # Create worker instance
    worker = BackgroundWorker()
    await worker.startup()

    # Store in context
    ctx["worker"] = worker
    ctx["health_metrics"] = _health_metrics

    await logger.ainfo("arq worker startup complete")


async def shutdown(ctx: dict[str, Any]) -> None:
    """arq shutdown function - cleanup resources.

    Args:
        ctx: arq context dictionary.
    """
    worker = ctx.get("worker")
    if worker:
        await worker.shutdown()

    await logger.ainfo("arq worker shutdown complete")


async def on_job_start(ctx: dict[str, Any]) -> None:
    """arq hook called before each job starts.

    Tracks job start for graceful shutdown handling.

    Args:
        ctx: arq context dictionary with job_id.
    """
    worker = ctx.get("worker")
    job_id = ctx.get("job_id")
    if worker and job_id:
        worker.track_job_start(job_id)


async def on_job_end(ctx: dict[str, Any]) -> None:
    """arq hook called after each job completes.

    Tracks job completion for graceful shutdown handling.

    Args:
        ctx: arq context dictionary with job_id.
    """
    worker = ctx.get("worker")
    job_id = ctx.get("job_id")
    if worker and job_id:
        worker.track_job_end(job_id)


# Import job functions for registration
from packages.shared.digital_valerii_shared.workers.jobs import (  # noqa: E402
    cleanup_expired_approvals,
    annual_archive,
    cleanup_orphaned_outbox,
    cross_store_deletion,
    execute_scheduled_task,
    extract_lessons,
    generate_embeddings,
    hard_delete_expired,
    process_meeting_transcript,
    requeue_stuck_messages,
    sync_qdrant_outbox,
)


class WorkerSettings:
    """arq worker settings configuration.

    This class is used by arq to configure the worker process.

    Usage:
        arq packages.shared.digital_valerii_shared.workers.WorkerSettings
    """

    # Redis connection
    redis_settings = get_arq_redis_settings()

    # Job functions to register
    functions = [
        annual_archive,
        extract_lessons,
        sync_qdrant_outbox,
        generate_embeddings,
        process_meeting_transcript,
        cross_store_deletion,
        hard_delete_expired,
        cleanup_orphaned_outbox,
        cleanup_expired_approvals,
        execute_scheduled_task,
        requeue_stuck_messages,
    ]

    # Cron jobs (scheduled tasks)
    cron_jobs = [
        # Sync Qdrant outbox every 15 minutes
        cron(
            sync_qdrant_outbox,
            minute={0, 15, 30, 45},
            run_at_startup=True,
        ),
        # Cleanup expired approvals every 30 minutes
        cron(
            cleanup_expired_approvals,
            minute={0, 30},
        ),
        # Hard delete expired records daily at 3 AM
        cron(
            hard_delete_expired,
            hour=3,
            minute=0,
        ),
        # Cleanup orphaned outbox entries daily at 2 AM
        cron(
            cleanup_orphaned_outbox,
            hour=2,
            minute=0,
        ),
        # Requeue stuck session messages every 2 minutes (FIX-4.8.2)
        cron(
            requeue_stuck_messages,
            minute={0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58},
        ),
        # Annual archive job - runs January 1st at 4 AM (FIX-4.9.3)
        cron(
            annual_archive,
            month=1,
            day=1,
            hour=4,
            minute=0,
        ),
    ]

    # Worker configuration from settings
    _config = WorkerConfig()

    # Max concurrent jobs
    max_jobs = _config.max_jobs

    # Job timeout in seconds (10 minutes default)
    job_timeout = timedelta(seconds=_config.job_timeout)

    # Max retry attempts
    max_tries = _config.max_tries

    # Delay between retries
    retry_delay = timedelta(seconds=_config.retry_delay)

    # Lifecycle hooks
    on_startup = startup
    on_shutdown = shutdown

    # Job lifecycle hooks for tracking in-progress jobs
    on_job_start = on_job_start
    on_job_end = on_job_end

    # Queue names to consume from
    queue_name = "dv:jobs:default"

    # Additional queues
    queues = [
        "dv:jobs:high",
        "dv:jobs:default",
        "dv:jobs:low",
        "dv:jobs:scheduled",
    ]
