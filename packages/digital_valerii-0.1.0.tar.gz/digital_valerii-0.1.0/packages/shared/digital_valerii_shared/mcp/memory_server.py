"""Memory MCP Server using FastMCP.

This module provides the FastMCP server that exposes memory tools
from Component 1.5 (MemoryManager) via Model Context Protocol.

Usage:
    python -m digital_valerii_shared.mcp.memory_server

Or configure in .mcp.json:
    {
        "mcpServers": {
            "memory": {
                "command": "python",
                "args": ["-m", "digital_valerii_shared.mcp.memory_server"]
            }
        }
    }
"""

from __future__ import annotations

import asyncio
import logging

from mcp.server.fastmcp import FastMCP

from .memory_schemas import (
    HealthCheckInput,
    MemoryRecallInput,
    MemoryStoreInput,
    PeopleSearchInput,
    PersonGetInput,
    ProjectGetInput,
    ProjectSearchInput,
    WorkingMemoryGetInput,
    WorkingMemoryUpdateInput,
)
from .memory_tools import (
    configure_memory_manager,
    memory_health_impl,
    memory_people_get_impl,
    memory_people_search_impl,
    memory_projects_get_impl,
    memory_projects_search_impl,
    memory_recall_impl,
    memory_store_impl,
    memory_working_get_impl,
    memory_working_update_impl,
)

logger = logging.getLogger(__name__)

# =============================================================================
# FastMCP Server Instance
# =============================================================================

mcp = FastMCP(
    "memory_mcp",
    description="Digital Valerii Memory System - Semantic search, storage, and management of memories",
)


# =============================================================================
# Tool Registrations
# =============================================================================


@mcp.tool(
    name="memory_recall",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_recall(params: MemoryRecallInput) -> str:
    """Search and retrieve relevant memories based on query.

    This tool performs hybrid search across PostgreSQL and Qdrant to find
    memories relevant to the query. Results include events, people, projects,
    and lessons, ranked by relevance with time decay.

    Args:
        params: Search parameters including query, session_id, and limits.

    Returns:
        JSON string with matching memories including events, people, projects,
        and lessons ranked by relevance.
    """
    return await memory_recall_impl(params)


@mcp.tool(
    name="memory_store",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def memory_store(params: MemoryStoreInput) -> str:
    """Store an interaction in memory.

    This tool stores a user message and agent response pair in the memory
    system with embeddings for future semantic search.

    Args:
        params: Store parameters including user_message, agent_response,
                session_id, and optional metadata.

    Returns:
        JSON string with store result including event_id and stored_at timestamp.
    """
    return await memory_store_impl(params)


@mcp.tool(
    name="memory_working_get",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_working_get(params: WorkingMemoryGetInput) -> str:
    """Get current session working memory.

    This tool retrieves the working memory for a given session, including
    recent messages and context data stored in Redis.

    Args:
        params: Parameters with session_id to retrieve.

    Returns:
        JSON string with working memory including messages and context.
    """
    return await memory_working_get_impl(params)


@mcp.tool(
    name="memory_working_update",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def memory_working_update(params: WorkingMemoryUpdateInput) -> str:
    """Update session working memory.

    This tool updates the working memory for a session, merging context
    data and optionally replacing messages.

    Args:
        params: Update parameters with session_id, optional messages,
                and optional context data.

    Returns:
        JSON string with updated working memory state.
    """
    return await memory_working_update_impl(params)


@mcp.tool(
    name="memory_people_search",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_people_search(params: PeopleSearchInput) -> str:
    """Search for people in memory by name, email, or company.

    This tool searches the people database using pattern matching
    against name, email, and company fields.

    Args:
        params: Search parameters with query string and limit.

    Returns:
        JSON string with list of matching people.
    """
    return await memory_people_search_impl(params)


@mcp.tool(
    name="memory_people_get",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_people_get(params: PersonGetInput) -> str:
    """Get detailed information about a specific person.

    This tool retrieves full details for a person by their UUID.

    Args:
        params: Parameters with person_id (UUID).

    Returns:
        JSON string with person details or error if not found.
    """
    return await memory_people_get_impl(params)


@mcp.tool(
    name="memory_projects_search",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_projects_search(params: ProjectSearchInput) -> str:
    """Search for projects in memory by name or description.

    This tool searches the projects database using pattern matching
    against name and description fields.

    Args:
        params: Search parameters with query string and limit.

    Returns:
        JSON string with list of matching projects.
    """
    return await memory_projects_search_impl(params)


@mcp.tool(
    name="memory_projects_get",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_projects_get(params: ProjectGetInput) -> str:
    """Get detailed information about a specific project.

    This tool retrieves full details for a project by its UUID.

    Args:
        params: Parameters with project_id (UUID).

    Returns:
        JSON string with project details or error if not found.
    """
    return await memory_projects_get_impl(params)


@mcp.tool(
    name="memory_health",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def memory_health(params: HealthCheckInput) -> str:
    """Check health of all memory system components.

    This tool checks the health of PostgreSQL, Qdrant, Redis, and
    embedding service backends.

    Args:
        params: Empty input (no parameters required).

    Returns:
        JSON string with health status of each component.
    """
    return await memory_health_impl(params)


# =============================================================================
# Server Initialization
# =============================================================================


async def initialize_memory_manager() -> None:
    """Initialize the memory manager from environment variables.

    This function creates a MemoryManager instance using configuration
    from environment variables and configures it for use by all tools.
    """
    # Only initialize if not already configured (for testing)
    from .memory_tools import get_memory_manager

    try:
        get_memory_manager()
        logger.info("Memory manager already configured")
        return
    except RuntimeError:
        pass  # Not configured yet, proceed with initialization

    # Import here to avoid circular imports
    from digital_valerii_shared.config import (
        DatabaseSettings,
        EmbeddingSettings,
        QdrantSettings,
        RedisSettings,
    )
    from digital_valerii_shared.database import Database
    from digital_valerii_shared.services.embedding import EmbeddingService
    from digital_valerii_shared.services.memory import MemoryManager
    from digital_valerii_shared.services.qdrant import QdrantService
    from digital_valerii_shared.services.redis import RedisService

    # Create settings from environment variables
    # Settings classes use validation_alias to read from env vars
    try:
        db_settings = DatabaseSettings()
        qdrant_settings = QdrantSettings()
        redis_settings = RedisSettings()
        embedding_settings = EmbeddingSettings()
    except Exception as e:
        logger.exception("Failed to load settings from environment")
        raise RuntimeError(
            "Failed to initialize memory manager: missing environment variables"
        ) from e

    # Create service instances
    db = Database(db_settings)
    qdrant = QdrantService(qdrant_settings)
    redis = RedisService(redis_settings)
    embedding = EmbeddingService(embedding_settings, redis=redis)

    # Create memory manager with service instances
    manager = MemoryManager(
        db=db,
        qdrant=qdrant,
        redis=redis,
        embedding=embedding,
    )

    configure_memory_manager(manager)
    logger.info("Memory manager initialized successfully")


def main() -> None:
    """Run the MCP server.

    This is the entry point when running as a module:
        python -m digital_valerii_shared.mcp.memory_server
    """
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    logger.info("Starting Memory MCP Server")

    # Initialize memory manager before starting server
    try:
        asyncio.get_event_loop().run_until_complete(initialize_memory_manager())
    except RuntimeError:
        # No event loop exists yet, create one
        asyncio.run(initialize_memory_manager())

    # Run the FastMCP server
    mcp.run()


if __name__ == "__main__":
    main()
