# Digital Valerii MCP Package

Model Context Protocol (MCP) servers for Digital Valerii AI Clone system.

## Memory MCP Server

Custom MCP server wrapping the Memory Layer (Component 1.5).

### Tools

| Tool | Type | Description |
|------|------|-------------|
| `memory_recall` | Read | Search memories by semantic query |
| `memory_store` | Write | Store interaction in memory |
| `memory_working_get` | Read | Get session working memory |
| `memory_working_update` | Write | Update working memory |
| `memory_people_search` | Read | Search people by name/email |
| `memory_people_get` | Read | Get person details |
| `memory_projects_search` | Read | Search projects |
| `memory_projects_get` | Read | Get project details |
| `memory_health` | Read | Check system health |

### Usage

```bash
# Run as module
python -m digital_valerii_shared.mcp.memory_server

# With environment variables
DATABASE_URL=postgresql://... \
QDRANT_URL=http://localhost:6333 \
REDIS_URL=redis://localhost:6379 \
OPENAI_API_KEY=sk-... \
python -m digital_valerii_shared.mcp.memory_server
```

### Configuration

Add to `.mcp.json`:

```json
{
  "mcpServers": {
    "memory": {
      "command": "python",
      "args": ["-m", "digital_valerii_shared.mcp.memory_server"]
    }
  }
}
```

## External MCP Servers

### Playwright (Browser Automation)

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    }
  }
}
```

### macOS Office (Local Only)

Requires macOS with Office apps installed.

```json
{
  "mcpServers": {
    "office": {
      "command": "python",
      "args": ["-m", "macos_office365_mcp.server"]
    }
  }
}
```

**macOS Permissions:**

1. System Preferences → Privacy & Security → Privacy
2. Select "Automation"
3. Enable: Microsoft Word, Excel, PowerPoint

## Programmatic Usage

```python
from digital_valerii_shared.agent.core import AgentOptionsBuilder, MCPServerConfig

# Configure MCP servers
mcp_config = MCPServerConfig(
    enable_memory=True,
    enable_browser=True,
    enable_local_office=True,  # macOS only
)

# Create builder with MCP config
builder = AgentOptionsBuilder(
    personality_manager=personality,
    mcp_config=mcp_config,
)

# Build options includes MCP servers
options = builder.build(context)
print(options["mcp_servers"])
```

## Testing

```bash
# Run MCP tests
pytest packages/shared/digital_valerii_shared/mcp/tests/ -v
```
