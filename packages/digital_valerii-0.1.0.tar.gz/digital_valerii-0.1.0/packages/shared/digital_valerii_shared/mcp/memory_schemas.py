"""Pydantic schemas for Memory MCP Server.

This module provides input and output models for all memory tools
with proper validation, constraints, and documentation.
"""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

# =============================================================================
# Common Configuration
# =============================================================================

SCHEMA_CONFIG = ConfigDict(
    str_strip_whitespace=True,
    validate_assignment=True,
    extra="forbid",
)


# =============================================================================
# Tool Response Wrapper
# =============================================================================


class ToolResponse(BaseModel):
    """Standard response wrapper for all MCP tools."""

    model_config = SCHEMA_CONFIG

    success: bool = True
    data: Any | None = None
    error: str | None = None


# =============================================================================
# Input Schemas
# =============================================================================


class MemoryRecallInput(BaseModel):
    """Input for memory_recall tool."""

    model_config = SCHEMA_CONFIG

    query: str = Field(
        ...,
        description="Search query for relevant memories",
        min_length=1,
        max_length=1000,
    )
    session_id: str = Field(
        default="default",
        description="Session identifier for context",
        min_length=1,
        max_length=100,
    )
    conversation_id: str | None = Field(
        default=None,
        description="Optional conversation ID for scoping",
    )
    limit: int = Field(
        default=10,
        description="Maximum number of memories to return",
        ge=1,
        le=50,
    )

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """Ensure query is not empty after stripping."""
        if not v.strip():
            raise ValueError("Query cannot be empty or whitespace only")
        return v.strip()


class MemoryStoreInput(BaseModel):
    """Input for memory_store tool."""

    model_config = SCHEMA_CONFIG

    user_message: str = Field(
        ...,
        description="The user's message to store",
        min_length=1,
        max_length=10000,
    )
    agent_response: str = Field(
        ...,
        description="The agent's response to store",
        min_length=1,
        max_length=50000,
    )
    session_id: str = Field(
        default="default",
        description="Session identifier",
        min_length=1,
        max_length=100,
    )
    conversation_id: str | None = Field(
        default=None,
        description="Optional conversation ID",
    )
    interface: str = Field(
        default="mcp",
        description="Interface type (mcp, cli, web, slack)",
        min_length=1,
        max_length=50,
    )
    event_type: str = Field(
        default="conversation",
        description="Type of event (conversation, meeting, email, call)",
        min_length=1,
        max_length=50,
    )
    importance: float = Field(
        default=0.5,
        description="Importance score from 0.0 to 1.0",
        ge=0.0,
        le=1.0,
    )


class WorkingMemoryGetInput(BaseModel):
    """Input for memory_working_get tool."""

    model_config = SCHEMA_CONFIG

    session_id: str = Field(
        ...,
        description="Session identifier to retrieve working memory for",
        min_length=1,
        max_length=100,
    )


class WorkingMemoryUpdateInput(BaseModel):
    """Input for memory_working_update tool."""

    model_config = SCHEMA_CONFIG

    session_id: str = Field(
        ...,
        description="Session identifier to update",
        min_length=1,
        max_length=100,
    )
    messages: list[dict[str, Any]] | None = Field(
        default=None,
        description="Optional list of messages to set",
    )
    context: dict[str, Any] | None = Field(
        default=None,
        description="Optional context data to merge",
    )


class PeopleSearchInput(BaseModel):
    """Input for memory_people_search tool."""

    model_config = SCHEMA_CONFIG

    query: str = Field(
        ...,
        description="Search query to match against names, emails, or companies",
        min_length=1,
        max_length=200,
    )
    limit: int = Field(
        default=10,
        description="Maximum number of people to return",
        ge=1,
        le=50,
    )

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """Ensure query is not empty after stripping."""
        if not v.strip():
            raise ValueError("Query cannot be empty or whitespace only")
        return v.strip()


class PersonGetInput(BaseModel):
    """Input for memory_people_get tool."""

    model_config = SCHEMA_CONFIG

    person_id: str = Field(
        ...,
        description="UUID of the person to retrieve",
        min_length=36,
        max_length=36,
    )

    @field_validator("person_id")
    @classmethod
    def validate_person_id(cls, v: str) -> str:
        """Validate person_id is a valid UUID."""
        try:
            UUID(v)
        except ValueError as e:
            raise ValueError("Invalid UUID format for person_id") from e
        return v


class ProjectSearchInput(BaseModel):
    """Input for memory_projects_search tool."""

    model_config = SCHEMA_CONFIG

    query: str = Field(
        ...,
        description="Search query to match against project names or descriptions",
        min_length=1,
        max_length=200,
    )
    limit: int = Field(
        default=10,
        description="Maximum number of projects to return",
        ge=1,
        le=50,
    )

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        """Ensure query is not empty after stripping."""
        if not v.strip():
            raise ValueError("Query cannot be empty or whitespace only")
        return v.strip()


class ProjectGetInput(BaseModel):
    """Input for memory_projects_get tool."""

    model_config = SCHEMA_CONFIG

    project_id: str = Field(
        ...,
        description="UUID of the project to retrieve",
        min_length=36,
        max_length=36,
    )

    @field_validator("project_id")
    @classmethod
    def validate_project_id(cls, v: str) -> str:
        """Validate project_id is a valid UUID."""
        try:
            UUID(v)
        except ValueError as e:
            raise ValueError("Invalid UUID format for project_id") from e
        return v


class HealthCheckInput(BaseModel):
    """Input for memory_health tool (no parameters)."""

    model_config = SCHEMA_CONFIG


# =============================================================================
# Output Schemas
# =============================================================================


class RankedEventOutput(BaseModel):
    """Output schema for a ranked memory event."""

    model_config = SCHEMA_CONFIG

    event_id: str
    event_type: str
    title: str | None = None
    summary: str | None = None
    occurred_at: datetime
    importance: float
    vector_score: float
    time_decay: float
    final_score: float


class PersonOutput(BaseModel):
    """Output schema for a person."""

    model_config = SCHEMA_CONFIG

    id: str
    name: str
    email: str | None = None
    company: str | None = None
    relationship_type: str | None = None


class ProjectOutput(BaseModel):
    """Output schema for a project."""

    model_config = SCHEMA_CONFIG

    id: str
    name: str
    status: str
    description: str | None = None


class LessonOutput(BaseModel):
    """Output schema for a lesson."""

    model_config = SCHEMA_CONFIG

    id: str
    content: str
    category: str | None = None
    confidence: float


class MemoryRecallOutput(BaseModel):
    """Output schema for memory_recall tool."""

    model_config = SCHEMA_CONFIG

    events: list[RankedEventOutput] = Field(default_factory=list)
    people: list[PersonOutput] = Field(default_factory=list)
    projects: list[ProjectOutput] = Field(default_factory=list)
    lessons: list[LessonOutput] = Field(default_factory=list)
    query: str
    cached: bool = False


class MemoryStoreOutput(BaseModel):
    """Output schema for memory_store tool."""

    model_config = SCHEMA_CONFIG

    success: bool = True
    event_id: str | None = None
    stored_at: datetime | None = None


class WorkingMemoryOutput(BaseModel):
    """Output schema for working memory tools."""

    model_config = SCHEMA_CONFIG

    session_id: str
    messages: list[dict[str, Any]] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)
    updated_at: datetime | None = None


class HealthOutput(BaseModel):
    """Output schema for memory_health tool."""

    model_config = SCHEMA_CONFIG

    database: bool = False
    qdrant: bool = False
    redis: bool = False
    embedding: bool = False
    overall: bool = False
