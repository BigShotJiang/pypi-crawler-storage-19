"""MCP (Model Context Protocol) Server Package.

This package provides MCP servers for Digital Valerii, exposing
memory and other services via the Model Context Protocol.

Servers:
    memory_mcp: Memory system tools (recall, store, working memory, etc.)

Usage:
    Run as a module:
        python -m digital_valerii_shared.mcp.memory_server

    Or configure in .mcp.json:
        {
            "mcpServers": {
                "memory": {
                    "command": "python",
                    "args": ["-m", "digital_valerii_shared.mcp.memory_server"]
                }
            }
        }
"""

from .memory_schemas import (
    HealthCheckInput,
    HealthOutput,
    LessonOutput,
    MemoryRecallInput,
    MemoryRecallOutput,
    MemoryStoreInput,
    MemoryStoreOutput,
    PeopleSearchInput,
    PersonGetInput,
    PersonOutput,
    ProjectGetInput,
    ProjectOutput,
    ProjectSearchInput,
    RankedEventOutput,
    ToolResponse,
    WorkingMemoryGetInput,
    WorkingMemoryOutput,
    WorkingMemoryUpdateInput,
)
from .memory_tools import (
    clear_memory_manager,
    configure_memory_manager,
    get_memory_manager,
    memory_health_impl,
    memory_people_get_impl,
    memory_people_search_impl,
    memory_projects_get_impl,
    memory_projects_search_impl,
    memory_recall_impl,
    memory_store_impl,
    memory_working_get_impl,
    memory_working_update_impl,
)

__all__ = [
    # Schemas - Input
    "MemoryRecallInput",
    "MemoryStoreInput",
    "WorkingMemoryGetInput",
    "WorkingMemoryUpdateInput",
    "PeopleSearchInput",
    "PersonGetInput",
    "ProjectSearchInput",
    "ProjectGetInput",
    "HealthCheckInput",
    # Schemas - Output
    "RankedEventOutput",
    "PersonOutput",
    "ProjectOutput",
    "LessonOutput",
    "MemoryRecallOutput",
    "MemoryStoreOutput",
    "WorkingMemoryOutput",
    "HealthOutput",
    "ToolResponse",
    # Tools - Configuration
    "configure_memory_manager",
    "get_memory_manager",
    "clear_memory_manager",
    # Tools - Implementations
    "memory_recall_impl",
    "memory_store_impl",
    "memory_working_get_impl",
    "memory_working_update_impl",
    "memory_people_search_impl",
    "memory_people_get_impl",
    "memory_projects_search_impl",
    "memory_projects_get_impl",
    "memory_health_impl",
]
