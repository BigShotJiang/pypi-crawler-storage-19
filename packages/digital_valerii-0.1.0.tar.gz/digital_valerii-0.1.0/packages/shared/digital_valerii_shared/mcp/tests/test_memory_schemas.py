"""Tests for MCP memory schemas.

This module provides comprehensive tests for all input and output
Pydantic models used by the Memory MCP Server.
"""

from datetime import datetime
from uuid import uuid4

import pytest
from digital_valerii_shared.mcp.memory_schemas import (
    HealthCheckInput,
    HealthOutput,
    LessonOutput,
    MemoryRecallInput,
    MemoryRecallOutput,
    MemoryStoreInput,
    MemoryStoreOutput,
    PeopleSearchInput,
    PersonGetInput,
    PersonOutput,
    ProjectGetInput,
    ProjectOutput,
    ProjectSearchInput,
    RankedEventOutput,
    ToolResponse,
    WorkingMemoryGetInput,
    WorkingMemoryOutput,
    WorkingMemoryUpdateInput,
)
from pydantic import ValidationError

# =============================================================================
# MemoryRecallInput Tests
# =============================================================================


class TestMemoryRecallInput:
    """Tests for MemoryRecallInput schema."""

    def test_valid_minimal(self) -> None:
        """Test minimal valid input."""
        input_data = MemoryRecallInput(query="test query")
        assert input_data.query == "test query"
        assert input_data.session_id == "default"
        assert input_data.conversation_id is None
        assert input_data.limit == 10

    def test_valid_full(self) -> None:
        """Test full valid input."""
        input_data = MemoryRecallInput(
            query="search query",
            session_id="session-123",
            conversation_id="conv-456",
            limit=25,
        )
        assert input_data.query == "search query"
        assert input_data.session_id == "session-123"
        assert input_data.conversation_id == "conv-456"
        assert input_data.limit == 25

    def test_query_strips_whitespace(self) -> None:
        """Test that query is stripped of whitespace."""
        input_data = MemoryRecallInput(query="  test query  ")
        assert input_data.query == "test query"

    def test_empty_query_fails(self) -> None:
        """Test that empty query fails validation."""
        with pytest.raises(ValidationError) as exc_info:
            MemoryRecallInput(query="")
        assert "String should have at least 1 character" in str(exc_info.value)

    def test_whitespace_only_query_fails(self) -> None:
        """Test that whitespace-only query fails validation."""
        with pytest.raises(ValidationError):
            MemoryRecallInput(query="   ")

    def test_query_max_length(self) -> None:
        """Test that query respects max length."""
        with pytest.raises(ValidationError) as exc_info:
            MemoryRecallInput(query="x" * 1001)
        assert "String should have at most 1000 characters" in str(exc_info.value)

    def test_limit_min_value(self) -> None:
        """Test limit minimum value."""
        with pytest.raises(ValidationError) as exc_info:
            MemoryRecallInput(query="test", limit=0)
        assert "greater than or equal to 1" in str(exc_info.value)

    def test_limit_max_value(self) -> None:
        """Test limit maximum value."""
        with pytest.raises(ValidationError) as exc_info:
            MemoryRecallInput(query="test", limit=51)
        assert "less than or equal to 50" in str(exc_info.value)

    def test_forbids_extra_fields(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValidationError) as exc_info:
            MemoryRecallInput(query="test", unknown_field="value")
        assert "Extra inputs are not permitted" in str(exc_info.value)


# =============================================================================
# MemoryStoreInput Tests
# =============================================================================


class TestMemoryStoreInput:
    """Tests for MemoryStoreInput schema."""

    def test_valid_minimal(self) -> None:
        """Test minimal valid input."""
        input_data = MemoryStoreInput(
            user_message="Hello",
            agent_response="Hi there!",
        )
        assert input_data.user_message == "Hello"
        assert input_data.agent_response == "Hi there!"
        assert input_data.session_id == "default"
        assert input_data.interface == "mcp"
        assert input_data.event_type == "conversation"
        assert input_data.importance == 0.5

    def test_valid_full(self) -> None:
        """Test full valid input."""
        input_data = MemoryStoreInput(
            user_message="What's the weather?",
            agent_response="It's sunny today!",
            session_id="session-abc",
            conversation_id="conv-xyz",
            interface="slack",
            event_type="meeting",
            importance=0.8,
        )
        assert input_data.interface == "slack"
        assert input_data.event_type == "meeting"
        assert input_data.importance == 0.8

    def test_empty_user_message_fails(self) -> None:
        """Test that empty user message fails."""
        with pytest.raises(ValidationError):
            MemoryStoreInput(user_message="", agent_response="response")

    def test_empty_agent_response_fails(self) -> None:
        """Test that empty agent response fails."""
        with pytest.raises(ValidationError):
            MemoryStoreInput(user_message="message", agent_response="")

    def test_importance_min_value(self) -> None:
        """Test importance minimum value."""
        with pytest.raises(ValidationError):
            MemoryStoreInput(
                user_message="msg",
                agent_response="resp",
                importance=-0.1,
            )

    def test_importance_max_value(self) -> None:
        """Test importance maximum value."""
        with pytest.raises(ValidationError):
            MemoryStoreInput(
                user_message="msg",
                agent_response="resp",
                importance=1.1,
            )

    def test_importance_boundary_values(self) -> None:
        """Test importance at boundary values."""
        input_min = MemoryStoreInput(
            user_message="msg",
            agent_response="resp",
            importance=0.0,
        )
        assert input_min.importance == 0.0

        input_max = MemoryStoreInput(
            user_message="msg",
            agent_response="resp",
            importance=1.0,
        )
        assert input_max.importance == 1.0


# =============================================================================
# WorkingMemoryGetInput Tests
# =============================================================================


class TestWorkingMemoryGetInput:
    """Tests for WorkingMemoryGetInput schema."""

    def test_valid_input(self) -> None:
        """Test valid input."""
        input_data = WorkingMemoryGetInput(session_id="session-123")
        assert input_data.session_id == "session-123"

    def test_empty_session_id_fails(self) -> None:
        """Test that empty session_id fails."""
        with pytest.raises(ValidationError):
            WorkingMemoryGetInput(session_id="")

    def test_session_id_max_length(self) -> None:
        """Test session_id max length."""
        with pytest.raises(ValidationError):
            WorkingMemoryGetInput(session_id="x" * 101)


# =============================================================================
# WorkingMemoryUpdateInput Tests
# =============================================================================


class TestWorkingMemoryUpdateInput:
    """Tests for WorkingMemoryUpdateInput schema."""

    def test_valid_minimal(self) -> None:
        """Test minimal valid input."""
        input_data = WorkingMemoryUpdateInput(session_id="session-123")
        assert input_data.session_id == "session-123"
        assert input_data.messages is None
        assert input_data.context is None

    def test_valid_with_messages(self) -> None:
        """Test valid input with messages."""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi!"},
        ]
        input_data = WorkingMemoryUpdateInput(
            session_id="session-123",
            messages=messages,
        )
        assert input_data.messages == messages

    def test_valid_with_context(self) -> None:
        """Test valid input with context."""
        context = {"key": "value", "nested": {"a": 1}}
        input_data = WorkingMemoryUpdateInput(
            session_id="session-123",
            context=context,
        )
        assert input_data.context == context


# =============================================================================
# PeopleSearchInput Tests
# =============================================================================


class TestPeopleSearchInput:
    """Tests for PeopleSearchInput schema."""

    def test_valid_minimal(self) -> None:
        """Test minimal valid input."""
        input_data = PeopleSearchInput(query="John")
        assert input_data.query == "John"
        assert input_data.limit == 10

    def test_query_strips_whitespace(self) -> None:
        """Test that query is stripped."""
        input_data = PeopleSearchInput(query="  Jane  ")
        assert input_data.query == "Jane"

    def test_whitespace_only_query_fails(self) -> None:
        """Test that whitespace-only query fails."""
        with pytest.raises(ValidationError):
            PeopleSearchInput(query="   ")


# =============================================================================
# PersonGetInput Tests
# =============================================================================


class TestPersonGetInput:
    """Tests for PersonGetInput schema."""

    def test_valid_uuid(self) -> None:
        """Test valid UUID input."""
        person_id = str(uuid4())
        input_data = PersonGetInput(person_id=person_id)
        assert input_data.person_id == person_id

    def test_invalid_uuid_fails(self) -> None:
        """Test that invalid UUID fails."""
        # Use 36-char string with non-hex characters (g is invalid)
        with pytest.raises(ValidationError) as exc_info:
            PersonGetInput(person_id="gggggggg-gggg-gggg-gggg-gggggggggggg")
        assert "Invalid UUID format" in str(exc_info.value)

    def test_short_string_fails(self) -> None:
        """Test that short string fails."""
        with pytest.raises(ValidationError):
            PersonGetInput(person_id="short")


# =============================================================================
# ProjectSearchInput Tests
# =============================================================================


class TestProjectSearchInput:
    """Tests for ProjectSearchInput schema."""

    def test_valid_minimal(self) -> None:
        """Test minimal valid input."""
        input_data = ProjectSearchInput(query="Digital Valerii")
        assert input_data.query == "Digital Valerii"
        assert input_data.limit == 10

    def test_query_strips_whitespace(self) -> None:
        """Test that query is stripped."""
        input_data = ProjectSearchInput(query="  Project  ")
        assert input_data.query == "Project"


# =============================================================================
# ProjectGetInput Tests
# =============================================================================


class TestProjectGetInput:
    """Tests for ProjectGetInput schema."""

    def test_valid_uuid(self) -> None:
        """Test valid UUID input."""
        project_id = str(uuid4())
        input_data = ProjectGetInput(project_id=project_id)
        assert input_data.project_id == project_id

    def test_invalid_uuid_fails(self) -> None:
        """Test that invalid UUID fails."""
        # Use 36-char string with non-hex characters (z is invalid)
        with pytest.raises(ValidationError) as exc_info:
            ProjectGetInput(project_id="zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz")
        assert "Invalid UUID format" in str(exc_info.value)


# =============================================================================
# HealthCheckInput Tests
# =============================================================================


class TestHealthCheckInput:
    """Tests for HealthCheckInput schema."""

    def test_empty_input(self) -> None:
        """Test that empty input is valid."""
        input_data = HealthCheckInput()
        assert input_data is not None

    def test_forbids_extra_fields(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValidationError):
            HealthCheckInput(extra_field="value")


# =============================================================================
# Output Schema Tests
# =============================================================================


class TestRankedEventOutput:
    """Tests for RankedEventOutput schema."""

    def test_valid_output(self) -> None:
        """Test valid output."""
        output = RankedEventOutput(
            event_id=str(uuid4()),
            event_type="conversation",
            title="Test Event",
            summary="A test event summary",
            occurred_at=datetime.now(),
            importance=0.8,
            vector_score=0.95,
            time_decay=0.9,
            final_score=0.855,
        )
        assert output.event_type == "conversation"
        assert output.importance == 0.8

    def test_optional_fields(self) -> None:
        """Test optional fields can be None."""
        output = RankedEventOutput(
            event_id=str(uuid4()),
            event_type="meeting",
            title=None,
            summary=None,
            occurred_at=datetime.now(),
            importance=0.5,
            vector_score=0.8,
            time_decay=0.85,
            final_score=0.68,
        )
        assert output.title is None
        assert output.summary is None


class TestPersonOutput:
    """Tests for PersonOutput schema."""

    def test_valid_output(self) -> None:
        """Test valid output."""
        output = PersonOutput(
            id=str(uuid4()),
            name="John Doe",
            email="john@example.com",
            company="Acme Corp",
            relationship_type="colleague",
        )
        assert output.name == "John Doe"
        assert output.email == "john@example.com"

    def test_optional_fields(self) -> None:
        """Test optional fields."""
        output = PersonOutput(
            id=str(uuid4()),
            name="Jane Doe",
        )
        assert output.email is None
        assert output.company is None
        assert output.relationship_type is None


class TestProjectOutput:
    """Tests for ProjectOutput schema."""

    def test_valid_output(self) -> None:
        """Test valid output."""
        output = ProjectOutput(
            id=str(uuid4()),
            name="Project Alpha",
            status="active",
            description="A test project",
        )
        assert output.name == "Project Alpha"
        assert output.status == "active"


class TestLessonOutput:
    """Tests for LessonOutput schema."""

    def test_valid_output(self) -> None:
        """Test valid output."""
        output = LessonOutput(
            id=str(uuid4()),
            content="Always test your code",
            category="testing",
            confidence=0.9,
        )
        assert output.content == "Always test your code"
        assert output.confidence == 0.9


class TestMemoryRecallOutput:
    """Tests for MemoryRecallOutput schema."""

    def test_empty_output(self) -> None:
        """Test empty output."""
        output = MemoryRecallOutput(query="test", cached=False)
        assert output.events == []
        assert output.people == []
        assert output.projects == []
        assert output.lessons == []

    def test_full_output(self) -> None:
        """Test full output with all fields."""
        output = MemoryRecallOutput(
            events=[
                RankedEventOutput(
                    event_id=str(uuid4()),
                    event_type="conversation",
                    occurred_at=datetime.now(),
                    importance=0.5,
                    vector_score=0.8,
                    time_decay=0.9,
                    final_score=0.72,
                )
            ],
            people=[PersonOutput(id=str(uuid4()), name="John")],
            projects=[ProjectOutput(id=str(uuid4()), name="Project", status="active")],
            lessons=[LessonOutput(id=str(uuid4()), content="Lesson", confidence=0.8)],
            query="test query",
            cached=True,
        )
        assert len(output.events) == 1
        assert len(output.people) == 1
        assert len(output.projects) == 1
        assert len(output.lessons) == 1
        assert output.cached is True


class TestMemoryStoreOutput:
    """Tests for MemoryStoreOutput schema."""

    def test_success_output(self) -> None:
        """Test success output."""
        output = MemoryStoreOutput(
            success=True,
            event_id=str(uuid4()),
            stored_at=datetime.now(),
        )
        assert output.success is True
        assert output.event_id is not None

    def test_default_output(self) -> None:
        """Test default output."""
        output = MemoryStoreOutput()
        assert output.success is True
        assert output.event_id is None
        assert output.stored_at is None


class TestWorkingMemoryOutput:
    """Tests for WorkingMemoryOutput schema."""

    def test_valid_output(self) -> None:
        """Test valid output."""
        output = WorkingMemoryOutput(
            session_id="session-123",
            messages=[{"role": "user", "content": "Hello"}],
            context={"key": "value"},
            updated_at=datetime.now(),
        )
        assert output.session_id == "session-123"
        assert len(output.messages) == 1
        assert output.context == {"key": "value"}

    def test_empty_output(self) -> None:
        """Test empty output."""
        output = WorkingMemoryOutput(session_id="empty-session")
        assert output.messages == []
        assert output.context == {}
        assert output.updated_at is None


class TestHealthOutput:
    """Tests for HealthOutput schema."""

    def test_all_healthy(self) -> None:
        """Test all healthy output."""
        output = HealthOutput(
            database=True,
            qdrant=True,
            redis=True,
            embedding=True,
            overall=True,
        )
        assert output.overall is True

    def test_partial_healthy(self) -> None:
        """Test partial healthy output."""
        output = HealthOutput(
            database=True,
            qdrant=False,
            redis=True,
            embedding=True,
            overall=False,
        )
        assert output.qdrant is False
        assert output.overall is False

    def test_default_values(self) -> None:
        """Test default values are False."""
        output = HealthOutput()
        assert output.database is False
        assert output.qdrant is False
        assert output.redis is False
        assert output.embedding is False
        assert output.overall is False


class TestToolResponse:
    """Tests for ToolResponse schema."""

    def test_success_response(self) -> None:
        """Test success response."""
        response = ToolResponse(success=True, data={"key": "value"})
        assert response.success is True
        assert response.data == {"key": "value"}
        assert response.error is None

    def test_error_response(self) -> None:
        """Test error response."""
        response = ToolResponse(success=False, error="Something went wrong")
        assert response.success is False
        assert response.error == "Something went wrong"
        assert response.data is None

    def test_default_success(self) -> None:
        """Test default success value."""
        response = ToolResponse()
        assert response.success is True
