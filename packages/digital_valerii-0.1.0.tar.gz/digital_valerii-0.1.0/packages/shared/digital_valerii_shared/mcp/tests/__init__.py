"""Tests for MCP package."""
