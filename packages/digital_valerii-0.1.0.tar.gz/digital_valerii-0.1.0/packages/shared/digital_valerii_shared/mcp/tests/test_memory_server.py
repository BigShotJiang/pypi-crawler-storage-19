"""Tests for MCP memory server.

This module provides tests for the FastMCP server setup,
tool registration, and server initialization.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Skip all tests in this module if mcp is not installed
pytest.importorskip("mcp", reason="MCP library not installed")

from digital_valerii_shared.mcp.memory_schemas import (  # noqa: E402
    HealthCheckInput,
    MemoryRecallInput,
    MemoryStoreInput,
    PeopleSearchInput,
    PersonGetInput,
    ProjectGetInput,
    ProjectSearchInput,
    WorkingMemoryGetInput,
    WorkingMemoryUpdateInput,
)
from digital_valerii_shared.mcp.memory_tools import (  # noqa: E402
    clear_memory_manager,
    configure_memory_manager,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def cleanup_memory_manager():
    """Clear memory manager before and after each test."""
    clear_memory_manager()
    yield
    clear_memory_manager()


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    manager = MagicMock()
    manager.recall = AsyncMock()
    manager.store = AsyncMock()
    manager.get_working_memory = AsyncMock()
    manager.update_working_memory = AsyncMock()
    manager.search_people = AsyncMock()
    manager.get_person = AsyncMock()
    manager.search_projects = AsyncMock()
    manager.get_project = AsyncMock()
    manager.health_check = AsyncMock()
    return manager


# =============================================================================
# Server Import Tests
# =============================================================================


class TestServerImport:
    """Tests for server module imports."""

    def test_mcp_instance_exists(self) -> None:
        """Test that MCP instance is created."""
        from digital_valerii_shared.mcp.memory_server import mcp

        assert mcp is not None
        assert mcp.name == "memory_mcp"

    def test_tools_are_registered(self) -> None:
        """Test that all tools are registered with MCP."""
        from digital_valerii_shared.mcp.memory_server import (
            memory_health,
            memory_people_get,
            memory_people_search,
            memory_projects_get,
            memory_projects_search,
            memory_recall,
            memory_store,
            memory_working_get,
            memory_working_update,
        )

        # Verify all tools are callable
        assert callable(memory_recall)
        assert callable(memory_store)
        assert callable(memory_working_get)
        assert callable(memory_working_update)
        assert callable(memory_people_search)
        assert callable(memory_people_get)
        assert callable(memory_projects_search)
        assert callable(memory_projects_get)
        assert callable(memory_health)


# =============================================================================
# Tool Registration Tests
# =============================================================================


class TestToolRegistration:
    """Tests for tool registration with FastMCP."""

    def test_memory_recall_registered(self) -> None:
        """Test memory_recall tool is registered."""
        from digital_valerii_shared.mcp.memory_server import mcp

        # FastMCP registers tools in _tools dict
        assert hasattr(mcp, "_tool_manager") or hasattr(mcp, "_tools")

    def test_all_nine_tools_exist(self) -> None:
        """Test that all 9 tools are defined."""
        from digital_valerii_shared.mcp import memory_server

        tool_names = [
            "memory_recall",
            "memory_store",
            "memory_working_get",
            "memory_working_update",
            "memory_people_search",
            "memory_people_get",
            "memory_projects_search",
            "memory_projects_get",
            "memory_health",
        ]

        for name in tool_names:
            assert hasattr(memory_server, name), f"Tool {name} not found"


# =============================================================================
# Tool Function Tests
# =============================================================================


class TestToolFunctions:
    """Tests for tool function calls."""

    @pytest.mark.asyncio
    async def test_memory_recall_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_recall calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_recall

        configure_memory_manager(mock_memory_manager)

        # Setup mock
        mock_result = MagicMock()
        mock_result.events = []
        mock_result.people = []
        mock_result.projects = []
        mock_result.lessons = []
        mock_result.query = "test"
        mock_result.cached = False
        mock_memory_manager.recall.return_value = mock_result

        params = MemoryRecallInput(query="test query")
        result = await memory_recall(params)

        assert '"success": true' in result or '"success":true' in result

    @pytest.mark.asyncio
    async def test_memory_store_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_store calls implementation."""
        from datetime import datetime

        from digital_valerii_shared.mcp.memory_server import memory_store

        configure_memory_manager(mock_memory_manager)

        # Setup mock
        from uuid import uuid4

        mock_event = MagicMock()
        mock_event.id = uuid4()
        mock_event.occurred_at = datetime.now()
        mock_memory_manager.store.return_value = mock_event

        params = MemoryStoreInput(
            user_message="Hello",
            agent_response="Hi there!",
        )
        result = await memory_store(params)

        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_working_get_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_working_get calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_working_get

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.get_working_memory.return_value = None

        params = WorkingMemoryGetInput(session_id="test-session")
        result = await memory_working_get(params)

        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_working_update_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_working_update calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_working_update

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.get_working_memory.return_value = None

        params = WorkingMemoryUpdateInput(
            session_id="test-session",
            messages=[{"role": "user", "content": "Test"}],
        )
        result = await memory_working_update(params)

        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_people_search_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_people_search calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_people_search

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.search_people.return_value = []

        params = PeopleSearchInput(query="John")
        result = await memory_people_search(params)

        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_people_get_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_people_get calls implementation."""
        from uuid import uuid4

        from digital_valerii_shared.mcp.memory_server import memory_people_get

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.get_person.return_value = None

        params = PersonGetInput(person_id=str(uuid4()))
        result = await memory_people_get(params)

        # Should return error since person not found
        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_projects_search_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_projects_search calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_projects_search

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.search_projects.return_value = []

        params = ProjectSearchInput(query="Digital")
        result = await memory_projects_search(params)

        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_projects_get_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_projects_get calls implementation."""
        from uuid import uuid4

        from digital_valerii_shared.mcp.memory_server import memory_projects_get

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.get_project.return_value = None

        params = ProjectGetInput(project_id=str(uuid4()))
        result = await memory_projects_get(params)

        # Should return error since project not found
        assert "success" in result

    @pytest.mark.asyncio
    async def test_memory_health_calls_impl(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test that memory_health calls implementation."""
        from digital_valerii_shared.mcp.memory_server import memory_health

        configure_memory_manager(mock_memory_manager)
        mock_memory_manager.health_check.return_value = {
            "database": True,
            "qdrant": True,
            "redis": True,
            "embedding": True,
        }

        params = HealthCheckInput()
        result = await memory_health(params)

        assert "success" in result
        assert "overall" in result


# =============================================================================
# Server Initialization Tests
# =============================================================================


class TestServerInitialization:
    """Tests for server initialization."""

    @pytest.mark.asyncio
    async def test_initialize_already_configured(
        self, mock_memory_manager: MagicMock
    ) -> None:
        """Test initialization when manager is already configured."""
        from digital_valerii_shared.mcp.memory_server import initialize_memory_manager

        configure_memory_manager(mock_memory_manager)

        # Should not raise, just log and return
        await initialize_memory_manager()

    @pytest.mark.asyncio
    async def test_initialize_creates_manager(self) -> None:
        """Test initialization creates memory manager."""
        from digital_valerii_shared.mcp.memory_server import initialize_memory_manager

        with (
            patch.dict(
                "os.environ",
                {
                    "DATABASE_URL": "postgresql://test:test@localhost/test",
                    "QDRANT_URL": "http://localhost:6333",
                    "REDIS_URL": "redis://localhost:6379",
                    "OPENAI_API_KEY": "test-key",
                },
            ),
            patch(
                "digital_valerii_shared.mcp.memory_server.MemoryManager"
            ) as MockManager,
        ):
            mock_manager = MagicMock()
            MockManager.return_value = mock_manager

            await initialize_memory_manager()

            # Verify MemoryManager was called with env vars
            MockManager.assert_called_once()

    @pytest.mark.asyncio
    async def test_initialize_handles_missing_env_vars(self) -> None:
        """Test initialization handles missing environment variables."""
        from digital_valerii_shared.mcp.memory_server import initialize_memory_manager

        with (
            patch.dict("os.environ", {}, clear=True),
            patch(
                "digital_valerii_shared.mcp.memory_server.MemoryManager"
            ) as MockManager,
        ):
            mock_manager = MagicMock()
            MockManager.return_value = mock_manager

            # Should not raise, just warn
            await initialize_memory_manager()


# =============================================================================
# Main Function Tests
# =============================================================================


class TestMainFunction:
    """Tests for main entry point."""

    def test_main_exists(self) -> None:
        """Test that main function exists."""
        from digital_valerii_shared.mcp.memory_server import main

        assert callable(main)

    def test_main_module_runnable(self) -> None:
        """Test that module can be imported as entry point."""
        import digital_valerii_shared.mcp.memory_server as server_module

        assert hasattr(server_module, "__name__")
        assert hasattr(server_module, "main")


# =============================================================================
# Tool Annotations Tests
# =============================================================================


class TestToolAnnotations:
    """Tests for tool annotations (hints)."""

    def test_recall_is_readonly(self) -> None:
        """Test that recall is marked as readonly."""
        from digital_valerii_shared.mcp.memory_server import memory_recall

        # The annotations are set via decorator, we can verify the function exists
        assert callable(memory_recall)

    def test_store_is_destructive(self) -> None:
        """Test that store is marked as destructive."""
        from digital_valerii_shared.mcp.memory_server import memory_store

        # The annotations are set via decorator, we can verify the function exists
        assert callable(memory_store)

    def test_all_tools_have_docstrings(self) -> None:
        """Test that all tools have proper docstrings."""
        from digital_valerii_shared.mcp.memory_server import (
            memory_health,
            memory_people_get,
            memory_people_search,
            memory_projects_get,
            memory_projects_search,
            memory_recall,
            memory_store,
            memory_working_get,
            memory_working_update,
        )

        tools = [
            memory_recall,
            memory_store,
            memory_working_get,
            memory_working_update,
            memory_people_search,
            memory_people_get,
            memory_projects_search,
            memory_projects_get,
            memory_health,
        ]

        for tool in tools:
            assert tool.__doc__ is not None, f"Tool {tool.__name__} has no docstring"
            assert len(tool.__doc__) > 20, f"Tool {tool.__name__} has short docstring"
