"""Tests for MCP memory tools.

This module provides tests for all memory tool implementations,
including dependency injection and error handling.
"""

from __future__ import annotations

import json
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from digital_valerii_shared.mcp.memory_schemas import (
    HealthCheckInput,
    MemoryRecallInput,
    MemoryStoreInput,
    PeopleSearchInput,
    PersonGetInput,
    ProjectGetInput,
    ProjectSearchInput,
    WorkingMemoryGetInput,
    WorkingMemoryUpdateInput,
)
from digital_valerii_shared.mcp.memory_tools import (
    clear_memory_manager,
    configure_memory_manager,
    get_memory_manager,
    memory_health_impl,
    memory_people_get_impl,
    memory_people_search_impl,
    memory_projects_get_impl,
    memory_projects_search_impl,
    memory_recall_impl,
    memory_store_impl,
    memory_working_get_impl,
    memory_working_update_impl,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(autouse=True)
def cleanup_memory_manager():
    """Clear memory manager before and after each test."""
    clear_memory_manager()
    yield
    clear_memory_manager()


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    manager = MagicMock()
    # Configure all async methods
    manager.recall = AsyncMock()
    manager.store = AsyncMock()
    manager.get_working_memory = AsyncMock()
    manager.update_working_memory = AsyncMock()
    manager.search_people = AsyncMock()
    manager.get_person = AsyncMock()
    manager.search_projects = AsyncMock()
    manager.get_project = AsyncMock()
    manager.health_check = AsyncMock()
    return manager


@pytest.fixture
def configured_manager(mock_memory_manager: MagicMock) -> MagicMock:
    """Configure and return the memory manager."""
    configure_memory_manager(mock_memory_manager)
    return mock_memory_manager


# =============================================================================
# Dependency Injection Tests
# =============================================================================


class TestDependencyInjection:
    """Tests for memory manager dependency injection."""

    def test_get_manager_not_configured(self) -> None:
        """Test that getting manager before configuration raises error."""
        with pytest.raises(RuntimeError) as exc_info:
            get_memory_manager()
        assert "not configured" in str(exc_info.value)

    def test_configure_manager(self, mock_memory_manager: MagicMock) -> None:
        """Test configuring the memory manager."""
        configure_memory_manager(mock_memory_manager)
        result = get_memory_manager()
        assert result is mock_memory_manager

    def test_clear_manager(self, mock_memory_manager: MagicMock) -> None:
        """Test clearing the memory manager."""
        configure_memory_manager(mock_memory_manager)
        clear_memory_manager()
        with pytest.raises(RuntimeError):
            get_memory_manager()

    def test_reconfigure_manager(self, mock_memory_manager: MagicMock) -> None:
        """Test reconfiguring the memory manager."""
        configure_memory_manager(mock_memory_manager)
        new_manager = MagicMock()
        configure_memory_manager(new_manager)
        result = get_memory_manager()
        assert result is new_manager


# =============================================================================
# Memory Recall Tests
# =============================================================================


class TestMemoryRecall:
    """Tests for memory_recall_impl."""

    @pytest.mark.asyncio
    async def test_recall_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that recall returns valid JSON."""
        # Setup mock return
        mock_result = MagicMock()
        mock_result.events = []
        mock_result.people = []
        mock_result.projects = []
        mock_result.lessons = []
        mock_result.query = "test query"
        mock_result.cached = False
        configured_manager.recall.return_value = mock_result

        params = MemoryRecallInput(query="test query")
        result = await memory_recall_impl(params)

        # Verify JSON response
        data = json.loads(result)
        assert data["success"] is True
        assert "data" in data

    @pytest.mark.asyncio
    async def test_recall_with_events(self, configured_manager: MagicMock) -> None:
        """Test recall with events in result."""
        event_id = uuid4()
        mock_event = MagicMock()
        mock_event.event_id = event_id
        mock_event.event_type = "conversation"
        mock_event.title = "Test Event"
        mock_event.summary = "A test summary"
        mock_event.occurred_at = datetime.now()
        mock_event.importance = 0.8
        mock_event.vector_score = 0.95
        mock_event.time_decay = 0.9
        mock_event.final_score = 0.855

        mock_result = MagicMock()
        mock_result.events = [mock_event]
        mock_result.people = []
        mock_result.projects = []
        mock_result.lessons = []
        mock_result.query = "test"
        mock_result.cached = False
        configured_manager.recall.return_value = mock_result

        params = MemoryRecallInput(query="test")
        result = await memory_recall_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert len(data["data"]["events"]) == 1
        assert data["data"]["events"][0]["event_id"] == str(event_id)

    @pytest.mark.asyncio
    async def test_recall_with_people(self, configured_manager: MagicMock) -> None:
        """Test recall with people in result."""
        person_id = uuid4()
        mock_person = MagicMock()
        mock_person.id = person_id
        mock_person.name = "John Doe"
        mock_person.email = "john@example.com"
        mock_person.company = "Acme"
        mock_person.relationship_type = "colleague"

        mock_result = MagicMock()
        mock_result.events = []
        mock_result.people = [mock_person]
        mock_result.projects = []
        mock_result.lessons = []
        mock_result.query = "John"
        mock_result.cached = False
        configured_manager.recall.return_value = mock_result

        params = MemoryRecallInput(query="John")
        result = await memory_recall_impl(params)

        data = json.loads(result)
        assert len(data["data"]["people"]) == 1
        assert data["data"]["people"][0]["name"] == "John Doe"

    @pytest.mark.asyncio
    async def test_recall_error_returns_json(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that recall errors return JSON."""
        configured_manager.recall.side_effect = RuntimeError("Database error")

        params = MemoryRecallInput(query="test")
        result = await memory_recall_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        assert "Database error" in data["error"]

    @pytest.mark.asyncio
    async def test_recall_manager_not_configured(self) -> None:
        """Test recall when manager not configured."""
        params = MemoryRecallInput(query="test")
        result = await memory_recall_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        assert "not configured" in data["error"]


# =============================================================================
# Memory Store Tests
# =============================================================================


class TestMemoryStore:
    """Tests for memory_store_impl."""

    @pytest.mark.asyncio
    async def test_store_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that store returns valid JSON."""
        mock_event = MagicMock()
        mock_event.id = uuid4()
        mock_event.occurred_at = datetime.now()
        configured_manager.store.return_value = mock_event

        params = MemoryStoreInput(
            user_message="Hello",
            agent_response="Hi there!",
        )
        result = await memory_store_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert "data" in data

    @pytest.mark.asyncio
    async def test_store_with_all_params(self, configured_manager: MagicMock) -> None:
        """Test store with all parameters."""
        mock_event = MagicMock()
        mock_event.id = uuid4()
        mock_event.occurred_at = datetime.now()
        configured_manager.store.return_value = mock_event

        params = MemoryStoreInput(
            user_message="What's the weather?",
            agent_response="It's sunny!",
            session_id="session-123",
            conversation_id="conv-456",
            interface="slack",
            event_type="meeting",
            importance=0.9,
        )
        result = await memory_store_impl(params)

        data = json.loads(result)
        assert data["success"] is True

        # Verify call arguments
        configured_manager.store.assert_called_once()
        call_kwargs = configured_manager.store.call_args.kwargs
        assert call_kwargs["user_message"] == "What's the weather?"
        assert call_kwargs["event_type"] == "meeting"
        assert call_kwargs["importance"] == 0.9

    @pytest.mark.asyncio
    async def test_store_error_returns_json(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that store errors return JSON."""
        configured_manager.store.side_effect = RuntimeError("Storage failed")

        params = MemoryStoreInput(
            user_message="Hello",
            agent_response="Hi!",
        )
        result = await memory_store_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        assert "Storage failed" in data["error"]


# =============================================================================
# Working Memory Get Tests
# =============================================================================


class TestWorkingMemoryGet:
    """Tests for memory_working_get_impl."""

    @pytest.mark.asyncio
    async def test_get_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that get returns valid JSON."""
        mock_wm = MagicMock()
        mock_wm.session_id = "session-123"
        mock_wm.messages = [{"role": "user", "content": "Hello"}]
        mock_wm.context = {"key": "value"}
        mock_wm.updated_at = datetime.now()
        configured_manager.get_working_memory.return_value = mock_wm

        params = WorkingMemoryGetInput(session_id="session-123")
        result = await memory_working_get_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["session_id"] == "session-123"
        assert len(data["data"]["messages"]) == 1

    @pytest.mark.asyncio
    async def test_get_returns_empty_for_missing(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that get returns empty for missing session."""
        configured_manager.get_working_memory.return_value = None

        params = WorkingMemoryGetInput(session_id="nonexistent")
        result = await memory_working_get_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["session_id"] == "nonexistent"
        assert data["data"]["messages"] == []
        assert data["data"]["context"] == {}


# =============================================================================
# Working Memory Update Tests
# =============================================================================


class TestWorkingMemoryUpdate:
    """Tests for memory_working_update_impl."""

    @pytest.mark.asyncio
    async def test_update_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that update returns valid JSON."""
        mock_wm = MagicMock()
        mock_wm.session_id = "session-123"
        mock_wm.messages = [{"role": "user", "content": "New"}]
        mock_wm.context = {"updated": True}
        mock_wm.updated_at = datetime.now()
        configured_manager.get_working_memory.return_value = mock_wm

        params = WorkingMemoryUpdateInput(
            session_id="session-123",
            messages=[{"role": "user", "content": "New"}],
        )
        result = await memory_working_update_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        configured_manager.update_working_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_with_context(self, configured_manager: MagicMock) -> None:
        """Test update with context."""
        mock_wm = MagicMock()
        mock_wm.session_id = "session-123"
        mock_wm.messages = []
        mock_wm.context = {"key": "value"}
        mock_wm.updated_at = datetime.now()
        configured_manager.get_working_memory.return_value = mock_wm

        params = WorkingMemoryUpdateInput(
            session_id="session-123",
            context={"key": "value"},
        )
        result = await memory_working_update_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["context"] == {"key": "value"}


# =============================================================================
# People Search Tests
# =============================================================================


class TestPeopleSearch:
    """Tests for memory_people_search_impl."""

    @pytest.mark.asyncio
    async def test_search_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that search returns valid JSON."""
        mock_person = MagicMock()
        mock_person.id = uuid4()
        mock_person.name = "Jane Doe"
        mock_person.email = "jane@example.com"
        mock_person.company = "Tech Corp"
        mock_person.relationship_type = "client"
        configured_manager.search_people.return_value = [mock_person]

        params = PeopleSearchInput(query="Jane")
        result = await memory_people_search_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert len(data["data"]) == 1
        assert data["data"][0]["name"] == "Jane Doe"

    @pytest.mark.asyncio
    async def test_search_empty_results(self, configured_manager: MagicMock) -> None:
        """Test search with no results."""
        configured_manager.search_people.return_value = []

        params = PeopleSearchInput(query="Nobody")
        result = await memory_people_search_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"] == []


# =============================================================================
# Person Get Tests
# =============================================================================


class TestPersonGet:
    """Tests for memory_people_get_impl."""

    @pytest.mark.asyncio
    async def test_get_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that get returns valid JSON."""
        person_id = uuid4()
        mock_person = MagicMock()
        mock_person.id = person_id
        mock_person.name = "Bob Smith"
        mock_person.email = "bob@example.com"
        mock_person.company = "Acme"
        mock_person.relationship_type = "partner"
        configured_manager.get_person.return_value = mock_person

        params = PersonGetInput(person_id=str(person_id))
        result = await memory_people_get_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["name"] == "Bob Smith"

    @pytest.mark.asyncio
    async def test_get_not_found(self, configured_manager: MagicMock) -> None:
        """Test get with person not found."""
        person_id = uuid4()
        configured_manager.get_person.return_value = None

        params = PersonGetInput(person_id=str(person_id))
        result = await memory_people_get_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        assert "not found" in data["error"]


# =============================================================================
# Projects Search Tests
# =============================================================================


class TestProjectsSearch:
    """Tests for memory_projects_search_impl."""

    @pytest.mark.asyncio
    async def test_search_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that search returns valid JSON."""
        mock_project = MagicMock()
        mock_project.id = uuid4()
        mock_project.name = "Project Alpha"
        mock_project.status = "active"
        mock_project.description = "A test project"
        configured_manager.search_projects.return_value = [mock_project]

        params = ProjectSearchInput(query="Alpha")
        result = await memory_projects_search_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert len(data["data"]) == 1
        assert data["data"][0]["name"] == "Project Alpha"


# =============================================================================
# Project Get Tests
# =============================================================================


class TestProjectGet:
    """Tests for memory_projects_get_impl."""

    @pytest.mark.asyncio
    async def test_get_returns_json(self, configured_manager: MagicMock) -> None:
        """Test that get returns valid JSON."""
        project_id = uuid4()
        mock_project = MagicMock()
        mock_project.id = project_id
        mock_project.name = "Project Beta"
        mock_project.status = "completed"
        mock_project.description = "Completed project"
        configured_manager.get_project.return_value = mock_project

        params = ProjectGetInput(project_id=str(project_id))
        result = await memory_projects_get_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["name"] == "Project Beta"

    @pytest.mark.asyncio
    async def test_get_not_found(self, configured_manager: MagicMock) -> None:
        """Test get with project not found."""
        project_id = uuid4()
        configured_manager.get_project.return_value = None

        params = ProjectGetInput(project_id=str(project_id))
        result = await memory_projects_get_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        assert "not found" in data["error"]


# =============================================================================
# Health Check Tests
# =============================================================================


class TestHealthCheck:
    """Tests for memory_health_impl."""

    @pytest.mark.asyncio
    async def test_health_all_healthy(self, configured_manager: MagicMock) -> None:
        """Test health check with all healthy."""
        configured_manager.health_check.return_value = {
            "database": True,
            "qdrant": True,
            "redis": True,
            "embedding": True,
        }

        params = HealthCheckInput()
        result = await memory_health_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["overall"] is True
        assert data["data"]["database"] is True

    @pytest.mark.asyncio
    async def test_health_partial_failure(self, configured_manager: MagicMock) -> None:
        """Test health check with partial failure."""
        configured_manager.health_check.return_value = {
            "database": True,
            "qdrant": False,
            "redis": True,
            "embedding": True,
        }

        params = HealthCheckInput()
        result = await memory_health_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["overall"] is False
        assert data["data"]["qdrant"] is False

    @pytest.mark.asyncio
    async def test_health_all_failed(self, configured_manager: MagicMock) -> None:
        """Test health check with all failed."""
        configured_manager.health_check.return_value = {
            "database": False,
            "qdrant": False,
            "redis": False,
            "embedding": False,
        }

        params = HealthCheckInput()
        result = await memory_health_impl(params)

        data = json.loads(result)
        assert data["success"] is True
        assert data["data"]["overall"] is False


# =============================================================================
# Error Handling Tests
# =============================================================================


class TestErrorHandling:
    """Tests for error handling in all tools."""

    @pytest.mark.asyncio
    async def test_recall_exception_returns_error_json(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that exceptions are caught and returned as generic JSON error."""
        configured_manager.recall.side_effect = Exception("Unexpected error")

        params = MemoryRecallInput(query="test")
        result = await memory_recall_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        # Error message should be generic, not leak internal details
        assert "Memory recall failed" in data["error"]
        assert "Unexpected error" not in data["error"]

    @pytest.mark.asyncio
    async def test_store_exception_returns_error_json(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that exceptions are caught and returned as generic JSON error."""
        configured_manager.store.side_effect = Exception("Storage crashed")

        params = MemoryStoreInput(
            user_message="Hello",
            agent_response="Hi!",
        )
        result = await memory_store_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        # Error message should be generic, not leak internal details
        assert "Memory store failed" in data["error"]
        assert "Storage crashed" not in data["error"]

    @pytest.mark.asyncio
    async def test_health_exception_returns_error_json(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that health check exceptions return generic JSON error."""
        configured_manager.health_check.side_effect = Exception("Check failed")

        params = HealthCheckInput()
        result = await memory_health_impl(params)

        data = json.loads(result)
        assert data["success"] is False
        # Error message should be generic, not leak internal details
        assert "Health check failed" in data["error"]
        assert "Check failed" not in data["error"]

    @pytest.mark.asyncio
    async def test_invalid_uuid_returns_error(
        self, configured_manager: MagicMock
    ) -> None:
        """Test that invalid UUID returns error JSON."""
        # This should be caught by Pydantic validation before reaching the tool
        # But let's test the tool's own error handling for invalid UUIDs
        configured_manager.get_person.side_effect = ValueError("Invalid UUID")

        valid_uuid = str(uuid4())
        params = PersonGetInput(person_id=valid_uuid)
        result = await memory_people_get_impl(params)

        # The ValueError from get_person will be caught
        data = json.loads(result)
        assert data["success"] is False
