"""Memory MCP tool implementations.

This module provides FastMCP tool functions that wrap the MemoryManager
from Component 1.5 with proper error handling and JSON responses.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

from .memory_schemas import (
    HealthCheckInput,
    HealthOutput,
    LessonOutput,
    MemoryRecallInput,
    MemoryRecallOutput,
    MemoryStoreInput,
    MemoryStoreOutput,
    PeopleSearchInput,
    PersonGetInput,
    PersonOutput,
    ProjectGetInput,
    ProjectOutput,
    ProjectSearchInput,
    RankedEventOutput,
    ToolResponse,
    WorkingMemoryGetInput,
    WorkingMemoryOutput,
    WorkingMemoryUpdateInput,
)

if TYPE_CHECKING:
    from digital_valerii_shared.services.memory import MemoryManager

logger = logging.getLogger(__name__)

# =============================================================================
# Dependency Injection
# =============================================================================

_memory_manager: MemoryManager | None = None


def configure_memory_manager(manager: MemoryManager) -> None:
    """Configure the memory manager instance.

    Args:
        manager: MemoryManager instance to use for all tool operations.
    """
    global _memory_manager
    _memory_manager = manager
    logger.info("Memory manager configured for MCP server")


def get_memory_manager() -> MemoryManager:
    """Get the configured memory manager.

    Returns:
        The configured MemoryManager instance.

    Raises:
        RuntimeError: If memory manager is not configured.
    """
    if _memory_manager is None:
        raise RuntimeError(
            "MemoryManager not configured. Call configure_memory_manager() first."
        )
    return _memory_manager


def clear_memory_manager() -> None:
    """Clear the memory manager (for testing)."""
    global _memory_manager
    _memory_manager = None


# =============================================================================
# Helper Functions
# =============================================================================


def _serialize_response(data: Any) -> str:
    """Serialize response data to JSON string.

    Args:
        data: Data to serialize (Pydantic model or dict).

    Returns:
        JSON string representation.
    """
    if hasattr(data, "model_dump"):
        return json.dumps(data.model_dump(mode="json"), default=str, indent=2)
    return json.dumps(data, default=str, indent=2)


def _error_response(error: str) -> str:
    """Create a standardized error response.

    Args:
        error: Error message.

    Returns:
        JSON string with error response.
    """
    return _serialize_response(ToolResponse(success=False, error=error))


def _success_response(data: Any) -> str:
    """Create a standardized success response.

    Args:
        data: Response data.

    Returns:
        JSON string with success response.
    """
    if hasattr(data, "model_dump"):
        return _serialize_response(
            ToolResponse(success=True, data=data.model_dump(mode="json"))
        )
    return _serialize_response(ToolResponse(success=True, data=data))


# =============================================================================
# Tool Implementations
# =============================================================================


async def memory_recall_impl(params: MemoryRecallInput) -> str:
    """Search and retrieve relevant memories based on query.

    This tool performs hybrid search across PostgreSQL and Qdrant to find
    memories relevant to the query. Results include events, people, projects,
    and lessons, ranked by relevance with time decay.

    Args:
        params: Search parameters including query and limits.

    Returns:
        JSON string with matching memories or error.
    """
    try:
        manager = get_memory_manager()

        # Import here to avoid circular imports
        from digital_valerii_shared.services.memory import Context

        context = Context(
            session_id=params.session_id,
            conversation_id=params.conversation_id,
            message_index=0,
            interface="mcp",
        )

        result = await manager.recall(
            query=params.query,
            context=context,
            limit=params.limit,
        )

        # Convert to output schema
        output = MemoryRecallOutput(
            events=[
                RankedEventOutput(
                    event_id=str(e.event_id),
                    event_type=e.event_type,
                    title=e.title,
                    summary=e.summary,
                    occurred_at=e.occurred_at,
                    importance=e.importance,
                    vector_score=e.vector_score,
                    time_decay=e.time_decay,
                    final_score=e.final_score,
                )
                for e in result.events
            ],
            people=[
                PersonOutput(
                    id=str(p.id),
                    name=p.name,
                    email=p.email,
                    company=p.company,
                    relationship_type=p.relationship_type,
                )
                for p in result.people
            ],
            projects=[
                ProjectOutput(
                    id=str(p.id),
                    name=p.name,
                    status=p.status,
                    description=p.description,
                )
                for p in result.projects
            ],
            lessons=[
                LessonOutput(
                    id=str(ls.id),
                    content=ls.content,
                    category=ls.category,
                    confidence=ls.confidence,
                )
                for ls in result.lessons
            ],
            query=result.query,
            cached=result.cached,
        )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Memory recall failed")
        return _error_response("Memory recall failed. Check server logs for details.")


async def memory_store_impl(params: MemoryStoreInput) -> str:
    """Store an interaction in memory.

    This tool stores a user message and agent response pair in the memory
    system with embeddings for future semantic search.

    Args:
        params: Store parameters including messages and metadata.

    Returns:
        JSON string with store result or error.
    """
    try:
        manager = get_memory_manager()

        from digital_valerii_shared.services.memory import Context

        context = Context(
            session_id=params.session_id,
            conversation_id=params.conversation_id,
            message_index=0,
            interface=params.interface,
        )

        event = await manager.store(
            user_message=params.user_message,
            agent_response=params.agent_response,
            context=context,
            event_type=params.event_type,
            importance=params.importance,
        )

        output = MemoryStoreOutput(
            success=True,
            event_id=str(event.id),
            stored_at=event.occurred_at,
        )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Memory store failed")
        return _error_response("Memory store failed. Check server logs for details.")


async def memory_working_get_impl(params: WorkingMemoryGetInput) -> str:
    """Get current session working memory.

    This tool retrieves the working memory for a given session, including
    recent messages and context data stored in Redis.

    Args:
        params: Parameters with session ID.

    Returns:
        JSON string with working memory or error.
    """
    try:
        manager = get_memory_manager()

        result = await manager.get_working_memory(params.session_id)

        if result is None:
            output = WorkingMemoryOutput(
                session_id=params.session_id,
                messages=[],
                context={},
                updated_at=None,
            )
        else:
            output = WorkingMemoryOutput(
                session_id=result.session_id,
                messages=result.messages,
                context=result.context,
                updated_at=result.updated_at,
            )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Working memory get failed")
        return _error_response(
            "Working memory retrieval failed. Check server logs for details."
        )


async def memory_working_update_impl(params: WorkingMemoryUpdateInput) -> str:
    """Update session working memory.

    This tool updates the working memory for a session, merging context
    data and optionally replacing messages.

    Args:
        params: Update parameters with session ID and data.

    Returns:
        JSON string with update result or error.
    """
    try:
        manager = get_memory_manager()

        await manager.update_working_memory(
            session_id=params.session_id,
            messages=params.messages,
            context=params.context,
        )

        # Retrieve updated state
        result = await manager.get_working_memory(params.session_id)

        if result is None:
            output = WorkingMemoryOutput(
                session_id=params.session_id,
                messages=params.messages or [],
                context=params.context or {},
                updated_at=datetime.now(UTC),
            )
        else:
            output = WorkingMemoryOutput(
                session_id=result.session_id,
                messages=result.messages,
                context=result.context,
                updated_at=result.updated_at,
            )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Working memory update failed")
        return _error_response(
            "Working memory update failed. Check server logs for details."
        )


async def memory_people_search_impl(params: PeopleSearchInput) -> str:
    """Search for people in memory by name, email, or company.

    This tool searches the people database using pattern matching
    against name, email, and company fields.

    Args:
        params: Search parameters with query and limit.

    Returns:
        JSON string with matching people or error.
    """
    try:
        manager = get_memory_manager()

        people = await manager.search_people(
            query=params.query,
            limit=params.limit,
        )

        output = [
            PersonOutput(
                id=str(p.id),
                name=p.name,
                email=p.email,
                company=p.company,
                relationship_type=p.relationship_type,
            )
            for p in people
        ]

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("People search failed")
        return _error_response("People search failed. Check server logs for details.")


async def memory_people_get_impl(params: PersonGetInput) -> str:
    """Get detailed information about a specific person.

    This tool retrieves full details for a person by their UUID.

    Args:
        params: Parameters with person UUID.

    Returns:
        JSON string with person details or error.
    """
    try:
        manager = get_memory_manager()

        person = await manager.get_person(UUID(params.person_id))

        if person is None:
            return _error_response(f"Person not found: {params.person_id}")

        output = PersonOutput(
            id=str(person.id),
            name=person.name,
            email=person.email,
            company=person.company,
            relationship_type=person.relationship_type,
        )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except ValueError:
        return _error_response("Invalid person ID format.")
    except Exception:
        logger.exception("Person get failed")
        return _error_response(
            "Person retrieval failed. Check server logs for details."
        )


async def memory_projects_search_impl(params: ProjectSearchInput) -> str:
    """Search for projects in memory by name or description.

    This tool searches the projects database using pattern matching
    against name and description fields.

    Args:
        params: Search parameters with query and limit.

    Returns:
        JSON string with matching projects or error.
    """
    try:
        manager = get_memory_manager()

        projects = await manager.search_projects(
            query=params.query,
            limit=params.limit,
        )

        output = [
            ProjectOutput(
                id=str(p.id),
                name=p.name,
                status=p.status,
                description=p.description,
            )
            for p in projects
        ]

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Projects search failed")
        return _error_response("Projects search failed. Check server logs for details.")


async def memory_projects_get_impl(params: ProjectGetInput) -> str:
    """Get detailed information about a specific project.

    This tool retrieves full details for a project by its UUID.

    Args:
        params: Parameters with project UUID.

    Returns:
        JSON string with project details or error.
    """
    try:
        manager = get_memory_manager()

        project = await manager.get_project(UUID(params.project_id))

        if project is None:
            return _error_response(f"Project not found: {params.project_id}")

        output = ProjectOutput(
            id=str(project.id),
            name=project.name,
            status=project.status,
            description=project.description,
        )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except ValueError:
        return _error_response("Invalid project ID format.")
    except Exception:
        logger.exception("Project get failed")
        return _error_response(
            "Project retrieval failed. Check server logs for details."
        )


async def memory_health_impl(params: HealthCheckInput) -> str:  # noqa: ARG001
    """Check health of all memory system components.

    This tool checks the health of PostgreSQL, Qdrant, Redis, and
    embedding service backends.

    Args:
        params: Empty input (no parameters required).

    Returns:
        JSON string with health status of each component.
    """
    try:
        manager = get_memory_manager()

        health = await manager.health_check()

        output = HealthOutput(
            database=health.get("database", False),
            qdrant=health.get("qdrant", False),
            redis=health.get("redis", False),
            embedding=health.get("embedding", False),
            overall=all(health.values()),
        )

        return _success_response(output)

    except RuntimeError as e:
        return _error_response(str(e))
    except Exception:
        logger.exception("Health check failed")
        return _error_response("Health check failed. Check server logs for details.")
