# Digital Valerii

[![CI](https://github.com/ValeriiSysoiev/digital-valerii/actions/workflows/ci.yml/badge.svg)](https://github.com/ValeriiSysoiev/digital-valerii/actions/workflows/ci.yml)

> AI Clone / AI Avatar - A persistent AI that thinks, speaks, and acts as Valerii

## Overview

Digital Valerii is an AI-powered digital clone with:

- **Persistent Memory** - Remembers all interactions, projects, people
- **Multiple Interfaces** - CLI, Web, Slack, Voice, Meeting Avatar
- **Task Execution** - Calendar, email, documents, browser automation
- **Continuous Learning** - Extracts lessons from experience

## Quick Start

```bash
# Clone and setup
cd digital-valerii

# Start local development environment
docker-compose up -d

# Install CLI
cd apps/cli && pip install -e .

# Run CLI
dv chat
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md) - Full system design
- [Setup Guide](docs/SETUP.md) - Installation instructions
- [API Reference](docs/API.md) - API documentation

## Project Structure

```
digital-valerii/
├── docs/              # Documentation
├── apps/
│   ├── api/          # FastAPI Backend
│   ├── web/          # Next.js Dashboard
│   └── cli/          # CLI Interface
├── packages/
│   └── shared/       # Shared code
├── infrastructure/   # Docker, Railway, Azure configs
└── scripts/          # Utility scripts
```

## Tech Stack

| Component | Technology |
|-----------|------------|
| Agent | Claude Agent SDK + Claude Sonnet 4 |
| Backend | Python + FastAPI |
| Frontend | Next.js 15 |
| Database | PostgreSQL + Qdrant + Redis |
| Avatar | HeyGen Interactive |
| Meetings | Recall.ai |
| Voice | ElevenLabs |

## Development Phases

- [x] Phase 1: Architecture Design
- [ ] Phase 2: Foundation (Agent + Memory + CLI)
- [ ] Phase 3: Web Dashboard
- [ ] Phase 4: Slack Integration
- [ ] Phase 5: Voice & Avatar
- [ ] Phase 6: Production Polish

## License

Private - All rights reserved
