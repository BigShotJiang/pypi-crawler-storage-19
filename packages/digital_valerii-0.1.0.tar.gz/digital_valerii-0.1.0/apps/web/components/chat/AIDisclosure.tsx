"use client";

import { Bot, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/Tooltip";

/**
 * AI Disclosure Banner - EU AI Act Article 50 Compliance
 *
 * This component MUST be visible at all times when users interact with AI.
 * It cannot be dismissed or hidden.
 *
 * Requirements:
 * - Persistent visibility
 * - Clear disclosure that user is chatting with AI
 * - Additional information available via tooltip
 * - Accessible (proper ARIA attributes)
 */
export function AIDisclosure() {
  return (
    <TooltipProvider>
      <div
        className="flex items-center justify-center gap-2 px-4 py-2 bg-muted/50 border-b border-border text-sm"
        role="status"
        aria-live="polite"
        aria-label="AI disclosure notice"
      >
        <Bot className="h-4 w-4 text-primary shrink-0" aria-hidden="true" />
        <span className="text-muted-foreground">
          You are chatting with an <span className="font-medium text-foreground">AI assistant</span>
        </span>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              className="inline-flex items-center justify-center h-5 w-5 rounded-full hover:bg-muted transition-colors"
              aria-label="More information about AI disclosure"
            >
              <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="text-sm">
              This is <strong>Digital Valerii</strong>, an AI system. All responses
              are AI-generated and should be verified for accuracy. This
              disclosure is required by EU AI Act Article 50.
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
