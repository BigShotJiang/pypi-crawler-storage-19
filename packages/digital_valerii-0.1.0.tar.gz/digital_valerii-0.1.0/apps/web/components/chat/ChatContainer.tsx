"use client";

import { useEffect } from "react";
import { useChatStore } from "@/lib/stores/chat";
import { AIDisclosure } from "@/components/chat/AIDisclosure";
import { ChatMessageList } from "@/components/chat/ChatMessageList";
import { ChatInput } from "@/components/chat/ChatInput";
import { AlertCircle, X } from "lucide-react";
import { Button } from "@/components/ui/Button";

interface ChatContainerProps {
  conversationId?: string;
}

export function ChatContainer({ conversationId }: ChatContainerProps) {
  const {
    currentConversation,
    isLoading,
    isSending,
    error,
    fetchConversation,
    sendMessage,
    setCurrentConversation,
    clearError,
  } = useChatStore();

  // Fetch conversation if ID provided
  useEffect(() => {
    if (conversationId) {
      fetchConversation(conversationId);
    } else {
      setCurrentConversation(null);
    }
  }, [conversationId, fetchConversation, setCurrentConversation]);

  const handleSendMessage = async (message: string) => {
    await sendMessage(message);
  };

  return (
    <div className="flex flex-col h-full">
      {/* AI Disclosure Banner - EU AI Act Art.50 Compliance */}
      <AIDisclosure />

      {/* Error Banner */}
      {error && (
        <div className="flex items-center justify-between gap-2 px-4 py-2 bg-destructive/10 border-b border-destructive/20">
          <div className="flex items-center gap-2 text-sm text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={clearError}
            className="h-6 w-6 text-destructive hover:bg-destructive/20"
            aria-label="Dismiss error"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Message List */}
      <ChatMessageList
        messages={currentConversation?.messages || []}
        isLoading={isLoading && !!conversationId}
      />

      {/* Input Area */}
      <ChatInput
        onSend={handleSendMessage}
        disabled={isSending}
        placeholder={isSending ? "Generating response..." : "Send a message..."}
      />
    </div>
  );
}
