import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { AIDisclosure } from "../AIDisclosure";

describe("AIDisclosure", () => {
  it("renders the AI disclosure message", () => {
    render(<AIDisclosure />);

    expect(screen.getByText(/You are chatting with an/)).toBeInTheDocument();
    expect(screen.getByText("AI assistant")).toBeInTheDocument();
  });

  it("has proper accessibility attributes", () => {
    render(<AIDisclosure />);

    const disclosure = screen.getByRole("status");
    expect(disclosure).toHaveAttribute("aria-live", "polite");
    expect(disclosure).toHaveAttribute(
      "aria-label",
      "AI disclosure notice"
    );
  });

  it("contains info button for more details", () => {
    render(<AIDisclosure />);

    const infoButton = screen.getByRole("button", {
      name: /More information about AI disclosure/i,
    });
    expect(infoButton).toBeInTheDocument();
  });

  it("displays bot icon", () => {
    render(<AIDisclosure />);

    // Check that the container has the bot icon (via aria-hidden)
    const disclosure = screen.getByRole("status");
    expect(disclosure.querySelector('[aria-hidden="true"]')).toBeInTheDocument();
  });
});
