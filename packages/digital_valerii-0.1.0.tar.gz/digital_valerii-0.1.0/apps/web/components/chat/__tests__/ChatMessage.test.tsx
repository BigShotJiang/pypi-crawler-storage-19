import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ChatMessage } from "../ChatMessage";
import type { Message } from "@/types";

describe("ChatMessage", () => {
  const userMessage: Message = {
    id: "1",
    role: "user",
    content: "Hello, how are you?",
    timestamp: new Date().toISOString(),
  };

  const assistantMessage: Message = {
    id: "2",
    role: "assistant",
    content: "I am doing well, thank you for asking!",
    timestamp: new Date().toISOString(),
  };

  it("renders user message with correct label", () => {
    render(<ChatMessage message={userMessage} />);

    expect(screen.getByText("You")).toBeInTheDocument();
    expect(screen.getByText("Hello, how are you?")).toBeInTheDocument();
  });

  it("renders assistant message with correct label", () => {
    render(<ChatMessage message={assistantMessage} />);

    expect(screen.getByText("Digital Valerii")).toBeInTheDocument();
    expect(
      screen.getByText("I am doing well, thank you for asking!")
    ).toBeInTheDocument();
  });

  it("has proper accessibility attributes", () => {
    render(<ChatMessage message={userMessage} />);

    expect(
      screen.getByRole("article", { name: "Your message" })
    ).toBeInTheDocument();
  });

  it("shows copy button for assistant messages on hover", async () => {
    render(<ChatMessage message={assistantMessage} />);

    // Copy button should exist but be hidden initially
    const copyButton = screen.getByRole("button", { name: /copy/i });
    expect(copyButton).toBeInTheDocument();
  });

  it("copies message content when copy button is clicked", async () => {
    // Set up clipboard mock for this test
    const writeTextMock = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      value: { writeText: writeTextMock },
      writable: true,
      configurable: true,
    });

    render(<ChatMessage message={assistantMessage} />);

    const copyButton = screen.getByRole("button", { name: /copy/i });
    // Use fireEvent instead of userEvent for elements with opacity:0
    fireEvent.click(copyButton);

    // Wait for async clipboard operation
    await waitFor(() => {
      expect(writeTextMock).toHaveBeenCalledWith(
        "I am doing well, thank you for asking!"
      );
    });
  });

  it("shows streaming indicator when isStreaming is true", () => {
    const streamingMessage: Message = {
      ...assistantMessage,
      is_streaming: true,
    };

    render(<ChatMessage message={streamingMessage} isStreaming />);

    // The message container should have animate-pulse class
    const content = screen.getByText("I am doing well, thank you for asking!");
    expect(content.closest(".animate-pulse")).toBeInTheDocument();
  });

  it("renders markdown content in assistant messages", () => {
    const markdownMessage: Message = {
      id: "3",
      role: "assistant",
      content: "Here is **bold** text and *italic* text.",
      timestamp: new Date().toISOString(),
    };

    render(<ChatMessage message={markdownMessage} />);

    expect(screen.getByText("bold")).toBeInTheDocument();
    expect(screen.getByText("italic")).toBeInTheDocument();
  });

  it("does not show copy button for user messages", () => {
    render(<ChatMessage message={userMessage} />);

    expect(
      screen.queryByRole("button", { name: /copy/i })
    ).not.toBeInTheDocument();
  });

  it("preserves whitespace in user messages", () => {
    const multilineMessage: Message = {
      id: "4",
      role: "user",
      content: "Line 1\nLine 2\nLine 3",
      timestamp: new Date().toISOString(),
    };

    render(<ChatMessage message={multilineMessage} />);

    const paragraph = screen.getByText(/Line 1/);
    expect(paragraph).toHaveClass("whitespace-pre-wrap");
  });
});
