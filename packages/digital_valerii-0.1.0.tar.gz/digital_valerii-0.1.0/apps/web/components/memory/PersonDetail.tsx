"use client";

import { memo } from "react";
import Link from "next/link";
import {
  Mail,
  Building2,
  MessageSquare,
  Calendar,
  ArrowLeft,
  StickyNote,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Avatar, AvatarFallback } from "@/components/ui/Avatar";
import { Skeleton } from "@/components/ui/Skeleton";
import { RelationshipBadge } from "./RelationshipBadge";
import type { PersonDetail as PersonDetailType } from "@/types";
import { cn, formatDate } from "@/lib/utils";

interface PersonDetailProps {
  person: PersonDetailType;
  className?: string;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function PersonDetailComponent({ person, className }: PersonDetailProps) {
  return (
    <div className={cn("space-y-6", className)}>
      {/* Back navigation */}
      <div>
        <Button
          variant="ghost"
          size="sm"
          asChild
          className="gap-2 text-muted-foreground hover:text-foreground"
        >
          <Link href="/memory/people">
            <ArrowLeft className="h-4 w-4" />
            Back to People
          </Link>
        </Button>
      </div>

      {/* Header card */}
      <Card className="bg-card/60 backdrop-blur-sm border-border/50 overflow-hidden">
        {/* Decorative gradient header */}
        <div
          className="h-24 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent"
          aria-hidden="true"
        />

        <CardContent className="relative -mt-12 pb-6">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            {/* Avatar */}
            <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
              <AvatarFallback
                className={cn(
                  "text-2xl font-bold",
                  "bg-gradient-to-br from-primary/30 to-primary/10",
                  "text-primary"
                )}
              >
                {getInitials(person.name)}
              </AvatarFallback>
            </Avatar>

            {/* Info */}
            <div className="flex-1 mt-2 sm:mt-8">
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <h1 className="text-2xl font-bold text-foreground">
                  {person.name}
                </h1>
                {person.relationship_type && (
                  <RelationshipBadge type={person.relationship_type} />
                )}
              </div>

              {/* Contact info */}
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                {person.email && (
                  <a
                    href={`mailto:${person.email}`}
                    className="flex items-center gap-1.5 hover:text-primary transition-colors"
                  >
                    <Mail className="h-4 w-4" />
                    {person.email}
                  </a>
                )}
                {person.company && (
                  <span className="flex items-center gap-1.5">
                    <Building2 className="h-4 w-4" />
                    {person.company}
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Interaction count */}
        <Card className="bg-card/60 backdrop-blur-sm border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-primary/10">
                <MessageSquare className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {person.interaction_count}
                </p>
                <p className="text-xs text-muted-foreground">Interactions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Last interaction */}
        <Card className="bg-card/60 backdrop-blur-sm border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-muted">
                <Calendar className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">
                  {person.last_interaction
                    ? formatDate(person.last_interaction)
                    : "Never"}
                </p>
                <p className="text-xs text-muted-foreground">Last Seen</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notes */}
      {person.notes && (
        <Card className="bg-card/60 backdrop-blur-sm border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-semibold">
              <StickyNote className="h-4 w-4 text-primary" />
              Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
              {person.notes}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export const PersonDetail = memo(PersonDetailComponent);

// Loading skeleton
export function PersonDetailSkeleton() {
  return (
    <div className="space-y-6">
      {/* Back button skeleton */}
      <Skeleton className="h-8 w-32" />

      {/* Header card skeleton */}
      <Card className="bg-card/60 border-border/50 overflow-hidden">
        <div className="h-24 bg-muted" />
        <CardContent className="relative -mt-12 pb-6">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            <Skeleton className="h-24 w-24 rounded-full" />
            <div className="flex-1 mt-8 space-y-4">
              <Skeleton className="h-8 w-48" />
              <div className="flex gap-4">
                <Skeleton className="h-5 w-40" />
                <Skeleton className="h-5 w-32" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats skeleton */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-card/60 border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <Skeleton className="h-10 w-10 rounded-lg" />
              <div className="space-y-1">
                <Skeleton className="h-7 w-12" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card/60 border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <Skeleton className="h-10 w-10 rounded-lg" />
              <div className="space-y-1">
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-3 w-16" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notes skeleton */}
      <Card className="bg-card/60 border-border/50">
        <CardHeader className="pb-3">
          <Skeleton className="h-5 w-20" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-4/5" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
