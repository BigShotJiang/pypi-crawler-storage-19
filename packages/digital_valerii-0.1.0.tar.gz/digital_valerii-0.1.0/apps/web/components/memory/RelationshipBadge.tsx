"use client";

import { memo } from "react";
import { Heart, Briefcase, UserCheck, Users, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type RelationshipType =
  | "friend"
  | "colleague"
  | "client"
  | "family"
  | "acquaintance"
  | string;

interface RelationshipBadgeProps {
  type: RelationshipType | null;
  size?: "sm" | "md";
  className?: string;
}

const relationshipConfig: Record<
  string,
  {
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    colors: string;
  }
> = {
  friend: {
    label: "Friend",
    icon: Heart,
    colors:
      "bg-rose-500/10 text-rose-500 border-rose-500/20 dark:bg-rose-500/15 dark:text-rose-400",
  },
  colleague: {
    label: "Colleague",
    icon: Briefcase,
    colors:
      "bg-primary/10 text-primary border-primary/20 dark:bg-primary/15",
  },
  client: {
    label: "Client",
    icon: UserCheck,
    colors:
      "bg-violet-500/10 text-violet-500 border-violet-500/20 dark:bg-violet-500/15 dark:text-violet-400",
  },
  family: {
    label: "Family",
    icon: Users,
    colors:
      "bg-teal-500/10 text-teal-500 border-teal-500/20 dark:bg-teal-500/15 dark:text-teal-400",
  },
  acquaintance: {
    label: "Acquaintance",
    icon: HelpCircle,
    colors:
      "bg-muted text-muted-foreground border-border dark:bg-muted/50",
  },
};

function RelationshipBadgeComponent({
  type,
  size = "md",
  className,
}: RelationshipBadgeProps) {
  if (!type) return null;

  const normalizedType = type.toLowerCase();
  const config = relationshipConfig[normalizedType] || {
    label: type.charAt(0).toUpperCase() + type.slice(1),
    icon: HelpCircle,
    colors: "bg-muted text-muted-foreground border-border",
  };
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        "transition-colors duration-200",
        config.colors,
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-xs",
        className
      )}
      role="status"
      aria-label={`Relationship: ${config.label}`}
    >
      <Icon className={cn(size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5")} />
      {config.label}
    </span>
  );
}

export const RelationshipBadge = memo(RelationshipBadgeComponent);
