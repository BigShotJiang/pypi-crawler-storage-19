"use client";

import { memo } from "react";
import Link from "next/link";
import { FolderKanban, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { StatusBadge } from "./StatusBadge";
import type { ProjectSummary } from "@/types";
import { cn } from "@/lib/utils";

interface ProjectCardProps {
  project: ProjectSummary;
  className?: string;
}

function ProjectCardComponent({ project, className }: ProjectCardProps) {
  return (
    <Link
      href={`/memory/projects/${project.id}`}
      className={cn("block group focus:outline-none", className)}
      aria-label={`View ${project.name} project`}
    >
      <Card
        className={cn(
          "relative overflow-hidden h-full",
          "bg-card/60 backdrop-blur-sm border-border/50",
          "transition-all duration-300 ease-out",
          "hover:bg-card hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
          "hover:-translate-y-0.5",
          "group-focus:ring-2 group-focus:ring-primary/50 group-focus:ring-offset-2 group-focus:ring-offset-background"
        )}
      >
        <CardContent className="p-5">
          {/* Header with icon and status */}
          <div className="flex items-start justify-between gap-3 mb-4">
            <div
              className={cn(
                "p-2.5 rounded-lg",
                "bg-gradient-to-br from-violet-500/20 to-violet-500/5",
                "border border-violet-500/20"
              )}
            >
              <FolderKanban className="h-5 w-5 text-violet-500 dark:text-violet-400" />
            </div>
            <StatusBadge status={project.status} size="sm" />
          </div>

          {/* Name */}
          <h3
            className={cn(
              "text-base font-semibold text-foreground mb-2",
              "line-clamp-2 group-hover:text-primary transition-colors duration-200"
            )}
          >
            {project.name}
          </h3>

          {/* Description */}
          {project.description && (
            <p className="text-sm text-muted-foreground line-clamp-3">
              {project.description}
            </p>
          )}

          {/* View arrow */}
          <div
            className={cn(
              "absolute bottom-4 right-4",
              "opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0",
              "transition-all duration-300"
            )}
            aria-hidden="true"
          >
            <ArrowRight className="h-4 w-4 text-primary" />
          </div>
        </CardContent>

        {/* Bottom accent line on hover */}
        <div
          className={cn(
            "absolute bottom-0 left-0 right-0 h-0.5",
            "bg-gradient-to-r from-transparent via-violet-500 to-transparent",
            "opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          )}
          aria-hidden="true"
        />
      </Card>
    </Link>
  );
}

export const ProjectCard = memo(ProjectCardComponent);

// Skeleton variant
export function ProjectCardSkeleton() {
  return (
    <Card className="bg-card/60 border-border/50">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-start justify-between">
          <div className="h-10 w-10 rounded-lg bg-muted animate-pulse" />
          <div className="h-6 w-20 rounded-full bg-muted animate-pulse" />
        </div>
        <div className="h-5 w-3/4 bg-muted animate-pulse rounded" />
        <div className="space-y-2">
          <div className="h-4 w-full bg-muted animate-pulse rounded" />
          <div className="h-4 w-5/6 bg-muted animate-pulse rounded" />
        </div>
      </CardContent>
    </Card>
  );
}
