"use client";

import { memo } from "react";
import { CheckCircle2, Archive, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

type ProjectStatus = "active" | "completed" | "archived";

interface StatusBadgeProps {
  status: ProjectStatus;
  size?: "sm" | "md";
  className?: string;
}

const statusConfig: Record<
  ProjectStatus,
  {
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    colors: string;
  }
> = {
  active: {
    label: "Active",
    icon: Clock,
    colors:
      "bg-emerald-500/10 text-emerald-500 border-emerald-500/20 dark:bg-emerald-500/15 dark:text-emerald-400",
  },
  completed: {
    label: "Completed",
    icon: CheckCircle2,
    colors:
      "bg-blue-500/10 text-blue-500 border-blue-500/20 dark:bg-blue-500/15 dark:text-blue-400",
  },
  archived: {
    label: "Archived",
    icon: Archive,
    colors:
      "bg-muted text-muted-foreground border-border dark:bg-muted/50",
  },
};

function StatusBadgeComponent({
  status,
  size = "md",
  className,
}: StatusBadgeProps) {
  const config = statusConfig[status] || statusConfig.archived;
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium",
        "transition-colors duration-200",
        config.colors,
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-xs",
        className
      )}
      role="status"
      aria-label={`Project status: ${config.label}`}
    >
      <Icon className={cn(size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5")} />
      {config.label}
    </span>
  );
}

export const StatusBadge = memo(StatusBadgeComponent);
