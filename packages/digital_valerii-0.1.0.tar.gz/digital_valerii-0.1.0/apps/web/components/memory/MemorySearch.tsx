"use client";

import { useCallback, useState, useEffect } from "react";
import { Search, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

interface MemorySearchProps {
  value: string;
  onChange: (value: string) => void;
  onSearch: (query: string) => void;
  isLoading?: boolean;
  placeholder?: string;
  debounceMs?: number;
  className?: string;
}

export function MemorySearch({
  value,
  onChange,
  onSearch,
  isLoading = false,
  placeholder = "Search your memories...",
  debounceMs = 300,
  className,
}: MemorySearchProps) {
  const [localValue, setLocalValue] = useState(value);

  // Sync with external value
  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (localValue !== value) {
        onChange(localValue);
        if (localValue.trim()) {
          onSearch(localValue);
        }
      }
    }, debounceMs);

    return () => clearTimeout(timer);
  }, [localValue, value, onChange, onSearch, debounceMs]);

  const handleClear = useCallback(() => {
    setLocalValue("");
    onChange("");
  }, [onChange]);

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      if (localValue.trim()) {
        onSearch(localValue);
      }
    },
    [localValue, onSearch]
  );

  return (
    <form
      onSubmit={handleSubmit}
      className={cn("relative group", className)}
      role="search"
    >
      {/* Ambient glow effect */}
      <div
        className={cn(
          "absolute -inset-1 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 rounded-xl blur-lg opacity-0 transition-opacity duration-500",
          localValue && "opacity-100"
        )}
        aria-hidden="true"
      />

      <div className="relative flex items-center">
        {/* Search icon with pulse animation when loading */}
        <div className="absolute left-4 z-10">
          {isLoading ? (
            <Loader2
              className="h-5 w-5 text-primary animate-spin"
              aria-hidden="true"
            />
          ) : (
            <Search
              className={cn(
                "h-5 w-5 transition-colors duration-300",
                localValue
                  ? "text-primary"
                  : "text-muted-foreground group-focus-within:text-primary"
              )}
              aria-hidden="true"
            />
          )}
        </div>

        <Input
          type="search"
          value={localValue}
          onChange={(e) => setLocalValue(e.target.value)}
          placeholder={placeholder}
          aria-label="Search memories"
          className={cn(
            "w-full h-14 pl-12 pr-12 text-base",
            "bg-card/60 backdrop-blur-sm border-border/50",
            "placeholder:text-muted-foreground/60",
            "hover:border-primary/30 hover:bg-card/80",
            "focus:border-primary/50 focus:bg-card focus:ring-primary/20",
            "transition-all duration-300"
          )}
        />

        {/* Clear button with fade animation */}
        {localValue && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={handleClear}
            className={cn(
              "absolute right-2 h-8 w-8",
              "text-muted-foreground hover:text-foreground",
              "opacity-0 animate-in fade-in duration-200",
              localValue && "opacity-100"
            )}
            aria-label="Clear search"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Keyboard hint */}
      <div
        className={cn(
          "absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none",
          "opacity-0 group-focus-within:opacity-0 transition-opacity duration-200",
          !localValue && "opacity-50"
        )}
        aria-hidden="true"
      >
        <kbd className="hidden sm:inline-flex h-6 items-center gap-1 rounded border border-border/50 bg-muted/50 px-2 font-mono text-xs text-muted-foreground">
          <span className="text-xs">Enter</span>
        </kbd>
      </div>
    </form>
  );
}
