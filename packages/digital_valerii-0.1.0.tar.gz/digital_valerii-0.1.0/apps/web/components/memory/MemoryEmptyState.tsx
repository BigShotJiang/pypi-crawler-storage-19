"use client";

import { memo } from "react";
import { Search, Brain, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

type EmptyStateVariant = "search" | "no-results" | "no-data";

interface MemoryEmptyStateProps {
  variant?: EmptyStateVariant;
  searchQuery?: string;
  title?: string;
  description?: string;
  className?: string;
}

const variantConfig: Record<
  EmptyStateVariant,
  {
    icon: React.ComponentType<{ className?: string }>;
    defaultTitle: string;
    defaultDescription: string;
  }
> = {
  search: {
    icon: Brain,
    defaultTitle: "Explore Your Memories",
    defaultDescription:
      "Search through your stored memories, people, and projects. Start typing to discover connections.",
  },
  "no-results": {
    icon: Search,
    defaultTitle: "No Memories Found",
    defaultDescription:
      "We couldn't find any memories matching your search. Try different keywords or broaden your search.",
  },
  "no-data": {
    icon: Sparkles,
    defaultTitle: "No Memories Yet",
    defaultDescription:
      "Start conversations to build your memory bank. Your memories, people, and projects will appear here.",
  },
};

function MemoryEmptyStateComponent({
  variant = "search",
  searchQuery,
  title,
  description,
  className,
}: MemoryEmptyStateProps) {
  const config = variantConfig[variant];
  const Icon = config.icon;

  const displayTitle = title || config.defaultTitle;
  const displayDescription =
    description ||
    (variant === "no-results" && searchQuery
      ? `No results found for "${searchQuery}". Try adjusting your search terms.`
      : config.defaultDescription);

  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center py-16 px-4 text-center",
        className
      )}
      role="status"
      aria-label={displayTitle}
    >
      {/* Animated icon container */}
      <div className="relative mb-6">
        {/* Background glow */}
        <div
          className={cn(
            "absolute inset-0 blur-3xl rounded-full",
            "bg-gradient-to-br from-primary/20 via-primary/10 to-transparent",
            "animate-pulse"
          )}
          style={{ animationDuration: "3s" }}
          aria-hidden="true"
        />

        {/* Icon container with ring */}
        <div
          className={cn(
            "relative w-20 h-20 rounded-full",
            "bg-gradient-to-br from-muted to-muted/50",
            "border border-border/50",
            "flex items-center justify-center",
            "shadow-lg shadow-background/50"
          )}
        >
          <Icon
            className={cn(
              "h-10 w-10 text-muted-foreground",
              variant === "search" && "text-primary/70"
            )}
          />

          {/* Decorative particles */}
          {variant === "search" && (
            <>
              <span
                className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary/60 animate-ping"
                style={{ animationDuration: "2s", animationDelay: "0.5s" }}
                aria-hidden="true"
              />
              <span
                className="absolute -bottom-0.5 -left-0.5 w-1.5 h-1.5 rounded-full bg-primary/40 animate-ping"
                style={{ animationDuration: "2s", animationDelay: "1s" }}
                aria-hidden="true"
              />
            </>
          )}
        </div>
      </div>

      {/* Title */}
      <h3 className="text-xl font-semibold text-foreground mb-2">
        {displayTitle}
      </h3>

      {/* Description */}
      <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
        {displayDescription}
      </p>

      {/* Keyboard hint for search variant */}
      {variant === "search" && (
        <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground/60">
          <kbd className="px-2 py-1 rounded bg-muted/50 border border-border/50 font-mono">
            /
          </kbd>
          <span>to focus search</span>
        </div>
      )}
    </div>
  );
}

export const MemoryEmptyState = memo(MemoryEmptyStateComponent);
