import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ProjectCard, ProjectCardSkeleton } from "../ProjectCard";
import type { ProjectSummary } from "@/types";

// Mock next/link
vi.mock("next/link", () => ({
  default: ({
    children,
    href,
    ...props
  }: {
    children: React.ReactNode;
    href: string;
    [key: string]: unknown;
  }) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

describe("ProjectCard", () => {
  const baseProject: ProjectSummary = {
    id: "456",
    name: "AI Clone Project",
    status: "active",
    description: "Building an AI avatar system",
  };

  it("renders project name", () => {
    render(<ProjectCard project={baseProject} />);

    expect(screen.getByText("AI Clone Project")).toBeInTheDocument();
  });

  it("renders project description", () => {
    render(<ProjectCard project={baseProject} />);

    expect(
      screen.getByText("Building an AI avatar system")
    ).toBeInTheDocument();
  });

  it("renders active status badge", () => {
    render(<ProjectCard project={baseProject} />);

    expect(screen.getByText("Active")).toBeInTheDocument();
  });

  it("renders completed status badge", () => {
    const completedProject: ProjectSummary = {
      ...baseProject,
      status: "completed",
    };

    render(<ProjectCard project={completedProject} />);

    expect(screen.getByText("Completed")).toBeInTheDocument();
  });

  it("renders archived status badge", () => {
    const archivedProject: ProjectSummary = {
      ...baseProject,
      status: "archived",
    };

    render(<ProjectCard project={archivedProject} />);

    expect(screen.getByText("Archived")).toBeInTheDocument();
  });

  it("links to project detail page", () => {
    render(<ProjectCard project={baseProject} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/memory/projects/456");
  });

  it("has proper accessibility label", () => {
    render(<ProjectCard project={baseProject} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("aria-label", "View AI Clone Project project");
  });

  it("handles missing description", () => {
    const projectWithoutDescription: ProjectSummary = {
      ...baseProject,
      description: null,
    };

    render(<ProjectCard project={projectWithoutDescription} />);

    expect(screen.getByText("AI Clone Project")).toBeInTheDocument();
    expect(
      screen.queryByText("Building an AI avatar system")
    ).not.toBeInTheDocument();
  });
});

describe("ProjectCardSkeleton", () => {
  it("renders skeleton elements", () => {
    render(<ProjectCardSkeleton />);

    // Should have animated skeleton elements
    const skeletons = document.querySelectorAll(".animate-pulse");
    expect(skeletons.length).toBeGreaterThan(0);
  });
});
