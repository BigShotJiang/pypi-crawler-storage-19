import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemorySearch } from "../MemorySearch";

describe("MemorySearch", () => {
  const defaultProps = {
    value: "",
    onChange: vi.fn(),
    onSearch: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders search input with placeholder", () => {
    render(<MemorySearch {...defaultProps} />);

    expect(
      screen.getByPlaceholderText("Search your memories...")
    ).toBeInTheDocument();
  });

  it("renders with custom placeholder", () => {
    render(
      <MemorySearch {...defaultProps} placeholder="Find something..." />
    );

    expect(
      screen.getByPlaceholderText("Find something...")
    ).toBeInTheDocument();
  });

  it("displays current value in input", () => {
    render(<MemorySearch {...defaultProps} value="test query" />);

    expect(screen.getByRole("searchbox")).toHaveValue("test query");
  });

  it("calls onChange when input value changes", async () => {
    const onChange = vi.fn();
    render(<MemorySearch {...defaultProps} onChange={onChange} debounceMs={0} />);

    const input = screen.getByRole("searchbox");
    await userEvent.type(input, "hello");

    await waitFor(() => {
      expect(onChange).toHaveBeenCalled();
    });
  });

  it("calls onSearch after debounce when typing", async () => {
    const onSearch = vi.fn();
    render(
      <MemorySearch {...defaultProps} onSearch={onSearch} debounceMs={100} />
    );

    const input = screen.getByRole("searchbox");
    await userEvent.type(input, "test");

    // Wait for debounce
    await waitFor(
      () => {
        expect(onSearch).toHaveBeenCalledWith("test");
      },
      { timeout: 500 }
    );
  });

  it("shows clear button when value exists", async () => {
    render(<MemorySearch {...defaultProps} value="some text" />);

    const input = screen.getByRole("searchbox");
    await userEvent.type(input, "more");

    await waitFor(() => {
      expect(screen.getByLabelText("Clear search")).toBeInTheDocument();
    });
  });

  it("clears input when clear button is clicked", async () => {
    const onChange = vi.fn();
    render(<MemorySearch {...defaultProps} value="test" onChange={onChange} />);

    // Type something first to make clear button visible
    const input = screen.getByRole("searchbox");
    await userEvent.type(input, " more");

    // Click clear button
    const clearButton = screen.getByLabelText("Clear search");
    await userEvent.click(clearButton);

    expect(onChange).toHaveBeenCalledWith("");
  });

  it("shows loading indicator when isLoading is true", () => {
    render(<MemorySearch {...defaultProps} isLoading />);

    // Loading indicator should be present (spinner)
    const container = screen.getByRole("search");
    expect(container.querySelector(".animate-spin")).toBeInTheDocument();
  });

  it("has proper accessibility attributes", () => {
    render(<MemorySearch {...defaultProps} />);

    expect(screen.getByRole("search")).toBeInTheDocument();
    expect(screen.getByLabelText("Search memories")).toBeInTheDocument();
  });

  it("submits on form submit", async () => {
    const onSearch = vi.fn();
    render(<MemorySearch {...defaultProps} value="query" onSearch={onSearch} />);

    const form = screen.getByRole("search");
    fireEvent.submit(form);

    expect(onSearch).toHaveBeenCalledWith("query");
  });
});
