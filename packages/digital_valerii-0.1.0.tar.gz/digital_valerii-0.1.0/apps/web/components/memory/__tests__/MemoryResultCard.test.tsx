import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryResultCard } from "../MemoryResultCard";
import type { MemorySearchResult } from "@/types";

// Mock next/link
vi.mock("next/link", () => ({
  default: ({
    children,
    href,
    ...props
  }: {
    children: React.ReactNode;
    href: string;
    [key: string]: unknown;
  }) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

describe("MemoryResultCard", () => {
  const baseResult: MemorySearchResult = {
    event_id: "123",
    event_type: "person",
    title: "John Doe",
    summary: "A colleague from work",
    occurred_at: "2024-01-15T10:30:00Z",
    score: 0.85,
  };

  it("renders the title", () => {
    render(<MemoryResultCard result={baseResult} />);

    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });

  it("renders the summary", () => {
    render(<MemoryResultCard result={baseResult} />);

    expect(screen.getByText("A colleague from work")).toBeInTheDocument();
  });

  it("renders the event type", () => {
    render(<MemoryResultCard result={baseResult} />);

    expect(screen.getByText("person")).toBeInTheDocument();
  });

  it("renders relevance score as percentage", () => {
    render(<MemoryResultCard result={baseResult} />);

    expect(screen.getByText("85%")).toBeInTheDocument();
  });

  it("links to person detail page for person type", () => {
    render(<MemoryResultCard result={baseResult} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/memory/people/123");
  });

  it("links to project detail page for project type", () => {
    const projectResult: MemorySearchResult = {
      ...baseResult,
      event_type: "project",
    };

    render(<MemoryResultCard result={projectResult} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/memory/projects/123");
  });

  it("links to chat for conversation type", () => {
    const conversationResult: MemorySearchResult = {
      ...baseResult,
      event_type: "conversation",
    };

    render(<MemoryResultCard result={conversationResult} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/chat/123");
  });

  it("has proper accessibility label", () => {
    render(<MemoryResultCard result={baseResult} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("aria-label", "John Doe - person");
  });

  it("shows relevance score accessibility label", () => {
    render(<MemoryResultCard result={baseResult} />);

    expect(
      screen.getByLabelText("Relevance score: 85 percent")
    ).toBeInTheDocument();
  });

  it("handles result without title", () => {
    const noTitleResult: MemorySearchResult = {
      ...baseResult,
      title: null,
    };

    render(<MemoryResultCard result={noTitleResult} />);

    // Should still render without errors
    expect(screen.getByText("A colleague from work")).toBeInTheDocument();
  });

  it("handles result without summary", () => {
    const noSummaryResult: MemorySearchResult = {
      ...baseResult,
      summary: null,
    };

    render(<MemoryResultCard result={noSummaryResult} />);

    // Should still render the title
    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });
});
