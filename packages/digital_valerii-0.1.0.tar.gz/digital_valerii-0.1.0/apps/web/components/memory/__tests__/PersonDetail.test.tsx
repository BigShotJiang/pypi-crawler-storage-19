import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { PersonDetail, PersonDetailSkeleton } from "../PersonDetail";
import type { PersonDetail as PersonDetailType } from "@/types";

// Mock next/link
vi.mock("next/link", () => ({
  default: ({
    children,
    href,
    ...props
  }: {
    children: React.ReactNode;
    href: string;
    [key: string]: unknown;
  }) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

describe("PersonDetail", () => {
  const basePerson: PersonDetailType = {
    id: "123",
    name: "Jane Smith",
    email: "jane@example.com",
    company: "Tech Corp",
    relationship_type: "friend",
    notes: "Met at a conference in 2023.",
    last_interaction: "2024-01-15T10:30:00Z",
    interaction_count: 42,
  };

  it("renders person name", () => {
    render(<PersonDetail person={basePerson} />);

    expect(
      screen.getByRole("heading", { name: "Jane Smith" })
    ).toBeInTheDocument();
  });

  it("renders email with mailto link", () => {
    render(<PersonDetail person={basePerson} />);

    const emailLink = screen.getByRole("link", { name: /jane@example.com/i });
    expect(emailLink).toHaveAttribute("href", "mailto:jane@example.com");
  });

  it("renders company", () => {
    render(<PersonDetail person={basePerson} />);

    expect(screen.getByText("Tech Corp")).toBeInTheDocument();
  });

  it("renders relationship badge", () => {
    render(<PersonDetail person={basePerson} />);

    expect(screen.getByText("Friend")).toBeInTheDocument();
  });

  it("renders interaction count", () => {
    render(<PersonDetail person={basePerson} />);

    expect(screen.getByText("42")).toBeInTheDocument();
    expect(screen.getByText("Interactions")).toBeInTheDocument();
  });

  it("renders last interaction date", () => {
    render(<PersonDetail person={basePerson} />);

    expect(screen.getByText("Last Seen")).toBeInTheDocument();
  });

  it("renders notes section", () => {
    render(<PersonDetail person={basePerson} />);

    expect(
      screen.getByText("Met at a conference in 2023.")
    ).toBeInTheDocument();
  });

  it("has back navigation link", () => {
    render(<PersonDetail person={basePerson} />);

    const backLink = screen.getByRole("link", { name: /back to people/i });
    expect(backLink).toHaveAttribute("href", "/memory/people");
  });

  it("renders initials in avatar", () => {
    render(<PersonDetail person={basePerson} />);

    expect(screen.getByText("JS")).toBeInTheDocument();
  });

  it("shows Never for null last_interaction", () => {
    const personWithoutInteraction: PersonDetailType = {
      ...basePerson,
      last_interaction: null,
    };

    render(<PersonDetail person={personWithoutInteraction} />);

    expect(screen.getByText("Never")).toBeInTheDocument();
  });

  it("handles missing notes", () => {
    const personWithoutNotes: PersonDetailType = {
      ...basePerson,
      notes: null,
    };

    render(<PersonDetail person={personWithoutNotes} />);

    // Notes section should not be rendered
    expect(screen.queryByText("Notes")).not.toBeInTheDocument();
  });
});

describe("PersonDetailSkeleton", () => {
  it("renders skeleton elements", () => {
    render(<PersonDetailSkeleton />);

    // Should have multiple skeleton elements
    const container = document.querySelector(".space-y-6");
    expect(container).toBeInTheDocument();
  });

  it("renders back button skeleton", () => {
    render(<PersonDetailSkeleton />);

    // First skeleton should be for back button
    const skeletons = document.querySelectorAll(".bg-muted, .animate-pulse");
    expect(skeletons.length).toBeGreaterThan(0);
  });
});
