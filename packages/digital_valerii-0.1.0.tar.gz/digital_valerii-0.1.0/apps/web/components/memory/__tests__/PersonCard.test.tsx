import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { PersonCard, PersonCardSkeleton } from "../PersonCard";
import type { PersonSummary } from "@/types";

// Mock next/link
vi.mock("next/link", () => ({
  default: ({
    children,
    href,
    ...props
  }: {
    children: React.ReactNode;
    href: string;
    [key: string]: unknown;
  }) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

describe("PersonCard", () => {
  const basePerson: PersonSummary = {
    id: "123",
    name: "John Doe",
    email: "john@example.com",
    company: "Acme Corp",
    relationship_type: "colleague",
  };

  it("renders person name", () => {
    render(<PersonCard person={basePerson} />);

    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });

  it("renders person email", () => {
    render(<PersonCard person={basePerson} />);

    expect(screen.getByText("john@example.com")).toBeInTheDocument();
  });

  it("renders person company", () => {
    render(<PersonCard person={basePerson} />);

    expect(screen.getByText("Acme Corp")).toBeInTheDocument();
  });

  it("renders relationship badge", () => {
    render(<PersonCard person={basePerson} />);

    expect(screen.getByText("Colleague")).toBeInTheDocument();
  });

  it("links to person detail page", () => {
    render(<PersonCard person={basePerson} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("href", "/memory/people/123");
  });

  it("renders initials in avatar", () => {
    render(<PersonCard person={basePerson} />);

    expect(screen.getByText("JD")).toBeInTheDocument();
  });

  it("has proper accessibility label", () => {
    render(<PersonCard person={basePerson} />);

    const link = screen.getByRole("link");
    expect(link).toHaveAttribute("aria-label", "View John Doe's profile");
  });

  it("handles missing email", () => {
    const personWithoutEmail: PersonSummary = {
      ...basePerson,
      email: null,
    };

    render(<PersonCard person={personWithoutEmail} />);

    expect(screen.queryByText("john@example.com")).not.toBeInTheDocument();
    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });

  it("handles missing company", () => {
    const personWithoutCompany: PersonSummary = {
      ...basePerson,
      company: null,
    };

    render(<PersonCard person={personWithoutCompany} />);

    expect(screen.queryByText("Acme Corp")).not.toBeInTheDocument();
    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });

  it("handles missing relationship type", () => {
    const personWithoutRelationship: PersonSummary = {
      ...basePerson,
      relationship_type: null,
    };

    render(<PersonCard person={personWithoutRelationship} />);

    expect(screen.queryByText("Colleague")).not.toBeInTheDocument();
    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });
});

describe("PersonCardSkeleton", () => {
  it("renders skeleton elements", () => {
    render(<PersonCardSkeleton />);

    // Should have animated skeleton elements
    const skeletons = document.querySelectorAll(".animate-pulse");
    expect(skeletons.length).toBeGreaterThan(0);
  });
});
