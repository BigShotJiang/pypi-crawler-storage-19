import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ProjectDetail, ProjectDetailSkeleton } from "../ProjectDetail";
import type { ProjectDetail as ProjectDetailType } from "@/types";

// Mock next/link
vi.mock("next/link", () => ({
  default: ({
    children,
    href,
    ...props
  }: {
    children: React.ReactNode;
    href: string;
    [key: string]: unknown;
  }) => (
    <a href={href} {...props}>
      {children}
    </a>
  ),
}));

describe("ProjectDetail", () => {
  const baseProject: ProjectDetailType = {
    id: "456",
    name: "AI Clone Project",
    status: "active",
    description: "Building an AI avatar system for personal use",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-15T10:30:00Z",
    people: [
      {
        id: "p1",
        name: "Alice Johnson",
        email: "alice@example.com",
        company: "Tech Corp",
        relationship_type: "colleague",
      },
      {
        id: "p2",
        name: "Bob Smith",
        email: "bob@example.com",
        company: null,
        relationship_type: "friend",
      },
    ],
  };

  it("renders project name", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(
      screen.getByRole("heading", { name: "AI Clone Project" })
    ).toBeInTheDocument();
  });

  it("renders project description", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(
      screen.getByText("Building an AI avatar system for personal use")
    ).toBeInTheDocument();
  });

  it("renders status badge", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Active")).toBeInTheDocument();
  });

  it("has back navigation link", () => {
    render(<ProjectDetail project={baseProject} />);

    const backLink = screen.getByRole("link", { name: /back to projects/i });
    expect(backLink).toHaveAttribute("href", "/memory/projects");
  });

  it("shows created date", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Created")).toBeInTheDocument();
  });

  it("shows last updated date", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Last Updated")).toBeInTheDocument();
  });

  it("renders team members section title", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Team Members")).toBeInTheDocument();
  });

  it("shows team member count", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("2 members")).toBeInTheDocument();
  });

  it("renders team member names", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Alice Johnson")).toBeInTheDocument();
    expect(screen.getByText("Bob Smith")).toBeInTheDocument();
  });

  it("links team members to their profile pages", () => {
    render(<ProjectDetail project={baseProject} />);

    const aliceLink = screen.getByRole("link", { name: /alice johnson/i });
    expect(aliceLink).toHaveAttribute("href", "/memory/people/p1");

    const bobLink = screen.getByRole("link", { name: /bob smith/i });
    expect(bobLink).toHaveAttribute("href", "/memory/people/p2");
  });

  it("shows team member relationship badges", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("Colleague")).toBeInTheDocument();
    expect(screen.getByText("Friend")).toBeInTheDocument();
  });

  it("shows empty state for projects without team members", () => {
    const projectWithoutTeam: ProjectDetailType = {
      ...baseProject,
      people: [],
    };

    render(<ProjectDetail project={projectWithoutTeam} />);

    expect(screen.getByText("No team members yet")).toBeInTheDocument();
  });

  it("renders initials for team members", () => {
    render(<ProjectDetail project={baseProject} />);

    expect(screen.getByText("AJ")).toBeInTheDocument();
    expect(screen.getByText("BS")).toBeInTheDocument();
  });

  it("shows singular member text for one person", () => {
    const projectWithOnePerson: ProjectDetailType = {
      ...baseProject,
      people: [baseProject.people[0]],
    };

    render(<ProjectDetail project={projectWithOnePerson} />);

    expect(screen.getByText("1 member")).toBeInTheDocument();
  });
});

describe("ProjectDetailSkeleton", () => {
  it("renders skeleton elements", () => {
    render(<ProjectDetailSkeleton />);

    // Should have multiple skeleton elements
    const container = document.querySelector(".space-y-6");
    expect(container).toBeInTheDocument();
  });

  it("renders team member skeletons", () => {
    render(<ProjectDetailSkeleton />);

    // Should have skeleton elements for team members
    const roundedFullSkeletons = document.querySelectorAll(".rounded-full");
    expect(roundedFullSkeletons.length).toBeGreaterThan(0);
  });
});
