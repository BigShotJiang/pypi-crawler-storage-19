"use client";

import { memo } from "react";
import Link from "next/link";
import {
  FolderKanban,
  Calendar,
  ArrowLeft,
  Users,
  Clock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Avatar, AvatarFallback } from "@/components/ui/Avatar";
import { Skeleton } from "@/components/ui/Skeleton";
import { StatusBadge } from "./StatusBadge";
import { RelationshipBadge } from "./RelationshipBadge";
import type { ProjectDetail as ProjectDetailType } from "@/types";
import { cn, formatDate } from "@/lib/utils";

interface ProjectDetailProps {
  project: ProjectDetailType;
  className?: string;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function ProjectDetailComponent({ project, className }: ProjectDetailProps) {
  return (
    <div className={cn("space-y-6", className)}>
      {/* Back navigation */}
      <div>
        <Button
          variant="ghost"
          size="sm"
          asChild
          className="gap-2 text-muted-foreground hover:text-foreground"
        >
          <Link href="/memory/projects">
            <ArrowLeft className="h-4 w-4" />
            Back to Projects
          </Link>
        </Button>
      </div>

      {/* Header card */}
      <Card className="bg-card/60 backdrop-blur-sm border-border/50 overflow-hidden">
        {/* Decorative gradient header */}
        <div
          className="h-24 bg-gradient-to-br from-violet-500/20 via-violet-500/10 to-transparent"
          aria-hidden="true"
        />

        <CardContent className="relative -mt-12 pb-6">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            {/* Project icon */}
            <div
              className={cn(
                "h-20 w-20 rounded-xl border-4 border-background shadow-lg",
                "bg-gradient-to-br from-violet-500/30 to-violet-500/10",
                "flex items-center justify-center"
              )}
            >
              <FolderKanban className="h-10 w-10 text-violet-500 dark:text-violet-400" />
            </div>

            {/* Info */}
            <div className="flex-1 mt-2 sm:mt-4">
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <h1 className="text-2xl font-bold text-foreground">
                  {project.name}
                </h1>
                <StatusBadge status={project.status} />
              </div>

              {/* Description */}
              {project.description && (
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Created date */}
        <Card className="bg-card/60 backdrop-blur-sm border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-muted">
                <Calendar className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {formatDate(project.created_at)}
                </p>
                <p className="text-xs text-muted-foreground">Created</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Updated date */}
        <Card className="bg-card/60 backdrop-blur-sm border-border/50">
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-muted">
                <Clock className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">
                  {formatDate(project.updated_at)}
                </p>
                <p className="text-xs text-muted-foreground">Last Updated</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Team members */}
      <Card className="bg-card/60 backdrop-blur-sm border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base font-semibold">
            <Users className="h-4 w-4 text-primary" />
            Team Members
            {project.people.length > 0 && (
              <span className="ml-auto text-sm font-normal text-muted-foreground">
                {project.people.length} member{project.people.length !== 1 && "s"}
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {project.people.length > 0 ? (
            <ul className="space-y-3" role="list">
              {project.people.map((person) => (
                <li key={person.id}>
                  <Link
                    href={`/memory/people/${person.id}`}
                    className={cn(
                      "flex items-center gap-3 p-3 -mx-3 rounded-lg",
                      "hover:bg-muted/50 transition-colors duration-200",
                      "group focus:outline-none focus:ring-2 focus:ring-primary/50"
                    )}
                  >
                    <Avatar className="h-10 w-10 border border-border/50 group-hover:border-primary/30 transition-colors">
                      <AvatarFallback
                        className={cn(
                          "text-sm font-medium",
                          "bg-gradient-to-br from-primary/20 to-primary/5",
                          "text-primary"
                        )}
                      >
                        {getInitials(person.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate">
                        {person.name}
                      </p>
                      {person.email && (
                        <p className="text-xs text-muted-foreground truncate">
                          {person.email}
                        </p>
                      )}
                    </div>
                    {person.relationship_type && (
                      <RelationshipBadge
                        type={person.relationship_type}
                        size="sm"
                      />
                    )}
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-6">
              No team members yet
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export const ProjectDetail = memo(ProjectDetailComponent);

// Loading skeleton
export function ProjectDetailSkeleton() {
  return (
    <div className="space-y-6">
      {/* Back button skeleton */}
      <Skeleton className="h-8 w-36" />

      {/* Header card skeleton */}
      <Card className="bg-card/60 border-border/50 overflow-hidden">
        <div className="h-24 bg-muted" />
        <CardContent className="relative -mt-12 pb-6">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            <Skeleton className="h-20 w-20 rounded-xl" />
            <div className="flex-1 mt-4 space-y-4">
              <div className="flex items-center gap-3">
                <Skeleton className="h-8 w-48" />
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats skeleton */}
      <div className="grid grid-cols-2 gap-4">
        {[1, 2].map((i) => (
          <Card key={i} className="bg-card/60 border-border/50">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <Skeleton className="h-10 w-10 rounded-lg" />
                <div className="space-y-1">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Team members skeleton */}
      <Card className="bg-card/60 border-border/50">
        <CardHeader className="pb-3">
          <Skeleton className="h-5 w-32" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-3 p-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-40" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
