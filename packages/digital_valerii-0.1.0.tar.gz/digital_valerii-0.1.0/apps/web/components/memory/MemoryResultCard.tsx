"use client";

import { memo } from "react";
import Link from "next/link";
import { Calendar, Sparkles, User, FolderKanban, MessageSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import type { MemorySearchResult } from "@/types";
import { cn, formatDate } from "@/lib/utils";

interface MemoryResultCardProps {
  result: MemorySearchResult;
  className?: string;
}

const eventTypeConfig: Record<
  string,
  {
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    href: (id: string) => string;
  }
> = {
  person: {
    icon: User,
    color: "text-rose-500",
    href: (id) => `/memory/people/${id}`,
  },
  project: {
    icon: FolderKanban,
    color: "text-violet-500",
    href: (id) => `/memory/projects/${id}`,
  },
  conversation: {
    icon: MessageSquare,
    color: "text-primary",
    href: (id) => `/chat/${id}`,
  },
  default: {
    icon: Sparkles,
    color: "text-teal-500",
    href: () => "#",
  },
};

function MemoryResultCardComponent({
  result,
  className,
}: MemoryResultCardProps) {
  const config =
    eventTypeConfig[result.event_type.toLowerCase()] || eventTypeConfig.default;
  const Icon = config.icon;
  const href = config.href(result.event_id);

  // Relevance score visualization (0-1 to percentage)
  const relevancePercent = Math.round(result.score * 100);

  return (
    <Link
      href={href}
      className={cn("block group focus:outline-none", className)}
      aria-label={`${result.title || "Memory"} - ${result.event_type}`}
    >
      <Card
        className={cn(
          "relative overflow-hidden h-full",
          "bg-card/60 backdrop-blur-sm border-border/50",
          "transition-all duration-300 ease-out",
          "hover:bg-card hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
          "hover:-translate-y-0.5",
          "group-focus:ring-2 group-focus:ring-primary/50 group-focus:ring-offset-2 group-focus:ring-offset-background"
        )}
      >
        {/* Relevance indicator glow */}
        <div
          className={cn(
            "absolute top-0 right-0 w-24 h-24 rounded-full blur-3xl opacity-0 transition-opacity duration-500",
            "bg-gradient-to-br from-primary/30 to-transparent",
            result.score > 0.7 && "opacity-50",
            result.score > 0.9 && "opacity-75"
          )}
          aria-hidden="true"
        />

        <CardContent className="p-5">
          {/* Header with type and score */}
          <div className="flex items-start justify-between gap-3 mb-3">
            {/* Event type badge */}
            <div
              className={cn(
                "flex items-center gap-1.5 px-2.5 py-1 rounded-full",
                "bg-muted/50 text-sm font-medium capitalize",
                config.color
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {result.event_type}
            </div>

            {/* Relevance score */}
            <div
              className="flex items-center gap-1.5 text-xs text-muted-foreground"
              title={`${relevancePercent}% relevance`}
              aria-label={`Relevance score: ${relevancePercent} percent`}
            >
              <Sparkles className="h-3 w-3 text-primary/70" />
              <span>{relevancePercent}%</span>
            </div>
          </div>

          {/* Title */}
          {result.title && (
            <h3
              className={cn(
                "text-base font-semibold text-foreground mb-2",
                "line-clamp-2 group-hover:text-primary transition-colors duration-200"
              )}
            >
              {result.title}
            </h3>
          )}

          {/* Summary */}
          {result.summary && (
            <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
              {result.summary}
            </p>
          )}

          {/* Footer with date */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground/70">
            <Calendar className="h-3 w-3" />
            <time dateTime={result.occurred_at}>
              {formatDate(result.occurred_at)}
            </time>
          </div>
        </CardContent>

        {/* Bottom accent line on hover */}
        <div
          className={cn(
            "absolute bottom-0 left-0 right-0 h-0.5",
            "bg-gradient-to-r from-transparent via-primary to-transparent",
            "opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          )}
          aria-hidden="true"
        />
      </Card>
    </Link>
  );
}

export const MemoryResultCard = memo(MemoryResultCardComponent);
