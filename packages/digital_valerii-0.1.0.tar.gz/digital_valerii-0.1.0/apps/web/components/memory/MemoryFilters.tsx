"use client";

import { memo } from "react";
import { Layers, Users, FolderKanban, Calendar } from "lucide-react";
import { Button } from "@/components/ui/Button";
import type { MemoryFilterType } from "@/types";
import { cn } from "@/lib/utils";

interface FilterOption {
  value: MemoryFilterType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const filterOptions: FilterOption[] = [
  { value: "all", label: "All", icon: Layers },
  { value: "people", label: "People", icon: Users },
  { value: "projects", label: "Projects", icon: FolderKanban },
  { value: "events", label: "Events", icon: Calendar },
];

interface MemoryFiltersProps {
  activeFilter: MemoryFilterType;
  onChange: (filter: MemoryFilterType) => void;
  counts?: Partial<Record<MemoryFilterType, number>>;
  className?: string;
}

function MemoryFiltersComponent({
  activeFilter,
  onChange,
  counts,
  className,
}: MemoryFiltersProps) {
  return (
    <nav
      className={cn("flex items-center gap-1", className)}
      role="tablist"
      aria-label="Filter memory results"
    >
      {filterOptions.map(({ value, label, icon: Icon }) => {
        const isActive = activeFilter === value;
        const count = counts?.[value];

        return (
          <Button
            key={value}
            variant="ghost"
            role="tab"
            aria-selected={isActive}
            aria-controls={`memory-results-${value}`}
            onClick={() => onChange(value)}
            className={cn(
              "relative h-10 px-4 gap-2",
              "transition-all duration-300 ease-out",
              isActive
                ? "bg-primary/10 text-primary hover:bg-primary/15"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
            )}
          >
            {/* Active indicator */}
            {isActive && (
              <span
                className="absolute inset-x-0 -bottom-px h-0.5 bg-primary rounded-full"
                aria-hidden="true"
              />
            )}

            <Icon
              className={cn(
                "h-4 w-4 transition-transform duration-300",
                isActive && "scale-110"
              )}
            />

            <span className="text-sm font-medium">{label}</span>

            {/* Count badge */}
            {typeof count === "number" && count > 0 && (
              <span
                className={cn(
                  "ml-1 min-w-[1.25rem] h-5 px-1.5 rounded-full text-xs font-medium",
                  "flex items-center justify-center",
                  "transition-colors duration-300",
                  isActive
                    ? "bg-primary/20 text-primary"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {count > 99 ? "99+" : count}
              </span>
            )}
          </Button>
        );
      })}
    </nav>
  );
}

export const MemoryFilters = memo(MemoryFiltersComponent);
