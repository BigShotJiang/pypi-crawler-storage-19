"use client";

import { memo } from "react";
import Link from "next/link";
import { Mail, Building2, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import { Avatar, AvatarFallback } from "@/components/ui/Avatar";
import { RelationshipBadge } from "./RelationshipBadge";
import type { PersonSummary } from "@/types";
import { cn } from "@/lib/utils";

interface PersonCardProps {
  person: PersonSummary;
  className?: string;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function PersonCardComponent({ person, className }: PersonCardProps) {
  return (
    <Link
      href={`/memory/people/${person.id}`}
      className={cn("block group focus:outline-none", className)}
      aria-label={`View ${person.name}'s profile`}
    >
      <Card
        className={cn(
          "relative overflow-hidden h-full",
          "bg-card/60 backdrop-blur-sm border-border/50",
          "transition-all duration-300 ease-out",
          "hover:bg-card hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
          "hover:-translate-y-0.5",
          "group-focus:ring-2 group-focus:ring-primary/50 group-focus:ring-offset-2 group-focus:ring-offset-background"
        )}
      >
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            {/* Avatar */}
            <Avatar className="h-14 w-14 shrink-0 border-2 border-border/50 group-hover:border-primary/30 transition-colors duration-300">
              <AvatarFallback
                className={cn(
                  "text-lg font-semibold",
                  "bg-gradient-to-br from-primary/20 to-primary/5",
                  "text-primary"
                )}
              >
                {getInitials(person.name)}
              </AvatarFallback>
            </Avatar>

            {/* Info */}
            <div className="flex-1 min-w-0">
              {/* Name and relationship */}
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3
                  className={cn(
                    "text-base font-semibold text-foreground truncate",
                    "group-hover:text-primary transition-colors duration-200"
                  )}
                >
                  {person.name}
                </h3>

                {person.relationship_type && (
                  <RelationshipBadge
                    type={person.relationship_type}
                    size="sm"
                    className="shrink-0"
                  />
                )}
              </div>

              {/* Email */}
              {person.email && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-1">
                  <Mail className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{person.email}</span>
                </div>
              )}

              {/* Company */}
              {person.company && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Building2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{person.company}</span>
                </div>
              )}
            </div>
          </div>

          {/* View arrow */}
          <div
            className={cn(
              "absolute bottom-4 right-4",
              "opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0",
              "transition-all duration-300"
            )}
            aria-hidden="true"
          >
            <ArrowRight className="h-4 w-4 text-primary" />
          </div>
        </CardContent>

        {/* Bottom accent line on hover */}
        <div
          className={cn(
            "absolute bottom-0 left-0 right-0 h-0.5",
            "bg-gradient-to-r from-transparent via-primary to-transparent",
            "opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          )}
          aria-hidden="true"
        />
      </Card>
    </Link>
  );
}

export const PersonCard = memo(PersonCardComponent);

// Skeleton variant
export function PersonCardSkeleton() {
  return (
    <Card className="bg-card/60 border-border/50">
      <CardContent className="p-5">
        <div className="flex items-start gap-4">
          <div className="h-14 w-14 rounded-full bg-muted animate-pulse" />
          <div className="flex-1 space-y-2">
            <div className="h-5 w-32 bg-muted animate-pulse rounded" />
            <div className="h-4 w-48 bg-muted animate-pulse rounded" />
            <div className="h-4 w-28 bg-muted animate-pulse rounded" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
