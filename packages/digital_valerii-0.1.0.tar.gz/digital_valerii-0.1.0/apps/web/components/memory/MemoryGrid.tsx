"use client";

import { memo } from "react";
import { Skeleton } from "@/components/ui/Skeleton";
import { Card, CardContent } from "@/components/ui/Card";
import { cn } from "@/lib/utils";

interface MemoryGridProps {
  children: React.ReactNode;
  className?: string;
}

function MemoryGridComponent({ children, className }: MemoryGridProps) {
  return (
    <div
      className={cn(
        "grid gap-4",
        "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
        className
      )}
      role="list"
      aria-label="Memory results"
    >
      {children}
    </div>
  );
}

export const MemoryGrid = memo(MemoryGridComponent);

// Skeleton loading state
interface MemoryGridSkeletonProps {
  count?: number;
  className?: string;
}

function MemoryGridSkeletonComponent({
  count = 6,
  className,
}: MemoryGridSkeletonProps) {
  return (
    <div
      className={cn(
        "grid gap-4",
        "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3",
        className
      )}
      aria-label="Loading memories"
      aria-busy="true"
    >
      {Array.from({ length: count }).map((_, i) => (
        <Card
          key={i}
          className="bg-card/60 border-border/50"
          style={{ animationDelay: `${i * 100}ms` }}
        >
          <CardContent className="p-5 space-y-4">
            {/* Header skeleton */}
            <div className="flex items-center justify-between">
              <Skeleton className="h-7 w-20 rounded-full" />
              <Skeleton className="h-4 w-12" />
            </div>

            {/* Title skeleton */}
            <Skeleton className="h-5 w-3/4" />

            {/* Summary skeleton */}
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
              <Skeleton className="h-4 w-2/3" />
            </div>

            {/* Date skeleton */}
            <Skeleton className="h-3 w-24" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export const MemoryGridSkeleton = memo(MemoryGridSkeletonComponent);
