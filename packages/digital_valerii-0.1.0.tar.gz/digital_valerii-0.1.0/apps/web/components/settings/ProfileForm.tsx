"use client";

import { useState, useCallback, memo } from "react";
import { User, Mail, Shield, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { useAuthStore } from "@/lib/stores/auth";
import { apiClient } from "@/lib/api/client";
import { cn } from "@/lib/utils";

interface ProfileFormProps {
  className?: string;
}

function ProfileFormComponent({ className }: ProfileFormProps) {
  const { user, setUser } = useAuthStore();
  const [displayName, setDisplayName] = useState(user?.display_name || "");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const hasChanges = displayName !== user?.display_name;

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!hasChanges) return;

      setIsLoading(true);
      setError(null);
      setSuccess(false);

      try {
        const updatedUser = await apiClient.updateProfile({ display_name: displayName });
        setUser(updatedUser);
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      } catch (err) {
        // Log error for debugging, show generic message to user
        console.error("Profile update error:", err);
        setError("Unable to update profile. Please try again.");
      } finally {
        setIsLoading(false);
      }
    },
    [displayName, hasChanges, setUser]
  );

  const handleReset = useCallback(() => {
    setDisplayName(user?.display_name || "");
    setError(null);
    setSuccess(false);
  }, [user?.display_name]);

  return (
    <form onSubmit={handleSubmit} className={cn("space-y-6", className)}>
      {/* Display Name */}
      <div className="space-y-2">
        <Label htmlFor="displayName" className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          Display Name
        </Label>
        <Input
          id="displayName"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="Your display name"
          className="bg-background/50"
          disabled={isLoading}
        />
      </div>

      {/* Email (read-only) */}
      <div className="space-y-2">
        <Label htmlFor="email" className="flex items-center gap-2">
          <Mail className="h-4 w-4 text-muted-foreground" />
          Email
        </Label>
        <Input
          id="email"
          value={user?.email || ""}
          disabled
          className="bg-muted/30 text-muted-foreground cursor-not-allowed"
        />
        <p className="text-xs text-muted-foreground">
          Email cannot be changed for security reasons
        </p>
      </div>

      {/* Role (read-only) */}
      <div className="space-y-2">
        <Label className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-muted-foreground" />
          Role
        </Label>
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "inline-flex items-center px-3 py-1.5 rounded-lg text-sm font-medium",
              user?.role === "owner" && "bg-primary/20 text-primary border border-primary/30",
              user?.role === "admin" && "bg-blue-500/20 text-blue-400 border border-blue-500/30",
              user?.role === "user" && "bg-muted text-muted-foreground border border-border"
            )}
          >
            {user?.role?.charAt(0).toUpperCase()}{user?.role?.slice(1)}
          </span>
          {user?.is_verified && (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs bg-green-500/20 text-green-400 border border-green-500/30">
              <Check className="h-3 w-3" />
              Verified
            </span>
          )}
        </div>
      </div>

      {/* Error message */}
      {error && (
        <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {/* Success message */}
      {success && (
        <div className="rounded-lg border border-green-500/50 bg-green-500/10 p-3 text-sm text-green-400 flex items-center gap-2">
          <Check className="h-4 w-4" />
          Profile updated successfully
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-3 pt-2">
        <Button type="submit" disabled={!hasChanges || isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save Changes"
          )}
        </Button>
        {hasChanges && (
          <Button
            type="button"
            variant="ghost"
            onClick={handleReset}
            disabled={isLoading}
          >
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}

export const ProfileForm = memo(ProfileFormComponent);
