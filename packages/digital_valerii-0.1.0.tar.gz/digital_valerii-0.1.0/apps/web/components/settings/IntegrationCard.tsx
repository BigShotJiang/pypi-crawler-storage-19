"use client";

import { memo, type ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { ComingSoonBadge } from "./ComingSoonBadge";
import { cn } from "@/lib/utils";

type IntegrationStatus = "connected" | "disconnected" | "coming_soon";

interface IntegrationCardProps {
  name: string;
  description: string;
  icon: ReactNode;
  status: IntegrationStatus;
  features?: string[];
  onConnect?: () => void;
  onDisconnect?: () => void;
  className?: string;
}

function IntegrationCardComponent({
  name,
  description,
  icon,
  status,
  features,
  onConnect,
  onDisconnect,
  className,
}: IntegrationCardProps) {
  const isComingSoon = status === "coming_soon";
  const isConnected = status === "connected";

  return (
    <Card
      className={cn(
        "relative overflow-hidden",
        "bg-card/60 backdrop-blur-sm border-border/50",
        "transition-all duration-300",
        isComingSoon && "opacity-75",
        !isComingSoon && "hover:bg-card hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
        className
      )}
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          {/* Icon */}
          <div
            className={cn(
              "flex h-12 w-12 shrink-0 items-center justify-center rounded-xl",
              "transition-colors duration-200",
              isComingSoon
                ? "bg-muted/50 text-muted-foreground"
                : isConnected
                ? "bg-green-500/20 text-green-400"
                : "bg-primary/10 text-primary"
            )}
          >
            {icon}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Header */}
            <div className="flex items-start justify-between gap-2 mb-2">
              <div>
                <h3
                  className={cn(
                    "text-base font-semibold",
                    isComingSoon ? "text-muted-foreground" : "text-foreground"
                  )}
                >
                  {name}
                </h3>
                <p className="text-sm text-muted-foreground mt-0.5">{description}</p>
              </div>

              {isComingSoon && <ComingSoonBadge size="sm" />}

              {isConnected && (
                <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-green-500/20 text-green-400 border border-green-500/30">
                  Connected
                </span>
              )}
            </div>

            {/* Features */}
            {features && features.length > 0 && (
              <ul className="mt-3 space-y-1">
                {features.map((feature, index) => (
                  <li
                    key={index}
                    className={cn(
                      "text-xs flex items-center gap-2",
                      isComingSoon ? "text-muted-foreground/70" : "text-muted-foreground"
                    )}
                  >
                    <span
                      className={cn(
                        "h-1 w-1 rounded-full",
                        isComingSoon ? "bg-muted-foreground/40" : "bg-primary/60"
                      )}
                    />
                    {feature}
                  </li>
                ))}
              </ul>
            )}

            {/* Actions */}
            {!isComingSoon && (
              <div className="mt-4">
                {isConnected ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onDisconnect}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10 hover:border-destructive/30"
                  >
                    Disconnect
                  </Button>
                ) : (
                  <Button size="sm" onClick={onConnect}>
                    Connect
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>

      {/* Bottom accent for connected */}
      {isConnected && (
        <div
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-green-500 to-transparent"
          aria-hidden="true"
        />
      )}
    </Card>
  );
}

export const IntegrationCard = memo(IntegrationCardComponent);
