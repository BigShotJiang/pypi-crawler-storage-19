import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ProfileForm } from "../ProfileForm";

// Mock auth store
const mockUser = {
  id: "user-123",
  email: "test@example.com",
  display_name: "Test User",
  role: "owner" as const,
  is_active: true,
  is_verified: true,
  created_at: "2024-01-01T00:00:00Z",
  last_login_at: "2024-01-05T00:00:00Z",
};

const mockSetUser = vi.fn();

vi.mock("@/lib/stores/auth", () => ({
  useAuthStore: () => ({
    user: mockUser,
    setUser: mockSetUser,
  }),
}));

// Mock API client
const mockUpdateProfile = vi.fn();
vi.mock("@/lib/api/client", () => ({
  apiClient: {
    updateProfile: (data: { display_name: string }) => mockUpdateProfile(data),
  },
}));

describe("ProfileForm", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders form fields", () => {
    render(<ProfileForm />);

    expect(screen.getByLabelText(/Display Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
    expect(screen.getByText(/Role/i)).toBeInTheDocument();
  });

  it("displays user data from store", () => {
    render(<ProfileForm />);

    expect(screen.getByDisplayValue("Test User")).toBeInTheDocument();
    expect(screen.getByDisplayValue("test@example.com")).toBeInTheDocument();
    expect(screen.getByText("Owner")).toBeInTheDocument();
    expect(screen.getByText("Verified")).toBeInTheDocument();
  });

  it("email field is disabled", () => {
    render(<ProfileForm />);

    const emailInput = screen.getByLabelText(/Email/i);
    expect(emailInput).toBeDisabled();
  });

  it("shows save button when display name changes", async () => {
    render(<ProfileForm />);

    const displayNameInput = screen.getByLabelText(/Display Name/i);
    await userEvent.clear(displayNameInput);
    await userEvent.type(displayNameInput, "New Name");

    expect(screen.getByRole("button", { name: /Save Changes/i })).toBeEnabled();
    expect(screen.getByRole("button", { name: /Cancel/i })).toBeInTheDocument();
  });

  it("disables save button when no changes", () => {
    render(<ProfileForm />);

    const saveButton = screen.getByRole("button", { name: /Save Changes/i });
    expect(saveButton).toBeDisabled();
  });

  it("resets form when cancel clicked", async () => {
    render(<ProfileForm />);

    const displayNameInput = screen.getByLabelText(/Display Name/i);
    await userEvent.clear(displayNameInput);
    await userEvent.type(displayNameInput, "New Name");

    const cancelButton = screen.getByRole("button", { name: /Cancel/i });
    fireEvent.click(cancelButton);

    expect(screen.getByDisplayValue("Test User")).toBeInTheDocument();
  });

  it("calls updateProfile on submit", async () => {
    mockUpdateProfile.mockResolvedValue({ ...mockUser, display_name: "New Name" });
    render(<ProfileForm />);

    const displayNameInput = screen.getByLabelText(/Display Name/i);
    await userEvent.clear(displayNameInput);
    await userEvent.type(displayNameInput, "New Name");

    const saveButton = screen.getByRole("button", { name: /Save Changes/i });
    fireEvent.click(saveButton);

    await waitFor(() => {
      expect(mockUpdateProfile).toHaveBeenCalledWith({ display_name: "New Name" });
    });
  });

  it("shows success message after successful update", async () => {
    mockUpdateProfile.mockResolvedValue({ ...mockUser, display_name: "New Name" });
    render(<ProfileForm />);

    const displayNameInput = screen.getByLabelText(/Display Name/i);
    await userEvent.clear(displayNameInput);
    await userEvent.type(displayNameInput, "New Name");

    const saveButton = screen.getByRole("button", { name: /Save Changes/i });
    fireEvent.click(saveButton);

    await waitFor(() => {
      expect(screen.getByText(/Profile updated successfully/i)).toBeInTheDocument();
    });
  });

  it("shows error message on failed update", async () => {
    mockUpdateProfile.mockRejectedValue(new Error("Update failed"));
    render(<ProfileForm />);

    const displayNameInput = screen.getByLabelText(/Display Name/i);
    await userEvent.clear(displayNameInput);
    await userEvent.type(displayNameInput, "New Name");

    const saveButton = screen.getByRole("button", { name: /Save Changes/i });
    fireEvent.click(saveButton);

    await waitFor(() => {
      expect(screen.getByText("Unable to update profile. Please try again.")).toBeInTheDocument();
    });
  });
});
