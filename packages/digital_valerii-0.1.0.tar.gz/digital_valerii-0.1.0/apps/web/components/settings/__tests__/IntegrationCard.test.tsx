import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { IntegrationCard } from "../IntegrationCard";
import { Plug } from "lucide-react";

describe("IntegrationCard", () => {
  const defaultProps = {
    name: "Test Integration",
    description: "A test integration description",
    icon: <Plug data-testid="integration-icon" />,
    status: "disconnected" as const,
    features: ["Feature 1", "Feature 2", "Feature 3"],
  };

  it("renders integration name and description", () => {
    render(<IntegrationCard {...defaultProps} />);

    expect(screen.getByText("Test Integration")).toBeInTheDocument();
    expect(screen.getByText("A test integration description")).toBeInTheDocument();
  });

  it("renders icon", () => {
    render(<IntegrationCard {...defaultProps} />);

    expect(screen.getByTestId("integration-icon")).toBeInTheDocument();
  });

  it("renders features list", () => {
    render(<IntegrationCard {...defaultProps} />);

    expect(screen.getByText("Feature 1")).toBeInTheDocument();
    expect(screen.getByText("Feature 2")).toBeInTheDocument();
    expect(screen.getByText("Feature 3")).toBeInTheDocument();
  });

  it("renders Connect button when disconnected", () => {
    render(<IntegrationCard {...defaultProps} status="disconnected" />);

    expect(screen.getByRole("button", { name: /Connect/i })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Disconnect/i })).not.toBeInTheDocument();
  });

  it("renders Disconnect button when connected", () => {
    render(<IntegrationCard {...defaultProps} status="connected" />);

    expect(screen.getByRole("button", { name: /Disconnect/i })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /^Connect$/i })).not.toBeInTheDocument();
  });

  it("renders Connected badge when connected", () => {
    render(<IntegrationCard {...defaultProps} status="connected" />);

    expect(screen.getByText("Connected")).toBeInTheDocument();
  });

  it("renders Coming Soon badge when coming_soon", () => {
    render(<IntegrationCard {...defaultProps} status="coming_soon" />);

    expect(screen.getByText("Coming Soon")).toBeInTheDocument();
  });

  it("does not render buttons when coming_soon", () => {
    render(<IntegrationCard {...defaultProps} status="coming_soon" />);

    expect(screen.queryByRole("button", { name: /^Connect$/i })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /Disconnect/i })).not.toBeInTheDocument();
  });

  it("calls onConnect when Connect button clicked", () => {
    const onConnect = vi.fn();
    render(
      <IntegrationCard {...defaultProps} status="disconnected" onConnect={onConnect} />
    );

    fireEvent.click(screen.getByRole("button", { name: /Connect/i }));
    expect(onConnect).toHaveBeenCalledTimes(1);
  });

  it("calls onDisconnect when Disconnect button clicked", () => {
    const onDisconnect = vi.fn();
    render(
      <IntegrationCard {...defaultProps} status="connected" onDisconnect={onDisconnect} />
    );

    fireEvent.click(screen.getByRole("button", { name: /Disconnect/i }));
    expect(onDisconnect).toHaveBeenCalledTimes(1);
  });

  it("renders without features", () => {
    render(<IntegrationCard {...defaultProps} features={undefined} />);

    expect(screen.getByText("Test Integration")).toBeInTheDocument();
    expect(screen.queryByText("Feature 1")).not.toBeInTheDocument();
  });

  it("applies custom className", () => {
    const { container } = render(
      <IntegrationCard {...defaultProps} className="custom-class" />
    );

    const card = container.firstChild;
    expect(card).toHaveClass("custom-class");
  });
});
