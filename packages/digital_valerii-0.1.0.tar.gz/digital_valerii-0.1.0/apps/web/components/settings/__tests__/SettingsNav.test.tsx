import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import { SettingsNav } from "../SettingsNav";

// Mock next/navigation
const mockPathname = vi.fn();
vi.mock("next/navigation", () => ({
  usePathname: () => mockPathname(),
}));

describe("SettingsNav", () => {
  beforeEach(() => {
    mockPathname.mockReturnValue("/settings");
  });

  it("renders all navigation items", () => {
    render(<SettingsNav />);

    expect(screen.getByText("Account")).toBeInTheDocument();
    expect(screen.getByText("Personality")).toBeInTheDocument();
    expect(screen.getByText("Integrations")).toBeInTheDocument();
  });

  it("renders descriptions for all items", () => {
    render(<SettingsNav />);

    expect(screen.getByText("Manage your profile and security")).toBeInTheDocument();
    expect(screen.getByText("Configure AI behavior")).toBeInTheDocument();
    expect(screen.getByText("Connect external services")).toBeInTheDocument();
  });

  it("highlights Account when on /settings", () => {
    mockPathname.mockReturnValue("/settings");
    render(<SettingsNav />);

    const accountLink = screen.getByRole("link", { name: /Account/i });
    expect(accountLink).toHaveAttribute("aria-current", "page");
  });

  it("highlights Personality when on /settings/personality", () => {
    mockPathname.mockReturnValue("/settings/personality");
    render(<SettingsNav />);

    const personalityLink = screen.getByRole("link", { name: /Personality/i });
    expect(personalityLink).toHaveAttribute("aria-current", "page");
  });

  it("highlights Integrations when on /settings/integrations", () => {
    mockPathname.mockReturnValue("/settings/integrations");
    render(<SettingsNav />);

    const integrationsLink = screen.getByRole("link", { name: /Integrations/i });
    expect(integrationsLink).toHaveAttribute("aria-current", "page");
  });

  it("has correct href for all links", () => {
    render(<SettingsNav />);

    expect(screen.getByRole("link", { name: /Account/i })).toHaveAttribute(
      "href",
      "/settings"
    );
    expect(screen.getByRole("link", { name: /Personality/i })).toHaveAttribute(
      "href",
      "/settings/personality"
    );
    expect(screen.getByRole("link", { name: /Integrations/i })).toHaveAttribute(
      "href",
      "/settings/integrations"
    );
  });

  it("renders navigation with correct aria-label", () => {
    render(<SettingsNav />);

    expect(screen.getByRole("navigation")).toHaveAttribute(
      "aria-label",
      "Settings navigation"
    );
  });
});
