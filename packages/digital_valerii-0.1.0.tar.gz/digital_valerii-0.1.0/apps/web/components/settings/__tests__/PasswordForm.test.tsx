import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { PasswordForm } from "../PasswordForm";

// Mock API client
const mockChangePassword = vi.fn();
vi.mock("@/lib/api/client", () => ({
  apiClient: {
    changePassword: (data: { current_password: string; new_password: string }) =>
      mockChangePassword(data),
  },
}));

describe("PasswordForm", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders password fields", () => {
    render(<PasswordForm />);

    expect(screen.getByLabelText(/Current Password/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^New Password$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Confirm New Password/i)).toBeInTheDocument();
  });

  it("disables submit button when fields are empty", () => {
    render(<PasswordForm />);

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    expect(submitButton).toBeDisabled();
  });

  it("shows password mismatch error", async () => {
    render(<PasswordForm />);

    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "differentpassword");

    expect(screen.getByText(/Passwords do not match/i)).toBeInTheDocument();
  });

  it("shows password match confirmation", async () => {
    render(<PasswordForm />);

    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    expect(screen.getByText(/Passwords match/i)).toBeInTheDocument();
  });

  it("shows minimum length error for short password", async () => {
    render(<PasswordForm />);

    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    await userEvent.type(newPasswordInput, "short");

    expect(
      screen.getByText(/Password must be at least 8 characters/i)
    ).toBeInTheDocument();
  });

  it("enables submit when all fields are valid", async () => {
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(currentPasswordInput, "oldpassword");
    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    expect(submitButton).toBeEnabled();
  });

  it("calls changePassword on submit", async () => {
    mockChangePassword.mockResolvedValue(undefined);
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(currentPasswordInput, "oldpassword");
    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(mockChangePassword).toHaveBeenCalledWith({
        current_password: "oldpassword",
        new_password: "newpassword123",
      });
    });
  });

  it("shows success message after password change", async () => {
    mockChangePassword.mockResolvedValue(undefined);
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(currentPasswordInput, "oldpassword");
    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText(/Password changed successfully/i)).toBeInTheDocument();
    });
  });

  it("clears form after successful password change", async () => {
    mockChangePassword.mockResolvedValue(undefined);
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(currentPasswordInput, "oldpassword");
    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(currentPasswordInput).toHaveValue("");
      expect(newPasswordInput).toHaveValue("");
      expect(confirmPasswordInput).toHaveValue("");
    });
  });

  it("shows error message on failed password change", async () => {
    mockChangePassword.mockRejectedValue(new Error("Incorrect current password"));
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    const newPasswordInput = screen.getByLabelText(/^New Password$/i);
    const confirmPasswordInput = screen.getByLabelText(/Confirm New Password/i);

    await userEvent.type(currentPasswordInput, "wrongpassword");
    await userEvent.type(newPasswordInput, "newpassword123");
    await userEvent.type(confirmPasswordInput, "newpassword123");

    const submitButton = screen.getByRole("button", { name: /Change Password/i });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText("Unable to change password. Please check your current password and try again.")).toBeInTheDocument();
    });
  });

  it("toggles password visibility", async () => {
    render(<PasswordForm />);

    const currentPasswordInput = screen.getByLabelText(/Current Password/i);
    expect(currentPasswordInput).toHaveAttribute("type", "password");

    // Find toggle button (there are multiple, get the first one which is for current password)
    const toggleButtons = screen.getAllByRole("button");
    const currentPasswordToggle = toggleButtons.find(
      (btn) => btn.closest("div")?.contains(currentPasswordInput)
    );

    if (currentPasswordToggle) {
      fireEvent.click(currentPasswordToggle);
      // After toggle, input type should change
      await waitFor(() => {
        expect(currentPasswordInput).toHaveAttribute("type", "text");
      });
    }
  });
});
