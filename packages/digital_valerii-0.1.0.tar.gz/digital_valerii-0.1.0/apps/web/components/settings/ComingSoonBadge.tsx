"use client";

import { memo } from "react";
import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

interface ComingSoonBadgeProps {
  size?: "sm" | "md";
  className?: string;
}

function ComingSoonBadgeComponent({ size = "md", className }: ComingSoonBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 font-medium",
        "bg-gradient-to-r from-primary/20 to-primary/10",
        "text-primary border border-primary/30",
        "rounded-full",
        size === "sm" && "px-2 py-0.5 text-[10px]",
        size === "md" && "px-3 py-1 text-xs",
        className
      )}
    >
      <Sparkles
        className={cn(
          "animate-pulse",
          size === "sm" && "h-2.5 w-2.5",
          size === "md" && "h-3 w-3"
        )}
      />
      Coming Soon
    </span>
  );
}

export const ComingSoonBadge = memo(ComingSoonBadgeComponent);
