"use client";

import { memo } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { User, Sparkles, Plug, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  {
    href: "/settings",
    label: "Account",
    description: "Manage your profile and security",
    icon: User,
  },
  {
    href: "/settings/personality",
    label: "Personality",
    description: "Configure AI behavior",
    icon: Sparkles,
  },
  {
    href: "/settings/integrations",
    label: "Integrations",
    description: "Connect external services",
    icon: Plug,
  },
];

interface SettingsNavProps {
  className?: string;
}

function SettingsNavComponent({ className }: SettingsNavProps) {
  const pathname = usePathname();

  const isActive = (href: string) => {
    if (href === "/settings") {
      return pathname === "/settings";
    }
    return pathname.startsWith(href);
  };

  return (
    <nav className={cn("space-y-1", className)} role="navigation" aria-label="Settings navigation">
      {navItems.map((item) => {
        const active = isActive(item.href);
        const Icon = item.icon;

        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "group flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
              "hover:bg-card/80",
              active && "bg-card border border-border/50 shadow-sm"
            )}
            aria-current={active ? "page" : undefined}
          >
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-lg transition-colors duration-200",
                active
                  ? "bg-primary/20 text-primary"
                  : "bg-muted/50 text-muted-foreground group-hover:bg-muted group-hover:text-foreground"
              )}
            >
              <Icon className="h-5 w-5" />
            </div>

            <div className="flex-1 min-w-0">
              <p
                className={cn(
                  "text-sm font-medium transition-colors duration-200",
                  active ? "text-foreground" : "text-muted-foreground group-hover:text-foreground"
                )}
              >
                {item.label}
              </p>
              <p className="text-xs text-muted-foreground truncate">{item.description}</p>
            </div>

            <ChevronRight
              className={cn(
                "h-4 w-4 transition-all duration-200",
                active
                  ? "text-primary opacity-100"
                  : "text-muted-foreground opacity-0 group-hover:opacity-100"
              )}
            />
          </Link>
        );
      })}
    </nav>
  );
}

export const SettingsNav = memo(SettingsNavComponent);
