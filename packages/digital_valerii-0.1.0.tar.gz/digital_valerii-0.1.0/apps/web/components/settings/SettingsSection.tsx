"use client";

import { memo, type ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/Card";
import { cn } from "@/lib/utils";

interface SettingsSectionProps {
  title: string;
  description?: string;
  children: ReactNode;
  variant?: "default" | "danger";
  className?: string;
}

function SettingsSectionComponent({
  title,
  description,
  children,
  variant = "default",
  className,
}: SettingsSectionProps) {
  return (
    <Card
      className={cn(
        "bg-card/60 backdrop-blur-sm border-border/50",
        variant === "danger" && "border-destructive/30 bg-destructive/5",
        className
      )}
    >
      <CardHeader className="pb-4">
        <CardTitle
          className={cn(
            "text-lg font-semibold",
            variant === "danger" && "text-destructive"
          )}
        >
          {title}
        </CardTitle>
        {description && (
          <CardDescription className="text-sm text-muted-foreground">
            {description}
          </CardDescription>
        )}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export const SettingsSection = memo(SettingsSectionComponent);
