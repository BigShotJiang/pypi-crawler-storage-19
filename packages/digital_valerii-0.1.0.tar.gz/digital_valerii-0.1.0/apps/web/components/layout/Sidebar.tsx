"use client";

import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useChatStore } from "@/lib/stores/chat";
import { useAuthStore } from "@/lib/stores/auth";
import { Button } from "@/components/ui/Button";
import { ScrollArea } from "@/components/ui/ScrollArea";
import { Separator } from "@/components/ui/Separator";
import { ConversationItem } from "@/components/chat/ConversationItem";
import {
  Plus,
  MessageSquare,
  Settings,
  LogOut,
  X,
  Moon,
  Sun,
  Brain,
} from "lucide-react";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

interface SidebarProps {
  onClose?: () => void;
}

export function Sidebar({ onClose }: SidebarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const { user, logout } = useAuthStore();
  const {
    conversations,
    currentConversation,
    fetchConversations,
    createNewConversation,
    deleteConversation,
  } = useChatStore();

  // Fetch conversations on mount
  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  const handleNewChat = () => {
    createNewConversation();
    router.push("/chat");
    onClose?.();
  };

  const handleSelectConversation = (id: string) => {
    router.push(`/chat/${id}`);
    onClose?.();
  };

  const handleDeleteConversation = async (id: string) => {
    await deleteConversation(id);
    if (currentConversation?.id === id) {
      router.push("/chat");
    }
  };

  const handleLogout = async () => {
    await logout();
    router.push("/login");
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className="flex h-full w-72 flex-col bg-card border-r border-border">
      {/* Header */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
            <span className="text-lg">🤖</span>
          </div>
          <span className="font-semibold text-foreground">Digital Valerii</span>
        </div>
        {onClose && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="md:hidden"
            aria-label="Close sidebar"
          >
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>

      {/* New Chat Button */}
      <div className="px-4 pb-2">
        <Button onClick={handleNewChat} className="w-full gap-2">
          <Plus className="h-4 w-4" />
          New Chat
        </Button>
      </div>

      {/* Memory Button */}
      <div className="px-4 pb-4">
        <Button
          variant="outline"
          onClick={() => {
            router.push("/memory");
            onClose?.();
          }}
          className={cn(
            "w-full gap-2",
            pathname.startsWith("/memory") && "bg-primary/10 border-primary/30 text-primary"
          )}
        >
          <Brain className="h-4 w-4" />
          Memory
        </Button>
      </div>

      <Separator />

      {/* Conversations List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {conversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No conversations yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                Start a new chat to begin
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              {conversations.map((conversation) => (
                <ConversationItem
                  key={conversation.id}
                  conversation={conversation}
                  isActive={
                    currentConversation?.id === conversation.id ||
                    pathname === `/chat/${conversation.id}`
                  }
                  onSelect={handleSelectConversation}
                  onDelete={handleDeleteConversation}
                />
              ))}
            </div>
          )}
        </div>
      </ScrollArea>

      <Separator />

      {/* Footer */}
      <div className="p-4 space-y-2">
        {/* User Info */}
        {user && (
          <div className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-sm font-medium text-primary">
              {user.display_name?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.display_name}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="flex-1 gap-2"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <>
                <Sun className="h-4 w-4" />
                Light
              </>
            ) : (
              <>
                <Moon className="h-4 w-4" />
                Dark
              </>
            )}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push("/settings")}
            className={cn(
              "flex-1 gap-2",
              pathname.startsWith("/settings") && "bg-accent text-accent-foreground"
            )}
            aria-label="Settings"
          >
            <Settings className="h-4 w-4" />
            Settings
          </Button>
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleLogout}
          className="w-full gap-2 text-muted-foreground hover:text-destructive"
          aria-label="Sign out"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </Button>
      </div>
    </div>
  );
}
