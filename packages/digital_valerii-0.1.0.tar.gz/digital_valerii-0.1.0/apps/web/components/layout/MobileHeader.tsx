"use client";

import { useRouter } from "next/navigation";
import { useChatStore } from "@/lib/stores/chat";
import { Button } from "@/components/ui/Button";
import { Menu, Plus } from "lucide-react";

interface MobileHeaderProps {
  onMenuClick: () => void;
}

export function MobileHeader({ onMenuClick }: MobileHeaderProps) {
  const router = useRouter();
  const { createNewConversation } = useChatStore();

  const handleNewChat = () => {
    createNewConversation();
    router.push("/chat");
  };

  return (
    <header className="flex items-center justify-between p-4 border-b border-border bg-card md:hidden safe-top">
      <Button
        variant="ghost"
        size="icon"
        onClick={onMenuClick}
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </Button>

      <div className="flex items-center gap-2">
        <div className="flex h-6 w-6 items-center justify-center rounded-md bg-primary/10">
          <span className="text-sm">🤖</span>
        </div>
        <span className="font-semibold text-foreground">Digital Valerii</span>
      </div>

      <Button
        variant="ghost"
        size="icon"
        onClick={handleNewChat}
        aria-label="New chat"
      >
        <Plus className="h-5 w-5" />
      </Button>
    </header>
  );
}
