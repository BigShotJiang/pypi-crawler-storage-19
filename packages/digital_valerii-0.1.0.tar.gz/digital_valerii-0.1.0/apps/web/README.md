# Digital Valerii Web Interface

Production-grade web chat interface for Digital Valerii AI Clone.

## Tech Stack

- **Next.js 15** - React framework with App Router
- **React 19** - UI library
- **TypeScript** - Type safety
- **Tailwind CSS 4** - Styling
- **shadcn/ui** - Component library
- **Zustand** - State management
- **TanStack Query** - Data fetching + caching

## Getting Started

```bash
# Install dependencies
npm install

# Copy environment variables
cp .env.local.example .env.local

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Project Structure

```
apps/web/
├── app/                    # Next.js App Router
│   ├── (auth)/            # Auth route group (login)
│   ├── (dashboard)/       # Dashboard route group (chat)
│   ├── globals.css        # Global styles
│   ├── layout.tsx         # Root layout
│   └── page.tsx           # Home (redirects to /chat)
├── components/
│   ├── chat/              # Chat components
│   ├── layout/            # Layout components
│   ├── providers/         # Context providers
│   └── ui/                # Base UI components
├── lib/
│   ├── api/               # API client
│   ├── stores/            # Zustand stores
│   └── utils.ts           # Utilities
└── types/                 # TypeScript types
```

## Features

- Real-time streaming chat responses
- Conversation history management
- Dark/Light theme switching
- Mobile responsive design
- EU AI Act compliant AI disclosure

## Scripts

```bash
npm run dev        # Development server
npm run build      # Production build
npm run start      # Production server
npm run lint       # ESLint
npm run test       # Run tests
npm run test:coverage  # Test coverage
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NEXT_PUBLIC_API_URL` | Backend API URL | `http://localhost:8000/api/v1` |
| `NEXT_PUBLIC_APP_NAME` | Application name | `Digital Valerii` |
