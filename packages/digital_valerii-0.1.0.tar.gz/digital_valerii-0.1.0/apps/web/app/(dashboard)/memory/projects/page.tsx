"use client";

import { useEffect, useState, useCallback } from "react";
import { Search, Filter } from "lucide-react";
import { useMemoryStore } from "@/lib/stores/memory";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import {
  ProjectCard,
  ProjectCardSkeleton,
  MemoryGrid,
  MemoryEmptyState,
} from "@/components/memory";
import { cn } from "@/lib/utils";

type StatusFilter = "all" | "active" | "completed" | "archived";

const statusFilters: { value: StatusFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "active", label: "Active" },
  { value: "completed", label: "Completed" },
  { value: "archived", label: "Archived" },
];

export default function ProjectsPage() {
  const { projects, isLoading, error, listProjects } = useMemoryStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Fetch projects when query or filter changes
  useEffect(() => {
    listProjects(
      debouncedQuery || undefined,
      statusFilter === "all" ? undefined : statusFilter
    );
  }, [debouncedQuery, statusFilter, listProjects]);

  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchQuery(e.target.value);
    },
    []
  );

  return (
    <div className="space-y-6">
      {/* Search and filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search input */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={handleSearchChange}
            className={cn(
              "pl-10 h-11",
              "bg-card/60 backdrop-blur-sm border-border/50",
              "focus:border-primary/50"
            )}
          />
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-1 p-1 bg-muted/50 rounded-lg">
          {statusFilters.map(({ value, label }) => (
            <Button
              key={value}
              variant="ghost"
              size="sm"
              onClick={() => setStatusFilter(value)}
              className={cn(
                "h-8 px-3",
                statusFilter === value
                  ? "bg-background shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {label}
            </Button>
          ))}
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">
          Unable to load projects. Please try again.
        </div>
      )}

      {/* Loading state */}
      {isLoading && (
        <MemoryGrid>
          {Array.from({ length: 6 }).map((_, i) => (
            <ProjectCardSkeleton key={i} />
          ))}
        </MemoryGrid>
      )}

      {/* Projects list */}
      {!isLoading && projects.length > 0 && (
        <>
          <p className="text-sm text-muted-foreground">
            {projects.length} {projects.length === 1 ? "project" : "projects"}{" "}
            {statusFilter !== "all" && `(${statusFilter})`}
          </p>
          <MemoryGrid>
            {projects.map((project) => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </MemoryGrid>
        </>
      )}

      {/* Empty state */}
      {!isLoading && projects.length === 0 && (
        <MemoryEmptyState
          variant={debouncedQuery || statusFilter !== "all" ? "no-results" : "no-data"}
          searchQuery={debouncedQuery}
          title={
            debouncedQuery || statusFilter !== "all"
              ? "No projects found"
              : "No projects yet"
          }
          description={
            debouncedQuery
              ? `No projects match "${debouncedQuery}". Try a different search.`
              : statusFilter !== "all"
              ? `No ${statusFilter} projects found.`
              : "Projects you work on will appear here over time."
          }
        />
      )}
    </div>
  );
}
