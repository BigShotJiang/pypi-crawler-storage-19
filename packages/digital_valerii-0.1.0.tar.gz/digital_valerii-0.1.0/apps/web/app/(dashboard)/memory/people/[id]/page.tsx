"use client";

import { useEffect } from "react";
import { useParams, notFound } from "next/navigation";
import { useMemoryStore } from "@/lib/stores/memory";
import { PersonDetail, PersonDetailSkeleton } from "@/components/memory";

export default function PersonDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const { selectedPerson, isLoading, error, getPerson, clearSelectedPerson } =
    useMemoryStore();

  // Fetch person on mount
  useEffect(() => {
    if (id) {
      getPerson(id);
    }

    // Cleanup on unmount
    return () => {
      clearSelectedPerson();
    };
  }, [id, getPerson, clearSelectedPerson]);

  // Error handling - 404 if person not found
  if (error && error.includes("not found")) {
    notFound();
  }

  // Loading state
  if (isLoading || !selectedPerson) {
    return <PersonDetailSkeleton />;
  }

  // Error state
  if (error) {
    return (
      <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">
        {error}
      </div>
    );
  }

  return <PersonDetail person={selectedPerson} />;
}
