"use client";

import { usePathname } from "next/navigation";
import Link from "next/link";
import { Brain, Users, FolderKanban, Search } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/memory", label: "Search", icon: Search },
  { href: "/memory/people", label: "People", icon: Users },
  { href: "/memory/projects", label: "Projects", icon: FolderKanban },
];

export default function MemoryLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  // Check if we're on a detail page (has an ID in the path)
  const isDetailPage =
    pathname.includes("/people/") || pathname.includes("/projects/");

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      {!isDetailPage && (
        <header className="shrink-0 border-b border-border bg-card/50 backdrop-blur-sm">
          <div className="px-4 sm:px-6 lg:px-8">
            {/* Title row */}
            <div className="flex items-center gap-3 pt-6 pb-4">
              <div className="p-2 rounded-xl bg-primary/10">
                <Brain className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Memory Browser</h1>
                <p className="text-sm text-muted-foreground">
                  Explore your memories, people, and projects
                </p>
              </div>
            </div>

            {/* Navigation tabs */}
            <nav
              className="flex items-center gap-1 -mb-px"
              role="tablist"
              aria-label="Memory sections"
            >
              {navItems.map(({ href, label, icon: Icon }) => {
                const isActive = pathname === href;

                return (
                  <Button
                    key={href}
                    variant="ghost"
                    asChild
                    role="tab"
                    aria-selected={isActive}
                    className={cn(
                      "relative gap-2 rounded-none border-b-2 border-transparent px-4",
                      "hover:bg-transparent hover:text-foreground",
                      "transition-all duration-200",
                      isActive
                        ? "border-primary text-primary"
                        : "text-muted-foreground"
                    )}
                  >
                    <Link href={href}>
                      <Icon className="h-4 w-4" />
                      {label}
                    </Link>
                  </Button>
                );
              })}
            </nav>
          </div>
        </header>
      )}

      {/* Content */}
      <div className="flex-1 overflow-auto">
        <div className="px-4 sm:px-6 lg:px-8 py-6">{children}</div>
      </div>
    </div>
  );
}
