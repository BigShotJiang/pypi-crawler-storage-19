"use client";

import { useCallback } from "react";
import { useMemoryStore } from "@/lib/stores/memory";
import {
  MemorySearch,
  MemoryFilters,
  MemoryResultCard,
  MemoryGrid,
  MemoryGridSkeleton,
  MemoryEmptyState,
} from "@/components/memory";

export default function MemoryPage() {
  const {
    searchResults,
    searchQuery,
    filter,
    isLoading,
    error,
    searchMemories,
    setFilter,
    setSearchQuery,
  } = useMemoryStore();

  const handleSearch = useCallback(
    (query: string) => {
      if (query.trim()) {
        searchMemories(query);
      }
    },
    [searchMemories]
  );

  const handleQueryChange = useCallback(
    (query: string) => {
      setSearchQuery(query);
    },
    [setSearchQuery]
  );

  // Filter results based on selected filter
  const filteredResults =
    filter === "all"
      ? searchResults
      : searchResults.filter(
          (result) => result.event_type.toLowerCase() === filter.replace("s", "")
        );

  // Count by type for filter badges
  const counts = {
    all: searchResults.length,
    people: searchResults.filter(
      (r) => r.event_type.toLowerCase() === "person"
    ).length,
    projects: searchResults.filter(
      (r) => r.event_type.toLowerCase() === "project"
    ).length,
    events: searchResults.filter(
      (r) =>
        r.event_type.toLowerCase() !== "person" &&
        r.event_type.toLowerCase() !== "project"
    ).length,
  };

  return (
    <div className="space-y-6">
      {/* Search input */}
      <MemorySearch
        value={searchQuery}
        onChange={handleQueryChange}
        onSearch={handleSearch}
        isLoading={isLoading}
        className="max-w-2xl mx-auto"
      />

      {/* Show content based on state */}
      {searchQuery ? (
        <>
          {/* Filters */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <MemoryFilters
              activeFilter={filter}
              onChange={setFilter}
              counts={counts}
            />

            {/* Results count */}
            {!isLoading && searchResults.length > 0 && (
              <p className="text-sm text-muted-foreground">
                {filteredResults.length} result
                {filteredResults.length !== 1 && "s"}
                {filter !== "all" && ` in ${filter}`}
              </p>
            )}
          </div>

          {/* Error state */}
          {error && (
            <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">
              Unable to load memories. Please try again.
            </div>
          )}

          {/* Loading state */}
          {isLoading && <MemoryGridSkeleton count={6} />}

          {/* Results */}
          {!isLoading && filteredResults.length > 0 && (
            <MemoryGrid>
              {filteredResults.map((result) => (
                <MemoryResultCard key={result.event_id} result={result} />
              ))}
            </MemoryGrid>
          )}

          {/* No results */}
          {!isLoading && searchResults.length === 0 && (
            <MemoryEmptyState variant="no-results" searchQuery={searchQuery} />
          )}

          {/* No results for filter */}
          {!isLoading &&
            searchResults.length > 0 &&
            filteredResults.length === 0 && (
              <MemoryEmptyState
                variant="no-results"
                title={`No ${filter} found`}
                description={`No ${filter} match your search. Try selecting a different filter.`}
              />
            )}
        </>
      ) : (
        /* Empty search state */
        <MemoryEmptyState variant="search" />
      )}
    </div>
  );
}
