"use client";

import { useEffect } from "react";
import { useParams, notFound } from "next/navigation";
import { useMemoryStore } from "@/lib/stores/memory";
import { ProjectDetail, ProjectDetailSkeleton } from "@/components/memory";

export default function ProjectDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const { selectedProject, isLoading, error, getProject, clearSelectedProject } =
    useMemoryStore();

  // Fetch project on mount
  useEffect(() => {
    if (id) {
      getProject(id);
    }

    // Cleanup on unmount
    return () => {
      clearSelectedProject();
    };
  }, [id, getProject, clearSelectedProject]);

  // Error handling - 404 if project not found
  if (error && error.includes("not found")) {
    notFound();
  }

  // Loading state
  if (isLoading || !selectedProject) {
    return <ProjectDetailSkeleton />;
  }

  // Error state
  if (error) {
    return (
      <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">
        {error}
      </div>
    );
  }

  return <ProjectDetail project={selectedProject} />;
}
