"use client";

import { useEffect, useState, useCallback } from "react";
import { Search } from "lucide-react";
import { useMemoryStore } from "@/lib/stores/memory";
import { Input } from "@/components/ui/Input";
import {
  PersonCard,
  PersonCardSkeleton,
  MemoryGrid,
  MemoryEmptyState,
} from "@/components/memory";
import { cn } from "@/lib/utils";

export default function PeoplePage() {
  const { people, isLoading, error, listPeople } = useMemoryStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  // Fetch people on mount
  useEffect(() => {
    listPeople();
  }, [listPeople]);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Re-fetch when debounced query changes
  useEffect(() => {
    listPeople(debouncedQuery || undefined);
  }, [debouncedQuery, listPeople]);

  const handleSearchChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchQuery(e.target.value);
    },
    []
  );

  return (
    <div className="space-y-6">
      {/* Search input */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search people..."
          value={searchQuery}
          onChange={handleSearchChange}
          className={cn(
            "pl-10 h-11",
            "bg-card/60 backdrop-blur-sm border-border/50",
            "focus:border-primary/50"
          )}
        />
      </div>

      {/* Error state */}
      {error && (
        <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4 text-sm text-destructive">
          Unable to load people. Please try again.
        </div>
      )}

      {/* Loading state */}
      {isLoading && (
        <MemoryGrid>
          {Array.from({ length: 6 }).map((_, i) => (
            <PersonCardSkeleton key={i} />
          ))}
        </MemoryGrid>
      )}

      {/* People list */}
      {!isLoading && people.length > 0 && (
        <>
          <p className="text-sm text-muted-foreground">
            {people.length} {people.length === 1 ? "person" : "people"} found
          </p>
          <MemoryGrid>
            {people.map((person) => (
              <PersonCard key={person.id} person={person} />
            ))}
          </MemoryGrid>
        </>
      )}

      {/* Empty state */}
      {!isLoading && people.length === 0 && (
        <MemoryEmptyState
          variant={debouncedQuery ? "no-results" : "no-data"}
          searchQuery={debouncedQuery}
          title={debouncedQuery ? "No people found" : "No people yet"}
          description={
            debouncedQuery
              ? `No people match "${debouncedQuery}". Try a different search.`
              : "People you interact with will appear here over time."
          }
        />
      )}
    </div>
  );
}
