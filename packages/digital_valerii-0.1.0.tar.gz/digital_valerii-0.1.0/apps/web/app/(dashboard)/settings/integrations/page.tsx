"use client";

import { Plug, Calendar, Mail, Cloud, MessageSquare, Globe } from "lucide-react";
import { SettingsSection, IntegrationCard, ComingSoonBadge } from "@/components/settings";

// Microsoft 365 icon component
function Microsoft365Icon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      aria-hidden="true"
    >
      <path d="M11.5 3v8.5H3V3h8.5zm0 18H3v-8.5h8.5V21zm1-18H21v8.5h-8.5V3zm8.5 9.5V21h-8.5v-8.5H21z" />
    </svg>
  );
}

// Slack icon component
function SlackIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      aria-hidden="true"
    >
      <path d="M5.042 15.165a2.528 2.528 0 0 1-2.52 2.523A2.528 2.528 0 0 1 0 15.165a2.527 2.527 0 0 1 2.522-2.52h2.52v2.52zm1.271 0a2.527 2.527 0 0 1 2.521-2.52 2.527 2.527 0 0 1 2.521 2.52v6.313A2.528 2.528 0 0 1 8.834 24a2.528 2.528 0 0 1-2.521-2.522v-6.313zM8.834 5.042a2.528 2.528 0 0 1-2.521-2.52A2.528 2.528 0 0 1 8.834 0a2.528 2.528 0 0 1 2.521 2.522v2.52H8.834zm0 1.271a2.528 2.528 0 0 1 2.521 2.521 2.528 2.528 0 0 1-2.521 2.521H2.522A2.528 2.528 0 0 1 0 8.834a2.528 2.528 0 0 1 2.522-2.521h6.312zm10.124 2.521a2.528 2.528 0 0 1 2.52-2.521A2.528 2.528 0 0 1 24 8.834a2.528 2.528 0 0 1-2.522 2.521h-2.52V8.834zm-1.271 0a2.528 2.528 0 0 1-2.521 2.521 2.528 2.528 0 0 1-2.521-2.521V2.522A2.528 2.528 0 0 1 15.166 0a2.528 2.528 0 0 1 2.521 2.522v6.312zm-2.521 10.124a2.528 2.528 0 0 1 2.521 2.52A2.528 2.528 0 0 1 15.166 24a2.528 2.528 0 0 1-2.521-2.522v-2.52h2.521zm0-1.271a2.528 2.528 0 0 1-2.521-2.521 2.528 2.528 0 0 1 2.521-2.521h6.312A2.528 2.528 0 0 1 24 15.166a2.528 2.528 0 0 1-2.522 2.521h-6.312z" />
    </svg>
  );
}

// Integration data
const integrations = [
  {
    name: "Microsoft 365",
    description: "Connect your Microsoft account for calendar, email, and file access",
    icon: <Microsoft365Icon className="h-6 w-6" />,
    status: "coming_soon" as const,
    features: [
      "Calendar synchronization",
      "Email integration",
      "OneDrive file access",
    ],
  },
  {
    name: "Slack",
    description: "Integrate with Slack for team communication and notifications",
    icon: <SlackIcon className="h-6 w-6" />,
    status: "coming_soon" as const,
    features: [
      "Send and receive messages",
      "Channel notifications",
      "Direct messaging",
    ],
  },
  {
    name: "Browser Automation",
    description: "Enable automated web interactions and data gathering",
    icon: <Globe className="h-6 w-6" />,
    status: "coming_soon" as const,
    features: [
      "Web research automation",
      "Form filling",
      "Data extraction",
    ],
  },
];

export default function IntegrationsSettingsPage() {
  return (
    <div className="space-y-8">
      {/* Info Banner */}
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20">
            <Plug className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-foreground">Integrations</h3>
              <ComingSoonBadge size="sm" />
            </div>
            <p className="text-sm text-muted-foreground">
              Integrations allow your AI clone to connect with external services
              and tools. These powerful features are being developed and will
              be available in Phase 4.
            </p>
          </div>
        </div>
      </div>

      {/* Planned Integrations */}
      <SettingsSection
        title="Planned Integrations"
        description="Services that will be available for connection"
      >
        <div className="space-y-4">
          {integrations.map((integration) => (
            <IntegrationCard
              key={integration.name}
              name={integration.name}
              description={integration.description}
              icon={integration.icon}
              status={integration.status}
              features={integration.features}
            />
          ))}
        </div>
      </SettingsSection>

      {/* What to Expect */}
      <SettingsSection
        title="What to Expect"
        description="Benefits of integrating external services"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-primary" />
              <h4 className="font-medium text-foreground">Calendar Access</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Your AI clone will be able to check your availability and schedule meetings
            </p>
          </div>
          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <Mail className="h-4 w-4 text-primary" />
              <h4 className="font-medium text-foreground">Email Management</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Draft responses, summarize emails, and manage your inbox efficiently
            </p>
          </div>
          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <Cloud className="h-4 w-4 text-primary" />
              <h4 className="font-medium text-foreground">Cloud Storage</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Access and organize files from your cloud storage services
            </p>
          </div>
          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              <h4 className="font-medium text-foreground">Team Communication</h4>
            </div>
            <p className="text-xs text-muted-foreground">
              Stay connected with your team through integrated messaging platforms
            </p>
          </div>
        </div>
      </SettingsSection>
    </div>
  );
}
