"use client";

import { User, MessageSquare, Globe, Sparkles } from "lucide-react";
import { SettingsSection, ComingSoonBadge } from "@/components/settings";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { cn } from "@/lib/utils";

// Placeholder personality data (from Phase 2 Personality System)
const personalityData = {
  name: "Valerii Sysoiev",
  persona: "AI Clone of cybersecurity consultant",
  communicationStyle: "Professional, friendly",
  languagePreference: "English, Ukrainian",
};

export default function PersonalitySettingsPage() {
  return (
    <div className="space-y-8">
      {/* Info Banner */}
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-6">
        <div className="flex items-start gap-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-foreground">Personality Configuration</h3>
              <ComingSoonBadge size="sm" />
            </div>
            <p className="text-sm text-muted-foreground">
              The personality system allows you to customize how your AI clone behaves,
              communicates, and represents you. Full customization will be available soon.
            </p>
          </div>
        </div>
      </div>

      {/* Identity Section */}
      <SettingsSection
        title="Identity"
        description="Define who your AI clone represents"
      >
        <div className="space-y-6">
          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="persona-name" className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              Name
              <ComingSoonBadge size="sm" />
            </Label>
            <Input
              id="persona-name"
              value={personalityData.name}
              disabled
              className="bg-muted/30 text-muted-foreground cursor-not-allowed"
            />
            <p className="text-xs text-muted-foreground">
              The name your AI clone will use when introducing itself
            </p>
          </div>

          {/* Persona */}
          <div className="space-y-2">
            <Label htmlFor="persona-description" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-muted-foreground" />
              Persona
              <ComingSoonBadge size="sm" />
            </Label>
            <Input
              id="persona-description"
              value={personalityData.persona}
              disabled
              className="bg-muted/30 text-muted-foreground cursor-not-allowed"
            />
            <p className="text-xs text-muted-foreground">
              A brief description of your AI clone&apos;s professional identity
            </p>
          </div>
        </div>
      </SettingsSection>

      {/* Communication Section */}
      <SettingsSection
        title="Communication Style"
        description="Configure how your AI clone communicates"
      >
        <div className="space-y-6">
          {/* Communication Style */}
          <div className="space-y-2">
            <Label htmlFor="comm-style" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
              Style
              <ComingSoonBadge size="sm" />
            </Label>
            <Input
              id="comm-style"
              value={personalityData.communicationStyle}
              disabled
              className="bg-muted/30 text-muted-foreground cursor-not-allowed"
            />
            <p className="text-xs text-muted-foreground">
              The tone and manner in which your AI clone communicates
            </p>
          </div>

          {/* Language */}
          <div className="space-y-2">
            <Label htmlFor="language-pref" className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              Languages
              <ComingSoonBadge size="sm" />
            </Label>
            <Input
              id="language-pref"
              value={personalityData.languagePreference}
              disabled
              className="bg-muted/30 text-muted-foreground cursor-not-allowed"
            />
            <p className="text-xs text-muted-foreground">
              Languages your AI clone can communicate in
            </p>
          </div>
        </div>
      </SettingsSection>

      {/* Preview Section */}
      <SettingsSection
        title="Personality Preview"
        description="A preview of how your AI clone presents itself"
      >
        <div className="p-6 rounded-xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border border-primary/20">
          <div className="flex items-start gap-4">
            <div
              className={cn(
                "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl",
                "bg-gradient-to-br from-primary/30 to-primary/10",
                "text-primary font-bold text-xl"
              )}
            >
              {personalityData.name.charAt(0)}
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground mb-1">{personalityData.name}</h4>
              <p className="text-sm text-muted-foreground mb-3">
                {personalityData.persona}
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-2 py-1 text-xs rounded-md bg-muted/50 text-muted-foreground border border-border/50">
                  {personalityData.communicationStyle}
                </span>
                <span className="px-2 py-1 text-xs rounded-md bg-muted/50 text-muted-foreground border border-border/50">
                  {personalityData.languagePreference}
                </span>
              </div>
            </div>
          </div>
        </div>
      </SettingsSection>
    </div>
  );
}
