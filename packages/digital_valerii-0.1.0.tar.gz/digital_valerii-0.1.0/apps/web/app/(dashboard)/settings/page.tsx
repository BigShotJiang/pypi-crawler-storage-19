"use client";

import { LogOut, AlertTriangle } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState, useCallback } from "react";
import { SettingsSection, ProfileForm, PasswordForm } from "@/components/settings";
import { Button } from "@/components/ui/Button";
import { useAuthStore } from "@/lib/stores/auth";
import { formatDate } from "@/lib/utils";

export default function AccountSettingsPage() {
  const router = useRouter();
  const { user, logout } = useAuthStore();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = useCallback(async () => {
    setIsLoggingOut(true);
    try {
      await logout();
      router.push("/login");
    } catch {
      setIsLoggingOut(false);
    }
  }, [logout, router]);

  return (
    <div className="space-y-8">
      {/* Profile Section */}
      <SettingsSection
        title="Profile"
        description="Manage your personal information and display preferences"
      >
        <ProfileForm />
      </SettingsSection>

      {/* Security Section */}
      <SettingsSection
        title="Security"
        description="Update your password and manage account security"
      >
        <PasswordForm />
      </SettingsSection>

      {/* Account Info Section */}
      <SettingsSection title="Account Information" description="View your account details">
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
              <p className="text-xs text-muted-foreground mb-1">Account Created</p>
              <p className="text-sm font-medium text-foreground">
                {user?.created_at ? formatDate(user.created_at) : "Unknown"}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
              <p className="text-xs text-muted-foreground mb-1">Last Login</p>
              <p className="text-sm font-medium text-foreground">
                {user?.last_login_at ? formatDate(user.last_login_at) : "Current session"}
              </p>
            </div>
          </div>
          <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
            <p className="text-xs text-muted-foreground mb-1">Account Status</p>
            <div className="flex items-center gap-2 mt-1">
              {user?.is_active ? (
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium bg-green-500/20 text-green-400 border border-green-500/30">
                  Active
                </span>
              ) : (
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium bg-destructive/20 text-destructive border border-destructive/30">
                  Inactive
                </span>
              )}
              {user?.is_verified && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  Verified
                </span>
              )}
            </div>
          </div>
        </div>
      </SettingsSection>

      {/* Danger Zone */}
      <SettingsSection
        title="Danger Zone"
        description="Irreversible and destructive actions"
        variant="danger"
      >
        <div className="space-y-4">
          {/* Logout */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-destructive/5 border border-destructive/20">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">Sign out</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Sign out from this session. You will need to sign in again.
                </p>
              </div>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleLogout}
              disabled={isLoggingOut}
              className="shrink-0"
            >
              <LogOut className="h-4 w-4" />
              {isLoggingOut ? "Signing out..." : "Sign out"}
            </Button>
          </div>
        </div>
      </SettingsSection>
    </div>
  );
}
