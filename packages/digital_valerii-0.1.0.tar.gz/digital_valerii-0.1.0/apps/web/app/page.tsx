import { redirect } from "next/navigation";

export default function HomePage() {
  // Redirect to chat page - auth check happens in dashboard layout
  redirect("/chat");
}
