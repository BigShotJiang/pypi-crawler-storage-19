/**
 * TypeScript types for Digital Valerii Web Interface.
 */

// User types
export interface User {
  id: string;
  email: string;
  display_name: string;
  role: UserRole;
  is_active: boolean;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
  last_login_at?: string;
}

export type UserRole = "owner" | "admin" | "user";

// Auth types
export interface TokenPair {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse extends TokenPair {
  user: User;
}

// Chat types
export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  is_streaming?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface ConversationDetail extends Conversation {
  messages: Message[];
}

export interface SendMessageRequest {
  message: string;
  conversation_id?: string;
}

export interface ChatResponse {
  id: string;
  message: Message;
  conversation_id: string;
}

// Memory types (Component 3.3)
export interface MemorySearchResult {
  event_id: string;
  event_type: string;
  title: string | null;
  summary: string | null;
  occurred_at: string;
  score: number;
}

export interface PersonSummary {
  id: string;
  name: string;
  email: string | null;
  company: string | null;
  relationship_type: string | null;
}

export interface PersonDetail extends PersonSummary {
  notes: string | null;
  last_interaction: string | null;
  interaction_count: number;
}

export interface ProjectSummary {
  id: string;
  name: string;
  status: "active" | "completed" | "archived";
  description: string | null;
}

export interface ProjectDetail extends ProjectSummary {
  created_at: string;
  updated_at: string;
  people: PersonSummary[];
}

export type MemoryFilterType = "all" | "people" | "projects" | "events";

export interface MemoryState {
  searchResults: MemorySearchResult[];
  people: PersonSummary[];
  projects: ProjectSummary[];
  selectedPerson: PersonDetail | null;
  selectedProject: ProjectDetail | null;
  filter: MemoryFilterType;
  searchQuery: string;
  isLoading: boolean;
  error: string | null;
}

// API Error types
export interface ApiError {
  detail: string;
  code?: string;
  status?: number;
}

// Store state types
export interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface ChatState {
  conversations: Conversation[];
  currentConversation: ConversationDetail | null;
  isLoading: boolean;
  isSending: boolean;
  error: string | null;
}
