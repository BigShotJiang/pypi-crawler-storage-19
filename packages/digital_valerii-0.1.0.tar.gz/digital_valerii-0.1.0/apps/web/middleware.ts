import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Next.js Middleware for server-side auth protection (UI HINT ONLY).
 *
 * SECURITY NOTE: This middleware is NOT a security boundary.
 * - The auth-token cookie is unsigned and client-set (can be forged)
 * - This only provides better UX by redirecting before page load
 * - No sensitive SSR data is exposed based on this cookie alone
 * - Real authentication happens on API calls with JWT tokens
 *
 * Purpose: Avoid showing protected UI shells to unauthenticated users.
 * Actual data access always requires valid JWT on API requests.
 */
export function middleware(request: NextRequest) {
  // Check for auth indicator cookie
  const authCookie = request.cookies.get("auth-token")?.value;
  const isAuthenticated = authCookie === "1";

  const { pathname } = request.nextUrl;

  // Define route types
  const isAuthPage = pathname.startsWith("/login");
  const isProtectedPage =
    pathname.startsWith("/chat") ||
    pathname.startsWith("/settings") ||
    pathname.startsWith("/memory");

  // Redirect unauthenticated users to login
  if (isProtectedPage && !isAuthenticated) {
    const loginUrl = new URL("/login", request.url);
    // Preserve the intended destination for redirect after login
    loginUrl.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Redirect authenticated users away from login page
  if (isAuthPage && isAuthenticated) {
    return NextResponse.redirect(new URL("/chat", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    // Match all protected and auth routes
    "/chat/:path*",
    "/settings/:path*",
    "/memory/:path*",
    "/login",
  ],
};
