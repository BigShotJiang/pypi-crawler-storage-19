import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { apiClient } from "../client";

describe("ApiClient", () => {
  const mockFetch = vi.fn();
  const originalFetch = global.fetch;

  beforeEach(() => {
    global.fetch = mockFetch;
    mockFetch.mockReset();
  });

  afterEach(() => {
    global.fetch = originalFetch;
    apiClient.setAccessToken(null);
  });

  describe("setAccessToken", () => {
    it("sets the access token for authenticated requests", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify({ id: "1", email: "test@example.com" }),
      });

      apiClient.setAccessToken("test-token");
      await apiClient.getMe();

      expect(mockFetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: "Bearer test-token",
          }),
        })
      );
    });
  });

  describe("login", () => {
    it("sends login request with credentials", async () => {
      const mockResponse = {
        access_token: "access-123",
        refresh_token: "refresh-123",
        token_type: "bearer",
        expires_in: 1800,
        user: { id: "1", email: "test@example.com" },
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify(mockResponse),
      });

      const result = await apiClient.login("test@example.com", "password123");

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/auth/login"),
        expect.objectContaining({
          method: "POST",
          body: JSON.stringify({
            email: "test@example.com",
            password: "password123",
          }),
        })
      );
      expect(result).toEqual(mockResponse);
    });

    it("throws error on failed login", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: false,
        status: 401,
        json: async () => ({ detail: "Invalid credentials" }),
      });

      await expect(
        apiClient.login("test@example.com", "wrongpassword")
      ).rejects.toThrow("Invalid credentials");
    });
  });

  describe("logout", () => {
    it("sends logout request without refresh token", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => "",
      });

      await apiClient.logout();

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/auth/logout"),
        expect.objectContaining({
          method: "POST",
          body: JSON.stringify({ refresh_token: undefined }),
        })
      );
    });

    it("sends logout request with refresh token for revocation", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => "",
      });

      await apiClient.logout("refresh-token-123");

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/auth/logout"),
        expect.objectContaining({
          method: "POST",
          body: JSON.stringify({ refresh_token: "refresh-token-123" }),
        })
      );
    });
  });

  describe("getConversations", () => {
    it("fetches conversations list", async () => {
      const mockConversations = [
        { id: "1", title: "Test Conversation", created_at: new Date().toISOString() },
      ];

      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify(mockConversations),
      });

      const result = await apiClient.getConversations();

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/chat/conversations"),
        expect.any(Object)
      );
      expect(result).toEqual(mockConversations);
    });
  });

  describe("sendMessage", () => {
    it("sends message and returns response", async () => {
      const mockResponse = {
        id: "msg-1",
        message: {
          id: "1",
          role: "assistant",
          content: "Hello!",
          timestamp: new Date().toISOString(),
        },
        conversation_id: "conv-1",
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify(mockResponse),
      });

      const result = await apiClient.sendMessage("Hello", "conv-1");

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/chat/message"),
        expect.objectContaining({
          method: "POST",
          body: JSON.stringify({
            message: "Hello",
            conversation_id: "conv-1",
          }),
        })
      );
      expect(result).toEqual(mockResponse);
    });

    it("sends message without conversation ID for new chat", async () => {
      const mockResponse = {
        id: "msg-1",
        message: {
          id: "1",
          role: "assistant",
          content: "Hello!",
          timestamp: new Date().toISOString(),
        },
        conversation_id: "new-conv-1",
      };

      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify(mockResponse),
      });

      await apiClient.sendMessage("Hello");

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/chat/message"),
        expect.objectContaining({
          body: JSON.stringify({
            message: "Hello",
            conversation_id: undefined,
          }),
        })
      );
    });
  });

  describe("deleteConversation", () => {
    it("sends delete request for conversation", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => "",
      });

      await apiClient.deleteConversation("conv-1");

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining("/chat/conversations/conv-1"),
        expect.objectContaining({
          method: "DELETE",
        })
      );
    });
  });

  describe("error handling", () => {
    it("handles network errors", async () => {
      mockFetch.mockRejectedValueOnce(new Error("Network error"));

      await expect(apiClient.getMe()).rejects.toThrow("Network error");
    });

    it("handles malformed JSON responses", async () => {
      mockFetch.mockResolvedValueOnce({
        ok: false,
        status: 500,
        json: async () => {
          throw new Error("Invalid JSON");
        },
      });

      await expect(apiClient.getMe()).rejects.toThrow();
    });
  });

  describe("UUID validation", () => {
    it("getPerson throws error for invalid UUID format", async () => {
      await expect(apiClient.getPerson("invalid-id")).rejects.toThrow(
        "Invalid person ID format"
      );
      expect(mockFetch).not.toHaveBeenCalled();
    });

    it("getPerson allows valid UUID", async () => {
      const validUUID = "550e8400-e29b-41d4-a716-446655440000";
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify({ id: validUUID, name: "Test Person" }),
      });

      await apiClient.getPerson(validUUID);

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining(`/memory/people/${validUUID}`),
        expect.any(Object)
      );
    });

    it("getProject throws error for invalid UUID format", async () => {
      await expect(apiClient.getProject("not-a-uuid")).rejects.toThrow(
        "Invalid project ID format"
      );
      expect(mockFetch).not.toHaveBeenCalled();
    });

    it("getProject allows valid UUID", async () => {
      const validUUID = "123e4567-e89b-12d3-a456-426614174000";
      mockFetch.mockResolvedValueOnce({
        ok: true,
        text: async () => JSON.stringify({ id: validUUID, name: "Test Project" }),
      });

      await apiClient.getProject(validUUID);

      expect(mockFetch).toHaveBeenCalledWith(
        expect.stringContaining(`/memory/projects/${validUUID}`),
        expect.any(Object)
      );
    });

    it("getPerson rejects malicious path traversal attempts", async () => {
      await expect(apiClient.getPerson("../../../etc/passwd")).rejects.toThrow(
        "Invalid person ID format"
      );
      expect(mockFetch).not.toHaveBeenCalled();
    });

    it("getProject rejects SQL injection attempts", async () => {
      await expect(apiClient.getProject("1; DROP TABLE projects;")).rejects.toThrow(
        "Invalid project ID format"
      );
      expect(mockFetch).not.toHaveBeenCalled();
    });
  });
});
