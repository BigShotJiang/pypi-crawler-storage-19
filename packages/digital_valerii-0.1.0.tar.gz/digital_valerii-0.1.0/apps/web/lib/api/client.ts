/**
 * API Client for Digital Valerii backend.
 * Supports authentication, chat, and streaming responses.
 */

import type {
  User,
  TokenPair,
  LoginResponse,
  Conversation,
  ConversationDetail,
  ChatResponse,
  MemorySearchResult,
  PersonSummary,
  PersonDetail,
  ProjectSummary,
  ProjectDetail,
  ApiError,
} from "@/types";
import { isValidUUID } from "@/lib/utils";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

class ApiClient {
  private baseUrl: string;
  private accessToken: string | null = null;

  constructor(baseUrl: string = API_URL) {
    this.baseUrl = baseUrl;
  }

  /**
   * Set the access token for authenticated requests.
   */
  setAccessToken(token: string | null): void {
    this.accessToken = token;
  }

  /**
   * Make an authenticated request.
   */
  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;

    const headers: HeadersInit = {
      "Content-Type": "application/json",
      ...options.headers,
    };

    if (this.accessToken) {
      (headers as Record<string, string>)["Authorization"] =
        `Bearer ${this.accessToken}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error: ApiError = await response.json().catch(() => ({
        detail: "An unexpected error occurred",
        status: response.status,
      }));
      throw new Error(error.detail || `Request failed: ${response.status}`);
    }

    // Handle empty responses
    const text = await response.text();
    if (!text) return {} as T;

    return JSON.parse(text);
  }

  // ===================
  // Auth Endpoints
  // ===================

  async login(email: string, password: string): Promise<LoginResponse> {
    return this.request<LoginResponse>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  }

  async logout(refreshToken?: string): Promise<void> {
    await this.request<void>("/auth/logout", {
      method: "POST",
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
  }

  async refresh(refreshToken: string): Promise<TokenPair> {
    return this.request<TokenPair>("/auth/refresh", {
      method: "POST",
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
  }

  async getMe(): Promise<User> {
    return this.request<User>("/auth/me");
  }

  /**
   * Update user profile.
   * Note: Backend endpoint may not be implemented yet - will return error.
   */
  async updateProfile(data: { display_name: string }): Promise<User> {
    return this.request<User>("/auth/me", {
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  /**
   * Change user password.
   * Note: Backend endpoint may not be implemented yet - will return error.
   */
  async changePassword(data: {
    current_password: string;
    new_password: string;
  }): Promise<void> {
    return this.request<void>("/auth/change-password", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  // ===================
  // Chat Endpoints
  // ===================

  async sendMessage(
    message: string,
    conversationId?: string
  ): Promise<ChatResponse> {
    return this.request<ChatResponse>("/chat/message", {
      method: "POST",
      body: JSON.stringify({
        message,
        conversation_id: conversationId,
      }),
    });
  }

  /**
   * Stream a chat message response using Server-Sent Events.
   * Yields chunks of text as they arrive.
   */
  async *streamMessage(
    message: string,
    conversationId?: string
  ): AsyncGenerator<{ content: string; done: boolean; conversationId?: string }> {
    const url = `${this.baseUrl}/chat/message/stream`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(this.accessToken && { Authorization: `Bearer ${this.accessToken}` }),
      },
      body: JSON.stringify({
        message,
        conversation_id: conversationId,
      }),
    });

    if (!response.ok) {
      const error: ApiError = await response.json().catch(() => ({
        detail: "Streaming request failed",
      }));
      throw new Error(error.detail);
    }

    if (!response.body) {
      throw new Error("No response body");
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    try {
      while (true) {
        const { done, value } = await reader.read();

        if (done) {
          // Process any remaining data in buffer
          if (buffer.trim()) {
            const lines = buffer.split("\n").filter((line) => line.trim());
            for (const line of lines) {
              if (line.startsWith("data: ")) {
                const data = line.slice(6);
                if (data === "[DONE]") {
                  yield { content: "", done: true };
                } else {
                  try {
                    const parsed = JSON.parse(data);
                    yield {
                      content: parsed.content || "",
                      done: false,
                      conversationId: parsed.conversation_id,
                    };
                  } catch {
                    // Not JSON, treat as text
                    yield { content: data, done: false };
                  }
                }
              }
            }
          }
          break;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || ""; // Keep incomplete line in buffer

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const data = line.slice(6).trim();
            if (data === "[DONE]") {
              yield { content: "", done: true };
            } else if (data) {
              try {
                const parsed = JSON.parse(data);
                yield {
                  content: parsed.content || "",
                  done: false,
                  conversationId: parsed.conversation_id,
                };
              } catch {
                // Not JSON, treat as text content
                yield { content: data, done: false };
              }
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }

  async getConversations(): Promise<Conversation[]> {
    return this.request<Conversation[]>("/chat/conversations");
  }

  async getConversation(id: string): Promise<ConversationDetail> {
    return this.request<ConversationDetail>(`/chat/conversations/${id}`);
  }

  async deleteConversation(id: string): Promise<void> {
    await this.request<void>(`/chat/conversations/${id}`, {
      method: "DELETE",
    });
  }

  // ===================
  // Memory Endpoints
  // ===================

  async searchMemories(
    query: string,
    limit?: number
  ): Promise<MemorySearchResult[]> {
    const params = new URLSearchParams({ q: query });
    if (limit) params.append("limit", String(limit));
    return this.request<MemorySearchResult[]>(`/memory/search?${params}`);
  }

  async listPeople(query?: string, limit?: number): Promise<PersonSummary[]> {
    const params = new URLSearchParams();
    if (query) params.append("q", query);
    if (limit) params.append("limit", String(limit));
    const queryString = params.toString();
    return this.request<PersonSummary[]>(
      `/memory/people${queryString ? `?${queryString}` : ""}`
    );
  }

  async getPerson(id: string): Promise<PersonDetail> {
    if (!isValidUUID(id)) {
      throw new Error("Invalid person ID format");
    }
    return this.request<PersonDetail>(`/memory/people/${id}`);
  }

  async listProjects(
    query?: string,
    status?: string,
    limit?: number
  ): Promise<ProjectSummary[]> {
    const params = new URLSearchParams();
    if (query) params.append("q", query);
    if (status) params.append("status", status);
    if (limit) params.append("limit", String(limit));
    const queryString = params.toString();
    return this.request<ProjectSummary[]>(
      `/memory/projects${queryString ? `?${queryString}` : ""}`
    );
  }

  async getProject(id: string): Promise<ProjectDetail> {
    if (!isValidUUID(id)) {
      throw new Error("Invalid project ID format");
    }
    return this.request<ProjectDetail>(`/memory/projects/${id}`);
  }
}

// Export singleton instance
export const apiClient = new ApiClient();
