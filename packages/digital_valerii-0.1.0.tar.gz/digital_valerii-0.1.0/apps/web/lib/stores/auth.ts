import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { User, AuthState, LoginResponse } from "@/types";
import { apiClient } from "@/lib/api/client";
import { useMemoryStore } from "./memory";

/**
 * Cookie utility for auth indicator (UI HINT ONLY).
 *
 * SECURITY NOTE: This cookie is NOT a security boundary.
 * - It is unsigned and client-set (can be forged)
 * - It only provides better UX by redirecting before page load
 * - Real authentication happens on API with JWT tokens
 * - No sensitive data is exposed based on this cookie alone
 *
 * The middleware uses this to avoid showing protected UI shells
 * to unauthenticated users, but actual data access requires valid JWT.
 */
function setAuthCookie(authenticated: boolean) {
  if (typeof document !== "undefined") {
    // Detect HTTPS for Secure flag
    const isSecure = window.location.protocol === "https:";
    const secureFlag = isSecure ? "; Secure" : "";

    if (authenticated) {
      // Set auth indicator cookie (UI hint, not security boundary)
      document.cookie = `auth-token=1; path=/; SameSite=Strict${secureFlag}; max-age=86400`;
    } else {
      // Clear the auth cookie
      document.cookie = `auth-token=; path=/; SameSite=Strict${secureFlag}; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    }
  }
}

interface AuthActions {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshTokens: () => Promise<boolean>;
  checkAuth: () => Promise<boolean>;
  setUser: (user: User | null) => void;
  clearError: () => void;
}

type AuthStore = AuthState & AuthActions;

const initialState: AuthState = {
  user: null,
  accessToken: null,
  refreshToken: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
};

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      ...initialState,

      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null });

        try {
          const response: LoginResponse = await apiClient.login(email, password);

          set({
            user: response.user,
            accessToken: response.access_token,
            refreshToken: response.refresh_token,
            isAuthenticated: true,
            isLoading: false,
            error: null,
          });

          // Update API client with new token
          apiClient.setAccessToken(response.access_token);

          // Set auth indicator cookie for middleware
          setAuthCookie(true);
        } catch (error) {
          const message =
            error instanceof Error ? error.message : "Login failed";
          set({
            isLoading: false,
            error: message,
            isAuthenticated: false,
          });
          throw error;
        }
      },

      logout: async () => {
        const { refreshToken } = get();

        try {
          // Send refresh token for server-side revocation (FIX-2)
          if (refreshToken) {
            await apiClient.logout(refreshToken);
          }
        } catch {
          // Best-effort revocation - still clear local state
        } finally {
          set({
            ...initialState,
            isLoading: false,
          });
          apiClient.setAccessToken(null);

          // Clear auth indicator cookie
          setAuthCookie(false);

          // Clear memory store to prevent data leak between accounts
          useMemoryStore.getState().reset();
        }
      },

      refreshTokens: async () => {
        const { refreshToken } = get();
        if (!refreshToken) return false;

        try {
          const response = await apiClient.refresh(refreshToken);
          set({
            accessToken: response.access_token,
            refreshToken: response.refresh_token,
          });
          apiClient.setAccessToken(response.access_token);
          return true;
        } catch {
          // Refresh failed - clear auth state
          set({
            ...initialState,
            isLoading: false,
          });
          apiClient.setAccessToken(null);
          setAuthCookie(false);
          return false;
        }
      },

      checkAuth: async () => {
        const { accessToken, refreshToken } = get();

        if (!accessToken && !refreshToken) {
          set({ isLoading: false, isAuthenticated: false });
          setAuthCookie(false);
          return false;
        }

        if (accessToken) {
          apiClient.setAccessToken(accessToken);
        }

        try {
          const user = await apiClient.getMe();
          set({
            user,
            isAuthenticated: true,
            isLoading: false,
          });
          setAuthCookie(true);
          return true;
        } catch {
          // Token might be expired, try refresh
          if (refreshToken) {
            const refreshed = await get().refreshTokens();
            if (refreshed) {
              try {
                const user = await apiClient.getMe();
                set({
                  user,
                  isAuthenticated: true,
                  isLoading: false,
                });
                setAuthCookie(true);
                return true;
              } catch {
                // Still failed
              }
            }
          }

          set({
            ...initialState,
            isLoading: false,
          });
          setAuthCookie(false);
          return false;
        }
      },

      setUser: (user) => set({ user }),

      clearError: () => set({ error: null }),
    }),
    {
      name: "digital-valerii-auth",
      storage: createJSONStorage(() => localStorage),
      // FIX-1: Do NOT persist tokens in localStorage (XSS risk)
      // Only persist non-sensitive user preference data
      // Tokens are kept in memory only - user must re-login after page refresh
      partialize: () => ({}),
    }
  )
);
