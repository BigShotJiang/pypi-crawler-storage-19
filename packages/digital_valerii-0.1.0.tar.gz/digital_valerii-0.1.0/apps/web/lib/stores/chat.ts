import { create } from "zustand";
import type {
  Conversation,
  ConversationDetail,
  Message,
  ChatState,
} from "@/types";
import { apiClient } from "@/lib/api/client";
import { generateId } from "@/lib/utils";

interface ChatActions {
  fetchConversations: () => Promise<void>;
  fetchConversation: (id: string) => Promise<void>;
  sendMessage: (message: string) => Promise<void>;
  deleteConversation: (id: string) => Promise<void>;
  createNewConversation: () => void;
  setCurrentConversation: (conversation: ConversationDetail | null) => void;
  clearError: () => void;
}

type ChatStore = ChatState & ChatActions;

const initialState: ChatState = {
  conversations: [],
  currentConversation: null,
  isLoading: false,
  isSending: false,
  error: null,
};

export const useChatStore = create<ChatStore>((set, get) => ({
  ...initialState,

  fetchConversations: async () => {
    set({ isLoading: true, error: null });

    try {
      const conversations = await apiClient.getConversations();
      set({ conversations, isLoading: false });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load conversations";
      set({ isLoading: false, error: message });
    }
  },

  fetchConversation: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const conversation = await apiClient.getConversation(id);
      set({ currentConversation: conversation, isLoading: false });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load conversation";
      set({ isLoading: false, error: message });
    }
  },

  sendMessage: async (message: string) => {
    const { currentConversation, conversations } = get();

    // Create optimistic user message
    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content: message,
      timestamp: new Date().toISOString(),
    };

    // Create placeholder for assistant response
    const assistantMessage: Message = {
      id: generateId(),
      role: "assistant",
      content: "",
      timestamp: new Date().toISOString(),
      is_streaming: true,
    };

    // Update state with optimistic messages
    const updatedMessages = [
      ...(currentConversation?.messages || []),
      userMessage,
      assistantMessage,
    ];

    set({
      isSending: true,
      error: null,
      currentConversation: currentConversation
        ? { ...currentConversation, messages: updatedMessages }
        : {
            id: "",
            title: message.slice(0, 50),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            message_count: 0,
            messages: updatedMessages,
          },
    });

    try {
      let fullContent = "";
      let newConversationId: string | undefined;

      // Stream the response
      for await (const chunk of apiClient.streamMessage(
        message,
        currentConversation?.id
      )) {
        if (chunk.done) break;

        fullContent += chunk.content;
        if (chunk.conversationId) {
          newConversationId = chunk.conversationId;
        }

        // Update assistant message with streamed content
        set((state) => {
          if (!state.currentConversation) return state;

          const messages = state.currentConversation.messages.map((msg) =>
            msg.id === assistantMessage.id
              ? { ...msg, content: fullContent }
              : msg
          );

          return {
            ...state,
            currentConversation: {
              ...state.currentConversation,
              id: newConversationId || state.currentConversation.id,
              messages,
            },
          };
        });
      }

      // Finalize the message
      set((state) => {
        if (!state.currentConversation) return state;

        const messages = state.currentConversation.messages.map((msg) =>
          msg.id === assistantMessage.id
            ? { ...msg, content: fullContent, is_streaming: false }
            : msg
        );

        const updatedConversation = {
          ...state.currentConversation,
          id: newConversationId || state.currentConversation.id,
          messages,
          message_count: messages.length,
          updated_at: new Date().toISOString(),
        };

        // Update conversations list
        let updatedConversations = [...conversations];
        const existingIndex = updatedConversations.findIndex(
          (c) => c.id === updatedConversation.id
        );

        if (existingIndex >= 0) {
          updatedConversations[existingIndex] = {
            ...updatedConversations[existingIndex],
            updated_at: updatedConversation.updated_at,
            message_count: updatedConversation.message_count,
          };
        } else if (newConversationId) {
          // Add new conversation to the list
          updatedConversations = [
            {
              id: newConversationId,
              title: message.slice(0, 50) + (message.length > 50 ? "..." : ""),
              created_at: updatedConversation.created_at,
              updated_at: updatedConversation.updated_at,
              message_count: updatedConversation.message_count,
            },
            ...updatedConversations,
          ];
        }

        return {
          ...state,
          isSending: false,
          currentConversation: updatedConversation,
          conversations: updatedConversations,
        };
      });
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Failed to send message";

      // Remove the failed messages
      set((state) => {
        if (!state.currentConversation) return { ...state, isSending: false, error: errorMessage };

        const messages = state.currentConversation.messages.filter(
          (msg) => msg.id !== userMessage.id && msg.id !== assistantMessage.id
        );

        return {
          ...state,
          isSending: false,
          error: errorMessage,
          currentConversation: {
            ...state.currentConversation,
            messages,
          },
        };
      });
    }
  },

  deleteConversation: async (id: string) => {
    try {
      await apiClient.deleteConversation(id);

      set((state) => ({
        conversations: state.conversations.filter((c) => c.id !== id),
        currentConversation:
          state.currentConversation?.id === id
            ? null
            : state.currentConversation,
      }));
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete conversation";
      set({ error: message });
    }
  },

  createNewConversation: () => {
    set({ currentConversation: null });
  },

  setCurrentConversation: (conversation) => {
    set({ currentConversation: conversation });
  },

  clearError: () => set({ error: null }),
}));
