import { create } from "zustand";
import type {
  MemorySearchResult,
  PersonSummary,
  PersonDetail,
  ProjectSummary,
  ProjectDetail,
  MemoryFilterType,
  MemoryState,
} from "@/types";
import { apiClient } from "@/lib/api/client";

interface MemoryActions {
  searchMemories: (query: string, limit?: number) => Promise<void>;
  listPeople: (query?: string, limit?: number) => Promise<void>;
  getPerson: (id: string) => Promise<void>;
  listProjects: (query?: string, status?: string, limit?: number) => Promise<void>;
  getProject: (id: string) => Promise<void>;
  setFilter: (filter: MemoryFilterType) => void;
  setSearchQuery: (query: string) => void;
  clearSelectedPerson: () => void;
  clearSelectedProject: () => void;
  clearError: () => void;
  reset: () => void;
}

type MemoryStore = MemoryState & MemoryActions;

const initialState: MemoryState = {
  searchResults: [],
  people: [],
  projects: [],
  selectedPerson: null,
  selectedProject: null,
  filter: "all",
  searchQuery: "",
  isLoading: false,
  error: null,
};

export const useMemoryStore = create<MemoryStore>()((set) => ({
  ...initialState,

  searchMemories: async (query: string, limit?: number) => {
    set({ isLoading: true, error: null });

    try {
      const results = await apiClient.searchMemories(query, limit);
      set({
        searchResults: results,
        searchQuery: query,
        isLoading: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to search memories";
      set({ isLoading: false, error: message });
    }
  },

  listPeople: async (query?: string, limit?: number) => {
    set({ isLoading: true, error: null });

    try {
      const people = await apiClient.listPeople(query, limit);
      set({
        people,
        isLoading: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load people";
      set({ isLoading: false, error: message });
    }
  },

  getPerson: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const person = await apiClient.getPerson(id);
      set({
        selectedPerson: person,
        isLoading: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load person";
      set({ isLoading: false, error: message });
    }
  },

  listProjects: async (query?: string, status?: string, limit?: number) => {
    set({ isLoading: true, error: null });

    try {
      const projects = await apiClient.listProjects(query, status, limit);
      set({
        projects,
        isLoading: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load projects";
      set({ isLoading: false, error: message });
    }
  },

  getProject: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const project = await apiClient.getProject(id);
      set({
        selectedProject: project,
        isLoading: false,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load project";
      set({ isLoading: false, error: message });
    }
  },

  setFilter: (filter: MemoryFilterType) => {
    set({ filter });
  },

  setSearchQuery: (query: string) => {
    set({ searchQuery: query });
  },

  clearSelectedPerson: () => {
    set({ selectedPerson: null });
  },

  clearSelectedProject: () => {
    set({ selectedProject: null });
  },

  clearError: () => {
    set({ error: null });
  },

  reset: () => {
    set(initialState);
  },
}));
