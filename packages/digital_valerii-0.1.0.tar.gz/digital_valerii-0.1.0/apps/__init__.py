"""Digital Valerii applications package."""
