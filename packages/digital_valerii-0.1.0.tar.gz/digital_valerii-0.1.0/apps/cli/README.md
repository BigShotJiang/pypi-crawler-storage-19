# Digital Valerii CLI

Command-line interface for interacting with Digital Valerii AI clone.

## Installation

The CLI is installed as part of the main project:

```bash
uv sync
```

Entry point: `dv`

## Configuration

Before using the CLI, configure your API connection:

```bash
# Set API URL (default: http://localhost:8000)
dv config set api_url http://localhost:8000

# Set API key (required for authentication)
dv config set api_key YOUR_API_KEY

# View current configuration
dv config show
```

Configuration is stored in `~/.config/digital-valerii/config.json` with secure permissions (0600).

## Quick Query

Send a quick one-shot message:

```bash
dv ask "What's on my calendar today?"
dv ask "Summarize my last meeting"
```

## Chat Commands

Interactive and quick chat modes:

```bash
# Quick message
dv chat "How do I set up feature X?"

# Enter interactive mode
dv chat

# Continue last conversation
dv chat --continue

# Resume specific conversation
dv chat -c <conversation-uuid>

# Output as JSON (for scripting)
dv chat "Quick question" --json
```

## Memory Commands

Search and explore memories:

```bash
# Search memories
dv memory search "project alpha"
dv memory search "meeting notes" --limit 5
dv memory search "client" --json

# List people
dv memory people
dv memory people --query "john"
dv memory people <person-uuid>  # Get details

# List projects
dv memory projects
dv memory projects --status active
dv memory projects <project-uuid>  # Get details
```

## Status Check

Check API connection:

```bash
dv status
```

## Output Formats

Configure default output format:

```bash
dv config set output_format rich   # Rich formatting (default)
dv config set output_format plain  # Plain text
dv config set output_format json   # JSON output
```

Or use `--json` flag for one-off JSON output:

```bash
dv memory search "query" --json
dv memory people --json
```

## Error Handling

The CLI provides helpful error messages:

- **No API key**: Prompts to run `dv config set api_key`
- **Connection error**: Shows API URL and suggests checking server
- **Rate limited (429)**: Shows wait message
- **Authentication failed (401)**: Prompts to check API key

## Development

Run tests:

```bash
pytest apps/cli/tests -v
```

Lint:

```bash
ruff check apps/cli
```
