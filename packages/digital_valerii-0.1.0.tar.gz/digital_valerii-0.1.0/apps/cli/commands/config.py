"""Configuration commands."""

import typer

from apps.cli.config import get_config_path, load_config, update_config
from apps.cli.display import console, print_config, print_error, print_success

config_app = typer.Typer(name="config", help="Manage CLI configuration")


@config_app.command("show")
def show() -> None:
    """Show current configuration."""
    settings = load_config()
    print_config(settings)
    console.print(f"\n[dim]Config file: {get_config_path()}[/dim]")


@config_app.command("set")
def set_config(
    key: str = typer.Argument(..., help="Configuration key to set"),
    value: str = typer.Argument(..., help="Value to set"),
) -> None:
    """Set a configuration value.

    Examples:
        dv config set api_url http://localhost:8000
        dv config set api_key your-api-key
        dv config set output_format json
    """
    try:
        settings = update_config(key, value)

        # Show masked value for api_key
        display_value = settings.mask_api_key() if key == "api_key" else value
        print_success(f"Set {key} = {display_value}")
    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except RuntimeError as e:
        print_error(str(e))
        raise typer.Exit(1) from None


@config_app.command("path")
def path() -> None:
    """Show configuration file path."""
    config_path = get_config_path()
    console.print(str(config_path))
