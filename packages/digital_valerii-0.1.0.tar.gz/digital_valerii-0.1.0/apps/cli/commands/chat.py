"""Chat commands."""

import asyncio
from typing import Annotated
from uuid import UUID

import typer
from rich.prompt import Prompt

from apps.cli.client import APIError, ConnectionError, DVClient
from apps.cli.config import load_config, save_config
from apps.cli.display import (
    console,
    print_chat_header,
    print_chat_response,
    print_error,
    print_info,
)

chat_app = typer.Typer(name="chat", help="Chat with Digital Valerii")


def _validate_uuid(value: str) -> UUID:
    """Validate and parse UUID string.

    Args:
        value: UUID string.

    Returns:
        Parsed UUID.

    Raises:
        typer.BadParameter: If invalid UUID.
    """
    try:
        return UUID(value)
    except ValueError:
        raise typer.BadParameter(f"Invalid UUID: {value}") from None


async def _send_message(
    message: str,
    conversation_id: UUID | None = None,
    output_json: bool = False,
) -> UUID | None:
    """Send a chat message and display response.

    Args:
        message: User message.
        conversation_id: Optional conversation ID.
        output_json: Output as JSON.

    Returns:
        Conversation ID for continuing.
    """
    # Validate message length
    if len(message) > 10000:
        print_error("Message too long. Maximum 10000 characters.")
        raise typer.Exit(1)

    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Thinking...[/yellow]"):
                response = await client.chat(message, conversation_id)

            if output_json:
                import json

                console.print(json.dumps(response.model_dump(mode="json"), indent=2))
            else:
                print_chat_response(response.message, response.tokens_used)

            return response.conversation_id

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            print_info(f"API URL: {settings.api_url}")
            print_info("Make sure the API server is running.")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
                print_info("Run: dv config set api_key YOUR_KEY")
            elif e.status_code == 429:
                print_error("Rate limit exceeded. Please wait and try again.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


async def _interactive_chat(conversation_id: UUID | None = None) -> None:
    """Run interactive chat session.

    Args:
        conversation_id: Optional conversation ID to continue.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    print_chat_header()

    if conversation_id:
        print_info(f"Continuing conversation: {conversation_id}")
        console.print()

    async with DVClient(settings) as client:
        while True:
            try:
                user_input = Prompt.ask("[bold cyan]You[/bold cyan]")

                if user_input.lower() in ("exit", "quit", "q"):
                    break

                if not user_input.strip():
                    continue

                # Validate message length
                if len(user_input) > 10000:
                    print_error("Message too long. Maximum 10000 characters.")
                    continue

                with console.status("[yellow]Thinking...[/yellow]"):
                    response = await client.chat(user_input, conversation_id)

                print_chat_response(response.message, response.tokens_used)
                conversation_id = response.conversation_id

                # Save last conversation ID
                settings.last_conversation_id = str(conversation_id)
                save_config(settings)

            except KeyboardInterrupt:
                console.print("\n[dim]Chat ended.[/dim]")
                break

            except ConnectionError as e:
                print_error(f"Connection lost: {e.cause}")
                print_info("Trying to reconnect on next message...")

            except APIError as e:
                if e.status_code == 429:
                    print_error("Rate limit exceeded. Please wait before sending.")
                else:
                    print_error(f"API error: {e.message}")


@chat_app.callback(invoke_without_command=True)
def chat_main(
    ctx: typer.Context,
    message: Annotated[
        str | None,
        typer.Argument(help="Quick message to send"),
    ] = None,
    continue_chat: Annotated[
        bool,
        typer.Option("--continue", "-C", help="Continue last conversation"),
    ] = False,
    conversation: Annotated[
        str | None,
        typer.Option("-c", "--conversation", help="Conversation ID to continue"),
    ] = None,
    output_json: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON"),
    ] = False,
) -> None:
    """Chat with Digital Valerii.

    Examples:
        dv chat "What's on my calendar?"    # Quick message
        dv chat                              # Interactive mode
        dv chat --continue                   # Continue last conversation
        dv chat -c <uuid>                    # Continue specific conversation
    """
    # If subcommand was invoked, don't run this
    if ctx.invoked_subcommand is not None:
        return

    # Determine conversation ID
    conversation_id: UUID | None = None
    if conversation:
        conversation_id = _validate_uuid(conversation)
    elif continue_chat:
        settings = load_config()
        if settings.last_conversation_id:
            conversation_id = UUID(settings.last_conversation_id)
        else:
            print_info("No previous conversation found.")

    if message:
        # Quick message mode
        new_conversation_id = asyncio.run(
            _send_message(message, conversation_id, output_json)
        )
        # Save last conversation
        if new_conversation_id:
            settings = load_config()
            settings.last_conversation_id = str(new_conversation_id)
            save_config(settings)
    else:
        # Interactive mode
        asyncio.run(_interactive_chat(conversation_id))
