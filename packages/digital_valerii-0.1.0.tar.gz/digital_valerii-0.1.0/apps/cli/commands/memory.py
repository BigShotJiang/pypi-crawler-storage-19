"""Memory commands."""

import asyncio
from typing import Annotated
from uuid import UUID

import typer

from apps.cli.client import APIError, ConnectionError, DVClient
from apps.cli.config import load_config
from apps.cli.display import (
    console,
    print_error,
    print_people_list,
    print_person_detail,
    print_project_detail,
    print_projects_list,
    print_search_results,
)

memory_app = typer.Typer(name="memory", help="Search and explore memories")


def _validate_uuid(value: str) -> UUID:
    """Validate and parse UUID string.

    Args:
        value: UUID string.

    Returns:
        Parsed UUID.

    Raises:
        typer.BadParameter: If invalid UUID.
    """
    try:
        return UUID(value)
    except ValueError:
        raise typer.BadParameter(f"Invalid UUID: {value}") from None


def _get_output_format(json_output: bool) -> str:
    """Get output format based on flags and settings.

    Args:
        json_output: If --json flag was passed.

    Returns:
        Output format string.
    """
    if json_output:
        return "json"
    settings = load_config()
    return settings.output_format


async def _search_memories(query: str, limit: int, output_format: str) -> None:
    """Search memories and display results.

    Args:
        query: Search query.
        limit: Maximum results.
        output_format: Output format.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Searching...[/yellow]"):
                results = await client.search_memories(query, limit)

            print_search_results(results, output_format)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


async def _list_people(
    query: str | None,
    limit: int,
    output_format: str,
) -> None:
    """List people and display results.

    Args:
        query: Optional search query.
        limit: Maximum results.
        output_format: Output format.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Loading...[/yellow]"):
                people = await client.list_people(query, limit)

            print_people_list(people, output_format)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


async def _get_person(person_id: UUID, output_format: str) -> None:
    """Get person details.

    Args:
        person_id: Person UUID.
        output_format: Output format.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Loading...[/yellow]"):
                person = await client.get_person(person_id)

            print_person_detail(person, output_format)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 404:
                print_error(f"Person not found: {person_id}")
            elif e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


async def _list_projects(
    query: str | None,
    status: str | None,
    limit: int,
    output_format: str,
) -> None:
    """List projects and display results.

    Args:
        query: Optional search query.
        status: Optional status filter.
        limit: Maximum results.
        output_format: Output format.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Loading...[/yellow]"):
                projects = await client.list_projects(query, status, limit)

            print_projects_list(projects, output_format)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


async def _get_project(project_id: UUID, output_format: str) -> None:
    """Get project details.

    Args:
        project_id: Project UUID.
        output_format: Output format.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Loading...[/yellow]"):
                project = await client.get_project(project_id)

            print_project_detail(project, output_format)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 404:
                print_error(f"Project not found: {project_id}")
            elif e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


@memory_app.command("search")
def search(
    query: Annotated[str, typer.Argument(help="Search query")],
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 10,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """Search memories by query.

    Examples:
        dv memory search "project alpha"
        dv memory search "meeting" --limit 5
        dv memory search "client" --json
    """
    # Validate query length
    if len(query) > 500:
        print_error("Query too long. Maximum 500 characters.")
        raise typer.Exit(1)

    output_format = _get_output_format(json_output)
    asyncio.run(_search_memories(query, limit, output_format))


@memory_app.command("people")
def people(
    person_id: Annotated[
        str | None, typer.Argument(help="Person ID for details")
    ] = None,
    query: Annotated[
        str | None, typer.Option("--query", "-q", help="Search by name")
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 20,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List people or get person details.

    Examples:
        dv memory people                     # List all
        dv memory people --query "john"      # Search by name
        dv memory people <uuid>              # Get details
    """
    output_format = _get_output_format(json_output)

    if person_id:
        uuid = _validate_uuid(person_id)
        asyncio.run(_get_person(uuid, output_format))
    else:
        asyncio.run(_list_people(query, limit, output_format))


@memory_app.command("projects")
def projects(
    project_id: Annotated[
        str | None, typer.Argument(help="Project ID for details")
    ] = None,
    query: Annotated[
        str | None, typer.Option("--query", "-q", help="Search by name")
    ] = None,
    status: Annotated[
        str | None, typer.Option("--status", "-s", help="Filter by status")
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 20,
    json_output: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
) -> None:
    """List projects or get project details.

    Examples:
        dv memory projects                   # List all
        dv memory projects --status active   # Filter by status
        dv memory projects <uuid>            # Get details
    """
    output_format = _get_output_format(json_output)

    if project_id:
        uuid = _validate_uuid(project_id)
        asyncio.run(_get_project(uuid, output_format))
    else:
        asyncio.run(_list_projects(query, status, limit, output_format))
