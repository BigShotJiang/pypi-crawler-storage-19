"""Rich display helpers for CLI output."""

import json
import os
from typing import TYPE_CHECKING

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

if TYPE_CHECKING:
    from apps.cli.client import (
        MemorySearchResult,
        PersonDetail,
        PersonSummary,
        ProjectDetail,
        ProjectSummary,
    )
    from apps.cli.config import CLISettings

console = Console()

# EU AI Act Article 50 - Transparency Disclosure
AI_DISCLOSURE_TEXT = (
    "[bold blue]DIGITAL VALERII - AI ASSISTANT[/bold blue]\n\n"
    "This is an AI assistant, not a human."
)


def print_ai_disclosure() -> None:
    """Display AI disclosure banner per EU AI Act Art.50.

    Informs users they are interacting with an AI system.
    Can be disabled via DV_DISABLE_AI_DISCLOSURE=1 for automation.
    """
    if os.environ.get("DV_DISABLE_AI_DISCLOSURE", "").lower() in ("1", "true", "yes"):
        return

    console.print(
        Panel(
            AI_DISCLOSURE_TEXT,
            title="🤖 AI System",
            border_style="blue",
            padding=(0, 2),
        )
    )
    console.print()


def print_error(message: str) -> None:
    """Print error message in red.

    Args:
        message: Error message.
    """
    console.print(f"[bold red]Error:[/bold red] {message}")


def print_warning(message: str) -> None:
    """Print warning message in yellow.

    Args:
        message: Warning message.
    """
    console.print(f"[yellow]Warning:[/yellow] {message}")


def print_success(message: str) -> None:
    """Print success message in green.

    Args:
        message: Success message.
    """
    console.print(f"[green]{message}[/green]")


def print_info(message: str) -> None:
    """Print info message in dim style.

    Args:
        message: Info message.
    """
    console.print(f"[dim]{message}[/dim]")


def print_config(settings: "CLISettings") -> None:
    """Display configuration settings.

    Args:
        settings: CLISettings to display.
    """
    table = Table(title="Configuration", show_header=False)
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("API URL", settings.api_url)
    table.add_row("API Key", settings.mask_api_key())
    table.add_row("Default Model", settings.default_model)
    table.add_row("Output Format", settings.output_format)

    console.print(table)


def print_chat_response(message: str, tokens_used: int | None = None) -> None:
    """Display chat response with markdown formatting.

    Args:
        message: Agent response message.
        tokens_used: Optional token count.
    """
    console.print("\n[bold green]Valerii[/bold green]")
    console.print(Markdown(message))

    if tokens_used:
        console.print(f"\n[dim]Tokens used: {tokens_used}[/dim]")
    console.print()


def print_chat_header() -> None:
    """Print interactive chat header (AI disclosure shown by main)."""
    console.print(
        Panel.fit(
            "[bold]Chat Session[/bold]\n" "[dim]Type 'exit' or Ctrl+C to quit[/dim]",
            border_style="cyan",
        )
    )
    console.print()


def print_search_results(
    results: list["MemorySearchResult"],
    output_format: str = "rich",
) -> None:
    """Display memory search results.

    Args:
        results: Search results to display.
        output_format: Output format (rich, plain, json).
    """
    if output_format == "json":
        console.print(
            json.dumps([r.model_dump(mode="json") for r in results], indent=2)
        )
        return

    if not results:
        print_info("No memories found.")
        return

    if output_format == "plain":
        for r in results:
            title = r.title or "(Untitled)"
            date = r.occurred_at.strftime("%Y-%m-%d")
            console.print(f"{r.event_type}: {title} ({date}) - Score: {r.score:.2f}")
        return

    table = Table(title="Memory Search Results")
    table.add_column("Type", style="cyan")
    table.add_column("Title", style="green")
    table.add_column("Date", style="yellow")
    table.add_column("Score", style="magenta", justify="right")

    for result in results:
        table.add_row(
            result.event_type,
            result.title or "[dim]Untitled[/dim]",
            result.occurred_at.strftime("%Y-%m-%d"),
            f"{result.score:.2f}",
        )

    console.print(table)


def print_people_list(
    people: list["PersonSummary"],
    output_format: str = "rich",
) -> None:
    """Display list of people.

    Args:
        people: People to display.
        output_format: Output format (rich, plain, json).
    """
    if output_format == "json":
        console.print(json.dumps([p.model_dump(mode="json") for p in people], indent=2))
        return

    if not people:
        print_info("No people found.")
        return

    if output_format == "plain":
        for p in people:
            company = p.company or "-"
            relationship = p.relationship_type or "-"
            console.print(f"{p.name} | {company} | {relationship}")
        return

    table = Table(title="People")
    table.add_column("Name", style="green")
    table.add_column("Company", style="cyan")
    table.add_column("Relationship", style="yellow")
    table.add_column("Email", style="dim")

    for person in people:
        table.add_row(
            person.name,
            person.company or "-",
            person.relationship_type or "-",
            person.email or "-",
        )

    console.print(table)


def print_person_detail(
    person: "PersonDetail",
    output_format: str = "rich",
) -> None:
    """Display person details.

    Args:
        person: Person to display.
        output_format: Output format (rich, plain, json).
    """
    if output_format == "json":
        console.print(json.dumps(person.model_dump(mode="json"), indent=2))
        return

    if output_format == "plain":
        console.print(f"Name: {person.name}")
        console.print(f"Email: {person.email or '-'}")
        console.print(f"Company: {person.company or '-'}")
        console.print(f"Relationship: {person.relationship_type or '-'}")
        console.print(f"Interactions: {person.interaction_count}")
        if person.last_interaction:
            console.print(
                f"Last Interaction: {person.last_interaction.strftime('%Y-%m-%d')}"
            )
        if person.notes:
            console.print(f"Notes: {person.notes}")
        return

    table = Table(title=f"Person: {person.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Name", person.name)
    table.add_row("Email", person.email or "-")
    table.add_row("Company", person.company or "-")
    table.add_row("Relationship", person.relationship_type or "-")
    table.add_row("Interactions", str(person.interaction_count))
    if person.last_interaction:
        table.add_row(
            "Last Interaction", person.last_interaction.strftime("%Y-%m-%d %H:%M")
        )
    if person.notes:
        table.add_row("Notes", person.notes)

    console.print(table)


def print_projects_list(
    projects: list["ProjectSummary"],
    output_format: str = "rich",
) -> None:
    """Display list of projects.

    Args:
        projects: Projects to display.
        output_format: Output format (rich, plain, json).
    """
    if output_format == "json":
        console.print(
            json.dumps([p.model_dump(mode="json") for p in projects], indent=2)
        )
        return

    if not projects:
        print_info("No projects found.")
        return

    if output_format == "plain":
        for p in projects:
            desc = (p.description or "-")[:40]
            console.print(f"{p.name} | {p.status} | {desc}")
        return

    table = Table(title="Projects")
    table.add_column("Name", style="green")
    table.add_column("Status", style="cyan")
    table.add_column("Description", style="dim", max_width=40)

    for project in projects:
        status_style = "green" if project.status == "active" else "yellow"
        table.add_row(
            project.name,
            f"[{status_style}]{project.status}[/{status_style}]",
            (project.description or "-")[:40],
        )

    console.print(table)


def print_project_detail(
    project: "ProjectDetail",
    output_format: str = "rich",
) -> None:
    """Display project details.

    Args:
        project: Project to display.
        output_format: Output format (rich, plain, json).
    """
    if output_format == "json":
        console.print(json.dumps(project.model_dump(mode="json"), indent=2))
        return

    if output_format == "plain":
        console.print(f"Name: {project.name}")
        console.print(f"Status: {project.status}")
        console.print(f"Description: {project.description or '-'}")
        console.print(f"Created: {project.created_at.strftime('%Y-%m-%d')}")
        console.print(f"Updated: {project.updated_at.strftime('%Y-%m-%d')}")
        if project.people:
            console.print(f"Team: {', '.join(p.name for p in project.people)}")
        return

    # Main project info
    table = Table(title=f"Project: {project.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="green")

    status_style = "green" if project.status == "active" else "yellow"
    table.add_row("Name", project.name)
    table.add_row("Status", f"[{status_style}]{project.status}[/{status_style}]")
    table.add_row("Description", project.description or "-")
    table.add_row("Created", project.created_at.strftime("%Y-%m-%d %H:%M"))
    table.add_row("Updated", project.updated_at.strftime("%Y-%m-%d %H:%M"))

    console.print(table)

    # Team members
    if project.people:
        console.print()
        team_table = Table(title="Team Members")
        team_table.add_column("Name", style="green")
        team_table.add_column("Role", style="cyan")
        team_table.add_column("Email", style="dim")

        for person in project.people:
            team_table.add_row(
                person.name,
                person.relationship_type or "-",
                person.email or "-",
            )

        console.print(team_table)
