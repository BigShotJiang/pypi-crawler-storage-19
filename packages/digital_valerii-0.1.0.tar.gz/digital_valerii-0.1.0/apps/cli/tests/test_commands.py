"""Tests for CLI commands."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from typer.testing import CliRunner

from apps.cli.main import app


@pytest.fixture
def runner() -> CliRunner:
    """Create CLI test runner."""
    return CliRunner()


@pytest.fixture
def mock_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Mock config directory."""
    from apps.cli import config as config_module

    config_dir = tmp_path / ".config" / "digital-valerii"
    config_dir.mkdir(parents=True)
    config_file = config_dir / "config.json"

    # Write default config with API key
    config_file.write_text(
        json.dumps(
            {
                "api_url": "http://localhost:8000",
                "api_key": "test-api-key",
                "default_model": "default",
                "output_format": "rich",
            }
        )
    )

    monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

    return config_file


class TestVersionCommand:
    """Tests for version command."""

    def test_version(self, runner: CliRunner) -> None:
        """Test version command output."""
        result = runner.invoke(app, ["version"])

        assert result.exit_code == 0
        assert "Digital Valerii" in result.output
        assert "0.1.0" in result.output


class TestConfigCommands:
    """Tests for config commands."""

    def test_config_show(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test config show command."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        result = runner.invoke(app, ["config", "show"])

        assert result.exit_code == 0
        assert "localhost:8000" in result.output
        # API key should be masked
        assert "****" in result.output

    def test_config_set(
        self,
        runner: CliRunner,
        mock_config: Path,
        monkeypatch: pytest.MonkeyPatch,  # noqa: ARG002
    ) -> None:
        """Test config set command."""
        _ = monkeypatch  # Used via pytest fixture injection
        result = runner.invoke(app, ["config", "set", "api_url", "http://new-api.com"])

        assert result.exit_code == 0
        assert "new-api.com" in result.output

        # Verify file was updated
        data = json.loads(mock_config.read_text())
        assert data["api_url"] == "http://new-api.com"

    def test_config_set_invalid_key(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test config set with invalid key."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        result = runner.invoke(app, ["config", "set", "invalid_key", "value"])

        assert result.exit_code == 1
        assert "Invalid config key" in result.output

    def test_config_path(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test config path command."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        # Disable AI disclosure banner for cleaner test output
        monkeypatch.setenv("DV_DISABLE_AI_DISCLOSURE", "1")
        result = runner.invoke(app, ["config", "path"])

        assert result.exit_code == 0
        # Remove newlines before checking - Rich may wrap long paths
        output_no_wrap = result.output.replace("\n", "")
        assert "config.json" in output_no_wrap


class TestQuickQuery:
    """Tests for quick query mode."""

    def test_quick_query_no_api_key(
        self, runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test quick query without API key."""
        from apps.cli import config as config_module

        config_dir = tmp_path / ".config" / "digital-valerii"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({"api_key": ""}))

        monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        result = runner.invoke(app, ["ask", "Hello"])

        assert result.exit_code == 1
        assert "API key not configured" in result.output

    def test_quick_query_success(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test successful quick query."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        conversation_id = uuid4()
        mock_response = MagicMock()
        mock_response.message = "Hello! How can I help you?"
        mock_response.conversation_id = conversation_id
        mock_response.tokens_used = 50

        with patch("apps.cli.main.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.chat.return_value = mock_response
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["ask", "Hello world"])

        assert result.exit_code == 0
        assert "Hello! How can I help you?" in result.output

    def test_quick_query_connection_error(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test quick query with connection error."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        from apps.cli.client import ConnectionError

        with patch("apps.cli.main.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.chat.side_effect = ConnectionError(
                "http://localhost:8000", "Connection refused"
            )
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["ask", "Hello"])

        assert result.exit_code == 1
        assert "Cannot connect" in result.output


class TestChatCommands:
    """Tests for chat commands."""

    def test_chat_no_api_key(
        self, runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test chat without API key."""
        from apps.cli import config as config_module

        config_dir = tmp_path / ".config" / "digital-valerii"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({"api_key": ""}))

        monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        result = runner.invoke(app, ["chat", "Hello"])

        assert result.exit_code == 1
        assert "API key not configured" in result.output

    def test_chat_quick_message(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test chat with quick message."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        conversation_id = uuid4()
        mock_response = MagicMock()
        mock_response.message = "Quick response"
        mock_response.conversation_id = conversation_id
        mock_response.tokens_used = None

        with patch("apps.cli.commands.chat.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.chat.return_value = mock_response
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["chat", "Quick question"])

        assert result.exit_code == 0
        assert "Quick response" in result.output

    def test_chat_message_too_long(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test chat rejects messages over 10k chars."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        long_message = "x" * 10001

        result = runner.invoke(app, ["chat", long_message])

        assert result.exit_code == 1
        assert "too long" in result.output


class TestMemoryCommands:
    """Tests for memory commands."""

    def test_memory_search_no_api_key(
        self, runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test memory search without API key."""
        from apps.cli import config as config_module

        config_dir = tmp_path / ".config" / "digital-valerii"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "config.json"
        config_file.write_text(json.dumps({"api_key": ""}))

        monkeypatch.setattr(config_module, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        result = runner.invoke(app, ["memory", "search", "test"])

        assert result.exit_code == 1
        assert "API key not configured" in result.output

    def test_memory_search_success(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test successful memory search."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        from datetime import UTC, datetime

        mock_results = [
            MagicMock(
                event_id=uuid4(),
                event_type="meeting",
                title="Team standup",
                summary="Daily sync",
                occurred_at=datetime(2025, 1, 15, 9, 0, tzinfo=UTC),
                score=0.95,
                model_dump=lambda _mode: {
                    "event_id": str(uuid4()),
                    "event_type": "meeting",
                    "title": "Team standup",
                    "score": 0.95,
                },
            )
        ]

        with patch("apps.cli.commands.memory.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.search_memories.return_value = mock_results
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["memory", "search", "standup"])

        assert result.exit_code == 0

    def test_memory_search_query_too_long(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test memory search with query too long."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        long_query = "x" * 600

        result = runner.invoke(app, ["memory", "search", long_query])

        assert result.exit_code == 1
        assert "Query too long" in result.output

    def test_memory_people_list(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test listing people."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        from apps.cli.client import PersonSummary

        mock_people = [
            PersonSummary(
                id=uuid4(),
                name="John Doe",
                email="john@example.com",
                company="Acme",
                relationship_type="client",
            )
        ]

        with patch("apps.cli.commands.memory.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.list_people.return_value = mock_people
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["memory", "people"])

        assert result.exit_code == 0

    def test_memory_projects_list(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test listing projects."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        from apps.cli.client import ProjectSummary

        mock_projects = [
            ProjectSummary(
                id=uuid4(),
                name="Project Alpha",
                status="active",
                description="Main project",
            )
        ]

        with patch("apps.cli.commands.memory.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.list_projects.return_value = mock_projects
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["memory", "projects"])

        assert result.exit_code == 0


class TestStatusCommand:
    """Tests for status command."""

    def test_status_healthy(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test status when API is healthy."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        with patch("apps.cli.main.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.health_check.return_value = True
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "healthy" in result.output

    def test_status_unhealthy(  # noqa: ARG002
        self, runner: CliRunner, mock_config: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test status when API is not reachable."""
        _ = mock_config, monkeypatch  # Used via pytest fixture injection
        with patch("apps.cli.main.DVClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.health_check.return_value = False
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client_class.return_value = mock_client

            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "not reachable" in result.output
