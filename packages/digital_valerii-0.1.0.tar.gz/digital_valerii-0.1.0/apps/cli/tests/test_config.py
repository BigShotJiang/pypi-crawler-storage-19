"""Tests for CLI configuration."""

import json
from pathlib import Path

import pytest

from apps.cli.config import (
    CLISettings,
    ensure_config_dir,
    get_config_path,
    load_config,
    save_config,
    update_config,
)


class TestCLISettings:
    """Tests for CLISettings model."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        settings = CLISettings()

        assert settings.api_url == "http://localhost:8000"
        assert settings.api_key == ""
        assert settings.default_model == "default"
        assert settings.output_format == "rich"
        assert settings.last_conversation_id is None

    def test_extra_forbid(self) -> None:
        """Test extra fields are forbidden."""
        with pytest.raises(ValueError, match="Extra inputs are not permitted"):
            CLISettings(unknown_field="value")

    def test_mask_api_key_empty(self) -> None:
        """Test masking empty API key."""
        settings = CLISettings(api_key="")
        assert settings.mask_api_key() == "(not set)"

    def test_mask_api_key_short(self) -> None:
        """Test masking short API key."""
        settings = CLISettings(api_key="abc")
        assert settings.mask_api_key() == "****"

    def test_mask_api_key_long(self) -> None:
        """Test masking long API key."""
        settings = CLISettings(api_key="secret-api-key-12345")
        assert settings.mask_api_key() == "****2345"

    def test_output_format_validation(self) -> None:
        """Test output format is validated."""
        with pytest.raises(ValueError):
            CLISettings(output_format="invalid")


class TestConfigFile:
    """Tests for config file operations."""

    @pytest.fixture
    def temp_config_dir(self, tmp_path: Path) -> Path:
        """Create temporary config directory."""
        config_dir = tmp_path / ".config" / "digital-valerii"
        return config_dir

    def test_ensure_config_dir_creates_directory(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test config directory is created."""
        from apps.cli import config as config_module

        monkeypatch.setattr(config_module, "CONFIG_DIR", temp_config_dir)

        ensure_config_dir()

        assert temp_config_dir.exists()
        # Check permissions (0700)
        assert oct(temp_config_dir.stat().st_mode)[-3:] == "700"

    def test_load_config_default_when_missing(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test loading config when file doesn't exist returns defaults."""
        from apps.cli import config as config_module

        config_file = temp_config_dir / "config.json"
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        settings = load_config()

        assert settings.api_url == "http://localhost:8000"
        assert settings.api_key == ""

    def test_load_config_from_file(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test loading config from existing file."""
        from apps.cli import config as config_module

        temp_config_dir.mkdir(parents=True, exist_ok=True)
        config_file = temp_config_dir / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "api_url": "http://example.com",
                    "api_key": "test-key",
                    "default_model": "custom",
                    "output_format": "json",
                }
            )
        )
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        settings = load_config()

        assert settings.api_url == "http://example.com"
        assert settings.api_key == "test-key"
        assert settings.default_model == "custom"
        assert settings.output_format == "json"

    def test_load_config_invalid_json(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test loading config with invalid JSON returns defaults."""
        from apps.cli import config as config_module

        temp_config_dir.mkdir(parents=True, exist_ok=True)
        config_file = temp_config_dir / "config.json"
        config_file.write_text("not valid json")
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        settings = load_config()

        assert settings.api_url == "http://localhost:8000"

    def test_save_config_creates_file(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test saving config creates file with secure permissions."""
        from apps.cli import config as config_module

        config_file = temp_config_dir / "config.json"
        monkeypatch.setattr(config_module, "CONFIG_DIR", temp_config_dir)
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        settings = CLISettings(api_key="secret")
        save_config(settings)

        assert config_file.exists()
        # Check file permissions (0600)
        mode = config_file.stat().st_mode & 0o777
        assert mode == 0o600

        # Verify content
        data = json.loads(config_file.read_text())
        assert data["api_key"] == "secret"

    def test_update_config_valid_key(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test updating a valid config key."""
        from apps.cli import config as config_module

        config_file = temp_config_dir / "config.json"
        monkeypatch.setattr(config_module, "CONFIG_DIR", temp_config_dir)
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        settings = update_config("api_url", "http://new-url.com")

        assert settings.api_url == "http://new-url.com"

    def test_update_config_invalid_key(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test updating an invalid config key raises error."""
        from apps.cli import config as config_module

        config_file = temp_config_dir / "config.json"
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        with pytest.raises(ValueError, match="Invalid config key"):
            update_config("invalid_key", "value")

    def test_update_config_invalid_output_format(
        self, temp_config_dir: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test updating output_format with invalid value raises error."""
        from apps.cli import config as config_module

        config_file = temp_config_dir / "config.json"
        monkeypatch.setattr(config_module, "CONFIG_FILE", config_file)

        with pytest.raises(ValueError, match="output_format must be one of"):
            update_config("output_format", "invalid")

    def test_get_config_path(self) -> None:
        """Test getting config file path."""
        path = get_config_path()

        assert path.name == "config.json"
        assert "digital-valerii" in str(path)
