"""Tests for API client."""

from unittest.mock import MagicMock, patch
from uuid import uuid4

import httpx
import pytest

from apps.cli.client import (
    APIError,
    ConnectionError,
    DVClient,
)
from apps.cli.config import CLISettings


class TestDVClient:
    """Tests for DVClient."""

    @pytest.fixture
    def settings(self) -> CLISettings:
        """Create test settings."""
        return CLISettings(
            api_url="http://localhost:8000",
            api_key="test-api-key",
        )

    @pytest.fixture
    def client(self, settings: CLISettings) -> DVClient:
        """Create test client."""
        return DVClient(settings)

    def test_init(self, settings: CLISettings) -> None:
        """Test client initialization."""
        client = DVClient(settings)

        assert client.base_url == "http://localhost:8000"
        assert client.api_key == "test-api-key"

    def test_init_strips_trailing_slash(self) -> None:
        """Test client strips trailing slash from URL."""
        settings = CLISettings(api_url="http://localhost:8000/")
        client = DVClient(settings)

        assert client.base_url == "http://localhost:8000"

    def test_get_headers_with_api_key(self, client: DVClient) -> None:
        """Test headers include API key."""
        headers = client._get_headers()

        assert headers["X-API-Key"] == "test-api-key"
        assert headers["Content-Type"] == "application/json"

    def test_get_headers_without_api_key(self) -> None:
        """Test headers without API key."""
        settings = CLISettings(api_key="")
        client = DVClient(settings)

        headers = client._get_headers()

        assert "X-API-Key" not in headers

    @pytest.mark.asyncio
    async def test_context_manager(self, settings: CLISettings) -> None:
        """Test async context manager."""
        async with DVClient(settings) as client:
            assert client._client is not None

        assert client._client is None

    @pytest.mark.asyncio
    async def test_request_not_initialized(self, client: DVClient) -> None:
        """Test request without context manager raises error."""
        with pytest.raises(RuntimeError, match="Client not initialized"):
            await client._request("GET", "/test")

    @pytest.mark.asyncio
    async def test_chat_success(self, settings: CLISettings) -> None:
        """Test successful chat request."""
        conversation_id = uuid4()
        mock_response = {
            "message": "Hello from Valerii",
            "conversation_id": str(conversation_id),
            "created_at": "2025-01-01T00:00:00Z",
            "tokens_used": 100,
        }

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                response = await client.chat("Hello")

        assert response.message == "Hello from Valerii"
        assert response.conversation_id == conversation_id
        assert response.tokens_used == 100

    @pytest.mark.asyncio
    async def test_chat_with_conversation_id(self, settings: CLISettings) -> None:
        """Test chat with existing conversation ID."""
        conversation_id = uuid4()
        mock_response = {
            "message": "Continued response",
            "conversation_id": str(conversation_id),
            "created_at": "2025-01-01T00:00:00Z",
        }

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                await client.chat("Continue", conversation_id)

            # Verify conversation_id was included in payload
            call_args = mock_request.call_args
            assert "json" in call_args.kwargs
            assert call_args.kwargs["json"]["conversation_id"] == str(conversation_id)

    @pytest.mark.asyncio
    async def test_connection_error(self, settings: CLISettings) -> None:
        """Test connection error handling."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.side_effect = httpx.ConnectError("Connection refused")

            async with DVClient(settings) as client:
                with pytest.raises(ConnectionError) as exc_info:
                    await client.chat("Hello")

        assert "localhost:8000" in exc_info.value.url

    @pytest.mark.asyncio
    async def test_timeout_error(self, settings: CLISettings) -> None:
        """Test timeout error handling."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.side_effect = httpx.TimeoutException("Timeout")

            async with DVClient(settings) as client:
                with pytest.raises(ConnectionError) as exc_info:
                    await client.chat("Hello")

        assert "timed out" in exc_info.value.cause

    @pytest.mark.asyncio
    async def test_api_error_401(self, settings: CLISettings) -> None:
        """Test 401 API error handling."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=401,
                text="Unauthorized",
                json=lambda: {"detail": "Unauthorized"},
            )

            async with DVClient(settings) as client:
                with pytest.raises(APIError) as exc_info:
                    await client.chat("Hello")

        assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_search_memories(self, settings: CLISettings) -> None:
        """Test memory search."""
        event_id = uuid4()
        mock_response = [
            {
                "event_id": str(event_id),
                "event_type": "meeting",
                "title": "Team standup",
                "summary": "Daily sync",
                "occurred_at": "2025-01-01T09:00:00Z",
                "score": 0.95,
            }
        ]

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                results = await client.search_memories("standup", limit=5)

        assert len(results) == 1
        assert results[0].event_id == event_id
        assert results[0].event_type == "meeting"
        assert results[0].score == 0.95

    @pytest.mark.asyncio
    async def test_list_people(self, settings: CLISettings) -> None:
        """Test listing people."""
        person_id = uuid4()
        mock_response = [
            {
                "id": str(person_id),
                "name": "John Doe",
                "email": "john@example.com",
                "company": "Acme Inc",
                "relationship_type": "client",
            }
        ]

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                people = await client.list_people(query="john")

        assert len(people) == 1
        assert people[0].name == "John Doe"
        assert people[0].company == "Acme Inc"

    @pytest.mark.asyncio
    async def test_get_person(self, settings: CLISettings) -> None:
        """Test getting person details."""
        person_id = uuid4()
        mock_response = {
            "id": str(person_id),
            "name": "John Doe",
            "email": "john@example.com",
            "company": "Acme Inc",
            "relationship_type": "client",
            "notes": "Important client",
            "last_interaction": "2025-01-01T10:00:00Z",
            "interaction_count": 5,
        }

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                person = await client.get_person(person_id)

        assert person.name == "John Doe"
        assert person.interaction_count == 5
        assert person.notes == "Important client"

    @pytest.mark.asyncio
    async def test_list_projects(self, settings: CLISettings) -> None:
        """Test listing projects."""
        project_id = uuid4()
        mock_response = [
            {
                "id": str(project_id),
                "name": "Project Alpha",
                "status": "active",
                "description": "Main project",
            }
        ]

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                projects = await client.list_projects(status="active")

        assert len(projects) == 1
        assert projects[0].name == "Project Alpha"
        assert projects[0].status == "active"

    @pytest.mark.asyncio
    async def test_get_project(self, settings: CLISettings) -> None:
        """Test getting project details."""
        project_id = uuid4()
        person_id = uuid4()
        mock_response = {
            "id": str(project_id),
            "name": "Project Alpha",
            "status": "active",
            "description": "Main project",
            "created_at": "2025-01-01T00:00:00Z",
            "updated_at": "2025-01-02T00:00:00Z",
            "people": [
                {
                    "id": str(person_id),
                    "name": "John Doe",
                    "email": "john@example.com",
                    "company": None,
                    "relationship_type": "developer",
                }
            ],
        }

        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=200,
                json=lambda: mock_response,
            )

            async with DVClient(settings) as client:
                project = await client.get_project(project_id)

        assert project.name == "Project Alpha"
        assert len(project.people) == 1
        assert project.people[0].name == "John Doe"

    @pytest.mark.asyncio
    async def test_health_check_success(self, settings: CLISettings) -> None:
        """Test successful health check."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(status_code=200)

            async with DVClient(settings) as client:
                is_healthy = await client.health_check()

        assert is_healthy is True

    @pytest.mark.asyncio
    async def test_health_check_failure(self, settings: CLISettings) -> None:
        """Test failed health check."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.side_effect = httpx.ConnectError("Connection refused")

            async with DVClient(settings) as client:
                is_healthy = await client.health_check()

        assert is_healthy is False

    def test_http_warning_for_remote_host(self, capsys: pytest.CaptureFixture) -> None:
        """Test warning for HTTP to remote host."""
        settings = CLISettings(
            api_url="http://remote-server.com",
            api_key="secret-key",
        )
        DVClient(settings)
        captured = capsys.readouterr()
        assert "Warning" in captured.err
        assert "unencrypted HTTP" in captured.err

    def test_no_warning_for_localhost(self, capsys: pytest.CaptureFixture) -> None:
        """Test no warning for localhost HTTP."""
        settings = CLISettings(
            api_url="http://localhost:8000",
            api_key="secret-key",
        )
        DVClient(settings)
        captured = capsys.readouterr()
        assert "Warning" not in captured.err

    def test_no_warning_for_127_0_0_1(self, capsys: pytest.CaptureFixture) -> None:
        """Test no warning for 127.0.0.1 HTTP."""
        settings = CLISettings(
            api_url="http://127.0.0.1:8000",
            api_key="secret-key",
        )
        DVClient(settings)
        captured = capsys.readouterr()
        assert "Warning" not in captured.err

    def test_no_warning_for_https(self, capsys: pytest.CaptureFixture) -> None:
        """Test no warning for HTTPS to remote host."""
        settings = CLISettings(
            api_url="https://remote-server.com",
            api_key="secret-key",
        )
        DVClient(settings)
        captured = capsys.readouterr()
        assert "Warning" not in captured.err

    def test_no_warning_without_api_key(self, capsys: pytest.CaptureFixture) -> None:
        """Test no warning when no API key is set."""
        settings = CLISettings(
            api_url="http://remote-server.com",
            api_key="",
        )
        DVClient(settings)
        captured = capsys.readouterr()
        assert "Warning" not in captured.err

    @pytest.mark.asyncio
    async def test_api_error_500_hides_details(self, settings: CLISettings) -> None:
        """Test 500 errors hide internal details."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=500,
                text="Internal database connection failed at line 42",
                json=lambda: {"detail": "PostgreSQL error: connection refused"},
            )

            async with DVClient(settings) as client:
                with pytest.raises(APIError) as exc_info:
                    await client.chat("Hello")

        assert exc_info.value.status_code == 500
        assert exc_info.value.message == "Internal server error"
        assert "PostgreSQL" not in exc_info.value.message
        assert "database" not in exc_info.value.message

    @pytest.mark.asyncio
    async def test_api_error_4xx_shows_details(self, settings: CLISettings) -> None:
        """Test 4xx errors show API detail."""
        with patch("httpx.AsyncClient.request") as mock_request:
            mock_request.return_value = MagicMock(
                status_code=400,
                text="Bad Request",
                json=lambda: {"detail": "Invalid message format"},
            )

            async with DVClient(settings) as client:
                with pytest.raises(APIError) as exc_info:
                    await client.chat("Hello")

        assert exc_info.value.status_code == 400
        assert exc_info.value.message == "Invalid message format"
