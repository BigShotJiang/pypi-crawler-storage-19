"""Tests for display helpers."""

import json
from datetime import UTC, datetime
from uuid import uuid4

import pytest

from apps.cli.client import (
    MemorySearchResult,
    PersonDetail,
    PersonSummary,
    ProjectDetail,
    ProjectSummary,
)
from apps.cli.config import CLISettings
from apps.cli.display import (
    print_config,
    print_people_list,
    print_person_detail,
    print_project_detail,
    print_projects_list,
    print_search_results,
)


class TestPrintConfig:
    """Tests for print_config."""

    def test_print_config_shows_masked_key(self, capsys: pytest.CaptureFixture) -> None:
        """Test config display shows masked API key."""
        settings = CLISettings(
            api_url="http://localhost:8000",
            api_key="secret-api-key-12345",
        )

        print_config(settings)

        captured = capsys.readouterr()
        assert "localhost:8000" in captured.out
        assert "****2345" in captured.out
        assert "secret-api-key-12345" not in captured.out


class TestPrintSearchResults:
    """Tests for print_search_results."""

    @pytest.fixture
    def sample_results(self) -> list[MemorySearchResult]:
        """Create sample search results."""
        return [
            MemorySearchResult(
                event_id=uuid4(),
                event_type="meeting",
                title="Team standup",
                summary="Daily sync",
                occurred_at=datetime(2025, 1, 15, 9, 0, tzinfo=UTC),
                score=0.95,
            ),
            MemorySearchResult(
                event_id=uuid4(),
                event_type="email",
                title=None,
                summary="Follow up",
                occurred_at=datetime(2025, 1, 14, 14, 30, tzinfo=UTC),
                score=0.85,
            ),
        ]

    def test_print_search_results_json(
        self, sample_results: list[MemorySearchResult], capsys: pytest.CaptureFixture
    ) -> None:
        """Test JSON output format."""
        print_search_results(sample_results, output_format="json")

        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert len(data) == 2
        assert data[0]["event_type"] == "meeting"
        assert data[0]["title"] == "Team standup"

    def test_print_search_results_plain(
        self, sample_results: list[MemorySearchResult], capsys: pytest.CaptureFixture
    ) -> None:
        """Test plain output format."""
        print_search_results(sample_results, output_format="plain")

        captured = capsys.readouterr()
        assert "meeting" in captured.out
        assert "Team standup" in captured.out
        assert "0.95" in captured.out

    def test_print_search_results_empty(self, capsys: pytest.CaptureFixture) -> None:
        """Test empty results message."""
        print_search_results([], output_format="rich")

        captured = capsys.readouterr()
        assert "No memories found" in captured.out


class TestPrintPeopleList:
    """Tests for print_people_list."""

    @pytest.fixture
    def sample_people(self) -> list[PersonSummary]:
        """Create sample people list."""
        return [
            PersonSummary(
                id=uuid4(),
                name="John Doe",
                email="john@example.com",
                company="Acme Inc",
                relationship_type="client",
            ),
            PersonSummary(
                id=uuid4(),
                name="Jane Smith",
                email=None,
                company=None,
                relationship_type="colleague",
            ),
        ]

    def test_print_people_list_json(
        self, sample_people: list[PersonSummary], capsys: pytest.CaptureFixture
    ) -> None:
        """Test JSON output format."""
        print_people_list(sample_people, output_format="json")

        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert len(data) == 2
        assert data[0]["name"] == "John Doe"

    def test_print_people_list_plain(
        self, sample_people: list[PersonSummary], capsys: pytest.CaptureFixture
    ) -> None:
        """Test plain output format."""
        print_people_list(sample_people, output_format="plain")

        captured = capsys.readouterr()
        assert "John Doe" in captured.out
        assert "Acme Inc" in captured.out

    def test_print_people_list_empty(self, capsys: pytest.CaptureFixture) -> None:
        """Test empty people list."""
        print_people_list([], output_format="rich")

        captured = capsys.readouterr()
        assert "No people found" in captured.out


class TestPrintPersonDetail:
    """Tests for print_person_detail."""

    @pytest.fixture
    def sample_person(self) -> PersonDetail:
        """Create sample person detail."""
        return PersonDetail(
            id=uuid4(),
            name="John Doe",
            email="john@example.com",
            company="Acme Inc",
            relationship_type="client",
            notes="VIP client",
            last_interaction=datetime(2025, 1, 15, 10, 0, tzinfo=UTC),
            interaction_count=5,
        )

    def test_print_person_detail_json(
        self, sample_person: PersonDetail, capsys: pytest.CaptureFixture
    ) -> None:
        """Test JSON output format."""
        print_person_detail(sample_person, output_format="json")

        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["name"] == "John Doe"
        assert data["interaction_count"] == 5

    def test_print_person_detail_plain(
        self, sample_person: PersonDetail, capsys: pytest.CaptureFixture
    ) -> None:
        """Test plain output format."""
        print_person_detail(sample_person, output_format="plain")

        captured = capsys.readouterr()
        assert "Name: John Doe" in captured.out
        assert "Interactions: 5" in captured.out
        assert "VIP client" in captured.out


class TestPrintProjectsList:
    """Tests for print_projects_list."""

    @pytest.fixture
    def sample_projects(self) -> list[ProjectSummary]:
        """Create sample projects list."""
        return [
            ProjectSummary(
                id=uuid4(),
                name="Project Alpha",
                status="active",
                description="Main development project",
            ),
            ProjectSummary(
                id=uuid4(),
                name="Project Beta",
                status="completed",
                description=None,
            ),
        ]

    def test_print_projects_list_json(
        self, sample_projects: list[ProjectSummary], capsys: pytest.CaptureFixture
    ) -> None:
        """Test JSON output format."""
        print_projects_list(sample_projects, output_format="json")

        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert len(data) == 2
        assert data[0]["name"] == "Project Alpha"

    def test_print_projects_list_plain(
        self, sample_projects: list[ProjectSummary], capsys: pytest.CaptureFixture
    ) -> None:
        """Test plain output format."""
        print_projects_list(sample_projects, output_format="plain")

        captured = capsys.readouterr()
        assert "Project Alpha" in captured.out
        assert "active" in captured.out

    def test_print_projects_list_empty(self, capsys: pytest.CaptureFixture) -> None:
        """Test empty projects list."""
        print_projects_list([], output_format="rich")

        captured = capsys.readouterr()
        assert "No projects found" in captured.out


class TestPrintProjectDetail:
    """Tests for print_project_detail."""

    @pytest.fixture
    def sample_project(self) -> ProjectDetail:
        """Create sample project detail."""
        return ProjectDetail(
            id=uuid4(),
            name="Project Alpha",
            status="active",
            description="Main development project",
            created_at=datetime(2025, 1, 1, 0, 0, tzinfo=UTC),
            updated_at=datetime(2025, 1, 15, 12, 0, tzinfo=UTC),
            people=[
                PersonSummary(
                    id=uuid4(),
                    name="John Doe",
                    email="john@example.com",
                    company=None,
                    relationship_type="developer",
                )
            ],
        )

    def test_print_project_detail_json(
        self, sample_project: ProjectDetail, capsys: pytest.CaptureFixture
    ) -> None:
        """Test JSON output format."""
        print_project_detail(sample_project, output_format="json")

        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["name"] == "Project Alpha"
        assert len(data["people"]) == 1

    def test_print_project_detail_plain(
        self, sample_project: ProjectDetail, capsys: pytest.CaptureFixture
    ) -> None:
        """Test plain output format."""
        print_project_detail(sample_project, output_format="plain")

        captured = capsys.readouterr()
        assert "Name: Project Alpha" in captured.out
        assert "Status: active" in captured.out
        assert "John Doe" in captured.out
