"""Tests for AI disclosure (EU AI Act Art.50 compliance)."""

import os
from io import StringIO
from unittest.mock import patch

import pytest
from rich.console import Console

from apps.cli.display import AI_DISCLOSURE_TEXT, print_ai_disclosure


class TestAIDisclosure:
    """AI Disclosure banner tests."""

    def test_disclosure_contains_required_elements(self) -> None:
        """Verify disclosure contains EU AI Act required elements."""
        assert "AI" in AI_DISCLOSURE_TEXT
        assert "assistant" in AI_DISCLOSURE_TEXT.lower()
        assert "not a human" in AI_DISCLOSURE_TEXT.lower()

    def test_disclosure_contains_digital_valerii(self) -> None:
        """Verify disclosure contains system name."""
        assert "DIGITAL VALERII" in AI_DISCLOSURE_TEXT

    def test_disclosure_displayed_by_default(self) -> None:
        """Verify disclosure is displayed when env var not set."""
        # Clear env var if set
        with patch.dict(os.environ, {}, clear=True):
            # Should not raise, should print output
            print_ai_disclosure()

    def test_disclosure_disabled_by_env_1(self) -> None:
        """Verify DV_DISABLE_AI_DISCLOSURE=1 skips banner."""
        with patch.dict(os.environ, {"DV_DISABLE_AI_DISCLOSURE": "1"}):
            # Create a console to capture output
            output = StringIO()
            test_console = Console(file=output, force_terminal=True)

            # Patch the console in display module
            with patch("apps.cli.display.console", test_console):
                print_ai_disclosure()

            # Should have no output (banner skipped)
            assert output.getvalue() == ""

    @pytest.mark.parametrize("value", ["1", "true", "TRUE", "yes", "YES"])
    def test_disclosure_disabled_variations(self, value: str) -> None:
        """Verify various truthy values disable disclosure."""
        with patch.dict(os.environ, {"DV_DISABLE_AI_DISCLOSURE": value}):
            output = StringIO()
            test_console = Console(file=output, force_terminal=True)

            with patch("apps.cli.display.console", test_console):
                print_ai_disclosure()

            assert output.getvalue() == ""

    def test_disclosure_not_disabled_by_invalid_value(self) -> None:
        """Verify invalid values don't disable disclosure."""
        with patch.dict(os.environ, {"DV_DISABLE_AI_DISCLOSURE": "no"}):
            output = StringIO()
            test_console = Console(file=output, force_terminal=True)

            with patch("apps.cli.display.console", test_console):
                print_ai_disclosure()

            # Should have output (banner shown)
            assert len(output.getvalue()) > 0

    def test_disclosure_not_disabled_by_empty_value(self) -> None:
        """Verify empty value doesn't disable disclosure."""
        with patch.dict(os.environ, {"DV_DISABLE_AI_DISCLOSURE": ""}):
            output = StringIO()
            test_console = Console(file=output, force_terminal=True)

            with patch("apps.cli.display.console", test_console):
                print_ai_disclosure()

            # Should have output (banner shown)
            assert len(output.getvalue()) > 0

    def test_disclosure_output_contains_ai_system(self) -> None:
        """Verify output contains AI System title."""
        with patch.dict(os.environ, {}, clear=True):
            output = StringIO()
            test_console = Console(file=output, force_terminal=True)

            with patch("apps.cli.display.console", test_console):
                print_ai_disclosure()

            result = output.getvalue()
            assert "AI System" in result or "AI" in result
