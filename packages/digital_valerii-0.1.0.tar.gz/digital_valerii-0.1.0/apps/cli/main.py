"""Digital Valerii CLI - Main application."""

import asyncio
from typing import Annotated

import typer
from rich.console import Console

from apps.cli.client import APIError, ConnectionError, DVClient
from apps.cli.commands import chat_app, config_app, memory_app
from apps.cli.config import load_config, save_config
from apps.cli.display import (
    print_ai_disclosure,
    print_chat_response,
    print_error,
    print_info,
)

app = typer.Typer(
    name="dv",
    help="Digital Valerii CLI - Interact with your AI clone",
    add_completion=False,
)
console = Console()

# Add subcommand groups
app.add_typer(chat_app, name="chat")
app.add_typer(memory_app, name="memory")
app.add_typer(config_app, name="config")


async def _quick_query(message: str) -> None:
    """Send a quick one-shot query.

    Args:
        message: User message.
    """
    settings = load_config()

    if not settings.api_key:
        print_error("API key not configured. Run: dv config set api_key YOUR_KEY")
        raise typer.Exit(1)

    async with DVClient(settings) as client:
        try:
            with console.status("[yellow]Thinking...[/yellow]"):
                response = await client.chat(message)

            print_chat_response(response.message, response.tokens_used)

            # Save conversation ID for --continue
            settings.last_conversation_id = str(response.conversation_id)
            save_config(settings)

        except ConnectionError as e:
            print_error(f"Cannot connect to API: {e.cause}")
            print_info(f"API URL: {settings.api_url}")
            print_info("Make sure the API server is running.")
            raise typer.Exit(1) from None

        except APIError as e:
            if e.status_code == 401:
                print_error("Authentication failed. Check your API key.")
                print_info("Run: dv config set api_key YOUR_KEY")
            elif e.status_code == 429:
                print_error("Rate limit exceeded. Please wait and try again.")
            else:
                print_error(f"API error: {e.message}")
            raise typer.Exit(1) from None


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Digital Valerii CLI - Interact with your AI clone.

    Quick query mode:
        dv ask "What's on my calendar?"

    Subcommands:
        dv chat     - Interactive chat
        dv memory   - Search memories
        dv config   - Manage configuration
    """
    # Show AI disclosure at session start (EU AI Act Art.50)
    print_ai_disclosure()

    # If no subcommand, show help
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())


@app.command()
def ask(
    message: Annotated[str, typer.Argument(help="Quick query message")],
) -> None:
    """Send a quick one-shot query.

    Examples:
        dv ask "What's on my calendar?"
        dv ask "Summarize my last meeting"
    """
    if len(message) > 10000:
        print_error("Message too long. Maximum 10000 characters.")
        raise typer.Exit(1)

    asyncio.run(_quick_query(message))


@app.command()
def version() -> None:
    """Show version information."""
    console.print("[bold]Digital Valerii[/bold] v0.1.0")


@app.command()
def status() -> None:
    """Check API connection status."""
    settings = load_config()

    console.print(f"[dim]API URL:[/dim] {settings.api_url}")
    console.print(f"[dim]API Key:[/dim] {settings.mask_api_key()}")

    async def _check() -> bool:
        async with DVClient(settings) as client:
            return await client.health_check()

    with console.status("[yellow]Checking connection...[/yellow]"):
        is_healthy = asyncio.run(_check())

    if is_healthy:
        console.print("[green]API is healthy[/green]")
    else:
        console.print("[red]API is not reachable[/red]")
        print_info("Make sure the API server is running.")


if __name__ == "__main__":
    app()
