"""CLI configuration management."""

import json
import logging
import os
import stat
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

# Default config directory
CONFIG_DIR = Path.home() / ".config" / "digital-valerii"
CONFIG_FILE = CONFIG_DIR / "config.json"


class CLISettings(BaseModel):
    """CLI configuration settings."""

    model_config = ConfigDict(extra="forbid")

    api_url: str = Field(default="http://localhost:8000")
    api_key: str = Field(default="")
    default_model: str = Field(default="default")
    output_format: Literal["rich", "plain", "json"] = Field(default="rich")
    last_conversation_id: str | None = Field(default=None)

    def mask_api_key(self) -> str:
        """Return masked API key for display.

        Returns:
            Masked key showing only last 4 characters.
        """
        if not self.api_key:
            return "(not set)"
        if len(self.api_key) <= 4:
            return "****"
        return f"****{self.api_key[-4:]}"


def ensure_config_dir() -> None:
    """Create config directory if it doesn't exist."""
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True, mode=0o700)
        logger.debug("Created config directory: %s", CONFIG_DIR)


def load_config() -> CLISettings:
    """Load configuration from file.

    Returns:
        CLISettings loaded from file or defaults.
    """
    if not CONFIG_FILE.exists():
        return CLISettings()

    try:
        with CONFIG_FILE.open("r") as f:
            data = json.load(f)
        return CLISettings(**data)
    except (json.JSONDecodeError, TypeError) as e:
        logger.warning("Failed to parse config file: %s", e)
        return CLISettings()
    except Exception as e:
        logger.warning("Failed to load config: %s", e)
        return CLISettings()


def save_config(settings: CLISettings) -> None:
    """Save configuration to file with secure permissions.

    Args:
        settings: CLISettings to save.
    """
    ensure_config_dir()

    try:
        with CONFIG_FILE.open("w") as f:
            json.dump(settings.model_dump(), f, indent=2)

        # Set file permissions to 0600 (owner read/write only)
        os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)
        logger.debug("Saved config to: %s", CONFIG_FILE)
    except Exception as e:
        logger.exception("Failed to save config: %s", e)
        raise RuntimeError(f"Failed to save configuration: {e}") from None


def update_config(key: str, value: str) -> CLISettings:
    """Update a single configuration value.

    Args:
        key: Configuration key to update.
        value: New value.

    Returns:
        Updated CLISettings.

    Raises:
        ValueError: If key is invalid.
    """
    settings = load_config()

    if not hasattr(settings, key):
        valid_keys = [k for k in settings.model_fields if k != "last_conversation_id"]
        raise ValueError(
            f"Invalid config key: {key}. Valid keys: {', '.join(valid_keys)}"
        )

    # Convert value based on field type
    if key == "output_format" and value not in ("rich", "plain", "json"):
        raise ValueError("output_format must be one of: rich, plain, json")

    setattr(settings, key, value)
    save_config(settings)
    return settings


def get_config_path() -> Path:
    """Get path to config file.

    Returns:
        Path to config file.
    """
    return CONFIG_FILE
