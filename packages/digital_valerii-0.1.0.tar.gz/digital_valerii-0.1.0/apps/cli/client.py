"""API client for Digital Valerii."""

import logging
from datetime import datetime
from typing import TYPE_CHECKING
from uuid import UUID

import httpx
from pydantic import BaseModel, ConfigDict

if TYPE_CHECKING:
    from apps.cli.config import CLISettings

logger = logging.getLogger(__name__)

# Timeout configuration
DEFAULT_TIMEOUT = 60.0  # seconds


class ChatResponse(BaseModel):
    """Response from chat endpoint."""

    model_config = ConfigDict(extra="forbid")

    message: str
    conversation_id: UUID
    created_at: datetime
    tokens_used: int | None = None


class MemorySearchResult(BaseModel):
    """Memory search result."""

    model_config = ConfigDict(extra="forbid")

    event_id: UUID
    event_type: str
    title: str | None = None
    summary: str | None = None
    occurred_at: datetime
    score: float


class PersonSummary(BaseModel):
    """Person summary."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    email: str | None = None
    company: str | None = None
    relationship_type: str | None = None


class PersonDetail(PersonSummary):
    """Full person details."""

    notes: str | None = None
    last_interaction: datetime | None = None
    interaction_count: int = 0


class ProjectSummary(BaseModel):
    """Project summary."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    status: str
    description: str | None = None


class ProjectDetail(ProjectSummary):
    """Full project details."""

    created_at: datetime
    updated_at: datetime
    people: list[PersonSummary] = []


class APIError(Exception):
    """API error with status code and message."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"API error ({status_code}): {message}")


class ConnectionError(Exception):
    """Connection error when API is unreachable."""

    def __init__(self, url: str, cause: str) -> None:
        self.url = url
        self.cause = cause
        super().__init__(f"Cannot connect to {url}: {cause}")


class DVClient:
    """Async API client for Digital Valerii."""

    def __init__(self, settings: "CLISettings") -> None:
        """Initialize client with settings.

        Args:
            settings: CLI settings with API URL and key.
        """
        self.base_url = settings.api_url.rstrip("/")
        self.api_key = settings.api_key
        self._client: httpx.AsyncClient | None = None

        # Warn if sending API key over non-HTTPS to remote host
        if self.api_key and self.base_url.startswith("http://"):
            from urllib.parse import urlparse

            host = urlparse(self.base_url).hostname or ""
            if host not in ("localhost", "127.0.0.1", "::1"):
                import sys

                print(
                    "Warning: Sending API key over unencrypted HTTP to remote host. "
                    "Consider using HTTPS.",
                    file=sys.stderr,
                )

    async def __aenter__(self) -> "DVClient":
        """Enter async context."""
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self._get_headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        return self

    async def __aexit__(self, *args: object) -> None:
        """Exit async context."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_headers(self) -> dict[str, str]:
        """Get request headers with API key.

        Returns:
            Headers dict with X-API-Key.
        """
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: object,
    ) -> httpx.Response:
        """Make HTTP request with error handling.

        Args:
            method: HTTP method.
            path: API path.
            **kwargs: Additional request arguments.

        Returns:
            HTTP response.

        Raises:
            ConnectionError: If API is unreachable.
            APIError: If API returns error status.
        """
        if not self._client:
            raise RuntimeError("Client not initialized. Use 'async with' context.")

        try:
            response = await self._client.request(method, path, **kwargs)
        except httpx.ConnectError as e:
            raise ConnectionError(self.base_url, str(e)) from None
        except httpx.TimeoutException:
            raise ConnectionError(self.base_url, "Request timed out") from None
        except httpx.RequestError as e:
            raise ConnectionError(self.base_url, str(e)) from None

        if response.status_code >= 400:
            if response.status_code < 500:
                # Client errors - safe to show detail
                try:
                    detail = response.json().get("detail", "Request failed")
                except Exception:
                    detail = "Request failed"
            else:
                # Server errors - hide internal details
                detail = "Internal server error"
            raise APIError(response.status_code, detail)

        return response

    async def chat(
        self,
        message: str,
        conversation_id: UUID | None = None,
    ) -> ChatResponse:
        """Send chat message.

        Args:
            message: User message.
            conversation_id: Optional conversation ID to continue.

        Returns:
            ChatResponse with agent reply.
        """
        payload: dict[str, object] = {"message": message}
        if conversation_id:
            payload["conversation_id"] = str(conversation_id)

        response = await self._request("POST", "/api/v1/chat/message", json=payload)
        return ChatResponse.model_validate(response.json())

    async def search_memories(
        self,
        query: str,
        limit: int = 10,
    ) -> list[MemorySearchResult]:
        """Search memories.

        Args:
            query: Search query.
            limit: Maximum results.

        Returns:
            List of memory search results.
        """
        response = await self._request(
            "GET",
            "/api/v1/memory/search",
            params={"q": query, "limit": limit},
        )
        return [MemorySearchResult.model_validate(r) for r in response.json()]

    async def list_people(
        self,
        query: str | None = None,
        limit: int = 20,
    ) -> list[PersonSummary]:
        """List people.

        Args:
            query: Optional search query.
            limit: Maximum results.

        Returns:
            List of person summaries.
        """
        params: dict[str, object] = {"limit": limit}
        if query:
            params["q"] = query

        response = await self._request("GET", "/api/v1/memory/people", params=params)
        return [PersonSummary.model_validate(p) for p in response.json()]

    async def get_person(self, person_id: UUID) -> PersonDetail:
        """Get person details.

        Args:
            person_id: Person UUID.

        Returns:
            PersonDetail.
        """
        response = await self._request("GET", f"/api/v1/memory/people/{person_id}")
        return PersonDetail.model_validate(response.json())

    async def list_projects(
        self,
        query: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> list[ProjectSummary]:
        """List projects.

        Args:
            query: Optional search query.
            status: Optional status filter.
            limit: Maximum results.

        Returns:
            List of project summaries.
        """
        params: dict[str, object] = {"limit": limit}
        if query:
            params["q"] = query
        if status:
            params["status"] = status

        response = await self._request("GET", "/api/v1/memory/projects", params=params)
        return [ProjectSummary.model_validate(p) for p in response.json()]

    async def get_project(self, project_id: UUID) -> ProjectDetail:
        """Get project details.

        Args:
            project_id: Project UUID.

        Returns:
            ProjectDetail.
        """
        response = await self._request("GET", f"/api/v1/memory/projects/{project_id}")
        return ProjectDetail.model_validate(response.json())

    async def health_check(self) -> bool:
        """Check if API is healthy.

        Returns:
            True if healthy.
        """
        try:
            response = await self._request("GET", "/health")
            return response.status_code == 200
        except Exception:
            return False
