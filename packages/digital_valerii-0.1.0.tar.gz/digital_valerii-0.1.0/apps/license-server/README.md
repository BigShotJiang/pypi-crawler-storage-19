# License Server

Component 4.10: Licensing & Protection System

FastAPI-based license server with Ed25519 signing and Dead Man's Switch architecture.

## Quick Start

```bash
# Install dependencies
pip install -e ".[dev]"

# Run migrations
alembic upgrade head

# Start server
uvicorn license_server.main:app --reload
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection URL | Yes |
| `ADMIN_API_KEY` | Admin API authentication | Production |
| `JWT_SECRET_KEY` | JWT token signing | Production |
| `LICENSE_SERVER_PRIVATE_KEY` | Ed25519 private key (base64) | Production |
| `LICENSE_SERVER_PUBLIC_KEY` | Ed25519 public key (base64) | Clients |

## API Endpoints

### Public (License Validation)
- `POST /api/v1/license/validate` - Validate license
- `POST /api/v1/license/heartbeat` - Agent heartbeat

### Admin
- `GET /api/v1/admin/licenses` - List licenses
- `POST /api/v1/admin/licenses` - Create license
- `GET /api/v1/admin/status` - Server status
- `POST /api/v1/admin/monthly-sign` - Monthly signature (Dead Man's Switch)

## Database Schema

Five tables: `licenses`, `activation_tokens`, `monthly_signatures`, `usage_logs`, `security_events`

## Security Features

- Ed25519 digital signatures
- Dead Man's Switch (monthly activation required)
- Grace period handling
- Security event logging
