"""License Server routes."""

from .admin import router as admin_router
from .health import router as health_router
from .license import router as license_router

__all__ = ["admin_router", "health_router", "license_router"]
