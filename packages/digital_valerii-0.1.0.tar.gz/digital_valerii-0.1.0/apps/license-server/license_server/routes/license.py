"""License validation endpoints (public API).

Component 4.10: Licensing & Protection System
"""

from fastapi import APIRouter

from ..dependencies import LicenseServiceDep
from ..schemas import (
    LicenseHeartbeatRequest,
    LicenseHeartbeatResponse,
    LicenseValidateRequest,
    LicenseValidateResponse,
)

router = APIRouter(prefix="/license", tags=["license"])


@router.post("/validate", response_model=LicenseValidateResponse)
async def validate_license(
    request: LicenseValidateRequest,
    service: LicenseServiceDep,
) -> LicenseValidateResponse:
    """Validate a license for an agent.

    This endpoint is called by agents to verify their license is valid.
    Returns license details including features and expiration.
    """
    try:
        result = await service.validate_license(
            agent_id=request.agent_id,
            client_id=request.client_id,
            signature=request.signature,
            timestamp=request.timestamp,
        )
        return result
    except Exception as e:
        # Log security event for failed validation
        await service.log_security_event(
            license_id=None,
            event_type="validation_failed",
            details={"agent_id": request.agent_id, "error": str(e)},
            severity="warning",
        )
        return LicenseValidateResponse(
            valid=False,
            message=f"Validation failed: {str(e)}",
        )


@router.post("/heartbeat", response_model=LicenseHeartbeatResponse)
async def license_heartbeat(
    request: LicenseHeartbeatRequest,
    service: LicenseServiceDep,
) -> LicenseHeartbeatResponse:
    """Send a heartbeat from an agent.

    Used to track agent activity and report usage metrics.
    Returns whether the agent should continue operating.
    """
    try:
        result = await service.process_heartbeat(
            agent_id=request.agent_id,
            usage_metrics=request.usage_metrics,
        )
        return result
    except Exception as e:
        return LicenseHeartbeatResponse(
            continue_operation=False,
            message=f"Heartbeat failed: {str(e)}",
        )
