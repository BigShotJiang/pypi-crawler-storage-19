"""Admin endpoints for license management.

Component 4.10: Licensing & Protection System
Protected endpoints - require admin API key.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status

from ..config import settings
from ..dependencies import LicenseServiceDep
from ..schemas import (
    LicenseCreate,
    LicenseListResponse,
    LicenseResponse,
    LicenseRevokeRequest,
    LicenseRevokeResponse,
    LicenseUpdate,
    MonthlySignatureRequest,
    MonthlySignatureResponse,
    SecurityEventListResponse,
    ServerStatusResponse,
    UsageLogResponse,
)

router = APIRouter(prefix="/admin", tags=["admin"])


async def verify_admin_key(
    x_api_key: str = Header(..., alias="X-API-Key"),
) -> None:
    """Verify admin API key."""
    if settings.app_env == "development" and not settings.admin_api_key:
        # Allow in development without key
        return
    if x_api_key != settings.admin_api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
        )


AdminAuth = Annotated[None, Depends(verify_admin_key)]


# =============================================================================
# License CRUD
# =============================================================================


@router.get("/licenses", response_model=LicenseListResponse)
async def list_licenses(
    _auth: AdminAuth,
    service: LicenseServiceDep,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    status_filter: str | None = Query(default=None, alias="status"),
) -> LicenseListResponse:
    """List all licenses with pagination."""
    return await service.list_licenses(
        page=page,
        page_size=page_size,
        status_filter=status_filter,
    )


@router.post(
    "/licenses",
    response_model=LicenseResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_license(
    _auth: AdminAuth,
    body: LicenseCreate,
    service: LicenseServiceDep,
) -> LicenseResponse:
    """Create a new license."""
    return await service.create_license(body)


@router.get("/licenses/{license_id}", response_model=LicenseResponse)
async def get_license(
    license_id: UUID,
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> LicenseResponse:
    """Get a specific license by ID."""
    license = await service.get_license(license_id)
    if not license:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="License not found",
        )
    return license


@router.put("/licenses/{license_id}", response_model=LicenseResponse)
async def update_license(
    license_id: UUID,
    body: LicenseUpdate,
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> LicenseResponse:
    """Update a license."""
    license = await service.update_license(license_id, body)
    if not license:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="License not found",
        )
    return license


@router.delete("/licenses/{license_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_license(
    license_id: UUID,
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> None:
    """Delete a license (hard delete)."""
    success = await service.delete_license(license_id)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="License not found",
        )


@router.post("/licenses/{license_id}/revoke", response_model=LicenseRevokeResponse)
async def revoke_license(
    license_id: UUID,
    body: LicenseRevokeRequest,
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> LicenseRevokeResponse:
    """Revoke a license immediately."""
    success = await service.revoke_license(license_id, body.reason)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="License not found",
        )
    return LicenseRevokeResponse(revoked=True, message="License revoked successfully")


# =============================================================================
# Usage & Security
# =============================================================================


@router.get("/usage/{license_id}", response_model=list[UsageLogResponse])
async def get_usage_logs(
    license_id: UUID,
    _auth: AdminAuth,
    service: LicenseServiceDep,
    limit: int = Query(default=100, ge=1, le=1000),
) -> list[UsageLogResponse]:
    """Get usage logs for a license."""
    return await service.get_usage_logs(license_id, limit=limit)


@router.get("/security-events", response_model=SecurityEventListResponse)
async def get_security_events(
    _auth: AdminAuth,
    service: LicenseServiceDep,
    severity: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=1000),
) -> SecurityEventListResponse:
    """Get security events."""
    return await service.get_security_events(severity=severity, limit=limit)


# =============================================================================
# Monthly Signing (Dead Man's Switch)
# =============================================================================


@router.post("/sign-monthly", response_model=MonthlySignatureResponse)
async def sign_monthly(
    body: MonthlySignatureRequest,
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> MonthlySignatureResponse:
    """Sign the license server for a month (YubiKey required)."""
    return await service.sign_monthly(
        month=body.month,
        signature=body.signature,
        signed_by=body.signed_by,
    )


@router.get("/server-status", response_model=ServerStatusResponse)
async def get_server_status(
    _auth: AdminAuth,
    service: LicenseServiceDep,
) -> ServerStatusResponse:
    """Get license server status including monthly signature status."""
    return await service.get_server_status()
