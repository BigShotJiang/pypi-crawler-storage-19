"""Health check endpoints.

Component 4.10: Licensing & Protection System
"""

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ..database import get_db
from ..schemas import HealthResponse, ReadyResponse

router = APIRouter(tags=["health"])

# Module-level dependency for ruff B008 compliance
DBSession = Annotated[AsyncSession, Depends(get_db)]


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Basic health check endpoint."""
    from .. import __version__

    return HealthResponse(
        status="healthy",
        version=__version__,
        timestamp=datetime.now(UTC),
    )


@router.get("/health/ready", response_model=ReadyResponse)
async def readiness_check(db: DBSession) -> ReadyResponse:
    """Readiness check - verifies database connectivity."""
    try:
        # Try a simple query
        await db.execute(text("SELECT 1"))
        return ReadyResponse(
            ready=True,
            database=True,
            message="All systems operational",
        )
    except Exception as e:
        return ReadyResponse(
            ready=False,
            database=False,
            message=f"Database connection failed: {str(e)}",
        )
