"""SQLAlchemy models for License Server.

Component 4.10: Licensing & Protection System
Database schema as defined in ARCHITECTURE.md 8.9.9
"""

from datetime import UTC, datetime
from uuid import uuid4

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    LargeBinary,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Base class for all models."""

    pass


class License(Base):
    """License model - core license information for clients."""

    __tablename__ = "licenses"

    id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    client_id: Mapped[str] = mapped_column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )
    client_name: Mapped[str] = mapped_column(String(255), nullable=False)
    tier: Mapped[str] = mapped_column(String(50), default="standard")
    worker_count: Mapped[int] = mapped_column(Integer, default=1)
    features: Mapped[list[str]] = mapped_column(
        ARRAY(Text),
        default=list,
        server_default="{}",
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )
    grace_period_days: Mapped[int] = mapped_column(Integer, default=14)
    status: Mapped[str] = mapped_column(
        String(20),
        default="active",
        index=True,
    )  # active, suspended, revoked
    # Security fields for HMAC request verification and Ed25519 license signature
    shared_secret: Mapped[str | None] = mapped_column(
        String(64),
        nullable=True,  # Nullable for backwards compatibility
        doc="Shared secret for HMAC request signature verification",
    )
    signature: Mapped[str | None] = mapped_column(
        String(128),
        nullable=True,  # Nullable for backwards compatibility
        doc="Ed25519 signature of license data (base64)",
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        onupdate=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
    )

    # Relationships
    activation_tokens: Mapped[list["ActivationToken"]] = relationship(
        back_populates="license",
        cascade="all, delete-orphan",
    )
    usage_logs: Mapped[list["UsageLog"]] = relationship(
        back_populates="license",
        cascade="all, delete-orphan",
    )
    security_events: Mapped[list["SecurityEvent"]] = relationship(
        back_populates="license",
        cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<License {self.client_id} ({self.status})>"

    @property
    def is_active(self) -> bool:
        """Check if license is currently active."""
        return bool(self.status == "active" and datetime.now(UTC) < self.expires_at)

    @property
    def is_in_grace_period(self) -> bool:
        """Check if license is in grace period."""
        if self.status != "active":
            return False
        now = datetime.now(UTC)
        from datetime import timedelta

        grace_end = self.expires_at + timedelta(days=self.grace_period_days)
        return bool(self.expires_at <= now < grace_end)


class ActivationToken(Base):
    """Activation tokens for license validation."""

    __tablename__ = "activation_tokens"

    id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    license_id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("licenses.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    issued_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
    )
    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)

    # Relationships
    license: Mapped["License"] = relationship(back_populates="activation_tokens")

    def __repr__(self) -> str:
        return f"<ActivationToken {self.id}>"


class MonthlySignature(Base):
    """Monthly YubiKey signatures for Dead Man's Switch."""

    __tablename__ = "monthly_signatures"

    id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    month: Mapped[str] = mapped_column(
        String(7),
        unique=True,
        nullable=False,
        index=True,
    )  # "2025-01"
    signature: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    signed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
    )
    signed_by: Mapped[str] = mapped_column(String(100), nullable=False)

    def __repr__(self) -> str:
        return f"<MonthlySignature {self.month}>"


class UsageLog(Base):
    """Usage tracking for billing and analytics."""

    __tablename__ = "usage_log"

    id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    license_id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("licenses.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
        index=True,
    )
    endpoint: Mapped[str | None] = mapped_column(String(100))
    tokens_in: Mapped[int | None] = mapped_column(Integer)
    tokens_out: Mapped[int | None] = mapped_column(Integer)
    latency_ms: Mapped[int | None] = mapped_column(Integer)

    # Relationships
    license: Mapped["License"] = relationship(back_populates="usage_logs")

    def __repr__(self) -> str:
        return f"<UsageLog {self.license_id} @ {self.timestamp}>"


class SecurityEvent(Base):
    """Security event logging for auditing."""

    __tablename__ = "security_events"

    id: Mapped[str] = mapped_column(
        PGUUID(as_uuid=True),
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    license_id: Mapped[str | None] = mapped_column(
        PGUUID(as_uuid=True),
        ForeignKey("licenses.id", ondelete="SET NULL"),
        index=True,
    )
    event_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    details: Mapped[dict | None] = mapped_column(JSONB)
    severity: Mapped[str] = mapped_column(
        String(20),
        default="info",
    )  # info, warning, error, critical
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(UTC),
        server_default=text("CURRENT_TIMESTAMP"),
        index=True,
    )

    # Relationships
    license: Mapped["License | None"] = relationship(back_populates="security_events")

    def __repr__(self) -> str:
        return f"<SecurityEvent {self.event_type} ({self.severity})>"
