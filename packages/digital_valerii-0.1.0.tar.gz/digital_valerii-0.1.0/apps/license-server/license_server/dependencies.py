"""FastAPI dependencies for License Server.

Component 4.10: Licensing & Protection System
"""

from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from .database import get_db
from .services.license_service import LicenseService
from .services.signature_service import SignatureService


async def get_signature_service() -> SignatureService:
    """Get signature service instance."""
    return SignatureService()


async def get_license_service(
    db: Annotated[AsyncSession, Depends(get_db)],
    signature_service: Annotated[SignatureService, Depends(get_signature_service)],
) -> LicenseService:
    """Get license service with injected dependencies.

    Args:
        db: Database session from dependency injection.
        signature_service: Signature service from dependency injection.

    Returns:
        Configured LicenseService instance.
    """
    service = LicenseService(db=db)
    service._signature_service = signature_service
    return service


# Type aliases for cleaner route signatures
DbSession = Annotated[AsyncSession, Depends(get_db)]
LicenseServiceDep = Annotated[LicenseService, Depends(get_license_service)]
SignatureServiceDep = Annotated[SignatureService, Depends(get_signature_service)]
