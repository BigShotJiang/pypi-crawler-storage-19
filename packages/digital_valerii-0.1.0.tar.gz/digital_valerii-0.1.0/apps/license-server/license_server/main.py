"""License Server FastAPI application.

Component 4.10: Licensing & Protection System
Main entry point for the License Server.
"""

from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .config import settings
from .database import engine
from .models import Base
from .routes import admin_router, health_router, license_router

logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):  # type: ignore[no-untyped-def]
    """Application lifespan manager."""
    # Startup
    logger.info(
        "Starting License Server",
        app_env=settings.app_env,
        debug=settings.debug,
    )

    # Create tables if in development (use Alembic in production)
    if settings.app_env == "development":
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
            logger.info("Database tables created/verified")

    yield

    # Shutdown
    logger.info("Shutting down License Server")
    await engine.dispose()


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        description="License Server for Digital Valerii AI Clone System",
        docs_url="/docs" if settings.debug else None,
        redoc_url="/redoc" if settings.debug else None,
        openapi_url="/openapi.json" if settings.debug else None,
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
        allow_headers=["*"],
    )

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        """Handle uncaught exceptions."""
        logger.exception(
            "Unhandled exception",
            path=request.url.path,
            method=request.method,
            error=str(exc),
        )
        # Don't expose internal errors in production
        detail = str(exc) if settings.debug else "Internal server error"
        return JSONResponse(
            status_code=500,
            content={"detail": detail},
        )

    # Register routers
    app.include_router(health_router, tags=["Health"])
    app.include_router(
        license_router,
        prefix=f"{settings.api_v1_prefix}/license",
        tags=["License"],
    )
    app.include_router(
        admin_router,
        prefix=f"{settings.api_v1_prefix}/admin",
        tags=["Admin"],
    )

    return app


# Create app instance
app = create_app()


@app.get("/")
async def root() -> dict[str, Any]:
    """Root endpoint."""
    return {
        "name": settings.app_name,
        "version": "1.0.0",
        "status": "operational",
    }
