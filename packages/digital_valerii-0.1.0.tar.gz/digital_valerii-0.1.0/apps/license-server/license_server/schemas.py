"""Pydantic schemas for License Server API.

Component 4.10: Licensing & Protection System
"""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

# =============================================================================
# License Validation Schemas (Public API)
# =============================================================================


class LicenseValidateRequest(BaseModel):
    """Request to validate a license."""

    model_config = ConfigDict(extra="forbid")

    agent_id: str = Field(..., min_length=1, max_length=100)
    client_id: str = Field(..., min_length=1, max_length=100)
    signature: str = Field(..., min_length=1, description="HMAC-SHA256 signature hex")
    timestamp: int = Field(..., description="Unix timestamp for replay protection")


class LicenseValidateResponse(BaseModel):
    """Response for license validation."""

    model_config = ConfigDict(extra="forbid")

    valid: bool
    expires: datetime | None = None
    features: list[str] = Field(default_factory=list)
    tier: str | None = None
    worker_count: int | None = None
    message: str | None = None
    in_grace_period: bool = False


class LicenseHeartbeatRequest(BaseModel):
    """Request for license heartbeat."""

    model_config = ConfigDict(extra="forbid")

    agent_id: str = Field(..., min_length=1, max_length=100)
    usage_metrics: dict[str, Any] | None = Field(default=None)


class LicenseHeartbeatResponse(BaseModel):
    """Response for license heartbeat."""

    model_config = ConfigDict(extra="forbid")

    continue_operation: bool = Field(alias="continue")
    message: str | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class LicenseRevokeRequest(BaseModel):
    """Request to revoke a license (admin only)."""

    model_config = ConfigDict(extra="forbid")

    license_id: UUID
    reason: str = Field(..., min_length=1, max_length=500)


class LicenseRevokeResponse(BaseModel):
    """Response for license revocation."""

    model_config = ConfigDict(extra="forbid")

    revoked: bool = True
    message: str | None = None


# =============================================================================
# Admin Schemas
# =============================================================================


class LicenseCreate(BaseModel):
    """Request to create a new license."""

    model_config = ConfigDict(extra="forbid")

    client_id: str = Field(..., min_length=1, max_length=100)
    client_name: str = Field(..., min_length=1, max_length=255)
    tier: str = Field(default="standard", max_length=50)
    worker_count: int = Field(default=1, ge=1, le=100)
    features: list[str] = Field(default_factory=list)
    expires_at: datetime
    grace_period_days: int = Field(default=14, ge=0, le=90)

    @field_validator("client_id")
    @classmethod
    def validate_client_id(cls, v: str) -> str:
        """Validate client_id format (alphanumeric + hyphens)."""
        import re

        if not re.match(r"^[a-zA-Z0-9\-_]+$", v):
            raise ValueError(
                "client_id must contain only alphanumeric characters, hyphens, and underscores"
            )
        return v.lower()


class LicenseUpdate(BaseModel):
    """Request to update a license."""

    model_config = ConfigDict(extra="forbid")

    client_name: str | None = Field(default=None, max_length=255)
    tier: str | None = Field(default=None, max_length=50)
    worker_count: int | None = Field(default=None, ge=1, le=100)
    features: list[str] | None = None
    expires_at: datetime | None = None
    grace_period_days: int | None = Field(default=None, ge=0, le=90)
    status: str | None = Field(default=None, pattern="^(active|suspended|revoked)$")


class LicenseResponse(BaseModel):
    """License response for admin API."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    client_id: str
    client_name: str
    tier: str
    worker_count: int
    features: list[str]
    expires_at: datetime
    grace_period_days: int
    status: str
    created_at: datetime
    updated_at: datetime
    shared_secret: str | None = Field(
        default=None,
        description="Shared secret for HMAC signing. Only returned on license creation.",
    )


class LicenseListResponse(BaseModel):
    """Response for listing licenses."""

    model_config = ConfigDict(extra="forbid")

    items: list[LicenseResponse]
    total: int
    page: int
    page_size: int


# =============================================================================
# Usage & Security Schemas
# =============================================================================


class UsageLogResponse(BaseModel):
    """Usage log entry response."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    license_id: UUID
    timestamp: datetime
    endpoint: str | None
    tokens_in: int | None
    tokens_out: int | None
    latency_ms: int | None


class UsageStatsResponse(BaseModel):
    """Aggregated usage statistics."""

    model_config = ConfigDict(extra="forbid")

    license_id: UUID
    period_start: datetime
    period_end: datetime
    total_requests: int
    total_tokens_in: int
    total_tokens_out: int
    avg_latency_ms: float


class SecurityEventResponse(BaseModel):
    """Security event response."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    license_id: UUID | None
    event_type: str
    details: dict[str, Any] | None
    severity: str
    created_at: datetime


class SecurityEventListResponse(BaseModel):
    """Response for listing security events."""

    model_config = ConfigDict(extra="forbid")

    items: list[SecurityEventResponse]
    total: int


# =============================================================================
# Monthly Signature Schemas
# =============================================================================


class MonthlySignatureRequest(BaseModel):
    """Request to sign monthly (YubiKey)."""

    model_config = ConfigDict(extra="forbid")

    month: str = Field(..., pattern=r"^\d{4}-\d{2}$", description="YYYY-MM format")
    signature: str = Field(..., min_length=1, description="Base64 encoded signature")
    signed_by: str = Field(..., min_length=1, max_length=100)


class MonthlySignatureResponse(BaseModel):
    """Response for monthly signature."""

    model_config = ConfigDict(extra="forbid")

    success: bool
    month: str
    signed_at: datetime
    message: str | None = None


class ServerStatusResponse(BaseModel):
    """Response for server status."""

    model_config = ConfigDict(extra="forbid")

    status: str  # active, warning, grace_period, inactive
    current_month: str
    monthly_signature_valid: bool
    days_until_expiry: int | None
    total_licenses: int
    active_licenses: int
    message: str | None = None


# =============================================================================
# Health Check Schemas
# =============================================================================


class HealthResponse(BaseModel):
    """Health check response."""

    model_config = ConfigDict(extra="forbid")

    status: str = "healthy"
    version: str
    timestamp: datetime


class ReadyResponse(BaseModel):
    """Readiness check response."""

    model_config = ConfigDict(extra="forbid")

    ready: bool
    database: bool
    message: str | None = None
