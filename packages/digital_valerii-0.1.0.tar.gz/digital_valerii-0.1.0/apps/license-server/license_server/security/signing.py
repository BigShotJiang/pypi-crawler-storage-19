"""Ed25519 signing operations.

Component 4.10: Licensing & Protection System
Low-level signing primitives.
"""

import base64


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate Ed25519 keypair.

    Returns:
        Tuple of (public_key, private_key) as bytes.
    """
    try:
        from nacl.signing import SigningKey

        signing_key = SigningKey.generate()
        return bytes(signing_key.verify_key), bytes(signing_key)
    except ImportError as e:
        raise RuntimeError("PyNaCl not installed. Run: pip install pynacl") from e


def sign_data(data: bytes, private_key: bytes) -> bytes:
    """Sign data with Ed25519 private key.

    Args:
        data: Data to sign.
        private_key: Ed25519 private key (32 bytes).

    Returns:
        Signature bytes (64 bytes).
    """
    try:
        from nacl.signing import SigningKey

        signing_key = SigningKey(private_key)
        signed = signing_key.sign(data)
        return bytes(signed.signature)
    except ImportError as e:
        raise RuntimeError("PyNaCl not installed. Run: pip install pynacl") from e


def verify_signature(data: bytes, signature: bytes, public_key: bytes) -> bool:
    """Verify Ed25519 signature.

    Args:
        data: Original data.
        signature: Signature to verify (64 bytes).
        public_key: Ed25519 public key (32 bytes).

    Returns:
        True if signature is valid.
    """
    try:
        from nacl.signing import VerifyKey

        verify_key = VerifyKey(public_key)
        verify_key.verify(data, signature)
        return True
    except ImportError as e:
        raise RuntimeError("PyNaCl not installed. Run: pip install pynacl") from e
    except Exception:
        return False


def encode_key(key: bytes) -> str:
    """Encode key as base64 string.

    Args:
        key: Key bytes.

    Returns:
        Base64 encoded string.
    """
    return base64.b64encode(key).decode("ascii")


def decode_key(key_str: str) -> bytes:
    """Decode base64 key string.

    Args:
        key_str: Base64 encoded key.

    Returns:
        Key bytes.
    """
    return base64.b64decode(key_str)
