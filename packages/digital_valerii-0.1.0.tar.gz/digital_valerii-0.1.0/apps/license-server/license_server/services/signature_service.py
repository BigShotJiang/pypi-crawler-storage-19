"""Signature service for Ed25519 operations.

Component 4.10: Licensing & Protection System
"""

import base64
from datetime import datetime

import structlog

from ..config import settings

logger = structlog.get_logger(__name__)


class SignatureError(Exception):
    """Error during signature operations."""

    pass


class SignatureService:
    """Service for Ed25519 signature operations."""

    def __init__(self) -> None:
        """Initialize signature service."""
        self._public_key: bytes | None = None
        self._private_key: bytes | None = None
        self._load_keys()

    def _load_keys(self) -> None:
        """Load keys from settings."""
        if settings.license_server_public_key:
            try:
                self._public_key = base64.b64decode(settings.license_server_public_key)
            except Exception as e:
                logger.warning("Failed to load public key", error=str(e))

        if settings.license_server_private_key:
            try:
                self._private_key = base64.b64decode(settings.license_server_private_key)
            except Exception as e:
                logger.warning("Failed to load private key", error=str(e))

    def sign_data(self, data: bytes) -> bytes:
        """Sign data with Ed25519 private key.

        Args:
            data: Data to sign.

        Returns:
            Signature bytes.

        Raises:
            SignatureError: If signing fails.
        """
        if not self._private_key:
            raise SignatureError("Private key not configured")

        try:
            from nacl.signing import SigningKey

            signing_key = SigningKey(self._private_key)
            signed = signing_key.sign(data)
            return bytes(signed.signature)
        except ImportError as e:
            raise SignatureError("PyNaCl not installed. Run: pip install pynacl") from e
        except Exception as e:
            raise SignatureError(f"Signing failed: {e}") from e

    def verify_signature(self, data: bytes, signature: bytes) -> bool:
        """Verify Ed25519 signature.

        FAIL CLOSED in production - verification must succeed.

        Args:
            data: Original data.
            signature: Signature to verify.

        Returns:
            True if signature is valid.

        Raises:
            SignatureError: If verification cannot be performed in production.
        """
        if not self._public_key:
            if settings.app_env == "production":
                raise SignatureError("Public key not configured - cannot verify in production")
            logger.warning("Public key not configured - skipping verification in development")
            return True  # Only allow in dev/test

        try:
            from nacl.signing import VerifyKey

            verify_key = VerifyKey(self._public_key)
            verify_key.verify(data, signature)
            return True
        except ImportError as e:
            if settings.app_env == "production":
                raise SignatureError(
                    "PyNaCl not available - cannot verify signatures in production"
                ) from e
            logger.warning("PyNaCl not installed - skipping verification in development")
            return True  # Only allow in dev/test
        except Exception:
            return False

    def sign_license(
        self,
        license_id: str,
        client_id: str,
        expires_at: datetime,
    ) -> str:
        """Sign license data.

        Args:
            license_id: License UUID.
            client_id: Client identifier.
            expires_at: Expiration datetime.

        Returns:
            Base64 encoded signature.
        """
        # Create canonical data to sign
        data = f"{license_id}:{client_id}:{expires_at.isoformat()}".encode()
        signature = self.sign_data(data)
        return base64.b64encode(signature).decode()

    def verify_license_signature(
        self,
        license_id: str,
        client_id: str,
        expires_at: datetime,
        signature: str,
    ) -> bool:
        """Verify license signature.

        Args:
            license_id: License UUID.
            client_id: Client identifier.
            expires_at: Expiration datetime.
            signature: Base64 encoded signature.

        Returns:
            True if signature is valid.
        """
        try:
            data = f"{license_id}:{client_id}:{expires_at.isoformat()}".encode()
            sig_bytes = base64.b64decode(signature)
            return self.verify_signature(data, sig_bytes)
        except Exception:
            return False

    def sign_monthly(self, month: str) -> str:
        """Sign monthly activation.

        Args:
            month: Month in YYYY-MM format.

        Returns:
            Base64 encoded signature.
        """
        data = f"monthly-activation:{month}".encode()
        signature = self.sign_data(data)
        return base64.b64encode(signature).decode()

    def verify_monthly_signature(self, month: str, signature: str) -> bool:
        """Verify monthly activation signature.

        Args:
            month: Month in YYYY-MM format.
            signature: Base64 encoded signature.

        Returns:
            True if signature is valid.
        """
        try:
            data = f"monthly-activation:{month}".encode()
            sig_bytes = base64.b64decode(signature)
            return self.verify_signature(data, sig_bytes)
        except Exception:
            return False

    @staticmethod
    def generate_keypair() -> tuple[str, str]:
        """Generate a new Ed25519 keypair.

        Returns:
            Tuple of (public_key_base64, private_key_base64).
        """
        try:
            from nacl.signing import SigningKey

            signing_key = SigningKey.generate()
            private_key = bytes(signing_key)
            public_key = bytes(signing_key.verify_key)

            return (
                base64.b64encode(public_key).decode(),
                base64.b64encode(private_key).decode(),
            )
        except ImportError as e:
            raise SignatureError("PyNaCl not installed. Run: pip install pynacl") from e
