"""Usage tracking service.

Component 4.10: Licensing & Protection System
"""

from datetime import UTC, datetime, timedelta
from uuid import UUID

import structlog
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..models import UsageLog
from ..schemas import UsageStatsResponse

logger = structlog.get_logger(__name__)


class UsageService:
    """Service for tracking and aggregating usage."""

    def __init__(self, db: AsyncSession) -> None:
        """Initialize usage service.

        Args:
            db: Database session.
        """
        self._db = db

    async def log_usage(
        self,
        license_id: UUID,
        endpoint: str | None = None,
        tokens_in: int | None = None,
        tokens_out: int | None = None,
        latency_ms: int | None = None,
    ) -> None:
        """Log a usage event.

        Args:
            license_id: License UUID.
            endpoint: API endpoint called.
            tokens_in: Input token count.
            tokens_out: Output token count.
            latency_ms: Request latency in milliseconds.
        """
        log = UsageLog(
            license_id=str(license_id),
            endpoint=endpoint,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
        )
        self._db.add(log)
        await self._db.commit()

    async def get_usage_stats(
        self,
        license_id: UUID,
        period_days: int = 30,
    ) -> UsageStatsResponse:
        """Get aggregated usage statistics.

        Args:
            license_id: License UUID.
            period_days: Number of days to aggregate.

        Returns:
            Aggregated usage statistics.
        """
        period_start = datetime.now(UTC) - timedelta(days=period_days)
        period_end = datetime.now(UTC)

        result = await self._db.execute(
            select(
                func.count(UsageLog.id).label("total_requests"),
                func.coalesce(func.sum(UsageLog.tokens_in), 0).label("total_tokens_in"),
                func.coalesce(func.sum(UsageLog.tokens_out), 0).label("total_tokens_out"),
                func.coalesce(func.avg(UsageLog.latency_ms), 0).label("avg_latency_ms"),
            )
            .where(UsageLog.license_id == str(license_id))
            .where(UsageLog.timestamp >= period_start)
        )

        row = result.one()

        return UsageStatsResponse(
            license_id=license_id,
            period_start=period_start,
            period_end=period_end,
            total_requests=row.total_requests,
            total_tokens_in=row.total_tokens_in,
            total_tokens_out=row.total_tokens_out,
            avg_latency_ms=float(row.avg_latency_ms),
        )

    async def get_daily_usage(
        self,
        license_id: UUID,
        days: int = 30,
    ) -> list[dict]:
        """Get daily usage breakdown.

        Args:
            license_id: License UUID.
            days: Number of days.

        Returns:
            List of daily usage dictionaries.
        """
        period_start = datetime.now(UTC) - timedelta(days=days)

        result = await self._db.execute(
            select(
                func.date_trunc("day", UsageLog.timestamp).label("day"),
                func.count(UsageLog.id).label("requests"),
                func.coalesce(func.sum(UsageLog.tokens_in), 0).label("tokens_in"),
                func.coalesce(func.sum(UsageLog.tokens_out), 0).label("tokens_out"),
            )
            .where(UsageLog.license_id == str(license_id))
            .where(UsageLog.timestamp >= period_start)
            .group_by(func.date_trunc("day", UsageLog.timestamp))
            .order_by(func.date_trunc("day", UsageLog.timestamp))
        )

        return [
            {
                "date": row.day.isoformat(),
                "requests": row.requests,
                "tokens_in": row.tokens_in,
                "tokens_out": row.tokens_out,
            }
            for row in result.all()
        ]
