"""YubiKey signing service for Dead Man's Switch.

Component 4.10: Licensing & Protection System
"""

import base64
from datetime import UTC, datetime

import structlog

from ..config import settings

logger = structlog.get_logger(__name__)


class YubiKeyError(Exception):
    """Error during YubiKey operations."""

    pass


class YubiKeyService:
    """Service for YubiKey-based signing operations.

    Uses Ed25519 signatures via YubiKey for monthly activation.
    """

    def __init__(self) -> None:
        """Initialize YubiKey service."""
        self._device = None

    def is_available(self) -> bool:
        """Check if YubiKey is available.

        Returns:
            True if YubiKey is detected.
        """
        try:
            from fido2.hid import CtapHidDevice

            devices = list(CtapHidDevice.list_devices())
            return len(devices) > 0
        except ImportError:
            logger.warning("python-fido2 not installed")
            return False
        except Exception as e:
            logger.warning("Failed to detect YubiKey", error=str(e))
            return False

    def get_device_info(self) -> dict | None:
        """Get YubiKey device information.

        Returns:
            Device info dict or None if not available.
        """
        try:
            from fido2.hid import CtapHidDevice

            devices = list(CtapHidDevice.list_devices())
            if not devices:
                return None

            device = devices[0]
            return {
                "product_name": getattr(device, "product_name", "Unknown"),
                "vendor_id": getattr(device, "descriptor", {}).get("vendor_id", 0),
                "product_id": getattr(device, "descriptor", {}).get("product_id", 0),
            }
        except Exception as e:
            logger.warning("Failed to get device info", error=str(e))
            return None

    def sign_monthly(self, month: str, private_key_path: str | None = None) -> str:
        """Sign monthly activation.

        In production, ONLY hardware YubiKey allowed - NO software fallback.
        In development/testing, allows software key for testing.

        Args:
            month: Month in YYYY-MM format.
            private_key_path: Optional path to private key file (dev/test only).

        Returns:
            Base64 encoded signature.

        Raises:
            YubiKeyError: If signing fails or YubiKey not available in production.
        """
        is_production = settings.app_env == "production"

        if is_production:
            # PRODUCTION: Hardware YubiKey ONLY - no exceptions
            if not self.is_available():
                raise YubiKeyError(
                    "YubiKey hardware required in production. "
                    "No software key fallback allowed. "
                    "Please insert YubiKey and try again."
                )
            # Use hardware YubiKey signing
            return self._sign_with_hardware_yubikey(month)

        # DEVELOPMENT/TESTING: Software key allowed
        return self._sign_with_software_key(month, private_key_path)

    def _sign_with_hardware_yubikey(self, month: str) -> str:
        """Sign with actual YubiKey hardware.

        Uses FIDO2 or PIV interface for cryptographic signing.

        Args:
            month: Month in YYYY-MM format.

        Returns:
            Base64 encoded signature.

        Raises:
            YubiKeyError: If hardware signing fails.
            NotImplementedError: If hardware signing not yet implemented.
        """
        # Hardware YubiKey signing not yet implemented
        # Block production usage until FIDO2/PIV signing is implemented
        raise NotImplementedError(
            "Hardware YubiKey signing not yet implemented. "
            "Production deployment requires this feature. "
            "Please implement FIDO2 or PIV signing before production use."
        )

    def _sign_with_software_key(self, month: str, private_key_path: str | None = None) -> str:
        """Sign with software key (development/testing only).

        Args:
            month: Month in YYYY-MM format.
            private_key_path: Optional path to private key file.

        Returns:
            Base64 encoded signature.

        Raises:
            YubiKeyError: If signing fails.
        """
        try:
            from nacl.signing import SigningKey

            if private_key_path:
                # Load key from file
                with open(private_key_path, "rb") as f:
                    key_data = f.read()
                    if key_data.startswith(b"-----"):
                        # PEM format - not implemented yet
                        raise YubiKeyError("PEM format not yet supported")
                    private_key = base64.b64decode(key_data)
                signing_key = SigningKey(private_key)
                method = "file"
            else:
                # Generate temporary key for testing
                logger.warning(
                    "Using generated temporary key - FOR TESTING ONLY",
                    month=month,
                    environment=settings.app_env,
                )
                signing_key = SigningKey.generate()
                method = "temp"

            data = f"monthly-activation:{month}".encode()
            signed = signing_key.sign(data)

            signature = base64.b64encode(signed.signature).decode()

            logger.info(
                "Monthly activation signed",
                month=month,
                method=method,
                environment=settings.app_env,
            )

            return signature

        except ImportError as e:
            raise YubiKeyError("PyNaCl not installed. Run: pip install pynacl") from e
        except YubiKeyError:
            raise
        except Exception as e:
            raise YubiKeyError(f"Signing failed: {e}") from e

    def verify_yubikey_present(self) -> None:
        """Verify YubiKey is present and ready.

        Raises:
            YubiKeyError: If YubiKey not detected.
        """
        if not self.is_available():
            raise YubiKeyError("No YubiKey detected. Please insert YubiKey and try again.")

    def prompt_touch(self) -> None:
        """Display prompt to touch YubiKey."""
        print("\n🔐 Touch your YubiKey to sign...\n")

    async def sign_monthly_interactive(self, month: str) -> str:
        """Sign monthly activation with user interaction.

        Args:
            month: Month in YYYY-MM format.

        Returns:
            Base64 encoded signature.
        """
        self.verify_yubikey_present()
        self.prompt_touch()

        # For production, would wait for YubiKey touch
        # For now, sign immediately
        return self.sign_monthly(month)


def get_current_month() -> str:
    """Get current month in YYYY-MM format.

    Returns:
        Current month string.
    """
    return datetime.now(UTC).strftime("%Y-%m")


def get_next_month() -> str:
    """Get next month in YYYY-MM format.

    Returns:
        Next month string.
    """
    now = datetime.now(UTC)
    if now.month == 12:
        return f"{now.year + 1}-01"
    return f"{now.year}-{now.month + 1:02d}"
