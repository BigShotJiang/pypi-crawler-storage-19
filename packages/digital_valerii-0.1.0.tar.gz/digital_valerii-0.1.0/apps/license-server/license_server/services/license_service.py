"""License management service.

Component 4.10: Licensing & Protection System
Core business logic for license operations.
"""

import hashlib
import hmac
import secrets
import time
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

import structlog
from sqlalchemy import delete, func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import settings
from ..models import License, MonthlySignature, SecurityEvent, UsageLog
from ..schemas import (
    LicenseCreate,
    LicenseHeartbeatResponse,
    LicenseListResponse,
    LicenseResponse,
    LicenseUpdate,
    LicenseValidateResponse,
    MonthlySignatureResponse,
    SecurityEventListResponse,
    SecurityEventResponse,
    ServerStatusResponse,
    UsageLogResponse,
)
from .signature_service import SignatureService

logger = structlog.get_logger(__name__)


class LicenseError(Exception):
    """Base exception for license operations."""

    pass


class LicenseService:
    """Service for license management operations."""

    def __init__(self, db: AsyncSession | None = None) -> None:
        """Initialize license service.

        Args:
            db: Database session (if None, will be injected per-request).
        """
        self._db = db
        self._signature_service = SignatureService()

    async def _get_db(self) -> AsyncSession:
        """Get database session."""
        if self._db is None:
            # In production, this would come from dependency injection
            raise RuntimeError("Database session not configured")
        return self._db

    # Request signature replay protection window (5 minutes)
    REQUEST_SIGNATURE_MAX_AGE = 300

    async def _verify_request_signature(
        self,
        agent_id: str,
        client_id: str,
        signature: str,
        timestamp: int,
    ) -> bool:
        """Verify request signature using HMAC with shared secret.

        Args:
            agent_id: Agent identifier.
            client_id: Client identifier.
            signature: HMAC-SHA256 signature hex string.
            timestamp: Unix timestamp from request.

        Returns:
            True if signature is valid and request is not replayed.
        """
        # Check timestamp is within acceptable window (prevent replay attacks)
        current_time = int(time.time())
        if abs(current_time - timestamp) > self.REQUEST_SIGNATURE_MAX_AGE:
            logger.warning(
                "Request timestamp outside acceptable window",
                client_id=client_id,
                timestamp=timestamp,
                current_time=current_time,
            )
            return False

        # Get shared secret for this client from DB
        db = await self._get_db()
        result = await db.execute(select(License).where(License.client_id == client_id))
        license = result.scalar_one_or_none()

        if not license:
            logger.warning("License not found for signature verification", client_id=client_id)
            return False

        if not license.shared_secret:
            # In production, shared secret is required
            if settings.app_env == "production":
                logger.warning(
                    "No shared secret configured for client in production",
                    client_id=client_id,
                )
                return False
            # In dev/test, fall back to SHA256 for backwards compatibility
            logger.warning(
                "No shared secret - using fallback signature (dev/test only)",
                client_id=client_id,
            )
            message = f"{agent_id}:{client_id}:{timestamp}"
            expected_signature = hashlib.sha256(message.encode()).hexdigest()
        else:
            # Use HMAC with shared secret
            message = f"{agent_id}:{client_id}:{timestamp}"
            expected_signature = hmac.new(
                license.shared_secret.encode(),
                message.encode(),
                hashlib.sha256,
            ).hexdigest()

        # Constant-time comparison to prevent timing attacks
        if not hmac.compare_digest(signature, expected_signature):
            logger.warning(
                "Request signature mismatch",
                client_id=client_id,
            )
            return False

        return True

    # =========================================================================
    # License Validation (Public API)
    # =========================================================================

    async def validate_license(
        self,
        agent_id: str,
        client_id: str,
        signature: str,
        timestamp: int,
    ) -> LicenseValidateResponse:
        """Validate a license for an agent.

        Args:
            agent_id: Agent identifier.
            client_id: Client identifier from license.
            signature: Request signature (HMAC-SHA256 hex).
            timestamp: Unix timestamp for replay protection.

        Returns:
            Validation response with license details.
        """
        await logger.ainfo(
            "Validating license",
            agent_id=agent_id,
            client_id=client_id,
        )

        # 1. Verify request signature (HMAC with shared secret)
        if not await self._verify_request_signature(agent_id, client_id, signature, timestamp):
            await logger.awarning(
                "Invalid request signature",
                client_id=client_id,
                agent_id=agent_id,
            )
            return LicenseValidateResponse(
                valid=False,
                message="Invalid request signature",
            )

        # Check monthly signature (Dead Man's Switch)
        monthly_valid = await self._check_monthly_signature()
        if not monthly_valid:
            await logger.awarning(
                "Monthly signature invalid or expired",
                client_id=client_id,
            )
            # Check grace period
            grace_status = await self._get_grace_status()
            if grace_status == "expired":
                return LicenseValidateResponse(
                    valid=False,
                    message="License server activation expired. Contact administrator.",
                )

        # Get license
        db = await self._get_db()
        result = await db.execute(select(License).where(License.client_id == client_id))
        license = result.scalar_one_or_none()

        if not license:
            await logger.awarning(
                "License not found",
                client_id=client_id,
            )
            return LicenseValidateResponse(
                valid=False,
                message="License not found",
            )

        # Check status
        if license.status == "revoked":
            return LicenseValidateResponse(
                valid=False,
                message="License has been revoked",
            )

        if license.status == "suspended":
            return LicenseValidateResponse(
                valid=False,
                message="License is suspended. Contact support.",
            )

        # Check expiration
        now = datetime.now(UTC)
        if license.expires_at < now:
            # Check grace period
            if license.is_in_grace_period:
                return LicenseValidateResponse(
                    valid=True,
                    expires=license.expires_at,
                    features=license.features,
                    tier=license.tier,
                    worker_count=license.worker_count,
                    in_grace_period=True,
                    message="License expired but in grace period. Please renew.",
                )
            return LicenseValidateResponse(
                valid=False,
                message="License has expired",
            )

        # 2. Verify license Ed25519 signature (if license has stored signature)
        if license.signature and not self._signature_service.verify_license_signature(
            license_id=str(license.id),
            client_id=license.client_id,
            expires_at=license.expires_at,
            signature=license.signature,
        ):
            await logger.awarning(
                "License signature verification failed",
                client_id=client_id,
                license_id=str(license.id),
            )
            return LicenseValidateResponse(
                valid=False,
                message="License signature verification failed",
            )

        await logger.ainfo(
            "License validated successfully",
            client_id=client_id,
            tier=license.tier,
        )

        return LicenseValidateResponse(
            valid=True,
            expires=license.expires_at,
            features=license.features,
            tier=license.tier,
            worker_count=license.worker_count,
        )

    async def process_heartbeat(
        self,
        agent_id: str,
        usage_metrics: dict[str, Any] | None,
    ) -> LicenseHeartbeatResponse:
        """Process a heartbeat from an agent.

        Args:
            agent_id: Agent identifier.
            usage_metrics: Optional usage metrics.

        Returns:
            Heartbeat response.
        """
        # Log usage if provided
        if usage_metrics:
            # In production, would log to usage_log table
            await logger.ainfo(
                "Agent heartbeat received",
                agent_id=agent_id,
                metrics=usage_metrics,
            )

        # Check if server is still active
        monthly_valid = await self._check_monthly_signature()
        if not monthly_valid:
            grace_status = await self._get_grace_status()
            if grace_status == "expired":
                return LicenseHeartbeatResponse(
                    continue_operation=False,
                    message="License server deactivated",
                )
            elif grace_status == "warning":
                return LicenseHeartbeatResponse(
                    continue_operation=True,
                    message="License server activation expiring soon",
                )

        return LicenseHeartbeatResponse(
            continue_operation=True,
            message=None,
        )

    # =========================================================================
    # Monthly Signature (Dead Man's Switch)
    # =========================================================================

    async def _check_monthly_signature(self) -> bool:
        """Check if current month has valid signature.

        Returns:
            True only if:
            1. Signature exists for current month
            2. Signature verifies against pinned public key
        """
        current_month = datetime.now(UTC).strftime("%Y-%m")

        try:
            db = await self._get_db()
            result = await db.execute(
                select(MonthlySignature).where(MonthlySignature.month == current_month)
            )
            signature = result.scalar_one_or_none()

            if not signature:
                return False

            # VERIFY against pinned public key - not just check presence!
            import base64

            sig_base64 = base64.b64encode(signature.signature).decode()
            is_valid = self._signature_service.verify_monthly_signature(
                month=current_month,
                signature=sig_base64,
            )

            if not is_valid:
                await logger.awarning(
                    "Monthly signature verification failed",
                    month=current_month,
                )

            return is_valid
        except Exception as e:
            # In production, fail closed - don't allow operation without valid signature
            if settings.app_env == "production":
                await logger.aerror(
                    "Monthly signature check failed in production",
                    error=str(e),
                )
                return False
            # In development, log warning but allow
            logger.warning("Monthly signature check failed", error=str(e))
            return True

    async def _get_grace_status(self) -> str:
        """Get grace period status.

        Returns:
            "active" if within grace period
            "warning" if approaching end
            "expired" if past grace period
        """
        # Get last signature
        try:
            db = await self._get_db()
            result = await db.execute(
                select(MonthlySignature).order_by(MonthlySignature.signed_at.desc()).limit(1)
            )
            last_sig = result.scalar_one_or_none()

            if not last_sig:
                return "expired"

            # Calculate days since last signature
            now = datetime.now(UTC)
            days_since = (now - last_sig.signed_at).days

            grace_days = settings.monthly_signature_grace_days
            if days_since > 30 + grace_days:
                return "expired"
            elif days_since > 30 + (grace_days // 2):
                return "warning"
            return "active"
        except Exception:
            return "active"  # Fail open if DB unavailable

    async def sign_monthly(
        self,
        month: str,
        signature: str,
        signed_by: str,
    ) -> MonthlySignatureResponse:
        """Record monthly signature.

        Args:
            month: Month in YYYY-MM format.
            signature: Base64 encoded signature.
            signed_by: Identifier of signer.

        Returns:
            Signature response.
        """
        db = await self._get_db()

        # Verify signature format
        try:
            import base64

            sig_bytes = base64.b64decode(signature)
        except Exception as e:
            raise LicenseError("Invalid signature format") from e

        # Check for existing signature
        result = await db.execute(select(MonthlySignature).where(MonthlySignature.month == month))
        existing = result.scalar_one_or_none()

        if existing:
            # Update existing
            existing.signature = sig_bytes
            existing.signed_at = datetime.now(UTC)
            existing.signed_by = signed_by
        else:
            # Create new
            sig = MonthlySignature(
                month=month,
                signature=sig_bytes,
                signed_by=signed_by,
            )
            db.add(sig)

        await db.commit()

        await logger.ainfo(
            "Monthly signature recorded",
            month=month,
            signed_by=signed_by,
        )

        return MonthlySignatureResponse(
            success=True,
            month=month,
            signed_at=datetime.now(UTC),
            message="License server activated for " + month,
        )

    async def get_server_status(self) -> ServerStatusResponse:
        """Get license server status."""
        current_month = datetime.now(UTC).strftime("%Y-%m")
        monthly_valid = await self._check_monthly_signature()
        grace_status = await self._get_grace_status()

        # Count licenses
        db = await self._get_db()
        total_result = await db.execute(select(func.count(License.id)))
        total = total_result.scalar() or 0

        active_result = await db.execute(
            select(func.count(License.id)).where(License.status == "active")
        )
        active = active_result.scalar() or 0

        # Determine status
        if monthly_valid:
            status = "active"
            days_until = None
        elif grace_status == "active":
            status = "grace_period"
            days_until = settings.monthly_signature_grace_days
        elif grace_status == "warning":
            status = "warning"
            days_until = settings.monthly_signature_grace_days // 2
        else:
            status = "inactive"
            days_until = 0

        return ServerStatusResponse(
            status=status,
            current_month=current_month,
            monthly_signature_valid=monthly_valid,
            days_until_expiry=days_until,
            total_licenses=total,
            active_licenses=active,
        )

    # =========================================================================
    # License CRUD (Admin API)
    # =========================================================================

    async def list_licenses(
        self,
        page: int,
        page_size: int,
        status_filter: str | None = None,
    ) -> LicenseListResponse:
        """List licenses with pagination."""
        db = await self._get_db()

        # Build query
        query = select(License)
        count_query = select(func.count(License.id))

        if status_filter:
            query = query.where(License.status == status_filter)
            count_query = count_query.where(License.status == status_filter)

        # Get total
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        # Get page
        offset = (page - 1) * page_size
        query = query.offset(offset).limit(page_size).order_by(License.created_at.desc())
        result = await db.execute(query)
        licenses = result.scalars().all()

        # Build response items with shared_secret cleared (never expose on list)
        items = []
        for lic in licenses:
            response = LicenseResponse.model_validate(lic)
            response.shared_secret = None
            items.append(response)

        return LicenseListResponse(
            items=items,
            total=total,
            page=page,
            page_size=page_size,
        )

    async def create_license(self, data: LicenseCreate) -> LicenseResponse:
        """Create a new license with auto-generated shared secret."""
        db = await self._get_db()

        # Generate a cryptographically secure shared secret (64 character hex string)
        shared_secret = secrets.token_hex(32)

        license = License(
            client_id=data.client_id,
            client_name=data.client_name,
            tier=data.tier,
            worker_count=data.worker_count,
            features=data.features,
            expires_at=data.expires_at,
            grace_period_days=data.grace_period_days,
            status="active",
            shared_secret=shared_secret,
        )

        db.add(license)

        try:
            await db.commit()
            await db.refresh(license)
        except IntegrityError as e:
            await db.rollback()
            raise LicenseError(f"License with client_id '{data.client_id}' already exists") from e

        await logger.ainfo(
            "License created",
            client_id=data.client_id,
            tier=data.tier,
        )

        # Return response with shared_secret (only returned on creation)
        response = LicenseResponse.model_validate(license)
        response.shared_secret = shared_secret
        return response

    async def get_license(self, license_id: UUID) -> LicenseResponse | None:
        """Get a license by ID."""
        db = await self._get_db()
        result = await db.execute(select(License).where(License.id == str(license_id)))
        license = result.scalar_one_or_none()
        if license:
            response = LicenseResponse.model_validate(license)
            response.shared_secret = None  # Never expose on get
            return response
        return None

    async def update_license(
        self,
        license_id: UUID,
        data: LicenseUpdate,
    ) -> LicenseResponse | None:
        """Update a license."""
        db = await self._get_db()

        result = await db.execute(select(License).where(License.id == str(license_id)))
        license = result.scalar_one_or_none()

        if not license:
            return None

        # Update fields
        update_data = data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(license, field, value)

        license.updated_at = datetime.now(UTC)
        await db.commit()
        await db.refresh(license)

        await logger.ainfo(
            "License updated",
            license_id=str(license_id),
            updates=list(update_data.keys()),
        )

        response = LicenseResponse.model_validate(license)
        response.shared_secret = None  # Never expose on update
        return response

    async def delete_license(self, license_id: UUID) -> bool:
        """Delete a license."""
        db = await self._get_db()

        result = await db.execute(delete(License).where(License.id == str(license_id)))
        await db.commit()

        deleted = bool(result.rowcount and result.rowcount > 0)
        if deleted:
            await logger.ainfo("License deleted", license_id=str(license_id))

        return deleted

    async def revoke_license(self, license_id: UUID, reason: str) -> bool:
        """Revoke a license."""
        db = await self._get_db()

        result = await db.execute(
            update(License)
            .where(License.id == str(license_id))
            .values(status="revoked", updated_at=datetime.now(UTC))
        )
        await db.commit()

        if result.rowcount > 0:
            # Log security event
            await self.log_security_event(
                license_id=license_id,
                event_type="license_revoked",
                details={"reason": reason},
                severity="warning",
            )
            await logger.awarning(
                "License revoked",
                license_id=str(license_id),
                reason=reason,
            )
            return True

        return False

    # =========================================================================
    # Usage & Security Logging
    # =========================================================================

    async def log_security_event(
        self,
        license_id: UUID | None,
        event_type: str,
        details: dict[str, Any] | None,
        severity: str = "info",
    ) -> None:
        """Log a security event."""
        try:
            db = await self._get_db()
            event = SecurityEvent(
                license_id=str(license_id) if license_id else None,
                event_type=event_type,
                details=details,
                severity=severity,
            )
            db.add(event)
            await db.commit()
        except Exception as e:
            await logger.aerror(
                "Failed to log security event",
                error=str(e),
            )

    async def get_usage_logs(
        self,
        license_id: UUID,
        limit: int = 100,
    ) -> list[UsageLogResponse]:
        """Get usage logs for a license."""
        db = await self._get_db()
        result = await db.execute(
            select(UsageLog)
            .where(UsageLog.license_id == str(license_id))
            .order_by(UsageLog.timestamp.desc())
            .limit(limit)
        )
        logs = result.scalars().all()
        return [UsageLogResponse.model_validate(log) for log in logs]

    async def get_security_events(
        self,
        severity: str | None = None,
        limit: int = 100,
    ) -> SecurityEventListResponse:
        """Get security events."""
        db = await self._get_db()

        query = select(SecurityEvent).order_by(SecurityEvent.created_at.desc())
        if severity:
            query = query.where(SecurityEvent.severity == severity)
        query = query.limit(limit)

        result = await db.execute(query)
        events = result.scalars().all()

        count_query = select(func.count(SecurityEvent.id))
        if severity:
            count_query = count_query.where(SecurityEvent.severity == severity)
        total_result = await db.execute(count_query)
        total = total_result.scalar() or 0

        return SecurityEventListResponse(
            items=[SecurityEventResponse.model_validate(e) for e in events],
            total=total,
        )
