"""License Server configuration.

Component 4.10: Licensing & Protection System
"""

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """License Server settings from environment."""

    # Application
    app_name: str = "Digital Valerii License Server"
    app_env: str = Field(default="development", validation_alias="APP_ENV")
    debug: bool = Field(default=True, validation_alias="DEBUG")
    log_level: str = Field(default="DEBUG", validation_alias="LOG_LEVEL")

    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/license_server",
        validation_alias="DATABASE_URL",
    )

    @field_validator("database_url", mode="after")
    @classmethod
    def ensure_asyncpg_driver(cls, v: str) -> str:
        """Ensure database URL uses asyncpg driver for async SQLAlchemy."""
        if v.startswith("postgresql://"):
            return v.replace("postgresql://", "postgresql+asyncpg://", 1)
        return v

    # API
    api_v1_prefix: str = "/api/v1"
    cors_origins: list[str] = Field(
        default=["http://localhost:3000", "https://admin.tripletree.ca"],
        validation_alias="CORS_ORIGINS",
    )

    # Security
    max_request_size_bytes: int = Field(default=1_000_000)
    admin_api_key: str = Field(default="", validation_alias="ADMIN_API_KEY")
    jwt_secret_key: str = Field(default="", validation_alias="JWT_SECRET_KEY")
    jwt_algorithm: str = "HS256"
    jwt_expiry_hours: int = 24

    # License Server Specific
    license_server_public_key: str = Field(
        default="",
        validation_alias="LICENSE_SERVER_PUBLIC_KEY",
        description="Ed25519 public key for license verification (base64)",
    )
    license_server_private_key: str = Field(
        default="",
        validation_alias="LICENSE_SERVER_PRIVATE_KEY",
        description="Ed25519 private key for license signing (base64)",
    )

    # Dead Man's Switch
    monthly_signature_grace_days: int = Field(
        default=14,
        description="Days to allow operation without monthly signature",
    )

    model_config = {
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @model_validator(mode="after")
    def validate_production_settings(self) -> "Settings":
        """Validate required settings in production."""
        if self.app_env == "production":
            if not self.admin_api_key:
                raise ValueError("ADMIN_API_KEY required in production")
            if not self.jwt_secret_key:
                raise ValueError("JWT_SECRET_KEY required in production")
            if not self.license_server_private_key:
                raise ValueError("LICENSE_SERVER_PRIVATE_KEY required in production")
        return self


settings = Settings()
