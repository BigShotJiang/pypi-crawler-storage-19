"""License Server signing CLI commands.

Component 4.10: Licensing & Protection System

CLI for managing License Server monthly activations.
"""

import sys
from datetime import UTC, datetime

import click
import httpx

from ..services.yubikey_service import (
    YubiKeyError,
    YubiKeyService,
    get_current_month,
)


@click.group()
def cli() -> None:
    """Digital Valerii License Server CLI."""
    pass


@cli.command("sign-monthly")
@click.option(
    "--month",
    default=None,
    help="Month to sign (YYYY-MM format). Defaults to current month.",
)
@click.option(
    "--key-file",
    default=None,
    type=click.Path(exists=True),
    help="Path to Ed25519 private key file.",
)
@click.option(
    "--server-url",
    default="http://localhost:8000",
    help="License server URL.",
)
def sign_monthly(month: str | None, key_file: str | None, server_url: str) -> None:
    """Sign License Server for a month.

    This activates the License Server for the specified month,
    enabling all license validation requests.

    Without a valid monthly signature, the server enters grace period
    and eventually stops validating licenses.
    """
    if month is None:
        month = get_current_month()

    click.echo(f"\n🔐 Signing License Server for {month}")
    click.echo("-" * 40)

    yubikey = YubiKeyService()

    # Check for YubiKey
    if yubikey.is_available():
        device_info = yubikey.get_device_info()
        if device_info:
            click.echo(f"✅ YubiKey detected: {device_info.get('product_name', 'Unknown')}")
    else:
        click.echo("⚠️  No YubiKey detected, using software signing")

    try:
        # Sign the month
        signature = yubikey.sign_monthly(month, key_file)
        click.echo("✅ Signature generated")

        # Submit to server
        click.echo(f"\n📤 Submitting to License Server at {server_url}")
        response = httpx.post(
            f"{server_url}/api/v1/admin/monthly-sign",
            json={
                "month": month,
                "signature": signature,
                "signed_by": "cli-user",
            },
            timeout=10.0,
        )

        if response.status_code == 200:
            data = response.json()
            click.echo(f"\n✅ {data.get('message', 'License Server activated')}")
            click.echo(f"   Month: {month}")
            click.echo(f"   Signed at: {datetime.now(UTC).isoformat()}")
        else:
            click.echo(f"\n❌ Server error: {response.text}", err=True)
            sys.exit(1)

    except YubiKeyError as e:
        click.echo(f"\n❌ YubiKey error: {e}", err=True)
        sys.exit(1)
    except httpx.RequestError as e:
        click.echo(f"\n❌ Connection error: {e}", err=True)
        sys.exit(1)


@cli.command("server-status")
@click.option(
    "--server-url",
    default="http://localhost:8000",
    help="License server URL.",
)
def server_status(server_url: str) -> None:
    """Check License Server status.

    Shows current activation status, license counts,
    and monthly signature validity.
    """
    click.echo("\n📊 License Server Status")
    click.echo("-" * 40)

    try:
        response = httpx.get(
            f"{server_url}/api/v1/admin/status",
            timeout=10.0,
        )

        if response.status_code == 200:
            data = response.json()

            status = data.get("status", "unknown")
            status_emoji = {
                "active": "🟢",
                "grace_period": "🟡",
                "warning": "🟠",
                "inactive": "🔴",
            }.get(status, "⚪")

            click.echo(f"Status: {status_emoji} {status.upper()}")
            click.echo(f"Current Month: {data.get('current_month', 'N/A')}")
            click.echo(
                f"Monthly Signature: {'✅ Valid' if data.get('monthly_signature_valid') else '❌ Invalid'}"
            )

            if data.get("days_until_expiry") is not None:
                click.echo(f"Days Until Expiry: {data.get('days_until_expiry')}")

            click.echo("\nLicenses:")
            click.echo(f"  Total: {data.get('total_licenses', 0)}")
            click.echo(f"  Active: {data.get('active_licenses', 0)}")

        else:
            click.echo(f"\n❌ Server error: {response.text}", err=True)
            sys.exit(1)

    except httpx.RequestError as e:
        click.echo(f"\n❌ Connection error: {e}", err=True)
        sys.exit(1)


@cli.command("generate-keys")
@click.option(
    "--output-dir",
    default=".",
    type=click.Path(file_okay=False),
    help="Directory to save keys.",
)
def generate_keys(output_dir: str) -> None:
    """Generate Ed25519 keypair for license signing.

    Generates a new keypair and saves:
    - public.key (share with clients)
    - private.key (keep secret, use for signing)
    """
    from pathlib import Path

    try:
        import base64

        from nacl.signing import SigningKey

        click.echo("\n🔑 Generating Ed25519 keypair...")

        # Generate keypair
        signing_key = SigningKey.generate()
        private_key = bytes(signing_key)
        public_key = bytes(signing_key.verify_key)

        # Encode to base64
        private_b64 = base64.b64encode(private_key).decode()
        public_b64 = base64.b64encode(public_key).decode()

        # Save to files
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        (output_path / "private.key").write_text(private_b64)
        (output_path / "public.key").write_text(public_b64)

        click.echo("\n✅ Keys generated!")
        click.echo(f"   Private key: {output_path / 'private.key'}")
        click.echo(f"   Public key: {output_path / 'public.key'}")
        click.echo("\n⚠️  Keep private.key SECRET! Only share public.key.")

    except ImportError:
        click.echo("❌ PyNaCl not installed. Run: pip install pynacl", err=True)
        sys.exit(1)


@cli.command("check-yubikey")
def check_yubikey() -> None:
    """Check if YubiKey is connected and ready."""
    click.echo("\n🔐 Checking for YubiKey...")

    yubikey = YubiKeyService()

    if yubikey.is_available():
        device_info = yubikey.get_device_info()
        click.echo("\n✅ YubiKey detected!")
        if device_info:
            click.echo(f"   Device: {device_info.get('product_name', 'Unknown')}")
            click.echo(f"   Vendor ID: {device_info.get('vendor_id', 'N/A')}")
            click.echo(f"   Product ID: {device_info.get('product_id', 'N/A')}")
    else:
        click.echo("\n❌ No YubiKey detected.")
        click.echo("   Please insert YubiKey and try again.")
        sys.exit(1)


if __name__ == "__main__":
    cli()
