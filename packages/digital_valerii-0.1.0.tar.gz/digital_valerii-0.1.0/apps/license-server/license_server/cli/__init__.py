"""License Server CLI commands.

Component 4.10: Licensing & Protection System
"""

from .sign import cli

__all__ = ["cli"]
