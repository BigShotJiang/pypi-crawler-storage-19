"""Tests for security and signature functionality.

Component 4.10: Licensing & Protection System
"""

import pytest

from ..security.signing import decode_key, encode_key, generate_keypair, sign_data, verify_signature
from ..services.signature_service import SignatureService

# ============================================================================
# Low-level Signing Primitives
# ============================================================================


@pytest.mark.asyncio
async def test_generate_keypair():
    """Test Ed25519 keypair generation."""
    try:
        public_key, private_key = generate_keypair()
        assert len(public_key) == 32  # Ed25519 public key is 32 bytes
        assert len(private_key) == 32  # Ed25519 seed is 32 bytes
    except RuntimeError as e:
        if "PyNaCl not installed" in str(e):
            pytest.skip("PyNaCl not installed")
        raise


@pytest.mark.asyncio
async def test_sign_and_verify():
    """Test signing and verifying data."""
    try:
        public_key, private_key = generate_keypair()
        data = b"test data to sign"

        signature = sign_data(data, private_key)
        assert len(signature) == 64  # Ed25519 signature is 64 bytes

        is_valid = verify_signature(data, signature, public_key)
        assert is_valid is True
    except RuntimeError as e:
        if "PyNaCl not installed" in str(e):
            pytest.skip("PyNaCl not installed")
        raise


@pytest.mark.asyncio
async def test_verify_invalid_signature():
    """Test that invalid signatures are rejected."""
    try:
        public_key, private_key = generate_keypair()
        data = b"test data to sign"
        wrong_data = b"different data"

        signature = sign_data(data, private_key)
        is_valid = verify_signature(wrong_data, signature, public_key)
        assert is_valid is False
    except RuntimeError as e:
        if "PyNaCl not installed" in str(e):
            pytest.skip("PyNaCl not installed")
        raise


@pytest.mark.asyncio
async def test_key_encoding():
    """Test key encoding and decoding."""
    try:
        public_key, private_key = generate_keypair()

        # Encode and decode public key
        encoded = encode_key(public_key)
        decoded = decode_key(encoded)
        assert decoded == public_key

        # Encode and decode private key
        encoded_priv = encode_key(private_key)
        decoded_priv = decode_key(encoded_priv)
        assert decoded_priv == private_key
    except RuntimeError as e:
        if "PyNaCl not installed" in str(e):
            pytest.skip("PyNaCl not installed")
        raise


# ============================================================================
# SignatureService
# ============================================================================


@pytest.mark.asyncio
async def test_signature_service_generate_keypair():
    """Test SignatureService keypair generation."""
    try:
        public_key, private_key = SignatureService.generate_keypair()
        assert isinstance(public_key, str)
        assert isinstance(private_key, str)
        # Base64 encoded keys should be longer than raw bytes
        assert len(public_key) > 32
        assert len(private_key) > 32
    except Exception as e:
        if "PyNaCl not installed" in str(e):
            pytest.skip("PyNaCl not installed")
        raise


@pytest.mark.asyncio
async def test_signature_service_no_key_configured():
    """Test SignatureService fails gracefully without keys."""
    service = SignatureService()
    # Without keys, should raise SignatureError
    from ..services.signature_service import SignatureError

    with pytest.raises(SignatureError):
        service.sign_data(b"test data")


@pytest.mark.asyncio
async def test_signature_service_verify_without_key():
    """Test verification returns True without public key (fail open in dev)."""
    service = SignatureService()
    # Without public key, should return True (fail open in development)
    result = service.verify_signature(b"test data", b"fake signature")
    assert result is True


# ============================================================================
# Monthly Signature
# ============================================================================


@pytest.mark.asyncio
async def test_monthly_signature_format():
    """Test monthly signature data format."""
    month = "2025-01"
    expected_data = f"monthly-activation:{month}".encode()
    assert expected_data == b"monthly-activation:2025-01"


@pytest.mark.asyncio
async def test_license_signature_format():
    """Test license signature data format."""
    from datetime import UTC, datetime

    license_id = "550e8400-e29b-41d4-a716-446655440000"
    client_id = "test-client-001"
    expires_at = datetime(2025, 12, 31, 23, 59, 59, tzinfo=UTC)

    expected_data = f"{license_id}:{client_id}:{expires_at.isoformat()}".encode()
    assert license_id.encode() in expected_data
    assert client_id.encode() in expected_data
