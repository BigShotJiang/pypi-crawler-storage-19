"""Test fixtures for License Server.

Component 4.10: Licensing & Protection System
"""

import asyncio
from collections.abc import AsyncGenerator
from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from ..config import Settings
from ..database import get_db
from ..main import create_app
from ..models import Base, License


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for session-scoped async fixtures."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def test_settings() -> Settings:
    """Create test settings."""
    return Settings(
        app_env="test",
        debug=True,
        database_url="sqlite+aiosqlite:///:memory:",
        admin_api_key="test-admin-key",
        jwt_secret_key="test-jwt-secret-key-for-testing-only",
        license_server_public_key="",
        license_server_private_key="",
    )


@pytest_asyncio.fixture
async def db_engine(test_settings: Settings):
    """Create test database engine."""
    engine = create_async_engine(
        test_settings.database_url,
        echo=False,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(db_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create test database session."""
    session_factory = async_sessionmaker(
        db_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with session_factory() as session:
        yield session


@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Create test client with overridden dependencies."""
    app = create_app()

    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client


@pytest_asyncio.fixture
async def sample_license(db_session: AsyncSession) -> License:
    """Create a sample license for testing."""
    license = License(
        id=str(uuid4()),
        client_id="test-client-001",
        client_name="Test Client",
        tier="professional",
        worker_count=10,
        features=["basic", "api", "analytics"],
        expires_at=datetime.now(UTC) + timedelta(days=365),
        grace_period_days=14,
        status="active",
    )
    db_session.add(license)
    await db_session.commit()
    await db_session.refresh(license)
    return license


@pytest_asyncio.fixture
async def expired_license(db_session: AsyncSession) -> License:
    """Create an expired license for testing."""
    license = License(
        id=str(uuid4()),
        client_id="expired-client-001",
        client_name="Expired Client",
        tier="starter",
        worker_count=2,
        features=["basic"],
        expires_at=datetime.now(UTC) - timedelta(days=30),
        grace_period_days=14,
        status="active",
    )
    db_session.add(license)
    await db_session.commit()
    await db_session.refresh(license)
    return license


@pytest_asyncio.fixture
async def revoked_license(db_session: AsyncSession) -> License:
    """Create a revoked license for testing."""
    license = License(
        id=str(uuid4()),
        client_id="revoked-client-001",
        client_name="Revoked Client",
        tier="professional",
        worker_count=5,
        features=["basic", "api"],
        expires_at=datetime.now(UTC) + timedelta(days=180),
        grace_period_days=14,
        status="revoked",
    )
    db_session.add(license)
    await db_session.commit()
    await db_session.refresh(license)
    return license
