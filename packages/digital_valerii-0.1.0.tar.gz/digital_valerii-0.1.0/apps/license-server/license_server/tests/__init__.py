"""License Server tests."""
