"""Tests for License Server endpoints.

Component 4.10: Licensing & Protection System
"""

from datetime import UTC, datetime, timedelta

import pytest
from httpx import AsyncClient

from ..models import License

# ============================================================================
# Health Endpoints
# ============================================================================


@pytest.mark.asyncio
async def test_health_endpoint(client: AsyncClient):
    """Test health endpoint returns OK."""
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "timestamp" in data


@pytest.mark.asyncio
async def test_health_ready_endpoint(client: AsyncClient):
    """Test readiness endpoint."""
    response = await client.get("/health/ready")
    assert response.status_code == 200
    data = response.json()
    assert data["ready"] is True


@pytest.mark.asyncio
async def test_root_endpoint(client: AsyncClient):
    """Test root endpoint returns app info."""
    response = await client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert "version" in data
    assert data["status"] == "operational"


# ============================================================================
# License Validation
# ============================================================================


@pytest.mark.asyncio
async def test_validate_license_success(client: AsyncClient, sample_license: License):
    """Test successful license validation."""
    response = await client.post(
        "/api/v1/license/validate",
        json={
            "agent_id": "test-agent-001",
            "client_id": sample_license.client_id,
            "signature": "test-signature",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is True
    assert data["tier"] == "professional"
    assert data["worker_count"] == 10


@pytest.mark.asyncio
async def test_validate_license_not_found(client: AsyncClient):
    """Test validation with non-existent license."""
    response = await client.post(
        "/api/v1/license/validate",
        json={
            "agent_id": "test-agent-001",
            "client_id": "non-existent-client",
            "signature": "test-signature",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is False
    assert "not found" in data["message"].lower()


@pytest.mark.asyncio
async def test_validate_expired_license(client: AsyncClient, expired_license: License):
    """Test validation of expired license."""
    response = await client.post(
        "/api/v1/license/validate",
        json={
            "agent_id": "test-agent-001",
            "client_id": expired_license.client_id,
            "signature": "test-signature",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is False
    assert "expired" in data["message"].lower()


@pytest.mark.asyncio
async def test_validate_revoked_license(client: AsyncClient, revoked_license: License):
    """Test validation of revoked license."""
    response = await client.post(
        "/api/v1/license/validate",
        json={
            "agent_id": "test-agent-001",
            "client_id": revoked_license.client_id,
            "signature": "test-signature",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["valid"] is False
    assert "revoked" in data["message"].lower()


# ============================================================================
# Heartbeat
# ============================================================================


@pytest.mark.asyncio
async def test_heartbeat_success(client: AsyncClient):
    """Test successful heartbeat."""
    response = await client.post(
        "/api/v1/license/heartbeat",
        json={
            "agent_id": "test-agent-001",
            "usage_metrics": {
                "requests": 100,
                "tokens_in": 5000,
                "tokens_out": 3000,
            },
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["continue_operation"] is True


@pytest.mark.asyncio
async def test_heartbeat_without_metrics(client: AsyncClient):
    """Test heartbeat without usage metrics."""
    response = await client.post(
        "/api/v1/license/heartbeat",
        json={
            "agent_id": "test-agent-001",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["continue_operation"] is True


# ============================================================================
# Admin - License CRUD
# ============================================================================


@pytest.mark.asyncio
async def test_list_licenses_empty(client: AsyncClient):
    """Test listing licenses when none exist."""
    response = await client.get("/api/v1/admin/licenses")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 0
    assert data["items"] == []


@pytest.mark.asyncio
async def test_list_licenses_with_data(client: AsyncClient, sample_license: License):
    """Test listing licenses with data."""
    response = await client.get("/api/v1/admin/licenses")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] >= 1


@pytest.mark.asyncio
async def test_create_license(client: AsyncClient):
    """Test creating a new license."""
    response = await client.post(
        "/api/v1/admin/licenses",
        json={
            "client_id": "new-client-001",
            "client_name": "New Test Client",
            "tier": "enterprise",
            "worker_count": 50,
            "features": ["basic", "api", "analytics", "premium"],
            "expires_at": (datetime.now(UTC) + timedelta(days=365)).isoformat(),
            "grace_period_days": 30,
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["client_id"] == "new-client-001"
    assert data["tier"] == "enterprise"
    assert data["status"] == "active"


@pytest.mark.asyncio
async def test_create_duplicate_license(client: AsyncClient, sample_license: License):
    """Test creating a duplicate license fails."""
    response = await client.post(
        "/api/v1/admin/licenses",
        json={
            "client_id": sample_license.client_id,  # Duplicate
            "client_name": "Another Client",
            "tier": "starter",
            "worker_count": 1,
            "features": ["basic"],
            "expires_at": (datetime.now(UTC) + timedelta(days=30)).isoformat(),
        },
    )
    assert response.status_code == 400
    assert "already exists" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_get_license(client: AsyncClient, sample_license: License):
    """Test getting a specific license."""
    response = await client.get(f"/api/v1/admin/licenses/{sample_license.id}")
    assert response.status_code == 200
    data = response.json()
    assert data["client_id"] == sample_license.client_id


@pytest.mark.asyncio
async def test_get_license_not_found(client: AsyncClient):
    """Test getting non-existent license."""
    response = await client.get("/api/v1/admin/licenses/00000000-0000-0000-0000-000000000000")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_update_license(client: AsyncClient, sample_license: License):
    """Test updating a license."""
    response = await client.patch(
        f"/api/v1/admin/licenses/{sample_license.id}",
        json={
            "worker_count": 20,
            "features": ["basic", "api", "analytics", "premium"],
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["worker_count"] == 20
    assert "premium" in data["features"]


@pytest.mark.asyncio
async def test_revoke_license(client: AsyncClient, sample_license: License):
    """Test revoking a license."""
    response = await client.post(
        f"/api/v1/admin/licenses/{sample_license.id}/revoke",
        json={"reason": "Testing revocation"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["revoked"] is True


# ============================================================================
# Server Status
# ============================================================================


@pytest.mark.asyncio
async def test_server_status(client: AsyncClient):
    """Test server status endpoint."""
    response = await client.get("/api/v1/admin/status")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "current_month" in data
    assert "total_licenses" in data


# ============================================================================
# Security Events
# ============================================================================


@pytest.mark.asyncio
async def test_get_security_events_empty(client: AsyncClient):
    """Test getting security events when none exist."""
    response = await client.get("/api/v1/admin/security-events")
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 0
    assert data["items"] == []
