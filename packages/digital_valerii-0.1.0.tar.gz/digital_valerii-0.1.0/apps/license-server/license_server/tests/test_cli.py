"""Tests for License Server CLI.

Component 4.10: Licensing & Protection System
"""

import base64
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from license_server.cli.sign import cli

# Check if nacl is available
HAS_NACL = importlib.util.find_spec("nacl") is not None


class TestSignMonthlyCLI:
    """Tests for sign-monthly command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI runner."""
        return CliRunner()

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_default_month(self, runner: CliRunner) -> None:
        """Test sign-monthly with default month."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "License Server activated"}

        with (
            patch("license_server.cli.sign.httpx.post", return_value=mock_response),
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=False,
            ),
        ):
            result = runner.invoke(cli, ["sign-monthly"])

        assert result.exit_code == 0
        assert "Signing License Server" in result.output
        assert "activated" in result.output.lower()

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_custom_month(self, runner: CliRunner) -> None:
        """Test sign-monthly with custom month."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"message": "License Server activated"}

        with (
            patch("license_server.cli.sign.httpx.post", return_value=mock_response),
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=False,
            ),
        ):
            result = runner.invoke(cli, ["sign-monthly", "--month", "2025-06"])

        assert result.exit_code == 0
        assert "2025-06" in result.output

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_server_error(self, runner: CliRunner) -> None:
        """Test sign-monthly handles server error."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"

        with (
            patch("license_server.cli.sign.httpx.post", return_value=mock_response),
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=False,
            ),
        ):
            result = runner.invoke(cli, ["sign-monthly"])

        assert result.exit_code == 1
        assert "Server error" in result.output

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_connection_error(self, runner: CliRunner) -> None:
        """Test sign-monthly handles connection error."""
        import httpx

        with (
            patch(
                "license_server.cli.sign.httpx.post",
                side_effect=httpx.RequestError("Connection refused"),
            ),
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=False,
            ),
        ):
            result = runner.invoke(cli, ["sign-monthly"])

        assert result.exit_code == 1
        assert "Connection error" in result.output

    def test_sign_monthly_yubikey_error(self, runner: CliRunner) -> None:
        """Test sign-monthly handles YubiKey error."""
        from license_server.services.yubikey_service import YubiKeyError

        with (
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=False,
            ),
            patch(
                "license_server.cli.sign.YubiKeyService.sign_monthly",
                side_effect=YubiKeyError("Test error"),
            ),
        ):
            result = runner.invoke(cli, ["sign-monthly"])

        assert result.exit_code == 1
        assert "YubiKey error" in result.output


class TestServerStatusCLI:
    """Tests for server-status command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI runner."""
        return CliRunner()

    def test_server_status_active(self, runner: CliRunner) -> None:
        """Test server-status shows active status."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "active",
            "current_month": "2025-01",
            "monthly_signature_valid": True,
            "total_licenses": 10,
            "active_licenses": 8,
        }

        with patch("license_server.cli.sign.httpx.get", return_value=mock_response):
            result = runner.invoke(cli, ["server-status"])

        assert result.exit_code == 0
        assert "ACTIVE" in result.output
        assert "2025-01" in result.output
        assert "Valid" in result.output

    def test_server_status_grace_period(self, runner: CliRunner) -> None:
        """Test server-status shows grace period."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "grace_period",
            "current_month": "2025-01",
            "monthly_signature_valid": False,
            "days_until_expiry": 7,
            "total_licenses": 10,
            "active_licenses": 8,
        }

        with patch("license_server.cli.sign.httpx.get", return_value=mock_response):
            result = runner.invoke(cli, ["server-status"])

        assert result.exit_code == 0
        assert "GRACE_PERIOD" in result.output
        assert "7" in result.output

    def test_server_status_connection_error(self, runner: CliRunner) -> None:
        """Test server-status handles connection error."""
        import httpx

        with patch(
            "license_server.cli.sign.httpx.get",
            side_effect=httpx.RequestError("Connection refused"),
        ):
            result = runner.invoke(cli, ["server-status"])

        assert result.exit_code == 1
        assert "Connection error" in result.output

    def test_server_status_server_error(self, runner: CliRunner) -> None:
        """Test server-status handles server error."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"

        with patch("license_server.cli.sign.httpx.get", return_value=mock_response):
            result = runner.invoke(cli, ["server-status"])

        assert result.exit_code == 1
        assert "Server error" in result.output


class TestGenerateKeysCLI:
    """Tests for generate-keys command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI runner."""
        return CliRunner()

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_generate_keys_success(self, runner: CliRunner) -> None:
        """Test generate-keys creates keypair."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = runner.invoke(cli, ["generate-keys", "--output-dir", tmpdir])

            assert result.exit_code == 0
            assert "Keys generated" in result.output

            # Verify files created
            private_key = Path(tmpdir) / "private.key"
            public_key = Path(tmpdir) / "public.key"

            assert private_key.exists()
            assert public_key.exists()

            # Verify key format (base64 encoded)
            private_b64 = private_key.read_text()
            public_b64 = public_key.read_text()

            private_bytes = base64.b64decode(private_b64)
            public_bytes = base64.b64decode(public_b64)

            assert len(private_bytes) == 32  # Ed25519 private key
            assert len(public_bytes) == 32  # Ed25519 public key

    def test_generate_keys_creates_dir(self, runner: CliRunner) -> None:
        """Test generate-keys creates output directory if needed."""
        with tempfile.TemporaryDirectory() as tmpdir:
            subdir = Path(tmpdir) / "subdir" / "keys"
            result = runner.invoke(cli, ["generate-keys", "--output-dir", str(subdir)])

            # Will succeed if nacl installed
            if HAS_NACL:
                assert result.exit_code == 0
                assert subdir.exists()
            else:
                assert result.exit_code == 1


class TestCheckYubikeyCLI:
    """Tests for check-yubikey command."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI runner."""
        return CliRunner()

    def test_check_yubikey_not_found(self, runner: CliRunner) -> None:
        """Test check-yubikey when no device."""
        with patch(
            "license_server.cli.sign.YubiKeyService.is_available",
            return_value=False,
        ):
            result = runner.invoke(cli, ["check-yubikey"])

        assert result.exit_code == 1
        assert "No YubiKey detected" in result.output

    def test_check_yubikey_found(self, runner: CliRunner) -> None:
        """Test check-yubikey when device present."""
        with (
            patch(
                "license_server.cli.sign.YubiKeyService.is_available",
                return_value=True,
            ),
            patch(
                "license_server.cli.sign.YubiKeyService.get_device_info",
                return_value={
                    "product_name": "YubiKey 5 NFC",
                    "vendor_id": "0x1050",
                    "product_id": "0x0407",
                },
            ),
        ):
            result = runner.invoke(cli, ["check-yubikey"])

        assert result.exit_code == 0
        assert "YubiKey detected" in result.output
        assert "YubiKey 5 NFC" in result.output


class TestCLIGroup:
    """Tests for CLI group."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        """Create CLI runner."""
        return CliRunner()

    def test_cli_help(self, runner: CliRunner) -> None:
        """Test CLI help shows all commands."""
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        assert "sign-monthly" in result.output
        assert "server-status" in result.output
        assert "generate-keys" in result.output
        assert "check-yubikey" in result.output
