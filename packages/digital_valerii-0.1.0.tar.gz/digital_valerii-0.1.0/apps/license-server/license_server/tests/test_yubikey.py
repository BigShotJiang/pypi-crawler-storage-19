"""Tests for YubiKey service.

Component 4.10: Licensing & Protection System

Tests use mocking since actual YubiKey hardware is not available in CI.
"""

import base64

# Check if nacl is available
import importlib.util
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from license_server.services.yubikey_service import (
    YubiKeyError,
    YubiKeyService,
    get_current_month,
    get_next_month,
)

HAS_NACL = importlib.util.find_spec("nacl") is not None
if HAS_NACL:
    from nacl.signing import SigningKey
else:
    SigningKey = None


class TestYubiKeyService:
    """Tests for YubiKeyService class."""

    @pytest.fixture
    def service(self) -> YubiKeyService:
        """Create YubiKey service instance."""
        return YubiKeyService()

    def test_is_available_returns_bool(self, service: YubiKeyService) -> None:
        """Test is_available returns a boolean."""
        result = service.is_available()
        assert isinstance(result, bool)

    def test_is_available_no_fido2_warning(self, service: YubiKeyService) -> None:
        """Test is_available handles import error gracefully."""
        # Force the import to fail by patching
        with patch.dict("sys.modules", {"fido2": None, "fido2.hid": None}):
            # Service should return False when fido2 not available
            result = service.is_available()
            assert result is False or result is True  # Depends on actual install

    def test_get_device_info_no_device(self, service: YubiKeyService) -> None:
        """Test get_device_info returns None when no device."""
        result = service.get_device_info()
        # Will be None if no device connected
        assert result is None or isinstance(result, dict)

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_with_temp_key(self, service: YubiKeyService) -> None:
        """Test signing with temporary generated key."""
        month = "2025-01"
        signature = service.sign_monthly(month)

        # Should return base64 encoded signature
        assert isinstance(signature, str)
        # Should be valid base64
        decoded = base64.b64decode(signature)
        assert len(decoded) == 64  # Ed25519 signature is 64 bytes

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_with_key_file(self, service: YubiKeyService) -> None:
        """Test signing with key from file."""
        assert SigningKey is not None
        signing_key = SigningKey.generate()
        private_key = bytes(signing_key)
        key_b64 = base64.b64encode(private_key).decode()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False) as f:
            f.write(key_b64)
            key_path = f.name

        try:
            signature = service.sign_monthly("2025-01", key_path)
            assert isinstance(signature, str)
            decoded = base64.b64decode(signature)
            assert len(decoded) == 64
        finally:
            Path(key_path).unlink()

    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    def test_sign_monthly_pem_not_supported(self, service: YubiKeyService) -> None:
        """Test that PEM format raises error."""
        pem_content = b"-----BEGIN PRIVATE KEY-----\ndata\n-----END PRIVATE KEY-----"

        with tempfile.NamedTemporaryFile(mode="wb", suffix=".pem", delete=False) as f:
            f.write(pem_content)
            key_path = f.name

        try:
            with pytest.raises(YubiKeyError, match="PEM format not yet supported"):
                service.sign_monthly("2025-01", key_path)
        finally:
            Path(key_path).unlink()

    def test_sign_monthly_invalid_key(self, service: YubiKeyService) -> None:
        """Test that invalid key raises error."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".key", delete=False) as f:
            f.write("not_valid_base64!!!")
            key_path = f.name

        try:
            with pytest.raises(YubiKeyError):
                service.sign_monthly("2025-01", key_path)
        finally:
            Path(key_path).unlink()

    def test_verify_yubikey_present_raises(self, service: YubiKeyService) -> None:
        """Test verify_yubikey_present raises when no YubiKey."""
        with (
            patch.object(service, "is_available", return_value=False),
            pytest.raises(YubiKeyError, match="No YubiKey detected"),
        ):
            service.verify_yubikey_present()

    def test_verify_yubikey_present_success(self, service: YubiKeyService) -> None:
        """Test verify_yubikey_present passes when YubiKey available."""
        with patch.object(service, "is_available", return_value=True):
            # Should not raise
            service.verify_yubikey_present()

    def test_prompt_touch(
        self, service: YubiKeyService, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """Test prompt_touch displays message."""
        service.prompt_touch()
        captured = capsys.readouterr()
        assert "Touch your YubiKey" in captured.out

    @pytest.mark.asyncio
    @pytest.mark.skipif(not HAS_NACL, reason="PyNaCl not installed")
    async def test_sign_monthly_interactive(self, service: YubiKeyService) -> None:
        """Test interactive signing flow."""
        with (
            patch.object(service, "is_available", return_value=True),
            patch.object(service, "prompt_touch"),
        ):
            signature = await service.sign_monthly_interactive("2025-01")
            assert isinstance(signature, str)
            decoded = base64.b64decode(signature)
            assert len(decoded) == 64

    def test_sign_monthly_no_nacl_raises(self, service: YubiKeyService) -> None:
        """Test sign_monthly raises descriptive error when nacl missing."""

        def mock_sign(month: str, key_path: str | None = None) -> str:
            raise YubiKeyError("PyNaCl not installed. Run: pip install pynacl")

        with (
            patch.dict("sys.modules", {"nacl": None, "nacl.signing": None}),
            patch.object(service, "sign_monthly", side_effect=mock_sign),
            pytest.raises(YubiKeyError, match="PyNaCl not installed"),
        ):
            service.sign_monthly("2025-01")


class TestHelperFunctions:
    """Tests for module helper functions."""

    def test_get_current_month_format(self) -> None:
        """Test current month returns YYYY-MM format."""
        month = get_current_month()
        assert len(month) == 7
        assert month[4] == "-"
        year, mon = month.split("-")
        assert int(year) >= 2024
        assert 1 <= int(mon) <= 12

    def test_get_next_month_format(self) -> None:
        """Test next month returns YYYY-MM format."""
        month = get_next_month()
        assert len(month) == 7
        assert month[4] == "-"
        year, mon = month.split("-")
        assert int(year) >= 2024
        assert 1 <= int(mon) <= 12

    def test_get_next_month_december_rollover(self) -> None:
        """Test next month handles December correctly."""
        mock_now = MagicMock()
        mock_now.month = 12
        mock_now.year = 2025

        with patch("license_server.services.yubikey_service.datetime") as mock_datetime:
            mock_datetime.now.return_value = mock_now
            month = get_next_month()
            assert month == "2026-01"

    def test_get_next_month_regular(self) -> None:
        """Test next month increments correctly."""
        mock_now = MagicMock()
        mock_now.month = 5
        mock_now.year = 2025

        with patch("license_server.services.yubikey_service.datetime") as mock_datetime:
            mock_datetime.now.return_value = mock_now
            month = get_next_month()
            assert month == "2025-06"

    def test_get_current_month_uses_utc(self) -> None:
        """Test current month uses UTC timezone."""
        from datetime import UTC

        mock_now = MagicMock()
        mock_now.strftime.return_value = "2025-01"

        with patch("license_server.services.yubikey_service.datetime") as mock_datetime:
            mock_datetime.now.return_value = mock_now
            mock_datetime.UTC = UTC
            get_current_month()
            mock_datetime.now.assert_called_with(UTC)
