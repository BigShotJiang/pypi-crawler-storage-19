"""Initial schema for License Server.

Revision ID: 001
Revises:
Create Date: 2025-01-11
"""

from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op  # type: ignore[attr-defined]

# revision identifiers, used by Alembic.
revision: str = "001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # Create licenses table
    op.create_table(
        "licenses",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("client_id", sa.String(255), nullable=False, unique=True),
        sa.Column("client_name", sa.String(255), nullable=False),
        sa.Column("tier", sa.String(50), nullable=False, default="starter"),
        sa.Column("worker_count", sa.Integer, nullable=False, default=1),
        sa.Column("features", sa.JSON, nullable=False, default=list),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("grace_period_days", sa.Integer, nullable=False, default=14),
        sa.Column(
            "status",
            sa.String(20),
            nullable=False,
            default="active",
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_licenses_client_id", "licenses", ["client_id"])
    op.create_index("ix_licenses_status", "licenses", ["status"])

    # Create activation_tokens table
    op.create_table(
        "activation_tokens",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "license_id",
            sa.String(36),
            sa.ForeignKey("licenses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("token_hash", sa.String(128), nullable=False, unique=True),
        sa.Column("machine_fingerprint", sa.String(255), nullable=True),
        sa.Column("activated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("is_active", sa.Boolean, nullable=False, default=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index("ix_activation_tokens_token_hash", "activation_tokens", ["token_hash"])
    op.create_index("ix_activation_tokens_license_id", "activation_tokens", ["license_id"])

    # Create monthly_signatures table (Dead Man's Switch)
    op.create_table(
        "monthly_signatures",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("month", sa.String(7), nullable=False, unique=True),
        sa.Column("signature", sa.LargeBinary, nullable=False),
        sa.Column(
            "signed_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column("signed_by", sa.String(255), nullable=False),
    )
    op.create_index("ix_monthly_signatures_month", "monthly_signatures", ["month"])

    # Create usage_logs table
    op.create_table(
        "usage_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "license_id",
            sa.String(36),
            sa.ForeignKey("licenses.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("endpoint", sa.String(255), nullable=True),
        sa.Column("tokens_in", sa.Integer, nullable=True),
        sa.Column("tokens_out", sa.Integer, nullable=True),
        sa.Column("latency_ms", sa.Integer, nullable=True),
        sa.Column(
            "timestamp",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index("ix_usage_logs_license_id", "usage_logs", ["license_id"])
    op.create_index("ix_usage_logs_timestamp", "usage_logs", ["timestamp"])

    # Create security_events table
    op.create_table(
        "security_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "license_id",
            sa.String(36),
            sa.ForeignKey("licenses.id", ondelete="SET NULL"),
            nullable=True,
        ),
        sa.Column("event_type", sa.String(100), nullable=False),
        sa.Column("details", sa.JSON, nullable=True),
        sa.Column("severity", sa.String(20), nullable=False, default="info"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
    )
    op.create_index("ix_security_events_license_id", "security_events", ["license_id"])
    op.create_index("ix_security_events_event_type", "security_events", ["event_type"])
    op.create_index("ix_security_events_severity", "security_events", ["severity"])


def downgrade() -> None:
    op.drop_table("security_events")
    op.drop_table("usage_logs")
    op.drop_table("monthly_signatures")
    op.drop_table("activation_tokens")
    op.drop_table("licenses")
