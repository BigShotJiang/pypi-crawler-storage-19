"""Tools module - external integrations."""
