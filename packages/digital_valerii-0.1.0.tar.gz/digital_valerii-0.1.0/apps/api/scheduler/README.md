# Scheduler Service

APScheduler-based cron scheduling for recurring agent tasks.

## Overview

The Scheduler Service enables Digital Valerii to execute tasks on a recurring schedule:
- Weekly status reports, daily summaries
- Proactive actions (meeting prep 30 min before events)
- Maintenance tasks (memory cleanup, cache refresh)
- Business workflows (scheduled emails, document generation)

## Architecture

```
User creates schedule → SchedulerService → APScheduler (cron engine)
                              ↓                    ↓
                        PostgreSQL           On schedule:
                     (scheduled_tasks)     create task_queue
                                                  ↓
                                            arq worker
                                          executes task
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/schedules` | Create scheduled task |
| GET | `/api/v1/schedules` | List user's schedules |
| GET | `/api/v1/schedules/{id}` | Get schedule details |
| PUT | `/api/v1/schedules/{id}` | Update schedule |
| DELETE | `/api/v1/schedules/{id}` | Delete schedule |
| POST | `/api/v1/schedules/{id}/pause` | Pause schedule |
| POST | `/api/v1/schedules/{id}/resume` | Resume schedule |
| POST | `/api/v1/schedules/{id}/trigger` | Manual trigger |

## Task Types

- `agent_task` - Execute agent with prompt (requires `prompt` in payload)
- `send_email` - Send scheduled email (requires `to`, `subject` in payload)
- `create_doc` - Generate document (requires `template` in payload)

## Usage Examples

```python
# Create daily summary schedule
POST /api/v1/schedules
{
    "name": "Daily Summary",
    "cron_expression": "0 9 * * *",
    "task_type": "agent_task",
    "task_payload": {"prompt": "Generate daily summary"},
    "timezone": "America/New_York"
}

# Create weekly report
POST /api/v1/schedules
{
    "name": "Weekly Status",
    "cron_expression": "0 16 * * FRI",
    "task_type": "agent_task",
    "task_payload": {"prompt": "Create weekly status report"},
    "timezone": "UTC"
}
```

## Cron Expression Format

Standard 5-part cron: `minute hour day-of-month month day-of-week`

Examples:
- `0 9 * * *` - Daily at 9:00 AM
- `0 9 * * 1-5` - Weekdays at 9:00 AM
- `0 16 * * FRI` - Fridays at 4:00 PM
- `0 0 1 * *` - First day of each month at midnight

## Dependencies

- `apscheduler>=3.10.4` - Async scheduler
- `croniter>=2.0.1` - Cron expression validation
- `pytz>=2024.1` - Timezone handling

## Database

Table: `scheduled_tasks`
- Stores schedule configuration and execution history
- `schedule_id` in `task_queue` links executed tasks

## Testing

```bash
pytest apps/api/scheduler/tests/ -v
```
