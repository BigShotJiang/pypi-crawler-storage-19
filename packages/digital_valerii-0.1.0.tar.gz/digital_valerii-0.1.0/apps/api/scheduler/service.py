"""Scheduler service with APScheduler integration."""

import json
from collections.abc import AsyncGenerator, Callable
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

import pytz
import structlog
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from croniter import croniter
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.scheduler.models import (
    ScheduledTaskCreate,
    ScheduledTaskFilter,
    ScheduledTaskResponse,
    ScheduledTaskUpdate,
    TaskType,
)

logger = structlog.get_logger(__name__)

# Session factory type
SessionFactory = Callable[[], AsyncGenerator[AsyncSession, None]]


class SchedulerError(Exception):
    """Base exception for scheduler errors."""

    pass


class ScheduleNotFoundError(SchedulerError):
    """Schedule not found."""

    def __init__(self, schedule_id: UUID) -> None:
        self.schedule_id = schedule_id
        super().__init__(f"Schedule not found: {schedule_id}")


class ScheduleLimitExceededError(SchedulerError):
    """Maximum schedules per user exceeded."""

    def __init__(self, limit: int) -> None:
        self.limit = limit
        super().__init__(f"Maximum {limit} schedules per user")


class PayloadValidationError(SchedulerError):
    """Task payload validation failed."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


# Rate limiting constants
MAX_SCHEDULES_PER_USER = 100


class SchedulerService:
    """APScheduler-based cron scheduling service.

    Manages scheduled tasks with:
    - APScheduler for cron-based job execution
    - PostgreSQL for persistent schedule storage
    - Integration with task_queue for task execution
    - Session factory pattern for long-lived service
    """

    def __init__(self, session_factory: SessionFactory) -> None:
        """Initialize scheduler service.

        Args:
            session_factory: Async context manager factory for database sessions.
        """
        self._session_factory = session_factory
        self._scheduler = AsyncIOScheduler()
        self._jobs: dict[UUID, str] = {}  # schedule_id -> apscheduler_job_id
        self._started = False

    @asynccontextmanager
    async def _get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get a fresh database session using the factory.

        Yields:
            AsyncSession: Fresh database session.
        """
        # FIX-4.6.2 Round 3: Use async with for @asynccontextmanager, not async for
        async with self._session_factory() as session:
            yield session

    async def start(self) -> None:
        """Start scheduler and load existing schedules from database."""
        if self._started:
            await logger.awarning("Scheduler already started")
            return

        await logger.ainfo("Starting scheduler service")

        # Load enabled schedules from database
        schedules = await self._load_enabled_schedules()
        await logger.ainfo("Loaded schedules from database", count=len(schedules))

        # Add jobs to APScheduler
        for schedule in schedules:
            await self._add_job_to_scheduler(schedule)

        # Start the scheduler
        self._scheduler.start()
        self._started = True

        await logger.ainfo("Scheduler started", job_count=len(self._jobs))

    async def stop(self) -> None:
        """Graceful shutdown of scheduler."""
        if not self._started:
            return

        await logger.ainfo("Stopping scheduler service")
        self._scheduler.shutdown(wait=True)
        self._jobs.clear()
        self._started = False
        await logger.ainfo("Scheduler stopped")

    async def add_schedule(
        self, schedule: ScheduledTaskCreate, user_id: UUID
    ) -> ScheduledTaskResponse:
        """Add new scheduled task.

        Args:
            schedule: Schedule creation data.
            user_id: ID of user creating the schedule.

        Returns:
            Created schedule response.

        Raises:
            ScheduleLimitExceededError: If user has too many schedules.
        """
        async with self._get_session() as session:
            # Check user's schedule count (FIX-4.6.5: rate limiting)
            count_query = text("""
                SELECT COUNT(*) FROM scheduled_tasks WHERE user_id = :user_id
            """)
            count_result = await session.execute(count_query, {"user_id": user_id})
            count = count_result.scalar()

            if count >= MAX_SCHEDULES_PER_USER:
                raise ScheduleLimitExceededError(MAX_SCHEDULES_PER_USER)

            schedule_id = uuid4()
            tz = pytz.timezone(schedule.timezone)
            now = datetime.now(UTC)

            # Calculate next run time
            cron = croniter(schedule.cron_expression, now.astimezone(tz))
            next_run = cron.get_next(datetime)
            if next_run.tzinfo is None:
                next_run = tz.localize(next_run)
            next_run_utc = next_run.astimezone(UTC)

            # Insert into database
            query = text("""
                INSERT INTO scheduled_tasks (
                    id, user_id, name, cron_expression, task_type,
                    task_payload, timezone, next_run_at, enabled,
                    created_at, updated_at
                ) VALUES (
                    :id, :user_id, :name, :cron_expression, :task_type,
                    :task_payload::jsonb, :timezone, :next_run_at, :enabled,
                    :created_at, :updated_at
                )
                RETURNING id, user_id, project_id, name, cron_expression,
                          task_type, task_payload, timezone, last_run_at,
                          next_run_at, last_result, enabled, created_at, updated_at
            """)

            result = await session.execute(
                query,
                {
                    "id": schedule_id,
                    "user_id": user_id,
                    "name": schedule.name,
                    "cron_expression": schedule.cron_expression,
                    "task_type": schedule.task_type.value,
                    "task_payload": json.dumps(schedule.task_payload),
                    "timezone": schedule.timezone,
                    "next_run_at": next_run_utc,
                    "enabled": schedule.enabled,
                    "created_at": now,
                    "updated_at": now,
                },
            )
            await session.commit()
            row = result.fetchone()

            response = self._row_to_response(row)

            # Add job to scheduler if enabled
            if schedule.enabled and self._started:
                await self._add_job_to_scheduler(response)

            await logger.ainfo(
                "Schedule created",
                schedule_id=str(schedule_id),
                name=schedule.name,
                cron=schedule.cron_expression,
            )

            return response

    async def get_schedule(
        self, schedule_id: UUID, user_id: UUID | None = None
    ) -> ScheduledTaskResponse:
        """Get schedule by ID.

        Args:
            schedule_id: Schedule ID.
            user_id: Optional user ID for access control.

        Returns:
            Schedule response.

        Raises:
            ScheduleNotFoundError: If schedule not found.
        """
        async with self._get_session() as session:
            if user_id:
                query = text("""
                    SELECT id, user_id, project_id, name, cron_expression,
                           task_type, task_payload, timezone, last_run_at,
                           next_run_at, last_result, enabled, created_at, updated_at
                    FROM scheduled_tasks
                    WHERE id = :schedule_id AND user_id = :user_id
                """)
                result = await session.execute(
                    query, {"schedule_id": schedule_id, "user_id": user_id}
                )
            else:
                query = text("""
                    SELECT id, user_id, project_id, name, cron_expression,
                           task_type, task_payload, timezone, last_run_at,
                           next_run_at, last_result, enabled, created_at, updated_at
                    FROM scheduled_tasks
                    WHERE id = :schedule_id
                """)
                result = await session.execute(query, {"schedule_id": schedule_id})

            row = result.fetchone()
            if not row:
                raise ScheduleNotFoundError(schedule_id)

            return self._row_to_response(row)

    async def list_schedules(
        self,
        user_id: UUID,
        filter_params: ScheduledTaskFilter | None = None,
    ) -> list[ScheduledTaskResponse]:
        """List user's scheduled tasks.

        Args:
            user_id: User ID.
            filter_params: Optional filter parameters.

        Returns:
            List of schedule responses.
        """
        if filter_params is None:
            filter_params = ScheduledTaskFilter()

        async with self._get_session() as session:
            # Build query with optional filters
            conditions = ["user_id = :user_id"]
            params: dict[str, Any] = {"user_id": user_id}

            if filter_params.enabled is not None:
                conditions.append("enabled = :enabled")
                params["enabled"] = filter_params.enabled

            if filter_params.task_type is not None:
                conditions.append("task_type = :task_type")
                params["task_type"] = filter_params.task_type.value

            where_clause = " AND ".join(conditions)
            params["limit"] = filter_params.limit
            params["offset"] = filter_params.offset

            query = text(f"""
                SELECT id, user_id, project_id, name, cron_expression,
                       task_type, task_payload, timezone, last_run_at,
                       next_run_at, last_result, enabled, created_at, updated_at
                FROM scheduled_tasks
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT :limit OFFSET :offset
            """)

            result = await session.execute(query, params)
            rows = result.fetchall()

            return [self._row_to_response(row) for row in rows]

    async def update_schedule(
        self,
        schedule_id: UUID,
        update: ScheduledTaskUpdate,
        user_id: UUID,
    ) -> ScheduledTaskResponse:
        """Update a scheduled task.

        Args:
            schedule_id: Schedule ID.
            update: Update data.
            user_id: User ID for access control.

        Returns:
            Updated schedule response.

        Raises:
            ScheduleNotFoundError: If schedule not found.
            PayloadValidationError: If payload validation fails.
        """
        # First verify schedule exists and belongs to user
        existing = await self.get_schedule(schedule_id, user_id)

        # FIX-4.6.6: Revalidate payload if task_type or task_payload changes
        if update.task_type is not None or update.task_payload is not None:
            new_type = update.task_type or existing.task_type
            new_payload = update.task_payload or existing.task_payload
            self._validate_payload_for_type(new_type, new_payload)

        async with self._get_session() as session:
            # Build update query
            updates = []
            params: dict[str, Any] = {
                "schedule_id": schedule_id,
                "user_id": user_id,
                "updated_at": datetime.now(UTC),
            }

            if update.name is not None:
                updates.append("name = :name")
                params["name"] = update.name

            # FIX-4.6.6: Recalculate next_run_at when cron OR timezone changes
            recalc_next_run = (
                update.cron_expression is not None or update.timezone is not None
            )
            if recalc_next_run:
                new_tz = update.timezone or existing.timezone
                new_cron = update.cron_expression or existing.cron_expression
                tz = pytz.timezone(new_tz)
                cron = croniter(new_cron, datetime.now(UTC).astimezone(tz))
                next_run = cron.get_next(datetime)
                if next_run.tzinfo is None:
                    next_run = tz.localize(next_run)
                updates.append("next_run_at = :next_run_at")
                params["next_run_at"] = next_run.astimezone(UTC)

            if update.cron_expression is not None:
                updates.append("cron_expression = :cron_expression")
                params["cron_expression"] = update.cron_expression

            if update.task_type is not None:
                updates.append("task_type = :task_type")
                params["task_type"] = update.task_type.value

            if update.task_payload is not None:
                updates.append("task_payload = :task_payload::jsonb")
                params["task_payload"] = json.dumps(update.task_payload)

            if update.timezone is not None:
                updates.append("timezone = :timezone")
                params["timezone"] = update.timezone

            if update.enabled is not None:
                updates.append("enabled = :enabled")
                params["enabled"] = update.enabled

            if not updates:
                return existing

            updates.append("updated_at = :updated_at")

            query = text(f"""
                UPDATE scheduled_tasks
                SET {', '.join(updates)}
                WHERE id = :schedule_id AND user_id = :user_id
                RETURNING id, user_id, project_id, name, cron_expression,
                          task_type, task_payload, timezone, last_run_at,
                          next_run_at, last_result, enabled, created_at, updated_at
            """)

            result = await session.execute(query, params)
            await session.commit()
            row = result.fetchone()

            response = self._row_to_response(row)

            # Update APScheduler job
            if self._started:
                if schedule_id in self._jobs:
                    self._scheduler.remove_job(self._jobs[schedule_id])
                    del self._jobs[schedule_id]

                if response.enabled:
                    await self._add_job_to_scheduler(response)

            await logger.ainfo(
                "Schedule updated",
                schedule_id=str(schedule_id),
            )

            return response

    def _validate_payload_for_type(
        self, task_type: TaskType, task_payload: dict[str, Any]
    ) -> None:
        """Validate task payload for the given task type.

        Args:
            task_type: Task type.
            task_payload: Task payload.

        Raises:
            PayloadValidationError: If payload is invalid.
        """
        if task_type == TaskType.AGENT_TASK:
            if "prompt" not in task_payload:
                raise PayloadValidationError(
                    "task_payload must contain 'prompt' for agent_task"
                )
            if not task_payload["prompt"]:
                raise PayloadValidationError("prompt cannot be empty for agent_task")
        elif task_type == TaskType.SEND_EMAIL:
            required = ["to", "subject"]
            missing = [f for f in required if f not in task_payload]
            if missing:
                raise PayloadValidationError(
                    f"task_payload must contain {missing} for send_email"
                )
        elif task_type == TaskType.CREATE_DOC:
            if "template" not in task_payload:
                raise PayloadValidationError(
                    "task_payload must contain 'template' for create_doc"
                )

    async def delete_schedule(self, schedule_id: UUID, user_id: UUID) -> None:
        """Delete a scheduled task.

        Args:
            schedule_id: Schedule ID.
            user_id: User ID for access control.

        Raises:
            ScheduleNotFoundError: If schedule not found.
        """
        # Verify schedule exists and belongs to user
        await self.get_schedule(schedule_id, user_id)

        # Remove from APScheduler
        if schedule_id in self._jobs:
            self._scheduler.remove_job(self._jobs[schedule_id])
            del self._jobs[schedule_id]

        # Delete from database
        async with self._get_session() as session:
            query = text("""
                DELETE FROM scheduled_tasks
                WHERE id = :schedule_id AND user_id = :user_id
            """)
            await session.execute(
                query, {"schedule_id": schedule_id, "user_id": user_id}
            )
            await session.commit()

        await logger.ainfo(
            "Schedule deleted",
            schedule_id=str(schedule_id),
        )

    async def pause_schedule(self, schedule_id: UUID, user_id: UUID) -> None:
        """Pause schedule without deleting.

        Args:
            schedule_id: Schedule ID.
            user_id: User ID for access control.
        """
        await self.update_schedule(
            schedule_id,
            ScheduledTaskUpdate(enabled=False),
            user_id,
        )

        await logger.ainfo(
            "Schedule paused",
            schedule_id=str(schedule_id),
        )

    async def resume_schedule(self, schedule_id: UUID, user_id: UUID) -> None:
        """Resume paused schedule.

        Args:
            schedule_id: Schedule ID.
            user_id: User ID for access control.
        """
        await self.update_schedule(
            schedule_id,
            ScheduledTaskUpdate(enabled=True),
            user_id,
        )

        await logger.ainfo(
            "Schedule resumed",
            schedule_id=str(schedule_id),
        )

    async def trigger_now(self, schedule_id: UUID, user_id: UUID) -> UUID:
        """Manually trigger a scheduled task.

        Args:
            schedule_id: Schedule ID.
            user_id: User ID for access control.

        Returns:
            Created task ID.
        """
        # Verify schedule exists and user has access (raises ScheduleNotFoundError if not)
        await self.get_schedule(schedule_id, user_id)
        return await self._execute_scheduled_task(schedule_id, manual=True)

    async def _execute_scheduled_task(
        self, schedule_id: UUID, manual: bool = False
    ) -> UUID:
        """Execute a scheduled task by creating a task_queue entry.

        Uses fresh session for each execution (critical for scheduled callbacks).

        Args:
            schedule_id: Schedule ID.
            manual: Whether this is a manual trigger.

        Returns:
            Created task ID.
        """
        # Load schedule from database
        schedule = await self.get_schedule(schedule_id)
        now = datetime.now(UTC)

        async with self._get_session() as session:
            # Create task_queue entry
            task_id = uuid4()
            query = text("""
                INSERT INTO task_queue (
                    id, trigger_id, schedule_id, task_type, payload,
                    priority, status, created_at
                ) VALUES (
                    :id, NULL, :schedule_id, :task_type, :payload::jsonb,
                    'normal', 'pending', :created_at
                )
            """)
            await session.execute(
                query,
                {
                    "id": task_id,
                    "schedule_id": schedule_id,
                    "task_type": schedule.task_type.value,
                    "payload": json.dumps(schedule.task_payload),
                    "created_at": now,
                },
            )

            # Calculate next run time
            tz = pytz.timezone(schedule.timezone)
            cron = croniter(schedule.cron_expression, now.astimezone(tz))
            next_run = cron.get_next(datetime)
            if next_run.tzinfo is None:
                next_run = tz.localize(next_run)
            next_run_utc = next_run.astimezone(UTC)

            # Update last_run_at and next_run_at
            update_query = text("""
                UPDATE scheduled_tasks
                SET last_run_at = :last_run_at,
                    next_run_at = :next_run_at,
                    updated_at = :updated_at
                WHERE id = :schedule_id
            """)
            await session.execute(
                update_query,
                {
                    "schedule_id": schedule_id,
                    "last_run_at": now,
                    "next_run_at": next_run_utc,
                    "updated_at": now,
                },
            )
            await session.commit()

        trigger_type = "manual" if manual else "scheduled"
        await logger.ainfo(
            "Scheduled task executed",
            schedule_id=str(schedule_id),
            task_id=str(task_id),
            trigger_type=trigger_type,
        )

        return task_id

    async def _load_enabled_schedules(self) -> list[ScheduledTaskResponse]:
        """Load all enabled schedules from database."""
        async with self._get_session() as session:
            query = text("""
                SELECT id, user_id, project_id, name, cron_expression,
                       task_type, task_payload, timezone, last_run_at,
                       next_run_at, last_result, enabled, created_at, updated_at
                FROM scheduled_tasks
                WHERE enabled = true
                ORDER BY created_at ASC
            """)
            result = await session.execute(query)
            rows = result.fetchall()
            return [self._row_to_response(row) for row in rows]

    async def _add_job_to_scheduler(self, schedule: ScheduledTaskResponse) -> None:
        """Add a job to APScheduler.

        Args:
            schedule: Schedule to add as a job.
        """
        try:
            # Parse cron expression into APScheduler trigger
            tz = pytz.timezone(schedule.timezone)
            trigger = CronTrigger.from_crontab(schedule.cron_expression, timezone=tz)

            # Add job
            job = self._scheduler.add_job(
                self._job_callback,
                trigger=trigger,
                id=str(schedule.id),
                args=[schedule.id],
                replace_existing=True,
            )
            self._jobs[schedule.id] = job.id

            await logger.ainfo(
                "Job added to scheduler",
                schedule_id=str(schedule.id),
                job_id=job.id,
            )
        except Exception as e:
            await logger.aerror(
                "Failed to add job to scheduler",
                schedule_id=str(schedule.id),
                error=str(e),
            )

    async def _job_callback(self, schedule_id: UUID) -> None:
        """Callback executed when APScheduler triggers a job.

        Args:
            schedule_id: Schedule ID to execute.
        """
        try:
            await self._execute_scheduled_task(schedule_id)
        except Exception as e:
            await logger.aerror(
                "Scheduled task execution failed",
                schedule_id=str(schedule_id),
                error=str(e),
                exc_info=True,
            )

    def _row_to_response(self, row: Any) -> ScheduledTaskResponse:
        """Convert database row to response model.

        Args:
            row: Database row.

        Returns:
            ScheduledTaskResponse.
        """
        # Handle task_payload - may be dict or JSON string
        task_payload = row.task_payload
        if isinstance(task_payload, str):
            task_payload = json.loads(task_payload)

        # Handle last_result
        last_result = row.last_result
        if isinstance(last_result, str):
            last_result = json.loads(last_result)

        return ScheduledTaskResponse(
            id=row.id,
            user_id=row.user_id,
            project_id=row.project_id,
            name=row.name,
            cron_expression=row.cron_expression,
            task_type=TaskType(row.task_type),
            task_payload=task_payload,
            timezone=row.timezone,
            last_run_at=row.last_run_at,
            next_run_at=row.next_run_at,
            last_result=last_result,
            enabled=row.enabled,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )
