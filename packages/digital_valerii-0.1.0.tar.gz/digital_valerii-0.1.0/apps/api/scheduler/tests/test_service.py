"""Tests for SchedulerService."""

from datetime import UTC, datetime
from unittest.mock import MagicMock
from uuid import UUID, uuid4

import pytest

from apps.api.scheduler.models import (
    ScheduledTaskCreate,
    ScheduledTaskFilter,
    ScheduledTaskUpdate,
    TaskType,
)
from apps.api.scheduler.service import (
    ScheduleLimitExceededError,
    ScheduleNotFoundError,
    SchedulerService,
)


class TestSchedulerServiceLifecycle:
    """Scheduler lifecycle tests."""

    @pytest.mark.asyncio
    async def test_start_scheduler(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
    ) -> None:
        """Starting scheduler initializes APScheduler."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)

        # Mock empty schedules
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db_session.execute.return_value = mock_result

        await service.start()

        mock_apscheduler.start.assert_called_once()

    @pytest.mark.asyncio
    async def test_stop_scheduler(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
    ) -> None:
        """Stopping scheduler shuts down APScheduler."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)

        # Mock empty schedules for start
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db_session.execute.return_value = mock_result

        await service.start()
        await service.stop()

        mock_apscheduler.shutdown.assert_called_once_with(wait=True)


class TestSchedulerServiceAddSchedule:
    """SchedulerService.add_schedule tests."""

    @pytest.mark.asyncio
    async def test_add_schedule_success(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_schedule_create: ScheduledTaskCreate,
        sample_user_id: str,
        db_row_factory,
    ) -> None:
        """Add schedule creates database record and APScheduler job."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        # Mock insert returning row
        mock_row = db_row_factory(user_id=sample_user_id, project_id=None)

        # Setup mock results
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # FIX-4.6.5: Mock count query for limit check
        mock_count_result = MagicMock()
        mock_count_result.scalar.return_value = 0  # Use scalar() not scalar_one()

        mock_add_result = MagicMock()
        mock_add_result.fetchone.return_value = mock_row

        # First call for start (load schedules), second for count, third for add_schedule
        mock_db_session.execute.side_effect = [
            mock_start_result,
            mock_count_result,
            mock_add_result,
        ]

        await service.start()
        response = await service.add_schedule(sample_schedule_create, user_id=user_id)

        assert response.name == mock_row.name
        mock_db_session.commit.assert_called()

    @pytest.mark.asyncio
    async def test_add_schedule_limit_exceeded(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_schedule_create: ScheduledTaskCreate,
        sample_user_id: str,
    ) -> None:
        """FIX-4.6.5: Add schedule raises error when limit exceeded."""
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        # Mock start
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # Mock count query returning max limit
        mock_count_result = MagicMock()
        mock_count_result.scalar.return_value = (
            100  # MAX_SCHEDULES_PER_USER (use scalar())
        )

        mock_db_session.execute.side_effect = [mock_start_result, mock_count_result]

        await service.start()

        with pytest.raises(ScheduleLimitExceededError) as exc_info:
            await service.add_schedule(sample_schedule_create, user_id=user_id)

        assert exc_info.value.limit == 100


class TestSchedulerServiceGetSchedule:
    """SchedulerService.get_schedule tests."""

    @pytest.mark.asyncio
    async def test_get_schedule_found(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Get schedule returns schedule when found."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        mock_row = db_row_factory(
            id=sample_schedule_id, user_id=sample_user_id, project_id=None
        )
        mock_result = MagicMock()
        mock_result.fetchone.return_value = mock_row
        mock_db_session.execute.return_value = mock_result

        response = await service.get_schedule(schedule_id, user_id)

        # Compare UUIDs properly
        assert str(response.id) == sample_schedule_id

    @pytest.mark.asyncio
    async def test_get_schedule_not_found(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
    ) -> None:
        """Get schedule raises error when not found."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = uuid4()

        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db_session.execute.return_value = mock_result

        with pytest.raises(ScheduleNotFoundError):
            await service.get_schedule(schedule_id, user_id)


class TestSchedulerServiceListSchedules:
    """SchedulerService.list_schedules tests."""

    @pytest.mark.asyncio
    async def test_list_schedules_empty(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
    ) -> None:
        """List schedules returns empty list when none exist."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db_session.execute.return_value = mock_result

        response = await service.list_schedules(user_id, ScheduledTaskFilter())

        assert response == []

    @pytest.mark.asyncio
    async def test_list_schedules_returns_multiple(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
        db_row_factory,
    ) -> None:
        """List schedules returns all matching schedules."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        mock_rows = [
            db_row_factory(user_id=sample_user_id, name="Schedule 1", project_id=None),
            db_row_factory(user_id=sample_user_id, name="Schedule 2", project_id=None),
        ]
        mock_result = MagicMock()
        mock_result.fetchall.return_value = mock_rows
        mock_db_session.execute.return_value = mock_result

        response = await service.list_schedules(user_id, ScheduledTaskFilter())

        assert len(response) == 2

    @pytest.mark.asyncio
    async def test_list_schedules_filter_enabled(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
        db_row_factory,
    ) -> None:
        """List schedules applies enabled filter."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        filter_params = ScheduledTaskFilter(enabled=True)

        mock_rows = [
            db_row_factory(user_id=sample_user_id, enabled=True, project_id=None)
        ]
        mock_result = MagicMock()
        mock_result.fetchall.return_value = mock_rows
        mock_db_session.execute.return_value = mock_result

        response = await service.list_schedules(user_id, filter_params)

        assert len(response) == 1


class TestSchedulerServiceUpdateSchedule:
    """SchedulerService.update_schedule tests."""

    @pytest.mark.asyncio
    async def test_update_schedule_name(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Update schedule name."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        # Mock start
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # Mock get_schedule (called by update_schedule)
        mock_get_row = db_row_factory(
            id=sample_schedule_id,
            user_id=sample_user_id,
            name="Old Name",
            project_id=None,
        )
        mock_get_result = MagicMock()
        mock_get_result.fetchone.return_value = mock_get_row

        # Mock update RETURNING
        mock_update_row = db_row_factory(
            id=sample_schedule_id,
            user_id=sample_user_id,
            name="Updated Name",
            project_id=None,
        )
        mock_update_result = MagicMock()
        mock_update_result.fetchone.return_value = mock_update_row

        mock_db_session.execute.side_effect = [
            mock_start_result,  # start()
            mock_get_result,  # get_schedule()
            mock_update_result,  # UPDATE RETURNING
        ]

        await service.start()

        update = ScheduledTaskUpdate(name="Updated Name")
        response = await service.update_schedule(schedule_id, update, user_id)

        assert response.name == "Updated Name"

    @pytest.mark.asyncio
    async def test_update_schedule_not_found(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
    ) -> None:
        """Update schedule raises error when not found."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = uuid4()

        # get_schedule returns None -> raises ScheduleNotFoundError
        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db_session.execute.return_value = mock_result

        update = ScheduledTaskUpdate(name="New Name")
        with pytest.raises(ScheduleNotFoundError):
            await service.update_schedule(schedule_id, update, user_id)


class TestSchedulerServiceDeleteSchedule:
    """SchedulerService.delete_schedule tests."""

    @pytest.mark.asyncio
    async def test_delete_schedule_success(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Delete schedule removes from DB and APScheduler."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        # Mock start
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # Mock get_schedule (called by delete_schedule)
        mock_get_row = db_row_factory(
            id=sample_schedule_id, user_id=sample_user_id, project_id=None
        )
        mock_get_result = MagicMock()
        mock_get_result.fetchone.return_value = mock_get_row

        # Mock DELETE
        mock_delete_result = MagicMock()

        mock_db_session.execute.side_effect = [
            mock_start_result,  # start()
            mock_get_result,  # get_schedule()
            mock_delete_result,  # DELETE
        ]

        await service.start()
        await service.delete_schedule(schedule_id, user_id)

        mock_db_session.commit.assert_called()

    @pytest.mark.asyncio
    async def test_delete_schedule_not_found(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
    ) -> None:
        """Delete schedule raises error when not found."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = uuid4()

        # get_schedule returns None -> raises ScheduleNotFoundError
        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db_session.execute.return_value = mock_result

        with pytest.raises(ScheduleNotFoundError):
            await service.delete_schedule(schedule_id, user_id)


class TestSchedulerServicePauseResume:
    """SchedulerService pause/resume tests."""

    @pytest.mark.asyncio
    async def test_pause_schedule(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Pause schedule sets enabled=False."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        # Mock start
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # Mock get_schedule (called by update_schedule)
        mock_get_row = db_row_factory(
            id=sample_schedule_id, user_id=sample_user_id, enabled=True, project_id=None
        )
        mock_get_result = MagicMock()
        mock_get_result.fetchone.return_value = mock_get_row

        # Mock update RETURNING
        mock_update_row = db_row_factory(
            id=sample_schedule_id,
            user_id=sample_user_id,
            enabled=False,
            project_id=None,
        )
        mock_update_result = MagicMock()
        mock_update_result.fetchone.return_value = mock_update_row

        mock_db_session.execute.side_effect = [
            mock_start_result,  # start()
            mock_get_result,  # get_schedule()
            mock_update_result,  # UPDATE RETURNING
        ]

        await service.start()
        await service.pause_schedule(schedule_id, user_id)

        # Verify pause_job was called (job exists in scheduler)
        # Note: job might not exist if not started, so just verify no error

    @pytest.mark.asyncio
    async def test_resume_schedule(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Resume schedule sets enabled=True."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        # Mock start
        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # Mock get_schedule (called by update_schedule)
        mock_get_row = db_row_factory(
            id=sample_schedule_id,
            user_id=sample_user_id,
            enabled=False,
            project_id=None,
        )
        mock_get_result = MagicMock()
        mock_get_result.fetchone.return_value = mock_get_row

        # Mock update RETURNING
        mock_update_row = db_row_factory(
            id=sample_schedule_id, user_id=sample_user_id, enabled=True, project_id=None
        )
        mock_update_result = MagicMock()
        mock_update_result.fetchone.return_value = mock_update_row

        mock_db_session.execute.side_effect = [
            mock_start_result,  # start()
            mock_get_result,  # get_schedule()
            mock_update_result,  # UPDATE RETURNING
        ]

        await service.start()
        await service.resume_schedule(schedule_id, user_id)


class TestSchedulerServiceTriggerNow:
    """SchedulerService.trigger_now tests."""

    @pytest.mark.asyncio
    async def test_trigger_now_success(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
        sample_schedule_id: str,
        db_row_factory,
    ) -> None:
        """Trigger now creates task queue entry."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = UUID(sample_schedule_id)

        # Mock get schedule (called twice - once for trigger_now, once for _execute_scheduled_task)
        mock_row = db_row_factory(
            id=sample_schedule_id, user_id=sample_user_id, project_id=None
        )
        mock_get_result = MagicMock()
        mock_get_result.fetchone.return_value = mock_row

        # Mock INSERT (no return value needed - task_id generated internally)
        mock_insert_result = MagicMock()

        # Mock update last_run_at result
        mock_update_result = MagicMock()

        mock_db_session.execute.side_effect = [
            mock_get_result,  # get_schedule() from trigger_now
            mock_get_result,  # get_schedule() from _execute_scheduled_task
            mock_insert_result,  # INSERT task_queue
            mock_update_result,  # UPDATE last_run_at
        ]

        result_id = await service.trigger_now(schedule_id, user_id)

        # Service generates task_id internally using uuid4()
        assert isinstance(result_id, UUID)

    @pytest.mark.asyncio
    async def test_trigger_now_not_found(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
    ) -> None:
        """Trigger now raises error when schedule not found."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)
        schedule_id = uuid4()

        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db_session.execute.return_value = mock_result

        with pytest.raises(ScheduleNotFoundError):
            await service.trigger_now(schedule_id, user_id)


class TestSchedulerServiceCronCalculation:
    """Cron next_run calculation tests."""

    @pytest.mark.asyncio
    async def test_next_run_calculated_on_add(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        mock_apscheduler: MagicMock,
        sample_user_id: str,
        db_row_factory,
    ) -> None:
        """Next run is calculated when schedule is added."""
        # FIX-4.6.2: Use session factory pattern
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        schedule_data = ScheduledTaskCreate(
            name="Test",
            cron_expression="0 9 * * *",
            task_type=TaskType.AGENT_TASK,
            task_payload={"prompt": "test"},
        )

        mock_row = db_row_factory(
            user_id=sample_user_id,
            next_run_at=datetime.now(UTC),
            project_id=None,
        )

        mock_start_result = MagicMock()
        mock_start_result.fetchall.return_value = []

        # FIX-4.6.5: Mock count query for limit check
        mock_count_result = MagicMock()
        mock_count_result.scalar.return_value = 0  # Use scalar() not scalar_one()

        mock_add_result = MagicMock()
        mock_add_result.fetchone.return_value = mock_row

        mock_db_session.execute.side_effect = [
            mock_start_result,
            mock_count_result,
            mock_add_result,
        ]

        await service.start()
        response = await service.add_schedule(schedule_data, user_id=user_id)

        # next_run_at should be set
        assert response.next_run_at is not None


class TestSchedulerServiceSessionFactory:
    """FIX-4.6.2: Session factory pattern tests."""

    @pytest.mark.asyncio
    async def test_session_factory_called_per_operation(
        self,
        mock_db_session: MagicMock,
        mock_session_factory,
        sample_user_id: str,
        db_row_factory,
    ) -> None:
        """Each operation uses a fresh session from factory."""
        service = SchedulerService(mock_session_factory)
        user_id = UUID(sample_user_id)

        mock_row = db_row_factory(user_id=sample_user_id, project_id=None)
        mock_result = MagicMock()
        mock_result.fetchone.return_value = mock_row
        mock_db_session.execute.return_value = mock_result

        # Multiple operations should each get a session
        await service.get_schedule(uuid4(), user_id)

        # Session execute should be called (session was obtained from factory)
        assert mock_db_session.execute.called
