"""Tests for scheduler API routes."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI, status
from fastapi.testclient import TestClient

from apps.api.scheduler.models import (
    ScheduledTaskResponse,
)
from apps.api.dependencies import get_scheduler_service
from apps.api.scheduler.routes import get_current_user_id, router
from apps.api.scheduler.service import ScheduleNotFoundError, SchedulerService


@pytest.fixture
def sample_user_id() -> UUID:
    """Sample user ID."""
    return uuid4()


@pytest.fixture
def mock_scheduler_service():
    """Mock scheduler service."""
    return AsyncMock(spec=SchedulerService)


@pytest.fixture
def app(sample_user_id: UUID, mock_scheduler_service: AsyncMock) -> FastAPI:
    """Create test FastAPI app with dependency overrides."""
    test_app = FastAPI()
    test_app.include_router(router, prefix="/api/v1")

    # Override dependencies
    async def override_get_current_user_id():
        return sample_user_id

    async def override_get_scheduler_service():
        return mock_scheduler_service

    test_app.dependency_overrides[get_current_user_id] = override_get_current_user_id
    test_app.dependency_overrides[get_scheduler_service] = override_get_scheduler_service

    return test_app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    """Create test client."""
    return TestClient(app)


@pytest.fixture
def sample_response_data(sample_user_id: UUID) -> dict:
    """Sample response data."""
    return {
        "id": str(uuid4()),
        "user_id": str(sample_user_id),
        "project_id": None,
        "name": "Daily Report",
        "cron_expression": "0 9 * * *",
        "task_type": "agent_task",
        "task_payload": {"prompt": "Generate summary"},
        "timezone": "UTC",
        "enabled": True,
        "next_run_at": datetime.now(UTC).isoformat(),
        "last_run_at": None,
        "last_result": None,
        "created_at": datetime.now(UTC).isoformat(),
        "updated_at": datetime.now(UTC).isoformat(),
    }


class TestCreateScheduleEndpoint:
    """POST /schedules endpoint tests."""

    def test_create_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
        sample_response_data: dict,
    ) -> None:
        """Create schedule with valid data."""
        mock_scheduler_service.add_schedule.return_value = ScheduledTaskResponse(
            **sample_response_data
        )

        response = client.post(
            "/api/v1/schedules",
            json={
                "name": "Daily Report",
                "cron_expression": "0 9 * * *",
                "task_type": "agent_task",
                "task_payload": {"prompt": "Generate summary"},
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["name"] == "Daily Report"

    def test_create_schedule_invalid_cron(
        self,
        client: TestClient,
    ) -> None:
        """Create schedule with invalid cron fails validation."""
        response = client.post(
            "/api/v1/schedules",
            json={
                "name": "Bad Cron",
                "cron_expression": "invalid",
                "task_type": "agent_task",
                "task_payload": {"prompt": "test"},
            },
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestListSchedulesEndpoint:
    """GET /schedules endpoint tests."""

    def test_list_schedules_empty(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """List schedules returns empty array."""
        mock_scheduler_service.list_schedules.return_value = []

        response = client.get("/api/v1/schedules")

        assert response.status_code == status.HTTP_200_OK
        assert response.json() == []

    def test_list_schedules_with_results(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
        sample_response_data: dict,
    ) -> None:
        """List schedules returns array of schedules."""
        mock_scheduler_service.list_schedules.return_value = [
            ScheduledTaskResponse(**sample_response_data)
        ]

        response = client.get("/api/v1/schedules")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 1

    def test_list_schedules_with_filters(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """List schedules applies query filters."""
        mock_scheduler_service.list_schedules.return_value = []

        response = client.get(
            "/api/v1/schedules",
            params={"enabled": True, "task_type": "agent_task"},
        )

        assert response.status_code == status.HTTP_200_OK
        mock_scheduler_service.list_schedules.assert_called_once()


class TestGetScheduleEndpoint:
    """GET /schedules/{schedule_id} endpoint tests."""

    def test_get_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
        sample_response_data: dict,
    ) -> None:
        """Get schedule returns schedule details."""
        schedule_id = sample_response_data["id"]
        mock_scheduler_service.get_schedule.return_value = ScheduledTaskResponse(
            **sample_response_data
        )

        response = client.get(f"/api/v1/schedules/{schedule_id}")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == schedule_id

    def test_get_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Get schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.get_schedule.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.get(f"/api/v1/schedules/{schedule_id}")

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestUpdateScheduleEndpoint:
    """PUT /schedules/{schedule_id} endpoint tests."""

    def test_update_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
        sample_response_data: dict,
    ) -> None:
        """Update schedule with valid data."""
        schedule_id = sample_response_data["id"]
        sample_response_data["name"] = "Updated Name"
        mock_scheduler_service.update_schedule.return_value = ScheduledTaskResponse(
            **sample_response_data
        )

        response = client.put(
            f"/api/v1/schedules/{schedule_id}",
            json={"name": "Updated Name"},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["name"] == "Updated Name"

    def test_update_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Update schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.update_schedule.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.put(
            f"/api/v1/schedules/{schedule_id}",
            json={"name": "New Name"},
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestDeleteScheduleEndpoint:
    """DELETE /schedules/{schedule_id} endpoint tests."""

    def test_delete_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Delete schedule returns 204."""
        schedule_id = uuid4()
        mock_scheduler_service.delete_schedule.return_value = None

        response = client.delete(f"/api/v1/schedules/{schedule_id}")

        assert response.status_code == status.HTTP_204_NO_CONTENT

    def test_delete_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Delete schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.delete_schedule.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.delete(f"/api/v1/schedules/{schedule_id}")

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestPauseScheduleEndpoint:
    """POST /schedules/{schedule_id}/pause endpoint tests."""

    def test_pause_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Pause schedule returns 204."""
        schedule_id = uuid4()
        mock_scheduler_service.pause_schedule.return_value = None

        response = client.post(f"/api/v1/schedules/{schedule_id}/pause")

        assert response.status_code == status.HTTP_204_NO_CONTENT

    def test_pause_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Pause schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.pause_schedule.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.post(f"/api/v1/schedules/{schedule_id}/pause")

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestResumeScheduleEndpoint:
    """POST /schedules/{schedule_id}/resume endpoint tests."""

    def test_resume_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Resume schedule returns 204."""
        schedule_id = uuid4()
        mock_scheduler_service.resume_schedule.return_value = None

        response = client.post(f"/api/v1/schedules/{schedule_id}/resume")

        assert response.status_code == status.HTTP_204_NO_CONTENT

    def test_resume_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Resume schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.resume_schedule.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.post(f"/api/v1/schedules/{schedule_id}/resume")

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestTriggerScheduleEndpoint:
    """POST /schedules/{schedule_id}/trigger endpoint tests."""

    def test_trigger_schedule_success(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Trigger schedule returns task ID."""
        schedule_id = uuid4()
        task_id = uuid4()
        mock_scheduler_service.trigger_now.return_value = task_id

        response = client.post(f"/api/v1/schedules/{schedule_id}/trigger")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["task_id"] == str(task_id)

    def test_trigger_schedule_not_found(
        self,
        client: TestClient,
        mock_scheduler_service: AsyncMock,
    ) -> None:
        """Trigger schedule returns 404 when not found."""
        schedule_id = uuid4()
        mock_scheduler_service.trigger_now.side_effect = ScheduleNotFoundError(schedule_id)

        response = client.post(f"/api/v1/schedules/{schedule_id}/trigger")

        assert response.status_code == status.HTTP_404_NOT_FOUND


class TestAuthenticationRequired:
    """Test that routes without proper auth override require authentication."""

    def test_unauthenticated_request(self) -> None:
        """Request without auth token fails."""
        # Create app WITHOUT overriding get_current_user_id
        test_app = FastAPI()
        test_app.include_router(router, prefix="/api/v1")
        client = TestClient(test_app)

        response = client.get("/api/v1/schedules")

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
