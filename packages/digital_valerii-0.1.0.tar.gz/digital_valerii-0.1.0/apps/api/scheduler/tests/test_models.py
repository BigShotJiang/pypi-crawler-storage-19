"""Tests for scheduler Pydantic models."""

import pytest
from pydantic import ValidationError

from apps.api.scheduler.models import (
    ScheduledTaskCreate,
    ScheduledTaskFilter,
    ScheduledTaskUpdate,
    TaskType,
)


class TestTaskType:
    """TaskType enum tests."""

    def test_task_types_defined(self) -> None:
        """All expected task types exist."""
        assert TaskType.AGENT_TASK.value == "agent_task"
        assert TaskType.SEND_EMAIL.value == "send_email"
        assert TaskType.CREATE_DOC.value == "create_doc"


class TestScheduledTaskCreate:
    """ScheduledTaskCreate model tests."""

    def test_valid_agent_task(self) -> None:
        """Create valid agent task schedule."""
        schedule = ScheduledTaskCreate(
            name="Daily Summary",
            cron_expression="0 9 * * *",
            task_type=TaskType.AGENT_TASK,
            task_payload={"prompt": "Generate daily summary"},
        )
        assert schedule.name == "Daily Summary"
        assert schedule.task_type == TaskType.AGENT_TASK

    def test_valid_send_email_task(self) -> None:
        """Create valid send email schedule."""
        schedule = ScheduledTaskCreate(
            name="Weekly Report",
            cron_expression="0 8 * * MON",
            task_type=TaskType.SEND_EMAIL,
            task_payload={
                "to": "test@example.com",
                "subject": "Weekly Report",
                "template": "weekly",
            },
        )
        assert schedule.task_type == TaskType.SEND_EMAIL

    def test_valid_create_doc_task(self) -> None:
        """Create valid document creation schedule."""
        schedule = ScheduledTaskCreate(
            name="Monthly Doc",
            cron_expression="0 0 1 * *",
            task_type=TaskType.CREATE_DOC,
            task_payload={
                "template": "monthly_summary",
                "title": "Monthly Summary",
            },
        )
        assert schedule.task_type == TaskType.CREATE_DOC

    def test_invalid_cron_expression(self) -> None:
        """Invalid cron expression raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="Bad Cron",
                cron_expression="invalid cron",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
            )
        # FIX-4.6.3: Now validates field count first
        error_msg = str(exc_info.value).lower()
        assert "cron" in error_msg and (
            "invalid" in error_msg or "5 fields" in error_msg
        )

    def test_invalid_cron_too_few_fields(self) -> None:
        """Cron with too few fields raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="Bad Cron",
                cron_expression="* * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
            )
        # FIX-4.6.3: Now requires exactly 5 fields
        assert "5 fields" in str(exc_info.value)

    def test_invalid_cron_six_fields_rejected(self) -> None:
        """FIX-4.6.3: 6-field cron expressions are rejected."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="Six Field Cron",
                cron_expression="0 0 9 * * *",  # 6 fields (with seconds)
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
            )
        assert "5 fields" in str(exc_info.value)

    def test_minimum_interval_one_minute_allowed(self) -> None:
        """FIX-4.6.5: Cron every minute is allowed (minimum interval)."""
        # Every minute is exactly MIN_INTERVAL_MINUTES (1 min), should pass
        schedule = ScheduledTaskCreate(
            name="Every Minute",
            cron_expression="* * * * *",
            task_type=TaskType.AGENT_TASK,
            task_payload={"prompt": "test"},
        )
        assert schedule.cron_expression == "* * * * *"

    def test_invalid_timezone(self) -> None:
        """Invalid timezone raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="Bad TZ",
                cron_expression="0 9 * * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
                timezone="Invalid/Timezone",
            )
        assert "Invalid timezone" in str(exc_info.value)

    def test_valid_timezones(self) -> None:
        """Various valid timezones work."""
        timezones = ["UTC", "America/New_York", "Europe/London", "Asia/Tokyo"]
        for tz in timezones:
            schedule = ScheduledTaskCreate(
                name="TZ Test",
                cron_expression="0 9 * * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
                timezone=tz,
            )
            assert schedule.timezone == tz

    def test_agent_task_requires_prompt(self) -> None:
        """Agent task without prompt raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="No Prompt",
                cron_expression="0 9 * * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={},
            )
        assert "prompt" in str(exc_info.value).lower()

    def test_send_email_requires_to(self) -> None:
        """Send email without 'to' raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="No To",
                cron_expression="0 9 * * *",
                task_type=TaskType.SEND_EMAIL,
                task_payload={"subject": "Test"},
            )
        assert "to" in str(exc_info.value).lower()

    def test_send_email_requires_subject(self) -> None:
        """Send email without 'subject' raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="No Subject",
                cron_expression="0 9 * * *",
                task_type=TaskType.SEND_EMAIL,
                task_payload={"to": "test@example.com"},
            )
        assert "subject" in str(exc_info.value).lower()

    def test_create_doc_requires_template(self) -> None:
        """Create doc without template raises error."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskCreate(
                name="No Template",
                cron_expression="0 9 * * *",
                task_type=TaskType.CREATE_DOC,
                task_payload={"title": "Test"},
            )
        assert "template" in str(exc_info.value).lower()

    def test_name_max_length(self) -> None:
        """Name exceeding max length raises error."""
        with pytest.raises(ValidationError):
            ScheduledTaskCreate(
                name="x" * 256,
                cron_expression="0 9 * * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
            )

    def test_extra_fields_forbidden(self) -> None:
        """Extra fields raise validation error."""
        with pytest.raises(ValidationError):
            ScheduledTaskCreate(
                name="Extra",
                cron_expression="0 9 * * *",
                task_type=TaskType.AGENT_TASK,
                task_payload={"prompt": "test"},
                extra_field="not allowed",
            )


class TestScheduledTaskUpdate:
    """ScheduledTaskUpdate model tests."""

    def test_partial_update_name(self) -> None:
        """Can update just name."""
        update = ScheduledTaskUpdate(name="New Name")
        assert update.name == "New Name"
        assert update.cron_expression is None

    def test_partial_update_enabled(self) -> None:
        """Can update just enabled flag."""
        update = ScheduledTaskUpdate(enabled=False)
        assert update.enabled is False
        assert update.name is None

    def test_update_cron_validates(self) -> None:
        """Cron update validates expression."""
        with pytest.raises(ValidationError):
            ScheduledTaskUpdate(cron_expression="invalid")

    def test_update_cron_six_fields_rejected(self) -> None:
        """FIX-4.6.3: 6-field cron in update is rejected."""
        with pytest.raises(ValidationError) as exc_info:
            ScheduledTaskUpdate(cron_expression="0 0 9 * * *")
        assert "5 fields" in str(exc_info.value)

    def test_update_cron_valid_five_fields(self) -> None:
        """Valid 5-field cron in update is accepted."""
        update = ScheduledTaskUpdate(cron_expression="0 9 * * *")
        assert update.cron_expression == "0 9 * * *"

    def test_update_timezone_validates(self) -> None:
        """Timezone update validates."""
        with pytest.raises(ValidationError):
            ScheduledTaskUpdate(timezone="Bad/Zone")

    def test_empty_update_allowed(self) -> None:
        """Empty update is allowed."""
        update = ScheduledTaskUpdate()
        assert update.name is None


class TestScheduledTaskFilter:
    """ScheduledTaskFilter model tests."""

    def test_default_values(self) -> None:
        """Default filter values."""
        filter_params = ScheduledTaskFilter()
        assert filter_params.enabled is None
        assert filter_params.task_type is None
        assert filter_params.limit == 50
        assert filter_params.offset == 0

    def test_filter_by_enabled(self) -> None:
        """Filter by enabled status."""
        filter_params = ScheduledTaskFilter(enabled=True)
        assert filter_params.enabled is True

    def test_filter_by_task_type(self) -> None:
        """Filter by task type."""
        filter_params = ScheduledTaskFilter(task_type=TaskType.AGENT_TASK)
        assert filter_params.task_type == TaskType.AGENT_TASK

    def test_limit_max_constraint(self) -> None:
        """Limit has max constraint."""
        with pytest.raises(ValidationError):
            ScheduledTaskFilter(limit=1000)

    def test_offset_non_negative(self) -> None:
        """Offset must be non-negative."""
        with pytest.raises(ValidationError):
            ScheduledTaskFilter(offset=-1)
