"""Pytest configuration for scheduler tests."""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from apps.api.scheduler.models import (
    ScheduledTaskCreate,
    ScheduledTaskResponse,
    TaskType,
)


@pytest.fixture
def mock_db_session() -> MagicMock:
    """Create mock database session."""
    session = MagicMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    session.refresh = AsyncMock()
    session.add = MagicMock()
    return session


@pytest.fixture
def mock_session_factory(mock_db_session: MagicMock):
    """Create mock session factory that returns the mock session.

    FIX-4.6.2 Round 3: Returns @asynccontextmanager for use with 'async with'.
    """

    @asynccontextmanager
    async def _session_factory() -> AsyncGenerator[MagicMock, None]:
        yield mock_db_session

    return _session_factory


@pytest.fixture
def sample_user_id() -> str:
    """Sample user ID for tests."""
    return str(uuid4())


@pytest.fixture
def sample_schedule_id() -> str:
    """Sample schedule ID for tests."""
    return str(uuid4())


@pytest.fixture
def sample_schedule_create() -> ScheduledTaskCreate:
    """Sample schedule create data."""
    return ScheduledTaskCreate(
        name="Daily Report",
        cron_expression="0 9 * * *",
        task_type=TaskType.AGENT_TASK,
        task_payload={"prompt": "Generate daily summary"},
        timezone="America/New_York",
    )


@pytest.fixture
def sample_schedule_response(
    sample_user_id: str, sample_schedule_id: str
) -> ScheduledTaskResponse:
    """Sample schedule response."""
    return ScheduledTaskResponse(
        id=sample_schedule_id,
        user_id=sample_user_id,
        name="Daily Report",
        cron_expression="0 9 * * *",
        task_type=TaskType.AGENT_TASK,
        task_payload={"prompt": "Generate daily summary"},
        timezone="America/New_York",
        enabled=True,
        next_run_at=datetime.now(UTC),
        last_run_at=None,
        last_result=None,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


@pytest.fixture
def mock_apscheduler():
    """Mock APScheduler AsyncIOScheduler."""
    with patch("apps.api.scheduler.service.AsyncIOScheduler") as mock_scheduler:
        mock_instance = MagicMock()
        mock_instance.start = MagicMock()
        mock_instance.shutdown = MagicMock()
        mock_instance.add_job = MagicMock()
        mock_instance.remove_job = MagicMock()
        mock_instance.pause_job = MagicMock()
        mock_instance.resume_job = MagicMock()
        mock_scheduler.return_value = mock_instance
        yield mock_instance


@pytest.fixture
def db_row_factory():
    """Factory to create mock database rows."""

    def _create_row(
        id: str | None = None,
        user_id: str | None = None,
        project_id: str | None = None,
        name: str = "Test Schedule",
        cron_expression: str = "0 9 * * *",
        task_type: str = "agent_task",
        task_payload: dict | None = None,
        timezone: str = "UTC",
        enabled: bool = True,
        next_run_at: datetime | None = None,
        last_run_at: datetime | None = None,
        last_result: dict | None = None,
        created_at: datetime | None = None,
        updated_at: datetime | None = None,
    ) -> MagicMock:
        row = MagicMock()
        row.id = id or str(uuid4())
        row.user_id = user_id or str(uuid4())
        row.project_id = project_id  # Explicitly None by default
        row.name = name
        row.cron_expression = cron_expression
        row.task_type = task_type
        row.task_payload = task_payload or {"prompt": "test"}
        row.timezone = timezone
        row.enabled = enabled
        row.next_run_at = next_run_at or datetime.now(UTC)
        row.last_run_at = last_run_at
        row.last_result = last_result
        row.created_at = created_at or datetime.now(UTC)
        row.updated_at = updated_at or datetime.now(UTC)
        return row

    return _create_row
