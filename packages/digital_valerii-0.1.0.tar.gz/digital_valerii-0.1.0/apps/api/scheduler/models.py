"""Scheduler service Pydantic models."""

from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID

import pytz
from croniter import croniter
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# Rate limiting constants (FIX-4.6.5)
MIN_INTERVAL_MINUTES = 1  # Minimum 1 minute between runs


class TaskType(str, Enum):
    """Types of scheduled tasks."""

    AGENT_TASK = "agent_task"
    SEND_EMAIL = "send_email"
    CREATE_DOC = "create_doc"


class ScheduledTaskCreate(BaseModel):
    """Create a new scheduled task."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=1, max_length=255)
    cron_expression: str = Field(..., description="Cron expression (5-6 parts)")
    task_type: TaskType
    task_payload: dict[str, Any]
    timezone: str = Field(default="UTC")
    enabled: bool = True

    @field_validator("cron_expression")
    @classmethod
    def validate_cron(cls, v: str) -> str:
        """Validate cron expression format (5 fields only, FIX-4.6.3)."""
        # FIX-4.6.3: APScheduler CronTrigger.from_crontab expects exactly 5 fields
        parts = v.strip().split()
        if len(parts) != 5:
            raise ValueError(
                f"Cron expression must have exactly 5 fields "
                f"(minute hour day month weekday), got {len(parts)}"
            )
        try:
            # croniter validates the expression syntax
            croniter(v)
        except (ValueError, KeyError) as e:
            raise ValueError(f"Invalid cron expression: {e}") from e
        return v

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, v: str) -> str:
        """Validate timezone is a valid IANA timezone."""
        try:
            pytz.timezone(v)
        except pytz.exceptions.UnknownTimeZoneError as e:
            raise ValueError(f"Invalid timezone: {v}") from e
        return v

    @model_validator(mode="after")
    def validate_payload_for_task_type(self) -> "ScheduledTaskCreate":
        """Validate task payload contains required fields for task type."""
        if self.task_type == TaskType.AGENT_TASK:
            if "prompt" not in self.task_payload:
                raise ValueError("task_payload must contain 'prompt' for agent_task")
            if not self.task_payload["prompt"]:
                raise ValueError("prompt cannot be empty for agent_task")
        elif self.task_type == TaskType.SEND_EMAIL:
            required = ["to", "subject"]
            missing = [f for f in required if f not in self.task_payload]
            if missing:
                raise ValueError(f"task_payload must contain {missing} for send_email")
        elif self.task_type == TaskType.CREATE_DOC:
            if "template" not in self.task_payload:
                raise ValueError("task_payload must contain 'template' for create_doc")
        return self

    @model_validator(mode="after")
    def validate_cron_frequency(self) -> "ScheduledTaskCreate":
        """Ensure cron doesn't run more frequently than allowed (FIX-4.6.5)."""
        cron = croniter(self.cron_expression, datetime.now(UTC))
        first_run = cron.get_next(datetime)
        second_run = cron.get_next(datetime)

        interval_minutes = (second_run - first_run).total_seconds() / 60
        if interval_minutes < MIN_INTERVAL_MINUTES:
            raise ValueError(
                f"Schedule runs too frequently ({interval_minutes:.1f} min). "
                f"Minimum interval: {MIN_INTERVAL_MINUTES} min"
            )
        return self


class ScheduledTaskUpdate(BaseModel):
    """Update a scheduled task."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(None, min_length=1, max_length=255)
    cron_expression: str | None = None
    task_type: TaskType | None = None
    task_payload: dict[str, Any] | None = None
    timezone: str | None = None
    enabled: bool | None = None

    @field_validator("cron_expression")
    @classmethod
    def validate_cron(cls, v: str | None) -> str | None:
        """Validate cron expression format if provided (5 fields only, FIX-4.6.3)."""
        if v is None:
            return v
        # FIX-4.6.3: APScheduler CronTrigger.from_crontab expects exactly 5 fields
        parts = v.strip().split()
        if len(parts) != 5:
            raise ValueError(
                f"Cron expression must have exactly 5 fields "
                f"(minute hour day month weekday), got {len(parts)}"
            )
        try:
            croniter(v)
        except (ValueError, KeyError) as e:
            raise ValueError(f"Invalid cron expression: {e}") from e

        # FIX-4.6.5: Validate minimum interval
        cron = croniter(v, datetime.now(UTC))
        first_run = cron.get_next(datetime)
        second_run = cron.get_next(datetime)
        interval_minutes = (second_run - first_run).total_seconds() / 60
        if interval_minutes < MIN_INTERVAL_MINUTES:
            raise ValueError(
                f"Schedule runs too frequently ({interval_minutes:.1f} min). "
                f"Minimum interval: {MIN_INTERVAL_MINUTES} min"
            )
        return v

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, v: str | None) -> str | None:
        """Validate timezone is a valid IANA timezone if provided."""
        if v is None:
            return v
        try:
            pytz.timezone(v)
        except pytz.exceptions.UnknownTimeZoneError as e:
            raise ValueError(f"Invalid timezone: {v}") from e
        return v


class ScheduledTaskResponse(BaseModel):
    """Scheduled task response."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    user_id: UUID
    project_id: UUID | None
    name: str
    cron_expression: str
    task_type: TaskType
    task_payload: dict[str, Any]
    timezone: str
    last_run_at: datetime | None
    next_run_at: datetime | None
    last_result: dict[str, Any] | None
    enabled: bool
    created_at: datetime
    updated_at: datetime


class ScheduledTaskFilter(BaseModel):
    """Filter for scheduled task queries."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool | None = None
    task_type: TaskType | None = None
    limit: int = Field(default=50, ge=1, le=100)
    offset: int = Field(default=0, ge=0)
