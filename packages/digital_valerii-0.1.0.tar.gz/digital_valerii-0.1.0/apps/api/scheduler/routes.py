"""Scheduler API endpoints."""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, status
from jose import JWTError

from apps.api.auth.jwt import JWTService
from apps.api.config import settings
from apps.api.dependencies import SchedulerServiceDep
from apps.api.scheduler.models import (
    ScheduledTaskCreate,
    ScheduledTaskFilter,
    ScheduledTaskResponse,
    ScheduledTaskUpdate,
    TaskType,
)
from apps.api.scheduler.service import (
    PayloadValidationError,
    ScheduleLimitExceededError,
    ScheduleNotFoundError,
)

router = APIRouter(prefix="/schedules", tags=["scheduler"])


# =============================================================================
# Dependencies
# =============================================================================


def get_jwt_service() -> JWTService:
    """Get JWT service."""
    return JWTService(
        secret_key=settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
        access_token_expire_minutes=settings.access_token_expire_minutes,
        refresh_token_expire_days=settings.refresh_token_expire_days,
    )


JWTServiceDep = Annotated[JWTService, Depends(get_jwt_service)]


async def get_current_user_id(
    jwt_service: JWTServiceDep,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> UUID:
    """Get current user ID from JWT token.

    Args:
        jwt_service: JWT service.
        authorization: Authorization header.

    Returns:
        User ID.

    Raises:
        HTTPException: If not authenticated.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = authorization.replace("Bearer ", "")

    try:
        token_data = jwt_service.verify_token(token, "access")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from None

    return UUID(token_data.sub)


CurrentUserId = Annotated[UUID, Depends(get_current_user_id)]

# Use singleton from dependencies (FIX-4.6.1)
SchedulerDep = SchedulerServiceDep


# =============================================================================
# Endpoints
# =============================================================================


@router.post(
    "", response_model=ScheduledTaskResponse, status_code=status.HTTP_201_CREATED
)
async def create_schedule(
    schedule: ScheduledTaskCreate,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> ScheduledTaskResponse:
    """Create a new scheduled task.

    Args:
        schedule: Schedule creation data.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Returns:
        Created schedule.

    Raises:
        HTTPException: If schedule limit exceeded.
    """
    try:
        return await scheduler.add_schedule(schedule, user_id=user_id)
    except ScheduleLimitExceededError as e:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(e),
        ) from None


@router.get("", response_model=list[ScheduledTaskResponse])
async def list_schedules(
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
    enabled: bool | None = None,
    task_type: TaskType | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[ScheduledTaskResponse]:
    """List user's scheduled tasks.

    Args:
        user_id: Current user ID.
        scheduler: Scheduler service.
        enabled: Filter by enabled status.
        task_type: Filter by task type.
        limit: Maximum results.
        offset: Results offset.

    Returns:
        List of schedules.
    """
    filter_params = ScheduledTaskFilter(
        enabled=enabled,
        task_type=task_type,
        limit=limit,
        offset=offset,
    )
    return await scheduler.list_schedules(user_id, filter_params)


@router.get("/{schedule_id}", response_model=ScheduledTaskResponse)
async def get_schedule(
    schedule_id: UUID,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> ScheduledTaskResponse:
    """Get schedule details.

    Args:
        schedule_id: Schedule ID.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Returns:
        Schedule details.

    Raises:
        HTTPException: If schedule not found.
    """
    try:
        return await scheduler.get_schedule(schedule_id, user_id)
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None


@router.put("/{schedule_id}", response_model=ScheduledTaskResponse)
async def update_schedule(
    schedule_id: UUID,
    update: ScheduledTaskUpdate,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> ScheduledTaskResponse:
    """Update a scheduled task.

    Args:
        schedule_id: Schedule ID.
        update: Update data.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Returns:
        Updated schedule.

    Raises:
        HTTPException: If schedule not found or payload validation fails.
    """
    try:
        return await scheduler.update_schedule(schedule_id, update, user_id)
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None
    except PayloadValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(e),
        ) from None


@router.delete("/{schedule_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_schedule(
    schedule_id: UUID,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> None:
    """Delete a scheduled task.

    Args:
        schedule_id: Schedule ID.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Raises:
        HTTPException: If schedule not found.
    """
    try:
        await scheduler.delete_schedule(schedule_id, user_id)
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None


@router.post("/{schedule_id}/pause", status_code=status.HTTP_204_NO_CONTENT)
async def pause_schedule(
    schedule_id: UUID,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> None:
    """Pause a schedule without deleting.

    Args:
        schedule_id: Schedule ID.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Raises:
        HTTPException: If schedule not found.
    """
    try:
        await scheduler.pause_schedule(schedule_id, user_id)
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None


@router.post("/{schedule_id}/resume", status_code=status.HTTP_204_NO_CONTENT)
async def resume_schedule(
    schedule_id: UUID,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> None:
    """Resume a paused schedule.

    Args:
        schedule_id: Schedule ID.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Raises:
        HTTPException: If schedule not found.
    """
    try:
        await scheduler.resume_schedule(schedule_id, user_id)
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None


@router.post("/{schedule_id}/trigger", response_model=dict)
async def trigger_schedule(
    schedule_id: UUID,
    user_id: CurrentUserId,
    scheduler: SchedulerDep,
) -> dict:
    """Manually trigger a scheduled task.

    Creates a task_queue entry immediately.

    Args:
        schedule_id: Schedule ID.
        user_id: Current user ID.
        scheduler: Scheduler service.

    Returns:
        Task ID of the created task.

    Raises:
        HTTPException: If schedule not found.
    """
    try:
        task_id = await scheduler.trigger_now(schedule_id, user_id)
        return {"task_id": str(task_id)}
    except ScheduleNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Schedule not found",
        ) from None
