"""Authentication dependencies for FastAPI.

Per ISO 42001 A.8.3: JWT-based authentication for audit trail.
"""

from typing import Annotated
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError

from apps.api.auth.jwt import JWTService
from apps.api.auth.models import User
from apps.api.auth.service import UserService
from apps.api.config import settings
from apps.api.dependencies import DBSession, get_redis

# HTTPBearer with auto_error=False to allow optional auth
security = HTTPBearer(auto_error=False)


def get_jwt_service() -> JWTService:
    """Get JWT service instance.

    Returns:
        JWTService configured with settings.
    """
    return JWTService(
        secret_key=settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
        access_token_expire_minutes=settings.access_token_expire_minutes,
        refresh_token_expire_days=settings.refresh_token_expire_days,
    )


async def get_user_service(
    db: DBSession,
    redis: Annotated[object | None, Depends(get_redis)],
) -> UserService:
    """Get user service instance.

    Args:
        db: Database session.
        redis: Redis service (RedisService wrapper).

    Returns:
        UserService instance.
    """
    # Pass redis.client (raw Redis) to UserService, not the RedisService wrapper
    redis_client = getattr(redis, "client", None) if redis else None
    return UserService(db=db, redis=redis_client)


async def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(security)],
    db: DBSession,
) -> User:
    """Get current user from JWT token.

    Replaces the stub get_current_user_id() in approvals.py.

    Args:
        credentials: HTTP Bearer credentials.
        db: Database session.

    Returns:
        Authenticated user.

    Raises:
        HTTPException: If not authenticated or token invalid.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    jwt_service = get_jwt_service()

    try:
        token_data = jwt_service.verify_token(credentials.credentials, "access")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from None

    # Get user service without Redis for simple lookup
    user_service = UserService(db=db, redis=None)
    user = await user_service.get_by_id(UUID(token_data.sub))

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is disabled",
        )

    return user


async def get_current_user_optional(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(security)],
    db: DBSession,
) -> User | None:
    """Get current user or None if not authenticated.

    Args:
        credentials: HTTP Bearer credentials.
        db: Database session.

    Returns:
        User or None.
    """
    if not credentials:
        return None
    try:
        return await get_current_user(credentials, db)
    except HTTPException:
        return None


# Type aliases for dependency injection
CurrentUserDep = Annotated[User, Depends(get_current_user)]
OptionalUserDep = Annotated[User | None, Depends(get_current_user_optional)]
JWTServiceDep = Annotated[JWTService, Depends(get_jwt_service)]
UserServiceDep = Annotated[UserService, Depends(get_user_service)]
