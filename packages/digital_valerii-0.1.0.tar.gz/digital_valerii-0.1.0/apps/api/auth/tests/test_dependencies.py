"""Tests for auth dependencies."""

import sys
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest
from fastapi import HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials
from fastapi.testclient import TestClient

from apps.api.auth.jwt import JWTService
from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password

# Mock digital_valerii_shared before importing dependencies
mock_shared = MagicMock()
mock_shared.agent = MagicMock()
mock_shared.config = MagicMock()
mock_shared.services = MagicMock()
sys.modules["digital_valerii_shared"] = mock_shared
sys.modules["digital_valerii_shared.agent"] = mock_shared.agent
sys.modules["digital_valerii_shared.config"] = mock_shared.config
sys.modules["digital_valerii_shared.services"] = mock_shared.services
sys.modules["digital_valerii_shared.services.audit"] = MagicMock()
sys.modules["digital_valerii_shared.services.embedding"] = MagicMock()
sys.modules["digital_valerii_shared.services.memory"] = MagicMock()
sys.modules["digital_valerii_shared.services.qdrant"] = MagicMock()
sys.modules["digital_valerii_shared.services.redis"] = MagicMock()
sys.modules["digital_valerii_shared.models"] = MagicMock()
sys.modules["digital_valerii_shared.models.base"] = MagicMock()

# Now import dependencies (after mocking)
from apps.api.auth.dependencies import (  # noqa: E402
    get_current_user,
    get_current_user_optional,
    get_jwt_service,
)
from apps.api.main import app  # noqa: E402


@pytest.fixture
def sample_user() -> User:
    """Create sample user for tests."""
    return User(
        id=str(uuid4()),
        email="test@example.com",
        password_hash=hash_password("securepassword123"),
        display_name="Test User",
        role=UserRole.USER.value,
        is_active=True,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


@pytest.fixture
def inactive_user() -> User:
    """Create inactive user for tests."""
    return User(
        id=str(uuid4()),
        email="inactive@example.com",
        password_hash=hash_password("password123"),
        display_name="Inactive User",
        role=UserRole.USER.value,
        is_active=False,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


class TestGetJWTService:
    """get_jwt_service dependency tests."""

    def test_returns_jwt_service(self) -> None:
        """Returns configured JWTService instance."""
        service = get_jwt_service()

        assert isinstance(service, JWTService)


class TestGetCurrentUser:
    """get_current_user dependency tests."""

    @pytest.mark.asyncio
    async def test_no_credentials_raises_401(self) -> None:
        """No credentials raises 401."""
        mock_db = MagicMock()

        with pytest.raises(HTTPException) as exc:
            await get_current_user(credentials=None, db=mock_db)

        assert exc.value.status_code == status.HTTP_401_UNAUTHORIZED

    @pytest.mark.asyncio
    async def test_invalid_token_raises_401(self) -> None:
        """Invalid token raises 401."""
        mock_db = MagicMock()
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials="invalid-token",
        )

        with pytest.raises(HTTPException) as exc:
            await get_current_user(credentials=credentials, db=mock_db)

        assert exc.value.status_code == status.HTTP_401_UNAUTHORIZED

    @pytest.mark.asyncio
    async def test_user_not_found_raises_401(self, jwt_service: JWTService) -> None:
        """User not found raises 401."""
        user_id = uuid4()
        token, _ = jwt_service.create_access_token(user_id)
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=token,
        )

        mock_db = MagicMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_db.execute = AsyncMock(return_value=mock_result)

        with (
            patch(
                "apps.api.auth.dependencies.get_jwt_service", return_value=jwt_service
            ),
            pytest.raises(HTTPException) as exc,
        ):
            await get_current_user(credentials=credentials, db=mock_db)

        assert exc.value.status_code == status.HTTP_401_UNAUTHORIZED

    @pytest.mark.asyncio
    async def test_inactive_user_raises_401(
        self, jwt_service: JWTService, inactive_user: User
    ) -> None:
        """Inactive user raises 401."""
        from uuid import UUID

        token, _ = jwt_service.create_access_token(UUID(inactive_user.id))
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=token,
        )

        mock_db = MagicMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = inactive_user
        mock_db.execute = AsyncMock(return_value=mock_result)

        with (
            patch(
                "apps.api.auth.dependencies.get_jwt_service", return_value=jwt_service
            ),
            pytest.raises(HTTPException) as exc,
        ):
            await get_current_user(credentials=credentials, db=mock_db)

        assert exc.value.status_code == status.HTTP_401_UNAUTHORIZED

    @pytest.mark.asyncio
    async def test_valid_token_returns_user(
        self, jwt_service: JWTService, sample_user: User
    ) -> None:
        """Valid token returns user."""
        from uuid import UUID

        token, _ = jwt_service.create_access_token(UUID(sample_user.id))
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=token,
        )

        mock_db = MagicMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_user
        mock_db.execute = AsyncMock(return_value=mock_result)

        with patch(
            "apps.api.auth.dependencies.get_jwt_service", return_value=jwt_service
        ):
            user = await get_current_user(credentials=credentials, db=mock_db)

        assert user == sample_user


class TestGetCurrentUserOptional:
    """get_current_user_optional dependency tests."""

    @pytest.mark.asyncio
    async def test_no_credentials_returns_none(self) -> None:
        """No credentials returns None."""
        mock_db = MagicMock()

        result = await get_current_user_optional(credentials=None, db=mock_db)

        assert result is None

    @pytest.mark.asyncio
    async def test_invalid_token_returns_none(self) -> None:
        """Invalid token returns None."""
        mock_db = MagicMock()
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials="invalid-token",
        )

        result = await get_current_user_optional(credentials=credentials, db=mock_db)

        assert result is None

    @pytest.mark.asyncio
    async def test_valid_token_returns_user(
        self, jwt_service: JWTService, sample_user: User
    ) -> None:
        """Valid token returns user."""
        from uuid import UUID

        token, _ = jwt_service.create_access_token(UUID(sample_user.id))
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=token,
        )

        mock_db = MagicMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_user
        mock_db.execute = AsyncMock(return_value=mock_result)

        with patch(
            "apps.api.auth.dependencies.get_jwt_service", return_value=jwt_service
        ):
            user = await get_current_user_optional(credentials=credentials, db=mock_db)

        assert user == sample_user


class TestApprovalsUsesJWTAuth:
    """Test that approvals endpoints use JWT auth.

    NOTE: These tests are skipped until approvals endpoints are updated
    to use JWT auth instead of the current stub get_current_user_id().
    """

    @pytest.mark.skip(reason="Approvals endpoints don't have JWT auth yet (use stub)")
    def test_approvals_pending_requires_auth(self) -> None:
        """Approvals pending endpoint requires authentication."""
        client = TestClient(app, raise_server_exceptions=False)

        response = client.get("/api/v1/approvals/pending")

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    @pytest.mark.skip(reason="Approvals endpoints don't have JWT auth yet (use stub)")
    def test_approvals_get_requires_auth(self) -> None:
        """Approvals get endpoint requires authentication."""
        client = TestClient(app, raise_server_exceptions=False)
        approval_id = str(uuid4())

        response = client.get(f"/api/v1/approvals/{approval_id}")

        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestAuthRouterMounted:
    """Test that auth router is mounted correctly."""

    def test_auth_register_route_exists(self) -> None:
        """Auth register route exists."""
        client = TestClient(app, raise_server_exceptions=False)

        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "test@example.com",
                "password": "password123",
                "display_name": "Test",
            },
        )

        # Should not be 404 (route exists)
        assert response.status_code != status.HTTP_404_NOT_FOUND

    def test_auth_login_route_exists(self) -> None:
        """Auth login route exists."""
        client = TestClient(app, raise_server_exceptions=False)

        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "test@example.com",
                "password": "password123",
            },
        )

        # Should not be 404 (route exists)
        assert response.status_code != status.HTTP_404_NOT_FOUND

    def test_auth_me_route_exists(self) -> None:
        """Auth me route exists."""
        client = TestClient(app, raise_server_exceptions=False)

        response = client.get("/api/v1/auth/me")

        # Should be 401 not 404 (route exists but requires auth)
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
