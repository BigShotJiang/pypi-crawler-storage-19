"""Tests for JWT service."""

from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
from jose import JWTError

from apps.api.auth.jwt import JWTService, TokenData


class TestJWTService:
    """JWT service tests."""

    def test_create_access_token(self, jwt_service: JWTService) -> None:
        """Create access token returns token and expiry."""
        user_id = uuid4()
        token, expires_at = jwt_service.create_access_token(user_id)

        assert isinstance(token, str)
        assert len(token) > 0
        assert expires_at > datetime.now(UTC)

    def test_create_access_token_expiry(self, jwt_service: JWTService) -> None:
        """Access token expiry is approximately 30 minutes."""
        user_id = uuid4()
        token, expires_at = jwt_service.create_access_token(user_id)

        delta = expires_at - datetime.now(UTC)
        # Should be approximately 30 minutes (1800 seconds)
        assert 1798 <= delta.total_seconds() <= 1802

    def test_create_refresh_token(self, jwt_service: JWTService) -> None:
        """Create refresh token returns token, jti, and expiry."""
        user_id = uuid4()
        token, jti, expires_at = jwt_service.create_refresh_token(user_id)

        assert isinstance(token, str)
        assert isinstance(jti, str)
        assert len(jti) == 36  # UUID length
        assert expires_at > datetime.now(UTC)

    def test_create_refresh_token_expiry(self, jwt_service: JWTService) -> None:
        """Refresh token expiry is approximately 7 days."""
        user_id = uuid4()
        token, jti, expires_at = jwt_service.create_refresh_token(user_id)

        delta = expires_at - datetime.now(UTC)
        # Should be approximately 7 days (604800 seconds)
        # Allow small variance for test execution time
        assert 604790 <= delta.total_seconds() <= 604810

    def test_verify_access_token(self, jwt_service: JWTService) -> None:
        """Verify valid access token returns TokenData."""
        user_id = uuid4()
        token, _ = jwt_service.create_access_token(user_id)

        data = jwt_service.verify_token(token, "access")

        assert data.sub == str(user_id)
        assert data.type == "access"
        assert data.jti is not None

    def test_verify_refresh_token(self, jwt_service: JWTService) -> None:
        """Verify valid refresh token returns TokenData."""
        user_id = uuid4()
        token, jti, _ = jwt_service.create_refresh_token(user_id)

        data = jwt_service.verify_token(token, "refresh")

        assert data.sub == str(user_id)
        assert data.type == "refresh"
        assert data.jti == jti

    def test_verify_wrong_token_type(self, jwt_service: JWTService) -> None:
        """Verify token with wrong type raises error."""
        user_id = uuid4()
        token, _ = jwt_service.create_access_token(user_id)

        with pytest.raises(JWTError, match="Expected refresh token"):
            jwt_service.verify_token(token, "refresh")

    def test_verify_invalid_token(self, jwt_service: JWTService) -> None:
        """Verify invalid token raises error."""
        with pytest.raises(JWTError):
            jwt_service.verify_token("invalid.token.here", "access")

    def test_verify_expired_token(self, jwt_service: JWTService) -> None:
        """Verify expired token raises error."""
        from jose import jwt as jose_jwt

        # Create an already-expired token manually
        user_id = uuid4()
        expired_time = datetime.now(UTC) - timedelta(minutes=5)

        payload = {
            "sub": str(user_id),
            "exp": expired_time,
            "type": "access",
            "jti": str(uuid4()),
        }

        expired_token = jose_jwt.encode(
            payload, jwt_service.secret_key, algorithm=jwt_service.algorithm
        )

        with pytest.raises(JWTError, match="expired"):
            jwt_service.verify_token(expired_token, "access")

    def test_verify_wrong_secret(self, jwt_service: JWTService) -> None:
        """Token signed with different secret fails verification."""
        user_id = uuid4()
        token, _ = jwt_service.create_access_token(user_id)

        other_service = JWTService(secret_key="different-secret")

        with pytest.raises(JWTError):
            other_service.verify_token(token, "access")

    def test_create_token_pair(self, jwt_service: JWTService) -> None:
        """Create token pair returns TokenPair and refresh jti."""
        user_id = uuid4()
        token_pair, refresh_jti = jwt_service.create_token_pair(user_id)

        assert token_pair.access_token is not None
        assert token_pair.refresh_token is not None
        assert token_pair.token_type == "bearer"
        assert token_pair.expires_in > 0
        assert isinstance(refresh_jti, str)

    def test_token_data_extra_forbid(self) -> None:
        """TokenData rejects extra fields."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            TokenData(
                sub="user123",
                exp=datetime.now(UTC),
                type="access",
                jti="jti123",
                extra_field="value",
            )

    def test_verify_token_missing_sub_claim(self, jwt_service: JWTService) -> None:
        """Token missing 'sub' claim raises JWTError."""
        from jose import jwt as jose_jwt

        payload = {
            "exp": datetime.now(UTC) + timedelta(minutes=30),
            "type": "access",
            "jti": str(uuid4()),
            # Missing 'sub'
        }

        token = jose_jwt.encode(
            payload, jwt_service.secret_key, algorithm=jwt_service.algorithm
        )

        with pytest.raises(JWTError, match="Missing required claim: sub"):
            jwt_service.verify_token(token, "access")

    def test_verify_token_missing_type_claim(self, jwt_service: JWTService) -> None:
        """Token missing 'type' claim raises JWTError."""
        from jose import jwt as jose_jwt

        payload = {
            "sub": str(uuid4()),
            "exp": datetime.now(UTC) + timedelta(minutes=30),
            "jti": str(uuid4()),
            # Missing 'type'
        }

        token = jose_jwt.encode(
            payload, jwt_service.secret_key, algorithm=jwt_service.algorithm
        )

        with pytest.raises(JWTError, match="Missing required claim: type"):
            jwt_service.verify_token(token, "access")

    def test_verify_token_missing_jti_claim(self, jwt_service: JWTService) -> None:
        """Token missing 'jti' claim raises JWTError."""
        from jose import jwt as jose_jwt

        payload = {
            "sub": str(uuid4()),
            "exp": datetime.now(UTC) + timedelta(minutes=30),
            "type": "access",
            # Missing 'jti'
        }

        token = jose_jwt.encode(
            payload, jwt_service.secret_key, algorithm=jwt_service.algorithm
        )

        with pytest.raises(JWTError, match="Missing required claim: jti"):
            jwt_service.verify_token(token, "access")

    def test_algorithm_configurable(self) -> None:
        """JWT algorithm is configurable."""
        service = JWTService(
            secret_key="test-secret",
            algorithm="HS384",
        )

        assert service.algorithm == "HS384"

        # Create and verify with HS384
        user_id = uuid4()
        token, _ = service.create_access_token(user_id)

        # Should be able to verify
        data = service.verify_token(token, "access")
        assert data.sub == str(user_id)
