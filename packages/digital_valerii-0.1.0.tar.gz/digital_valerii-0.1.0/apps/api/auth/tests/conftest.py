"""Pytest configuration for auth tests."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.auth.jwt import JWTService
from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password


@pytest.fixture
def jwt_service() -> JWTService:
    """Create JWT service with test secret."""
    return JWTService(
        secret_key="test-secret-key-for-unit-tests",
        access_token_expire_minutes=30,
        refresh_token_expire_days=7,
    )


@pytest.fixture
def mock_db_session() -> MagicMock:
    """Create mock database session."""
    session = MagicMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    session.refresh = AsyncMock()
    session.add = MagicMock()
    return session


@pytest.fixture
def mock_redis() -> MagicMock:
    """Create mock Redis client."""
    redis = MagicMock()
    redis.setex = AsyncMock()
    redis.exists = AsyncMock(return_value=True)
    redis.delete = AsyncMock()
    return redis


@pytest.fixture
def sample_user() -> User:
    """Create sample user for tests."""
    user = User(
        id=str(uuid4()),
        email="test@example.com",
        password_hash=hash_password("securepassword123"),
        display_name="Test User",
        role=UserRole.USER.value,
        is_active=True,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    return user


@pytest.fixture
def inactive_user() -> User:
    """Create inactive user for tests."""
    user = User(
        id=str(uuid4()),
        email="inactive@example.com",
        password_hash=hash_password("password123"),
        display_name="Inactive User",
        role=UserRole.USER.value,
        is_active=False,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )
    return user
