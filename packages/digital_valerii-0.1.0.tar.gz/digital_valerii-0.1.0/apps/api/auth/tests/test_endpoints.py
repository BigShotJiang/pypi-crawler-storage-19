"""Tests for auth endpoints."""

import sys
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from fastapi import status
from fastapi.testclient import TestClient

from apps.api.auth.jwt import JWTService
from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password

# Mock digital_valerii_shared before importing app
mock_shared = MagicMock()
mock_shared.agent = MagicMock()
mock_shared.config = MagicMock()
mock_shared.services = MagicMock()
sys.modules["digital_valerii_shared"] = mock_shared
sys.modules["digital_valerii_shared.agent"] = mock_shared.agent
sys.modules["digital_valerii_shared.config"] = mock_shared.config
sys.modules["digital_valerii_shared.services"] = mock_shared.services
sys.modules["digital_valerii_shared.services.audit"] = MagicMock()
sys.modules["digital_valerii_shared.services.embedding"] = MagicMock()
sys.modules["digital_valerii_shared.services.memory"] = MagicMock()
sys.modules["digital_valerii_shared.services.qdrant"] = MagicMock()
sys.modules["digital_valerii_shared.services.redis"] = MagicMock()
sys.modules["digital_valerii_shared.models"] = MagicMock()
sys.modules["digital_valerii_shared.models.base"] = MagicMock()

# Now import app (after mocking)
from apps.api.main import app  # noqa: E402


@pytest.fixture
def client() -> TestClient:
    """Create test client."""
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture
def jwt_service() -> JWTService:
    """Create JWT service with test secret."""
    return JWTService(
        secret_key="test-secret-key-for-unit-tests",
        access_token_expire_minutes=30,
        refresh_token_expire_days=7,
    )


@pytest.fixture
def mock_user_service(jwt_service: JWTService):
    """Create mock user service using FastAPI dependency override."""
    from apps.api.api.routes.auth import get_jwt_service, get_user_service

    service = MagicMock()
    service.email_exists = AsyncMock(return_value=False)
    service.create_user = AsyncMock()
    service.authenticate = AsyncMock()
    service.get_by_id = AsyncMock()
    service.store_refresh_token = AsyncMock()
    service.update_last_login = AsyncMock()
    service.revoke_refresh_token = AsyncMock()
    service.is_refresh_token_valid = AsyncMock(return_value=True)

    async def override_get_user_service():
        return service

    def override_get_jwt_service():
        return jwt_service

    app.dependency_overrides[get_user_service] = override_get_user_service
    app.dependency_overrides[get_jwt_service] = override_get_jwt_service
    yield service
    app.dependency_overrides.clear()


@pytest.fixture
def test_user() -> User:
    """Create test user."""
    return User(
        id=str(uuid4()),
        email="test@example.com",
        password_hash=hash_password("password123"),
        display_name="Test User",
        role=UserRole.USER.value,
        is_active=True,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


@pytest.fixture
def inactive_user() -> User:
    """Create inactive user."""
    return User(
        id=str(uuid4()),
        email="inactive@example.com",
        password_hash=hash_password("password123"),
        display_name="Inactive User",
        role=UserRole.USER.value,
        is_active=False,
        is_verified=False,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


class TestRegisterEndpoint:
    """POST /auth/register tests."""

    def test_register_success(
        self, client: TestClient, mock_user_service: MagicMock
    ) -> None:
        """Register new user successfully."""
        mock_user_service.create_user.return_value = User(
            id=str(uuid4()),
            email="new@example.com",
            password_hash="hashed",
            display_name="New User",
            role=UserRole.USER.value,
            is_active=True,
            is_verified=False,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )

        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "new@example.com",
                "password": "securepass123",
                "display_name": "New User",
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["email"] == "new@example.com"

    def test_register_email_exists(
        self, client: TestClient, mock_user_service: MagicMock
    ) -> None:
        """Register with existing email fails."""
        mock_user_service.email_exists.return_value = True

        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "exists@example.com",
                "password": "securepass123",
                "display_name": "User",
            },
        )

        assert response.status_code == status.HTTP_409_CONFLICT

    def test_register_invalid_email(self, client: TestClient) -> None:
        """Register with invalid email fails validation."""
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "not-an-email",
                "password": "securepass123",
                "display_name": "User",
            },
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_register_short_password(self, client: TestClient) -> None:
        """Register with short password fails validation."""
        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "test@example.com",
                "password": "short",
                "display_name": "User",
            },
        )

        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY

    def test_register_race_condition(
        self, client: TestClient, mock_user_service: MagicMock
    ) -> None:
        """Race condition in registration returns 409 not 500."""
        from sqlalchemy.exc import IntegrityError

        # First check returns False (email doesn't exist)
        mock_user_service.email_exists.return_value = False
        # But create_user raises IntegrityError (race condition)
        mock_user_service.create_user.side_effect = IntegrityError(
            statement="INSERT INTO users",
            params={},
            orig=Exception("duplicate key"),
        )

        response = client.post(
            "/api/v1/auth/register",
            json={
                "email": "race@example.com",
                "password": "securepass123",
                "display_name": "Race User",
            },
        )

        # Should return 409 Conflict, not 500 Internal Server Error
        assert response.status_code == status.HTTP_409_CONFLICT


class TestLoginEndpoint:
    """POST /auth/login tests."""

    def test_login_success(
        self, client: TestClient, mock_user_service: MagicMock, test_user: User
    ) -> None:
        """Login with valid credentials."""
        mock_user_service.authenticate.return_value = test_user

        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "test@example.com",
                "password": "password123",
            },
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"

    def test_login_invalid_credentials(
        self, client: TestClient, mock_user_service: MagicMock
    ) -> None:
        """Login with invalid credentials fails."""
        mock_user_service.authenticate.return_value = None

        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "test@example.com",
                "password": "wrongpassword",
            },
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_login_inactive_user(
        self, client: TestClient, mock_user_service: MagicMock, inactive_user: User
    ) -> None:
        """Login with inactive user fails."""
        mock_user_service.authenticate.return_value = inactive_user

        response = client.post(
            "/api/v1/auth/login",
            json={
                "email": "inactive@example.com",
                "password": "password123",
            },
        )

        assert response.status_code == status.HTTP_403_FORBIDDEN


class TestLogoutEndpoint:
    """POST /auth/logout tests."""

    def test_logout_success(
        self,
        client: TestClient,
        mock_user_service: MagicMock,  # noqa: ARG002
        jwt_service: JWTService,
        test_user: User,
    ) -> None:
        """Logout revokes refresh token."""
        from uuid import UUID

        refresh_token, _, _ = jwt_service.create_refresh_token(UUID(test_user.id))

        response = client.post(
            "/api/v1/auth/logout",
            json={"refresh_token": refresh_token},
        )

        assert response.status_code == status.HTTP_200_OK

    def test_logout_invalid_token(
        self,
        client: TestClient,
        mock_user_service: MagicMock,  # noqa: ARG002
    ) -> None:
        """Logout with invalid token fails."""
        response = client.post(
            "/api/v1/auth/logout",
            json={"refresh_token": "invalid-token"},
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestRefreshEndpoint:
    """POST /auth/refresh tests."""

    def test_refresh_success(
        self,
        client: TestClient,
        mock_user_service: MagicMock,
        jwt_service: JWTService,
        test_user: User,
    ) -> None:
        """Refresh token returns new token pair."""
        from uuid import UUID

        refresh_token, _, _ = jwt_service.create_refresh_token(UUID(test_user.id))
        mock_user_service.get_by_id.return_value = test_user

        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": refresh_token},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data

    def test_refresh_revoked_token(
        self,
        client: TestClient,
        mock_user_service: MagicMock,
        jwt_service: JWTService,
        test_user: User,
    ) -> None:
        """Refresh with revoked token fails."""
        from uuid import UUID

        refresh_token, _, _ = jwt_service.create_refresh_token(UUID(test_user.id))
        mock_user_service.is_refresh_token_valid.return_value = False

        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": refresh_token},
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_refresh_invalid_token(
        self,
        client: TestClient,
        mock_user_service: MagicMock,  # noqa: ARG002
    ) -> None:
        """Refresh with invalid token fails."""
        response = client.post(
            "/api/v1/auth/refresh",
            json={"refresh_token": "invalid-token"},
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED


class TestMeEndpoint:
    """GET /auth/me tests."""

    def test_me_success(
        self,
        client: TestClient,
        mock_user_service: MagicMock,
        jwt_service: JWTService,
        test_user: User,
    ) -> None:
        """Get current user with valid token."""
        from uuid import UUID

        access_token, _ = jwt_service.create_access_token(UUID(test_user.id))
        mock_user_service.get_by_id.return_value = test_user

        response = client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {access_token}"},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == "test@example.com"

    def test_me_no_token(self, client: TestClient) -> None:
        """Get current user without token fails."""
        response = client.get("/api/v1/auth/me")

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_me_invalid_token(self, client: TestClient) -> None:
        """Get current user with invalid token fails."""
        response = client.get(
            "/api/v1/auth/me",
            headers={"Authorization": "Bearer invalid-token"},
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_me_user_not_found(
        self,
        client: TestClient,
        mock_user_service: MagicMock,
        jwt_service: JWTService,
    ) -> None:
        """Get current user when user deleted fails."""
        access_token, _ = jwt_service.create_access_token(uuid4())
        mock_user_service.get_by_id.return_value = None

        response = client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {access_token}"},
        )

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
