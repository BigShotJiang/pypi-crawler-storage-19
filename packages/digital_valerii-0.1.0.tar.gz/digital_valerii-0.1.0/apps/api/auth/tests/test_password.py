"""Tests for password hashing."""

from apps.api.auth.password import hash_password, verify_password


class TestPasswordHashing:
    """Password hashing function tests."""

    def test_hash_password_returns_string(self) -> None:
        """Hash password returns a string."""
        result = hash_password("testpassword")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_hash_password_different_each_time(self) -> None:
        """Same password produces different hashes (salt)."""
        password = "samepassword"
        hash1 = hash_password(password)
        hash2 = hash_password(password)
        assert hash1 != hash2

    def test_hash_password_uses_argon2(self) -> None:
        """Hash uses argon2 algorithm."""
        result = hash_password("testpassword")
        assert result.startswith("$argon2")

    def test_verify_password_correct(self) -> None:
        """Verify correct password returns True."""
        password = "correctpassword"
        hashed = hash_password(password)
        assert verify_password(password, hashed) is True

    def test_verify_password_incorrect(self) -> None:
        """Verify incorrect password returns False."""
        hashed = hash_password("original")
        assert verify_password("wrong", hashed) is False

    def test_verify_password_empty_fails(self) -> None:
        """Empty password does not match hash."""
        hashed = hash_password("password")
        assert verify_password("", hashed) is False

    def test_hash_password_handles_unicode(self) -> None:
        """Hash handles unicode passwords."""
        password = "пароль123"  # Ukrainian "password123"
        hashed = hash_password(password)
        assert verify_password(password, hashed) is True

    def test_hash_password_handles_special_chars(self) -> None:
        """Hash handles special characters."""
        password = "P@ssw0rd!#$%^&*()"
        hashed = hash_password(password)
        assert verify_password(password, hashed) is True
