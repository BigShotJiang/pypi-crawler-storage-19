"""Tests for auth models."""

import pytest
from pydantic import ValidationError

from apps.api.auth.models import User, UserRole
from apps.api.auth.schemas import (
    TokenPair,
    TokenRefresh,
    UserCreate,
    UserLogin,
    UserResponse,
)


class TestUserRole:
    """UserRole enum tests."""

    def test_role_values(self) -> None:
        """Verify all expected role values exist."""
        assert UserRole.OWNER.value == "owner"
        assert UserRole.ADMIN.value == "admin"
        assert UserRole.USER.value == "user"

    def test_role_from_string(self) -> None:
        """Verify role can be created from string."""
        assert UserRole("owner") == UserRole.OWNER
        assert UserRole("admin") == UserRole.ADMIN
        assert UserRole("user") == UserRole.USER


class TestUserModel:
    """User SQLAlchemy model tests."""

    def test_user_repr(self, sample_user: User) -> None:
        """Verify user string representation."""
        assert repr(sample_user) == "<User test@example.com>"

    def test_user_defaults(self) -> None:
        """Verify user default values when explicitly set."""
        # SQLAlchemy defaults apply on DB insert, not Python object creation
        # Test with explicit role to verify model works correctly
        user = User(
            email="new@example.com",
            password_hash="hashed",
            display_name="New User",
            role=UserRole.USER.value,
            is_active=True,
            is_verified=False,
        )
        assert user.role == UserRole.USER.value
        assert user.is_active is True
        assert user.is_verified is False


class TestUserSchemas:
    """Pydantic schema tests."""

    def test_user_create_valid(self) -> None:
        """Create user with valid data."""
        user = UserCreate(
            email="test@example.com",
            password="securepass123",
            display_name="Test User",
        )
        assert user.email == "test@example.com"
        assert user.display_name == "Test User"

    def test_user_create_password_min_length(self) -> None:
        """Password must be at least 8 characters."""
        with pytest.raises(ValidationError):
            UserCreate(
                email="test@example.com",
                password="short",
                display_name="Test User",
            )

    def test_user_create_extra_forbid(self) -> None:
        """Extra fields are rejected."""
        with pytest.raises(ValidationError):
            UserCreate(
                email="test@example.com",
                password="securepass123",
                display_name="Test User",
                unknown_field="value",
            )

    def test_user_login_valid(self) -> None:
        """Create login with valid data."""
        login = UserLogin(
            email="test@example.com",
            password="password",
        )
        assert login.email == "test@example.com"

    def test_user_response_from_attributes(self, sample_user: User) -> None:
        """Create response from User model."""
        response = UserResponse.model_validate(sample_user)
        assert response.email == sample_user.email
        assert response.display_name == sample_user.display_name

    def test_token_pair_valid(self) -> None:
        """Create token pair."""
        pair = TokenPair(
            access_token="access",
            refresh_token="refresh",
            expires_in=1800,
        )
        assert pair.token_type == "bearer"
        assert pair.expires_in == 1800

    def test_token_refresh_valid(self) -> None:
        """Create token refresh request."""
        refresh = TokenRefresh(refresh_token="token123")
        assert refresh.refresh_token == "token123"

    def test_token_refresh_extra_forbid(self) -> None:
        """Extra fields are rejected."""
        with pytest.raises(ValidationError):
            TokenRefresh(
                refresh_token="token123",
                unknown="value",
            )
