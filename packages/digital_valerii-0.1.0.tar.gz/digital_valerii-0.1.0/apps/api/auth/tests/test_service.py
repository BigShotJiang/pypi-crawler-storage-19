"""Tests for user service."""

from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from apps.api.auth.models import User
from apps.api.auth.password import hash_password
from apps.api.auth.schemas import UserCreate
from apps.api.auth.service import UserService


class TestUserServiceCreate:
    """UserService.create_user tests."""

    @pytest.mark.asyncio
    async def test_create_user_success(self, mock_db_session: MagicMock) -> None:
        """Create user with valid data."""
        service = UserService(db=mock_db_session, redis=None)
        data = UserCreate(
            email="new@example.com",
            password="securepass123",
            display_name="New User",
        )

        user = await service.create_user(data)

        assert user.email == "new@example.com"
        assert user.display_name == "New User"
        mock_db_session.add.assert_called_once()
        mock_db_session.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_user_lowercases_email(
        self, mock_db_session: MagicMock
    ) -> None:
        """Email is lowercased on creation."""
        service = UserService(db=mock_db_session, redis=None)
        data = UserCreate(
            email="Test@EXAMPLE.com",
            password="securepass123",
            display_name="Test",
        )

        user = await service.create_user(data)

        assert user.email == "test@example.com"


class TestUserServiceGet:
    """UserService get methods tests."""

    @pytest.mark.asyncio
    async def test_get_by_email_found(
        self, mock_db_session: MagicMock, sample_user: User
    ) -> None:
        """Get user by email when exists."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_user
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        user = await service.get_by_email("test@example.com")

        assert user == sample_user

    @pytest.mark.asyncio
    async def test_get_by_email_not_found(self, mock_db_session: MagicMock) -> None:
        """Get user by email when not exists."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        user = await service.get_by_email("notfound@example.com")

        assert user is None

    @pytest.mark.asyncio
    async def test_get_by_id_found(
        self, mock_db_session: MagicMock, sample_user: User
    ) -> None:
        """Get user by ID when exists."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = sample_user
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        user = await service.get_by_id(uuid4())

        assert user == sample_user


class TestUserServiceAuthenticate:
    """UserService.authenticate tests."""

    @pytest.mark.asyncio
    async def test_authenticate_success(self, mock_db_session: MagicMock) -> None:
        """Authenticate with valid credentials."""
        password = "correctpassword"
        user = User(
            email="auth@example.com",
            password_hash=hash_password(password),
            display_name="Auth User",
        )
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = user
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        result = await service.authenticate("auth@example.com", password)

        assert result == user

    @pytest.mark.asyncio
    async def test_authenticate_wrong_password(
        self, mock_db_session: MagicMock
    ) -> None:
        """Authenticate with wrong password fails."""
        user = User(
            email="auth@example.com",
            password_hash=hash_password("correctpassword"),
            display_name="Auth User",
        )
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = user
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        result = await service.authenticate("auth@example.com", "wrongpassword")

        assert result is None

    @pytest.mark.asyncio
    async def test_authenticate_user_not_found(
        self, mock_db_session: MagicMock
    ) -> None:
        """Authenticate with non-existent user fails."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        result = await service.authenticate("notfound@example.com", "password")

        assert result is None


class TestUserServiceRefreshTokens:
    """UserService refresh token management tests."""

    @pytest.mark.asyncio
    async def test_store_refresh_token_with_redis(
        self, mock_db_session: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Store refresh token in Redis."""
        service = UserService(db=mock_db_session, redis=mock_redis)
        jti = "token-jti-123"
        user_id = uuid4()

        await service.store_refresh_token(jti, user_id)

        mock_redis.setex.assert_called_once()

    @pytest.mark.asyncio
    async def test_store_refresh_token_without_redis(
        self, mock_db_session: MagicMock
    ) -> None:
        """Store refresh token without Redis (no-op)."""
        service = UserService(db=mock_db_session, redis=None)
        jti = "token-jti-123"
        user_id = uuid4()

        # Should not raise
        await service.store_refresh_token(jti, user_id)

    @pytest.mark.asyncio
    async def test_is_refresh_token_valid_with_redis(
        self, mock_db_session: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Check token validity with Redis."""
        mock_redis.exists.return_value = True
        service = UserService(db=mock_db_session, redis=mock_redis)

        result = await service.is_refresh_token_valid("jti123")

        assert result is True

    @pytest.mark.asyncio
    async def test_is_refresh_token_valid_without_redis(
        self, mock_db_session: MagicMock
    ) -> None:
        """Check token validity without Redis (fail closed - always invalid)."""
        service = UserService(db=mock_db_session, redis=None)

        result = await service.is_refresh_token_valid("jti123")

        # Fail closed: without Redis, refresh tokens are invalid
        assert result is False

    @pytest.mark.asyncio
    async def test_revoke_refresh_token_with_redis(
        self, mock_db_session: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Revoke refresh token in Redis."""
        service = UserService(db=mock_db_session, redis=mock_redis)

        await service.revoke_refresh_token("jti123")

        mock_redis.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_email_exists_true(self, mock_db_session: MagicMock) -> None:
        """Email exists returns True."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = "some-id"
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        result = await service.email_exists("exists@example.com")

        assert result is True

    @pytest.mark.asyncio
    async def test_email_exists_false(self, mock_db_session: MagicMock) -> None:
        """Email does not exist returns False."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_db_session.execute.return_value = mock_result

        service = UserService(db=mock_db_session, redis=None)
        result = await service.email_exists("notexists@example.com")

        assert result is False
