"""User service for authentication operations.

Per ISO 42001 A.8.3: User management for audit trail.
"""

import warnings
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password, verify_password
from apps.api.auth.schemas import UserCreate
from apps.api.config import RedisNamespace


class UserService:
    """User service for CRUD operations.

    Per ISO 42001 A.8.3: User identity management.
    """

    def __init__(self, db: AsyncSession, redis: Any | None = None):
        """Initialize user service.

        Args:
            db: Database session.
            redis: Optional Redis client for refresh tokens.
        """
        self.db = db
        self.redis = redis

    async def create_user(self, data: UserCreate) -> User:
        """Create a new user.

        Args:
            data: User creation data.

        Returns:
            Created user.
        """
        user = User(
            email=data.email.lower(),
            password_hash=hash_password(data.password),
            display_name=data.display_name,
            role=UserRole.USER.value,
        )
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user

    async def get_by_email(self, email: str) -> User | None:
        """Get user by email.

        Args:
            email: User email.

        Returns:
            User or None if not found.
        """
        result = await self.db.execute(
            select(User).where(
                User.email == email.lower(),
                User.deleted_at.is_(None),
            )
        )
        return result.scalar_one_or_none()

    async def get_by_id(self, user_id: UUID) -> User | None:
        """Get user by ID.

        Args:
            user_id: User ID.

        Returns:
            User or None if not found.
        """
        result = await self.db.execute(
            select(User).where(
                User.id == str(user_id),
                User.deleted_at.is_(None),
            )
        )
        return result.scalar_one_or_none()

    async def authenticate(self, email: str, password: str) -> User | None:
        """Authenticate user with email and password.

        Args:
            email: User email.
            password: Plain text password.

        Returns:
            User if authenticated, None otherwise.
        """
        user = await self.get_by_email(email)
        if not user:
            return None

        if not verify_password(password, user.password_hash):
            return None

        return user

    async def update_last_login(self, user_id: UUID) -> None:
        """Update user's last login timestamp.

        Args:
            user_id: User ID.
        """
        await self.db.execute(
            update(User)
            .where(User.id == str(user_id))
            .values(last_login_at=datetime.now(UTC))
        )
        await self.db.commit()

    async def email_exists(self, email: str) -> bool:
        """Check if email is already registered.

        Args:
            email: Email to check.

        Returns:
            True if email exists, False otherwise.
        """
        result = await self.db.execute(
            select(User.id).where(
                User.email == email.lower(),
                User.deleted_at.is_(None),
            )
        )
        return result.scalar_one_or_none() is not None

    # Refresh token management (Redis)

    async def store_refresh_token(
        self, jti: str, user_id: UUID, ttl_days: int = 7
    ) -> None:
        """Store refresh token JTI for revocation checking.

        Args:
            jti: JWT ID.
            user_id: User ID.
            ttl_days: TTL in days.
        """
        if not self.redis:
            warnings.warn(
                "Redis unavailable - refresh tokens will not work",
                UserWarning,
                stacklevel=2,
            )
            return
        key = f"{RedisNamespace.REFRESH_TOKENS}{jti}"
        await self.redis.setex(key, ttl_days * 86400, str(user_id))

    async def is_refresh_token_valid(self, jti: str) -> bool:
        """Check if refresh token JTI exists (not revoked).

        Fail closed: if Redis unavailable, reject refresh.

        Args:
            jti: JWT ID.

        Returns:
            True if valid, False if revoked, not found, or Redis unavailable.
        """
        if not self.redis:
            return False  # Fail closed - no Redis = no refresh tokens
        key = f"{RedisNamespace.REFRESH_TOKENS}{jti}"
        return await self.redis.exists(key)

    async def revoke_refresh_token(self, jti: str) -> None:
        """Revoke refresh token by removing JTI.

        Args:
            jti: JWT ID.
        """
        if not self.redis:
            return
        key = f"{RedisNamespace.REFRESH_TOKENS}{jti}"
        await self.redis.delete(key)
