"""Authentication module for Digital Valerii API.

Per ISO 42001 A.8.3: User identity for audit trail.
Per EU AI Act Art.14: Human oversight requires user identification.
"""

from apps.api.auth.jwt import JWTService, TokenData
from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password, verify_password
from apps.api.auth.schemas import (
    TokenPair,
    TokenRefresh,
    UserCreate,
    UserLogin,
    UserResponse,
)

__all__ = [
    "JWTService",
    "TokenData",
    "TokenPair",
    "TokenRefresh",
    "User",
    "UserCreate",
    "UserLogin",
    "UserResponse",
    "UserRole",
    "hash_password",
    "verify_password",
]
