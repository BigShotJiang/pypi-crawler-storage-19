"""Pydantic schemas for authentication.

Per ISO 42001 A.8.3: User identity schemas for audit trail.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from apps.api.auth.models import UserRole


class UserCreate(BaseModel):
    """User registration request."""

    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    display_name: str = Field(..., min_length=1, max_length=100)


class UserLogin(BaseModel):
    """User login request."""

    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str


class UserResponse(BaseModel):
    """User response (no password)."""

    model_config = ConfigDict(extra="forbid", from_attributes=True)

    id: UUID
    email: EmailStr
    display_name: str
    role: UserRole
    is_active: bool
    is_verified: bool
    created_at: datetime


class TokenPair(BaseModel):
    """Access + refresh token pair."""

    model_config = ConfigDict(extra="forbid")

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds


class TokenRefresh(BaseModel):
    """Refresh token request."""

    model_config = ConfigDict(extra="forbid")

    refresh_token: str
