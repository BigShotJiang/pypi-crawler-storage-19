"""JWT token utilities for authentication.

Per ISO 42001 A.8.3: Token-based authentication for audit trail.
"""

from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid4

from jose import JWTError, jwt
from pydantic import BaseModel, ConfigDict

from apps.api.auth.schemas import TokenPair


class TokenData(BaseModel):
    """JWT payload data."""

    model_config = ConfigDict(extra="forbid")

    sub: str  # user_id
    exp: datetime
    type: str  # "access" or "refresh"
    jti: str  # JWT ID for revocation


class JWTService:
    """JWT token management.

    Access tokens: 30 minutes
    Refresh tokens: 7 days

    Per ISO 42001 A.8.3: Token-based authentication.
    """

    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        access_token_expire_minutes: int = 30,
        refresh_token_expire_days: int = 7,
    ):
        """Initialize JWT service.

        Args:
            secret_key: Secret key for signing tokens.
            algorithm: JWT signing algorithm (default: HS256).
            access_token_expire_minutes: Access token expiry in minutes.
            refresh_token_expire_days: Refresh token expiry in days.
        """
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire_minutes = access_token_expire_minutes
        self.refresh_token_expire_days = refresh_token_expire_days

    def create_access_token(self, user_id: UUID) -> tuple[str, datetime]:
        """Create access token.

        Args:
            user_id: User ID to encode in token.

        Returns:
            Tuple of (token, expires_at).
        """
        expires_at = datetime.now(UTC) + timedelta(
            minutes=self.access_token_expire_minutes
        )
        jti = str(uuid4())

        payload = {
            "sub": str(user_id),
            "exp": expires_at,
            "type": "access",
            "jti": jti,
        }

        token = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
        return token, expires_at

    def create_refresh_token(self, user_id: UUID) -> tuple[str, str, datetime]:
        """Create refresh token.

        Args:
            user_id: User ID to encode in token.

        Returns:
            Tuple of (token, jti, expires_at).
        """
        expires_at = datetime.now(UTC) + timedelta(days=self.refresh_token_expire_days)
        jti = str(uuid4())

        payload = {
            "sub": str(user_id),
            "exp": expires_at,
            "type": "refresh",
            "jti": jti,
        }

        token = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
        return token, jti, expires_at

    def verify_token(self, token: str, expected_type: str = "access") -> TokenData:
        """Verify and decode token.

        Args:
            token: JWT token to verify.
            expected_type: Expected token type ("access" or "refresh").

        Returns:
            TokenData with decoded payload.

        Raises:
            JWTError: If token is invalid, expired, missing claims, or wrong type.
        """
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
        except jwt.ExpiredSignatureError:
            raise JWTError("Token has expired") from None
        except jwt.JWTClaimsError:
            raise JWTError("Invalid token claims") from None
        except Exception:
            raise JWTError("Invalid token") from None

        # Validate required claims
        required_claims = ["sub", "exp", "type", "jti"]
        for claim in required_claims:
            if claim not in payload:
                raise JWTError(f"Missing required claim: {claim}")

        token_type = payload.get("type")
        if token_type != expected_type:
            raise JWTError(f"Expected {expected_type} token, got {token_type}")

        return TokenData(
            sub=payload["sub"],
            exp=datetime.fromtimestamp(payload["exp"], tz=UTC),
            type=payload["type"],
            jti=payload["jti"],
        )

    def create_token_pair(self, user_id: UUID) -> tuple[TokenPair, str]:
        """Create access + refresh token pair.

        Args:
            user_id: User ID to encode in tokens.

        Returns:
            Tuple of (TokenPair, refresh_jti).
        """
        access_token, access_expires = self.create_access_token(user_id)
        refresh_token, refresh_jti, _ = self.create_refresh_token(user_id)

        expires_in = int((access_expires - datetime.now(UTC)).total_seconds())

        return TokenPair(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=expires_in,
        ), refresh_jti
