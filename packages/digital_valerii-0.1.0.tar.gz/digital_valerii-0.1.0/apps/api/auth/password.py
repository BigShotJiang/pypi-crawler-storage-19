"""Password hashing utilities.

Uses argon2 as primary algorithm (OWASP recommended).
Per ISO 42001 A.8.3: Secure password storage.
"""

from passlib.context import CryptContext

# Use argon2 as primary, bcrypt as fallback
pwd_context = CryptContext(
    schemes=["argon2", "bcrypt"],
    deprecated="auto",
)


def hash_password(password: str) -> str:
    """Hash password using argon2.

    Args:
        password: Plain text password.

    Returns:
        Hashed password string.
    """
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against hash.

    Args:
        plain_password: Plain text password to verify.
        hashed_password: Stored hashed password.

    Returns:
        True if password matches, False otherwise.
    """
    return pwd_context.verify(plain_password, hashed_password)
