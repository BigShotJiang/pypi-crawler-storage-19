"""Approval requests table for human oversight.

Revision ID: 004
Revises: 003
Create Date: 2025-01-04

Per EU AI Act Art.14 (Human Oversight) and ISO 42001 A.9.3 (Responsible Use).
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "004"
down_revision: str | None = "003"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "approval_requests",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column("tool_name", sa.String(100), nullable=False),
        sa.Column("arguments", postgresql.JSONB, nullable=False),
        sa.Column("context", postgresql.JSONB, nullable=False),  # user_id, session_id
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("risk_level", sa.String(20), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("decided_by", sa.String(100), nullable=True),
        sa.Column("decision_reason", sa.Text, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
    )

    # Indexes for common queries
    op.create_index(
        "ix_approval_status",
        "approval_requests",
        ["status"],
    )
    op.create_index(
        "ix_approval_created",
        "approval_requests",
        [sa.text("created_at DESC")],
    )
    op.create_index(
        "ix_approval_expires",
        "approval_requests",
        ["expires_at"],
    )
    # Index for JSONB user_id lookup
    op.create_index(
        "ix_approval_user",
        "approval_requests",
        [sa.text("(context->>'user_id')")],
    )
    op.create_index(
        "ix_approval_tool_name",
        "approval_requests",
        ["tool_name"],
    )


def downgrade() -> None:
    op.drop_table("approval_requests")
