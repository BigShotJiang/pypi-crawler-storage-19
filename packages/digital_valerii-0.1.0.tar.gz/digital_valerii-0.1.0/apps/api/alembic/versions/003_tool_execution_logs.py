"""Tool execution logs table for audit trail.

Revision ID: 003
Revises: 002
Create Date: 2025-01-04

Per ISO 42001 A.8.3 (External Reporting) and EU AI Act Art.14 (Traceability).
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "003"
down_revision: str | None = "002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "tool_execution_logs",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
        ),
        sa.Column("tool_name", sa.String(100), nullable=False),
        sa.Column("arguments", postgresql.JSONB, nullable=False),
        sa.Column("risk_level", sa.String(20), nullable=False),
        sa.Column("user_id", sa.String(100), nullable=False),
        sa.Column("session_id", sa.String(100), nullable=False),
        sa.Column("approved_by", sa.String(100), nullable=True),
        sa.Column("result_status", sa.String(20), nullable=False),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column(
            "executed_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
    )

    # Indexes for compliance queries
    op.create_index(
        "ix_tool_logs_user_executed",
        "tool_execution_logs",
        ["user_id", sa.text("executed_at DESC")],
    )
    op.create_index(
        "ix_tool_logs_session",
        "tool_execution_logs",
        ["session_id"],
    )
    op.create_index(
        "ix_tool_logs_risk_executed",
        "tool_execution_logs",
        ["risk_level", sa.text("executed_at DESC")],
    )
    op.create_index(
        "ix_tool_logs_tool_name",
        "tool_execution_logs",
        ["tool_name"],
    )
    op.create_index(
        "ix_tool_logs_result_status",
        "tool_execution_logs",
        ["result_status"],
    )


def downgrade() -> None:
    op.drop_table("tool_execution_logs")
