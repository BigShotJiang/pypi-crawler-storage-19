"""Fix schedule_id FK to allow schedule deletion.

FIX-4.6.4: The FK constraint on task_queue.schedule_id was restrictive,
preventing deletion of schedules that had executed tasks. This migration
changes it to ON DELETE SET NULL so schedules can be deleted while
preserving task history.

Revision ID: 009
Revises: 008
Create Date: 2025-01-09
"""

from alembic import op
from sqlalchemy import text

# revision identifiers, used by Alembic.
revision = "009"
down_revision = "008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Drop old FK and recreate with ON DELETE SET NULL."""
    conn = op.get_bind()

    # Check if FK exists before dropping
    fk_result = conn.execute(
        text("""
            SELECT constraint_name FROM information_schema.table_constraints
            WHERE table_name = 'task_queue' AND constraint_name = 'fk_task_queue_schedule'
        """)
    )
    if fk_result.fetchone():
        # Drop the existing restrictive FK constraint
        op.drop_constraint("fk_task_queue_schedule", "task_queue", type_="foreignkey")

    # Recreate with ON DELETE SET NULL
    # This allows deleting schedules while preserving task_queue history
    op.create_foreign_key(
        "fk_task_queue_schedule",
        "task_queue",
        "scheduled_tasks",
        ["schedule_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    """Restore original FK constraint (restrictive)."""
    op.drop_constraint("fk_task_queue_schedule", "task_queue", type_="foreignkey")

    op.create_foreign_key(
        "fk_task_queue_schedule",
        "task_queue",
        "scheduled_tasks",
        ["schedule_id"],
        ["id"],
    )
