"""Add scheduled_tasks table.

Revision ID: 008
Revises: 007
Create Date: 2025-01-09

Scheduler Service for cron-based task scheduling (Component 4.6).
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID

# revision identifiers, used by Alembic.
revision = "008"
down_revision = "007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create scheduled_tasks table and add schedule_id to task_queue."""
    # Create scheduled_tasks table
    op.create_table(
        "scheduled_tasks",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("users.id"),
            nullable=False,
        ),
        # project_id without FK - projects table not yet created
        sa.Column("project_id", PGUUID(as_uuid=True), nullable=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("cron_expression", sa.String(100), nullable=False),
        sa.Column("task_type", sa.String(50), nullable=False),
        sa.Column("task_payload", JSONB, nullable=False),
        sa.Column("timezone", sa.String(50), server_default="UTC"),
        sa.Column("last_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("next_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_result", JSONB, nullable=True),
        sa.Column("enabled", sa.Boolean, server_default="true"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
    )

    # Create indexes
    op.create_index(
        "ix_scheduled_tasks_next_run",
        "scheduled_tasks",
        ["next_run_at"],
        postgresql_where=text("enabled = true"),
    )
    op.create_index("ix_scheduled_tasks_user", "scheduled_tasks", ["user_id"])

    # Add schedule_id to task_queue (for linking tasks to schedules)
    # Use conditional check to handle case where column already exists
    conn = op.get_bind()
    result = conn.execute(
        text("""
            SELECT column_name FROM information_schema.columns
            WHERE table_name = 'task_queue' AND column_name = 'schedule_id'
        """)
    )
    if not result.fetchone():
        op.add_column(
            "task_queue",
            sa.Column("schedule_id", PGUUID(as_uuid=True), nullable=True),
        )

    # Create FK only if it doesn't exist
    fk_result = conn.execute(
        text("""
            SELECT constraint_name FROM information_schema.table_constraints
            WHERE table_name = 'task_queue' AND constraint_name = 'fk_task_queue_schedule'
        """)
    )
    if not fk_result.fetchone():
        op.create_foreign_key(
            "fk_task_queue_schedule",
            "task_queue",
            "scheduled_tasks",
            ["schedule_id"],
            ["id"],
        )


def downgrade() -> None:
    """Drop scheduled_tasks table and remove schedule_id from task_queue."""
    # Remove schedule_id from task_queue
    op.drop_constraint("fk_task_queue_schedule", "task_queue", type_="foreignkey")
    op.drop_column("task_queue", "schedule_id")

    # Drop indexes and table
    op.drop_index("ix_scheduled_tasks_user", table_name="scheduled_tasks")
    op.drop_index("ix_scheduled_tasks_next_run", table_name="scheduled_tasks")
    op.drop_table("scheduled_tasks")
