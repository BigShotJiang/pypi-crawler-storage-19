"""Unified Session Manager tables.

Revision ID: 011
Revises: 010
Create Date: 2025-01-11

Component 4.8: Unified Session Manager
- One session per user across all channels
- Session checkpoints for auto-compact recovery
- Cross-channel message queue
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID

# revision identifiers, used by Alembic.
revision = "011"
down_revision = "010"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add unified session manager tables."""
    # Create user_sessions table (one active session per user)
    op.create_table(
        "user_sessions",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("sdk_session_id", sa.String(255), nullable=True),
        sa.Column("status", sa.String(20), server_default="active", nullable=False),
        sa.Column("last_channel", sa.String(50), nullable=True),
        sa.Column(
            "last_activity_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column("compact_count", sa.Integer, server_default="0", nullable=False),
        sa.Column("checkpoint", JSONB, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
    )

    # Create partial unique index for one active session per user
    op.create_index(
        "ix_user_sessions_user_active",
        "user_sessions",
        ["user_id"],
        unique=True,
        postgresql_where=text("status = 'active'"),
    )

    # Create index for user + status lookup
    op.create_index(
        "ix_user_sessions_user_status",
        "user_sessions",
        ["user_id", "status"],
    )

    # Create session_checkpoints table
    op.create_table(
        "session_checkpoints",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_session_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("user_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("checkpoint_type", sa.String(20), nullable=False),
        sa.Column("summary", sa.Text, nullable=True),
        sa.Column("working_memory", JSONB, nullable=True),
        sa.Column("active_context", JSONB, nullable=True),
        sa.Column("message_count", sa.Integer, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
    )

    # Create index for checkpoint lookup by session
    op.create_index(
        "ix_session_checkpoints_session",
        "session_checkpoints",
        ["user_session_id", "created_at"],
    )

    # Create message_queue table for cross-channel messaging
    op.create_table(
        "message_queue",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_session_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("user_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("channel", sa.String(50), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("metadata", JSONB, server_default="'{}'", nullable=False),
        sa.Column("priority", sa.Integer, server_default="0", nullable=False),
        sa.Column("status", sa.String(20), server_default="pending", nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column("processed_at", sa.DateTime(timezone=True), nullable=True),
    )

    # Create partial index for pending messages
    op.create_index(
        "ix_message_queue_pending",
        "message_queue",
        ["user_session_id", "status", "created_at"],
        postgresql_where=text("status = 'pending'"),
    )


def downgrade() -> None:
    """Remove unified session manager tables."""
    # Drop message_queue
    op.drop_index("ix_message_queue_pending", table_name="message_queue")
    op.drop_table("message_queue")

    # Drop session_checkpoints
    op.drop_index("ix_session_checkpoints_session", table_name="session_checkpoints")
    op.drop_table("session_checkpoints")

    # Drop user_sessions
    op.drop_index("ix_user_sessions_user_status", table_name="user_sessions")
    op.drop_index("ix_user_sessions_user_active", table_name="user_sessions")
    op.drop_table("user_sessions")
