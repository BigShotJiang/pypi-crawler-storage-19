"""Event system tables.

Revision ID: 006
Revises: 005
Create Date: 2025-01-07

Event-Driven Architecture for Digital Valerii.
Tables: event_triggers, task_queue, event_log
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID

# revision identifiers, used by Alembic.
revision = "006"
down_revision = "005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create event system tables."""
    # Event triggers configuration
    op.create_table(
        "event_triggers",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("trigger_type", sa.String(50), nullable=False),
        sa.Column("source", sa.String(100), nullable=True),
        sa.Column("conditions", JSONB, nullable=True),
        sa.Column("action", JSONB, nullable=False),
        sa.Column("priority", sa.String(20), server_default="normal"),
        sa.Column("enabled", sa.Boolean, server_default="true"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )

    # Task execution queue
    op.create_table(
        "task_queue",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "trigger_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("event_triggers.id"),
            nullable=True,
        ),
        sa.Column("schedule_id", PGUUID(as_uuid=True), nullable=True),
        sa.Column("task_type", sa.String(50), nullable=False),
        sa.Column("payload", JSONB, nullable=False),
        sa.Column("priority", sa.String(20), server_default="normal"),
        sa.Column("status", sa.String(20), server_default="pending"),
        sa.Column("attempts", sa.Integer, server_default="0"),
        sa.Column("max_attempts", sa.Integer, server_default="3"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error", sa.Text, nullable=True),
    )

    # Event log for audit trail
    op.create_table(
        "event_log",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column("event_type", sa.String(50), nullable=False),
        sa.Column("source", sa.String(100), nullable=False),
        sa.Column("external_id", sa.String(255), nullable=True),
        sa.Column("payload", JSONB, nullable=True),
        sa.Column(
            "trigger_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("event_triggers.id"),
            nullable=True,
        ),
        sa.Column(
            "task_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("task_queue.id"),
            nullable=True,
        ),
        sa.Column("processed", sa.Boolean, server_default="false"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
    )

    # Indexes for event_triggers
    op.create_index("ix_event_triggers_type", "event_triggers", ["trigger_type"])
    op.create_index(
        "ix_event_triggers_enabled",
        "event_triggers",
        ["enabled"],
        postgresql_where=text("enabled = true"),
    )

    # Indexes for task_queue
    op.create_index("ix_task_queue_status", "task_queue", ["status", "priority"])
    op.create_index("ix_task_queue_created", "task_queue", ["created_at"])

    # Indexes for event_log
    op.create_index("ix_event_log_source", "event_log", ["source", "created_at"])
    op.create_index("ix_event_log_processed", "event_log", ["processed"])


def downgrade() -> None:
    """Drop event system tables."""
    # Drop indexes
    op.drop_index("ix_event_log_processed", table_name="event_log")
    op.drop_index("ix_event_log_source", table_name="event_log")
    op.drop_index("ix_task_queue_created", table_name="task_queue")
    op.drop_index("ix_task_queue_status", table_name="task_queue")
    op.drop_index("ix_event_triggers_enabled", table_name="event_triggers")
    op.drop_index("ix_event_triggers_type", table_name="event_triggers")

    # Drop tables in order (respecting foreign keys)
    op.drop_table("event_log")
    op.drop_table("task_queue")
    op.drop_table("event_triggers")
