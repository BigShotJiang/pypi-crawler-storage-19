"""Long-term Memory Architecture tables.

Revision ID: 012
Revises: 011
Create Date: 2025-01-11

Component 4.9: Long-term Memory Architecture
- Tiered memory (Working -> Active -> Archive)
- Annual archiving with strategic memory extraction
- Partitioned archived_events table by year
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID

# revision identifiers, used by Alembic.
revision = "012"
down_revision = "011"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add long-term memory architecture tables."""
    # Create archive_index table (metadata about each year's archive)
    op.create_table(
        "archive_index",
        sa.Column("year", sa.Integer, nullable=False),
        sa.Column(
            "user_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "archived_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column("event_count", sa.Integer, server_default="0", nullable=False),
        sa.Column("message_count", sa.Integer, server_default="0", nullable=False),
        sa.Column("project_count", sa.Integer, server_default="0", nullable=True),
        sa.Column("people_count", sa.Integer, server_default="0", nullable=True),
        sa.Column("lesson_count", sa.Integer, server_default="0", nullable=True),
        sa.Column("decision_count", sa.Integer, server_default="0", nullable=True),
        sa.Column("summary", sa.Text, nullable=False),
        sa.Column("key_achievements", sa.ARRAY(sa.Text), nullable=True),
        sa.Column("stats", JSONB, nullable=True),
        sa.Column("qdrant_collection", sa.String(50), nullable=False),
        sa.Column("size_bytes", sa.BigInteger, server_default="0", nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("year", "user_id"),
    )

    # Create index for user lookup
    op.create_index(
        "ix_archive_index_user",
        "archive_index",
        ["user_id"],
    )

    # Create strategic_memories table (kept in active for fast access)
    op.create_table(
        "strategic_memories",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "user_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("year", sa.Integer, nullable=False),
        # memory_type: project, person, lesson, decision, milestone
        sa.Column("memory_type", sa.String(50), nullable=False),
        sa.Column("entity_id", PGUUID(as_uuid=True), nullable=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("summary", sa.Text, nullable=False),
        sa.Column("keywords", sa.ARRAY(sa.Text), nullable=True),
        # importance: 0.0 to 1.0
        sa.Column(
            "importance",
            sa.Float,
            server_default="0.5",
            nullable=False,
        ),
        sa.Column("related_entities", JSONB, nullable=True),
        sa.Column("metadata", JSONB, nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.CheckConstraint(
            "importance >= 0 AND importance <= 1",
            name="ck_strategic_memories_importance",
        ),
    )

    # Create indexes for strategic_memories
    op.create_index(
        "ix_strategic_memories_user_year",
        "strategic_memories",
        ["user_id", "year"],
    )
    op.create_index(
        "ix_strategic_memories_type",
        "strategic_memories",
        ["memory_type"],
    )
    # GIN index for keywords array search
    op.execute(
        text(
            "CREATE INDEX ix_strategic_memories_keywords "
            "ON strategic_memories USING gin(keywords)"
        )
    )

    # Create archived_events table (partitioned by year)
    # Using raw SQL for partition support
    op.execute(
        text("""
            CREATE TABLE archived_events (
                id UUID NOT NULL DEFAULT gen_random_uuid(),
                user_id UUID NOT NULL,
                year INTEGER NOT NULL,
                original_id UUID NOT NULL,
                event_type VARCHAR(50) NOT NULL,
                title VARCHAR(255),
                content TEXT,
                occurred_at TIMESTAMPTZ,
                source VARCHAR(50),
                conversation_id UUID,
                importance FLOAT,
                metadata JSONB,
                embedding_id VARCHAR(100),
                archived_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (year, id)
            ) PARTITION BY LIST (year)
        """)
    )

    # Create indexes on partitioned table
    op.execute(
        text(
            "CREATE INDEX ix_archived_events_user ON archived_events(year, user_id)"
        )
    )
    op.execute(
        text(
            "CREATE INDEX ix_archived_events_type ON archived_events(year, event_type)"
        )
    )
    op.execute(
        text(
            "CREATE INDEX ix_archived_events_occurred ON archived_events(year, occurred_at)"
        )
    )
    op.execute(
        text(
            "CREATE INDEX ix_archived_events_original ON archived_events(year, original_id)"
        )
    )

    # Create a default partition for any years not explicitly covered
    op.execute(
        text(
            "CREATE TABLE archived_events_default "
            "PARTITION OF archived_events DEFAULT"
        )
    )


def downgrade() -> None:
    """Remove long-term memory architecture tables."""
    # Drop archived_events partitioned table and its default partition
    op.execute(text("DROP TABLE IF EXISTS archived_events_default"))
    op.execute(text("DROP TABLE IF EXISTS archived_events CASCADE"))

    # Drop strategic_memories
    op.execute(text("DROP INDEX IF EXISTS ix_strategic_memories_keywords"))
    op.drop_index("ix_strategic_memories_type", table_name="strategic_memories")
    op.drop_index("ix_strategic_memories_user_year", table_name="strategic_memories")
    op.drop_table("strategic_memories")

    # Drop archive_index
    op.drop_index("ix_archive_index_user", table_name="archive_index")
    op.drop_table("archive_index")
