"""Background task runner tables.

Revision ID: 010
Revises: 009
Create Date: 2025-01-10

Component 4.7: Background Task Runner
- Extend task_queue for multi-step execution
- Add task_step_history for step tracking
- Add task_templates for reusable task definitions
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.dialects.postgresql import UUID as PGUUID

# revision identifiers, used by Alembic.
revision = "010"
down_revision = "009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add background task runner tables and columns."""
    # Extend task_queue with new columns for multi-step tasks
    op.add_column(
        "task_queue",
        sa.Column("steps", JSONB, nullable=True),
    )
    op.add_column(
        "task_queue",
        sa.Column("progress", JSONB, nullable=True),
    )
    op.add_column(
        "task_queue",
        sa.Column("created_by_session_id", sa.String(255), nullable=True),
    )
    op.add_column(
        "task_queue",
        sa.Column("notification_channels", ARRAY(sa.Text), nullable=True),
    )
    op.add_column(
        "task_queue",
        sa.Column("result", JSONB, nullable=True),
    )
    op.add_column(
        "task_queue",
        sa.Column("error_details", JSONB, nullable=True),
    )

    # Create index for session lookup
    op.create_index(
        "ix_task_queue_session",
        "task_queue",
        ["created_by_session_id"],
        postgresql_where=text("created_by_session_id IS NOT NULL"),
    )

    # Create task_step_history table for step execution tracking
    op.create_table(
        "task_step_history",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column(
            "task_id",
            PGUUID(as_uuid=True),
            sa.ForeignKey("task_queue.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("step_name", sa.String(100), nullable=False),
        sa.Column("step_index", sa.Integer, nullable=False),
        sa.Column("executor", sa.String(50), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("input", JSONB, nullable=True),
        sa.Column("output", JSONB, nullable=True),
        sa.Column("error", sa.Text, nullable=True),
        sa.Column("tokens_used", sa.Integer, nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("duration_ms", sa.Integer, nullable=True),
    )

    # Create index for task lookup
    op.create_index(
        "ix_task_step_history_task",
        "task_step_history",
        ["task_id", "step_index"],
    )

    # Create task_templates table for reusable task definitions
    op.create_table(
        "task_templates",
        sa.Column(
            "id",
            PGUUID(as_uuid=True),
            primary_key=True,
            server_default=text("gen_random_uuid()"),
        ),
        sa.Column("task_type", sa.String(100), unique=True, nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("steps", JSONB, nullable=False),
        sa.Column("default_config", JSONB, nullable=True),
        sa.Column("timeout_seconds", sa.Integer, server_default="3600"),
        sa.Column("enabled", sa.Boolean, server_default="true"),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
    )

    # Create index for enabled templates
    op.create_index(
        "ix_task_templates_enabled",
        "task_templates",
        ["enabled"],
        postgresql_where=text("enabled = true"),
    )


def downgrade() -> None:
    """Remove background task runner tables and columns."""
    # Drop task_templates
    op.drop_index("ix_task_templates_enabled", table_name="task_templates")
    op.drop_table("task_templates")

    # Drop task_step_history
    op.drop_index("ix_task_step_history_task", table_name="task_step_history")
    op.drop_table("task_step_history")

    # Remove columns from task_queue
    op.drop_index("ix_task_queue_session", table_name="task_queue")
    op.drop_column("task_queue", "error_details")
    op.drop_column("task_queue", "result")
    op.drop_column("task_queue", "notification_channels")
    op.drop_column("task_queue", "created_by_session_id")
    op.drop_column("task_queue", "progress")
    op.drop_column("task_queue", "steps")
