"""Add triggered_tasks to event_log.

Revision ID: 007
Revises: 006
Create Date: 2025-01-07

Supports multiple triggers matching the same event.
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

# revision identifiers, used by Alembic.
revision = "007"
down_revision = "006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add triggered_tasks column to event_log."""
    op.add_column(
        "event_log",
        sa.Column("triggered_tasks", JSONB, nullable=True),
    )


def downgrade() -> None:
    """Remove triggered_tasks column from event_log."""
    op.drop_column("event_log", "triggered_tasks")
