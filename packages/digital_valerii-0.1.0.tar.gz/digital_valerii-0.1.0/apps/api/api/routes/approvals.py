"""Approval API endpoints for human oversight.

Per EU AI Act Art.14: Human oversight for AI decisions.
Per ISO 42001 A.9.3: Responsible use controls.
"""

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict

from apps.api.agent.approval import (
    ApprovalAlreadyDecidedError,
    ApprovalDecision,
    ApprovalExpiredError,
    ApprovalNotFoundError,
    ApprovalRequest,
)
from apps.api.agent.approval.service import ApprovalService
from apps.api.agent.approval.store import ApprovalStore
from apps.api.dependencies import DBSession

router = APIRouter(prefix="/approvals", tags=["approvals"])


# =============================================================================
# Request/Response Models
# =============================================================================


class ApproveRequest(BaseModel):
    """Request body for approval."""

    model_config = ConfigDict(extra="forbid")

    reason: str | None = None
    modified_arguments: dict | None = None


class DenyRequest(BaseModel):
    """Request body for denial."""

    model_config = ConfigDict(extra="forbid")

    reason: str | None = None


# =============================================================================
# Dependencies
# =============================================================================


async def get_approval_service(db: DBSession) -> ApprovalService:
    """FastAPI dependency for approval service.

    Args:
        db: Database session from dependency injection.

    Returns:
        ApprovalService instance for the request.
    """
    store = ApprovalStore(db=db, redis=None)  # Redis optional for now
    return ApprovalService(store=store)


ApprovalServiceDep = Annotated[ApprovalService, Depends(get_approval_service)]


# Stub for current user - will be replaced with real auth in Phase 3
def get_current_user_id() -> str:
    """Get current user ID (stub for now).

    Returns:
        User ID string.
    """
    return "default-user"


CurrentUserDep = Annotated[str, Depends(get_current_user_id)]


# =============================================================================
# Endpoints
# =============================================================================


@router.get("/pending")
async def list_pending_approvals(
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> list[ApprovalRequest]:
    """List pending approval requests for current user.

    Per EU AI Act Art.14(4)(c): User can see pending AI decisions.

    Returns:
        List of pending approval requests.
    """
    return await service.list_pending(user_id=current_user)


@router.get("/{approval_id}")
async def get_approval_status(
    approval_id: UUID,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalRequest:
    """Get status of an approval request.

    Args:
        approval_id: Approval request ID.
        service: Approval service.
        current_user: Current user ID.

    Returns:
        Approval request details.

    Raises:
        HTTPException: If not found or not authorized.
    """
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    # Check ownership
    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view this approval",
        )

    return request


@router.post("/{approval_id}/approve")
async def approve_request(
    approval_id: UUID,
    body: ApproveRequest,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalDecision:
    """Approve a pending tool execution.

    Per EU AI Act Art.14(4)(c): User can override AI decisions.
    Per ISO 42001 A.9.3: Human oversight for high-risk actions.

    Args:
        approval_id: Approval request ID.
        body: Approval request body.
        service: Approval service.
        current_user: Current user ID.

    Returns:
        Approval decision.

    Raises:
        HTTPException: If not found, expired, already decided, or not authorized.
    """
    # ISSUE-2: Disable modified_arguments until validation exists
    if body.modified_arguments:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Argument modification not yet supported",
        )

    # ISSUE-1: Check ownership before approval
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    try:
        return await service.approve(
            approval_id=approval_id,
            decided_by=current_user,
            reason=body.reason,
            modified_arguments=None,  # Disabled for now
        )
    except ApprovalNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        ) from None
    except ApprovalExpiredError:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail=f"Approval {approval_id} expired",
        ) from None
    except ApprovalAlreadyDecidedError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        ) from None


@router.post("/{approval_id}/deny")
async def deny_request(
    approval_id: UUID,
    body: DenyRequest,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalDecision:
    """Deny a pending tool execution.

    Per EU AI Act Art.14(4)(c): User can override AI decisions.

    Args:
        approval_id: Approval request ID.
        body: Denial request body.
        service: Approval service.
        current_user: Current user ID.

    Returns:
        Approval decision.

    Raises:
        HTTPException: If not found, already decided, or not authorized.
    """
    # ISSUE-1: Check ownership before denial
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    try:
        return await service.deny(
            approval_id=approval_id,
            decided_by=current_user,
            reason=body.reason,
        )
    except ApprovalNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        ) from None
    except ApprovalAlreadyDecidedError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        ) from None


@router.delete("/{approval_id}")
async def cancel_approval(
    approval_id: UUID,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> dict:
    """Cancel a pending approval request.

    Per EU AI Act Art.14(4)(d): User can stop AI operation.

    Args:
        approval_id: Approval request ID.
        service: Approval service.
        current_user: Current user ID.

    Returns:
        Cancellation status.

    Raises:
        HTTPException: If not found, already decided, or not authorized.
    """
    # ISSUE-1: Check ownership before cancellation
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    success = await service.cancel(
        approval_id=approval_id,
        cancelled_by=current_user,
    )

    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found or already decided",
        )

    return {"cancelled": True}
