"""Chat API endpoints."""

import logging
from datetime import UTC, datetime
from uuid import UUID, uuid4

from digital_valerii_shared.agent import ConversationContext, InterfaceType
from fastapi import APIRouter, HTTPException, Query

from apps.api.api.schemas.chat import (
    ChatRequest,
    ChatResponse,
    ConversationDetail,
    ConversationSummary,
)
from apps.api.auth.dependencies import CurrentUserDep, OptionalUserDep
from apps.api.dependencies import AgentDep, MemoryManagerDep, SessionManagerDep

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("/message", response_model=ChatResponse)
async def send_message(
    request: ChatRequest,
    agent: AgentDep,
) -> ChatResponse:
    """Send a message and get agent response.

    Args:
        request: Chat request with message and optional conversation_id.
        agent: DigitalValeriiAgent instance.

    Returns:
        ChatResponse with agent's reply.
    """
    try:
        # Create or use existing conversation ID
        conversation_id = request.conversation_id or uuid4()

        # Build conversation context
        context = ConversationContext(
            conversation_id=conversation_id,
            interface=InterfaceType.API,
            session_id=request.session_id,
        )

        # Process message through agent
        response = await agent.chat(
            message=request.message,
            context=context,
        )

        return ChatResponse(
            message=response.message,
            conversation_id=conversation_id,
            created_at=datetime.now(UTC),
            tokens_used=response.tokens_used,
        )

    except Exception:
        logger.exception("Chat message processing failed")
        raise HTTPException(
            status_code=500,
            detail="Failed to process message",
        ) from None


@router.get("/conversations", response_model=list[ConversationSummary])
async def list_conversations(
    limit: int = Query(default=20, ge=1, le=100),  # noqa: ARG001
    offset: int = Query(default=0, ge=0),  # noqa: ARG001
) -> list[ConversationSummary]:
    """List all conversations.

    Args:
        limit: Maximum number of conversations to return.
        offset: Number of conversations to skip.

    Returns:
        List of conversation summaries.
    """
    # Note: Conversation storage is through working memory (Redis).
    # For persistent conversations, we would query Events grouped by session.
    # For now, return empty list as conversations are session-based.
    return []


@router.get("/conversations/{conversation_id}", response_model=ConversationDetail)
async def get_conversation(
    conversation_id: UUID,
    memory: MemoryManagerDep,
) -> ConversationDetail:
    """Get a specific conversation with messages.

    Args:
        conversation_id: The conversation UUID.
        memory: Memory manager instance.

    Returns:
        Conversation detail with messages.

    Raises:
        HTTPException: If conversation not found.
    """
    try:
        # Get working memory for this conversation (using conversation_id as session_id)
        working_memory = await memory.get_working_memory(str(conversation_id))

        if working_memory is None:
            raise HTTPException(
                status_code=404,
                detail="Conversation not found",
            )

        return ConversationDetail(
            id=conversation_id,
            title=None,
            messages=working_memory.messages,
            created_at=working_memory.updated_at or datetime.now(UTC),
            updated_at=working_memory.updated_at or datetime.now(UTC),
        )

    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to get conversation")
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve conversation",
        ) from None


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: UUID,
    memory: MemoryManagerDep,
) -> dict[str, str]:
    """Soft-delete a conversation.

    Args:
        conversation_id: The conversation UUID.
        memory: Memory manager instance.

    Returns:
        Success message.
    """
    try:
        # Clear working memory for this conversation
        await memory.clear_working_memory(str(conversation_id))

        return {"message": "Conversation deleted"}

    except Exception:
        logger.exception("Failed to delete conversation")
        raise HTTPException(
            status_code=500,
            detail="Failed to delete conversation",
        ) from None


# =============================================================================
# Session-Based Chat Endpoints (Component 4.8)
# =============================================================================


@router.post("/session/message", response_model=ChatResponse)
async def send_session_message(
    request: ChatRequest,
    agent: AgentDep,
    current_user: CurrentUserDep,
    session_manager: SessionManagerDep,
) -> ChatResponse:
    """Send a message using unified session management.

    This endpoint uses the unified session manager for cross-channel
    session continuity. One session per user across all channels.

    Args:
        request: Chat request with message.
        agent: DigitalValeriiAgent instance.
        current_user: Authenticated user.
        session_manager: Unified session manager.

    Returns:
        ChatResponse with agent's reply.
    """
    try:
        # Get or create user session
        user_session = await session_manager.get_or_create_session(current_user.id)

        # Enqueue message with SDK session ID tracking
        message_id = await session_manager.enqueue_message(
            user_id=current_user.id,
            channel="web",
            content=request.message,
            metadata={
                "conversation_id": str(request.conversation_id) if request.conversation_id else None,
            },
            sdk_session_id=request.session_id,
        )

        # Build conversation context with session info
        context = ConversationContext(
            conversation_id=request.conversation_id or uuid4(),
            interface=InterfaceType.API,
            session_id=str(user_session.sdk_session_id) if user_session.sdk_session_id else request.session_id,
        )

        # Process message through agent
        response = await agent.chat(
            message=request.message,
            context=context,
        )

        # Complete message in queue
        await session_manager.complete_message(message_id, success=True)

        return ChatResponse(
            message=response.message,
            conversation_id=context.conversation_id,
            created_at=datetime.now(UTC),
            tokens_used=response.tokens_used,
        )

    except Exception:
        logger.exception("Session message processing failed")
        raise HTTPException(
            status_code=500,
            detail="Failed to process message",
        ) from None


@router.get("/session/queue")
async def get_queue_status(
    current_user: CurrentUserDep,
    session_manager: SessionManagerDep,
) -> dict:
    """Get current user's message queue status.

    Args:
        current_user: Authenticated user.
        session_manager: Unified session manager.

    Returns:
        Queue status with pending message count.
    """
    try:
        session = await session_manager.get_session(current_user.id)
        queue_length = await session_manager.get_queue_length(current_user.id)

        return {
            "has_session": session is not None,
            "session_id": str(session.id) if session else None,
            "last_channel": session.last_channel if session else None,
            "pending_messages": queue_length,
            "compact_count": session.compact_count if session else 0,
        }

    except Exception:
        logger.exception("Failed to get queue status")
        raise HTTPException(
            status_code=500,
            detail="Failed to get queue status",
        ) from None


@router.post("/sessions/new")
async def start_new_session(
    current_user: CurrentUserDep,
    session_manager: SessionManagerDep,
) -> dict:
    """Start a fresh session, archiving the current one.

    This implements the /new command - allows users to explicitly
    start a fresh session across all channels.

    Args:
        current_user: Authenticated user.
        session_manager: Unified session manager.

    Returns:
        New session info.
    """
    try:
        session = await session_manager.start_new_session(current_user.id)

        return {
            "session_id": str(session.id),
            "message": "Нова сесія розпочата!",
            "status": session.status.value,
            "created_at": session.created_at.isoformat(),
        }

    except Exception:
        logger.exception("Failed to start new session")
        raise HTTPException(
            status_code=500,
            detail="Failed to start new session",
        ) from None


@router.get("/sessions/current")
async def get_current_session(
    current_user: CurrentUserDep,
    session_manager: SessionManagerDep,
) -> dict:
    """Get current user's session info.

    Args:
        current_user: Authenticated user.
        session_manager: Unified session manager.

    Returns:
        Current session info or null session.
    """
    try:
        session = await session_manager.get_session(current_user.id)
        checkpoint = await session_manager.get_latest_checkpoint(current_user.id)
        queue_length = await session_manager.get_queue_length(current_user.id)

        if not session:
            return {
                "has_session": False,
                "session": None,
            }

        return {
            "has_session": True,
            "session": {
                "id": str(session.id),
                "status": session.status.value,
                "last_channel": session.last_channel,
                "compact_count": session.compact_count,
                "pending_messages": queue_length,
                "created_at": session.created_at.isoformat(),
                "last_activity_at": session.last_activity_at.isoformat(),
            },
            "latest_checkpoint": {
                "id": str(checkpoint.id),
                "type": checkpoint.checkpoint_type.value,
                "summary": checkpoint.summary,
                "created_at": checkpoint.created_at.isoformat(),
            } if checkpoint else None,
        }

    except Exception:
        logger.exception("Failed to get current session")
        raise HTTPException(
            status_code=500,
            detail="Failed to get current session",
        ) from None
