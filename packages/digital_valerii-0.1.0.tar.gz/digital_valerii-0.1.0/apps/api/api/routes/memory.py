"""Memory API endpoints."""

import logging
from uuid import UUID

from digital_valerii_shared.services.memory import Context
from fastapi import APIRouter, HTTPException, Query

from apps.api.api.schemas.memory import (
    MemorySearchResult,
    PersonDetail,
    PersonSummary,
    ProjectDetail,
    ProjectSummary,
)
from apps.api.dependencies import MemoryManagerDep

logger = logging.getLogger(__name__)

# Note: Context is used in search_memories function

router = APIRouter(prefix="/memory", tags=["memory"])


@router.get("/search", response_model=list[MemorySearchResult])
async def search_memories(
    q: str = Query(..., min_length=1, max_length=500),
    limit: int = Query(default=10, ge=1, le=50),
    session_id: str = Query(default="default"),
    memory: MemoryManagerDep = None,
) -> list[MemorySearchResult]:
    """Search memories by query.

    Args:
        q: Search query string.
        limit: Maximum number of results.
        session_id: Session identifier for context.
        memory: Memory manager instance.

    Returns:
        List of matching memory search results.
    """
    try:
        # Create context for recall
        context = Context(
            session_id=session_id,
            conversation_id=None,
            message_index=0,
            interface="api",
        )

        # Recall memories
        result = await memory.recall(
            query=q,
            context=context,
            limit=limit,
        )

        # Convert to response schema
        return [
            MemorySearchResult(
                event_id=event.event_id,
                event_type=event.event_type,
                title=event.title,
                summary=event.summary,
                occurred_at=event.occurred_at,
                score=event.final_score,
            )
            for event in result.events
        ]

    except Exception:
        logger.exception("Memory search failed")
        raise HTTPException(
            status_code=500,
            detail="Failed to search memories",
        ) from None


@router.get("/people", response_model=list[PersonSummary])
async def list_people(
    q: str | None = Query(default=None, max_length=200),
    limit: int = Query(default=20, ge=1, le=100),
    memory: MemoryManagerDep = None,
) -> list[PersonSummary]:
    """List people, optionally filtered by query.

    Args:
        q: Optional search query.
        limit: Maximum number of results.
        memory: Memory manager instance.

    Returns:
        List of person summaries.
    """
    try:
        if q:
            people = await memory.search_people(query=q, limit=limit)
        else:
            # Search with empty pattern returns all (up to limit)
            people = await memory.search_people(query="", limit=limit)

        return [
            PersonSummary(
                id=person.id,
                name=person.name,
                email=person.email,
                company=person.company,
                relationship_type=person.relationship_type,
            )
            for person in people
        ]

    except Exception:
        logger.exception("Failed to list people")
        raise HTTPException(
            status_code=500,
            detail="Failed to list people",
        ) from None


@router.get("/people/{person_id}", response_model=PersonDetail)
async def get_person(
    person_id: UUID,
    memory: MemoryManagerDep = None,
) -> PersonDetail:
    """Get person details.

    Args:
        person_id: The person UUID.
        memory: Memory manager instance.

    Returns:
        Person details.

    Raises:
        HTTPException: If person not found.
    """
    try:
        person = await memory.get_person(person_id)

        if person is None:
            raise HTTPException(
                status_code=404,
                detail="Person not found",
            )

        # Count interactions from event_participations if available
        interaction_count = 0
        last_interaction = None
        if hasattr(person, "event_participations") and person.event_participations:
            interaction_count = len(person.event_participations)
            # Get most recent interaction
            for participation in person.event_participations:
                if hasattr(participation, "event") and participation.event:
                    event_time = participation.event.occurred_at
                    if last_interaction is None or event_time > last_interaction:
                        last_interaction = event_time

        return PersonDetail(
            id=person.id,
            name=person.name,
            email=person.email,
            company=person.company,
            relationship_type=person.relationship_type,
            notes=person.notes if hasattr(person, "notes") else None,
            last_interaction=last_interaction,
            interaction_count=interaction_count,
        )

    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to get person")
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve person",
        ) from None


@router.get("/projects", response_model=list[ProjectSummary])
async def list_projects(
    q: str | None = Query(default=None, max_length=200),
    status: str | None = Query(default=None, max_length=50),
    limit: int = Query(default=20, ge=1, le=100),
    memory: MemoryManagerDep = None,
) -> list[ProjectSummary]:
    """List projects, optionally filtered.

    Args:
        q: Optional search query.
        status: Optional status filter.
        limit: Maximum number of results.
        memory: Memory manager instance.

    Returns:
        List of project summaries.
    """
    try:
        if q:
            projects = await memory.search_projects(query=q, limit=limit)
        else:
            projects = await memory.search_projects(query="", limit=limit)

        # Apply status filter if provided
        if status:
            projects = [p for p in projects if p.status == status]

        return [
            ProjectSummary(
                id=project.id,
                name=project.name,
                status=project.status,
                description=project.description,
            )
            for project in projects
        ]

    except Exception:
        logger.exception("Failed to list projects")
        raise HTTPException(
            status_code=500,
            detail="Failed to list projects",
        ) from None


@router.get("/projects/{project_id}", response_model=ProjectDetail)
async def get_project(
    project_id: UUID,
    memory: MemoryManagerDep = None,
) -> ProjectDetail:
    """Get project details.

    Args:
        project_id: The project UUID.
        memory: Memory manager instance.

    Returns:
        Project details with associated people.

    Raises:
        HTTPException: If project not found.
    """
    try:
        project = await memory.get_project(project_id)

        if project is None:
            raise HTTPException(
                status_code=404,
                detail="Project not found",
            )

        # Get project people if available
        people: list[PersonSummary] = []
        if hasattr(project, "people") and project.people:
            people = [
                PersonSummary(
                    id=p.id,
                    name=p.name,
                    email=p.email,
                    company=p.company,
                    relationship_type=p.relationship_type,
                )
                for p in project.people
            ]

        return ProjectDetail(
            id=project.id,
            name=project.name,
            status=project.status,
            description=project.description,
            created_at=project.created_at,
            updated_at=project.updated_at,
            people=people,
        )

    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to get project")
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve project",
        ) from None
