"""Authentication API endpoints.

Per EU AI Act Art.14: Human oversight requires user identification.
Per ISO 42001 A.8.3: User identity for audit trail.
"""

from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException, status
from jose import JWTError
from sqlalchemy.exc import IntegrityError

from apps.api.auth.jwt import JWTService
from apps.api.auth.schemas import (
    TokenPair,
    TokenRefresh,
    UserCreate,
    UserLogin,
    UserResponse,
)
from apps.api.auth.service import UserService
from apps.api.config import settings
from apps.api.dependencies import DBSession, get_redis

router = APIRouter(prefix="/auth", tags=["auth"])


# =============================================================================
# Dependencies
# =============================================================================


async def get_user_service(
    db: DBSession,
    redis: Annotated[object | None, Depends(get_redis)],
) -> UserService:
    """Get user service with dependencies.

    Args:
        db: Database session.
        redis: Redis service (RedisService wrapper).

    Returns:
        UserService instance.
    """
    # Pass redis.client (raw Redis) to UserService, not the RedisService wrapper
    redis_client = getattr(redis, "client", None) if redis else None
    return UserService(db=db, redis=redis_client)


UserServiceDep = Annotated[UserService, Depends(get_user_service)]


def get_jwt_service() -> JWTService:
    """Get JWT service.

    Returns:
        JWTService instance.
    """
    return JWTService(
        secret_key=settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
        access_token_expire_minutes=settings.access_token_expire_minutes,
        refresh_token_expire_days=settings.refresh_token_expire_days,
    )


JWTServiceDep = Annotated[JWTService, Depends(get_jwt_service)]


# =============================================================================
# Endpoints
# =============================================================================


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(
    body: UserCreate,
    service: UserServiceDep,
) -> UserResponse:
    """Register a new user.

    Per ISO 42001 A.8.3: User identity creation for audit trail.

    Args:
        body: User registration data.
        service: User service.

    Returns:
        Created user response.

    Raises:
        HTTPException: If email already registered.
    """
    if await service.email_exists(body.email):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email already registered",
        )

    try:
        user = await service.create_user(body)
    except IntegrityError:
        # Handle race condition - concurrent registration
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email already registered",
        ) from None

    return UserResponse.model_validate(user)


@router.post("/login")
async def login(
    body: UserLogin,
    service: UserServiceDep,
    jwt_service: JWTServiceDep,
) -> TokenPair:
    """Login with email and password.

    Returns access + refresh token pair.
    Updates last_login_at timestamp.

    Args:
        body: Login credentials.
        service: User service.
        jwt_service: JWT service.

    Returns:
        Token pair.

    Raises:
        HTTPException: If credentials invalid or user inactive.
    """
    user = await service.authenticate(body.email, body.password)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is disabled",
        )

    # Create token pair
    from uuid import UUID

    user_id = UUID(str(user.id))
    token_pair, refresh_jti = jwt_service.create_token_pair(user_id)

    # Store refresh token in Redis
    await service.store_refresh_token(
        jti=refresh_jti,
        user_id=user_id,
        ttl_days=settings.refresh_token_expire_days,
    )

    # Update last login
    await service.update_last_login(user_id)

    return token_pair


@router.post("/logout")
async def logout(
    body: TokenRefresh,
    service: UserServiceDep,
    jwt_service: JWTServiceDep,
) -> dict:
    """Logout - revoke refresh token.

    Removes refresh token JTI from Redis.

    Args:
        body: Refresh token.
        service: User service.
        jwt_service: JWT service.

    Returns:
        Success message.

    Raises:
        HTTPException: If token invalid.
    """
    try:
        token_data = jwt_service.verify_token(body.refresh_token, "refresh")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        ) from None

    await service.revoke_refresh_token(token_data.jti)
    return {"message": "Logged out successfully"}


@router.post("/refresh")
async def refresh_token(
    body: TokenRefresh,
    service: UserServiceDep,
    jwt_service: JWTServiceDep,
) -> TokenPair:
    """Get new access token using refresh token.

    Implements refresh token rotation for security.

    Args:
        body: Refresh token.
        service: User service.
        jwt_service: JWT service.

    Returns:
        New token pair.

    Raises:
        HTTPException: If token invalid or revoked.
    """
    try:
        token_data = jwt_service.verify_token(body.refresh_token, "refresh")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        ) from None

    # Check if token is revoked
    if not await service.is_refresh_token_valid(token_data.jti):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token has been revoked",
        )

    # Verify user still exists and is active
    from uuid import UUID

    user = await service.get_by_id(UUID(token_data.sub))
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    # Revoke old refresh token
    await service.revoke_refresh_token(token_data.jti)

    # Create new token pair (rotation)
    user_id = UUID(token_data.sub)
    new_token_pair, new_refresh_jti = jwt_service.create_token_pair(user_id)

    # Store new refresh token
    await service.store_refresh_token(
        jti=new_refresh_jti,
        user_id=user_id,
        ttl_days=settings.refresh_token_expire_days,
    )

    return new_token_pair


@router.get("/me")
async def get_current_user_profile(
    service: UserServiceDep,
    jwt_service: JWTServiceDep,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> UserResponse:
    """Get current authenticated user.

    Args:
        service: User service.
        jwt_service: JWT service.
        authorization: Authorization header.

    Returns:
        Current user.

    Raises:
        HTTPException: If not authenticated.
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = authorization.replace("Bearer ", "")

    try:
        token_data = jwt_service.verify_token(token, "access")
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from None

    from uuid import UUID

    user = await service.get_by_id(UUID(token_data.sub))

    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return UserResponse.model_validate(user)
