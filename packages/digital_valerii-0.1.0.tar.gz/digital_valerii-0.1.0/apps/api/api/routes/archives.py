"""Archive API endpoints for long-term memory management.

Component 4.9: Long-term Memory Architecture
Provides API access to archive operations and tiered memory search.
"""

import logging
from typing import Any

from digital_valerii_shared.models.archive import (
    ArchiveIndexEntry,
    ArchiveResult,
    ArchiveSearchRequest,
    ArchivedEvent,
    StrategicMemory,
    TieredMemoryContext,
)
from digital_valerii_shared.services.archive_manager import (
    ArchiveError,
    ArchiveExistsError,
    ArchiveNotFoundError,
)
from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field

from apps.api.auth.dependencies import CurrentUserDep
from apps.api.dependencies import ArchiveManagerDep, TieredMemoryDep

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/archives", tags=["archives"])


# =============================================================================
# Request/Response Models
# =============================================================================


class ArchiveYearRequest(BaseModel):
    """Request to archive a year."""

    model_config = ConfigDict(extra="forbid")

    run_in_background: bool = Field(
        default=True,
        description="Run archive operation as background task",
    )


class ArchiveStatusResponse(BaseModel):
    """Response for archive status."""

    model_config = ConfigDict(extra="forbid")

    status: str
    message: str
    year: int


class TieredSearchRequest(BaseModel):
    """Request for tiered memory search."""

    model_config = ConfigDict(extra="forbid")

    query: str = Field(..., min_length=1, max_length=1000)
    include_archives: list[int] | None = Field(
        default=None,
        description="Explicit years to include",
    )
    auto_detect_years: bool = Field(
        default=True,
        description="Detect years from query",
    )
    limit: int = Field(default=20, ge=1, le=100)
    include_strategic: bool = Field(
        default=True,
        description="Include strategic memories",
    )


class MemoryStatsResponse(BaseModel):
    """Response for memory statistics."""

    model_config = ConfigDict(extra="forbid")

    current_year: int
    total_archived_years: int = 0
    total_archived_events: int = 0
    tiers: dict[str, Any]


# =============================================================================
# Archive Management Endpoints
# =============================================================================


@router.post("/{year}", response_model=ArchiveStatusResponse)
async def archive_year(
    year: int,
    request: ArchiveYearRequest,
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
    background_tasks: BackgroundTasks,
) -> ArchiveStatusResponse:
    """Archive a year's memories.

    Moves events from active memory to archive storage.
    Can run as background task for large archives.

    Args:
        year: Year to archive (must be in the past).
        request: Archive configuration.
        current_user: Authenticated user.
        archive_manager: Archive manager instance.
        background_tasks: FastAPI background tasks.

    Returns:
        Status of archive operation.

    Raises:
        HTTPException: If archive fails or already exists.
    """
    try:
        if request.run_in_background:
            # Queue as background task
            background_tasks.add_task(
                archive_manager.archive_year,
                year=year,
                user_id=current_user.id,
            )
            return ArchiveStatusResponse(
                status="queued",
                message=f"Archive operation for {year} queued as background task",
                year=year,
            )

        # Run synchronously
        result = await archive_manager.archive_year(
            year=year,
            user_id=current_user.id,
        )
        return ArchiveStatusResponse(
            status="completed",
            message=f"Archived {result.events_archived} events from {year}",
            year=year,
        )

    except ArchiveExistsError:
        raise HTTPException(
            status_code=409,
            detail=f"Year {year} is already archived",
        ) from None
    except ArchiveError as e:
        logger.exception("Archive operation failed")
        raise HTTPException(
            status_code=400,
            detail=str(e),
        ) from None
    except Exception:
        logger.exception("Unexpected error during archive")
        raise HTTPException(
            status_code=500,
            detail="Failed to archive year",
        ) from None


@router.get("", response_model=list[ArchiveIndexEntry])
async def list_archives(
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
) -> list[ArchiveIndexEntry]:
    """List all available archives for the current user.

    Args:
        current_user: Authenticated user.
        archive_manager: Archive manager instance.

    Returns:
        List of archive index entries sorted by year descending.
    """
    try:
        return await archive_manager.get_archive_index(current_user.id)
    except Exception:
        logger.exception("Failed to list archives")
        raise HTTPException(
            status_code=500,
            detail="Failed to list archives",
        ) from None


@router.get("/{year}", response_model=ArchiveIndexEntry)
async def get_archive(
    year: int,
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
) -> ArchiveIndexEntry:
    """Get details of a specific archive.

    Args:
        year: Year to get.
        current_user: Authenticated user.
        archive_manager: Archive manager instance.

    Returns:
        Archive details.

    Raises:
        HTTPException: If archive not found.
    """
    try:
        archive = await archive_manager.get_archive(year, current_user.id)
        if not archive:
            raise HTTPException(
                status_code=404,
                detail=f"No archive found for year {year}",
            )
        return archive
    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to get archive")
        raise HTTPException(
            status_code=500,
            detail="Failed to get archive",
        ) from None


@router.post("/{year}/search", response_model=list[ArchivedEvent])
async def search_archive(
    year: int,
    request: ArchiveSearchRequest,
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
) -> list[ArchivedEvent]:
    """Search within a specific year's archive.

    Uses semantic search to find relevant events.

    Args:
        year: Year to search.
        request: Search parameters.
        current_user: Authenticated user.
        archive_manager: Archive manager instance.

    Returns:
        List of matching archived events.

    Raises:
        HTTPException: If archive not found.
    """
    try:
        return await archive_manager.search_archive(
            year=year,
            query=request.query,
            user_id=current_user.id,
            limit=request.limit,
            event_types=request.event_types,
        )
    except ArchiveNotFoundError:
        raise HTTPException(
            status_code=404,
            detail=f"No archive found for year {year}",
        ) from None
    except Exception:
        logger.exception("Archive search failed")
        raise HTTPException(
            status_code=500,
            detail="Failed to search archive",
        ) from None


@router.delete("/{year}")
async def delete_archive(
    year: int,
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
    restore: bool = Query(
        default=False,
        description="Restore events to active memory",
    ),
) -> dict:
    """Delete an archive.

    Optionally restores events back to active memory.

    Args:
        year: Year to delete.
        current_user: Authenticated user.
        archive_manager: Archive manager instance.
        restore: Whether to restore events.

    Returns:
        Confirmation message.

    Raises:
        HTTPException: If archive not found or deletion fails.
    """
    try:
        await archive_manager.delete_archive(
            year=year,
            user_id=current_user.id,
            restore_to_active=restore,
        )
        return {
            "status": "deleted",
            "year": year,
            "restored": restore,
        }
    except ArchiveNotFoundError:
        raise HTTPException(
            status_code=404,
            detail=f"No archive found for year {year}",
        ) from None
    except Exception:
        logger.exception("Failed to delete archive")
        raise HTTPException(
            status_code=500,
            detail="Failed to delete archive",
        ) from None


# =============================================================================
# Strategic Memory Endpoints
# =============================================================================


@router.get("/{year}/strategic", response_model=list[StrategicMemory])
async def get_strategic_memories(
    year: int,
    current_user: CurrentUserDep,
    archive_manager: ArchiveManagerDep,
    memory_type: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
) -> list[StrategicMemory]:
    """Get strategic memories for a year.

    Args:
        year: Year to get memories for.
        current_user: Authenticated user.
        archive_manager: Archive manager instance.
        memory_type: Optional filter by type.
        limit: Maximum results.

    Returns:
        List of strategic memories.
    """
    try:
        from digital_valerii_shared.models.archive import MemoryType

        mem_type = MemoryType(memory_type) if memory_type else None
        return await archive_manager.get_strategic_memories(
            user_id=current_user.id,
            year=year,
            memory_type=mem_type,
            limit=limit,
        )
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid memory type: {memory_type}",
        ) from None
    except Exception:
        logger.exception("Failed to get strategic memories")
        raise HTTPException(
            status_code=500,
            detail="Failed to get strategic memories",
        ) from None


# =============================================================================
# Tiered Memory Endpoints
# =============================================================================


@router.post("/tiered/search", response_model=TieredMemoryContext)
async def tiered_search(
    request: TieredSearchRequest,
    current_user: CurrentUserDep,
    tiered_memory: TieredMemoryDep,
) -> TieredMemoryContext:
    """Search across all memory tiers.

    Automatically detects years from query and searches
    appropriate tiers (active + archive).

    Args:
        request: Search parameters.
        current_user: Authenticated user.
        tiered_memory: Tiered memory manager.

    Returns:
        Combined search results from all tiers.
    """
    try:
        return await tiered_memory.recall(
            query=request.query,
            user_id=current_user.id,
            include_archives=request.include_archives,
            auto_detect_years=request.auto_detect_years,
            limit=request.limit,
            include_strategic=request.include_strategic,
        )
    except Exception:
        logger.exception("Tiered search failed")
        raise HTTPException(
            status_code=500,
            detail="Failed to search memories",
        ) from None


@router.get("/tiered/stats", response_model=MemoryStatsResponse)
async def get_memory_stats(
    current_user: CurrentUserDep,
    tiered_memory: TieredMemoryDep,
) -> MemoryStatsResponse:
    """Get memory statistics across all tiers.

    Args:
        current_user: Authenticated user.
        tiered_memory: Tiered memory manager.

    Returns:
        Statistics about memory tiers.
    """
    try:
        stats = await tiered_memory.get_memory_stats(current_user.id)
        return MemoryStatsResponse(
            current_year=stats["current_year"],
            total_archived_years=stats.get("total_archived_years", 0),
            total_archived_events=stats.get("total_archived_events", 0),
            tiers=stats["tiers"],
        )
    except Exception:
        logger.exception("Failed to get memory stats")
        raise HTTPException(
            status_code=500,
            detail="Failed to get memory stats",
        ) from None


@router.get("/tiered/years")
async def get_available_years(
    current_user: CurrentUserDep,
    tiered_memory: TieredMemoryDep,
) -> list[int]:
    """Get list of years with available data.

    Args:
        current_user: Authenticated user.
        tiered_memory: Tiered memory manager.

    Returns:
        List of years sorted descending.
    """
    try:
        return await tiered_memory.get_available_years(current_user.id)
    except Exception:
        logger.exception("Failed to get available years")
        raise HTTPException(
            status_code=500,
            detail="Failed to get available years",
        ) from None
