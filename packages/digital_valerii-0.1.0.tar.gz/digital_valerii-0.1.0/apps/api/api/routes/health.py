"""Health check endpoints."""

from fastapi import APIRouter
from sqlalchemy import text

from apps.api.dependencies import DBSession

router = APIRouter()


@router.get("/health")
async def health_check(db: DBSession) -> dict[str, str]:
    """Health check endpoint with database verification.

    Args:
        db: Database session from dependency injection.

    Returns:
        Health status including database connectivity.
    """
    try:
        await db.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "database": str(e)}
