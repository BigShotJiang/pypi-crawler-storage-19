"""Memory API schemas."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class MemorySearchResult(BaseModel):
    """Single memory search result."""

    model_config = ConfigDict(extra="forbid")

    event_id: UUID
    event_type: str
    title: str | None = None
    summary: str | None = None
    occurred_at: datetime
    score: float


class PersonSummary(BaseModel):
    """Summary of a person for listing."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    email: str | None = None
    company: str | None = None
    relationship_type: str | None = None


class PersonDetail(PersonSummary):
    """Full person details."""

    notes: str | None = None
    last_interaction: datetime | None = None
    interaction_count: int = 0


class ProjectSummary(BaseModel):
    """Summary of a project for listing."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    status: str
    description: str | None = None


class ProjectDetail(ProjectSummary):
    """Full project details."""

    created_at: datetime
    updated_at: datetime
    people: list[PersonSummary] = []
