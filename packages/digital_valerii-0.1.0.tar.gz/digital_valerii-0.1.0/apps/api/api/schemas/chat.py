"""Chat API schemas."""

from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ChatRequest(BaseModel):
    """Request to send a chat message."""

    model_config = ConfigDict(extra="forbid")

    message: str = Field(..., min_length=1, max_length=10000)
    conversation_id: UUID | None = None
    session_id: str = Field(default="default", max_length=100)


class ChatResponse(BaseModel):
    """Response from chat endpoint."""

    model_config = ConfigDict(extra="forbid")

    message: str
    conversation_id: UUID
    created_at: datetime
    tokens_used: int | None = None


class ConversationSummary(BaseModel):
    """Summary of a conversation for listing."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    title: str | None = None
    message_count: int
    created_at: datetime
    updated_at: datetime


class ConversationDetail(BaseModel):
    """Full conversation with messages."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    title: str | None = None
    messages: list[dict[str, Any]] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime
