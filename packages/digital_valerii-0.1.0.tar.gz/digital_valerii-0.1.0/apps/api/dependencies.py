"""FastAPI dependencies for the API."""

from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING, Annotated

if TYPE_CHECKING:
    from apps.api.integrations.slack.services import SlackService

from digital_valerii_shared.agent import (
    DigitalValeriiAgent,
    PersonalityManager,
)
from digital_valerii_shared.config import (
    EmbeddingSettings,
    QdrantSettings,
    RedisSettings,
)
from digital_valerii_shared.services.audit import AuditService
from digital_valerii_shared.services.embedding import EmbeddingService
from digital_valerii_shared.services.memory import MemoryManager
from digital_valerii_shared.services.qdrant import QdrantService
from digital_valerii_shared.services.redis import RedisService
from digital_valerii_shared.services.session_manager import UnifiedSessionManager
from digital_valerii_shared.services.compact_handler import CompactHandler
from digital_valerii_shared.services.channel_notifier import ChannelNotifier
from digital_valerii_shared.services.archive_manager import ArchiveManager
from digital_valerii_shared.services.tiered_memory import TieredMemoryManager
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from .config import settings
from .database import get_database

# =============================================================================
# Global Service Singletons
# =============================================================================

_memory_manager: MemoryManager | None = None
_agent: DigitalValeriiAgent | None = None
_slack_service: "SlackService | None" = None


def _get_memory_manager_instance() -> MemoryManager:
    """Get or create the global MemoryManager instance."""
    global _memory_manager  # noqa: PLW0603
    if _memory_manager is None:
        db = get_database()
        qdrant = QdrantService(
            QdrantSettings(
                url=settings.qdrant_url,
                api_key=settings.qdrant_api_key,
            )
        )
        redis = RedisService(RedisSettings(url=settings.redis_url))
        embedding = EmbeddingService(
            EmbeddingSettings(
                voyage_api_key=settings.voyage_api_key,
                model=settings.embedding_model,
                dimensions=settings.embedding_dimensions,
            ),
            redis=redis,
        )
        _memory_manager = MemoryManager(
            db=db,
            qdrant=qdrant,
            redis=redis,
            embedding=embedding,
        )
    return _memory_manager


def _get_agent_instance() -> DigitalValeriiAgent:
    """Get or create the global DigitalValeriiAgent instance."""
    global _agent  # noqa: PLW0603
    if _agent is None:
        personality = PersonalityManager()
        memory = _get_memory_manager_instance()
        _agent = DigitalValeriiAgent(
            personality_manager=personality,
            memory_manager=memory,
        )
    return _agent


def reset_services() -> None:
    """Reset global service instances (for testing)."""
    global _memory_manager, _agent, _slack_service  # noqa: PLW0603
    _memory_manager = None
    _agent = None
    _slack_service = None


# =============================================================================
# Database Dependencies
# =============================================================================


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for database sessions.

    Provides a transactional session that commits on success
    and rolls back on failure.

    Yields:
        AsyncSession: Database session for the request.
    """
    db = get_database()
    async with db.session() as session:
        yield session


# Type alias for cleaner dependency injection
DBSession = Annotated[AsyncSession, Depends(get_db_session)]


# =============================================================================
# Service Dependencies
# =============================================================================


async def get_audit_service(
    session: DBSession,
) -> AuditService:
    """FastAPI dependency for audit service.

    Args:
        session: Database session from dependency injection.

    Returns:
        AuditService instance for the request.
    """
    return AuditService(session)


async def get_memory_manager() -> MemoryManager:
    """FastAPI dependency for memory manager.

    Returns:
        MemoryManager singleton instance.
    """
    return _get_memory_manager_instance()


async def get_agent() -> DigitalValeriiAgent:
    """FastAPI dependency for agent.

    Returns:
        DigitalValeriiAgent singleton instance.
    """
    return _get_agent_instance()


# =============================================================================
# Redis Dependencies
# =============================================================================

_redis: RedisService | None = None


def _get_redis_instance() -> RedisService:
    """Get or create the global Redis instance."""
    global _redis  # noqa: PLW0603
    if _redis is None:
        _redis = RedisService(RedisSettings(url=settings.redis_url))
    return _redis


async def get_redis() -> RedisService:
    """FastAPI dependency for Redis client.

    Returns:
        RedisService singleton instance (connected).
    """
    redis = _get_redis_instance()
    # Ensure Redis is connected before returning
    if redis._client is None:
        await redis.connect()
    return redis


RedisDep = Annotated[RedisService, Depends(get_redis)]


# =============================================================================
# Slack Service Dependencies
# =============================================================================


def _get_slack_service_instance() -> "SlackService":
    """Get or create the global SlackService instance."""
    global _slack_service  # noqa: PLW0603
    if _slack_service is None:
        from apps.api.integrations.slack.services import SlackService

        agent = _get_agent_instance()
        memory = _get_memory_manager_instance()
        redis = _get_redis_instance()
        _slack_service = SlackService(
            agent=agent,
            memory=memory,
            redis=redis,
        )
    return _slack_service


async def get_slack_service() -> "SlackService":
    """FastAPI dependency for Slack service.

    Returns:
        SlackService singleton instance.
    """
    return _get_slack_service_instance()


async def initialize_slack() -> None:
    """Initialize Slack handlers during app startup.

    This sets up the Slack Bolt handlers with the SlackService.
    Should be called once during application lifespan startup.
    Skips initialization if Slack is not configured.
    """
    # Skip if Slack is not configured
    if not settings.slack_bot_token:
        return

    from apps.api.integrations.slack.app import setup_slack_handlers

    service = _get_slack_service_instance()
    setup_slack_handlers(service)


# =============================================================================
# Type Aliases
# =============================================================================

AuditDep = Annotated[AuditService, Depends(get_audit_service)]
MemoryManagerDep = Annotated[MemoryManager, Depends(get_memory_manager)]
AgentDep = Annotated[DigitalValeriiAgent, Depends(get_agent)]


# =============================================================================
# Scheduler Service Dependencies
# =============================================================================

_scheduler_service: "SchedulerService | None" = None


async def get_scheduler_service() -> "SchedulerService":
    """FastAPI dependency for scheduler service.

    Returns:
        SchedulerService singleton instance.
    """
    global _scheduler_service  # noqa: PLW0603
    if _scheduler_service is None:
        from apps.api.scheduler.service import SchedulerService

        db = get_database()
        _scheduler_service = SchedulerService(db.session)
    return _scheduler_service


async def reset_scheduler_service() -> None:
    """Reset scheduler service instance (for testing)."""
    global _scheduler_service  # noqa: PLW0603
    if _scheduler_service is not None:
        await _scheduler_service.stop()
    _scheduler_service = None


SchedulerServiceDep = Annotated["SchedulerService", Depends(get_scheduler_service)]


# =============================================================================
# Session Manager Dependencies (Component 4.8)
# =============================================================================


async def get_session_manager(
    session: DBSession,
) -> UnifiedSessionManager:
    """FastAPI dependency for session manager.

    Args:
        session: Database session from dependency injection.

    Returns:
        UnifiedSessionManager instance for the request.
    """
    return UnifiedSessionManager(session)


async def get_compact_handler(
    session: DBSession,
) -> CompactHandler:
    """FastAPI dependency for compact handler.

    Args:
        session: Database session from dependency injection.

    Returns:
        CompactHandler instance for the request.
    """
    session_manager = UnifiedSessionManager(session)
    return CompactHandler(session_manager)


async def get_channel_notifier(
    session: DBSession,
) -> ChannelNotifier:
    """FastAPI dependency for channel notifier.

    Args:
        session: Database session from dependency injection.

    Returns:
        ChannelNotifier instance for the request.
    """
    session_manager = UnifiedSessionManager(session)
    return ChannelNotifier(session_manager=session_manager)


SessionManagerDep = Annotated[UnifiedSessionManager, Depends(get_session_manager)]
CompactHandlerDep = Annotated[CompactHandler, Depends(get_compact_handler)]
ChannelNotifierDep = Annotated[ChannelNotifier, Depends(get_channel_notifier)]


# =============================================================================
# Archive Manager Dependencies (Component 4.9)
# =============================================================================


_archive_manager: ArchiveManager | None = None
_tiered_memory: TieredMemoryManager | None = None


def _get_archive_manager_instance() -> ArchiveManager:
    """Get or create the global ArchiveManager instance."""
    global _archive_manager  # noqa: PLW0603
    if _archive_manager is None:
        db = get_database()
        qdrant = QdrantService(
            QdrantSettings(
                url=settings.qdrant_url,
                api_key=settings.qdrant_api_key,
            )
        )
        embedding = EmbeddingService(
            EmbeddingSettings(
                voyage_api_key=settings.voyage_api_key,
                model=settings.embedding_model,
                dimensions=settings.embedding_dimensions,
            ),
        )
        _archive_manager = ArchiveManager(
            db=db,
            qdrant=qdrant,
            embedding=embedding,
        )
    return _archive_manager


def _get_tiered_memory_instance() -> TieredMemoryManager:
    """Get or create the global TieredMemoryManager instance."""
    global _tiered_memory  # noqa: PLW0603
    if _tiered_memory is None:
        memory = _get_memory_manager_instance()
        archive = _get_archive_manager_instance()
        _tiered_memory = TieredMemoryManager(
            memory_manager=memory,
            archive_manager=archive,
        )
    return _tiered_memory


async def get_archive_manager() -> ArchiveManager:
    """FastAPI dependency for archive manager.

    Returns:
        ArchiveManager singleton instance.
    """
    return _get_archive_manager_instance()


async def get_tiered_memory() -> TieredMemoryManager:
    """FastAPI dependency for tiered memory manager.

    Returns:
        TieredMemoryManager singleton instance.
    """
    return _get_tiered_memory_instance()


ArchiveManagerDep = Annotated[ArchiveManager, Depends(get_archive_manager)]
TieredMemoryDep = Annotated[TieredMemoryManager, Depends(get_tiered_memory)]


if TYPE_CHECKING:
    from apps.api.scheduler.service import SchedulerService
