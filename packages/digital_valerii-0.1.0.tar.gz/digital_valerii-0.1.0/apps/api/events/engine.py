"""Trigger engine for event matching and action execution."""

import json
from uuid import UUID

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.events.evaluator import ConditionEvaluator
from apps.api.events.executor import ActionExecutor
from apps.api.events.models import (
    EventTriggerResponse,
    IncomingEvent,
    TaskPriority,
    TriggerAction,
    TriggerCondition,
    TriggerType,
)

logger = structlog.get_logger(__name__)

# Map event sources to allowed trigger types (Issue 4)
SOURCE_TO_TRIGGER_TYPES: dict[str, list[str]] = {
    "outlook": ["email", "calendar"],
    "github": ["webhook"],
    "slack": ["slack", "webhook"],
    "servicenow": ["webhook"],
    "calendar": ["calendar"],
    "internal": ["webhook", "schedule"],
}


class TriggerEngine:
    """Engine for matching events against triggers and executing actions.

    Responsibilities:
    1. Query enabled triggers from database
    2. Evaluate trigger conditions against event payloads
    3. Execute matching trigger actions
    4. Update event log with trigger/task links
    """

    def __init__(self, db: AsyncSession) -> None:
        """Initialize engine.

        Args:
            db: Database session for persistence.
        """
        self._db = db
        self._evaluator = ConditionEvaluator()
        self._executor = ActionExecutor(db)

    async def find_matching_triggers(
        self, event: IncomingEvent
    ) -> list[EventTriggerResponse]:
        """Find all enabled triggers that match the event.

        Args:
            event: Incoming event to match.

        Returns:
            List of matching triggers.
        """
        # 1. Query enabled triggers (optionally filtered by source)
        triggers = await self._query_enabled_triggers(event.source.value)

        # 2. For each trigger, evaluate conditions against event payload
        matching = []
        for trigger in triggers:
            if self._evaluator.evaluate_all(trigger.conditions, event.payload):
                matching.append(trigger)
                await logger.ainfo(
                    "Trigger matched",
                    trigger_id=str(trigger.id),
                    trigger_name=trigger.name,
                    event_type=event.event_type,
                )

        return matching

    async def process_triggers(
        self, event: IncomingEvent, event_id: UUID
    ) -> list[UUID]:
        """Find matching triggers and execute their actions.

        Args:
            event: Incoming event.
            event_id: Event log ID for linking.

        Returns:
            List of queued task IDs.
        """
        # 1. Find matching triggers
        matching_triggers = await self.find_matching_triggers(event)

        if not matching_triggers:
            await logger.ainfo(
                "No matching triggers",
                event_type=event.event_type,
                source=event.source.value,
            )
            return []

        # 2. For each trigger, execute action
        task_ids = []
        for trigger in matching_triggers:
            try:
                task_id = await self._executor.execute(trigger, event, event_id)
                if task_id:
                    task_ids.append(task_id)
                    # 3. Update event_log with trigger_id and task_id
                    await self._update_event_log_with_trigger(
                        event_id, trigger.id, task_id
                    )
            except Exception as e:
                await logger.aerror(
                    "Trigger execution failed",
                    trigger_id=str(trigger.id),
                    trigger_name=trigger.name,
                    error=str(e),
                    exc_info=True,
                )
                # Continue with other triggers even if one fails

        await logger.ainfo(
            "Triggers processed",
            event_id=str(event_id),
            matched_count=len(matching_triggers),
            task_count=len(task_ids),
        )

        return task_ids

    async def _query_enabled_triggers(
        self, source: str | None = None
    ) -> list[EventTriggerResponse]:
        """Query enabled triggers from database.

        Args:
            source: Optional source to filter by.

        Returns:
            List of enabled triggers.
        """
        # Get allowed trigger types for this source (Issue 4)
        allowed_types = (
            SOURCE_TO_TRIGGER_TYPES.get(source, ["webhook"]) if source else None
        )

        # Build query with source and trigger type filtering
        if source:
            query = text("""
                SELECT id, name, trigger_type, source, conditions, action,
                       priority, enabled, created_at, updated_at
                FROM event_triggers
                WHERE enabled = true
                  AND deleted_at IS NULL
                  AND (source IS NULL OR source = :source)
                  AND trigger_type = ANY(:allowed_types)
                ORDER BY
                    CASE priority
                        WHEN 'critical' THEN 1
                        WHEN 'high' THEN 2
                        WHEN 'normal' THEN 3
                        WHEN 'low' THEN 4
                        ELSE 5
                    END ASC,
                    created_at ASC
            """)
            result = await self._db.execute(
                query, {"source": source, "allowed_types": allowed_types}
            )
        else:
            query = text("""
                SELECT id, name, trigger_type, source, conditions, action,
                       priority, enabled, created_at, updated_at
                FROM event_triggers
                WHERE enabled = true AND deleted_at IS NULL
                ORDER BY
                    CASE priority
                        WHEN 'critical' THEN 1
                        WHEN 'high' THEN 2
                        WHEN 'normal' THEN 3
                        WHEN 'low' THEN 4
                        ELSE 5
                    END ASC,
                    created_at ASC
            """)
            result = await self._db.execute(query)

        rows = result.fetchall()
        triggers = []

        for row in rows:
            # Parse conditions from JSONB
            conditions = None
            if row.conditions:
                conditions_data = (
                    row.conditions
                    if isinstance(row.conditions, list)
                    else json.loads(row.conditions)
                    if row.conditions
                    else None
                )
                if conditions_data:
                    conditions = [TriggerCondition(**c) for c in conditions_data]

            # Parse action from JSONB
            action_data = (
                row.action
                if isinstance(row.action, dict)
                else json.loads(row.action)
                if row.action
                else {}
            )
            action = TriggerAction(**action_data)

            triggers.append(
                EventTriggerResponse(
                    id=row.id,
                    name=row.name,
                    trigger_type=TriggerType(row.trigger_type),
                    source=row.source,
                    conditions=conditions,
                    action=action,
                    priority=TaskPriority(row.priority),
                    enabled=row.enabled,
                    created_at=row.created_at,
                    updated_at=row.updated_at,
                )
            )

        return triggers

    async def _update_event_log_with_trigger(
        self, event_id: UUID, trigger_id: UUID, task_id: UUID
    ) -> None:
        """Append trigger/task link to event log (supports multiple triggers).

        Uses JSONB array to store all trigger/task matches for an event,
        rather than overwriting a single trigger_id/task_id pair.

        Args:
            event_id: Event log ID.
            trigger_id: Trigger that matched.
            task_id: Task that was queued.
        """
        query = text("""
            UPDATE event_log
            SET triggered_tasks = COALESCE(triggered_tasks, '[]'::jsonb) ||
                jsonb_build_object('trigger_id', :trigger_id::text, 'task_id', :task_id::text)
            WHERE id = :event_id
        """)
        await self._db.execute(
            query,
            {
                "event_id": event_id,
                "trigger_id": str(trigger_id),
                "task_id": str(task_id),
            },
        )
        await self._db.commit()
