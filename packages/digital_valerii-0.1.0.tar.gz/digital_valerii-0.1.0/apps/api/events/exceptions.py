"""Event system exceptions."""

from uuid import UUID


class EventError(Exception):
    """Base exception for event system."""

    def __init__(self, message: str = "Event operation failed") -> None:
        self.message = message
        super().__init__(message)


class EventValidationError(EventError):
    """Raised when event validation fails."""

    def __init__(self, message: str = "Event validation failed") -> None:
        super().__init__(message)


class EventProcessingError(EventError):
    """Raised when event processing fails."""

    def __init__(
        self, event_id: UUID | None = None, message: str = "Event processing failed"
    ) -> None:
        self.event_id = event_id
        full_message = f"{message} (event_id={event_id})" if event_id else message
        super().__init__(full_message)


class TriggerNotFoundError(EventError):
    """Raised when trigger is not found."""

    def __init__(self, trigger_id: UUID) -> None:
        self.trigger_id = trigger_id
        super().__init__(f"Trigger not found: {trigger_id}")


class TaskNotFoundError(EventError):
    """Raised when task is not found."""

    def __init__(self, task_id: UUID) -> None:
        self.task_id = task_id
        super().__init__(f"Task not found: {task_id}")


class WebhookSignatureError(EventError):
    """Raised when webhook signature verification fails."""

    def __init__(self, source: str, message: str = "Invalid signature") -> None:
        self.source = source
        super().__init__(f"Webhook signature error from {source}: {message}")


class TriggerMatchError(EventError):
    """Raised when trigger matching fails."""

    def __init__(self, trigger_id: UUID, message: str = "Trigger match failed") -> None:
        self.trigger_id = trigger_id
        super().__init__(f"{message} (trigger_id={trigger_id})")


class ConditionEvaluationError(EventError):
    """Raised when condition evaluation fails."""

    def __init__(
        self, condition: str, message: str = "Condition evaluation failed"
    ) -> None:
        self.condition = condition
        super().__init__(f"{message}: {condition}")


class ActionExecutionError(EventError):
    """Raised when action execution fails."""

    def __init__(
        self, action_type: str, message: str = "Action execution failed"
    ) -> None:
        self.action_type = action_type
        super().__init__(f"{message} (action_type={action_type})")
