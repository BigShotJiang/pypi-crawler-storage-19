"""Event system module.

Provides webhook handling, event processing, and task queue management
for Digital Valerii's event-driven architecture.
"""

from .engine import TriggerEngine
from .evaluator import ConditionEvaluator
from .exceptions import (
    ActionExecutionError,
    ConditionEvaluationError,
    EventError,
    EventProcessingError,
    EventValidationError,
    TriggerMatchError,
    TriggerNotFoundError,
)
from .executor import ActionExecutor
from .models import (
    EventLogEntry,
    EventSource,
    EventTriggerCreate,
    EventTriggerResponse,
    IncomingEvent,
    TaskPriority,
    TaskQueueItem,
    TaskStatus,
    TriggerAction,
    TriggerCondition,
    TriggerType,
)
from .processor import EventProcessor

__all__ = [
    # Processor & Engine
    "EventProcessor",
    "TriggerEngine",
    "ConditionEvaluator",
    "ActionExecutor",
    # Models
    "TriggerType",
    "EventSource",
    "TaskPriority",
    "TaskStatus",
    "TriggerCondition",
    "TriggerAction",
    "EventTriggerCreate",
    "EventTriggerResponse",
    "IncomingEvent",
    "TaskQueueItem",
    "EventLogEntry",
    # Exceptions
    "EventError",
    "EventValidationError",
    "EventProcessingError",
    "TriggerNotFoundError",
    "TriggerMatchError",
    "ConditionEvaluationError",
    "ActionExecutionError",
]
