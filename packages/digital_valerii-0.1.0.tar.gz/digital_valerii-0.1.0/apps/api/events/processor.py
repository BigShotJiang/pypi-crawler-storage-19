"""Event processor for validation and routing."""

import json
from datetime import UTC, datetime
from uuid import UUID, uuid4

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.events.engine import TriggerEngine
from apps.api.events.exceptions import EventProcessingError
from apps.api.events.models import (
    IncomingEvent,
    TaskPriority,
    TaskQueueItem,
    TaskStatus,
)

logger = structlog.get_logger(__name__)


class EventProcessor:
    """Processes incoming events.

    Responsibilities:
    1. Validate incoming events
    2. Log events to database
    3. Match against triggers (delegated to TriggerEngine in 4.5)
    4. Queue tasks for execution
    """

    def __init__(self, db: AsyncSession) -> None:
        """Initialize processor.

        Args:
            db: Database session for persistence.
        """
        self._db = db
        self._trigger_engine = TriggerEngine(db)

    async def process(self, event: IncomingEvent) -> UUID:
        """Process an incoming event.

        Args:
            event: The incoming event to process.

        Returns:
            Event log ID for tracking.
        """
        event_id = uuid4()

        await logger.ainfo(
            "Processing event",
            event_id=str(event_id),
            event_type=event.event_type,
            source=event.source.value,
        )

        try:
            # 1. Log the event
            await self._log_event(event_id, event)

            # 2. Find and execute matching triggers
            task_ids = await self._trigger_engine.process_triggers(event, event_id)

            if task_ids:
                await logger.ainfo(
                    "Triggers executed",
                    event_id=str(event_id),
                    task_count=len(task_ids),
                )

            # 3. Mark as processed
            await self._mark_processed(event_id)

            await logger.ainfo(
                "Event processed",
                event_id=str(event_id),
                task_count=len(task_ids),
            )

            return event_id

        except Exception as e:
            await logger.aerror(
                "Event processing failed",
                event_id=str(event_id),
                error=str(e),
                exc_info=True,
            )
            raise EventProcessingError(event_id, str(e)) from e

    async def _log_event(self, event_id: UUID, event: IncomingEvent) -> None:
        """Log event to database."""
        query = text("""
            INSERT INTO event_log (id, event_type, source, external_id, payload, processed)
            VALUES (:id, :event_type, :source, :external_id, :payload::jsonb, false)
        """)
        await self._db.execute(
            query,
            {
                "id": event_id,
                "event_type": event.event_type,
                "source": event.source.value,
                "external_id": event.external_id,
                "payload": json.dumps(event.payload),
            },
        )
        await self._db.commit()

    async def _mark_processed(self, event_id: UUID) -> None:
        """Mark event as processed."""
        query = text("""
            UPDATE event_log SET processed = true WHERE id = :id
        """)
        await self._db.execute(query, {"id": event_id})
        await self._db.commit()

    async def queue_task(
        self,
        task_type: str,
        payload: dict,
        priority: TaskPriority = TaskPriority.NORMAL,
        trigger_id: UUID | None = None,
        schedule_id: UUID | None = None,
    ) -> UUID:
        """Queue a task for execution.

        Args:
            task_type: Type of task (agent_task, notification, etc.)
            payload: Task payload.
            priority: Task priority.
            trigger_id: Optional trigger that created this task.
            schedule_id: Optional schedule that created this task.

        Returns:
            Task ID.
        """
        task_id = uuid4()

        query = text("""
            INSERT INTO task_queue (id, trigger_id, schedule_id, task_type, payload, priority, status)
            VALUES (:id, :trigger_id, :schedule_id, :task_type, :payload::jsonb, :priority, 'pending')
        """)
        await self._db.execute(
            query,
            {
                "id": task_id,
                "trigger_id": trigger_id,
                "schedule_id": schedule_id,
                "task_type": task_type,
                "payload": json.dumps(payload),
                "priority": priority.value,
            },
        )
        await self._db.commit()

        await logger.ainfo(
            "Task queued",
            task_id=str(task_id),
            task_type=task_type,
            priority=priority.value,
        )

        return task_id

    async def get_pending_tasks(self, limit: int = 10) -> list[TaskQueueItem]:
        """Get pending tasks for execution.

        Args:
            limit: Maximum tasks to return.

        Returns:
            List of pending tasks.
        """
        query = text("""
            SELECT id, trigger_id, schedule_id, task_type, payload, priority,
                   status, attempts, max_attempts, created_at, started_at,
                   completed_at, error
            FROM task_queue
            WHERE status = 'pending' AND attempts < max_attempts
            ORDER BY
                CASE priority
                    WHEN 'critical' THEN 1
                    WHEN 'high' THEN 2
                    WHEN 'normal' THEN 3
                    WHEN 'low' THEN 4
                END,
                created_at ASC
            LIMIT :limit
        """)
        result = await self._db.execute(query, {"limit": limit})
        rows = result.fetchall()

        tasks = []
        for row in rows:
            tasks.append(
                TaskQueueItem(
                    id=row.id,
                    trigger_id=row.trigger_id,
                    schedule_id=row.schedule_id,
                    task_type=row.task_type,
                    payload=row.payload if isinstance(row.payload, dict) else {},
                    priority=TaskPriority(row.priority),
                    status=TaskStatus(row.status),
                    attempts=row.attempts,
                    max_attempts=row.max_attempts,
                    created_at=row.created_at,
                    started_at=row.started_at,
                    completed_at=row.completed_at,
                    error=row.error,
                )
            )

        return tasks

    async def mark_task_running(self, task_id: UUID) -> None:
        """Mark task as running."""
        query = text("""
            UPDATE task_queue
            SET status = 'running', started_at = :now, attempts = attempts + 1
            WHERE id = :id
        """)
        await self._db.execute(
            query,
            {"id": task_id, "now": datetime.now(UTC)},
        )
        await self._db.commit()

    async def mark_task_completed(self, task_id: UUID) -> None:
        """Mark task as completed."""
        query = text("""
            UPDATE task_queue
            SET status = 'completed', completed_at = :now
            WHERE id = :id
        """)
        await self._db.execute(
            query,
            {"id": task_id, "now": datetime.now(UTC)},
        )
        await self._db.commit()

    async def mark_task_failed(self, task_id: UUID, error: str) -> None:
        """Mark task as failed."""
        query = text("""
            UPDATE task_queue
            SET status = CASE WHEN attempts >= max_attempts THEN 'failed' ELSE 'pending' END,
                error = :error
            WHERE id = :id
        """)
        await self._db.execute(query, {"id": task_id, "error": error})
        await self._db.commit()
