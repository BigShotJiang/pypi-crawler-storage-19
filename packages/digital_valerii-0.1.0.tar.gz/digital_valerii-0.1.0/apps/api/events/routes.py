"""Event webhook endpoints."""

import hashlib
import hmac
from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.config import settings
from apps.api.dependencies import get_db_session
from apps.api.events.models import (
    EventLogEntry,
    EventLogFilter,
    EventSource,
    EventTriggerCreate,
    EventTriggerResponse,
    EventTriggerUpdate,
    IncomingEvent,
    TriggerType,
)
from apps.api.events.processor import EventProcessor
from apps.api.events.service import EventService

logger = structlog.get_logger(__name__)
router = APIRouter(prefix="/events", tags=["events"])

# Sources blocked from generic webhook (must use specific endpoints)
BLOCKED_SOURCES = {EventSource.INTERNAL}


# =============================================================================
# Dependencies
# =============================================================================


async def get_event_processor(
    db: Annotated[AsyncSession, Depends(get_db_session)],
) -> EventProcessor:
    """Get EventProcessor dependency."""
    return EventProcessor(db)


async def get_event_service(
    db: Annotated[AsyncSession, Depends(get_db_session)],
) -> EventService:
    """Get EventService dependency."""
    return EventService(db)


EventProcessorDep = Annotated[EventProcessor, Depends(get_event_processor)]
EventServiceDep = Annotated[EventService, Depends(get_event_service)]


# =============================================================================
# Webhook Endpoints
# =============================================================================


@router.post("/webhook/{source}")
async def generic_webhook(
    source: EventSource,
    request: Request,
    processor: EventProcessorDep,
    x_api_key: str | None = Header(None),
) -> dict[str, Any]:
    """Generic webhook receiver.

    Args:
        source: Event source identifier.
        request: Raw request for payload extraction.
        processor: Event processor dependency.
        x_api_key: API key header for authentication.

    Returns:
        Acknowledgment with event ID.
    """
    # Block INTERNAL source on generic endpoint
    if source in BLOCKED_SOURCES:
        await logger.awarning("Blocked source on generic webhook", source=source.value)
        raise HTTPException(
            status_code=400, detail="Source not allowed on generic endpoint"
        )

    # Fail closed: require API key for generic webhook
    if not settings.events_api_key:
        await logger.awarning("Generic webhook called but API key not configured")
        raise HTTPException(status_code=503, detail="Generic webhook not configured")

    # Verify API key
    if not x_api_key or not hmac.compare_digest(x_api_key, settings.events_api_key):
        await logger.awarning("Invalid or missing API key on generic webhook")
        raise HTTPException(status_code=401, detail="Invalid API key")

    payload = await request.json()

    await logger.ainfo(
        "Webhook received",
        source=source.value,
        payload_size=len(str(payload)),
    )

    event = IncomingEvent(
        event_type="webhook",
        source=source,
        payload=payload,
    )

    event_id = await processor.process(event)

    return {"status": "accepted", "event_id": str(event_id)}


@router.post("/outlook/webhook", response_model=None)
async def outlook_webhook(
    request: Request,
    processor: EventProcessorDep,
    x_client_state: str | None = Header(None),
) -> Response | dict[str, Any]:
    """Microsoft Graph webhook for mail/calendar.

    Handles validation requests and actual notifications.
    """
    # Handle validation request (Graph sends validationToken in query)
    validation_token = request.query_params.get("validationToken")
    if validation_token:
        await logger.ainfo("Outlook webhook validation", token=validation_token[:20])
        # Must return plain token for validation
        return Response(content=validation_token, media_type="text/plain")

    payload = await request.json()

    # Verify client state if configured - require header when secret is set
    if settings.microsoft_webhook_client_state:
        if not x_client_state:
            await logger.awarning("Missing Outlook webhook client state header")
            raise HTTPException(status_code=401, detail="Missing client state")
        if not hmac.compare_digest(
            x_client_state, settings.microsoft_webhook_client_state
        ):
            await logger.awarning("Invalid Outlook webhook client state")
            raise HTTPException(status_code=401, detail="Invalid client state")

    # Process notifications
    for notification in payload.get("value", []):
        event = IncomingEvent(
            event_type=notification.get("changeType", "unknown"),
            source=EventSource.OUTLOOK,
            external_id=notification.get("resourceData", {}).get("id"),
            payload=notification,
        )
        await processor.process(event)

    return {"status": "accepted"}


@router.post("/github/webhook")
async def github_webhook(
    request: Request,
    processor: EventProcessorDep,
    x_hub_signature_256: str | None = Header(None),
    x_github_event: str | None = Header(None),
) -> dict[str, Any]:
    """GitHub webhook for PR/issue events.

    Verifies signature using GITHUB_WEBHOOK_SECRET.
    """
    # Fail closed: require secret for webhook endpoints
    if not settings.github_webhook_secret:
        await logger.awarning("GitHub webhook called but secret not configured")
        raise HTTPException(status_code=503, detail="GitHub webhook not configured")

    body = await request.body()

    # Verify signature
    if not x_hub_signature_256:
        raise HTTPException(status_code=401, detail="Missing signature")

    expected = (
        "sha256="
        + hmac.new(
            settings.github_webhook_secret.encode(),
            body,
            hashlib.sha256,
        ).hexdigest()
    )

    if not hmac.compare_digest(x_hub_signature_256, expected):
        await logger.awarning("Invalid GitHub webhook signature")
        raise HTTPException(status_code=401, detail="Invalid signature")

    payload = await request.json()

    event = IncomingEvent(
        event_type=x_github_event or "unknown",
        source=EventSource.GITHUB,
        external_id=str(payload.get("action", "")),
        payload=payload,
    )

    event_id = await processor.process(event)

    return {"status": "accepted", "event_id": str(event_id)}


@router.post("/servicenow/webhook")
async def servicenow_webhook(
    request: Request,
    processor: EventProcessorDep,
    x_servicenow_signature: str | None = Header(None),
) -> dict[str, Any]:
    """ServiceNow webhook for incident events.

    Verifies HMAC-SHA256 signature using SERVICENOW_WEBHOOK_SECRET.
    """
    # Fail closed: require secret for webhook endpoints
    if not settings.servicenow_webhook_secret:
        await logger.awarning("ServiceNow webhook called but secret not configured")
        raise HTTPException(status_code=503, detail="ServiceNow webhook not configured")

    body = await request.body()

    # Verify signature
    if not x_servicenow_signature:
        await logger.awarning("Missing ServiceNow webhook signature")
        raise HTTPException(status_code=401, detail="Missing signature")

    expected = (
        "sha256="
        + hmac.new(
            settings.servicenow_webhook_secret.encode(),
            body,
            hashlib.sha256,
        ).hexdigest()
    )

    if not hmac.compare_digest(x_servicenow_signature, expected):
        await logger.awarning("Invalid ServiceNow webhook signature")
        raise HTTPException(status_code=401, detail="Invalid signature")

    payload = await request.json()

    # Extract incident info
    incident = payload.get("current", {})
    event_type = "incident_" + incident.get("state", "unknown")

    event = IncomingEvent(
        event_type=event_type,
        source=EventSource.SERVICENOW,
        external_id=incident.get("number"),
        payload=payload,
    )

    event_id = await processor.process(event)

    return {"status": "accepted", "event_id": str(event_id)}


# =============================================================================
# Trigger CRUD Endpoints
# =============================================================================


@router.post("/triggers", response_model=EventTriggerResponse)
async def create_trigger(
    trigger: EventTriggerCreate,
    service: EventServiceDep,
) -> EventTriggerResponse:
    """Create a new event trigger."""
    return await service.create_trigger(trigger)


@router.get("/triggers", response_model=list[EventTriggerResponse])
async def list_triggers(
    service: EventServiceDep,
    trigger_type: TriggerType | None = None,
    source: EventSource | None = None,
    enabled: bool | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[EventTriggerResponse]:
    """List event triggers."""
    return await service.list_triggers(
        trigger_type=trigger_type,
        source=source,
        enabled=enabled,
        limit=limit,
        offset=offset,
    )


@router.get("/triggers/{trigger_id}", response_model=EventTriggerResponse)
async def get_trigger(
    trigger_id: str,
    service: EventServiceDep,
) -> EventTriggerResponse:
    """Get an event trigger by ID."""
    from uuid import UUID

    return await service.get_trigger(UUID(trigger_id))


@router.patch("/triggers/{trigger_id}", response_model=EventTriggerResponse)
async def update_trigger(
    trigger_id: str,
    update: EventTriggerUpdate,
    service: EventServiceDep,
) -> EventTriggerResponse:
    """Update an event trigger."""
    from uuid import UUID

    return await service.update_trigger(UUID(trigger_id), update)


@router.delete("/triggers/{trigger_id}", status_code=204)
async def delete_trigger(
    trigger_id: str,
    service: EventServiceDep,
) -> None:
    """Delete an event trigger."""
    from uuid import UUID

    await service.delete_trigger(UUID(trigger_id))


# =============================================================================
# Event Log Endpoints
# =============================================================================


@router.get("/log", response_model=list[EventLogEntry])
async def get_event_log(
    service: EventServiceDep,
    source: EventSource | None = None,
    event_type: str | None = None,
    processed: bool | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[EventLogEntry]:
    """Get event log entries."""
    filter_params = EventLogFilter(
        source=source,
        event_type=event_type,
        processed=processed,
        limit=limit,
        offset=offset,
    )
    return await service.get_event_log(filter_params)
