"""Event system Pydantic models."""

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator


class TriggerType(str, Enum):
    """Types of event triggers."""

    WEBHOOK = "webhook"
    EMAIL = "email"
    SLACK = "slack"
    CALENDAR = "calendar"
    SCHEDULE = "schedule"


class EventSource(str, Enum):
    """Known event sources."""

    OUTLOOK = "outlook"
    SERVICENOW = "servicenow"
    SLACK = "slack"
    GITHUB = "github"
    CALENDAR = "calendar"
    INTERNAL = "internal"


class TaskPriority(str, Enum):
    """Task priority levels."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class TaskStatus(str, Enum):
    """Task execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class TriggerCondition(BaseModel):
    """Condition for trigger matching."""

    model_config = ConfigDict(extra="forbid")

    field: str = Field(..., description="Field to match")
    operator: str = Field(..., pattern="^(eq|ne|contains|regex|gt|lt)$")
    value: Any = Field(..., description="Value to compare")


class TriggerAction(BaseModel):
    """Action to execute when trigger fires."""

    model_config = ConfigDict(extra="forbid")

    type: str = Field(..., pattern="^(agent_task|notification|webhook)$")
    prompt: str | None = Field(None, description="Prompt for agent_task")
    webhook_url: str | None = Field(None, description="URL for webhook action")
    notification_channel: str | None = Field(
        None, description="Channel for notification"
    )

    @model_validator(mode="after")
    def validate_action_fields(self) -> "TriggerAction":
        """Validate required fields based on action type."""
        if self.type == "agent_task":
            if not self.prompt:
                raise ValueError("prompt is required for agent_task action")
        elif self.type == "webhook":
            if not self.webhook_url:
                raise ValueError("webhook_url is required for webhook action")
        elif self.type == "notification":
            if not self.notification_channel:
                raise ValueError(
                    "notification_channel is required for notification action"
                )
        return self


class EventTriggerCreate(BaseModel):
    """Create a new event trigger."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., min_length=1, max_length=255)
    trigger_type: TriggerType
    source: EventSource | None = None
    conditions: list[TriggerCondition] | None = None
    action: TriggerAction
    priority: TaskPriority = TaskPriority.NORMAL
    enabled: bool = True


class EventTriggerUpdate(BaseModel):
    """Update an event trigger."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(None, min_length=1, max_length=255)
    trigger_type: TriggerType | None = None
    source: EventSource | None = None
    conditions: list[TriggerCondition] | None = None
    action: TriggerAction | None = None
    priority: TaskPriority | None = None
    enabled: bool | None = None


class EventTriggerResponse(BaseModel):
    """Event trigger response."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    name: str
    trigger_type: TriggerType
    source: EventSource | None
    conditions: list[TriggerCondition] | None
    action: TriggerAction
    priority: TaskPriority
    enabled: bool
    created_at: datetime
    updated_at: datetime


class IncomingEvent(BaseModel):
    """Incoming event from webhook."""

    model_config = ConfigDict(extra="forbid")

    event_type: str = Field(..., description="Type of event")
    source: EventSource = Field(..., description="Event source")
    external_id: str | None = Field(None, description="External reference ID")
    payload: dict[str, Any] = Field(default_factory=dict)


class TaskQueueItem(BaseModel):
    """Task in the execution queue."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    trigger_id: UUID | None
    schedule_id: UUID | None = None
    task_type: str
    payload: dict[str, Any]
    priority: TaskPriority
    status: TaskStatus
    attempts: int
    max_attempts: int
    created_at: datetime
    started_at: datetime | None
    completed_at: datetime | None
    error: str | None


class EventLogEntry(BaseModel):
    """Event log entry."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    event_type: str
    source: EventSource
    external_id: str | None
    payload: dict[str, Any] | None
    trigger_id: UUID | None
    task_id: UUID | None
    triggered_tasks: list[dict[str, str]] | None = None  # [{trigger_id, task_id}, ...]
    processed: bool
    created_at: datetime


class EventLogFilter(BaseModel):
    """Filter for event log queries."""

    model_config = ConfigDict(extra="forbid")

    source: EventSource | None = None
    event_type: str | None = None
    processed: bool | None = None
    limit: int = Field(default=50, ge=1, le=100)
    offset: int = Field(default=0, ge=0)
