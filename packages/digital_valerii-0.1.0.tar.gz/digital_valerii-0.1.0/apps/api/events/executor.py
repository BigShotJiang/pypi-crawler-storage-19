"""Action executor for trigger actions."""

import json
from uuid import UUID, uuid4

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.events.exceptions import ActionExecutionError
from apps.api.events.models import (
    EventTriggerResponse,
    IncomingEvent,
)

logger = structlog.get_logger(__name__)


class ActionExecutor:
    """Executes trigger actions by queuing tasks."""

    def __init__(self, db: AsyncSession) -> None:
        """Initialize executor.

        Args:
            db: Database session for task queuing.
        """
        self._db = db

    async def execute(
        self,
        trigger: EventTriggerResponse,
        event: IncomingEvent,
        event_id: UUID,
    ) -> UUID | None:
        """Execute trigger action by queuing a task.

        Args:
            trigger: Trigger that matched.
            event: Event that triggered.
            event_id: Event log ID.

        Returns:
            Task ID if task was queued, None otherwise.
        """
        action = trigger.action

        await logger.ainfo(
            "Executing action",
            trigger_id=str(trigger.id),
            trigger_name=trigger.name,
            action_type=action.type,
        )

        if action.type == "agent_task":
            return await self._execute_agent_task(trigger, event, event_id)
        elif action.type == "notification":
            return await self._execute_notification(trigger, event, event_id)
        elif action.type == "webhook":
            return await self._execute_webhook(trigger, event, event_id)
        else:
            await logger.awarning(
                "Unknown action type",
                action_type=action.type,
                trigger_id=str(trigger.id),
            )
            return None

    async def _execute_agent_task(
        self,
        trigger: EventTriggerResponse,
        event: IncomingEvent,
        event_id: UUID,
    ) -> UUID:
        """Queue an agent task.

        Creates a task in task_queue with:
        - task_type: "agent_task"
        - payload: {prompt, event_payload, event_type, source}
        - priority: from trigger
        - trigger_id: trigger.id

        Args:
            trigger: Trigger that fired.
            event: Incoming event.
            event_id: Event log ID.

        Returns:
            Queued task ID.

        Raises:
            ActionExecutionError: If prompt is missing.
        """
        # Defensive check - prompt should be validated by model, but check anyway
        if not trigger.action.prompt:
            raise ActionExecutionError("agent_task", "Missing prompt")

        payload = {
            "prompt": trigger.action.prompt,
            "event_type": event.event_type,
            "source": event.source.value,
            "event_payload": event.payload,
            "trigger_name": trigger.name,
            "event_id": str(event_id),
        }

        task_id = await self._queue_task(
            task_type="agent_task",
            payload=payload,
            priority=trigger.priority.value,
            trigger_id=trigger.id,
        )

        await logger.ainfo(
            "Agent task queued",
            task_id=str(task_id),
            trigger_name=trigger.name,
        )

        return task_id

    async def _execute_notification(
        self,
        trigger: EventTriggerResponse,
        event: IncomingEvent,
        event_id: UUID,
    ) -> UUID:
        """Queue a notification task.

        Creates a task in task_queue with:
        - task_type: "notification"
        - payload: {channel, message, event_summary}
        - priority: from trigger
        - trigger_id: trigger.id

        Args:
            trigger: Trigger that fired.
            event: Incoming event.
            event_id: Event log ID.

        Returns:
            Queued task ID.

        Raises:
            ActionExecutionError: If notification_channel is missing.
        """
        # Defensive check - channel should be validated by model, but check anyway
        if not trigger.action.notification_channel:
            raise ActionExecutionError("notification", "Missing notification_channel")

        payload = {
            "channel": trigger.action.notification_channel,
            "trigger_name": trigger.name,
            "event_type": event.event_type,
            "source": event.source.value,
            "summary": (
                f"Trigger '{trigger.name}' fired for "
                f"{event.event_type} from {event.source.value}"
            ),
            "event_id": str(event_id),
        }

        task_id = await self._queue_task(
            task_type="notification",
            payload=payload,
            priority=trigger.priority.value,
            trigger_id=trigger.id,
        )

        await logger.ainfo(
            "Notification task queued",
            task_id=str(task_id),
            trigger_name=trigger.name,
            channel=trigger.action.notification_channel,
        )

        return task_id

    async def _execute_webhook(
        self,
        trigger: EventTriggerResponse,
        event: IncomingEvent,
        event_id: UUID,
    ) -> UUID:
        """Queue a webhook task.

        Creates a task in task_queue with:
        - task_type: "webhook"
        - payload: {url, event_payload}
        - priority: from trigger
        - trigger_id: trigger.id

        NOTE: Actual HTTP call is made by task worker.

        Args:
            trigger: Trigger that fired.
            event: Incoming event.
            event_id: Event log ID.

        Returns:
            Queued task ID.

        Raises:
            ActionExecutionError: If webhook_url is missing.
        """
        # Defensive check - url should be validated by model, but check anyway
        if not trigger.action.webhook_url:
            raise ActionExecutionError("webhook", "Missing webhook_url")

        payload = {
            "url": trigger.action.webhook_url,
            "method": "POST",
            "body": {
                "trigger_id": str(trigger.id),
                "trigger_name": trigger.name,
                "event_type": event.event_type,
                "source": event.source.value,
                "event_payload": event.payload,
                "event_id": str(event_id),
            },
        }

        task_id = await self._queue_task(
            task_type="webhook",
            payload=payload,
            priority=trigger.priority.value,
            trigger_id=trigger.id,
        )

        await logger.ainfo(
            "Webhook task queued",
            task_id=str(task_id),
            trigger_name=trigger.name,
            webhook_url=trigger.action.webhook_url,
        )

        return task_id

    async def _queue_task(
        self,
        task_type: str,
        payload: dict,
        priority: str,
        trigger_id: UUID,
    ) -> UUID:
        """Queue a task in task_queue.

        Args:
            task_type: Type of task.
            payload: Task payload.
            priority: Task priority.
            trigger_id: Trigger that created this task.

        Returns:
            New task ID.
        """
        task_id = uuid4()

        query = text("""
            INSERT INTO task_queue (id, trigger_id, task_type, payload, priority, status)
            VALUES (:id, :trigger_id, :task_type, :payload::jsonb, :priority, 'pending')
        """)
        await self._db.execute(
            query,
            {
                "id": task_id,
                "trigger_id": trigger_id,
                "task_type": task_type,
                "payload": json.dumps(payload),
                "priority": priority,
            },
        )
        await self._db.commit()

        return task_id
