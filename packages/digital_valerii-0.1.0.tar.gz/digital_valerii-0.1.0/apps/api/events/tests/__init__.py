"""Event system tests."""
