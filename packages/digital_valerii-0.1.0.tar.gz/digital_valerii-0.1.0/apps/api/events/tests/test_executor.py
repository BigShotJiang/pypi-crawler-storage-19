"""Tests for ActionExecutor."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.events.exceptions import ActionExecutionError
from apps.api.events.executor import ActionExecutor
from apps.api.events.models import (
    EventSource,
    EventTriggerResponse,
    IncomingEvent,
    TaskPriority,
    TriggerAction,
    TriggerType,
)


@pytest.fixture
def mock_db():
    """Create mock database session."""
    db = AsyncMock()
    db.execute = AsyncMock()
    db.commit = AsyncMock()
    return db


@pytest.fixture
def executor(mock_db):
    """Create ActionExecutor with mock database."""
    return ActionExecutor(mock_db)


@pytest.fixture
def sample_event():
    """Create sample incoming event."""
    return IncomingEvent(
        event_type="pull_request",
        source=EventSource.GITHUB,
        external_id="12345",
        payload={"action": "opened", "number": 123},
    )


def create_trigger(action_type: str, **action_kwargs) -> EventTriggerResponse:
    """Helper to create trigger with specified action."""
    return EventTriggerResponse(
        id=uuid4(),
        name="Test Trigger",
        trigger_type=TriggerType.WEBHOOK,
        source=EventSource.GITHUB,
        conditions=None,
        action=TriggerAction(type=action_type, **action_kwargs),
        priority=TaskPriority.HIGH,
        enabled=True,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


class TestActionExecutorInit:
    """Tests for ActionExecutor initialization."""

    def test_init(self, mock_db):
        """Should initialize with database session."""
        executor = ActionExecutor(mock_db)
        assert executor._db == mock_db


class TestExecuteAgentTask:
    """Tests for agent_task action execution."""

    @pytest.mark.asyncio
    async def test_execute_agent_task(self, executor, mock_db, sample_event):
        """Should queue agent task."""
        trigger = create_trigger("agent_task", prompt="Process this event")
        event_id = uuid4()

        task_id = await executor.execute(trigger, sample_event, event_id)

        assert task_id is not None
        mock_db.execute.assert_called_once()
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_agent_task_payload_format(self, executor, mock_db, sample_event):
        """Should create correct payload format."""
        trigger = create_trigger("agent_task", prompt="Test prompt")
        event_id = uuid4()

        await executor.execute(trigger, sample_event, event_id)

        # Get the call args and check payload
        call_args = mock_db.execute.call_args
        params = call_args[0][1] if len(call_args[0]) > 1 else call_args[1]

        assert params["task_type"] == "agent_task"
        # Payload is JSON string, so check it was passed
        assert "prompt" in params["payload"]
        assert "event_type" in params["payload"]


class TestExecuteNotification:
    """Tests for notification action execution."""

    @pytest.mark.asyncio
    async def test_execute_notification(self, executor, mock_db, sample_event):
        """Should queue notification task."""
        trigger = create_trigger("notification", notification_channel="slack:#alerts")
        event_id = uuid4()

        task_id = await executor.execute(trigger, sample_event, event_id)

        assert task_id is not None
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_notification_payload_format(self, executor, mock_db, sample_event):
        """Should create correct notification payload."""
        trigger = create_trigger("notification", notification_channel="slack:#dev")
        event_id = uuid4()

        await executor.execute(trigger, sample_event, event_id)

        call_args = mock_db.execute.call_args
        params = call_args[0][1] if len(call_args[0]) > 1 else call_args[1]

        assert params["task_type"] == "notification"
        assert "channel" in params["payload"]
        assert "summary" in params["payload"]


class TestExecuteWebhook:
    """Tests for webhook action execution."""

    @pytest.mark.asyncio
    async def test_execute_webhook(self, executor, mock_db, sample_event):
        """Should queue webhook task."""
        trigger = create_trigger("webhook", webhook_url="https://example.com/hook")
        event_id = uuid4()

        task_id = await executor.execute(trigger, sample_event, event_id)

        assert task_id is not None
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_webhook_payload_format(self, executor, mock_db, sample_event):
        """Should create correct webhook payload."""
        trigger = create_trigger(
            "webhook", webhook_url="https://api.example.com/webhook"
        )
        event_id = uuid4()

        await executor.execute(trigger, sample_event, event_id)

        call_args = mock_db.execute.call_args
        params = call_args[0][1] if len(call_args[0]) > 1 else call_args[1]

        assert params["task_type"] == "webhook"
        assert "url" in params["payload"]
        assert "method" in params["payload"]
        assert "body" in params["payload"]


class TestExecuteUnknownAction:
    """Tests for unknown action type handling."""

    @pytest.mark.asyncio
    async def test_execute_unknown_action_type(self, executor, mock_db, sample_event):
        """Should return None for unknown action type."""
        # Create trigger with action that has valid type for Pydantic
        trigger = EventTriggerResponse(
            id=uuid4(),
            name="Test Trigger",
            trigger_type=TriggerType.WEBHOOK,
            source=EventSource.GITHUB,
            conditions=None,
            action=TriggerAction(type="agent_task", prompt="Test"),
            priority=TaskPriority.NORMAL,
            enabled=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        # Manually set invalid type after creation to bypass validation
        trigger.action.type = "unknown_type"
        event_id = uuid4()

        result = await executor.execute(trigger, sample_event, event_id)

        # Should return None for unknown type
        assert result is None
        mock_db.execute.assert_not_called()


class TestDefensiveChecks:
    """Tests for defensive checks (missing required fields)."""

    @pytest.mark.asyncio
    async def test_agent_task_missing_prompt_raises(
        self, executor, mock_db, sample_event
    ):
        """Should raise ActionExecutionError if prompt is missing."""
        # Create trigger with valid prompt, then clear it to bypass model validation
        trigger = EventTriggerResponse(
            id=uuid4(),
            name="Test Trigger",
            trigger_type=TriggerType.WEBHOOK,
            source=EventSource.GITHUB,
            conditions=None,
            action=TriggerAction(type="agent_task", prompt="Test"),
            priority=TaskPriority.NORMAL,
            enabled=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        # Manually clear prompt to test defensive check
        trigger.action.prompt = None
        event_id = uuid4()

        with pytest.raises(ActionExecutionError) as exc_info:
            await executor.execute(trigger, sample_event, event_id)

        assert "Missing prompt" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_notification_missing_channel_raises(
        self, executor, mock_db, sample_event
    ):
        """Should raise ActionExecutionError if notification_channel is missing."""
        trigger = EventTriggerResponse(
            id=uuid4(),
            name="Test Trigger",
            trigger_type=TriggerType.WEBHOOK,
            source=EventSource.GITHUB,
            conditions=None,
            action=TriggerAction(type="notification", notification_channel="slack"),
            priority=TaskPriority.NORMAL,
            enabled=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        # Manually clear channel to test defensive check
        trigger.action.notification_channel = None
        event_id = uuid4()

        with pytest.raises(ActionExecutionError) as exc_info:
            await executor.execute(trigger, sample_event, event_id)

        assert "Missing notification_channel" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_webhook_missing_url_raises(self, executor, mock_db, sample_event):
        """Should raise ActionExecutionError if webhook_url is missing."""
        trigger = EventTriggerResponse(
            id=uuid4(),
            name="Test Trigger",
            trigger_type=TriggerType.WEBHOOK,
            source=EventSource.GITHUB,
            conditions=None,
            action=TriggerAction(type="webhook", webhook_url="https://example.com"),
            priority=TaskPriority.NORMAL,
            enabled=True,
            created_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        # Manually clear url to test defensive check
        trigger.action.webhook_url = None
        event_id = uuid4()

        with pytest.raises(ActionExecutionError) as exc_info:
            await executor.execute(trigger, sample_event, event_id)

        assert "Missing webhook_url" in str(exc_info.value)


class TestTaskPriority:
    """Tests for task priority handling."""

    @pytest.mark.asyncio
    async def test_priority_passed_to_task(self, executor, mock_db, sample_event):
        """Should pass trigger priority to queued task."""
        trigger = create_trigger("notification", notification_channel="slack")
        trigger.priority = TaskPriority.CRITICAL
        event_id = uuid4()

        await executor.execute(trigger, sample_event, event_id)

        call_args = mock_db.execute.call_args
        params = call_args[0][1] if len(call_args[0]) > 1 else call_args[1]

        assert params["priority"] == "critical"


class TestTriggerId:
    """Tests for trigger ID linking."""

    @pytest.mark.asyncio
    async def test_trigger_id_linked(self, executor, mock_db, sample_event):
        """Should link task to trigger ID."""
        trigger = create_trigger("agent_task", prompt="Test")
        event_id = uuid4()

        await executor.execute(trigger, sample_event, event_id)

        call_args = mock_db.execute.call_args
        params = call_args[0][1] if len(call_args[0]) > 1 else call_args[1]

        assert params["trigger_id"] == trigger.id
