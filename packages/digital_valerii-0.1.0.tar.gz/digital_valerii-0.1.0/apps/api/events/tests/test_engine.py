"""Tests for TriggerEngine."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.events.engine import TriggerEngine
from apps.api.events.models import (
    EventSource,
    EventTriggerResponse,
    IncomingEvent,
    TaskPriority,
    TriggerAction,
    TriggerCondition,
    TriggerType,
)


@pytest.fixture
def mock_db():
    """Create mock database session."""
    db = AsyncMock()
    db.execute = AsyncMock()
    db.commit = AsyncMock()
    return db


@pytest.fixture
def engine(mock_db):
    """Create TriggerEngine with mock database."""
    return TriggerEngine(mock_db)


@pytest.fixture
def sample_trigger():
    """Create sample trigger response."""
    return EventTriggerResponse(
        id=uuid4(),
        name="Test Trigger",
        trigger_type=TriggerType.WEBHOOK,
        source=EventSource.GITHUB,
        conditions=[TriggerCondition(field="action", operator="eq", value="opened")],
        action=TriggerAction(type="notification", notification_channel="slack"),
        priority=TaskPriority.NORMAL,
        enabled=True,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


@pytest.fixture
def sample_event():
    """Create sample incoming event."""
    return IncomingEvent(
        event_type="pull_request",
        source=EventSource.GITHUB,
        external_id="12345",
        payload={"action": "opened", "number": 123},
    )


class TestTriggerEngineInit:
    """Tests for TriggerEngine initialization."""

    def test_init(self, mock_db):
        """Should initialize with database session."""
        engine = TriggerEngine(mock_db)
        assert engine._db == mock_db
        assert engine._evaluator is not None
        assert engine._executor is not None


class TestFindMatchingTriggers:
    """Tests for find_matching_triggers method."""

    @pytest.mark.asyncio
    async def test_find_matching_triggers_single_match(
        self, engine, mock_db, sample_trigger, sample_event
    ):
        """Should find single matching trigger."""
        # Mock database response
        mock_row = MagicMock()
        mock_row.id = sample_trigger.id
        mock_row.name = sample_trigger.name
        mock_row.trigger_type = "webhook"
        mock_row.source = "github"
        mock_row.conditions = [{"field": "action", "operator": "eq", "value": "opened"}]
        mock_row.action = {"type": "notification", "notification_channel": "slack"}
        mock_row.priority = "normal"
        mock_row.enabled = True
        mock_row.created_at = sample_trigger.created_at
        mock_row.updated_at = sample_trigger.updated_at

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        matches = await engine.find_matching_triggers(sample_event)

        assert len(matches) == 1
        assert matches[0].name == "Test Trigger"

    @pytest.mark.asyncio
    async def test_find_matching_triggers_no_match(
        self, engine, mock_db, sample_trigger
    ):
        """Should return empty list when no triggers match."""
        # Event with different action
        event = IncomingEvent(
            event_type="pull_request",
            source=EventSource.GITHUB,
            payload={"action": "closed"},  # Different from trigger condition
        )

        # Mock database response
        mock_row = MagicMock()
        mock_row.id = sample_trigger.id
        mock_row.name = sample_trigger.name
        mock_row.trigger_type = "webhook"
        mock_row.source = "github"
        mock_row.conditions = [{"field": "action", "operator": "eq", "value": "opened"}]
        mock_row.action = {"type": "notification", "notification_channel": "slack"}
        mock_row.priority = "normal"
        mock_row.enabled = True
        mock_row.created_at = sample_trigger.created_at
        mock_row.updated_at = sample_trigger.updated_at

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        matches = await engine.find_matching_triggers(event)

        assert len(matches) == 0

    @pytest.mark.asyncio
    async def test_find_matching_triggers_multiple_matches(
        self, engine, mock_db, sample_event
    ):
        """Should find multiple matching triggers."""
        now = datetime.now(UTC)

        # Create two triggers that both match
        mock_rows = []
        for i in range(2):
            row = MagicMock()
            row.id = uuid4()
            row.name = f"Trigger {i}"
            row.trigger_type = "webhook"
            row.source = "github"
            row.conditions = [{"field": "action", "operator": "eq", "value": "opened"}]
            row.action = {"type": "notification", "notification_channel": "slack"}
            row.priority = "normal"
            row.enabled = True
            row.created_at = now
            row.updated_at = now
            mock_rows.append(row)

        mock_result = MagicMock()
        mock_result.fetchall.return_value = mock_rows
        mock_db.execute.return_value = mock_result

        matches = await engine.find_matching_triggers(sample_event)

        assert len(matches) == 2

    @pytest.mark.asyncio
    async def test_find_matching_triggers_no_conditions(
        self, engine, mock_db, sample_event
    ):
        """Should match trigger with no conditions (always match)."""
        now = datetime.now(UTC)

        mock_row = MagicMock()
        mock_row.id = uuid4()
        mock_row.name = "No Conditions Trigger"
        mock_row.trigger_type = "webhook"
        mock_row.source = "github"
        mock_row.conditions = None  # No conditions
        mock_row.action = {"type": "notification", "notification_channel": "slack"}
        mock_row.priority = "normal"
        mock_row.enabled = True
        mock_row.created_at = now
        mock_row.updated_at = now

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        matches = await engine.find_matching_triggers(sample_event)

        assert len(matches) == 1


class TestProcessTriggers:
    """Tests for process_triggers method."""

    @pytest.mark.asyncio
    async def test_process_triggers_executes_actions(
        self, engine, mock_db, sample_trigger, sample_event
    ):
        """Should execute actions for matching triggers."""
        event_id = uuid4()
        now = datetime.now(UTC)

        # Mock database response for trigger query
        mock_row = MagicMock()
        mock_row.id = sample_trigger.id
        mock_row.name = sample_trigger.name
        mock_row.trigger_type = "webhook"
        mock_row.source = "github"
        mock_row.conditions = [{"field": "action", "operator": "eq", "value": "opened"}]
        mock_row.action = {"type": "notification", "notification_channel": "slack"}
        mock_row.priority = "normal"
        mock_row.enabled = True
        mock_row.created_at = now
        mock_row.updated_at = now

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        task_ids = await engine.process_triggers(sample_event, event_id)

        # Should return task IDs (executor creates tasks)
        assert len(task_ids) == 1

    @pytest.mark.asyncio
    async def test_process_triggers_no_matches(self, engine, mock_db, sample_event):
        """Should return empty list when no triggers match."""
        event_id = uuid4()

        # Mock empty database response
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        task_ids = await engine.process_triggers(sample_event, event_id)

        assert task_ids == []

    @pytest.mark.asyncio
    async def test_process_triggers_updates_event_log(
        self, engine, mock_db, sample_trigger, sample_event
    ):
        """Should update event log with trigger and task IDs."""
        event_id = uuid4()
        now = datetime.now(UTC)

        mock_row = MagicMock()
        mock_row.id = sample_trigger.id
        mock_row.name = sample_trigger.name
        mock_row.trigger_type = "webhook"
        mock_row.source = "github"
        mock_row.conditions = [{"field": "action", "operator": "eq", "value": "opened"}]
        mock_row.action = {"type": "notification", "notification_channel": "slack"}
        mock_row.priority = "normal"
        mock_row.enabled = True
        mock_row.created_at = now
        mock_row.updated_at = now

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        await engine.process_triggers(sample_event, event_id)

        # Should have called execute multiple times:
        # 1. Query triggers
        # 2. Insert task
        # 3. Update event_log
        assert mock_db.execute.call_count >= 2

    @pytest.mark.asyncio
    async def test_process_triggers_continues_on_error(
        self, engine, mock_db, sample_event
    ):
        """Should continue processing other triggers if one fails."""
        event_id = uuid4()
        now = datetime.now(UTC)

        # Create two mock triggers
        mock_rows = []
        for i in range(2):
            row = MagicMock()
            row.id = uuid4()
            row.name = f"Trigger {i}"
            row.trigger_type = "webhook"
            row.source = "github"
            row.conditions = None  # Always match
            row.action = {"type": "notification", "notification_channel": "slack"}
            row.priority = "normal"
            row.enabled = True
            row.created_at = now
            row.updated_at = now
            mock_rows.append(row)

        mock_result = MagicMock()
        mock_result.fetchall.return_value = mock_rows

        # Make first insert fail, second succeed
        call_count = [0]

        async def side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 2:  # First task insert
                raise Exception("Database error")
            return mock_result

        mock_db.execute = AsyncMock(side_effect=side_effect)

        # Should not raise, should continue with second trigger
        task_ids = await engine.process_triggers(sample_event, event_id)

        # May have partial results depending on which calls succeeded
        assert isinstance(task_ids, list)


class TestQueryEnabledTriggers:
    """Tests for _query_enabled_triggers method."""

    @pytest.mark.asyncio
    async def test_query_filters_by_source(self, engine, mock_db):
        """Should filter triggers by source."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("github")

        # Check that execute was called with source parameter
        call_args = mock_db.execute.call_args
        assert "source" in str(call_args) or call_args[1].get("source") == "github"

    @pytest.mark.asyncio
    async def test_query_without_source(self, engine, mock_db):
        """Should query all triggers when no source specified."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers(None)

        # Should have been called
        assert mock_db.execute.called


class TestUpdateEventLogWithTrigger:
    """Tests for _update_event_log_with_trigger method."""

    @pytest.mark.asyncio
    async def test_update_event_log(self, engine, mock_db):
        """Should update event log entry."""
        event_id = uuid4()
        trigger_id = uuid4()
        task_id = uuid4()

        await engine._update_event_log_with_trigger(event_id, trigger_id, task_id)

        mock_db.execute.assert_called_once()
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_event_log_uses_jsonb_array(self, engine, mock_db):
        """Should use JSONB array append for triggered_tasks."""
        event_id = uuid4()
        trigger_id = uuid4()
        task_id = uuid4()

        await engine._update_event_log_with_trigger(event_id, trigger_id, task_id)

        # Check that query uses triggered_tasks JSONB append
        call_args = mock_db.execute.call_args
        query_text = str(call_args[0][0])
        assert "triggered_tasks" in query_text
        assert "COALESCE" in query_text
        assert "jsonb_build_object" in query_text


class TestPriorityOrdering:
    """Tests for priority ordering (CASE expression)."""

    @pytest.mark.asyncio
    async def test_query_uses_case_expression(self, engine, mock_db):
        """Should use CASE expression for priority ordering."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("github")

        # Check that query uses CASE expression
        call_args = mock_db.execute.call_args
        query_text = str(call_args[0][0])
        assert "CASE priority" in query_text
        assert "WHEN 'critical' THEN 1" in query_text
        assert "WHEN 'high' THEN 2" in query_text
        assert "WHEN 'normal' THEN 3" in query_text
        assert "WHEN 'low' THEN 4" in query_text


class TestTriggerTypeFiltering:
    """Tests for trigger type filtering by source."""

    @pytest.mark.asyncio
    async def test_github_source_uses_webhook_type(self, engine, mock_db):
        """Should filter to webhook type for github source."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("github")

        # Check query includes trigger_type filter
        call_args = mock_db.execute.call_args
        query_text = str(call_args[0][0])
        params = call_args[0][1]

        assert "trigger_type = ANY" in query_text
        assert params["allowed_types"] == ["webhook"]

    @pytest.mark.asyncio
    async def test_outlook_source_uses_email_calendar_types(self, engine, mock_db):
        """Should filter to email/calendar types for outlook source."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("outlook")

        call_args = mock_db.execute.call_args
        params = call_args[0][1]

        assert set(params["allowed_types"]) == {"email", "calendar"}

    @pytest.mark.asyncio
    async def test_slack_source_uses_slack_webhook_types(self, engine, mock_db):
        """Should filter to slack/webhook types for slack source."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("slack")

        call_args = mock_db.execute.call_args
        params = call_args[0][1]

        assert set(params["allowed_types"]) == {"slack", "webhook"}

    @pytest.mark.asyncio
    async def test_unknown_source_defaults_to_webhook(self, engine, mock_db):
        """Should default to webhook type for unknown source."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers("unknown_source")

        call_args = mock_db.execute.call_args
        params = call_args[0][1]

        assert params["allowed_types"] == ["webhook"]

    @pytest.mark.asyncio
    async def test_no_source_skips_type_filter(self, engine, mock_db):
        """Should not filter by type when no source specified."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        await engine._query_enabled_triggers(None)

        # Check query does NOT include trigger_type filter
        call_args = mock_db.execute.call_args
        query_text = str(call_args[0][0])

        assert "trigger_type = ANY" not in query_text


class TestMultipleTriggerMatches:
    """Tests for multiple triggers matching same event."""

    @pytest.mark.asyncio
    async def test_multiple_triggers_all_recorded(self, engine, mock_db, sample_event):
        """Should record all matching triggers in triggered_tasks."""
        event_id = uuid4()
        now = datetime.now(UTC)

        # Create two triggers that both match
        mock_rows = []
        for i in range(2):
            row = MagicMock()
            row.id = uuid4()
            row.name = f"Trigger {i}"
            row.trigger_type = "webhook"
            row.source = "github"
            row.conditions = None  # Always match
            row.action = {"type": "notification", "notification_channel": "slack"}
            row.priority = "normal"
            row.enabled = True
            row.created_at = now
            row.updated_at = now
            mock_rows.append(row)

        mock_result = MagicMock()
        mock_result.fetchall.return_value = mock_rows
        mock_db.execute.return_value = mock_result

        task_ids = await engine.process_triggers(sample_event, event_id)

        # Should have 2 tasks queued
        assert len(task_ids) == 2

        # Should have called _update_event_log_with_trigger for each trigger
        # (query triggers + 2x task insert + 2x update event_log = 5 calls)
        assert mock_db.execute.call_count >= 4
