"""Tests for EventProcessor."""

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.events.exceptions import EventProcessingError
from apps.api.events.models import EventSource, IncomingEvent, TaskPriority
from apps.api.events.processor import EventProcessor


@pytest.fixture
def mock_db():
    """Create mock database session."""
    db = AsyncMock()

    # Create mock result that returns empty list for trigger queries
    mock_result = MagicMock()
    mock_result.fetchall.return_value = []

    db.execute = AsyncMock(return_value=mock_result)
    db.commit = AsyncMock()
    return db


@pytest.fixture
def processor(mock_db):
    """Create EventProcessor with mock database."""
    return EventProcessor(db=mock_db)


class TestEventProcessorInit:
    """Tests for EventProcessor initialization."""

    def test_init(self, mock_db):
        """Should initialize with database session."""
        processor = EventProcessor(db=mock_db)
        assert processor._db == mock_db


class TestProcess:
    """Tests for process method."""

    @pytest.mark.asyncio
    async def test_process_event(self, processor, mock_db):
        """Should process incoming event."""
        event = IncomingEvent(
            event_type="push",
            source=EventSource.GITHUB,
            external_id="abc123",
            payload={"action": "opened"},
        )

        event_id = await processor.process(event)

        assert event_id is not None
        # Should log event, query triggers, and mark processed (3 queries)
        assert mock_db.execute.call_count == 3
        # Log event commit + mark processed commit = 2 commits
        assert mock_db.commit.call_count == 2

    @pytest.mark.asyncio
    async def test_process_minimal_event(self, processor, mock_db):
        """Should process event with minimal data."""
        event = IncomingEvent(
            event_type="test",
            source=EventSource.INTERNAL,
        )

        event_id = await processor.process(event)

        assert event_id is not None

    @pytest.mark.asyncio
    async def test_process_error_handling(self, processor, mock_db):
        """Should raise EventProcessingError on failure."""
        mock_db.execute.side_effect = Exception("Database error")

        event = IncomingEvent(
            event_type="test",
            source=EventSource.INTERNAL,
        )

        with pytest.raises(EventProcessingError):
            await processor.process(event)


class TestQueueTask:
    """Tests for queue_task method."""

    @pytest.mark.asyncio
    async def test_queue_task(self, processor, mock_db):
        """Should queue a task."""
        task_id = await processor.queue_task(
            task_type="agent_task",
            payload={"prompt": "Do something"},
            priority=TaskPriority.HIGH,
        )

        assert task_id is not None
        mock_db.execute.assert_called()
        mock_db.commit.assert_called()

    @pytest.mark.asyncio
    async def test_queue_task_with_trigger(self, processor, mock_db):
        """Should queue task with trigger reference."""
        trigger_id = uuid4()

        task_id = await processor.queue_task(
            task_type="notification",
            payload={},
            trigger_id=trigger_id,
        )

        assert task_id is not None

    @pytest.mark.asyncio
    async def test_queue_task_with_schedule(self, processor, mock_db):
        """Should queue task with schedule reference."""
        schedule_id = uuid4()

        task_id = await processor.queue_task(
            task_type="scheduled_task",
            payload={"data": "test"},
            schedule_id=schedule_id,
        )

        assert task_id is not None


class TestGetPendingTasks:
    """Tests for get_pending_tasks method."""

    @pytest.mark.asyncio
    async def test_get_pending_tasks(self, processor, mock_db):
        """Should get pending tasks."""
        # Mock database response
        mock_row = MagicMock()
        mock_row.id = uuid4()
        mock_row.trigger_id = None
        mock_row.schedule_id = None
        mock_row.task_type = "agent_task"
        mock_row.payload = {"prompt": "test"}
        mock_row.priority = "normal"
        mock_row.status = "pending"
        mock_row.attempts = 0
        mock_row.max_attempts = 3
        mock_row.created_at = MagicMock()
        mock_row.started_at = None
        mock_row.completed_at = None
        mock_row.error = None

        mock_result = MagicMock()
        mock_result.fetchall.return_value = [mock_row]
        mock_db.execute.return_value = mock_result

        tasks = await processor.get_pending_tasks(limit=10)

        assert len(tasks) == 1
        assert tasks[0].task_type == "agent_task"

    @pytest.mark.asyncio
    async def test_get_pending_tasks_empty(self, processor, mock_db):
        """Should handle no pending tasks."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute.return_value = mock_result

        tasks = await processor.get_pending_tasks()

        assert tasks == []


class TestMarkTaskRunning:
    """Tests for mark_task_running method."""

    @pytest.mark.asyncio
    async def test_mark_running(self, processor, mock_db):
        """Should mark task as running."""
        task_id = uuid4()

        await processor.mark_task_running(task_id)

        mock_db.execute.assert_called()
        mock_db.commit.assert_called()


class TestMarkTaskCompleted:
    """Tests for mark_task_completed method."""

    @pytest.mark.asyncio
    async def test_mark_completed(self, processor, mock_db):
        """Should mark task as completed."""
        task_id = uuid4()

        await processor.mark_task_completed(task_id)

        mock_db.execute.assert_called()
        mock_db.commit.assert_called()


class TestMarkTaskFailed:
    """Tests for mark_task_failed method."""

    @pytest.mark.asyncio
    async def test_mark_failed(self, processor, mock_db):
        """Should mark task as failed."""
        task_id = uuid4()

        await processor.mark_task_failed(task_id, "Something went wrong")

        mock_db.execute.assert_called()
        mock_db.commit.assert_called()
