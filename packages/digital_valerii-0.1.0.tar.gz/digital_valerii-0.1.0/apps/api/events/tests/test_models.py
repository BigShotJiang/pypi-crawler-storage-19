"""Tests for event system models."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from pydantic import ValidationError

from apps.api.events.models import (
    EventLogEntry,
    EventLogFilter,
    EventSource,
    EventTriggerCreate,
    EventTriggerUpdate,
    IncomingEvent,
    TaskPriority,
    TaskQueueItem,
    TaskStatus,
    TriggerAction,
    TriggerCondition,
    TriggerType,
)


class TestEnums:
    """Tests for event system enums."""

    def test_trigger_types(self):
        """Should have all expected trigger types."""
        assert TriggerType.WEBHOOK == "webhook"
        assert TriggerType.EMAIL == "email"
        assert TriggerType.SLACK == "slack"
        assert TriggerType.CALENDAR == "calendar"
        assert TriggerType.SCHEDULE == "schedule"

    def test_event_sources(self):
        """Should have all expected event sources."""
        assert EventSource.OUTLOOK == "outlook"
        assert EventSource.SERVICENOW == "servicenow"
        assert EventSource.SLACK == "slack"
        assert EventSource.GITHUB == "github"
        assert EventSource.CALENDAR == "calendar"
        assert EventSource.INTERNAL == "internal"

    def test_task_priorities(self):
        """Should have all priority levels."""
        assert TaskPriority.LOW == "low"
        assert TaskPriority.NORMAL == "normal"
        assert TaskPriority.HIGH == "high"
        assert TaskPriority.CRITICAL == "critical"

    def test_task_statuses(self):
        """Should have all status values."""
        assert TaskStatus.PENDING == "pending"
        assert TaskStatus.RUNNING == "running"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"


class TestTriggerCondition:
    """Tests for TriggerCondition model."""

    def test_valid_condition(self):
        """Should create valid condition."""
        condition = TriggerCondition(
            field="subject",
            operator="contains",
            value="urgent",
        )
        assert condition.field == "subject"
        assert condition.operator == "contains"
        assert condition.value == "urgent"

    def test_all_operators(self):
        """Should accept all valid operators."""
        for op in ["eq", "ne", "contains", "regex", "gt", "lt"]:
            condition = TriggerCondition(field="test", operator=op, value="val")
            assert condition.operator == op

    def test_invalid_operator(self):
        """Should reject invalid operator."""
        with pytest.raises(ValidationError):
            TriggerCondition(field="test", operator="invalid", value="val")

    def test_extra_field_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            TriggerCondition(field="test", operator="eq", value="val", extra="bad")


class TestTriggerAction:
    """Tests for TriggerAction model."""

    def test_agent_task_action(self):
        """Should create agent_task action."""
        action = TriggerAction(
            type="agent_task",
            prompt="Process this email",
        )
        assert action.type == "agent_task"
        assert action.prompt == "Process this email"

    def test_notification_action(self):
        """Should create notification action."""
        action = TriggerAction(
            type="notification",
            notification_channel="slack",
        )
        assert action.type == "notification"
        assert action.notification_channel == "slack"

    def test_webhook_action(self):
        """Should create webhook action."""
        action = TriggerAction(
            type="webhook",
            webhook_url="https://example.com/hook",
        )
        assert action.type == "webhook"
        assert action.webhook_url == "https://example.com/hook"

    def test_invalid_type(self):
        """Should reject invalid action type."""
        with pytest.raises(ValidationError):
            TriggerAction(type="invalid")

    def test_agent_task_missing_prompt(self):
        """Should reject agent_task without prompt."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="agent_task")
        assert "prompt is required" in str(exc_info.value)

    def test_agent_task_empty_prompt(self):
        """Should reject agent_task with empty prompt."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="agent_task", prompt="")
        assert "prompt is required" in str(exc_info.value)

    def test_notification_missing_channel(self):
        """Should reject notification without channel."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="notification")
        assert "notification_channel is required" in str(exc_info.value)

    def test_notification_empty_channel(self):
        """Should reject notification with empty channel."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="notification", notification_channel="")
        assert "notification_channel is required" in str(exc_info.value)

    def test_webhook_missing_url(self):
        """Should reject webhook without url."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="webhook")
        assert "webhook_url is required" in str(exc_info.value)

    def test_webhook_empty_url(self):
        """Should reject webhook with empty url."""
        with pytest.raises(ValidationError) as exc_info:
            TriggerAction(type="webhook", webhook_url="")
        assert "webhook_url is required" in str(exc_info.value)


class TestEventTriggerCreate:
    """Tests for EventTriggerCreate model."""

    def test_valid_trigger(self):
        """Should create valid trigger."""
        trigger = EventTriggerCreate(
            name="Urgent Email Handler",
            trigger_type=TriggerType.EMAIL,
            source=EventSource.OUTLOOK,
            conditions=[
                TriggerCondition(field="subject", operator="contains", value="urgent")
            ],
            action=TriggerAction(type="agent_task", prompt="Handle urgent email"),
        )
        assert trigger.name == "Urgent Email Handler"
        assert trigger.trigger_type == TriggerType.EMAIL
        assert trigger.enabled is True
        assert trigger.priority == TaskPriority.NORMAL

    def test_minimal_trigger(self):
        """Should create trigger with minimal fields."""
        trigger = EventTriggerCreate(
            name="Test",
            trigger_type=TriggerType.WEBHOOK,
            action=TriggerAction(type="notification", notification_channel="slack"),
        )
        assert trigger.source is None
        assert trigger.conditions is None

    def test_empty_name_rejected(self):
        """Should reject empty name."""
        with pytest.raises(ValidationError):
            EventTriggerCreate(
                name="",
                trigger_type=TriggerType.WEBHOOK,
                action=TriggerAction(type="notification", notification_channel="slack"),
            )

    def test_name_too_long(self):
        """Should reject name over 255 chars."""
        with pytest.raises(ValidationError):
            EventTriggerCreate(
                name="x" * 256,
                trigger_type=TriggerType.WEBHOOK,
                action=TriggerAction(type="notification", notification_channel="slack"),
            )


class TestEventTriggerUpdate:
    """Tests for EventTriggerUpdate model."""

    def test_partial_update(self):
        """Should allow partial updates."""
        update = EventTriggerUpdate(name="New Name")
        assert update.name == "New Name"
        assert update.trigger_type is None
        assert update.enabled is None

    def test_full_update(self):
        """Should allow full update."""
        update = EventTriggerUpdate(
            name="Updated",
            trigger_type=TriggerType.SCHEDULE,
            enabled=False,
            priority=TaskPriority.HIGH,
        )
        assert update.enabled is False


class TestIncomingEvent:
    """Tests for IncomingEvent model."""

    def test_valid_event(self):
        """Should create valid incoming event."""
        event = IncomingEvent(
            event_type="push",
            source=EventSource.GITHUB,
            external_id="12345",
            payload={"repository": {"name": "test"}},
        )
        assert event.event_type == "push"
        assert event.source == EventSource.GITHUB
        assert event.external_id == "12345"

    def test_minimal_event(self):
        """Should create event with minimal fields."""
        event = IncomingEvent(
            event_type="test",
            source=EventSource.INTERNAL,
        )
        assert event.external_id is None
        assert event.payload == {}

    def test_extra_field_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            IncomingEvent(
                event_type="test",
                source=EventSource.INTERNAL,
                extra="bad",
            )


class TestTaskQueueItem:
    """Tests for TaskQueueItem model."""

    def test_valid_task(self):
        """Should create valid task item."""
        task = TaskQueueItem(
            id=uuid4(),
            trigger_id=uuid4(),
            task_type="agent_task",
            payload={"prompt": "Do something"},
            priority=TaskPriority.HIGH,
            status=TaskStatus.PENDING,
            attempts=0,
            max_attempts=3,
            created_at=datetime.now(UTC),
            started_at=None,
            completed_at=None,
            error=None,
        )
        assert task.status == TaskStatus.PENDING
        assert task.attempts == 0

    def test_completed_task(self):
        """Should represent completed task."""
        now = datetime.now(UTC)
        task = TaskQueueItem(
            id=uuid4(),
            trigger_id=None,
            task_type="notification",
            payload={},
            priority=TaskPriority.NORMAL,
            status=TaskStatus.COMPLETED,
            attempts=1,
            max_attempts=3,
            created_at=now,
            started_at=now,
            completed_at=now,
            error=None,
        )
        assert task.status == TaskStatus.COMPLETED


class TestEventLogEntry:
    """Tests for EventLogEntry model."""

    def test_valid_entry(self):
        """Should create valid log entry."""
        entry = EventLogEntry(
            id=uuid4(),
            event_type="push",
            source=EventSource.GITHUB,
            external_id="abc123",
            payload={"action": "opened"},
            trigger_id=uuid4(),
            task_id=uuid4(),
            processed=True,
            created_at=datetime.now(UTC),
        )
        assert entry.processed is True

    def test_unprocessed_entry(self):
        """Should represent unprocessed entry."""
        entry = EventLogEntry(
            id=uuid4(),
            event_type="webhook",
            source=EventSource.SERVICENOW,
            external_id=None,
            payload=None,
            trigger_id=None,
            task_id=None,
            processed=False,
            created_at=datetime.now(UTC),
        )
        assert entry.processed is False

    def test_entry_with_triggered_tasks(self):
        """Should support multiple triggered tasks."""
        trigger1_id = str(uuid4())
        trigger2_id = str(uuid4())
        task1_id = str(uuid4())
        task2_id = str(uuid4())

        entry = EventLogEntry(
            id=uuid4(),
            event_type="push",
            source=EventSource.GITHUB,
            external_id="abc123",
            payload={"action": "opened"},
            trigger_id=None,
            task_id=None,
            triggered_tasks=[
                {"trigger_id": trigger1_id, "task_id": task1_id},
                {"trigger_id": trigger2_id, "task_id": task2_id},
            ],
            processed=True,
            created_at=datetime.now(UTC),
        )
        assert len(entry.triggered_tasks) == 2
        assert entry.triggered_tasks[0]["trigger_id"] == trigger1_id
        assert entry.triggered_tasks[1]["trigger_id"] == trigger2_id


class TestEventLogFilter:
    """Tests for EventLogFilter model."""

    def test_default_filter(self):
        """Should have default values."""
        filter_params = EventLogFilter()
        assert filter_params.source is None
        assert filter_params.limit == 50
        assert filter_params.offset == 0

    def test_custom_filter(self):
        """Should accept custom values."""
        filter_params = EventLogFilter(
            source=EventSource.GITHUB,
            event_type="push",
            processed=True,
            limit=10,
            offset=20,
        )
        assert filter_params.source == EventSource.GITHUB
        assert filter_params.limit == 10

    def test_limit_bounds(self):
        """Should enforce limit bounds."""
        with pytest.raises(ValidationError):
            EventLogFilter(limit=0)
        with pytest.raises(ValidationError):
            EventLogFilter(limit=101)
