"""Tests for event webhook routes."""

import hashlib
import hmac
from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from apps.api.events.models import EventSource


@pytest.fixture
def mock_processor():
    """Create mock EventProcessor."""
    processor = AsyncMock()
    processor.process = AsyncMock(return_value=uuid4())
    return processor


@pytest.fixture
def mock_service():
    """Create mock EventService."""
    service = AsyncMock()
    return service


class TestGenericWebhook:
    """Tests for generic webhook endpoint."""

    @pytest.mark.asyncio
    async def test_generic_webhook_success(self, mock_processor):
        """Should process generic webhook with valid API key."""
        from apps.api.events.routes import generic_webhook

        mock_request = AsyncMock()
        mock_request.json = AsyncMock(return_value={"data": "test"})

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.events_api_key = "test-api-key"

            result = await generic_webhook(
                source=EventSource.GITHUB,
                request=mock_request,
                processor=mock_processor,
                x_api_key="test-api-key",
            )

            assert result["status"] == "accepted"
            assert "event_id" in result
            mock_processor.process.assert_called_once()

    @pytest.mark.asyncio
    async def test_generic_webhook_rejects_internal_source(self, mock_processor):
        """Should reject INTERNAL source with 400."""
        from fastapi import HTTPException

        from apps.api.events.routes import generic_webhook

        mock_request = AsyncMock()

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.events_api_key = "test-api-key"

            with pytest.raises(HTTPException) as exc_info:
                await generic_webhook(
                    source=EventSource.INTERNAL,
                    request=mock_request,
                    processor=mock_processor,
                    x_api_key="test-api-key",
                )

            assert exc_info.value.status_code == 400
            assert "not allowed" in exc_info.value.detail

    @pytest.mark.asyncio
    async def test_generic_webhook_503_when_not_configured(self, mock_processor):
        """Should return 503 when API key not configured."""
        from fastapi import HTTPException

        from apps.api.events.routes import generic_webhook

        mock_request = AsyncMock()

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.events_api_key = ""

            with pytest.raises(HTTPException) as exc_info:
                await generic_webhook(
                    source=EventSource.GITHUB,
                    request=mock_request,
                    processor=mock_processor,
                    x_api_key="some-key",
                )

            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    async def test_generic_webhook_rejects_missing_api_key(self, mock_processor):
        """Should reject missing API key with 401."""
        from fastapi import HTTPException

        from apps.api.events.routes import generic_webhook

        mock_request = AsyncMock()

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.events_api_key = "test-api-key"

            with pytest.raises(HTTPException) as exc_info:
                await generic_webhook(
                    source=EventSource.GITHUB,
                    request=mock_request,
                    processor=mock_processor,
                    x_api_key=None,
                )

            assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_generic_webhook_rejects_invalid_api_key(self, mock_processor):
        """Should reject invalid API key with 401."""
        from fastapi import HTTPException

        from apps.api.events.routes import generic_webhook

        mock_request = AsyncMock()

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.events_api_key = "correct-key"

            with pytest.raises(HTTPException) as exc_info:
                await generic_webhook(
                    source=EventSource.GITHUB,
                    request=mock_request,
                    processor=mock_processor,
                    x_api_key="wrong-key",
                )

            assert exc_info.value.status_code == 401


class TestOutlookWebhook:
    """Tests for Outlook webhook endpoint."""

    @pytest.mark.asyncio
    async def test_outlook_validation(self, mock_processor):
        """Should handle validation token."""
        from apps.api.events.routes import outlook_webhook

        mock_request = AsyncMock()
        mock_request.query_params = {"validationToken": "test-token-12345"}

        result = await outlook_webhook(
            request=mock_request,
            processor=mock_processor,
        )

        # Should return plain text response
        assert result.body == b"test-token-12345"
        mock_processor.process.assert_not_called()

    @pytest.mark.asyncio
    async def test_outlook_notification(self, mock_processor):
        """Should process Outlook notification."""
        from apps.api.events.routes import outlook_webhook

        mock_request = AsyncMock()
        mock_request.query_params = {}
        mock_request.json = AsyncMock(
            return_value={
                "value": [
                    {
                        "changeType": "created",
                        "resourceData": {"id": "msg-123"},
                    }
                ]
            }
        )

        result = await outlook_webhook(
            request=mock_request,
            processor=mock_processor,
        )

        assert result["status"] == "accepted"
        mock_processor.process.assert_called_once()

    @pytest.mark.asyncio
    async def test_outlook_multiple_notifications(self, mock_processor):
        """Should process multiple notifications."""
        from apps.api.events.routes import outlook_webhook

        mock_request = AsyncMock()
        mock_request.query_params = {}
        mock_request.json = AsyncMock(
            return_value={
                "value": [
                    {"changeType": "created", "resourceData": {"id": "1"}},
                    {"changeType": "updated", "resourceData": {"id": "2"}},
                ]
            }
        )

        await outlook_webhook(
            request=mock_request,
            processor=mock_processor,
        )

        assert mock_processor.process.call_count == 2

    @pytest.mark.asyncio
    async def test_outlook_rejects_missing_client_state_when_configured(
        self, mock_processor
    ):
        """Should reject missing client state header when configured."""
        from fastapi import HTTPException

        from apps.api.events.routes import outlook_webhook

        mock_request = AsyncMock()
        mock_request.query_params = {}
        mock_request.json = AsyncMock(return_value={"value": []})

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.microsoft_webhook_client_state = "configured-secret"

            with pytest.raises(HTTPException) as exc_info:
                await outlook_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_client_state=None,
                )

            assert exc_info.value.status_code == 401
            assert "Missing client state" in exc_info.value.detail

    @pytest.mark.asyncio
    async def test_outlook_rejects_invalid_client_state(self, mock_processor):
        """Should reject invalid client state with 401."""
        from fastapi import HTTPException

        from apps.api.events.routes import outlook_webhook

        mock_request = AsyncMock()
        mock_request.query_params = {}
        mock_request.json = AsyncMock(return_value={"value": []})

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.microsoft_webhook_client_state = "correct-secret"

            with pytest.raises(HTTPException) as exc_info:
                await outlook_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_client_state="wrong-secret",
                )

            assert exc_info.value.status_code == 401


class TestGitHubWebhook:
    """Tests for GitHub webhook endpoint."""

    @pytest.mark.asyncio
    async def test_github_webhook_503_when_not_configured(self, mock_processor):
        """Should return 503 when secret not configured (fail closed)."""
        from fastapi import HTTPException

        from apps.api.events.routes import github_webhook

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=b'{"action": "opened"}')

        # Patch settings to have no secret
        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.github_webhook_secret = ""

            with pytest.raises(HTTPException) as exc_info:
                await github_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_hub_signature_256=None,
                    x_github_event="push",
                )

            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    async def test_github_webhook_with_signature(self, mock_processor):
        """Should verify signature when secret is configured."""
        from apps.api.events.routes import github_webhook

        body = b'{"action": "opened"}'
        secret = "test-secret"
        signature = (
            "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        )

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=body)
        mock_request.json = AsyncMock(return_value={"action": "opened"})

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.github_webhook_secret = secret

            result = await github_webhook(
                request=mock_request,
                processor=mock_processor,
                x_hub_signature_256=signature,
                x_github_event="push",
            )

            assert result["status"] == "accepted"

    @pytest.mark.asyncio
    async def test_github_webhook_invalid_signature(self, mock_processor):
        """Should reject invalid signature."""
        from fastapi import HTTPException

        from apps.api.events.routes import github_webhook

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=b'{"action": "opened"}')

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.github_webhook_secret = "secret"

            with pytest.raises(HTTPException) as exc_info:
                await github_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_hub_signature_256="sha256=invalid",
                    x_github_event="push",
                )

            assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_github_webhook_missing_signature(self, mock_processor):
        """Should reject missing signature when secret configured."""
        from fastapi import HTTPException

        from apps.api.events.routes import github_webhook

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=b"{}")

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.github_webhook_secret = "secret"

            with pytest.raises(HTTPException) as exc_info:
                await github_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_hub_signature_256=None,
                    x_github_event="push",
                )

            assert exc_info.value.status_code == 401


class TestServiceNowWebhook:
    """Tests for ServiceNow webhook endpoint."""

    @pytest.mark.asyncio
    async def test_servicenow_incident_with_signature(self, mock_processor):
        """Should process ServiceNow incident webhook with valid signature."""
        from apps.api.events.routes import servicenow_webhook

        body = b'{"current": {"number": "INC0012345", "state": "new", "short_description": "Server down"}}'
        secret = "test-secret"
        signature = (
            "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        )

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=body)
        mock_request.json = AsyncMock(
            return_value={
                "current": {
                    "number": "INC0012345",
                    "state": "new",
                    "short_description": "Server down",
                }
            }
        )

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.servicenow_webhook_secret = secret

            result = await servicenow_webhook(
                request=mock_request,
                processor=mock_processor,
                x_servicenow_signature=signature,
            )

            assert result["status"] == "accepted"

            # Verify event was processed with correct type
            call_args = mock_processor.process.call_args[0][0]
            assert call_args.event_type == "incident_new"
            assert call_args.source == EventSource.SERVICENOW
            assert call_args.external_id == "INC0012345"

    @pytest.mark.asyncio
    async def test_servicenow_503_when_not_configured(self, mock_processor):
        """Should return 503 when secret not configured (fail closed)."""
        from fastapi import HTTPException

        from apps.api.events.routes import servicenow_webhook

        mock_request = AsyncMock()

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.servicenow_webhook_secret = ""

            with pytest.raises(HTTPException) as exc_info:
                await servicenow_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_servicenow_signature=None,
                )

            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    async def test_servicenow_rejects_missing_signature(self, mock_processor):
        """Should reject missing signature with 401."""
        from fastapi import HTTPException

        from apps.api.events.routes import servicenow_webhook

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=b"{}")

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.servicenow_webhook_secret = "secret"

            with pytest.raises(HTTPException) as exc_info:
                await servicenow_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_servicenow_signature=None,
                )

            assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_servicenow_rejects_invalid_signature(self, mock_processor):
        """Should reject invalid signature with 401."""
        from fastapi import HTTPException

        from apps.api.events.routes import servicenow_webhook

        mock_request = AsyncMock()
        mock_request.body = AsyncMock(return_value=b'{"data": "test"}')

        with patch("apps.api.events.routes.settings") as mock_settings:
            mock_settings.servicenow_webhook_secret = "secret"

            with pytest.raises(HTTPException) as exc_info:
                await servicenow_webhook(
                    request=mock_request,
                    processor=mock_processor,
                    x_servicenow_signature="sha256=invalid",
                )

            assert exc_info.value.status_code == 401
