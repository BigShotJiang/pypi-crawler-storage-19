"""Tests for ConditionEvaluator."""

import pytest

from apps.api.events.evaluator import ConditionEvaluator
from apps.api.events.models import TriggerCondition


@pytest.fixture
def evaluator():
    """Create ConditionEvaluator instance."""
    return ConditionEvaluator()


class TestEqOperator:
    """Tests for eq (equal) operator."""

    def test_eq_string_match(self, evaluator):
        """Should match equal strings."""
        condition = TriggerCondition(field="status", operator="eq", value="new")
        payload = {"status": "new"}
        assert evaluator.evaluate(condition, payload) is True

    def test_eq_string_no_match(self, evaluator):
        """Should not match different strings."""
        condition = TriggerCondition(field="status", operator="eq", value="new")
        payload = {"status": "closed"}
        assert evaluator.evaluate(condition, payload) is False

    def test_eq_number_match(self, evaluator):
        """Should match equal numbers."""
        condition = TriggerCondition(field="count", operator="eq", value=5)
        payload = {"count": 5}
        assert evaluator.evaluate(condition, payload) is True

    def test_eq_number_no_match(self, evaluator):
        """Should not match different numbers."""
        condition = TriggerCondition(field="count", operator="eq", value=5)
        payload = {"count": 10}
        assert evaluator.evaluate(condition, payload) is False

    def test_eq_boolean_match(self, evaluator):
        """Should match equal booleans."""
        condition = TriggerCondition(field="active", operator="eq", value=True)
        payload = {"active": True}
        assert evaluator.evaluate(condition, payload) is True

    def test_eq_boolean_no_match(self, evaluator):
        """Should not match different booleans."""
        condition = TriggerCondition(field="active", operator="eq", value=True)
        payload = {"active": False}
        assert evaluator.evaluate(condition, payload) is False


class TestNeOperator:
    """Tests for ne (not equal) operator."""

    def test_ne_match(self, evaluator):
        """Should match when values are different."""
        condition = TriggerCondition(field="status", operator="ne", value="closed")
        payload = {"status": "open"}
        assert evaluator.evaluate(condition, payload) is True

    def test_ne_no_match(self, evaluator):
        """Should not match when values are equal."""
        condition = TriggerCondition(field="status", operator="ne", value="closed")
        payload = {"status": "closed"}
        assert evaluator.evaluate(condition, payload) is False


class TestContainsOperator:
    """Tests for contains operator."""

    def test_contains_string(self, evaluator):
        """Should find substring in string."""
        condition = TriggerCondition(
            field="subject", operator="contains", value="urgent"
        )
        payload = {"subject": "This is an urgent message"}
        assert evaluator.evaluate(condition, payload) is True

    def test_contains_string_no_match(self, evaluator):
        """Should not find missing substring."""
        condition = TriggerCondition(
            field="subject", operator="contains", value="urgent"
        )
        payload = {"subject": "This is a regular message"}
        assert evaluator.evaluate(condition, payload) is False

    def test_contains_list(self, evaluator):
        """Should find element in list."""
        condition = TriggerCondition(
            field="tags", operator="contains", value="important"
        )
        payload = {"tags": ["important", "review"]}
        assert evaluator.evaluate(condition, payload) is True

    def test_contains_list_no_match(self, evaluator):
        """Should not find missing element in list."""
        condition = TriggerCondition(field="tags", operator="contains", value="urgent")
        payload = {"tags": ["important", "review"]}
        assert evaluator.evaluate(condition, payload) is False

    def test_contains_none_value(self, evaluator):
        """Should return False when field is None."""
        condition = TriggerCondition(
            field="subject", operator="contains", value="urgent"
        )
        payload = {"subject": None}
        assert evaluator.evaluate(condition, payload) is False

    def test_contains_case_sensitive(self, evaluator):
        """Should be case sensitive."""
        condition = TriggerCondition(
            field="subject", operator="contains", value="Urgent"
        )
        payload = {"subject": "This is an urgent message"}
        assert evaluator.evaluate(condition, payload) is False


class TestRegexOperator:
    """Tests for regex operator."""

    def test_regex_match(self, evaluator):
        """Should match regex pattern."""
        condition = TriggerCondition(
            field="email", operator="regex", value=r"@company\.com$"
        )
        payload = {"email": "user@company.com"}
        assert evaluator.evaluate(condition, payload) is True

    def test_regex_no_match(self, evaluator):
        """Should not match non-matching pattern."""
        condition = TriggerCondition(
            field="email", operator="regex", value=r"@company\.com$"
        )
        payload = {"email": "user@other.com"}
        assert evaluator.evaluate(condition, payload) is False

    def test_regex_invalid_pattern(self, evaluator):
        """Should return False for invalid regex, not crash."""
        condition = TriggerCondition(
            field="text",
            operator="regex",
            value="[invalid",  # Invalid regex
        )
        payload = {"text": "some text"}
        # Should return False, not raise exception
        assert evaluator.evaluate(condition, payload) is False

    def test_regex_none_value(self, evaluator):
        """Should return False when field is None."""
        condition = TriggerCondition(
            field="email", operator="regex", value=r"@company\.com$"
        )
        payload = {"email": None}
        assert evaluator.evaluate(condition, payload) is False

    def test_regex_partial_match(self, evaluator):
        """Should match partial pattern (search, not fullmatch)."""
        condition = TriggerCondition(field="message", operator="regex", value=r"error")
        payload = {"message": "An error occurred in the system"}
        assert evaluator.evaluate(condition, payload) is True


class TestGtOperator:
    """Tests for gt (greater than) operator."""

    def test_gt_match(self, evaluator):
        """Should match when actual > expected."""
        condition = TriggerCondition(field="priority", operator="gt", value=3)
        payload = {"priority": 5}
        assert evaluator.evaluate(condition, payload) is True

    def test_gt_no_match(self, evaluator):
        """Should not match when actual <= expected."""
        condition = TriggerCondition(field="priority", operator="gt", value=5)
        payload = {"priority": 5}
        assert evaluator.evaluate(condition, payload) is False

    def test_gt_float(self, evaluator):
        """Should work with floats."""
        condition = TriggerCondition(field="score", operator="gt", value=3.5)
        payload = {"score": 4.0}
        assert evaluator.evaluate(condition, payload) is True

    def test_gt_type_mismatch(self, evaluator):
        """Should return False for non-numeric comparison."""
        condition = TriggerCondition(field="name", operator="gt", value=5)
        payload = {"name": "not a number"}
        assert evaluator.evaluate(condition, payload) is False


class TestLtOperator:
    """Tests for lt (less than) operator."""

    def test_lt_match(self, evaluator):
        """Should match when actual < expected."""
        condition = TriggerCondition(field="count", operator="lt", value=10)
        payload = {"count": 5}
        assert evaluator.evaluate(condition, payload) is True

    def test_lt_no_match(self, evaluator):
        """Should not match when actual >= expected."""
        condition = TriggerCondition(field="count", operator="lt", value=5)
        payload = {"count": 5}
        assert evaluator.evaluate(condition, payload) is False

    def test_lt_float(self, evaluator):
        """Should work with floats."""
        condition = TriggerCondition(field="temperature", operator="lt", value=37.5)
        payload = {"temperature": 36.8}
        assert evaluator.evaluate(condition, payload) is True


class TestNestedFieldAccess:
    """Tests for nested field access using dot notation."""

    def test_nested_field_single_level(self, evaluator):
        """Should access single-level nested field."""
        condition = TriggerCondition(field="user.name", operator="eq", value="Alice")
        payload = {"user": {"name": "Alice"}}
        assert evaluator.evaluate(condition, payload) is True

    def test_nested_field_multi_level(self, evaluator):
        """Should access multi-level nested field."""
        condition = TriggerCondition(
            field="pull_request.head.ref", operator="eq", value="main"
        )
        payload = {"pull_request": {"head": {"ref": "main"}}}
        assert evaluator.evaluate(condition, payload) is True

    def test_nested_field_not_found(self, evaluator):
        """Should return None for missing nested field."""
        condition = TriggerCondition(
            field="user.address.city", operator="eq", value="NYC"
        )
        payload = {"user": {"name": "Alice"}}
        # None != "NYC", so should return False
        assert evaluator.evaluate(condition, payload) is False

    def test_nested_field_intermediate_not_dict(self, evaluator):
        """Should handle non-dict intermediate values."""
        condition = TriggerCondition(
            field="user.name.first", operator="eq", value="Alice"
        )
        payload = {"user": {"name": "Alice"}}  # name is string, not dict
        assert evaluator.evaluate(condition, payload) is False


class TestEvaluateAll:
    """Tests for evaluate_all method."""

    def test_evaluate_all_empty_conditions(self, evaluator):
        """Should return True for empty conditions."""
        result = evaluator.evaluate_all(None, {"data": "test"})
        assert result is True

    def test_evaluate_all_empty_list(self, evaluator):
        """Should return True for empty conditions list."""
        result = evaluator.evaluate_all([], {"data": "test"})
        assert result is True

    def test_evaluate_all_single_condition(self, evaluator):
        """Should evaluate single condition."""
        conditions = [TriggerCondition(field="status", operator="eq", value="open")]
        result = evaluator.evaluate_all(conditions, {"status": "open"})
        assert result is True

    def test_evaluate_all_multiple_conditions_all_pass(self, evaluator):
        """Should return True when all conditions pass."""
        conditions = [
            TriggerCondition(field="status", operator="eq", value="open"),
            TriggerCondition(field="priority", operator="gt", value=3),
            TriggerCondition(field="tags", operator="contains", value="urgent"),
        ]
        payload = {"status": "open", "priority": 5, "tags": ["urgent", "review"]}
        result = evaluator.evaluate_all(conditions, payload)
        assert result is True

    def test_evaluate_all_multiple_conditions_one_fails(self, evaluator):
        """Should return False when any condition fails."""
        conditions = [
            TriggerCondition(field="status", operator="eq", value="open"),
            TriggerCondition(field="priority", operator="gt", value=10),  # Fails
        ]
        payload = {"status": "open", "priority": 5}
        result = evaluator.evaluate_all(conditions, payload)
        assert result is False


class TestEdgeCases:
    """Tests for edge cases."""

    def test_type_mismatch_returns_false(self, evaluator):
        """Should return False for type mismatches, not crash."""
        condition = TriggerCondition(field="count", operator="gt", value="not a number")
        payload = {"count": 5}
        assert evaluator.evaluate(condition, payload) is False

    def test_null_value_handling(self, evaluator):
        """Should handle null values gracefully."""
        condition = TriggerCondition(field="status", operator="eq", value="open")
        payload = {"status": None}
        assert evaluator.evaluate(condition, payload) is False

    def test_missing_field(self, evaluator):
        """Should handle missing fields."""
        condition = TriggerCondition(field="nonexistent", operator="eq", value="test")
        payload = {"other": "value"}
        assert evaluator.evaluate(condition, payload) is False

    def test_empty_payload(self, evaluator):
        """Should handle empty payload."""
        condition = TriggerCondition(field="status", operator="eq", value="open")
        payload = {}
        assert evaluator.evaluate(condition, payload) is False

    def test_unknown_operator(self, evaluator):
        """Should return False for unknown operator."""
        # This would normally be caught by Pydantic validation
        # but test the evaluator's handling directly
        result = evaluator._compare("test", "unknown", "test")
        assert result is False
