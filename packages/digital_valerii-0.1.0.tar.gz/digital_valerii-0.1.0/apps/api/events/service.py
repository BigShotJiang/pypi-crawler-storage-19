"""Event service for CRUD operations."""

import json
from datetime import UTC, datetime
from uuid import UUID, uuid4

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.events.exceptions import TriggerNotFoundError
from apps.api.events.models import (
    EventLogEntry,
    EventLogFilter,
    EventSource,
    EventTriggerCreate,
    EventTriggerResponse,
    EventTriggerUpdate,
    TaskPriority,
    TriggerAction,
    TriggerCondition,
    TriggerType,
)

logger = structlog.get_logger(__name__)


class EventService:
    """Service for event CRUD operations."""

    def __init__(self, db: AsyncSession) -> None:
        """Initialize event service.

        Args:
            db: Database session.
        """
        self._db = db

    # =========================================================================
    # Trigger CRUD
    # =========================================================================

    async def create_trigger(self, trigger: EventTriggerCreate) -> EventTriggerResponse:
        """Create a new event trigger.

        Args:
            trigger: Trigger creation data.

        Returns:
            Created trigger.
        """
        trigger_id = uuid4()
        now = datetime.now(UTC)

        conditions_json = (
            json.dumps([c.model_dump() for c in trigger.conditions])
            if trigger.conditions
            else None
        )

        query = text("""
            INSERT INTO event_triggers (
                id, name, trigger_type, source, conditions, action,
                priority, enabled, created_at, updated_at
            )
            VALUES (
                :id, :name, :trigger_type, :source, :conditions::jsonb, :action::jsonb,
                :priority, :enabled, :created_at, :updated_at
            )
        """)

        await self._db.execute(
            query,
            {
                "id": trigger_id,
                "name": trigger.name,
                "trigger_type": trigger.trigger_type.value,
                "source": trigger.source.value if trigger.source else None,
                "conditions": conditions_json,
                "action": json.dumps(trigger.action.model_dump()),
                "priority": trigger.priority.value,
                "enabled": trigger.enabled,
                "created_at": now,
                "updated_at": now,
            },
        )
        await self._db.commit()

        await logger.ainfo(
            "Trigger created",
            trigger_id=str(trigger_id),
            name=trigger.name,
        )

        return EventTriggerResponse(
            id=trigger_id,
            name=trigger.name,
            trigger_type=trigger.trigger_type,
            source=trigger.source,
            conditions=trigger.conditions,
            action=trigger.action,
            priority=trigger.priority,
            enabled=trigger.enabled,
            created_at=now,
            updated_at=now,
        )

    async def get_trigger(self, trigger_id: UUID) -> EventTriggerResponse:
        """Get a trigger by ID.

        Args:
            trigger_id: Trigger ID.

        Returns:
            Trigger response.

        Raises:
            TriggerNotFoundError: If trigger not found.
        """
        query = text("""
            SELECT id, name, trigger_type, source, conditions, action,
                   priority, enabled, created_at, updated_at
            FROM event_triggers
            WHERE id = :id AND deleted_at IS NULL
        """)
        result = await self._db.execute(query, {"id": trigger_id})
        row = result.fetchone()

        if not row:
            raise TriggerNotFoundError(trigger_id)

        return self._row_to_trigger_response(row)

    async def list_triggers(
        self,
        trigger_type: TriggerType | None = None,
        source: EventSource | None = None,
        enabled: bool | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[EventTriggerResponse]:
        """List triggers with optional filters.

        Args:
            trigger_type: Filter by trigger type.
            source: Filter by source.
            enabled: Filter by enabled status.
            limit: Maximum results.
            offset: Skip results.

        Returns:
            List of triggers.
        """
        conditions = ["deleted_at IS NULL"]
        params: dict = {"limit": limit, "offset": offset}

        if trigger_type:
            conditions.append("trigger_type = :trigger_type")
            params["trigger_type"] = trigger_type.value

        if source:
            conditions.append("source = :source")
            params["source"] = source.value

        if enabled is not None:
            conditions.append("enabled = :enabled")
            params["enabled"] = enabled

        where_clause = " AND ".join(conditions)

        query = text(f"""
            SELECT id, name, trigger_type, source, conditions, action,
                   priority, enabled, created_at, updated_at
            FROM event_triggers
            WHERE {where_clause}
            ORDER BY created_at DESC
            LIMIT :limit OFFSET :offset
        """)

        result = await self._db.execute(query, params)
        return [self._row_to_trigger_response(row) for row in result.fetchall()]

    async def update_trigger(
        self,
        trigger_id: UUID,
        update: EventTriggerUpdate,
    ) -> EventTriggerResponse:
        """Update a trigger.

        Args:
            trigger_id: Trigger ID.
            update: Update data.

        Returns:
            Updated trigger.

        Raises:
            TriggerNotFoundError: If trigger not found.
        """
        # Verify exists
        await self.get_trigger(trigger_id)

        updates = []
        params: dict = {"id": trigger_id, "updated_at": datetime.now(UTC)}

        if update.name is not None:
            updates.append("name = :name")
            params["name"] = update.name

        if update.trigger_type is not None:
            updates.append("trigger_type = :trigger_type")
            params["trigger_type"] = update.trigger_type.value

        if update.source is not None:
            updates.append("source = :source")
            params["source"] = update.source.value

        if update.conditions is not None:
            updates.append("conditions = :conditions::jsonb")
            params["conditions"] = json.dumps(
                [c.model_dump() for c in update.conditions]
            )

        if update.action is not None:
            updates.append("action = :action::jsonb")
            params["action"] = json.dumps(update.action.model_dump())

        if update.priority is not None:
            updates.append("priority = :priority")
            params["priority"] = update.priority.value

        if update.enabled is not None:
            updates.append("enabled = :enabled")
            params["enabled"] = update.enabled

        updates.append("updated_at = :updated_at")

        if updates:
            set_clause = ", ".join(updates)
            query = text(f"""
                UPDATE event_triggers
                SET {set_clause}
                WHERE id = :id
            """)
            await self._db.execute(query, params)
            await self._db.commit()

        return await self.get_trigger(trigger_id)

    async def delete_trigger(self, trigger_id: UUID) -> None:
        """Soft delete a trigger.

        Args:
            trigger_id: Trigger ID.

        Raises:
            TriggerNotFoundError: If trigger not found.
        """
        # Verify exists
        await self.get_trigger(trigger_id)

        query = text("""
            UPDATE event_triggers
            SET deleted_at = :now
            WHERE id = :id
        """)
        await self._db.execute(
            query,
            {"id": trigger_id, "now": datetime.now(UTC)},
        )
        await self._db.commit()

        await logger.ainfo("Trigger deleted", trigger_id=str(trigger_id))

    # =========================================================================
    # Event Log
    # =========================================================================

    async def get_event_log(self, filter_params: EventLogFilter) -> list[EventLogEntry]:
        """Get event log entries with filters.

        Args:
            filter_params: Filter parameters.

        Returns:
            List of event log entries.
        """
        conditions = ["1=1"]
        params: dict = {"limit": filter_params.limit, "offset": filter_params.offset}

        if filter_params.source:
            conditions.append("source = :source")
            params["source"] = filter_params.source.value

        if filter_params.event_type:
            conditions.append("event_type = :event_type")
            params["event_type"] = filter_params.event_type

        if filter_params.processed is not None:
            conditions.append("processed = :processed")
            params["processed"] = filter_params.processed

        where_clause = " AND ".join(conditions)

        query = text(f"""
            SELECT id, event_type, source, external_id, payload,
                   trigger_id, task_id, processed, created_at
            FROM event_log
            WHERE {where_clause}
            ORDER BY created_at DESC
            LIMIT :limit OFFSET :offset
        """)

        result = await self._db.execute(query, params)
        entries = []
        for row in result.fetchall():
            entries.append(
                EventLogEntry(
                    id=row.id,
                    event_type=row.event_type,
                    source=EventSource(row.source),
                    external_id=row.external_id,
                    payload=row.payload if isinstance(row.payload, dict) else {},
                    trigger_id=row.trigger_id,
                    task_id=row.task_id,
                    processed=row.processed,
                    created_at=row.created_at,
                )
            )
        return entries

    # =========================================================================
    # Helpers
    # =========================================================================

    def _row_to_trigger_response(self, row) -> EventTriggerResponse:
        """Convert database row to response model."""
        conditions = None
        if row.conditions:
            conditions_data = row.conditions if isinstance(row.conditions, list) else []
            conditions = [TriggerCondition(**c) for c in conditions_data]

        action_data = row.action if isinstance(row.action, dict) else {}

        return EventTriggerResponse(
            id=row.id,
            name=row.name,
            trigger_type=TriggerType(row.trigger_type),
            source=EventSource(row.source) if row.source else None,
            conditions=conditions,
            action=TriggerAction(**action_data),
            priority=TaskPriority(row.priority),
            enabled=row.enabled,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )
