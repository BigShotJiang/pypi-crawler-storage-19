"""Condition evaluator for trigger matching."""

import re
from typing import Any

import structlog

from apps.api.events.models import TriggerCondition

logger = structlog.get_logger(__name__)


class ConditionEvaluator:
    """Evaluates trigger conditions against event payloads.

    Supports operators: eq, ne, contains, regex, gt, lt.
    Supports nested field access via dot notation (e.g., 'user.email').
    """

    def evaluate_all(
        self, conditions: list[TriggerCondition] | None, payload: dict[str, Any]
    ) -> bool:
        """Evaluate all conditions (AND logic).

        Args:
            conditions: List of conditions to evaluate.
            payload: Event payload to match against.

        Returns:
            True if ALL conditions match (or no conditions).
        """
        if not conditions:
            return True  # No conditions = always match
        return all(self.evaluate(c, payload) for c in conditions)

    def evaluate(self, condition: TriggerCondition, payload: dict[str, Any]) -> bool:
        """Evaluate a single condition.

        Args:
            condition: Condition to evaluate.
            payload: Event payload.

        Returns:
            True if condition matches, False otherwise.
        """
        try:
            value = self._get_nested_value(payload, condition.field)
            return self._compare(value, condition.operator, condition.value)
        except Exception as e:
            # Log but don't crash - return False on any error
            logger.warning(
                "Condition evaluation error",
                field=condition.field,
                operator=condition.operator,
                error=str(e),
            )
            return False

    def _get_nested_value(self, data: dict[str, Any], path: str) -> Any:
        """Get nested value using dot notation (e.g., 'user.email').

        Args:
            data: Dictionary to search.
            path: Dot-separated path (e.g., 'current.state').

        Returns:
            Value at path or None if not found.
        """
        if not path:
            return None

        parts = path.split(".")
        current = data

        for part in parts:
            if not isinstance(current, dict):
                return None
            if part not in current:
                return None
            current = current[part]

        return current

    def _compare(self, actual: Any, operator: str, expected: Any) -> bool:
        """Compare values using operator.

        Args:
            actual: Actual value from payload.
            operator: Comparison operator.
            expected: Expected value from condition.

        Returns:
            True if comparison succeeds, False otherwise.
        """
        if operator == "eq":
            return self._compare_eq(actual, expected)
        elif operator == "ne":
            return self._compare_ne(actual, expected)
        elif operator == "contains":
            return self._compare_contains(actual, expected)
        elif operator == "regex":
            return self._compare_regex(actual, expected)
        elif operator == "gt":
            return self._compare_gt(actual, expected)
        elif operator == "lt":
            return self._compare_lt(actual, expected)
        else:
            logger.warning("Unknown operator", operator=operator)
            return False

    def _compare_eq(self, actual: Any, expected: Any) -> bool:
        """Equal comparison."""
        return actual == expected

    def _compare_ne(self, actual: Any, expected: Any) -> bool:
        """Not equal comparison."""
        return actual != expected

    def _compare_contains(self, actual: Any, expected: Any) -> bool:
        """Contains comparison (string contains or list membership).

        Args:
            actual: String or list to search in.
            expected: Value to search for.

        Returns:
            True if expected is found in actual.
        """
        if actual is None:
            return False

        # String contains
        if isinstance(actual, str):
            return str(expected) in actual

        # List membership
        if isinstance(actual, list):
            return expected in actual

        # Try string conversion for other types
        try:
            return str(expected) in str(actual)
        except Exception:
            return False

    def _compare_regex(self, actual: Any, expected: Any) -> bool:
        """Regex match comparison.

        Args:
            actual: String to match against.
            expected: Regex pattern.

        Returns:
            True if pattern matches, False otherwise or on error.
        """
        if actual is None:
            return False

        try:
            # Convert to string if needed
            actual_str = str(actual) if not isinstance(actual, str) else actual
            pattern = str(expected)

            # Compile with timeout protection (basic - limit pattern complexity)
            # For more robust protection, consider regex-timeout libraries
            compiled = re.compile(pattern)
            return compiled.search(actual_str) is not None

        except re.error as e:
            # Invalid regex pattern - return False, don't crash
            logger.warning(
                "Invalid regex pattern",
                pattern=expected,
                error=str(e),
            )
            return False
        except Exception as e:
            logger.warning(
                "Regex evaluation error",
                pattern=expected,
                error=str(e),
            )
            return False

    def _compare_gt(self, actual: Any, expected: Any) -> bool:
        """Greater than comparison (for numbers).

        Args:
            actual: Actual numeric value.
            expected: Expected numeric value.

        Returns:
            True if actual > expected, False otherwise.
        """
        try:
            # Handle None
            if actual is None:
                return False

            # Convert to numbers
            actual_num = float(actual)
            expected_num = float(expected)
            return actual_num > expected_num

        except (TypeError, ValueError):
            # Type mismatch - return False
            return False

    def _compare_lt(self, actual: Any, expected: Any) -> bool:
        """Less than comparison (for numbers).

        Args:
            actual: Actual numeric value.
            expected: Expected numeric value.

        Returns:
            True if actual < expected, False otherwise.
        """
        try:
            # Handle None
            if actual is None:
                return False

            # Convert to numbers
            actual_num = float(actual)
            expected_num = float(expected)
            return actual_num < expected_num

        except (TypeError, ValueError):
            # Type mismatch - return False
            return False
