"""Tests for API scripts."""
