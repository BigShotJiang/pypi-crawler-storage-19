"""Tests for seed_owner script."""

import sys
from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Mock digital_valerii_shared before importing the module
mock_shared = MagicMock()
mock_shared.Database = MagicMock()
mock_shared.DatabaseSettings = MagicMock()
sys.modules["digital_valerii_shared"] = mock_shared

# Now import the module
import apps.api.scripts.seed_owner as seed_owner_module  # noqa: E402
from apps.api.auth.models import User, UserRole  # noqa: E402


class TestSeedOwner:
    """seed_owner function tests."""

    @pytest.fixture
    def mock_session(self) -> MagicMock:
        """Create mock database session."""
        session = MagicMock()
        session.execute = AsyncMock()
        session.add = MagicMock()
        session.commit = AsyncMock()
        session.rollback = AsyncMock()
        session.close = AsyncMock()
        return session

    @pytest.fixture
    def mock_db(self, mock_session: MagicMock) -> MagicMock:
        """Create mock database with async context manager."""
        db = MagicMock()

        @asynccontextmanager
        async def mock_session_cm():
            try:
                yield mock_session
                await mock_session.commit()
            except Exception:
                await mock_session.rollback()
                raise
            finally:
                await mock_session.close()

        db.session = mock_session_cm
        return db

    @pytest.mark.asyncio
    async def test_seed_owner_creates_user(
        self, mock_db: MagicMock, mock_session: MagicMock
    ) -> None:
        """Seed creates owner when not exists."""
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        mock_session.execute.return_value = mock_result

        mock_settings = MagicMock()
        mock_settings.owner_email = "owner@example.com"
        mock_settings.owner_password = "securepassword123"
        mock_settings.owner_name = "Test Owner"

        with (
            patch.object(seed_owner_module, "get_database", return_value=mock_db),
            patch.object(seed_owner_module, "settings", mock_settings),
            patch.object(seed_owner_module, "hash_password", return_value="hashed"),
        ):
            result = await seed_owner_module.seed_owner()

        assert result is True
        mock_session.add.assert_called_once()
        # Verify the user was created with correct attributes
        added_user = mock_session.add.call_args[0][0]
        assert added_user.email == "owner@example.com"
        assert added_user.role == UserRole.OWNER.value
        assert added_user.is_active is True
        assert added_user.is_verified is True

    @pytest.mark.asyncio
    async def test_seed_owner_skips_existing(
        self, mock_db: MagicMock, mock_session: MagicMock
    ) -> None:
        """Seed skips when owner exists."""
        existing_user = User(
            email="owner@example.com",
            password_hash="hashed",
            display_name="Existing Owner",
            role=UserRole.OWNER.value,
        )

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = existing_user
        mock_session.execute.return_value = mock_result

        mock_settings = MagicMock()
        mock_settings.owner_email = "owner@example.com"
        mock_settings.owner_password = "securepassword123"
        mock_settings.owner_name = "Test Owner"

        with (
            patch.object(seed_owner_module, "get_database", return_value=mock_db),
            patch.object(seed_owner_module, "settings", mock_settings),
        ):
            result = await seed_owner_module.seed_owner()

        assert result is False
        mock_session.add.assert_not_called()

    @pytest.mark.asyncio
    async def test_seed_owner_fails_without_email(self) -> None:
        """Seed fails when DV_OWNER_EMAIL not set."""
        mock_settings = MagicMock()
        mock_settings.owner_email = None
        mock_settings.owner_password = "password123"

        with (
            patch.object(seed_owner_module, "settings", mock_settings),
            pytest.raises(SystemExit) as exc_info,
        ):
            await seed_owner_module.seed_owner()

        assert exc_info.value.code == 1

    @pytest.mark.asyncio
    async def test_seed_owner_fails_without_password(self) -> None:
        """Seed fails when DV_OWNER_PASSWORD not set."""
        mock_settings = MagicMock()
        mock_settings.owner_email = "owner@example.com"
        mock_settings.owner_password = None

        with (
            patch.object(seed_owner_module, "settings", mock_settings),
            pytest.raises(SystemExit) as exc_info,
        ):
            await seed_owner_module.seed_owner()

        assert exc_info.value.code == 1
