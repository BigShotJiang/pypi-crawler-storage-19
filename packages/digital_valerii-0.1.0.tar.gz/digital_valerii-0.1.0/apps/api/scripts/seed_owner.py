"""Seed initial owner user.

Usage:
    python -m apps.api.scripts.seed_owner

Environment:
    DV_OWNER_EMAIL: Owner email (required)
    DV_OWNER_PASSWORD: Owner password (required)
    DV_OWNER_NAME: Display name (optional, default: "Owner")

Per ISO 42001 A.8.3: Initial privileged user creation.
"""

import asyncio
import sys

from sqlalchemy import select

from apps.api.auth.models import User, UserRole
from apps.api.auth.password import hash_password
from apps.api.config import settings
from apps.api.database import get_database


async def seed_owner() -> bool:
    """Create owner user if not exists.

    Returns:
        True if owner was created, False if already exists.

    Raises:
        SystemExit: If required environment variables not set.
    """
    if not settings.owner_email:
        print("ERROR: DV_OWNER_EMAIL not set")
        sys.exit(1)

    if not settings.owner_password:
        print("ERROR: DV_OWNER_PASSWORD not set")
        sys.exit(1)

    db = get_database()

    async with db.session() as session:
        # Check if owner exists
        result = await session.execute(
            select(User).where(User.email == settings.owner_email.lower())
        )
        existing = result.scalar_one_or_none()

        if existing:
            print(f"Owner {settings.owner_email} already exists")
            return False

        # Create owner
        owner = User(
            email=settings.owner_email.lower(),
            password_hash=hash_password(settings.owner_password),
            display_name=settings.owner_name,
            role=UserRole.OWNER.value,
            is_active=True,
            is_verified=True,
        )
        session.add(owner)
        # Note: session context manager commits automatically

    print(f"Created owner: {settings.owner_email}")
    return True


def main() -> None:
    """Run seed_owner script."""
    asyncio.run(seed_owner())


if __name__ == "__main__":
    main()
