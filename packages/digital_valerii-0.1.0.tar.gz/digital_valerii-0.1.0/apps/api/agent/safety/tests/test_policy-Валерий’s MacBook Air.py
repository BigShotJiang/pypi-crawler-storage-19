"""Tests for tool policy definitions."""

import pytest
from pydantic import ValidationError

from apps.api.agent.safety.policy import (
    TOOL_POLICIES,
    ApprovalMode,
    RiskLevel,
    ToolPolicy,
    get_tool_policy,
)


class TestRiskLevel:
    """Tests for RiskLevel enum."""

    def test_risk_levels_exist(self) -> None:
        """Test all risk levels are defined."""
        assert RiskLevel.LOW == "low"
        assert RiskLevel.MEDIUM == "medium"
        assert RiskLevel.HIGH == "high"
        assert RiskLevel.CRITICAL == "critical"

    def test_risk_level_count(self) -> None:
        """Test correct number of risk levels."""
        assert len(RiskLevel) == 4

    def test_risk_level_from_string(self) -> None:
        """Test creating risk level from string."""
        assert RiskLevel("low") == RiskLevel.LOW
        assert RiskLevel("critical") == RiskLevel.CRITICAL

    def test_risk_level_invalid_raises(self) -> None:
        """Test invalid risk level raises error."""
        with pytest.raises(ValueError):
            RiskLevel("invalid")


class TestApprovalMode:
    """Tests for ApprovalMode enum."""

    def test_approval_modes_exist(self) -> None:
        """Test all approval modes are defined."""
        assert ApprovalMode.AUTO == "auto"
        assert ApprovalMode.CONFIRM == "confirm"
        assert ApprovalMode.DENY == "deny"

    def test_approval_mode_count(self) -> None:
        """Test correct number of approval modes."""
        assert len(ApprovalMode) == 3

    def test_approval_mode_from_string(self) -> None:
        """Test creating approval mode from string."""
        assert ApprovalMode("auto") == ApprovalMode.AUTO
        assert ApprovalMode("deny") == ApprovalMode.DENY


class TestToolPolicy:
    """Tests for ToolPolicy model."""

    def test_create_minimal_policy(self) -> None:
        """Test creating policy with minimal fields."""
        policy = ToolPolicy(
            tool_name="test_tool",
            risk_level=RiskLevel.LOW,
        )
        assert policy.tool_name == "test_tool"
        assert policy.risk_level == RiskLevel.LOW
        assert policy.approval_mode == ApprovalMode.CONFIRM  # default
        assert policy.daily_limit is None
        assert policy.allowlist == []
        assert policy.blocklist == []
        assert policy.require_reason is False
        assert policy.audit_log is True

    def test_create_full_policy(self) -> None:
        """Test creating policy with all fields."""
        policy = ToolPolicy(
            tool_name="email_send",
            risk_level=RiskLevel.HIGH,
            approval_mode=ApprovalMode.CONFIRM,
            daily_limit=50,
            allowlist=["*@company.com"],
            blocklist=["*@competitor.com"],
            require_reason=True,
            audit_log=True,
        )
        assert policy.tool_name == "email_send"
        assert policy.risk_level == RiskLevel.HIGH
        assert policy.daily_limit == 50
        assert len(policy.allowlist) == 1
        assert len(policy.blocklist) == 1
        assert policy.require_reason is True

    def test_extra_fields_forbidden(self) -> None:
        """Test extra fields are rejected."""
        with pytest.raises(ValidationError):
            ToolPolicy(
                tool_name="test",
                risk_level=RiskLevel.LOW,
                extra_field="not allowed",  # type: ignore[call-arg]
            )

    def test_tool_name_required(self) -> None:
        """Test tool_name is required."""
        with pytest.raises(ValidationError):
            ToolPolicy(risk_level=RiskLevel.LOW)  # type: ignore[call-arg]

    def test_risk_level_required(self) -> None:
        """Test risk_level is required."""
        with pytest.raises(ValidationError):
            ToolPolicy(tool_name="test")  # type: ignore[call-arg]

    def test_daily_limit_can_be_none(self) -> None:
        """Test daily_limit can be None."""
        policy = ToolPolicy(
            tool_name="test",
            risk_level=RiskLevel.LOW,
            daily_limit=None,
        )
        assert policy.daily_limit is None

    def test_daily_limit_can_be_positive(self) -> None:
        """Test daily_limit accepts positive integers."""
        policy = ToolPolicy(
            tool_name="test",
            risk_level=RiskLevel.LOW,
            daily_limit=100,
        )
        assert policy.daily_limit == 100


class TestToolPoliciesDefaults:
    """Tests for default TOOL_POLICIES."""

    def test_default_policies_exist(self) -> None:
        """Test default policies are defined."""
        assert len(TOOL_POLICIES) > 0

    def test_memory_search_policy(self) -> None:
        """Test memory_search is LOW risk AUTO approval."""
        policy = TOOL_POLICIES.get("memory_search")
        assert policy is not None
        assert policy.risk_level == RiskLevel.LOW
        assert policy.approval_mode == ApprovalMode.AUTO

    def test_memory_store_policy(self) -> None:
        """Test memory_store is MEDIUM risk with limit."""
        policy = TOOL_POLICIES.get("memory_store")
        assert policy is not None
        assert policy.risk_level == RiskLevel.MEDIUM
        assert policy.daily_limit == 100

    def test_email_send_policy(self) -> None:
        """Test email_send is HIGH risk CONFIRM approval."""
        policy = TOOL_POLICIES.get("email_send")
        assert policy is not None
        assert policy.risk_level == RiskLevel.HIGH
        assert policy.approval_mode == ApprovalMode.CONFIRM
        assert policy.require_reason is True

    def test_code_execute_policy(self) -> None:
        """Test code_execute is CRITICAL risk."""
        policy = TOOL_POLICIES.get("code_execute")
        assert policy is not None
        assert policy.risk_level == RiskLevel.CRITICAL
        assert policy.approval_mode == ApprovalMode.CONFIRM
        assert policy.daily_limit == 10

    def test_browser_navigate_has_blocklist(self) -> None:
        """Test browser_navigate has internal hosts blocklisted."""
        policy = TOOL_POLICIES.get("browser_navigate")
        assert policy is not None
        assert len(policy.blocklist) > 0
        assert "localhost*" in policy.blocklist
        assert "127.0.0.1*" in policy.blocklist

    def test_all_policies_have_audit_log(self) -> None:
        """Test all default policies have audit_log enabled."""
        for name, policy in TOOL_POLICIES.items():
            assert policy.audit_log is True, f"{name} should have audit_log=True"


class TestGetToolPolicy:
    """Tests for get_tool_policy function."""

    def test_get_existing_policy(self) -> None:
        """Test getting existing policy."""
        policy = get_tool_policy("memory_search")
        assert policy is not None
        assert policy.tool_name == "memory_search"

    def test_get_nonexistent_policy(self) -> None:
        """Test getting non-existent policy returns None."""
        policy = get_tool_policy("nonexistent_tool")
        assert policy is None

    def test_get_policy_case_sensitive(self) -> None:
        """Test policy lookup is case-sensitive."""
        assert get_tool_policy("Memory_Search") is None
        assert get_tool_policy("MEMORY_SEARCH") is None
        assert get_tool_policy("memory_search") is not None
