"""Tests for tool safety framework."""
