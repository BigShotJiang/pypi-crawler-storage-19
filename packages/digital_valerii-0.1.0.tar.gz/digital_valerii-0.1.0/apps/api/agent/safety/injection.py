"""Prompt injection detection and prevention.

Detects and blocks prompt injection attempts in tool arguments.
"""

import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class InjectionCheckResult(BaseModel):
    """Result of injection check."""

    model_config = ConfigDict(extra="forbid")

    is_safe: bool
    risk_score: float  # 0.0 - 1.0
    detected_patterns: list[str] = Field(default_factory=list)
    sanitized_input: str | None = None


class PromptInjectionGuard:
    """Guard against prompt injection attacks.

    Detects common injection patterns and provides sanitization.
    """

    # Common injection patterns
    INJECTION_PATTERNS: list[str] = [
        r"ignore (all )?(previous|prior|above) instructions?",
        r"disregard (all )?(previous|prior|above)",
        r"forget (everything|all|what)",
        r"you are now (a |an )?",
        r"new instructions?:",
        r"override (your|the) (instructions?|programming)",
        r"system prompt:",
        r"developer mode",
        r"jailbreak",
        r"DAN( mode)?",
        r"\[INST\]",
        r"<\|im_start\|>",
        r"<\|system\|>",
        r"<\|user\|>",
        r"<\|assistant\|>",
        r"```system",
        r"act as if",
        r"pretend (you are|to be)",
        r"roleplay as",
        r"bypass (safety|security|filter)",
        r"ignore (safety|security|filter)",
        r"disable (safety|security|filter)",
    ]

    def __init__(self, patterns: list[str] | None = None) -> None:
        """Initialize guard with optional custom patterns.

        Args:
            patterns: Custom injection patterns. Defaults to INJECTION_PATTERNS.
        """
        self.patterns = [
            re.compile(p, re.IGNORECASE) for p in (patterns or self.INJECTION_PATTERNS)
        ]

    def check(self, text: str) -> InjectionCheckResult:
        """Check text for injection attempts.

        Args:
            text: Text to check.

        Returns:
            InjectionCheckResult with safety status and risk score.
        """
        if not text:
            return InjectionCheckResult(is_safe=True, risk_score=0.0)

        detected = []
        for pattern in self.patterns:
            if pattern.search(text):
                detected.append(pattern.pattern)

        # Risk score: 0.3 per pattern, max 1.0
        risk_score = min(1.0, len(detected) * 0.3)

        return InjectionCheckResult(
            is_safe=len(detected) == 0,
            risk_score=risk_score,
            detected_patterns=detected,
            sanitized_input=self._sanitize(text) if detected else None,
        )

    def _sanitize(self, text: str) -> str:
        """Remove detected injection patterns from text.

        Args:
            text: Text to sanitize.

        Returns:
            Sanitized text with injection patterns replaced.
        """
        result = text
        for pattern in self.patterns:
            result = pattern.sub("[REDACTED]", result)
        return result

    def guard_tool_arguments(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> tuple[dict[str, Any], list[str]]:
        """Check and sanitize tool arguments for injection.

        Args:
            tool_name: Name of the tool (for logging).
            arguments: Tool arguments to check.

        Returns:
            Tuple of (sanitized_arguments, list_of_detected_patterns).
        """
        sanitized: dict[str, Any] = {}
        all_detected: list[str] = []

        for key, value in arguments.items():
            if isinstance(value, str):
                result = self.check(value)
                if not result.is_safe and result.sanitized_input is not None:
                    sanitized[key] = result.sanitized_input
                    all_detected.extend(result.detected_patterns)
                else:
                    sanitized[key] = value
            elif isinstance(value, dict):
                # Recursively check nested dicts
                nested_sanitized, nested_detected = self.guard_tool_arguments(
                    tool_name, value
                )
                sanitized[key] = nested_sanitized
                all_detected.extend(nested_detected)
            elif isinstance(value, list):
                # Check list items
                sanitized_list = []
                for item in value:
                    if isinstance(item, str):
                        result = self.check(item)
                        if not result.is_safe and result.sanitized_input is not None:
                            sanitized_list.append(result.sanitized_input)
                            all_detected.extend(result.detected_patterns)
                        else:
                            sanitized_list.append(item)
                    else:
                        sanitized_list.append(item)
                sanitized[key] = sanitized_list
            else:
                sanitized[key] = value

        return sanitized, all_detected

    def is_high_risk(self, text: str, threshold: float = 0.5) -> bool:
        """Check if text is high risk for injection.

        Args:
            text: Text to check.
            threshold: Risk score threshold for high risk.

        Returns:
            True if risk score exceeds threshold.
        """
        result = self.check(text)
        return result.risk_score > threshold
