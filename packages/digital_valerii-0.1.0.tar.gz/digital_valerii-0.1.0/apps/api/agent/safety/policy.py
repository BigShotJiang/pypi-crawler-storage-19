"""Tool policy definitions for risk classification and approval modes.

Implements ISO 42001 A.5 (Impact Assessment) and EU AI Act Art.14 (Human Oversight).
"""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class RiskLevel(str, Enum):
    """Tool risk classification per ISO 42001 A.5.

    Levels determine the approval requirements and audit granularity.
    """

    LOW = "low"  # Read-only, no side effects (Level 0)
    MEDIUM = "medium"  # Limited scope modifications (Level 1)
    HIGH = "high"  # External actions (Level 2)
    CRITICAL = "critical"  # Financial/destructive (Level 3)


class ApprovalMode(str, Enum):
    """Approval mode per EU AI Act Art.14.

    Determines how tool execution requests are handled.
    """

    AUTO = "auto"  # Automatic execution
    CONFIRM = "confirm"  # Require user confirmation
    DENY = "deny"  # Always deny


class ToolPolicy(BaseModel):
    """Policy for tool execution.

    Defines risk level, approval mode, and constraints for a tool.
    """

    model_config = ConfigDict(extra="forbid")

    tool_name: str
    risk_level: RiskLevel
    approval_mode: ApprovalMode = ApprovalMode.CONFIRM
    daily_limit: int | None = None
    allowlist: list[str] = Field(default_factory=list)
    blocklist: list[str] = Field(default_factory=list)
    require_reason: bool = False
    audit_log: bool = True


# Default tool policies per ARCHITECTURE.md 3.4.3
TOOL_POLICIES: dict[str, ToolPolicy] = {
    "memory_search": ToolPolicy(
        tool_name="memory_search",
        risk_level=RiskLevel.LOW,
        approval_mode=ApprovalMode.AUTO,
        audit_log=True,
    ),
    "memory_store": ToolPolicy(
        tool_name="memory_store",
        risk_level=RiskLevel.MEDIUM,
        approval_mode=ApprovalMode.AUTO,
        daily_limit=100,
        audit_log=True,
    ),
    "calendar_read": ToolPolicy(
        tool_name="calendar_read",
        risk_level=RiskLevel.LOW,
        approval_mode=ApprovalMode.AUTO,
        audit_log=True,
    ),
    "calendar_create": ToolPolicy(
        tool_name="calendar_create",
        risk_level=RiskLevel.HIGH,
        approval_mode=ApprovalMode.CONFIRM,
        daily_limit=20,
        require_reason=True,
        audit_log=True,
    ),
    "email_read": ToolPolicy(
        tool_name="email_read",
        risk_level=RiskLevel.LOW,
        approval_mode=ApprovalMode.AUTO,
        audit_log=True,
    ),
    "email_send": ToolPolicy(
        tool_name="email_send",
        risk_level=RiskLevel.HIGH,
        approval_mode=ApprovalMode.CONFIRM,
        daily_limit=50,
        require_reason=True,
        audit_log=True,
    ),
    "browser_navigate": ToolPolicy(
        tool_name="browser_navigate",
        risk_level=RiskLevel.MEDIUM,
        approval_mode=ApprovalMode.CONFIRM,
        blocklist=[
            "*.internal.*",
            "localhost*",
            "127.0.0.1*",
            "*.local",
            "10.*",
            "192.168.*",
            "172.16.*",
        ],
        audit_log=True,
    ),
    "code_execute": ToolPolicy(
        tool_name="code_execute",
        risk_level=RiskLevel.CRITICAL,
        approval_mode=ApprovalMode.CONFIRM,
        daily_limit=10,
        require_reason=True,
        audit_log=True,
    ),
    "file_read": ToolPolicy(
        tool_name="file_read",
        risk_level=RiskLevel.LOW,
        approval_mode=ApprovalMode.AUTO,
        audit_log=True,
    ),
    "file_write": ToolPolicy(
        tool_name="file_write",
        risk_level=RiskLevel.HIGH,
        approval_mode=ApprovalMode.CONFIRM,
        daily_limit=50,
        require_reason=True,
        audit_log=True,
    ),
    "file_delete": ToolPolicy(
        tool_name="file_delete",
        risk_level=RiskLevel.CRITICAL,
        approval_mode=ApprovalMode.CONFIRM,
        daily_limit=10,
        require_reason=True,
        audit_log=True,
    ),
}


def get_tool_policy(tool_name: str) -> ToolPolicy | None:
    """Get policy for a tool.

    Args:
        tool_name: Name of the tool.

    Returns:
        ToolPolicy if defined, None otherwise.
    """
    return TOOL_POLICIES.get(tool_name)
