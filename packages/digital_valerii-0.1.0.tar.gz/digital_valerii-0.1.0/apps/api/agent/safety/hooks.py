"""SDK hooks for tool safety.

Implements PreToolUse and PostToolUse hooks per Claude Agent SDK interface.
Provides policy enforcement and audit logging per ISO 42001 and EU AI Act.
"""

import fnmatch
import json
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from apps.api.agent.safety.injection import PromptInjectionGuard
from apps.api.agent.safety.policy import ApprovalMode, RiskLevel, ToolPolicy

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession

    from apps.api.agent.approval.service import ApprovalService

logger = logging.getLogger(__name__)


class ToolExecutionLog(BaseModel):
    """Audit log entry per ISO 42001 A.8.3.

    Records tool execution for compliance and audit.
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(default_factory=uuid4)
    tool_name: str
    arguments: dict[str, Any]
    risk_level: RiskLevel
    user_id: str
    session_id: str
    approved_by: str | None = None  # None = auto, user_id = manual
    result_status: str  # success, error, denied, timeout
    error_message: str | None = None
    executed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class DenyResponse(BaseModel):
    """SDK-compliant deny response structure."""

    model_config = ConfigDict(extra="forbid")

    hookSpecificOutput: dict[str, Any]


class SafetyHooks:
    """SDK hooks for tool safety.

    Implements PreToolUse and PostToolUse hooks for policy enforcement
    and audit logging per ISO 42001 A.8.3 and A.9.3.
    """

    def __init__(
        self,
        policies: dict[str, ToolPolicy],
        db: "AsyncSession | None" = None,
        injection_guard: PromptInjectionGuard | None = None,
        approval_service: "ApprovalService | None" = None,
    ) -> None:
        """Initialize safety hooks.

        Args:
            policies: Tool policies dict.
            db: Optional database session for logging.
            injection_guard: Optional custom injection guard.
            approval_service: Optional approval service for CONFIRM mode.
        """
        self.policies = policies
        self.db = db
        self.injection_guard = injection_guard or PromptInjectionGuard()
        self.approval_service = approval_service
        self._daily_counts: dict[str, int] = {}
        self._last_count_reset: datetime = datetime.now(UTC)

    async def on_pre_tool_use(
        self,
        input_data: dict[str, Any],
        tool_use_id: str,  # noqa: ARG002
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Check tool policy before execution.

        Per ISO 42001 A.9.3: Human oversight for high-risk actions.
        Per EU AI Act Art.14: User can override AI decisions.

        Args:
            input_data: Tool input data with tool_name and arguments.
            tool_use_id: Unique tool use identifier.
            context: Execution context with user_id, session_id.

        Returns:
            Empty dict to allow, or dict with permissionDecision: deny.
        """
        tool_name = input_data.get("tool_name", "")

        # Get policy (fail-safe: deny unknown tools)
        policy = self.policies.get(tool_name)
        if not policy:
            logger.warning(f"No policy for tool: {tool_name}")
            return self._deny(f"No policy defined for tool: {tool_name}")

        # Check for prompt injection in arguments
        arguments = input_data.get("arguments", {})
        injection_result = await self._check_injection(tool_name, arguments, context)
        if injection_result:
            return injection_result

        # Check approval mode for ALL risk levels
        if policy.approval_mode == ApprovalMode.DENY:
            return self._deny(f"Tool '{tool_name}' is permanently disabled")

        if policy.approval_mode == ApprovalMode.CONFIRM:
            if self.approval_service:
                # Component 2.8: Create approval request
                approval_id = await self.approval_service.create_request(
                    tool_name=tool_name,
                    arguments=arguments,
                    context=context,
                    risk_level=policy.risk_level.value,
                )
                return self._deny(
                    f"Requires approval (ID: {approval_id})",
                    approval_id=str(approval_id),
                )
            else:
                # Fallback when no approval service configured
                return self._deny(
                    f"Requires approval (risk: {policy.risk_level.value})"
                )

        # Only AUTO mode reaches here - continue with other checks

        # Check blocklist
        target = self._extract_target(tool_name, arguments)
        if target and self._matches_blocklist(target, policy.blocklist):
            logger.warning(f"Blocklisted target for {tool_name}: {target}")
            return self._deny(f"Target '{target}' is blocklisted")

        # Check allowlist (if defined, target must match)
        if (
            policy.allowlist
            and target
            and not self._matches_allowlist(target, policy.allowlist)
        ):
            return self._deny(f"Target '{target}' is not in allowlist")

        # Check daily limit
        if policy.daily_limit:
            user_id = context.get("user_id", "default")
            count = await self._get_daily_count(tool_name, user_id)
            if count >= policy.daily_limit:
                logger.warning(f"Daily limit exceeded for {tool_name}: {count}")
                return self._deny(
                    f"Daily limit ({policy.daily_limit}) exceeded for '{tool_name}'"
                )

        # Allow execution
        logger.debug(f"Allowing tool execution: {tool_name}")
        return {}

    async def on_post_tool_use(
        self,
        output_data: dict[str, Any],
        tool_use_id: str,  # noqa: ARG002
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Log tool execution for audit.

        Per ISO 42001 A.8.3: External reporting/audit trail.
        Per EU AI Act Art.14: Traceability of AI decisions.

        Args:
            output_data: Tool output data with result or error.
            tool_use_id: Unique tool use identifier.
            context: Execution context with user_id, session_id.

        Returns:
            Empty dict (don't modify output).
        """
        tool_name = output_data.get("tool_name", "")
        policy = self.policies.get(tool_name)

        if policy and policy.audit_log:
            # Determine result status
            has_error = output_data.get("error") is not None
            result_status = "error" if has_error else "success"

            log_entry = ToolExecutionLog(
                tool_name=tool_name,
                arguments=output_data.get("input", {}).get("arguments", {}),
                risk_level=policy.risk_level,
                user_id=context.get("user_id", "unknown"),
                session_id=context.get("session_id", "unknown"),
                result_status=result_status,
                error_message=output_data.get("error"),
            )

            await self._store_log(log_entry)

            # Increment daily count
            user_id = context.get("user_id", "default")
            await self._increment_daily_count(tool_name, user_id)

        return {}

    def _deny(self, reason: str, approval_id: str | None = None) -> dict[str, Any]:
        """Return deny response per SDK format.

        Args:
            reason: Reason for denial.
            approval_id: Optional approval request ID for CONFIRM mode.

        Returns:
            SDK-compliant deny response dict.
        """
        response: dict[str, Any] = {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }
        }

        if approval_id:
            response["hookSpecificOutput"]["approval_id"] = approval_id

        return response

    async def _check_injection(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Check arguments for prompt injection (recursive).

        Args:
            tool_name: Tool name.
            arguments: Tool arguments.
            context: Execution context.

        Returns:
            Deny response if injection detected, None otherwise.
        """
        # Use recursive guard_tool_arguments for nested scanning
        _, detected_patterns = self.injection_guard.guard_tool_arguments(
            tool_name, arguments
        )

        if detected_patterns:
            # Calculate risk score (0.3 per pattern, capped at 1.0)
            risk_score = min(1.0, len(detected_patterns) * 0.3)

            if risk_score > 0.5:
                logger.warning(
                    f"Injection attempt in {tool_name}: patterns={detected_patterns}"
                )
                await self._log_injection_attempt(
                    tool_name, "nested", detected_patterns, context
                )
                return self._deny("Potential prompt injection detected in arguments")

        return None

    async def _log_injection_attempt(
        self,
        tool_name: str,
        argument_key: str,
        patterns: list[str],
        context: dict[str, Any],
    ) -> None:
        """Log injection attempt for security audit.

        Args:
            tool_name: Tool that was targeted.
            argument_key: Argument that contained injection.
            patterns: Detected injection patterns.
            context: Execution context.
        """
        log_entry = ToolExecutionLog(
            tool_name=tool_name,
            arguments={"injection_in": argument_key, "patterns": patterns},
            risk_level=RiskLevel.CRITICAL,
            user_id=context.get("user_id", "unknown"),
            session_id=context.get("session_id", "unknown"),
            result_status="denied",
            error_message="Prompt injection attempt detected",
        )
        await self._store_log(log_entry)

    def _extract_target(
        self,
        tool_name: str,
        arguments: dict[str, Any],
    ) -> str | None:
        """Extract target (email, URL, path) from arguments.

        Args:
            tool_name: Tool name.
            arguments: Tool arguments.

        Returns:
            Target string if found, None otherwise.
        """
        # Map tool names to argument keys that contain targets
        target_keys: dict[str, list[str]] = {
            "email_send": ["to", "recipient", "recipients"],
            "browser_navigate": ["url", "href", "link"],
            "file_read": ["path", "file_path", "filename"],
            "file_write": ["path", "file_path", "filename"],
            "file_delete": ["path", "file_path", "filename"],
            "calendar_create": ["attendees", "location"],
        }

        keys_to_check = target_keys.get(tool_name, [])
        for key in keys_to_check:
            value = arguments.get(key)
            if value:
                if isinstance(value, list):
                    return value[0] if value else None
                return str(value)
        return None

    def _normalize_target(self, target: str) -> list[str]:
        """Extract matchable components from target (URL, email, path).

        Args:
            target: Target string (URL, email, path).

        Returns:
            List of strings to match against patterns.
        """
        candidates = [target.lower()]

        # Try parsing as URL
        try:
            parsed = urlparse(target)
            if parsed.hostname:
                candidates.append(parsed.hostname.lower())
                # Add with port if present
                if parsed.port:
                    candidates.append(f"{parsed.hostname.lower()}:{parsed.port}")
                # Add full netloc
                if parsed.netloc:
                    candidates.append(parsed.netloc.lower())
        except Exception:
            pass

        return candidates

    def _matches_blocklist(self, target: str, blocklist: list[str]) -> bool:
        """Check if target matches any blocklist pattern.

        Args:
            target: Target to check.
            blocklist: List of glob patterns.

        Returns:
            True if target matches any pattern.
        """
        candidates = self._normalize_target(target)
        for candidate in candidates:
            for pattern in blocklist:
                if fnmatch.fnmatch(candidate, pattern.lower()):
                    return True
        return False

    def _matches_allowlist(self, target: str, allowlist: list[str]) -> bool:
        """Check if target matches any allowlist pattern.

        Args:
            target: Target to check.
            allowlist: List of glob patterns.

        Returns:
            True if target matches any pattern.
        """
        candidates = self._normalize_target(target)
        for candidate in candidates:
            for pattern in allowlist:
                if fnmatch.fnmatch(candidate, pattern.lower()):
                    return True
        return False

    async def _get_daily_count(self, tool_name: str, user_id: str = "default") -> int:
        """Get today's execution count for tool + user.

        Args:
            tool_name: Tool name.
            user_id: User identifier.

        Returns:
            Count of executions today.
        """
        # Reset counts if new day
        now = datetime.now(UTC)
        if now.date() != self._last_count_reset.date():
            self._daily_counts = {}
            self._last_count_reset = now

        key = f"{tool_name}:{user_id}"
        return self._daily_counts.get(key, 0)

    async def _increment_daily_count(
        self, tool_name: str, user_id: str = "default"
    ) -> None:
        """Increment daily execution count for tool + user.

        Args:
            tool_name: Tool name.
            user_id: User identifier.
        """
        key = f"{tool_name}:{user_id}"
        current = await self._get_daily_count(tool_name, user_id)
        self._daily_counts[key] = current + 1

    async def _store_log(self, log_entry: ToolExecutionLog) -> None:
        """Store audit log entry.

        Args:
            log_entry: Log entry to store.
        """
        if self.db is None:
            # No database session - log to standard logger
            logger.info(
                f"Tool execution log: {log_entry.tool_name} "
                f"status={log_entry.result_status} "
                f"user={log_entry.user_id}"
            )
            return

        # Database storage will be implemented with Component 2.8
        # For now, the migration creates the table structure
        try:
            from sqlalchemy import text

            await self.db.execute(
                text("""
                    INSERT INTO tool_execution_logs
                    (id, tool_name, arguments, risk_level, user_id, session_id,
                     approved_by, result_status, error_message, executed_at)
                    VALUES
                    (:id, :tool_name, :arguments::jsonb, :risk_level, :user_id,
                     :session_id, :approved_by, :result_status, :error_message,
                     :executed_at)
                """),
                {
                    "id": str(log_entry.id),
                    "tool_name": log_entry.tool_name,
                    "arguments": json.dumps(log_entry.arguments),
                    "risk_level": log_entry.risk_level.value,
                    "user_id": log_entry.user_id,
                    "session_id": log_entry.session_id,
                    "approved_by": log_entry.approved_by,
                    "result_status": log_entry.result_status,
                    "error_message": log_entry.error_message,
                    "executed_at": log_entry.executed_at,
                },
            )
            await self.db.commit()
        except Exception as e:
            logger.error(f"Failed to store tool execution log: {e}")

    async def get_execution_logs(
        self,
        user_id: str | None = None,
        tool_name: str | None = None,
        risk_level: RiskLevel | None = None,
        limit: int = 100,
    ) -> list[ToolExecutionLog]:
        """Query execution logs for audit reports.

        Args:
            user_id: Filter by user.
            tool_name: Filter by tool.
            risk_level: Filter by risk level.
            limit: Maximum results.

        Returns:
            List of execution logs.
        """
        if self.db is None:
            return []

        try:
            from sqlalchemy import text

            conditions = []
            params: dict[str, Any] = {"limit": limit}

            if user_id:
                conditions.append("user_id = :user_id")
                params["user_id"] = user_id
            if tool_name:
                conditions.append("tool_name = :tool_name")
                params["tool_name"] = tool_name
            if risk_level:
                conditions.append("risk_level = :risk_level")
                params["risk_level"] = risk_level.value

            where_clause = " AND ".join(conditions) if conditions else "1=1"

            result = await self.db.execute(
                text(f"""
                    SELECT id, tool_name, arguments, risk_level, user_id,
                           session_id, approved_by, result_status, error_message,
                           executed_at
                    FROM tool_execution_logs
                    WHERE {where_clause}
                    ORDER BY executed_at DESC
                    LIMIT :limit
                """),
                params,
            )

            logs = []
            for row in result.fetchall():
                logs.append(
                    ToolExecutionLog(
                        id=row[0],
                        tool_name=row[1],
                        arguments=row[2] if isinstance(row[2], dict) else {},
                        risk_level=RiskLevel(row[3]),
                        user_id=row[4],
                        session_id=row[5],
                        approved_by=row[6],
                        result_status=row[7],
                        error_message=row[8],
                        executed_at=row[9],
                    )
                )
            return logs

        except Exception as e:
            logger.error(f"Failed to query execution logs: {e}")
            return []
