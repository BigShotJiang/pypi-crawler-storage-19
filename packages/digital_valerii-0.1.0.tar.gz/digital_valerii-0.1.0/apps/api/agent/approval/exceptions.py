"""Approval system exceptions."""


class ApprovalError(Exception):
    """Base exception for approval errors."""

    pass


class ApprovalNotFoundError(ApprovalError):
    """Approval request not found."""

    pass


class ApprovalExpiredError(ApprovalError):
    """Approval request expired."""

    pass


class ApprovalAlreadyDecidedError(ApprovalError):
    """Approval already approved or denied."""

    pass
