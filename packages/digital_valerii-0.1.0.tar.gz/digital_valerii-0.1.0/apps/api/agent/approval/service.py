"""Approval service for managing tool approvals.

Per EU AI Act Art.14: Human oversight for AI decisions.
Per ISO 42001 A.9.3: Responsible use controls.
"""

import logging
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING
from uuid import UUID

from apps.api.agent.approval.exceptions import (
    ApprovalAlreadyDecidedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
)
from apps.api.agent.approval.models import (
    ApprovalDecision,
    ApprovalRequest,
    ApprovalStatus,
)
from apps.api.agent.approval.store import ApprovalStore

if TYPE_CHECKING:
    from apps.api.agent.approval.notifier import ApprovalNotifier

logger = logging.getLogger(__name__)


class ApprovalService:
    """Service for managing tool approvals.

    Per EU AI Act Art.14: Human oversight for AI decisions.
    Per ISO 42001 A.9.3: Responsible use controls.
    """

    def __init__(
        self,
        store: ApprovalStore,
        notifier: "ApprovalNotifier | None" = None,
    ) -> None:
        """Initialize approval service.

        Args:
            store: Approval storage.
            notifier: Optional notification service.
        """
        self.store = store
        self.notifier = notifier

    async def create_request(
        self,
        tool_name: str,
        arguments: dict,
        context: dict,
        risk_level: str,
        expires_in_seconds: int = 300,
    ) -> UUID:
        """Create approval request for tool execution.

        Args:
            tool_name: Name of the tool requiring approval.
            arguments: Tool arguments.
            context: Execution context (user_id, session_id).
            risk_level: Risk level from policy.
            expires_in_seconds: TTL for the request (default 5 min).

        Returns:
            Approval request ID.
        """
        request = ApprovalRequest(
            tool_name=tool_name,
            arguments=arguments,
            context=context,
            description=self._generate_description(tool_name, arguments),
            risk_level=risk_level,
            expires_at=datetime.now(UTC) + timedelta(seconds=expires_in_seconds),
        )

        approval_id = await self.store.create(request)

        # Notify user (WebSocket, push notification)
        if self.notifier:
            await self.notifier.notify(request)

        logger.info(f"Approval request created: {approval_id} for {tool_name}")
        return approval_id

    async def approve(
        self,
        approval_id: UUID,
        decided_by: str,
        reason: str | None = None,
        modified_arguments: dict | None = None,
    ) -> ApprovalDecision:
        """Approve a pending request.

        Args:
            approval_id: Request ID.
            decided_by: User ID who approved.
            reason: Optional approval reason.
            modified_arguments: Optional modified parameters.

        Returns:
            ApprovalDecision.

        Raises:
            ApprovalNotFoundError: Request not found.
            ApprovalExpiredError: Request expired.
            ApprovalAlreadyDecidedError: Already approved/denied.
        """
        request = await self.store.get(approval_id)

        if not request:
            raise ApprovalNotFoundError(f"Approval {approval_id} not found")

        if request.status != ApprovalStatus.PENDING:
            raise ApprovalAlreadyDecidedError(
                f"Approval {approval_id} already {request.status.value}"
            )

        if request.expires_at < datetime.now(UTC):
            await self.store.update_status(
                approval_id, ApprovalStatus.EXPIRED, decided_by
            )
            raise ApprovalExpiredError(f"Approval {approval_id} expired")

        await self.store.update_status(
            approval_id, ApprovalStatus.APPROVED, decided_by, reason
        )

        decision = ApprovalDecision(
            request_id=approval_id,
            approved=True,
            reason=reason,
            modified_arguments=modified_arguments,
            decided_by=decided_by,
        )

        logger.info(f"Approval {approval_id} approved by {decided_by}")
        return decision

    async def deny(
        self,
        approval_id: UUID,
        decided_by: str,
        reason: str | None = None,
    ) -> ApprovalDecision:
        """Deny a pending request.

        Args:
            approval_id: Request ID.
            decided_by: User ID who denied.
            reason: Optional denial reason.

        Returns:
            ApprovalDecision.

        Raises:
            ApprovalNotFoundError: Request not found.
            ApprovalAlreadyDecidedError: Already approved/denied.
        """
        request = await self.store.get(approval_id)

        if not request:
            raise ApprovalNotFoundError(f"Approval {approval_id} not found")

        if request.status != ApprovalStatus.PENDING:
            raise ApprovalAlreadyDecidedError(
                f"Approval {approval_id} already {request.status.value}"
            )

        await self.store.update_status(
            approval_id, ApprovalStatus.DENIED, decided_by, reason
        )

        decision = ApprovalDecision(
            request_id=approval_id,
            approved=False,
            reason=reason,
            decided_by=decided_by,
        )

        logger.info(f"Approval {approval_id} denied by {decided_by}")
        return decision

    async def get_status(self, approval_id: UUID) -> ApprovalRequest | None:
        """Get current status of an approval request.

        Args:
            approval_id: Request ID.

        Returns:
            ApprovalRequest if found, None otherwise.
        """
        return await self.store.get(approval_id)

    async def list_pending(
        self,
        user_id: str | None = None,
    ) -> list[ApprovalRequest]:
        """List pending approvals for a user.

        Args:
            user_id: Filter by user ID (optional).

        Returns:
            List of pending approval requests.
        """
        return await self.store.list_pending(user_id)

    async def cancel(
        self,
        approval_id: UUID,
        cancelled_by: str,
    ) -> bool:
        """Cancel a pending approval request.

        Args:
            approval_id: Request ID.
            cancelled_by: User ID who cancelled.

        Returns:
            True if cancelled, False if not found or already decided.
        """
        success = await self.store.update_status(
            approval_id, ApprovalStatus.CANCELLED, cancelled_by, "Cancelled by user"
        )
        if success:
            logger.info(f"Approval {approval_id} cancelled by {cancelled_by}")
        return success

    def _generate_description(self, tool_name: str, arguments: dict) -> str:
        """Generate human-readable action description.

        Args:
            tool_name: Name of the tool.
            arguments: Tool arguments.

        Returns:
            Human-readable description.
        """
        # Tool-specific descriptions
        descriptions: dict = {
            "email_send": lambda args: (
                f"Send email to {args.get('to', 'unknown')}: "
                f"\"{args.get('subject', 'No subject')}\""
            ),
            "calendar_create": lambda args: (
                f"Create calendar event: {args.get('title', 'Untitled')} "
                f"on {args.get('date', 'unknown date')}"
            ),
            "code_execute": lambda args: (
                f"Execute code ({args.get('language', 'unknown')}): "
                f"{str(args.get('code', ''))[:50]}..."
            ),
            "file_write": lambda args: (
                f"Write to file: {args.get('path', 'unknown path')}"
            ),
            "file_delete": lambda args: (
                f"Delete file: {args.get('path', 'unknown path')}"
            ),
            "browser_navigate": lambda args: (
                f"Navigate to: {args.get('url', 'unknown URL')}"
            ),
        }

        if tool_name in descriptions:
            try:
                return descriptions[tool_name](arguments)
            except Exception:
                pass

        return f"Execute {tool_name} with {len(arguments)} arguments"
