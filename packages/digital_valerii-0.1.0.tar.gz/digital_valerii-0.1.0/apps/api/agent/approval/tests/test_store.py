"""Tests for ApprovalStore."""

from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.agent.approval.models import ApprovalRequest, ApprovalStatus
from apps.api.agent.approval.store import ApprovalStore


class TestApprovalStore:
    """ApprovalStore tests."""

    @pytest.fixture
    def mock_db(self) -> MagicMock:
        """Create mock database session."""
        mock = MagicMock()
        mock.execute = AsyncMock()
        mock.commit = AsyncMock()
        return mock

    @pytest.fixture
    def mock_redis(self) -> MagicMock:
        """Create mock Redis client."""
        mock = MagicMock()
        mock.setex = AsyncMock()
        mock.get = AsyncMock(return_value=None)
        mock.delete = AsyncMock()
        mock.scan_iter = AsyncMock(return_value=[])
        mock.ttl = AsyncMock(return_value=100)
        return mock

    @pytest.fixture
    def store(self, mock_db: MagicMock, mock_redis: MagicMock) -> ApprovalStore:
        """Create store with mocks."""
        return ApprovalStore(db=mock_db, redis=mock_redis)

    @pytest.fixture
    def sample_request(self) -> ApprovalRequest:
        """Create sample approval request."""
        return ApprovalRequest(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            risk_level="high",
        )

    @pytest.mark.asyncio
    async def test_create_stores_in_postgres(
        self, store: ApprovalStore, sample_request: ApprovalRequest, mock_db: MagicMock
    ) -> None:
        """Verify create stores request in Postgres."""
        result = await store.create(sample_request)

        assert result == sample_request.id
        mock_db.execute.assert_called_once()
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_caches_in_redis(
        self,
        store: ApprovalStore,
        sample_request: ApprovalRequest,
        mock_redis: MagicMock,
    ) -> None:
        """Verify create caches request in Redis with TTL."""
        await store.create(sample_request)

        mock_redis.setex.assert_called_once()
        call_args = mock_redis.setex.call_args
        assert f"{store.REDIS_PREFIX}{sample_request.id}" in str(call_args)

    @pytest.mark.asyncio
    async def test_create_without_redis(
        self, mock_db: MagicMock, sample_request: ApprovalRequest
    ) -> None:
        """Verify create works without Redis."""
        store = ApprovalStore(db=mock_db, redis=None)
        result = await store.create(sample_request)

        assert result == sample_request.id
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_returns_from_redis_cache(
        self,
        store: ApprovalStore,
        sample_request: ApprovalRequest,
        mock_redis: MagicMock,
    ) -> None:
        """Verify get returns cached request from Redis."""
        mock_redis.get = AsyncMock(return_value=sample_request.model_dump_json())

        result = await store.get(sample_request.id)

        assert result is not None
        assert result.id == sample_request.id
        assert result.tool_name == sample_request.tool_name

    @pytest.mark.asyncio
    async def test_get_fallback_to_postgres(
        self, store: ApprovalStore, mock_db: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Verify get falls back to Postgres when Redis misses."""
        mock_redis.get = AsyncMock(return_value=None)

        # Mock Postgres returning None
        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.get(uuid4())

        assert result is None
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_without_redis(self, mock_db: MagicMock) -> None:
        """Verify get works without Redis (direct Postgres)."""
        store = ApprovalStore(db=mock_db, redis=None)

        mock_result = MagicMock()
        mock_result.fetchone.return_value = None
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.get(uuid4())

        assert result is None

    @pytest.mark.asyncio
    async def test_update_status_updates_postgres(
        self, store: ApprovalStore, mock_db: MagicMock
    ) -> None:
        """Verify update_status updates Postgres."""
        mock_result = MagicMock()
        mock_result.rowcount = 1
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.update_status(
            uuid4(), ApprovalStatus.APPROVED, "admin123", "Approved"
        )

        assert result is True
        mock_db.execute.assert_called_once()
        mock_db.commit.assert_called_once()

    @pytest.mark.asyncio
    async def test_update_status_removes_from_redis(
        self, store: ApprovalStore, mock_db: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Verify update_status removes from Redis cache."""
        mock_result = MagicMock()
        mock_result.rowcount = 1
        mock_db.execute = AsyncMock(return_value=mock_result)

        approval_id = uuid4()
        await store.update_status(
            approval_id, ApprovalStatus.APPROVED, "admin123", None
        )

        mock_redis.delete.assert_called_once_with(f"{store.REDIS_PREFIX}{approval_id}")

    @pytest.mark.asyncio
    async def test_update_status_returns_false_when_not_found(
        self, store: ApprovalStore, mock_db: MagicMock
    ) -> None:
        """Verify update_status returns False when not found."""
        mock_result = MagicMock()
        mock_result.rowcount = 0
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.update_status(
            uuid4(), ApprovalStatus.APPROVED, "admin123", None
        )

        assert result is False

    @pytest.mark.asyncio
    async def test_list_pending_returns_pending_only(
        self, store: ApprovalStore, mock_db: MagicMock
    ) -> None:
        """Verify list_pending returns only pending requests."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.list_pending()

        assert result == []
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_pending_filters_by_user(
        self, store: ApprovalStore, mock_db: MagicMock
    ) -> None:
        """Verify list_pending filters by user_id."""
        mock_result = MagicMock()
        mock_result.fetchall.return_value = []
        mock_db.execute = AsyncMock(return_value=mock_result)

        await store.list_pending(user_id="user123")

        # Verify execute was called with user filter
        mock_db.execute.assert_called_once()

    @pytest.mark.asyncio
    async def test_expire_old_requests(
        self, store: ApprovalStore, mock_db: MagicMock
    ) -> None:
        """Verify expire_old_requests marks expired."""
        mock_result = MagicMock()
        mock_result.rowcount = 5
        mock_db.execute = AsyncMock(return_value=mock_result)

        result = await store.expire_old_requests()

        assert result == 5
        mock_db.execute.assert_called_once()
        mock_db.commit.assert_called_once()
