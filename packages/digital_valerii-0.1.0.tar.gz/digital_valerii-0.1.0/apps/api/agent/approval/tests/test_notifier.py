"""Tests for ApprovalNotifier."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from apps.api.agent.approval.models import ApprovalRequest
from apps.api.agent.approval.notifier import ApprovalNotifier


class TestApprovalNotifier:
    """Tests for ApprovalNotifier class."""

    @pytest.fixture
    def mock_connection_manager(self) -> MagicMock:
        """Create mock connection manager."""
        mock = MagicMock()
        mock.send_to_user = AsyncMock()
        return mock

    @pytest.fixture
    def notifier(self, mock_connection_manager: MagicMock) -> ApprovalNotifier:
        """Create notifier with mocks."""
        return ApprovalNotifier(connection_manager=mock_connection_manager)

    @pytest.fixture
    def sample_request(self) -> ApprovalRequest:
        """Create sample approval request."""
        return ApprovalRequest(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            description="Send email to test@example.com",
            risk_level="high",
        )

    @pytest.mark.asyncio
    async def test_notify_sends_to_user_connection(
        self,
        notifier: ApprovalNotifier,
        mock_connection_manager: MagicMock,
        sample_request: ApprovalRequest,
    ) -> None:
        """Verify notify sends message to user."""
        await notifier.notify(sample_request)

        mock_connection_manager.send_to_user.assert_called_once()
        call_args = mock_connection_manager.send_to_user.call_args

        # Verify user_id
        assert call_args[0][0] == "user123"

        # Verify message structure
        message = call_args[0][1]
        assert message["type"] == "approval_needed"
        assert message["tool_name"] == "email_send"
        assert message["description"] == "Send email to test@example.com"
        assert message["risk_level"] == "high"
        assert "expires_at" in message

    @pytest.mark.asyncio
    async def test_notify_handles_missing_user_id(
        self,
        notifier: ApprovalNotifier,
        mock_connection_manager: MagicMock,
    ) -> None:
        """Verify notify handles missing user_id gracefully."""
        request = ApprovalRequest(
            tool_name="test",
            arguments={},
            context={},  # No user_id
            risk_level="low",
        )

        await notifier.notify(request)

        mock_connection_manager.send_to_user.assert_not_called()

    @pytest.mark.asyncio
    async def test_notify_handles_send_error(
        self,
        notifier: ApprovalNotifier,
        mock_connection_manager: MagicMock,
        sample_request: ApprovalRequest,
    ) -> None:
        """Verify notify handles send errors gracefully."""
        mock_connection_manager.send_to_user = AsyncMock(
            side_effect=Exception("Connection failed")
        )

        # Should not raise
        await notifier.notify(sample_request)

    @pytest.mark.asyncio
    async def test_notify_includes_approval_id(
        self,
        notifier: ApprovalNotifier,
        mock_connection_manager: MagicMock,
        sample_request: ApprovalRequest,
    ) -> None:
        """Verify notify includes approval ID in message."""
        await notifier.notify(sample_request)

        call_args = mock_connection_manager.send_to_user.call_args
        message = call_args[0][1]

        assert message["approval_id"] == str(sample_request.id)
