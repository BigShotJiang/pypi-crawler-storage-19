"""Tests for ApprovalService."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.agent.approval.exceptions import (
    ApprovalAlreadyDecidedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
)
from apps.api.agent.approval.models import ApprovalRequest, ApprovalStatus
from apps.api.agent.approval.service import ApprovalService
from apps.api.agent.approval.store import ApprovalStore


class TestApprovalService:
    """ApprovalService tests."""

    @pytest.fixture
    def mock_store(self) -> MagicMock:
        """Create mock store."""
        mock = MagicMock(spec=ApprovalStore)
        mock.create = AsyncMock(return_value=uuid4())
        mock.get = AsyncMock(return_value=None)
        mock.update_status = AsyncMock(return_value=True)
        mock.list_pending = AsyncMock(return_value=[])
        return mock

    @pytest.fixture
    def mock_notifier(self) -> MagicMock:
        """Create mock notifier."""
        mock = MagicMock()
        mock.notify = AsyncMock()
        return mock

    @pytest.fixture
    def service(self, mock_store: MagicMock) -> ApprovalService:
        """Create service with mocks."""
        return ApprovalService(store=mock_store)

    @pytest.fixture
    def pending_request(self) -> ApprovalRequest:
        """Create pending approval request."""
        return ApprovalRequest(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            risk_level="high",
            status=ApprovalStatus.PENDING,
            expires_at=datetime.now(UTC) + timedelta(minutes=5),
        )

    @pytest.mark.asyncio
    async def test_create_request_stores_and_returns_id(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify create_request stores and returns ID."""
        expected_id = uuid4()
        mock_store.create = AsyncMock(return_value=expected_id)

        result = await service.create_request(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            risk_level="high",
        )

        assert result == expected_id
        mock_store.create.assert_called_once()

    @pytest.mark.asyncio
    async def test_create_request_notifies_user(
        self, mock_store: MagicMock, mock_notifier: MagicMock
    ) -> None:
        """Verify create_request sends notification."""
        service = ApprovalService(store=mock_store, notifier=mock_notifier)

        await service.create_request(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            risk_level="high",
        )

        mock_notifier.notify.assert_called_once()

    @pytest.mark.asyncio
    async def test_approve_updates_status(
        self,
        service: ApprovalService,
        mock_store: MagicMock,
        pending_request: ApprovalRequest,
    ) -> None:
        """Verify approve updates status."""
        mock_store.get = AsyncMock(return_value=pending_request)

        decision = await service.approve(
            approval_id=pending_request.id,
            decided_by="admin123",
            reason="Approved",
        )

        assert decision.approved is True
        assert decision.request_id == pending_request.id
        assert decision.decided_by == "admin123"
        mock_store.update_status.assert_called_once()

    @pytest.mark.asyncio
    async def test_approve_raises_not_found(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify approve raises NotFoundError."""
        mock_store.get = AsyncMock(return_value=None)

        with pytest.raises(ApprovalNotFoundError):
            await service.approve(
                approval_id=uuid4(),
                decided_by="admin123",
            )

    @pytest.mark.asyncio
    async def test_approve_raises_expired(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify approve raises ExpiredError."""
        expired_request = ApprovalRequest(
            tool_name="email_send",
            arguments={},
            context={},
            risk_level="high",
            expires_at=datetime.now(UTC) - timedelta(minutes=1),  # Expired
        )
        mock_store.get = AsyncMock(return_value=expired_request)

        with pytest.raises(ApprovalExpiredError):
            await service.approve(
                approval_id=expired_request.id,
                decided_by="admin123",
            )

    @pytest.mark.asyncio
    async def test_approve_raises_already_decided(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify approve raises AlreadyDecidedError."""
        decided_request = ApprovalRequest(
            tool_name="email_send",
            arguments={},
            context={},
            risk_level="high",
            status=ApprovalStatus.APPROVED,  # Already decided
            expires_at=datetime.now(UTC) + timedelta(minutes=5),
        )
        mock_store.get = AsyncMock(return_value=decided_request)

        with pytest.raises(ApprovalAlreadyDecidedError):
            await service.approve(
                approval_id=decided_request.id,
                decided_by="admin123",
            )

    @pytest.mark.asyncio
    async def test_deny_updates_status(
        self,
        service: ApprovalService,
        mock_store: MagicMock,
        pending_request: ApprovalRequest,
    ) -> None:
        """Verify deny updates status."""
        mock_store.get = AsyncMock(return_value=pending_request)

        decision = await service.deny(
            approval_id=pending_request.id,
            decided_by="admin123",
            reason="Too risky",
        )

        assert decision.approved is False
        assert decision.reason == "Too risky"
        mock_store.update_status.assert_called_once()

    @pytest.mark.asyncio
    async def test_deny_raises_not_found(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify deny raises NotFoundError."""
        mock_store.get = AsyncMock(return_value=None)

        with pytest.raises(ApprovalNotFoundError):
            await service.deny(
                approval_id=uuid4(),
                decided_by="admin123",
            )

    @pytest.mark.asyncio
    async def test_cancel_updates_status(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify cancel updates status."""
        mock_store.update_status = AsyncMock(return_value=True)

        result = await service.cancel(
            approval_id=uuid4(),
            cancelled_by="user123",
        )

        assert result is True
        mock_store.update_status.assert_called_once()

    @pytest.mark.asyncio
    async def test_list_pending_returns_only_pending(
        self, service: ApprovalService, mock_store: MagicMock
    ) -> None:
        """Verify list_pending returns pending requests."""
        expected = [
            ApprovalRequest(
                tool_name="test",
                arguments={},
                context={"user_id": "user123"},
                risk_level="high",
            )
        ]
        mock_store.list_pending = AsyncMock(return_value=expected)

        result = await service.list_pending(user_id="user123")

        assert result == expected

    def test_generate_description_email(self, service: ApprovalService) -> None:
        """Verify email description generation."""
        desc = service._generate_description(
            "email_send", {"to": "test@example.com", "subject": "Hello"}
        )

        assert "test@example.com" in desc
        assert "Hello" in desc

    def test_generate_description_calendar(self, service: ApprovalService) -> None:
        """Verify calendar description generation."""
        desc = service._generate_description(
            "calendar_create", {"title": "Meeting", "date": "2025-01-15"}
        )

        assert "Meeting" in desc
        assert "2025-01-15" in desc

    def test_generate_description_code_execute(self, service: ApprovalService) -> None:
        """Verify code execute description generation."""
        desc = service._generate_description(
            "code_execute",
            {"language": "python", "code": "print('hello world')" * 10},
        )

        assert "python" in desc
        assert "..." in desc  # Should be truncated

    def test_generate_description_unknown_tool(self, service: ApprovalService) -> None:
        """Verify unknown tool description generation."""
        desc = service._generate_description("unknown_tool", {"a": 1, "b": 2})

        assert "unknown_tool" in desc
        assert "2 arguments" in desc
