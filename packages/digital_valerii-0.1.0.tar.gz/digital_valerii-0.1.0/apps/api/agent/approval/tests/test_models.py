"""Tests for approval models."""

from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
from pydantic import ValidationError

from apps.api.agent.approval.models import (
    ApprovalDecision,
    ApprovalRequest,
    ApprovalStatus,
)


class TestApprovalStatus:
    """ApprovalStatus enum tests."""

    def test_status_values(self) -> None:
        """Verify all expected status values exist."""
        assert ApprovalStatus.PENDING.value == "pending"
        assert ApprovalStatus.APPROVED.value == "approved"
        assert ApprovalStatus.DENIED.value == "denied"
        assert ApprovalStatus.EXPIRED.value == "expired"
        assert ApprovalStatus.CANCELLED.value == "cancelled"

    def test_status_from_string(self) -> None:
        """Verify status can be created from string."""
        assert ApprovalStatus("pending") == ApprovalStatus.PENDING
        assert ApprovalStatus("approved") == ApprovalStatus.APPROVED


class TestApprovalRequest:
    """ApprovalRequest model tests."""

    def test_create_minimal(self) -> None:
        """Create request with minimal fields."""
        request = ApprovalRequest(
            tool_name="email_send",
            arguments={"to": "test@example.com"},
            context={"user_id": "user123"},
            risk_level="high",
        )

        assert request.tool_name == "email_send"
        assert request.arguments == {"to": "test@example.com"}
        assert request.context == {"user_id": "user123"}
        assert request.risk_level == "high"
        assert request.status == ApprovalStatus.PENDING
        assert request.id is not None
        assert request.created_at is not None
        assert request.expires_at is not None

    def test_create_full(self) -> None:
        """Create request with all fields."""
        now = datetime.now(UTC)
        expires = now + timedelta(seconds=600)
        request_id = uuid4()

        request = ApprovalRequest(
            id=request_id,
            tool_name="code_execute",
            arguments={"code": "print('hello')"},
            context={"user_id": "user123", "session_id": "sess456"},
            description="Execute Python code",
            risk_level="critical",
            status=ApprovalStatus.PENDING,
            created_at=now,
            expires_at=expires,
        )

        assert request.id == request_id
        assert request.description == "Execute Python code"

    def test_default_expires_at(self) -> None:
        """Verify default expiration is ~5 minutes."""
        request = ApprovalRequest(
            tool_name="test",
            arguments={},
            context={},
            risk_level="low",
        )

        now = datetime.now(UTC)
        delta = request.expires_at - now

        # Should be approximately 300 seconds (5 minutes)
        assert 298 <= delta.total_seconds() <= 302

    def test_extra_forbid(self) -> None:
        """Verify extra fields are rejected."""
        with pytest.raises(ValidationError):
            ApprovalRequest(
                tool_name="test",
                arguments={},
                context={},
                risk_level="low",
                unknown_field="value",
            )


class TestApprovalDecision:
    """ApprovalDecision model tests."""

    def test_create_approval(self) -> None:
        """Create approval decision."""
        request_id = uuid4()
        decision = ApprovalDecision(
            request_id=request_id,
            approved=True,
            reason="Looks good",
            decided_by="admin123",
        )

        assert decision.request_id == request_id
        assert decision.approved is True
        assert decision.reason == "Looks good"
        assert decision.decided_by == "admin123"
        assert decision.decided_at is not None

    def test_create_denial(self) -> None:
        """Create denial decision."""
        request_id = uuid4()
        decision = ApprovalDecision(
            request_id=request_id,
            approved=False,
            reason="Suspicious activity",
            decided_by="admin123",
        )

        assert decision.approved is False
        assert decision.reason == "Suspicious activity"

    def test_modified_arguments(self) -> None:
        """Create decision with modified arguments."""
        request_id = uuid4()
        decision = ApprovalDecision(
            request_id=request_id,
            approved=True,
            modified_arguments={"to": "corrected@example.com"},
            decided_by="admin123",
        )

        assert decision.modified_arguments == {"to": "corrected@example.com"}

    def test_extra_forbid(self) -> None:
        """Verify extra fields are rejected."""
        with pytest.raises(ValidationError):
            ApprovalDecision(
                request_id=uuid4(),
                approved=True,
                decided_by="admin",
                unknown_field="value",
            )
