"""Tests for approval API endpoints."""

from typing import Annotated
from unittest.mock import AsyncMock, MagicMock
from uuid import UUID, uuid4

import pytest
from fastapi import APIRouter, Depends, FastAPI, HTTPException, status
from fastapi.testclient import TestClient
from pydantic import BaseModel, ConfigDict

from apps.api.agent.approval.exceptions import (
    ApprovalAlreadyDecidedError,
    ApprovalExpiredError,
    ApprovalNotFoundError,
)
from apps.api.agent.approval.models import (
    ApprovalDecision,
    ApprovalRequest,
)
from apps.api.agent.approval.service import ApprovalService


# Inline route definitions to avoid importing from routes module
# which has dependencies on digital_valerii_shared
class ApproveRequest(BaseModel):
    """Request body for approval."""

    model_config = ConfigDict(extra="forbid")

    reason: str | None = None
    modified_arguments: dict | None = None


class DenyRequest(BaseModel):
    """Request body for denial."""

    model_config = ConfigDict(extra="forbid")

    reason: str | None = None


router = APIRouter(prefix="/approvals", tags=["approvals"])


# Stubs for dependencies
async def get_approval_service() -> ApprovalService:
    """Stub - overridden in tests."""
    raise NotImplementedError


def get_current_user_id() -> str:
    """Stub - overridden in tests."""
    return "test-user"


ApprovalServiceDep = Annotated[ApprovalService, Depends(get_approval_service)]
CurrentUserDep = Annotated[str, Depends(get_current_user_id)]


@router.get("/pending")
async def list_pending_approvals(
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> list[ApprovalRequest]:
    """List pending approvals."""
    return await service.list_pending(user_id=current_user)


@router.get("/{approval_id}")
async def get_approval_status(
    approval_id: UUID,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalRequest:
    """Get approval status."""
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )
    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to view this approval",
        )
    return request


@router.post("/{approval_id}/approve")
async def approve_request(
    approval_id: UUID,
    body: ApproveRequest,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalDecision:
    """Approve request."""
    # ISSUE-2: Disable modified_arguments until validation exists
    if body.modified_arguments:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Argument modification not yet supported",
        )

    # ISSUE-1: Check ownership before approval
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    try:
        return await service.approve(
            approval_id=approval_id,
            decided_by=current_user,
            reason=body.reason,
            modified_arguments=None,
        )
    except ApprovalNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        ) from None
    except ApprovalExpiredError:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail=f"Approval {approval_id} expired",
        ) from None
    except ApprovalAlreadyDecidedError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        ) from None


@router.post("/{approval_id}/deny")
async def deny_request(
    approval_id: UUID,
    body: DenyRequest,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> ApprovalDecision:
    """Deny request."""
    # ISSUE-1: Check ownership before denial
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    try:
        return await service.deny(
            approval_id=approval_id,
            decided_by=current_user,
            reason=body.reason,
        )
    except ApprovalNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        ) from None
    except ApprovalAlreadyDecidedError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(e),
        ) from None


@router.delete("/{approval_id}")
async def cancel_approval(
    approval_id: UUID,
    service: ApprovalServiceDep,
    current_user: CurrentUserDep,
) -> dict:
    """Cancel approval."""
    # ISSUE-1: Check ownership before cancellation
    request = await service.get_status(approval_id)
    if not request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found",
        )

    if request.context.get("user_id") != current_user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to modify this approval",
        )

    success = await service.cancel(
        approval_id=approval_id,
        cancelled_by=current_user,
    )
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Approval {approval_id} not found or already decided",
        )
    return {"cancelled": True}


@pytest.fixture
def app() -> FastAPI:
    """Create test FastAPI app."""
    app = FastAPI()
    app.include_router(router)
    return app


@pytest.fixture
def mock_service() -> MagicMock:
    """Create mock ApprovalService."""
    mock = MagicMock(spec=ApprovalService)
    mock.list_pending = AsyncMock(return_value=[])
    mock.get_status = AsyncMock(return_value=None)
    mock.approve = AsyncMock()
    mock.deny = AsyncMock()
    mock.cancel = AsyncMock(return_value=True)
    return mock


@pytest.fixture
def client(app: FastAPI, mock_service: MagicMock) -> TestClient:
    """Create test client with mocked dependencies."""
    app.dependency_overrides[get_approval_service] = lambda: mock_service
    app.dependency_overrides[get_current_user_id] = lambda: "test-user"
    return TestClient(app)


@pytest.fixture
def sample_request() -> ApprovalRequest:
    """Create sample approval request."""
    return ApprovalRequest(
        tool_name="email_send",
        arguments={"to": "test@example.com"},
        context={"user_id": "test-user"},
        risk_level="high",
        description="Send email to test@example.com",
    )


class TestListPendingApprovals:
    """Tests for GET /approvals/pending."""

    def test_list_pending_returns_empty(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify empty list returned when no pending."""
        mock_service.list_pending = AsyncMock(return_value=[])

        response = client.get("/approvals/pending")

        assert response.status_code == 200
        assert response.json() == []

    def test_list_pending_returns_user_approvals(
        self,
        client: TestClient,
        mock_service: MagicMock,
        sample_request: ApprovalRequest,
    ) -> None:
        """Verify pending approvals returned."""
        mock_service.list_pending = AsyncMock(return_value=[sample_request])

        response = client.get("/approvals/pending")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["tool_name"] == "email_send"


class TestGetApprovalStatus:
    """Tests for GET /approvals/{approval_id}."""

    def test_get_approval_returns_details(
        self,
        client: TestClient,
        mock_service: MagicMock,
        sample_request: ApprovalRequest,
    ) -> None:
        """Verify approval details returned."""
        mock_service.get_status = AsyncMock(return_value=sample_request)

        response = client.get(f"/approvals/{sample_request.id}")

        assert response.status_code == 200
        data = response.json()
        assert data["tool_name"] == "email_send"

    def test_get_approval_404_not_found(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 404 when not found."""
        mock_service.get_status = AsyncMock(return_value=None)

        response = client.get(f"/approvals/{uuid4()}")

        assert response.status_code == 404

    def test_get_approval_403_other_user(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 403 when viewing another user's approval."""
        other_request = ApprovalRequest(
            tool_name="test",
            arguments={},
            context={"user_id": "other-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=other_request)

        response = client.get(f"/approvals/{other_request.id}")

        assert response.status_code == 403


class TestApproveRequest:
    """Tests for POST /approvals/{approval_id}/approve."""

    def test_approve_returns_decision(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify approval returns decision."""
        approval_id = uuid4()
        # Mock get_status for ownership check
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "test-user"},
            risk_level="high",
        )
        decision = ApprovalDecision(
            request_id=approval_id,
            approved=True,
            decided_by="test-user",
        )
        mock_service.get_status = AsyncMock(return_value=request)
        mock_service.approve = AsyncMock(return_value=decision)

        response = client.post(
            f"/approvals/{approval_id}/approve",
            json={"reason": "Looks good"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["approved"] is True

    def test_approve_404_not_found(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 404 when not found."""
        mock_service.get_status = AsyncMock(return_value=None)

        response = client.post(
            f"/approvals/{uuid4()}/approve",
            json={},
        )

        assert response.status_code == 404

    def test_approve_410_expired(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 410 when expired."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "test-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)
        mock_service.approve = AsyncMock(side_effect=ApprovalExpiredError("Expired"))

        response = client.post(
            f"/approvals/{approval_id}/approve",
            json={},
        )

        assert response.status_code == 410

    def test_approve_409_already_decided(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 409 when already decided."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "test-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)
        mock_service.approve = AsyncMock(
            side_effect=ApprovalAlreadyDecidedError("Already approved")
        )

        response = client.post(
            f"/approvals/{approval_id}/approve",
            json={},
        )

        assert response.status_code == 409

    def test_approve_403_wrong_user(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 403 when approving another user's request."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "other-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)

        response = client.post(
            f"/approvals/{approval_id}/approve",
            json={},
        )

        assert response.status_code == 403

    def test_approve_400_modified_arguments(self, client: TestClient) -> None:
        """Verify 400 when modified_arguments provided."""
        approval_id = uuid4()

        response = client.post(
            f"/approvals/{approval_id}/approve",
            json={"modified_arguments": {"to": "new@example.com"}},
        )

        assert response.status_code == 400
        assert "not yet supported" in response.json()["detail"]


class TestDenyRequest:
    """Tests for POST /approvals/{approval_id}/deny."""

    def test_deny_returns_decision(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify deny returns decision."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "test-user"},
            risk_level="high",
        )
        decision = ApprovalDecision(
            request_id=approval_id,
            approved=False,
            decided_by="test-user",
            reason="Too risky",
        )
        mock_service.get_status = AsyncMock(return_value=request)
        mock_service.deny = AsyncMock(return_value=decision)

        response = client.post(
            f"/approvals/{approval_id}/deny",
            json={"reason": "Too risky"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["approved"] is False

    def test_deny_404_not_found(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 404 when not found."""
        mock_service.get_status = AsyncMock(return_value=None)

        response = client.post(
            f"/approvals/{uuid4()}/deny",
            json={},
        )

        assert response.status_code == 404

    def test_deny_403_wrong_user(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 403 when denying another user's request."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "other-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)

        response = client.post(
            f"/approvals/{approval_id}/deny",
            json={},
        )

        assert response.status_code == 403


class TestCancelApproval:
    """Tests for DELETE /approvals/{approval_id}."""

    def test_cancel_deletes_pending(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify cancel returns success."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "test-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)
        mock_service.cancel = AsyncMock(return_value=True)

        response = client.delete(f"/approvals/{approval_id}")

        assert response.status_code == 200
        assert response.json()["cancelled"] is True

    def test_cancel_404_not_found(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 404 when not found or already decided."""
        mock_service.get_status = AsyncMock(return_value=None)

        response = client.delete(f"/approvals/{uuid4()}")

        assert response.status_code == 404

    def test_cancel_403_wrong_user(
        self, client: TestClient, mock_service: MagicMock
    ) -> None:
        """Verify 403 when cancelling another user's request."""
        approval_id = uuid4()
        request = ApprovalRequest(
            id=approval_id,
            tool_name="test",
            arguments={},
            context={"user_id": "other-user"},
            risk_level="high",
        )
        mock_service.get_status = AsyncMock(return_value=request)

        response = client.delete(f"/approvals/{approval_id}")

        assert response.status_code == 403


class TestRouterMounted:
    """Integration test for router mounting."""

    def test_approvals_router_included_in_main_app(self) -> None:
        """Verify approvals router is mounted in main app."""
        try:
            from apps.api.main import app
        except ModuleNotFoundError:
            pytest.skip("Skipping: digital_valerii_shared not available")

        # Check that a route with /approvals exists
        routes = [route.path for route in app.routes]
        approval_routes = [r for r in routes if "/approvals" in r]
        assert len(approval_routes) > 0, "Approvals router not mounted"
