"""Tests for approval cleanup job."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from apps.api.agent.approval.cleanup import cleanup_expired_approvals
from apps.api.agent.approval.store import ApprovalStore


class TestCleanupExpiredApprovals:
    """Tests for cleanup_expired_approvals function."""

    @pytest.fixture
    def mock_store(self) -> MagicMock:
        """Create mock store."""
        mock = MagicMock(spec=ApprovalStore)
        mock.expire_old_requests = AsyncMock(return_value=5)
        mock.REDIS_PREFIX = "dv:approval:"
        return mock

    @pytest.fixture
    def mock_redis(self) -> MagicMock:
        """Create mock Redis client."""
        mock = MagicMock()
        mock.scan_iter = MagicMock(return_value=iter([]))
        mock.ttl = AsyncMock(return_value=100)
        mock.delete = AsyncMock()
        return mock

    @pytest.mark.asyncio
    async def test_cleanup_marks_expired_as_expired(
        self, mock_store: MagicMock
    ) -> None:
        """Verify cleanup marks expired requests."""
        mock_store.expire_old_requests = AsyncMock(return_value=5)

        result = await cleanup_expired_approvals(store=mock_store, redis=None)

        assert result["expired_count"] == 5
        mock_store.expire_old_requests.assert_called_once()

    @pytest.mark.asyncio
    async def test_cleanup_removes_redis_keys(
        self, mock_store: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Verify cleanup removes expired Redis keys."""

        # Create async iterator for scan_iter
        async def async_scan_iter(pattern: str) -> None:  # noqa: ARG001
            keys = [b"dv:approval:key1", b"dv:approval:key2"]
            for key in keys:
                yield key

        mock_redis.scan_iter = async_scan_iter
        mock_redis.ttl = AsyncMock(return_value=-1)  # Key has no TTL (expired)

        result = await cleanup_expired_approvals(store=mock_store, redis=mock_redis)

        assert result["redis_cleaned"] == 2
        assert mock_redis.delete.call_count == 2

    @pytest.mark.asyncio
    async def test_cleanup_skips_valid_redis_keys(
        self, mock_store: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Verify cleanup skips Redis keys with valid TTL."""

        async def async_scan_iter(pattern: str) -> None:  # noqa: ARG001
            keys = [b"dv:approval:key1"]
            for key in keys:
                yield key

        mock_redis.scan_iter = async_scan_iter
        mock_redis.ttl = AsyncMock(return_value=100)  # Key still has TTL

        result = await cleanup_expired_approvals(store=mock_store, redis=mock_redis)

        assert result["redis_cleaned"] == 0
        mock_redis.delete.assert_not_called()

    @pytest.mark.asyncio
    async def test_cleanup_without_redis(self, mock_store: MagicMock) -> None:
        """Verify cleanup works without Redis."""
        result = await cleanup_expired_approvals(store=mock_store, redis=None)

        assert result["expired_count"] == 5
        assert result["redis_cleaned"] == 0

    @pytest.mark.asyncio
    async def test_cleanup_handles_redis_error(
        self, mock_store: MagicMock, mock_redis: MagicMock
    ) -> None:
        """Verify cleanup handles Redis errors gracefully."""

        async def async_scan_iter(pattern: str) -> None:  # noqa: ARG001
            raise ConnectionError("Redis connection failed")
            # This makes the function a generator
            yield  # noqa: B901

        mock_redis.scan_iter = async_scan_iter

        # Should not raise, just log error
        result = await cleanup_expired_approvals(store=mock_store, redis=mock_redis)

        assert result["expired_count"] == 5
        assert result["redis_cleaned"] == 0
