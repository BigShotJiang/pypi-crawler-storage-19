"""Approval system tests."""
