"""Background job to clean up expired approvals.

Run via scheduler (every 5 minutes) to maintain database hygiene.
"""

import logging
from typing import TYPE_CHECKING

from apps.api.agent.approval.store import ApprovalStore

if TYPE_CHECKING:
    from redis.asyncio import Redis

logger = logging.getLogger(__name__)


async def cleanup_expired_approvals(
    store: ApprovalStore,
    redis: "Redis | None" = None,
) -> dict:
    """Background job to clean up expired approvals.

    Run via scheduler (every 5 minutes).

    Args:
        store: Approval store.
        redis: Redis client (optional).

    Returns:
        Cleanup statistics.
    """
    # Mark expired in Postgres
    expired_count = await store.expire_old_requests()

    # Clean up any orphaned Redis keys
    cleaned_redis = 0

    if redis:
        pattern = f"{store.REDIS_PREFIX}*"
        try:
            async for key in redis.scan_iter(pattern):
                ttl = await redis.ttl(key)
                if ttl <= 0:
                    await redis.delete(key)
                    cleaned_redis += 1
        except Exception as e:
            logger.error(f"Failed to clean Redis keys: {e}")

    logger.info(f"Cleanup: {expired_count} expired, {cleaned_redis} Redis keys removed")

    return {
        "expired_count": expired_count,
        "redis_cleaned": cleaned_redis,
    }
