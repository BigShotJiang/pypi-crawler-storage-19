"""Storage for approval requests (Postgres + Redis).

Postgres: Persistent storage for audit/compliance.
Redis: Fast pending request lookup with TTL.
"""

from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import UUID

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PG_UUID

from apps.api.agent.approval.models import ApprovalRequest, ApprovalStatus

if TYPE_CHECKING:
    from redis.asyncio import Redis
    from sqlalchemy.ext.asyncio import AsyncSession


# SQLAlchemy table definition
metadata = sa.MetaData()

approval_requests = sa.Table(
    "approval_requests",
    metadata,
    sa.Column("id", PG_UUID(as_uuid=True), primary_key=True),
    sa.Column("tool_name", sa.String(100), nullable=False),
    sa.Column("arguments", JSONB, nullable=False),
    sa.Column("context", JSONB, nullable=False),
    sa.Column("description", sa.Text, nullable=True),
    sa.Column("risk_level", sa.String(20), nullable=False),
    sa.Column("status", sa.String(20), nullable=False),
    sa.Column("decided_by", sa.String(100), nullable=True),
    sa.Column("decision_reason", sa.Text, nullable=True),
    sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
)


class ApprovalStore:
    """Storage for approval requests (Postgres + Redis).

    Postgres: Persistent storage for audit/compliance.
    Redis: Fast pending request lookup with TTL.
    """

    REDIS_PREFIX = "dv:approval:"

    def __init__(self, db: "AsyncSession", redis: "Redis | None" = None) -> None:
        """Initialize approval store.

        Args:
            db: SQLAlchemy async session.
            redis: Redis async client (optional for testing).
        """
        self.db = db
        self.redis = redis

    async def create(self, request: ApprovalRequest) -> UUID:
        """Store new approval request.

        Args:
            request: Approval request to store.

        Returns:
            Request ID.
        """
        # Save to Postgres
        await self.db.execute(
            sa.insert(approval_requests).values(
                id=request.id,
                tool_name=request.tool_name,
                arguments=request.arguments,
                context=request.context,
                description=request.description,
                risk_level=request.risk_level,
                status=request.status.value,
                created_at=request.created_at,
                expires_at=request.expires_at,
            )
        )
        await self.db.commit()

        # Cache in Redis with TTL
        if self.redis:
            ttl = max(1, int((request.expires_at - datetime.now(UTC)).total_seconds()))
            await self.redis.setex(
                f"{self.REDIS_PREFIX}{request.id}",
                ttl,
                request.model_dump_json(),
            )

        return request.id

    async def get(self, approval_id: UUID) -> ApprovalRequest | None:
        """Get approval request by ID.

        Args:
            approval_id: Request ID.

        Returns:
            ApprovalRequest if found, None otherwise.
        """
        # Try Redis first (fast path)
        if self.redis:
            cached = await self.redis.get(f"{self.REDIS_PREFIX}{approval_id}")
            if cached:
                return ApprovalRequest.model_validate_json(cached)

        # Fall back to Postgres
        result = await self.db.execute(
            sa.select(approval_requests).where(approval_requests.c.id == approval_id)
        )
        row = result.fetchone()
        if not row:
            return None

        return self._row_to_model(row)

    async def update_status(
        self,
        approval_id: UUID,
        status: ApprovalStatus,
        decided_by: str,
        reason: str | None = None,
    ) -> bool:
        """Update approval status.

        Args:
            approval_id: Request ID.
            status: New status.
            decided_by: User ID who made the decision.
            reason: Optional decision reason.

        Returns:
            True if updated, False if not found or already decided.
        """
        now = datetime.now(UTC)

        result = await self.db.execute(
            sa.update(approval_requests)
            .where(approval_requests.c.id == approval_id)
            .where(approval_requests.c.status == ApprovalStatus.PENDING.value)
            .values(
                status=status.value,
                decided_by=decided_by,
                decision_reason=reason,
                decided_at=now,
            )
        )
        await self.db.commit()

        # Remove from Redis cache
        if self.redis:
            await self.redis.delete(f"{self.REDIS_PREFIX}{approval_id}")

        return result.rowcount > 0

    async def list_pending(
        self,
        user_id: str | None = None,
        limit: int = 20,
    ) -> list[ApprovalRequest]:
        """List pending approval requests.

        Args:
            user_id: Filter by user ID (optional).
            limit: Maximum results to return.

        Returns:
            List of pending approval requests.
        """
        query = (
            sa.select(approval_requests)
            .where(approval_requests.c.status == ApprovalStatus.PENDING.value)
            .where(approval_requests.c.expires_at > datetime.now(UTC))
            .order_by(approval_requests.c.created_at.desc())
            .limit(limit)
        )

        if user_id:
            query = query.where(
                approval_requests.c.context["user_id"].astext == user_id
            )

        result = await self.db.execute(query)
        return [self._row_to_model(row) for row in result.fetchall()]

    async def expire_old_requests(self) -> int:
        """Mark expired requests. Returns count of expired.

        Returns:
            Number of requests marked as expired.
        """
        now = datetime.now(UTC)

        result = await self.db.execute(
            sa.update(approval_requests)
            .where(approval_requests.c.status == ApprovalStatus.PENDING.value)
            .where(approval_requests.c.expires_at < now)
            .values(status=ApprovalStatus.EXPIRED.value)
        )
        await self.db.commit()

        return result.rowcount

    def _row_to_model(self, row: sa.Row) -> ApprovalRequest:
        """Convert database row to model.

        Args:
            row: Database row.

        Returns:
            ApprovalRequest model.
        """
        return ApprovalRequest(
            id=row.id,
            tool_name=row.tool_name,
            arguments=row.arguments,
            context=row.context,
            description=row.description,
            risk_level=row.risk_level,
            status=ApprovalStatus(row.status),
            decided_by=row.decided_by,
            decision_reason=row.decision_reason,
            created_at=row.created_at,
            expires_at=row.expires_at,
            decided_at=row.decided_at,
        )
