"""WebSocket notification for approval requests.

Notifies users of pending approvals in real-time.
"""

import logging
from typing import TYPE_CHECKING, Protocol

from apps.api.agent.approval.models import ApprovalRequest

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class ConnectionManager(Protocol):
    """Protocol for WebSocket connection manager."""

    async def send_to_user(self, user_id: str, message: dict) -> None:
        """Send message to a specific user.

        Args:
            user_id: Target user ID.
            message: Message to send.
        """
        ...


class ApprovalNotifier:
    """Notify users of pending approvals via WebSocket."""

    def __init__(self, connection_manager: ConnectionManager) -> None:
        """Initialize notifier.

        Args:
            connection_manager: WebSocket connection manager.
        """
        self.connections = connection_manager

    async def notify(self, request: ApprovalRequest) -> None:
        """Send approval request notification to user.

        Args:
            request: Approval request to notify about.
        """
        user_id = request.context.get("user_id")
        if not user_id:
            logger.warning(f"No user_id in approval request {request.id}")
            return

        message = {
            "type": "approval_needed",
            "approval_id": str(request.id),
            "tool_name": request.tool_name,
            "description": request.description,
            "risk_level": request.risk_level,
            "expires_at": request.expires_at.isoformat(),
        }

        try:
            await self.connections.send_to_user(user_id, message)
            logger.info(f"Sent approval notification to user {user_id}")
        except Exception as e:
            logger.error(f"Failed to send approval notification: {e}")
