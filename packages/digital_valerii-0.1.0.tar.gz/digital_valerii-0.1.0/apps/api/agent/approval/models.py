"""Approval request models for EU AI Act Art.14 human oversight.

Implements human-in-the-loop approval for high-risk tool executions.
"""

from datetime import UTC, datetime, timedelta
from enum import Enum
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field


class ApprovalStatus(str, Enum):
    """Status of an approval request.

    Tracks the lifecycle of a tool approval request.
    """

    PENDING = "pending"  # Awaiting user decision
    APPROVED = "approved"  # User approved the action
    DENIED = "denied"  # User denied the action
    EXPIRED = "expired"  # Request timed out
    CANCELLED = "cancelled"  # Request was cancelled


class ApprovalRequest(BaseModel):
    """Approval request per EU AI Act Art.14.

    Represents a pending tool execution that requires human authorization.
    """

    model_config = ConfigDict(extra="forbid")

    id: UUID = Field(default_factory=uuid4)
    tool_name: str
    arguments: dict
    context: dict  # user_id, session_id, etc.
    description: str | None = None  # Human-readable action description
    risk_level: str
    status: ApprovalStatus = ApprovalStatus.PENDING
    decided_by: str | None = None
    decision_reason: str | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC) + timedelta(seconds=300)
    )
    decided_at: datetime | None = None


class ApprovalDecision(BaseModel):
    """Decision on an approval request.

    Records the outcome of a user's approval decision.
    """

    model_config = ConfigDict(extra="forbid")

    request_id: UUID
    approved: bool
    reason: str | None = None
    modified_arguments: dict | None = None  # User can modify params before approval
    decided_by: str
    decided_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
