"""Digital Valerii API - Main application."""

import warnings

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from apps.api.api.routes import approvals, archives, auth, chat, health, memory
from apps.api.config import settings
from apps.api.database import lifespan
from apps.api.middleware import (
    AuditMiddleware,
    AuthMiddleware,
    ErrorHandlingMiddleware,
    RateLimitMiddleware,
    RequestIDMiddleware,
    RequestLoggingMiddleware,
    RequestSizeLimitMiddleware,
)
from apps.api.scheduler.routes import router as scheduler_router

logger = structlog.get_logger(__name__)

app = FastAPI(
    title="Digital Valerii API",
    description="AI Clone/Avatar API",
    version="0.1.0",
    lifespan=lifespan,
)

# =============================================================================
# Middleware Configuration
# =============================================================================
# Order matters: last added = first executed
# Request flow: RequestID → ErrorHandling → SizeLimit → RateLimit → Auth
#               → RequestLogging → Audit → Routes
# NOTE: SizeLimit runs BEFORE Auth to reject oversized requests early (DoS protection)
# NOTE: RateLimit runs BEFORE Auth to throttle brute-force attempts

# 7. Audit - log significant requests to DB (fire-and-forget)
app.add_middleware(AuditMiddleware)
# 6. Request Logging - log request start/complete to console
app.add_middleware(RequestLoggingMiddleware)
# 5. Auth - validate API key/JWT on protected endpoints
app.add_middleware(AuthMiddleware)
# 4. Rate Limit - enforce request rate limits (before auth to throttle brute-force)
app.add_middleware(RateLimitMiddleware)
# 3. Size Limit - reject oversized requests early (before auth processing)
app.add_middleware(RequestSizeLimitMiddleware)
# 2. Error Handling - catch unhandled exceptions
app.add_middleware(ErrorHandlingMiddleware)
# 1. Request ID - add unique ID to each request
app.add_middleware(RequestIDMiddleware)

# =============================================================================
# CORS Configuration
# =============================================================================
# Validate CORS config: wildcard with credentials is insecure
if "*" in settings.cors_origins:
    warnings.warn(
        "CORS wildcard '*' detected - credentials disabled for security",
        UserWarning,
        stacklevel=1,
    )
    allow_credentials = False
else:
    allow_credentials = True

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, tags=["health"])
app.include_router(auth.router, prefix=settings.api_v1_prefix)
app.include_router(chat.router, prefix=settings.api_v1_prefix)
app.include_router(memory.router, prefix=settings.api_v1_prefix)
app.include_router(approvals.router, prefix=settings.api_v1_prefix)
app.include_router(archives.router, prefix=settings.api_v1_prefix)
app.include_router(scheduler_router, prefix=settings.api_v1_prefix)

# =============================================================================
# Optional Integration Routers
# =============================================================================
# These are loaded conditionally to avoid import errors when dependencies
# are not installed or credentials are not configured.

# Microsoft Graph API (Component 4.1)
if settings.microsoft_client_id:
    try:
        from apps.api.integrations.microsoft.routes import router as microsoft_router

        app.include_router(microsoft_router, prefix=settings.api_v1_prefix)
        logger.info("Microsoft Graph API router registered")
    except ImportError as e:
        logger.warning("Microsoft integration not available", error=str(e))

# Slack Bot (Component 4.2)
if settings.slack_bot_token:
    try:
        from apps.api.integrations.slack.routes import router as slack_router

        app.include_router(slack_router, prefix=settings.api_v1_prefix)
        logger.info("Slack Bot router registered")
    except ImportError as e:
        logger.warning("Slack integration not available", error=str(e))


@app.get("/")
async def root() -> dict[str, str]:
    """Root endpoint."""
    return {"message": "Digital Valerii API", "status": "running"}
