"""Task Worker Service for background task execution."""

import asyncio
from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import UUID

import structlog

from apps.api.background.exceptions import (
    TaskExecutionError,
    TaskTimeoutError,
)
from apps.api.background.executors.base import ExecutionContext
from apps.api.background.executors.registry import StepExecutorRegistry
from apps.api.background.models import (
    BackgroundTask,
    StepResult,
    StepStatus,
    TaskProgress,
    TaskStatus,
    TaskStep,
)

if TYPE_CHECKING:
    from apps.api.background.executors.base import BaseStepExecutor
    from apps.api.background.manager import BackgroundTaskManager

logger = structlog.get_logger(__name__)


class TaskWorkerService:
    """Service that executes background tasks.

    Polls the task queue, executes steps in order, and tracks progress.

    Example:
        registry = StepExecutorRegistry()
        registry.register(PythonExecutor())
        registry.register(AIExecutor(anthropic_client))

        worker = TaskWorkerService(manager, registry)
        await worker.start()
        # Worker runs until stopped
        await worker.stop()
    """

    def __init__(
        self,
        manager: "BackgroundTaskManager",
        registry: StepExecutorRegistry,
        poll_interval: float = 1.0,
        max_concurrent_tasks: int = 5,
    ) -> None:
        """Initialize worker service.

        Args:
            manager: BackgroundTaskManager for task operations.
            registry: StepExecutorRegistry with available executors.
            poll_interval: Seconds between queue polls.
            max_concurrent_tasks: Max tasks to run concurrently.
        """
        self._manager = manager
        self._registry = registry
        self._poll_interval = poll_interval
        self._max_concurrent = max_concurrent_tasks

        self._running = False
        self._active_tasks: dict[UUID, asyncio.Task] = {}
        self._task_queue: asyncio.Queue[BackgroundTask] = asyncio.Queue()

    async def start(self) -> None:
        """Start the worker service.

        Begins polling and processing tasks.
        """
        if self._running:
            return

        self._running = True
        await logger.ainfo("Task worker starting")

        # Start worker loop
        asyncio.create_task(self._run_loop())

    async def stop(self, timeout: float = 30.0) -> None:
        """Stop the worker service.

        Waits for active tasks to complete (up to timeout).

        Args:
            timeout: Max seconds to wait for tasks.
        """
        self._running = False
        await logger.ainfo("Task worker stopping", active_tasks=len(self._active_tasks))

        # Wait for active tasks
        if self._active_tasks:
            try:
                await asyncio.wait_for(
                    asyncio.gather(
                        *self._active_tasks.values(), return_exceptions=True
                    ),
                    timeout=timeout,
                )
            except TimeoutError:
                await logger.awarning(
                    "Timeout waiting for active tasks",
                    remaining=len(self._active_tasks),
                )
                # Cancel remaining tasks
                for task in self._active_tasks.values():
                    task.cancel()

        await logger.ainfo("Task worker stopped")

    @property
    def is_running(self) -> bool:
        """Check if worker is running."""
        return self._running

    @property
    def active_task_count(self) -> int:
        """Get number of active tasks."""
        return len(self._active_tasks)

    async def _run_loop(self) -> None:
        """Main worker loop."""
        while self._running:
            try:
                # Check if we can accept more tasks
                if len(self._active_tasks) < self._max_concurrent:
                    task = await self._poll_queue()
                    if task:
                        # Start task execution
                        asyncio_task = asyncio.create_task(
                            self._execute_task_safe(task)
                        )
                        self._active_tasks[task.id] = asyncio_task

                # Clean up completed tasks
                self._cleanup_completed()

                # Wait before next poll
                await asyncio.sleep(self._poll_interval)

            except Exception as e:
                await logger.aerror("Error in worker loop", error=str(e))
                await asyncio.sleep(self._poll_interval)

    async def _poll_queue(self) -> BackgroundTask | None:
        """Poll for next pending task (atomic claim).

        Uses atomic UPDATE with FOR UPDATE SKIP LOCKED to prevent
        race conditions when multiple workers poll simultaneously.

        Returns:
            BackgroundTask with status RUNNING, or None if queue empty.
        """
        try:
            # Atomic claim: selects and updates in single transaction
            task = await self._manager.claim_next_pending_task()
            return task

        except Exception as e:
            await logger.aerror("Error polling queue", error=str(e))
            return None

    async def _execute_task_safe(self, task: BackgroundTask) -> None:
        """Execute task with error handling.

        Args:
            task: Task to execute.
        """
        try:
            await self._execute_task(task)
        except Exception as e:
            await logger.aerror(
                "Task execution failed",
                task_id=str(task.id),
                error=str(e),
            )
            await self._fail_task(task, str(e))
        finally:
            # Remove from active tasks
            self._active_tasks.pop(task.id, None)

    async def _execute_task(self, task: BackgroundTask) -> None:
        """Execute all steps of a task.

        Args:
            task: Task to execute.
        """
        await logger.ainfo(
            "Starting task execution",
            task_id=str(task.id),
            task_type=task.task_type,
            steps=len(task.steps),
        )

        # Build execution context
        context = ExecutionContext(
            task_id=task.id,
            task_type=task.task_type,
            task_name=task.name,
            session_id=task.created_by_session_id,
            payload=task.payload,
            previous_results={},
        )

        # Check total timeout
        started_at = datetime.now(UTC)
        total_timeout = task.timeout_seconds

        # Execute each step
        for i, step in enumerate(task.steps):
            # Check if timeout exceeded
            elapsed = (datetime.now(UTC) - started_at).total_seconds()
            if elapsed > total_timeout:
                raise TaskTimeoutError(str(task.id), total_timeout)

            # Update progress
            await self._update_progress(
                task=task,
                step_index=i,
                message=f"Executing step: {step.name}",
            )

            # Get executor
            if not self._registry.has(step.executor):
                raise TaskExecutionError(
                    str(task.id),
                    step.name,
                    f"Unknown executor: {step.executor}",
                )

            executor = self._registry.get(step.executor)

            # Execute step with retry
            result = await self._execute_step_with_retry(
                executor=executor,
                step=step,
                context=context,
                step_index=i,
            )

            # Record step history
            await self._record_step_result(task.id, result)

            # Handle failure
            if result.status == StepStatus.FAILED:
                if step.continue_on_failure:
                    await logger.awarning(
                        "Step failed, continuing",
                        task_id=str(task.id),
                        step_name=step.name,
                        error=result.error,
                    )
                else:
                    raise TaskExecutionError(
                        str(task.id),
                        step.name,
                        result.error or "Unknown error",
                    )

            # Store result for next steps
            context.previous_results[step.name] = result.output

        # Task completed successfully
        await self._complete_task(task, context.previous_results)

    async def _execute_step_with_retry(
        self,
        executor: "BaseStepExecutor",
        step: "TaskStep",
        context: ExecutionContext,
        step_index: int,
    ) -> StepResult:
        """Execute step with retry logic.

        Args:
            executor: Step executor.
            step: Step definition.
            context: Execution context.
            step_index: Index of step.

        Returns:
            StepResult from execution.
        """
        last_error = None
        for attempt in range(step.retry_count + 1):
            try:
                result = await executor._execute_with_timeout(step, context, step_index)

                if result.status == StepStatus.COMPLETED:
                    return result

                # Failed, but may retry
                last_error = result.error
                if attempt < step.retry_count:
                    await logger.awarning(
                        "Step failed, retrying",
                        step_name=step.name,
                        attempt=attempt + 1,
                        max_attempts=step.retry_count + 1,
                        error=result.error,
                    )
                    await asyncio.sleep(2**attempt)  # Exponential backoff

            except Exception as e:
                last_error = str(e)
                if attempt < step.retry_count:
                    await logger.awarning(
                        "Step exception, retrying",
                        step_name=step.name,
                        attempt=attempt + 1,
                        error=str(e),
                    )
                    await asyncio.sleep(2**attempt)

        # All retries exhausted
        return StepResult(
            step_name=step.name,
            step_index=step_index,
            status=StepStatus.FAILED,
            error=last_error or "Max retries exceeded",
            completed_at=datetime.now(UTC),
        )

    async def _update_status(
        self,
        task: BackgroundTask,
        status: TaskStatus,
    ) -> None:
        """Update task status.

        Args:
            task: Task to update.
            status: New status.
        """
        try:
            progress = TaskProgress(
                task_id=task.id,
                status=status,
                current_step=None,
                step_index=0,
                total_steps=len(task.steps),
                percent=0 if status == TaskStatus.RUNNING else 100,
                message=f"Status: {status.value}",
                started_at=datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
            await self._manager.update_progress(task.id, progress)
        except Exception as e:
            await logger.aerror("Failed to update status", error=str(e))

    async def _update_progress(
        self,
        task: BackgroundTask,
        step_index: int,
        message: str,
    ) -> None:
        """Update task progress.

        Args:
            task: Task being executed.
            step_index: Current step index.
            message: Progress message.
        """
        try:
            total_steps = len(task.steps)
            percent = int((step_index / total_steps) * 100) if total_steps > 0 else 0

            progress = TaskProgress(
                task_id=task.id,
                status=TaskStatus.RUNNING,
                current_step=task.steps[step_index].name
                if step_index < total_steps
                else None,
                step_index=step_index,
                total_steps=total_steps,
                percent=percent,
                message=message,
                started_at=task.started_at or datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
            await self._manager.update_progress(task.id, progress)
        except Exception as e:
            await logger.aerror("Failed to update progress", error=str(e))

    async def _record_step_result(
        self,
        task_id: UUID,
        result: StepResult,
    ) -> None:
        """Record step result in history.

        Args:
            task_id: Task ID.
            result: Step result.
        """
        # TODO: Implement step history recording in manager
        await logger.adebug(
            "Step result",
            task_id=str(task_id),
            step_name=result.step_name,
            status=result.status.value,
            duration_ms=result.duration_ms,
        )

    async def _complete_task(
        self,
        task: BackgroundTask,
        results: dict,  # noqa: ARG002 - reserved for future result storage
    ) -> None:
        """Mark task as completed.

        Args:
            task: Completed task.
            results: All step results (reserved for future use).
        """
        _ = results  # Reserved for future result storage
        try:
            progress = TaskProgress(
                task_id=task.id,
                status=TaskStatus.COMPLETED,
                current_step=None,
                step_index=len(task.steps),
                total_steps=len(task.steps),
                percent=100,
                message="Task completed successfully",
                started_at=task.started_at or datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
            await self._manager.update_progress(task.id, progress)

            await logger.ainfo(
                "Task completed",
                task_id=str(task.id),
                task_type=task.task_type,
            )
        except Exception as e:
            await logger.aerror("Failed to complete task", error=str(e))

    async def _fail_task(self, task: BackgroundTask, error: str) -> None:
        """Mark task as failed.

        Args:
            task: Failed task.
            error: Error message.
        """
        try:
            progress = TaskProgress(
                task_id=task.id,
                status=TaskStatus.FAILED,
                current_step=None,
                step_index=0,
                total_steps=len(task.steps),
                percent=0,
                message=f"Task failed: {error}",
                started_at=task.started_at or datetime.now(UTC),
                updated_at=datetime.now(UTC),
            )
            await self._manager.update_progress(task.id, progress)

            await logger.aerror(
                "Task failed",
                task_id=str(task.id),
                task_type=task.task_type,
                error=error,
            )
        except Exception as e:
            await logger.aerror("Failed to mark task as failed", error=str(e))

    def _cleanup_completed(self) -> None:
        """Remove completed tasks from active set."""
        completed = [
            task_id for task_id, task in self._active_tasks.items() if task.done()
        ]
        for task_id in completed:
            del self._active_tasks[task_id]
