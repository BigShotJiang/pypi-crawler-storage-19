"""Context provider for background task awareness in conversations."""

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import structlog

from apps.api.background.models import BackgroundTask, TaskStatus
from apps.api.background.progress import ProgressTracker

if TYPE_CHECKING:
    from apps.api.background.manager import BackgroundTaskManager

logger = structlog.get_logger(__name__)


class BackgroundTaskContextProvider:
    """Provides context about background tasks for system prompts.

    Generates context strings that inform the AI about:
    - Active background tasks for the session
    - Recently completed tasks
    - Task progress updates

    Example:
        provider = BackgroundTaskContextProvider(manager, tracker)
        context = await provider.get_context("session-123")

        # Returns:
        # [Active Background Tasks]
        # - vulnerability_scan: "Q1 Security Scan" (running, 45%)
        # - report_generation: "Monthly Report" (pending)
    """

    def __init__(
        self,
        manager: "BackgroundTaskManager",
        tracker: ProgressTracker | None = None,
        max_tasks: int = 5,
        include_completed: bool = True,
        completed_window_hours: int = 24,
    ) -> None:
        """Initialize context provider.

        Args:
            manager: BackgroundTaskManager for task queries.
            tracker: Optional ProgressTracker for real-time progress.
            max_tasks: Maximum tasks to include in context.
            include_completed: Whether to include recently completed tasks.
            completed_window_hours: Hours to look back for completed tasks.
        """
        self._manager = manager
        self._tracker = tracker
        self._max_tasks = max_tasks
        self._include_completed = include_completed
        self._completed_window_hours = completed_window_hours

    async def get_context(self, session_id: str) -> str:
        """Generate context string for system prompt.

        Args:
            session_id: Session ID to get tasks for.

        Returns:
            Context string or empty string if no tasks.
        """
        try:
            tasks = await self._manager.get_active_tasks(session_id)

            if not tasks:
                return ""

            lines = ["[Active Background Tasks]"]

            for task in tasks[: self._max_tasks]:
                task_line = await self._format_task_line(task)
                lines.append(task_line)

            if len(tasks) > self._max_tasks:
                remaining = len(tasks) - self._max_tasks
                lines.append(f"  ... and {remaining} more task(s)")

            return "\n".join(lines)

        except Exception as e:
            await logger.awarning(
                "Failed to generate task context",
                session_id=session_id,
                error=str(e),
            )
            return ""

    async def get_full_context(self, session_id: str) -> str:
        """Generate full context including recently completed tasks.

        Args:
            session_id: Session ID.

        Returns:
            Full context string.
        """
        sections = []

        # Active tasks
        active_context = await self.get_context(session_id)
        if active_context:
            sections.append(active_context)

        # Recently completed (if enabled)
        if self._include_completed:
            completed_context = await self._get_completed_context(session_id)
            if completed_context:
                sections.append(completed_context)

        return "\n\n".join(sections)

    async def _get_completed_context(self, session_id: str) -> str:
        """Get context for recently completed tasks.

        Args:
            session_id: Session ID.

        Returns:
            Context string for completed tasks.
        """
        try:
            from apps.api.background.models import TaskFilter

            # Get recently completed tasks
            cutoff = datetime.now(UTC) - timedelta(hours=self._completed_window_hours)

            filter_obj = TaskFilter(
                session_id=session_id,
                status=TaskStatus.COMPLETED,
                limit=self._max_tasks,
            )

            tasks, _ = await self._manager.list_tasks(filter_obj)

            # Filter by completion time
            recent_tasks = [
                t for t in tasks if t.completed_at and t.completed_at >= cutoff
            ]

            if not recent_tasks:
                return ""

            lines = ["[Recently Completed Tasks]"]

            for task in recent_tasks:
                duration = self._format_duration(task)
                result_preview = self._get_result_preview(task)

                line = f'  - {task.task_type}: "{task.name}" (completed'
                if duration:
                    line += f", {duration}"
                line += ")"
                if result_preview:
                    line += f"\n    Result: {result_preview}"

                lines.append(line)

            return "\n".join(lines)

        except Exception as e:
            await logger.awarning(
                "Failed to get completed task context",
                session_id=session_id,
                error=str(e),
            )
            return ""

    async def _format_task_line(self, task: BackgroundTask) -> str:
        """Format a single task for context.

        Args:
            task: Task to format.

        Returns:
            Formatted task line.
        """
        status_str = task.status.value

        # Try to get real-time progress
        progress_str = ""
        if self._tracker and task.status == TaskStatus.RUNNING:
            progress = await self._tracker.get_progress(task.id)
            if progress:
                progress_str = f", {progress.percent}%"
                if progress.current_step:
                    progress_str += f" - {progress.current_step}"

        line = f'  - {task.task_type}: "{task.name}" ({status_str}{progress_str})'

        return line

    def _format_duration(self, task: BackgroundTask) -> str | None:
        """Format task duration.

        Args:
            task: Completed task.

        Returns:
            Duration string or None.
        """
        if not task.started_at or not task.completed_at:
            return None

        duration = (task.completed_at - task.started_at).total_seconds()

        if duration < 60:
            return f"{duration:.0f}s"
        elif duration < 3600:
            minutes = int(duration / 60)
            return f"{minutes}m"
        else:
            hours = int(duration / 3600)
            minutes = int((duration % 3600) / 60)
            return f"{hours}h {minutes}m"

    def _get_result_preview(self, task: BackgroundTask) -> str | None:
        """Get preview of task result.

        Args:
            task: Completed task.

        Returns:
            Result preview or None.
        """
        if not task.result:
            return None

        # Try to get a summary from the result
        if isinstance(task.result, dict):
            # Look for common summary fields
            for key in ["summary", "message", "status", "count", "total"]:
                if key in task.result:
                    value = task.result[key]
                    if isinstance(value, str) and len(value) > 100:
                        return value[:100] + "..."
                    return str(value)

        # Truncate if too long
        preview = str(task.result)
        if len(preview) > 100:
            return preview[:100] + "..."

        return preview

    async def get_task_notification_context(
        self,
        task: BackgroundTask,
        include_result: bool = True,
    ) -> str:
        """Generate notification context for a completed task.

        Used when notifying about task completion.

        Args:
            task: Completed task.
            include_result: Whether to include result preview.

        Returns:
            Notification context string.
        """
        status_emoji = {
            TaskStatus.COMPLETED: "✅",
            TaskStatus.FAILED: "❌",
            TaskStatus.CANCELLED: "⚠️",
        }.get(task.status, "ℹ️")

        lines = [
            f"{status_emoji} Background task completed:",
            f"  Task: {task.name} ({task.task_type})",
            f"  Status: {task.status.value}",
        ]

        # Add duration
        duration = self._format_duration(task)
        if duration:
            lines.append(f"  Duration: {duration}")

        # Add result preview
        if include_result and task.status == TaskStatus.COMPLETED:
            preview = self._get_result_preview(task)
            if preview:
                lines.append(f"  Result: {preview}")

        # Add error for failed tasks
        if task.status == TaskStatus.FAILED and task.error_details:
            error_msg = task.error_details.get("message", "Unknown error")
            if len(error_msg) > 150:
                error_msg = error_msg[:150] + "..."
            lines.append(f"  Error: {error_msg}")

        return "\n".join(lines)


# Factory function
def create_context_provider(
    manager: "BackgroundTaskManager",
    tracker: ProgressTracker | None = None,
) -> BackgroundTaskContextProvider:
    """Create a BackgroundTaskContextProvider.

    Args:
        manager: BackgroundTaskManager instance.
        tracker: Optional ProgressTracker.

    Returns:
        Configured BackgroundTaskContextProvider.
    """
    return BackgroundTaskContextProvider(
        manager=manager,
        tracker=tracker,
        max_tasks=5,
        include_completed=True,
        completed_window_hours=24,
    )
