"""Progress tracking for background tasks using Redis."""

from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import UUID

import structlog

from apps.api.background.models import TaskProgress, TaskStatus

if TYPE_CHECKING:
    import redis.asyncio as redis

logger = structlog.get_logger(__name__)


class ProgressTracker:
    """Redis-based progress tracker for background tasks.

    Provides real-time progress updates and pub/sub notifications.

    Example:
        tracker = ProgressTracker(redis_client)

        # Update progress
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            step_index=1,
            total_steps=3,
            percent=33,
        )
        await tracker.update_progress(task_id, progress)

        # Get progress
        progress = await tracker.get_progress(task_id)
    """

    def __init__(
        self,
        redis_client: "redis.Redis | None" = None,
        key_prefix: str = "task",
        ttl_seconds: int = 86400,  # 24 hours
    ) -> None:
        """Initialize progress tracker.

        Args:
            redis_client: Redis async client. If None, creates on first use.
            key_prefix: Prefix for Redis keys.
            ttl_seconds: TTL for progress data.
        """
        self._redis = redis_client
        self._key_prefix = key_prefix
        self._ttl = ttl_seconds

    async def _get_redis(self) -> "redis.Redis":
        """Get or create Redis client.

        Returns:
            Redis client.

        Raises:
            RuntimeError: If Redis not configured.
        """
        if self._redis is None:
            import redis.asyncio as redis_pkg

            self._redis = redis_pkg.from_url(
                "redis://localhost:6379", decode_responses=True
            )
        return self._redis

    def _progress_key(self, task_id: UUID) -> str:
        """Get Redis key for task progress.

        Args:
            task_id: Task ID.

        Returns:
            Redis key string.
        """
        return f"{self._key_prefix}:{task_id}:progress"

    def _channel_key(self, task_id: UUID) -> str:
        """Get Redis pub/sub channel for task.

        Args:
            task_id: Task ID.

        Returns:
            Channel name string.
        """
        return f"{self._key_prefix}:{task_id}"

    async def update_progress(
        self,
        task_id: UUID,
        progress: TaskProgress,
    ) -> None:
        """Update task progress in Redis.

        Stores progress data and publishes update notification.

        Args:
            task_id: Task ID.
            progress: Progress data.
        """
        redis_client = await self._get_redis()
        key = self._progress_key(task_id)

        try:
            # Store progress
            await redis_client.set(
                key,
                progress.model_dump_json(),
                ex=self._ttl,
            )

            # Publish update notification
            channel = self._channel_key(task_id)
            await redis_client.publish(channel, "update")

            await logger.adebug(
                "Progress updated",
                task_id=str(task_id),
                status=progress.status.value,
                percent=progress.percent,
            )

        except Exception as e:
            await logger.aerror(
                "Failed to update progress",
                task_id=str(task_id),
                error=str(e),
            )
            raise

    async def get_progress(self, task_id: UUID) -> TaskProgress | None:
        """Get current task progress.

        Args:
            task_id: Task ID.

        Returns:
            TaskProgress or None if not found.
        """
        redis_client = await self._get_redis()
        key = self._progress_key(task_id)

        try:
            data = await redis_client.get(key)
            if data:
                return TaskProgress.model_validate_json(data)
            return None

        except Exception as e:
            await logger.aerror(
                "Failed to get progress",
                task_id=str(task_id),
                error=str(e),
            )
            return None

    async def delete_progress(self, task_id: UUID) -> bool:
        """Delete task progress data.

        Args:
            task_id: Task ID.

        Returns:
            True if deleted, False if not found.
        """
        redis_client = await self._get_redis()
        key = self._progress_key(task_id)

        try:
            result = await redis_client.delete(key)
            return result > 0

        except Exception as e:
            await logger.aerror(
                "Failed to delete progress",
                task_id=str(task_id),
                error=str(e),
            )
            return False

    async def subscribe_progress(
        self,
        task_id: UUID,
    ) -> "redis.client.PubSub":
        """Subscribe to task progress updates.

        Returns a pub/sub subscription for real-time updates.

        Args:
            task_id: Task ID.

        Returns:
            PubSub instance for listening to updates.
        """
        redis_client = await self._get_redis()
        channel = self._channel_key(task_id)

        pubsub = redis_client.pubsub()
        await pubsub.subscribe(channel)

        await logger.adebug(
            "Subscribed to progress",
            task_id=str(task_id),
            channel=channel,
        )

        return pubsub

    async def publish_completion(
        self,
        task_id: UUID,
        status: TaskStatus,
    ) -> None:
        """Publish task completion event.

        Args:
            task_id: Task ID.
            status: Final task status.
        """
        redis_client = await self._get_redis()
        channel = self._channel_key(task_id)

        try:
            message = f"complete:{status.value}"
            await redis_client.publish(channel, message)

            await logger.ainfo(
                "Published completion",
                task_id=str(task_id),
                status=status.value,
            )

        except Exception as e:
            await logger.aerror(
                "Failed to publish completion",
                task_id=str(task_id),
                error=str(e),
            )

    async def get_active_tasks(self, pattern: str | None = None) -> list[UUID]:
        """Get list of active task IDs.

        Args:
            pattern: Optional pattern to filter tasks.

        Returns:
            List of task UUIDs with active progress.
        """
        redis_client = await self._get_redis()
        key_pattern = f"{self._key_prefix}:*:progress"

        if pattern:
            key_pattern = f"{self._key_prefix}:{pattern}:progress"

        try:
            keys = []
            async for key in redis_client.scan_iter(key_pattern):
                keys.append(key)

            # Extract UUIDs from keys
            task_ids = []
            for key in keys:
                parts = key.split(":")
                if len(parts) >= 2:
                    try:
                        task_ids.append(UUID(parts[1]))
                    except ValueError:
                        continue

            return task_ids

        except Exception as e:
            await logger.aerror(
                "Failed to get active tasks",
                error=str(e),
            )
            return []

    async def set_step_progress(
        self,
        task_id: UUID,
        step_name: str,
        step_index: int,
        total_steps: int,
        message: str | None = None,
    ) -> None:
        """Convenience method to update step progress.

        Args:
            task_id: Task ID.
            step_name: Current step name.
            step_index: Current step index.
            total_steps: Total number of steps.
            message: Optional progress message.
        """
        percent = int((step_index / total_steps) * 100) if total_steps > 0 else 0

        now = datetime.now(UTC)
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            current_step=step_name,
            step_index=step_index,
            total_steps=total_steps,
            percent=percent,
            message=message or f"Running: {step_name}",
            started_at=now,
            updated_at=now,
        )

        await self.update_progress(task_id, progress)


# Global progress tracker instance
_progress_tracker: ProgressTracker | None = None


def get_progress_tracker() -> ProgressTracker:
    """Get or create global progress tracker.

    Returns:
        ProgressTracker instance.
    """
    global _progress_tracker
    if _progress_tracker is None:
        _progress_tracker = ProgressTracker()
    return _progress_tracker


def reset_progress_tracker() -> None:
    """Reset global progress tracker (for testing)."""
    global _progress_tracker
    _progress_tracker = None
