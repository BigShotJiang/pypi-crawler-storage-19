"""Multi-channel notifications for background tasks."""

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

import httpx
import structlog
from pydantic import BaseModel, ConfigDict, Field

from apps.api.background.models import BackgroundTask, TaskStatus

if TYPE_CHECKING:
    pass

logger = structlog.get_logger(__name__)


class NotificationResult(BaseModel):
    """Result of a notification attempt."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    channel: str
    success: bool
    error: str | None = None
    sent_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class TaskResult(BaseModel):
    """Summary of task completion."""

    model_config = ConfigDict(extra="forbid")

    task_id: UUID
    task_type: str
    task_name: str
    status: TaskStatus
    started_at: datetime | None = None
    completed_at: datetime | None = None
    duration_seconds: float | None = None
    steps_completed: int = 0
    steps_total: int = 0
    output: dict | None = None
    error: str | None = None


class TaskNotifier:
    """Multi-channel notification service for background tasks.

    Supports notification channels:
    - conversation: Notify back to the conversation session
    - slack: Send to Slack webhook
    - webhook: Send to custom webhook URL

    Example:
        notifier = TaskNotifier()

        result = TaskResult(
            task_id=task_id,
            task_type="vulnerability_scan",
            task_name="Q1 Security Scan",
            status=TaskStatus.COMPLETED,
        )

        await notifier.notify_completion(task, result)
    """

    def __init__(
        self,
        slack_webhook_url: str | None = None,
        conversation_callback: Any = None,
        default_timeout: float = 10.0,
    ) -> None:
        """Initialize notifier.

        Args:
            slack_webhook_url: Slack incoming webhook URL.
            conversation_callback: Callback for conversation notifications.
            default_timeout: HTTP request timeout in seconds.
        """
        self._slack_webhook = slack_webhook_url
        self._conversation_callback = conversation_callback
        self._timeout = default_timeout
        self._http_client: httpx.AsyncClient | None = None

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client.

        Returns:
            Async HTTP client.
        """
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(timeout=self._timeout)
        return self._http_client

    async def close(self) -> None:
        """Close HTTP client."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    async def notify_completion(
        self,
        task: BackgroundTask,
        result: TaskResult,
    ) -> list[NotificationResult]:
        """Send completion notifications to all configured channels.

        Args:
            task: The completed task.
            result: Task result summary.

        Returns:
            List of notification results.
        """
        results = []

        # Generate summary
        summary = self._generate_summary(task, result)

        # Send to each channel
        for channel in task.notification_channels:
            try:
                if channel == "conversation":
                    notification_result = await self._notify_conversation(
                        task, result, summary
                    )
                elif channel == "slack":
                    notification_result = await self._notify_slack(
                        task, result, summary
                    )
                elif channel.startswith("webhook:"):
                    webhook_url = channel.split(":", 1)[1]
                    notification_result = await self._notify_webhook(
                        task, result, summary, webhook_url
                    )
                else:
                    notification_result = NotificationResult(
                        channel=channel,
                        success=False,
                        error=f"Unknown channel: {channel}",
                    )

                results.append(notification_result)

            except Exception as e:
                await logger.aerror(
                    "Notification failed",
                    channel=channel,
                    task_id=str(task.id),
                    error=str(e),
                )
                results.append(
                    NotificationResult(
                        channel=channel,
                        success=False,
                        error=str(e),
                    )
                )

        return results

    def _generate_summary(
        self,
        task: BackgroundTask,
        result: TaskResult,
    ) -> str:
        """Generate human-readable task summary.

        Args:
            task: The completed task.
            result: Task result summary.

        Returns:
            Summary string.
        """
        status_emoji = {
            TaskStatus.COMPLETED: "✅",
            TaskStatus.FAILED: "❌",
            TaskStatus.CANCELLED: "⚠️",
        }.get(result.status, "ℹ️")

        lines = [
            f"{status_emoji} **{task.name}** ({task.task_type})",
        ]

        if result.status == TaskStatus.COMPLETED:
            lines.append("Status: Completed successfully")
            if result.steps_completed > 0:
                lines.append(
                    f"Steps: {result.steps_completed}/{result.steps_total} completed"
                )
        elif result.status == TaskStatus.FAILED:
            lines.append("Status: Failed")
            if result.error:
                # Truncate error for notifications
                error_preview = result.error[:200]
                if len(result.error) > 200:
                    error_preview += "..."
                lines.append(f"Error: {error_preview}")
        elif result.status == TaskStatus.CANCELLED:
            lines.append("Status: Cancelled")

        if result.duration_seconds:
            duration = self._format_duration(result.duration_seconds)
            lines.append(f"Duration: {duration}")

        return "\n".join(lines)

    def _format_duration(self, seconds: float) -> str:
        """Format duration in human-readable form.

        Args:
            seconds: Duration in seconds.

        Returns:
            Formatted string.
        """
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            secs = int(seconds % 60)
            return f"{minutes}m {secs}s"
        else:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}h {minutes}m"

    async def _notify_conversation(
        self,
        task: BackgroundTask,
        result: TaskResult,
        summary: str,
    ) -> NotificationResult:
        """Notify back to conversation session.

        Args:
            task: The completed task.
            result: Task result.
            summary: Generated summary.

        Returns:
            NotificationResult.
        """
        try:
            if self._conversation_callback:
                await self._conversation_callback(
                    session_id=task.created_by_session_id,
                    task_id=task.id,
                    message=summary,
                    result=result.model_dump(),
                )
                await logger.ainfo(
                    "Conversation notification sent",
                    task_id=str(task.id),
                    session_id=task.created_by_session_id,
                )
                return NotificationResult(channel="conversation", success=True)
            else:
                # Log for session to pick up
                await logger.ainfo(
                    "Task completed (conversation notification)",
                    task_id=str(task.id),
                    session_id=task.created_by_session_id,
                    summary=summary,
                )
                return NotificationResult(channel="conversation", success=True)

        except Exception as e:
            return NotificationResult(
                channel="conversation",
                success=False,
                error=str(e),
            )

    async def _notify_slack(
        self,
        task: BackgroundTask,
        result: TaskResult,
        summary: str,
    ) -> NotificationResult:
        """Send notification to Slack.

        Args:
            task: The completed task.
            result: Task result.
            summary: Generated summary.

        Returns:
            NotificationResult.
        """
        if not self._slack_webhook:
            return NotificationResult(
                channel="slack",
                success=False,
                error="Slack webhook not configured",
            )

        try:
            client = await self._get_http_client()

            # Build Slack message
            color = {
                TaskStatus.COMPLETED: "good",
                TaskStatus.FAILED: "danger",
                TaskStatus.CANCELLED: "warning",
            }.get(result.status, "#808080")

            payload = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"Background Task: {task.name}",
                        "text": summary,
                        "footer": f"Task ID: {task.id}",
                        "ts": int(datetime.now(UTC).timestamp()),
                    }
                ]
            }

            response = await client.post(
                self._slack_webhook,
                json=payload,
            )

            if response.status_code == 200:
                await logger.ainfo(
                    "Slack notification sent",
                    task_id=str(task.id),
                )
                return NotificationResult(channel="slack", success=True)
            else:
                return NotificationResult(
                    channel="slack",
                    success=False,
                    error=f"Slack API error: {response.status_code}",
                )

        except Exception as e:
            return NotificationResult(
                channel="slack",
                success=False,
                error=str(e),
            )

    async def _notify_webhook(
        self,
        task: BackgroundTask,
        result: TaskResult,
        summary: str,
        webhook_url: str,
    ) -> NotificationResult:
        """Send notification to custom webhook.

        Args:
            task: The completed task.
            result: Task result.
            summary: Generated summary.
            webhook_url: Webhook URL.

        Returns:
            NotificationResult.
        """
        try:
            client = await self._get_http_client()

            # Don't expose sensitive data in webhook
            payload = {
                "task_id": str(task.id),
                "task_type": task.task_type,
                "task_name": task.name,
                "status": result.status.value,
                "summary": summary,
                "completed_at": (
                    result.completed_at.isoformat() if result.completed_at else None
                ),
                "duration_seconds": result.duration_seconds,
            }

            response = await client.post(
                webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
            )

            if response.status_code in (200, 201, 202, 204):
                await logger.ainfo(
                    "Webhook notification sent",
                    task_id=str(task.id),
                    webhook_url=webhook_url,
                )
                return NotificationResult(
                    channel=f"webhook:{webhook_url}", success=True
                )
            else:
                return NotificationResult(
                    channel=f"webhook:{webhook_url}",
                    success=False,
                    error=f"Webhook error: {response.status_code}",
                )

        except Exception as e:
            return NotificationResult(
                channel=f"webhook:{webhook_url}",
                success=False,
                error=str(e),
            )

    async def notify_progress(
        self,
        task: BackgroundTask,
        step_name: str,
        step_index: int,
        total_steps: int,
        message: str | None = None,
    ) -> None:
        """Send progress notification (for long-running steps).

        Only sends to conversation channel.

        Args:
            task: The running task.
            step_name: Current step name.
            step_index: Current step index.
            total_steps: Total steps.
            message: Optional message.
        """
        if "conversation" not in task.notification_channels:
            return

        percent = int((step_index / total_steps) * 100) if total_steps > 0 else 0
        progress_bar = self._make_progress_bar(percent)

        progress_message = (
            f"📊 **{task.name}** ({task.task_type})\n"
            f"Step {step_index + 1}/{total_steps}: {step_name}\n"
            f"{progress_bar} {percent}%"
        )

        if message:
            progress_message += f"\n{message}"

        try:
            if self._conversation_callback:
                await self._conversation_callback(
                    session_id=task.created_by_session_id,
                    task_id=task.id,
                    message=progress_message,
                    is_progress=True,
                )

        except Exception as e:
            await logger.awarning(
                "Progress notification failed",
                task_id=str(task.id),
                error=str(e),
            )

    def _make_progress_bar(self, percent: int, width: int = 20) -> str:
        """Create ASCII progress bar.

        Args:
            percent: Completion percentage.
            width: Bar width in characters.

        Returns:
            Progress bar string.
        """
        filled = int(width * percent / 100)
        empty = width - filled
        return f"[{'█' * filled}{'░' * empty}]"


# Global notifier instance
_notifier: TaskNotifier | None = None


def get_task_notifier() -> TaskNotifier:
    """Get or create global task notifier.

    Returns:
        TaskNotifier instance.
    """
    global _notifier
    if _notifier is None:
        _notifier = TaskNotifier()
    return _notifier


def reset_task_notifier() -> None:
    """Reset global notifier (for testing)."""
    global _notifier
    _notifier = None
