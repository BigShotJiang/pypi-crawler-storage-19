"""API routes for background task management."""

from typing import Annotated
from uuid import UUID

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field

from apps.api.auth.dependencies import CurrentUserDep
from apps.api.background.exceptions import (
    TaskLimitExceededError,
    TaskNotFoundError,
    TaskTemplateNotFoundError,
)
from apps.api.background.manager import BackgroundTaskManager
from apps.api.background.models import (
    BackgroundTask,
    BackgroundTaskCreate,
    TaskFilter,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskStep,
    TaskTemplate,
    TaskTemplateCreate,
)
from apps.api.background.progress import ProgressTracker, get_progress_tracker

logger = structlog.get_logger(__name__)

router = APIRouter(prefix="/background-tasks", tags=["background-tasks"])


# Request/Response models
class TaskCreateRequest(BaseModel):
    """Request to create a background task."""

    model_config = ConfigDict(extra="forbid")

    task_type: str = Field(max_length=100)
    name: str = Field(max_length=255)
    steps: list[TaskStep] = Field(min_length=1, max_length=20)
    payload: dict = Field(default_factory=dict)
    notification_channels: list[str] = Field(default_factory=lambda: ["conversation"])
    priority: TaskPriority = Field(default=TaskPriority.NORMAL)


class TaskFromTemplateRequest(BaseModel):
    """Request to create task from template."""

    model_config = ConfigDict(extra="forbid")

    template_id: UUID
    name: str | None = None
    payload: dict = Field(default_factory=dict)
    notification_channels: list[str] = Field(default_factory=lambda: ["conversation"])


class TaskListResponse(BaseModel):
    """Response for task list."""

    model_config = ConfigDict(extra="forbid")

    tasks: list[BackgroundTask]
    total: int
    offset: int
    limit: int


class TaskStatusResponse(BaseModel):
    """Response for task status check."""

    model_config = ConfigDict(extra="forbid")

    task_id: UUID
    status: TaskStatus
    progress: TaskProgress | None = None
    result: dict | None = None
    error: str | None = None


class TemplateListResponse(BaseModel):
    """Response for template list."""

    model_config = ConfigDict(extra="forbid")

    templates: list[TaskTemplate]
    total: int


# Dependency
def get_background_task_manager() -> BackgroundTaskManager:
    """Get BackgroundTaskManager instance.

    Note: This should be overridden with app dependency injection.
    """
    raise NotImplementedError(
        "BackgroundTaskManager dependency not configured. "
        "Use app.dependency_overrides to provide implementation."
    )


ManagerDep = Annotated[BackgroundTaskManager, Depends(get_background_task_manager)]
TrackerDep = Annotated[ProgressTracker, Depends(get_progress_tracker)]


async def _check_task_ownership(
    task_id: UUID,
    manager: BackgroundTaskManager,
    user_id: str,
) -> BackgroundTask:
    """Get task and verify ownership.

    Args:
        task_id: Task UUID.
        manager: BackgroundTaskManager instance.
        user_id: Current user's ID.

    Returns:
        BackgroundTask if owned by user.

    Raises:
        HTTPException: 404 if not found, 403 if not owned.
    """
    try:
        task = await manager.get_task(task_id)
    except TaskNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e

    if task.created_by_session_id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    return task


# Task endpoints
@router.post(
    "/",
    response_model=BackgroundTask,
    status_code=status.HTTP_201_CREATED,
    summary="Create background task",
)
async def create_task(
    request: TaskCreateRequest,
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> BackgroundTask:
    """Create a new background task.

    The task will be queued for execution by the background worker.

    Args:
        request: Task creation request.
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user (session scope derived from user ID).

    Returns:
        Created BackgroundTask.

    Raises:
        HTTPException: If task limit exceeded or validation fails.
    """
    # Derive session_id from authenticated user
    session_id = str(current_user.id)

    try:
        task_create = BackgroundTaskCreate(
            task_type=request.task_type,
            name=request.name,
            steps=request.steps,
            payload=request.payload,
            notification_channels=request.notification_channels,
            priority=request.priority,
        )

        task = await manager.create_task(task_create, session_id=session_id)

        await logger.ainfo(
            "Background task created",
            task_id=str(task.id),
            task_type=task.task_type,
            session_id=session_id,
        )

        return task

    except TaskLimitExceededError as e:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(e),
        ) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.post(
    "/from-template",
    response_model=BackgroundTask,
    status_code=status.HTTP_201_CREATED,
    summary="Create task from template",
)
async def create_task_from_template(
    request: TaskFromTemplateRequest,
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> BackgroundTask:
    """Create a background task from a template.

    Args:
        request: Template-based task creation request.
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user (session scope derived from user ID).

    Returns:
        Created BackgroundTask.

    Raises:
        HTTPException: If template not found or limit exceeded.
    """
    # Derive session_id from authenticated user
    session_id = str(current_user.id)

    try:
        task = await manager.create_from_template(
            template_id=request.template_id,
            name=request.name,
            payload=request.payload,
            notification_channels=request.notification_channels,
            session_id=session_id,
        )

        await logger.ainfo(
            "Task created from template",
            task_id=str(task.id),
            template_id=str(request.template_id),
            session_id=session_id,
        )

        return task

    except TaskTemplateNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e
    except TaskLimitExceededError as e:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=str(e),
        ) from e


@router.get(
    "/",
    response_model=TaskListResponse,
    summary="List background tasks",
)
async def list_tasks(
    manager: ManagerDep,
    current_user: CurrentUserDep,
    status_filter: Annotated[TaskStatus | None, Query(alias="status")] = None,
    task_type: Annotated[str | None, Query(max_length=100)] = None,
    priority: Annotated[TaskPriority | None, Query()] = None,
    offset: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=100)] = 20,
) -> TaskListResponse:
    """List background tasks for the current user.

    Args:
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user.
        status_filter: Filter by task status.
        task_type: Filter by task type.
        priority: Filter by priority.
        offset: Pagination offset.
        limit: Pagination limit.

    Returns:
        TaskListResponse with tasks and pagination info.
    """
    # Force filter to current user's tasks only
    session_id = str(current_user.id)

    filter_obj = TaskFilter(
        status=status_filter,
        task_type=task_type,
        session_id=session_id,
        priority=priority,
        offset=offset,
        limit=limit,
    )

    tasks, total = await manager.list_tasks(filter_obj)

    return TaskListResponse(
        tasks=tasks,
        total=total,
        offset=offset,
        limit=limit,
    )


# Session-specific endpoints (must be before /{task_id} to avoid route conflicts)
@router.get(
    "/my-active",
    response_model=list[BackgroundTask],
    summary="Get active tasks for current user",
)
async def get_my_active_tasks(
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> list[BackgroundTask]:
    """Get all active (pending, running, paused) tasks for the current user.

    Args:
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user.

    Returns:
        List of active BackgroundTasks.
    """
    session_id = str(current_user.id)
    tasks = await manager.get_active_tasks(session_id)
    return tasks


@router.get(
    "/{task_id}",
    response_model=BackgroundTask,
    summary="Get task details",
)
async def get_task(
    task_id: UUID,
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> BackgroundTask:
    """Get details of a specific background task.

    Args:
        task_id: Task UUID.
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user.

    Returns:
        BackgroundTask details.

    Raises:
        HTTPException: If task not found or access denied.
    """
    task = await _check_task_ownership(task_id, manager, str(current_user.id))
    return task


@router.get(
    "/{task_id}/status",
    response_model=TaskStatusResponse,
    summary="Get task status",
)
async def get_task_status(
    task_id: UUID,
    manager: ManagerDep,
    tracker: TrackerDep,
    current_user: CurrentUserDep,
) -> TaskStatusResponse:
    """Get current status and progress of a task.

    Uses Redis for real-time progress if available.

    Args:
        task_id: Task UUID.
        manager: BackgroundTaskManager instance.
        tracker: ProgressTracker instance.
        current_user: Authenticated user.

    Returns:
        TaskStatusResponse with status and progress.

    Raises:
        HTTPException: If task not found or access denied.
    """
    task = await _check_task_ownership(task_id, manager, str(current_user.id))

    # Try to get real-time progress from Redis
    progress = await tracker.get_progress(task_id)

    return TaskStatusResponse(
        task_id=task_id,
        status=task.status,
        progress=progress,
        result=task.result,
        error=task.error_details.get("message") if task.error_details else None,
    )


@router.post(
    "/{task_id}/cancel",
    response_model=BackgroundTask,
    summary="Cancel task",
)
async def cancel_task(
    task_id: UUID,
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> BackgroundTask:
    """Cancel a pending or running task.

    Args:
        task_id: Task UUID.
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user.

    Returns:
        Updated BackgroundTask.

    Raises:
        HTTPException: If task not found, access denied, or cannot be cancelled.
    """
    # Verify ownership first
    await _check_task_ownership(task_id, manager, str(current_user.id))

    try:
        task = await manager.cancel_task(task_id)

        await logger.ainfo(
            "Task cancelled",
            task_id=str(task_id),
        )

        return task

    except TaskNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.delete(
    "/{task_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete task",
)
async def delete_task(
    task_id: UUID,
    manager: ManagerDep,
    current_user: CurrentUserDep,
) -> None:
    """Delete a background task.

    Only completed, failed, or cancelled tasks can be deleted.

    Args:
        task_id: Task UUID.
        manager: BackgroundTaskManager instance.
        current_user: Authenticated user.

    Raises:
        HTTPException: If task not found, access denied, or cannot be deleted.
    """
    # Verify ownership first
    await _check_task_ownership(task_id, manager, str(current_user.id))

    try:
        await manager.delete_task(task_id)

        await logger.ainfo(
            "Task deleted",
            task_id=str(task_id),
        )

    except TaskNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


# Template endpoints
@router.get(
    "/templates/",
    response_model=TemplateListResponse,
    summary="List task templates",
)
async def list_templates(
    manager: ManagerDep,
    enabled_only: Annotated[bool, Query()] = True,
) -> TemplateListResponse:
    """List available task templates.

    Args:
        manager: BackgroundTaskManager instance.
        enabled_only: Whether to return only enabled templates.

    Returns:
        TemplateListResponse with templates.
    """
    templates = await manager.list_templates(enabled_only=enabled_only)

    return TemplateListResponse(
        templates=templates,
        total=len(templates),
    )


@router.get(
    "/templates/{template_id}",
    response_model=TaskTemplate,
    summary="Get template details",
)
async def get_template(
    template_id: UUID,
    manager: ManagerDep,
) -> TaskTemplate:
    """Get details of a specific task template.

    Args:
        template_id: Template UUID.
        manager: BackgroundTaskManager instance.

    Returns:
        TaskTemplate details.

    Raises:
        HTTPException: If template not found.
    """
    try:
        template = await manager.get_template(template_id)
        return template

    except TaskTemplateNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        ) from e


@router.post(
    "/templates/",
    response_model=TaskTemplate,
    status_code=status.HTTP_201_CREATED,
    summary="Create task template",
)
async def create_template(
    template: TaskTemplateCreate,
    manager: ManagerDep,
) -> TaskTemplate:
    """Create a new task template.

    Args:
        template: Template creation data.
        manager: BackgroundTaskManager instance.

    Returns:
        Created TaskTemplate.

    Raises:
        HTTPException: If validation fails.
    """
    try:
        created = await manager.create_template(template)

        await logger.ainfo(
            "Task template created",
            template_id=str(created.id),
            task_type=created.task_type,
        )

        return created

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e
