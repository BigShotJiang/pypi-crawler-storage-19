"""Pydantic models for Background Task Runner."""

from datetime import datetime
from enum import Enum
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class TaskStatus(str, Enum):
    """Task execution status."""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(str, Enum):
    """Task priority levels."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class StepStatus(str, Enum):
    """Step execution status."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


# =============================================================================
# Step Models
# =============================================================================


class TaskStep(BaseModel):
    """Single step in a multi-step task."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(max_length=100, description="Step name")
    executor: Literal["python", "ai"] = Field(
        description="Executor type: 'python' for code, 'ai' for Claude"
    )
    config: dict = Field(
        default_factory=dict,
        description="Step-specific configuration",
    )
    timeout_seconds: int = Field(
        default=300,
        ge=1,
        le=3600,
        description="Step timeout (1-3600 seconds)",
    )
    retry_count: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Max retry attempts",
    )
    continue_on_failure: bool = Field(
        default=False,
        description="Continue to next step on failure",
    )


class StepResult(BaseModel):
    """Result of a step execution."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    step_name: str
    step_index: int
    status: StepStatus
    output: dict | None = None
    error: str | None = None
    tokens_used: int | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    duration_ms: int | None = None


# =============================================================================
# Task Models
# =============================================================================


class BackgroundTaskCreate(BaseModel):
    """Request to create a new background task."""

    model_config = ConfigDict(extra="forbid")

    task_type: str = Field(
        max_length=100,
        description="Task type identifier",
    )
    name: str = Field(
        max_length=255,
        description="Human-readable task name",
    )
    steps: list[TaskStep] = Field(
        min_length=1,
        max_length=20,
        description="Ordered list of execution steps",
    )
    payload: dict = Field(
        default_factory=dict,
        description="Input data for task",
    )
    notification_channels: list[str] = Field(
        default_factory=lambda: ["conversation"],
        description="Notification channels on completion",
    )
    timeout_seconds: int = Field(
        default=3600,
        ge=60,
        le=86400,
        description="Total task timeout (60-86400 seconds)",
    )
    priority: TaskPriority = Field(
        default=TaskPriority.NORMAL,
        description="Task priority",
    )


class BackgroundTask(BaseModel):
    """Full background task model."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    task_type: str = Field(max_length=100)
    name: str = Field(max_length=255)
    steps: list[TaskStep]
    payload: dict = Field(default_factory=dict)
    created_by_session_id: str | None = None
    notification_channels: list[str] = Field(default_factory=lambda: ["conversation"])
    timeout_seconds: int = Field(default=3600, ge=60, le=86400)
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    progress: dict | None = None
    result: dict | None = None
    error_details: dict | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class BackgroundTaskUpdate(BaseModel):
    """Partial update for a background task."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, max_length=255)
    notification_channels: list[str] | None = None
    priority: TaskPriority | None = None


# =============================================================================
# Progress Models
# =============================================================================


class TaskProgress(BaseModel):
    """Real-time progress tracking."""

    model_config = ConfigDict(extra="forbid")

    task_id: UUID
    status: TaskStatus
    current_step: str | None = None
    step_index: int = 0
    total_steps: int
    percent: int = Field(ge=0, le=100)
    message: str
    started_at: datetime
    updated_at: datetime
    estimated_completion: datetime | None = None


# =============================================================================
# Template Models
# =============================================================================


class TaskTemplateCreate(BaseModel):
    """Request to create a task template."""

    model_config = ConfigDict(extra="forbid")

    task_type: str = Field(
        max_length=100,
        description="Unique task type identifier",
    )
    name: str = Field(
        max_length=255,
        description="Template display name",
    )
    description: str | None = Field(
        default=None,
        max_length=2000,
        description="Template description",
    )
    steps: list[TaskStep] = Field(
        min_length=1,
        max_length=20,
        description="Default steps for this task type",
    )
    default_config: dict = Field(
        default_factory=dict,
        description="Default configuration values",
    )
    timeout_seconds: int = Field(
        default=3600,
        ge=60,
        le=86400,
        description="Default timeout",
    )


class TaskTemplate(BaseModel):
    """Full task template model."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    task_type: str = Field(max_length=100)
    name: str = Field(max_length=255)
    description: str | None = None
    steps: list[TaskStep]
    default_config: dict = Field(default_factory=dict)
    timeout_seconds: int = Field(default=3600)
    enabled: bool = True
    created_at: datetime
    updated_at: datetime


class TaskTemplateUpdate(BaseModel):
    """Partial update for a task template."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, max_length=255)
    description: str | None = Field(default=None, max_length=2000)
    steps: list[TaskStep] | None = None
    default_config: dict | None = None
    timeout_seconds: int | None = Field(default=None, ge=60, le=86400)
    enabled: bool | None = None


# =============================================================================
# Filter Models
# =============================================================================


class TaskFilter(BaseModel):
    """Filter for listing tasks."""

    model_config = ConfigDict(extra="forbid")

    status: TaskStatus | None = None
    task_type: str | None = None
    session_id: str | None = None
    priority: TaskPriority | None = None
    limit: int = Field(default=20, ge=1, le=100)
    offset: int = Field(default=0, ge=0)


# =============================================================================
# Response Models
# =============================================================================


class TaskResponse(BaseModel):
    """API response for a task."""

    model_config = ConfigDict(extra="forbid")

    id: UUID
    task_type: str
    name: str
    status: TaskStatus
    priority: TaskPriority
    progress: TaskProgress | None = None
    result: dict | None = None
    error_details: dict | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class TaskListResponse(BaseModel):
    """API response for task list."""

    model_config = ConfigDict(extra="forbid")

    tasks: list[TaskResponse]
    total: int
    limit: int
    offset: int
