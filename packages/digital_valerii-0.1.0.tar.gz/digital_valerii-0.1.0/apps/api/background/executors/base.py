"""Base classes for step executors."""

from abc import ABC, abstractmethod
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from apps.api.background.models import StepResult, StepStatus, TaskStep


class ExecutionContext(BaseModel):
    """Context passed to step executors.

    Contains all information needed for step execution:
    - Task metadata (ID, type, name)
    - Session context
    - Payload data
    - Previous step results
    """

    model_config = ConfigDict(extra="forbid")

    task_id: UUID
    task_type: str
    task_name: str
    session_id: str | None = None
    payload: dict = Field(default_factory=dict)
    previous_results: dict[str, Any] = Field(default_factory=dict)


class BaseStepExecutor(ABC):
    """Abstract base class for step executors.

    Each executor type (python, ai) must implement the execute method.

    Example:
        class MyExecutor(BaseStepExecutor):
            async def execute(self, step, context, previous_results):
                # Do the work
                return StepResult(...)
    """

    @property
    @abstractmethod
    def executor_type(self) -> str:
        """Return the executor type identifier."""
        pass

    @abstractmethod
    async def execute(
        self,
        step: TaskStep,
        context: ExecutionContext,
    ) -> StepResult:
        """Execute a single step.

        Args:
            step: The step definition to execute.
            context: Execution context with task info and previous results.

        Returns:
            StepResult with status, output, and any errors.
        """
        pass

    def _create_result(
        self,
        step: TaskStep,
        step_index: int,
        status: StepStatus,
        output: dict | None = None,
        error: str | None = None,
        tokens_used: int | None = None,
        started_at: datetime | None = None,
        completed_at: datetime | None = None,
    ) -> StepResult:
        """Helper to create a StepResult.

        Args:
            step: The step that was executed.
            step_index: Index of the step in the task.
            status: Execution status.
            output: Output data if successful.
            error: Error message if failed.
            tokens_used: AI tokens consumed (for AI executor).
            started_at: When execution started.
            completed_at: When execution completed.

        Returns:
            StepResult with duration calculated.
        """
        duration_ms = None
        if started_at and completed_at:
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

        return StepResult(
            step_name=step.name,
            step_index=step_index,
            status=status,
            output=output,
            error=error,
            tokens_used=tokens_used,
            started_at=started_at,
            completed_at=completed_at,
            duration_ms=duration_ms,
        )

    async def _execute_with_timeout(
        self,
        step: TaskStep,
        context: ExecutionContext,
        step_index: int,
    ) -> StepResult:
        """Execute step with timeout handling.

        Args:
            step: The step to execute.
            context: Execution context.
            step_index: Index of the step.

        Returns:
            StepResult, possibly with timeout error.
        """
        import asyncio

        started_at = datetime.now(UTC)

        try:
            result = await asyncio.wait_for(
                self.execute(step, context),
                timeout=step.timeout_seconds,
            )
            return result
        except TimeoutError:
            completed_at = datetime.now(UTC)
            return self._create_result(
                step=step,
                step_index=step_index,
                status=StepStatus.FAILED,
                error=f"Step timed out after {step.timeout_seconds}s",
                started_at=started_at,
                completed_at=completed_at,
            )
        except Exception as e:
            completed_at = datetime.now(UTC)
            return self._create_result(
                step=step,
                step_index=step_index,
                status=StepStatus.FAILED,
                error=str(e),
                started_at=started_at,
                completed_at=completed_at,
            )
