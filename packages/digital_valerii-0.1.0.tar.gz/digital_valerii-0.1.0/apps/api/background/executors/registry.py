"""Step executor registry."""

from typing import TYPE_CHECKING

import structlog

from apps.api.background.executors.base import BaseStepExecutor

if TYPE_CHECKING:
    pass

logger = structlog.get_logger(__name__)


class StepExecutorRegistry:
    """Registry for step executors.

    Manages available executors and provides lookup by type.

    Example:
        registry = StepExecutorRegistry()
        registry.register(PythonExecutor())
        registry.register(AIExecutor(anthropic_client))

        executor = registry.get("python")
        result = await executor.execute(step, context)
    """

    def __init__(self) -> None:
        """Initialize empty registry."""
        self._executors: dict[str, BaseStepExecutor] = {}

    def register(self, executor: BaseStepExecutor) -> None:
        """Register an executor.

        Args:
            executor: The executor instance to register.

        Raises:
            ValueError: If executor type already registered.
        """
        executor_type = executor.executor_type
        if executor_type in self._executors:
            raise ValueError(f"Executor '{executor_type}' already registered")

        self._executors[executor_type] = executor
        logger.info("Registered step executor", executor_type=executor_type)

    def get(self, executor_type: str) -> BaseStepExecutor:
        """Get an executor by type.

        Args:
            executor_type: The executor type to look up.

        Returns:
            The registered executor.

        Raises:
            KeyError: If executor type not found.
        """
        if executor_type not in self._executors:
            raise KeyError(f"Unknown executor type: {executor_type}")
        return self._executors[executor_type]

    def has(self, executor_type: str) -> bool:
        """Check if an executor type is registered.

        Args:
            executor_type: The executor type to check.

        Returns:
            True if registered, False otherwise.
        """
        return executor_type in self._executors

    @property
    def available_types(self) -> list[str]:
        """List all registered executor types.

        Returns:
            List of executor type strings.
        """
        return list(self._executors.keys())

    def unregister(self, executor_type: str) -> None:
        """Unregister an executor.

        Args:
            executor_type: The executor type to unregister.

        Raises:
            KeyError: If executor type not found.
        """
        if executor_type not in self._executors:
            raise KeyError(f"Unknown executor type: {executor_type}")
        del self._executors[executor_type]
        logger.info("Unregistered step executor", executor_type=executor_type)

    def clear(self) -> None:
        """Clear all registered executors."""
        self._executors.clear()
        logger.info("Cleared all step executors")


# Default global registry
_default_registry: StepExecutorRegistry | None = None


def get_default_registry() -> StepExecutorRegistry:
    """Get or create the default executor registry.

    Returns:
        The default StepExecutorRegistry.
    """
    global _default_registry
    if _default_registry is None:
        _default_registry = StepExecutorRegistry()
    return _default_registry


def reset_default_registry() -> None:
    """Reset the default registry (for testing)."""
    global _default_registry
    if _default_registry:
        _default_registry.clear()
    _default_registry = None
