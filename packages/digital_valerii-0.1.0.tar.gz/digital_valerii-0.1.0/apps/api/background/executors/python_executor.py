"""Python step executor for background tasks."""

from collections.abc import Callable, Coroutine
from datetime import UTC, datetime
from typing import Any

import structlog

from apps.api.background.executors.base import (
    BaseStepExecutor,
    ExecutionContext,
)
from apps.api.background.models import StepResult, StepStatus, TaskStep

logger = structlog.get_logger(__name__)


# Type alias for step handlers
StepHandler = Callable[[dict, ExecutionContext], Coroutine[Any, Any, dict]]


class PythonExecutor(BaseStepExecutor):
    """Executes Python code steps.

    Supports two modes:
    1. Handler mode: Calls registered handlers by name
    2. Config mode: Executes operations from step config

    Example (handler mode):
        executor = PythonExecutor()
        executor.register_handler("ingest", ingest_handler)

        # Step config: {"handler": "ingest", "sources": ["nessus"]}

    Example (config mode):
        # Step config: {"operation": "http_request", "url": "..."}
    """

    def __init__(self) -> None:
        """Initialize Python executor."""
        self._handlers: dict[str, StepHandler] = {}

    @property
    def executor_type(self) -> str:
        """Return executor type identifier."""
        return "python"

    def register_handler(
        self,
        name: str,
        handler: StepHandler,
    ) -> None:
        """Register a step handler.

        Args:
            name: Handler name (used in step config).
            handler: Async function that takes (config, context) and returns dict.
        """
        self._handlers[name] = handler
        logger.debug("Registered Python handler", name=name)

    def has_handler(self, name: str) -> bool:
        """Check if a handler is registered.

        Args:
            name: Handler name to check.

        Returns:
            True if handler exists.
        """
        return name in self._handlers

    async def execute(
        self,
        step: TaskStep,
        context: ExecutionContext,
    ) -> StepResult:
        """Execute a Python step.

        Args:
            step: Step definition with config.
            context: Execution context.

        Returns:
            StepResult with output or error.
        """
        started_at = datetime.now(UTC)
        config = step.config

        try:
            await logger.ainfo(
                "Executing Python step",
                step_name=step.name,
                task_id=str(context.task_id),
            )

            # Determine execution mode
            handler_name = config.get("handler")
            operation = config.get("operation")

            if handler_name:
                # Handler mode
                output = await self._execute_handler(handler_name, config, context)
            elif operation:
                # Built-in operation mode
                output = await self._execute_operation(operation, config, context)
            else:
                # Default: pass-through with config as output
                output = {"config": config, "status": "completed"}

            completed_at = datetime.now(UTC)

            await logger.ainfo(
                "Python step completed",
                step_name=step.name,
                task_id=str(context.task_id),
            )

            return self._create_result(
                step=step,
                step_index=self._get_step_index(step, context),
                status=StepStatus.COMPLETED,
                output=output,
                started_at=started_at,
                completed_at=completed_at,
            )

        except Exception as e:
            completed_at = datetime.now(UTC)
            await logger.aerror(
                "Python step failed",
                step_name=step.name,
                task_id=str(context.task_id),
                error=str(e),
            )

            return self._create_result(
                step=step,
                step_index=self._get_step_index(step, context),
                status=StepStatus.FAILED,
                error=str(e),
                started_at=started_at,
                completed_at=completed_at,
            )

    async def _execute_handler(
        self,
        handler_name: str,
        config: dict,
        context: ExecutionContext,
    ) -> dict:
        """Execute a registered handler.

        Args:
            handler_name: Name of the handler.
            config: Step configuration.
            context: Execution context.

        Returns:
            Handler output.

        Raises:
            KeyError: If handler not found.
        """
        if handler_name not in self._handlers:
            raise KeyError(f"Unknown handler: {handler_name}")

        handler = self._handlers[handler_name]
        return await handler(config, context)

    async def _execute_operation(
        self,
        operation: str,
        config: dict,
        context: ExecutionContext,
    ) -> dict:
        """Execute a built-in operation.

        Args:
            operation: Operation name.
            config: Operation configuration.
            context: Execution context.

        Returns:
            Operation output.
        """
        # Built-in operations
        if operation == "noop":
            return {"status": "noop", "message": "No operation performed"}

        if operation == "log":
            message = config.get("message", "No message")
            await logger.ainfo(
                "Python step log",
                message=message,
                task_id=str(context.task_id),
            )
            return {"status": "logged", "message": message}

        if operation == "merge_results":
            # Merge all previous results into single output
            return {
                "status": "merged",
                "merged_data": context.previous_results,
            }

        if operation == "validate":
            # Validate required fields in previous results
            required = config.get("required_fields", [])
            missing = []
            for field in required:
                if field not in context.previous_results:
                    missing.append(field)
            if missing:
                raise ValueError(f"Missing required fields: {missing}")
            return {"status": "validated", "validated_fields": required}

        # Unknown operation - return as pass-through
        return {
            "status": "unknown_operation",
            "operation": operation,
            "config": config,
        }

    def _get_step_index(
        self,
        step: TaskStep,  # noqa: ARG002 - reserved for future step-based index
        context: ExecutionContext,
    ) -> int:
        """Get the step index from context.

        Args:
            step: Current step (reserved for future use).
            context: Execution context.

        Returns:
            Step index (0 if not found).
        """
        _ = step  # Reserved for future step-based index lookup
        return len(context.previous_results)
