"""AI step executor using Claude for reasoning."""

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import structlog

from apps.api.background.executors.base import (
    BaseStepExecutor,
    ExecutionContext,
)
from apps.api.background.models import StepResult, StepStatus, TaskStep

if TYPE_CHECKING:
    import anthropic

logger = structlog.get_logger(__name__)


class AIExecutor(BaseStepExecutor):
    """Executes AI-powered steps using Claude.

    Uses Anthropic API to perform reasoning, analysis, and generation tasks.

    Example step config:
        {
            "prompt": "Analyze these vulnerabilities: {vulnerabilities}",
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 4096,
            "system": "You are a security analyst.",
            "output_format": "json"
        }

    Template variables in prompt are replaced with:
    - Context payload fields
    - Previous step results
    """

    def __init__(
        self,
        client: "anthropic.Anthropic | anthropic.AsyncAnthropic | None" = None,
        default_model: str = "claude-sonnet-4-20250514",
        default_max_tokens: int = 4096,
    ) -> None:
        """Initialize AI executor.

        Args:
            client: Anthropic client (creates default if None).
            default_model: Default model to use.
            default_max_tokens: Default max tokens.
        """
        self._client = client
        self._default_model = default_model
        self._default_max_tokens = default_max_tokens

    @property
    def executor_type(self) -> str:
        """Return executor type identifier."""
        return "ai"

    def _get_client(self) -> "anthropic.Anthropic":
        """Get or create Anthropic client.

        Returns:
            Anthropic client.

        Raises:
            RuntimeError: If no API key configured.
        """
        if self._client is None:
            import anthropic

            self._client = anthropic.Anthropic()
        return self._client

    async def execute(
        self,
        step: TaskStep,
        context: ExecutionContext,
    ) -> StepResult:
        """Execute an AI step with Claude.

        Args:
            step: Step definition with prompt config.
            context: Execution context.

        Returns:
            StepResult with AI response.
        """
        started_at = datetime.now(UTC)
        config = step.config

        try:
            await logger.ainfo(
                "Executing AI step",
                step_name=step.name,
                task_id=str(context.task_id),
            )

            # Get prompt template
            prompt_template = config.get("prompt")
            if not prompt_template:
                raise ValueError("AI step requires 'prompt' in config")

            # Build template variables
            template_vars = {
                **context.payload,
                **context.previous_results,
                "task_id": str(context.task_id),
                "task_type": context.task_type,
                "task_name": context.task_name,
            }

            # Format prompt with variables
            prompt = self._format_prompt(prompt_template, template_vars)

            # Get model settings
            model = config.get("model", self._default_model)
            max_tokens = config.get("max_tokens", self._default_max_tokens)
            system = config.get("system")
            output_format = config.get("output_format", "text")

            # Call Claude API
            client = self._get_client()
            messages = [{"role": "user", "content": prompt}]

            # Build request kwargs
            request_kwargs: dict[str, Any] = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": messages,
            }
            if system:
                request_kwargs["system"] = system

            # Make API call (sync for now, can be made async with AsyncAnthropic)
            response = client.messages.create(**request_kwargs)

            # Extract response text
            response_text = ""
            for block in response.content:
                if hasattr(block, "text"):
                    response_text += block.text

            # Parse output based on format
            output = self._parse_output(response_text, output_format)

            # Calculate tokens used
            tokens_used = None
            if hasattr(response, "usage"):
                tokens_used = response.usage.input_tokens + response.usage.output_tokens

            completed_at = datetime.now(UTC)

            await logger.ainfo(
                "AI step completed",
                step_name=step.name,
                task_id=str(context.task_id),
                tokens_used=tokens_used,
            )

            return self._create_result(
                step=step,
                step_index=self._get_step_index(step, context),
                status=StepStatus.COMPLETED,
                output=output,
                tokens_used=tokens_used,
                started_at=started_at,
                completed_at=completed_at,
            )

        except Exception as e:
            completed_at = datetime.now(UTC)
            await logger.aerror(
                "AI step failed",
                step_name=step.name,
                task_id=str(context.task_id),
                error=str(e),
            )

            return self._create_result(
                step=step,
                step_index=self._get_step_index(step, context),
                status=StepStatus.FAILED,
                error=str(e),
                started_at=started_at,
                completed_at=completed_at,
            )

    def _format_prompt(self, template: str, variables: dict) -> str:
        """Format prompt template with variables.

        Uses safe formatting that ignores missing keys.

        Args:
            template: Prompt template string.
            variables: Variables to substitute.

        Returns:
            Formatted prompt.
        """
        # Simple variable substitution
        result = template
        for key, value in variables.items():
            placeholder = "{" + key + "}"
            if placeholder in result:
                # Convert complex types to JSON
                if isinstance(value, dict | list):
                    value_str = json.dumps(value, indent=2, default=str)
                else:
                    value_str = str(value)
                result = result.replace(placeholder, value_str)
        return result

    def _parse_output(self, text: str, output_format: str) -> dict:
        """Parse AI response into structured output.

        Args:
            text: Raw response text.
            output_format: Expected format (json, text, markdown).

        Returns:
            Structured output dict.
        """
        if output_format == "json":
            # Try to extract JSON from response
            try:
                # Find JSON in response (may be wrapped in markdown code block)
                json_start = text.find("{")
                json_end = text.rfind("}") + 1

                if json_start >= 0 and json_end > json_start:
                    json_str = text[json_start:json_end]
                    return {"type": "json", "data": json.loads(json_str)}
                else:
                    # No JSON found, return as text
                    return {"type": "text", "data": text}
            except json.JSONDecodeError:
                return {"type": "text", "data": text, "parse_error": "Invalid JSON"}

        elif output_format == "markdown":
            return {"type": "markdown", "content": text}

        else:
            # Default: text
            return {"type": "text", "content": text}

    def _get_step_index(
        self,
        step: TaskStep,  # noqa: ARG002 - reserved for future step-based index
        context: ExecutionContext,
    ) -> int:
        """Get the step index from context.

        Args:
            step: Current step (reserved for future use).
            context: Execution context.

        Returns:
            Step index (0 if not found).
        """
        _ = step  # Reserved for future step-based index lookup
        return len(context.previous_results)
