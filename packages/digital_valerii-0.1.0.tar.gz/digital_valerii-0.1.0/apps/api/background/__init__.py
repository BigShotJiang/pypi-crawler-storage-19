"""Background Task Runner for Digital Valerii.

This module enables execution of long-running tasks in the background
while the main conversation continues. Key components:

- BackgroundTaskManager: Creates and manages background tasks
- TaskWorkerService: Executes tasks with step-by-step processing
- ProgressTracker: Real-time progress updates via Redis
- TaskNotifier: Multi-channel completion notifications
"""

from apps.api.background.exceptions import (
    BackgroundTaskError,
    TaskLimitExceededError,
    TaskNotFoundError,
    TaskTemplateNotFoundError,
)
from apps.api.background.models import (
    BackgroundTask,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskStep,
)

__all__ = [
    # Models
    "BackgroundTask",
    "TaskStep",
    "TaskProgress",
    "TaskStatus",
    "TaskPriority",
    # Exceptions
    "BackgroundTaskError",
    "TaskNotFoundError",
    "TaskLimitExceededError",
    "TaskTemplateNotFoundError",
]
