"""BackgroundTaskManager - Creates and manages background tasks."""

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from apps.api.background.exceptions import (
    TaskLimitExceededError,
    TaskNotFoundError,
    TaskTemplateNotFoundError,
)
from apps.api.background.models import (
    BackgroundTask,
    BackgroundTaskCreate,
    BackgroundTaskUpdate,
    TaskFilter,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskStep,
    TaskTemplate,
    TaskTemplateCreate,
    TaskTemplateUpdate,
)

if TYPE_CHECKING:
    from collections.abc import Callable

logger = structlog.get_logger(__name__)


# Maximum active tasks per user/session
MAX_ACTIVE_TASKS = 10


class BackgroundTaskManager:
    """Manages background task lifecycle.

    Responsibilities:
    - Create tasks from templates or definitions
    - Track task status and progress
    - Enforce task limits per session
    - Query tasks by various criteria

    Example:
        manager = BackgroundTaskManager(session_factory)
        task = await manager.create_task(
            task_type="vulnerability_scan",
            name="Q1 Security Scan",
            session_id="abc123",
        )
    """

    def __init__(self, session_factory: "Callable[[], AsyncSession]") -> None:
        """Initialize manager with session factory.

        Args:
            session_factory: Async function that returns an AsyncSession.
        """
        self._session_factory = session_factory

    # =========================================================================
    # Task CRUD
    # =========================================================================

    async def create_task(
        self,
        task: BackgroundTaskCreate,
        session_id: str | None = None,
    ) -> BackgroundTask:
        """Create a new background task.

        Args:
            task: Task definition.
            session_id: Optional session ID for tracking.

        Returns:
            Created BackgroundTask.

        Raises:
            TaskLimitExceededError: If active task limit exceeded.
        """
        async with self._session_factory() as db:
            # Check active task limit
            if session_id:
                active_count = await self._count_active_tasks(db, session_id)
                if active_count >= MAX_ACTIVE_TASKS:
                    raise TaskLimitExceededError(
                        limit=MAX_ACTIVE_TASKS,
                        current=active_count,
                    )

            task_id = uuid4()
            now = datetime.now(UTC)

            # Insert task into task_queue
            stmt = text("""
                INSERT INTO task_queue (
                    id, task_type, payload, priority, status,
                    steps, progress, created_by_session_id,
                    notification_channels, created_at
                ) VALUES (
                    :id, :task_type, :payload::jsonb, :priority, :status,
                    :steps::jsonb, :progress::jsonb, :session_id,
                    :notification_channels, :created_at
                )
            """)

            # Build progress JSON
            progress_data = {
                "task_id": str(task_id),
                "status": TaskStatus.PENDING.value,
                "current_step": None,
                "step_index": 0,
                "total_steps": len(task.steps),
                "percent": 0,
                "message": "Waiting to start",
                "started_at": None,
                "updated_at": now.isoformat(),
                "estimated_completion": None,
            }

            await db.execute(
                stmt,
                {
                    "id": str(task_id),
                    "task_type": task.task_type,
                    "payload": _to_json(
                        {
                            "name": task.name,
                            "input": task.payload,
                            "timeout_seconds": task.timeout_seconds,
                        }
                    ),
                    "priority": task.priority.value,
                    "status": TaskStatus.PENDING.value,
                    "steps": _to_json([s.model_dump() for s in task.steps]),
                    "progress": _to_json(progress_data),
                    "session_id": session_id,
                    "notification_channels": task.notification_channels,
                    "created_at": now,
                },
            )
            await db.commit()

            await logger.ainfo(
                "Background task created",
                task_id=str(task_id),
                task_type=task.task_type,
                session_id=session_id,
            )

            return BackgroundTask(
                id=task_id,
                task_type=task.task_type,
                name=task.name,
                steps=task.steps,
                payload=task.payload,
                created_by_session_id=session_id,
                notification_channels=task.notification_channels,
                timeout_seconds=task.timeout_seconds,
                priority=task.priority,
                status=TaskStatus.PENDING,
                progress=progress_data,
                created_at=now,
            )

    async def create_from_template(
        self,
        template_id: UUID,
        name: str | None = None,
        payload: dict | None = None,
        notification_channels: list[str] | None = None,
        session_id: str | None = None,
    ) -> BackgroundTask:
        """Create a task from a template.

        Args:
            template_id: Template UUID.
            name: Optional name override for this task instance.
            payload: Optional payload overrides.
            notification_channels: Optional notification channels override.
            session_id: Optional session ID.

        Returns:
            Created BackgroundTask.

        Raises:
            TaskTemplateNotFoundError: If template not found.
        """
        template = await self.get_template(template_id)

        # Merge payload with default config
        merged_payload = {**template.default_config, **(payload or {})}

        # Create task from template
        task_create = BackgroundTaskCreate(
            task_type=template.task_type,
            name=name or template.name,
            steps=template.steps,
            payload=merged_payload,
            notification_channels=notification_channels or ["conversation"],
            timeout_seconds=template.timeout_seconds,
        )

        return await self.create_task(task_create, session_id)

    async def create_from_template_by_type(
        self,
        task_type: str,
        name: str,
        config: dict | None = None,
        session_id: str | None = None,
    ) -> BackgroundTask:
        """Create a task from a template by task type.

        Args:
            task_type: Task type to look up template.
            name: Name for this task instance.
            config: Optional config overrides.
            session_id: Optional session ID.

        Returns:
            Created BackgroundTask.

        Raises:
            TaskTemplateNotFoundError: If template not found.
        """
        template = await self.get_template_by_type(task_type)
        if not template:
            raise TaskTemplateNotFoundError(task_type)

        # Merge config
        merged_config = {**template.default_config, **(config or {})}

        # Create task from template
        task_create = BackgroundTaskCreate(
            task_type=task_type,
            name=name,
            steps=template.steps,
            payload=merged_config,
            timeout_seconds=template.timeout_seconds,
        )

        return await self.create_task(task_create, session_id)

    async def get_task(self, task_id: UUID) -> BackgroundTask:
        """Get a task by ID.

        Args:
            task_id: Task UUID.

        Returns:
            BackgroundTask.

        Raises:
            TaskNotFoundError: If task not found.
        """
        async with self._session_factory() as db:
            stmt = text("""
                SELECT
                    id, task_type, payload, priority, status,
                    steps, progress, created_by_session_id,
                    notification_channels, result, error_details,
                    created_at, started_at, completed_at
                FROM task_queue
                WHERE id = :task_id
            """)
            result = await db.execute(stmt, {"task_id": str(task_id)})
            row = result.fetchone()

            if not row:
                raise TaskNotFoundError(str(task_id))

            return self._row_to_task(row)

    async def update_task(
        self,
        task_id: UUID,
        update: BackgroundTaskUpdate,
    ) -> BackgroundTask:
        """Update a task.

        Args:
            task_id: Task UUID.
            update: Update data.

        Returns:
            Updated BackgroundTask.

        Raises:
            TaskNotFoundError: If task not found.
        """
        async with self._session_factory() as db:
            # Build update
            updates = []
            params: dict[str, Any] = {"task_id": str(task_id)}

            if update.name is not None:
                updates.append("payload = jsonb_set(payload, '{name}', :name::jsonb)")
                params["name"] = json.dumps(update.name)  # Proper JSON serialization

            if update.notification_channels is not None:
                updates.append("notification_channels = :channels::text[]")
                # PostgreSQL array literal format with proper escaping
                params["channels"] = (
                    "{"
                    + ",".join(
                        _escape_pg_array_element(c) for c in update.notification_channels
                    )
                    + "}"
                )

            if update.priority is not None:
                updates.append("priority = :priority")
                params["priority"] = update.priority.value

            if not updates:
                return await self.get_task(task_id)

            stmt = text(f"""
                UPDATE task_queue
                SET {", ".join(updates)}
                WHERE id = :task_id
                RETURNING id
            """)

            result = await db.execute(stmt, params)
            if not result.fetchone():
                raise TaskNotFoundError(str(task_id))

            await db.commit()
            return await self.get_task(task_id)

    async def delete_task(self, task_id: UUID) -> None:
        """Delete a task (hard delete).

        Args:
            task_id: Task UUID.

        Raises:
            TaskNotFoundError: If task not found.
        """
        async with self._session_factory() as db:
            stmt = text("""
                DELETE FROM task_queue
                WHERE id = :task_id
                RETURNING id
            """)
            result = await db.execute(stmt, {"task_id": str(task_id)})

            if not result.fetchone():
                raise TaskNotFoundError(str(task_id))

            await db.commit()
            await logger.ainfo("Background task deleted", task_id=str(task_id))

    async def cancel_task(self, task_id: UUID) -> BackgroundTask:
        """Cancel a running or pending task.

        Args:
            task_id: Task UUID.

        Returns:
            Updated BackgroundTask.

        Raises:
            TaskNotFoundError: If task not found.
        """
        async with self._session_factory() as db:
            now = datetime.now(UTC)
            stmt = text("""
                UPDATE task_queue
                SET status = :status, completed_at = :completed_at,
                    progress = jsonb_set(
                        progress,
                        '{status}',
                        :progress_status::jsonb
                    )
                WHERE id = :task_id
                  AND status IN ('pending', 'running', 'paused')
                RETURNING id
            """)

            result = await db.execute(
                stmt,
                {
                    "task_id": str(task_id),
                    "status": TaskStatus.CANCELLED.value,
                    "completed_at": now,
                    "progress_status": f'"{TaskStatus.CANCELLED.value}"',
                },
            )

            if not result.fetchone():
                raise TaskNotFoundError(str(task_id))

            await db.commit()
            await logger.ainfo("Background task cancelled", task_id=str(task_id))

            return await self.get_task(task_id)

    # =========================================================================
    # Task Queries
    # =========================================================================

    async def list_tasks(self, filter_: TaskFilter) -> tuple[list[BackgroundTask], int]:
        """List tasks with filtering.

        Args:
            filter_: Filter criteria.

        Returns:
            Tuple of (tasks, total_count).
        """
        async with self._session_factory() as db:
            # Build WHERE conditions
            conditions = []
            params: dict = {}

            if filter_.status:
                conditions.append("status = :status")
                params["status"] = filter_.status.value

            if filter_.task_type:
                conditions.append("task_type = :task_type")
                params["task_type"] = filter_.task_type

            if filter_.session_id:
                conditions.append("created_by_session_id = :session_id")
                params["session_id"] = filter_.session_id

            if filter_.priority:
                conditions.append("priority = :priority")
                params["priority"] = filter_.priority.value

            where_clause = " AND ".join(conditions) if conditions else "1=1"

            # Get total count
            count_stmt = text(f"SELECT COUNT(*) FROM task_queue WHERE {where_clause}")
            count_result = await db.execute(count_stmt, params)
            total = count_result.scalar() or 0

            # Get tasks with pagination
            stmt = text(f"""
                SELECT
                    id, task_type, payload, priority, status,
                    steps, progress, created_by_session_id,
                    notification_channels, result, error_details,
                    created_at, started_at, completed_at
                FROM task_queue
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT :limit OFFSET :offset
            """)
            params["limit"] = filter_.limit
            params["offset"] = filter_.offset

            result = await db.execute(stmt, params)
            rows = result.fetchall()

            tasks = [self._row_to_task(row) for row in rows]
            return tasks, total

    async def get_active_tasks(self, session_id: str) -> list[BackgroundTask]:
        """Get active tasks for a session.

        Args:
            session_id: Session ID.

        Returns:
            List of active tasks.
        """
        async with self._session_factory() as db:
            stmt = text("""
                SELECT
                    id, task_type, payload, priority, status,
                    steps, progress, created_by_session_id,
                    notification_channels, result, error_details,
                    created_at, started_at, completed_at
                FROM task_queue
                WHERE created_by_session_id = :session_id
                  AND status IN ('pending', 'running', 'paused')
                ORDER BY created_at DESC
            """)
            result = await db.execute(stmt, {"session_id": session_id})
            rows = result.fetchall()

            return [self._row_to_task(row) for row in rows]

    async def claim_next_pending_task(self) -> BackgroundTask | None:
        """Atomically claim the next pending task for execution.

        Uses FOR UPDATE SKIP LOCKED to prevent race conditions
        when multiple workers poll simultaneously.

        Returns:
            Claimed BackgroundTask with status set to RUNNING, or None if no tasks.
        """
        async with self._session_factory() as db:
            stmt = text("""
                UPDATE task_queue
                SET status = 'running', started_at = :started_at
                WHERE id = (
                    SELECT id FROM task_queue
                    WHERE status = 'pending'
                    ORDER BY
                        CASE priority
                            WHEN 'critical' THEN 0
                            WHEN 'high' THEN 1
                            WHEN 'normal' THEN 2
                            WHEN 'low' THEN 3
                        END,
                        created_at
                    LIMIT 1
                    FOR UPDATE SKIP LOCKED
                )
                RETURNING id, task_type, payload, priority, status,
                          steps, progress, created_by_session_id,
                          notification_channels, result, error_details,
                          created_at, started_at, completed_at
            """)

            result = await db.execute(stmt, {"started_at": datetime.now(UTC)})
            row = result.fetchone()

            if row:
                await db.commit()
                return self._row_to_task(row)
            return None

    # =========================================================================
    # Progress
    # =========================================================================

    async def get_progress(self, task_id: UUID) -> TaskProgress:
        """Get task progress.

        Args:
            task_id: Task UUID.

        Returns:
            TaskProgress.

        Raises:
            TaskNotFoundError: If task not found.
        """
        task = await self.get_task(task_id)
        if not task.progress:
            return TaskProgress(
                task_id=task_id,
                status=task.status,
                current_step=None,
                step_index=0,
                total_steps=len(task.steps),
                percent=0,
                message="No progress data",
                started_at=task.started_at or task.created_at,
                updated_at=task.created_at,
            )

        return TaskProgress(
            task_id=task_id,
            status=TaskStatus(task.progress.get("status", task.status.value)),
            current_step=task.progress.get("current_step"),
            step_index=task.progress.get("step_index", 0),
            total_steps=task.progress.get("total_steps", len(task.steps)),
            percent=task.progress.get("percent", 0),
            message=task.progress.get("message", ""),
            started_at=_parse_datetime(task.progress.get("started_at"))
            or task.started_at
            or task.created_at,
            updated_at=_parse_datetime(task.progress.get("updated_at"))
            or task.created_at,
            estimated_completion=_parse_datetime(
                task.progress.get("estimated_completion")
            ),
        )

    async def update_progress(
        self,
        task_id: UUID,
        progress: TaskProgress,
    ) -> None:
        """Update task progress.

        Args:
            task_id: Task UUID.
            progress: New progress data.
        """
        async with self._session_factory() as db:
            stmt = text("""
                UPDATE task_queue
                SET progress = :progress::jsonb,
                    status = :status
                WHERE id = :task_id
            """)

            await db.execute(
                stmt,
                {
                    "task_id": str(task_id),
                    "progress": _to_json(progress.model_dump(mode="json")),
                    "status": progress.status.value,
                },
            )
            await db.commit()

    # =========================================================================
    # Templates
    # =========================================================================

    async def create_template(
        self,
        template: TaskTemplateCreate,
    ) -> TaskTemplate:
        """Create a task template.

        Args:
            template: Template definition.

        Returns:
            Created TaskTemplate.
        """
        async with self._session_factory() as db:
            template_id = uuid4()
            now = datetime.now(UTC)

            stmt = text("""
                INSERT INTO task_templates (
                    id, task_type, name, description, steps,
                    default_config, timeout_seconds, enabled,
                    created_at, updated_at
                ) VALUES (
                    :id, :task_type, :name, :description, :steps::jsonb,
                    :default_config::jsonb, :timeout_seconds, :enabled,
                    :created_at, :updated_at
                )
            """)

            await db.execute(
                stmt,
                {
                    "id": str(template_id),
                    "task_type": template.task_type,
                    "name": template.name,
                    "description": template.description,
                    "steps": _to_json([s.model_dump() for s in template.steps]),
                    "default_config": _to_json(template.default_config),
                    "timeout_seconds": template.timeout_seconds,
                    "enabled": True,
                    "created_at": now,
                    "updated_at": now,
                },
            )
            await db.commit()

            return TaskTemplate(
                id=template_id,
                task_type=template.task_type,
                name=template.name,
                description=template.description,
                steps=template.steps,
                default_config=template.default_config,
                timeout_seconds=template.timeout_seconds,
                enabled=True,
                created_at=now,
                updated_at=now,
            )

    async def get_template_by_type(self, task_type: str) -> TaskTemplate | None:
        """Get a template by task type.

        Args:
            task_type: Task type identifier.

        Returns:
            TaskTemplate or None if not found.
        """
        async with self._session_factory() as db:
            stmt = text("""
                SELECT
                    id, task_type, name, description, steps,
                    default_config, timeout_seconds, enabled,
                    created_at, updated_at
                FROM task_templates
                WHERE task_type = :task_type AND enabled = true
            """)
            result = await db.execute(stmt, {"task_type": task_type})
            row = result.fetchone()

            if not row:
                return None

            return self._row_to_template(row)

    async def get_template(self, template_id: UUID) -> TaskTemplate:
        """Get a template by ID.

        Args:
            template_id: Template UUID.

        Returns:
            TaskTemplate.

        Raises:
            TaskTemplateNotFoundError: If template not found.
        """
        async with self._session_factory() as db:
            stmt = text("""
                SELECT
                    id, task_type, name, description, steps,
                    default_config, timeout_seconds, enabled,
                    created_at, updated_at
                FROM task_templates
                WHERE id = :template_id
            """)
            result = await db.execute(stmt, {"template_id": str(template_id)})
            row = result.fetchone()

            if not row:
                raise TaskTemplateNotFoundError(str(template_id))

            return self._row_to_template(row)

    async def list_templates(self, enabled_only: bool = True) -> list[TaskTemplate]:
        """List all templates.

        Args:
            enabled_only: Only return enabled templates.

        Returns:
            List of TaskTemplate.
        """
        async with self._session_factory() as db:
            if enabled_only:
                stmt = text("""
                    SELECT
                        id, task_type, name, description, steps,
                        default_config, timeout_seconds, enabled,
                        created_at, updated_at
                    FROM task_templates
                    WHERE enabled = true
                    ORDER BY name
                """)
            else:
                stmt = text("""
                    SELECT
                        id, task_type, name, description, steps,
                        default_config, timeout_seconds, enabled,
                        created_at, updated_at
                    FROM task_templates
                    ORDER BY name
                """)

            result = await db.execute(stmt)
            rows = result.fetchall()

            return [self._row_to_template(row) for row in rows]

    async def update_template(
        self,
        task_type: str,
        update: TaskTemplateUpdate,
    ) -> TaskTemplate:
        """Update a template.

        Args:
            task_type: Task type identifier.
            update: Update data.

        Returns:
            Updated TaskTemplate.

        Raises:
            TaskTemplateNotFoundError: If template not found.
        """
        async with self._session_factory() as db:
            updates = ["updated_at = :updated_at"]
            params: dict = {
                "task_type": task_type,
                "updated_at": datetime.now(UTC),
            }

            if update.name is not None:
                updates.append("name = :name")
                params["name"] = update.name

            if update.description is not None:
                updates.append("description = :description")
                params["description"] = update.description

            if update.steps is not None:
                updates.append("steps = :steps::jsonb")
                params["steps"] = _to_json([s.model_dump() for s in update.steps])

            if update.default_config is not None:
                updates.append("default_config = :default_config::jsonb")
                params["default_config"] = _to_json(update.default_config)

            if update.timeout_seconds is not None:
                updates.append("timeout_seconds = :timeout_seconds")
                params["timeout_seconds"] = update.timeout_seconds

            if update.enabled is not None:
                updates.append("enabled = :enabled")
                params["enabled"] = update.enabled

            stmt = text(f"""
                UPDATE task_templates
                SET {", ".join(updates)}
                WHERE task_type = :task_type
                RETURNING id
            """)

            result = await db.execute(stmt, params)
            if not result.fetchone():
                raise TaskTemplateNotFoundError(task_type)

            await db.commit()

            template = await self.get_template_by_type(task_type)
            if not template:
                raise TaskTemplateNotFoundError(task_type)
            return template

    async def delete_template(self, task_type: str) -> None:
        """Delete a template.

        Args:
            task_type: Task type identifier.

        Raises:
            TaskTemplateNotFoundError: If template not found.
        """
        async with self._session_factory() as db:
            stmt = text("""
                DELETE FROM task_templates
                WHERE task_type = :task_type
                RETURNING id
            """)
            result = await db.execute(stmt, {"task_type": task_type})

            if not result.fetchone():
                raise TaskTemplateNotFoundError(task_type)

            await db.commit()
            await logger.ainfo("Task template deleted", task_type=task_type)

    # =========================================================================
    # Helpers
    # =========================================================================

    async def _count_active_tasks(self, db: AsyncSession, session_id: str) -> int:
        """Count active tasks for a session."""
        stmt = text("""
            SELECT COUNT(*)
            FROM task_queue
            WHERE created_by_session_id = :session_id
              AND status IN ('pending', 'running', 'paused')
        """)
        result = await db.execute(stmt, {"session_id": session_id})
        return result.scalar() or 0

    def _row_to_task(self, row: tuple) -> BackgroundTask:
        """Convert database row to BackgroundTask."""
        import json

        # Row columns: id, task_type, payload, priority, status,
        #              steps, progress, created_by_session_id,
        #              notification_channels, result, error_details,
        #              created_at, started_at, completed_at
        task_id = UUID(str(row[0])) if row[0] else None
        payload = row[2] if isinstance(row[2], dict) else json.loads(row[2] or "{}")
        steps_data = row[5] if isinstance(row[5], list) else json.loads(row[5] or "[]")
        progress = row[6] if isinstance(row[6], dict) else json.loads(row[6] or "{}")
        result_data = (
            row[9]
            if isinstance(row[9], dict)
            else json.loads(row[9] or "null")
            if row[9]
            else None
        )
        error_details = (
            row[10]
            if isinstance(row[10], dict)
            else json.loads(row[10] or "null")
            if row[10]
            else None
        )

        return BackgroundTask(
            id=task_id,
            task_type=row[1],
            name=payload.get("name", row[1]),
            steps=[TaskStep(**s) for s in steps_data],
            payload=payload.get("input", {}),
            created_by_session_id=row[7],
            notification_channels=row[8] or ["conversation"],
            timeout_seconds=payload.get("timeout_seconds", 3600),
            priority=TaskPriority(row[3]),
            status=TaskStatus(row[4]),
            progress=progress,
            result=result_data,
            error_details=error_details,
            created_at=row[11],
            started_at=row[12],
            completed_at=row[13],
        )

    def _row_to_template(self, row: tuple) -> TaskTemplate:
        """Convert database row to TaskTemplate."""
        import json

        # Row columns: id, task_type, name, description, steps,
        #              default_config, timeout_seconds, enabled,
        #              created_at, updated_at
        template_id = UUID(str(row[0])) if row[0] else None
        steps_data = row[4] if isinstance(row[4], list) else json.loads(row[4] or "[]")
        default_config = (
            row[5] if isinstance(row[5], dict) else json.loads(row[5] or "{}")
        )

        return TaskTemplate(
            id=template_id,
            task_type=row[1],
            name=row[2],
            description=row[3],
            steps=[TaskStep(**s) for s in steps_data],
            default_config=default_config,
            timeout_seconds=row[6] or 3600,
            enabled=row[7],
            created_at=row[8],
            updated_at=row[9],
        )


def _to_json(data: dict | list | None) -> str:
    """Convert data to JSON string."""
    import json

    return json.dumps(data, default=str)


def _parse_datetime(value: str | None) -> datetime | None:
    """Parse ISO datetime string."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None


def _escape_pg_array_element(value: str) -> str:
    """Escape a value for PostgreSQL array literal.

    Properly handles quotes and backslashes to prevent injection.

    Args:
        value: String value to escape.

    Returns:
        Escaped and quoted string for use in PostgreSQL array literal.
    """
    # Escape backslashes first, then double-quotes
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'
