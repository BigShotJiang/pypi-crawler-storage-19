"""Exceptions for Background Task Runner."""


class BackgroundTaskError(Exception):
    """Base exception for background task errors."""

    pass


class TaskNotFoundError(BackgroundTaskError):
    """Raised when a task is not found."""

    def __init__(self, task_id: str) -> None:
        """Initialize with task ID.

        Args:
            task_id: The ID of the task that was not found.
        """
        self.task_id = task_id
        super().__init__(f"Task not found: {task_id}")


class TaskTemplateNotFoundError(BackgroundTaskError):
    """Raised when a task template is not found."""

    def __init__(self, task_type: str) -> None:
        """Initialize with task type.

        Args:
            task_type: The type of task template that was not found.
        """
        self.task_type = task_type
        super().__init__(f"Task template not found: {task_type}")


class TaskLimitExceededError(BackgroundTaskError):
    """Raised when the active task limit is exceeded."""

    def __init__(self, limit: int, current: int) -> None:
        """Initialize with limit information.

        Args:
            limit: Maximum allowed active tasks.
            current: Current number of active tasks.
        """
        self.limit = limit
        self.current = current
        super().__init__(
            f"Active task limit exceeded: {current}/{limit} tasks active"
        )


class TaskExecutionError(BackgroundTaskError):
    """Raised when task execution fails."""

    def __init__(self, task_id: str, step_name: str, error: str) -> None:
        """Initialize with execution details.

        Args:
            task_id: The ID of the failed task.
            step_name: The name of the failed step.
            error: The error message.
        """
        self.task_id = task_id
        self.step_name = step_name
        self.error = error
        super().__init__(f"Task {task_id} failed at step '{step_name}': {error}")


class TaskTimeoutError(BackgroundTaskError):
    """Raised when a task or step times out."""

    def __init__(self, task_id: str, timeout_seconds: int) -> None:
        """Initialize with timeout details.

        Args:
            task_id: The ID of the timed-out task.
            timeout_seconds: The timeout duration.
        """
        self.task_id = task_id
        self.timeout_seconds = timeout_seconds
        super().__init__(f"Task {task_id} timed out after {timeout_seconds}s")


class StepValidationError(BackgroundTaskError):
    """Raised when step configuration is invalid."""

    def __init__(self, step_name: str, error: str) -> None:
        """Initialize with validation details.

        Args:
            step_name: The name of the invalid step.
            error: The validation error message.
        """
        self.step_name = step_name
        self.error = error
        super().__init__(f"Invalid step '{step_name}': {error}")
