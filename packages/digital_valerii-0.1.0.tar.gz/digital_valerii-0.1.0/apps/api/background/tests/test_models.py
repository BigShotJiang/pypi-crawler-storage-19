"""Tests for background task models."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from apps.api.background.models import (
    BackgroundTask,
    BackgroundTaskCreate,
    BackgroundTaskUpdate,
    StepResult,
    StepStatus,
    TaskFilter,
    TaskPriority,
    TaskProgress,
    TaskResponse,
    TaskStatus,
    TaskStep,
    TaskTemplate,
    TaskTemplateCreate,
    TaskTemplateUpdate,
)


# =============================================================================
# TaskStatus and TaskPriority Tests
# =============================================================================


class TestEnums:
    """Tests for enum values."""

    def test_task_status_values(self) -> None:
        """Test TaskStatus enum values."""
        assert TaskStatus.PENDING.value == "pending"
        assert TaskStatus.RUNNING.value == "running"
        assert TaskStatus.PAUSED.value == "paused"
        assert TaskStatus.COMPLETED.value == "completed"
        assert TaskStatus.FAILED.value == "failed"
        assert TaskStatus.CANCELLED.value == "cancelled"

    def test_task_priority_values(self) -> None:
        """Test TaskPriority enum values."""
        assert TaskPriority.LOW.value == "low"
        assert TaskPriority.NORMAL.value == "normal"
        assert TaskPriority.HIGH.value == "high"
        assert TaskPriority.CRITICAL.value == "critical"

    def test_step_status_values(self) -> None:
        """Test StepStatus enum values."""
        assert StepStatus.PENDING.value == "pending"
        assert StepStatus.RUNNING.value == "running"
        assert StepStatus.COMPLETED.value == "completed"
        assert StepStatus.FAILED.value == "failed"
        assert StepStatus.SKIPPED.value == "skipped"


# =============================================================================
# TaskStep Tests
# =============================================================================


class TestTaskStep:
    """Tests for TaskStep model."""

    def test_minimal_step(self) -> None:
        """Test step with minimal fields."""
        step = TaskStep(name="test", executor="python")
        assert step.name == "test"
        assert step.executor == "python"
        assert step.config == {}
        assert step.timeout_seconds == 300
        assert step.retry_count == 3
        assert step.continue_on_failure is False

    def test_full_step(self) -> None:
        """Test step with all fields."""
        step = TaskStep(
            name="process_data",
            executor="ai",
            config={"prompt": "Analyze {data}"},
            timeout_seconds=600,
            retry_count=5,
            continue_on_failure=True,
        )
        assert step.name == "process_data"
        assert step.executor == "ai"
        assert step.config["prompt"] == "Analyze {data}"
        assert step.timeout_seconds == 600
        assert step.retry_count == 5
        assert step.continue_on_failure is True

    def test_executor_literal(self) -> None:
        """Test executor accepts only valid literals."""
        # Valid executors
        TaskStep(name="test", executor="python")
        TaskStep(name="test", executor="ai")

        # Invalid executor
        with pytest.raises(ValueError):
            TaskStep(name="test", executor="bash")  # type: ignore

    def test_name_max_length(self) -> None:
        """Test name max length validation."""
        # At max length
        step = TaskStep(name="a" * 100, executor="python")
        assert len(step.name) == 100

        # Over max length
        with pytest.raises(ValueError):
            TaskStep(name="a" * 101, executor="python")

    def test_retry_count_bounds(self) -> None:
        """Test retry_count bounds."""
        # Min
        step = TaskStep(name="test", executor="python", retry_count=0)
        assert step.retry_count == 0

        # Max
        step = TaskStep(name="test", executor="python", retry_count=10)
        assert step.retry_count == 10

        # Below min
        with pytest.raises(ValueError):
            TaskStep(name="test", executor="python", retry_count=-1)

        # Above max
        with pytest.raises(ValueError):
            TaskStep(name="test", executor="python", retry_count=11)

    def test_extra_fields_forbidden(self) -> None:
        """Test extra fields are forbidden."""
        with pytest.raises(ValueError):
            TaskStep(
                name="test",
                executor="python",
                extra_field="not_allowed",  # type: ignore
            )


# =============================================================================
# StepResult Tests
# =============================================================================


class TestStepResult:
    """Tests for StepResult model."""

    def test_minimal_result(self) -> None:
        """Test result with minimal fields."""
        result = StepResult(
            step_name="test",
            step_index=0,
            status=StepStatus.COMPLETED,
        )
        assert result.step_name == "test"
        assert result.step_index == 0
        assert result.status == StepStatus.COMPLETED
        assert result.output is None
        assert result.error is None

    def test_full_result(self) -> None:
        """Test result with all fields."""
        now = datetime.now(UTC)
        result = StepResult(
            step_name="process",
            step_index=1,
            status=StepStatus.COMPLETED,
            output={"data": "processed"},
            tokens_used=150,
            started_at=now,
            completed_at=now,
            duration_ms=500,
        )
        assert result.output == {"data": "processed"}
        assert result.tokens_used == 150
        assert result.duration_ms == 500

    def test_frozen_model(self) -> None:
        """Test that StepResult is frozen."""
        result = StepResult(
            step_name="test",
            step_index=0,
            status=StepStatus.COMPLETED,
        )
        with pytest.raises(ValueError):
            result.step_name = "changed"  # type: ignore


# =============================================================================
# BackgroundTaskCreate Tests
# =============================================================================


class TestBackgroundTaskCreate:
    """Tests for BackgroundTaskCreate model."""

    def test_minimal_task(self) -> None:
        """Test task with minimal fields."""
        step = TaskStep(name="test", executor="python")
        task = BackgroundTaskCreate(
            task_type="test_type",
            name="Test Task",
            steps=[step],
        )
        assert task.task_type == "test_type"
        assert task.name == "Test Task"
        assert len(task.steps) == 1
        assert task.payload == {}
        assert task.notification_channels == ["conversation"]
        assert task.timeout_seconds == 3600
        assert task.priority == TaskPriority.NORMAL

    def test_full_task(self) -> None:
        """Test task with all fields."""
        step = TaskStep(name="test", executor="python")
        task = BackgroundTaskCreate(
            task_type="vulnerability_scan",
            name="Q1 Security Scan",
            steps=[step],
            payload={"target": "production"},
            notification_channels=["conversation", "slack"],
            timeout_seconds=7200,
            priority=TaskPriority.HIGH,
        )
        assert task.task_type == "vulnerability_scan"
        assert task.payload["target"] == "production"
        assert "slack" in task.notification_channels
        assert task.priority == TaskPriority.HIGH

    def test_steps_min_length(self) -> None:
        """Test minimum 1 step required."""
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[],
            )

    def test_steps_max_length(self) -> None:
        """Test maximum 20 steps allowed."""
        step = TaskStep(name="test", executor="python")
        # At max
        task = BackgroundTaskCreate(
            task_type="test",
            name="Test",
            steps=[step] * 20,
        )
        assert len(task.steps) == 20

        # Over max
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[step] * 21,
            )

    def test_timeout_bounds(self) -> None:
        """Test timeout_seconds bounds."""
        step = TaskStep(name="test", executor="python")

        # At min (60 seconds)
        task = BackgroundTaskCreate(
            task_type="test",
            name="Test",
            steps=[step],
            timeout_seconds=60,
        )
        assert task.timeout_seconds == 60

        # At max (86400 = 24 hours)
        task = BackgroundTaskCreate(
            task_type="test",
            name="Test",
            steps=[step],
            timeout_seconds=86400,
        )
        assert task.timeout_seconds == 86400

        # Below min
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[step],
                timeout_seconds=59,
            )

        # Above max
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[step],
                timeout_seconds=86401,
            )


# =============================================================================
# BackgroundTask Tests
# =============================================================================


class TestBackgroundTask:
    """Tests for BackgroundTask model."""

    def test_full_task(self) -> None:
        """Test BackgroundTask with all fields."""
        now = datetime.now(UTC)
        task_id = uuid4()
        step = TaskStep(name="test", executor="python")

        task = BackgroundTask(
            id=task_id,
            task_type="test",
            name="Test Task",
            steps=[step],
            payload={"data": "test"},
            created_by_session_id="session123",
            notification_channels=["conversation"],
            timeout_seconds=3600,
            priority=TaskPriority.NORMAL,
            status=TaskStatus.RUNNING,
            progress={"percent": 50},
            result=None,
            error_details=None,
            created_at=now,
            started_at=now,
            completed_at=None,
        )

        assert task.id == task_id
        assert task.status == TaskStatus.RUNNING
        assert task.progress == {"percent": 50}


# =============================================================================
# TaskProgress Tests
# =============================================================================


class TestTaskProgress:
    """Tests for TaskProgress model."""

    def test_minimal_progress(self) -> None:
        """Test progress with minimal fields."""
        task_id = uuid4()
        now = datetime.now(UTC)

        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.PENDING,
            total_steps=3,
            percent=0,
            message="Waiting",
            started_at=now,
            updated_at=now,
        )

        assert progress.task_id == task_id
        assert progress.current_step is None
        assert progress.step_index == 0
        assert progress.percent == 0

    def test_full_progress(self) -> None:
        """Test progress with all fields."""
        task_id = uuid4()
        now = datetime.now(UTC)

        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            current_step="process_data",
            step_index=1,
            total_steps=3,
            percent=33,
            message="Processing data...",
            started_at=now,
            updated_at=now,
            estimated_completion=now,
        )

        assert progress.current_step == "process_data"
        assert progress.percent == 33
        assert progress.estimated_completion == now

    def test_percent_bounds(self) -> None:
        """Test percent bounds 0-100."""
        task_id = uuid4()
        now = datetime.now(UTC)

        # Min
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.PENDING,
            total_steps=1,
            percent=0,
            message="Start",
            started_at=now,
            updated_at=now,
        )
        assert progress.percent == 0

        # Max
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.COMPLETED,
            total_steps=1,
            percent=100,
            message="Done",
            started_at=now,
            updated_at=now,
        )
        assert progress.percent == 100

        # Below min
        with pytest.raises(ValueError):
            TaskProgress(
                task_id=task_id,
                status=TaskStatus.PENDING,
                total_steps=1,
                percent=-1,
                message="Invalid",
                started_at=now,
                updated_at=now,
            )

        # Above max
        with pytest.raises(ValueError):
            TaskProgress(
                task_id=task_id,
                status=TaskStatus.COMPLETED,
                total_steps=1,
                percent=101,
                message="Invalid",
                started_at=now,
                updated_at=now,
            )


# =============================================================================
# TaskTemplate Tests
# =============================================================================


class TestTaskTemplateCreate:
    """Tests for TaskTemplateCreate model."""

    def test_minimal_template(self) -> None:
        """Test template with minimal fields."""
        step = TaskStep(name="test", executor="python")
        template = TaskTemplateCreate(
            task_type="test_type",
            name="Test Template",
            steps=[step],
        )
        assert template.task_type == "test_type"
        assert template.name == "Test Template"
        assert template.description is None
        assert template.default_config == {}
        assert template.timeout_seconds == 3600

    def test_full_template(self) -> None:
        """Test template with all fields."""
        step = TaskStep(name="test", executor="python")
        template = TaskTemplateCreate(
            task_type="vulnerability_scan",
            name="Security Scan",
            description="Performs a full security scan",
            steps=[step],
            default_config={"target": "all_systems"},
            timeout_seconds=7200,
        )
        assert template.description == "Performs a full security scan"
        assert template.default_config["target"] == "all_systems"

    def test_description_max_length(self) -> None:
        """Test description max length."""
        step = TaskStep(name="test", executor="python")

        # At max
        template = TaskTemplateCreate(
            task_type="test",
            name="Test",
            description="a" * 2000,
            steps=[step],
        )
        assert len(template.description) == 2000

        # Over max
        with pytest.raises(ValueError):
            TaskTemplateCreate(
                task_type="test",
                name="Test",
                description="a" * 2001,
                steps=[step],
            )


class TestTaskTemplateUpdate:
    """Tests for TaskTemplateUpdate model."""

    def test_empty_update(self) -> None:
        """Test empty update."""
        update = TaskTemplateUpdate()
        assert update.name is None
        assert update.description is None
        assert update.steps is None
        assert update.enabled is None

    def test_partial_update(self) -> None:
        """Test partial update."""
        update = TaskTemplateUpdate(
            name="Updated Name",
            enabled=False,
        )
        assert update.name == "Updated Name"
        assert update.enabled is False
        assert update.steps is None


# =============================================================================
# TaskFilter Tests
# =============================================================================


class TestTaskFilter:
    """Tests for TaskFilter model."""

    def test_default_values(self) -> None:
        """Test default filter values."""
        filter_ = TaskFilter()
        assert filter_.status is None
        assert filter_.task_type is None
        assert filter_.session_id is None
        assert filter_.priority is None
        assert filter_.limit == 20
        assert filter_.offset == 0

    def test_full_filter(self) -> None:
        """Test filter with all fields."""
        filter_ = TaskFilter(
            status=TaskStatus.RUNNING,
            task_type="vulnerability_scan",
            session_id="session123",
            priority=TaskPriority.HIGH,
            limit=50,
            offset=10,
        )
        assert filter_.status == TaskStatus.RUNNING
        assert filter_.task_type == "vulnerability_scan"
        assert filter_.priority == TaskPriority.HIGH
        assert filter_.limit == 50
        assert filter_.offset == 10

    def test_limit_bounds(self) -> None:
        """Test limit bounds."""
        # Min
        filter_ = TaskFilter(limit=1)
        assert filter_.limit == 1

        # Max
        filter_ = TaskFilter(limit=100)
        assert filter_.limit == 100

        # Below min
        with pytest.raises(ValueError):
            TaskFilter(limit=0)

        # Above max
        with pytest.raises(ValueError):
            TaskFilter(limit=101)

    def test_offset_non_negative(self) -> None:
        """Test offset non-negative."""
        # Zero
        filter_ = TaskFilter(offset=0)
        assert filter_.offset == 0

        # Positive
        filter_ = TaskFilter(offset=100)
        assert filter_.offset == 100

        # Negative
        with pytest.raises(ValueError):
            TaskFilter(offset=-1)
