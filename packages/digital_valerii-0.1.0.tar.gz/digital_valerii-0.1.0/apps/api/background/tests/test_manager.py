"""Tests for BackgroundTaskManager."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from apps.api.background.exceptions import (
    TaskLimitExceededError,
    TaskNotFoundError,
    TaskTemplateNotFoundError,
)
from apps.api.background.manager import MAX_ACTIVE_TASKS, BackgroundTaskManager
from apps.api.background.models import (
    BackgroundTaskCreate,
    BackgroundTaskUpdate,
    TaskFilter,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskStep,
    TaskTemplateCreate,
    TaskTemplateUpdate,
)
from apps.api.background.tests.conftest import MockResult

# =============================================================================
# Task Creation Tests
# =============================================================================


class TestCreateTask:
    """Tests for task creation."""

    @pytest.mark.asyncio
    async def test_create_task_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_create: BackgroundTaskCreate,
    ) -> None:
        """Test successful task creation."""
        # Mock: count active tasks returns 0
        mock_session.add_result(MockResult(scalar_value=0))
        # Mock: insert returns
        mock_session.add_result(MockResult())

        task = await manager.create_task(sample_task_create, session_id="session123")

        assert task.task_type == "test_task"
        assert task.name == "Test Task"
        assert task.status == TaskStatus.PENDING
        assert task.created_by_session_id == "session123"
        assert len(task.steps) == 1

    @pytest.mark.asyncio
    async def test_create_task_without_session(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_create: BackgroundTaskCreate,
    ) -> None:
        """Test task creation without session ID."""
        # Mock: insert returns (no count check without session_id)
        mock_session.add_result(MockResult())

        task = await manager.create_task(sample_task_create)

        assert task.task_type == "test_task"
        assert task.created_by_session_id is None

    @pytest.mark.asyncio
    async def test_create_task_limit_exceeded(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_create: BackgroundTaskCreate,
    ) -> None:
        """Test task creation fails when limit exceeded."""
        # Mock: count active tasks returns MAX
        mock_session.add_result(MockResult(scalar_value=MAX_ACTIVE_TASKS))

        with pytest.raises(TaskLimitExceededError) as exc_info:
            await manager.create_task(sample_task_create, session_id="session123")

        assert exc_info.value.limit == MAX_ACTIVE_TASKS
        assert exc_info.value.current == MAX_ACTIVE_TASKS

    @pytest.mark.asyncio
    async def test_create_task_with_multiple_steps(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task creation with multiple steps."""
        mock_session.add_result(MockResult(scalar_value=0))
        mock_session.add_result(MockResult())

        task_create = BackgroundTaskCreate(
            task_type="multi_step",
            name="Multi Step Task",
            steps=[
                TaskStep(name="step1", executor="python", config={}),
                TaskStep(name="step2", executor="ai", config={"prompt": "test"}),
                TaskStep(name="step3", executor="python", config={}),
            ],
        )

        task = await manager.create_task(task_create, session_id="session123")

        assert len(task.steps) == 3
        assert task.steps[0].name == "step1"
        assert task.steps[1].executor == "ai"


class TestCreateFromTemplate:
    """Tests for creating tasks from templates."""

    @pytest.mark.asyncio
    async def test_create_from_template_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_template_row: tuple,
    ) -> None:
        """Test successful task creation from template."""
        # Mock: get template
        mock_session.add_result(MockResult([sample_template_row]))
        # Mock: count active tasks
        mock_session.add_result(MockResult(scalar_value=0))
        # Mock: insert task
        mock_session.add_result(MockResult())

        task = await manager.create_from_template_by_type(
            task_type="test_template",
            name="Instance of Template",
            config={"override": "value"},
            session_id="session123",
        )

        assert task.task_type == "test_template"
        assert task.name == "Instance of Template"

    @pytest.mark.asyncio
    async def test_create_from_template_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task creation fails when template not found."""
        # Mock: get template returns None
        mock_session.add_result(MockResult())

        with pytest.raises(TaskTemplateNotFoundError) as exc_info:
            await manager.create_from_template_by_type(
                task_type="nonexistent",
                name="Test",
            )

        assert exc_info.value.task_type == "nonexistent"


# =============================================================================
# Task Retrieval Tests
# =============================================================================


class TestGetTask:
    """Tests for task retrieval."""

    @pytest.mark.asyncio
    async def test_get_task_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test successful task retrieval."""
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        task = await manager.get_task(task_id)

        assert task.task_type == "test_task"
        assert task.status == TaskStatus.PENDING

    @pytest.mark.asyncio
    async def test_get_task_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task retrieval fails when not found."""
        mock_session.add_result(MockResult())

        task_id = uuid4()
        with pytest.raises(TaskNotFoundError) as exc_info:
            await manager.get_task(task_id)

        assert exc_info.value.task_id == str(task_id)


class TestListTasks:
    """Tests for listing tasks."""

    @pytest.mark.asyncio
    async def test_list_tasks_empty(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test listing tasks returns empty list."""
        # Mock: count
        mock_session.add_result(MockResult(scalar_value=0))
        # Mock: list
        mock_session.add_result(MockResult([]))

        tasks, total = await manager.list_tasks(TaskFilter())

        assert tasks == []
        assert total == 0

    @pytest.mark.asyncio
    async def test_list_tasks_with_results(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test listing tasks with results."""
        # Mock: count
        mock_session.add_result(MockResult(scalar_value=2))
        # Mock: list
        mock_session.add_result(MockResult([sample_task_row, sample_task_row]))

        tasks, total = await manager.list_tasks(TaskFilter())

        assert len(tasks) == 2
        assert total == 2

    @pytest.mark.asyncio
    async def test_list_tasks_with_filter(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test listing tasks with filter."""
        # Mock: count
        mock_session.add_result(MockResult(scalar_value=1))
        # Mock: list
        mock_session.add_result(MockResult([sample_task_row]))

        filter_ = TaskFilter(
            status=TaskStatus.PENDING,
            task_type="test_task",
            limit=10,
        )
        tasks, total = await manager.list_tasks(filter_)

        assert len(tasks) == 1


class TestGetActiveTasks:
    """Tests for getting active tasks."""

    @pytest.mark.asyncio
    async def test_get_active_tasks_empty(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test getting active tasks when none exist."""
        mock_session.add_result(MockResult([]))

        tasks = await manager.get_active_tasks("session123")

        assert tasks == []

    @pytest.mark.asyncio
    async def test_get_active_tasks_with_results(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test getting active tasks with results."""
        mock_session.add_result(MockResult([sample_task_row]))

        tasks = await manager.get_active_tasks("session123")

        assert len(tasks) == 1


# =============================================================================
# Task Update Tests
# =============================================================================


class TestUpdateTask:
    """Tests for task updates."""

    @pytest.mark.asyncio
    async def test_update_task_name(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test updating task name."""
        # Mock: update returns row (uses own session context)
        mock_session.add_result(MockResult([("id",)]))
        # Mock: get task (uses its own session context)
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        update = BackgroundTaskUpdate(name="Updated Name")
        task = await manager.update_task(task_id, update)

        assert task is not None

    @pytest.mark.asyncio
    async def test_update_task_priority(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test updating task priority."""
        # Mock: update returns row
        mock_session.add_result(MockResult([("id",)]))
        # Mock: get task
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        update = BackgroundTaskUpdate(priority=TaskPriority.HIGH)
        task = await manager.update_task(task_id, update)

        assert task is not None

    @pytest.mark.asyncio
    async def test_update_task_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task update fails when not found."""
        mock_session.add_result(MockResult())

        task_id = uuid4()
        update = BackgroundTaskUpdate(name="Updated Name")

        with pytest.raises(TaskNotFoundError):
            await manager.update_task(task_id, update)

    @pytest.mark.asyncio
    async def test_update_task_empty_update(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test empty update returns current task."""
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        update = BackgroundTaskUpdate()
        task = await manager.update_task(task_id, update)

        assert task is not None


class TestDeleteTask:
    """Tests for task deletion."""

    @pytest.mark.asyncio
    async def test_delete_task_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test successful task deletion."""
        mock_session.add_result(MockResult([("id",)]))
        mock_session.add_result(MockResult())

        task_id = uuid4()
        await manager.delete_task(task_id)

        # Should not raise

    @pytest.mark.asyncio
    async def test_delete_task_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task deletion fails when not found."""
        mock_session.add_result(MockResult())

        task_id = uuid4()
        with pytest.raises(TaskNotFoundError):
            await manager.delete_task(task_id)


class TestCancelTask:
    """Tests for task cancellation."""

    @pytest.mark.asyncio
    async def test_cancel_task_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test successful task cancellation."""
        # Mock: update returns row
        mock_session.add_result(MockResult([("id",)]))
        # Mock: get_task returns task
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        task = await manager.cancel_task(task_id)

        assert task is not None

    @pytest.mark.asyncio
    async def test_cancel_task_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test task cancellation fails when not found."""
        mock_session.add_result(MockResult())

        task_id = uuid4()
        with pytest.raises(TaskNotFoundError):
            await manager.cancel_task(task_id)


# =============================================================================
# Progress Tests
# =============================================================================


class TestGetProgress:
    """Tests for progress retrieval."""

    @pytest.mark.asyncio
    async def test_get_progress_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_task_row: tuple,
    ) -> None:
        """Test successful progress retrieval."""
        mock_session.add_result(MockResult([sample_task_row]))

        task_id = uuid4()
        progress = await manager.get_progress(task_id)

        assert progress.task_id == task_id
        assert progress.status == TaskStatus.PENDING
        assert progress.percent == 0

    @pytest.mark.asyncio
    async def test_get_progress_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test progress retrieval fails when task not found."""
        mock_session.add_result(MockResult())

        task_id = uuid4()
        with pytest.raises(TaskNotFoundError):
            await manager.get_progress(task_id)


class TestUpdateProgress:
    """Tests for progress updates."""

    @pytest.mark.asyncio
    async def test_update_progress_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test successful progress update."""
        mock_session.add_result(MockResult())
        mock_session.add_result(MockResult())

        task_id = uuid4()
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            current_step="step1",
            step_index=0,
            total_steps=3,
            percent=33,
            message="Processing step 1",
            started_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )

        await manager.update_progress(task_id, progress)

        # Should not raise


# =============================================================================
# Template Tests
# =============================================================================


class TestCreateTemplate:
    """Tests for template creation."""

    @pytest.mark.asyncio
    async def test_create_template_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_template_create: TaskTemplateCreate,
    ) -> None:
        """Test successful template creation."""
        mock_session.add_result(MockResult())
        mock_session.add_result(MockResult())

        template = await manager.create_template(sample_template_create)

        assert template.task_type == "test_template"
        assert template.name == "Test Template"
        assert template.enabled is True


class TestGetTemplateByType:
    """Tests for template retrieval by type."""

    @pytest.mark.asyncio
    async def test_get_template_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_template_row: tuple,
    ) -> None:
        """Test successful template retrieval."""
        mock_session.add_result(MockResult([sample_template_row]))

        template = await manager.get_template_by_type("test_template")

        assert template is not None
        assert template.task_type == "test_template"

    @pytest.mark.asyncio
    async def test_get_template_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test template retrieval returns None when not found."""
        mock_session.add_result(MockResult())

        template = await manager.get_template_by_type("nonexistent")

        assert template is None


class TestListTemplates:
    """Tests for listing templates."""

    @pytest.mark.asyncio
    async def test_list_templates_empty(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test listing templates returns empty list."""
        mock_session.add_result(MockResult([]))

        templates = await manager.list_templates()

        assert templates == []

    @pytest.mark.asyncio
    async def test_list_templates_with_results(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_template_row: tuple,
    ) -> None:
        """Test listing templates with results."""
        mock_session.add_result(MockResult([sample_template_row]))

        templates = await manager.list_templates()

        assert len(templates) == 1


class TestUpdateTemplate:
    """Tests for template updates."""

    @pytest.mark.asyncio
    async def test_update_template_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
        sample_template_row: tuple,
    ) -> None:
        """Test successful template update."""
        # Mock: update returns row
        mock_session.add_result(MockResult([("id",)]))
        # Mock: get_template_by_type returns template
        mock_session.add_result(MockResult([sample_template_row]))

        update = TaskTemplateUpdate(name="Updated Template")
        template = await manager.update_template("test_template", update)

        assert template is not None

    @pytest.mark.asyncio
    async def test_update_template_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test template update fails when not found."""
        mock_session.add_result(MockResult())

        update = TaskTemplateUpdate(name="Updated")
        with pytest.raises(TaskTemplateNotFoundError):
            await manager.update_template("nonexistent", update)


class TestDeleteTemplate:
    """Tests for template deletion."""

    @pytest.mark.asyncio
    async def test_delete_template_success(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test successful template deletion."""
        mock_session.add_result(MockResult([("id",)]))
        mock_session.add_result(MockResult())

        await manager.delete_template("test_template")

        # Should not raise

    @pytest.mark.asyncio
    async def test_delete_template_not_found(
        self,
        manager: BackgroundTaskManager,
        mock_session,
    ) -> None:
        """Test template deletion fails when not found."""
        mock_session.add_result(MockResult())

        with pytest.raises(TaskTemplateNotFoundError):
            await manager.delete_template("nonexistent")


# =============================================================================
# Model Validation Tests
# =============================================================================


class TestTaskStepValidation:
    """Tests for TaskStep validation."""

    def test_valid_python_step(self) -> None:
        """Test valid Python step."""
        step = TaskStep(
            name="test",
            executor="python",
            config={"action": "test"},
        )
        assert step.executor == "python"

    def test_valid_ai_step(self) -> None:
        """Test valid AI step."""
        step = TaskStep(
            name="test",
            executor="ai",
            config={"prompt": "analyze"},
        )
        assert step.executor == "ai"

    def test_invalid_executor(self) -> None:
        """Test invalid executor type."""
        with pytest.raises(ValueError):
            TaskStep(
                name="test",
                executor="invalid",
                config={},
            )

    def test_timeout_bounds(self) -> None:
        """Test timeout bounds."""
        # Min bound
        step = TaskStep(name="test", executor="python", timeout_seconds=1)
        assert step.timeout_seconds == 1

        # Max bound
        step = TaskStep(name="test", executor="python", timeout_seconds=3600)
        assert step.timeout_seconds == 3600

        # Below min
        with pytest.raises(ValueError):
            TaskStep(name="test", executor="python", timeout_seconds=0)

        # Above max
        with pytest.raises(ValueError):
            TaskStep(name="test", executor="python", timeout_seconds=3601)


class TestBackgroundTaskCreateValidation:
    """Tests for BackgroundTaskCreate validation."""

    def test_valid_task(self, sample_step: TaskStep) -> None:
        """Test valid task creation."""
        task = BackgroundTaskCreate(
            task_type="test",
            name="Test",
            steps=[sample_step],
        )
        assert task.task_type == "test"

    def test_empty_steps_rejected(self) -> None:
        """Test empty steps rejected."""
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[],
            )

    def test_max_steps_exceeded(self, sample_step: TaskStep) -> None:
        """Test max steps exceeded."""
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[sample_step] * 21,  # Max is 20
            )

    def test_timeout_bounds(self, sample_step: TaskStep) -> None:
        """Test task timeout bounds."""
        # Min bound
        task = BackgroundTaskCreate(
            task_type="test",
            name="Test",
            steps=[sample_step],
            timeout_seconds=60,
        )
        assert task.timeout_seconds == 60

        # Below min
        with pytest.raises(ValueError):
            BackgroundTaskCreate(
                task_type="test",
                name="Test",
                steps=[sample_step],
                timeout_seconds=59,
            )


class TestTaskFilterValidation:
    """Tests for TaskFilter validation."""

    def test_default_values(self) -> None:
        """Test default filter values."""
        filter_ = TaskFilter()
        assert filter_.limit == 20
        assert filter_.offset == 0

    def test_limit_bounds(self) -> None:
        """Test limit bounds."""
        # Min bound
        filter_ = TaskFilter(limit=1)
        assert filter_.limit == 1

        # Max bound
        filter_ = TaskFilter(limit=100)
        assert filter_.limit == 100

        # Below min
        with pytest.raises(ValueError):
            TaskFilter(limit=0)

        # Above max
        with pytest.raises(ValueError):
            TaskFilter(limit=101)
