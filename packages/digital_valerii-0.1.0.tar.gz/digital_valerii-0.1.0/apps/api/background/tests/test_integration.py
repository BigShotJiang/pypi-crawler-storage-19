"""Integration tests for background task routes and context."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from apps.api.auth.dependencies import get_current_user
from apps.api.auth.models import User
from apps.api.background.context import (
    BackgroundTaskContextProvider,
    create_context_provider,
)
from apps.api.background.exceptions import TaskLimitExceededError, TaskNotFoundError
from apps.api.background.models import (
    BackgroundTask,
    TaskPriority,
    TaskProgress,
    TaskStatus,
    TaskStep,
    TaskTemplate,
)
from apps.api.background.progress import ProgressTracker
from apps.api.background.routes import get_background_task_manager, router


# Fixtures
@pytest.fixture
def mock_manager() -> MagicMock:
    """Create mock BackgroundTaskManager."""
    manager = MagicMock()
    manager.create_task = AsyncMock()
    manager.create_from_template = AsyncMock()
    manager.get_task = AsyncMock()
    manager.list_tasks = AsyncMock(return_value=([], 0))
    manager.cancel_task = AsyncMock()
    manager.delete_task = AsyncMock()
    manager.list_templates = AsyncMock(return_value=[])
    manager.get_template = AsyncMock()
    manager.create_template = AsyncMock()
    manager.get_active_tasks = AsyncMock(return_value=[])
    return manager


@pytest.fixture
def mock_tracker() -> MagicMock:
    """Create mock ProgressTracker."""
    tracker = MagicMock(spec=ProgressTracker)
    tracker.get_progress = AsyncMock(return_value=None)
    return tracker


@pytest.fixture
def mock_user() -> MagicMock:
    """Create mock user for auth."""
    user = MagicMock(spec=User)
    user.id = uuid4()
    user.email = "test@example.com"
    user.display_name = "Test User"
    user.is_active = True
    return user


@pytest.fixture
def sample_task(mock_user: MagicMock) -> BackgroundTask:
    """Create sample task owned by mock_user."""
    return BackgroundTask(
        id=uuid4(),
        task_type="test_task",
        name="Test Task",
        status=TaskStatus.PENDING,
        priority=TaskPriority.NORMAL,
        steps=[TaskStep(name="step1", executor="python", config={})],
        payload={"key": "value"},
        created_by_session_id=str(mock_user.id),  # Use mock_user's ID for ownership
        notification_channels=["conversation"],
        timeout_seconds=3600,
        created_at=datetime.now(UTC),
    )


@pytest.fixture
def other_user_task() -> BackgroundTask:
    """Create sample task owned by a different user."""
    return BackgroundTask(
        id=uuid4(),
        task_type="test_task",
        name="Other User Task",
        status=TaskStatus.PENDING,
        priority=TaskPriority.NORMAL,
        steps=[TaskStep(name="step1", executor="python", config={})],
        payload={"key": "value"},
        created_by_session_id="other-user-id",  # Different user
        notification_channels=["conversation"],
        timeout_seconds=3600,
        created_at=datetime.now(UTC),
    )


@pytest.fixture
def sample_template() -> TaskTemplate:
    """Create sample template."""
    return TaskTemplate(
        id=uuid4(),
        task_type="scan",
        name="Security Scan",
        description="Run security scan",
        steps=[TaskStep(name="scan", executor="python", config={})],
        default_config={},
        timeout_seconds=3600,
        enabled=True,
        created_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


@pytest.fixture
def app(mock_manager: MagicMock, mock_tracker: MagicMock, mock_user: User) -> FastAPI:
    """Create test FastAPI app."""
    app = FastAPI()
    app.include_router(router)

    # Override dependencies
    app.dependency_overrides[get_background_task_manager] = lambda: mock_manager
    from apps.api.background.progress import get_progress_tracker

    app.dependency_overrides[get_progress_tracker] = lambda: mock_tracker
    app.dependency_overrides[get_current_user] = lambda: mock_user

    return app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    """Create test client."""
    return TestClient(app)


# Route Tests
class TestTaskRoutes:
    """Tests for task routes."""

    def test_create_task_from_template(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test creating task from template."""
        mock_manager.create_from_template.return_value = sample_task
        template_id = uuid4()

        response = client.post(
            "/background-tasks/from-template",
            json={
                "template_id": str(template_id),
                "name": "My Task",
                "payload": {"target": "prod"},
            },
        )

        assert response.status_code == 201
        data = response.json()
        assert data["task_type"] == "test_task"
        mock_manager.create_from_template.assert_called_once()

    def test_create_task_limit_exceeded(
        self,
        client: TestClient,
        mock_manager: MagicMock,
    ) -> None:
        """Test task creation when limit exceeded."""
        mock_manager.create_from_template.side_effect = TaskLimitExceededError(10, 10)

        response = client.post(
            "/background-tasks/from-template",
            json={
                "template_id": str(uuid4()),
            },
        )

        assert response.status_code == 429

    def test_list_tasks(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test listing tasks."""
        mock_manager.list_tasks.return_value = ([sample_task], 1)

        response = client.get("/background-tasks/")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 1
        assert len(data["tasks"]) == 1

    def test_list_tasks_with_filters(
        self,
        client: TestClient,
        mock_manager: MagicMock,
    ) -> None:
        """Test listing tasks with filters."""
        mock_manager.list_tasks.return_value = ([], 0)

        response = client.get(
            "/background-tasks/",
            params={
                "status": "running",
                "task_type": "scan",
                "limit": 10,
            },
        )

        assert response.status_code == 200
        mock_manager.list_tasks.assert_called_once()

    def test_get_task(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test getting task details."""
        mock_manager.get_task.return_value = sample_task

        response = client.get(f"/background-tasks/{sample_task.id}")

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == str(sample_task.id)

    def test_get_task_not_found(
        self,
        client: TestClient,
        mock_manager: MagicMock,
    ) -> None:
        """Test getting non-existent task."""
        mock_manager.get_task.side_effect = TaskNotFoundError(str(uuid4()))

        response = client.get(f"/background-tasks/{uuid4()}")

        assert response.status_code == 404

    def test_get_task_status(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        mock_tracker: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test getting task status."""
        sample_task.status = TaskStatus.RUNNING
        mock_manager.get_task.return_value = sample_task
        mock_tracker.get_progress.return_value = TaskProgress(
            task_id=sample_task.id,
            status=TaskStatus.RUNNING,
            step_index=1,
            total_steps=3,
            percent=33,
            message="Running...",
            started_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )

        response = client.get(f"/background-tasks/{sample_task.id}/status")

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "running"
        assert data["progress"] is not None
        assert data["progress"]["percent"] == 33

    def test_cancel_task(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test cancelling a task."""
        mock_manager.get_task.return_value = sample_task
        cancelled_task = BackgroundTask(
            id=sample_task.id,
            task_type=sample_task.task_type,
            name=sample_task.name,
            status=TaskStatus.CANCELLED,
            priority=sample_task.priority,
            steps=sample_task.steps,
            payload=sample_task.payload,
            created_by_session_id=sample_task.created_by_session_id,
            notification_channels=sample_task.notification_channels,
            timeout_seconds=sample_task.timeout_seconds,
            created_at=sample_task.created_at,
        )
        mock_manager.cancel_task.return_value = cancelled_task

        response = client.post(f"/background-tasks/{sample_task.id}/cancel")

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "cancelled"

    def test_delete_task(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test deleting a task."""
        mock_manager.get_task.return_value = sample_task
        mock_manager.delete_task.return_value = None

        response = client.delete(f"/background-tasks/{sample_task.id}")

        assert response.status_code == 204


class TestOwnershipEnforcement:
    """Tests for task ownership enforcement."""

    def test_get_task_access_denied(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        other_user_task: BackgroundTask,
    ) -> None:
        """Test accessing another user's task returns 403."""
        mock_manager.get_task.return_value = other_user_task

        response = client.get(f"/background-tasks/{other_user_task.id}")

        assert response.status_code == 403
        assert response.json()["detail"] == "Access denied"

    def test_get_task_status_access_denied(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        other_user_task: BackgroundTask,
    ) -> None:
        """Test getting status of another user's task returns 403."""
        mock_manager.get_task.return_value = other_user_task

        response = client.get(f"/background-tasks/{other_user_task.id}/status")

        assert response.status_code == 403
        assert response.json()["detail"] == "Access denied"

    def test_cancel_task_access_denied(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        other_user_task: BackgroundTask,
    ) -> None:
        """Test cancelling another user's task returns 403."""
        mock_manager.get_task.return_value = other_user_task

        response = client.post(f"/background-tasks/{other_user_task.id}/cancel")

        assert response.status_code == 403
        assert response.json()["detail"] == "Access denied"
        mock_manager.cancel_task.assert_not_called()

    def test_delete_task_access_denied(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        other_user_task: BackgroundTask,
    ) -> None:
        """Test deleting another user's task returns 403."""
        mock_manager.get_task.return_value = other_user_task

        response = client.delete(f"/background-tasks/{other_user_task.id}")

        assert response.status_code == 403
        assert response.json()["detail"] == "Access denied"
        mock_manager.delete_task.assert_not_called()

    def test_list_tasks_only_own_tasks(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        mock_user: MagicMock,
    ) -> None:
        """Test list_tasks always filters by current user's session."""
        mock_manager.list_tasks.return_value = ([], 0)

        response = client.get("/background-tasks/")

        assert response.status_code == 200
        # Verify the filter used the current user's ID
        call_args = mock_manager.list_tasks.call_args
        filter_obj = call_args[0][0]
        assert filter_obj.session_id == str(mock_user.id)


class TestTemplateRoutes:
    """Tests for template routes."""

    def test_list_templates(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_template: TaskTemplate,
    ) -> None:
        """Test listing templates."""
        mock_manager.list_templates.return_value = [sample_template]

        response = client.get("/background-tasks/templates/")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 1

    def test_get_template(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        sample_template: TaskTemplate,
    ) -> None:
        """Test getting template details."""
        mock_manager.get_template.return_value = sample_template

        response = client.get(f"/background-tasks/templates/{sample_template.id}")

        assert response.status_code == 200
        data = response.json()
        assert data["task_type"] == "scan"


class TestSessionRoutes:
    """Tests for session-specific routes."""

    def test_get_session_active_tasks(
        self,
        client: TestClient,
        mock_manager: MagicMock,
        mock_user: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test getting active tasks for current user."""
        mock_manager.get_active_tasks.return_value = [sample_task]

        response = client.get("/background-tasks/my-active")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        mock_manager.get_active_tasks.assert_called_once_with(str(mock_user.id))


# Context Provider Tests
class TestBackgroundTaskContextProvider:
    """Tests for BackgroundTaskContextProvider."""

    @pytest.mark.asyncio
    async def test_get_context_no_tasks(
        self, mock_manager: MagicMock, mock_tracker: MagicMock
    ) -> None:
        """Test context with no active tasks."""
        mock_manager.get_active_tasks.return_value = []

        provider = BackgroundTaskContextProvider(mock_manager, mock_tracker)
        context = await provider.get_context("session-123")

        assert context == ""

    @pytest.mark.asyncio
    async def test_get_context_with_tasks(
        self,
        mock_manager: MagicMock,
        mock_tracker: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test context with active tasks."""
        mock_manager.get_active_tasks.return_value = [sample_task]

        provider = BackgroundTaskContextProvider(mock_manager, mock_tracker)
        context = await provider.get_context("session-123")

        assert "[Active Background Tasks]" in context
        assert sample_task.task_type in context
        assert sample_task.name in context

    @pytest.mark.asyncio
    async def test_get_context_with_progress(
        self,
        mock_manager: MagicMock,
        mock_tracker: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test context includes real-time progress."""
        sample_task.status = TaskStatus.RUNNING
        mock_manager.get_active_tasks.return_value = [sample_task]
        mock_tracker.get_progress.return_value = TaskProgress(
            task_id=sample_task.id,
            status=TaskStatus.RUNNING,
            current_step="processing",
            step_index=2,
            total_steps=5,
            percent=40,
            message="Processing...",
            started_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )

        provider = BackgroundTaskContextProvider(mock_manager, mock_tracker)
        context = await provider.get_context("session-123")

        assert "40%" in context
        assert "processing" in context

    @pytest.mark.asyncio
    async def test_get_context_max_tasks(
        self,
        mock_manager: MagicMock,
        mock_tracker: MagicMock,
    ) -> None:
        """Test context respects max_tasks limit."""
        tasks = [
            BackgroundTask(
                id=uuid4(),
                task_type=f"task_{i}",
                name=f"Task {i}",
                status=TaskStatus.PENDING,
                priority=TaskPriority.NORMAL,
                steps=[TaskStep(name="step", executor="python", config={})],
                timeout_seconds=3600,
                created_at=datetime.now(UTC),
            )
            for i in range(10)
        ]
        mock_manager.get_active_tasks.return_value = tasks

        provider = BackgroundTaskContextProvider(mock_manager, max_tasks=3)
        context = await provider.get_context("session-123")

        assert "task_0" in context
        assert "task_2" in context
        assert "task_5" not in context
        assert "and 7 more task(s)" in context

    @pytest.mark.asyncio
    async def test_get_task_notification_context_completed(
        self,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test notification context for completed task."""
        sample_task.status = TaskStatus.COMPLETED
        sample_task.started_at = datetime.now(UTC)
        sample_task.completed_at = datetime.now(UTC)
        sample_task.result = {"vulnerabilities_found": 47}

        provider = BackgroundTaskContextProvider(mock_manager)
        context = await provider.get_task_notification_context(sample_task)

        assert "✅" in context
        assert sample_task.name in context
        assert "completed" in context.lower()

    @pytest.mark.asyncio
    async def test_get_task_notification_context_failed(
        self,
        mock_manager: MagicMock,
        sample_task: BackgroundTask,
    ) -> None:
        """Test notification context for failed task."""
        sample_task.status = TaskStatus.FAILED
        sample_task.error_details = {"message": "Connection timeout"}

        provider = BackgroundTaskContextProvider(mock_manager)
        context = await provider.get_task_notification_context(sample_task)

        assert "❌" in context
        assert "failed" in context.lower()
        assert "Connection timeout" in context


class TestCreateContextProvider:
    """Tests for factory function."""

    def test_create_context_provider(self, mock_manager: MagicMock) -> None:
        """Test creating context provider."""
        provider = create_context_provider(mock_manager)

        assert isinstance(provider, BackgroundTaskContextProvider)
        assert provider._max_tasks == 5
        assert provider._include_completed is True

    def test_create_context_provider_with_tracker(
        self, mock_manager: MagicMock, mock_tracker: MagicMock
    ) -> None:
        """Test creating context provider with tracker."""
        provider = create_context_provider(mock_manager, mock_tracker)

        assert provider._tracker is mock_tracker
