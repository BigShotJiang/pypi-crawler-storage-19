"""Pytest fixtures for background task tests."""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Any
from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.background.manager import BackgroundTaskManager
from apps.api.background.models import (
    BackgroundTaskCreate,
    TaskPriority,
    TaskStep,
    TaskTemplateCreate,
)


class MockResult:
    """Mock database result."""

    def __init__(
        self, rows: list[tuple[Any, ...]] | None = None, scalar_value: Any = None
    ) -> None:
        self._rows: list[tuple[Any, ...]] = rows or []
        self._scalar_value = scalar_value
        self._index = 0

    def fetchone(self) -> tuple[Any, ...] | None:
        if self._rows:
            return self._rows[0]
        return None

    def fetchall(self) -> list[tuple[Any, ...]]:
        return self._rows

    def scalar(self) -> Any:
        return self._scalar_value


class MockSession:
    """Mock async database session."""

    def __init__(self) -> None:
        self._results: list[MockResult] = []
        self._result_index = 0
        self.execute = AsyncMock(side_effect=self._execute)
        self.commit = AsyncMock()
        self.rollback = AsyncMock()

    def add_result(self, result: MockResult) -> None:
        """Add a mock result for the next execute call."""
        self._results.append(result)

    async def _execute(self, *args: Any, **kwargs: Any) -> MockResult:
        """Return the next queued result or empty result."""
        if self._result_index < len(self._results):
            result = self._results[self._result_index]
            self._result_index += 1
            return result
        return MockResult()


@pytest.fixture
def mock_session() -> MockSession:
    """Create a mock database session."""
    return MockSession()


@pytest.fixture
def session_factory(mock_session: MockSession):
    """Create a session factory that returns the mock session."""

    @asynccontextmanager
    async def _factory() -> AsyncGenerator[MockSession, None]:
        yield mock_session

    return _factory


@pytest.fixture
def manager(session_factory) -> BackgroundTaskManager:
    """Create a BackgroundTaskManager with mock session."""
    return BackgroundTaskManager(session_factory)


@pytest.fixture
def sample_step() -> TaskStep:
    """Sample task step."""
    return TaskStep(
        name="test_step",
        executor="python",
        config={"action": "test"},
        timeout_seconds=60,
    )


@pytest.fixture
def sample_task_create(sample_step: TaskStep) -> BackgroundTaskCreate:
    """Sample task creation request."""
    return BackgroundTaskCreate(
        task_type="test_task",
        name="Test Task",
        steps=[sample_step],
        payload={"key": "value"},
        notification_channels=["conversation"],
        timeout_seconds=3600,
        priority=TaskPriority.NORMAL,
    )


@pytest.fixture
def sample_template_create(sample_step: TaskStep) -> TaskTemplateCreate:
    """Sample template creation request."""
    return TaskTemplateCreate(
        task_type="test_template",
        name="Test Template",
        description="A test template",
        steps=[sample_step],
        default_config={"default_key": "default_value"},
        timeout_seconds=1800,
    )


@pytest.fixture
def sample_task_row() -> tuple:
    """Sample database row for a task."""
    task_id = uuid4()
    return (
        str(task_id),  # id
        "test_task",  # task_type
        '{"name": "Test Task", "input": {"key": "value"}, "timeout_seconds": 3600}',  # payload
        "normal",  # priority
        "pending",  # status
        '[{"name": "test_step", "executor": "python", "config": {}, "timeout_seconds": 60, "retry_count": 3, "continue_on_failure": false}]',  # steps
        '{"task_id": "'
        + str(task_id)
        + '", "status": "pending", "percent": 0}',  # progress
        "session123",  # created_by_session_id
        ["conversation"],  # notification_channels
        None,  # result
        None,  # error_details
        datetime.now(UTC),  # created_at
        None,  # started_at
        None,  # completed_at
    )


@pytest.fixture
def sample_template_row() -> tuple:
    """Sample database row for a template."""
    template_id = uuid4()
    return (
        str(template_id),  # id
        "test_template",  # task_type
        "Test Template",  # name
        "A test template",  # description
        '[{"name": "test_step", "executor": "python", "config": {}, "timeout_seconds": 60, "retry_count": 3, "continue_on_failure": false}]',  # steps
        '{"default_key": "default_value"}',  # default_config
        1800,  # timeout_seconds
        True,  # enabled
        datetime.now(UTC),  # created_at
        datetime.now(UTC),  # updated_at
    )
