"""Tests for background task runner."""
