"""Tests for TaskNotifier."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.background.models import (
    BackgroundTask,
    TaskPriority,
    TaskStatus,
    TaskStep,
)
from apps.api.background.notifier import (
    NotificationResult,
    TaskNotifier,
    TaskResult,
    get_task_notifier,
    reset_task_notifier,
)


# Fixtures
@pytest.fixture
def sample_task() -> BackgroundTask:
    """Create sample task for tests."""
    return BackgroundTask(
        id=uuid4(),
        task_type="vulnerability_scan",
        name="Q1 Security Scan",
        status=TaskStatus.COMPLETED,
        priority=TaskPriority.NORMAL,
        steps=[
            TaskStep(name="scan", executor="python", config={}),
            TaskStep(name="analyze", executor="ai", config={}),
        ],
        payload={"target": "production"},
        created_by_session_id="session-123",
        notification_channels=["conversation", "slack"],
        timeout_seconds=3600,
        created_at=datetime.now(UTC),
    )


@pytest.fixture
def sample_result(sample_task: BackgroundTask) -> TaskResult:
    """Create sample task result."""
    return TaskResult(
        task_id=sample_task.id,
        task_type=sample_task.task_type,
        task_name=sample_task.name,
        status=TaskStatus.COMPLETED,
        started_at=datetime.now(UTC),
        completed_at=datetime.now(UTC),
        duration_seconds=120.5,
        steps_completed=2,
        steps_total=2,
    )


@pytest.fixture
def notifier() -> TaskNotifier:
    """Create TaskNotifier for tests."""
    return TaskNotifier(slack_webhook_url="https://hooks.slack.com/test")


# NotificationResult Tests
class TestNotificationResult:
    """Tests for NotificationResult model."""

    def test_success_result(self) -> None:
        """Test successful notification result."""
        result = NotificationResult(channel="slack", success=True)

        assert result.channel == "slack"
        assert result.success is True
        assert result.error is None

    def test_failure_result(self) -> None:
        """Test failed notification result."""
        result = NotificationResult(
            channel="webhook",
            success=False,
            error="Connection timeout",
        )

        assert result.success is False
        assert result.error == "Connection timeout"

    def test_frozen_model(self) -> None:
        """Test that NotificationResult is frozen."""
        from pydantic import ValidationError

        result = NotificationResult(channel="slack", success=True)

        with pytest.raises(ValidationError):
            result.success = False  # type: ignore[misc]


# TaskResult Tests
class TestTaskResult:
    """Tests for TaskResult model."""

    def test_minimal_result(self) -> None:
        """Test minimal task result."""
        task_id = uuid4()
        result = TaskResult(
            task_id=task_id,
            task_type="scan",
            task_name="Test Scan",
            status=TaskStatus.COMPLETED,
        )

        assert result.task_id == task_id
        assert result.status == TaskStatus.COMPLETED

    def test_full_result(self) -> None:
        """Test task result with all fields."""
        task_id = uuid4()
        now = datetime.now(UTC)

        result = TaskResult(
            task_id=task_id,
            task_type="report",
            task_name="Monthly Report",
            status=TaskStatus.COMPLETED,
            started_at=now,
            completed_at=now,
            duration_seconds=300.0,
            steps_completed=5,
            steps_total=5,
            output={"report_url": "https://example.com/report.pdf"},
        )

        assert result.steps_completed == 5
        assert result.output is not None
        assert result.output["report_url"] == "https://example.com/report.pdf"

    def test_failed_result(self) -> None:
        """Test failed task result."""
        result = TaskResult(
            task_id=uuid4(),
            task_type="import",
            task_name="Data Import",
            status=TaskStatus.FAILED,
            error="Connection refused",
        )

        assert result.status == TaskStatus.FAILED
        assert result.error == "Connection refused"


# Summary Generation Tests
class TestSummaryGeneration:
    """Tests for summary generation."""

    def test_completed_summary(
        self,
        notifier: TaskNotifier,
        sample_task: BackgroundTask,
        sample_result: TaskResult,
    ) -> None:
        """Test summary for completed task."""
        summary = notifier._generate_summary(sample_task, sample_result)

        assert "✅" in summary
        assert sample_task.name in summary
        assert "Completed successfully" in summary
        assert "2/2" in summary  # steps

    def test_failed_summary(
        self, notifier: TaskNotifier, sample_task: BackgroundTask
    ) -> None:
        """Test summary for failed task."""
        result = TaskResult(
            task_id=sample_task.id,
            task_type=sample_task.task_type,
            task_name=sample_task.name,
            status=TaskStatus.FAILED,
            error="Network error: connection refused",
        )

        summary = notifier._generate_summary(sample_task, result)

        assert "❌" in summary
        assert "Failed" in summary
        assert "Network error" in summary

    def test_failed_summary_truncates_long_error(
        self, notifier: TaskNotifier, sample_task: BackgroundTask
    ) -> None:
        """Test that long errors are truncated in summary."""
        long_error = "A" * 500
        result = TaskResult(
            task_id=sample_task.id,
            task_type=sample_task.task_type,
            task_name=sample_task.name,
            status=TaskStatus.FAILED,
            error=long_error,
        )

        summary = notifier._generate_summary(sample_task, result)

        assert "..." in summary
        assert len(summary) < 600  # Should be truncated

    def test_cancelled_summary(
        self, notifier: TaskNotifier, sample_task: BackgroundTask
    ) -> None:
        """Test summary for cancelled task."""
        result = TaskResult(
            task_id=sample_task.id,
            task_type=sample_task.task_type,
            task_name=sample_task.name,
            status=TaskStatus.CANCELLED,
        )

        summary = notifier._generate_summary(sample_task, result)

        assert "⚠️" in summary
        assert "Cancelled" in summary


# Duration Formatting Tests
class TestDurationFormatting:
    """Tests for duration formatting."""

    def test_format_seconds(self, notifier: TaskNotifier) -> None:
        """Test formatting seconds."""
        assert notifier._format_duration(45.5) == "45.5s"

    def test_format_minutes(self, notifier: TaskNotifier) -> None:
        """Test formatting minutes."""
        assert notifier._format_duration(125) == "2m 5s"

    def test_format_hours(self, notifier: TaskNotifier) -> None:
        """Test formatting hours."""
        assert notifier._format_duration(3725) == "1h 2m"


# Progress Bar Tests
class TestProgressBar:
    """Tests for progress bar generation."""

    def test_progress_bar_empty(self, notifier: TaskNotifier) -> None:
        """Test empty progress bar."""
        bar = notifier._make_progress_bar(0)

        assert "░" in bar
        assert "█" not in bar

    def test_progress_bar_half(self, notifier: TaskNotifier) -> None:
        """Test half-filled progress bar."""
        bar = notifier._make_progress_bar(50, width=10)

        assert bar.count("█") == 5
        assert bar.count("░") == 5

    def test_progress_bar_full(self, notifier: TaskNotifier) -> None:
        """Test full progress bar."""
        bar = notifier._make_progress_bar(100)

        assert "█" in bar
        assert "░" not in bar


# Notification Tests
class TestNotifications:
    """Tests for notification delivery."""

    @pytest.mark.asyncio
    async def test_notify_conversation(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test conversation notification."""
        callback = AsyncMock()
        notifier = TaskNotifier(conversation_callback=callback)

        result = await notifier._notify_conversation(
            sample_task, sample_result, "Test summary"
        )

        assert result.success is True
        callback.assert_called_once()
        call_kwargs = callback.call_args[1]
        assert call_kwargs["session_id"] == sample_task.created_by_session_id

    @pytest.mark.asyncio
    async def test_notify_conversation_no_callback(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test conversation notification without callback (logs only)."""
        notifier = TaskNotifier()

        result = await notifier._notify_conversation(
            sample_task, sample_result, "Test summary"
        )

        # Should succeed (logs instead)
        assert result.success is True

    @pytest.mark.asyncio
    async def test_notify_slack_success(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test successful Slack notification."""
        notifier = TaskNotifier(slack_webhook_url="https://hooks.slack.com/test")

        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        notifier._http_client = mock_client

        result = await notifier._notify_slack(
            sample_task, sample_result, "Test summary"
        )

        assert result.success is True
        mock_client.post.assert_called_once()

    @pytest.mark.asyncio
    async def test_notify_slack_no_webhook(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test Slack notification without webhook configured."""
        notifier = TaskNotifier()  # No webhook URL

        result = await notifier._notify_slack(
            sample_task, sample_result, "Test summary"
        )

        assert result.success is False
        assert "not configured" in (result.error or "")

    @pytest.mark.asyncio
    async def test_notify_slack_error(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test Slack notification with API error."""
        notifier = TaskNotifier(slack_webhook_url="https://hooks.slack.com/test")

        mock_response = MagicMock()
        mock_response.status_code = 500

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        notifier._http_client = mock_client

        result = await notifier._notify_slack(
            sample_task, sample_result, "Test summary"
        )

        assert result.success is False
        assert "500" in (result.error or "")

    @pytest.mark.asyncio
    async def test_notify_webhook_success(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test successful webhook notification."""
        notifier = TaskNotifier()

        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        notifier._http_client = mock_client

        result = await notifier._notify_webhook(
            sample_task, sample_result, "Test summary", "https://example.com/webhook"
        )

        assert result.success is True
        mock_client.post.assert_called_once()

        # Verify payload doesn't expose sensitive data
        call_kwargs = mock_client.post.call_args[1]
        payload = call_kwargs["json"]
        assert "task_id" in payload
        assert "payload" not in payload  # Should not expose task payload


# Full Notification Flow Tests
class TestNotificationFlow:
    """Tests for full notification flow."""

    @pytest.mark.asyncio
    async def test_notify_completion_all_channels(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test notifying all configured channels."""
        callback = AsyncMock()
        notifier = TaskNotifier(
            slack_webhook_url="https://hooks.slack.com/test",
            conversation_callback=callback,
        )

        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        notifier._http_client = mock_client

        results = await notifier.notify_completion(sample_task, sample_result)

        assert len(results) == 2  # conversation + slack
        assert all(r.success for r in results)

    @pytest.mark.asyncio
    async def test_notify_completion_partial_failure(
        self, sample_task: BackgroundTask, sample_result: TaskResult
    ) -> None:
        """Test notification with partial channel failures."""
        callback = AsyncMock()
        notifier = TaskNotifier(
            conversation_callback=callback,
            # No Slack webhook - will fail
        )

        results = await notifier.notify_completion(sample_task, sample_result)

        # Conversation should succeed, Slack should fail
        conversation_result = next(r for r in results if r.channel == "conversation")
        slack_result = next(r for r in results if r.channel == "slack")

        assert conversation_result.success is True
        assert slack_result.success is False

    @pytest.mark.asyncio
    async def test_notify_completion_webhook_channel(
        self, sample_result: TaskResult
    ) -> None:
        """Test notification with webhook channel."""
        task = BackgroundTask(
            id=uuid4(),
            task_type="test",
            name="Test Task",
            status=TaskStatus.COMPLETED,
            priority=TaskPriority.NORMAL,
            steps=[TaskStep(name="step1", executor="python", config={})],
            notification_channels=["webhook:https://example.com/hook"],
            timeout_seconds=3600,
            created_at=datetime.now(UTC),
        )

        notifier = TaskNotifier()

        mock_response = MagicMock()
        mock_response.status_code = 200

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        notifier._http_client = mock_client

        results = await notifier.notify_completion(task, sample_result)

        assert len(results) == 1
        assert results[0].success is True
        assert "webhook:https://example.com/hook" in results[0].channel

    @pytest.mark.asyncio
    async def test_notify_completion_unknown_channel(
        self, sample_result: TaskResult
    ) -> None:
        """Test notification with unknown channel."""
        task = BackgroundTask(
            id=uuid4(),
            task_type="test",
            name="Test Task",
            status=TaskStatus.COMPLETED,
            priority=TaskPriority.NORMAL,
            steps=[TaskStep(name="step1", executor="python", config={})],
            notification_channels=["unknown_channel"],
            timeout_seconds=3600,
            created_at=datetime.now(UTC),
        )

        notifier = TaskNotifier()
        results = await notifier.notify_completion(task, sample_result)

        assert len(results) == 1
        assert results[0].success is False
        assert "Unknown channel" in (results[0].error or "")


# Progress Notification Tests
class TestProgressNotification:
    """Tests for progress notifications."""

    @pytest.mark.asyncio
    async def test_notify_progress(self, sample_task: BackgroundTask) -> None:
        """Test progress notification."""
        callback = AsyncMock()
        notifier = TaskNotifier(conversation_callback=callback)

        await notifier.notify_progress(
            task=sample_task,
            step_name="processing",
            step_index=1,
            total_steps=3,
            message="Processing batch 2...",
        )

        callback.assert_called_once()
        call_kwargs = callback.call_args[1]
        assert call_kwargs["is_progress"] is True
        assert "processing" in call_kwargs["message"].lower()
        assert "33%" in call_kwargs["message"]  # 1/3

    @pytest.mark.asyncio
    async def test_notify_progress_no_conversation_channel(self) -> None:
        """Test progress notification skipped without conversation channel."""
        task = BackgroundTask(
            id=uuid4(),
            task_type="test",
            name="Test Task",
            status=TaskStatus.RUNNING,
            priority=TaskPriority.NORMAL,
            steps=[TaskStep(name="step1", executor="python", config={})],
            notification_channels=["slack"],  # No conversation
            timeout_seconds=3600,
            created_at=datetime.now(UTC),
        )

        callback = AsyncMock()
        notifier = TaskNotifier(conversation_callback=callback)

        await notifier.notify_progress(
            task=task,
            step_name="processing",
            step_index=1,
            total_steps=3,
        )

        # Should not call callback
        callback.assert_not_called()


# Global Instance Tests
class TestGlobalInstance:
    """Tests for global notifier instance."""

    def test_get_task_notifier(self) -> None:
        """Test getting global notifier."""
        reset_task_notifier()

        notifier1 = get_task_notifier()
        notifier2 = get_task_notifier()

        assert notifier1 is notifier2

    def test_reset_task_notifier(self) -> None:
        """Test resetting global notifier."""
        reset_task_notifier()
        notifier1 = get_task_notifier()

        reset_task_notifier()
        notifier2 = get_task_notifier()

        assert notifier1 is not notifier2

    def teardown_method(self) -> None:
        """Reset after each test."""
        reset_task_notifier()
