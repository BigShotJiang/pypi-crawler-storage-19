"""Tests for TaskWorkerService."""

import asyncio
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from apps.api.background.executors.base import ExecutionContext
from apps.api.background.executors.python_executor import PythonExecutor
from apps.api.background.executors.registry import StepExecutorRegistry
from apps.api.background.models import (
    BackgroundTask,
    TaskPriority,
    TaskStatus,
    TaskStep,
)
from apps.api.background.worker import TaskWorkerService


# Fixtures
@pytest.fixture
def mock_manager() -> MagicMock:
    """Create mock BackgroundTaskManager."""
    manager = MagicMock()
    manager.list_tasks = AsyncMock(return_value=([], 0))
    manager.update_progress = AsyncMock()
    return manager


@pytest.fixture
def registry() -> StepExecutorRegistry:
    """Create registry with Python executor."""
    registry = StepExecutorRegistry()
    executor = PythonExecutor()

    # Register a test handler
    async def test_handler(_config: dict, _context: ExecutionContext) -> dict:
        return {"processed": True}

    executor.register_handler("test_handler", test_handler)
    registry.register(executor)
    return registry


@pytest.fixture
def sample_task() -> BackgroundTask:
    """Create sample background task."""
    return BackgroundTask(
        id=uuid4(),
        task_type="test_task",
        name="Test Task",
        status=TaskStatus.PENDING,
        priority=TaskPriority.NORMAL,
        steps=[
            TaskStep(
                name="step1",
                executor="python",
                config={"operation": "noop"},
            ),
            TaskStep(
                name="step2",
                executor="python",
                config={"handler": "test_handler"},
            ),
        ],
        timeout_seconds=300,
        created_at=datetime.now(UTC),
    )


@pytest.fixture
def worker(
    mock_manager: MagicMock, registry: StepExecutorRegistry
) -> TaskWorkerService:
    """Create worker service for tests."""
    return TaskWorkerService(
        manager=mock_manager,
        registry=registry,
        poll_interval=0.1,
        max_concurrent_tasks=2,
    )


# Worker Lifecycle Tests
class TestWorkerLifecycle:
    """Tests for worker start/stop lifecycle."""

    @pytest.mark.asyncio
    async def test_start_worker(self, worker: TaskWorkerService) -> None:
        """Test starting the worker."""
        await worker.start()

        assert worker.is_running is True

        # Cleanup
        await worker.stop()

    @pytest.mark.asyncio
    async def test_start_already_running(self, worker: TaskWorkerService) -> None:
        """Test starting an already running worker is idempotent."""
        await worker.start()
        await worker.start()  # Should not raise

        assert worker.is_running is True

        # Cleanup
        await worker.stop()

    @pytest.mark.asyncio
    async def test_stop_worker(self, worker: TaskWorkerService) -> None:
        """Test stopping the worker."""
        await worker.start()
        await worker.stop()

        assert worker.is_running is False

    @pytest.mark.asyncio
    async def test_active_task_count(
        self, worker: TaskWorkerService, sample_task: BackgroundTask
    ) -> None:
        """Test active task count tracking."""
        assert worker.active_task_count == 0


# Task Execution Tests
class TestTaskExecution:
    """Tests for task execution."""

    @pytest.mark.asyncio
    async def test_execute_task_success(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
        sample_task: BackgroundTask,
    ) -> None:
        """Test successful task execution."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
            poll_interval=0.1,
        )

        await worker._execute_task(sample_task)

        # Verify progress was updated multiple times
        assert mock_manager.update_progress.call_count >= 2

        # Verify final status was completed
        final_call = mock_manager.update_progress.call_args
        progress = final_call[0][1]
        assert progress.status == TaskStatus.COMPLETED
        assert progress.percent == 100

    @pytest.mark.asyncio
    async def test_execute_task_with_timeout(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
    ) -> None:
        """Test task execution respects timeout."""
        from apps.api.background.exceptions import TaskTimeoutError

        # Create task with minimum valid timeout
        task = BackgroundTask(
            id=uuid4(),
            task_type="timeout_task",
            name="Timeout Task",
            status=TaskStatus.PENDING,
            priority=TaskPriority.NORMAL,
            steps=[
                TaskStep(
                    name="slow_step",
                    executor="python",
                    config={"operation": "noop"},
                ),
            ],
            timeout_seconds=60,
            created_at=datetime.now(UTC),
        )

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        # Mock datetime.now to simulate time passing
        call_count = 0

        def mock_now(_tz=None):
            nonlocal call_count
            call_count += 1
            # First call sets started_at, second call checks elapsed time
            if call_count >= 2:
                # Return a time 100 seconds in the future (past 60s timeout)
                return datetime(2030, 1, 1, 0, 1, 40, tzinfo=UTC)
            return datetime(2030, 1, 1, 0, 0, 0, tzinfo=UTC)

        with patch("apps.api.background.worker.datetime") as mock_datetime:
            mock_datetime.now = mock_now
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(
                *args, **kwargs
            )

            # Should raise timeout error
            with pytest.raises(TaskTimeoutError):
                await worker._execute_task(task)

    @pytest.mark.asyncio
    async def test_execute_task_unknown_executor(
        self,
        mock_manager: MagicMock,
    ) -> None:
        """Test task execution with unregistered executor fails."""
        from apps.api.background.exceptions import TaskExecutionError

        # Use empty registry (no executors registered)
        registry = StepExecutorRegistry()

        # Create task with valid executor type but not registered
        task = BackgroundTask(
            id=uuid4(),
            task_type="unknown_executor_task",
            name="Unknown Executor Task",
            status=TaskStatus.PENDING,
            priority=TaskPriority.NORMAL,
            steps=[
                TaskStep(
                    name="bad_step",
                    executor="python",  # Valid type but not registered
                    config={},
                ),
            ],
            timeout_seconds=300,
            created_at=datetime.now(UTC),
        )

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        with pytest.raises(TaskExecutionError, match="Unknown executor"):
            await worker._execute_task(task)

    @pytest.mark.asyncio
    async def test_execute_task_step_failure(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
    ) -> None:
        """Test task execution handles step failures."""
        # Create task with failing step
        task = BackgroundTask(
            id=uuid4(),
            task_type="failing_task",
            name="Failing Task",
            status=TaskStatus.PENDING,
            priority=TaskPriority.NORMAL,
            steps=[
                TaskStep(
                    name="failing_step",
                    executor="python",
                    config={"handler": "nonexistent"},
                    continue_on_failure=False,
                ),
            ],
            timeout_seconds=300,
            created_at=datetime.now(UTC),
        )

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        from apps.api.background.exceptions import TaskExecutionError

        with pytest.raises(TaskExecutionError):
            await worker._execute_task(task)

    @pytest.mark.asyncio
    async def test_execute_task_continue_on_failure(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
    ) -> None:
        """Test task execution continues when continue_on_failure is True."""
        task = BackgroundTask(
            id=uuid4(),
            task_type="continue_task",
            name="Continue Task",
            status=TaskStatus.PENDING,
            priority=TaskPriority.NORMAL,
            steps=[
                TaskStep(
                    name="failing_step",
                    executor="python",
                    config={"handler": "nonexistent"},
                    continue_on_failure=True,  # Should continue
                ),
                TaskStep(
                    name="success_step",
                    executor="python",
                    config={"operation": "noop"},
                ),
            ],
            timeout_seconds=300,
            created_at=datetime.now(UTC),
        )

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        # Should complete despite failing step
        await worker._execute_task(task)

        # Verify completed
        final_call = mock_manager.update_progress.call_args
        progress = final_call[0][1]
        assert progress.status == TaskStatus.COMPLETED


# Queue Polling Tests
class TestQueuePolling:
    """Tests for queue polling."""

    @pytest.mark.asyncio
    async def test_poll_queue_empty(
        self, mock_manager: MagicMock, registry: StepExecutorRegistry
    ) -> None:
        """Test polling empty queue."""
        # Mock atomic claim returning None (no pending tasks)
        mock_manager.claim_next_pending_task = AsyncMock(return_value=None)

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        task = await worker._poll_queue()

        assert task is None
        mock_manager.claim_next_pending_task.assert_called_once()

    @pytest.mark.asyncio
    async def test_poll_queue_with_task(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
        sample_task: BackgroundTask,
    ) -> None:
        """Test polling queue with pending task."""
        # Mock atomic claim (returns task already marked as RUNNING)
        sample_task.status = TaskStatus.RUNNING
        mock_manager.claim_next_pending_task = AsyncMock(return_value=sample_task)

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        task = await worker._poll_queue()

        assert task is not None
        assert task.id == sample_task.id

        # Verify atomic claim was called
        mock_manager.claim_next_pending_task.assert_called_once()


# Step Retry Tests
class TestStepRetry:
    """Tests for step retry logic."""

    @pytest.mark.asyncio
    async def test_step_retry_on_failure(
        self,
        mock_manager: MagicMock,
    ) -> None:
        """Test step retries on failure."""
        # Create executor that fails twice then succeeds
        call_count = 0

        async def flaky_handler(_config: dict, _context: ExecutionContext) -> dict:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("Temporary failure")
            return {"success": True}

        registry = StepExecutorRegistry()
        executor = PythonExecutor()
        executor.register_handler("flaky", flaky_handler)
        registry.register(executor)

        task = BackgroundTask(
            id=uuid4(),
            task_type="retry_task",
            name="Retry Task",
            status=TaskStatus.PENDING,
            priority=TaskPriority.NORMAL,
            steps=[
                TaskStep(
                    name="flaky_step",
                    executor="python",
                    config={"handler": "flaky"},
                    retry_count=3,  # Allow 3 retries
                ),
            ],
            timeout_seconds=300,
            created_at=datetime.now(UTC),
        )

        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        await worker._execute_task(task)

        # Verify all retries happened
        assert call_count == 3


# Status Update Tests
class TestStatusUpdates:
    """Tests for status updates."""

    @pytest.mark.asyncio
    async def test_update_status(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
        sample_task: BackgroundTask,
    ) -> None:
        """Test status update."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        await worker._update_status(sample_task, TaskStatus.RUNNING)

        mock_manager.update_progress.assert_called_once()
        progress = mock_manager.update_progress.call_args[0][1]
        assert progress.status == TaskStatus.RUNNING

    @pytest.mark.asyncio
    async def test_update_progress(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
        sample_task: BackgroundTask,
    ) -> None:
        """Test progress update."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        await worker._update_progress(
            task=sample_task,
            step_index=1,
            message="Running step 2",
        )

        mock_manager.update_progress.assert_called_once()
        progress = mock_manager.update_progress.call_args[0][1]
        assert progress.step_index == 1
        assert "Running step 2" in progress.message

    @pytest.mark.asyncio
    async def test_fail_task(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
        sample_task: BackgroundTask,
    ) -> None:
        """Test marking task as failed."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        await worker._fail_task(sample_task, "Test error")

        mock_manager.update_progress.assert_called_once()
        progress = mock_manager.update_progress.call_args[0][1]
        assert progress.status == TaskStatus.FAILED
        assert "Test error" in progress.message


# Cleanup Tests
class TestCleanup:
    """Tests for cleanup operations."""

    @pytest.mark.asyncio
    async def test_cleanup_completed_tasks(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
    ) -> None:
        """Test completed task cleanup."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        # Add completed asyncio task
        done_task = asyncio.create_task(asyncio.sleep(0))
        await done_task  # Complete it
        worker._active_tasks[uuid4()] = done_task

        # Cleanup
        worker._cleanup_completed()

        assert worker.active_task_count == 0

    @pytest.mark.asyncio
    async def test_stop_waits_for_tasks(
        self,
        mock_manager: MagicMock,
        registry: StepExecutorRegistry,
    ) -> None:
        """Test stop waits for active tasks."""
        worker = TaskWorkerService(
            manager=mock_manager,
            registry=registry,
        )

        # Track if task completed
        task_completed = False

        async def slow_task():
            nonlocal task_completed
            await asyncio.sleep(0.05)
            task_completed = True

        # Add a running task
        task_id = uuid4()
        worker._active_tasks[task_id] = asyncio.create_task(slow_task())
        worker._running = True

        # Stop should wait for task
        await worker.stop(timeout=1.0)

        assert worker._running is False
        # The task should have completed during stop
        assert task_completed is True
