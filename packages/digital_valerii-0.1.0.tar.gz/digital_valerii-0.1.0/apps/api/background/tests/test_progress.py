"""Tests for ProgressTracker."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest

from apps.api.background.models import TaskProgress, TaskStatus
from apps.api.background.progress import (
    ProgressTracker,
    get_progress_tracker,
    reset_progress_tracker,
)


# Fixtures
@pytest.fixture
def mock_redis() -> MagicMock:
    """Create mock Redis client."""
    redis = MagicMock()
    redis.set = AsyncMock()
    redis.get = AsyncMock()
    redis.delete = AsyncMock(return_value=1)
    redis.publish = AsyncMock()
    redis.pubsub = MagicMock()
    redis.scan_iter = MagicMock()
    return redis


@pytest.fixture
def tracker(mock_redis: MagicMock) -> ProgressTracker:
    """Create ProgressTracker with mock Redis."""
    return ProgressTracker(redis_client=mock_redis)


@pytest.fixture
def sample_progress() -> TaskProgress:
    """Create sample progress data."""
    return TaskProgress(
        task_id=uuid4(),
        status=TaskStatus.RUNNING,
        current_step="processing",
        step_index=1,
        total_steps=3,
        percent=33,
        message="Processing data...",
        started_at=datetime.now(UTC),
        updated_at=datetime.now(UTC),
    )


# Key Generation Tests
class TestKeyGeneration:
    """Tests for Redis key generation."""

    def test_progress_key(self, tracker: ProgressTracker) -> None:
        """Test progress key format."""
        task_id = uuid4()
        key = tracker._progress_key(task_id)

        assert key == f"task:{task_id}:progress"

    def test_channel_key(self, tracker: ProgressTracker) -> None:
        """Test channel key format."""
        task_id = uuid4()
        key = tracker._channel_key(task_id)

        assert key == f"task:{task_id}"

    def test_custom_prefix(self, mock_redis: MagicMock) -> None:
        """Test custom key prefix."""
        tracker = ProgressTracker(redis_client=mock_redis, key_prefix="bg_task")
        task_id = uuid4()

        progress_key = tracker._progress_key(task_id)
        channel_key = tracker._channel_key(task_id)

        assert progress_key == f"bg_task:{task_id}:progress"
        assert channel_key == f"bg_task:{task_id}"


# Update Progress Tests
class TestUpdateProgress:
    """Tests for progress updates."""

    @pytest.mark.asyncio
    async def test_update_progress(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
        sample_progress: TaskProgress,
    ) -> None:
        """Test updating task progress."""
        await tracker.update_progress(sample_progress.task_id, sample_progress)

        # Verify Redis set was called
        mock_redis.set.assert_called_once()
        call_args = mock_redis.set.call_args
        assert f"task:{sample_progress.task_id}:progress" in call_args[0][0]

        # Verify publish was called
        mock_redis.publish.assert_called_once()
        channel = mock_redis.publish.call_args[0][0]
        assert f"task:{sample_progress.task_id}" == channel

    @pytest.mark.asyncio
    async def test_update_progress_with_ttl(
        self,
        mock_redis: MagicMock,
        sample_progress: TaskProgress,
    ) -> None:
        """Test progress update sets TTL."""
        tracker = ProgressTracker(redis_client=mock_redis, ttl_seconds=3600)

        await tracker.update_progress(sample_progress.task_id, sample_progress)

        # Verify TTL was set
        call_kwargs = mock_redis.set.call_args[1]
        assert call_kwargs.get("ex") == 3600

    @pytest.mark.asyncio
    async def test_update_progress_error(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
        sample_progress: TaskProgress,
    ) -> None:
        """Test handling Redis errors during update."""
        mock_redis.set.side_effect = Exception("Redis connection error")

        with pytest.raises(Exception, match="Redis connection error"):
            await tracker.update_progress(sample_progress.task_id, sample_progress)


# Get Progress Tests
class TestGetProgress:
    """Tests for getting progress."""

    @pytest.mark.asyncio
    async def test_get_progress_exists(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test getting existing progress."""
        task_id = uuid4()
        progress_data = TaskProgress(
            task_id=task_id,
            status=TaskStatus.RUNNING,
            step_index=2,
            total_steps=5,
            percent=40,
            message="Processing...",
            started_at=datetime.now(UTC),
            updated_at=datetime.now(UTC),
        )
        mock_redis.get.return_value = progress_data.model_dump_json()

        result = await tracker.get_progress(task_id)

        assert result is not None
        assert result.task_id == task_id
        assert result.status == TaskStatus.RUNNING
        assert result.percent == 40

    @pytest.mark.asyncio
    async def test_get_progress_not_found(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test getting non-existent progress."""
        mock_redis.get.return_value = None

        result = await tracker.get_progress(uuid4())

        assert result is None

    @pytest.mark.asyncio
    async def test_get_progress_error(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test handling Redis errors during get."""
        mock_redis.get.side_effect = Exception("Redis error")

        result = await tracker.get_progress(uuid4())

        assert result is None


# Delete Progress Tests
class TestDeleteProgress:
    """Tests for deleting progress."""

    @pytest.mark.asyncio
    async def test_delete_progress_exists(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test deleting existing progress."""
        mock_redis.delete.return_value = 1
        task_id = uuid4()

        result = await tracker.delete_progress(task_id)

        assert result is True
        mock_redis.delete.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_progress_not_found(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test deleting non-existent progress."""
        mock_redis.delete.return_value = 0

        result = await tracker.delete_progress(uuid4())

        assert result is False


# Publish Tests
class TestPublishCompletion:
    """Tests for completion publishing."""

    @pytest.mark.asyncio
    async def test_publish_completed(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test publishing completion status."""
        task_id = uuid4()

        await tracker.publish_completion(task_id, TaskStatus.COMPLETED)

        mock_redis.publish.assert_called_once()
        channel, message = mock_redis.publish.call_args[0]
        assert channel == f"task:{task_id}"
        assert message == "complete:completed"

    @pytest.mark.asyncio
    async def test_publish_failed(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test publishing failed status."""
        task_id = uuid4()

        await tracker.publish_completion(task_id, TaskStatus.FAILED)

        _, message = mock_redis.publish.call_args[0]
        assert message == "complete:failed"


# Subscription Tests
class TestSubscription:
    """Tests for progress subscription."""

    @pytest.mark.asyncio
    async def test_subscribe_progress(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test subscribing to progress updates."""
        mock_pubsub = MagicMock()
        mock_pubsub.subscribe = AsyncMock()
        mock_redis.pubsub.return_value = mock_pubsub

        task_id = uuid4()
        pubsub = await tracker.subscribe_progress(task_id)

        assert pubsub is mock_pubsub
        mock_pubsub.subscribe.assert_called_once_with(f"task:{task_id}")


# Convenience Method Tests
class TestConvenienceMethods:
    """Tests for convenience methods."""

    @pytest.mark.asyncio
    async def test_set_step_progress(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test set_step_progress convenience method."""
        task_id = uuid4()

        await tracker.set_step_progress(
            task_id=task_id,
            step_name="analyzing",
            step_index=2,
            total_steps=4,
            message="Analyzing data...",
        )

        # Verify Redis was called
        mock_redis.set.assert_called_once()

        # Parse the stored progress
        call_args = mock_redis.set.call_args[0]
        stored_json = call_args[1]
        progress = TaskProgress.model_validate_json(stored_json)

        assert progress.task_id == task_id
        assert progress.current_step == "analyzing"
        assert progress.step_index == 2
        assert progress.total_steps == 4
        assert progress.percent == 50  # 2/4 * 100
        assert "Analyzing data" in progress.message

    @pytest.mark.asyncio
    async def test_set_step_progress_default_message(
        self,
        tracker: ProgressTracker,
        mock_redis: MagicMock,
    ) -> None:
        """Test set_step_progress with default message."""
        task_id = uuid4()

        await tracker.set_step_progress(
            task_id=task_id,
            step_name="processing",
            step_index=1,
            total_steps=3,
        )

        call_args = mock_redis.set.call_args[0]
        progress = TaskProgress.model_validate_json(call_args[1])

        assert "processing" in progress.message


# Global Instance Tests
class TestGlobalInstance:
    """Tests for global progress tracker instance."""

    def test_get_progress_tracker(self) -> None:
        """Test getting global tracker."""
        reset_progress_tracker()

        tracker1 = get_progress_tracker()
        tracker2 = get_progress_tracker()

        assert tracker1 is tracker2

    def test_reset_progress_tracker(self) -> None:
        """Test resetting global tracker."""
        reset_progress_tracker()
        tracker1 = get_progress_tracker()

        reset_progress_tracker()
        tracker2 = get_progress_tracker()

        assert tracker1 is not tracker2

    def teardown_method(self) -> None:
        """Reset after each test."""
        reset_progress_tracker()
