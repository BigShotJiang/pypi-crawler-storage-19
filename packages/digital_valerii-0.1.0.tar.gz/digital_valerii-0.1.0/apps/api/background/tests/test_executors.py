"""Tests for step executors."""

from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from apps.api.background.executors.ai_executor import AIExecutor
from apps.api.background.executors.base import ExecutionContext
from apps.api.background.executors.python_executor import PythonExecutor
from apps.api.background.executors.registry import (
    StepExecutorRegistry,
    get_default_registry,
    reset_default_registry,
)
from apps.api.background.models import StepStatus, TaskStep


# Fixtures
@pytest.fixture
def execution_context() -> ExecutionContext:
    """Create execution context for tests."""
    return ExecutionContext(
        task_id=uuid4(),
        task_type="test_task",
        task_name="Test Task",
        session_id="test-session",
        payload={"key": "value"},
        previous_results={"step1": {"data": "result1"}},
    )


@pytest.fixture
def task_step() -> TaskStep:
    """Create task step for tests."""
    return TaskStep(
        name="test_step",
        executor="python",
        config={"handler": "test_handler"},
        timeout_seconds=60,
    )


@pytest.fixture
def ai_step() -> TaskStep:
    """Create AI task step for tests."""
    return TaskStep(
        name="ai_step",
        executor="ai",
        config={
            "prompt": "Analyze this: {key}",
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1000,
            "system": "You are a test assistant.",
            "output_format": "json",
        },
        timeout_seconds=120,
    )


# ExecutionContext Tests
class TestExecutionContext:
    """Tests for ExecutionContext model."""

    def test_create_context(self) -> None:
        """Test context creation with all fields."""
        task_id = uuid4()
        context = ExecutionContext(
            task_id=task_id,
            task_type="ingest",
            task_name="Ingest Task",
            session_id="session-123",
            payload={"sources": ["nessus"]},
            previous_results={},
        )

        assert context.task_id == task_id
        assert context.task_type == "ingest"
        assert context.task_name == "Ingest Task"
        assert context.session_id == "session-123"
        assert context.payload == {"sources": ["nessus"]}
        assert context.previous_results == {}

    def test_context_defaults(self) -> None:
        """Test context with default values."""
        task_id = uuid4()
        context = ExecutionContext(
            task_id=task_id,
            task_type="test",
            task_name="Test",
        )

        assert context.session_id is None
        assert context.payload == {}
        assert context.previous_results == {}

    def test_context_forbids_extra(self) -> None:
        """Test that extra fields are forbidden."""
        with pytest.raises(ValueError):
            ExecutionContext(
                task_id=uuid4(),
                task_type="test",
                task_name="Test",
                extra_field="not allowed",  # type: ignore[call-arg]
            )


# StepExecutorRegistry Tests
class TestStepExecutorRegistry:
    """Tests for StepExecutorRegistry."""

    def test_register_executor(self) -> None:
        """Test registering an executor."""
        registry = StepExecutorRegistry()
        executor = PythonExecutor()

        registry.register(executor)

        assert registry.has("python")
        assert registry.get("python") is executor

    def test_register_duplicate_raises(self) -> None:
        """Test registering duplicate executor raises error."""
        registry = StepExecutorRegistry()
        executor1 = PythonExecutor()
        executor2 = PythonExecutor()

        registry.register(executor1)

        with pytest.raises(ValueError, match="already registered"):
            registry.register(executor2)

    def test_get_unknown_raises(self) -> None:
        """Test getting unknown executor raises error."""
        registry = StepExecutorRegistry()

        with pytest.raises(KeyError, match="Unknown executor"):
            registry.get("unknown")

    def test_has_executor(self) -> None:
        """Test has method."""
        registry = StepExecutorRegistry()
        executor = PythonExecutor()

        assert not registry.has("python")
        registry.register(executor)
        assert registry.has("python")

    def test_available_types(self) -> None:
        """Test listing available executor types."""
        registry = StepExecutorRegistry()

        assert registry.available_types == []

        registry.register(PythonExecutor())
        assert "python" in registry.available_types

    def test_unregister_executor(self) -> None:
        """Test unregistering an executor."""
        registry = StepExecutorRegistry()
        registry.register(PythonExecutor())

        registry.unregister("python")

        assert not registry.has("python")

    def test_unregister_unknown_raises(self) -> None:
        """Test unregistering unknown executor raises error."""
        registry = StepExecutorRegistry()

        with pytest.raises(KeyError, match="Unknown executor"):
            registry.unregister("unknown")

    def test_clear_registry(self) -> None:
        """Test clearing all executors."""
        registry = StepExecutorRegistry()
        registry.register(PythonExecutor())

        registry.clear()

        assert registry.available_types == []


class TestDefaultRegistry:
    """Tests for default registry functions."""

    def test_get_default_registry(self) -> None:
        """Test getting default registry."""
        reset_default_registry()
        registry1 = get_default_registry()
        registry2 = get_default_registry()

        assert registry1 is registry2

    def test_reset_default_registry(self) -> None:
        """Test resetting default registry."""
        reset_default_registry()
        registry1 = get_default_registry()
        reset_default_registry()
        registry2 = get_default_registry()

        assert registry1 is not registry2


# PythonExecutor Tests
class TestPythonExecutor:
    """Tests for PythonExecutor."""

    def test_executor_type(self) -> None:
        """Test executor type property."""
        executor = PythonExecutor()
        assert executor.executor_type == "python"

    def test_register_handler(self) -> None:
        """Test registering a handler."""
        executor = PythonExecutor()

        async def my_handler(_config: dict, _context: ExecutionContext) -> dict:
            return {"result": "success"}

        executor.register_handler("my_handler", my_handler)

        assert executor.has_handler("my_handler")

    @pytest.mark.asyncio
    async def test_execute_handler(self, execution_context: ExecutionContext) -> None:
        """Test executing a registered handler."""
        executor = PythonExecutor()

        async def test_handler(config: dict, _context: ExecutionContext) -> dict:
            return {"processed": config.get("data", "none")}

        executor.register_handler("test_handler", test_handler)

        step = TaskStep(
            name="handler_step",
            executor="python",
            config={"handler": "test_handler", "data": "test_value"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output == {"processed": "test_value"}

    @pytest.mark.asyncio
    async def test_execute_unknown_handler(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test executing unknown handler fails."""
        executor = PythonExecutor()

        step = TaskStep(
            name="unknown_step",
            executor="python",
            config={"handler": "nonexistent"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.FAILED
        assert "Unknown handler" in (result.error or "")

    @pytest.mark.asyncio
    async def test_execute_noop_operation(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test noop operation."""
        executor = PythonExecutor()

        step = TaskStep(
            name="noop_step",
            executor="python",
            config={"operation": "noop"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["status"] == "noop"

    @pytest.mark.asyncio
    async def test_execute_log_operation(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test log operation."""
        executor = PythonExecutor()

        step = TaskStep(
            name="log_step",
            executor="python",
            config={"operation": "log", "message": "Test log message"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["status"] == "logged"

    @pytest.mark.asyncio
    async def test_execute_merge_results_operation(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test merge_results operation."""
        executor = PythonExecutor()

        step = TaskStep(
            name="merge_step",
            executor="python",
            config={"operation": "merge_results"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["status"] == "merged"
        assert "step1" in result.output["merged_data"]

    @pytest.mark.asyncio
    async def test_execute_validate_operation_pass(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test validate operation passes with required fields."""
        executor = PythonExecutor()

        step = TaskStep(
            name="validate_step",
            executor="python",
            config={"operation": "validate", "required_fields": ["step1"]},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["status"] == "validated"

    @pytest.mark.asyncio
    async def test_execute_validate_operation_fail(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test validate operation fails with missing fields."""
        executor = PythonExecutor()

        step = TaskStep(
            name="validate_step",
            executor="python",
            config={"operation": "validate", "required_fields": ["missing_field"]},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.FAILED
        assert "Missing required fields" in (result.error or "")

    @pytest.mark.asyncio
    async def test_execute_default_passthrough(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test default passthrough behavior."""
        executor = PythonExecutor()

        step = TaskStep(
            name="passthrough_step",
            executor="python",
            config={"custom_key": "custom_value"},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["status"] == "completed"
        assert result.output["config"]["custom_key"] == "custom_value"


# AIExecutor Tests
class TestAIExecutor:
    """Tests for AIExecutor."""

    def test_executor_type(self) -> None:
        """Test executor type property."""
        executor = AIExecutor()
        assert executor.executor_type == "ai"

    def test_format_prompt(self) -> None:
        """Test prompt template formatting."""
        executor = AIExecutor()

        template = "Analyze {key} with {task_type}"
        variables = {"key": "data", "task_type": "analysis"}

        result = executor._format_prompt(template, variables)

        assert result == "Analyze data with analysis"

    def test_format_prompt_with_dict(self) -> None:
        """Test prompt formatting with dict variable."""
        executor = AIExecutor()

        template = "Process: {data}"
        variables = {"data": {"items": [1, 2, 3]}}

        result = executor._format_prompt(template, variables)

        assert "items" in result
        # JSON is pretty-printed, so check for array elements
        assert "1" in result and "2" in result and "3" in result

    def test_format_prompt_missing_variable(self) -> None:
        """Test prompt with missing variable left unchanged."""
        executor = AIExecutor()

        template = "Hello {name}, your {missing} is ready"
        variables = {"name": "World"}

        result = executor._format_prompt(template, variables)

        assert result == "Hello World, your {missing} is ready"

    def test_parse_output_json(self) -> None:
        """Test JSON output parsing."""
        executor = AIExecutor()

        text = 'Here is the result: {"key": "value", "count": 42}'
        result = executor._parse_output(text, "json")

        assert result["type"] == "json"
        assert result["data"]["key"] == "value"
        assert result["data"]["count"] == 42

    def test_parse_output_json_with_markdown(self) -> None:
        """Test JSON parsing from markdown code block."""
        executor = AIExecutor()

        text = """```json
{"status": "success"}
```"""
        result = executor._parse_output(text, "json")

        assert result["type"] == "json"
        assert result["data"]["status"] == "success"

    def test_parse_output_invalid_json(self) -> None:
        """Test handling of invalid JSON."""
        executor = AIExecutor()

        text = "This is not JSON at all"
        result = executor._parse_output(text, "json")

        assert result["type"] == "text"
        assert result["data"] == text

    def test_parse_output_text(self) -> None:
        """Test text output parsing."""
        executor = AIExecutor()

        text = "Plain text response"
        result = executor._parse_output(text, "text")

        assert result["type"] == "text"
        assert result["content"] == text

    def test_parse_output_markdown(self) -> None:
        """Test markdown output parsing."""
        executor = AIExecutor()

        text = "# Header\n\nSome content"
        result = executor._parse_output(text, "markdown")

        assert result["type"] == "markdown"
        assert result["content"] == text

    @pytest.mark.asyncio
    async def test_execute_missing_prompt(
        self, execution_context: ExecutionContext
    ) -> None:
        """Test execution fails without prompt."""
        executor = AIExecutor()

        step = TaskStep(
            name="no_prompt_step",
            executor="ai",
            config={},
        )

        result = await executor.execute(step, execution_context)

        assert result.status == StepStatus.FAILED
        assert "requires 'prompt'" in (result.error or "")

    @pytest.mark.asyncio
    async def test_execute_with_mock_client(
        self, execution_context: ExecutionContext, ai_step: TaskStep
    ) -> None:
        """Test execution with mocked Anthropic client."""
        # Create mock response
        mock_block = MagicMock()
        mock_block.text = '{"analysis": "test result"}'

        mock_usage = MagicMock()
        mock_usage.input_tokens = 100
        mock_usage.output_tokens = 50

        mock_response = MagicMock()
        mock_response.content = [mock_block]
        mock_response.usage = mock_usage

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response

        executor = AIExecutor(client=mock_client)

        result = await executor.execute(ai_step, execution_context)

        assert result.status == StepStatus.COMPLETED
        assert result.output is not None
        assert result.output["type"] == "json"
        assert result.tokens_used == 150

        # Verify API was called correctly
        mock_client.messages.create.assert_called_once()
        call_kwargs = mock_client.messages.create.call_args[1]
        assert call_kwargs["model"] == "claude-sonnet-4-20250514"
        assert call_kwargs["max_tokens"] == 1000
        assert "system" in call_kwargs

    @pytest.mark.asyncio
    async def test_execute_api_error(
        self, execution_context: ExecutionContext, ai_step: TaskStep
    ) -> None:
        """Test handling of API errors."""
        mock_client = MagicMock()
        mock_client.messages.create.side_effect = Exception("API error")

        executor = AIExecutor(client=mock_client)

        result = await executor.execute(ai_step, execution_context)

        assert result.status == StepStatus.FAILED
        assert "API error" in (result.error or "")
