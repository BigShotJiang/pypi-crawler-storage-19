"""Microsoft Graph API integration.

Provides OAuth 2.0 authentication and Graph API client for
Calendar, Mail, OneDrive, Teams, and Office documents.
"""

from apps.api.integrations.microsoft.calendar import (
    CalendarService,
    get_calendar_service,
)
from apps.api.integrations.microsoft.exceptions import (
    GraphAPIError,
    MicrosoftAuthError,
    PermissionDeniedError,
    RateLimitError,
    ResourceNotFoundError,
    TokenExpiredError,
    TokenRefreshError,
)
from apps.api.integrations.microsoft.files import (
    FilesService,
    get_files_service,
)
from apps.api.integrations.microsoft.graph_client import (
    GraphClient,
    get_graph_client,
)
from apps.api.integrations.microsoft.mail import (
    MailService,
    get_mail_service,
)
from apps.api.integrations.microsoft.models import (
    MicrosoftToken,
    OAuthState,
)
from apps.api.integrations.microsoft.oauth import MicrosoftOAuth
from apps.api.integrations.microsoft.teams import (
    TeamsService,
    get_teams_service,
)

__all__ = [
    # OAuth
    "MicrosoftOAuth",
    "MicrosoftToken",
    "OAuthState",
    # Graph Client
    "GraphClient",
    "get_graph_client",
    # Services
    "CalendarService",
    "get_calendar_service",
    "MailService",
    "get_mail_service",
    "FilesService",
    "get_files_service",
    "TeamsService",
    "get_teams_service",
    # Exceptions
    "GraphAPIError",
    "MicrosoftAuthError",
    "PermissionDeniedError",
    "RateLimitError",
    "ResourceNotFoundError",
    "TokenExpiredError",
    "TokenRefreshError",
]
