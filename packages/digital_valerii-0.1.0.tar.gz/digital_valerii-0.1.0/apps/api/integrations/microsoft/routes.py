"""Microsoft OAuth API routes.

Provides endpoints for Microsoft OAuth 2.0 authentication flow:
- GET /auth/microsoft - Initiate OAuth flow
- GET /auth/microsoft/callback - Handle OAuth callback
- POST /auth/microsoft/refresh - Manually refresh tokens
- DELETE /auth/microsoft - Disconnect Microsoft account
- GET /auth/microsoft/status - Check connection status
"""

from typing import Annotated
from urllib.parse import urlencode

from digital_valerii_shared.services.redis import RedisService
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, ConfigDict, Field

from apps.api.auth.dependencies import get_current_user
from apps.api.auth.models import User
from apps.api.dependencies import get_redis
from apps.api.integrations.microsoft.exceptions import (
    InvalidStateError,
    MicrosoftAuthError,
    TokenRefreshError,
)
from apps.api.integrations.microsoft.models import (
    AuthorizeUrlResponse,
    OAuthCallbackResponse,
)
from apps.api.integrations.microsoft.oauth import MicrosoftOAuth, _validate_redirect_uri

router = APIRouter(prefix="/auth/microsoft", tags=["microsoft-auth"])


# =========================================================================
# Dependencies
# =========================================================================


async def get_microsoft_oauth(
    redis: Annotated[RedisService, Depends(get_redis)],
) -> MicrosoftOAuth:
    """Get Microsoft OAuth service instance."""
    return MicrosoftOAuth(redis)


# =========================================================================
# Request/Response Models
# =========================================================================


class ConnectionStatus(BaseModel):
    """Microsoft connection status response."""

    model_config = ConfigDict(extra="forbid")

    connected: bool = Field(..., description="Whether Microsoft is connected")
    email: str | None = Field(None, description="Connected Microsoft email")
    expires_at: str | None = Field(None, description="Token expiration time")


class RefreshResponse(BaseModel):
    """Token refresh response."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(default=True)
    expires_at: str = Field(..., description="New token expiration time")
    message: str = Field(default="Tokens refreshed successfully")


class DisconnectResponse(BaseModel):
    """Disconnect response."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(default=True)
    message: str = Field(default="Microsoft account disconnected successfully")


# =========================================================================
# Endpoints
# =========================================================================


@router.get(
    "",
    response_model=AuthorizeUrlResponse,
    summary="Initiate Microsoft OAuth",
    description="Start the OAuth 2.0 authorization flow with Microsoft.",
)
async def initiate_oauth(
    current_user: Annotated[User, Depends(get_current_user)],
    oauth: Annotated[MicrosoftOAuth, Depends(get_microsoft_oauth)],
    redirect_uri: str | None = Query(
        None, description="URL to redirect after auth completes"
    ),
) -> AuthorizeUrlResponse:
    """Initiate Microsoft OAuth flow.

    Returns the authorization URL to redirect the user to Microsoft login.
    """
    try:
        url, state = await oauth.get_authorize_url(
            user_id=current_user.id,
            redirect_uri_after=redirect_uri,
        )
        return AuthorizeUrlResponse(authorize_url=url, state=state)
    except MicrosoftAuthError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.get(
    "/callback",
    response_class=RedirectResponse,
    summary="OAuth callback",
    description="Handle Microsoft OAuth callback. Redirects to frontend.",
    include_in_schema=False,  # Hide from docs as it's browser-only
)
async def oauth_callback(
    code: str = Query(..., description="Authorization code"),
    state: str = Query(..., description="State for CSRF validation"),
    error: str | None = Query(None, description="Error if auth failed"),
    error_description: str | None = Query(None, description="Error description"),
    oauth: MicrosoftOAuth = Depends(get_microsoft_oauth),
) -> RedirectResponse:
    """Handle Microsoft OAuth callback.

    Exchanges code for tokens and redirects to frontend with result.
    """
    # Default frontend redirect (can be customized)
    default_frontend_url = "http://localhost:3000/settings/integrations"

    if error:
        # FIX-3: URL-encode query parameters
        params = urlencode(
            {
                "error": error,
                "error_description": error_description or "",
            }
        )
        return RedirectResponse(
            url=f"{default_frontend_url}?{params}",
            status_code=status.HTTP_302_FOUND,
        )

    try:
        tokens, user_info, redirect_uri = await oauth.handle_callback(code, state)

        # FIX-1: Validate redirect URI from state (already validated, but double-check)
        if redirect_uri:
            validated_uri = _validate_redirect_uri(redirect_uri)
            frontend_url = validated_uri if validated_uri else default_frontend_url
        else:
            frontend_url = default_frontend_url

        # FIX-3: URL-encode query parameters
        params = urlencode(
            {
                "microsoft_connected": "true",
                "email": user_info.mail or "",
            }
        )
        return RedirectResponse(
            url=f"{frontend_url}?{params}",
            status_code=status.HTTP_302_FOUND,
        )

    except InvalidStateError:
        # FIX-3: URL-encode query parameters
        params = urlencode(
            {
                "error": "invalid_state",
                "error_description": "Invalid or expired OAuth state",
            }
        )
        return RedirectResponse(
            url=f"{default_frontend_url}?{params}",
            status_code=status.HTTP_302_FOUND,
        )
    except MicrosoftAuthError as e:
        # FIX-3: URL-encode query parameters
        params = urlencode(
            {
                "error": "auth_failed",
                "error_description": str(e),
            }
        )
        return RedirectResponse(
            url=f"{default_frontend_url}?{params}",
            status_code=status.HTTP_302_FOUND,
        )


@router.post(
    "/callback",
    response_model=OAuthCallbackResponse,
    summary="OAuth callback (API)",
    description="Handle Microsoft OAuth callback via API (for mobile/SPA).",
)
async def oauth_callback_api(
    code: str = Query(..., description="Authorization code"),
    state: str = Query(..., description="State for CSRF validation"),
    oauth: MicrosoftOAuth = Depends(get_microsoft_oauth),
) -> OAuthCallbackResponse:
    """Handle Microsoft OAuth callback via API.

    For use when browser redirect is not available (mobile, SPA).
    """
    try:
        tokens, user_info, _ = await oauth.handle_callback(code, state)
        return OAuthCallbackResponse(user=user_info)
    except InvalidStateError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired OAuth state",
        ) from e
    except MicrosoftAuthError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.post(
    "/refresh",
    response_model=RefreshResponse,
    summary="Refresh tokens",
    description="Manually refresh Microsoft tokens.",
)
async def refresh_tokens(
    current_user: Annotated[User, Depends(get_current_user)],
    oauth: Annotated[MicrosoftOAuth, Depends(get_microsoft_oauth)],
) -> RefreshResponse:
    """Manually refresh Microsoft tokens."""
    try:
        tokens = await oauth.refresh_tokens(current_user.id)
        return RefreshResponse(
            expires_at=tokens.expires_at.isoformat(),
        )
    except TokenRefreshError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e


@router.get(
    "/status",
    response_model=ConnectionStatus,
    summary="Check connection status",
    description="Check if Microsoft account is connected.",
)
async def get_connection_status(
    current_user: Annotated[User, Depends(get_current_user)],
    oauth: Annotated[MicrosoftOAuth, Depends(get_microsoft_oauth)],
) -> ConnectionStatus:
    """Check Microsoft connection status."""
    tokens = await oauth.get_tokens(current_user.id)

    if not tokens:
        return ConnectionStatus(connected=False)

    # Try to get email from a refresh if possible
    # For now, just return connected status with expiration
    return ConnectionStatus(
        connected=True,
        expires_at=tokens.expires_at.isoformat(),
    )


@router.delete(
    "",
    response_model=DisconnectResponse,
    summary="Disconnect Microsoft",
    description="Disconnect Microsoft account and delete stored tokens.",
)
async def disconnect_microsoft(
    current_user: Annotated[User, Depends(get_current_user)],
    oauth: Annotated[MicrosoftOAuth, Depends(get_microsoft_oauth)],
) -> DisconnectResponse:
    """Disconnect Microsoft account."""
    deleted = await oauth.delete_tokens(current_user.id)

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No Microsoft connection found",
        )

    return DisconnectResponse()
