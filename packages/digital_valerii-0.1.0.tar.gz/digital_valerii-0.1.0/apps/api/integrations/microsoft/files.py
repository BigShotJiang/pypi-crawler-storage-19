"""Microsoft OneDrive Files API service.

Provides file operations via Microsoft Graph API including:
- File and folder listing
- File CRUD operations
- File content upload/download
- Sharing and permissions
- Search functionality
"""

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from apps.api.integrations.microsoft.graph_client import GraphClient, get_graph_client

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Models
# =============================================================================


class DriveItem(BaseModel):
    """OneDrive file or folder model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Item ID")
    name: str = Field(..., description="File/folder name")
    size: int = Field(default=0, description="Size in bytes")
    is_folder: bool = Field(default=False, description="Is a folder")
    mime_type: str | None = Field(None, description="MIME type for files")
    created_datetime: str | None = Field(None, description="Created time")
    modified_datetime: str | None = Field(None, description="Modified time")
    web_url: str | None = Field(None, description="Web URL")
    download_url: str | None = Field(None, description="Download URL")
    parent_path: str | None = Field(None, description="Parent folder path")
    created_by: str | None = Field(None, description="Creator email")
    modified_by: str | None = Field(None, description="Last modifier email")


class DriveInfo(BaseModel):
    """OneDrive information."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Drive ID")
    name: str = Field(..., description="Drive name")
    drive_type: str = Field(..., description="Drive type (personal, business)")
    owner_email: str | None = Field(None, description="Owner email")
    quota_total: int = Field(default=0, description="Total quota bytes")
    quota_used: int = Field(default=0, description="Used quota bytes")
    quota_remaining: int = Field(default=0, description="Remaining quota bytes")


class ShareLink(BaseModel):
    """Sharing link model."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(None, description="Link ID")
    link_url: str = Field(..., description="Sharing URL")
    link_type: str = Field(..., description="Link type (view, edit)")
    scope: str = Field(default="anonymous", description="Link scope")
    expires_at: str | None = Field(None, description="Expiration time")


class CreateFolderRequest(BaseModel):
    """Request to create a folder."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Folder name")
    parent_path: str = Field(default="/", description="Parent folder path")


class UploadFileRequest(BaseModel):
    """Request to upload a file."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="File name")
    content: bytes = Field(..., description="File content")
    parent_path: str = Field(default="/", description="Parent folder path")
    content_type: str = Field(
        default="application/octet-stream",
        description="MIME type",
    )


class CreateShareLinkRequest(BaseModel):
    """Request to create a sharing link."""

    model_config = ConfigDict(extra="forbid")

    item_id: str = Field(..., description="Item ID to share")
    link_type: str = Field(default="view", description="Link type (view, edit)")
    scope: str = Field(
        default="anonymous",
        description="Link scope (anonymous, organization)",
    )
    expiration_datetime: str | None = Field(None, description="Expiration datetime")
    password: str | None = Field(None, description="Link password")


# =============================================================================
# Files Service
# =============================================================================


class FilesService:
    """Service for Microsoft OneDrive operations.

    Provides methods for managing files and folders via Graph API.

    Example:
        async with FilesService(redis, user_id) as service:
            files = await service.list_items("/Documents")
            await service.upload_file(request)
    """

    def __init__(
        self,
        redis: "RedisService",
        user_id: UUID,
    ) -> None:
        """Initialize Files service.

        Args:
            redis: Redis service for token storage.
            user_id: User whose OneDrive to access.
        """
        self._redis = redis
        self._user_id = user_id
        self._client: GraphClient | None = None

    async def __aenter__(self) -> "FilesService":
        """Enter async context and initialize client."""
        self._client = await get_graph_client(self._redis, self._user_id)
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context and cleanup."""
        if self._client:
            await self._client.__aexit__(*args)
            self._client = None

    @property
    def client(self) -> GraphClient:
        """Get the Graph client."""
        if self._client is None:
            raise RuntimeError("FilesService must be used as async context manager")
        return self._client

    # =========================================================================
    # Drive Information
    # =========================================================================

    async def get_drive_info(self) -> DriveInfo:
        """Get user's OneDrive information.

        Returns:
            Drive information including quota.
        """
        data = await self.client.get("/me/drive")
        quota = data.get("quota", {})

        return DriveInfo(
            id=data["id"],
            name=data.get("name", "OneDrive"),
            drive_type=data.get("driveType", "personal"),
            owner_email=data.get("owner", {}).get("user", {}).get("email"),
            quota_total=quota.get("total", 0),
            quota_used=quota.get("used", 0),
            quota_remaining=quota.get("remaining", 0),
        )

    # =========================================================================
    # Item Operations
    # =========================================================================

    async def list_items(
        self,
        path: str = "/",
        *,
        top: int = 100,
    ) -> list[DriveItem]:
        """List items in a folder.

        Args:
            path: Folder path (root is "/").
            top: Maximum items to return.

        Returns:
            List of files and folders.
        """
        if path == "/" or path == "":
            endpoint = "/me/drive/root/children"
        else:
            # Normalize path
            path = path.strip("/")
            endpoint = f"/me/drive/root:/{path}:/children"

        params = {
            "$top": top,
            "$select": (
                "id,name,size,file,folder,createdDateTime,lastModifiedDateTime,"
                "webUrl,@microsoft.graph.downloadUrl,parentReference,createdBy,lastModifiedBy"
            ),
        }

        data = await self.client.get(endpoint, params=params)
        return [self._parse_item(item) for item in data.get("value", [])]

    async def get_item(self, item_id: str) -> DriveItem:
        """Get a single item by ID.

        Args:
            item_id: Item ID.

        Returns:
            Item details.
        """
        data = await self.client.get(f"/me/drive/items/{item_id}")
        return self._parse_item(data)

    async def get_item_by_path(self, path: str) -> DriveItem:
        """Get a single item by path.

        Args:
            path: Item path.

        Returns:
            Item details.
        """
        path = path.strip("/")
        data = await self.client.get(f"/me/drive/root:/{path}")
        return self._parse_item(data)

    async def create_folder(self, request: CreateFolderRequest) -> DriveItem:
        """Create a new folder.

        Args:
            request: Folder creation request.

        Returns:
            Created folder.
        """
        parent_path = request.parent_path.strip("/")

        if parent_path:
            endpoint = f"/me/drive/root:/{parent_path}:/children"
        else:
            endpoint = "/me/drive/root/children"

        body = {
            "name": request.name,
            "folder": {},
            "@microsoft.graph.conflictBehavior": "rename",
        }

        data = await self.client.post(endpoint, json=body)

        await logger.ainfo(
            "Created folder",
            user_id=str(self._user_id),
            name=request.name,
            path=request.parent_path,
        )

        return self._parse_item(data)

    async def delete_item(self, item_id: str) -> bool:
        """Delete a file or folder.

        Args:
            item_id: Item ID.

        Returns:
            True if deleted.
        """
        await self.client.delete(f"/me/drive/items/{item_id}")

        await logger.ainfo(
            "Deleted item",
            user_id=str(self._user_id),
            item_id=item_id,
        )

        return True

    async def rename_item(
        self,
        item_id: str,
        new_name: str,
    ) -> DriveItem:
        """Rename a file or folder.

        Args:
            item_id: Item ID.
            new_name: New name.

        Returns:
            Renamed item.
        """
        data = await self.client.patch(
            f"/me/drive/items/{item_id}",
            json={"name": new_name},
        )
        return self._parse_item(data)

    async def move_item(
        self,
        item_id: str,
        destination_path: str,
    ) -> DriveItem:
        """Move item to another folder.

        Args:
            item_id: Item ID.
            destination_path: Destination folder path.

        Returns:
            Moved item.
        """
        # Get destination folder ID
        dest_path = destination_path.strip("/")
        if dest_path:
            dest_item = await self.get_item_by_path(dest_path)
            parent_ref = {"id": dest_item.id}
        else:
            parent_ref = {"path": "/drive/root"}

        data = await self.client.patch(
            f"/me/drive/items/{item_id}",
            json={"parentReference": parent_ref},
        )
        return self._parse_item(data)

    async def copy_item(
        self,
        item_id: str,
        destination_path: str,
        new_name: str | None = None,
    ) -> str:
        """Copy item to another folder.

        Args:
            item_id: Item ID.
            destination_path: Destination folder path.
            new_name: Optional new name for copy.

        Returns:
            Copy operation URL (async operation).
        """
        dest_path = destination_path.strip("/")
        if dest_path:
            dest_item = await self.get_item_by_path(dest_path)
            parent_ref = {"id": dest_item.id}
        else:
            parent_ref = {"driveId": "me", "path": "/drive/root"}

        body: dict[str, Any] = {"parentReference": parent_ref}
        if new_name:
            body["name"] = new_name

        # Copy returns 202 Accepted with Location header
        await self.client.post(f"/me/drive/items/{item_id}/copy", json=body)
        return "copy_initiated"

    # =========================================================================
    # File Content Operations
    # =========================================================================

    async def upload_small_file(self, request: UploadFileRequest) -> DriveItem:
        """Upload a small file (< 4MB).

        Args:
            request: Upload request with content.

        Returns:
            Created file.

        Note:
            For files > 4MB, use upload_large_file with resumable upload.
        """
        parent_path = request.parent_path.strip("/")

        if parent_path:
            endpoint = f"/me/drive/root:/{parent_path}/{request.name}:/content"
        else:
            endpoint = f"/me/drive/root:/{request.name}:/content"

        # Graph API expects raw bytes for file upload
        # We need to make a custom request
        headers = await self.client._get_headers()
        headers["Content-Type"] = request.content_type

        import httpx

        async with httpx.AsyncClient() as http_client:
            response = await http_client.put(
                f"https://graph.microsoft.com/v1.0{endpoint}",
                content=request.content,
                headers=headers,
                timeout=60.0,
            )

            if response.status_code not in (200, 201):
                raise Exception(f"Upload failed: {response.status_code}")

            data = response.json()

        await logger.ainfo(
            "Uploaded file",
            user_id=str(self._user_id),
            name=request.name,
            size=len(request.content),
        )

        return self._parse_item(data)

    async def download_file(self, item_id: str) -> bytes:
        """Download file content.

        Args:
            item_id: File ID.

        Returns:
            File content as bytes.
        """
        # Get download URL
        item = await self.get_item(item_id)
        if not item.download_url:
            raise ValueError(f"Item {item_id} has no download URL")

        import httpx

        async with httpx.AsyncClient() as http_client:
            response = await http_client.get(item.download_url, timeout=60.0)
            response.raise_for_status()
            return response.content

    async def get_file_content_as_text(self, item_id: str) -> str:
        """Download file content as text.

        Args:
            item_id: File ID.

        Returns:
            File content as string.
        """
        content = await self.download_file(item_id)
        return content.decode("utf-8")

    # =========================================================================
    # Search
    # =========================================================================

    async def search(
        self,
        query: str,
        *,
        top: int = 25,
    ) -> list[DriveItem]:
        """Search for files and folders.

        Args:
            query: Search query.
            top: Maximum results.

        Returns:
            List of matching items.
        """
        params = {
            "$top": top,
            "$select": (
                "id,name,size,file,folder,createdDateTime,"
                "lastModifiedDateTime,webUrl,parentReference"
            ),
        }

        data = await self.client.get(
            f"/me/drive/root/search(q='{query}')",
            params=params,
        )

        return [self._parse_item(item) for item in data.get("value", [])]

    # =========================================================================
    # Sharing
    # =========================================================================

    async def create_share_link(self, request: CreateShareLinkRequest) -> ShareLink:
        """Create a sharing link for an item.

        Args:
            request: Share link request.

        Returns:
            Created sharing link.
        """
        body: dict[str, Any] = {
            "type": request.link_type,
            "scope": request.scope,
        }

        if request.expiration_datetime:
            body["expirationDateTime"] = request.expiration_datetime

        if request.password:
            body["password"] = request.password

        data = await self.client.post(
            f"/me/drive/items/{request.item_id}/createLink",
            json=body,
        )

        link_data = data.get("link", {})

        await logger.ainfo(
            "Created share link",
            user_id=str(self._user_id),
            item_id=request.item_id,
            type=request.link_type,
        )

        return ShareLink(
            id=data.get("id"),
            link_url=link_data.get("webUrl", ""),
            link_type=link_data.get("type", request.link_type),
            scope=link_data.get("scope", request.scope),
            expires_at=data.get("expirationDateTime"),
        )

    async def get_permissions(self, item_id: str) -> list[dict[str, Any]]:
        """Get permissions for an item.

        Args:
            item_id: Item ID.

        Returns:
            List of permissions.
        """
        data = await self.client.get(f"/me/drive/items/{item_id}/permissions")
        return data.get("value", [])

    async def delete_permission(
        self,
        item_id: str,
        permission_id: str,
    ) -> bool:
        """Remove a permission from an item.

        Args:
            item_id: Item ID.
            permission_id: Permission ID.

        Returns:
            True if deleted.
        """
        await self.client.delete(
            f"/me/drive/items/{item_id}/permissions/{permission_id}"
        )
        return True

    # =========================================================================
    # Pagination
    # =========================================================================

    async def iter_items(
        self,
        path: str = "/",
        *,
        page_size: int = 100,
    ) -> AsyncIterator[DriveItem]:
        """Iterate over all items in a folder.

        Args:
            path: Folder path.
            page_size: Items per page.

        Yields:
            Items in the folder.
        """
        if path == "/" or path == "":
            endpoint = "/me/drive/root/children"
        else:
            path = path.strip("/")
            endpoint = f"/me/drive/root:/{path}:/children"

        async for item in self.client.paginate(endpoint, top=page_size):
            yield self._parse_item(item)

    # =========================================================================
    # Helpers
    # =========================================================================

    def _parse_item(self, data: dict[str, Any]) -> DriveItem:
        """Parse Graph API item data to DriveItem model.

        Args:
            data: Raw item data from Graph API.

        Returns:
            Parsed DriveItem model.
        """
        is_folder = "folder" in data
        mime_type = data.get("file", {}).get("mimeType") if not is_folder else None

        parent_ref = data.get("parentReference", {})
        parent_path = parent_ref.get("path", "").replace("/drive/root:", "")

        created_by = data.get("createdBy", {}).get("user", {}).get("email")
        modified_by = data.get("lastModifiedBy", {}).get("user", {}).get("email")

        return DriveItem(
            id=data["id"],
            name=data.get("name", ""),
            size=data.get("size", 0),
            is_folder=is_folder,
            mime_type=mime_type,
            created_datetime=data.get("createdDateTime"),
            modified_datetime=data.get("lastModifiedDateTime"),
            web_url=data.get("webUrl"),
            download_url=data.get("@microsoft.graph.downloadUrl"),
            parent_path=parent_path or None,
            created_by=created_by,
            modified_by=modified_by,
        )


# =============================================================================
# Factory Function
# =============================================================================


def get_files_service(
    redis: "RedisService",
    user_id: UUID,
) -> FilesService:
    """Get a Files service instance.

    Args:
        redis: Redis service for token storage.
        user_id: User whose OneDrive to access.

    Returns:
        FilesService instance (use as async context manager).
    """
    return FilesService(redis, user_id)
