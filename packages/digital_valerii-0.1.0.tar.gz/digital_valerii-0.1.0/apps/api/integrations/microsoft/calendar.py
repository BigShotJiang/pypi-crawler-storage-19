"""Microsoft Calendar API service.

Provides calendar operations via Microsoft Graph API including:
- Calendar listing and management
- Event CRUD operations
- Availability checking (free/busy)
- Recurring event support
- Time zone handling
"""

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from apps.api.integrations.microsoft.graph_client import GraphClient, get_graph_client

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Models
# =============================================================================


class Calendar(BaseModel):
    """Microsoft Calendar model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Calendar ID")
    name: str = Field(..., description="Calendar name")
    color: str | None = Field(None, description="Calendar color")
    can_edit: bool = Field(default=True, description="Can edit events")
    is_default: bool = Field(default=False, description="Is default calendar")
    owner_email: str | None = Field(None, description="Owner email address")


class Attendee(BaseModel):
    """Event attendee model."""

    model_config = ConfigDict(extra="forbid")

    email: str = Field(..., description="Attendee email")
    name: str | None = Field(None, description="Attendee name")
    response_status: str = Field(
        default="none",
        description="Response status (none, organizer, tentativelyAccepted, accepted, declined)",
    )
    is_required: bool = Field(default=True, description="Required attendee")


class EventTime(BaseModel):
    """Event time with time zone."""

    model_config = ConfigDict(extra="forbid")

    datetime: str = Field(..., description="ISO 8601 datetime")
    timezone: str = Field(default="UTC", description="IANA time zone")


class Event(BaseModel):
    """Microsoft Calendar Event model."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(None, description="Event ID")
    subject: str = Field(..., description="Event subject/title")
    body: str | None = Field(None, description="Event body/description")
    body_content_type: str = Field(default="text", description="Body type (text/html)")
    start: EventTime = Field(..., description="Start time")
    end: EventTime = Field(..., description="End time")
    location: str | None = Field(None, description="Event location")
    is_all_day: bool = Field(default=False, description="All day event")
    is_online_meeting: bool = Field(default=False, description="Is online meeting")
    online_meeting_url: str | None = Field(None, description="Online meeting URL")
    attendees: list[Attendee] = Field(default_factory=list, description="Attendees")
    organizer_email: str | None = Field(None, description="Organizer email")
    recurrence: dict[str, Any] | None = Field(None, description="Recurrence pattern")
    is_cancelled: bool = Field(default=False, description="Event is cancelled")
    web_link: str | None = Field(None, description="Web link to event")


class FreeBusySlot(BaseModel):
    """Free/busy time slot."""

    model_config = ConfigDict(extra="forbid")

    start: str = Field(..., description="Start datetime ISO 8601")
    end: str = Field(..., description="End datetime ISO 8601")
    status: str = Field(..., description="Status (free, busy, tentative, oof)")


class CreateEventRequest(BaseModel):
    """Request to create a calendar event."""

    model_config = ConfigDict(extra="forbid")

    subject: str = Field(..., description="Event subject/title")
    body: str | None = Field(None, description="Event body/description")
    body_content_type: str = Field(default="text", description="Body type (text/html)")
    start_datetime: str = Field(..., description="Start datetime ISO 8601")
    start_timezone: str = Field(default="UTC", description="Start time zone")
    end_datetime: str = Field(..., description="End datetime ISO 8601")
    end_timezone: str = Field(default="UTC", description="End time zone")
    location: str | None = Field(None, description="Event location")
    is_all_day: bool = Field(default=False, description="All day event")
    is_online_meeting: bool = Field(default=False, description="Create Teams meeting")
    attendee_emails: list[str] = Field(
        default_factory=list, description="Attendee email addresses"
    )
    recurrence: dict[str, Any] | None = Field(None, description="Recurrence pattern")


class UpdateEventRequest(BaseModel):
    """Request to update a calendar event."""

    model_config = ConfigDict(extra="forbid")

    subject: str | None = Field(None, description="Event subject/title")
    body: str | None = Field(None, description="Event body/description")
    body_content_type: str | None = Field(None, description="Body type")
    start_datetime: str | None = Field(None, description="Start datetime ISO 8601")
    start_timezone: str | None = Field(None, description="Start time zone")
    end_datetime: str | None = Field(None, description="End datetime ISO 8601")
    end_timezone: str | None = Field(None, description="End time zone")
    location: str | None = Field(None, description="Event location")
    is_all_day: bool | None = Field(None, description="All day event")


# =============================================================================
# Calendar Service
# =============================================================================


class CalendarService:
    """Service for Microsoft Calendar operations.

    Provides methods for managing calendars and events via Graph API.

    Example:
        async with CalendarService(redis, user_id) as service:
            calendars = await service.get_calendars()
            events = await service.get_events(start, end)
            new_event = await service.create_event(request)
    """

    def __init__(
        self,
        redis: "RedisService",
        user_id: UUID,
    ) -> None:
        """Initialize Calendar service.

        Args:
            redis: Redis service for token storage.
            user_id: User whose calendar to access.
        """
        self._redis = redis
        self._user_id = user_id
        self._client: GraphClient | None = None

    async def __aenter__(self) -> "CalendarService":
        """Enter async context and initialize client."""
        self._client = await get_graph_client(self._redis, self._user_id)
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context and cleanup."""
        if self._client:
            await self._client.__aexit__(*args)
            self._client = None

    @property
    def client(self) -> GraphClient:
        """Get the Graph client."""
        if self._client is None:
            raise RuntimeError("CalendarService must be used as async context manager")
        return self._client

    # =========================================================================
    # Calendar Operations
    # =========================================================================

    async def get_calendars(self) -> list[Calendar]:
        """Get all calendars for the user.

        Returns:
            List of calendars.
        """
        data = await self.client.get("/me/calendars")
        calendars = []

        for item in data.get("value", []):
            calendars.append(
                Calendar(
                    id=item["id"],
                    name=item.get("name", ""),
                    color=item.get("color"),
                    can_edit=item.get("canEdit", True),
                    is_default=item.get("isDefaultCalendar", False),
                    owner_email=item.get("owner", {}).get("address"),
                )
            )

        await logger.ainfo(
            "Retrieved calendars",
            user_id=str(self._user_id),
            count=len(calendars),
        )
        return calendars

    async def get_default_calendar(self) -> Calendar:
        """Get the user's default calendar.

        Returns:
            Default calendar.
        """
        data = await self.client.get("/me/calendar")
        return Calendar(
            id=data["id"],
            name=data.get("name", ""),
            color=data.get("color"),
            can_edit=data.get("canEdit", True),
            is_default=True,
            owner_email=data.get("owner", {}).get("address"),
        )

    # =========================================================================
    # Event Operations
    # =========================================================================

    async def get_events(
        self,
        start_datetime: str,
        end_datetime: str,
        *,
        calendar_id: str | None = None,
        top: int = 100,
    ) -> list[Event]:
        """Get events within a time range.

        Args:
            start_datetime: Start of range (ISO 8601).
            end_datetime: End of range (ISO 8601).
            calendar_id: Calendar ID (default calendar if None).
            top: Maximum events to return.

        Returns:
            List of events.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"
        endpoint = f"{base_path}/calendarView"

        params = {
            "startDateTime": start_datetime,
            "endDateTime": end_datetime,
            "$top": top,
            "$orderby": "start/dateTime",
            "$select": (
                "id,subject,body,start,end,location,isAllDay,isCancelled,"
                "attendees,organizer,recurrence,onlineMeeting,webLink"
            ),
        }

        data = await self.client.get(endpoint, params=params)
        return [self._parse_event(item) for item in data.get("value", [])]

    async def get_event(
        self,
        event_id: str,
        *,
        calendar_id: str | None = None,
    ) -> Event:
        """Get a single event by ID.

        Args:
            event_id: Event ID.
            calendar_id: Calendar ID (default calendar if None).

        Returns:
            Event details.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"
        data = await self.client.get(f"{base_path}/events/{event_id}")
        return self._parse_event(data)

    async def create_event(
        self,
        request: CreateEventRequest,
        *,
        calendar_id: str | None = None,
    ) -> Event:
        """Create a new calendar event.

        Args:
            request: Event creation request.
            calendar_id: Calendar ID (default calendar if None).

        Returns:
            Created event.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"

        body: dict[str, Any] = {
            "subject": request.subject,
            "start": {
                "dateTime": request.start_datetime,
                "timeZone": request.start_timezone,
            },
            "end": {
                "dateTime": request.end_datetime,
                "timeZone": request.end_timezone,
            },
            "isAllDay": request.is_all_day,
        }

        if request.body:
            body["body"] = {
                "contentType": request.body_content_type,
                "content": request.body,
            }

        if request.location:
            body["location"] = {"displayName": request.location}

        if request.is_online_meeting:
            body["isOnlineMeeting"] = True
            body["onlineMeetingProvider"] = "teamsForBusiness"

        if request.attendee_emails:
            body["attendees"] = [
                {
                    "emailAddress": {"address": email},
                    "type": "required",
                }
                for email in request.attendee_emails
            ]

        if request.recurrence:
            body["recurrence"] = request.recurrence

        data = await self.client.post(f"{base_path}/events", json=body)

        await logger.ainfo(
            "Created calendar event",
            user_id=str(self._user_id),
            event_id=data.get("id"),
            subject=request.subject,
        )

        return self._parse_event(data)

    async def update_event(
        self,
        event_id: str,
        request: UpdateEventRequest,
        *,
        calendar_id: str | None = None,
    ) -> Event:
        """Update an existing calendar event.

        Args:
            event_id: Event ID.
            request: Event update request.
            calendar_id: Calendar ID (default calendar if None).

        Returns:
            Updated event.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"

        body: dict[str, Any] = {}

        if request.subject is not None:
            body["subject"] = request.subject

        if request.body is not None:
            body["body"] = {
                "contentType": request.body_content_type or "text",
                "content": request.body,
            }

        if request.start_datetime is not None:
            body["start"] = {
                "dateTime": request.start_datetime,
                "timeZone": request.start_timezone or "UTC",
            }

        if request.end_datetime is not None:
            body["end"] = {
                "dateTime": request.end_datetime,
                "timeZone": request.end_timezone or "UTC",
            }

        if request.location is not None:
            body["location"] = {"displayName": request.location}

        if request.is_all_day is not None:
            body["isAllDay"] = request.is_all_day

        data = await self.client.patch(f"{base_path}/events/{event_id}", json=body)

        await logger.ainfo(
            "Updated calendar event",
            user_id=str(self._user_id),
            event_id=event_id,
        )

        return self._parse_event(data)

    async def delete_event(
        self,
        event_id: str,
        *,
        calendar_id: str | None = None,
    ) -> bool:
        """Delete a calendar event.

        Args:
            event_id: Event ID.
            calendar_id: Calendar ID (default calendar if None).

        Returns:
            True if deleted successfully.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"
        await self.client.delete(f"{base_path}/events/{event_id}")

        await logger.ainfo(
            "Deleted calendar event",
            user_id=str(self._user_id),
            event_id=event_id,
        )

        return True

    # =========================================================================
    # Availability
    # =========================================================================

    async def get_free_busy(
        self,
        emails: list[str],
        start_datetime: str,
        end_datetime: str,
        *,
        timezone: str = "UTC",
    ) -> dict[str, list[FreeBusySlot]]:
        """Get free/busy schedule for users.

        Args:
            emails: List of email addresses to check.
            start_datetime: Start of range (ISO 8601).
            end_datetime: End of range (ISO 8601).
            timezone: Time zone for the response.

        Returns:
            Dict mapping email to list of busy slots.
        """
        body = {
            "schedules": emails,
            "startTime": {
                "dateTime": start_datetime,
                "timeZone": timezone,
            },
            "endTime": {
                "dateTime": end_datetime,
                "timeZone": timezone,
            },
            "availabilityViewInterval": 30,  # 30-minute slots
        }

        data = await self.client.post("/me/calendar/getSchedule", json=body)

        result: dict[str, list[FreeBusySlot]] = {}
        for schedule in data.get("value", []):
            email = schedule.get("scheduleId", "")
            slots = []
            for item in schedule.get("scheduleItems", []):
                slots.append(
                    FreeBusySlot(
                        start=item.get("start", {}).get("dateTime", ""),
                        end=item.get("end", {}).get("dateTime", ""),
                        status=item.get("status", "busy"),
                    )
                )
            result[email] = slots

        return result

    async def find_meeting_times(
        self,
        attendee_emails: list[str],
        start_datetime: str,
        end_datetime: str,
        *,
        duration_minutes: int = 60,
        timezone: str = "UTC",
        max_candidates: int = 5,
    ) -> list[dict[str, Any]]:
        """Find available meeting times.

        Args:
            attendee_emails: List of attendee emails.
            start_datetime: Start of search range (ISO 8601).
            end_datetime: End of search range (ISO 8601).
            duration_minutes: Meeting duration in minutes.
            timezone: Time zone for suggestions.
            max_candidates: Maximum suggestions to return.

        Returns:
            List of meeting time suggestions.
        """
        body = {
            "attendees": [
                {"emailAddress": {"address": email}} for email in attendee_emails
            ],
            "timeConstraint": {
                "timeslots": [
                    {
                        "start": {
                            "dateTime": start_datetime,
                            "timeZone": timezone,
                        },
                        "end": {
                            "dateTime": end_datetime,
                            "timeZone": timezone,
                        },
                    }
                ]
            },
            "meetingDuration": f"PT{duration_minutes}M",
            "maxCandidates": max_candidates,
        }

        data = await self.client.post("/me/findMeetingTimes", json=body)
        return data.get("meetingTimeSuggestions", [])

    # =========================================================================
    # Pagination
    # =========================================================================

    async def iter_events(
        self,
        start_datetime: str,
        end_datetime: str,
        *,
        calendar_id: str | None = None,
        page_size: int = 100,
    ) -> AsyncIterator[Event]:
        """Iterate over all events in a time range.

        Args:
            start_datetime: Start of range (ISO 8601).
            end_datetime: End of range (ISO 8601).
            calendar_id: Calendar ID (default calendar if None).
            page_size: Events per page.

        Yields:
            Events in the time range.
        """
        base_path = f"/me/calendars/{calendar_id}" if calendar_id else "/me/calendar"
        endpoint = f"{base_path}/calendarView"

        params = {
            "startDateTime": start_datetime,
            "endDateTime": end_datetime,
            "$orderby": "start/dateTime",
        }

        async for item in self.client.paginate(endpoint, params=params, top=page_size):
            yield self._parse_event(item)

    # =========================================================================
    # Helpers
    # =========================================================================

    def _parse_event(self, data: dict[str, Any]) -> Event:
        """Parse Graph API event data to Event model.

        Args:
            data: Raw event data from Graph API.

        Returns:
            Parsed Event model.
        """
        attendees = []
        for att in data.get("attendees", []):
            attendees.append(
                Attendee(
                    email=att.get("emailAddress", {}).get("address", ""),
                    name=att.get("emailAddress", {}).get("name"),
                    response_status=att.get("status", {}).get("response", "none"),
                    is_required=att.get("type", "required") == "required",
                )
            )

        start_data = data.get("start", {})
        end_data = data.get("end", {})

        return Event(
            id=data.get("id"),
            subject=data.get("subject", ""),
            body=data.get("body", {}).get("content"),
            body_content_type=data.get("body", {}).get("contentType", "text"),
            start=EventTime(
                datetime=start_data.get("dateTime", ""),
                timezone=start_data.get("timeZone", "UTC"),
            ),
            end=EventTime(
                datetime=end_data.get("dateTime", ""),
                timezone=end_data.get("timeZone", "UTC"),
            ),
            location=data.get("location", {}).get("displayName"),
            is_all_day=data.get("isAllDay", False),
            is_online_meeting=data.get("isOnlineMeeting", False),
            online_meeting_url=data.get("onlineMeeting", {}).get("joinUrl"),
            attendees=attendees,
            organizer_email=data.get("organizer", {})
            .get("emailAddress", {})
            .get("address"),
            recurrence=data.get("recurrence"),
            is_cancelled=data.get("isCancelled", False),
            web_link=data.get("webLink"),
        )


# =============================================================================
# Factory Function
# =============================================================================


def get_calendar_service(
    redis: "RedisService",
    user_id: UUID,
) -> CalendarService:
    """Get a Calendar service instance.

    Args:
        redis: Redis service for token storage.
        user_id: User whose calendar to access.

    Returns:
        CalendarService instance (use as async context manager).
    """
    return CalendarService(redis, user_id)
