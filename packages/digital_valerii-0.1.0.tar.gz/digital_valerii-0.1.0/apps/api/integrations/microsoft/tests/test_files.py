"""Tests for Microsoft OneDrive Files API service."""

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.files import (
    CreateFolderRequest,
    CreateShareLinkRequest,
    DriveInfo,
    DriveItem,
    FilesService,
    ShareLink,
    get_files_service,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def mock_redis():
    """Create mock Redis service."""
    return AsyncMock()


@pytest.fixture
def mock_graph_client():
    """Create mock Graph client."""
    client = AsyncMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


@pytest.fixture
def files_service(mock_redis, sample_user_id, mock_graph_client):
    """Create files service with mock client."""
    service = FilesService(mock_redis, sample_user_id)
    service._client = mock_graph_client
    return service


@pytest.fixture
def sample_drive_data():
    """Sample drive data from Graph API."""
    return {
        "id": "drive-123",
        "name": "OneDrive",
        "driveType": "personal",
        "owner": {"user": {"email": "user@example.com"}},
        "quota": {
            "total": 5368709120,
            "used": 1073741824,
            "remaining": 4294967296,
        },
    }


@pytest.fixture
def sample_item_data():
    """Sample file item data from Graph API."""
    return {
        "id": "item-123",
        "name": "document.pdf",
        "size": 12345,
        "file": {"mimeType": "application/pdf"},
        "createdDateTime": "2025-01-15T10:00:00Z",
        "lastModifiedDateTime": "2025-01-15T11:00:00Z",
        "webUrl": "https://onedrive.live.com/view/document.pdf",
        "@microsoft.graph.downloadUrl": "https://download.onedrive.com/file",
        "parentReference": {"path": "/drive/root:/Documents"},
        "createdBy": {"user": {"email": "user@example.com"}},
        "lastModifiedBy": {"user": {"email": "user@example.com"}},
    }


@pytest.fixture
def sample_folder_data():
    """Sample folder item data from Graph API."""
    return {
        "id": "folder-123",
        "name": "Documents",
        "size": 0,
        "folder": {"childCount": 5},
        "createdDateTime": "2025-01-10T10:00:00Z",
        "lastModifiedDateTime": "2025-01-15T10:00:00Z",
        "webUrl": "https://onedrive.live.com/folder/Documents",
        "parentReference": {"path": "/drive/root:"},
    }


# =============================================================================
# Drive Information Tests
# =============================================================================


class TestGetDriveInfo:
    """Tests for get_drive_info method."""

    @pytest.mark.anyio
    async def test_get_drive_info_success(
        self, files_service, mock_graph_client, sample_drive_data
    ):
        """Should return drive information."""
        mock_graph_client.get.return_value = sample_drive_data

        info = await files_service.get_drive_info()

        assert info.id == "drive-123"
        assert info.name == "OneDrive"
        assert info.drive_type == "personal"
        assert info.quota_total == 5368709120
        assert info.quota_used == 1073741824


# =============================================================================
# Item Operations Tests
# =============================================================================


class TestListItems:
    """Tests for list_items method."""

    @pytest.mark.anyio
    async def test_list_items_root(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should list items in root folder."""
        mock_graph_client.get.return_value = {"value": [sample_item_data]}

        items = await files_service.list_items("/")

        assert len(items) == 1
        assert items[0].id == "item-123"
        assert items[0].name == "document.pdf"

    @pytest.mark.anyio
    async def test_list_items_subfolder(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should list items in subfolder."""
        mock_graph_client.get.return_value = {"value": [sample_item_data]}

        await files_service.list_items("/Documents")

        call_args = mock_graph_client.get.call_args
        assert "Documents" in call_args[0][0]


class TestGetItem:
    """Tests for get_item method."""

    @pytest.mark.anyio
    async def test_get_item_by_id(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should get item by ID."""
        mock_graph_client.get.return_value = sample_item_data

        item = await files_service.get_item("item-123")

        assert item.id == "item-123"
        assert item.name == "document.pdf"
        assert item.is_folder is False

    @pytest.mark.anyio
    async def test_get_item_by_path(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should get item by path."""
        mock_graph_client.get.return_value = sample_item_data

        item = await files_service.get_item_by_path("/Documents/document.pdf")

        assert item.name == "document.pdf"


class TestCreateFolder:
    """Tests for create_folder method."""

    @pytest.mark.anyio
    async def test_create_folder_success(
        self, files_service, mock_graph_client, sample_folder_data
    ):
        """Should create folder."""
        mock_graph_client.post.return_value = sample_folder_data

        request = CreateFolderRequest(name="New Folder", parent_path="/")

        folder = await files_service.create_folder(request)

        assert folder.name == "Documents"
        assert folder.is_folder is True
        mock_graph_client.post.assert_called_once()

    @pytest.mark.anyio
    async def test_create_folder_in_subfolder(
        self, files_service, mock_graph_client, sample_folder_data
    ):
        """Should create folder in subfolder."""
        mock_graph_client.post.return_value = sample_folder_data

        request = CreateFolderRequest(name="SubFolder", parent_path="/Documents")

        await files_service.create_folder(request)

        call_args = mock_graph_client.post.call_args
        assert "Documents" in call_args[0][0]


class TestDeleteItem:
    """Tests for delete_item method."""

    @pytest.mark.anyio
    async def test_delete_item_success(self, files_service, mock_graph_client):
        """Should delete item."""
        mock_graph_client.delete.return_value = None

        result = await files_service.delete_item("item-123")

        assert result is True
        mock_graph_client.delete.assert_called_once()


class TestRenameItem:
    """Tests for rename_item method."""

    @pytest.mark.anyio
    async def test_rename_item_success(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should rename item."""
        sample_item_data["name"] = "renamed.pdf"
        mock_graph_client.patch.return_value = sample_item_data

        item = await files_service.rename_item("item-123", "renamed.pdf")

        assert item.name == "renamed.pdf"


class TestMoveItem:
    """Tests for move_item method."""

    @pytest.mark.anyio
    async def test_move_item_success(
        self, files_service, mock_graph_client, sample_item_data, sample_folder_data
    ):
        """Should move item."""
        mock_graph_client.get.return_value = sample_folder_data
        mock_graph_client.patch.return_value = sample_item_data

        item = await files_service.move_item("item-123", "/Archive")

        mock_graph_client.patch.assert_called_once()


# =============================================================================
# Search Tests
# =============================================================================


class TestSearch:
    """Tests for search method."""

    @pytest.mark.anyio
    async def test_search_success(
        self, files_service, mock_graph_client, sample_item_data
    ):
        """Should search files."""
        mock_graph_client.get.return_value = {"value": [sample_item_data]}

        items = await files_service.search("document")

        assert len(items) == 1
        call_args = mock_graph_client.get.call_args
        assert "search" in call_args[0][0]


# =============================================================================
# Sharing Tests
# =============================================================================


class TestCreateShareLink:
    """Tests for create_share_link method."""

    @pytest.mark.anyio
    async def test_create_share_link_success(self, files_service, mock_graph_client):
        """Should create sharing link."""
        mock_graph_client.post.return_value = {
            "id": "link-123",
            "link": {
                "webUrl": "https://1drv.ms/share/abc123",
                "type": "view",
                "scope": "anonymous",
            },
        }

        request = CreateShareLinkRequest(
            item_id="item-123",
            link_type="view",
            scope="anonymous",
        )

        link = await files_service.create_share_link(request)

        assert link.link_url == "https://1drv.ms/share/abc123"
        assert link.link_type == "view"


class TestPermissions:
    """Tests for permission operations."""

    @pytest.mark.anyio
    async def test_get_permissions(self, files_service, mock_graph_client):
        """Should get item permissions."""
        mock_graph_client.get.return_value = {
            "value": [
                {"id": "perm-1", "roles": ["read"]},
                {"id": "perm-2", "roles": ["write"]},
            ]
        }

        permissions = await files_service.get_permissions("item-123")

        assert len(permissions) == 2

    @pytest.mark.anyio
    async def test_delete_permission(self, files_service, mock_graph_client):
        """Should delete permission."""
        mock_graph_client.delete.return_value = None

        result = await files_service.delete_permission("item-123", "perm-1")

        assert result is True


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_drive_item_file(self):
        """DriveItem should correctly identify files."""
        item = DriveItem(
            id="item-1",
            name="file.txt",
            is_folder=False,
            mime_type="text/plain",
        )
        assert item.is_folder is False
        assert item.mime_type == "text/plain"

    def test_drive_item_folder(self):
        """DriveItem should correctly identify folders."""
        item = DriveItem(
            id="folder-1",
            name="Documents",
            is_folder=True,
        )
        assert item.is_folder is True
        assert item.mime_type is None

    def test_drive_info(self):
        """DriveInfo should have correct defaults."""
        info = DriveInfo(
            id="drive-1",
            name="OneDrive",
            drive_type="personal",
        )
        assert info.quota_total == 0
        assert info.quota_used == 0

    def test_share_link(self):
        """ShareLink should serialize correctly."""
        link = ShareLink(
            link_url="https://1drv.ms/abc",
            link_type="view",
        )
        assert link.link_url == "https://1drv.ms/abc"


# =============================================================================
# Context Manager Tests
# =============================================================================


class TestContextManager:
    """Tests for async context manager."""

    @pytest.mark.anyio
    async def test_context_manager_lifecycle(self, mock_redis, sample_user_id):
        """Should manage client lifecycle."""
        from unittest.mock import patch

        mock_client = AsyncMock()
        mock_client.get.return_value = {
            "id": "drive-1",
            "name": "OneDrive",
            "driveType": "personal",
            "quota": {},
        }

        with patch(
            "apps.api.integrations.microsoft.files.get_graph_client",
            return_value=mock_client,
        ):
            async with FilesService(mock_redis, sample_user_id) as service:
                await service.get_drive_info()

            mock_client.__aenter__.assert_called_once()
            mock_client.__aexit__.assert_called_once()

    def test_client_property_without_context(self, mock_redis, sample_user_id):
        """Should raise error outside context."""
        service = FilesService(mock_redis, sample_user_id)

        with pytest.raises(RuntimeError, match="must be used as async context manager"):
            _ = service.client


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunction:
    """Tests for get_files_service factory."""

    def test_get_files_service(self, mock_redis, sample_user_id):
        """Should create FilesService instance."""
        service = get_files_service(mock_redis, sample_user_id)

        assert isinstance(service, FilesService)
        assert service._user_id == sample_user_id
