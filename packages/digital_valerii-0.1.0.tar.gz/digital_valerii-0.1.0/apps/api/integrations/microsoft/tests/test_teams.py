"""Tests for Microsoft Teams API service."""

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.teams import (
    Channel,
    Chat,
    ChatMessage,
    ReplyMessageRequest,
    SendMessageRequest,
    Team,
    TeamsService,
    get_teams_service,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def mock_redis():
    """Create mock Redis service."""
    return AsyncMock()


@pytest.fixture
def mock_graph_client():
    """Create mock Graph client."""
    client = AsyncMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


@pytest.fixture
def teams_service(mock_redis, sample_user_id, mock_graph_client):
    """Create teams service with mock client."""
    service = TeamsService(mock_redis, sample_user_id)
    service._client = mock_graph_client
    return service


@pytest.fixture
def sample_team_data():
    """Sample team data from Graph API."""
    return {
        "id": "team-123",
        "displayName": "Engineering Team",
        "description": "Engineering team channel",
        "visibility": "private",
        "webUrl": "https://teams.microsoft.com/team/123",
        "isArchived": False,
    }


@pytest.fixture
def sample_channel_data():
    """Sample channel data from Graph API."""
    return {
        "id": "channel-456",
        "displayName": "General",
        "description": "General discussions",
        "membershipType": "standard",
        "webUrl": "https://teams.microsoft.com/channel/456",
        "isFavoriteByDefault": True,
    }


@pytest.fixture
def sample_message_data():
    """Sample message data from Graph API."""
    return {
        "id": "msg-789",
        "messageType": "message",
        "createdDateTime": "2025-01-15T10:00:00Z",
        "lastModifiedDateTime": "2025-01-15T10:00:00Z",
        "from": {
            "user": {
                "id": "user-123",
                "displayName": "John Doe",
            }
        },
        "body": {
            "contentType": "text",
            "content": "Hello team!",
        },
        "importance": "normal",
        "webUrl": "https://teams.microsoft.com/message/789",
        "attachments": [],
        "mentions": [],
    }


@pytest.fixture
def sample_chat_data():
    """Sample chat data from Graph API."""
    return {
        "id": "chat-101",
        "topic": "Project Discussion",
        "chatType": "group",
        "createdDateTime": "2025-01-10T10:00:00Z",
        "lastUpdatedDateTime": "2025-01-15T15:00:00Z",
        "webUrl": "https://teams.microsoft.com/chat/101",
        "members": [
            {"userId": "user-1"},
            {"userId": "user-2"},
        ],
    }


# =============================================================================
# Team Operations Tests
# =============================================================================


class TestGetTeams:
    """Tests for get_teams method."""

    @pytest.mark.anyio
    async def test_get_teams_success(
        self, teams_service, mock_graph_client, sample_team_data
    ):
        """Should return list of teams."""
        mock_graph_client.get.return_value = {"value": [sample_team_data]}

        teams = await teams_service.get_teams()

        assert len(teams) == 1
        assert teams[0].id == "team-123"
        assert teams[0].display_name == "Engineering Team"

    @pytest.mark.anyio
    async def test_get_team_by_id(
        self, teams_service, mock_graph_client, sample_team_data
    ):
        """Should return specific team."""
        mock_graph_client.get.return_value = sample_team_data

        team = await teams_service.get_team("team-123")

        assert team.id == "team-123"
        assert team.visibility == "private"


# =============================================================================
# Channel Operations Tests
# =============================================================================


class TestGetChannels:
    """Tests for get_channels method."""

    @pytest.mark.anyio
    async def test_get_channels_success(
        self, teams_service, mock_graph_client, sample_channel_data
    ):
        """Should return list of channels."""
        mock_graph_client.get.return_value = {"value": [sample_channel_data]}

        channels = await teams_service.get_channels("team-123")

        assert len(channels) == 1
        assert channels[0].id == "channel-456"
        assert channels[0].display_name == "General"

    @pytest.mark.anyio
    async def test_get_channel_by_id(
        self, teams_service, mock_graph_client, sample_channel_data
    ):
        """Should return specific channel."""
        mock_graph_client.get.return_value = sample_channel_data

        channel = await teams_service.get_channel("team-123", "channel-456")

        assert channel.id == "channel-456"
        assert channel.is_favorite is True


# =============================================================================
# Channel Message Tests
# =============================================================================


class TestChannelMessages:
    """Tests for channel message operations."""

    @pytest.mark.anyio
    async def test_get_channel_messages(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should return channel messages."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        messages = await teams_service.get_channel_messages("team-123", "channel-456")

        assert len(messages) == 1
        assert messages[0].id == "msg-789"
        assert messages[0].body_content == "Hello team!"

    @pytest.mark.anyio
    async def test_get_message_replies(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should return message replies."""
        sample_message_data["replyToId"] = "msg-789"
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        replies = await teams_service.get_message_replies(
            "team-123", "channel-456", "msg-789"
        )

        assert len(replies) == 1

    @pytest.mark.anyio
    async def test_send_channel_message(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should send message to channel."""
        mock_graph_client.post.return_value = sample_message_data

        request = SendMessageRequest(content="Hello team!")

        message = await teams_service.send_channel_message(
            "team-123", "channel-456", request
        )

        assert message.body_content == "Hello team!"
        mock_graph_client.post.assert_called_once()

    @pytest.mark.anyio
    async def test_send_channel_message_with_mentions(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should send message with @mentions."""
        mock_graph_client.post.return_value = sample_message_data

        request = SendMessageRequest(
            content="@John Doe please review",
            mentions=[{"id": "0", "display_name": "John Doe", "user_id": "user-123"}],
        )

        await teams_service.send_channel_message("team-123", "channel-456", request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert "mentions" in json_body

    @pytest.mark.anyio
    async def test_reply_to_channel_message(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should reply to channel message."""
        mock_graph_client.post.return_value = sample_message_data

        request = ReplyMessageRequest(content="Thanks!")

        reply = await teams_service.reply_to_channel_message(
            "team-123", "channel-456", "msg-789", request
        )

        assert reply is not None
        call_args = mock_graph_client.post.call_args
        assert "/replies" in call_args[0][0]


# =============================================================================
# Chat Tests
# =============================================================================


class TestChatOperations:
    """Tests for chat operations."""

    @pytest.mark.anyio
    async def test_get_chats(self, teams_service, mock_graph_client, sample_chat_data):
        """Should return list of chats."""
        mock_graph_client.get.return_value = {"value": [sample_chat_data]}

        chats = await teams_service.get_chats()

        assert len(chats) == 1
        assert chats[0].id == "chat-101"
        assert chats[0].chat_type == "group"
        assert len(chats[0].members) == 2

    @pytest.mark.anyio
    async def test_get_chat_by_id(
        self, teams_service, mock_graph_client, sample_chat_data
    ):
        """Should return specific chat."""
        mock_graph_client.get.return_value = sample_chat_data

        chat = await teams_service.get_chat("chat-101")

        assert chat.id == "chat-101"
        assert chat.topic == "Project Discussion"

    @pytest.mark.anyio
    async def test_get_chat_messages(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should return chat messages."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        messages = await teams_service.get_chat_messages("chat-101")

        assert len(messages) == 1

    @pytest.mark.anyio
    async def test_send_chat_message(
        self, teams_service, mock_graph_client, sample_message_data
    ):
        """Should send message to chat."""
        mock_graph_client.post.return_value = sample_message_data

        request = SendMessageRequest(content="Hi there!")

        message = await teams_service.send_chat_message("chat-101", request)

        assert message is not None
        mock_graph_client.post.assert_called_once()


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_team_model(self):
        """Team should have correct defaults."""
        team = Team(id="team-1", display_name="Test Team")
        assert team.id == "team-1"
        assert team.visibility == "private"
        assert team.is_archived is False

    def test_channel_model(self):
        """Channel should have correct defaults."""
        channel = Channel(id="channel-1", display_name="General")
        assert channel.id == "channel-1"
        assert channel.membership_type == "standard"

    def test_chat_message_model(self):
        """ChatMessage should have correct defaults."""
        msg = ChatMessage(body_content="Hello")
        assert msg.body_content == "Hello"
        assert msg.importance == "normal"

    def test_chat_model(self):
        """Chat should serialize correctly."""
        chat = Chat(id="chat-1", chat_type="oneOnOne")
        assert chat.chat_type == "oneOnOne"
        assert chat.members == []


# =============================================================================
# Helper Tests
# =============================================================================


class TestHelpers:
    """Tests for helper methods."""

    def test_build_content_with_mentions(self, teams_service):
        """Should insert mention tags."""
        content = "@John please review"
        mentions = [{"display_name": "John", "user_id": "user-1"}]

        result = teams_service._build_content_with_mentions(content, mentions)

        assert '<at id="0">John</at>' in result

    def test_build_content_without_mentions(self, teams_service):
        """Should return content unchanged."""
        content = "Hello team"

        result = teams_service._build_content_with_mentions(content, [])

        assert result == "Hello team"


# =============================================================================
# Context Manager Tests
# =============================================================================


class TestContextManager:
    """Tests for async context manager."""

    @pytest.mark.anyio
    async def test_context_manager_lifecycle(self, mock_redis, sample_user_id):
        """Should manage client lifecycle."""
        from unittest.mock import patch

        mock_client = AsyncMock()
        mock_client.get.return_value = {"value": []}

        with patch(
            "apps.api.integrations.microsoft.teams.get_graph_client",
            return_value=mock_client,
        ):
            async with TeamsService(mock_redis, sample_user_id) as service:
                await service.get_teams()

            mock_client.__aenter__.assert_called_once()
            mock_client.__aexit__.assert_called_once()

    def test_client_property_without_context(self, mock_redis, sample_user_id):
        """Should raise error outside context."""
        service = TeamsService(mock_redis, sample_user_id)

        with pytest.raises(RuntimeError, match="must be used as async context manager"):
            _ = service.client


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunction:
    """Tests for get_teams_service factory."""

    def test_get_teams_service(self, mock_redis, sample_user_id):
        """Should create TeamsService instance."""
        service = get_teams_service(mock_redis, sample_user_id)

        assert isinstance(service, TeamsService)
        assert service._user_id == sample_user_id
