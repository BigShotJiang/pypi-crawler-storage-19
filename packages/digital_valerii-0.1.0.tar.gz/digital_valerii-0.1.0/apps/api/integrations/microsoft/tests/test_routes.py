"""Tests for Microsoft OAuth routes."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

from apps.api.auth.dependencies import get_current_user
from apps.api.dependencies import get_redis
from apps.api.integrations.microsoft.exceptions import (
    InvalidStateError,
    TokenRefreshError,
)
from apps.api.integrations.microsoft.models import MicrosoftToken, MicrosoftUser
from apps.api.integrations.microsoft.oauth import MicrosoftOAuth
from apps.api.integrations.microsoft.routes import get_microsoft_oauth
from apps.api.main import app

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_user():
    """Create mock authenticated user."""
    user = MagicMock()
    user.id = uuid4()
    user.email = "test@example.com"
    return user


@pytest.fixture
def mock_redis():
    """Create mock Redis service."""
    redis = AsyncMock()
    redis.cache_set = AsyncMock()
    redis.cache_get = AsyncMock(return_value=None)
    redis.cache_delete = AsyncMock(return_value=1)
    return redis


@pytest.fixture
def mock_oauth():
    """Create mock MicrosoftOAuth."""
    return AsyncMock(spec=MicrosoftOAuth)


@pytest.fixture
def client(mock_user, mock_redis, mock_oauth):
    """Create test client with dependency overrides."""
    app.dependency_overrides[get_current_user] = lambda: mock_user
    app.dependency_overrides[get_redis] = lambda: mock_redis
    app.dependency_overrides[get_microsoft_oauth] = lambda: mock_oauth

    yield TestClient(app)

    # Clean up overrides
    app.dependency_overrides.clear()


@pytest.fixture
def unauthenticated_client():
    """Create test client without auth override."""
    return TestClient(app)


@pytest.fixture
def sample_tokens(mock_user):
    """Create sample tokens."""
    return MicrosoftToken(
        user_id=mock_user.id,
        access_token="test-access",
        refresh_token="test-refresh",
        token_type="Bearer",
        expires_at=datetime.now(UTC) + timedelta(hours=1),
        scope="openid profile email",
    )


@pytest.fixture
def sample_ms_user():
    """Create sample Microsoft user."""
    return MicrosoftUser(
        id="ms-user-123",
        display_name="Test User",
        mail="test@microsoft.com",
    )


# =============================================================================
# Initiate OAuth Tests
# =============================================================================


class TestInitiateOAuth:
    """Tests for OAuth initiation endpoint."""

    def test_initiate_oauth_unauthenticated(self, unauthenticated_client):
        """Should require authentication."""
        response = unauthenticated_client.get("/api/v1/auth/microsoft")
        assert response.status_code == 401

    def test_initiate_oauth_success(self, client, mock_oauth):
        """Should return authorization URL."""
        mock_oauth.get_authorize_url.return_value = (
            "https://login.microsoftonline.com/authorize?...",
            "test-state",
        )

        response = client.get("/api/v1/auth/microsoft")

        assert response.status_code == 200
        data = response.json()
        assert "authorize_url" in data
        assert "state" in data
        assert data["state"] == "test-state"

    def test_initiate_oauth_with_redirect(self, client, mock_oauth, mock_user):
        """Should accept custom redirect URI."""
        mock_oauth.get_authorize_url.return_value = (
            "https://login.microsoftonline.com/authorize?...",
            "test-state",
        )

        response = client.get(
            "/api/v1/auth/microsoft?redirect_uri=http://myapp.com/done"
        )

        assert response.status_code == 200
        mock_oauth.get_authorize_url.assert_called_once()
        call_args = mock_oauth.get_authorize_url.call_args
        assert call_args.kwargs.get("redirect_uri_after") == "http://myapp.com/done"


# =============================================================================
# Callback Tests (Browser redirect)
# =============================================================================


class TestOAuthCallback:
    """Tests for OAuth callback endpoint (browser redirect)."""

    def test_callback_with_error(self, client, mock_oauth):
        """Should redirect with error on auth failure."""
        response = client.get(
            "/api/v1/auth/microsoft/callback?code=test&state=test&error=access_denied&error_description=User+denied",
            follow_redirects=False,
        )

        assert response.status_code == 302
        assert "error=access_denied" in response.headers["location"]

    def test_callback_invalid_state(self, client, mock_oauth):
        """Should redirect with error on invalid state."""
        mock_oauth.handle_callback.side_effect = InvalidStateError("Invalid state")

        response = client.get(
            "/api/v1/auth/microsoft/callback?code=test&state=invalid",
            follow_redirects=False,
        )

        assert response.status_code == 302
        assert "error=invalid_state" in response.headers["location"]

    def test_callback_success(self, client, mock_oauth, sample_tokens, sample_ms_user):
        """Should redirect with success on valid callback."""
        mock_oauth.handle_callback.return_value = (
            sample_tokens,
            sample_ms_user,
            None,
        )

        response = client.get(
            "/api/v1/auth/microsoft/callback?code=auth-code&state=valid-state",
            follow_redirects=False,
        )

        assert response.status_code == 302
        assert "microsoft_connected=true" in response.headers["location"]
        # FIX-3: Email is now URL-encoded, @ becomes %40
        assert "email=test%40microsoft.com" in response.headers["location"]


# =============================================================================
# API Callback Tests (for mobile/SPA)
# =============================================================================


class TestOAuthCallbackAPI:
    """Tests for OAuth callback API endpoint."""

    def test_callback_api_invalid_state(self, client, mock_oauth):
        """Should return 400 on invalid state."""
        mock_oauth.handle_callback.side_effect = InvalidStateError("Invalid state")

        response = client.post(
            "/api/v1/auth/microsoft/callback?code=test&state=invalid"
        )

        assert response.status_code == 400
        assert "Invalid or expired" in response.json()["detail"]

    def test_callback_api_success(
        self, client, mock_oauth, sample_tokens, sample_ms_user
    ):
        """Should return user info on success."""
        mock_oauth.handle_callback.return_value = (
            sample_tokens,
            sample_ms_user,
            None,
        )

        response = client.post(
            "/api/v1/auth/microsoft/callback?code=auth-code&state=valid-state"
        )

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["user"]["mail"] == "test@microsoft.com"


# =============================================================================
# Token Refresh Tests
# =============================================================================


class TestRefreshTokens:
    """Tests for token refresh endpoint."""

    def test_refresh_unauthenticated(self, unauthenticated_client):
        """Should require authentication."""
        response = unauthenticated_client.post("/api/v1/auth/microsoft/refresh")
        assert response.status_code == 401

    def test_refresh_no_tokens(self, client, mock_oauth):
        """Should return 400 when no tokens exist."""
        mock_oauth.refresh_tokens.side_effect = TokenRefreshError("No tokens found")

        response = client.post("/api/v1/auth/microsoft/refresh")

        assert response.status_code == 400
        assert "No tokens found" in response.json()["detail"]

    def test_refresh_success(self, client, mock_oauth, sample_tokens):
        """Should return new expiration on success."""
        mock_oauth.refresh_tokens.return_value = sample_tokens

        response = client.post("/api/v1/auth/microsoft/refresh")

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "expires_at" in data


# =============================================================================
# Connection Status Tests
# =============================================================================


class TestConnectionStatus:
    """Tests for connection status endpoint."""

    def test_status_unauthenticated(self, unauthenticated_client):
        """Should require authentication."""
        response = unauthenticated_client.get("/api/v1/auth/microsoft/status")
        assert response.status_code == 401

    def test_status_not_connected(self, client, mock_oauth):
        """Should return not connected when no tokens."""
        mock_oauth.get_tokens.return_value = None

        response = client.get("/api/v1/auth/microsoft/status")

        assert response.status_code == 200
        data = response.json()
        assert data["connected"] is False

    def test_status_connected(self, client, mock_oauth, sample_tokens):
        """Should return connected with expiration."""
        mock_oauth.get_tokens.return_value = sample_tokens

        response = client.get("/api/v1/auth/microsoft/status")

        assert response.status_code == 200
        data = response.json()
        assert data["connected"] is True
        assert "expires_at" in data


# =============================================================================
# Disconnect Tests
# =============================================================================


class TestDisconnect:
    """Tests for disconnect endpoint."""

    def test_disconnect_unauthenticated(self, unauthenticated_client):
        """Should require authentication."""
        response = unauthenticated_client.delete("/api/v1/auth/microsoft")
        assert response.status_code == 401

    def test_disconnect_not_connected(self, client, mock_oauth):
        """Should return 404 when no connection exists."""
        mock_oauth.delete_tokens.return_value = False

        response = client.delete("/api/v1/auth/microsoft")

        assert response.status_code == 404

    def test_disconnect_success(self, client, mock_oauth):
        """Should successfully disconnect."""
        mock_oauth.delete_tokens.return_value = True

        response = client.delete("/api/v1/auth/microsoft")

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
