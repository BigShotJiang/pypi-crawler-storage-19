"""Tests for Microsoft Graph API client."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.exceptions import (
    GraphAPIError,
    PermissionDeniedError,
    RateLimitError,
    ResourceNotFoundError,
)
from apps.api.integrations.microsoft.graph_client import (
    GRAPH_BASE_URL,
    GraphClient,
    _parse_retry_after,
    get_graph_client,
)
from apps.api.integrations.microsoft.models import MicrosoftToken

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def mock_oauth(sample_user_id):
    """Create mock OAuth client."""
    oauth = AsyncMock()
    oauth.get_valid_token.return_value = MicrosoftToken(
        user_id=sample_user_id,
        access_token="test-access-token",
        refresh_token="test-refresh",
        token_type="Bearer",
        expires_at=datetime.now(UTC) + timedelta(hours=1),
        scope="openid profile email",
    )
    return oauth


@pytest.fixture
def graph_client(mock_oauth, sample_user_id):
    """Create Graph client with mock OAuth."""
    return GraphClient(mock_oauth, sample_user_id)


# =============================================================================
# Authentication Tests
# =============================================================================


class TestAuthentication:
    """Tests for authentication handling."""

    @pytest.mark.anyio
    async def test_get_headers_includes_token(self, graph_client, mock_oauth):
        """Should include access token in headers."""
        headers = await graph_client._get_headers()

        assert "Authorization" in headers
        assert headers["Authorization"] == "Bearer test-access-token"
        assert headers["Content-Type"] == "application/json"

    @pytest.mark.anyio
    async def test_get_headers_refreshes_token(self, graph_client, mock_oauth):
        """Should call get_valid_token which handles refresh."""
        await graph_client._get_headers()

        mock_oauth.get_valid_token.assert_called_once()


# =============================================================================
# GET Request Tests
# =============================================================================


class TestGetRequests:
    """Tests for GET requests."""

    @pytest.mark.anyio
    async def test_get_success(self, graph_client, mock_oauth):
        """Should return response data on success."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"displayName": "Test User"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            result = await graph_client.get("/me")

        assert result == {"displayName": "Test User"}

    @pytest.mark.anyio
    async def test_get_with_params(self, graph_client, mock_oauth):
        """Should pass query parameters."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"value": []}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            await graph_client.get("/me/messages", params={"$top": 10})

            call_args = mock_client.request.call_args
            assert call_args.kwargs["params"] == {"$top": 10}


# =============================================================================
# POST Request Tests
# =============================================================================


class TestPostRequests:
    """Tests for POST requests."""

    @pytest.mark.anyio
    async def test_post_success(self, graph_client, mock_oauth):
        """Should send POST with JSON body."""
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": "new-id"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            result = await graph_client.post(
                "/me/events",
                json={"subject": "Meeting"},
            )

        assert result == {"id": "new-id"}


# =============================================================================
# PATCH Request Tests
# =============================================================================


class TestPatchRequests:
    """Tests for PATCH requests."""

    @pytest.mark.anyio
    async def test_patch_success(self, graph_client, mock_oauth):
        """Should send PATCH with JSON body."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"id": "updated-id"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            result = await graph_client.patch(
                "/me/events/123",
                json={"subject": "Updated Meeting"},
            )

        assert result == {"id": "updated-id"}


# =============================================================================
# DELETE Request Tests
# =============================================================================


class TestDeleteRequests:
    """Tests for DELETE requests."""

    @pytest.mark.anyio
    async def test_delete_success_no_content(self, graph_client, mock_oauth):
        """Should handle 204 No Content response."""
        mock_response = MagicMock()
        mock_response.status_code = 204

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            result = await graph_client.delete("/me/events/123")

        assert result is None


# =============================================================================
# Error Handling Tests
# =============================================================================


class TestErrorHandling:
    """Tests for error handling."""

    @pytest.mark.anyio
    async def test_rate_limit_error(self, graph_client, mock_oauth):
        """Should raise RateLimitError on 429."""
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.content = b'{"error": {"message": "Too many requests"}}'
        mock_response.json.return_value = {"error": {"message": "Too many requests"}}
        mock_response.headers = {"Retry-After": "30"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(RateLimitError) as exc_info:
                await graph_client.get("/me")

            assert exc_info.value.retry_after == 30

    @pytest.mark.anyio
    async def test_not_found_error(self, graph_client, mock_oauth):
        """Should raise ResourceNotFoundError on 404."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.content = b'{"error": {"message": "Not found"}}'
        mock_response.json.return_value = {"error": {"message": "Not found"}}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(ResourceNotFoundError):
                await graph_client.get("/me/messages/invalid")

    @pytest.mark.anyio
    async def test_permission_denied_error(self, graph_client, mock_oauth):
        """Should raise PermissionDeniedError on 403."""
        mock_response = MagicMock()
        mock_response.status_code = 403
        mock_response.content = b'{"error": {"message": "Access denied"}}'
        mock_response.json.return_value = {"error": {"message": "Access denied"}}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(PermissionDeniedError):
                await graph_client.get("/me/calendar")

    @pytest.mark.anyio
    async def test_generic_error(self, graph_client, mock_oauth):
        """Should raise GraphAPIError on other errors."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.content = (
            b'{"error": {"message": "Server error", "code": "InternalError"}}'
        )
        mock_response.json.return_value = {
            "error": {"message": "Server error", "code": "InternalError"}
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(GraphAPIError) as exc_info:
                await graph_client.get("/me")

            assert exc_info.value.status_code == 500


# =============================================================================
# Retry Tests
# =============================================================================


class TestRetryLogic:
    """Tests for retry logic."""

    @pytest.mark.anyio
    async def test_retry_on_rate_limit(self, graph_client, mock_oauth):
        """Should retry after rate limit with backoff."""
        rate_limit_response = MagicMock()
        rate_limit_response.status_code = 429
        rate_limit_response.content = b'{"error": {"message": "Rate limited"}}'
        rate_limit_response.json.return_value = {"error": {"message": "Rate limited"}}
        rate_limit_response.headers = {"Retry-After": "1"}

        success_response = MagicMock()
        success_response.status_code = 200
        success_response.json.return_value = {"displayName": "Test"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.side_effect = [rate_limit_response, success_response]
            mock_client_class.return_value = mock_client

            with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
                result = await graph_client.get("/me")

            assert result == {"displayName": "Test"}
            mock_sleep.assert_called_once_with(1)


# =============================================================================
# Pagination Tests
# =============================================================================


class TestPagination:
    """Tests for pagination."""

    @pytest.mark.anyio
    async def test_paginate_single_page(self, graph_client, mock_oauth):
        """Should yield items from single page."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "value": [{"id": "1"}, {"id": "2"}],
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            items = []
            async for item in graph_client.paginate("/me/messages"):
                items.append(item)

        assert len(items) == 2
        assert items[0]["id"] == "1"

    @pytest.mark.anyio
    async def test_paginate_multiple_pages(self, graph_client, mock_oauth):
        """Should follow nextLink for multiple pages."""
        page1_response = MagicMock()
        page1_response.status_code = 200
        page1_response.json.return_value = {
            "value": [{"id": "1"}],
            "@odata.nextLink": f"{GRAPH_BASE_URL}/me/messages?$skip=1",
        }

        page2_response = MagicMock()
        page2_response.status_code = 200
        page2_response.json.return_value = {
            "value": [{"id": "2"}],
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = page1_response
            mock_client.get.return_value = page2_response
            mock_client_class.return_value = mock_client

            items = []
            async for item in graph_client.paginate("/me/messages"):
                items.append(item)

        assert len(items) == 2

    @pytest.mark.anyio
    async def test_paginate_max_pages(self, graph_client, mock_oauth):
        """Should respect max_pages limit."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "value": [{"id": "1"}],
            "@odata.nextLink": f"{GRAPH_BASE_URL}/me/messages?$skip=1",
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            items = []
            async for item in graph_client.paginate("/me/messages", max_pages=1):
                items.append(item)

        assert len(items) == 1


# =============================================================================
# Batch Request Tests
# =============================================================================


class TestBatchRequests:
    """Tests for batch requests."""

    @pytest.mark.anyio
    async def test_batch_success(self, graph_client, mock_oauth):
        """Should execute batch request."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "responses": [
                {"id": "1", "status": 200, "body": {"displayName": "User"}},
                {"id": "2", "status": 200, "body": {"value": []}},
            ]
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            responses = await graph_client.batch(
                [
                    {"id": "1", "method": "GET", "url": "/me"},
                    {"id": "2", "method": "GET", "url": "/me/calendar"},
                ]
            )

        assert len(responses) == 2
        assert responses[0]["status"] == 200


# =============================================================================
# Context Manager Tests
# =============================================================================


class TestContextManager:
    """Tests for async context manager."""

    @pytest.mark.anyio
    async def test_context_manager(self, mock_oauth, sample_user_id):
        """Should manage HTTP client lifecycle."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"displayName": "Test"}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_http_client = AsyncMock()
            mock_http_client.request.return_value = mock_response
            mock_http_client.aclose = AsyncMock()
            mock_client_class.return_value = mock_http_client

            async with GraphClient(mock_oauth, sample_user_id) as client:
                result = await client.get("/me")

            assert result == {"displayName": "Test"}
            mock_http_client.aclose.assert_called_once()


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunction:
    """Tests for get_graph_client factory."""

    @pytest.mark.anyio
    async def test_get_graph_client(self):
        """Should create configured GraphClient."""
        mock_redis = AsyncMock()
        user_id = uuid4()

        with patch(
            "apps.api.integrations.microsoft.graph_client.MicrosoftOAuth"
        ) as mock_oauth_class:
            mock_oauth = AsyncMock()
            mock_oauth_class.return_value = mock_oauth

            client = await get_graph_client(mock_redis, user_id)

        assert isinstance(client, GraphClient)
        assert client._user_id == user_id


# =============================================================================
# FIX-4: Retry-After Header Parsing Tests
# =============================================================================


class TestParseRetryAfter:
    """Tests for Retry-After header parsing (FIX-4)."""

    def test_parse_retry_after_integer(self):
        """Should parse integer seconds."""
        assert _parse_retry_after("60") == 60
        assert _parse_retry_after("120") == 120
        assert _parse_retry_after("1") == 1
        assert _parse_retry_after("0") == 0

    def test_parse_retry_after_http_date(self):
        """Should parse HTTP-date format."""
        from datetime import UTC, datetime, timedelta
        from email.utils import format_datetime

        # Create a future datetime
        future = datetime.now(UTC) + timedelta(seconds=120)
        http_date = format_datetime(future, usegmt=True)

        result = _parse_retry_after(http_date)

        # Should be approximately 120 seconds (allow for test execution time)
        assert result is not None
        assert 115 <= result <= 125

    def test_parse_retry_after_past_http_date(self):
        """Should return 0 for past HTTP-date."""
        from datetime import UTC, datetime, timedelta
        from email.utils import format_datetime

        # Create a past datetime
        past = datetime.now(UTC) - timedelta(seconds=60)
        http_date = format_datetime(past, usegmt=True)

        result = _parse_retry_after(http_date)

        # Should return 0 for past dates
        assert result == 0

    def test_parse_retry_after_none(self):
        """Should return None for None input."""
        assert _parse_retry_after(None) is None

    def test_parse_retry_after_empty_string(self):
        """Should return None for empty string."""
        assert _parse_retry_after("") is None

    def test_parse_retry_after_invalid_string(self):
        """Should return None for invalid strings."""
        assert _parse_retry_after("not-a-number") is None
        assert _parse_retry_after("abc123") is None
        assert _parse_retry_after("invalid date format") is None


# =============================================================================
# FIX-5: Non-JSON Error Response Tests
# =============================================================================


class TestNonJsonErrorHandling:
    """Tests for non-JSON error response handling (FIX-5)."""

    @pytest.mark.anyio
    async def test_handle_html_error_response(self, graph_client, mock_oauth):
        """Should handle HTML error response gracefully."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.content = b"<html><body>Internal Server Error</body></html>"
        mock_response.json.side_effect = ValueError("No JSON")

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(GraphAPIError) as exc_info:
                await graph_client.get("/me")

            # Should use fallback message
            assert "HTTP 500" in str(exc_info.value)

    @pytest.mark.anyio
    async def test_handle_empty_error_response(self, graph_client, mock_oauth):
        """Should handle empty error response gracefully."""
        mock_response = MagicMock()
        mock_response.status_code = 502
        mock_response.content = b""
        mock_response.json.return_value = {}

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(GraphAPIError) as exc_info:
                await graph_client.get("/me")

            # Should use fallback message
            assert "HTTP 502" in str(exc_info.value)

    @pytest.mark.anyio
    async def test_handle_rate_limit_with_http_date(self, graph_client, mock_oauth):
        """Should handle 429 with HTTP-date Retry-After.

        Note: This test validates the _parse_retry_after function handles HTTP-date
        format correctly. Due to retry logic, we test the parsing directly.
        """

        # Test that HTTP-date is parsed correctly by the _parse_retry_after function
        # (Tested separately in TestParseRetryAfter)

        # For the rate limit error test, use integer format to avoid timing issues
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.content = b'{"error": {"message": "Rate limited"}}'
        mock_response.json.return_value = {"error": {"message": "Rate limited"}}
        mock_response.headers = {"Retry-After": "30"}  # Use integer for reliability

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.request.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(RateLimitError) as exc_info:
                await graph_client.get("/me")

            # Should parse Retry-After header
            assert exc_info.value.retry_after == 30
