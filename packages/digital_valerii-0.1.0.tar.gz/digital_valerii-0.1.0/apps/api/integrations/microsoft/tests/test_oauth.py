"""Tests for Microsoft OAuth 2.0 implementation."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.exceptions import (
    InvalidStateError,
    MicrosoftAuthError,
    TokenRefreshError,
)
from apps.api.integrations.microsoft.models import (
    MicrosoftToken,
    MicrosoftUser,
    OAuthState,
)
from apps.api.integrations.microsoft.oauth import (
    MicrosoftOAuth,
    _decrypt_token,
    _encrypt_token,
    _validate_redirect_uri,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_redis() -> AsyncMock:
    """Create mock Redis service."""
    redis = AsyncMock()
    redis.cache_set = AsyncMock()
    redis.cache_get = AsyncMock(return_value=None)
    redis.cache_delete = AsyncMock(return_value=1)
    return redis


@pytest.fixture
def oauth_client(mock_redis: AsyncMock) -> MicrosoftOAuth:
    """Create OAuth client with mock Redis."""
    with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
        mock_settings.microsoft_client_id = "test-client-id"
        mock_settings.microsoft_client_secret = "test-client-secret"
        mock_settings.microsoft_tenant_id = "test-tenant"
        mock_settings.microsoft_redirect_uri = "http://localhost:8000/callback"
        mock_settings.microsoft_scopes = ["openid", "profile", "email"]
        return MicrosoftOAuth(mock_redis)


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def sample_token_response() -> dict:
    """Sample token response from Microsoft."""
    return {
        "access_token": "test-access-token",
        "token_type": "Bearer",
        "expires_in": 3600,
        "scope": "openid profile email",
        "refresh_token": "test-refresh-token",
    }


@pytest.fixture
def sample_user_info() -> dict:
    """Sample user info from Graph API."""
    return {
        "id": "user-123",
        "displayName": "Test User",
        "mail": "test@example.com",
        "userPrincipalName": "test@example.onmicrosoft.com",
        "jobTitle": "Developer",
        "officeLocation": "Building 1",
    }


# =============================================================================
# PKCE Tests
# =============================================================================


class TestPKCE:
    """Tests for PKCE code generation."""

    def test_generate_code_verifier_length(self, oauth_client: MicrosoftOAuth):
        """Code verifier should be between 43-128 characters."""
        verifier = oauth_client._generate_code_verifier()
        assert len(verifier) >= 43
        assert len(verifier) <= 128

    def test_generate_code_verifier_uniqueness(self, oauth_client: MicrosoftOAuth):
        """Each verifier should be unique."""
        verifiers = {oauth_client._generate_code_verifier() for _ in range(100)}
        assert len(verifiers) == 100

    def test_generate_code_challenge(self, oauth_client: MicrosoftOAuth):
        """Code challenge should be base64url-encoded SHA256."""
        verifier = "test-verifier-string"
        challenge = oauth_client._generate_code_challenge(verifier)

        # Should be base64url encoded (no padding)
        assert "=" not in challenge
        assert "+" not in challenge
        assert "/" not in challenge
        assert len(challenge) == 43  # SHA256 hash is 32 bytes = 43 base64 chars

    def test_generate_state_length(self, oauth_client: MicrosoftOAuth):
        """State should be 64 hex characters."""
        state = oauth_client._generate_state()
        assert len(state) == 64
        assert all(c in "0123456789abcdef" for c in state)


# =============================================================================
# Authorization URL Tests
# =============================================================================


class TestAuthorizeUrl:
    """Tests for authorization URL generation."""

    @pytest.mark.anyio
    async def test_get_authorize_url_success(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should generate valid authorization URL."""
        url, state = await oauth_client.get_authorize_url(sample_user_id)

        # Verify URL structure
        assert (
            "https://login.microsoftonline.com/test-tenant/oauth2/v2.0/authorize" in url
        )
        assert "client_id=test-client-id" in url
        assert "response_type=code" in url
        assert "code_challenge=" in url
        assert "code_challenge_method=S256" in url
        assert f"state={state}" in url

        # Verify state was stored
        mock_redis.cache_set.assert_called_once()

    @pytest.mark.anyio
    async def test_get_authorize_url_stores_state(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should store OAuth state in Redis."""
        _, state = await oauth_client.get_authorize_url(sample_user_id)

        call_args = mock_redis.cache_set.call_args
        key = call_args[0][0]
        data = call_args[0][1]

        assert state in key
        assert data["user_id"] == str(sample_user_id)
        assert "code_verifier" in data
        assert data["state"] == state

    @pytest.mark.anyio
    async def test_get_authorize_url_with_redirect(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should store custom redirect URI in state (if valid)."""
        # FIX-1: External URLs are now rejected - use an allowed host
        custom_redirect = "https://digitalvalerii.com/callback"
        _, _ = await oauth_client.get_authorize_url(
            sample_user_id, redirect_uri_after=custom_redirect
        )

        call_args = mock_redis.cache_set.call_args
        data = call_args[0][1]
        assert data["redirect_uri"] == custom_redirect

    @pytest.mark.anyio
    async def test_get_authorize_url_with_invalid_redirect(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should reject invalid redirect URIs (FIX-1)."""
        # External URLs not in allowlist should be rejected
        invalid_redirect = "http://myapp.com/callback"
        _, _ = await oauth_client.get_authorize_url(
            sample_user_id, redirect_uri_after=invalid_redirect
        )

        call_args = mock_redis.cache_set.call_args
        data = call_args[0][1]
        # Invalid redirect should be set to None
        assert data["redirect_uri"] is None

    @pytest.mark.anyio
    async def test_get_authorize_url_missing_client_id(
        self, mock_redis: AsyncMock, sample_user_id
    ):
        """Should raise error when client ID is not configured."""
        with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
            mock_settings.microsoft_client_id = ""
            mock_settings.microsoft_client_secret = "secret"
            mock_settings.microsoft_tenant_id = "tenant"
            mock_settings.microsoft_redirect_uri = "http://localhost"
            mock_settings.microsoft_scopes = ["openid"]

            oauth = MicrosoftOAuth(mock_redis)

            with pytest.raises(MicrosoftAuthError, match="client ID not configured"):
                await oauth.get_authorize_url(sample_user_id)


# =============================================================================
# Callback Handling Tests
# =============================================================================


class TestCallback:
    """Tests for OAuth callback handling."""

    @pytest.mark.anyio
    async def test_handle_callback_invalid_state(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock
    ):
        """Should raise error for invalid state."""
        mock_redis.cache_get.return_value = None

        with pytest.raises(InvalidStateError):
            await oauth_client.handle_callback("code", "invalid-state")

    @pytest.mark.anyio
    async def test_handle_callback_success(
        self,
        oauth_client: MicrosoftOAuth,
        mock_redis: AsyncMock,
        sample_user_id,
        sample_token_response,
        sample_user_info,
    ):
        """Should successfully exchange code for tokens."""
        # Setup mock state
        mock_redis.cache_get.return_value = {
            "state": "valid-state",
            "code_verifier": "test-verifier",
            "user_id": str(sample_user_id),
            "redirect_uri": None,
            "created_at": datetime.now(UTC).isoformat(),
        }

        # Mock HTTP responses
        mock_token_response = MagicMock()
        mock_token_response.status_code = 200
        mock_token_response.json.return_value = sample_token_response

        mock_user_response = MagicMock()
        mock_user_response.status_code = 200
        mock_user_response.json.return_value = sample_user_info

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.post.return_value = mock_token_response
            mock_client.get.return_value = mock_user_response
            mock_client_class.return_value = mock_client

            tokens, user, redirect = await oauth_client.handle_callback(
                "auth-code", "valid-state"
            )

        assert tokens.access_token == "test-access-token"
        assert tokens.refresh_token == "test-refresh-token"
        assert user.mail == "test@example.com"
        assert redirect is None

        # State should be deleted after use
        mock_redis.cache_delete.assert_called()

    @pytest.mark.anyio
    async def test_handle_callback_token_exchange_failure(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should raise error when token exchange fails."""
        mock_redis.cache_get.return_value = {
            "state": "valid-state",
            "code_verifier": "test-verifier",
            "user_id": str(sample_user_id),
            "redirect_uri": None,
            "created_at": datetime.now(UTC).isoformat(),
        }

        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "error": "invalid_grant",
            "error_description": "Code has expired",
        }

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.post.return_value = mock_response
            mock_client_class.return_value = mock_client

            with pytest.raises(MicrosoftAuthError, match="Token exchange failed"):
                await oauth_client.handle_callback("auth-code", "valid-state")


# =============================================================================
# Token Refresh Tests
# =============================================================================


class TestTokenRefresh:
    """Tests for token refresh functionality."""

    @pytest.mark.anyio
    async def test_refresh_tokens_no_existing_tokens(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should raise error when no tokens exist."""
        mock_redis.cache_get.return_value = None

        with pytest.raises(TokenRefreshError, match="No tokens found"):
            await oauth_client.refresh_tokens(sample_user_id)

    @pytest.mark.anyio
    async def test_refresh_tokens_no_refresh_token(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should raise error when no refresh token available."""
        mock_redis.cache_get.return_value = {
            "user_id": str(sample_user_id),
            "access_token": "old-access",
            "refresh_token": None,
            "token_type": "Bearer",
            "expires_at": datetime.now(UTC).isoformat(),
            "scope": "openid",
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
        }

        with pytest.raises(TokenRefreshError, match="No refresh token"):
            await oauth_client.refresh_tokens(sample_user_id)

    @pytest.mark.anyio
    async def test_refresh_tokens_success(
        self,
        oauth_client: MicrosoftOAuth,
        mock_redis: AsyncMock,
        sample_user_id,
        sample_token_response,
    ):
        """Should successfully refresh tokens."""
        mock_redis.cache_get.return_value = {
            "user_id": str(sample_user_id),
            "access_token": "old-access",
            "refresh_token": "old-refresh",
            "token_type": "Bearer",
            "expires_at": datetime.now(UTC).isoformat(),
            "scope": "openid",
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
        }

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = sample_token_response

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_client = AsyncMock()
            mock_client.__aenter__.return_value = mock_client
            mock_client.__aexit__.return_value = None
            mock_client.post.return_value = mock_response
            mock_client_class.return_value = mock_client

            new_tokens = await oauth_client.refresh_tokens(sample_user_id)

        assert new_tokens.access_token == "test-access-token"
        assert new_tokens.refresh_token == "test-refresh-token"
        mock_redis.cache_set.assert_called()  # New tokens stored


# =============================================================================
# Token Storage Tests
# =============================================================================


class TestTokenStorage:
    """Tests for token storage operations."""

    @pytest.mark.anyio
    async def test_get_tokens_not_found(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should return None when no tokens stored."""
        mock_redis.cache_get.return_value = None
        tokens = await oauth_client.get_tokens(sample_user_id)
        assert tokens is None

    @pytest.mark.anyio
    async def test_get_tokens_success(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should return stored tokens."""
        mock_redis.cache_get.return_value = {
            "user_id": str(sample_user_id),
            "access_token": "stored-access",
            "refresh_token": "stored-refresh",
            "token_type": "Bearer",
            "expires_at": (datetime.now(UTC) + timedelta(hours=1)).isoformat(),
            "scope": "openid profile",
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
        }

        tokens = await oauth_client.get_tokens(sample_user_id)

        assert tokens is not None
        assert tokens.access_token == "stored-access"
        assert tokens.refresh_token == "stored-refresh"

    @pytest.mark.anyio
    async def test_delete_tokens_success(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should delete tokens successfully."""
        mock_redis.cache_delete.return_value = 1

        result = await oauth_client.delete_tokens(sample_user_id)

        assert result is True
        mock_redis.cache_delete.assert_called_once()

    @pytest.mark.anyio
    async def test_delete_tokens_not_found(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should return False when no tokens to delete."""
        mock_redis.cache_delete.return_value = 0

        result = await oauth_client.delete_tokens(sample_user_id)

        assert result is False


# =============================================================================
# Valid Token Tests
# =============================================================================


class TestGetValidToken:
    """Tests for get_valid_token functionality."""

    @pytest.mark.anyio
    async def test_get_valid_token_not_expired(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should return existing token if not expired."""
        future_expiry = (datetime.now(UTC) + timedelta(hours=1)).isoformat()
        mock_redis.cache_get.return_value = {
            "user_id": str(sample_user_id),
            "access_token": "valid-access",
            "refresh_token": "refresh",
            "token_type": "Bearer",
            "expires_at": future_expiry,
            "scope": "openid",
            "created_at": datetime.now(UTC).isoformat(),
            "updated_at": datetime.now(UTC).isoformat(),
        }

        tokens = await oauth_client.get_valid_token(sample_user_id)

        assert tokens.access_token == "valid-access"

    @pytest.mark.anyio
    async def test_get_valid_token_no_tokens(
        self, oauth_client: MicrosoftOAuth, mock_redis: AsyncMock, sample_user_id
    ):
        """Should raise error when no tokens exist."""
        mock_redis.cache_get.return_value = None

        with pytest.raises(TokenRefreshError, match="No Microsoft tokens found"):
            await oauth_client.get_valid_token(sample_user_id)


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_microsoft_token_is_expired_true(self):
        """Token should be expired when past expiration."""
        token = MicrosoftToken(
            user_id=uuid4(),
            access_token="test",
            refresh_token="refresh",
            token_type="Bearer",
            expires_at=datetime.now(UTC) - timedelta(hours=1),
            scope="openid",
        )
        assert token.is_expired is True

    def test_microsoft_token_is_expired_false(self):
        """Token should not be expired when still valid."""
        token = MicrosoftToken(
            user_id=uuid4(),
            access_token="test",
            refresh_token="refresh",
            token_type="Bearer",
            expires_at=datetime.now(UTC) + timedelta(hours=1),
            scope="openid",
        )
        assert token.is_expired is False

    def test_microsoft_token_scopes_list(self):
        """Should parse scopes into list."""
        token = MicrosoftToken(
            user_id=uuid4(),
            access_token="test",
            refresh_token="refresh",
            token_type="Bearer",
            expires_at=datetime.now(UTC) + timedelta(hours=1),
            scope="openid profile email",
        )
        assert token.scopes == ["openid", "profile", "email"]

    def test_oauth_state_model(self):
        """OAuthState model should serialize correctly."""
        state = OAuthState(
            state="test-state",
            code_verifier="test-verifier",
            user_id=uuid4(),
        )
        data = state.model_dump(mode="json")

        assert data["state"] == "test-state"
        assert data["code_verifier"] == "test-verifier"
        assert "user_id" in data
        assert "created_at" in data

    def test_microsoft_user_model(self):
        """MicrosoftUser model should handle optional fields."""
        user = MicrosoftUser(
            id="user-123",
            display_name="Test User",
            mail="test@example.com",
        )
        assert user.id == "user-123"
        assert user.display_name == "Test User"
        assert user.mail == "test@example.com"
        assert user.job_title is None


# =============================================================================
# FIX-1: Redirect URI Validation Tests
# =============================================================================


class TestValidateRedirectUri:
    """Tests for redirect URI validation (FIX-1)."""

    def test_validate_redirect_uri_relative_path(self):
        """Should accept relative paths (same-origin)."""
        assert _validate_redirect_uri("/dashboard") == "/dashboard"
        assert (
            _validate_redirect_uri("/settings/integrations") == "/settings/integrations"
        )
        assert _validate_redirect_uri("/") == "/"

    def test_validate_redirect_uri_allowed_host_https(self):
        """Should accept allowed hosts with HTTPS."""
        assert _validate_redirect_uri("https://digitalvalerii.com/callback") is not None
        assert (
            _validate_redirect_uri(
                "https://digital-valerii-production.up.railway.app/auth"
            )
            is not None
        )

    def test_validate_redirect_uri_localhost_http(self):
        """Should accept HTTP for localhost."""
        assert _validate_redirect_uri("http://localhost:3000/callback") is not None
        assert _validate_redirect_uri("http://127.0.0.1:8000/auth") is not None

    def test_validate_redirect_uri_rejects_external(self):
        """Should reject external hosts not in allowlist."""
        assert _validate_redirect_uri("https://evil.com") is None
        assert _validate_redirect_uri("https://attacker.com/steal") is None
        assert _validate_redirect_uri("https://example.com/callback") is None

    def test_validate_redirect_uri_rejects_javascript(self):
        """Should reject javascript: scheme."""
        assert _validate_redirect_uri("javascript:alert(1)") is None
        assert _validate_redirect_uri("javascript:document.location='evil.com'") is None

    def test_validate_redirect_uri_rejects_data(self):
        """Should reject data: scheme."""
        assert _validate_redirect_uri("data:text/html,<script>evil()</script>") is None

    def test_validate_redirect_uri_rejects_vbscript(self):
        """Should reject vbscript: scheme."""
        assert _validate_redirect_uri("vbscript:msgbox(1)") is None

    def test_validate_redirect_uri_rejects_http_non_localhost(self):
        """Should reject HTTP for non-localhost hosts."""
        assert _validate_redirect_uri("http://digitalvalerii.com/callback") is None
        assert _validate_redirect_uri("http://evil.com") is None

    def test_validate_redirect_uri_none_input(self):
        """Should return None for None input."""
        assert _validate_redirect_uri(None) is None

    def test_validate_redirect_uri_empty_string(self):
        """Should return None for empty string."""
        assert _validate_redirect_uri("") is None

    def test_validate_redirect_uri_invalid_scheme(self):
        """Should reject unknown schemes."""
        assert _validate_redirect_uri("ftp://example.com") is None
        assert _validate_redirect_uri("file:///etc/passwd") is None


# =============================================================================
# FIX-2: Token Encryption Tests
# =============================================================================


class TestTokenEncryption:
    """Tests for token encryption/decryption (FIX-2)."""

    def test_encrypt_token_without_key_returns_original(self):
        """Should return original when no encryption key configured."""
        with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
            mock_settings.microsoft_token_encryption_key = ""

            token_json = '{"access_token": "secret_token_123"}'
            encrypted = _encrypt_token(token_json)

            assert encrypted == token_json

    def test_decrypt_token_without_key_returns_original(self):
        """Should return original when no encryption key configured."""
        with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
            mock_settings.microsoft_token_encryption_key = ""

            data = '{"access_token": "secret_token_123"}'
            decrypted = _decrypt_token(data)

            assert decrypted == data

    def test_encrypt_decrypt_roundtrip_with_key(self):
        """Should encrypt and decrypt successfully with valid key."""
        from cryptography.fernet import Fernet

        # Generate a valid Fernet key
        key = Fernet.generate_key().decode()

        with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
            mock_settings.microsoft_token_encryption_key = key

            token_json = (
                '{"access_token": "secret_token_123", "refresh_token": "refresh_456"}'
            )

            # Encrypt
            encrypted = _encrypt_token(token_json)
            assert encrypted != token_json  # Should be different

            # Decrypt
            decrypted = _decrypt_token(encrypted)
            assert decrypted == token_json

    def test_decrypt_invalid_data_returns_original(self):
        """Should return original data if decryption fails (migration case)."""
        from cryptography.fernet import Fernet

        key = Fernet.generate_key().decode()

        with patch("apps.api.integrations.microsoft.oauth.settings") as mock_settings:
            mock_settings.microsoft_token_encryption_key = key

            # Try to decrypt unencrypted data (migration scenario)
            original = '{"access_token": "old_unencrypted_token"}'
            result = _decrypt_token(original)

            # Should return original (graceful degradation)
            assert result == original
