"""Tests for Microsoft Calendar API service."""

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.calendar import (
    Attendee,
    Calendar,
    CalendarService,
    CreateEventRequest,
    Event,
    UpdateEventRequest,
    get_calendar_service,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def mock_redis():
    """Create mock Redis service."""
    redis = AsyncMock()
    return redis


@pytest.fixture
def mock_graph_client():
    """Create mock Graph client."""
    client = AsyncMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


@pytest.fixture
def calendar_service(mock_redis, sample_user_id, mock_graph_client):
    """Create calendar service with mock client."""
    service = CalendarService(mock_redis, sample_user_id)
    service._client = mock_graph_client
    return service


@pytest.fixture
def sample_calendar_data():
    """Sample calendar data from Graph API."""
    return {
        "value": [
            {
                "id": "cal-1",
                "name": "Calendar",
                "color": "blue",
                "canEdit": True,
                "isDefaultCalendar": True,
                "owner": {"address": "user@example.com"},
            },
            {
                "id": "cal-2",
                "name": "Work",
                "color": "green",
                "canEdit": True,
                "isDefaultCalendar": False,
                "owner": {"address": "user@example.com"},
            },
        ]
    }


@pytest.fixture
def sample_event_data():
    """Sample event data from Graph API."""
    return {
        "id": "event-123",
        "subject": "Team Meeting",
        "body": {"contentType": "text", "content": "Weekly sync"},
        "start": {"dateTime": "2025-01-15T10:00:00", "timeZone": "UTC"},
        "end": {"dateTime": "2025-01-15T11:00:00", "timeZone": "UTC"},
        "location": {"displayName": "Conference Room A"},
        "isAllDay": False,
        "isCancelled": False,
        "isOnlineMeeting": True,
        "onlineMeeting": {"joinUrl": "https://teams.microsoft.com/meeting/123"},
        "attendees": [
            {
                "emailAddress": {"address": "attendee@example.com", "name": "Attendee"},
                "status": {"response": "accepted"},
                "type": "required",
            }
        ],
        "organizer": {"emailAddress": {"address": "organizer@example.com"}},
        "recurrence": None,
        "webLink": "https://outlook.office.com/calendar/item/123",
    }


# =============================================================================
# Calendar Operations Tests
# =============================================================================


class TestGetCalendars:
    """Tests for get_calendars method."""

    @pytest.mark.anyio
    async def test_get_calendars_success(
        self, calendar_service, mock_graph_client, sample_calendar_data
    ):
        """Should return list of calendars."""
        mock_graph_client.get.return_value = sample_calendar_data

        calendars = await calendar_service.get_calendars()

        assert len(calendars) == 2
        assert calendars[0].id == "cal-1"
        assert calendars[0].name == "Calendar"
        assert calendars[0].is_default is True
        assert calendars[1].id == "cal-2"
        assert calendars[1].name == "Work"

    @pytest.mark.anyio
    async def test_get_default_calendar(self, calendar_service, mock_graph_client):
        """Should return default calendar."""
        mock_graph_client.get.return_value = {
            "id": "default-cal",
            "name": "Calendar",
            "color": "blue",
            "canEdit": True,
            "owner": {"address": "user@example.com"},
        }

        calendar = await calendar_service.get_default_calendar()

        assert calendar.id == "default-cal"
        assert calendar.is_default is True


# =============================================================================
# Event Operations Tests
# =============================================================================


class TestGetEvents:
    """Tests for get_events method."""

    @pytest.mark.anyio
    async def test_get_events_success(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should return list of events."""
        mock_graph_client.get.return_value = {"value": [sample_event_data]}

        events = await calendar_service.get_events(
            start_datetime="2025-01-15T00:00:00",
            end_datetime="2025-01-16T00:00:00",
        )

        assert len(events) == 1
        assert events[0].id == "event-123"
        assert events[0].subject == "Team Meeting"
        assert events[0].location == "Conference Room A"

    @pytest.mark.anyio
    async def test_get_events_with_calendar_id(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should use specific calendar ID."""
        mock_graph_client.get.return_value = {"value": [sample_event_data]}

        await calendar_service.get_events(
            start_datetime="2025-01-15T00:00:00",
            end_datetime="2025-01-16T00:00:00",
            calendar_id="cal-123",
        )

        call_args = mock_graph_client.get.call_args
        assert "/me/calendars/cal-123/calendarView" in call_args[0][0]


class TestGetEvent:
    """Tests for get_event method."""

    @pytest.mark.anyio
    async def test_get_event_success(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should return single event."""
        mock_graph_client.get.return_value = sample_event_data

        event = await calendar_service.get_event("event-123")

        assert event.id == "event-123"
        assert event.subject == "Team Meeting"
        assert event.is_online_meeting is True
        assert event.online_meeting_url == "https://teams.microsoft.com/meeting/123"


class TestCreateEvent:
    """Tests for create_event method."""

    @pytest.mark.anyio
    async def test_create_event_success(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should create event and return it."""
        mock_graph_client.post.return_value = sample_event_data

        request = CreateEventRequest(
            subject="Team Meeting",
            start_datetime="2025-01-15T10:00:00",
            end_datetime="2025-01-15T11:00:00",
            location="Conference Room A",
        )

        event = await calendar_service.create_event(request)

        assert event.id == "event-123"
        assert event.subject == "Team Meeting"
        mock_graph_client.post.assert_called_once()

    @pytest.mark.anyio
    async def test_create_event_with_attendees(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should include attendees in request."""
        mock_graph_client.post.return_value = sample_event_data

        request = CreateEventRequest(
            subject="Team Meeting",
            start_datetime="2025-01-15T10:00:00",
            end_datetime="2025-01-15T11:00:00",
            attendee_emails=["attendee1@example.com", "attendee2@example.com"],
        )

        await calendar_service.create_event(request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert len(json_body["attendees"]) == 2

    @pytest.mark.anyio
    async def test_create_event_with_online_meeting(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should request Teams meeting creation."""
        mock_graph_client.post.return_value = sample_event_data

        request = CreateEventRequest(
            subject="Online Meeting",
            start_datetime="2025-01-15T10:00:00",
            end_datetime="2025-01-15T11:00:00",
            is_online_meeting=True,
        )

        await calendar_service.create_event(request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert json_body["isOnlineMeeting"] is True
        assert json_body["onlineMeetingProvider"] == "teamsForBusiness"

    @pytest.mark.anyio
    async def test_create_event_with_recurrence(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should include recurrence pattern."""
        mock_graph_client.post.return_value = sample_event_data

        recurrence = {
            "pattern": {"type": "weekly", "interval": 1, "daysOfWeek": ["monday"]},
            "range": {"type": "noEnd", "startDate": "2025-01-15"},
        }

        request = CreateEventRequest(
            subject="Weekly Sync",
            start_datetime="2025-01-15T10:00:00",
            end_datetime="2025-01-15T11:00:00",
            recurrence=recurrence,
        )

        await calendar_service.create_event(request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert json_body["recurrence"] == recurrence


class TestUpdateEvent:
    """Tests for update_event method."""

    @pytest.mark.anyio
    async def test_update_event_success(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should update event and return it."""
        mock_graph_client.patch.return_value = sample_event_data

        request = UpdateEventRequest(
            subject="Updated Meeting",
            location="New Room",
        )

        event = await calendar_service.update_event("event-123", request)

        assert event.id == "event-123"
        mock_graph_client.patch.assert_called_once()

    @pytest.mark.anyio
    async def test_update_event_partial(
        self, calendar_service, mock_graph_client, sample_event_data
    ):
        """Should only include non-None fields."""
        mock_graph_client.patch.return_value = sample_event_data

        request = UpdateEventRequest(subject="New Subject")

        await calendar_service.update_event("event-123", request)

        call_args = mock_graph_client.patch.call_args
        json_body = call_args.kwargs["json"]
        assert "subject" in json_body
        assert "location" not in json_body


class TestDeleteEvent:
    """Tests for delete_event method."""

    @pytest.mark.anyio
    async def test_delete_event_success(self, calendar_service, mock_graph_client):
        """Should delete event and return True."""
        mock_graph_client.delete.return_value = None

        result = await calendar_service.delete_event("event-123")

        assert result is True
        mock_graph_client.delete.assert_called_once()


# =============================================================================
# Availability Tests
# =============================================================================


class TestGetFreeBusy:
    """Tests for get_free_busy method."""

    @pytest.mark.anyio
    async def test_get_free_busy_success(self, calendar_service, mock_graph_client):
        """Should return free/busy slots."""
        mock_graph_client.post.return_value = {
            "value": [
                {
                    "scheduleId": "user@example.com",
                    "scheduleItems": [
                        {
                            "start": {"dateTime": "2025-01-15T10:00:00"},
                            "end": {"dateTime": "2025-01-15T11:00:00"},
                            "status": "busy",
                        }
                    ],
                }
            ]
        }

        result = await calendar_service.get_free_busy(
            emails=["user@example.com"],
            start_datetime="2025-01-15T00:00:00",
            end_datetime="2025-01-16T00:00:00",
        )

        assert "user@example.com" in result
        assert len(result["user@example.com"]) == 1
        assert result["user@example.com"][0].status == "busy"


class TestFindMeetingTimes:
    """Tests for find_meeting_times method."""

    @pytest.mark.anyio
    async def test_find_meeting_times_success(
        self, calendar_service, mock_graph_client
    ):
        """Should return meeting time suggestions."""
        mock_graph_client.post.return_value = {
            "meetingTimeSuggestions": [
                {
                    "meetingTimeSlot": {
                        "start": {"dateTime": "2025-01-15T14:00:00"},
                        "end": {"dateTime": "2025-01-15T15:00:00"},
                    },
                    "confidence": 100,
                }
            ]
        }

        suggestions = await calendar_service.find_meeting_times(
            attendee_emails=["attendee@example.com"],
            start_datetime="2025-01-15T09:00:00",
            end_datetime="2025-01-15T17:00:00",
            duration_minutes=60,
        )

        assert len(suggestions) == 1
        assert suggestions[0]["confidence"] == 100


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_calendar_model(self):
        """Calendar model should serialize correctly."""
        cal = Calendar(
            id="cal-1",
            name="Test Calendar",
            color="blue",
            can_edit=True,
            is_default=True,
            owner_email="user@example.com",
        )
        assert cal.id == "cal-1"
        assert cal.name == "Test Calendar"

    def test_event_model(self):
        """Event model should serialize correctly."""
        event = Event(
            subject="Test Event",
            start={"datetime": "2025-01-15T10:00:00", "timezone": "UTC"},
            end={"datetime": "2025-01-15T11:00:00", "timezone": "UTC"},
        )
        assert event.subject == "Test Event"
        assert event.is_all_day is False

    def test_create_event_request(self):
        """CreateEventRequest should validate correctly."""
        request = CreateEventRequest(
            subject="Meeting",
            start_datetime="2025-01-15T10:00:00",
            end_datetime="2025-01-15T11:00:00",
        )
        assert request.subject == "Meeting"
        assert request.is_online_meeting is False

    def test_attendee_model(self):
        """Attendee model should have correct defaults."""
        attendee = Attendee(email="user@example.com")
        assert attendee.email == "user@example.com"
        assert attendee.response_status == "none"
        assert attendee.is_required is True


# =============================================================================
# Context Manager Tests
# =============================================================================


class TestContextManager:
    """Tests for async context manager."""

    @pytest.mark.anyio
    async def test_context_manager_lifecycle(self, mock_redis, sample_user_id):
        """Should manage client lifecycle."""
        from unittest.mock import patch

        mock_client = AsyncMock()
        mock_client.get.return_value = {"value": []}

        with patch(
            "apps.api.integrations.microsoft.calendar.get_graph_client",
            return_value=mock_client,
        ):
            async with CalendarService(mock_redis, sample_user_id) as service:
                await service.get_calendars()

            mock_client.__aenter__.assert_called_once()
            mock_client.__aexit__.assert_called_once()

    def test_client_property_without_context(self, mock_redis, sample_user_id):
        """Should raise error when accessing client outside context."""
        service = CalendarService(mock_redis, sample_user_id)

        with pytest.raises(RuntimeError, match="must be used as async context manager"):
            _ = service.client


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunction:
    """Tests for get_calendar_service factory."""

    def test_get_calendar_service(self, mock_redis, sample_user_id):
        """Should create CalendarService instance."""
        service = get_calendar_service(mock_redis, sample_user_id)

        assert isinstance(service, CalendarService)
        assert service._user_id == sample_user_id
