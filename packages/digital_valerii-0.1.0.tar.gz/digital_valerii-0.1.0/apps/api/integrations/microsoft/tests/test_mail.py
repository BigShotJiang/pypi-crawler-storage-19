"""Tests for Microsoft Mail API service."""

from unittest.mock import AsyncMock
from uuid import uuid4

import pytest

from apps.api.integrations.microsoft.mail import (
    Attachment,
    EmailAddress,
    ForwardMessageRequest,
    MailFolder,
    MailService,
    Message,
    ReplyMessageRequest,
    SendMessageRequest,
    get_mail_service,
)

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def sample_user_id():
    """Generate sample user ID."""
    return uuid4()


@pytest.fixture
def mock_redis():
    """Create mock Redis service."""
    return AsyncMock()


@pytest.fixture
def mock_graph_client():
    """Create mock Graph client."""
    client = AsyncMock()
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


@pytest.fixture
def mail_service(mock_redis, sample_user_id, mock_graph_client):
    """Create mail service with mock client."""
    service = MailService(mock_redis, sample_user_id)
    service._client = mock_graph_client
    return service


@pytest.fixture
def sample_folder_data():
    """Sample folder data from Graph API."""
    return {
        "value": [
            {
                "id": "folder-1",
                "displayName": "Inbox",
                "parentFolderId": None,
                "childFolderCount": 2,
                "unreadItemCount": 5,
                "totalItemCount": 100,
            },
            {
                "id": "folder-2",
                "displayName": "Sent Items",
                "parentFolderId": None,
                "childFolderCount": 0,
                "unreadItemCount": 0,
                "totalItemCount": 50,
            },
        ]
    }


@pytest.fixture
def sample_message_data():
    """Sample message data from Graph API."""
    return {
        "id": "msg-123",
        "subject": "Test Email",
        "bodyPreview": "This is a test email...",
        "body": {"contentType": "text", "content": "This is a test email body."},
        "from": {"emailAddress": {"address": "sender@example.com", "name": "Sender"}},
        "toRecipients": [
            {"emailAddress": {"address": "recipient@example.com", "name": "Recipient"}}
        ],
        "ccRecipients": [],
        "bccRecipients": [],
        "receivedDateTime": "2025-01-15T10:00:00Z",
        "sentDateTime": "2025-01-15T09:59:00Z",
        "hasAttachments": False,
        "importance": "normal",
        "isRead": False,
        "isDraft": False,
        "conversationId": "conv-456",
        "webLink": "https://outlook.office.com/mail/item/123",
    }


# =============================================================================
# Folder Tests
# =============================================================================


class TestGetFolders:
    """Tests for get_folders method."""

    @pytest.mark.anyio
    async def test_get_folders_success(
        self, mail_service, mock_graph_client, sample_folder_data
    ):
        """Should return list of folders."""
        mock_graph_client.get.return_value = sample_folder_data

        folders = await mail_service.get_folders()

        assert len(folders) == 2
        assert folders[0].id == "folder-1"
        assert folders[0].display_name == "Inbox"
        assert folders[0].unread_item_count == 5

    @pytest.mark.anyio
    async def test_get_folder_by_id(self, mail_service, mock_graph_client):
        """Should return specific folder."""
        mock_graph_client.get.return_value = {
            "id": "inbox",
            "displayName": "Inbox",
            "unreadItemCount": 10,
            "totalItemCount": 100,
        }

        folder = await mail_service.get_folder("inbox")

        assert folder.id == "inbox"
        assert folder.display_name == "Inbox"


# =============================================================================
# Message Operations Tests
# =============================================================================


class TestGetMessages:
    """Tests for get_messages method."""

    @pytest.mark.anyio
    async def test_get_messages_success(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should return list of messages."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        messages = await mail_service.get_messages(folder_id="inbox", top=10)

        assert len(messages) == 1
        assert messages[0].id == "msg-123"
        assert messages[0].subject == "Test Email"

    @pytest.mark.anyio
    async def test_get_messages_with_filter(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should apply filter query."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        await mail_service.get_messages(
            folder_id="inbox",
            filter_query="isRead eq false",
        )

        call_args = mock_graph_client.get.call_args
        assert "$filter" in call_args.kwargs["params"]

    @pytest.mark.anyio
    async def test_get_messages_with_search(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should apply search query."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        await mail_service.get_messages(
            folder_id="inbox",
            search_query="important",
        )

        call_args = mock_graph_client.get.call_args
        assert "$search" in call_args.kwargs["params"]


class TestGetMessage:
    """Tests for get_message method."""

    @pytest.mark.anyio
    async def test_get_message_success(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should return single message with body."""
        mock_graph_client.get.return_value = sample_message_data

        message = await mail_service.get_message("msg-123")

        assert message.id == "msg-123"
        assert message.body_content == "This is a test email body."
        assert message.from_address.address == "sender@example.com"


class TestSearchMessages:
    """Tests for search_messages method."""

    @pytest.mark.anyio
    async def test_search_messages_success(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should search across all folders."""
        mock_graph_client.get.return_value = {"value": [sample_message_data]}

        messages = await mail_service.search_messages("test query")

        assert len(messages) == 1
        call_args = mock_graph_client.get.call_args
        assert "/me/messages" in call_args[0][0]


class TestMarkAsRead:
    """Tests for mark_as_read method."""

    @pytest.mark.anyio
    async def test_mark_as_read(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should update read status."""
        sample_message_data["isRead"] = True
        mock_graph_client.patch.return_value = sample_message_data

        message = await mail_service.mark_as_read("msg-123", is_read=True)

        assert message.is_read is True
        mock_graph_client.patch.assert_called_once()


class TestMoveMessage:
    """Tests for move_message method."""

    @pytest.mark.anyio
    async def test_move_message(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should move message to folder."""
        mock_graph_client.post.return_value = sample_message_data

        message = await mail_service.move_message("msg-123", "archive")

        mock_graph_client.post.assert_called_once()
        call_args = mock_graph_client.post.call_args
        assert "move" in call_args[0][0]


class TestDeleteMessage:
    """Tests for delete_message method."""

    @pytest.mark.anyio
    async def test_delete_message(self, mail_service, mock_graph_client):
        """Should delete message."""
        mock_graph_client.delete.return_value = None

        result = await mail_service.delete_message("msg-123")

        assert result is True
        mock_graph_client.delete.assert_called_once()


# =============================================================================
# Send Operations Tests
# =============================================================================


class TestSendMessage:
    """Tests for send_message method."""

    @pytest.mark.anyio
    async def test_send_message_success(self, mail_service, mock_graph_client):
        """Should send email."""
        mock_graph_client.post.return_value = None

        request = SendMessageRequest(
            to_recipients=["recipient@example.com"],
            subject="Test Subject",
            body="Test body",
        )

        result = await mail_service.send_message(request)

        assert result is True
        mock_graph_client.post.assert_called_once()

    @pytest.mark.anyio
    async def test_send_message_with_attachments(self, mail_service, mock_graph_client):
        """Should include attachments."""
        mock_graph_client.post.return_value = None

        request = SendMessageRequest(
            to_recipients=["recipient@example.com"],
            subject="With Attachment",
            body="See attached",
            attachments=[
                Attachment(
                    name="test.txt",
                    content_type="text/plain",
                    content_bytes="VGVzdCBjb250ZW50",  # Base64 "Test content"
                )
            ],
        )

        await mail_service.send_message(request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert len(json_body["message"]["attachments"]) == 1

    @pytest.mark.anyio
    async def test_send_message_with_cc_bcc(self, mail_service, mock_graph_client):
        """Should include CC and BCC."""
        mock_graph_client.post.return_value = None

        request = SendMessageRequest(
            to_recipients=["to@example.com"],
            cc_recipients=["cc@example.com"],
            bcc_recipients=["bcc@example.com"],
            subject="Test",
            body="Test",
        )

        await mail_service.send_message(request)

        call_args = mock_graph_client.post.call_args
        json_body = call_args.kwargs["json"]
        assert "ccRecipients" in json_body["message"]
        assert "bccRecipients" in json_body["message"]


class TestReplyToMessage:
    """Tests for reply_to_message method."""

    @pytest.mark.anyio
    async def test_reply_success(self, mail_service, mock_graph_client):
        """Should send reply."""
        mock_graph_client.post.return_value = None

        request = ReplyMessageRequest(
            message_id="msg-123",
            comment="Thanks for your email!",
        )

        result = await mail_service.reply_to_message(request)

        assert result is True
        call_args = mock_graph_client.post.call_args
        assert "/reply" in call_args[0][0]
        assert "replyAll" not in call_args[0][0]

    @pytest.mark.anyio
    async def test_reply_all(self, mail_service, mock_graph_client):
        """Should send reply all."""
        mock_graph_client.post.return_value = None

        request = ReplyMessageRequest(
            message_id="msg-123",
            comment="Thanks everyone!",
            reply_all=True,
        )

        await mail_service.reply_to_message(request)

        call_args = mock_graph_client.post.call_args
        assert "/replyAll" in call_args[0][0]


class TestForwardMessage:
    """Tests for forward_message method."""

    @pytest.mark.anyio
    async def test_forward_success(self, mail_service, mock_graph_client):
        """Should forward message."""
        mock_graph_client.post.return_value = None

        request = ForwardMessageRequest(
            message_id="msg-123",
            to_recipients=["forward@example.com"],
            comment="FYI",
        )

        result = await mail_service.forward_message(request)

        assert result is True
        call_args = mock_graph_client.post.call_args
        assert "/forward" in call_args[0][0]


# =============================================================================
# Draft Tests
# =============================================================================


class TestDraftOperations:
    """Tests for draft operations."""

    @pytest.mark.anyio
    async def test_create_draft(
        self, mail_service, mock_graph_client, sample_message_data
    ):
        """Should create draft message."""
        sample_message_data["isDraft"] = True
        mock_graph_client.post.return_value = sample_message_data

        request = SendMessageRequest(
            to_recipients=["recipient@example.com"],
            subject="Draft Subject",
            body="Draft body",
        )

        draft = await mail_service.create_draft(request)

        assert draft.is_draft is True
        call_args = mock_graph_client.post.call_args
        assert call_args[0][0] == "/me/messages"

    @pytest.mark.anyio
    async def test_send_draft(self, mail_service, mock_graph_client):
        """Should send draft."""
        mock_graph_client.post.return_value = None

        result = await mail_service.send_draft("draft-123")

        assert result is True
        call_args = mock_graph_client.post.call_args
        assert "/send" in call_args[0][0]


# =============================================================================
# Attachment Tests
# =============================================================================


class TestAttachmentOperations:
    """Tests for attachment operations."""

    @pytest.mark.anyio
    async def test_get_attachments(self, mail_service, mock_graph_client):
        """Should list attachments."""
        mock_graph_client.get.return_value = {
            "value": [
                {
                    "id": "att-1",
                    "name": "document.pdf",
                    "contentType": "application/pdf",
                    "size": 12345,
                    "isInline": False,
                }
            ]
        }

        attachments = await mail_service.get_attachments("msg-123")

        assert len(attachments) == 1
        assert attachments[0].name == "document.pdf"

    @pytest.mark.anyio
    async def test_get_attachment_with_content(self, mail_service, mock_graph_client):
        """Should get attachment with content."""
        mock_graph_client.get.return_value = {
            "id": "att-1",
            "name": "document.pdf",
            "contentType": "application/pdf",
            "size": 12345,
            "isInline": False,
            "contentBytes": "SGVsbG8gV29ybGQ=",  # Base64 "Hello World"
        }

        attachment = await mail_service.get_attachment("msg-123", "att-1")

        assert attachment.content_bytes == "SGVsbG8gV29ybGQ="


# =============================================================================
# Model Tests
# =============================================================================


class TestModels:
    """Tests for Pydantic models."""

    def test_email_address_model(self):
        """EmailAddress should serialize correctly."""
        addr = EmailAddress(address="test@example.com", name="Test User")
        assert addr.address == "test@example.com"
        assert addr.name == "Test User"

    def test_mail_folder_model(self):
        """MailFolder should have correct defaults."""
        folder = MailFolder(id="folder-1", display_name="Inbox")
        assert folder.id == "folder-1"
        assert folder.unread_item_count == 0

    def test_message_model(self):
        """Message should have correct defaults."""
        msg = Message(subject="Test")
        assert msg.subject == "Test"
        assert msg.is_read is False
        assert msg.has_attachments is False

    def test_attachment_model(self):
        """Attachment should handle optional content."""
        att = Attachment(name="file.txt", content_type="text/plain")
        assert att.name == "file.txt"
        assert att.content_bytes is None


# =============================================================================
# Context Manager Tests
# =============================================================================


class TestContextManager:
    """Tests for async context manager."""

    @pytest.mark.anyio
    async def test_context_manager_lifecycle(self, mock_redis, sample_user_id):
        """Should manage client lifecycle."""
        from unittest.mock import patch

        mock_client = AsyncMock()
        mock_client.get.return_value = {"value": []}

        with patch(
            "apps.api.integrations.microsoft.mail.get_graph_client",
            return_value=mock_client,
        ):
            async with MailService(mock_redis, sample_user_id) as service:
                await service.get_folders()

            mock_client.__aenter__.assert_called_once()
            mock_client.__aexit__.assert_called_once()

    def test_client_property_without_context(self, mock_redis, sample_user_id):
        """Should raise error outside context."""
        service = MailService(mock_redis, sample_user_id)

        with pytest.raises(RuntimeError, match="must be used as async context manager"):
            _ = service.client


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunction:
    """Tests for get_mail_service factory."""

    def test_get_mail_service(self, mock_redis, sample_user_id):
        """Should create MailService instance."""
        service = get_mail_service(mock_redis, sample_user_id)

        assert isinstance(service, MailService)
        assert service._user_id == sample_user_id
