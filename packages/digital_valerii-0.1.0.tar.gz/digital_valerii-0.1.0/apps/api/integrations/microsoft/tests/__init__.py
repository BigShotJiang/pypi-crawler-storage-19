"""Tests for Microsoft Graph API integration."""
