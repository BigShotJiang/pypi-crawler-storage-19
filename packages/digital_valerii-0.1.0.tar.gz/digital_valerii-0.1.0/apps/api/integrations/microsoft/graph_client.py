"""Microsoft Graph API client with rate limiting and retry logic.

Provides a base client for interacting with Microsoft Graph API endpoints
with automatic token refresh, rate limiting, pagination, and error handling.
"""

import asyncio
from collections.abc import AsyncIterator
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from json import JSONDecodeError
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

import httpx
import structlog

from apps.api.integrations.microsoft.exceptions import (
    GraphAPIError,
    PermissionDeniedError,
    RateLimitError,
    ResourceNotFoundError,
)
from apps.api.integrations.microsoft.oauth import MicrosoftOAuth

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)

# Graph API base URL
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

# Default timeout for requests
DEFAULT_TIMEOUT = 30.0

# Retry configuration
MAX_RETRIES = 3
INITIAL_RETRY_DELAY = 1.0  # seconds
MAX_RETRY_DELAY = 30.0  # seconds

# Rate limit tracking window
RATE_LIMIT_WINDOW = 60  # seconds

T = TypeVar("T")


def _parse_retry_after(header: str | None) -> int | None:
    """Parse Retry-After header (integer seconds or HTTP-date).

    FIX-4: RFC 7231 allows both integer seconds and HTTP-date format.

    Args:
        header: Retry-After header value.

    Returns:
        Retry delay in seconds, or None if invalid/missing.
    """
    if not header:
        return None

    # Try integer first (e.g., "60")
    try:
        return int(header)
    except ValueError:
        pass

    # Try HTTP-date format (e.g., "Wed, 21 Oct 2015 07:28:00 GMT")
    try:
        retry_dt = parsedate_to_datetime(header)
        delta = retry_dt - datetime.now(UTC)
        return max(0, int(delta.total_seconds()))
    except (ValueError, TypeError):
        return None


class GraphClient:
    """Microsoft Graph API client.

    Handles authentication, rate limiting, retries, and pagination
    for all Graph API requests.

    Example:
        redis = get_redis()
        oauth = MicrosoftOAuth(redis)
        client = GraphClient(oauth, user_id)

        # Get user profile
        profile = await client.get("/me")

        # List emails with pagination
        async for email in client.paginate("/me/messages", top=50):
            process(email)
    """

    def __init__(
        self,
        oauth: MicrosoftOAuth,
        user_id: UUID,
        *,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        """Initialize Graph API client.

        Args:
            oauth: Microsoft OAuth service for token management.
            user_id: User whose tokens to use.
            timeout: Request timeout in seconds.
        """
        self._oauth = oauth
        self._user_id = user_id
        self._timeout = timeout
        self._http_client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "GraphClient":
        """Enter async context."""
        self._http_client = httpx.AsyncClient(timeout=self._timeout)
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

    # =========================================================================
    # Authentication
    # =========================================================================

    async def _get_headers(self) -> dict[str, str]:
        """Get request headers with valid access token.

        Returns:
            Headers dict with Authorization header.

        Raises:
            TokenRefreshError: If unable to get valid token.
        """
        token = await self._oauth.get_valid_token(self._user_id)
        return {
            "Authorization": f"Bearer {token.access_token}",
            "Content-Type": "application/json",
        }

    # =========================================================================
    # HTTP Methods
    # =========================================================================

    async def get(
        self,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make GET request to Graph API.

        Args:
            endpoint: API endpoint (e.g., "/me", "/me/messages").
            params: Query parameters.

        Returns:
            Response JSON data.

        Raises:
            GraphAPIError: On API errors.
        """
        return await self._request("GET", endpoint, params=params)

    async def post(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make POST request to Graph API.

        Args:
            endpoint: API endpoint.
            json: Request body.
            params: Query parameters.

        Returns:
            Response JSON data.

        Raises:
            GraphAPIError: On API errors.
        """
        return await self._request("POST", endpoint, json=json, params=params)

    async def patch(
        self,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make PATCH request to Graph API.

        Args:
            endpoint: API endpoint.
            json: Request body.
            params: Query parameters.

        Returns:
            Response JSON data.

        Raises:
            GraphAPIError: On API errors.
        """
        return await self._request("PATCH", endpoint, json=json, params=params)

    async def delete(
        self,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Make DELETE request to Graph API.

        Args:
            endpoint: API endpoint.
            params: Query parameters.

        Returns:
            Response JSON data or None for 204 responses.

        Raises:
            GraphAPIError: On API errors.
        """
        return await self._request("DELETE", endpoint, params=params)

    # =========================================================================
    # Request Handling
    # =========================================================================

    async def _request(
        self,
        method: str,
        endpoint: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Make HTTP request with retry and error handling.

        Args:
            method: HTTP method.
            endpoint: API endpoint.
            json: Request body.
            params: Query parameters.

        Returns:
            Response JSON data or None for 204 responses.

        Raises:
            GraphAPIError: On API errors after retries exhausted.
        """
        url = f"{GRAPH_BASE_URL}{endpoint}"

        for attempt in range(MAX_RETRIES):
            try:
                headers = await self._get_headers()

                if self._http_client is None:
                    # Create client for single request
                    async with httpx.AsyncClient(timeout=self._timeout) as client:
                        response = await client.request(
                            method,
                            url,
                            headers=headers,
                            json=json,
                            params=params,
                        )
                else:
                    response = await self._http_client.request(
                        method,
                        url,
                        headers=headers,
                        json=json,
                        params=params,
                    )

                return await self._handle_response(response, endpoint)

            except RateLimitError as e:
                if attempt == MAX_RETRIES - 1:
                    raise

                # Use retry-after or exponential backoff
                delay = e.retry_after or min(
                    INITIAL_RETRY_DELAY * (2**attempt),
                    MAX_RETRY_DELAY,
                )
                await logger.awarning(
                    "Rate limited, retrying",
                    endpoint=endpoint,
                    attempt=attempt + 1,
                    delay=delay,
                )
                await asyncio.sleep(delay)

            except httpx.RequestError as e:
                if attempt == MAX_RETRIES - 1:
                    raise GraphAPIError(
                        f"Request failed after {MAX_RETRIES} retries: {e}"
                    ) from e

                delay = min(
                    INITIAL_RETRY_DELAY * (2**attempt),
                    MAX_RETRY_DELAY,
                )
                await logger.awarning(
                    "Request error, retrying",
                    endpoint=endpoint,
                    attempt=attempt + 1,
                    error=str(e),
                )
                await asyncio.sleep(delay)

        # Should not reach here, but satisfy type checker
        raise GraphAPIError(f"Request to {endpoint} failed")

    async def _handle_response(
        self,
        response: httpx.Response,
        endpoint: str,
    ) -> dict[str, Any] | None:
        """Handle API response and raise appropriate errors.

        Args:
            response: HTTP response.
            endpoint: API endpoint for error context.

        Returns:
            Response JSON data or None for 204 responses.

        Raises:
            GraphAPIError: On API errors.
        """
        # Success - no content
        if response.status_code == 204:
            return None

        # Success - with content
        if 200 <= response.status_code < 300:
            return response.json()

        # FIX-5: Handle non-JSON error responses gracefully
        try:
            error_data = response.json() if response.content else {}
        except (ValueError, JSONDecodeError):
            error_data = {}

        error_msg = error_data.get("error", {}).get(
            "message", f"HTTP {response.status_code}"
        )
        error_code = error_data.get("error", {}).get("code", "")

        await logger.aerror(
            "Graph API error",
            endpoint=endpoint,
            status=response.status_code,
            code=error_code,
            message=error_msg,
        )

        if response.status_code == 429:
            # FIX-4: Parse Retry-After header (supports integer and HTTP-date)
            retry_after = _parse_retry_after(response.headers.get("Retry-After"))
            raise RateLimitError(retry_after)

        if response.status_code == 404:
            raise ResourceNotFoundError(endpoint)

        if response.status_code == 403:
            raise PermissionDeniedError(endpoint)

        raise GraphAPIError(
            error_msg,
            status_code=response.status_code,
            error_code=error_code,
        )

    # =========================================================================
    # Pagination
    # =========================================================================

    async def paginate(
        self,
        endpoint: str,
        *,
        params: dict[str, Any] | None = None,
        top: int = 100,
        max_pages: int | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Paginate through Graph API results.

        Uses OData pagination with @odata.nextLink.

        Args:
            endpoint: API endpoint.
            params: Additional query parameters.
            top: Number of results per page.
            max_pages: Maximum pages to fetch (None for all).

        Yields:
            Individual items from paginated response.

        Example:
            async for message in client.paginate("/me/messages", top=50):
                print(message["subject"])
        """
        params = params or {}
        params["$top"] = top

        url: str | None = f"{GRAPH_BASE_URL}{endpoint}"
        page_count = 0

        while url:
            if max_pages and page_count >= max_pages:
                break

            # First page uses params, subsequent pages use nextLink URL
            if page_count == 0:
                data = await self.get(endpoint, params=params)
            else:
                # nextLink is full URL, use _request_url directly
                data = await self._request_url(url)

            # Yield individual items
            for item in data.get("value", []):
                yield item

            # Get next page URL
            url = data.get("@odata.nextLink")
            page_count += 1

    async def _request_url(self, url: str) -> dict[str, Any]:
        """Make request to full URL (for pagination nextLink).

        Args:
            url: Full URL to request.

        Returns:
            Response JSON data.
        """
        headers = await self._get_headers()

        if self._http_client is None:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.get(url, headers=headers)
        else:
            response = await self._http_client.get(url, headers=headers)

        return await self._handle_response(response, url)

    # =========================================================================
    # Batch Requests
    # =========================================================================

    async def batch(
        self,
        requests: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Execute batch request with multiple operations.

        Args:
            requests: List of request objects with id, method, url keys.

        Returns:
            List of response objects.

        Example:
            responses = await client.batch([
                {"id": "1", "method": "GET", "url": "/me"},
                {"id": "2", "method": "GET", "url": "/me/calendar"},
            ])
        """
        batch_body = {"requests": requests}
        response = await self.post("/$batch", json=batch_body)
        return response.get("responses", [])


# =============================================================================
# Factory Function
# =============================================================================


async def get_graph_client(
    redis: "RedisService",
    user_id: UUID,
) -> GraphClient:
    """Get a configured Graph API client.

    Args:
        redis: Redis service for token storage.
        user_id: User whose tokens to use.

    Returns:
        Configured GraphClient instance.
    """
    oauth = MicrosoftOAuth(redis)
    return GraphClient(oauth, user_id)
