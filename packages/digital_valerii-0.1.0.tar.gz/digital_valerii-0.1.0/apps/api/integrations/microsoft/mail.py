"""Microsoft Mail API service.

Provides email operations via Microsoft Graph API including:
- Message listing, reading, and searching
- Sending, replying, and forwarding emails
- Folder management
- Attachment handling
"""

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from apps.api.integrations.microsoft.graph_client import GraphClient, get_graph_client

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Models
# =============================================================================


class EmailAddress(BaseModel):
    """Email address model."""

    model_config = ConfigDict(extra="forbid")

    address: str = Field(..., description="Email address")
    name: str | None = Field(None, description="Display name")


class Attachment(BaseModel):
    """Email attachment model."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(None, description="Attachment ID")
    name: str = Field(..., description="File name")
    content_type: str = Field(..., description="MIME type")
    size: int = Field(default=0, description="Size in bytes")
    is_inline: bool = Field(default=False, description="Inline attachment")
    content_bytes: str | None = Field(None, description="Base64 content")


class MailFolder(BaseModel):
    """Mail folder model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Folder ID")
    display_name: str = Field(..., description="Folder name")
    parent_folder_id: str | None = Field(None, description="Parent folder ID")
    child_folder_count: int = Field(default=0, description="Child folder count")
    unread_item_count: int = Field(default=0, description="Unread messages")
    total_item_count: int = Field(default=0, description="Total messages")


class Message(BaseModel):
    """Email message model."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(None, description="Message ID")
    subject: str = Field(default="", description="Subject")
    body_preview: str = Field(default="", description="Body preview")
    body_content: str | None = Field(None, description="Full body content")
    body_content_type: str = Field(default="text", description="Body type")
    from_address: EmailAddress | None = Field(None, description="Sender")
    to_recipients: list[EmailAddress] = Field(default_factory=list, description="To")
    cc_recipients: list[EmailAddress] = Field(default_factory=list, description="CC")
    bcc_recipients: list[EmailAddress] = Field(default_factory=list, description="BCC")
    received_datetime: str | None = Field(None, description="Received time")
    sent_datetime: str | None = Field(None, description="Sent time")
    has_attachments: bool = Field(default=False, description="Has attachments")
    attachments: list[Attachment] = Field(
        default_factory=list, description="Attachments"
    )
    importance: str = Field(default="normal", description="Importance level")
    is_read: bool = Field(default=False, description="Read status")
    is_draft: bool = Field(default=False, description="Is draft")
    conversation_id: str | None = Field(None, description="Conversation ID")
    web_link: str | None = Field(None, description="Web link to message")


class SendMessageRequest(BaseModel):
    """Request to send an email."""

    model_config = ConfigDict(extra="forbid")

    to_recipients: list[str] = Field(..., description="To email addresses")
    cc_recipients: list[str] = Field(default_factory=list, description="CC addresses")
    bcc_recipients: list[str] = Field(default_factory=list, description="BCC addresses")
    subject: str = Field(..., description="Email subject")
    body: str = Field(..., description="Email body")
    body_content_type: str = Field(default="text", description="Body type (text/html)")
    importance: str = Field(default="normal", description="Importance level")
    attachments: list[Attachment] = Field(
        default_factory=list, description="Attachments"
    )
    save_to_sent_items: bool = Field(default=True, description="Save to sent items")


class ReplyMessageRequest(BaseModel):
    """Request to reply to an email."""

    model_config = ConfigDict(extra="forbid")

    message_id: str = Field(..., description="Message ID to reply to")
    comment: str = Field(..., description="Reply text")
    reply_all: bool = Field(default=False, description="Reply to all recipients")


class ForwardMessageRequest(BaseModel):
    """Request to forward an email."""

    model_config = ConfigDict(extra="forbid")

    message_id: str = Field(..., description="Message ID to forward")
    to_recipients: list[str] = Field(..., description="Forward to addresses")
    comment: str | None = Field(None, description="Comment to include")


# =============================================================================
# Mail Service
# =============================================================================


class MailService:
    """Service for Microsoft Mail operations.

    Provides methods for managing emails via Graph API.

    Example:
        async with MailService(redis, user_id) as service:
            messages = await service.get_messages(top=10)
            await service.send_message(request)
    """

    def __init__(
        self,
        redis: "RedisService",
        user_id: UUID,
    ) -> None:
        """Initialize Mail service.

        Args:
            redis: Redis service for token storage.
            user_id: User whose mail to access.
        """
        self._redis = redis
        self._user_id = user_id
        self._client: GraphClient | None = None

    async def __aenter__(self) -> "MailService":
        """Enter async context and initialize client."""
        self._client = await get_graph_client(self._redis, self._user_id)
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context and cleanup."""
        if self._client:
            await self._client.__aexit__(*args)
            self._client = None

    @property
    def client(self) -> GraphClient:
        """Get the Graph client."""
        if self._client is None:
            raise RuntimeError("MailService must be used as async context manager")
        return self._client

    # =========================================================================
    # Folder Operations
    # =========================================================================

    async def get_folders(self) -> list[MailFolder]:
        """Get all mail folders.

        Returns:
            List of mail folders.
        """
        data = await self.client.get("/me/mailFolders")
        folders = []

        for item in data.get("value", []):
            folders.append(
                MailFolder(
                    id=item["id"],
                    display_name=item.get("displayName", ""),
                    parent_folder_id=item.get("parentFolderId"),
                    child_folder_count=item.get("childFolderCount", 0),
                    unread_item_count=item.get("unreadItemCount", 0),
                    total_item_count=item.get("totalItemCount", 0),
                )
            )

        return folders

    async def get_folder(self, folder_id: str) -> MailFolder:
        """Get a specific mail folder.

        Args:
            folder_id: Folder ID or well-known name (inbox, sentitems, etc.)

        Returns:
            Mail folder details.
        """
        data = await self.client.get(f"/me/mailFolders/{folder_id}")
        return MailFolder(
            id=data["id"],
            display_name=data.get("displayName", ""),
            parent_folder_id=data.get("parentFolderId"),
            child_folder_count=data.get("childFolderCount", 0),
            unread_item_count=data.get("unreadItemCount", 0),
            total_item_count=data.get("totalItemCount", 0),
        )

    # =========================================================================
    # Message Operations
    # =========================================================================

    async def get_messages(
        self,
        *,
        folder_id: str = "inbox",
        top: int = 25,
        skip: int = 0,
        filter_query: str | None = None,
        search_query: str | None = None,
        select: str | None = None,
        order_by: str = "receivedDateTime desc",
    ) -> list[Message]:
        """Get messages from a folder.

        Args:
            folder_id: Folder ID or well-known name.
            top: Maximum messages to return.
            skip: Number of messages to skip.
            filter_query: OData filter expression.
            search_query: Search query.
            select: Fields to select.
            order_by: Sort order.

        Returns:
            List of messages.
        """
        params: dict[str, Any] = {
            "$top": top,
            "$skip": skip,
            "$orderby": order_by,
        }

        if select:
            params["$select"] = select
        else:
            params["$select"] = (
                "id,subject,bodyPreview,from,toRecipients,ccRecipients,"
                "receivedDateTime,sentDateTime,hasAttachments,importance,"
                "isRead,isDraft,conversationId,webLink"
            )

        if filter_query:
            params["$filter"] = filter_query

        if search_query:
            params["$search"] = f'"{search_query}"'

        data = await self.client.get(
            f"/me/mailFolders/{folder_id}/messages",
            params=params,
        )

        return [self._parse_message(item) for item in data.get("value", [])]

    async def get_message(
        self,
        message_id: str,
        *,
        include_body: bool = True,
    ) -> Message:
        """Get a single message by ID.

        Args:
            message_id: Message ID.
            include_body: Include full body content.

        Returns:
            Message details.
        """
        params = {}
        if include_body:
            params["$select"] = (
                "id,subject,body,bodyPreview,from,toRecipients,ccRecipients,"
                "bccRecipients,receivedDateTime,sentDateTime,hasAttachments,"
                "importance,isRead,isDraft,conversationId,webLink"
            )

        data = await self.client.get(f"/me/messages/{message_id}", params=params)
        return self._parse_message(data)

    async def search_messages(
        self,
        query: str,
        *,
        top: int = 25,
    ) -> list[Message]:
        """Search messages across all folders.

        Args:
            query: Search query.
            top: Maximum results.

        Returns:
            List of matching messages.
        """
        params = {
            "$search": f'"{query}"',
            "$top": top,
            "$select": (
                "id,subject,bodyPreview,from,toRecipients,"
                "receivedDateTime,hasAttachments,importance,isRead"
            ),
        }

        data = await self.client.get("/me/messages", params=params)
        return [self._parse_message(item) for item in data.get("value", [])]

    async def mark_as_read(
        self,
        message_id: str,
        is_read: bool = True,
    ) -> Message:
        """Mark message as read or unread.

        Args:
            message_id: Message ID.
            is_read: Read status to set.

        Returns:
            Updated message.
        """
        data = await self.client.patch(
            f"/me/messages/{message_id}",
            json={"isRead": is_read},
        )
        return self._parse_message(data)

    async def move_message(
        self,
        message_id: str,
        destination_folder_id: str,
    ) -> Message:
        """Move message to another folder.

        Args:
            message_id: Message ID.
            destination_folder_id: Destination folder ID.

        Returns:
            Moved message with new ID.
        """
        data = await self.client.post(
            f"/me/messages/{message_id}/move",
            json={"destinationId": destination_folder_id},
        )
        return self._parse_message(data)

    async def delete_message(self, message_id: str) -> bool:
        """Delete a message (moves to Deleted Items).

        Args:
            message_id: Message ID.

        Returns:
            True if deleted.
        """
        await self.client.delete(f"/me/messages/{message_id}")
        return True

    # =========================================================================
    # Send Operations
    # =========================================================================

    async def send_message(self, request: SendMessageRequest) -> bool:
        """Send an email.

        Args:
            request: Send message request.

        Returns:
            True if sent successfully.
        """
        message_body: dict[str, Any] = {
            "subject": request.subject,
            "body": {
                "contentType": request.body_content_type,
                "content": request.body,
            },
            "toRecipients": [
                {"emailAddress": {"address": addr}} for addr in request.to_recipients
            ],
            "importance": request.importance,
        }

        if request.cc_recipients:
            message_body["ccRecipients"] = [
                {"emailAddress": {"address": addr}} for addr in request.cc_recipients
            ]

        if request.bcc_recipients:
            message_body["bccRecipients"] = [
                {"emailAddress": {"address": addr}} for addr in request.bcc_recipients
            ]

        if request.attachments:
            message_body["attachments"] = [
                {
                    "@odata.type": "#microsoft.graph.fileAttachment",
                    "name": att.name,
                    "contentType": att.content_type,
                    "contentBytes": att.content_bytes,
                }
                for att in request.attachments
            ]

        await self.client.post(
            "/me/sendMail",
            json={
                "message": message_body,
                "saveToSentItems": request.save_to_sent_items,
            },
        )

        await logger.ainfo(
            "Sent email",
            user_id=str(self._user_id),
            to=request.to_recipients,
            subject=request.subject,
        )

        return True

    async def reply_to_message(self, request: ReplyMessageRequest) -> bool:
        """Reply to an email.

        Args:
            request: Reply request.

        Returns:
            True if sent successfully.
        """
        endpoint = (
            f"/me/messages/{request.message_id}/replyAll"
            if request.reply_all
            else f"/me/messages/{request.message_id}/reply"
        )

        await self.client.post(endpoint, json={"comment": request.comment})

        await logger.ainfo(
            "Replied to email",
            user_id=str(self._user_id),
            message_id=request.message_id,
            reply_all=request.reply_all,
        )

        return True

    async def forward_message(self, request: ForwardMessageRequest) -> bool:
        """Forward an email.

        Args:
            request: Forward request.

        Returns:
            True if sent successfully.
        """
        body: dict[str, Any] = {
            "toRecipients": [
                {"emailAddress": {"address": addr}} for addr in request.to_recipients
            ],
        }

        if request.comment:
            body["comment"] = request.comment

        await self.client.post(
            f"/me/messages/{request.message_id}/forward",
            json=body,
        )

        await logger.ainfo(
            "Forwarded email",
            user_id=str(self._user_id),
            message_id=request.message_id,
            to=request.to_recipients,
        )

        return True

    # =========================================================================
    # Draft Operations
    # =========================================================================

    async def create_draft(self, request: SendMessageRequest) -> Message:
        """Create a draft email.

        Args:
            request: Draft message content.

        Returns:
            Created draft message.
        """
        message_body: dict[str, Any] = {
            "subject": request.subject,
            "body": {
                "contentType": request.body_content_type,
                "content": request.body,
            },
            "toRecipients": [
                {"emailAddress": {"address": addr}} for addr in request.to_recipients
            ],
            "importance": request.importance,
        }

        if request.cc_recipients:
            message_body["ccRecipients"] = [
                {"emailAddress": {"address": addr}} for addr in request.cc_recipients
            ]

        data = await self.client.post("/me/messages", json=message_body)
        return self._parse_message(data)

    async def send_draft(self, message_id: str) -> bool:
        """Send a draft message.

        Args:
            message_id: Draft message ID.

        Returns:
            True if sent.
        """
        await self.client.post(f"/me/messages/{message_id}/send")
        return True

    # =========================================================================
    # Attachment Operations
    # =========================================================================

    async def get_attachments(self, message_id: str) -> list[Attachment]:
        """Get attachments for a message.

        Args:
            message_id: Message ID.

        Returns:
            List of attachments (without content).
        """
        data = await self.client.get(f"/me/messages/{message_id}/attachments")
        attachments = []

        for item in data.get("value", []):
            attachments.append(
                Attachment(
                    id=item.get("id"),
                    name=item.get("name", ""),
                    content_type=item.get("contentType", "application/octet-stream"),
                    size=item.get("size", 0),
                    is_inline=item.get("isInline", False),
                )
            )

        return attachments

    async def get_attachment(
        self,
        message_id: str,
        attachment_id: str,
    ) -> Attachment:
        """Get a single attachment with content.

        Args:
            message_id: Message ID.
            attachment_id: Attachment ID.

        Returns:
            Attachment with content bytes.
        """
        data = await self.client.get(
            f"/me/messages/{message_id}/attachments/{attachment_id}"
        )

        return Attachment(
            id=data.get("id"),
            name=data.get("name", ""),
            content_type=data.get("contentType", "application/octet-stream"),
            size=data.get("size", 0),
            is_inline=data.get("isInline", False),
            content_bytes=data.get("contentBytes"),
        )

    # =========================================================================
    # Pagination
    # =========================================================================

    async def iter_messages(
        self,
        *,
        folder_id: str = "inbox",
        page_size: int = 50,
        filter_query: str | None = None,
    ) -> AsyncIterator[Message]:
        """Iterate over all messages in a folder.

        Args:
            folder_id: Folder ID or well-known name.
            page_size: Messages per page.
            filter_query: OData filter expression.

        Yields:
            Messages in the folder.
        """
        params: dict[str, Any] = {
            "$orderby": "receivedDateTime desc",
            "$select": (
                "id,subject,bodyPreview,from,toRecipients,"
                "receivedDateTime,hasAttachments,importance,isRead"
            ),
        }

        if filter_query:
            params["$filter"] = filter_query

        async for item in self.client.paginate(
            f"/me/mailFolders/{folder_id}/messages",
            params=params,
            top=page_size,
        ):
            yield self._parse_message(item)

    # =========================================================================
    # Helpers
    # =========================================================================

    def _parse_message(self, data: dict[str, Any]) -> Message:
        """Parse Graph API message data to Message model.

        Args:
            data: Raw message data from Graph API.

        Returns:
            Parsed Message model.
        """
        from_data = data.get("from", {}).get("emailAddress", {})
        from_address = (
            EmailAddress(
                address=from_data.get("address", ""),
                name=from_data.get("name"),
            )
            if from_data
            else None
        )

        to_recipients = [
            EmailAddress(
                address=r.get("emailAddress", {}).get("address", ""),
                name=r.get("emailAddress", {}).get("name"),
            )
            for r in data.get("toRecipients", [])
        ]

        cc_recipients = [
            EmailAddress(
                address=r.get("emailAddress", {}).get("address", ""),
                name=r.get("emailAddress", {}).get("name"),
            )
            for r in data.get("ccRecipients", [])
        ]

        bcc_recipients = [
            EmailAddress(
                address=r.get("emailAddress", {}).get("address", ""),
                name=r.get("emailAddress", {}).get("name"),
            )
            for r in data.get("bccRecipients", [])
        ]

        body_data = data.get("body", {})

        return Message(
            id=data.get("id"),
            subject=data.get("subject", ""),
            body_preview=data.get("bodyPreview", ""),
            body_content=body_data.get("content") if body_data else None,
            body_content_type=body_data.get("contentType", "text")
            if body_data
            else "text",
            from_address=from_address,
            to_recipients=to_recipients,
            cc_recipients=cc_recipients,
            bcc_recipients=bcc_recipients,
            received_datetime=data.get("receivedDateTime"),
            sent_datetime=data.get("sentDateTime"),
            has_attachments=data.get("hasAttachments", False),
            importance=data.get("importance", "normal"),
            is_read=data.get("isRead", False),
            is_draft=data.get("isDraft", False),
            conversation_id=data.get("conversationId"),
            web_link=data.get("webLink"),
        )


# =============================================================================
# Factory Function
# =============================================================================


def get_mail_service(
    redis: "RedisService",
    user_id: UUID,
) -> MailService:
    """Get a Mail service instance.

    Args:
        redis: Redis service for token storage.
        user_id: User whose mail to access.

    Returns:
        MailService instance (use as async context manager).
    """
    return MailService(redis, user_id)
