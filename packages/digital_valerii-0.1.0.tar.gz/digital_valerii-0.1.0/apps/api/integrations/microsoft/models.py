"""Pydantic models for Microsoft Graph API integration."""

from datetime import UTC, datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class OAuthState(BaseModel):
    """OAuth state for CSRF protection.

    Stores state and PKCE verifier for OAuth callback validation.
    """

    model_config = ConfigDict(extra="forbid")

    state: str = Field(..., description="Random state for CSRF protection")
    code_verifier: str = Field(..., description="PKCE code verifier")
    user_id: UUID = Field(..., description="User initiating OAuth flow")
    redirect_uri: str | None = Field(None, description="Custom redirect URI after auth")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))


class MicrosoftToken(BaseModel):
    """Microsoft OAuth tokens.

    Stores access and refresh tokens with expiration tracking.
    """

    model_config = ConfigDict(extra="forbid")

    user_id: UUID = Field(..., description="User who owns these tokens")
    access_token: str = Field(..., description="Microsoft access token")
    refresh_token: str | None = Field(None, description="Microsoft refresh token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_at: datetime = Field(..., description="When access token expires")
    scope: str = Field(..., description="Granted scopes (space-separated)")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def is_expired(self) -> bool:
        """Check if access token is expired."""
        from datetime import timedelta

        # Consider expired 5 minutes before actual expiration for safety
        buffer = timedelta(seconds=300)
        return datetime.now(UTC) >= (self.expires_at - buffer)

    @property
    def scopes(self) -> list[str]:
        """Get scopes as list."""
        return self.scope.split()


class MicrosoftUser(BaseModel):
    """Microsoft user profile from Graph API."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Microsoft user ID")
    display_name: str | None = Field(None, description="Display name")
    mail: str | None = Field(None, description="Email address")
    user_principal_name: str | None = Field(None, description="UPN")
    job_title: str | None = Field(None, description="Job title")
    office_location: str | None = Field(None, description="Office location")


class TokenResponse(BaseModel):
    """Response from Microsoft token endpoint."""

    model_config = ConfigDict(extra="forbid")

    access_token: str
    token_type: str
    expires_in: int  # seconds
    scope: str
    refresh_token: str | None = None
    id_token: str | None = None


class AuthorizeUrlResponse(BaseModel):
    """Response containing OAuth authorize URL."""

    model_config = ConfigDict(extra="forbid")

    authorize_url: str = Field(..., description="URL to redirect user to for auth")
    state: str = Field(..., description="State for CSRF validation")


class OAuthCallbackResponse(BaseModel):
    """Response after successful OAuth callback."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(default=True)
    user: MicrosoftUser
    message: str = Field(
        default="Microsoft account connected successfully",
        description="Success message",
    )
