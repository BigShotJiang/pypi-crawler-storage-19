"""Custom exceptions for Microsoft Graph API integration."""


class MicrosoftAuthError(Exception):
    """Base exception for Microsoft authentication errors."""

    pass


class TokenExpiredError(MicrosoftAuthError):
    """Raised when access token has expired and refresh failed."""

    pass


class TokenRefreshError(MicrosoftAuthError):
    """Raised when token refresh fails."""

    pass


class InvalidStateError(MicrosoftAuthError):
    """Raised when OAuth state validation fails."""

    pass


class GraphAPIError(Exception):
    """Base exception for Graph API errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        error_code: str | None = None,
    ) -> None:
        """Initialize GraphAPIError.

        Args:
            message: Error message.
            status_code: HTTP status code if applicable.
            error_code: Microsoft Graph error code.
        """
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


class RateLimitError(GraphAPIError):
    """Raised when Graph API rate limit is exceeded."""

    def __init__(self, retry_after: int | None = None) -> None:
        """Initialize RateLimitError.

        Args:
            retry_after: Seconds to wait before retrying.
        """
        super().__init__(
            f"Rate limit exceeded. Retry after {retry_after} seconds.",
            status_code=429,
            error_code="TooManyRequests",
        )
        self.retry_after = retry_after


class ResourceNotFoundError(GraphAPIError):
    """Raised when requested resource is not found."""

    def __init__(self, resource: str) -> None:
        """Initialize ResourceNotFoundError.

        Args:
            resource: Resource that was not found.
        """
        super().__init__(
            f"Resource not found: {resource}",
            status_code=404,
            error_code="ResourceNotFound",
        )


class PermissionDeniedError(GraphAPIError):
    """Raised when user lacks permission for requested operation."""

    def __init__(self, operation: str) -> None:
        """Initialize PermissionDeniedError.

        Args:
            operation: Operation that was denied.
        """
        super().__init__(
            f"Permission denied for operation: {operation}",
            status_code=403,
            error_code="AccessDenied",
        )
