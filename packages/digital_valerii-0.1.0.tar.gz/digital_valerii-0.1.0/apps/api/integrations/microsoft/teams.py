"""Microsoft Teams API service.

Provides Teams operations via Microsoft Graph API including:
- Team and channel listing
- Channel messages (read/send)
- Chat messages
- @mentions support
"""

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any
from uuid import UUID

import structlog
from pydantic import BaseModel, ConfigDict, Field

from apps.api.integrations.microsoft.graph_client import GraphClient, get_graph_client

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)


# =============================================================================
# Models
# =============================================================================


class Team(BaseModel):
    """Microsoft Teams team model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Team ID")
    display_name: str = Field(..., description="Team name")
    description: str | None = Field(None, description="Team description")
    visibility: str = Field(default="private", description="Team visibility")
    web_url: str | None = Field(None, description="Team web URL")
    is_archived: bool = Field(default=False, description="Is archived")


class Channel(BaseModel):
    """Teams channel model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Channel ID")
    display_name: str = Field(..., description="Channel name")
    description: str | None = Field(None, description="Channel description")
    membership_type: str = Field(default="standard", description="Channel type")
    web_url: str | None = Field(None, description="Channel web URL")
    is_favorite: bool = Field(default=False, description="Is favorite channel")


class ChatMessage(BaseModel):
    """Teams chat/channel message model."""

    model_config = ConfigDict(extra="forbid")

    id: str | None = Field(None, description="Message ID")
    message_type: str = Field(default="message", description="Message type")
    created_datetime: str | None = Field(None, description="Created time")
    modified_datetime: str | None = Field(None, description="Modified time")
    deleted_datetime: str | None = Field(None, description="Deleted time")
    from_user_id: str | None = Field(None, description="Sender user ID")
    from_user_name: str | None = Field(None, description="Sender display name")
    body_content: str = Field(default="", description="Message content")
    body_content_type: str = Field(default="text", description="Content type")
    importance: str = Field(default="normal", description="Importance")
    web_url: str | None = Field(None, description="Message web URL")
    reply_to_id: str | None = Field(None, description="Reply to message ID")
    attachments: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Message attachments",
    )
    mentions: list[dict[str, Any]] = Field(
        default_factory=list,
        description="@mentions",
    )


class Chat(BaseModel):
    """Teams chat model."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Chat ID")
    topic: str | None = Field(None, description="Chat topic")
    chat_type: str = Field(..., description="Chat type (oneOnOne, group, meeting)")
    created_datetime: str | None = Field(None, description="Created time")
    last_updated_datetime: str | None = Field(None, description="Last updated")
    web_url: str | None = Field(None, description="Chat web URL")
    members: list[str] = Field(default_factory=list, description="Member IDs")


class SendMessageRequest(BaseModel):
    """Request to send a Teams message."""

    model_config = ConfigDict(extra="forbid")

    content: str = Field(..., description="Message content")
    content_type: str = Field(default="text", description="Content type (text/html)")
    importance: str = Field(default="normal", description="Importance level")
    mentions: list[dict[str, str]] = Field(
        default_factory=list,
        description="@mentions [{id, display_name, user_id}]",
    )


class ReplyMessageRequest(BaseModel):
    """Request to reply to a Teams message."""

    model_config = ConfigDict(extra="forbid")

    content: str = Field(..., description="Reply content")
    content_type: str = Field(default="text", description="Content type")


# =============================================================================
# Teams Service
# =============================================================================


class TeamsService:
    """Service for Microsoft Teams operations.

    Provides methods for managing Teams via Graph API.

    Example:
        async with TeamsService(redis, user_id) as service:
            teams = await service.get_teams()
            channels = await service.get_channels(team_id)
            messages = await service.get_channel_messages(team_id, channel_id)
    """

    def __init__(
        self,
        redis: "RedisService",
        user_id: UUID,
    ) -> None:
        """Initialize Teams service.

        Args:
            redis: Redis service for token storage.
            user_id: User whose Teams to access.
        """
        self._redis = redis
        self._user_id = user_id
        self._client: GraphClient | None = None

    async def __aenter__(self) -> "TeamsService":
        """Enter async context and initialize client."""
        self._client = await get_graph_client(self._redis, self._user_id)
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context and cleanup."""
        if self._client:
            await self._client.__aexit__(*args)
            self._client = None

    @property
    def client(self) -> GraphClient:
        """Get the Graph client."""
        if self._client is None:
            raise RuntimeError("TeamsService must be used as async context manager")
        return self._client

    # =========================================================================
    # Team Operations
    # =========================================================================

    async def get_teams(self) -> list[Team]:
        """Get all teams the user is a member of.

        Returns:
            List of teams.
        """
        data = await self.client.get("/me/joinedTeams")
        teams = []

        for item in data.get("value", []):
            teams.append(
                Team(
                    id=item["id"],
                    display_name=item.get("displayName", ""),
                    description=item.get("description"),
                    visibility=item.get("visibility", "private"),
                    web_url=item.get("webUrl"),
                    is_archived=item.get("isArchived", False),
                )
            )

        return teams

    async def get_team(self, team_id: str) -> Team:
        """Get a specific team.

        Args:
            team_id: Team ID.

        Returns:
            Team details.
        """
        data = await self.client.get(f"/teams/{team_id}")
        return Team(
            id=data["id"],
            display_name=data.get("displayName", ""),
            description=data.get("description"),
            visibility=data.get("visibility", "private"),
            web_url=data.get("webUrl"),
            is_archived=data.get("isArchived", False),
        )

    # =========================================================================
    # Channel Operations
    # =========================================================================

    async def get_channels(self, team_id: str) -> list[Channel]:
        """Get all channels in a team.

        Args:
            team_id: Team ID.

        Returns:
            List of channels.
        """
        data = await self.client.get(f"/teams/{team_id}/channels")
        channels = []

        for item in data.get("value", []):
            channels.append(
                Channel(
                    id=item["id"],
                    display_name=item.get("displayName", ""),
                    description=item.get("description"),
                    membership_type=item.get("membershipType", "standard"),
                    web_url=item.get("webUrl"),
                    is_favorite=item.get("isFavoriteByDefault", False),
                )
            )

        return channels

    async def get_channel(self, team_id: str, channel_id: str) -> Channel:
        """Get a specific channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.

        Returns:
            Channel details.
        """
        data = await self.client.get(f"/teams/{team_id}/channels/{channel_id}")
        return Channel(
            id=data["id"],
            display_name=data.get("displayName", ""),
            description=data.get("description"),
            membership_type=data.get("membershipType", "standard"),
            web_url=data.get("webUrl"),
            is_favorite=data.get("isFavoriteByDefault", False),
        )

    # =========================================================================
    # Channel Message Operations
    # =========================================================================

    async def get_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        top: int = 50,
    ) -> list[ChatMessage]:
        """Get messages from a channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            top: Maximum messages to return.

        Returns:
            List of messages.
        """
        params = {"$top": top}
        data = await self.client.get(
            f"/teams/{team_id}/channels/{channel_id}/messages",
            params=params,
        )

        return [self._parse_message(item) for item in data.get("value", [])]

    async def get_message_replies(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
    ) -> list[ChatMessage]:
        """Get replies to a channel message.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            message_id: Parent message ID.

        Returns:
            List of reply messages.
        """
        data = await self.client.get(
            f"/teams/{team_id}/channels/{channel_id}/messages/{message_id}/replies"
        )

        return [self._parse_message(item) for item in data.get("value", [])]

    async def send_channel_message(
        self,
        team_id: str,
        channel_id: str,
        request: SendMessageRequest,
    ) -> ChatMessage:
        """Send a message to a channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            request: Message request.

        Returns:
            Sent message.
        """
        body: dict[str, Any] = {
            "body": {
                "contentType": request.content_type,
                "content": self._build_content_with_mentions(
                    request.content,
                    request.mentions,
                ),
            },
            "importance": request.importance,
        }

        if request.mentions:
            body["mentions"] = [
                {
                    "id": idx,
                    "mentionText": m["display_name"],
                    "mentioned": {
                        "user": {"id": m["user_id"]},
                    },
                }
                for idx, m in enumerate(request.mentions)
            ]

        data = await self.client.post(
            f"/teams/{team_id}/channels/{channel_id}/messages",
            json=body,
        )

        await logger.ainfo(
            "Sent channel message",
            user_id=str(self._user_id),
            team_id=team_id,
            channel_id=channel_id,
        )

        return self._parse_message(data)

    async def reply_to_channel_message(
        self,
        team_id: str,
        channel_id: str,
        message_id: str,
        request: ReplyMessageRequest,
    ) -> ChatMessage:
        """Reply to a channel message.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            message_id: Message to reply to.
            request: Reply request.

        Returns:
            Reply message.
        """
        body = {
            "body": {
                "contentType": request.content_type,
                "content": request.content,
            },
        }

        data = await self.client.post(
            f"/teams/{team_id}/channels/{channel_id}/messages/{message_id}/replies",
            json=body,
        )

        return self._parse_message(data)

    # =========================================================================
    # Chat Operations
    # =========================================================================

    async def get_chats(self, top: int = 50) -> list[Chat]:
        """Get all chats for the user.

        Args:
            top: Maximum chats to return.

        Returns:
            List of chats.
        """
        params = {"$top": top, "$expand": "members"}
        data = await self.client.get("/me/chats", params=params)
        chats = []

        for item in data.get("value", []):
            members = [
                m.get("userId", "") for m in item.get("members", []) if m.get("userId")
            ]
            chats.append(
                Chat(
                    id=item["id"],
                    topic=item.get("topic"),
                    chat_type=item.get("chatType", "oneOnOne"),
                    created_datetime=item.get("createdDateTime"),
                    last_updated_datetime=item.get("lastUpdatedDateTime"),
                    web_url=item.get("webUrl"),
                    members=members,
                )
            )

        return chats

    async def get_chat(self, chat_id: str) -> Chat:
        """Get a specific chat.

        Args:
            chat_id: Chat ID.

        Returns:
            Chat details.
        """
        params = {"$expand": "members"}
        data = await self.client.get(f"/me/chats/{chat_id}", params=params)
        members = [
            m.get("userId", "") for m in data.get("members", []) if m.get("userId")
        ]
        return Chat(
            id=data["id"],
            topic=data.get("topic"),
            chat_type=data.get("chatType", "oneOnOne"),
            created_datetime=data.get("createdDateTime"),
            last_updated_datetime=data.get("lastUpdatedDateTime"),
            web_url=data.get("webUrl"),
            members=members,
        )

    async def get_chat_messages(
        self,
        chat_id: str,
        *,
        top: int = 50,
    ) -> list[ChatMessage]:
        """Get messages from a chat.

        Args:
            chat_id: Chat ID.
            top: Maximum messages to return.

        Returns:
            List of messages.
        """
        params = {"$top": top}
        data = await self.client.get(f"/me/chats/{chat_id}/messages", params=params)
        return [self._parse_message(item) for item in data.get("value", [])]

    async def send_chat_message(
        self,
        chat_id: str,
        request: SendMessageRequest,
    ) -> ChatMessage:
        """Send a message to a chat.

        Args:
            chat_id: Chat ID.
            request: Message request.

        Returns:
            Sent message.
        """
        body: dict[str, Any] = {
            "body": {
                "contentType": request.content_type,
                "content": request.content,
            },
        }

        data = await self.client.post(f"/me/chats/{chat_id}/messages", json=body)

        await logger.ainfo(
            "Sent chat message",
            user_id=str(self._user_id),
            chat_id=chat_id,
        )

        return self._parse_message(data)

    # =========================================================================
    # Pagination
    # =========================================================================

    async def iter_channel_messages(
        self,
        team_id: str,
        channel_id: str,
        *,
        page_size: int = 50,
    ) -> AsyncIterator[ChatMessage]:
        """Iterate over all messages in a channel.

        Args:
            team_id: Team ID.
            channel_id: Channel ID.
            page_size: Messages per page.

        Yields:
            Channel messages.
        """
        async for item in self.client.paginate(
            f"/teams/{team_id}/channels/{channel_id}/messages",
            top=page_size,
        ):
            yield self._parse_message(item)

    # =========================================================================
    # Helpers
    # =========================================================================

    def _parse_message(self, data: dict[str, Any]) -> ChatMessage:
        """Parse Graph API message data to ChatMessage model.

        Args:
            data: Raw message data from Graph API.

        Returns:
            Parsed ChatMessage model.
        """
        from_data = data.get("from", {})
        user_data = from_data.get("user", {})

        body_data = data.get("body", {})

        return ChatMessage(
            id=data.get("id"),
            message_type=data.get("messageType", "message"),
            created_datetime=data.get("createdDateTime"),
            modified_datetime=data.get("lastModifiedDateTime"),
            deleted_datetime=data.get("deletedDateTime"),
            from_user_id=user_data.get("id"),
            from_user_name=user_data.get("displayName"),
            body_content=body_data.get("content", ""),
            body_content_type=body_data.get("contentType", "text"),
            importance=data.get("importance", "normal"),
            web_url=data.get("webUrl"),
            reply_to_id=data.get("replyToId"),
            attachments=data.get("attachments", []),
            mentions=data.get("mentions", []),
        )

    def _build_content_with_mentions(
        self,
        content: str,
        mentions: list[dict[str, str]],
    ) -> str:
        """Build message content with @mention tags.

        Args:
            content: Original content.
            mentions: List of mentions.

        Returns:
            Content with mention tags.
        """
        if not mentions:
            return content

        # Replace @DisplayName with <at id="N">DisplayName</at>
        result = content
        for idx, mention in enumerate(mentions):
            display_name = mention.get("display_name", "")
            at_text = f"@{display_name}"
            at_tag = f'<at id="{idx}">{display_name}</at>'
            result = result.replace(at_text, at_tag)

        return result


# =============================================================================
# Factory Function
# =============================================================================


def get_teams_service(
    redis: "RedisService",
    user_id: UUID,
) -> TeamsService:
    """Get a Teams service instance.

    Args:
        redis: Redis service for token storage.
        user_id: User whose Teams to access.

    Returns:
        TeamsService instance (use as async context manager).
    """
    return TeamsService(redis, user_id)
