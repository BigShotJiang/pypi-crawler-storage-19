"""Microsoft OAuth 2.0 implementation with PKCE.

Implements OAuth 2.0 authorization code flow with PKCE for secure
authentication with Microsoft Azure AD.
"""

import base64
import hashlib
import secrets
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING
from urllib.parse import urlencode, urlparse
from uuid import UUID

import httpx
import structlog
from cryptography.fernet import Fernet, InvalidToken

from apps.api.config import RedisNamespace, settings
from apps.api.integrations.microsoft.exceptions import (
    InvalidStateError,
    MicrosoftAuthError,
    TokenRefreshError,
)
from apps.api.integrations.microsoft.models import (
    MicrosoftToken,
    MicrosoftUser,
    OAuthState,
    TokenResponse,
)

if TYPE_CHECKING:
    from digital_valerii_shared.services.redis import RedisService

logger = structlog.get_logger(__name__)

# Microsoft OAuth URLs
AUTHORIZE_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize"
TOKEN_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

# OAuth state expiration (5 minutes)
STATE_TTL_SECONDS = 300

# Allowed redirect URI hosts (FIX-1: Open redirect prevention)
ALLOWED_REDIRECT_HOSTS = {
    "localhost",
    "127.0.0.1",
    "digitalvalerii.com",
    "digital-valerii-production.up.railway.app",
}


def _validate_redirect_uri(uri: str | None) -> str | None:
    """Validate redirect URI is safe (same-origin or allowed hosts).

    Prevents open redirect vulnerabilities by validating URIs against an allowlist.

    Args:
        uri: Redirect URI to validate.

    Returns:
        Validated URI or None if invalid.
    """
    if not uri:
        return None

    # Allow relative paths (same-origin)
    if uri.startswith("/"):
        return uri

    # Parse and validate
    parsed = urlparse(uri)

    # Reject dangerous schemes (javascript:, data:)
    if parsed.scheme in ("javascript", "data", "vbscript"):
        return None

    # Only allow http/https schemes
    if parsed.scheme not in ("https", "http"):
        return None

    # HTTP only allowed for localhost
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1"):
        return None

    # Check hostname against allowlist
    if parsed.hostname not in ALLOWED_REDIRECT_HOSTS:
        return None

    return uri


def _encrypt_token(token_json: str) -> str:
    """Encrypt token data before storing.

    Uses Fernet symmetric encryption if key is configured.

    Args:
        token_json: JSON string of token data.

    Returns:
        Encrypted data (base64) or original if no key configured.
    """
    if not settings.microsoft_token_encryption_key:
        return token_json  # Fallback for dev
    try:
        fernet = Fernet(settings.microsoft_token_encryption_key.encode())
        return fernet.encrypt(token_json.encode()).decode()
    except Exception:
        # If encryption fails, log and return unencrypted (for dev only)
        return token_json


def _decrypt_token(encrypted: str) -> str:
    """Decrypt token data after retrieval.

    Args:
        encrypted: Encrypted data string.

    Returns:
        Decrypted JSON string.
    """
    if not settings.microsoft_token_encryption_key:
        return encrypted  # Fallback for dev
    try:
        fernet = Fernet(settings.microsoft_token_encryption_key.encode())
        return fernet.decrypt(encrypted.encode()).decode()
    except InvalidToken:
        # If decryption fails, assume unencrypted (migration case)
        return encrypted


class MicrosoftOAuth:
    """Microsoft OAuth 2.0 client with PKCE support.

    Handles the complete OAuth flow:
    1. Generate authorization URL with PKCE challenge
    2. Handle callback and exchange code for tokens
    3. Refresh tokens when expired
    4. Store tokens securely in Redis

    Example:
        oauth = MicrosoftOAuth(redis)

        # Start OAuth flow
        url, state = await oauth.get_authorize_url(user_id)
        # Redirect user to url...

        # Handle callback
        tokens = await oauth.handle_callback(code, state)

        # Get valid token (auto-refresh if needed)
        token = await oauth.get_valid_token(user_id)
    """

    def __init__(self, redis: "RedisService") -> None:
        """Initialize Microsoft OAuth client.

        Args:
            redis: Redis service for state and token storage.
        """
        self._redis = redis
        self._client_id = settings.microsoft_client_id
        self._client_secret = settings.microsoft_client_secret
        self._tenant_id = settings.microsoft_tenant_id
        self._redirect_uri = settings.microsoft_redirect_uri
        self._scopes = settings.microsoft_scopes

    # =========================================================================
    # PKCE Helpers
    # =========================================================================

    @staticmethod
    def _generate_code_verifier() -> str:
        """Generate a random code verifier for PKCE.

        Returns:
            Random string (43-128 characters) as code verifier.
        """
        return secrets.token_urlsafe(64)

    @staticmethod
    def _generate_code_challenge(verifier: str) -> str:
        """Generate code challenge from verifier using SHA256.

        Args:
            verifier: Code verifier string.

        Returns:
            Base64 URL-encoded SHA256 hash of verifier.
        """
        digest = hashlib.sha256(verifier.encode()).digest()
        return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    @staticmethod
    def _generate_state() -> str:
        """Generate random state for CSRF protection.

        Returns:
            Random hex string.
        """
        return secrets.token_hex(32)

    # =========================================================================
    # Authorization URL
    # =========================================================================

    async def get_authorize_url(
        self,
        user_id: UUID,
        redirect_uri_after: str | None = None,
    ) -> tuple[str, str]:
        """Generate authorization URL for OAuth flow.

        Args:
            user_id: User initiating the OAuth flow.
            redirect_uri_after: Optional URL to redirect after auth completes.

        Returns:
            Tuple of (authorize_url, state).

        Raises:
            MicrosoftAuthError: If configuration is missing.
        """
        if not self._client_id:
            raise MicrosoftAuthError("Microsoft client ID not configured")

        # FIX-1: Validate redirect URI to prevent open redirects
        validated_redirect = _validate_redirect_uri(redirect_uri_after)

        # Generate PKCE values
        code_verifier = self._generate_code_verifier()
        code_challenge = self._generate_code_challenge(code_verifier)
        state = self._generate_state()

        # Store state with verifier for callback validation
        oauth_state = OAuthState(
            state=state,
            code_verifier=code_verifier,
            user_id=user_id,
            redirect_uri=validated_redirect,
        )
        await self._store_state(state, oauth_state)

        # Build authorization URL
        params = {
            "client_id": self._client_id,
            "response_type": "code",
            "redirect_uri": self._redirect_uri,
            "response_mode": "query",
            "scope": " ".join(self._scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "prompt": "consent",  # Always show consent for all scopes
        }

        authorize_url = AUTHORIZE_URL.format(tenant=self._tenant_id)
        full_url = f"{authorize_url}?{urlencode(params)}"

        await logger.ainfo(
            "Generated Microsoft OAuth URL",
            user_id=str(user_id),
            state=state[:8] + "...",
        )

        return full_url, state

    # =========================================================================
    # Callback Handling
    # =========================================================================

    async def handle_callback(
        self,
        code: str,
        state: str,
    ) -> tuple[MicrosoftToken, MicrosoftUser, str | None]:
        """Handle OAuth callback and exchange code for tokens.

        Args:
            code: Authorization code from Microsoft.
            state: State parameter for CSRF validation.

        Returns:
            Tuple of (tokens, user_info, redirect_uri_after).

        Raises:
            InvalidStateError: If state validation fails.
            MicrosoftAuthError: If token exchange fails.
        """
        # Validate and retrieve state
        oauth_state = await self._get_and_delete_state(state)
        if not oauth_state:
            raise InvalidStateError("Invalid or expired OAuth state")

        # Exchange code for tokens
        token_response = await self._exchange_code(code, oauth_state.code_verifier)

        # Calculate expiration
        expires_at = datetime.now(UTC) + timedelta(seconds=token_response.expires_in)

        # Create token object
        tokens = MicrosoftToken(
            user_id=oauth_state.user_id,
            access_token=token_response.access_token,
            refresh_token=token_response.refresh_token,
            token_type=token_response.token_type,
            expires_at=expires_at,
            scope=token_response.scope,
        )

        # Store tokens
        await self._store_tokens(tokens)

        # Get user info
        user_info = await self._get_user_info(token_response.access_token)

        await logger.ainfo(
            "Microsoft OAuth completed",
            user_id=str(oauth_state.user_id),
            email=user_info.mail,
        )

        return tokens, user_info, oauth_state.redirect_uri

    async def _exchange_code(
        self,
        code: str,
        code_verifier: str,
    ) -> TokenResponse:
        """Exchange authorization code for tokens.

        Args:
            code: Authorization code from Microsoft.
            code_verifier: PKCE code verifier.

        Returns:
            Token response with access and refresh tokens.

        Raises:
            MicrosoftAuthError: If token exchange fails.
        """
        token_url = TOKEN_URL.format(tenant=self._tenant_id)

        data = {
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "code": code,
            "redirect_uri": self._redirect_uri,
            "grant_type": "authorization_code",
            "code_verifier": code_verifier,
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    token_url,
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    timeout=30.0,
                )

                if response.status_code != 200:
                    error_data = response.json()
                    error_desc = error_data.get("error_description", "Unknown error")
                    await logger.aerror(
                        "Token exchange failed",
                        status=response.status_code,
                        error=error_desc,
                    )
                    raise MicrosoftAuthError(f"Token exchange failed: {error_desc}")

                return TokenResponse(**response.json())

            except httpx.RequestError as e:
                raise MicrosoftAuthError(f"Token request failed: {e}") from e

    # =========================================================================
    # Token Refresh
    # =========================================================================

    async def refresh_tokens(self, user_id: UUID) -> MicrosoftToken:
        """Refresh tokens for a user.

        Args:
            user_id: User whose tokens to refresh.

        Returns:
            New tokens.

        Raises:
            TokenRefreshError: If refresh fails.
        """
        current_tokens = await self.get_tokens(user_id)
        if not current_tokens:
            raise TokenRefreshError("No tokens found for user")

        if not current_tokens.refresh_token:
            raise TokenRefreshError("No refresh token available")

        token_url = TOKEN_URL.format(tenant=self._tenant_id)

        data = {
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "refresh_token": current_tokens.refresh_token,
            "grant_type": "refresh_token",
            "scope": " ".join(self._scopes),
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    token_url,
                    data=data,
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    timeout=30.0,
                )

                if response.status_code != 200:
                    error_data = response.json()
                    error_desc = error_data.get("error_description", "Unknown error")
                    await logger.aerror(
                        "Token refresh failed",
                        user_id=str(user_id),
                        error=error_desc,
                    )
                    raise TokenRefreshError(f"Token refresh failed: {error_desc}")

                token_response = TokenResponse(**response.json())

                # Calculate expiration
                expires_at = datetime.now(UTC) + timedelta(
                    seconds=token_response.expires_in
                )

                # Create new token object
                new_tokens = MicrosoftToken(
                    user_id=user_id,
                    access_token=token_response.access_token,
                    refresh_token=token_response.refresh_token
                    or current_tokens.refresh_token,
                    token_type=token_response.token_type,
                    expires_at=expires_at,
                    scope=token_response.scope,
                )

                # Store new tokens
                await self._store_tokens(new_tokens)

                await logger.ainfo(
                    "Microsoft tokens refreshed",
                    user_id=str(user_id),
                )

                return new_tokens

            except httpx.RequestError as e:
                raise TokenRefreshError(f"Token refresh request failed: {e}") from e

    async def get_valid_token(self, user_id: UUID) -> MicrosoftToken:
        """Get a valid access token, refreshing if necessary.

        Args:
            user_id: User whose token to get.

        Returns:
            Valid token.

        Raises:
            TokenRefreshError: If no tokens or refresh fails.
        """
        tokens = await self.get_tokens(user_id)
        if not tokens:
            raise TokenRefreshError("No Microsoft tokens found for user")

        if tokens.is_expired:
            await logger.adebug("Token expired, refreshing", user_id=str(user_id))
            tokens = await self.refresh_tokens(user_id)

        return tokens

    # =========================================================================
    # User Info
    # =========================================================================

    async def _get_user_info(self, access_token: str) -> MicrosoftUser:
        """Get user profile from Microsoft Graph API.

        Args:
            access_token: Valid access token.

        Returns:
            User profile information.

        Raises:
            MicrosoftAuthError: If user info request fails.
        """
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{GRAPH_BASE_URL}/me",
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json",
                    },
                    timeout=30.0,
                )

                if response.status_code != 200:
                    raise MicrosoftAuthError(
                        f"Failed to get user info: {response.status_code}"
                    )

                data = response.json()
                return MicrosoftUser(
                    id=data.get("id", ""),
                    display_name=data.get("displayName"),
                    mail=data.get("mail"),
                    user_principal_name=data.get("userPrincipalName"),
                    job_title=data.get("jobTitle"),
                    office_location=data.get("officeLocation"),
                )

            except httpx.RequestError as e:
                raise MicrosoftAuthError(f"User info request failed: {e}") from e

    # =========================================================================
    # Storage Helpers
    # =========================================================================

    async def _store_state(self, state: str, oauth_state: OAuthState) -> None:
        """Store OAuth state in Redis.

        Args:
            state: State key.
            oauth_state: State data to store.
        """
        key = f"{RedisNamespace.MICROSOFT_OAUTH_STATE}{state}"
        await self._redis.cache_set(
            key,
            oauth_state.model_dump(mode="json"),
            ttl=STATE_TTL_SECONDS,
        )

    async def _get_and_delete_state(self, state: str) -> OAuthState | None:
        """Get and delete OAuth state from Redis.

        Args:
            state: State key.

        Returns:
            State data if found and valid, None otherwise.
        """
        key = f"{RedisNamespace.MICROSOFT_OAUTH_STATE}{state}"
        data = await self._redis.cache_get(key)
        if data:
            await self._redis.cache_delete(key)
            return OAuthState(**data)
        return None

    async def _store_tokens(self, tokens: MicrosoftToken) -> None:
        """Store tokens in Redis with encryption.

        FIX-2: Tokens are encrypted at rest using Fernet encryption.

        Args:
            tokens: Tokens to store.
        """
        key = f"{RedisNamespace.MICROSOFT_TOKENS}{tokens.user_id}"
        # Serialize and encrypt tokens
        token_json = tokens.model_dump_json()
        encrypted = _encrypt_token(token_json)

        # Store tokens with TTL slightly longer than refresh token validity
        # Refresh tokens typically last 90 days
        await self._redis.cache_set(
            key,
            encrypted,
            ttl=90 * 24 * 60 * 60,  # 90 days
        )

    async def get_tokens(self, user_id: UUID) -> MicrosoftToken | None:
        """Get stored tokens for a user (with decryption).

        FIX-2: Tokens are decrypted after retrieval.

        Args:
            user_id: User whose tokens to get.

        Returns:
            Tokens if found, None otherwise.
        """
        key = f"{RedisNamespace.MICROSOFT_TOKENS}{user_id}"
        data = await self._redis.cache_get(key)
        if data:
            # Handle both encrypted (string) and unencrypted (dict) formats
            if isinstance(data, str):
                decrypted = _decrypt_token(data)
                return MicrosoftToken.model_validate_json(decrypted)
            # Legacy format (unencrypted dict)
            return MicrosoftToken(**data)
        return None

    async def delete_tokens(self, user_id: UUID) -> bool:
        """Delete tokens for a user (disconnect Microsoft account).

        Args:
            user_id: User whose tokens to delete.

        Returns:
            True if deleted, False if not found.
        """
        key = f"{RedisNamespace.MICROSOFT_TOKENS}{user_id}"
        deleted = await self._redis.cache_delete(key)
        if deleted:
            await logger.ainfo("Microsoft tokens deleted", user_id=str(user_id))
        return deleted > 0

    async def has_valid_connection(self, user_id: UUID) -> bool:
        """Check if user has a valid Microsoft connection.

        Args:
            user_id: User to check.

        Returns:
            True if user has valid tokens.
        """
        tokens = await self.get_tokens(user_id)
        return tokens is not None
