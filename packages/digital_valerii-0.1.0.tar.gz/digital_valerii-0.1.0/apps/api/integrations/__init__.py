"""Integrations module - third-party services."""
