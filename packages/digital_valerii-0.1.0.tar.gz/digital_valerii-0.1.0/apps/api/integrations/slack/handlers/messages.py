"""Slack message handlers.

Handles direct messages and @mentions of the bot.
"""

import re
from typing import TYPE_CHECKING

import structlog
from slack_bolt.async_app import AsyncApp
from slack_sdk.web.async_client import AsyncWebClient

from apps.api.integrations.slack.config import slack_settings
from apps.api.integrations.slack.models import AI_DISCLOSURE, SlackMessage

if TYPE_CHECKING:
    from apps.api.integrations.slack.services.slack_service import SlackService

logger = structlog.get_logger(__name__)


def register_message_handlers(app: AsyncApp, service: "SlackService") -> None:
    """Register message event handlers.

    Args:
        app: Slack Bolt async app.
        service: Slack service for processing messages.
    """

    @app.event("message")
    async def handle_message(
        event: dict,
        say,
        _client: AsyncWebClient,
    ) -> None:
        """Handle direct messages to the bot.

        Only responds to DMs (im channel type), ignores:
        - Bot messages
        - Message edits/deletions
        - Channel messages (use @mentions for those)
        """
        # Ignore bot messages and message edits
        if event.get("bot_id") or event.get("subtype"):
            return

        channel_type = event.get("channel_type")
        user_id = event.get("user")
        text = event.get("text", "")
        channel = event.get("channel")
        thread_ts = event.get("thread_ts") or event.get("ts")

        # Only respond to DMs
        if channel_type != "im":
            return

        if not text.strip():
            return

        await logger.ainfo(
            "Received DM",
            user_id=user_id,
            channel=channel,
            text_length=len(text),
        )

        try:
            # Validate message
            validated = SlackMessage(
                text=text,
                user_id=user_id,
                channel=channel,
                thread_ts=thread_ts,
                timestamp=event.get("ts"),
            )

            # Check rate limit
            is_allowed = await service.check_rate_limit(user_id, "messages")
            if not is_allowed:
                await say(
                    text="You're sending messages too quickly. Please wait a moment.",
                    thread_ts=thread_ts
                    if slack_settings.thread_replies_enabled
                    else None,
                )
                return

            # Process message through agent
            response = await service.process_message(
                user_id=validated.user_id,
                text=validated.text,
                channel=validated.channel,
                thread_ts=validated.thread_ts,
            )

            # Include AI disclosure for first message in thread
            response_text = response.text
            if slack_settings.ai_disclosure_enabled and not event.get("thread_ts"):
                response_text = f"{AI_DISCLOSURE}\n\n{response.text}"

            # Reply in thread
            await say(
                text=response_text,
                thread_ts=thread_ts if slack_settings.thread_replies_enabled else None,
                blocks=response.blocks if response.blocks else None,
            )

            await logger.ainfo(
                "Sent DM response",
                user_id=user_id,
                response_length=len(response.text),
            )

        except Exception as e:
            await logger.aerror(
                "Error handling DM",
                user_id=user_id,
                error=str(e),
                exc_info=True,
            )
            await say(
                text="Sorry, I encountered an error processing your message. Please try again.",
                thread_ts=thread_ts if slack_settings.thread_replies_enabled else None,
            )

    @app.event("app_mention")
    async def handle_mention(
        event: dict,
        say,
        _client: AsyncWebClient,
    ) -> None:
        """Handle @mentions of the bot in channels.

        Extracts the message text (removing the bot mention) and processes it.
        """
        user_id = event.get("user")
        text = event.get("text", "")
        channel = event.get("channel")
        thread_ts = event.get("thread_ts") or event.get("ts")

        # Remove bot mention from text
        # Format: <@U12345> message
        text = re.sub(r"<@[A-Z0-9]+>\s*", "", text).strip()

        await logger.ainfo(
            "Received mention",
            user_id=user_id,
            channel=channel,
            text_length=len(text),
        )

        if not text:
            await say(
                text="Hi! How can I help you? Ask me a question or use `/dv help` for commands.",
                thread_ts=thread_ts,
            )
            return

        try:
            # Check rate limit
            is_allowed = await service.check_rate_limit(user_id, "messages")
            if not is_allowed:
                await say(
                    text="You're sending messages too quickly. Please wait a moment.",
                    thread_ts=thread_ts,
                )
                return

            # Process message through agent
            response = await service.process_message(
                user_id=user_id,
                text=text,
                channel=channel,
                thread_ts=thread_ts,
            )

            # Include AI disclosure for first message in thread
            response_text = response.text
            if slack_settings.ai_disclosure_enabled and not event.get("thread_ts"):
                response_text = f"{AI_DISCLOSURE}\n\n{response.text}"

            await say(
                text=response_text,
                thread_ts=thread_ts,
                blocks=response.blocks if response.blocks else None,
            )

            await logger.ainfo(
                "Sent mention response",
                user_id=user_id,
                channel=channel,
                response_length=len(response.text),
            )

        except Exception as e:
            await logger.aerror(
                "Error handling mention",
                user_id=user_id,
                channel=channel,
                error=str(e),
                exc_info=True,
            )
            await say(
                text="Sorry, I encountered an error processing your message. Please try again.",
                thread_ts=thread_ts,
            )
