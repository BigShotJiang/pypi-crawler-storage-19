"""Slack event handlers.

Handles other Slack events:
- app_home_opened: When user opens the bot's home tab
"""

from typing import TYPE_CHECKING

import structlog
from slack_bolt.async_app import AsyncApp
from slack_sdk.web.async_client import AsyncWebClient

from apps.api.integrations.slack.models import AI_DISCLOSURE_BLOCK

if TYPE_CHECKING:
    from apps.api.integrations.slack.services.slack_service import SlackService

logger = structlog.get_logger(__name__)


def register_event_handlers(app: AsyncApp, _service: "SlackService") -> None:
    """Register event handlers.

    Args:
        app: Slack Bolt async app.
        service: Slack service (not used here but kept for consistency).
    """

    @app.event("app_home_opened")
    async def handle_app_home_opened(
        event: dict,
        client: AsyncWebClient,
    ) -> None:
        """Handle when user opens the bot's home tab.

        Displays a welcome message and usage instructions.
        """
        user_id = event.get("user")

        await logger.ainfo("App home opened", user_id=user_id)

        try:
            # Build home tab view
            home_view = {
                "type": "home",
                "blocks": [
                    {
                        "type": "header",
                        "text": {
                            "type": "plain_text",
                            "text": ":wave: Welcome to Digital Valerii!",
                            "emoji": True,
                        },
                    },
                    {"type": "divider"},
                    AI_DISCLOSURE_BLOCK,
                    {"type": "divider"},
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "*How to use Digital Valerii:*\n\n"
                            ":speech_balloon: *Direct Message* - Just send me a message!\n\n"
                            ":loudspeaker: *Mention in Channel* - Type `@Digital Valerii` followed by your message\n\n"
                            ":zap: *Slash Commands* - Use `/dv` for quick actions",
                        },
                    },
                    {"type": "divider"},
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "*Available Commands:*\n\n"
                            "`/dv ask <question>` - Ask me anything\n"
                            "`/dv memory <query>` - Search my memory\n"
                            "`/dv status` - Check bot status\n"
                            "`/dv help` - Show help message",
                        },
                    },
                    {"type": "divider"},
                    {
                        "type": "context",
                        "elements": [
                            {
                                "type": "mrkdwn",
                                "text": ":lock: Your conversations are private and secure.",
                            }
                        ],
                    },
                ],
            }

            # Publish the home tab
            await client.views_publish(user_id=user_id, view=home_view)

        except Exception as e:
            await logger.aerror(
                "Error publishing home tab",
                user_id=user_id,
                error=str(e),
                exc_info=True,
            )

    @app.event("team_join")
    async def handle_team_join(
        event: dict,
        _client: AsyncWebClient,
    ) -> None:
        """Handle when a new user joins the workspace.

        Optionally sends a welcome message.
        """
        user_id = event.get("user", {}).get("id")
        if not user_id:
            return

        await logger.ainfo("New user joined", user_id=user_id)

        # Note: Uncomment to send welcome DM to new users
        # try:
        #     await client.chat_postMessage(
        #         channel=user_id,
        #         text="Welcome! I'm Digital Valerii, an AI assistant. "
        #              "Feel free to message me anytime or use `/dv help` for commands.",
        #     )
        # except Exception as e:
        #     await logger.aerror("Error sending welcome message", error=str(e))
