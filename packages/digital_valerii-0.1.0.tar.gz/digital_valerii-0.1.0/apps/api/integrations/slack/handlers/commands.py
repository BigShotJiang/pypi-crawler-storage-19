"""Slack slash command handlers.

Handles /dv commands:
- /dv ask <question> - Ask the AI
- /dv memory <query> - Search memory
- /dv status - Bot status
- /dv new - Start fresh session
- /dv session - Session info
- /dv help - Show help
"""

from typing import TYPE_CHECKING

import structlog
from slack_bolt.async_app import AsyncApp

from apps.api.integrations.slack.models import AI_DISCLOSURE

if TYPE_CHECKING:
    from apps.api.integrations.slack.services.slack_service import SlackService

logger = structlog.get_logger(__name__)


def register_command_handlers(app: AsyncApp, service: "SlackService") -> None:
    """Register slash command handlers.

    Args:
        app: Slack Bolt async app.
        service: Slack service for processing commands.
    """

    @app.command("/dv")
    async def handle_dv_command(ack, command: dict, respond) -> None:
        """Handle /dv commands.

        Usage:
            /dv ask <question>       - Ask a question
            /dv memory <query>       - Search memory
            /dv status               - Bot status
            /dv help                 - Show help
        """
        # Acknowledge within 3 seconds (required by Slack)
        await ack()

        user_id = command.get("user_id", "")
        text = command.get("text", "").strip()
        channel_id = command.get("channel_id", "")

        await logger.ainfo(
            "Received /dv command",
            user_id=user_id,
            text=text,
            channel_id=channel_id,
        )

        # Parse subcommand
        parts = text.split(maxsplit=1)
        subcommand = parts[0].lower() if parts else "help"
        args = parts[1] if len(parts) > 1 else ""

        try:
            # Check rate limit
            is_allowed = await service.check_rate_limit(user_id, "commands")
            if not is_allowed:
                await respond(
                    "You're using commands too quickly. Please wait a moment.",
                    response_type="ephemeral",
                )
                return

            if subcommand == "ask":
                if not args:
                    await respond(
                        "Usage: `/dv ask <your question>`",
                        response_type="ephemeral",
                    )
                    return

                response = await service.process_command_ask(
                    user_id=user_id,
                    question=args,
                    channel_id=channel_id,
                )

                # Include AI disclosure
                response_text = f"{AI_DISCLOSURE}\n\n{response.text}"
                await respond(response_text, blocks=response.blocks)

            elif subcommand == "memory":
                if not args:
                    await respond(
                        "Usage: `/dv memory <search query>`",
                        response_type="ephemeral",
                    )
                    return

                response = await service.search_memory(
                    user_id=user_id,
                    query=args,
                )
                await respond(response.text, blocks=response.blocks)

            elif subcommand == "status":
                response = await service.get_status()
                await respond(response.text, blocks=response.blocks)

            elif subcommand == "new":
                # Start new session (Component 4.8)
                response = await service.start_new_session(user_id)
                await respond(response.text, response_type="ephemeral")

            elif subcommand == "session":
                # Get session info (Component 4.8)
                session_info = await service.get_user_session_info(user_id)
                if session_info:
                    session_text = f"""*Session Info*

:id: Session: `{session_info['session_id'][:8]}...`
:channel: Last Channel: {session_info['last_channel'] or 'N/A'}
:arrows_counterclockwise: Compact Count: {session_info['compact_count']}
:incoming_envelope: Pending Messages: {session_info['pending_messages']}
:white_check_mark: Status: {session_info['status']}"""
                else:
                    session_text = "No active session. Session will be created on your next message."
                await respond(session_text, response_type="ephemeral")

            elif subcommand == "help":
                help_text = """*Digital Valerii Commands*

`/dv ask <question>` - Ask me anything
`/dv memory <query>` - Search my memory
`/dv status` - Check bot status
`/dv new` - Start a fresh session
`/dv session` - View session info
`/dv help` - Show this help message

You can also DM me directly or @mention me in a channel!

_Digital Valerii is an AI assistant. All responses are AI-generated._"""
                await respond(help_text)

            else:
                await respond(
                    f"Unknown command: `{subcommand}`. Use `/dv help` for available commands.",
                    response_type="ephemeral",
                )

            await logger.ainfo(
                "Processed /dv command",
                user_id=user_id,
                subcommand=subcommand,
            )

        except Exception as e:
            await logger.aerror(
                "Error handling /dv command",
                user_id=user_id,
                subcommand=subcommand,
                error=str(e),
                exc_info=True,
            )
            await respond(
                "Sorry, I encountered an error processing your command. Please try again.",
                response_type="ephemeral",
            )
