"""Tests for SlackService."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from apps.api.integrations.slack.models import SlackResponse
from apps.api.integrations.slack.services.slack_service import SlackService

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_agent():
    """Create mock DigitalValeriiAgent."""
    agent = AsyncMock()
    agent.chat = AsyncMock()
    return agent


@pytest.fixture
def mock_memory():
    """Create mock MemoryManager."""
    memory = AsyncMock()
    memory.recall = AsyncMock()
    return memory


@pytest.fixture
def mock_redis():
    """Create mock RedisService."""
    redis = AsyncMock()
    redis.incr = AsyncMock(return_value=1)
    redis.expire = AsyncMock()
    redis.cache_get = AsyncMock(return_value=None)
    redis.cache_set = AsyncMock()
    return redis


@pytest.fixture
def service(mock_agent, mock_memory, mock_redis):
    """Create SlackService with mocked dependencies."""
    return SlackService(
        agent=mock_agent,
        memory=mock_memory,
        redis=mock_redis,
    )


# =============================================================================
# Process Message Tests
# =============================================================================


class TestProcessMessage:
    """Tests for process_message method."""

    @pytest.mark.asyncio
    async def test_process_message_success(self, service, mock_agent):
        """Should process message through agent."""
        mock_response = MagicMock()
        mock_response.content = "Hello! How can I help?"
        mock_agent.chat.return_value = mock_response

        result = await service.process_message(
            user_id="U123",
            text="Hello",
            channel="C456",
            thread_ts="123.456",
        )

        assert isinstance(result, SlackResponse)
        assert result.text == "Hello! How can I help?"
        mock_agent.chat.assert_called_once()

    @pytest.mark.asyncio
    async def test_process_message_agent_error(self, service, mock_agent):
        """Should return error message on agent failure."""
        mock_agent.chat.side_effect = Exception("Agent error")

        result = await service.process_message(
            user_id="U123",
            text="Hello",
            channel="C456",
        )

        assert "trouble processing" in result.text.lower()

    @pytest.mark.asyncio
    async def test_process_message_creates_context(
        self, service, mock_agent, mock_redis
    ):
        """Should create conversation context in Redis."""
        mock_response = MagicMock()
        mock_response.content = "Response"
        mock_agent.chat.return_value = mock_response

        await service.process_message(
            user_id="U123",
            text="Hello",
            channel="C456",
            thread_ts="123.456",
        )

        # Should store context in Redis
        mock_redis.cache_set.assert_called()

    @pytest.mark.asyncio
    async def test_process_message_long_response_truncated(self, service, mock_agent):
        """Should truncate long responses."""
        mock_response = MagicMock()
        mock_response.content = "x" * 5000  # Long response
        mock_agent.chat.return_value = mock_response

        with patch.object(service, "_format_response") as mock_format:
            mock_format.return_value = "truncated"
            _result = await service.process_message(
                user_id="U123",
                text="Hello",
                channel="C456",
            )
            mock_format.assert_called_once()


# =============================================================================
# Process Command Ask Tests
# =============================================================================


class TestProcessCommandAsk:
    """Tests for process_command_ask method."""

    @pytest.mark.asyncio
    async def test_command_ask_success(self, service, mock_agent):
        """Should process ask command through agent."""
        mock_response = MagicMock()
        mock_response.content = "The answer is 42"
        mock_agent.chat.return_value = mock_response

        result = await service.process_command_ask(
            user_id="U123",
            question="What is the meaning of life?",
            channel_id="C456",
        )

        assert result.text == "The answer is 42"
        mock_agent.chat.assert_called_once()

    @pytest.mark.asyncio
    async def test_command_ask_error(self, service, mock_agent):
        """Should return error on failure."""
        mock_agent.chat.side_effect = Exception("Failed")

        result = await service.process_command_ask(
            user_id="U123",
            question="Test?",
            channel_id="C456",
        )

        assert "trouble" in result.text.lower()


# =============================================================================
# Search Memory Tests
# =============================================================================


class TestSearchMemory:
    """Tests for search_memory method."""

    @pytest.mark.asyncio
    async def test_search_memory_success(self, service, mock_memory):
        """Should return formatted search results."""
        mock_event = MagicMock()
        mock_event.event_type = "conversation"
        mock_event.content = "A conversation about cats"
        mock_event.timestamp = datetime.now(UTC)

        mock_results = MagicMock()
        mock_results.events = [mock_event]
        mock_memory.recall.return_value = mock_results

        result = await service.search_memory(
            user_id="U123",
            query="cats",
        )

        assert "1 memories" in result.text
        assert result.blocks is not None
        assert len(result.blocks) > 0

    @pytest.mark.asyncio
    async def test_search_memory_no_results(self, service, mock_memory):
        """Should handle no results."""
        mock_results = MagicMock()
        mock_results.events = []
        mock_memory.recall.return_value = mock_results

        result = await service.search_memory(
            user_id="U123",
            query="nonexistent",
        )

        assert "No memories found" in result.text
        assert result.blocks is None

    @pytest.mark.asyncio
    async def test_search_memory_error(self, service, mock_memory):
        """Should handle search errors."""
        mock_memory.recall.side_effect = Exception("Search failed")

        result = await service.search_memory(
            user_id="U123",
            query="test",
        )

        assert "Failed to search" in result.text

    @pytest.mark.asyncio
    async def test_search_memory_truncates_long_content(self, service, mock_memory):
        """Should truncate long content in results."""
        mock_event = MagicMock()
        mock_event.event_type = "conversation"
        mock_event.content = "x" * 300  # Long content
        mock_event.timestamp = datetime.now(UTC)

        mock_results = MagicMock()
        mock_results.events = [mock_event]
        mock_memory.recall.return_value = mock_results

        result = await service.search_memory(
            user_id="U123",
            query="test",
        )

        # Content should be truncated in blocks
        assert result.blocks is not None


# =============================================================================
# Get Status Tests
# =============================================================================


class TestGetStatus:
    """Tests for get_status method."""

    @pytest.mark.asyncio
    async def test_get_status(self, service):
        """Should return status message."""
        result = await service.get_status()

        assert "Digital Valerii Status" in result.text
        assert "Online" in result.text
        assert "Ready" in result.text


# =============================================================================
# Rate Limit Tests
# =============================================================================


class TestCheckRateLimit:
    """Tests for check_rate_limit method."""

    @pytest.mark.asyncio
    async def test_rate_limit_allowed(self, service, mock_redis):
        """Should allow requests within limit."""
        mock_redis.incr.return_value = 1

        result = await service.check_rate_limit("U123", "messages")

        assert result is True

    @pytest.mark.asyncio
    async def test_rate_limit_exceeded(self, service, mock_redis):
        """Should block requests exceeding limit."""
        mock_redis.incr.return_value = 100  # Over limit

        result = await service.check_rate_limit("U123", "messages")

        assert result is False

    @pytest.mark.asyncio
    async def test_rate_limit_error_allows_request(self, service, mock_redis):
        """Should allow request on Redis error (fail open)."""
        mock_redis.incr.side_effect = Exception("Redis error")

        result = await service.check_rate_limit("U123", "messages")

        assert result is True  # Fail open

    @pytest.mark.asyncio
    async def test_rate_limit_sets_expiry_on_first_request(self, service, mock_redis):
        """Should set expiry on first request."""
        mock_redis.incr.return_value = 1

        await service.check_rate_limit("U123", "messages")

        mock_redis.expire.assert_called_once()

    @pytest.mark.asyncio
    async def test_rate_limit_no_expiry_on_subsequent(self, service, mock_redis):
        """Should not set expiry on subsequent requests."""
        mock_redis.incr.return_value = 5  # Not first

        await service.check_rate_limit("U123", "messages")

        mock_redis.expire.assert_not_called()


# =============================================================================
# Format Response Tests
# =============================================================================


class TestFormatResponse:
    """Tests for _format_response method."""

    def test_short_response_unchanged(self, service):
        """Should not modify short responses."""
        result = service._format_response("Hello world")
        assert result == "Hello world"

    def test_long_response_truncated(self, service):
        """Should truncate long responses."""
        long_text = "x" * 5000
        result = service._format_response(long_text, max_length=100)

        assert len(result) <= 100
        assert "_(truncated)_" in result

    def test_default_max_length(self, service):
        """Should use default max length from settings."""
        # This tests that the method uses settings when max_length is None
        result = service._format_response("Hello")
        assert result == "Hello"


# =============================================================================
# Context Management Tests
# =============================================================================


class TestContextManagement:
    """Tests for conversation context management."""

    @pytest.mark.asyncio
    async def test_creates_new_context(self, service, mock_redis):
        """Should create new context when none exists."""
        mock_redis.cache_get.return_value = None

        context = await service._get_or_create_context(
            user_id="U123",
            channel="C456",
            thread_ts="123.456",
        )

        assert context is not None
        mock_redis.cache_set.assert_called_once()

    @pytest.mark.asyncio
    async def test_restores_existing_context(self, service, mock_redis):
        """Should restore existing context from Redis."""
        stored_context = {
            "conversation_id": str(uuid4()),
            "session_id": "test-session",
        }
        mock_redis.cache_get.return_value = stored_context

        context = await service._get_or_create_context(
            user_id="U123",
            channel="C456",
            thread_ts="123.456",
        )

        assert context is not None
        # Should not create new context
        mock_redis.cache_set.assert_not_called()

    @pytest.mark.asyncio
    async def test_ephemeral_context_not_stored(self, service, mock_redis):
        """Should not store ephemeral context."""
        context = await service._create_ephemeral_context(
            user_id="U123",
            channel_id="C456",
        )

        assert context is not None
        mock_redis.cache_set.assert_not_called()
