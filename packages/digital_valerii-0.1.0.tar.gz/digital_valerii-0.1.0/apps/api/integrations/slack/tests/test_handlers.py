"""Tests for Slack message and command handlers."""

from unittest.mock import AsyncMock, MagicMock

import pytest

from apps.api.integrations.slack.models import SlackResponse

# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def mock_service():
    """Create mock SlackService."""
    service = AsyncMock()
    service.check_rate_limit = AsyncMock(return_value=True)
    service.process_message = AsyncMock(
        return_value=SlackResponse(text="Response text")
    )
    service.process_command_ask = AsyncMock(return_value=SlackResponse(text="Answer"))
    service.search_memory = AsyncMock(return_value=SlackResponse(text="Memory results"))
    service.get_status = AsyncMock(return_value=SlackResponse(text="Status: OK"))
    return service


@pytest.fixture
def mock_say():
    """Create mock say function."""
    return AsyncMock()


@pytest.fixture
def mock_respond():
    """Create mock respond function."""
    return AsyncMock()


@pytest.fixture
def mock_ack():
    """Create mock ack function."""
    return AsyncMock()


@pytest.fixture
def mock_client():
    """Create mock Slack client."""
    return AsyncMock()


# =============================================================================
# Message Handler Tests
# =============================================================================


class TestMessageHandler:
    """Tests for message event handlers."""

    @pytest.mark.asyncio
    async def test_ignores_bot_messages(self, mock_service, mock_say, mock_client):
        """Should ignore messages from bots."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "bot_id": "B123",
            "text": "Bot message",
            "user": "U123",
            "channel": "C123",
            "channel_type": "im",
        }

        await handlers["message"](event, mock_say, mock_client)
        mock_service.process_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_ignores_message_edits(self, mock_service, mock_say, mock_client):
        """Should ignore message edits."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "subtype": "message_changed",
            "text": "Edited message",
            "user": "U123",
            "channel": "C123",
            "channel_type": "im",
        }

        await handlers["message"](event, mock_say, mock_client)
        mock_service.process_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_ignores_channel_messages(self, mock_service, mock_say, mock_client):
        """Should ignore messages in channels (not DMs)."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "text": "Channel message",
            "user": "U123",
            "channel": "C123",
            "channel_type": "channel",
        }

        await handlers["message"](event, mock_say, mock_client)
        mock_service.process_message.assert_not_called()

    @pytest.mark.asyncio
    async def test_processes_dm(self, mock_service, mock_say, mock_client):
        """Should process direct messages."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "text": "Hello bot",
            "user": "U123",
            "channel": "D123",
            "channel_type": "im",
            "ts": "123.456",
        }

        await handlers["message"](event, mock_say, mock_client)

        mock_service.check_rate_limit.assert_called_once()
        mock_service.process_message.assert_called_once()
        mock_say.assert_called_once()

    @pytest.mark.asyncio
    async def test_rate_limit_blocks_dm(self, mock_service, mock_say, mock_client):
        """Should block rate-limited users."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        mock_service.check_rate_limit.return_value = False

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "text": "Hello bot",
            "user": "U123",
            "channel": "D123",
            "channel_type": "im",
            "ts": "123.456",
        }

        await handlers["message"](event, mock_say, mock_client)

        mock_service.process_message.assert_not_called()
        mock_say.assert_called_once()
        assert "too quickly" in mock_say.call_args[1]["text"]


# =============================================================================
# Mention Handler Tests
# =============================================================================


class TestMentionHandler:
    """Tests for app_mention event handlers."""

    @pytest.mark.asyncio
    async def test_processes_mention(self, mock_service, mock_say, mock_client):
        """Should process @mentions."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "text": "<@U456> Hello bot",
            "user": "U123",
            "channel": "C123",
            "ts": "123.456",
        }

        await handlers["app_mention"](event, mock_say, mock_client)

        mock_service.process_message.assert_called_once()
        # Text should have mention removed
        call_args = mock_service.process_message.call_args
        assert "<@" not in call_args.kwargs.get(
            "text", call_args.args[1] if len(call_args.args) > 1 else ""
        )

    @pytest.mark.asyncio
    async def test_empty_mention_shows_help(self, mock_service, mock_say, mock_client):
        """Should show help for empty mentions."""
        from apps.api.integrations.slack.handlers.messages import (
            register_message_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_message_handlers(app, mock_service)

        event = {
            "text": "<@U456>",
            "user": "U123",
            "channel": "C123",
            "ts": "123.456",
        }

        await handlers["app_mention"](event, mock_say, mock_client)

        mock_service.process_message.assert_not_called()
        mock_say.assert_called_once()
        assert "help" in mock_say.call_args[1]["text"].lower()


# =============================================================================
# Command Handler Tests
# =============================================================================


class TestCommandHandler:
    """Tests for slash command handlers."""

    @pytest.mark.asyncio
    async def test_ask_command(self, mock_service, mock_ack, mock_respond):
        """Should process /dv ask command."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "ask What is the weather?",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_ack.assert_called_once()
        mock_service.process_command_ask.assert_called_once()
        mock_respond.assert_called_once()

    @pytest.mark.asyncio
    async def test_memory_command(self, mock_service, mock_ack, mock_respond):
        """Should process /dv memory command."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "memory cats",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_ack.assert_called_once()
        mock_service.search_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_status_command(self, mock_service, mock_ack, mock_respond):
        """Should process /dv status command."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "status",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_service.get_status.assert_called_once()

    @pytest.mark.asyncio
    async def test_help_command(self, mock_service, mock_ack, mock_respond):
        """Should show help for /dv help."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "help",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_respond.assert_called_once()
        assert "Commands" in mock_respond.call_args[0][0]

    @pytest.mark.asyncio
    async def test_unknown_command(self, mock_service, mock_ack, mock_respond):
        """Should handle unknown subcommands."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "unknown",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_respond.assert_called_once()
        assert "Unknown command" in mock_respond.call_args[0][0]

    @pytest.mark.asyncio
    async def test_rate_limit_blocks_command(
        self, mock_service, mock_ack, mock_respond
    ):
        """Should block rate-limited commands."""
        from apps.api.integrations.slack.handlers.commands import (
            register_command_handlers,
        )

        mock_service.check_rate_limit.return_value = False

        app = MagicMock()
        handlers = {}

        def capture_command(cmd):
            def decorator(func):
                handlers[cmd] = func
                return func

            return decorator

        app.command = capture_command
        register_command_handlers(app, mock_service)

        command = {
            "user_id": "U123",
            "channel_id": "C123",
            "text": "ask test",
        }

        await handlers["/dv"](mock_ack, command, mock_respond)

        mock_service.process_command_ask.assert_not_called()
        mock_respond.assert_called_once()
        assert "too quickly" in mock_respond.call_args[0][0]


# =============================================================================
# Event Handler Tests
# =============================================================================


class TestEventHandler:
    """Tests for other event handlers."""

    @pytest.mark.asyncio
    async def test_app_home_opened(self, mock_service, mock_client):
        """Should publish home view when app home is opened."""
        from apps.api.integrations.slack.handlers.events import (
            register_event_handlers,
        )

        app = MagicMock()
        handlers = {}

        def capture_event(event_type):
            def decorator(func):
                handlers[event_type] = func
                return func

            return decorator

        app.event = capture_event
        register_event_handlers(app, mock_service)

        event = {"user": "U123"}

        await handlers["app_home_opened"](event, mock_client)

        mock_client.views_publish.assert_called_once()
        call_kwargs = mock_client.views_publish.call_args.kwargs
        assert call_kwargs["user_id"] == "U123"
        assert call_kwargs["view"]["type"] == "home"
