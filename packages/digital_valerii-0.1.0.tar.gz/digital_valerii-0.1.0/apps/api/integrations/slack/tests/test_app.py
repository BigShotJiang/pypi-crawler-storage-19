"""Tests for Slack app initialization."""

from unittest.mock import AsyncMock, patch

from slack_bolt.async_app import AsyncApp

from apps.api.integrations.slack.app import (
    create_slack_app,
    reset_slack_handlers,
    setup_slack_handlers,
)

# =============================================================================
# Create Slack App Tests
# =============================================================================


class TestCreateSlackApp:
    """Tests for create_slack_app function."""

    def test_creates_async_app(self):
        """Should create AsyncApp instance."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = "xoxb-test-token"
            mock_settings.slack_signing_secret = "test-secret"

            app = create_slack_app()

            assert isinstance(app, AsyncApp)

    def test_unconfigured_app_when_no_token(self):
        """Should create unconfigured app when token missing."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = ""
            mock_settings.slack_signing_secret = "test-secret"

            app = create_slack_app()

            assert isinstance(app, AsyncApp)

    def test_unconfigured_app_when_no_secret(self):
        """Should create unconfigured app when secret missing."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = "xoxb-test-token"
            mock_settings.slack_signing_secret = ""

            app = create_slack_app()

            assert isinstance(app, AsyncApp)


# =============================================================================
# Setup Handlers Tests
# =============================================================================


class TestSetupSlackHandlers:
    """Tests for setup_slack_handlers function."""

    def setup_method(self):
        """Reset handler state before each test."""
        reset_slack_handlers()

    def test_registers_handlers_when_configured(self):
        """Should register handlers when Slack is configured."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = "xoxb-test-token"
            mock_settings.slack_signing_secret = "test-secret"

            with patch(
                "apps.api.integrations.slack.app.register_message_handlers"
            ) as mock_msg:
                with patch(
                    "apps.api.integrations.slack.app.register_command_handlers"
                ) as mock_cmd:
                    with patch(
                        "apps.api.integrations.slack.app.register_event_handlers"
                    ) as mock_evt:
                        mock_service = AsyncMock()

                        setup_slack_handlers(mock_service)

                        mock_msg.assert_called_once()
                        mock_cmd.assert_called_once()
                        mock_evt.assert_called_once()

    def test_skips_when_not_configured(self):
        """Should skip registration when Slack not configured."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = ""
            mock_settings.slack_signing_secret = ""

            with patch(
                "apps.api.integrations.slack.app.register_message_handlers"
            ) as mock_msg:
                mock_service = AsyncMock()

                setup_slack_handlers(mock_service)

                mock_msg.assert_not_called()

    def test_skips_when_already_registered(self):
        """Should skip if handlers already registered."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = "xoxb-test-token"
            mock_settings.slack_signing_secret = "test-secret"

            with patch(
                "apps.api.integrations.slack.app.register_message_handlers"
            ) as mock_msg:
                with patch("apps.api.integrations.slack.app.register_command_handlers"):
                    with patch(
                        "apps.api.integrations.slack.app.register_event_handlers"
                    ):
                        mock_service = AsyncMock()

                        # First call
                        setup_slack_handlers(mock_service)
                        # Second call
                        setup_slack_handlers(mock_service)

                        # Should only be called once
                        assert mock_msg.call_count == 1


# =============================================================================
# Reset Handlers Tests
# =============================================================================


class TestResetSlackHandlers:
    """Tests for reset_slack_handlers function."""

    def test_allows_re_registration(self):
        """Should allow re-registration after reset."""
        with patch("apps.api.integrations.slack.app.settings") as mock_settings:
            mock_settings.slack_bot_token = "xoxb-test-token"
            mock_settings.slack_signing_secret = "test-secret"

            with patch(
                "apps.api.integrations.slack.app.register_message_handlers"
            ) as mock_msg:
                with patch("apps.api.integrations.slack.app.register_command_handlers"):
                    with patch(
                        "apps.api.integrations.slack.app.register_event_handlers"
                    ):
                        mock_service = AsyncMock()

                        setup_slack_handlers(mock_service)
                        reset_slack_handlers()
                        setup_slack_handlers(mock_service)

                        # Should be called twice
                        assert mock_msg.call_count == 2
