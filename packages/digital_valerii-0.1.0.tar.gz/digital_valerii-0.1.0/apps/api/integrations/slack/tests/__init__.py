"""Tests for Slack Bot integration."""
