"""Tests for Slack models."""

import pytest
from pydantic import ValidationError

from apps.api.integrations.slack.models import (
    AI_DISCLOSURE,
    AI_DISCLOSURE_BLOCK,
    CommandRequest,
    SlackConversationContext,
    SlackMessage,
    SlackResponse,
    SlackUser,
)

# =============================================================================
# SlackMessage Tests
# =============================================================================


class TestSlackMessage:
    """Tests for SlackMessage model."""

    def test_valid_message(self):
        """Should accept valid message."""
        msg = SlackMessage(
            text="Hello world",
            user_id="U123456",
            channel="C789",
            thread_ts="1234567890.123456",
            timestamp="1234567890.123456",
        )
        assert msg.text == "Hello world"
        assert msg.user_id == "U123456"
        assert msg.channel == "C789"

    def test_text_stripped(self):
        """Should strip text whitespace."""
        msg = SlackMessage(
            text="  Hello world  ",
            user_id="U123",
            channel="C123",
        )
        assert msg.text == "Hello world"

    def test_empty_text_rejected(self):
        """Should reject empty text."""
        with pytest.raises(ValidationError) as exc:
            SlackMessage(
                text="",
                user_id="U123",
                channel="C123",
            )
        assert "Message text cannot be empty" in str(exc.value)

    def test_whitespace_only_rejected(self):
        """Should reject whitespace-only text."""
        with pytest.raises(ValidationError) as exc:
            SlackMessage(
                text="   ",
                user_id="U123",
                channel="C123",
            )
        assert "Message text cannot be empty" in str(exc.value)

    def test_text_too_long(self):
        """Should reject text exceeding max length."""
        with pytest.raises(ValidationError) as exc:
            SlackMessage(
                text="x" * 40001,
                user_id="U123",
                channel="C123",
            )
        assert "at most 40000" in str(exc.value)

    def test_optional_fields(self):
        """Should allow optional fields to be None."""
        msg = SlackMessage(
            text="Hello",
            user_id="U123",
            channel="C123",
        )
        assert msg.thread_ts is None
        assert msg.timestamp is None

    def test_extra_fields_forbidden(self):
        """Should reject extra fields."""
        with pytest.raises(ValidationError):
            SlackMessage(
                text="Hello",
                user_id="U123",
                channel="C123",
                extra_field="not allowed",
            )


# =============================================================================
# SlackResponse Tests
# =============================================================================


class TestSlackResponse:
    """Tests for SlackResponse model."""

    def test_text_only_response(self):
        """Should accept text-only response."""
        resp = SlackResponse(text="Hello")
        assert resp.text == "Hello"
        assert resp.blocks is None

    def test_response_with_blocks(self):
        """Should accept response with blocks."""
        blocks = [{"type": "section", "text": {"type": "mrkdwn", "text": "Hello"}}]
        resp = SlackResponse(text="Hello", blocks=blocks)
        assert resp.blocks == blocks

    def test_empty_text_rejected(self):
        """Should reject empty text."""
        with pytest.raises(ValidationError):
            SlackResponse(text="")


# =============================================================================
# SlackUser Tests
# =============================================================================


class TestSlackUser:
    """Tests for SlackUser model."""

    def test_valid_user(self):
        """Should accept valid user."""
        user = SlackUser(
            id="U123456",
            name="john.doe",
            real_name="John Doe",
        )
        assert user.id == "U123456"
        assert user.name == "john.doe"
        assert user.real_name == "John Doe"

    def test_minimal_user(self):
        """Should accept minimal user."""
        user = SlackUser(id="U123")
        assert user.id == "U123"
        assert user.name is None
        assert user.real_name is None


# =============================================================================
# SlackConversationContext Tests
# =============================================================================


class TestSlackConversationContext:
    """Tests for SlackConversationContext model."""

    def test_valid_context(self):
        """Should accept valid context."""
        ctx = SlackConversationContext(
            user_id="U123",
            channel="C456",
            thread_ts="1234567890.123456",
        )
        assert ctx.user_id == "U123"
        assert ctx.channel == "C456"
        assert ctx.thread_ts == "1234567890.123456"

    def test_optional_thread_ts(self):
        """Should allow optional thread_ts."""
        ctx = SlackConversationContext(
            user_id="U123",
            channel="C456",
        )
        assert ctx.thread_ts is None


# =============================================================================
# CommandRequest Tests
# =============================================================================


class TestCommandRequest:
    """Tests for CommandRequest model."""

    def test_valid_command(self):
        """Should accept valid command."""
        cmd = CommandRequest(
            user_id="U123",
            channel_id="C456",
            command="/dv",
            text="ask What is the weather?",
        )
        assert cmd.user_id == "U123"
        assert cmd.command == "/dv"
        assert cmd.text == "ask What is the weather?"

    def test_empty_text_allowed(self):
        """Should allow empty text for commands like /dv help."""
        cmd = CommandRequest(
            user_id="U123",
            channel_id="C456",
            command="/dv",
            text="",
        )
        assert cmd.text == ""


# =============================================================================
# AI Disclosure Tests
# =============================================================================


class TestAIDisclosure:
    """Tests for AI disclosure constants."""

    def test_ai_disclosure_not_empty(self):
        """Should have non-empty AI disclosure."""
        assert AI_DISCLOSURE
        assert len(AI_DISCLOSURE) > 0

    def test_ai_disclosure_contains_ai(self):
        """Should mention AI in disclosure."""
        assert "AI" in AI_DISCLOSURE or "artificial" in AI_DISCLOSURE.lower()

    def test_ai_disclosure_block_valid(self):
        """Should have valid block structure."""
        assert AI_DISCLOSURE_BLOCK["type"] == "context"
        assert "elements" in AI_DISCLOSURE_BLOCK
        assert len(AI_DISCLOSURE_BLOCK["elements"]) > 0
