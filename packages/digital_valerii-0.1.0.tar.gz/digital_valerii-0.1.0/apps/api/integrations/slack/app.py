"""Slack Bolt app instance.

Creates and configures the Slack Bolt async app with FastAPI adapter.
"""

from typing import TYPE_CHECKING

import structlog
from slack_bolt.adapter.fastapi.async_handler import AsyncSlackRequestHandler
from slack_bolt.async_app import AsyncApp

from apps.api.config import settings

if TYPE_CHECKING:
    from apps.api.integrations.slack.services import SlackService

logger = structlog.get_logger(__name__)

# Track if handlers are registered
_handlers_registered = False


def create_slack_app() -> AsyncApp:
    """Create and configure Slack Bolt async app.

    Returns:
        Configured AsyncApp instance.
    """
    # Check if Slack is configured
    if not settings.slack_bot_token or not settings.slack_signing_secret:
        logger.warning(
            "Slack not configured",
            has_token=bool(settings.slack_bot_token),
            has_secret=bool(settings.slack_signing_secret),
        )
        # Return unconfigured app (will fail gracefully on requests)
        return AsyncApp(
            token="placeholder",
            signing_secret="placeholder",
            request_verification_enabled=False,
        )

    app = AsyncApp(
        token=settings.slack_bot_token,
        signing_secret=settings.slack_signing_secret,
        request_verification_enabled=True,
    )

    logger.info("Slack app created", configured=True)
    return app


def setup_slack_handlers(service: "SlackService") -> None:
    """Register Slack event handlers with the service.

    This should be called once during application startup after
    the SlackService is created with its dependencies.

    Args:
        service: SlackService instance for handling business logic.
    """
    global _handlers_registered  # noqa: PLW0603

    if _handlers_registered:
        logger.warning("Slack handlers already registered, skipping")
        return

    # Check if Slack is configured
    if not settings.slack_bot_token or not settings.slack_signing_secret:
        logger.warning("Slack not configured, handlers not registered")
        return

    # Import handlers here to avoid circular imports
    from apps.api.integrations.slack.handlers import (
        register_command_handlers,
        register_event_handlers,
        register_message_handlers,
    )

    # Register all handlers
    register_message_handlers(slack_app, service)
    register_command_handlers(slack_app, service)
    register_event_handlers(slack_app, service)

    _handlers_registered = True
    logger.info("Slack handlers registered successfully")


def reset_slack_handlers() -> None:
    """Reset handler registration state (for testing)."""
    global _handlers_registered  # noqa: PLW0603
    _handlers_registered = False


# Create the Slack app instance
slack_app = create_slack_app()

# FastAPI adapter for handling HTTP requests
slack_handler = AsyncSlackRequestHandler(slack_app)
