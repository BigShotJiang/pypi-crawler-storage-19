"""Slack integration exceptions."""


class SlackError(Exception):
    """Base exception for Slack integration errors."""

    def __init__(self, message: str = "Slack error occurred") -> None:
        self.message = message
        super().__init__(message)


class SlackRateLimitError(SlackError):
    """Raised when user exceeds rate limits."""

    def __init__(
        self,
        user_id: str,
        limit_type: str = "messages",
        retry_after: int = 60,
    ) -> None:
        self.user_id = user_id
        self.limit_type = limit_type
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit exceeded for {limit_type}. Retry after {retry_after} seconds."
        )


class SlackValidationError(SlackError):
    """Raised when input validation fails."""

    def __init__(self, field: str, reason: str) -> None:
        self.field = field
        self.reason = reason
        super().__init__(f"Validation error in {field}: {reason}")


class SlackAuthError(SlackError):
    """Raised when authentication/authorization fails."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message)


class SlackServiceError(SlackError):
    """Raised when service processing fails."""

    def __init__(self, message: str = "Service error occurred") -> None:
        super().__init__(message)
