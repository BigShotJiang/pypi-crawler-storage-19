"""Slack service for processing interactions.

Business logic for Slack bot interactions including message processing,
command handling, memory search, and rate limiting.
"""

from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

import structlog
from digital_valerii_shared.agent import DigitalValeriiAgent
from digital_valerii_shared.agent.core.context import ConversationContext, InterfaceType
from digital_valerii_shared.services.memory import MemoryManager
from digital_valerii_shared.services.redis import RedisService

from apps.api.config import RedisNamespace
from apps.api.integrations.slack.config import slack_settings
from apps.api.integrations.slack.models import SlackConversationContext, SlackResponse

if TYPE_CHECKING:
    from digital_valerii_shared.services.session_manager import UnifiedSessionManager

logger = structlog.get_logger(__name__)


class SlackService:
    """Service for processing Slack interactions.

    Handles message processing, command execution, memory search,
    and rate limiting for the Slack bot.
    """

    def __init__(
        self,
        agent: DigitalValeriiAgent,
        memory: MemoryManager,
        redis: RedisService,
        session_manager: "UnifiedSessionManager | None" = None,
    ) -> None:
        """Initialize Slack service.

        Args:
            agent: Digital Valerii agent for processing messages.
            memory: Memory manager for memory search.
            redis: Redis service for rate limiting and context storage.
            session_manager: Optional unified session manager for cross-channel sessions.
        """
        self._agent = agent
        self._memory = memory
        self._redis = redis
        self._session_manager = session_manager
        self._conversation_contexts: dict[str, SlackConversationContext] = {}
        # Mapping from Slack user ID to internal user UUID (populated via integration)
        self._user_id_mapping: dict[str, UUID] = {}

    async def process_message(
        self,
        user_id: str,
        text: str,
        channel: str,
        thread_ts: str | None = None,
    ) -> SlackResponse:
        """Process a message through the agent.

        Args:
            user_id: Slack user ID.
            text: Message text.
            channel: Channel ID.
            thread_ts: Thread timestamp for context continuity.

        Returns:
            SlackResponse with text and optional blocks.
        """
        await logger.ainfo(
            "Processing message",
            user_id=user_id,
            channel=channel,
            text_length=len(text),
        )

        # Get or create conversation context
        context = await self._get_or_create_context(
            user_id=user_id,
            channel=channel,
            thread_ts=thread_ts,
        )

        # Process through agent
        try:
            response = await self._agent.chat(
                message=text,
                context=context,
            )

            # Format response for Slack (max chars)
            formatted_text = self._format_response(response.message)

            return SlackResponse(text=formatted_text)

        except Exception as e:
            await logger.aerror(
                "Agent processing failed",
                user_id=user_id,
                error=str(e),
                exc_info=True,
            )
            return SlackResponse(
                text="I'm having trouble processing your request. Please try again."
            )

    async def process_command_ask(
        self,
        user_id: str,
        question: str,
        channel_id: str,
    ) -> SlackResponse:
        """Process /dv ask command.

        Args:
            user_id: Slack user ID.
            question: Question to ask.
            channel_id: Channel ID where command was invoked.

        Returns:
            SlackResponse with answer.
        """
        # Commands don't have thread context, create ephemeral session
        context = await self._create_ephemeral_context(user_id, channel_id)

        try:
            response = await self._agent.chat(
                message=question,
                context=context,
            )

            return SlackResponse(text=self._format_response(response.message))

        except Exception as e:
            await logger.aerror(
                "Ask command failed",
                user_id=user_id,
                error=str(e),
                exc_info=True,
            )
            return SlackResponse(
                text="I'm having trouble answering your question. Please try again."
            )

    async def search_memory(
        self,
        user_id: str,
        query: str,
    ) -> SlackResponse:
        """Search memory and return formatted results.

        Args:
            user_id: Slack user ID.
            query: Search query.

        Returns:
            SlackResponse with search results.
        """
        await logger.ainfo(
            "Searching memory",
            user_id=user_id,
            query=query,
        )

        try:
            results = await self._memory.recall(
                query=query,
                limit=5,
            )

            if not results.events:
                return SlackResponse(text=f"No memories found for: _{query}_")

            # Format as Slack blocks
            blocks = [
                {
                    "type": "header",
                    "text": {"type": "plain_text", "text": f"Memory Search: {query}"},
                },
                {"type": "divider"},
            ]

            for event in results.events[:5]:
                content_preview = (
                    event.content[:200] + "..."
                    if len(event.content) > 200
                    else event.content
                )
                timestamp = (
                    event.timestamp.strftime("%Y-%m-%d")
                    if event.timestamp
                    else "Unknown"
                )
                blocks.append(
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*{event.event_type}* ({timestamp})\n{content_preview}",
                        },
                    }
                )

            text = f"Found {len(results.events)} memories for '{query}'"
            return SlackResponse(text=text, blocks=blocks)

        except Exception as e:
            await logger.aerror(
                "Memory search failed",
                user_id=user_id,
                query=query,
                error=str(e),
                exc_info=True,
            )
            return SlackResponse(text="Failed to search memory. Please try again.")

    async def get_status(self) -> SlackResponse:
        """Get bot status.

        Returns:
            SlackResponse with status information.
        """
        now = datetime.now(UTC)
        status_text = f"""*Digital Valerii Status*

:white_check_mark: Bot: Online
:white_check_mark: Agent: Ready
:white_check_mark: Memory: Connected

_Last checked: {now.strftime('%Y-%m-%d %H:%M UTC')}_"""

        return SlackResponse(text=status_text)

    async def check_rate_limit(
        self,
        user_id: str,
        limit_type: str = "messages",
    ) -> bool:
        """Check if user is within rate limits.

        Args:
            user_id: Slack user ID.
            limit_type: Type of limit ("messages" or "commands").

        Returns:
            True if allowed, False if rate limited.
        """
        if limit_type == "messages":
            max_requests = slack_settings.rate_limit_messages_per_minute
        else:
            max_requests = slack_settings.rate_limit_commands_per_minute

        window_seconds = 60

        key = f"{RedisNamespace.SLACK_RATE_LIMIT}{limit_type}:{user_id}"

        try:
            current = await self._redis.increment(key)

            if current == 1:
                await self._redis.expire(key, window_seconds)

            is_allowed = current <= max_requests

            if not is_allowed:
                await logger.awarning(
                    "Rate limit exceeded",
                    user_id=user_id,
                    limit_type=limit_type,
                    current=current,
                    max_requests=max_requests,
                )

            return is_allowed

        except Exception as e:
            await logger.aerror(
                "Rate limit check failed",
                user_id=user_id,
                error=str(e),
            )
            # Allow request on error (fail open)
            return True

    def _format_response(
        self,
        text: str,
        max_length: int | None = None,
    ) -> str:
        """Format response for Slack, respecting length limits.

        Args:
            text: Response text.
            max_length: Maximum length (defaults to setting).

        Returns:
            Formatted text.
        """
        if max_length is None:
            max_length = slack_settings.max_message_length

        if len(text) <= max_length:
            return text

        # Truncate and add ellipsis
        return text[: max_length - 20] + "\n\n_(truncated)_"

    async def _get_or_create_context(
        self,
        user_id: str,
        channel: str,
        thread_ts: str | None,
    ) -> ConversationContext:
        """Get or create conversation context for thread.

        Uses thread_ts as session identifier for thread continuity.

        Args:
            user_id: Slack user ID.
            channel: Channel ID.
            thread_ts: Thread timestamp.

        Returns:
            ConversationContext for the agent.
        """
        # Use thread_ts as context key for continuity
        context_key = f"{channel}:{thread_ts}" if thread_ts else f"{channel}:{user_id}"

        # Try to get existing context from Redis
        redis_key = f"{RedisNamespace.SLACK_CONVERSATIONS}{context_key}"
        stored = await self._redis.cache_get(redis_key)

        if stored and isinstance(stored, dict):
            # Restore context
            context = ConversationContext(
                conversation_id=stored.get("conversation_id", uuid4()),
                interface=InterfaceType.SLACK,
                session_id=stored.get("session_id"),
            )
            context.add_metadata("slack_user_id", user_id)
            context.add_metadata("slack_channel", channel)
            context.add_metadata("slack_thread_ts", thread_ts)
            return context

        # Create new context
        context = ConversationContext(
            conversation_id=uuid4(),
            interface=InterfaceType.SLACK,
        )
        context.add_metadata("slack_user_id", user_id)
        context.add_metadata("slack_channel", channel)
        context.add_metadata("slack_thread_ts", thread_ts)

        # Store context (TTL: 1 hour for conversation continuity)
        await self._redis.cache_set(
            redis_key,
            {
                "conversation_id": str(context.conversation_id),
                "session_id": context.session_id,
            },
            ttl=3600,
        )

        return context

    async def _create_ephemeral_context(
        self,
        user_id: str,
        channel_id: str,
    ) -> ConversationContext:
        """Create ephemeral context for one-off commands.

        Args:
            user_id: Slack user ID.
            channel_id: Channel ID.

        Returns:
            New ConversationContext without session persistence.
        """
        context = ConversationContext(
            conversation_id=uuid4(),
            interface=InterfaceType.SLACK,
        )
        context.add_metadata("slack_user_id", user_id)
        context.add_metadata("slack_channel", channel_id)
        context.add_metadata("ephemeral", True)
        return context

    # =========================================================================
    # Session Manager Integration (Component 4.8)
    # =========================================================================

    def set_session_manager(
        self,
        session_manager: "UnifiedSessionManager",
    ) -> None:
        """Set session manager for cross-channel session support.

        Args:
            session_manager: Unified session manager instance.
        """
        self._session_manager = session_manager

    def register_user_mapping(
        self,
        slack_user_id: str,
        internal_user_id: UUID,
    ) -> None:
        """Register mapping between Slack user ID and internal user UUID.

        Args:
            slack_user_id: Slack user ID (e.g., "U123ABC").
            internal_user_id: Internal system user UUID.
        """
        self._user_id_mapping[slack_user_id] = internal_user_id

    def get_internal_user_id(self, slack_user_id: str) -> UUID | None:
        """Get internal user UUID for a Slack user ID.

        Args:
            slack_user_id: Slack user ID.

        Returns:
            Internal user UUID or None if not mapped.
        """
        return self._user_id_mapping.get(slack_user_id)

    async def enqueue_slack_message(
        self,
        slack_user_id: str,
        text: str,
        channel: str,
        thread_ts: str | None = None,
    ) -> UUID | None:
        """Enqueue a Slack message using the session manager.

        This method uses the unified session manager to enqueue messages,
        enabling cross-channel session continuity.

        Args:
            slack_user_id: Slack user ID.
            text: Message text.
            channel: Slack channel ID.
            thread_ts: Optional thread timestamp.

        Returns:
            Message UUID if enqueued, None if no session manager or user mapping.
        """
        if not self._session_manager:
            await logger.adebug(
                "Session manager not configured, skipping enqueue",
                slack_user_id=slack_user_id,
            )
            return None

        internal_user_id = self.get_internal_user_id(slack_user_id)
        if not internal_user_id:
            await logger.adebug(
                "No user mapping found, skipping enqueue",
                slack_user_id=slack_user_id,
            )
            return None

        try:
            # Note: Slack doesn't have SDK session IDs (those are specific to Claude SDK web API).
            # Passing None explicitly to be clear about the intent.
            message_id = await self._session_manager.enqueue_message(
                user_id=internal_user_id,
                channel="slack",
                content=text,
                metadata={
                    "slack_channel": channel,
                    "thread_ts": thread_ts,
                    "slack_user_id": slack_user_id,
                },
                sdk_session_id=None,  # Slack doesn't use SDK sessions
            )

            await logger.ainfo(
                "Slack message enqueued to session manager",
                message_id=str(message_id),
                slack_user_id=slack_user_id,
                internal_user_id=str(internal_user_id),
            )

            return message_id

        except Exception as e:
            await logger.aerror(
                "Failed to enqueue Slack message",
                slack_user_id=slack_user_id,
                error=str(e),
            )
            return None

    async def get_user_session_info(
        self,
        slack_user_id: str,
    ) -> dict | None:
        """Get session info for a Slack user.

        Args:
            slack_user_id: Slack user ID.

        Returns:
            Session info dict or None.
        """
        if not self._session_manager:
            return None

        internal_user_id = self.get_internal_user_id(slack_user_id)
        if not internal_user_id:
            return None

        try:
            session = await self._session_manager.get_session(internal_user_id)
            if not session:
                return None

            queue_length = await self._session_manager.get_queue_length(
                internal_user_id
            )

            return {
                "session_id": str(session.id),
                "status": session.status.value,
                "last_channel": session.last_channel,
                "compact_count": session.compact_count,
                "pending_messages": queue_length,
            }

        except Exception as e:
            await logger.aerror(
                "Failed to get session info",
                slack_user_id=slack_user_id,
                error=str(e),
            )
            return None

    async def start_new_session(
        self,
        slack_user_id: str,
    ) -> SlackResponse:
        """Start a new session for a Slack user (/dv new command).

        Archives current session and creates a fresh one.

        Args:
            slack_user_id: Slack user ID.

        Returns:
            SlackResponse with confirmation message.
        """
        if not self._session_manager:
            return SlackResponse(
                text="Session management is not configured. Using default conversation mode."
            )

        internal_user_id = self.get_internal_user_id(slack_user_id)
        if not internal_user_id:
            return SlackResponse(
                text="User not linked to session management. Using default conversation mode."
            )

        try:
            session = await self._session_manager.start_new_session(internal_user_id)

            await logger.ainfo(
                "Started new session via Slack",
                slack_user_id=slack_user_id,
                session_id=str(session.id),
            )

            return SlackResponse(
                text=f":sparkles: Нова сесія розпочата!\n\n"
                f"Session ID: `{str(session.id)[:8]}...`\n"
                f"Previous session has been archived."
            )

        except Exception as e:
            await logger.aerror(
                "Failed to start new session",
                slack_user_id=slack_user_id,
                error=str(e),
            )
            return SlackResponse(text="Failed to start new session. Please try again.")
