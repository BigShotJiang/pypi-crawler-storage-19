"""Slack services."""

from apps.api.integrations.slack.services.slack_service import SlackService

__all__ = ["SlackService"]
