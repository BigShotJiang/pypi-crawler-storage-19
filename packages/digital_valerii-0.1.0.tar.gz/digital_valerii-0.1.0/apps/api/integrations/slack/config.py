"""Slack integration settings."""

from pydantic import Field
from pydantic_settings import BaseSettings


class SlackSettings(BaseSettings):
    """Slack integration settings."""

    # Bot credentials (loaded from main config)
    bot_token: str = Field(default="", validation_alias="SLACK_BOT_TOKEN")
    signing_secret: str = Field(default="", validation_alias="SLACK_SIGNING_SECRET")
    app_token: str = Field(
        default="", validation_alias="SLACK_APP_TOKEN"
    )  # For Socket Mode

    # Rate limits
    rate_limit_messages_per_minute: int = 50
    rate_limit_commands_per_minute: int = 20

    # Behavior
    max_message_length: int = 3000  # Slack limit is 4000, leave room for formatting
    typing_indicator_enabled: bool = True
    thread_replies_enabled: bool = True
    ai_disclosure_enabled: bool = True  # EU AI Act Art.50 compliance

    # Timeouts
    response_timeout_seconds: int = 25  # Slack requires response within 3s, use async

    model_config = {
        "env_file": (".env",),
        "extra": "ignore",  # Allow other env vars from .env file
    }


slack_settings = SlackSettings()
