"""Slack API routes.

Provides endpoints for Slack webhooks:
- POST /slack/events - Event subscriptions (messages, mentions)
- POST /slack/commands - Slash commands
- POST /slack/interactions - Interactive components (buttons, modals)
"""

from fastapi import APIRouter, Request

from apps.api.integrations.slack.app import slack_handler

router = APIRouter(prefix="/slack", tags=["slack"])


@router.post("/events")
async def slack_events(request: Request):
    """Handle Slack events (messages, mentions, etc.).

    This endpoint receives event subscriptions from Slack including:
    - message.im: Direct messages to the bot
    - app_mention: @mentions of the bot in channels

    Slack verifies the endpoint by sending a challenge request during setup.
    """
    return await slack_handler.handle(request)


@router.post("/commands")
async def slack_commands(request: Request):
    """Handle Slack slash commands.

    This endpoint receives slash command invocations, primarily /dv.
    Commands must acknowledge within 3 seconds.
    """
    return await slack_handler.handle(request)


@router.post("/interactions")
async def slack_interactions(request: Request):
    """Handle Slack interactive components.

    This endpoint receives interactions from:
    - Button clicks
    - Modal submissions
    - Shortcut invocations
    """
    return await slack_handler.handle(request)
