"""Slack Bot integration.

Provides Slack Bot interface for Digital Valerii using Slack Bolt SDK.
Supports direct messages, @mentions, and slash commands.
"""

from apps.api.integrations.slack.app import (
    reset_slack_handlers,
    setup_slack_handlers,
    slack_app,
    slack_handler,
)
from apps.api.integrations.slack.exceptions import (
    SlackError,
    SlackRateLimitError,
    SlackValidationError,
)
from apps.api.integrations.slack.models import SlackMessage, SlackResponse
from apps.api.integrations.slack.services.slack_service import SlackService

__all__ = [
    # App
    "slack_app",
    "slack_handler",
    "setup_slack_handlers",
    "reset_slack_handlers",
    # Service
    "SlackService",
    # Models
    "SlackMessage",
    "SlackResponse",
    # Exceptions
    "SlackError",
    "SlackRateLimitError",
    "SlackValidationError",
]
