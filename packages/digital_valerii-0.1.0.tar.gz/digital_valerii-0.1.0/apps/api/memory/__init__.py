"""Memory module - persistent storage."""
