"""Health endpoint tests."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from apps.api.dependencies import get_db_session
from apps.api.main import app


@pytest.fixture
def client() -> TestClient:
    """Create test client with mocked database."""
    mock_session = MagicMock()
    mock_session.execute = AsyncMock()

    async def mock_get_db():
        yield mock_session

    app.dependency_overrides[get_db_session] = mock_get_db

    yield TestClient(app, raise_server_exceptions=False)

    app.dependency_overrides.clear()


def test_health_endpoint(client: TestClient) -> None:
    """Test health endpoint returns OK."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"


def test_root_endpoint(client: TestClient) -> None:
    """Test root endpoint returns API info."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Digital Valerii API"
    assert data["status"] == "running"
