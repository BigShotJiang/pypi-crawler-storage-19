"""Middleware tests."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from starlette.requests import Request

from apps.api.middleware.auth import AuthMiddleware
from apps.api.middleware.rate_limit import RateLimitMiddleware
from apps.api.middleware.size_limit import RequestSizeLimitMiddleware

# =============================================================================
# Auth Middleware Tests
# =============================================================================


class TestAuthMiddleware:
    """Tests for AuthMiddleware."""

    @pytest.fixture
    def app_with_auth(self) -> FastAPI:
        """Create test app with auth middleware."""
        app = FastAPI()
        app.add_middleware(AuthMiddleware)

        @app.get("/api/v1/test")
        async def test_endpoint() -> dict:
            return {"status": "ok"}

        @app.get("/health")
        async def health_endpoint() -> dict:
            return {"status": "healthy"}

        @app.get("/")
        async def root_endpoint() -> dict:
            return {"status": "root"}

        return app

    def test_auth_skip_health_endpoint(self, app_with_auth: FastAPI) -> None:
        """Test health endpoint skips auth."""
        client = TestClient(app_with_auth)
        response = client.get("/health")
        assert response.status_code == 200

    def test_auth_skip_root_endpoint(self, app_with_auth: FastAPI) -> None:
        """Test root endpoint skips auth."""
        client = TestClient(app_with_auth)
        response = client.get("/")
        assert response.status_code == 200

    @patch("apps.api.middleware.auth.settings")
    def test_auth_no_api_key_dev_mode(
        self, mock_settings: MagicMock, app_with_auth: FastAPI
    ) -> None:
        """Test auth skipped when no api_key configured in development."""
        mock_settings.api_key = ""
        mock_settings.app_env = "development"

        client = TestClient(app_with_auth)
        response = client.get("/api/v1/test")
        assert response.status_code == 200

    @patch("apps.api.middleware.auth.settings")
    def test_auth_no_api_key_production_fails(
        self, mock_settings: MagicMock, app_with_auth: FastAPI
    ) -> None:
        """Test auth fails closed in production when no api_key configured."""
        mock_settings.api_key = ""
        mock_settings.app_env = "production"

        client = TestClient(app_with_auth)
        response = client.get("/api/v1/test")
        assert response.status_code == 500
        assert response.json()["detail"] == "Server configuration error"

    @patch("apps.api.middleware.auth.settings")
    def test_auth_valid_api_key(
        self, mock_settings: MagicMock, app_with_auth: FastAPI
    ) -> None:
        """Test auth succeeds with valid API key."""
        mock_settings.api_key = "secret-key"
        mock_settings.app_env = "production"

        client = TestClient(app_with_auth)
        response = client.get("/api/v1/test", headers={"X-API-Key": "secret-key"})
        assert response.status_code == 200

    @patch("apps.api.middleware.auth.settings")
    def test_auth_invalid_api_key(
        self, mock_settings: MagicMock, app_with_auth: FastAPI
    ) -> None:
        """Test auth fails with invalid API key."""
        mock_settings.api_key = "secret-key"
        mock_settings.app_env = "production"

        client = TestClient(app_with_auth)
        response = client.get("/api/v1/test", headers={"X-API-Key": "wrong-key"})
        assert response.status_code == 401
        assert response.json()["detail"] == "Invalid authentication credentials"

    @patch("apps.api.middleware.auth.settings")
    def test_auth_missing_api_key(
        self, mock_settings: MagicMock, app_with_auth: FastAPI
    ) -> None:
        """Test auth fails with missing API key."""
        mock_settings.api_key = "secret-key"
        mock_settings.app_env = "production"

        client = TestClient(app_with_auth)
        response = client.get("/api/v1/test")
        assert response.status_code == 401
        assert response.json()["detail"] == "Invalid authentication credentials"

    def test_auth_uses_constant_time_comparison(self) -> None:
        """Test that secrets.compare_digest is used for timing attack prevention."""
        import secrets

        # Verify compare_digest is imported and used in auth module
        from apps.api.middleware import auth

        assert hasattr(auth, "secrets")
        assert hasattr(auth.secrets, "compare_digest")
        # Verify the function exists and works
        assert secrets.compare_digest("test", "test") is True
        assert secrets.compare_digest("test", "other") is False


# =============================================================================
# Size Limit Middleware Tests
# =============================================================================


class TestRequestSizeLimitMiddleware:
    """Tests for RequestSizeLimitMiddleware."""

    @pytest.fixture
    def app_with_size_limit(self) -> FastAPI:
        """Create test app with size limit middleware."""
        app = FastAPI()
        app.add_middleware(RequestSizeLimitMiddleware)

        @app.post("/api/v1/test")
        async def test_endpoint() -> dict:
            return {"status": "ok"}

        return app

    @patch("apps.api.middleware.size_limit.settings")
    def test_size_limit_within_limit(
        self, mock_settings: MagicMock, app_with_size_limit: FastAPI
    ) -> None:
        """Test request within size limit passes."""
        mock_settings.max_request_size_bytes = 1000

        client = TestClient(app_with_size_limit)
        response = client.post(
            "/api/v1/test",
            content="x" * 100,
            headers={"Content-Length": "100"},
        )
        assert response.status_code == 200

    @patch("apps.api.middleware.size_limit.settings")
    def test_size_limit_exceeds_limit(
        self, mock_settings: MagicMock, app_with_size_limit: FastAPI
    ) -> None:
        """Test request exceeding size limit rejected."""
        mock_settings.max_request_size_bytes = 100

        client = TestClient(app_with_size_limit)
        response = client.post(
            "/api/v1/test",
            content="x" * 200,
            headers={"Content-Length": "200"},
        )
        assert response.status_code == 413
        assert response.json()["detail"] == "Request body too large"

    @patch("apps.api.middleware.size_limit.settings")
    def test_size_limit_get_no_content_length_passes(
        self, mock_settings: MagicMock, app_with_size_limit: FastAPI
    ) -> None:
        """Test GET request without content-length passes (no body expected)."""
        mock_settings.max_request_size_bytes = 100

        client = TestClient(app_with_size_limit)
        # GET request has no content-length - should pass
        response = client.get("/api/v1/test")
        # Will return 405 (Method Not Allowed) but should not be 411 or 413
        assert response.status_code not in (411, 413)

    def test_size_limit_post_requires_content_length(
        self, app_with_size_limit: FastAPI
    ) -> None:
        """Test POST without Content-Length returns 411."""
        # httpx/TestClient always adds Content-Length, so we need to mock
        # Just verify the middleware has the check
        _ = app_with_size_limit  # Use fixture to satisfy pytest
        from apps.api.middleware.size_limit import RequestSizeLimitMiddleware

        assert "POST" in RequestSizeLimitMiddleware.BODY_METHODS
        assert "PUT" in RequestSizeLimitMiddleware.BODY_METHODS
        assert "PATCH" in RequestSizeLimitMiddleware.BODY_METHODS


# =============================================================================
# Rate Limit Middleware Tests
# =============================================================================


class TestRateLimitMiddleware:
    """Tests for RateLimitMiddleware."""

    @pytest.fixture
    def app_with_rate_limit(self) -> FastAPI:
        """Create test app with rate limit middleware."""
        app = FastAPI()
        app.add_middleware(RateLimitMiddleware)

        @app.get("/api/v1/test")
        async def test_endpoint() -> dict:
            return {"status": "ok"}

        @app.get("/health")
        async def health_endpoint() -> dict:
            return {"status": "healthy"}

        return app

    def test_rate_limit_skip_health(self, app_with_rate_limit: FastAPI) -> None:
        """Test health endpoint skips rate limiting."""
        client = TestClient(app_with_rate_limit)
        response = client.get("/health")
        assert response.status_code == 200
        # Should not have rate limit header
        assert "X-RateLimit-Remaining" not in response.headers

    @patch("apps.api.middleware.rate_limit.RateLimitMiddleware._check_rate_limit")
    def test_rate_limit_within_limit(
        self, mock_check: AsyncMock, app_with_rate_limit: FastAPI
    ) -> None:
        """Test request within rate limit passes."""
        mock_check.return_value = (99, False)

        client = TestClient(app_with_rate_limit)
        response = client.get("/api/v1/test")
        assert response.status_code == 200
        assert response.headers["X-RateLimit-Remaining"] == "99"

    @patch("apps.api.middleware.rate_limit.RateLimitMiddleware._check_rate_limit")
    def test_rate_limit_exceeded(
        self, mock_check: AsyncMock, app_with_rate_limit: FastAPI
    ) -> None:
        """Test request exceeding rate limit rejected."""
        mock_check.return_value = (0, True)

        client = TestClient(app_with_rate_limit)
        response = client.get("/api/v1/test")
        assert response.status_code == 429
        assert response.json()["detail"] == "Rate limit exceeded"
        assert response.headers["X-RateLimit-Remaining"] == "0"

    @patch("apps.api.middleware.rate_limit.RateLimitMiddleware._check_rate_limit")
    def test_rate_limit_redis_error_fails_open(
        self, mock_check: AsyncMock, app_with_rate_limit: FastAPI
    ) -> None:
        """Test rate limit fails open on Redis error."""
        mock_check.side_effect = Exception("Redis connection error")

        client = TestClient(app_with_rate_limit)
        response = client.get("/api/v1/test")
        # Should pass (fail open)
        assert response.status_code == 200

    def test_rate_limit_get_client_ip_direct(self) -> None:
        """Test getting client IP from direct connection."""
        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {}
        request.client = MagicMock()
        request.client.host = "192.168.1.1"

        ip = middleware._get_client_ip(request)
        assert ip == "192.168.1.1"

    def test_rate_limit_get_client_ip_forwarded(self) -> None:
        """Test getting client IP from X-Forwarded-For header."""
        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {"X-Forwarded-For": "10.0.0.1, 10.0.0.2"}
        request.client = MagicMock()
        request.client.host = "192.168.1.1"

        ip = middleware._get_client_ip(request)
        assert ip == "10.0.0.1"

    def test_rate_limit_get_client_ip_unknown(self) -> None:
        """Test getting client IP when no client info."""
        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {}
        request.client = None

        ip = middleware._get_client_ip(request)
        assert ip == "unknown"

    @patch("apps.api.middleware.rate_limit.settings")
    def test_rate_limit_valid_api_key_uses_key(self, mock_settings: MagicMock) -> None:
        """Test valid API key uses key-based rate limiting."""
        mock_settings.api_key = "valid-key"

        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {"X-API-Key": "valid-key"}
        request.client = MagicMock()
        request.client.host = "192.168.1.1"

        client_id = middleware._get_client_id(request)
        assert client_id == "key:valid-key"

    @patch("apps.api.middleware.rate_limit.settings")
    def test_rate_limit_invalid_api_key_uses_ip(self, mock_settings: MagicMock) -> None:
        """Test invalid API key falls back to IP-based rate limiting."""
        mock_settings.api_key = "valid-key"

        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {"X-API-Key": "wrong-key"}
        request.client = MagicMock()
        request.client.host = "192.168.1.1"

        client_id = middleware._get_client_id(request)
        assert client_id == "ip:192.168.1.1"

    @patch("apps.api.middleware.rate_limit.settings")
    def test_rate_limit_no_api_key_uses_ip(self, mock_settings: MagicMock) -> None:
        """Test missing API key uses IP-based rate limiting."""
        mock_settings.api_key = "valid-key"

        middleware = RateLimitMiddleware(app=MagicMock())

        request = MagicMock(spec=Request)
        request.headers = {}
        request.client = MagicMock()
        request.client.host = "192.168.1.1"

        client_id = middleware._get_client_id(request)
        assert client_id == "ip:192.168.1.1"

    @patch("apps.api.middleware.rate_limit.settings")
    def test_rate_limit_rotating_keys_same_ip(self, mock_settings: MagicMock) -> None:
        """Test rotating invalid keys from same IP still use IP-based limit."""
        mock_settings.api_key = "valid-key"

        middleware = RateLimitMiddleware(app=MagicMock())

        # First request with invalid key
        request1 = MagicMock(spec=Request)
        request1.headers = {"X-API-Key": "fake-key-1"}
        request1.client = MagicMock()
        request1.client.host = "10.0.0.1"

        # Second request with different invalid key from same IP
        request2 = MagicMock(spec=Request)
        request2.headers = {"X-API-Key": "fake-key-2"}
        request2.client = MagicMock()
        request2.client.host = "10.0.0.1"

        # Both should use same IP-based client_id
        client_id1 = middleware._get_client_id(request1)
        client_id2 = middleware._get_client_id(request2)

        assert client_id1 == "ip:10.0.0.1"
        assert client_id2 == "ip:10.0.0.1"
        assert client_id1 == client_id2  # Same limit bucket


# =============================================================================
# CORS Validation Tests
# =============================================================================


class TestCORSValidation:
    """Tests for CORS wildcard validation."""

    def test_cors_wildcard_warning(self) -> None:
        """Test CORS wildcard triggers warning."""
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            # Simulate the validation logic
            cors_origins = ["*"]
            if "*" in cors_origins:
                warnings.warn(
                    "CORS wildcard '*' detected - credentials disabled for security",
                    UserWarning,
                    stacklevel=1,
                )

            assert len(w) == 1
            assert "CORS wildcard" in str(w[0].message)

    def test_cors_specific_origins_no_warning(self) -> None:
        """Test specific CORS origins don't trigger warning."""
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            cors_origins = ["http://localhost:3000"]
            if "*" in cors_origins:
                warnings.warn(
                    "CORS wildcard '*' detected - credentials disabled for security",
                    UserWarning,
                    stacklevel=1,
                )

            assert len(w) == 0
