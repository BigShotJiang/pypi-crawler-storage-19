"""Chat endpoint tests."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from digital_valerii_shared.agent.core.models import AgentResponse, AgentStatus
from fastapi.testclient import TestClient


@pytest.fixture
def mock_agent() -> MagicMock:
    """Create a mock agent."""
    agent = MagicMock()
    agent.chat = AsyncMock(
        return_value=AgentResponse(
            status=AgentStatus.COMPLETE,
            message="Hello! How can I help you?",
            session_id="test-session",
            tokens_used=100,
            tools_used=(),
        )
    )
    return agent


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    memory = MagicMock()
    memory.get_working_memory = AsyncMock(return_value=None)
    memory.clear_working_memory = AsyncMock()
    return memory


@pytest.fixture
def client(mock_agent: MagicMock, mock_memory_manager: MagicMock) -> TestClient:
    """Create test client with mocked dependencies."""
    from apps.api.dependencies import get_agent, get_memory_manager
    from apps.api.main import app

    app.dependency_overrides[get_agent] = lambda: mock_agent
    app.dependency_overrides[get_memory_manager] = lambda: mock_memory_manager

    yield TestClient(app, raise_server_exceptions=False)

    app.dependency_overrides.clear()


class TestSendMessage:
    """Tests for POST /api/v1/chat/message."""

    def test_send_message_success(
        self, client: TestClient, mock_agent: MagicMock
    ) -> None:
        """Test sending a message returns response."""
        response = client.post(
            "/api/v1/chat/message",
            json={"message": "Hello"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["message"] == "Hello! How can I help you?"
        assert "conversation_id" in data
        assert "created_at" in data
        assert data["tokens_used"] == 100

    def test_send_message_with_conversation_id(
        self, client: TestClient, mock_agent: MagicMock
    ) -> None:
        """Test sending a message with existing conversation."""
        conv_id = str(uuid4())
        response = client.post(
            "/api/v1/chat/message",
            json={"message": "Hello", "conversation_id": conv_id},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["conversation_id"] == conv_id

    def test_send_message_with_session_id(
        self, client: TestClient, mock_agent: MagicMock
    ) -> None:
        """Test sending a message with custom session."""
        response = client.post(
            "/api/v1/chat/message",
            json={"message": "Hello", "session_id": "custom-session"},
        )

        assert response.status_code == 200

    def test_send_message_empty_message(self, client: TestClient) -> None:
        """Test empty message returns validation error."""
        response = client.post(
            "/api/v1/chat/message",
            json={"message": ""},
        )

        assert response.status_code == 422

    def test_send_message_too_long(self, client: TestClient) -> None:
        """Test message over limit returns validation error."""
        response = client.post(
            "/api/v1/chat/message",
            json={"message": "x" * 10001},
        )

        assert response.status_code == 422

    def test_send_message_extra_fields_forbidden(self, client: TestClient) -> None:
        """Test extra fields are rejected."""
        response = client.post(
            "/api/v1/chat/message",
            json={"message": "Hello", "extra_field": "not allowed"},
        )

        assert response.status_code == 422


class TestListConversations:
    """Tests for GET /api/v1/chat/conversations."""

    def test_list_conversations_empty(self, client: TestClient) -> None:
        """Test listing returns empty list."""
        response = client.get("/api/v1/chat/conversations")

        assert response.status_code == 200
        assert response.json() == []

    def test_list_conversations_with_limit(self, client: TestClient) -> None:
        """Test listing with limit parameter."""
        response = client.get("/api/v1/chat/conversations?limit=10")

        assert response.status_code == 200

    def test_list_conversations_invalid_limit(self, client: TestClient) -> None:
        """Test invalid limit returns error."""
        response = client.get("/api/v1/chat/conversations?limit=0")

        assert response.status_code == 422


class TestGetConversation:
    """Tests for GET /api/v1/chat/conversations/{id}."""

    def test_get_conversation_not_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting non-existent conversation returns 404."""
        mock_memory_manager.get_working_memory.return_value = None
        conv_id = uuid4()

        response = client.get(f"/api/v1/chat/conversations/{conv_id}")

        assert response.status_code == 404
        assert response.json()["detail"] == "Conversation not found"

    def test_get_conversation_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting existing conversation returns details."""
        conv_id = uuid4()
        now = datetime.now(UTC)

        # Create mock working memory
        mock_wm = MagicMock()
        mock_wm.messages = [{"role": "user", "content": "Hello"}]
        mock_wm.updated_at = now
        mock_memory_manager.get_working_memory = AsyncMock(return_value=mock_wm)

        response = client.get(f"/api/v1/chat/conversations/{conv_id}")

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == str(conv_id)
        assert len(data["messages"]) == 1

    def test_get_conversation_invalid_uuid(self, client: TestClient) -> None:
        """Test invalid UUID returns 422."""
        response = client.get("/api/v1/chat/conversations/invalid-uuid")

        assert response.status_code == 422


class TestDeleteConversation:
    """Tests for DELETE /api/v1/chat/conversations/{id}."""

    def test_delete_conversation_success(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test deleting conversation succeeds."""
        conv_id = uuid4()

        response = client.delete(f"/api/v1/chat/conversations/{conv_id}")

        assert response.status_code == 200
        assert response.json()["message"] == "Conversation deleted"
        mock_memory_manager.clear_working_memory.assert_called_once_with(str(conv_id))

    def test_delete_conversation_invalid_uuid(self, client: TestClient) -> None:
        """Test invalid UUID returns 422."""
        response = client.delete("/api/v1/chat/conversations/not-a-uuid")

        assert response.status_code == 422
