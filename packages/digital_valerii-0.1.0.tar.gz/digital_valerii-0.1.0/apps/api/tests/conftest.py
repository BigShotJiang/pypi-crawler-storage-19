"""Pytest configuration and fixtures."""

from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from apps.api.main import app


@pytest.fixture
def base_client() -> Generator[TestClient, None, None]:
    """Create base test client without mocks.

    Use this for health check and root endpoint tests.
    """
    yield TestClient(app, raise_server_exceptions=False)


@pytest.fixture
def mock_db_session() -> MagicMock:
    """Create mock database session."""
    session = MagicMock()
    session.execute = AsyncMock()
    session.commit = AsyncMock()
    session.rollback = AsyncMock()
    return session
