"""Memory endpoint tests."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock
from uuid import uuid4

import pytest
from digital_valerii_shared.services.memory import MemoryContext, RankedEvent
from fastapi.testclient import TestClient


@pytest.fixture
def mock_memory_manager() -> MagicMock:
    """Create a mock memory manager."""
    memory = MagicMock()

    # Mock recall method
    memory.recall = AsyncMock(
        return_value=MemoryContext(
            events=[],
            people=[],
            projects=[],
            lessons=[],
            query="test",
            cached=False,
        )
    )

    # Mock search methods
    memory.search_people = AsyncMock(return_value=[])
    memory.search_projects = AsyncMock(return_value=[])

    # Mock get methods
    memory.get_person = AsyncMock(return_value=None)
    memory.get_project = AsyncMock(return_value=None)

    return memory


@pytest.fixture
def client(mock_memory_manager: MagicMock) -> TestClient:
    """Create test client with mocked dependencies."""
    from apps.api.dependencies import get_memory_manager
    from apps.api.main import app

    app.dependency_overrides[get_memory_manager] = lambda: mock_memory_manager

    yield TestClient(app, raise_server_exceptions=False)

    app.dependency_overrides.clear()


class TestMemorySearch:
    """Tests for GET /api/v1/memory/search."""

    def test_search_empty_results(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test search with no results."""
        response = client.get("/api/v1/memory/search?q=test")

        assert response.status_code == 200
        assert response.json() == []

    def test_search_with_results(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test search with results."""
        event_id = uuid4()
        now = datetime.now(UTC)

        mock_memory_manager.recall = AsyncMock(
            return_value=MemoryContext(
                events=[
                    RankedEvent(
                        event_id=event_id,
                        event_type="conversation",
                        title="Test conversation",
                        summary="A test summary",
                        occurred_at=now,
                        importance=0.8,
                        vector_score=0.95,
                        time_decay=0.9,
                        final_score=0.85,
                    )
                ],
                people=[],
                projects=[],
                lessons=[],
                query="test",
                cached=False,
            )
        )

        response = client.get("/api/v1/memory/search?q=test")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["event_id"] == str(event_id)
        assert data[0]["event_type"] == "conversation"
        assert data[0]["score"] == 0.85

    def test_search_missing_query(self, client: TestClient) -> None:
        """Test search without query returns error."""
        response = client.get("/api/v1/memory/search")

        assert response.status_code == 422

    def test_search_with_limit(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test search with custom limit."""
        response = client.get("/api/v1/memory/search?q=test&limit=5")

        assert response.status_code == 200

    def test_search_limit_too_high(self, client: TestClient) -> None:
        """Test search with limit over max."""
        response = client.get("/api/v1/memory/search?q=test&limit=100")

        assert response.status_code == 422


class TestListPeople:
    """Tests for GET /api/v1/memory/people."""

    def test_list_people_empty(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing people with no results."""
        response = client.get("/api/v1/memory/people")

        assert response.status_code == 200
        assert response.json() == []

    def test_list_people_with_results(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing people with results."""
        person_id = uuid4()

        mock_person = MagicMock()
        mock_person.id = person_id
        mock_person.name = "John Doe"
        mock_person.email = "john@example.com"
        mock_person.company = "Acme Inc"
        mock_person.relationship_type = "colleague"

        mock_memory_manager.search_people = AsyncMock(return_value=[mock_person])

        response = client.get("/api/v1/memory/people")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["id"] == str(person_id)
        assert data[0]["name"] == "John Doe"

    def test_list_people_with_query(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing people with search query."""
        response = client.get("/api/v1/memory/people?q=John")

        assert response.status_code == 200
        mock_memory_manager.search_people.assert_called()


class TestGetPerson:
    """Tests for GET /api/v1/memory/people/{id}."""

    def test_get_person_not_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting non-existent person returns 404."""
        person_id = uuid4()

        response = client.get(f"/api/v1/memory/people/{person_id}")

        assert response.status_code == 404
        assert response.json()["detail"] == "Person not found"

    def test_get_person_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting existing person returns details."""
        person_id = uuid4()

        mock_person = MagicMock()
        mock_person.id = person_id
        mock_person.name = "Jane Doe"
        mock_person.email = "jane@example.com"
        mock_person.company = "Tech Corp"
        mock_person.relationship_type = "client"
        mock_person.notes = "Important client"
        mock_person.event_participations = []

        mock_memory_manager.get_person = AsyncMock(return_value=mock_person)

        response = client.get(f"/api/v1/memory/people/{person_id}")

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == str(person_id)
        assert data["name"] == "Jane Doe"
        assert data["notes"] == "Important client"
        assert data["interaction_count"] == 0

    def test_get_person_invalid_uuid(self, client: TestClient) -> None:
        """Test invalid UUID returns 422."""
        response = client.get("/api/v1/memory/people/invalid")

        assert response.status_code == 422


class TestListProjects:
    """Tests for GET /api/v1/memory/projects."""

    def test_list_projects_empty(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing projects with no results."""
        response = client.get("/api/v1/memory/projects")

        assert response.status_code == 200
        assert response.json() == []

    def test_list_projects_with_results(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing projects with results."""
        project_id = uuid4()

        mock_project = MagicMock()
        mock_project.id = project_id
        mock_project.name = "Project Alpha"
        mock_project.status = "active"
        mock_project.description = "A test project"

        mock_memory_manager.search_projects = AsyncMock(return_value=[mock_project])

        response = client.get("/api/v1/memory/projects")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["id"] == str(project_id)
        assert data[0]["name"] == "Project Alpha"

    def test_list_projects_with_status_filter(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test listing projects with status filter."""
        project_id = uuid4()

        mock_project = MagicMock()
        mock_project.id = project_id
        mock_project.name = "Project Alpha"
        mock_project.status = "active"
        mock_project.description = "A test project"

        mock_memory_manager.search_projects = AsyncMock(return_value=[mock_project])

        response = client.get("/api/v1/memory/projects?status=active")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["status"] == "active"


class TestGetProject:
    """Tests for GET /api/v1/memory/projects/{id}."""

    def test_get_project_not_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting non-existent project returns 404."""
        project_id = uuid4()

        response = client.get(f"/api/v1/memory/projects/{project_id}")

        assert response.status_code == 404
        assert response.json()["detail"] == "Project not found"

    def test_get_project_found(
        self, client: TestClient, mock_memory_manager: MagicMock
    ) -> None:
        """Test getting existing project returns details."""
        project_id = uuid4()
        now = datetime.now(UTC)

        mock_project = MagicMock()
        mock_project.id = project_id
        mock_project.name = "Project Beta"
        mock_project.status = "completed"
        mock_project.description = "Completed project"
        mock_project.created_at = now
        mock_project.updated_at = now
        mock_project.people = []

        mock_memory_manager.get_project = AsyncMock(return_value=mock_project)

        response = client.get(f"/api/v1/memory/projects/{project_id}")

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == str(project_id)
        assert data["name"] == "Project Beta"
        assert data["status"] == "completed"
        assert data["people"] == []

    def test_get_project_invalid_uuid(self, client: TestClient) -> None:
        """Test invalid UUID returns 422."""
        response = client.get("/api/v1/memory/projects/not-uuid")

        assert response.status_code == 422
