"""Application database configuration."""

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from digital_valerii_shared import Database, DatabaseSettings
from digital_valerii_shared.config import QdrantSettings
from digital_valerii_shared.services.qdrant import QdrantService

from .config import settings

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from fastapi import FastAPI


# Global database instance
_database: Database | None = None

# Global Qdrant instance
_qdrant: QdrantService | None = None


def get_database() -> Database:
    """Get the global database instance.

    Returns:
        Database: The singleton database instance.
    """
    global _database  # noqa: PLW0603
    if _database is None:
        db_settings = DatabaseSettings(url=settings.database_url)
        _database = Database(db_settings)
    return _database


def reset_database() -> None:
    """Reset the global database instance (for testing)."""
    global _database  # noqa: PLW0603
    _database = None


def get_qdrant() -> QdrantService:
    """Get the global Qdrant instance.

    Returns:
        QdrantService: The singleton Qdrant instance.
    """
    global _qdrant  # noqa: PLW0603
    if _qdrant is None:
        qdrant_settings = QdrantSettings(
            url=settings.qdrant_url,
            api_key=settings.qdrant_api_key,
        )
        _qdrant = QdrantService(qdrant_settings)
    return _qdrant


def reset_qdrant() -> None:
    """Reset the global Qdrant instance (for testing)."""
    global _qdrant  # noqa: PLW0603
    _qdrant = None


@asynccontextmanager
async def lifespan(_app: "FastAPI") -> "AsyncGenerator[None, None]":
    """Application lifespan handler.

    Verifies database connection on startup and cleans up on shutdown.

    Args:
        app: FastAPI application instance.

    Raises:
        RuntimeError: If database or Qdrant connection fails on startup.
    """
    # Startup - Database
    db = get_database()
    if not await db.health_check():
        raise RuntimeError("Database connection failed on startup")

    # Startup - Qdrant (creates collections if missing)
    qdrant = get_qdrant()
    await qdrant.initialize()

    # Startup - Slack (register handlers if configured)
    # This is optional and should not block startup if it fails
    try:
        from apps.api.dependencies import initialize_slack

        await initialize_slack()
    except ImportError:
        pass  # Slack dependencies not installed, skip
    except Exception:
        pass  # Slack initialization failed, skip (non-critical)

    # Startup - Scheduler (APScheduler for scheduled tasks)
    # This is optional and should not block startup if it fails
    scheduler = None
    try:
        from apps.api.dependencies import get_scheduler_service

        scheduler = await get_scheduler_service()
        await scheduler.start()
    except ImportError:
        pass  # Scheduler dependencies not installed, skip
    except Exception:
        pass  # Scheduler initialization failed, skip (non-critical)

    yield

    # Shutdown - Scheduler
    if scheduler is not None:
        try:
            await scheduler.stop()
        except Exception:
            pass  # Ignore shutdown errors

    # Shutdown
    await qdrant.close()
    reset_qdrant()
    await db.close()
    reset_database()
