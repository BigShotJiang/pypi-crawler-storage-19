"""Audit middleware for logging API requests."""

import logging
from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware

from apps.api.database import get_database

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response

logger = logging.getLogger(__name__)


class AuditMiddleware(BaseHTTPMiddleware):
    """Middleware to log API requests for auditing.

    Logs significant API endpoints while skipping health checks,
    documentation, and static files. Uses fire-and-forget pattern
    to avoid blocking requests on audit failures.
    """

    # Paths to skip logging
    SKIP_PATHS = frozenset(
        [
            "/health",
            "/metrics",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/favicon.ico",
        ]
    )

    async def dispatch(self, request: "Request", call_next: "callable") -> "Response":
        """Process request and log to audit if appropriate.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response from the next handler.
        """
        response = await call_next(request)

        # Log significant endpoints only (fire-and-forget)
        if self._should_log(request):
            try:
                await self._log_request(request, response)
            except Exception:
                # Never block request on audit failure
                logger.exception("Failed to log audit entry")

        return response

    def _should_log(self, request: "Request") -> bool:
        """Determine if request should be logged.

        Args:
            request: HTTP request to check.

        Returns:
            True if request should be logged.
        """
        path = request.url.path
        # Skip configured paths and prefixes
        if path in self.SKIP_PATHS:
            return False
        return not (path.startswith("/docs") or path.startswith("/redoc"))

    async def _log_request(self, request: "Request", response: "Response") -> None:
        """Log the request to audit log.

        Args:
            request: HTTP request that was processed.
            response: HTTP response returned.
        """
        from packages.shared.digital_valerii_shared.services.audit import AuditService

        db = get_database()
        async with db.session() as session:
            audit = AuditService(session)
            await audit.log(
                action="api_call",
                resource=f"endpoint:{request.url.path}",
                ip_address=request.client.host if request.client else None,
                user_agent=request.headers.get("user-agent"),
                details={
                    "method": request.method,
                    "status_code": response.status_code,
                },
            )
