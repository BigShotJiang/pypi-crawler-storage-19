"""Authentication middleware supporting API Key and JWT.

Per ISO 42001 A.8.3: Dual authentication methods for external services and web users.
"""

import logging
import secrets
from typing import TYPE_CHECKING

from fastapi.responses import JSONResponse
from jose import JWTError
from starlette.middleware.base import BaseHTTPMiddleware

from apps.api.config import settings

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response

logger = logging.getLogger(__name__)


class AuthMiddleware(BaseHTTPMiddleware):
    """Middleware to validate authentication on protected endpoints.

    Supports two authentication methods:
    1. X-API-Key header: For external services/CLI tools
    2. Authorization: Bearer <JWT>: For web frontend users

    Skips authentication for health, docs, and public endpoints.
    In production mode, requires at least one auth method to be configured.
    Uses constant-time comparison for API key to prevent timing attacks.
    """

    # Paths that don't require authentication
    SKIP_PATHS = frozenset(
        [
            "/",
            "/health",
            "/metrics",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/favicon.ico",
        ]
    )

    # Auth endpoints that don't require authentication
    AUTH_PATHS = frozenset(
        [
            "/api/v1/auth/login",
            "/api/v1/auth/register",
            "/api/v1/auth/refresh",
        ]
    )

    # Slack endpoints use their own signing secret verification
    SLACK_PATHS = frozenset(
        [
            "/api/v1/slack/events",
            "/api/v1/slack/commands",
            "/api/v1/slack/interactions",
        ]
    )

    def __init__(self, app: "callable") -> None:
        """Initialize middleware with JWT service.

        Args:
            app: ASGI application.
        """
        super().__init__(app)
        # Lazy-load JWTService to avoid circular imports
        self._jwt_service = None

    def _get_jwt_service(self):
        """Get JWT service instance (lazy-loaded)."""
        if self._jwt_service is None:
            from apps.api.auth.jwt import JWTService

            self._jwt_service = JWTService(
                secret_key=settings.jwt_secret_key,
                algorithm=settings.jwt_algorithm,
                access_token_expire_minutes=settings.access_token_expire_minutes,
                refresh_token_expire_days=settings.refresh_token_expire_days,
            )
        return self._jwt_service

    async def dispatch(self, request: "Request", call_next: "callable") -> "Response":
        """Validate authentication for protected endpoints.

        Accepts EITHER valid X-API-Key OR valid JWT Bearer token.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response from handler, 401 on auth failure, or 500 on config error.
        """
        path = request.url.path

        # Skip auth for public paths
        if path in self.SKIP_PATHS:
            return await call_next(request)

        # Skip auth for non-API paths (docs subpaths, etc.)
        if not path.startswith("/api/"):
            return await call_next(request)

        # Skip auth for authentication endpoints
        if path in self.AUTH_PATHS:
            return await call_next(request)

        # Skip auth for Slack endpoints (use their own signing secret)
        if path in self.SLACK_PATHS:
            return await call_next(request)

        # Development mode without configured auth - allow requests
        if not settings.api_key and settings.app_env != "production":
            return await call_next(request)

        # Production requires authentication configuration
        if settings.app_env == "production" and not settings.api_key:
            logger.error("No authentication methods configured in production")
            return JSONResponse(
                status_code=500,
                content={"detail": "Server configuration error"},
            )

        # Try API Key first (for external services/CLI)
        api_key = request.headers.get("X-API-Key")
        if (
            api_key
            and settings.api_key
            and secrets.compare_digest(api_key, settings.api_key)
        ):
            # API key authenticated - mark request
            request.state.auth_method = "api_key"
            return await call_next(request)

        # Try JWT Bearer token (for web frontend)
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header[7:]
            try:
                jwt_service = self._get_jwt_service()
                token_data = jwt_service.verify_token(token, "access")
                # JWT authenticated - store user_id in request state
                request.state.auth_method = "jwt"
                request.state.user_id = token_data.sub
                return await call_next(request)
            except JWTError as e:
                logger.debug(f"JWT validation failed: {e}")
                # Fall through to unauthorized response

        # No valid authentication provided
        return JSONResponse(
            status_code=401,
            content={"detail": "Invalid authentication credentials"},
        )
