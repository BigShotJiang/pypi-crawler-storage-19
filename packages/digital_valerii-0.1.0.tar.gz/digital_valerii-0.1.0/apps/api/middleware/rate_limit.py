"""Rate limiting middleware."""

import logging
import secrets
from typing import TYPE_CHECKING

from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from apps.api.config import settings

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce request rate limits.

    Uses Redis for distributed rate limiting with sliding window.
    Limits by client identifier:
    - Valid API key: rate limit by key
    - Invalid/missing key: rate limit by IP (prevents bypass via rotating keys)
    """

    # Paths that don't count toward rate limits
    SKIP_PATHS = frozenset(
        [
            "/",
            "/health",
            "/metrics",
            "/docs",
            "/redoc",
            "/openapi.json",
            "/favicon.ico",
        ]
    )

    # Slack endpoints have their own rate limiting
    SLACK_PATHS = frozenset(
        [
            "/api/v1/slack/events",
            "/api/v1/slack/commands",
            "/api/v1/slack/interactions",
        ]
    )

    async def dispatch(self, request: "Request", call_next: "callable") -> "Response":
        """Check rate limit and process request.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response from handler or 429 if rate limited.
        """
        # Skip rate limiting for certain paths
        path = request.url.path
        if path in self.SKIP_PATHS or not path.startswith("/api/"):
            return await call_next(request)

        # Skip rate limiting for Slack endpoints (have their own rate limiting)
        if path in self.SLACK_PATHS:
            return await call_next(request)

        # Get client identifier
        # Use API key only if it matches configured key (valid)
        # Otherwise fall back to IP to prevent bypass via rotating invalid keys
        client_id = self._get_client_id(request)

        # Check rate limit
        try:
            remaining, is_limited = await self._check_rate_limit(client_id)
        except Exception:
            # Log that rate limiting is bypassed (fail open)
            logger.warning(
                "Rate limit check failed, allowing request",
                extra={"client_id": client_id, "path": path},
            )
            return await call_next(request)

        if is_limited:
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded"},
                headers={"X-RateLimit-Remaining": "0"},
            )

        response = await call_next(request)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        return response

    def _get_client_id(self, request: "Request") -> str:
        """Get client identifier for rate limiting.

        Uses API key only if it's valid (matches configured key).
        Otherwise falls back to IP to prevent bypass via rotating keys.

        Args:
            request: HTTP request.

        Returns:
            Client identifier string (prefixed with 'key:' or 'ip:').
        """
        provided_key = request.headers.get("X-API-Key") or ""

        # Use API key only if it matches configured key (valid)
        if settings.api_key and secrets.compare_digest(provided_key, settings.api_key):
            return f"key:{provided_key}"

        # Invalid or no key - rate limit by IP
        return f"ip:{self._get_client_ip(request)}"

    def _get_client_ip(self, request: "Request") -> str:
        """Get client IP address from request.

        Handles X-Forwarded-For header for proxied requests.

        Args:
            request: HTTP request.

        Returns:
            Client IP address string.
        """
        # Check X-Forwarded-For header first (for reverse proxy setups)
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            # Take first IP (original client)
            return forwarded.split(",")[0].strip()

        # Fall back to direct client
        if request.client:
            return request.client.host

        return "unknown"

    async def _check_rate_limit(self, client_id: str) -> tuple[int, bool]:
        """Check if client is rate limited.

        Uses Redis INCR with 60-second TTL for sliding window.

        Args:
            client_id: Client identifier (API key or IP).

        Returns:
            Tuple of (remaining requests, is_limited).
        """
        from digital_valerii_shared.services.redis import RedisNamespace, RedisService

        from apps.api.dependencies import _get_memory_manager_instance

        # Get Redis from memory manager (reuse connection)
        memory = _get_memory_manager_instance()
        redis: RedisService = memory._redis  # noqa: SLF001

        # Ensure Redis is connected
        if not redis._client:  # noqa: SLF001
            await redis.connect()

        # Rate limit key with 60-second window
        key = client_id
        limit = settings.rate_limit_anthropic_rpm
        window_seconds = 60

        # Increment counter
        count = await redis.increment(
            key, RedisNamespace.RATE_LIMIT, ttl=window_seconds
        )

        remaining = max(0, limit - count)
        is_limited = count > limit

        return remaining, is_limited
