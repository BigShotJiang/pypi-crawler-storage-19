"""Request size limit middleware."""

import logging
from typing import TYPE_CHECKING

from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from apps.api.config import settings

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.responses import Response

logger = logging.getLogger(__name__)


class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce request body size limits.

    Checks Content-Length header against configured max_request_size_bytes.
    Returns 413 Payload Too Large if limit exceeded.
    Returns 411 Length Required if POST/PUT/PATCH lacks Content-Length.

    Note: For additional protection, also configure server-side limits:
    - uvicorn: --limit-max-request-size 1000000
    - gunicorn: --limit-request-body 1000000
    """

    # HTTP methods that typically have request bodies
    BODY_METHODS = frozenset(["POST", "PUT", "PATCH"])

    async def dispatch(self, request: "Request", call_next: "callable") -> "Response":
        """Check request size and reject if too large.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response from handler, 411 if Content-Length missing, or 413 if too large.
        """
        content_length = request.headers.get("content-length")

        # Require Content-Length for methods that have request bodies
        # This prevents chunked transfer bypass of size limits
        if request.method in self.BODY_METHODS and not content_length:
            logger.warning(
                "Request without Content-Length header rejected",
                extra={"path": request.url.path, "method": request.method},
            )
            return JSONResponse(
                status_code=411,
                content={"detail": "Content-Length header required"},
            )

        # Check Content-Length against limit
        if content_length:
            try:
                size = int(content_length)
                if size > settings.max_request_size_bytes:
                    return JSONResponse(
                        status_code=413,
                        content={"detail": "Request body too large"},
                    )
            except ValueError:
                # Invalid content-length header - reject request
                return JSONResponse(
                    status_code=400,
                    content={"detail": "Invalid Content-Length header"},
                )

        return await call_next(request)
