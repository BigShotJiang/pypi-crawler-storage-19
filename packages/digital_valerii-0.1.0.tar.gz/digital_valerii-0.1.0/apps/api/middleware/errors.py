"""Error handling middleware for unhandled exceptions."""

import structlog
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = structlog.get_logger()


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware to catch unhandled exceptions.

    Catches any unhandled exceptions, logs them, and returns
    a generic 500 error response without leaking internal details.
    """

    async def dispatch(self, request: Request, call_next: callable) -> Response:
        """Handle request and catch any unhandled exceptions.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response from handler or error response on exception.
        """
        try:
            return await call_next(request)
        except Exception:
            request_id = getattr(request.state, "request_id", "unknown")

            logger.exception(
                "unhandled_error",
                request_id=request_id,
                method=request.method,
                path=request.url.path,
            )

            return JSONResponse(
                status_code=500,
                content={"detail": "Internal server error"},
                headers={"X-Request-ID": request_id},
            )
