"""Request ID middleware for request tracking."""

from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware to add unique request ID to each request.

    Generates a UUID for each request and adds it to:
    - request.state.request_id (for use in handlers)
    - X-Request-ID response header (for client correlation)
    """

    async def dispatch(self, request: Request, call_next: callable) -> Response:
        """Add request ID to request and response.

        Args:
            request: Incoming HTTP request.
            call_next: Next middleware/handler in chain.

        Returns:
            Response with X-Request-ID header.
        """
        request_id = str(uuid4())
        request.state.request_id = request_id

        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id

        return response
