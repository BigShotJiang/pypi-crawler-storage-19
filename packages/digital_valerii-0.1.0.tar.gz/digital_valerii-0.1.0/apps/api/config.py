"""Application configuration."""

import secrets
import warnings

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    # Application
    app_env: str = "development"
    debug: bool = True
    log_level: str = "DEBUG"

    # Database
    database_url: str = "postgresql+asyncpg://digital_valerii:dev_password@localhost:5432/digital_valerii"

    # Qdrant
    qdrant_url: str = "http://localhost:6333"
    qdrant_api_key: str | None = None

    # Redis
    redis_url: str = "redis://localhost:6379"

    # Anthropic
    anthropic_api_key: str = ""

    # Claude Models
    default_model: str = "claude-sonnet-4-5-20241022"  # Sonnet 4.5 for regular tasks
    advanced_model: str = "claude-opus-4-5-20251101"  # Opus 4.5 for complex reasoning

    # Embeddings (Voyage)
    voyage_api_key: str = ""
    embedding_model: str = "voyage-large-2"
    embedding_dimensions: int = 1536

    # TTLs (seconds)
    session_ttl_seconds: int = 86400  # 24 hours
    working_memory_ttl_seconds: int = 3600  # 1 hour
    recall_cache_ttl_seconds: int = 300  # 5 minutes

    # Rate Limits
    rate_limit_anthropic_rpm: int = 4000  # Requests per minute
    rate_limit_anthropic_tpm: int = 400000  # Tokens per minute
    rate_limit_voyage_rpm: int = 300

    # CORS
    cors_origins: list[str] = ["http://localhost:3000"]

    # API
    api_v1_prefix: str = "/api/v1"

    # Security
    api_key: str = ""  # Required in production
    max_request_size_bytes: int = 1_000_000  # 1MB
    # NOTE: For complete protection, also configure server:
    # uvicorn: --limit-max-request-size 1000000
    # gunicorn: --limit-request-body 1000000

    # JWT Configuration
    jwt_secret_key: str = ""  # Required in production
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # Owner Seed Settings
    owner_email: str | None = Field(default=None, validation_alias="DV_OWNER_EMAIL")
    owner_password: str | None = Field(
        default=None, validation_alias="DV_OWNER_PASSWORD"
    )
    owner_name: str = Field(default="Owner", validation_alias="DV_OWNER_NAME")

    # Microsoft Graph API (Component 4.1)
    microsoft_client_id: str = Field(default="", validation_alias="MICROSOFT_CLIENT_ID")
    microsoft_client_secret: str = Field(
        default="", validation_alias="MICROSOFT_CLIENT_SECRET"
    )
    microsoft_tenant_id: str = Field(
        default="common", validation_alias="MICROSOFT_TENANT_ID"
    )
    microsoft_redirect_uri: str = Field(
        default="http://localhost:8000/api/v1/auth/microsoft/callback",
        validation_alias="MICROSOFT_REDIRECT_URI",
    )
    microsoft_webhook_client_state: str = Field(
        default="", validation_alias="MICROSOFT_WEBHOOK_CLIENT_STATE"
    )
    # FIX-2: Encryption key for Microsoft tokens at rest
    # Generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    microsoft_token_encryption_key: str = Field(
        default="", validation_alias="MICROSOFT_TOKEN_ENCRYPTION_KEY"
    )
    # Microsoft Graph API scopes
    microsoft_scopes: list[str] = [
        "offline_access",
        "Mail.Read",
        "Mail.Send",
        "Mail.ReadWrite",
        "Calendars.ReadWrite",
        "Files.ReadWrite.All",
        "ChannelMessage.Read.All",
        "ChannelMessage.Send",
        "Chat.Read",
        "Chat.ReadWrite",
        "User.Read",
        "User.ReadBasic.All",
    ]

    # Slack Bot (Component 4.2)
    slack_bot_token: str = Field(default="", validation_alias="SLACK_BOT_TOKEN")
    slack_signing_secret: str = Field(
        default="", validation_alias="SLACK_SIGNING_SECRET"
    )
    slack_app_token: str = Field(
        default="", validation_alias="SLACK_APP_TOKEN"
    )  # For Socket Mode (optional)

    model_config = {
        "env_file": ("../../.env", "../.env", ".env"),
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @model_validator(mode="after")
    def validate_jwt_secret(self) -> "Settings":
        """Validate JWT secret - fail fast in production, warn in dev.

        Per OWASP: Empty secrets enable trivial token forgery.
        """
        if not self.jwt_secret_key and self.app_env == "production":
            raise ValueError("jwt_secret_key must be set in production")
        if not self.jwt_secret_key:
            # Generate random secret for dev/test (with warning)
            object.__setattr__(self, "jwt_secret_key", secrets.token_urlsafe(32))
            warnings.warn(
                "jwt_secret_key not set - using random secret (tokens invalid after restart)",
                UserWarning,
                stacklevel=2,
            )
        return self


# Redis key namespaces
class RedisNamespace:
    """Redis key prefixes for namespacing."""

    SESSIONS = "dv:sessions:"
    CACHE = "dv:cache:"
    RATE_LIMIT = "dv:rate:"
    LOCKS = "dv:lock:"
    WORKING_MEMORY = "dv:wm:"
    REFRESH_TOKENS = "dv:refresh:"
    MICROSOFT_TOKENS = "dv:ms_tokens:"
    MICROSOFT_OAUTH_STATE = "dv:ms_oauth:"
    # Slack Bot (Component 4.2)
    SLACK_RATE_LIMIT = "dv:slack_rate:"
    SLACK_CONVERSATIONS = "dv:slack_conv:"


settings = Settings()
