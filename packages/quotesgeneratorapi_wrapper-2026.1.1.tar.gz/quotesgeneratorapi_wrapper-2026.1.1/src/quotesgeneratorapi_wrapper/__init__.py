from .quotesgenerator import getQuotes
