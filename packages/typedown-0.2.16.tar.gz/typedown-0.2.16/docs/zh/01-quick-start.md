---
title: 快速开始
---

## 快速开始 (Quick Start)

欢迎来到 Typedown。本教程将带你体验 Typedown 的核心工作流：**编写 Markdown，即时获得反馈**。

## 1. 安装

Typedown 提供了命令行工具 (CLI) 和 VS Code 插件。

### 安装 CLI

需要 Python 3.12+。

```bash
pip install typedown
```

### 安装 VS Code 插件

在 VS Code 插件市场搜索 `Typedown` 并安装。

## 2. Hello World

创建一个新目录，并新建文件 `hello.td` (Typedown 使用 `.td` 扩展名，完全兼容 Markdown)。

### 第一步：定义模型 (Model)

在 Typedown 中，一切始于**模型**。我们需要先告诉系统 `User` 长什么样。

在 `hello.td` 中输入以下内容：

````markdown
```model:User
class User(BaseModel):
    name: str
    role: str
```
````

这里我们使用了 `model` 块，采用 Pydantic 风格定义了一个简单的 `User` 类。

### 第二步：创建实体 (Entity)

有了模型，我们就可以实例化数据了。在同一个文件中添加：

````markdown
```entity User: alice
name: "Alice"
role: "admin"
```
````

这里我们使用了 `entity` 块，创建了一个类型为 `User` 的实体，ID 为 `alice`。

## 3. 获得反馈

在终端中运行检查：

```bash
td check .
```

你会看到 Typedown 扫描了当前目录，并报告：**No errors found**。🎉

这就是 Typedown 的核心体验：**强类型的 Markdown**。

如果你尝试修改 `alice` 的 `age` (一个未定义的字段)，或者将 `name` 改为数字，`td check` 会立即报错。

## 4. 下一步

你已经掌握了 Typedown 的核心循环：**定义模型 -> 创建实体 -> 校验反馈**。

👉 前往 [语法基础](/zh/docs/syntax/code-blocks) 深入了解更多细节。

## 5. 学习路线 (Learning Path)

我们为你精心编排了一套**渐进式教程**，位于项目根目录的 `examples/` 文件夹中。建议按照以下顺序阅读和运行：

| 目录                     | 核心概念                               |
| ------------------------ | -------------------------------------- |
| `00_basic_modeling`      | **结构** (Model + Entity) 定义基础     |
| `01_schema_constraints`  | **校验** (Field + Validator) 内置约束  |
| `02_inheritance`         | **复用** (Inheritance) 模型继承        |
| `03_simple_rules`        | **逻辑** (Spec + Assert) 业务规则      |
| `04_context_interaction` | **交互** (Methods) 模型方法            |
| `05_global_governance`   | **体系** (Global + SQL) 全局与聚合     |
| `06_modular_project`     | **工程** (Config + Imports) 多文件组织 |
