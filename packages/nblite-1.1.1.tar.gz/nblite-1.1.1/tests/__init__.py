"""Tests for nblite."""
