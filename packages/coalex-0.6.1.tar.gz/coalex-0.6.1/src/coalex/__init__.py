"""Coalex SDK for observability and monitoring."""

from .otel.register import register, add_request_context, coalex_context
from .otel.auto_instrument import (
    auto_instrument,
    # Common helper functions
    instrument_openai,
    instrument_llamaindex,
    instrument_langchain,
    instrument_vertexai,
    instrument_bedrock,
    instrument_anthropic,
)
from .approve import approve, ApprovalRequest, ApprovalResponse
from .metrics import submit_metric, MetricRequest, MetricResponse

__version__ = "0.6.1"

# Expose main functions
__all__ = [
    "register",
    "add_request_context",
    "coalex_context",
    # Auto-instrumentation
    "auto_instrument",
    "instrument_openai",
    "instrument_llamaindex",
    "instrument_langchain",
    "instrument_vertexai",
    "instrument_bedrock",
    "instrument_anthropic",
    # Approval/metrics
    "approve",
    "ApprovalRequest",
    "ApprovalResponse",
    "submit_metric",
    "MetricRequest",
    "MetricResponse"
]