"""Coalex OpenTelemetry SDK with OTLP integration."""

from .register import register, add_request_context, coalex_context
from .auto_instrument import (
    auto_instrument,
    instrument_openai,
    instrument_llamaindex,
    instrument_langchain,
    instrument_vertexai,
    instrument_bedrock,
    instrument_anthropic,
)
from .filtering_exporter import FilteringSpanExporter

__all__ = [
    "register",
    "add_request_context",
    "coalex_context",
    "auto_instrument",
    "instrument_openai",
    "instrument_llamaindex",
    "instrument_langchain",
    "instrument_vertexai",
    "instrument_bedrock",
    "instrument_anthropic",
    "FilteringSpanExporter",
]