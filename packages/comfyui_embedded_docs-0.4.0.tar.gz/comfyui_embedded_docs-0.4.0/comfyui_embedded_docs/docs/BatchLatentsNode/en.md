> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchLatentsNode/en.md)

The Batch Latents node combines multiple latent inputs into a single batch. It takes a variable number of latent samples and merges them along the batch dimension, allowing them to be processed together in subsequent nodes. This is useful for generating or processing multiple images in a single operation.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `latents` | LATENT | Yes | N/A | The first latent sample to be included in the batch. |
| `latent_2` to `latent_50` | LATENT | No | N/A | Additional latent samples to be included in the batch. You can add between 2 and 50 latent inputs in total. |

**Note:** You must provide at least two latent inputs for the node to function. The node will automatically create input slots as you connect more latents, up to a maximum of 50.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | LATENT | A single latent output containing all the input latents combined into one batch. |