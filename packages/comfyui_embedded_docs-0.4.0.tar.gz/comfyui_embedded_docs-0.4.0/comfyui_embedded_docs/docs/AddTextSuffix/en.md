> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextSuffix/en.md)

This node appends a specified suffix to the end of an input text string. It takes the original text and the suffix as inputs, then returns the combined result.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `text` | STRING | Yes | | The original text to which the suffix will be added. |
| `suffix` | STRING | No | | The suffix to add to the text (default: ""). |

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `text` | STRING | The resulting text after the suffix has been appended. |