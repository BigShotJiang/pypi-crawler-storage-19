> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesMasksLatentsNode/en.md)

The Batch Images/Masks/Latents node combines multiple inputs of the same type into a single batch. It automatically detects whether the inputs are images, masks, or latent representations and uses the appropriate batching method. This is useful for preparing multiple items for processing by nodes that accept batched inputs.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `inputs` | IMAGE, MASK, or LATENT | Yes | 1 to 50 inputs | A dynamic list of inputs to be combined into a batch. You can add between 1 and 50 items. All items must be of the same type (all images, all masks, or all latents). |

**Note:** The node automatically determines the data type (IMAGE, MASK, or LATENT) based on the first item in the `inputs` list. All subsequent items must match this type. The node will fail if you try to mix different data types.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | IMAGE, MASK, or LATENT | A single batched output. The data type matches the input type (batched IMAGE, batched MASK, or batched LATENT). |