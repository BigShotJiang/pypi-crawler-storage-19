> 本文档由 AI 生成。如果您发现任何错误或有改进建议，欢迎贡献！ [在 GitHub 上编辑](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/CLIPTextEncodeKandinsky5/zh.md)

该节点为 Kandinsky 5 模型准备文本提示。它接收两个独立的文本输入，使用提供的 CLIP 模型对其进行分词处理，并将它们组合成单个条件输出。此输出用于指导图像生成过程。

## 输入参数

| 参数 | 数据类型 | 必填 | 取值范围 | 描述 |
|-----------|-----------|----------|-------|-------------|
| `clip` | CLIP | 是 | | 用于对文本提示进行分词和编码的 CLIP 模型。 |
| `clip_l` | STRING | 是 | | 主文本提示。此输入支持多行文本和动态提示。 |
| `qwen25_7b` | STRING | 是 | | 辅助文本提示。此输入支持多行文本和动态提示。 |

## 输出

| 输出名称 | 数据类型 | 描述 |
|-------------|-----------|-------------|
| `CONDITIONING` | CONDITIONING | 由两个文本提示生成的组合条件数据，准备输入到 Kandinsky 5 模型以进行图像生成。 |