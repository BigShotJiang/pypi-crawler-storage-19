> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchImagesNode/en.md)

The Batch Images node combines multiple individual images into a single batch. It takes a variable number of image inputs and outputs them as one batched image tensor, allowing them to be processed together in subsequent nodes.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `images` | IMAGE | Yes | 2 to 50 inputs | A dynamic list of image inputs. You can add between 2 and 50 images to be combined into a batch. The node interface allows you to add more image input slots as needed. |

**Note:** You must connect at least two images for the node to function. The first input slot is always required, and you can add more using the "+" button that appears in the node interface.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | IMAGE | A single batched image tensor containing all the input images stacked together. |