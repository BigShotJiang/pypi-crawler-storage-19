> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/BatchMasksNode/en.md)

The Batch Masks node combines multiple individual mask inputs into a single batch. It takes a variable number of mask inputs and outputs them as a single batched mask tensor, allowing for batch processing of masks in subsequent nodes.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `mask_0` | MASK | Yes | - | The first mask input. |
| `mask_1` | MASK | Yes | - | The second mask input. |
| `mask_2` to `mask_49` | MASK | No | - | Additional optional mask inputs. The node can accept a minimum of 2 and a maximum of 50 masks in total. |

**Note:** This node uses an autogrow input template. You must connect at least two masks (`mask_0` and `mask_1`). You can add up to 48 more optional mask inputs (`mask_2` through `mask_49`) for a total of 50 masks. All connected masks will be combined into a single batch.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | MASK | A single batched mask containing all the input masks stacked together. |