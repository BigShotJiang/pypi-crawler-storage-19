> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowNamesTestNode/en.md)

This node is a test for the Autogrow input feature. It takes a dynamic number of float inputs, each labeled with a specific name, and combines their values into a single comma-separated string.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `autogrow` | FLOAT | Yes | N/A | A dynamic input group. You can add multiple float inputs, each with a pre-defined name from the list: "a", "b", or "c". The node will accept any combination of these named inputs. |

**Note:** The `autogrow` input is dynamic. You can add or remove individual float inputs (named "a", "b", or "c") as needed for your workflow. The node processes all provided values.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | STRING | A single string containing the values from all provided float inputs, joined together with commas. |