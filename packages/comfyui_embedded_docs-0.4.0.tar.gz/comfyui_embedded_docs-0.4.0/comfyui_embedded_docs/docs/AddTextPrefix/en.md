> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AddTextPrefix/en.md)

The Add Text Prefix node modifies text by adding a specified string to the beginning of each input text. It takes the text and a prefix as input, then returns the combined result.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `text` | STRING | Yes | | The text to which the prefix will be added. |
| `prefix` | STRING | No | | The string to add to the beginning of the text (default: ""). |

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `text` | STRING | The resulting text with the prefix added to the front. |