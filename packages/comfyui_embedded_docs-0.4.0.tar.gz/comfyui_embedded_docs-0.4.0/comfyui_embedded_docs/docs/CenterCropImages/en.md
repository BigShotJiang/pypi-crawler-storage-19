> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/CenterCropImages/en.md)

The Center Crop Images node crops an image from its center to a specified width and height. It calculates the central region of the input image and extracts a rectangular area of the defined dimensions. If the requested crop size is larger than the image, the crop will be constrained to the image's boundaries.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `image` | IMAGE | Yes | - | The input image to be cropped. |
| `width` | INT | No | 1 to 8192 | The width of the crop area (default: 512). |
| `height` | INT | No | 1 to 8192 | The height of the crop area (default: 512). |

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `image` | IMAGE | The resulting image after the center crop operation. |