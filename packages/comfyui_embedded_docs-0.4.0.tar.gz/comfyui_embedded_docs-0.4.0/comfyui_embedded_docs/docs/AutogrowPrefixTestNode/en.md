> This documentation was AI-generated. If you find any errors or have suggestions for improvement, please feel free to contribute! [Edit on GitHub](https://github.com/Comfy-Org/embedded-docs/blob/main/comfyui_embedded_docs/docs/AutogrowPrefixTestNode/en.md)

The AutogrowPrefixTestNode is a logic node designed to test the autogrow input feature. It accepts a dynamic number of float inputs, combines their values into a comma-separated string, and outputs that string.

## Inputs

| Parameter | Data Type | Required | Range | Description |
|-----------|-----------|----------|-------|-------------|
| `autogrow` | AUTOGROW | Yes | 1 to 10 inputs | A dynamic input group that can accept between 1 and 10 float values. Each input in the group is a FLOAT type. |

**Note:** The `autogrow` input is a special dynamic input. You can add multiple float inputs to this group, up to a maximum of 10. The node will process all provided values.

## Outputs

| Output Name | Data Type | Description |
|-------------|-----------|-------------|
| `output` | STRING | A single string containing all the input float values, separated by commas. |