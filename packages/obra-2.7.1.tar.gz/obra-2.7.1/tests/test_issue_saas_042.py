"""Regression tests for ISSUE-SAAS-042: No events logged to hybrid.jsonl.

Root Cause: ProductionLogger is not available in the published obra package
because it lives in src/monitoring/ which is not packaged. This causes
_log_session_event() to silently become a no-op.

Fix: Create a minimal HybridEventLogger in obra/hybrid/ that works
in both development and installed package environments.
"""

import json
import tempfile
from pathlib import Path
from threading import Lock
from unittest.mock import MagicMock, patch

import pytest


class TestHybridEventLoggerAvailability:
    """Test that HybridEventLogger is always available in the package."""

    def test_hybrid_event_logger_importable(self):
        """F1: HybridEventLogger should be importable from obra package.

        This test FAILS before fix because HybridEventLogger doesn't exist.
        """
        # This import should work in both dev and installed package
        from obra.hybrid.event_logger import HybridEventLogger

        assert HybridEventLogger is not None

    def test_hybrid_event_logger_has_no_src_dependencies(self):
        """F1: HybridEventLogger should not depend on src/ modules.

        This ensures the logger works in the installed package.
        """
        # Check that the module doesn't import from src/
        import obra.hybrid.event_logger as module
        from obra.hybrid.event_logger import HybridEventLogger

        source = Path(module.__file__).read_text()

        assert "from src." not in source
        assert "import src." not in source


class TestHybridEventLoggerFunctionality:
    """Test HybridEventLogger event logging functionality."""

    def test_log_event_writes_jsonl(self, tmp_path):
        """F1: HybridEventLogger should write JSONL events to file."""
        from obra.hybrid.event_logger import HybridEventLogger

        log_file = tmp_path / "test_hybrid.jsonl"
        logger = HybridEventLogger(log_file)

        # Log an event
        logger.log_event(
            "session_started", session_id="test-session-123", objective="test objective"
        )

        # Verify file was created and contains valid JSONL
        assert log_file.exists()

        content = log_file.read_text()
        event = json.loads(content.strip())

        assert event["type"] == "session_started"
        assert event["session"] == "test-session-123"
        assert event["objective"] == "test objective"
        assert "ts" in event  # Timestamp

    def test_log_event_appends_multiple_events(self, tmp_path):
        """F1: Multiple events should be appended to the same file."""
        from obra.hybrid.event_logger import HybridEventLogger

        log_file = tmp_path / "test_hybrid.jsonl"
        logger = HybridEventLogger(log_file)

        # Log multiple events
        logger.log_event("session_started", session_id="sess-1")
        logger.log_event("phase_started", session_id="sess-1", phase="derivation")
        logger.log_event("session_completed", session_id="sess-1")

        # Verify all events were logged
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 3

        events = [json.loads(line) for line in lines]
        assert events[0]["type"] == "session_started"
        assert events[1]["type"] == "phase_started"
        assert events[2]["type"] == "session_completed"

    def test_log_event_creates_parent_directory(self, tmp_path):
        """F1: Logger should create parent directories if they don't exist."""
        from obra.hybrid.event_logger import HybridEventLogger

        log_file = tmp_path / "nested" / "dirs" / "hybrid.jsonl"
        logger = HybridEventLogger(log_file)

        logger.log_event("test_event", session_id="sess-1")

        assert log_file.exists()

    def test_log_event_is_thread_safe(self, tmp_path):
        """F1: Logger should be thread-safe for concurrent writes."""
        import threading

        from obra.hybrid.event_logger import HybridEventLogger

        log_file = tmp_path / "test_hybrid.jsonl"
        logger = HybridEventLogger(log_file)

        def log_events(thread_id):
            for i in range(10):
                logger.log_event("test_event", session_id=f"sess-{thread_id}", event_num=i)

        threads = [threading.Thread(target=log_events, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        # All 50 events should be logged
        lines = log_file.read_text().strip().split("\n")
        assert len(lines) == 50

        # Each line should be valid JSON
        for line in lines:
            event = json.loads(line)
            assert "type" in event
            assert "session" in event


class TestOrchestratorUsesHybridEventLogger:
    """Test that HybridOrchestrator uses HybridEventLogger instead of ProductionLogger."""

    def test_orchestrator_initializes_event_logger(self):
        """F1: Orchestrator should initialize HybridEventLogger, not ProductionLogger."""
        from obra.hybrid.event_logger import HybridEventLogger

        # Mock APIClient to avoid network calls
        with patch("obra.hybrid.orchestrator.APIClient"):
            from obra.hybrid.orchestrator import HybridOrchestrator

            mock_client = MagicMock()
            orchestrator = HybridOrchestrator(mock_client)

            # Verify the orchestrator has a HybridEventLogger (not ProductionLogger)
            assert hasattr(orchestrator, "_event_logger")
            assert orchestrator._event_logger is not None
            assert isinstance(orchestrator._event_logger, HybridEventLogger)

    def test_log_session_event_writes_to_file(self, tmp_path):
        """F1: _log_session_event should write to hybrid.jsonl."""
        # This is an integration test verifying events are actually logged
        from obra.hybrid.event_logger import HybridEventLogger

        with patch("obra.hybrid.orchestrator.APIClient"):
            # Patch the default log path
            log_file = tmp_path / "hybrid.jsonl"

            with patch.object(HybridEventLogger, "_get_default_log_path", return_value=log_file):
                from obra.hybrid.orchestrator import HybridOrchestrator

                mock_client = MagicMock()
                orchestrator = HybridOrchestrator(mock_client)
                orchestrator._session_id = "test-session-456"

                # Log an event
                orchestrator._log_session_event("test_event", foo="bar")

                # Verify event was logged
                assert log_file.exists()
                event = json.loads(log_file.read_text().strip())
                assert event["type"] == "test_event"
                assert event["session"] == "test-session-456"
                assert event["foo"] == "bar"


class TestBackwardCompatibility:
    """Test backward compatibility with ProductionLogger in development mode."""

    def test_development_mode_still_works(self):
        """Verify development mode (with ProductionLogger) still works.

        In development, ProductionLogger import succeeds and is preferred
        over HybridEventLogger for full feature set.
        """
        # This test just verifies we didn't break the development path
        # The actual ProductionLogger tests are in tests/test_production_logger.py
        pass  # Placeholder - ProductionLogger coverage exists elsewhere
