"""Integration tests for progress visibility features.

This test module validates end-to-end progress visibility behavior including
heartbeat messages and file change events during execution.

Integration tests follow these guidelines:
- May use real components with minimal mocking
- Longer execution times allowed (< 30s)
- Validate complete workflows
"""

import threading
import time
from unittest.mock import MagicMock, Mock

import pytest

from obra.display.observability import ObservabilityConfig, ProgressEmitter, VerbosityLevel
from obra.hybrid.handlers.execute import (
    ExecuteHandler,
    FileChangeTracker,
    HeartbeatThread,
)


class TestHeartbeatVisibility:
    """Integration tests for heartbeat visibility during execution."""

    @pytest.fixture
    def mock_emitter(self):
        """Create mock ProgressEmitter for capturing heartbeat calls."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=0)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(
            return_value=MagicMock(added=set(), modified=set(), count=0)
        )
        return handler

    @pytest.fixture
    def mock_file_tracker(self):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.integration
    def test_heartbeat_appears_after_initial_delay(
        self, mock_emitter, mock_file_tracker, mock_handler
    ):
        """Test heartbeat message appears after configured initial delay.

        This is the core integration test verifying that:
        1. No heartbeat before initial_delay
        2. Heartbeat appears after initial_delay
        3. Heartbeat includes correct data
        """
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="integration-test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.3,  # 300ms delay
            stop_event=stop_event,
        )

        thread.start()

        # Verify no heartbeat before initial delay
        time.sleep(0.15)  # Half of initial delay
        mock_emitter.item_heartbeat.assert_not_called()

        # Wait past initial delay
        time.sleep(0.25)  # Total: 0.4s > 0.3s initial delay

        # Verify heartbeat appeared
        assert mock_emitter.item_heartbeat.call_count >= 1

        # Verify heartbeat contains expected data
        call_args = mock_emitter.item_heartbeat.call_args[0]
        assert call_args[0] == "integration-test-item"  # item_id
        assert isinstance(call_args[1], int)  # elapsed time
        assert call_args[1] >= 0  # elapsed should be non-negative

        # Cleanup
        thread.stop()

    @pytest.mark.integration
    def test_multiple_heartbeats_over_time(
        self, mock_emitter, mock_file_tracker, mock_handler
    ):
        """Test multiple heartbeats are emitted over extended execution."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="multi-heartbeat-test",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=0.2,  # 200ms between heartbeats
            initial_delay=0.1,  # 100ms initial delay
            stop_event=stop_event,
        )

        thread.start()

        # Wait long enough for multiple heartbeats
        time.sleep(0.5)  # Should get ~2 heartbeats (at 0.1s and 0.3s)

        # Verify multiple heartbeats
        assert mock_emitter.item_heartbeat.call_count >= 2

        # Cleanup
        thread.stop()

    @pytest.mark.integration
    def test_heartbeat_with_file_changes(self, mock_emitter, mock_handler):
        """Test heartbeat correctly reports file changes when they occur."""
        # Create tracker that simulates file changes appearing over time
        tracker = Mock(spec=FileChangeTracker)

        # First poll: no changes
        # Second poll: new file appears
        tracker.poll = Mock(
            side_effect=[
                MagicMock(added=set(), modified=set(), count=0),
                MagicMock(added={"src/new_file.py"}, modified=set(), count=1),
            ]
        )

        mock_handler._count_lines = Mock(return_value=50)

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="file-change-test",
            emitter=mock_emitter,
            file_tracker=tracker,
            handler=mock_handler,
            interval=0.2,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for two heartbeats to occur
        time.sleep(0.5)

        # Verify file event was emitted
        assert mock_emitter.file_event.call_count >= 1
        file_event_call = mock_emitter.file_event.call_args[0]
        assert file_event_call[0] == "src/new_file.py"
        assert file_event_call[1] == "new"
        assert file_event_call[2] == 50  # Line count

        # Cleanup
        thread.stop()


class TestVerbosityScaling:
    """Integration tests for verbosity-based behavior scaling."""

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=0)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(
            return_value=MagicMock(added=set(), modified=set(), count=0)
        )
        return handler

    @pytest.fixture
    def mock_file_tracker(self):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.integration
    def test_detail_verbosity_includes_liveness_indicators(
        self, mock_handler, mock_file_tracker
    ):
        """Test that DETAIL verbosity level includes liveness indicators."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.DETAIL  # DETAIL level

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="detail-test",
            emitter=emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify heartbeat was called with liveness indicators
        assert emitter.item_heartbeat.call_count >= 1
        call_args = emitter.item_heartbeat.call_args[0]

        # Fourth argument should be liveness indicators dict
        liveness = call_args[3]
        assert liveness is not None
        assert isinstance(liveness, dict)
        assert "files" in liveness
        assert "log" in liveness
        assert "proc" in liveness

        # Cleanup
        thread.stop()

    @pytest.mark.integration
    def test_progress_verbosity_no_liveness_indicators(
        self, mock_handler, mock_file_tracker
    ):
        """Test that PROGRESS verbosity level does not include liveness indicators."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS  # PROGRESS level

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="progress-test",
            emitter=emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify heartbeat was called WITHOUT liveness indicators
        assert emitter.item_heartbeat.call_count >= 1
        call_args = emitter.item_heartbeat.call_args[0]

        # Fourth argument should be None (no liveness indicators)
        liveness = call_args[3]
        assert liveness is None

        # Cleanup
        thread.stop()


class TestThreadCleanup:
    """Integration tests for proper thread cleanup and resource management."""

    @pytest.fixture
    def mock_emitter(self):
        """Create mock ProgressEmitter."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=0)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(
            return_value=MagicMock(added=set(), modified=set(), count=0)
        )
        return handler

    @pytest.fixture
    def mock_file_tracker(self):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.integration
    def test_thread_cleanup_after_execution(
        self, mock_emitter, mock_file_tracker, mock_handler
    ):
        """Test thread properly cleans up after execution completes."""
        initial_thread_count = threading.active_count()

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="cleanup-test",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        # Start and run thread
        thread.start()
        time.sleep(0.2)

        # Verify thread is running
        assert thread.is_alive()
        assert threading.active_count() > initial_thread_count

        # Stop thread
        thread.stop()

        # Verify thread count returns to baseline
        time.sleep(0.1)  # Give thread time to exit
        final_thread_count = threading.active_count()
        assert final_thread_count == initial_thread_count

    @pytest.mark.integration
    def test_stop_method_idempotent(
        self, mock_emitter, mock_file_tracker, mock_handler
    ):
        """Test that calling stop() multiple times is safe."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="idempotent-test",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()
        time.sleep(0.2)

        # Call stop multiple times
        thread.stop()
        thread.stop()
        thread.stop()

        # Should not raise exception and thread should be stopped
        assert not thread.is_alive()
