"""Tests for obra/hybrid/json_utils.py.

FIX-GEMINI-UNWRAP-001: Tests for Gemini CLI JSON unwrapper and related utilities.
"""

import pytest

from obra.hybrid.json_utils import (
    extract_json_payload,
    unwrap_claude_cli_json,
    unwrap_gemini_cli_json,
)


class TestUnwrapGeminiCliJson:
    """Tests for unwrap_gemini_cli_json function."""

    def test_gemini_wrapper_with_json_response(self):
        """Test unwrapping Gemini wrapper containing JSON in response field."""
        gemini_wrapper = {
            "response": '{"plan_items": [{"title": "Test Task", "description": "Do something"}]}',
            "stats": {"models": {"gemini-2.5-pro": {"tokens": {"total": 100}}}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert isinstance(result, dict)
        assert "plan_items" in result
        assert result["plan_items"][0]["title"] == "Test Task"

    def test_gemini_wrapper_with_text_response(self):
        """Test unwrapping Gemini wrapper containing plain text response."""
        gemini_wrapper = {
            "response": "The capital of France is Paris.",
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert result == "The capital of France is Paris."

    def test_gemini_wrapper_with_dict_response(self):
        """Test unwrapping Gemini wrapper where response is already a dict."""
        gemini_wrapper = {
            "response": {"plan_items": [{"title": "Task 1"}]},
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert isinstance(result, dict)
        assert result["plan_items"][0]["title"] == "Task 1"

    def test_gemini_wrapper_with_list_response(self):
        """Test unwrapping Gemini wrapper where response is a list."""
        gemini_wrapper = {
            "response": [{"title": "Task 1"}, {"title": "Task 2"}],
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert isinstance(result, list)
        assert len(result) == 2

    def test_gemini_wrapper_with_markdown_code_block(self):
        """Test unwrapping Gemini response with JSON inside markdown code block."""
        gemini_wrapper = {
            "response": '```json\n{"tasks": [{"title": "Build feature"}]}\n```',
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert isinstance(result, dict)
        assert result["tasks"][0]["title"] == "Build feature"

    def test_non_gemini_format_passes_through(self):
        """Test that non-Gemini format data passes through unchanged."""
        non_gemini = {"plan_items": [{"title": "Test"}]}
        result, was_wrapped = unwrap_gemini_cli_json(non_gemini)

        assert was_wrapped is False
        assert result == non_gemini

    def test_non_dict_input_passes_through(self):
        """Test that non-dict input passes through unchanged."""
        list_input = [1, 2, 3]
        result, was_wrapped = unwrap_gemini_cli_json(list_input)

        assert was_wrapped is False
        assert result == list_input

    def test_missing_stats_key_not_recognized(self):
        """Test that dict with response but no stats is not recognized as Gemini wrapper."""
        partial_wrapper = {"response": "Some text"}
        result, was_wrapped = unwrap_gemini_cli_json(partial_wrapper)

        assert was_wrapped is False
        assert result == partial_wrapper

    def test_missing_response_key_not_recognized(self):
        """Test that dict with stats but no response is not recognized as Gemini wrapper."""
        partial_wrapper = {"stats": {"models": {}}}
        result, was_wrapped = unwrap_gemini_cli_json(partial_wrapper)

        assert was_wrapped is False
        assert result == partial_wrapper

    def test_empty_response_string(self):
        """Test handling of empty response string."""
        gemini_wrapper = {
            "response": "",
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert result == ""

    def test_whitespace_only_response(self):
        """Test handling of whitespace-only response."""
        gemini_wrapper = {
            "response": "   \n\t  ",
            "stats": {"models": {}},
        }
        result, was_wrapped = unwrap_gemini_cli_json(gemini_wrapper)

        assert was_wrapped is True
        assert result == ""  # Stripped whitespace


class TestUnwrapClaudeCliJson:
    """Tests for unwrap_claude_cli_json function (existing functionality)."""

    def test_claude_wrapper_with_json_result(self):
        """Test unwrapping Claude CLI wrapper with JSON result."""
        claude_wrapper = {
            "type": "result",
            "result": '{"plan_items": [{"title": "Test"}]}',
        }
        result, was_wrapped = unwrap_claude_cli_json(claude_wrapper)

        assert was_wrapped is True
        assert isinstance(result, dict)
        assert "plan_items" in result

    def test_claude_wrapper_with_text_result(self):
        """Test unwrapping Claude CLI wrapper with plain text result."""
        claude_wrapper = {
            "type": "result",
            "result": "Hello, world!",
        }
        result, was_wrapped = unwrap_claude_cli_json(claude_wrapper)

        assert was_wrapped is True
        assert result == "Hello, world!"

    def test_non_claude_format_passes_through(self):
        """Test that non-Claude format passes through."""
        non_claude = {"plan_items": [{"title": "Test"}]}
        result, was_wrapped = unwrap_claude_cli_json(non_claude)

        assert was_wrapped is False
        assert result == non_claude


class TestExtractJsonPayload:
    """Tests for extract_json_payload function."""

    def test_extract_from_code_block(self):
        """Test extracting JSON from markdown code block."""
        text = '```json\n{"key": "value"}\n```'
        result = extract_json_payload(text)

        assert result == '{"key": "value"}'

    def test_extract_bare_json_object(self):
        """Test extracting bare JSON object."""
        text = 'Some text {"key": "value"} more text'
        result = extract_json_payload(text)

        assert result == '{"key": "value"}'

    def test_extract_bare_json_array(self):
        """Test extracting bare JSON array."""
        text = 'Items: [1, 2, 3] end'
        result = extract_json_payload(text)

        assert result == "[1, 2, 3]"

    def test_empty_string_returns_none(self):
        """Test that empty string returns None."""
        assert extract_json_payload("") is None
        assert extract_json_payload("   ") is None

    def test_no_json_returns_none(self):
        """Test that text without JSON returns None."""
        assert extract_json_payload("Just plain text") is None
