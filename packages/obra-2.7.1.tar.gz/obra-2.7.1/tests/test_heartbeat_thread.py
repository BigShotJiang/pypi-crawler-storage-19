"""Tests for HeartbeatThread in execute.py and fix.py handlers.

This test module validates the heartbeat thread lifecycle, emission behavior,
and cleanup. All tests follow WSL2 resource limits:
- Max sleep: 0.5s per test (or use fast_time fixture)
- Max threads: 5 per test with mandatory timeout
- Thread safety: error tracking in all threaded tests
"""

import threading
import time
from unittest.mock import MagicMock, Mock

import pytest

from obra.display.observability import ObservabilityConfig, ProgressEmitter, VerbosityLevel
from obra.hybrid.handlers.execute import ExecuteHandler, FileChangeTracker, HeartbeatThread


class TestHeartbeatThreadLifecycle:
    """Tests for HeartbeatThread lifecycle (start, stop, join, no orphans)."""

    @pytest.fixture
    def mock_emitter(self):
        """Create mock ProgressEmitter."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=0)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return handler

    @pytest.fixture
    def mock_file_tracker(self, mock_handler):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.unit
    def test_thread_starts_successfully(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test HeartbeatThread starts without errors."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        # Start thread
        thread.start()
        assert thread.is_alive()

        # Stop thread immediately
        stop_event.set()
        thread.join(timeout=2.0)
        assert not thread.is_alive()

    @pytest.mark.unit
    def test_thread_stop_method(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test HeartbeatThread.stop() method properly terminates thread."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()
        assert thread.is_alive()

        # Use stop() method (which sets stop_event and joins)
        thread.stop()
        assert not thread.is_alive()

    @pytest.mark.unit
    def test_thread_is_daemon(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test HeartbeatThread is marked as daemon thread."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        assert thread.daemon is True

        # Cleanup
        stop_event.set()

    @pytest.mark.unit
    def test_no_orphan_threads(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test no threads are left running after stop."""
        initial_thread_count = threading.active_count()

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()
        time.sleep(0.05)  # Let thread start

        # Stop and verify thread count returns to baseline
        thread.stop()
        time.sleep(0.05)  # Let thread cleanup

        final_thread_count = threading.active_count()
        assert final_thread_count == initial_thread_count

    @pytest.mark.unit
    def test_join_timeout_prevents_hang(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test join() has timeout to prevent indefinite hang."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Join with timeout (should not hang even if thread doesn't stop)
        start = time.time()
        thread.join(timeout=0.5)
        elapsed = time.time() - start

        # Verify join respected timeout
        assert elapsed < 1.0

        # Cleanup
        stop_event.set()
        thread.join(timeout=2.0)


class TestHeartbeatEmission:
    """Tests for heartbeat emission behavior."""

    @pytest.fixture
    def mock_emitter(self):
        """Create mock ProgressEmitter."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=5)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return handler

    @pytest.fixture
    def mock_file_tracker(self):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.unit
    def test_heartbeat_waits_for_initial_delay(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test heartbeat waits for initial_delay before first emission."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.2,
            stop_event=stop_event,
        )

        thread.start()

        # Wait less than initial_delay - should not have emitted yet
        time.sleep(0.1)
        mock_emitter.item_heartbeat.assert_not_called()

        # Wait past initial_delay - should have emitted
        time.sleep(0.2)
        assert mock_emitter.item_heartbeat.call_count >= 1

        # Cleanup
        thread.stop()

    @pytest.mark.unit
    def test_heartbeat_includes_elapsed_time(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test heartbeat includes elapsed time since start."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify heartbeat called with elapsed time
        assert mock_emitter.item_heartbeat.call_count >= 1
        call_args = mock_emitter.item_heartbeat.call_args[0]

        # Args: item_id, elapsed_s, file_count, liveness_indicators
        assert call_args[0] == "test-item"
        assert isinstance(call_args[1], int)  # elapsed time
        assert call_args[1] >= 0

        # Cleanup
        thread.stop()

    @pytest.mark.unit
    def test_heartbeat_includes_file_count(self, mock_emitter, mock_file_tracker, mock_handler):
        """Test heartbeat includes file count."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify heartbeat called with file count
        assert mock_emitter.item_heartbeat.call_count >= 1
        call_args = mock_emitter.item_heartbeat.call_args[0]

        # Args: item_id, elapsed_s, file_count, liveness_indicators
        assert call_args[2] == 5  # From mock_handler._count_file_changes()

        # Cleanup
        thread.stop()


class TestLivenessIndicators:
    """Tests for liveness indicator reporting."""

    @pytest.fixture
    def mock_emitter_detail(self):
        """Create mock ProgressEmitter with DETAIL verbosity."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.DETAIL
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=3)
        handler._count_lines = Mock(return_value=None)
        handler._get_file_changes = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return handler

    @pytest.fixture
    def mock_file_tracker(self):
        """Create mock FileChangeTracker."""
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return tracker

    @pytest.mark.unit
    def test_liveness_indicators_at_detail_verbosity(self, mock_emitter_detail, mock_file_tracker, mock_handler):
        """Test liveness indicators included at DETAIL verbosity."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter_detail,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify heartbeat called with liveness indicators
        assert mock_emitter_detail.item_heartbeat.call_count >= 1
        call_args = mock_emitter_detail.item_heartbeat.call_args[0]

        # Args: item_id, elapsed_s, file_count, liveness_indicators
        liveness = call_args[3]
        assert liveness is not None
        assert isinstance(liveness, dict)
        assert "files" in liveness
        assert "log" in liveness
        assert "proc" in liveness

        # Cleanup
        thread.stop()

    @pytest.mark.unit
    def test_liveness_files_indicator(self, mock_emitter_detail, mock_file_tracker, mock_handler):
        """Test liveness 'files' indicator reflects file changes."""
        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter_detail,
            file_tracker=mock_file_tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat
        time.sleep(0.2)

        # Verify liveness indicators show files=True (file_count=3 > 0)
        call_args = mock_emitter_detail.item_heartbeat.call_args[0]
        liveness = call_args[3]
        assert liveness["files"] is True  # file_count > 0
        assert liveness["proc"] is True  # Always true in loop

        # Cleanup
        thread.stop()


class TestFileEventEmission:
    """Tests for file event emission behavior."""

    @pytest.fixture
    def mock_emitter(self):
        """Create mock ProgressEmitter."""
        emitter = Mock(spec=ProgressEmitter)
        emitter.config = Mock(spec=ObservabilityConfig)
        emitter.config.verbosity = VerbosityLevel.PROGRESS
        return emitter

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        handler._count_file_changes = Mock(return_value=0)
        handler._count_lines = Mock(return_value=42)
        handler._get_file_changes = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))
        return handler

    @pytest.mark.unit
    def test_file_events_emitted_for_new_files(self, mock_emitter, mock_handler):
        """Test file events emitted when new files detected."""
        # Create tracker that returns new files
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(
            return_value=MagicMock(
                added={"src/new_file.py"},
                modified=set(),
                count=1,
            )
        )

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat and file event
        time.sleep(0.2)

        # Verify file_event called for new file
        assert mock_emitter.file_event.call_count >= 1
        call_args = mock_emitter.file_event.call_args[0]
        assert call_args[0] == "src/new_file.py"
        assert call_args[1] == "new"
        assert call_args[2] == 42  # Line count from mock

        # Cleanup
        thread.stop()

    @pytest.mark.unit
    def test_file_events_emitted_for_modified_files(self, mock_emitter, mock_handler):
        """Test file events emitted when files modified."""
        # Create tracker that returns modified files
        tracker = Mock(spec=FileChangeTracker)
        tracker.poll = Mock(
            return_value=MagicMock(
                added=set(),
                modified={"src/existing_file.py"},
                count=1,
            )
        )

        stop_event = threading.Event()
        thread = HeartbeatThread(
            item_id="test-item",
            emitter=mock_emitter,
            file_tracker=tracker,
            handler=mock_handler,
            interval=1,
            initial_delay=0.1,
            stop_event=stop_event,
        )

        thread.start()

        # Wait for first heartbeat and file event
        time.sleep(0.2)

        # Verify file_event called for modified file
        assert mock_emitter.file_event.call_count >= 1
        call_args = mock_emitter.file_event.call_args[0]
        assert call_args[0] == "src/existing_file.py"
        assert call_args[1] == "modified"
        assert call_args[2] == 42  # Line count from mock

        # Cleanup
        thread.stop()


class TestThreadSafety:
    """Tests for thread safety and error handling."""

    @pytest.mark.unit
    def test_multiple_threads_no_interference(self, tmp_path):
        """Test multiple HeartbeatThreads can run concurrently without errors.

        Note: Uses 3 threads (under the 5 thread limit).
        """
        errors = []

        def safe_thread_runner(thread_id):
            """Run a heartbeat thread and track errors."""
            try:
                emitter = Mock(spec=ProgressEmitter)
                emitter.config = Mock(spec=ObservabilityConfig)
                emitter.config.verbosity = VerbosityLevel.PROGRESS

                handler = Mock(spec=ExecuteHandler)
                handler._working_dir = tmp_path
                handler._count_file_changes = Mock(return_value=0)
                handler._count_lines = Mock(return_value=None)
                handler._get_file_changes = Mock(
                    return_value=MagicMock(added=set(), modified=set(), count=0)
                )

                tracker = Mock(spec=FileChangeTracker)
                tracker.poll = Mock(return_value=MagicMock(added=set(), modified=set(), count=0))

                stop_event = threading.Event()
                thread = HeartbeatThread(
                    item_id=f"test-item-{thread_id}",
                    emitter=emitter,
                    file_tracker=tracker,
                    handler=handler,
                    interval=1,
                    initial_delay=0.1,
                    stop_event=stop_event,
                )

                thread.start()
                time.sleep(0.2)
                thread.stop()
            except Exception as e:
                errors.append(e)

        # Create 3 threads (under limit)
        threads = [threading.Thread(target=safe_thread_runner, args=(i,)) for i in range(3)]

        for t in threads:
            t.start()

        # Join with timeout (mandatory)
        for t in threads:
            t.join(timeout=5.0)

        # Verify no errors
        assert len(errors) == 0, f"Thread errors: {errors}"

