"""Tests for FileChangeTracker in execute.py handler.

This test module validates the file change tracking functionality that monitors
file additions and modifications between poll intervals.

All tests follow WSL2 resource limits:
- No threading (FileChangeTracker is not threaded)
- Fast execution (< 1s per test)
- Isolated tests with no shared state
"""

from unittest.mock import Mock

import pytest

from obra.hybrid.handlers.execute import ExecuteHandler, FileChangeSet, FileChangeTracker


class TestFileChangeTrackerBasics:
    """Basic tests for FileChangeTracker initialization and behavior."""

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        return handler

    @pytest.mark.unit
    def test_initialization(self, mock_handler):
        """Test FileChangeTracker initializes with empty state."""
        tracker = FileChangeTracker(mock_handler)

        assert tracker._handler == mock_handler
        assert tracker._previous_added == set()
        assert tracker._previous_modified == set()

    @pytest.mark.unit
    def test_first_poll_returns_all_changes(self, mock_handler):
        """Test first poll returns all current changes."""
        # Set up handler to return some file changes
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/new_file.py", "src/another_file.py"},
                modified={"src/existing.py"},
                count=3,
            )
        )

        tracker = FileChangeTracker(mock_handler)
        result = tracker.poll()

        # First poll should return all changes
        assert result.added == {"src/new_file.py", "src/another_file.py"}
        assert result.modified == {"src/existing.py"}
        assert result.count == 3

    @pytest.mark.unit
    def test_second_poll_returns_only_delta(self, mock_handler):
        """Test second poll returns only NEW changes since first poll."""
        # First poll: some files changed
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/file1.py"},
                modified={"src/file2.py"},
                count=2,
            )
        )

        tracker = FileChangeTracker(mock_handler)
        first_result = tracker.poll()

        assert first_result.count == 2

        # Second poll: same files plus new ones
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/file1.py", "src/file3.py"},  # file1 old, file3 new
                modified={"src/file2.py", "src/file4.py"},  # file2 old, file4 new
                count=4,
            )
        )

        second_result = tracker.poll()

        # Should only return NEW files
        assert second_result.added == {"src/file3.py"}
        assert second_result.modified == {"src/file4.py"}
        assert second_result.count == 2  # Only 2 new files

    @pytest.mark.unit
    def test_poll_with_no_new_changes(self, mock_handler):
        """Test poll returns empty set when no new changes."""
        # First poll: some files changed
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/file1.py"},
                modified={"src/file2.py"},
                count=2,
            )
        )

        tracker = FileChangeTracker(mock_handler)
        tracker.poll()

        # Second poll: same files, no new changes
        second_result = tracker.poll()

        assert second_result.added == set()
        assert second_result.modified == set()
        assert second_result.count == 0


class TestFileChangeTrackerEdgeCases:
    """Edge case tests for FileChangeTracker."""

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        return handler

    @pytest.mark.unit
    def test_poll_with_empty_initial_state(self, mock_handler):
        """Test poll when no files have changed yet."""
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added=set(), modified=set(), count=0)
        )

        tracker = FileChangeTracker(mock_handler)
        result = tracker.poll()

        assert result.added == set()
        assert result.modified == set()
        assert result.count == 0

    @pytest.mark.unit
    def test_multiple_polls_track_cumulative_state(self, mock_handler):
        """Test multiple polls correctly track cumulative state."""
        tracker = FileChangeTracker(mock_handler)

        # Poll 1: Add file1
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added={"file1.py"}, modified=set(), count=1)
        )
        result1 = tracker.poll()
        assert result1.added == {"file1.py"}
        assert result1.count == 1

        # Poll 2: Add file2 (file1 still present)
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"file1.py", "file2.py"}, modified=set(), count=2
            )
        )
        result2 = tracker.poll()
        assert result2.added == {"file2.py"}  # Only new file
        assert result2.count == 1

        # Poll 3: Add file3 (file1, file2 still present)
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"file1.py", "file2.py", "file3.py"}, modified=set(), count=3
            )
        )
        result3 = tracker.poll()
        assert result3.added == {"file3.py"}  # Only new file
        assert result3.count == 1

    @pytest.mark.unit
    def test_file_moves_from_added_to_modified(self, mock_handler):
        """Test tracking when a file appears first as added, then as modified."""
        tracker = FileChangeTracker(mock_handler)

        # Poll 1: file appears as added
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added={"file.py"}, modified=set(), count=1)
        )
        result1 = tracker.poll()
        assert result1.added == {"file.py"}

        # Poll 2: same file now appears in modified (git staged it)
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"file.py"}, modified={"file.py"}, count=2
            )
        )
        result2 = tracker.poll()
        # File is not NEW in modified, so shouldn't appear
        assert result2.added == set()
        assert result2.modified == {"file.py"}
        assert result2.count == 1

    @pytest.mark.unit
    def test_file_disappears_then_reappears(self, mock_handler):
        """Test file that disappears from changes then reappears later."""
        tracker = FileChangeTracker(mock_handler)

        # Poll 1: file present
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added={"file.py"}, modified=set(), count=1)
        )
        tracker.poll()

        # Poll 2: file disappears (git reset, deleted, etc.)
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added=set(), modified=set(), count=0)
        )
        result2 = tracker.poll()
        # No files in current poll, so nothing new
        assert result2.added == set()
        assert result2.count == 0

        # Poll 3: file reappears
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added={"file.py"}, modified=set(), count=1)
        )
        result3 = tracker.poll()

        # File SHOULD appear as new (it's new compared to previous poll which had no files)
        assert result3.added == {"file.py"}
        assert result3.count == 1


class TestFileChangeTrackerIntegration:
    """Integration-style tests using more realistic scenarios."""

    @pytest.fixture
    def mock_handler(self, tmp_path):
        """Create mock ExecuteHandler."""
        handler = Mock(spec=ExecuteHandler)
        handler._working_dir = tmp_path
        return handler

    @pytest.mark.unit
    def test_typical_development_workflow(self, mock_handler):
        """Test typical development workflow: create, modify, create more."""
        tracker = FileChangeTracker(mock_handler)

        # Step 1: Create initial file
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(added={"src/main.py"}, modified=set(), count=1)
        )
        result = tracker.poll()
        assert result.added == {"src/main.py"}

        # Step 2: Modify that file
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/main.py"}, modified={"src/main.py"}, count=2
            )
        )
        result = tracker.poll()
        assert result.modified == {"src/main.py"}
        assert result.added == set()

        # Step 3: Create test file
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/main.py", "tests/test_main.py"},
                modified={"src/main.py"},
                count=3,
            )
        )
        result = tracker.poll()
        assert result.added == {"tests/test_main.py"}
        assert result.modified == set()  # main.py already tracked as modified

        # Step 4: Modify both files
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"src/main.py", "tests/test_main.py"},
                modified={"src/main.py", "tests/test_main.py"},
                count=4,
            )
        )
        result = tracker.poll()
        assert result.added == set()
        assert result.modified == {"tests/test_main.py"}  # Only new modification

    @pytest.mark.unit
    def test_count_accuracy(self, mock_handler):
        """Test that count field is accurately calculated."""
        tracker = FileChangeTracker(mock_handler)

        # Poll with multiple changes
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"a.py", "b.py", "c.py"},
                modified={"d.py", "e.py"},
                count=5,
            )
        )
        result = tracker.poll()
        assert result.count == 5
        assert result.count == len(result.added) + len(result.modified)

        # Poll with only delta
        mock_handler._get_file_changes = Mock(
            return_value=FileChangeSet(
                added={"a.py", "b.py", "c.py", "f.py"},  # f.py is new
                modified={"d.py", "e.py", "g.py"},  # g.py is new
                count=7,
            )
        )
        result = tracker.poll()
        assert result.count == 2  # Only f.py and g.py are new
        assert result.count == len(result.added) + len(result.modified)
