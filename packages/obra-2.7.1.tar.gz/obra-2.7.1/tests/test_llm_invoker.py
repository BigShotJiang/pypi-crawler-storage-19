"""Tests for LLMInvoker functionality.

Tests verify provider discovery and lazy loading behavior.

Related:
    - CHORE-DOBRA-HARDENING-001: DObra production hardening
    - obra/llm/invoker.py
"""

import pytest

from obra.llm.invoker import LLMInvoker


class TestLLMInvokerProviderDiscovery:
    """Test suite for LLMInvoker provider discovery."""

    def test_available_providers_returns_all_known_providers(self):
        """Verify available_providers returns all 4 supported providers.

        This test ensures consistent provider discovery without
        triggering lazy loading.

        Related: CHORE-DOBRA-HARDENING-001, R1
        """
        invoker = LLMInvoker()

        providers = invoker.available_providers

        assert providers == ["anthropic", "google", "openai", "ollama"]
        assert len(providers) == 4

    def test_available_providers_does_not_trigger_lazy_load(self):
        """Verify available_providers doesn't instantiate providers.

        The internal _providers dict should remain empty until
        a provider is explicitly requested via invoke/is_available.

        Related: CHORE-DOBRA-HARDENING-001, R1
        """
        invoker = LLMInvoker()

        # Access available_providers
        _ = invoker.available_providers

        # Internal providers dict should still be empty
        assert invoker._providers == {}

    def test_available_providers_is_consistent(self):
        """Verify available_providers always returns the same list.

        Multiple calls should return identical results.
        """
        invoker = LLMInvoker()

        first_call = invoker.available_providers
        second_call = invoker.available_providers

        assert first_call == second_call
        assert first_call is not second_call  # New list each time

    def test_available_providers_with_registered_provider(self):
        """Verify available_providers includes known providers even when one is registered.

        The property should return the full list regardless of
        lazy load state.
        """
        invoker = LLMInvoker()

        # Trigger lazy load for one provider
        invoker._get_provider("anthropic")

        # available_providers should still list all 4
        providers = invoker.available_providers
        assert len(providers) == 4
        assert "anthropic" in providers


class TestLLMInvokerLazyLoading:
    """Test suite for LLMInvoker lazy loading behavior."""

    def test_lazy_load_anthropic_provider(self):
        """Verify anthropic provider can be lazy loaded."""
        invoker = LLMInvoker()

        # Initially empty
        assert "anthropic" not in invoker._providers

        # Trigger lazy load
        provider = invoker._get_provider("anthropic")

        # Should be loaded (may be None if deps missing, but key should be added if successful)
        # We just verify it doesn't crash and returns something
        assert provider is not None or "anthropic" not in invoker._providers

    def test_unknown_provider_returns_none(self):
        """Verify unknown provider returns None."""
        invoker = LLMInvoker()

        provider = invoker._get_provider("unknown_provider")

        assert provider is None
