"""Tests for timeout configuration getters.

Tests the 3-tier resolution pattern for agent execution and review timeouts:
env > config > default.

FIX-TIMEOUT-CONSOLIDATION-001
"""

from pathlib import Path
from unittest.mock import patch

import pytest

from obra.config.loaders import (
    DEFAULT_AGENT_EXECUTION_TIMEOUT,
    DEFAULT_REVIEW_AGENT_TIMEOUT,
    get_agent_execution_timeout,
    get_review_agent_timeout,
)


class TestGetAgentExecutionTimeout:
    """Tests for get_agent_execution_timeout()."""

    def test_default_value(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """Should return default when no env var or config."""
        # Clear env var
        monkeypatch.delenv("OBRA_AGENT_EXECUTION_TIMEOUT", raising=False)

        # Mock load_config to return empty config
        with patch("obra.config.loaders.load_config", return_value={}):
            assert get_agent_execution_timeout() == DEFAULT_AGENT_EXECUTION_TIMEOUT
            assert get_agent_execution_timeout() == 5400

    def test_env_override(self, monkeypatch: pytest.MonkeyPatch):
        """Should use env var when set."""
        monkeypatch.setenv("OBRA_AGENT_EXECUTION_TIMEOUT", "300")

        with patch("obra.config.loaders.load_config", return_value={}):
            assert get_agent_execution_timeout() == 300

    def test_config_override(self, monkeypatch: pytest.MonkeyPatch):
        """Should use config value when env var not set."""
        # Clear env var
        monkeypatch.delenv("OBRA_AGENT_EXECUTION_TIMEOUT", raising=False)

        # Mock config with timeout value
        config = {"orchestration": {"timeouts": {"agent_execution_s": 900}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_agent_execution_timeout() == 900

    def test_env_takes_precedence(self, monkeypatch: pytest.MonkeyPatch):
        """Env var should take precedence over config."""
        monkeypatch.setenv("OBRA_AGENT_EXECUTION_TIMEOUT", "300")

        # Config has different value
        config = {"orchestration": {"timeouts": {"agent_execution_s": 900}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_agent_execution_timeout() == 300

    def test_invalid_env_falls_through(self, monkeypatch: pytest.MonkeyPatch):
        """Invalid env var should fall through to config."""
        monkeypatch.setenv("OBRA_AGENT_EXECUTION_TIMEOUT", "not-a-number")

        config = {"orchestration": {"timeouts": {"agent_execution_s": 900}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_agent_execution_timeout() == 900

    def test_missing_config_section(self, monkeypatch: pytest.MonkeyPatch):
        """Should handle missing config sections gracefully."""
        monkeypatch.delenv("OBRA_AGENT_EXECUTION_TIMEOUT", raising=False)

        # Config missing orchestration.timeouts section
        config = {"orchestration": {}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_agent_execution_timeout() == DEFAULT_AGENT_EXECUTION_TIMEOUT


class TestGetReviewAgentTimeout:
    """Tests for get_review_agent_timeout()."""

    def test_default_value(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """Should return default when no env var or config."""
        # Clear env var
        monkeypatch.delenv("OBRA_REVIEW_AGENT_TIMEOUT", raising=False)

        # Mock load_config to return empty config
        with patch("obra.config.loaders.load_config", return_value={}):
            assert get_review_agent_timeout() == DEFAULT_REVIEW_AGENT_TIMEOUT
            assert get_review_agent_timeout() == 1800

    def test_env_override(self, monkeypatch: pytest.MonkeyPatch):
        """Should use env var when set."""
        monkeypatch.setenv("OBRA_REVIEW_AGENT_TIMEOUT", "120")

        with patch("obra.config.loaders.load_config", return_value={}):
            assert get_review_agent_timeout() == 120

    def test_config_override(self, monkeypatch: pytest.MonkeyPatch):
        """Should use config value when env var not set."""
        # Clear env var
        monkeypatch.delenv("OBRA_REVIEW_AGENT_TIMEOUT", raising=False)

        # Mock config with timeout value
        config = {"orchestration": {"timeouts": {"review_agent_s": 90}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_review_agent_timeout() == 90

    def test_env_takes_precedence(self, monkeypatch: pytest.MonkeyPatch):
        """Env var should take precedence over config."""
        monkeypatch.setenv("OBRA_REVIEW_AGENT_TIMEOUT", "120")

        # Config has different value
        config = {"orchestration": {"timeouts": {"review_agent_s": 90}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_review_agent_timeout() == 120

    def test_invalid_env_falls_through(self, monkeypatch: pytest.MonkeyPatch):
        """Invalid env var should fall through to config."""
        monkeypatch.setenv("OBRA_REVIEW_AGENT_TIMEOUT", "not-a-number")

        config = {"orchestration": {"timeouts": {"review_agent_s": 90}}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_review_agent_timeout() == 90

    def test_missing_config_section(self, monkeypatch: pytest.MonkeyPatch):
        """Should handle missing config sections gracefully."""
        monkeypatch.delenv("OBRA_REVIEW_AGENT_TIMEOUT", raising=False)

        # Config missing orchestration.timeouts section
        config = {"orchestration": {}}

        with patch("obra.config.loaders.load_config", return_value=config):
            assert get_review_agent_timeout() == DEFAULT_REVIEW_AGENT_TIMEOUT
