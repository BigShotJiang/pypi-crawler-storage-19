"""Regression tests for protocol escalation handling.

Tests ensure client can parse all escalation reasons that the server coordinator sends,
preventing ValueError crashes during enum construction.

Related:
    - ISSUE-CLI-019: EscalationReason enum mismatch
    - obra/api/protocol.py:93-99 (EscalationReason enum)
    - functions/src/orchestration/coordinator.py:689,1021,1058 (server sends reasons)
"""

import pytest

from obra.api.protocol import EscalationNotice, EscalationReason


class TestEscalationReasonEnumCoverage:
    """Test client can parse all escalation reasons server sends."""

    def test_issue_cli_019_max_refinement_iterations(self):
        """ISSUE-CLI-019: Client must support 'max_refinement_iterations' from server.

        Server sends this when refinement phase hits max iterations (default 3).
        Location: functions/src/orchestration/coordinator.py:689

        This test will FAIL before fix with:
            ValueError: 'max_refinement_iterations' is not a valid EscalationReason
        """
        payload = {
            "escalation_id": "esc_001",
            "reason": "max_refinement_iterations",  # Server sends this
            "blocking_issues": [{"severity": "P0", "description": "Test blocked"}],
            "iteration_history": [],
            "options": [],
        }

        # This should NOT crash
        notice = EscalationNotice.from_payload(payload)

        assert notice.reason == EscalationReason.MAX_REFINEMENT_ITERATIONS
        assert notice.escalation_id == "esc_001"
        assert len(notice.blocking_issues) == 1

    def test_issue_cli_019_quality_threshold_not_met(self):
        """ISSUE-CLI-019: Client must support 'quality_threshold_not_met' from server.

        Server sends this when quality score fails to meet threshold.
        Location: functions/src/orchestration/coordinator.py:1021

        This test will FAIL before fix with:
            ValueError: 'quality_threshold_not_met' is not a valid EscalationReason
        """
        payload = {
            "escalation_id": "esc_002",
            "reason": "quality_threshold_not_met",  # Server sends this
            "blocking_issues": [],
            "iteration_history": [{"quality_score": 0.65}],
            "options": [],
        }

        # This should NOT crash
        notice = EscalationNotice.from_payload(payload)

        assert notice.reason == EscalationReason.QUALITY_THRESHOLD_NOT_MET
        assert notice.escalation_id == "esc_002"

    def test_issue_cli_019_pending_human_review(self):
        """ISSUE-CLI-019: Client must support 'pending_human_review' from server.

        Server sends this when quality is good but human review requested.
        Location: functions/src/orchestration/coordinator.py:1058

        This test will FAIL before fix with:
            ValueError: 'pending_human_review' is not a valid EscalationReason
        """
        payload = {
            "escalation_id": "esc_003",
            "reason": "pending_human_review",  # Server sends this
            "blocking_issues": [],
            "iteration_history": [],
            "options": [{"action": "approve", "label": "Approve changes"}],
        }

        # This should NOT crash
        notice = EscalationNotice.from_payload(payload)

        assert notice.reason == EscalationReason.PENDING_HUMAN_REVIEW
        assert notice.escalation_id == "esc_003"
        assert len(notice.options) == 1

    def test_existing_escalation_reasons_still_work(self):
        """Verify existing escalation reasons remain functional after fix."""
        existing_reasons = [
            "max_iterations",
            "oscillation",
            "user_requested",
            "blocked",
        ]

        for reason_value in existing_reasons:
            payload = {
                "escalation_id": f"esc_{reason_value}",
                "reason": reason_value,
                "blocking_issues": [],
                "iteration_history": [],
                "options": [],
            }

            notice = EscalationNotice.from_payload(payload)
            assert notice.reason.value == reason_value

    def test_fallback_to_blocked_on_unknown_reason(self):
        """Verify fallback behavior when reason is missing from payload."""
        payload = {
            "escalation_id": "esc_004",
            # "reason" key missing
            "blocking_issues": [],
            "iteration_history": [],
            "options": [],
        }

        notice = EscalationNotice.from_payload(payload)

        # Should fallback to "blocked" per protocol.py:433
        assert notice.reason == EscalationReason.BLOCKED
        assert notice.escalation_id == "esc_004"


class TestEscalationNoticePayloadParsing:
    """Test EscalationNotice.from_payload handles various payload formats."""

    def test_complete_payload(self):
        """Test parsing complete escalation payload with all fields."""
        payload = {
            "escalation_id": "esc_complete",
            "reason": "max_refinement_iterations",
            "blocking_issues": [
                {"severity": "P0", "description": "Import error"},
                {"severity": "P1", "description": "Type mismatch"},
            ],
            "iteration_history": [
                {"iteration": 1, "action": "examine"},
                {"iteration": 2, "action": "revise"},
                {"iteration": 3, "action": "examine"},
            ],
            "options": [
                {"action": "force_complete", "label": "Force completion"},
                {"action": "continue_fixing", "label": "Continue fixing"},
            ],
        }

        notice = EscalationNotice.from_payload(payload)

        assert notice.escalation_id == "esc_complete"
        assert notice.reason == EscalationReason.MAX_REFINEMENT_ITERATIONS
        assert len(notice.blocking_issues) == 2
        assert len(notice.iteration_history) == 3
        assert len(notice.options) == 2

    def test_minimal_payload(self):
        """Test parsing minimal escalation payload with only required fields."""
        payload = {
            "escalation_id": "esc_minimal",
            "reason": "user_requested",
        }

        notice = EscalationNotice.from_payload(payload)

        assert notice.escalation_id == "esc_minimal"
        assert notice.reason == EscalationReason.USER_REQUESTED
        assert notice.blocking_issues == []
        assert notice.iteration_history == []
        assert notice.options == []

    def test_empty_lists_in_payload(self):
        """Test parsing escalation with explicitly empty lists."""
        payload = {
            "escalation_id": "esc_empty",
            "reason": "oscillation",
            "blocking_issues": [],
            "iteration_history": [],
            "options": [],
        }

        notice = EscalationNotice.from_payload(payload)

        assert notice.escalation_id == "esc_empty"
        assert notice.reason == EscalationReason.OSCILLATION
        assert isinstance(notice.blocking_issues, list)
        assert isinstance(notice.iteration_history, list)
        assert isinstance(notice.options, list)
