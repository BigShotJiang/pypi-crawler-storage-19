"""Regression tests for ISSUE: src imports leaking into obra package.

The obra package is the SaaS product distributed to customers via PyPI.
It must be 100% self-contained with NO imports from the src/ (dobra) package.

This test ensures no hard `from src.` or `import src.` statements exist
in the packaged code that would cause import failures for end users.

Allowed exceptions:
- Imports inside try/except blocks (graceful fallback)
- Test files (not distributed)
- Comments mentioning src
"""

import ast
import re
from pathlib import Path

import pytest


def get_obra_package_files() -> list[Path]:
    """Get all Python files in the obra package (excluding tests and build)."""
    obra_root = Path(__file__).parent.parent
    py_files = []

    for py_file in obra_root.rglob("*.py"):
        # Skip test files
        if "/tests/" in str(py_file) or py_file.name.startswith("test_"):
            continue
        # Skip build artifacts
        if "/build/" in str(py_file):
            continue
        py_files.append(py_file)

    return py_files


def has_unguarded_src_import(file_path: Path) -> tuple[bool, list[str]]:
    """Check if a file has unguarded imports from src.

    Returns:
        Tuple of (has_violation, list of violation descriptions)
    """
    content = file_path.read_text(encoding="utf-8")
    violations = []

    try:
        tree = ast.parse(content)
    except SyntaxError:
        # Can't parse - skip
        return False, []

    for node in ast.walk(tree):
        # Check Import nodes: import src.foo
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.startswith("src.") or alias.name == "src":
                    # Check if this import is inside a try block
                    if not _is_inside_try_block(tree, node):
                        violations.append(
                            f"Line {node.lineno}: import {alias.name}"
                        )

        # Check ImportFrom nodes: from src.foo import bar
        elif isinstance(node, ast.ImportFrom):
            if node.module and (node.module.startswith("src.") or node.module == "src"):
                # Check if this import is inside a try block
                if not _is_inside_try_block(tree, node):
                    violations.append(
                        f"Line {node.lineno}: from {node.module} import ..."
                    )

    return len(violations) > 0, violations


def _is_inside_try_block(tree: ast.AST, target_node: ast.AST) -> bool:
    """Check if a node is inside a try block (has graceful fallback)."""

    class TryBlockFinder(ast.NodeVisitor):
        def __init__(self):
            self.try_blocks = []

        def visit_Try(self, node):
            # Record line range of try block body
            if node.body:
                start = node.body[0].lineno
                end = node.body[-1].end_lineno or node.body[-1].lineno
                self.try_blocks.append((start, end))
            self.generic_visit(node)

    finder = TryBlockFinder()
    finder.visit(tree)

    target_line = target_node.lineno
    for start, end in finder.try_blocks:
        if start <= target_line <= end:
            return True

    return False


class TestNoSrcImportsInObraPackage:
    """Ensure no unguarded src imports exist in obra package."""

    def test_no_unguarded_src_imports(self):
        """All obra package files must not have unguarded imports from src.

        Imports inside try/except blocks are allowed (graceful fallback).
        """
        obra_files = get_obra_package_files()
        assert len(obra_files) > 0, "Should find obra package files"

        violations = []
        for py_file in obra_files:
            has_violation, file_violations = has_unguarded_src_import(py_file)
            if has_violation:
                relative_path = py_file.relative_to(Path(__file__).parent.parent)
                for violation in file_violations:
                    violations.append(f"{relative_path}: {violation}")

        if violations:
            violation_list = "\n  - ".join(violations)
            pytest.fail(
                f"Found unguarded 'from src.' imports in obra package:\n"
                f"  - {violation_list}\n\n"
                f"These imports will fail for users who install obra via pip.\n"
                f"Fix: Move the required code into the obra package, or wrap "
                f"in try/except with graceful fallback."
            )

    def test_cli_imports_successfully(self):
        """The CLI entry point must import without errors.

        This is the critical import path - if this fails, users can't run obra.
        """
        # This import chain was failing before the fix
        from obra.cli import main

        assert main is not None

    def test_key_modules_importable(self):
        """Key modules must be importable without src dependencies."""
        # These imports should all work
        from obra.validation.exceptions import YamlValidationError
        from obra.project.defaults import ensure_obra_claude_md
        from obra.project.context import ProjectContextManager
        from obra.workflow.tiered_resolver import TieredResolver
        from obra.agents.claude_code import ClaudeCodeAgent
        from obra.hybrid.handlers.derive import DeriveHandler

        # Basic sanity checks
        assert YamlValidationError is not None
        assert ensure_obra_claude_md is not None
        assert ProjectContextManager is not None
        assert TieredResolver is not None
        assert ClaudeCodeAgent is not None
        assert DeriveHandler is not None
