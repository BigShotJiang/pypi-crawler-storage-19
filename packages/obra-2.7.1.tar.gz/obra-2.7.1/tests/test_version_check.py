"""Tests for obra.version_check module.

Tests version comparison, PyPI fetching, caching, and async behavior.

Resource Limits (per docs/quality/testing/test-guidelines.md):
- Max sleep: 0.5s per test
- Max threads: 5 per test
- Max memory: 20KB per test

Reference: FEAT-CLI-VERSION-NOTIFY-001 Story S0
"""

import json
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from obra.version_check import (
    CACHE_FILE,
    compare_versions,
    fetch_latest_version,
    read_cache,
    write_cache,
    check_for_updates_async,
    _background_check,
)


# =============================================================================
# S0.T4: Version Comparison Tests
# =============================================================================


class TestCompareVersions:
    """Tests for semantic version comparison."""

    def test_newer_major_version(self):
        """Test detection of newer major version."""
        assert compare_versions("2.5.47", "3.0.0") is True

    def test_newer_minor_version(self):
        """Test detection of newer minor version."""
        assert compare_versions("2.5.47", "2.6.0") is True

    def test_newer_patch_version(self):
        """Test detection of newer patch version."""
        assert compare_versions("2.5.47", "2.5.48") is True

    def test_same_version(self):
        """Test identical versions return False."""
        assert compare_versions("2.5.47", "2.5.47") is False

    def test_older_version(self):
        """Test older version returns False."""
        assert compare_versions("2.6.0", "2.5.99") is False

    def test_semver_ordering(self):
        """Test semantic version ordering (2.6.0 > 2.5.99)."""
        assert compare_versions("2.5.99", "2.6.0") is True
        assert compare_versions("2.6.0", "2.5.99") is False

    def test_prerelease_versions(self):
        """Test prerelease version handling."""
        # Stable > prerelease of same version
        assert compare_versions("2.5.47-beta.1", "2.5.47") is True
        # Prerelease of newer version > stable
        assert compare_versions("2.5.47", "2.6.0-beta.1") is True
        # Same version with prerelease = no update
        assert compare_versions("2.5.47", "2.5.47-beta.1") is False

    def test_dev_versions(self):
        """Test dev version handling."""
        assert compare_versions("2.5.47.dev1", "2.5.47") is True
        assert compare_versions("2.5.47", "2.5.48.dev1") is True

    def test_invalid_version_current(self):
        """Test invalid current version returns False."""
        assert compare_versions("not-a-version", "2.6.0") is False

    def test_invalid_version_latest(self):
        """Test invalid latest version returns False."""
        assert compare_versions("2.5.47", "not-a-version") is False

    def test_invalid_both_versions(self):
        """Test both invalid versions returns False."""
        assert compare_versions("invalid", "also-invalid") is False


# =============================================================================
# S0.T5: Async Behavior and Timeout Tests
# =============================================================================


class TestFetchLatestVersion:
    """Tests for PyPI API fetching."""

    @patch("obra.version_check.requests.get")
    def test_successful_fetch(self, mock_get):
        """Test successful PyPI API fetch."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"info": {"version": "2.6.0"}}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        result = fetch_latest_version()

        assert result == "2.6.0"
        mock_get.assert_called_once()
        assert mock_get.call_args[1]["timeout"] == 2

    @patch("obra.version_check.requests.get")
    def test_timeout_handling(self, mock_get):
        """Test timeout returns None."""
        mock_get.side_effect = requests.exceptions.Timeout()

        result = fetch_latest_version()

        assert result is None

    @patch("obra.version_check.requests.get")
    def test_network_error_handling(self, mock_get):
        """Test network error returns None."""
        mock_get.side_effect = requests.exceptions.ConnectionError()

        result = fetch_latest_version()

        assert result is None

    @patch("obra.version_check.requests.get")
    def test_http_error_handling(self, mock_get):
        """Test HTTP error returns None."""
        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError()
        mock_get.return_value = mock_response

        result = fetch_latest_version()

        assert result is None

    @patch("obra.version_check.requests.get")
    def test_invalid_json_response(self, mock_get):
        """Test invalid JSON returns None."""
        mock_response = MagicMock()
        mock_response.json.side_effect = json.JSONDecodeError("test", "doc", 0)
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        result = fetch_latest_version()

        assert result is None

    @patch("obra.version_check.requests.get")
    def test_missing_version_field(self, mock_get):
        """Test response missing version field returns None."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"info": {}}  # Missing version
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        result = fetch_latest_version()

        assert result is None


class TestCacheOperations:
    """Tests for cache read/write operations."""

    def test_write_and_read_cache(self, tmp_path, monkeypatch):
        """Test cache persistence."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", tmp_path)

        # Write cache
        cache_data = {
            "last_check_time": "2026-01-08T12:34:56Z",
            "latest_version": "2.6.0",
            "last_shown_time": "2026-01-08T12:34:56Z",
        }
        result = write_cache(cache_data)
        assert result is True

        # Read cache
        read_data = read_cache()
        assert read_data == cache_data

    def test_read_nonexistent_cache(self, tmp_path, monkeypatch):
        """Test reading nonexistent cache returns None."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)

        result = read_cache()
        assert result is None

    def test_read_invalid_json_cache(self, tmp_path, monkeypatch):
        """Test reading invalid JSON returns None."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)

        # Write invalid JSON
        cache_file.write_text("not valid json")

        result = read_cache()
        assert result is None

    def test_write_cache_creates_directory(self, tmp_path, monkeypatch):
        """Test cache write creates directory if needed."""
        cache_dir = tmp_path / ".obra"
        cache_file = cache_dir / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", cache_dir)

        assert not cache_dir.exists()

        cache_data = {"last_check_time": "2026-01-08T12:34:56Z"}
        result = write_cache(cache_data)

        assert result is True
        assert cache_dir.exists()
        assert cache_file.exists()


class TestAsyncBehavior:
    """Tests for background thread behavior."""

    def test_check_for_updates_async_spawns_thread(self):
        """Test that check_for_updates_async spawns a daemon thread."""
        import threading

        initial_count = threading.active_count()

        with patch("obra.version_check._background_check"):
            check_for_updates_async()

            # Thread should be spawned
            # Note: daemon threads may not show up in active_count immediately
            # So we just verify the function returns immediately
            time.sleep(0.01)  # Minimal sleep to let thread start

        # Function should return immediately (verified by test completing)
        assert True

    def test_check_for_updates_async_returns_immediately(self):
        """Test that check_for_updates_async returns in <5ms."""
        with patch("obra.version_check._background_check"):
            start = time.perf_counter()
            check_for_updates_async()
            elapsed = (time.perf_counter() - start) * 1000  # Convert to ms

            # Should return in <5ms (being generous with 50ms for CI)
            assert elapsed < 50

    @patch("obra.version_check.fetch_latest_version")
    @patch("obra.version_check.write_cache")
    def test_background_check_handles_errors_silently(
        self, mock_write, mock_fetch, tmp_path, monkeypatch
    ):
        """Test that _background_check doesn't raise exceptions."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", tmp_path)

        # Make fetch raise an exception
        mock_fetch.side_effect = Exception("Network error")

        # Should not raise
        _background_check()

        # Should have attempted to fetch
        mock_fetch.assert_called_once()

    @patch("obra.version_check.fetch_latest_version")
    @patch("obra.version_check._display_update_banner")
    @patch("obra.version_check.write_cache")
    def test_background_check_shows_banner_for_new_version(
        self, mock_write, mock_banner, mock_fetch, tmp_path, monkeypatch
    ):
        """Test banner displays when new version available."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", tmp_path)

        # Mock PyPI returning newer version
        mock_fetch.return_value = "99.0.0"
        mock_write.return_value = True

        _background_check()

        # Banner should be displayed
        mock_banner.assert_called_once()
        # Should write cache
        mock_write.assert_called_once()

    @patch("obra.version_check.fetch_latest_version")
    @patch("obra.version_check._display_update_banner")
    @patch("obra.version_check.read_cache")
    @patch("obra.version_check.write_cache")
    def test_background_check_respects_cooldown(
        self, mock_write, mock_read, mock_banner, mock_fetch, tmp_path, monkeypatch
    ):
        """Test cooldown prevents repeated banner display."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", tmp_path)

        # Mock cache with recent last_shown_time (1 minute ago)
        recent_time = (datetime.now(UTC) - timedelta(minutes=1)).isoformat()
        mock_read.return_value = {
            "last_check_time": recent_time,
            "latest_version": "99.0.0",
            "last_shown_time": recent_time,
        }

        # Mock PyPI returning newer version
        mock_fetch.return_value = "99.0.0"
        mock_write.return_value = True

        _background_check()

        # Banner should NOT be displayed (cooldown not expired)
        mock_banner.assert_not_called()
        # Should still write cache
        mock_write.assert_called_once()

    @patch("obra.version_check.fetch_latest_version")
    @patch("obra.version_check._display_update_banner")
    @patch("obra.version_check.read_cache")
    @patch("obra.version_check.write_cache")
    def test_background_check_shows_banner_after_cooldown(
        self, mock_write, mock_read, mock_banner, mock_fetch, tmp_path, monkeypatch
    ):
        """Test banner displays after cooldown expires."""
        cache_file = tmp_path / ".version_check_cache"
        monkeypatch.setattr("obra.version_check.CACHE_FILE", cache_file)
        monkeypatch.setattr("obra.version_check.CACHE_DIR", tmp_path)

        # Mock cache with old last_shown_time (15 minutes ago, > 10min cooldown)
        old_time = (datetime.now(UTC) - timedelta(minutes=15)).isoformat()
        mock_read.return_value = {
            "last_check_time": old_time,
            "latest_version": "99.0.0",
            "last_shown_time": old_time,
        }

        # Mock PyPI returning newer version
        mock_fetch.return_value = "99.0.0"
        mock_write.return_value = True

        _background_check()

        # Banner SHOULD be displayed (cooldown expired)
        mock_banner.assert_called_once()
        # Should write cache
        mock_write.assert_called_once()
