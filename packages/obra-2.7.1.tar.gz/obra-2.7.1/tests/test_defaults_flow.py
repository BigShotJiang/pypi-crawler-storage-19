"""Tests for defaults confirmation flow in HybridOrchestrator."""

from unittest.mock import MagicMock

import pytest

from obra.exceptions import OrchestratorError
from obra.hybrid.orchestrator import HybridOrchestrator


def _make_orchestrator() -> HybridOrchestrator:
    """Create orchestrator with a mock client."""
    return HybridOrchestrator(client=MagicMock())


def test_process_proposed_defaults_prompts_and_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    """User can accept, override, or skip proposed defaults."""
    orchestrator = _make_orchestrator()
    monkeypatch.setattr(orchestrator, "_should_prompt_for_defaults", lambda: True)

    responses = iter(["", "override", "skip"])
    monkeypatch.setattr("builtins.input", lambda: next(responses))

    proposed = [
        {"issue_id": "p1", "proposed_value": "alpha", "rationale": "r1", "confidence": 0.5},
        {"issue_id": "p2", "proposed_value": "beta", "rationale": "", "confidence": 0.6},
        {"issue_id": "p3", "proposed_value": "gamma", "rationale": "r3", "confidence": 0.4},
    ]

    confirmed = orchestrator._process_proposed_defaults(proposed)

    assert len(confirmed) == 2
    assert confirmed[0]["proposed_value"] == "alpha"
    assert confirmed[1]["proposed_value"] == "override"
    assert "User override" in confirmed[1]["rationale"]


def test_process_proposed_defaults_defaults_json_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    """When --defaults-json is active, we output JSON and abort."""
    orchestrator = _make_orchestrator()
    orchestrator._defaults_json = True

    with pytest.raises(OrchestratorError):
        orchestrator._process_proposed_defaults(
            [{"issue_id": "p1", "proposed_value": "alpha", "rationale": "r1", "confidence": 0.5}]
        )

