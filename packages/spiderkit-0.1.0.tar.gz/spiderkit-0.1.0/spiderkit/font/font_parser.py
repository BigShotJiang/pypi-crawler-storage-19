"""字体解析模块实现

提供反爬虫字体文件解析和文本解密功能
"""

import json
import hashlib
import tempfile
import urllib.request
from pathlib import Path
from contextlib import suppress
from dataclasses import dataclass
from urllib.parse import urlparse
from typing import Optional, Dict, Union

from loguru import logger
from ddddocr import DdddOcr
from fontTools.ttLib import TTFont
from PIL.ImageFont import FreeTypeFont
from PIL import Image, ImageDraw, ImageFont


@dataclass(frozen=True)
class FontParseConfig:
    """字体解析配置"""

    image_size: int = 400
    font_size: int = 240
    background: tuple = (255, 255, 255, 255)
    color: tuple = (0, 0, 0, 255)
    include_unicode_escape: bool = False


def _save_font_maps(font_maps: Dict[str, str], json_file_path: Union[str, Path]) -> None:
    """保存字体映射到 JSON 文件, 并合并已有内容

    Args:
        font_maps: 字体映射字典
        json_file_path: JSON 文件路径

    Returns:
        无

    Raises:
        Exception: 保存失败时抛出
    """
    try:
        json_path = Path(json_file_path)
        existing_data: Dict[str, str] = {}

        with suppress(FileNotFoundError, json.JSONDecodeError):
            with json_path.open("r", encoding="utf-8") as file:
                existing_data = json.load(file)

        merged_maps = {**existing_data, **font_maps}
        if json_path.parent:
            json_path.parent.mkdir(parents=True, exist_ok=True)

        with json_path.open("w", encoding="utf-8") as file:
            json.dump(merged_maps, file, ensure_ascii=False, indent=4)

        existing_keys = set(existing_data.keys())
        new_keys = set(font_maps.keys())
        added = len(new_keys - existing_keys)
        updated = len(font_maps) - added
        logger.success(f"保存字体映射到 {json_path}: 新增 {added} 项, 更新 {updated} 项, 共 {len(merged_maps)} 项")
    except Exception:
        logger.exception("保存字体映射失败")
        raise


def _render_char_image(font: FreeTypeFont, char: str, config: FontParseConfig) -> Optional[Image.Image]:
    """渲染指定字符为图片

    Args:
        font: 字体对象
        char: 需要渲染的字符
        config: 字体解析配置

    Returns:
        渲染后的图片, 无法渲染时返回 None

    Raises:
        Exception: 渲染失败时抛出
    """
    try:
        bbox = font.getbbox(char)
        if not bbox:
            return None

        image = Image.new("RGBA", (config.image_size, config.image_size), config.background)
        draw = ImageDraw.Draw(image)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (config.image_size - text_width) // 2 - bbox[0]
        y = (config.image_size - text_height) // 2 - bbox[1]
        draw.text((x, y), char, fill=config.color, font=font)
        return image.convert("RGB")
    except Exception:
        logger.exception(f"渲染字符图片失败: {char}")
        return None


def _recognize_char(font: FreeTypeFont, ocr: DdddOcr, char: str, config: FontParseConfig) -> str:
    """识别指定字符的 OCR 结果

    Args:
        font: 字体对象
        ocr: OCR 识别器
        char: 需要识别的字符
        config: 字体解析配置

    Returns:
        OCR 识别结果, 识别失败时返回空字符串

    Raises:
        Exception: 识别失败时抛出
    """
    try:
        image = _render_char_image(font, char, config)
        if not image:
            return ""
        return ocr.classification(image).strip()
    except Exception:
        logger.exception(f"字符识别失败: {char}")
        return ""


def _iter_font_chars(font_data: TTFont) -> list:
    """遍历字体文件中包含的字符

    Args:
        font_data: 字体数据对象

    Returns:
        字符列表

    Raises:
        Exception: 遍历失败时抛出
    """
    try:
        cmap = font_data.getBestCmap() or {}
        return [chr(codepoint) for codepoint in sorted(cmap)]
    except Exception:
        logger.exception("遍历字体字符失败")
        raise


def parse_font_file(font_file_path: Union[str, Path], save_json: bool = False, json_file_path: Optional[Union[str, Path]] = None, ocr: Optional[DdddOcr] = None) -> Dict[str, str]:
    """解析字体文件并生成字符映射

    Args:
        font_file_path: 字体文件路径
        save_json: 是否保存字体映射到 JSON 文件
        json_file_path: JSON 文件路径, 为空时使用字体文件同名路径
        ocr: OCR 识别器, 为空时创建默认实例

    Returns:
        字体映射字典

    Raises:
        Exception: 解析失败时抛出
    """
    try:
        font_path = Path(font_file_path)
        if not font_path.exists():
            raise FileNotFoundError(f"字体文件不存在: {font_path}")

        config = FontParseConfig()
        ocr = ocr or DdddOcr(show_ad=False)
        font_maps: Dict[str, str] = {}

        with TTFont(font_path) as font_data:
            pil_font = ImageFont.truetype(str(font_path), size=config.font_size)

            for char in _iter_font_chars(font_data):
                recognized_char = _recognize_char(pil_font, ocr, char, config)
                if not recognized_char:
                    logger.warning(f"跳过无法识别字符: {char}")
                    continue

                font_maps[char] = recognized_char
                if config.include_unicode_escape:
                    font_maps[f"\\u{ord(char):04x}"] = recognized_char
                logger.success(f"映射字体字符: {char} -> {recognized_char}")

        if save_json:
            if json_file_path is None:
                json_file_path = font_path.with_suffix(".json")
            _save_font_maps(font_maps, json_file_path)

        return font_maps
    except Exception:
        logger.exception("解析字体文件失败")
        raise


def _build_download_path(font_url: str, download_dir: Optional[Union[str, Path]]) -> Path:
    """构建字体下载路径

    Args:
        font_url: 字体文件 URL
        download_dir: 下载目录, 为空时使用临时目录

    Returns:
        下载文件路径

    Raises:
        Exception: 路径构建失败时抛出
    """
    try:
        parsed = urlparse(font_url)
        filename = Path(parsed.path).name or "font.ttf"
        if not Path(filename).suffix:
            filename = f"{filename}.ttf"

        fingerprint = hashlib.sha1(font_url.encode("utf-8")).hexdigest()[:8]
        final_name = f"{fingerprint}_{filename}"

        if download_dir is None:
            download_dir = tempfile.mkdtemp(prefix="font_download_")
        download_path = Path(download_dir)
        download_path.mkdir(parents=True, exist_ok=True)
        return download_path / final_name
    except Exception:
        logger.exception("构建字体下载路径失败")
        raise


def _download_font_file(font_url: str, download_dir: Optional[Union[str, Path]] = None, timeout: int = 15) -> Path:
    """下载字体文件并返回本地路径

    Args:
        font_url: 字体文件 URL
        download_dir: 下载目录, 为空时使用临时目录
        timeout: 下载超时时间

    Returns:
        字体文件本地路径

    Raises:
        Exception: 下载失败时抛出
    """
    try:
        if not font_url:
            raise ValueError("字体 URL 不能为空")

        parsed = urlparse(font_url)
        if parsed.scheme and parsed.scheme not in {"http", "https", "file"}:
            raise ValueError(f"不支持的字体 URL 协议: {parsed.scheme}")

        if parsed.scheme == "file":
            return Path(parsed.path)

        if not parsed.scheme:
            local_path = Path(font_url).expanduser()
            if local_path.exists():
                return local_path
            raise ValueError(f"本地字体文件不存在: {font_url}")

        download_path = _build_download_path(font_url, download_dir)
        if download_path.exists():
            return download_path

        request = urllib.request.Request(font_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content = response.read()

        with download_path.open("wb") as file:
            file.write(content)

        logger.info(f"已下载字体文件: {download_path}")
        return download_path
    except Exception:
        logger.exception("下载字体文件失败")
        raise


def parse_font_url(font_url: str, download_dir: Optional[Union[str, Path]] = None, save_json: bool = False, json_file_path: Optional[Union[str, Path]] = None) -> Dict[str, str]:
    """解析字体 URL 并生成字符映射

    Args:
        font_url: 字体文件 URL
        download_dir: 下载目录, 为空时使用临时目录
        save_json: 是否保存字体映射到 JSON 文件
        json_file_path: JSON 文件路径

    Returns:
        字体映射字典

    Raises:
        Exception: 解析失败时抛出
    """
    try:
        font_path = _download_font_file(font_url, download_dir=download_dir)
        return parse_font_file(font_path, save_json=save_json, json_file_path=json_file_path)
    except Exception:
        logger.exception("解析字体 URL 失败")
        raise


def decrypt_text_with_font_maps(encrypted_text: str, font_maps: Dict[str, str]) -> str:
    """使用字体映射解密文本内容, 未匹配字符保持原样

    Args:
        encrypted_text: 加密文本
        font_maps: 字体映射字典

    Returns:
        解密后的文本

    Raises:
        Exception: 解密失败时抛出
    """
    try:
        return "".join(font_maps.get(char, font_maps.get(f"\\u{ord(char):04x}", char)) for char in encrypted_text)
    except Exception:
        logger.exception("使用字体映射解密文本失败")
        raise
