"""数据存储模块

提供多种格式的数据保存功能
"""

from spiderkit.storage.file import save_data_to_file

__all__ = ["save_data_to_file"]
