"""数据保存模块

支持 CSV、JSON、JSONL 格式的数据保存
"""

import csv
import json
from pathlib import Path
from typing import List, Dict, Any

from loguru import logger


def save_data_to_file(data: List[Dict[str, Any]], filename: str, file_format: str = "csv", output_dir: str = "./data", mode: str = "a") -> None:
    """保存数据到指定格式文件

    Args:
        data: 待保存的数据列表
        filename: 文件名, 不包含扩展名
        file_format: 保存格式, 支持 csv, json, jsonl
        output_dir: 输出目录
        mode: 文件写入模式, 默认追加

    Returns:
        无

    Raises:
        Exception: 保存过程中出现异常时抛出
    """
    try:
        if not data:
            logger.warning("没有数据需要保存")
            return

        file_path = _build_file_path(output_dir, filename, file_format)

        if file_format == "csv":
            _save_csv(data, file_path, mode)
        elif file_format == "json":
            _save_json(data, file_path, mode)
        elif file_format == "jsonl":
            _save_jsonl(data, file_path, mode)
        else:
            raise ValueError(f"不支持的保存格式: {file_format}")
    except Exception:
        logger.exception("保存数据失败")
        raise


def _build_file_path(output_dir: str, filename: str, file_format: str) -> Path:
    """构建输出文件路径

    Args:
        output_dir: 输出目录
        filename: 文件名
        file_format: 文件格式

    Returns:
        输出文件路径

    Raises:
        Exception: 路径构建失败时抛出
    """
    try:
        base_dir = Path(output_dir)
        file_path = base_dir / f"{filename}.{file_format}"
        file_path.parent.mkdir(parents=True, exist_ok=True)
        return file_path
    except Exception:
        logger.exception("构建输出路径失败")
        raise


def _save_csv(data: List[Dict[str, Any]], file_path: Path, mode: str) -> None:
    """保存数据为 CSV

    Args:
        data: 待保存的数据列表
        file_path: 文件路径
        mode: 文件写入模式

    Returns:
        无

    Raises:
        Exception: 保存失败时抛出
    """
    try:
        with open(file_path, mode, newline="", encoding="utf-8-sig") as file_handle:
            writer = csv.DictWriter(file_handle, fieldnames=list(data[0].keys()))
            if mode == "w" or not file_path.exists() or file_path.stat().st_size == 0:
                writer.writeheader()
            writer.writerows(data)
        logger.success(f"成功保存 {len(data)} 条数据到 {file_path}")
    except Exception:
        logger.exception("保存CSV文件失败")
        raise


def _save_json(data: List[Dict[str, Any]], file_path: Path, mode: str) -> None:
    """保存数据为 JSON

    Args:
        data: 待保存的数据列表
        file_path: 文件路径
        mode: 文件写入模式

    Returns:
        无

    Raises:
        Exception: 保存失败时抛出
    """
    try:
        target_data = data
        if mode == "a" and file_path.exists() and file_path.stat().st_size > 0:
            with open(file_path, "r", encoding="utf-8") as file_handle:
                existing = json.load(file_handle)
            if isinstance(existing, list):
                target_data = existing + data

        with open(file_path, "w", encoding="utf-8") as file_handle:
            json.dump(target_data, file_handle, ensure_ascii=False, indent=2)
        logger.success(f"成功保存 {len(data)} 条数据到 {file_path}")
    except Exception:
        logger.exception("保存JSON文件失败")
        raise


def _save_jsonl(data: List[Dict[str, Any]], file_path: Path, mode: str) -> None:
    """保存数据为 JSON Lines

    Args:
        data: 待保存的数据列表
        file_path: 文件路径
        mode: 文件写入模式

    Returns:
        无

    Raises:
        Exception: 保存失败时抛出
    """
    try:
        with open(file_path, mode, encoding="utf-8") as file_handle:
            for item in data:
                file_handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        logger.success(f"成功保存 {len(data)} 条数据到 {file_path}")
    except Exception:
        logger.exception("保存JSONL文件失败")
        raise
