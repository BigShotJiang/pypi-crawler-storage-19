#!/usr/bin/env python3
"""
CAR to Latents Extractor

Extracts latent data from CAR files, providing direct access to neural codec representations
without loading unnecessary metadata or processing overhead.

Based on CARHandler.car_to_np from carlib/processors/utils.py

Usage:
    python -m carlib.car_to_latents input.car
    python -m carlib.car_to_latents input.car --output latents.pt
    python -m carlib.car_to_latents input_dir/ --batch --output output_dir/
    python -m carlib.car_to_latents input.car --format numpy --output latents.npz
    python -m carlib.car_to_latents input.car --info  # Show latent info without extracting

Programmatic Usage:
    from carlib.car_to_latents import load_car_data_only, extract_latents_only
    
    # Load CAR file
    data_dict, metadata = load_car_data_only("path/to/file.car")
    
    # Extract only latents
    latents = extract_latents_only(data_dict)
"""

import sys
import argparse
import time
from pathlib import Path
from typing import Dict, Any, Tuple, Optional
import traceback
import json

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

def format_size(bytes_val: int) -> str:
    """Format file size in human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_val < 1024:
            return f"{bytes_val:.1f}{unit}"
        bytes_val /= 1024
    return f"{bytes_val:.1f}TB"

def format_tensor_info(tensor, name: str = "") -> str:
    """Format tensor information for display"""
    if hasattr(tensor, 'shape') and hasattr(tensor, 'dtype'):
        size = tensor.numel() * tensor.element_size() if hasattr(tensor, 'numel') and hasattr(tensor, 'element_size') else 0
        return f"{name}: {list(tensor.shape)} {tensor.dtype} ({format_size(size)})"
    elif hasattr(tensor, 'shape'):
        size = tensor.nbytes if hasattr(tensor, 'nbytes') else 0
        return f"{name}: {list(tensor.shape)} {tensor.dtype} ({format_size(size)})"
    else:
        return f"{name}: {type(tensor)}"

def load_car_data_only(car_path: str) -> Tuple[Dict[str, Any], dict]:
    """
    Load CAR file and extract only the data, similar to CARHandler.car_to_np
    but focused on latents extraction with minimal overhead
    
    Args:
        car_path: Path to the CAR file
        
    Returns:
        Tuple of (data_dict, metadata)
        
    Example:
        >>> data_dict, metadata = load_car_data_only("audio.car")
        >>> print(f"Keys: {list(data_dict.keys())}")
    """
    try:
        from .processors.utils import CARHandler
        
        with open(car_path, 'rb') as f:
            car_data = f.read()
        
        # Use the existing car_to_np method but extract only what we need
        data_dict, metadata = CARHandler.car_to_np(car_data, restore_original_dtype=True)
        
        return data_dict, metadata
        
    except ImportError:
        raise ImportError("carlib not found. Make sure carlib is in the Python path.")
    except Exception as e:
        raise RuntimeError(f"Failed to load CAR file {car_path}: {e}")

def extract_latents_only(data_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract only the latent/code data from the loaded CAR data,
    filtering out metadata and non-essential information
    
    Args:
        data_dict: Dictionary from load_car_data_only()
        
    Returns:
        Dictionary containing only latent tensors
        
    Example:
        >>> data_dict, _ = load_car_data_only("audio.car")
        >>> latents = extract_latents_only(data_dict)
        >>> print(f"Latent keys: {list(latents.keys())}")
    """
    latents = {}
    
    # Common latent keys from different codecs
    latent_keys = [
        'codes', 'encoded_codes', 'encoded_latents', 'encoded_indices',
        'audio_codes', 'tokens', 'latents', 'embeddings', 'features',
        'quantized_features', 'discrete_codes', 'compressed_codes'
    ]
    
    # Extract latent tensors
    for key, value in data_dict.items():
        if key.lower() in [k.lower() for k in latent_keys]:
            latents[key] = value
        elif isinstance(value, (torch.Tensor if TORCH_AVAILABLE else tuple, 
                               np.ndarray if NUMPY_AVAILABLE else tuple, list)):
            # Include tensor/array data that might be latents
            latents[key] = value
    
    # If no obvious latents found, include all tensor data
    if not latents:
        print("⚠️  No obvious latent keys found, including all tensor data")
        for key, value in data_dict.items():
            if isinstance(value, (torch.Tensor if TORCH_AVAILABLE else tuple,
                                 np.ndarray if NUMPY_AVAILABLE else tuple, list)):
                latents[key] = value
    
    return latents

def show_car_info(car_path: str) -> bool:
    """Show information about CAR file contents without extracting"""
    try:
        print(f"📄 Analyzing CAR file: {car_path}")
        
        # Get file size
        file_size = Path(car_path).stat().st_size
        print(f"📁 File size: {format_size(file_size)}")
        
        # Load data
        start_time = time.time()
        data_dict, metadata = load_car_data_only(car_path)
        load_time = time.time() - start_time
        
        print(f"⏱️  Load time: {load_time:.3f}s")
        
        # Show metadata
        print(f"\n📊 Metadata:")
        interesting_meta_keys = [
            'target_modality', 'model_name', 'model_type', 'original_tensor_dtype',
            'dtype_optimizations', 'dtype_conversions', 'compression', 'format'
        ]
        
        for key in interesting_meta_keys:
            if key in metadata:
                value = metadata[key]
                if isinstance(value, dict):
                    print(f"   {key}: {json.dumps(value, indent=6)}")
                else:
                    print(f"   {key}: {value}")
        
        # Show data structure
        print(f"\n📊 Data contents:")
        total_memory = 0
        
        for key, value in data_dict.items():
            info = format_tensor_info(value, key)
            print(f"   {info}")
            
            # Calculate memory usage
            if hasattr(value, 'numel') and hasattr(value, 'element_size'):
                total_memory += value.numel() * value.element_size()
            elif hasattr(value, 'nbytes'):
                total_memory += value.nbytes
            elif isinstance(value, list):
                for item in value:
                    if hasattr(item, 'numel') and hasattr(item, 'element_size'):
                        total_memory += item.numel() * item.element_size()
                    elif hasattr(item, 'nbytes'):
                        total_memory += item.nbytes
        
        print(f"\n📊 Total tensor memory: {format_size(total_memory)}")
        
        # Show potential latents
        latents = extract_latents_only(data_dict)
        if latents:
            print(f"\n🎯 Detected latent data:")
            for key, value in latents.items():
                info = format_tensor_info(value, key)
                print(f"   {info}")
        
        return True
        
    except Exception as e:
        print(f"❌ Failed to analyze CAR file: {e}")
        traceback.print_exc()
        return False

def extract_to_pytorch(latents: Dict[str, Any], output_path: str) -> bool:
    """Save latents as PyTorch .pt file"""
    if not TORCH_AVAILABLE:
        print("❌ PyTorch not available, cannot save as .pt")
        return False
    
    try:
        # Ensure all data is torch tensors
        torch_latents = {}
        for key, value in latents.items():
            if isinstance(value, torch.Tensor):
                torch_latents[key] = value
            elif NUMPY_AVAILABLE and isinstance(value, np.ndarray):
                torch_latents[key] = torch.from_numpy(value)
            elif isinstance(value, list):
                # Handle list of tensors (hierarchical codes)
                if value and isinstance(value[0], torch.Tensor):
                    torch_latents[key] = value
                elif NUMPY_AVAILABLE and value and isinstance(value[0], np.ndarray):
                    torch_latents[key] = [torch.from_numpy(arr) for arr in value]
                else:
                    print(f"⚠️  Skipping non-tensor list: {key}")
            else:
                print(f"⚠️  Skipping non-tensor data: {key}")
        
        torch.save(torch_latents, output_path)
        return True
        
    except Exception as e:
        print(f"❌ Failed to save PyTorch file: {e}")
        return False

def extract_to_numpy(latents: Dict[str, Any], output_path: str) -> bool:
    """Save latents as NumPy .npz file"""
    if not NUMPY_AVAILABLE:
        print("❌ NumPy not available, cannot save as .npz")
        return False
    
    try:
        # Convert all data to numpy arrays
        numpy_latents = {}
        for key, value in latents.items():
            if isinstance(value, np.ndarray):
                numpy_latents[key] = value
            elif TORCH_AVAILABLE and isinstance(value, torch.Tensor):
                numpy_latents[key] = value.cpu().numpy()
            elif isinstance(value, list):
                # Handle list of arrays
                if value and hasattr(value[0], 'shape'):
                    if TORCH_AVAILABLE and isinstance(value[0], torch.Tensor):
                        numpy_latents[key] = [arr.cpu().numpy() for arr in value]
                    else:
                        numpy_latents[key] = value
                else:
                    print(f"⚠️  Skipping non-array list: {key}")
            else:
                print(f"⚠️  Skipping non-array data: {key}")
        
        # Handle nested arrays (flatten for .npz)
        flattened = {}
        for key, value in numpy_latents.items():
            if isinstance(value, list):
                for i, arr in enumerate(value):
                    flattened[f"{key}_{i}"] = arr
            else:
                flattened[key] = value
        
        np.savez_compressed(output_path, **flattened)
        return True
        
    except Exception as e:
        print(f"❌ Failed to save NumPy file: {e}")
        return False

def extract_single_car(car_path: str, output_path: Optional[str] = None, 
                      output_format: str = "pytorch") -> bool:
    """Extract latents from a single CAR file"""
    try:
        print(f"🔍 Processing: {car_path}")
        
        # Load CAR data
        start_time = time.time()
        data_dict, _ = load_car_data_only(car_path)
        load_time = time.time() - start_time
        
        print(f"⏱️  Loaded in {load_time:.3f}s")
        
        # Extract latents
        latents = extract_latents_only(data_dict)
        
        if not latents:
            print("❌ No latent data found in CAR file")
            return False
        
        print(f"🎯 Extracted latents:")
        total_size = 0
        for key, value in latents.items():
            info = format_tensor_info(value, key)
            print(f"   {info}")
            
            if hasattr(value, 'numel') and hasattr(value, 'element_size'):
                total_size += value.numel() * value.element_size()
            elif hasattr(value, 'nbytes'):
                total_size += value.nbytes
        
        print(f"📊 Total latent data: {format_size(total_size)}")
        
        # Save if output path provided
        if output_path:
            start_time = time.time()
            
            if output_format.lower() in ["pytorch", "torch", "pt"]:
                success = extract_to_pytorch(latents, output_path)
                format_name = "PyTorch"
            elif output_format.lower() in ["numpy", "np", "npz"]:
                success = extract_to_numpy(latents, output_path)
                format_name = "NumPy"
            else:
                print(f"❌ Unknown output format: {output_format}")
                return False
            
            if success:
                save_time = time.time() - start_time
                output_size = Path(output_path).stat().st_size
                print(f"✅ Saved {format_name} file: {output_path}")
                print(f"⏱️  Save time: {save_time:.3f}s")
                print(f"📁 Output size: {format_size(output_size)}")
                
                # Show compression ratio
                if total_size > 0:
                    ratio = total_size / output_size
                    print(f"📊 Memory to disk ratio: {ratio:.2f}x")
            else:
                return False
        
        return True
        
    except Exception as e:
        print(f"❌ Failed to process {car_path}: {e}")
        traceback.print_exc()
        return False

def extract_batch_cars(input_dir: str, output_dir: str, output_format: str = "pytorch") -> bool:
    """Extract latents from all CAR files in a directory"""
    try:
        input_path = Path(input_dir)
        output_path = Path(output_dir)
        
        # Find all CAR files
        car_files = list(input_path.glob("*.car"))
        if not car_files:
            print(f"❌ No CAR files found in {input_dir}")
            return False
        
        print(f"🔍 Found {len(car_files)} CAR files")
        
        # Create output directory
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Process each file
        success_count = 0
        total_time = time.time()
        
        for car_file in car_files:
            print(f"\n{'='*60}")
            
            # Determine output filename
            if output_format.lower() in ["pytorch", "torch", "pt"]:
                output_file = output_path / f"{car_file.stem}_latents.pt"
            elif output_format.lower() in ["numpy", "np", "npz"]:
                output_file = output_path / f"{car_file.stem}_latents.npz"
            else:
                print(f"❌ Unknown output format: {output_format}")
                continue
            
            # Extract latents
            if extract_single_car(str(car_file), str(output_file), output_format):
                success_count += 1
            else:
                print(f"⚠️  Failed to process {car_file}")
        
        total_time = time.time() - total_time
        
        print(f"\n{'='*60}")
        print(f"📊 Batch processing complete:")
        print(f"   Processed: {success_count}/{len(car_files)} files")
        print(f"   Total time: {total_time:.2f}s")
        print(f"   Average: {total_time/len(car_files):.2f}s per file")
        
        return success_count == len(car_files)
        
    except Exception as e:
        print(f"❌ Batch processing failed: {e}")
        traceback.print_exc()
        return False

def main():
    parser = argparse.ArgumentParser(
        description="Extract latents from CAR files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Show CAR file info
  python -m carlib.car_to_latents input.car --info

  # Extract to PyTorch file
  python -m carlib.car_to_latents input.car --output latents.pt

  # Extract to NumPy file
  python -m carlib.car_to_latents input.car --format numpy --output latents.npz

  # Batch process directory
  python -m carlib.car_to_latents input_dir/ --batch --output output_dir/

  # Just extract and show info (no save)
  python -m carlib.car_to_latents input.car
        """
    )
    
    parser.add_argument("input", help="Input CAR file or directory")
    parser.add_argument("--output", "-o", help="Output file or directory")
    parser.add_argument("--format", "-f", choices=["pytorch", "torch", "pt", "numpy", "np", "npz"], 
                       default="pytorch", help="Output format (default: pytorch)")
    parser.add_argument("--batch", "-b", action="store_true", 
                       help="Process all CAR files in input directory")
    parser.add_argument("--info", "-i", action="store_true", 
                       help="Show file info only (no extraction)")
    
    args = parser.parse_args()
    
    # Validate input
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"❌ Input path does not exist: {args.input}")
        return 1
    
    print("🔧 CAR to Latents Extractor")
    print("=" * 40)
    
    try:
        if args.info:
            # Show info only
            if input_path.is_file():
                success = show_car_info(str(input_path))
            else:
                print("❌ --info requires a single CAR file")
                success = False
                
        elif args.batch:
            # Batch processing
            if not input_path.is_dir():
                print("❌ --batch requires input directory")
                return 1
            
            if not args.output:
                print("❌ --batch requires --output directory")
                return 1
                
            success = extract_batch_cars(str(input_path), args.output, args.format)
            
        else:
            # Single file processing
            if not input_path.is_file():
                print("❌ Input must be a CAR file")
                return 1
                
            success = extract_single_car(str(input_path), args.output, args.format)
        
        return 0 if success else 1
        
    except KeyboardInterrupt:
        print("\n⚠️  Interrupted by user")
        return 1
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())