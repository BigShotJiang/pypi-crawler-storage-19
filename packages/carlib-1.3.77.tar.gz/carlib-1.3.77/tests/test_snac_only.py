#!/usr/bin/env python3
"""
Test SNAC functionality
"""
import sys
import os
from pathlib import Path
import tempfile

def test_snac_basic():
    """Test basic SNAC functionality"""
    print("🧪 Testing SNAC audio processor")
    print("=" * 40)
    
    # Find MP3 file
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    mp3_files = list(assets_dir.glob("*.mp3"))
    
    if not mp3_files:
        print("❌ No MP3 files found in assets directory")
        return False
    
    test_mp3 = mp3_files[0]
    print(f"🎵 Test file: {test_mp3.name}")
    
    try:
        # Import and test SNAC processor
        from carlib.processors.audio_codecs import SNACAudioProcessor, AudioConfig
        
        # Create config
        config = AudioConfig(
            model_name="snac_24khz",  # Use 24kHz for faster testing
            model_type="snac",
            device="cpu",
            target_sample_rate=24000,
            max_duration=60.0  # Short for quick test
        )
        
        print("🔧 Initializing SNAC processor...")
        processor = SNACAudioProcessor(config)
        print("✅ SNAC processor initialized")
        
        # Create temp output
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / "test_snac.car"
            
            print("🎵 Processing audio...")
            result = processor.process_single_file(
                audio_path=str(test_mp3),
                output_path=str(output_path)
            )
            
            if output_path.exists():
                size_kb = output_path.stat().st_size / 1024
                print(f"✅ CAR file created: {size_kb:.1f} KB")
                
                # Test loading
                print("📖 Testing CAR file loading...")
                from carlib.loaders import load_single_car
                data = load_single_car(str(output_path))
                
                print(f"📊 Loaded keys: {list(data.keys())}")
                if 'data' in data:
                    print(f"📊 Data keys: {list(data['data'].keys())}")
                    # SNAC typically uses 'codes' or 'audio_codes'
                    if 'codes' in data['data'] or 'audio_codes' in data['data']:
                        codes_key = 'codes' if 'codes' in data['data'] else 'audio_codes'
                        codes = data['data'][codes_key]
                        print(f"✅ {codes_key} found: shape {codes.shape}")
                        return True
                    else:
                        print(f"❌ No codes found in data, available keys: {list(data['data'].keys())}")
                        return False
                else:
                    print("❌ No data key in loaded CAR")
                    return False
            else:
                print("❌ CAR file not created")
                return False
                
    except Exception as e:
        print(f"❌ SNAC test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_snac_basic()
    if success:
        print("\n🎉 SNAC test PASSED")
    else:
        print("\n❌ SNAC test FAILED")
    sys.exit(0 if success else 1)