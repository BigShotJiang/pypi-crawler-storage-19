#!/usr/bin/env python3
"""
EnCodec Memory and Performance Test

Tests CPU memory usage and timing for:
1. Loading music file
2. Converting to CAR format with EnCodec using dataset_to_car
3. Loading the CAR file back
4. Measuring memory and time metrics at each step

Based on test_dac_only.py structure
"""
import sys
import os
import time
import subprocess
from pathlib import Path
import tempfile
import traceback

# Try to import psutil for memory monitoring, fallback if not available
try:
    import psutil  # type: ignore
    PSUTIL_AVAILABLE = True
except ImportError:
    psutil = None  # type: ignore
    PSUTIL_AVAILABLE = False
    print("⚠️  psutil not available, using basic memory monitoring")

def format_memory_mb(bytes_val: int) -> str:
    """Format memory in MB"""
    return f"{bytes_val / 1024**2:.1f}MB"

def format_memory_gb(bytes_val: int) -> str:
    """Format memory in GB"""
    return f"{bytes_val / 1024**3:.2f}GB"

class CPUMemoryProfiler:
    """Simple CPU memory profiling utility with psutil fallback"""
    
    def __init__(self):
        if PSUTIL_AVAILABLE:
            self.process = psutil.Process(os.getpid())
            self.baseline_memory = self.get_current_memory()
            print(f"📊 Baseline memory usage: {format_memory_mb(self.baseline_memory)}")
        else:
            self.process = None
            self.baseline_memory = 0
            print("📊 Memory profiling: Basic mode (psutil not available)")
    
    def get_current_memory(self) -> int:
        """Get current memory usage in bytes"""
        if PSUTIL_AVAILABLE and self.process:
            return self.process.memory_info().rss
        else:
            # Fallback: try to get memory from /proc/self/status on Linux
            try:
                with open('/proc/self/status', 'r') as f:
                    for line in f:
                        if line.startswith('VmRSS:'):
                            # VmRSS is in kB, convert to bytes
                            return int(line.split()[1]) * 1024
            except:
                pass
            return 0
    
    def get_memory_delta(self) -> int:
        """Get memory delta from baseline in bytes"""
        current = self.get_current_memory()
        if current > 0 and self.baseline_memory > 0:
            return current - self.baseline_memory
        return 0
    
    def print_memory_status(self, label: str):
        """Print current memory status"""
        current = self.get_current_memory()
        if current > 0:
            delta = current - self.baseline_memory if self.baseline_memory > 0 else 0
            print(f"📊 {label}: {format_memory_mb(current)} (Δ{format_memory_mb(delta)})")
        else:
            print(f"📊 {label}: Memory monitoring unavailable")

def test_encodec_memory_performance():
    """Test EnCodec processing with memory and performance monitoring"""
    print("🧪 Testing EnCodec Memory & Performance")
    print("=" * 50)
    
    # Initialize memory profiler
    profiler = CPUMemoryProfiler()
    
    # Find MP3 file
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    mp3_files = list(assets_dir.glob("*.mp3"))
    
    if not mp3_files:
        print("❌ No MP3 files found in assets directory")
        return False
    
    test_mp3 = mp3_files[0]
    file_size = test_mp3.stat().st_size
    print(f"🎵 Test file: {test_mp3.name} ({format_memory_mb(file_size)})")
    
    # Track timing for each step
    step_times = {}
    
    try:
        # Step 1: Setup for dataset_to_car conversion
        print(f"\n{'='*20} STEP 1: Setup Conversion {'='*20}")
        step_start = time.time()
        
        # Create a temporary input directory with just our test MP3
        temp_input_dir = Path(tempfile.mkdtemp(prefix="encodec_input_"))
        temp_mp3_path = temp_input_dir / test_mp3.name
        
        # Copy the MP3 to temp input directory
        import shutil
        shutil.copy2(test_mp3, temp_mp3_path)
        print(f"📁 Created temp input directory: {temp_input_dir}")
        
        step_times['setup'] = time.time() - step_start
        profiler.print_memory_status("After setup")
        print(f"⏱️  Setup time: {step_times['setup']:.3f}s")
        
        # Step 2: Convert to CAR format using dataset_to_car
        print(f"\n{'='*20} STEP 2: Convert to CAR {'='*20}")
        step_start = time.time()
        
        try:
            # Create temp output directory
            temp_output_dir = Path(tempfile.mkdtemp(prefix="encodec_output_"))
            
            print("🎵 Converting audio to CAR format using dataset_to_car...")
            
            # Import and use dataset_to_car functionality
            from carlib.dataset_to_car import convert_dataset_to_car
            
            # Convert using dataset_to_car with model_config parameter
            convert_dataset_to_car(
                input_path=str(temp_input_dir),
                output_path=str(temp_output_dir),
                modality="vanilla",
                target_modality="audio",
                model_config={"model_name": "facebook/encodec_24khz"},
                parallel=False  # Single worker for consistent measurements
            )
            
            step_times['car_conversion'] = time.time() - step_start
            profiler.print_memory_status("After CAR conversion")
            print(f"⏱️  CAR conversion time: {step_times['car_conversion']:.3f}s")
            
            # Check if CAR files were generated
            car_files = list(temp_output_dir.glob("*.car"))
            if not car_files:
                print("❌ No CAR files generated")
                return False
            
            output_path = car_files[0]
            print(f"✅ CAR conversion successful: {output_path.name}")
            
        except ImportError:
            # Fallback: use subprocess to call dataset_to_car script
            print("🔄 Using subprocess fallback for dataset_to_car...")
            
            temp_output_dir = Path(tempfile.mkdtemp(prefix="encodec_output_"))
            
            # Build command for dataset_to_car
            dataset_to_car_path = Path(__file__).parent.parent / "carlib" / "dataset_to_car.py"
            cmd = [
                sys.executable, str(dataset_to_car_path),
                str(temp_input_dir),
                "--modality", "vanilla",
                "--target-modality", "audio",
                "--output", str(temp_output_dir),
                "--model-name", "facebook/encodec_24khz"
            ]
            
            # Run the conversion
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            step_times['car_conversion'] = time.time() - step_start
            profiler.print_memory_status("After CAR conversion")
            print(f"⏱️  CAR conversion time: {step_times['car_conversion']:.3f}s")
            
            if result.returncode != 0:
                print(f"❌ dataset_to_car failed: {result.stderr}")
                return False
            
            # Find the generated CAR file
            car_files = list(temp_output_dir.glob("*.car"))
            if not car_files:
                print("❌ No CAR files generated")
                return False
            
            output_path = car_files[0]
            print(f"✅ CAR conversion successful: {output_path.name}")
            
        # Check CAR file creation
        if not output_path.exists():
            print("❌ CAR file not created")
            return False
        
        car_size = output_path.stat().st_size
        compression_ratio = file_size / car_size if car_size > 0 else 0
        print(f"📁 CAR file size: {format_memory_mb(car_size)} (compression: {compression_ratio:.2f}x)")
        
        # Step 3: Load CAR file back
        print(f"\n{'='*20} STEP 3: Load CAR File {'='*20}")
        step_start = time.time()
        
        print("📖 Loading CAR file...")
        from carlib.loaders import load_single_car
        
        # Measure memory before loading
        memory_before_load = profiler.get_current_memory()
        
        data = load_single_car(str(output_path))
        
        step_times['car_loading'] = time.time() - step_start
        memory_after_load = profiler.get_current_memory()
        load_memory_delta = max(0, memory_after_load - memory_before_load) if memory_before_load > 0 else 0
        
        profiler.print_memory_status("After CAR loading")
        print(f"⏱️  CAR loading time: {step_times['car_loading']:.3f}s")
        if load_memory_delta > 0:
            print(f"📊 Memory used by loaded data: {format_memory_mb(load_memory_delta)}")
        else:
            print(f"📊 Memory used by loaded data: Not measurable")
            
        # Step 3.5: Test latents extraction performance
        print(f"\n{'='*15} STEP 3.5: Extract Latents Only {'='*15}")
        step_start = time.time()
        
        print("🎯 Extracting latents only using car_to_latents...")
        from car_to_latents import load_car_data_only, extract_latents_only
        
        # Measure memory before latents extraction
        memory_before_latents = profiler.get_current_memory()
        
        # Load CAR data directly for latents
        latent_data_dict, _ = load_car_data_only(str(output_path))
        latents_only = extract_latents_only(latent_data_dict)
        
        step_times['latents_extraction'] = time.time() - step_start
        memory_after_latents = profiler.get_current_memory()
        latents_memory_delta = max(0, memory_after_latents - memory_before_latents) if memory_before_latents > 0 else 0
        
        profiler.print_memory_status("After latents extraction")
        print(f"⏱️  Latents extraction time: {step_times['latents_extraction']:.3f}s")
        if latents_memory_delta > 0:
            print(f"📊 Memory used by latents only: {format_memory_mb(latents_memory_delta)}")
        
        # Compare memory efficiency
        if load_memory_delta > 0 and latents_memory_delta > 0:
            memory_efficiency = load_memory_delta / latents_memory_delta
            print(f"📊 Memory efficiency (full vs latents): {memory_efficiency:.2f}x")
        
        # Show latents structure
        print(f"🎯 Extracted latents structure:")
        latent_total_size = 0
        for key, value in latents_only.items():
            if hasattr(value, 'shape') and hasattr(value, 'dtype'):
                size = value.numel() * value.element_size() if hasattr(value, 'numel') and hasattr(value, 'element_size') else 0
                latent_total_size += size
                print(f"   {key}: {list(value.shape)} {value.dtype} ({format_memory_mb(size)})")
            elif hasattr(value, 'shape'):
                size = value.nbytes if hasattr(value, 'nbytes') else 0
                latent_total_size += size
                print(f"   {key}: {list(value.shape)} {value.dtype} ({format_memory_mb(size)})")
            elif isinstance(value, list):
                list_size = 0
                for i, item in enumerate(value):
                    if hasattr(item, 'numel') and hasattr(item, 'element_size'):
                        item_size = item.numel() * item.element_size()
                        list_size += item_size
                        print(f"   {key}[{i}]: {list(item.shape)} {item.dtype} ({format_memory_mb(item_size)})")
                latent_total_size += list_size
        
        print(f"📊 Total latent tensor memory: {format_memory_mb(latent_total_size)}")
        
        # Step 4: Analyze loaded data
        print(f"\n{'='*20} STEP 4: Analyze Loaded Data {'='*20}")
        
        print(f"📊 Top-level keys: {list(data.keys())}")
        
        if 'data' in data:
            data_keys = list(data['data'].keys())
            print(f"📊 Data keys: {data_keys}")
            
            # Check for EnCodec-specific keys
            if 'codes' in data['data']:
                codes = data['data']['codes']
                if isinstance(codes, list):
                    print(f"✅ EnCodec codes found: {len(codes)} levels")
                    for i, code in enumerate(codes):
                        if hasattr(code, 'shape'):
                            memory_usage = code.numel() * code.element_size() if hasattr(code, 'numel') else 0
                            print(f"   Level {i}: shape {code.shape}, memory {format_memory_mb(memory_usage)}")
                else:
                    if hasattr(codes, 'shape'):
                        memory_usage = codes.numel() * codes.element_size() if hasattr(codes, 'numel') else 0
                        print(f"✅ EnCodec codes found: shape {codes.shape}, memory {format_memory_mb(memory_usage)}")
            
            # Check metadata
            if 'metadata' in data:
                metadata = data['metadata']
                print(f"📊 Metadata keys: {list(metadata.keys()) if isinstance(metadata, dict) else 'Not a dict'}")
                if isinstance(metadata, dict) and 'target_modality' in metadata:
                    print(f"🎯 Target modality: {metadata['target_modality']}")
            
            # Calculate total data memory usage
            total_data_memory = 0
            for _, value in data['data'].items():
                if hasattr(value, 'numel') and hasattr(value, 'element_size'):
                    total_data_memory += value.numel() * value.element_size()
                elif isinstance(value, list):
                    for item in value:
                        if hasattr(item, 'numel') and hasattr(item, 'element_size'):
                            total_data_memory += item.numel() * item.element_size()
            
            print(f"📊 Total data tensor memory: {format_memory_mb(total_data_memory)}")
            
        else:
            print("❌ No 'data' key in loaded CAR")
            return False
        
        # Step 5: Performance Summary
        print(f"\n{'='*20} PERFORMANCE SUMMARY {'='*20}")
        
        total_time = sum(step_times.values())
        final_memory = profiler.get_current_memory()
        total_memory_delta = final_memory - profiler.baseline_memory
        
        print(f"⏱️  Timing breakdown:")
        for step, duration in step_times.items():
            percentage = (duration / total_time * 100) if total_time > 0 else 0
            print(f"   {step}: {duration:.3f}s ({percentage:.1f}%)")
        print(f"   TOTAL: {total_time:.3f}s")
        
        # Performance comparison between full loading and latents-only
        if 'car_loading' in step_times and 'latents_extraction' in step_times:
            latents_speedup = step_times['car_loading'] / step_times['latents_extraction'] if step_times['latents_extraction'] > 0 else 0
            print(f"   Latents-only speedup: {latents_speedup:.2f}x faster")
        
        print(f"\n📊 Memory breakdown:")
        print(f"   Baseline: {format_memory_mb(profiler.baseline_memory)}")
        print(f"   Final: {format_memory_mb(final_memory)}")
        print(f"   Total delta: {format_memory_mb(total_memory_delta)}")
        print(f"   Data loading delta: {format_memory_mb(load_memory_delta)}")
        
        # Memory efficiency metrics
        if car_size > 0:
            memory_efficiency = car_size / load_memory_delta if load_memory_delta > 0 else float('inf')
            print(f"   Memory efficiency: {memory_efficiency:.2f} (file size / RAM used)")
        
        # Performance metrics
        if 'car_conversion' in step_times and step_times['car_conversion'] > 0:
            processing_speed = file_size / step_times['car_conversion'] / 1024 / 1024  # MB/s
            print(f"   Processing speed: {processing_speed:.1f} MB/s")
        
        if step_times['car_loading'] > 0 and car_size > 0:
            loading_speed = car_size / step_times['car_loading'] / 1024 / 1024  # MB/s
            print(f"   Loading speed: {loading_speed:.1f} MB/s")
            
        # Clean up temp directories
        try:
            shutil.rmtree(temp_input_dir)
            shutil.rmtree(temp_output_dir)
        except:
            pass
        
        print(f"\n✅ EnCodec memory & performance test completed successfully!")
        return True
            
    except Exception as e:
        print(f"❌ EnCodec test failed: {e}")
        traceback.print_exc()
        return False
    
    finally:
        # Final memory status
        print(f"\n📊 Final memory status:")
        profiler.print_memory_status("Test completion")

def main():
    """Main test runner"""
    print("🧪 EnCodec Memory & Performance Test Suite")
    print("=" * 60)
    
    try:
        success = test_encodec_memory_performance()
        
        if success:
            print(f"\n🎉 All tests passed!")
            return 0
        else:
            print(f"\n❌ Test failed!")
            return 1
            
    except KeyboardInterrupt:
        print(f"\n⚠️  Test interrupted by user")
        return 1
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)