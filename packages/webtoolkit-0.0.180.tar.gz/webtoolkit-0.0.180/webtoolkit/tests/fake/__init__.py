"""
contains various life-examples
"""
