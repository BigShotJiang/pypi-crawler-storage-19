from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, TypedDict

try:
    from typing import Literal
except ImportError:  # pragma: no cover - Python <3.8 fallback (unreachable in supported versions)
    from typing_extensions import Literal  # type: ignore[assignment]


class _SingleScanRequestBase(TypedDict):
    text: str
    deep_scan: bool


class SingleScanRequest(_SingleScanRequestBase):
    pass


class BatchScanRequest(TypedDict):
    texts: List[str]
    deep_scan: bool


class ApiError(TypedDict, total=False):
    code: Optional[str]
    message: str
    details: Optional[Dict[str, Any]]


@dataclass(frozen=True)
class AnalyzeTextResult:
    """Result of single text analysis.

    Attributes:
        answer: Float value in range [0, 1].
        segmentation_tokens: Optional list of floats aligned to words when deep_scan=True.
        status: Literal status from the API (`success` when returned).
    """

    answer: float
    segmentation_tokens: Optional[List[float]]
    status: Literal["success", "processing", "error"]


@dataclass(frozen=True)
class AnalyzeBatchItemResult:
    """Per-item result for batch analysis.

    Attributes:
        text: Original input text.
        answer: Float in [0, 1].
        segmentation_tokens: Optional list of floats aligned to words when deep_scan=True.
        deep_scan: Whether deep scan was enabled for this item.
    """

    text: str
    answer: float
    segmentation_tokens: Optional[List[float]]
    deep_scan: bool


@dataclass(frozen=True)
class AnalyzeBatchResult:
    """Full batch analysis response payload."""

    answer: List[AnalyzeBatchItemResult]
    error: Optional[ApiError]
