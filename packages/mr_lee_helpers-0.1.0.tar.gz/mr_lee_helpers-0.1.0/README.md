Mr.lee's Helpers
Modules:
1）myodbc -> MSSQL
