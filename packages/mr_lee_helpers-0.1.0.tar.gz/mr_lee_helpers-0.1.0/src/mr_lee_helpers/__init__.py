def main() -> None:
    print("Hello from mr-lee-helpers!")
