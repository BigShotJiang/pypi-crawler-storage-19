'''
知识点：
1）pyodbc
    pip install pyodbc
🌺推荐：
用ODBC好，没有编码问题。
🌺注意：
A)控制面板->管理工具或Windows工具->ODBC数据源->驱动程序，看看有没有安装：ODBC Driver 17 for SQL Serve.
B)如果端口不是1433，记得在server那里要传端口，如127.0.0.1,1434
🌺ODBC Driver 17 for SQL Server下载：
https://learn.microsoft.com/zh-cn/sql/connect/odbc/download-odbc-driver-for-sql-server?view=sql-server-ver16
注意，如果是ODBC Driver 18 for SQL Server，那实例化时记得传driver.
'''
from numpy._core.numeric import False_
import pyodbc

class MSSQL:
    def __init__(self,*,server=None,user=None,password=None,database=None,port=1433,timeout=0,autoCommit=False,trusted=False,driver="ODBC Driver 17 for SQL Server") -> None:
        self.server=server
        self.user=user
        self.password=password
        self.database=database
        self.port=port
        self.timeout=timeout
        self.autoCommit=autoCommit
        self.trusted=trusted
        self.driver=driver
        self.conn=None
        self.cursor=None
        
    def getConnectString(self) -> str:
            conn_str = f"DRIVER={{{self.driver}}};SERVER={self.server},{self.port};DATABASE={self.database};"
            
            if self.trusted:
                conn_str += "Trusted_Connection=yes;"
            else:
                if self.user and self.password:
                    conn_str += f"UID={self.user};PWD={self.password};"
                if self.timeout>0:
                    conn_str += f"Connection Timeout={self.timeout};"
            
            return conn_str
        
    def connect(self) -> tuple[bool,str]:
        try:
            connectString = self.getConnectString()
            self.conn = pyodbc.connect(connectString)
            self.cursor=self.conn.cursor()
            return True,"OK"
        except Exception as e:
            self.conn=None
            self.cursor=None
            return False,str(e)
            
    # 获取连接状态
    @property
    def Connected(self):
        return self.conn is not None
        
    # 设置自动提交
    def setAutoCommit(self,autoCommit):
        if not self.conn:
            return False,"未连接数据库。"
        try:
            self.conn.autocommit=autoCommit
            return True
        except Exception as e:
            return False
            
    # 获取是否自动提交
    @property
    def IsAutoCommit(self):
        return self.conn.autocommit
        
    # 插入记录
    def insert(self, tableName: str, data: dict):
        if not self.conn:
            return False,"未连接数据库。"
        try:
            columns = ", ".join(data.keys())
            values = tuple(data.values())
            sql = f"INSERT INTO {tableName} ({columns}) VALUES {values}"
            self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
            
    # 修改记录
    def update(self, table_name: str, data: dict, where: str, params: tuple[any]):
        if not self.conn:
            return False,"未连接数据库。"
        try:
            set_clause = ", ".join([f"{key} = ?" for key in data.keys()])
            values = tuple(data.values()) + params
            sql = f"UPDATE {table_name} SET {set_clause} WHERE {where}"
            print(sql)
            self.cursor.execute(sql, values)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
        
    # 删除记录
    def delete(self, table_name: str, where: str, params: tuple[any]):
        if not self.conn:
            return False,"未连接数据库。"
        try:
            sql = f"DELETE FROM {table_name} WHERE {where}"
            self.cursor.execute(sql, params)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))
            
    # 查询数据
    def select(self, table_name, columns: tuple[str] = None, where=None, params: tuple[any]=None,toDict=True):
        if not self.conn:
            return False,"未连接数据库。",None
        try:
            cols = "*" if columns is None else ", ".join(columns)
            sql = f"SELECT {cols} FROM {table_name}"
            if where:
                sql += f" WHERE {where}"
            print(sql)
            if where and params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            if toDict:
                # 获取列名
                columns = [column[0] for column in self.cursor.description]
                # 转换为字典列表
                data = []
                for row in self.cursor.fetchall():
                    data.append(dict(zip(columns, row)))
                return True,"OK",data
            else:
                data = self.cursor.fetchall()
                return True,"OK",data
        except Exception as e:
            return False,str(e),None
            
    # 查询数据
    def get(self,sql,toDict=True):
        if not self.conn:
            return None
        try:
            self.cursor.execute(sql)
            if toDict:
                # 获取列名
                columns = [column[0] for column in self.cursor.description]
                # 转换为字典列表
                results = []
                for row in self.cursor.fetchall():
                    results.append(dict(zip(columns, row)))
                return results
            else:
                return self.cursor.fetchall()
        except:
            return None

    # 执行SQL
    def exec(self,sql):
        if not self.conn:
            return False,"未连接数据库。"
        try:
            self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))

    # 执行存储过程
    def execProc(self,procName,params: tuple[any] = None):
        if not self.conn:
            return (False,"未连接数据库。")
        try:
            if params:
                placeholders = ', '.join(['?' for _ in params])
                sql = f"EXEC {procName} {placeholders}"
                self.cursor.execute(sql, params)
            else:
                sql = f"EXEC {procName}"
                self.cursor.execute(sql)
            return (True,"OK")
        except Exception as e:
            return (False,str(e))

    # 执行存储过程并返回数据
    def execProcGet(self,procName,params: list[any] = None):
        if not self.conn:
            return (False,"未连接数据库。",None)
        try:
            if params:
                placeholders = ', '.join(['?' for _ in params])
                sql = f"EXEC {procName} {placeholders}"
                self.cursor.execute(sql, params)
            else:
                sql = f"EXEC {procName}"
                self.cursor.execute(sql)
                
            datas = []
            if self.cursor.description:
                columns = [desc[0] for desc in self.cursor.description]
                for row in self.cursor.fetchall():
                    datas.append(dict(zip(columns, row)))
                    
            return (True,"OK",datas)
        except Exception as e:
            return (False,str(e),None)

    # 提交事务
    def commit(self):
        if not self.conn:
            return
        if self.conn.autocommit==True:
            return
        self.conn.commit()

    # 回滚事务
    def rollback(self):
        if not self.conn:
            return
        self.conn.rollback()

    # 关闭连接
    def close(self):
        if self.cursor:
            self.cursor.close()
            self.cursor=None
        if self.conn:
            self.conn.close()
            self.conn=None

if __name__ == "__main__":
    server="127.0.0.1"
    user="sa"
    password="fpsoft@123"
    database="MyCustomer"
    # 实例化
    #mssql=MSSQL(server=server,database=database)
    mssql=MSSQL(server=server,user=user,password=password,database=database)
    # 连接数据库
    (successed,msg)=mssql.connect()
    # print(successed)
    # print(msg)
    print("数据库连接是否成功：")
    print(mssql.Connected)

    # Demo1：查询数据
    sql="SELECT TOP 2 P_CusName,P_Tel FROM Dt_Customers WITH(NOLOCK)"
    print("🌸Demot1：获取客户：")
    humans=mssql.get(sql)
    print(humans)

    # Demo2：执行无参存储过程
    # (successed,msg) = mssql.execProc("Usp_TestNoArgs")
    # print("🌸Demot2：执行无参存储过程(Usp_TestNoArgs)：")
    # print(successed,msg)

    # Demo3：执行带参存储过程
    # (successed,msg) = mssql.execProc("Usp_TestWithArgs",(99,"1号机"))
    # print("🌸Demot3：执行带参存储过程(Usp_TestWithArgs)：")
    # print(successed,msg)

    # Demo4：执行存储过程并返回数据
    # (successed,msg,datas) = mssql.execProcGet("Usp_Test",("",))
    # print("🌸Demot4：执行存储过程并返回数据(Usp_Test)：")
    # print(successed,msg,datas)
     
    # Demo5：Insert
    # user1 = {"P_UserName": "张三", "P_Age": 25, "P_Email": "Zhang3@example.com"}
    # user2 = {"P_UserName": "李四", "P_Age": 20, "P_Email": "Li4@example.com"}
    # user3 = {"P_UserName": "王五", "P_Age": 18, "P_Email": "Wang5@example.com"}
    # (successed,msg)=mssql.insert("Dt_User",user1)
    # (successed,msg)=mssql.insert("Dt_User",user2)
    # (successed,msg)=mssql.insert("Dt_User",user3)
    # print(successed,msg)

    # Demo6：Update
    # updateData = {"P_Age": 31,"P_Email":"Zhang3@QQ.com"}
    # (successed,msg)=mssql.update("Dt_User", updateData, "P_UserName = ?",('张三',))
    # print(successed,msg)

    # Demo7：Delete
    # (successed,msg)=mssql.delete("Dt_User", "P_UserName = ?", ("王五",))
    # print(successed,msg)
    
    # Demo8：Select
    # cols=("P_UserName","P_Age")
    # cols=None
    # (successed,msg,data)=mssql.select("Dt_User",cols,"P_UserName = ?",("张三",))
    # print(successed,msg,data)
    
    # 提交事务
    mssql.commit()
    # 关闭
    mssql.close()
