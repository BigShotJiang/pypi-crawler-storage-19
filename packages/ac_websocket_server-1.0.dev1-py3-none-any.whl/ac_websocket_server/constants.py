'''Constants for AC websocket proof of concept.'''

VERSION = '1.0dev1'
PROTOCOL = '0.7dev4'
PROG = 'ac-websocket-server'
PORT = 7890
HOST = 'localhost'
