"""Implementation of the various autodoc directive for the Nix domain."""

from __future__ import annotations

from copy import copy
from typing import TYPE_CHECKING, Any, ClassVar

from docutils import nodes
from docutils.parsers.rst import directives
from docutils.statemachine import StringList, string2lines
from sphinx.directives import code
from sphinx.util import logging
from sphinx.util.docutils import SphinxDirective

from . import _data as autodata
from ._utils import (
    is_part_of_scope,
    option_key_fun,
    skipped_options_levels,
    split_attr_path,
)
from .module import OptionDirective

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any


logger = logging.getLogger(__name__)

# TODO: related_packages


class NixAutoOptionDirective(SphinxDirective):
    has_content = False
    required_arguments = 1
    option_spec: ClassVar[dict[str, Callable[[str], Any]]] = {
        "no-index": directives.flag,
        "no-index-entry": directives.flag,
        "no-contents-entry": directives.flag,
        "no-typesetting": directives.flag,
    }

    def run(self) -> list[nodes.Node]:
        name = self.arguments[0]

        option = autodata.get_option(name)
        if option is None:
            logger.warning(
                "Could not find option '%s' in any of the 'nixdomain_objects' files",
                name,
                location=self.get_location(),
            )
            return []

        description = StringList()
        if option.description is not None:
            description = StringList(
                string2lines(
                    option.description,
                    self.state.document.settings.tab_width,
                    convert_whitespace=True,
                ),
                # TODO: use declarations
                source="<NixOS-like option>",
            )

        directive_options: dict[str, Any] = copy(self.options)

        if option.typ is not None:
            directive_options["type"] = option.typ

        if option.read_only:
            directive_options["read-only"] = True

        if option.declarations != []:
            # Not sure how to handle multiple declarations
            directive_options["declaration"] = option.declarations[0]

        rendered = OptionDirective(
            "nix:option",
            arguments=[name],
            options=directive_options,
            content=description,
            lineno=self.lineno,
            content_offset=self.content_offset,
            block_text=self.block_text,
            state=self.state,
            state_machine=self.state_machine,
        ).run()

        # HACK: if no-typesetting is given,
        # the directive doesn't return any content.
        if len(rendered[-1]) < 2:
            return rendered

        rendered_content = rendered[-1][-1]

        if option.default is not None:
            # Not sure if container_wrapper is public or private API
            rendered_content += code.container_wrapper(
                self,
                nodes.literal_block(option.default, option.default, language="nix"),
                "Default value",
            )

        if option.example is not None:
            # Not sure if container_wrapper is public or private API
            rendered_content += code.container_wrapper(
                self,
                nodes.literal_block(option.example, option.example, language="nix"),
                "Example",
            )

        if option.declarations != [] and self.config.nixdomain_linkcode_resolve is None:
            declaration_nodes: list[nodes.Element] = [
                nodes.term("Declared in", "Declared in"),
            ]
            for decl in option.declarations:
                decl_para = nodes.paragraph("", decl)
                declaration_nodes += [nodes.definition("", decl_para)]

            declarations = nodes.definition_list_item("", *declaration_nodes)
            rendered_content += nodes.definition_list("", declarations)

        return rendered


class NixAutoModuleDirective(SphinxDirective):
    has_content = False
    required_arguments = 1
    option_spec: ClassVar[dict[str, Callable[[str], Any]]] = {
        "no-index": directives.flag,
        "no-index-entry": directives.flag,
        "no-contents-entry": directives.flag,
        "no-typesetting": directives.flag,
    }

    def run(self) -> list[nodes.Node]:
        module = self.arguments[0]
        module_loc = split_attr_path(module)

        # If "no-recursive" is given, `self.options["no-recursive"]` is `None`,
        # so its bool representation is `False`.
        #
        # We pop it to pass the rest of the options to the `autooption` directive.
        recursive = bool(self.options.pop("no-recursive", True))

        options = [
            name
            for name, option in autodata.options()
            if is_part_of_scope(module_loc, option.loc, recursive=recursive)
        ]

        if options == []:
            logger.warning(
                "No options found for module: '%s'",
                module,
                location=self.get_location(),
            )
            return []

        result = []

        directive_options: dict[str, Any] = self.options

        # `no-typesetting` allows not showing the option on the page,
        # `no-index-entry` allows not showing it in the `genindex`,
        # but still have cross-references.
        in_between_directive_options = copy(directive_options)
        in_between_directive_options["no-typesetting"] = True
        in_between_directive_options["no-index-entry"] = True

        if not autodata.has_option(module):
            result += OptionDirective(
                "nix:option",
                arguments=[module],
                options=in_between_directive_options,
                content=StringList(),
                lineno=self.lineno,
                content_offset=self.content_offset,
                block_text=self.block_text,
                state=self.state,
                state_machine=self.state_machine,
            ).run()

        previous_option_loc = module_loc

        for option in sorted(options, key=option_key_fun):
            option_loc = split_attr_path(option)

            for in_between_option in skipped_options_levels(
                previous_option_loc,
                option_loc,
            ):
                result += OptionDirective(
                    "nix:option",
                    arguments=[in_between_option],
                    options=in_between_directive_options,
                    content=StringList(),
                    lineno=self.lineno,
                    content_offset=self.content_offset,
                    block_text=self.block_text,
                    state=self.state,
                    state_machine=self.state_machine,
                ).run()

            result += NixAutoOptionDirective(
                "",
                arguments=[option],
                options=directive_options,
                content=StringList(),
                lineno=self.lineno,
                content_offset=self.content_offset,
                block_text=self.block_text,
                state=self.state,
                state_machine=self.state_machine,
            ).run()

            previous_option_loc = option_loc

        return result
