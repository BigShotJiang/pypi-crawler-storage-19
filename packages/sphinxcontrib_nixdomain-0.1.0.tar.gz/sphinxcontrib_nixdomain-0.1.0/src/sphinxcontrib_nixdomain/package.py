"""Handle a set of packages."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, cast

from docutils import nodes
from docutils.parsers.rst import directives
from sphinx import addnodes
from sphinx.directives import ObjectDescription
from sphinx.util.docfields import Field, GroupedField, TypedField

from ._utils import split_attr_path

if TYPE_CHECKING:
    from collections.abc import Callable

    from sphinx.addnodes import desc_signature
    from sphinx.directives import ObjDescT

    from . import NixDomain


class PackageDirective(ObjectDescription):
    """Describe a package."""

    has_content = True
    required_arguments = 1
    option_spec: ClassVar[dict[str, Callable[[str], Any]]] = {
        "no-index": directives.flag,
        "no-index-entry": directives.flag,
        "no-contents-entry": directives.flag,
        "no-typesetting": directives.flag,
        "declaration": directives.unchanged,
    }

    doc_field_types: list[Field] = [  # noqa: RUF012
        TypedField(
            "override",
            label="Overrides",
            names=("override", "overrides"),
        ),
        GroupedField(
            "maintainer",
            label="Maintainers",
            names=("maintainer", "maintainers"),
        ),
    ]

    def handle_signature(self, sig: str, signode: desc_signature) -> str:
        """Print the option given its signature."""
        signode["fullname"] = fullname = sig
        signode["path-parts"] = sig_names = split_attr_path(sig)
        signode["name"] = sig_names[-1]

        for el in sig_names[:-1]:
            signode += addnodes.desc_addname(text=el)
            signode += addnodes.desc_sig_punctuation(text=".")

        signode += addnodes.desc_name(text=sig_names[-1])

        declaration = self.options.get("declaration")

        if declaration and self.config.nixdomain_linkcode_resolve is not None:
            uri = self.config.nixdomain_linkcode_resolve(declaration)

            # Mostly taken from the 'linkcode' builtin extension
            onlynode = addnodes.only(expr="html")
            onlynode += nodes.reference(
                "",
                "",
                nodes.inline("", "[source]", classes=["viewcode-link"]),
                internal=False,
                refuri=uri,
            )
            signode += onlynode

        return fullname

    def add_target_and_index(
        self,
        fullname: str,
        _sig: str,
        signode: desc_signature,
    ) -> None:
        """Add the given option to the index, and create a target."""
        signode["ids"].append(_package_target(fullname))

        nix = cast("NixDomain", self.env.get_domain("nix"))
        nix.add_package(fullname, {})

        if "no-index-entry" not in self.options:
            self.indexnode["entries"].append(
                (
                    "single",
                    f"{fullname} (Nix package)",
                    _package_target(fullname),
                    "",
                    None,
                ),
            )

    def _object_hierarchy_parts(self, signode: desc_signature) -> tuple[str]:
        return tuple(signode["path-parts"])

    def _toc_entry_name(self, signode: desc_signature) -> str:
        if not signode.get("_toc_parts"):
            return ""

        return signode["fullname"]


def _package_target(fullname: str) -> str:
    """Return a target for referencing a option."""
    return f"nix-package-{fullname}"
