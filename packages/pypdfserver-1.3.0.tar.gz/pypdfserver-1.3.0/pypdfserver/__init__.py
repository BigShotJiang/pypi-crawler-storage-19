"""
pyPDFserver - A locally hosted scan destination to apply OCR and duplex to scans
"""

from .core import *
from .core import __version__, __author__
from .server import PDF_FTPServer
from .cmd import start_pyPDFserver

pdf_server: PDF_FTPServer|None = None