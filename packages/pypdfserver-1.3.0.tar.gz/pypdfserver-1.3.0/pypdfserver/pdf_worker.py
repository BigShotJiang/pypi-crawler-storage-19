import ftplib
import io
import logging
import ocrmypdf
import ocrmypdf.exceptions
import pikepdf
import tempfile
import threading
import uuid
import weakref
import zlib
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from PIL import features
from queue import Queue, Empty
from typing import cast

from .core import *
from .core import __version__

ocrmypdf_logger = logging.getLogger("ocrmypdf")
ocrmypdf_logger.handlers.clear()
ocrmypdf_logger.setLevel(logging.DEBUG)
ocrmypdf_logger.addHandler(lib_log_handler)
ocrmypdf_logger.addHandler(file_log_handler)

if not features.check("jpg_2000"):
    logger.warning(f"Your platform does not support JPEG2000")

class TaskState(Enum):
    """ 
    Defines the status of a task. 
    Values 0-9 indicate a state before finishing, 10-19 indicate sucessfull finish and >20 indicate errors
    """
    CREATED = (0, 80)
    SCHEDULED = (1, 83)
    WAITING = (2, 82)
    RUNNING = (3, 84)
    FINISHED = (10, 81)
    FAILED = (20, 92)
    ABORTED = (21, 91)
    DEPENDENCY_FAILED = (22, 90)
    UNKOWN_ERROR = (0, 93)

    def __init__(self, value: int, priority: int):
        self._value_ = value      # behält den ursprünglichen Enum-Wert
        self.priority = priority # zusätzliches Attribut

    @classmethod
    def merge_states(cls, *states: "TaskState") -> "TaskState":
        if len(states) == 0:
            raise ValueError(f"Can't merge zeros TaskStates")
        return max(states, key=lambda s: s.priority)

class Artifact:
    """ 
    Implements an artifact class to pass results between tasks. Any subclass should implement garbage collection in the cleanup() method called when the 
    artifact goes out of scope
    """

    temp_dir = pyPDFserver_temp_dir_path / "artifacts"

    def __init__(self, task: "Task|None", name: str, _log: bool = True) -> None:
        self.task = task
        self._name = name
        if _log:
            logger.debug(f"Created artifact '{name}'" + (f" for task '{str(task)}'" if task is not None else ""))

    @property
    def name(self) -> str:
        return self._name
    
    @name.setter
    def name(self, val: str) -> None:
        logger.debug(f"Renamed artifact '{self._name}' to '{val}'")
        self._name = val

    def cleanup(self) -> None:
        """ Clean up the resources of the artifact """
        pass

    def __del__(self) -> None:
        self.cleanup()

    def __str__(self) -> str:
        return f"Artifact '{self.name}'"
    
    def __repr__(self) -> str:
        return f"<{str(self)}>"

Artifact.temp_dir.mkdir(exist_ok=True, parents=False)

class FileArtifact(Artifact):
    """
    Implements a file artifact class to pass files between tasks. Access the data with the given .path attribute.
    Once the object goes out of scope, the cleanup() method is called to remove the temporary file.
    
    """

    def __init__(self, task: "Task|None", name: str) -> None:
        super().__init__(task, name, _log=False)

        prefix = f"artifact_{name}"
        if self.task is not None:
            prefix = f"{type(task).__name__}_{name}."

        self._temp_file = tempfile.NamedTemporaryFile(dir=Artifact.temp_dir, prefix=prefix, suffix=".bin", delete=False)
        self._temp_file.close()
        self.path = Path(self._temp_file.name)

        self._finalizer = weakref.finalize(self, FileArtifact._cleanup, self.path, self.name, str(self.task) if self.task is not None else None)

        try:
            logger.debug(f"Created FileArtifact '{self.name}' at '{self.path.relative_to(Artifact.temp_dir)}'" + (f" of task '{str(task)}'" if self.task is not None else ""))
        except ValueError:
            logger.error(f"Failed to create FileArtifact '{self.name}': '{self.path}' is not in the temporary directory ('{Artifact.temp_dir}')")

    def cleanup(self) -> None:
        logger.debug(f"Cleanup for temporary artifact '{self.name}'"+ (f" of task '{str(self.task)}'" if self.task is not None else ""))
        if not self._temp_file.closed:
            self._temp_file.close()
        if self._finalizer.alive:
            self._finalizer()

    def __str__(self) -> str:
        return f"FileArtifact '{self.name}'"
    
    @staticmethod
    def _cleanup(path: Path, name: str, task_name: str|None) -> None:
        if not path.exists():
            return
        try:
            path.unlink(missing_ok=True)
        except Exception:
            logger.warning(f"Failed to delete temporary artifact '{name}'" + (f" of task '{task_name}'" if task_name is not None else ""))
        else:
            logger.debug(f"Garbage collected temporary artifact '{name}'" + (f" of task '{task_name}'" if task_name is not None else ""))


class ArtifactLink:

    def __init__(self, artifact_name: str, task: "Task") -> None:
        self.artifact_name = artifact_name
        self.task = task
    
    def get(self) -> "Artifact":
        return self.task.artifacts[self.artifact_name]
    
    def __str__(self) -> str:
        return f"Link to '{str(self.get())}'"
    
    def __repr__(self) -> str:
        return f"<{str(self)}>"

class FileArtifactLink(ArtifactLink):

    def get(self) -> FileArtifact:
        return cast(FileArtifact, super().get())

class Task:
    """ A task can define any workload scheduled to run asynchronously in the run() method. To pass results to other tasks, use the store_artifacts() method """
    
    task_list: list["Task"] = []
    groups: dict[str, str] = {}

    def __init__(self, group: str|None = None, group_name: str|None = None, hidden: bool = False) -> None:
        self.state = TaskState.CREATED
        self.uuid = str(uuid.uuid4())
        self.dependencies: list[Task] = []
        self.external_dependencies: set[str] = set()
        self._t_created: datetime = datetime.now()
        self._t_start: datetime|None = None
        self._t_end: datetime|None = None
        self.artifacts: dict[str, Artifact] = {}
        self.error: TaskException|None = None
        self.group = group
        self.hidden = hidden

        Task.task_list.append(self)

    @property
    def t_created(self) -> datetime:
        return self._t_created
    
    @t_created.setter
    def t_created(self, val: datetime) -> None:
        self._t_created = val

    @property
    def t_start(self) -> datetime|None:
        return self._t_start
    
    @t_start.setter
    def t_start(self, val: datetime|None) -> None:
        self._t_start = val

    @property
    def t_end(self) -> datetime|None:
        return self._t_end
    
    @t_end.setter
    def t_end(self, val: datetime|None) -> None:
        self._t_end = val

    def set_group_name(self, name: str) -> None:
        if self.group is not None:
            Task.groups[self.group] = name

    def run(self) -> None:
        """ Called when a Task is executed """
        raise NotImplementedError(f"The given task does not implement a run() method")
    
    def try_abort(self) -> None:
        if self.state in [TaskState.CREATED, TaskState.SCHEDULED, TaskState.WAITING]:
            self.state = TaskState.ABORTED
            logger.info(f"Aborted task '{str(self)}'")
        elif self.state == TaskState.RUNNING:
            logger.debug(f"Task '{str(self)}' is running and can not be aborted")
        else:
            logger.debug(f"Task '{str(self)}' has finished and can not be aborted")
    
    def add_external_dependency(self, name: str) -> None:
        """ Call this function """
        if self.state in [TaskState.CREATED, TaskState.SCHEDULED, TaskState.WAITING]:
            self.external_dependencies.add(name)
        elif self.state == TaskState.RUNNING:
            logger.debug(f"Can not add external dependency '{name}' to task '{str(self)}' as the task is already running")
        else:
            logger.debug(f"Can not add external dependency '{name}' to task '{str(self)}' as the task has already finished")

    def release_external_dependency(self, name: str) -> None:
        if name not in self.external_dependencies:
            logger.debug(f"'{str(self)}': Trying to release a not existing external dependency")
            return
        self.external_dependencies.remove(name)
        self.schedule()

    def clean_up(self) -> None:
        """ Clean up the artifacts and release their resources """
        logger.debug(f"Cleaning up task '{str(self)}'")
        for a in self.artifacts.values():
            a.cleanup()
            del a
        self.artifacts = {}

    def schedule(self) -> None:
        if self.state not in [TaskState.CREATED, TaskState.SCHEDULED, TaskState.WAITING]:
            return
        self.state = TaskState.SCHEDULED
        task_queue.put(self)

    def register_artifact(self, artifact: Artifact) -> Artifact:
        """ Store an artifact to be used in other dependend tasks """
        self.artifacts[artifact.name] = artifact
        return artifact
    
    @property
    def runtime(self) -> timedelta|None:
        if self.t_start is None or self.t_end is None:
            return None
        return self.t_end - self.t_start
    
    @property
    def name(self) -> str:
        return "Generic Task"
    
    @property
    def desc(self) -> str:
        return ""
    
    def __repr__(self) -> str:
        return f"<{str(self)}>"
    
    def __str__(self) -> str:
        return f"Generic Task {self.uuid}"
    
    def __del__(self) -> None:
        self.clean_up()

    
class TaskException(Exception):
    """ Should be raise inside a Task's run() function when an expected error happens. The difference to other errors is that it is not logged with stacktrace in the logs """

    def __init__(self, message: str, *args: object) -> None:
        super().__init__(*args)
        self.message = message

class WaitForFileTask(Task):
    """
    Wait for a file before proceding
    """

    def __init__(self, 
                 display_name: str,
                 display_desc: str,
                 group: str | None = None, 
                 group_name: str | None = None, 
                 hidden: bool = False) -> None:
        super().__init__(group, group_name, hidden)
        self.display_name = display_name
        self.display_desc = display_desc

        self._t_start = self.t_created

        self.register_artifact(FileArtifact(self, "file"))
        self.file_artifact_link = FileArtifactLink("file", self)
        logger.debug(f"Created WaitForFileTask '{str(self)}'")

    @Task.t_start.setter
    def t_start(self, val: datetime|None) -> None:
        pass

    @Task.t_end.setter
    def t_end(self, val: datetime|None) -> None:
        pass

    def set_file_received(self) -> None:
        self._t_end = datetime.now()

    @property
    def file_artifact(self) -> FileArtifact:
        return cast(FileArtifact, self.artifacts["file"])
    
    @file_artifact.setter
    def file_artifact(self, val: FileArtifact) -> None:
        self.artifacts["file"] = val
    
    def run(self):
        self.t_start = self.t_created

    def __str__(self) -> str:
        return f"WaitForFileTask '{self.name}'"
    
    @property
    def name(self) -> str:
        return self.display_name
    
    @property
    def desc(self) -> str:
        return self.display_desc

class UploadToFTPTask(Task):
    """
    Upload an file to an external FTP server
    """

    def __init__(self, 
                 input_file: Path|FileArtifactLink, 
                 file_name: str,
                 address: tuple[str, int], 
                 username: str, password: str, 
                 folder: str, 
                 tls: bool,
                 group: str|None = None, 
                 hidden: bool = False) -> None:
        super().__init__(group=group, hidden=hidden)
        self.input_file = input_file
        self.file_name = file_name
        self.address = address
        self.username = username
        self.password = password
        self.folder = folder
        self.tls = tls

        self.file_size: int|None = None

        logger.debug(f"Created UploadToFTPTask '{str(self)}'")

    def run(self) -> None:
        if self.tls:
            ftp = ftplib.FTP_TLS()
        else:
            ftp = ftplib.FTP()
        try:
            ftp.connect(self.address[0], self.address[1], timeout=30)
            if isinstance(ftp, ftplib.FTP_TLS):
                ftp.auth()
                ftp.prot_p()
            ftp.login(user=self.username, passwd=self.password)
            ftp.cwd(self.folder)
            ftp.sendcmd("OPTS UTF8 ON")
            logger.debug(f"Connected to upload FTP server ('{ftp.getwelcome()}')")
            files = ftp.nlst()

            if self.file_name in files:
                raise TaskException(f"File already present on the server")
            
            path = self.input_file.get().path if isinstance(self.input_file, FileArtifactLink) else self.input_file
            if not path.exists():
                raise TaskException(f"Missing input file '{self.input_file}'")

            self.file_size = path.stat().st_size
            
            with open(path, "rb") as f:
                ftp.storbinary(f"STOR {self.file_name}", f)

            logger.info(f"Uploaded file '{self.file_name}' to the remote FTP server")
        except ftplib.all_errors as ex:
            raise TaskException(f"Failed to upload the file: {str(ex)}")
        finally:
            ftp.close()    

    @property
    def name(self) -> str:
        return "Upload to FTP"
    
    @property
    def desc(self) -> str:
        s = f"{self.address[0]}:{self.address[1]}@{self.username}:{self.folder}"
        if self.file_size is not None:
            s += f" ({self.file_size/1024**2:.2f} MB)"
        return s


    def __str__(self) -> str:
        return f"Upload '{self.file_name}'"
class OCRTask(Task):

    def __init__(self, input_file: Path|FileArtifactLink, 
                 file_name: str, 
                 language: str, 
                 optimize: int, 
                 deskew: bool, 
                 rotate_pages: bool, 
                 jpg_quality: int|None,
                 png_quality: int|None,
                 color_conversion_strategy: str|None,
                 num_jobs: int|None = None, 
                 tesseract_timeout: int|None = 60,
                 group: str|None = None, 
                 hidden: bool = False) -> None:
        super().__init__(group=group, hidden=hidden)
        self.input_file = input_file
        self.file_name = file_name
        self.language = language
        self.deskew = deskew
        self.optimize = optimize
        self.rotate_pages = rotate_pages
        self.jpg_quality = jpg_quality
        self.png_quality = png_quality
        self.color_conversion_strategy = color_conversion_strategy
        self.num_jobs = num_jobs
        self.tesseract_timeout = tesseract_timeout

        self.file_size_before: int|None = None
        self.file_size_after: int|None = None

        self.register_artifact(FileArtifact(self, "export"))
        self.export_artifact_link = FileArtifactLink("export", self)
        logger.debug(f"Created OCRTask '{str(self)}'")

    @property
    def export_artifact(self) -> FileArtifact:
        return cast(FileArtifact, self.artifacts["export"])

    def run(self) -> None:
        path = self.input_file.get().path if isinstance(self.input_file, FileArtifactLink) else self.input_file
        if not path.exists():
            raise TaskException(f"Missing input file '{self.input_file}'")
        
        self.file_size_before = path.stat().st_size

        try:
            exit_code = ocrmypdf.ocr(path, self.export_artifact.path, 
                                        language=self.language,
                                        deskew=self.deskew,
                                        rotate_pages=self.rotate_pages,
                                        jobs=self.num_jobs,
                                        optimize=self.optimize,
                                        color_conversion_strategy=self.color_conversion_strategy,
                                        tesseract_timeout=self.tesseract_timeout,
                                        jpg_quality=self.jpg_quality,
                                        png_quality=self.png_quality,
                                        skip_text=True,
                                        progress_bar=False,
                                        )
        except ocrmypdf.exceptions.ExitCodeException as ex:
            raise TaskException(str(ex))
        if not exit_code == ocrmypdf.ExitCode.ok:
            raise TaskException(exit_code.name)
        self.file_size_after = self.export_artifact.path.stat().st_size
        logger.debug(f"Applied OCR for '{self.file_name}' ({self.param_str})")
        
    @property
    def name(self) -> str:
        return "OCR"
    
    @property
    def desc(self) -> str:
        return self.param_str
    
    @property
    def param_str(self) -> str:
        s = f"lang={self.language}, deskew={self.deskew}, optimize={self.optimize}, rotate_pages: {self.rotate_pages}"
        if self.jpg_quality is not None:
            s += f", jpg_quality={self.jpg_quality}"
        if self.png_quality is not None:
            s += f", png_quality={self.png_quality}"
        if self.color_conversion_strategy is not None:
            s += f", color_conversion_strategy={self.color_conversion_strategy}"
        if self.file_size_before is not None and self.file_size_after is not None:
            size1, size2 = self.file_size_before, self.file_size_after
            s += f", {size1/1024**2:.2f} MB -> {size2/1024**2:.2f} MB ({(100*(size2/size1 - 1)):+.1f}%)"
        return s

    def __repr__(self) -> str:
        return f"<OCR '{self.file_name}' ({self.param_str})>"

    def __str__(self) -> str:
        return f"OCR '{self.file_name}'"
    
        
class PDFTask(Task):

    def __init__(self, 
                 input1: Path|FileArtifactLink, 
                 file1_name: str, 
                 export_name: str,
                 input2: Path|FileArtifactLink|None = None, 
                 file2_name: str|None = None, 
                 group: str|None = None, 
                 hidden: bool = False) -> None:
        super().__init__(group=group, hidden=hidden)
        self.input1 = input1
        self.file1_name = file1_name
        self.export_name = export_name
        self.input2 = input2
        self.file2_name = file2_name

        self.file_size_before: int|None = None
        self.file_size_after: int|None = None

        if input2 is None != file2_name is None:
            raise ValueError(f"input2 and file2_name must both either be given or None")

        self.register_artifact(FileArtifact(self, "export"))
        self.export_artifact_link = FileArtifactLink("export", self)

        logger.debug(f"Created PDFTask '{str(self)}'")

    @property
    def export_artifact(self) -> FileArtifact:
        return cast(FileArtifact, self.artifacts["export"])

    def run(self):
        path1 = self.input1.get().path if isinstance(self.input1, FileArtifactLink) else self.input1
        if not path1.exists():
            raise TaskException(f"Missing input file '{self.input1}'")
        
        self.file_size_before = path1.stat().st_size
        
        path2 = None
        if self.input2 is not None:
            path2 = self.input2.get().path if isinstance(self.input2, FileArtifactLink) else self.input2
            if not path2.exists():
                raise TaskException(f"Missing input file '{self.input2}'")
            
            self.file_size_before += path2.stat().st_size        

        try:
            with (pikepdf.open(path1) if path2 is None else pikepdf.Pdf.new()) as pdf:
                if path2 is not None:
                    with pikepdf.open(path1) as pdf1, pikepdf.open(path2) as pdf2:
                        num_pages1 = len(pdf1.pages)
                        num_pages2 = len(pdf2.pages)

                        if num_pages1 != num_pages2:
                            raise TaskException(f"Rejected to merge PDFs with unequal page count ({num_pages1} and {num_pages2})")
                        
                        for p1, p2 in zip(pdf1.pages[:], pdf2.pages[::-1]):
                            pdf.pages.append(p1)
                            pdf.pages.append(p2)

                with pdf.open_metadata(set_pikepdf_as_editor=False) as meta:
                    meta["pdf:Producer"] = f"pyPDFserver {__version__}"
                    meta["xmp:CreatorTool"] = f"pyPDFserver {__version__} / " + meta["xmp:CreatorTool"]
                    if meta.pdfa_status:
                        logger.debug(f"Produced a valid PDF/A-{meta.pdfa_status.lower()} file")

                pdf.save(self.export_artifact.path, preserve_pdfa=True, linearize=True, compress_streams=True, )
        except (pikepdf.PdfError, pikepdf.PasswordError, pikepdf.DataDecodingError, pikepdf.ForeignObjectError) as ex:
            raise TaskException(f"Failed to process '{self.export_name}': {str(ex)}")
        except (ValueError, TypeError) as ex:
            logger.error(f"Failed to process '{self.export_name}': ", exc_info=True)
            raise TaskException(f"Failed to process '{self.export_name}': {str(ex)}")
        
        self.file_size_after = self.export_artifact.path.stat().st_size
        
            
    @property
    def name(self) -> str:
        return "Optimize PDF"
    
    @property
    def desc(self) -> str:
        s = []
        if self.input2 is not None:
            s.append("create duplex")
        return ", ".join(s)
        
    def __str__(self) -> str:
        return f"Optimize PDF '{self.export_name}'"


task_queue: Queue[Task] = Queue()
task_priority_queue: Queue[Task] = Queue()
current_task: Task|None = None

def _pdfworker_handler() -> None:
    global worker_thread
    logger.debug(f"Started the pdf server (thread {worker_thread.native_id})")
    try:
        _pdfworker_loop()
    except Exception as ex:
        logger.error(f"The pdf worker loop crashed", exc_info=True)
        logger.critical(f"Terminating pyPDFserver")
        exit()

try:
    task_keep_time = config.getint("SETTINGS", "tasks_keep_time")
except ValueError:
    raise ConfigError(f"Missing or invalid value for 'task_keep_time' in section 'SETTINGS'")
if task_keep_time <= 0:
    raise ConfigError(f"Invalid value {task_keep_time} for 'task_keep_time' in section 'SETTINGS'")


def clean() -> None:
    for t in Task.task_list.copy():
        # First remove old tasks
        if (datetime.now() - t.t_created).total_seconds() > task_keep_time*60:
            Task.task_list.remove(t)
            t.clean_up()
            match t.state:
                case TaskState.RUNNING:
                    logger.info(f"Running task '{str(t)}' marked for time out")
                case TaskState.CREATED | TaskState.SCHEDULED | TaskState.WAITING:
                    logger.info(f"Task '{str(t)}' timed out")
                case _:
                    logger.debug(f"Garbage collected task '{str(t)}'")
            continue

        # Now check if waiting task is ready (put to priority queue) or has failed dependencies
        if t.state != TaskState.WAITING:
            continue

        task_ready = True
        if len(t.external_dependencies) > 0:
            task_ready = False
        for d in t.dependencies:
            match d.state:
                case TaskState.CREATED | TaskState.SCHEDULED | TaskState.WAITING | TaskState.RUNNING:
                    task_ready = False
                case TaskState.FINISHED:
                    pass
                case _:
                    task_ready = False
                    t.state = TaskState.DEPENDENCY_FAILED
                    break
        if t.state != TaskState.WAITING:
            logger.debug(f"Task '{str(t)}' was marked as DEPENDENCY_FAILED")
        elif task_ready:
            t.state = TaskState.SCHEDULED
            task_priority_queue.put(t)
            logger.debug(f"Task '{str(t)}' was moved from WAITING to SCHEDULED")

def _pdfworker_loop() -> None:
    """ Implements the main thread loop """
    global current_task
    while True:
        current_task = None

        clean()

        # Get next task
        try:
            current_task = task_priority_queue.get_nowait()
        except Empty:
            try:
                current_task = task_queue.get(block=True, timeout=5*60)
            except Empty:
                continue

        if current_task not in Task.task_list:
            logger.debug(f"Skipped task '{str(current_task)}' as it timed out")
            continue
        elif current_task.state == TaskState.ABORTED:
            continue
        elif current_task.state != TaskState.SCHEDULED:
            current_task.state = TaskState.UNKOWN_ERROR
            logger.debug(f"Unexpected TaskState {current_task.state} for task '{current_task}' in queue. Skipping it")
            continue

        current_task.state = TaskState.RUNNING

        # Check if all dependencies for the task are resolved
        dependencies_resolved = True
        if len(current_task.external_dependencies) > 0:
            dependencies_resolved = False
        for d in current_task.dependencies:
            match d.state:
                case TaskState.FINISHED:
                    pass
                case TaskState.CREATED | TaskState.SCHEDULED | TaskState.WAITING | TaskState.RUNNING:
                    dependencies_resolved = False
                case _:
                    dependencies_resolved = False
                    current_task.state = TaskState.DEPENDENCY_FAILED
                    break
        if current_task.state != TaskState.RUNNING:
            logger.debug(f"Task '{str(current_task)}' was marked as DEPENDENCY_FAILED")
            continue
        elif not dependencies_resolved:
            current_task.state = TaskState.WAITING
            logger.debug(f"Task '{str(current_task)}' was marked as WAITING")
            continue

        logger.debug(f"Executing task '{str(current_task)}'")
        
        try:
            current_task.t_start = datetime.now()
            current_task.run()
        except TaskException as ex:
            current_task.state = TaskState.FAILED
            current_task.error = ex
            logger.info(f"Task '{str(current_task)}' failed: {ex.message}")
            continue
        except Exception as ex:
            current_task.state = TaskState.FAILED
            current_task.error = TaskException("Unexpected error")
            logger.warning(f"Failed to process task '{str(current_task)}': ", exc_info=True)
            continue
        finally:
            current_task.t_end = datetime.now()

        current_task.state = TaskState.FINISHED
        logger.debug(f"Finished task '{str(current_task)}'")

def run() -> None:
    """ Start the server loop """
    global worker_thread, current_task

    if current_task is not None and current_task.state.value < 10:
        current_task.state = TaskState.ABORTED

    worker_thread = threading.Thread(target=_pdfworker_handler, name="PDFworker loop", daemon=True)
    worker_thread.start()

run()