"""Sandbox script for testing the HP CAP parser with batch processing."""

from pathlib import Path
from hp_cap_parser import HPCapParser

if __name__ == "__main__":
    parser = HPCapParser()
    
    test_files_dir = Path("tests/test_files")
    xml_files = list(test_files_dir.glob("*.xml"))
    
    if len(xml_files) > 1:
        print(f"Processing {len(xml_files)} files in batch...")
        parser.parse_files_batch([str(f) for f in xml_files], "test_output_batch")
    else:
        print("Processing single file...")
        parser.parse_file("tests/test_files/9G145ET.xml", "test_output")
