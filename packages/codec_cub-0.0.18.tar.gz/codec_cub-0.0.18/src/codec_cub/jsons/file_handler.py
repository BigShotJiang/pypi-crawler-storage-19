"""JSON file handler built on top of BytesFileHandler.

This handler works with bytes directly for maximum orjson performance,
since orjson.dumps() returns bytes and orjson.loads() accepts bytes natively.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, overload

from codec_cub.general._orjson_helper import json_dumps, json_loads
from codec_cub.text.bytes_handler import BytesFileHandler
from funcy_bear.constants.type_constants import JSONLike, LitFalse, LitTrue

if TYPE_CHECKING:
    from funcy_bear.constants.type_constants import StrPath


class JSONFileHandler(BytesFileHandler):
    """Thin subclass for semantic clarity (JSON full-text IO)."""

    def __init__(
        self,
        file: StrPath,
        mode: str = "r+b",
        touch: bool = False,
    ) -> None:
        """Initialize the JSON file handler.

        Args:
            file: Path to the JSON file
            mode: File open mode (default: "r+b")
            touch: Whether to create the file if it doesn't exist (default: False)
        """
        super().__init__(file=file, mode=mode, touch=touch)

    def write(self, data: Any, **kwargs: Any) -> None:
        """Write a Python object as JSON to the file.

        Args:
            data: The data to write
            **kwargs: Common json.dumps kwargs (indent, sort_keys, etc.) for compatibility
        """
        if isinstance(data, JSONLike):
            json_bytes: bytes = json_dumps(data, **kwargs)
        else:
            json_bytes = str(data).encode("utf-8")
        super().write(json_bytes)

    @overload
    def read(self, as_json: LitTrue = True) -> JSONLike: ...

    @overload
    def read(self, as_json: LitFalse) -> bytes: ...

    def read(self, as_json: bool = True) -> bytes | JSONLike | None:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Read the raw bytes content of the file or parse as JSON if specified."""
        data: bytes = super().read()
        if data and as_json:
            return json_loads(data)
        return data if data else None

    def to_string(self, **kwargs: Any) -> str:
        """Return the JSON content as a formatted string.

        Args:
            **kwargs: Common json.dumps kwargs (indent, sort_keys, etc.) for compatibility
        """
        data: bytes = self.read(as_json=False)
        if not data:
            return ""
        return json_dumps(data, **kwargs).decode("utf-8")

    def to_json(self) -> JSONLike | None:
        """Return the JSON content of the file as a Python object."""
        value: JSONLike = self.read(as_json=True)
        return value if isinstance(value, JSONLike) else None


__all__ = ["JSONFileHandler"]
