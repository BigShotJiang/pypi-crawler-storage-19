# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VideoDescriptions:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'gop_duration_seconds': 'int'
    }

    attribute_map = {
        'gop_duration_seconds': 'gop_duration_seconds'
    }

    def __init__(self, gop_duration_seconds=None):
        r"""VideoDescriptions

        The model defined in huaweicloud sdk

        :param gop_duration_seconds: 自定义gop时长，单位秒，有效取值[0,10]. 默认值0，表示跟随源流，不支持7和9，值无效时按默认值处理
        :type gop_duration_seconds: int
        """
        
        

        self._gop_duration_seconds = None
        self.discriminator = None

        if gop_duration_seconds is not None:
            self.gop_duration_seconds = gop_duration_seconds

    @property
    def gop_duration_seconds(self):
        r"""Gets the gop_duration_seconds of this VideoDescriptions.

        自定义gop时长，单位秒，有效取值[0,10]. 默认值0，表示跟随源流，不支持7和9，值无效时按默认值处理

        :return: The gop_duration_seconds of this VideoDescriptions.
        :rtype: int
        """
        return self._gop_duration_seconds

    @gop_duration_seconds.setter
    def gop_duration_seconds(self, gop_duration_seconds):
        r"""Sets the gop_duration_seconds of this VideoDescriptions.

        自定义gop时长，单位秒，有效取值[0,10]. 默认值0，表示跟随源流，不支持7和9，值无效时按默认值处理

        :param gop_duration_seconds: The gop_duration_seconds of this VideoDescriptions.
        :type gop_duration_seconds: int
        """
        self._gop_duration_seconds = gop_duration_seconds

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VideoDescriptions):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
