# visa-instrument-drivers

Tiny, pragmatic VISA instrument drivers built to use PyVISA.

```python
import pyvisa
from visa_instrument_drivers import RigolDP800

rm = pyvisa.ResourceManager()
instr = rm.open_resource("TCPIP::192.168.0.107::INSTR")
dp832a = RigolDP800(instr)
dp832a.write_source_voltage(13.5)          # CH1
print(dp832a.read_source_voltage())        # 13.5 (setpoint)
instr.close()
rm.close()
```

Build and publish

```shell
python -m pip install --upgrade pip build twine 
# python -m build 
# python -m twine upload --repository pypi dist/*
uv version --bump patch
uv build 
# uv tool install uv-publish
uv-publish # looks for .pypirc file with PyPI credentials
```