import pyvisa

class KeysightE36150:
    class Channel:
        class Number:
            CH1 = 1

    def __init__(self, instr: pyvisa.Resource):
        self.instr = instr
        return

    def query_output_state(self, channel: int) -> int:
        if channel not in KeysightE36150.Channel.Number:
            raise ValueError(f"Channel {channel} is not supported")

        msg = f":OUTP? (@{channel})"
        resp = self.instr.query(msg)
        state = int(resp.strip())
        return state

    def write_output_state(self, channel: int, state: int):
        if channel not in KeysightE36150.Channel.Number:
            raise ValueError(f"Channel {channel} is not supported")

        msg = f":OUTP {state},(@{channel})"
        self.instr.write(msg)
        return

