from enum import Enum
import math

import pyvisa

class RigolMSO5000:

    class Attenuation:

        class Ratio(Enum):
            AR100u = 0.0001
            AR200u = 0.0002
            AR500u = 0.0005
            AR1m = 0.001
            AR2m = 0.002
            AR5m = 0.005
            AR10m = 0.01
            AR20m = 0.02
            AR50m = 0.05
            AR100m = 0.1
            AR200m = 0.2
            AR500m = 0.5
            AR1 = 1
            AR2 = 2
            AR5 = 5
            AR10 = 10
            AR20 = 20
            AR50 = 50
            AR100 = 100
            AR200 = 200
            AR500 = 500
            AR1000 = 1000
            AR2000 = 2000
            AR5000 = 5000
            AR10000 = 10000
            AR20000 = 20000
            AR50000 = 50000

    class Channel:

        class Number(Enum):
            CH1 = 1
            CH2 = 2
            CH3 = 3
            CH4 = 4

    class Display:

        class State(Enum):
            OFF = 0
            ON = 1

    class Units(Enum):
        AMP = 'AMP'
        UNKN = 'UNKN'
        VOLT = 'VOLT'
        WATT = 'WATT'

    def __init__(self, instr: pyvisa.Resource):
        self.instr = instr
        return

    def query_channel_offset(self, channel: int) -> float:
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:OFFS?"
        resp = self.instr.query(msg)
        level = float(resp.strip())
        return level

    def write_channel_offset(self, channel: int, offset: float):
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:OFFS {offset}"
        self.instr.write(msg)
        return

    def query_channel_scale(self, channel: int) -> float:
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:SCAL?"
        resp = self.instr.query(msg)
        level = float(resp.strip())
        return level

    def write_channel_scale(self, channel: int, scale: float):
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")
        msg = f":CHAN{channel}:SCAL {scale}"
        self.instr.write(msg)
        return

    def query_channel_probe(self, channel: int) -> float:
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:PROB?"
        resp = self.instr.query(msg)
        level = float(resp.strip())
        return float(level)

    def write_channel_probe(self, channel: int, attenuation: float):
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        attenuation_value = None
        for option in RigolMSO5000.Attenuation.Ratio:
            if math.isclose(option.value, attenuation):
                attenuation_value = option.value
        if attenuation_value is None:
            raise ValueError("Invalid attenuation")

        msg = f":CHAN{channel}:PROB {attenuation_value}"
        self.instr.write(msg)
        return

    def query_channel_display(self, channel: int) -> int:
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:DISP?"
        resp = self.instr.query(msg)
        state = resp.strip()
        if state not in RigolMSO5000.Display.State:
            raise ValueError("Invalid display state")
        return state

    def write_channel_display(self, channel: int, state: int):
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:DISP {state}?"
        self.instr.write(msg)
        return

    def query_channel_units(self, channel: int) -> str:
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:UNIT?"
        resp = self.instr.query(msg)
        units = resp.strip()

        if units not in RigolMSO5000.Units:
            raise ValueError("Invalid units")

        return units

    def write_channel_units(self, channel: int, units: str):
        if channel not in RigolMSO5000.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":CHAN{channel}:UNIT {units}?"
        self.instr.write(msg)
        return
