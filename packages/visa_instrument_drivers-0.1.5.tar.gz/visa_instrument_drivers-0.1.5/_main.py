import pyvisa
from src.visa_instrument_drivers.rigol_dp800 import RigolDP800

def main():
    rm = pyvisa.ResourceManager() #'/Users/mborgh/Downloads/nodevisa-v0.0.3-osx-arm64/liblibrary.dylib')
    instr = rm.open_resource('Rigol DP832A SLC')

    rigol_dp832a = RigolDP800(instr)

    initial_current_limit = rigol_dp832a.query_source_current_level_immediate_amplitude(1)
    initial_voltage_level = rigol_dp832a.query_source_voltage_level_immediate_amplitude(1)
    initial_output_state = rigol_dp832a.query_output_state(1)

    rigol_dp832a.write_source_current_level_immediate_amplitude(1, 3.0)
    rigol_dp832a.write_source_voltage_level_immediate_amplitude(1, 5.0)
    rigol_dp832a.write_output_state(1, 1)

    final_current_limit = rigol_dp832a.query_source_current_level_immediate_amplitude(1)
    final_voltage_level = rigol_dp832a.query_source_voltage_level_immediate_amplitude(1)
    final_output_state = rigol_dp832a.query_output_state(1)

    instr.close()
    rm.close()

    return


if __name__ == '__main__':
    main()
