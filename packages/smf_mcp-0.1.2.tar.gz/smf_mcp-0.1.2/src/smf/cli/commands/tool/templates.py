def tool_template(tool_name: str, description: str | None) -> str:
    desc = description or "Tool description"
    return f'''"""
Tool: {tool_name}
{desc}
"""

from typing import Any


def {tool_name}(*args: Any, **kwargs: Any) -> Any:
    """
    {desc}

    Args:
        *args: Tool arguments
        **kwargs: Tool keyword arguments

    Returns:
        Tool result
    """
    # TODO: Implement tool logic
    return {{"result": "not implemented"}}
'''
