from pathlib import Path

from smf.cli.commands.init.examples import write_examples
from smf.cli.commands.init.readme import write_readme
from smf.cli.commands.init.requirements import write_requirements
from smf.cli.commands.init.server import write_server
from smf.cli.commands.init.settings import write_settings
from smf.cli.commands.init.structure import create_structure


def init_project(args) -> int:
    project_path = Path(args.directory)
    if project_path.exists() and not args.force:
        print(f"Error: Directory {project_path} already exists. Use --force to overwrite.")
        return 1

    project_path.mkdir(parents=True, exist_ok=True)

    paths = create_structure(project_path)
    write_examples(paths)
    write_server(project_path)
    write_settings(project_path)
    write_requirements(project_path)

    project_name = args.name or "SMF Server"
    write_readme(project_path, project_name)

    print(f"? Created SMF project in {project_path}")
    return 0
