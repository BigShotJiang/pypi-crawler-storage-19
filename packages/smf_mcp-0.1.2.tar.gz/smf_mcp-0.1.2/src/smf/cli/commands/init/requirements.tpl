smf-mcp>={version}
fastmcp
pytest
pytest-asyncio
