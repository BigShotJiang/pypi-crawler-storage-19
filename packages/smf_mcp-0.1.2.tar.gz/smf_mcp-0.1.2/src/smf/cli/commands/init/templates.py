from importlib import resources


def _read_template(name: str) -> str:
    return resources.files(__package__).joinpath(name).read_text(encoding="utf-8")


def example_tool_template() -> str:
    return _read_template("example_tool.tpl")


def example_resource_template() -> str:
    return _read_template("example_resource.tpl")


def example_prompt_template() -> str:
    return _read_template("example_prompt.tpl")


def example_test_template() -> str:
    return _read_template("example_test.tpl")


def server_template() -> str:
    return _read_template("server.tpl")


def requirements_template(version: str) -> str:
    return _read_template("requirements.tpl").replace("{version}", version)


def readme_template(project_name: str) -> str:
    return _read_template("readme.tpl").replace("{project_name}", project_name)
