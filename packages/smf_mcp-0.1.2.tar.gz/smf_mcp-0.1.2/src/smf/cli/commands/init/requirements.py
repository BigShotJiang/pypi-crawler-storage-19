import importlib.metadata
from pathlib import Path

from smf.cli.commands.init.templates import requirements_template
from smf.cli.io import write_utf8


def _get_version() -> str:
    try:
        return importlib.metadata.version("smf-mcp")
    except importlib.metadata.PackageNotFoundError:
        return "0.1.1"


def write_requirements(project_path: Path) -> None:
    requirements_file = project_path / "requirements.txt"
    write_utf8(requirements_file, requirements_template(_get_version()))
