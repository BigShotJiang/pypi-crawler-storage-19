from pathlib import Path

from smf.cli.commands.init.templates import (
    example_prompt_template,
    example_resource_template,
    example_test_template,
    example_tool_template,
)
from smf.cli.io import write_utf8


def write_examples(paths: dict[str, Path]) -> None:
    tools_dir = paths["tools"]
    resources_dir = paths["resources"]
    prompts_dir = paths["prompts"]
    tests_dir = paths["tests"]

    write_utf8(tools_dir / "example_tool.py", example_tool_template())
    write_utf8(resources_dir / "example_resource.py", example_resource_template())
    write_utf8(prompts_dir / "example_prompt.py", example_prompt_template())
    write_utf8(tests_dir / "test_example.py", example_test_template())
