# {project_name}

Serveur MCP créé avec SMF (Enterprise MCP Framework).

## 🚀 Démarrage rapide

### Installation

```bash
# Installer les dépendances
# Installer les dépendances
uv add smf-mcp fastmcp pytest pytest-asyncio

# Ou avec pip
pip install -r requirements.txt
```

### Lancer le serveur

```bash
# Mode stdio (développement local)
python server.py

# Mode HTTP (accès distant)
python server.py --transport http --port 8000
```

## 📁 Structure du projet

```
{project_name}/
├── server.py              # Point d'entrée principal du serveur
├── smf.yaml              # Configuration SMF
├── src/
│   ├── tools/             # Définitions d'outils (tools)
│   │   └── example_tool.py
│   ├── resources/         # Définitions de ressources
│   │   └── example_resource.py
│   └── prompts/           # Templates de prompts
│       └── example_prompt.py
└── tests/                 # Tests unitaires
    └── test_example.py
```

## 🛠️ Composants inclus

### Tools (Outils)

Le projet inclut des exemples d'outils dans `src/tools/example_tool.py`:
- `greet(name)`: Salue quelqu'un par son nom
- `calculate(operation, a, b)`: Effectue des calculs mathématiques

### Resources (Ressources)

Exemples dans `src/resources/example_resource.py`:
- `get_server_info()`: Obtient des informations sur le serveur
- `get_config()`: Obtient la configuration

### Prompts

Exemples dans `src/prompts/example_prompt.py`:
- `system_prompt()`: Prompt système pour l'assistant
- `code_review_prompt()`: Template pour révision de code
- `data_analysis_prompt()`: Template pour analyse de données

## ➕ Ajouter un nouvel outil

```bash
smf add-tool mon-outil --description "Description de mon outil"
```

Cela crée `src/tools/mon-outil.py`. Ensuite, importez et enregistrez-le dans `server.py`:

```python
from src.tools.mon_outil import mon_outil

@mcp.tool
def mon_outil(...):
    return mon_outil(...)
```

## ⚙️ Configuration

Modifiez `smf.yaml` pour personnaliser:
- Nom et version du serveur
- Transport (stdio/http/sse)
- Logging et métriques
- Rate limiting
- Authentification

## 🧪 Tests

```bash
# Lancer les tests
pytest

# Avec couverture
pytest --cov=src
```

## 📚 Documentation

- [Guide SMF](https://github.com/your-repo/smf)
- [Documentation FastMCP](https://fastmcp.wiki/)
- [Architecture SMF](./src/docs/architecture.md)

## 🔧 Commandes CLI

```bash
# Initialiser un projet
smf init mon-projet

# Ajouter un outil
smf add-tool nom-outil --description "Description"

# Valider la configuration
smf validate --config smf.yaml

# Lancer le serveur
smf run server.py --transport http --port 8000
```

## 📝 Exemples

Voir les exemples dans:
- `src/examples/simple_server/` - Serveur simple
- `src/examples/advanced_server/` - Serveur avancé avec configuration

## 🤝 Contribution

Ce projet utilise SMF, un framework enterprise pour créer des serveurs MCP.

Pour plus d'informations, consultez la documentation SMF.
