from smf.cli.commands.elasticsearch.activate import _activate_elasticsearch, activate_plugin_command
from smf.cli.commands.elasticsearch.init import init_elasticsearch_command


def add_parser(subparsers) -> None:
    init_parser = subparsers.add_parser(
        "init-elasticsearch",
        help="Initialize new Elasticsearch SMF server",
    )
    init_parser.add_argument("directory", help="Project directory")
    init_parser.add_argument("--name", help="Server name")
    init_parser.add_argument(
        "--hosts",
        default="http://localhost:9200",
        help="Elasticsearch hosts (default: http://localhost:9200)",
    )
    init_parser.add_argument(
        "--index",
        help="Default Elasticsearch index name (default: my_index)",
    )
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing")
    init_parser.set_defaults(func=init_elasticsearch_command)

    activate_parser = subparsers.add_parser(
        "activate-plugin",
        help="Activate a plugin in existing project",
    )
    activate_parser.add_argument("plugin", choices=["elasticsearch"], help="Plugin to activate")
    activate_parser.add_argument(
        "--directory",
        default=".",
        help="Target directory (default: current)",
    )
    activate_parser.add_argument(
        "--hosts",
        help="Elasticsearch hosts (for elasticsearch plugin)",
    )
    activate_parser.add_argument(
        "--force",
        action="store_true",
        help="Force activation even if validation fails",
    )
    activate_parser.set_defaults(func=activate_plugin_command)


__all__ = [
    "add_parser",
    "init_elasticsearch_command",
    "activate_plugin_command",
    "_activate_elasticsearch",
]
