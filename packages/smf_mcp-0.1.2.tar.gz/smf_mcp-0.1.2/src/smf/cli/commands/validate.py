import argparse
import sys
from pathlib import Path
from typing import List

import pytest


def add_parser(subparsers) -> None:
    validate_parser = subparsers.add_parser("validate", help="Validate configuration")
    validate_parser.add_argument("--config", default="smf.yaml", help="Config file path")
    validate_parser.add_argument(
        "--tests", "-t",
        action="store_true",
        help="Also run comprehensive configuration tests",
    )
    validate_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Verbose output"
    )
    validate_parser.set_defaults(func=validate_command)


def validate_command(args: argparse.Namespace) -> int:
    """
    Validate SMF configuration.

    This command validates the configuration file syntax and values.
    Use --tests (-t) to also run comprehensive tests.

    Args:
        args: CLI arguments

    Returns:
        Exit code (0 = success, 1 = failure)
    """
    from smf.validation import validate_config_file
    from smf.settings import load_settings

    config_file = Path(args.config)
    if not config_file.exists():
        print(f"❌ Error: Config file not found: {config_file}", file=sys.stderr)
        return 1

    # Étape 1: Validation de base de la configuration
    print("📋 Step 1: Validating configuration file...")
    success, errors, warnings = validate_config_file(config_file)

    if errors:
        print("\n❌ Configuration validation failed:\n", file=sys.stderr)
        for error in errors:
            print(f"  • {error}", file=sys.stderr)
        return 1

    if warnings:
        print("\n⚠️  Warnings:\n")
        for warning in warnings:
            print(f"  • {warning}")

    # Afficher les informations de configuration
    try:
        settings = load_settings(base_dir=config_file.parent, config_file=config_file)
        print("\n✅ Configuration is valid")
        print(f"   Server name: {settings.server_name}")
        print(f"   Transport: {settings.transport}")
        print(f"   Environment: {settings.environment}")
        print(f"   Auth provider: {settings.auth_provider}")
    except Exception as e:
        print(f"\n❌ Error loading configuration: {e}", file=sys.stderr)
        return 1

    # Étape 2: Exécuter les tests complets (seulement si --tests ou -t)
    if not args.tests:
        return 0

    print("\n🧪 Step 2: Running comprehensive configuration tests...\n")

    # Obtenir les chemins des modules de tests
    # Les tests sont dans smf/testing/ (dans le package installé)
    try:
        import smf.testing
        testing_dir = Path(smf.testing.__file__).parent
    except (ImportError, AttributeError):
        # Fallback: utiliser le chemin relatif depuis ce fichier
        testing_dir = Path(__file__).parent.parent.parent / "testing"
    
    test_files = [
        testing_dir / "test_config_validation.py",
        testing_dir / "test_config_integration.py",
    ]

    # Vérifier que les fichiers de test existent
    existing_test_files = [f for f in test_files if f.exists()]
    if not existing_test_files:
        print(
            f"⚠️  Warning: No test files found in {testing_dir}", file=sys.stderr
        )
        print("   Configuration validation passed, but tests could not be run.", file=sys.stderr)
        return 0  # On retourne 0 car la validation de base a réussi

    # Préparer les arguments pytest
    pytest_args: List[str] = [str(f) for f in existing_test_files]
    if args.verbose:
        pytest_args.append("-v")

    # Exécuter pytest
    exit_code = pytest.main(pytest_args)

    if exit_code == 0:
        print("\n✅ All configuration tests passed!")
        return 0
    else:
        print("\n❌ Some configuration tests failed!", file=sys.stderr)
        return exit_code
