"""Compatibility wrapper for the SMF Inspector CLI."""

from smf.inspector.client import SMFInspector
from smf.inspector.main import main, run_official_inspector
from smf.inspector.modes import interactive_mode, list_mode
from smf.inspector.printers import print_prompts, print_resources, print_section, print_tools

__all__ = [
    "SMFInspector",
    "print_section",
    "print_tools",
    "print_resources",
    "print_prompts",
    "interactive_mode",
    "list_mode",
    "run_official_inspector",
    "main",
]

if __name__ == "__main__":
    raise SystemExit(main())
