import json


def print_section(title: str) -> None:
    """Print a section header."""
    print(f"\n{'=' * 60}")
    print(f" {title}")
    print(f"{'=' * 60}\n")


def print_tools(tools: list) -> None:
    """Print tools list."""
    print_section("TOOLS")
    if not tools:
        print("No tools available.")
        return

    for tool in tools:
        print(f"  • {tool.name}")
        if tool.description:
            print(f"    {tool.description}")
        if hasattr(tool, "inputSchema") and tool.inputSchema:
            print(f"    Schema: {json.dumps(tool.inputSchema, indent=4)}")
        print()


def print_resources(resources: list) -> None:
    """Print resources list."""
    print_section("RESOURCES")
    if not resources:
        print("No resources available.")
        return

    for resource in resources:
        print(f"  • {resource.uri}")
        if resource.name:
            print(f"    Name: {resource.name}")
        if resource.description:
            print(f"    Description: {resource.description}")
        if resource.mimeType:
            print(f"    MIME Type: {resource.mimeType}")
        print()


def print_prompts(prompts: list) -> None:
    """Print prompts list."""
    print_section("PROMPTS")
    if not prompts:
        print("No prompts available.")
        return

    for prompt in prompts:
        print(f"  • {prompt.name}")
        if prompt.description:
            print(f"    Description: {prompt.description}")
        if hasattr(prompt, "arguments") and prompt.arguments:
            print(f"    Arguments: {json.dumps(prompt.arguments, indent=4)}")
        print()
