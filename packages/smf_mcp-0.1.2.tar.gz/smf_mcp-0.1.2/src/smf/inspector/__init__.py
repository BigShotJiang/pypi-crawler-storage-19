"""
SMF MCP Inspector - Interactive tool for testing and debugging SMF servers.

Provides a command-line interface similar to MCP Inspector for inspecting
and testing SMF servers interactively.
"""

from smf.inspector.main import main as inspector_main

__all__ = ["inspector_main"]
