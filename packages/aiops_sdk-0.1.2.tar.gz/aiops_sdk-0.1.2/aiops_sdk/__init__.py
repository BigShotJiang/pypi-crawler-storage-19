from .config import load_config
from .exceptions import register_exception_hook, capture_exception
from .scheduler import start_heartbeat
from .version import __version__

def init(api_key=None):
    load_config(api_key)
    register_exception_hook()
    start_heartbeat()