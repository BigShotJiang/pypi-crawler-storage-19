import sys
import traceback
from .client import send_sync
from .payload import base_payload

def _handler(exc_type, exc, tb):
    payload = base_payload()
    payload.update({
        "error_type": exc_type.__name__,
        "message": str(exc),
        "stack_trace": "".join(traceback.format_tb(tb))
    })

    # 🔴 BLOCKING SEND (REQUIRED)
    send_sync("/v1/sdk/exception", payload)

def register_exception_hook():
    sys.excepthook = _handler

def capture_exception(exc):
    payload = base_payload()
    payload.update({
        "error_type": type(exc).__name__,
        "message": str(exc),
        "stack_trace": traceback.format_exc()
    })

    # 🔴 BLOCKING SEND (REQUIRED)
    send_sync("/v1/sdk/exception", payload)
