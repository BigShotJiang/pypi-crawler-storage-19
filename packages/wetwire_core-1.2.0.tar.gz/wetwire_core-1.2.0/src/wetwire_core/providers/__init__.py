"""Provider abstraction layer for multi-backend AI support.

This module provides a unified interface for different AI providers:
- Anthropic (Claude API)
- Kiro (AWS-based AI)

Usage:
    from wetwire_core.providers import get_provider, AnthropicProvider

    # Get default provider
    provider = get_provider("anthropic")

    # Use provider
    response = provider.create_message(
        messages=[{"role": "user", "content": "Hello"}],
        system="You are helpful.",
    )
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

import anthropic


@runtime_checkable
class Provider(Protocol):
    """Protocol for AI provider implementations.

    All providers must implement create_message and stream_message methods.
    """

    model: str

    def create_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> dict[str, Any]:
        """Create a message using the provider's API.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions.
            max_tokens: Maximum tokens in response.

        Returns:
            Response dictionary with content and metadata.
        """
        ...

    def stream_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> Iterator[dict[str, Any]]:
        """Stream a message response from the provider.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions.
            max_tokens: Maximum tokens in response.

        Yields:
            Stream events from the provider.
        """
        ...


@dataclass
class AnthropicProvider:
    """Anthropic Claude API provider.

    Wraps the Anthropic SDK to provide a consistent interface.
    """

    model: str = "claude-sonnet-4-20250514"
    client: anthropic.Anthropic = field(default_factory=anthropic.Anthropic)

    def create_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> dict[str, Any]:
        """Create a message using Claude API.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions.
            max_tokens: Maximum tokens in response.

        Returns:
            Response dictionary with content and metadata.
        """
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools

        response = self.client.messages.create(**kwargs)

        # Convert response to dict format
        return {
            "content": [
                {"type": block.type, "text": getattr(block, "text", None)}
                if block.type == "text"
                else {
                    "type": block.type,
                    "id": getattr(block, "id", None),
                    "name": getattr(block, "name", None),
                    "input": getattr(block, "input", None),
                }
                for block in response.content
            ],
            "stop_reason": response.stop_reason,
            "model": response.model,
            "usage": {
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
        }

    def stream_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> Iterator[dict[str, Any]]:
        """Stream a message response from Claude API.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions.
            max_tokens: Maximum tokens in response.

        Yields:
            Stream events from Claude API.
        """
        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools

        with self.client.messages.stream(**kwargs) as stream:
            for event in stream:
                yield {"type": event.type, "event": event}


@dataclass
class KiroProvider:
    """Kiro CLI-based provider.

    Uses Kiro CLI in non-interactive mode for AI interactions.
    This provider requires kiro-cli to be installed.

    Note: Kiro provider has limitations compared to Anthropic:
    - Streaming is not supported (returns single response)
    - Tool use depends on Kiro CLI capabilities
    """

    model: str = "kiro"
    agent_name: str = "wetwire-runner"
    agent_prompt: str = "You are a helpful AI assistant."
    mcp_command: str | None = None

    def create_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> dict[str, Any]:
        """Create a message using Kiro CLI.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions (limited support).
            max_tokens: Maximum tokens in response (not enforced by Kiro).

        Returns:
            Response dictionary with content and metadata.

        Raises:
            ImportError: If kiro module is not available.
            FileNotFoundError: If kiro-cli is not installed.
        """
        from wetwire_core.kiro import (
            KIRO_AVAILABLE,
            KiroConfig,
            run_scenario,
        )

        if not KIRO_AVAILABLE:
            raise FileNotFoundError("kiro-cli not found in PATH")

        # Build prompt from messages
        prompt_parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, list):
                # Handle structured content
                content = " ".join(
                    block.get("text", "") for block in content if block.get("type") == "text"
                )
            prompt_parts.append(f"{role}: {content}")

        prompt = "\n".join(prompt_parts)

        config = KiroConfig(
            agent_name=self.agent_name,
            agent_prompt=system or self.agent_prompt,
            mcp_command=self.mcp_command or "wetwire-mcp",
        )

        result = run_scenario(config, prompt)

        return {
            "content": [{"type": "text", "text": result.output}],
            "stop_reason": "end_turn" if result.exit_code == 0 else "error",
            "model": self.model,
            "usage": {
                "input_tokens": 0,  # Kiro doesn't report token usage
                "output_tokens": 0,
            },
        }

    def stream_message(
        self,
        messages: list[dict[str, Any]],
        system: str,
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 4096,
    ) -> Iterator[dict[str, Any]]:
        """Stream a message response from Kiro.

        Note: Kiro CLI doesn't support streaming, so this returns
        the complete response as a single event.

        Args:
            messages: Conversation history.
            system: System prompt.
            tools: Optional list of tool definitions.
            max_tokens: Maximum tokens in response.

        Yields:
            Single stream event with complete response.
        """
        response = self.create_message(messages, system, tools, max_tokens)
        yield {"type": "message_complete", "event": response}


def get_provider(name: str, model: str | None = None, **kwargs: Any) -> Provider:
    """Get a provider instance by name.

    Args:
        name: Provider name ("anthropic", "kiro").
        model: Optional model override.
        **kwargs: Additional arguments passed to provider constructor.

    Returns:
        Provider instance.

    Raises:
        ValueError: If provider name is not recognized.
    """
    providers: dict[str, type] = {
        "anthropic": AnthropicProvider,
        "kiro": KiroProvider,
    }

    if name not in providers:
        valid = ", ".join(providers.keys())
        raise ValueError(f"Unknown provider '{name}'. Valid: {valid}")

    provider_cls = providers[name]
    if model:
        return provider_cls(model=model, **kwargs)
    return provider_cls(**kwargs)


__all__ = [
    "Provider",
    "AnthropicProvider",
    "KiroProvider",
    "get_provider",
]
