"""Standard MCP tool definitions for wetwire domain packages.

This module provides standard tool schemas that all wetwire domain packages
should implement. Domain packages can use these definitions and provide
their own handlers.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol


class ToolHandler(Protocol):
    """Protocol for MCP tool handlers."""

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the tool with given arguments.

        Returns:
            Dictionary with 'success' (bool) and 'message' (str) keys.
        """
        ...


@dataclass
class ToolResult:
    """Result from a tool handler."""

    success: bool
    message: str


@dataclass
class ToolDefinition:
    """Definition of an MCP tool."""

    name: str
    description: str
    input_schema: dict[str, Any]


# Standard tool schemas

INIT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "name": {
            "type": "string",
            "description": "Project name",
        },
        "output": {
            "type": "string",
            "description": "Output directory (default: current directory)",
        },
    },
}

BUILD_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "package": {
            "type": "string",
            "description": "Package path to discover resources from",
        },
        "output": {
            "type": "string",
            "description": "Output directory for generated files",
        },
        "format": {
            "type": "string",
            "enum": ["yaml", "json"],
            "description": "Output format (default: yaml)",
        },
    },
}

LINT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "package": {
            "type": "string",
            "description": "Package path to lint",
        },
        "fix": {
            "type": "boolean",
            "description": "Automatically fix fixable issues",
        },
        "format": {
            "type": "string",
            "enum": ["text", "json"],
            "description": "Output format (default: text)",
        },
    },
}

VALIDATE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "files": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Files to validate",
        },
        "format": {
            "type": "string",
            "enum": ["text", "json"],
            "description": "Output format (default: text)",
        },
    },
}

IMPORT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "files": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Files to import",
        },
        "output": {
            "type": "string",
            "description": "Output directory for generated code",
        },
        "single_file": {
            "type": "boolean",
            "description": "Generate all code in a single file",
        },
    },
}

LIST_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "package": {
            "type": "string",
            "description": "Package path to discover from",
        },
        "format": {
            "type": "string",
            "enum": ["table", "json"],
            "description": "Output format (default: table)",
        },
    },
}

GRAPH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "package": {
            "type": "string",
            "description": "Package path to analyze",
        },
        "format": {
            "type": "string",
            "enum": ["dot", "mermaid"],
            "description": "Output format (default: mermaid)",
        },
        "output": {
            "type": "string",
            "description": "Output file path",
        },
    },
}


def get_standard_tool_definitions(domain: str) -> list[ToolDefinition]:
    """Get standard tool definitions for a domain.

    Args:
        domain: Domain name (e.g., "github", "aws").

    Returns:
        List of ToolDefinition objects.
    """
    return [
        ToolDefinition(
            name="wetwire_init",
            description=f"Initialize a new wetwire-{domain} project with example code",
            input_schema=INIT_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_build",
            description=f"Generate {domain} output from wetwire declarations",
            input_schema=BUILD_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_lint",
            description="Check code quality and style (domain lint rules)",
            input_schema=LINT_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_validate",
            description="Validate generated output using external validator",
            input_schema=VALIDATE_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_import",
            description=f"Convert existing {domain} configs to wetwire code",
            input_schema=IMPORT_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_list",
            description="List discovered resources",
            input_schema=LIST_SCHEMA,
        ),
        ToolDefinition(
            name="wetwire_graph",
            description="Visualize resource dependencies (DOT/Mermaid)",
            input_schema=GRAPH_SCHEMA,
        ),
    ]


@dataclass
class StandardToolHandlers:
    """Container for standard tool handlers.

    Domain packages provide these handlers to implement standard tools.
    If a handler is None, that tool is not registered.
    """

    init: Callable[..., ToolResult] | None = None
    build: Callable[..., ToolResult] | None = None
    lint: Callable[..., ToolResult] | None = None
    validate: Callable[..., ToolResult] | None = None
    import_: Callable[..., ToolResult] | None = field(default=None)  # import is reserved
    list_: Callable[..., ToolResult] | None = field(default=None)  # list is reserved
    graph: Callable[..., ToolResult] | None = None


def get_standard_tools_for_mcp(
    domain: str,
    handlers: StandardToolHandlers,
) -> list[dict[str, Any]]:
    """Get MCP tool definitions with handlers for registration.

    Args:
        domain: Domain name (e.g., "github", "aws").
        handlers: StandardToolHandlers with domain-specific implementations.

    Returns:
        List of tool dicts suitable for MCP server registration.
    """
    definitions = get_standard_tool_definitions(domain)
    handler_map: dict[str, Callable[..., ToolResult] | None] = {
        "wetwire_init": handlers.init,
        "wetwire_build": handlers.build,
        "wetwire_lint": handlers.lint,
        "wetwire_validate": handlers.validate,
        "wetwire_import": handlers.import_,
        "wetwire_list": handlers.list_,
        "wetwire_graph": handlers.graph,
    }

    tools = []
    for defn in definitions:
        handler = handler_map.get(defn.name)
        if handler is None:
            continue

        tools.append({
            "name": defn.name,
            "description": defn.description,
            "inputSchema": defn.input_schema,
            "handler": handler,
        })

    return tools


__all__ = [
    "ToolHandler",
    "ToolResult",
    "ToolDefinition",
    "StandardToolHandlers",
    "INIT_SCHEMA",
    "BUILD_SCHEMA",
    "LINT_SCHEMA",
    "VALIDATE_SCHEMA",
    "IMPORT_SCHEMA",
    "LIST_SCHEMA",
    "GRAPH_SCHEMA",
    "get_standard_tool_definitions",
    "get_standard_tools_for_mcp",
]
