"""Orchestrator for Developer/Runner communication.

The orchestrator coordinates communication between the Developer (human or AI)
and the Runner (AI with CLI tools). It handles:

- Message routing between Developer and Runner
- Maximum cycle enforcement (default: 3 lint cycles)
- Session state management
- Final output collection
"""

from dataclasses import dataclass, field
from typing import Any, Protocol


class DeveloperProtocol(Protocol):
    """Protocol for Developer role (human or AI)."""

    def respond(self, message: str) -> str:
        """Respond to a message from the Runner."""
        ...


class RunnerProtocol(Protocol):
    """Protocol for Runner role (AI with CLI tools)."""

    def process(self, message: str) -> str:
        """Process a message and return response or question."""
        ...

    def is_complete(self) -> bool:
        """Check if the Runner has completed its work."""
        ...


@dataclass
class SessionConfig:
    """Configuration for an orchestration session."""

    domain: str
    max_lint_cycles: int = 3
    max_turns: int = 50
    output_dir: str | None = None


@dataclass
class Session:
    """Represents an orchestration session."""

    config: SessionConfig
    developer: Any  # DeveloperProtocol - using Any to avoid Protocol in dataclass
    runner: Any  # RunnerProtocol - using Any to avoid Protocol in dataclass
    messages: list[dict[str, Any]] = field(default_factory=list)
    lint_cycles: int = 0
    turns: int = 0
    complete: bool = False
    output_path: str | None = None
    score: int | None = None


class OrchestratorError(Exception):
    """Base exception for orchestrator errors."""

    pass


class MaxLintCyclesExceeded(OrchestratorError):
    """Raised when maximum lint cycles is exceeded."""

    pass


class MaxTurnsExceeded(OrchestratorError):
    """Raised when maximum turns is exceeded."""

    pass


class Orchestrator:
    """Coordinates Developer/Runner communication.

    The orchestrator manages the back-and-forth between Developer and Runner,
    enforcing constraints like maximum lint cycles and collecting outputs.

    Example:
        >>> orchestrator = Orchestrator()
        >>> session = orchestrator.create_session(
        ...     domain="aws",
        ...     developer=ai_developer,
        ...     runner=ai_runner,
        ... )
        >>> result = orchestrator.run(session, initial_prompt="Create a VPC")
    """

    # Keywords that indicate a lint cycle occurred
    LINT_KEYWORDS = ["lint", "linting", "lint error", "lint warning", "linter"]

    def __init__(self) -> None:
        """Initialize the orchestrator."""
        pass

    def create_session(
        self,
        domain: str,
        developer: DeveloperProtocol,
        runner: RunnerProtocol,
        max_lint_cycles: int = 3,
        max_turns: int = 50,
    ) -> Session:
        """Create a new orchestration session.

        Args:
            domain: The domain to use (e.g., "aws", "gcp", "azure")
            developer: The Developer role implementation
            runner: The Runner role implementation
            max_lint_cycles: Maximum number of lint cycles allowed
            max_turns: Maximum number of conversation turns

        Returns:
            A new Session object
        """
        config = SessionConfig(
            domain=domain,
            max_lint_cycles=max_lint_cycles,
            max_turns=max_turns,
        )
        return Session(config=config, developer=developer, runner=runner)

    def _add_message(
        self, session: Session, role: str, content: str
    ) -> dict[str, Any]:
        """Add a message to the session history.

        Args:
            session: The session to add the message to
            role: The role (developer, runner)
            content: The message content

        Returns:
            The message dict that was added
        """
        message = {"role": role, "content": content, "turn": session.turns}
        session.messages.append(message)
        return message

    def _detect_lint_cycle(self, response: str) -> bool:
        """Detect if a response indicates a lint cycle.

        Args:
            response: The runner's response

        Returns:
            True if this appears to be a lint cycle
        """
        response_lower = response.lower()
        return any(keyword in response_lower for keyword in self.LINT_KEYWORDS)

    def run(self, session: Session, initial_prompt: str) -> dict[str, Any]:
        """Run an orchestration session.

        Coordinates the Developer/Runner conversation loop until the Runner
        signals completion or limits are exceeded.

        Args:
            session: The session to run
            initial_prompt: The initial prompt from the Developer

        Returns:
            Result dictionary with:
                - success: Whether the session completed successfully
                - output_path: Path to generated output (if any)
                - score: Final score (if scoring enabled)
                - messages: Full conversation history
                - lint_cycles: Number of lint cycles used
                - turns: Total conversation turns

        Raises:
            MaxLintCyclesExceeded: If max_lint_cycles is exceeded
            MaxTurnsExceeded: If max_turns is exceeded
        """
        # Add initial prompt as first message
        self._add_message(session, "developer", initial_prompt)

        # Send initial prompt to runner
        current_message = initial_prompt

        while not session.complete:
            session.turns += 1

            # Check turn limit
            if session.turns > session.config.max_turns:
                raise MaxTurnsExceeded(
                    f"Exceeded maximum turns ({session.config.max_turns})"
                )

            # Runner processes the message
            runner_response = session.runner.process(current_message)
            self._add_message(session, "runner", runner_response)

            # Check for lint cycle
            if self._detect_lint_cycle(runner_response):
                session.lint_cycles += 1
                if session.lint_cycles > session.config.max_lint_cycles:
                    raise MaxLintCyclesExceeded(
                        f"Exceeded maximum lint cycles ({session.config.max_lint_cycles})"
                    )

            # Check if runner is complete
            if session.runner.is_complete():
                session.complete = True
                break

            # Developer responds to runner
            developer_response = session.developer.respond(runner_response)
            self._add_message(session, "developer", developer_response)

            # Next iteration uses developer's response
            current_message = developer_response

        return {
            "success": session.complete,
            "output_path": session.output_path,
            "score": session.score,
            "messages": session.messages,
            "lint_cycles": session.lint_cycles,
            "turns": session.turns,
            "domain": session.config.domain,
        }
