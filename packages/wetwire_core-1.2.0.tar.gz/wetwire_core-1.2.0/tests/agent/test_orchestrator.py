"""Tests for agent.orchestrator module."""

import pytest

from wetwire_core.agent.orchestrator import (
    MaxLintCyclesExceeded,
    MaxTurnsExceeded,
    Orchestrator,
    OrchestratorError,
    Session,
    SessionConfig,
)


class MockDeveloper:
    """Mock Developer for testing."""

    def __init__(self, responses: list[str] | None = None):
        self.responses = responses or ["continue"]
        self.response_index = 0
        self.received_messages: list[str] = []

    def respond(self, message: str) -> str:
        self.received_messages.append(message)
        response = self.responses[min(self.response_index, len(self.responses) - 1)]
        self.response_index += 1
        return response


class MockRunner:
    """Mock Runner for testing."""

    def __init__(
        self,
        responses: list[str] | None = None,
        complete_after: int = 1,
    ):
        self.responses = responses or ["done"]
        self.response_index = 0
        self.complete_after = complete_after
        self.call_count = 0
        self.received_messages: list[str] = []

    def process(self, message: str) -> str:
        self.received_messages.append(message)
        self.call_count += 1
        response = self.responses[min(self.response_index, len(self.responses) - 1)]
        self.response_index += 1
        return response

    def is_complete(self) -> bool:
        return self.call_count >= self.complete_after


class TestSessionConfig:
    """Tests for SessionConfig dataclass."""

    def test_session_config_creation_minimal(self):
        """Test SessionConfig creation with minimal fields."""
        config = SessionConfig(domain="aws")
        assert config.domain == "aws"
        assert config.max_lint_cycles == 3
        assert config.max_turns == 50
        assert config.output_dir is None

    def test_session_config_creation_full(self):
        """Test SessionConfig creation with all fields."""
        config = SessionConfig(
            domain="gcp",
            max_lint_cycles=5,
            max_turns=100,
            output_dir="/tmp/output",
        )
        assert config.domain == "gcp"
        assert config.max_lint_cycles == 5
        assert config.max_turns == 100
        assert config.output_dir == "/tmp/output"


class TestSession:
    """Tests for Session dataclass."""

    def test_session_creation_minimal(self):
        """Test Session creation with minimal fields."""
        config = SessionConfig(domain="aws")
        developer = MockDeveloper()
        runner = MockRunner()
        session = Session(config=config, developer=developer, runner=runner)

        assert session.config == config
        assert session.developer == developer
        assert session.runner == runner
        assert session.messages == []
        assert session.lint_cycles == 0
        assert session.turns == 0
        assert session.complete is False
        assert session.output_path is None
        assert session.score is None

    def test_session_creation_with_data(self):
        """Test Session creation with data."""
        config = SessionConfig(domain="aws")
        developer = MockDeveloper()
        runner = MockRunner()
        messages = [{"role": "developer", "content": "Create a VPC", "turn": 0}]
        session = Session(
            config=config,
            developer=developer,
            runner=runner,
            messages=messages,
            lint_cycles=2,
            turns=5,
            complete=True,
            output_path="/tmp/output",
            score=12,
        )

        assert session.config == config
        assert session.messages == messages
        assert session.lint_cycles == 2
        assert session.turns == 5
        assert session.complete is True
        assert session.output_path == "/tmp/output"
        assert session.score == 12


class TestOrchestrator:
    """Tests for Orchestrator class."""

    def test_orchestrator_initialization(self):
        """Test that Orchestrator can be initialized."""
        orchestrator = Orchestrator()
        assert orchestrator is not None

    def test_create_session_minimal(self):
        """Test create_session with minimal parameters."""
        orchestrator = Orchestrator()
        developer = MockDeveloper()
        runner = MockRunner()

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
        )

        assert isinstance(session, Session)
        assert session.config.domain == "aws"
        assert session.config.max_lint_cycles == 3
        assert session.config.max_turns == 50
        assert session.developer == developer
        assert session.runner == runner
        assert session.messages == []
        assert session.lint_cycles == 0
        assert session.complete is False

    def test_create_session_with_custom_limits(self):
        """Test create_session with custom max_lint_cycles and max_turns."""
        orchestrator = Orchestrator()
        developer = MockDeveloper()
        runner = MockRunner()

        session = orchestrator.create_session(
            domain="gcp",
            developer=developer,
            runner=runner,
            max_lint_cycles=5,
            max_turns=100,
        )

        assert session.config.domain == "gcp"
        assert session.config.max_lint_cycles == 5
        assert session.config.max_turns == 100


class TestOrchestratorRun:
    """Tests for Orchestrator.run() method."""

    def test_run_simple_completion(self):
        """Test run() with immediate completion."""
        orchestrator = Orchestrator()
        developer = MockDeveloper()
        runner = MockRunner(responses=["Task complete"], complete_after=1)

        session = orchestrator.create_session(
            domain="azure",
            developer=developer,
            runner=runner,
        )

        result = orchestrator.run(session, "Create a storage account")

        assert result["success"] is True
        assert result["turns"] == 1
        assert result["lint_cycles"] == 0
        assert result["domain"] == "azure"
        assert len(result["messages"]) == 2  # initial + runner response
        assert result["messages"][0]["role"] == "developer"
        assert result["messages"][0]["content"] == "Create a storage account"
        assert result["messages"][1]["role"] == "runner"
        assert result["messages"][1]["content"] == "Task complete"

    def test_run_multi_turn_conversation(self):
        """Test run() with multiple turns."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["Yes, proceed", "Looks good"])
        runner = MockRunner(
            responses=["Should I create VPC?", "Creating VPC...", "Done!"],
            complete_after=3,
        )

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
        )

        result = orchestrator.run(session, "Create infrastructure")

        assert result["success"] is True
        assert result["turns"] == 3
        # Messages: initial, runner1, dev1, runner2, dev2, runner3
        assert len(result["messages"]) == 6
        assert runner.received_messages == [
            "Create infrastructure",
            "Yes, proceed",
            "Looks good",
        ]
        assert developer.received_messages == [
            "Should I create VPC?",
            "Creating VPC...",
        ]

    def test_run_detects_lint_cycles(self):
        """Test that run() detects lint cycles from runner responses."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["Fix it", "Fix again"])
        runner = MockRunner(
            responses=["Lint error found", "Another lint warning", "All clean!"],
            complete_after=3,
        )

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
            max_lint_cycles=5,
        )

        result = orchestrator.run(session, "Build project")

        assert result["success"] is True
        assert result["lint_cycles"] == 2  # Two lint-related responses

    def test_run_max_lint_cycles_exceeded(self):
        """Test that run() raises MaxLintCyclesExceeded."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["Fix it"] * 10)
        runner = MockRunner(
            responses=["Lint error"] * 10,  # Always reports lint errors
            complete_after=100,  # Never completes
        )

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
            max_lint_cycles=2,
        )

        with pytest.raises(MaxLintCyclesExceeded) as exc_info:
            orchestrator.run(session, "Build project")

        assert "2" in str(exc_info.value)
        assert session.lint_cycles == 3  # Exceeded after 3rd lint cycle

    def test_run_max_turns_exceeded(self):
        """Test that run() raises MaxTurnsExceeded."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["Continue"] * 100)
        runner = MockRunner(
            responses=["Working..."] * 100,  # Never completes
            complete_after=100,
        )

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
            max_turns=5,
        )

        with pytest.raises(MaxTurnsExceeded) as exc_info:
            orchestrator.run(session, "Long task")

        assert "5" in str(exc_info.value)

    def test_run_preserves_output_path_and_score(self):
        """Test that run() preserves output_path and score from session."""
        orchestrator = Orchestrator()
        developer = MockDeveloper()
        runner = MockRunner(responses=["Done"], complete_after=1)

        session = orchestrator.create_session(
            domain="azure",
            developer=developer,
            runner=runner,
        )
        session.output_path = "/tmp/generated"
        session.score = 14

        result = orchestrator.run(session, "Generate")

        assert result["output_path"] == "/tmp/generated"
        assert result["score"] == 14

    def test_run_message_turn_tracking(self):
        """Test that messages track the turn number."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["OK"])
        runner = MockRunner(
            responses=["Question?", "Done!"],
            complete_after=2,
        )

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
        )

        result = orchestrator.run(session, "Start")

        messages = result["messages"]
        assert messages[0]["turn"] == 0  # Initial prompt before turn 1
        assert messages[1]["turn"] == 1  # Runner response turn 1
        assert messages[2]["turn"] == 1  # Developer response turn 1
        assert messages[3]["turn"] == 2  # Runner response turn 2


class TestOrchestratorExceptions:
    """Tests for orchestrator exceptions."""

    def test_orchestrator_error_is_exception(self):
        """Test that OrchestratorError is an Exception."""
        assert issubclass(OrchestratorError, Exception)

    def test_max_lint_cycles_exceeded_is_orchestrator_error(self):
        """Test that MaxLintCyclesExceeded is an OrchestratorError."""
        assert issubclass(MaxLintCyclesExceeded, OrchestratorError)

    def test_max_turns_exceeded_is_orchestrator_error(self):
        """Test that MaxTurnsExceeded is an OrchestratorError."""
        assert issubclass(MaxTurnsExceeded, OrchestratorError)

    def test_can_catch_orchestrator_errors(self):
        """Test that orchestrator errors can be caught by base class."""
        orchestrator = Orchestrator()
        developer = MockDeveloper(responses=["Fix"] * 10)
        runner = MockRunner(responses=["Lint error"] * 10, complete_after=100)

        session = orchestrator.create_session(
            domain="aws",
            developer=developer,
            runner=runner,
            max_lint_cycles=1,
        )

        with pytest.raises(OrchestratorError):
            orchestrator.run(session, "Build")


class TestLintDetection:
    """Tests for lint cycle detection."""

    def test_detects_lint_keyword(self):
        """Test detection of 'lint' keyword."""
        orchestrator = Orchestrator()
        assert orchestrator._detect_lint_cycle("Found lint errors")
        assert orchestrator._detect_lint_cycle("Running LINT check")

    def test_detects_linting_keyword(self):
        """Test detection of 'linting' keyword."""
        orchestrator = Orchestrator()
        assert orchestrator._detect_lint_cycle("Linting the code")

    def test_detects_lint_error_keyword(self):
        """Test detection of 'lint error' keyword."""
        orchestrator = Orchestrator()
        assert orchestrator._detect_lint_cycle("Fixed lint error in file.py")

    def test_detects_lint_warning_keyword(self):
        """Test detection of 'lint warning' keyword."""
        orchestrator = Orchestrator()
        assert orchestrator._detect_lint_cycle("Got a lint warning")

    def test_detects_linter_keyword(self):
        """Test detection of 'linter' keyword."""
        orchestrator = Orchestrator()
        assert orchestrator._detect_lint_cycle("The linter found issues")

    def test_no_detection_without_keywords(self):
        """Test no detection when keywords absent."""
        orchestrator = Orchestrator()
        assert not orchestrator._detect_lint_cycle("Code looks good")
        assert not orchestrator._detect_lint_cycle("All tests pass")
        assert not orchestrator._detect_lint_cycle("Building project...")
