import sys
import os
import time
import select
import atexit
import re
import matplotlib.pyplot as plt
from datetime import datetime, timedelta, timezone
from typing import Optional

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

try:
    from dateutil import parser as date_parser
    HAS_DATEUTIL = True
except ImportError:
    HAS_DATEUTIL = False

if os.name == 'posix':
    import termios

_MONITOR_PAUSED = False
_ORIG_TERM_SETTINGS = None

def set_input_paused(paused: bool):
    global _MONITOR_PAUSED
    _MONITOR_PAUSED = paused

def ask_input(prompt: str) -> str:
    try:
        val = input(prompt)
    except EOFError:
        sys.exit(1)
    if val.strip().lower() in ['q', 'quit', 'exit']:
        print("\n  > User requested exit. Bye!")
        sys.exit(0)
    return val

def ask_bool(prompt: str, default: bool = True) -> bool:
    default_indicator = "Y/n" if default else "y/N"
    while True:
        val = ask_input(f"{prompt} [{default_indicator}]: ").strip().lower()
        if not val:
            return default
        if val in ['y', 'yes']:
            return True
        if val in ['n', 'no']:
            return False
        print("  > Error: Please enter 'y' or 'n'.")

def get_timezone_from_user() -> timezone:
    while True:
        tz_input = ask_input("  > Please enter timezone (e.g., 'UTC', 'Europe/Berlin', '+0100') [default: UTC]: ").strip()
        if not tz_input:
            print("  > Defaulting to UTC.")
            return timezone.utc
        if ZoneInfo:
            try:
                return ZoneInfo(tz_input)
            except Exception:
                pass
        if re.match(r'^[+-]\d{4}$', tz_input):
            try:
                return datetime.strptime(tz_input, "%z").tzinfo
            except ValueError:
                pass
        if tz_input.upper() == 'UTC':
            return timezone.utc
        print(f"  > Error: Could not understand timezone '{tz_input}'.")
        if not ZoneInfo:
            print("  > (Note: ZoneInfo not available, try offsets like +0100)")

def _create_time_axis(start_time, sampling_rate, length, is_timedelta=False):
    if start_time and not is_timedelta:
        return [start_time + i * sampling_rate for i in range(length)]
    else:
        base = start_time if start_time else timedelta(0)
        return [(base + i * sampling_rate).total_seconds() for i in range(length)]

def save_match_plot(match, ref, target, filename: str, title: str):
    import math
    import numpy as np
    
    if ref.signal_frequency != target.signal_frequency:
        raise ValueError("Signal frequencies should be identical.")
    
    duration = min(ref.duration - match.offset, target.duration)
    match_len = math.floor(duration.total_seconds() * ref.signal_frequency)
    
    t = _create_time_axis(ref.begins_at + match.offset if ref.begins_at else match.offset, 
                          ref.signal_sampling_rate, match_len, is_timedelta=ref.begins_at is None)

    offset_sample = math.floor(match.offset.total_seconds() * ref.signal_frequency)
    ref_samples = np.ma.empty(match_len, dtype=np.float32)
    ref_samples[:] = np.ma.masked
    ref_begin = max(0, offset_sample)
    samples_to_copy = min(len(ref.signal) - ref_begin, match_len)
    if samples_to_copy > 0:
        ref_samples[0:samples_to_copy] = ref.signal[ref_begin:ref_begin + samples_to_copy]
    target_samples = target.signal[0:match_len].astype(np.float32)

    _plot_and_save(t, [
        (ref_samples + ref.network_frequency, "blue", "Reference ENF"),
        (target_samples + target.network_frequency, "red", "Target ENF")
    ], filename, title, date_fmt=bool(ref.begins_at))

def save_signal_plot(signal, filename: str, title: str):
    t = _create_time_axis(signal.begins_at, signal.signal_sampling_rate, len(signal.signal), is_timedelta=signal.begins_at is None)
    _plot_and_save(t, [
        (signal.signal + signal.network_frequency, "green", "Signal")
    ], filename, title, date_fmt=bool(signal.begins_at))

def _plot_and_save(t, signals, filename, title, date_fmt=False):
    plt.figure(figsize=(12, 6))
    for data, color, label in signals:
        plt.plot(t, data, color=color, label=label, linewidth=1)
    plt.title(title)
    plt.xlabel("Time")
    plt.ylabel("Frequency (Hz)")
    if len(signals) > 1: plt.legend()
    plt.grid(True, alpha=0.3)
    if date_fmt: plt.gcf().autofmt_xdate()
    print(f"  > Saving plot to {filename}...")
    plt.savefig(filename)
    plt.close()

def _restore_term_settings():
    if _ORIG_TERM_SETTINGS and sys.stdin.isatty():
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, _ORIG_TERM_SETTINGS)

def _set_cbreak_no_flush(fd):
    mode = termios.tcgetattr(fd)
    mode[3] = mode[3] & ~(termios.ECHO | termios.ICANON)
    mode[6][termios.VMIN] = 1
    mode[6][termios.VTIME] = 0
    termios.tcsetattr(fd, termios.TCSANOW, mode)

def monitor_quit_key():
    global _ORIG_TERM_SETTINGS
    if os.name != 'posix' or not sys.stdin.isatty():
        return
    fd = sys.stdin.fileno()
    try:
        if _ORIG_TERM_SETTINGS is None:
            _ORIG_TERM_SETTINGS = termios.tcgetattr(fd)
            atexit.register(_restore_term_settings)
        is_cbreak = False
        while True:
            if _MONITOR_PAUSED:
                if is_cbreak:
                    termios.tcsetattr(fd, termios.TCSADRAIN, _ORIG_TERM_SETTINGS)
                    is_cbreak = False
                time.sleep(0.1)
                continue
            if not is_cbreak:
                _set_cbreak_no_flush(fd)
                is_cbreak = True
            
            if select.select([sys.stdin], [], [], 0.1)[0]:
                if _MONITOR_PAUSED:
                    continue
                key = sys.stdin.read(1)
                if key.lower() == 'q':
                    _restore_term_settings()
                    print("\n\n  > 'q' pressed. Aborting...")
                    os._exit(0)
    except Exception:
        _restore_term_settings()