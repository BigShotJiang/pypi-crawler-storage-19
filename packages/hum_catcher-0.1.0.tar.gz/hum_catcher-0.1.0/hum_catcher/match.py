import enum
import math
import numpy as np
import time
from datetime import timedelta
from typing import List, Optional, Tuple, Callable
from tqdm import tqdm

from .types import Signal, Match
from . import ui

class MatchBackend(enum.Enum):
    NUMPY = "numpy"
    OPENCL = "opencl"

MATCH_KERNEL_SOURCE = r"""
#ifdef BACKEND_IS_OPENCL
    #define __device
#endif

#ifdef USE_FLOAT16_BUFFERS
    #ifdef BACKEND_IS_OPENCL
        #pragma OPENCL EXTENSION cl_khr_fp16 : enable
    #endif

    typedef half enf;
#else
    typedef float enf;
#endif

#define MAX_LOCAL_MEMORY_SIZE (24 * 1024)

__kernel void corr_coeffs(
    __global const int *offsets,
    int offsets_size,
    __global const enf *ref,
    __global const char *ref_mask,
    int ref_size,
    __global const enf *target,
    __global const char *target_mask,
    int target_size,
    __global float *coeffs,
    __global int *match_lens
);

#ifdef USE_LOCAL_MEMORY
    __device void _group_copy_to_local(
        __global const enf *src,
        __global const char *src_mask,
        __local enf *dst,
        __local char *dst_mask,
        int size
    );
#endif

__device void _corr_coeff(
    __global const enf *a,
    __global const char *mask_a,
    #ifdef USE_LOCAL_MEMORY
        __local const enf *b,
        __local const char *mask_b,
    #else
        __global const enf *b,
        __global const char *mask_b,
    #endif
    int size,
    __global float *coeff,
    __global int *match_len
);

__kernel void corr_coeffs(
    __global const int *offsets,
    int offsets_size,
    __global const enf *ref,
    __global const char *ref_mask,
    int ref_size,
    __global const enf *target,
    __global const char *target_mask,
    int target_size,
    __global float *coeffs,
    __global int *match_lens
)
{
    #ifdef USE_LOCAL_MEMORY
        // Caches the target signal in local memory.

        const int TARGET_ITEM_SIZE = sizeof (*target) + sizeof (*target_mask);
        const int LOCAL_CACHE_SIZE = MAX_LOCAL_MEMORY_SIZE / TARGET_ITEM_SIZE;

        __local enf target_local[LOCAL_CACHE_SIZE];
        __local char target_mask_local[LOCAL_CACHE_SIZE];

        _group_copy_to_local(
            target, target_mask, target_local, target_mask_local, min(target_size, LOCAL_CACHE_SIZE)
        );
    #endif

    // Computes the comparison offsets.

    int i = get_group_id(0) * get_local_size(0) + get_local_id(0);

    if (i >= offsets_size) {
        return;
    }

    int offset = offsets[i];

    int ref_offset = max(0, offset);
    int target_offset = max(0, -offset);

    int size = min(ref_size - ref_offset, target_size - target_offset);

    __global const enf *ref_begin = ref + ref_offset;
    __global const char *ref_mask_begin = ref_mask + ref_offset;

    #ifdef USE_LOCAL_MEMORY
        __local const enf *target_begin = target_local + target_offset;
        __local const char *target_mask_begin = target_mask_local + target_offset;
    #else
        __global const enf *target_begin = target + target_offset;
        __global const char *target_mask_begin = target_mask + target_offset;
    #endif

    // Computes the corr. coefficient.

    _corr_coeff(
        ref_begin, ref_mask_begin, target_begin, target_mask_begin, size,
        &coeffs[i], &match_lens[i]
    );
}

#ifdef USE_LOCAL_MEMORY
    __device void _group_copy_to_local(
        __global const enf *src,
        __global const char *src_mask,
        __local enf *dst,
        __local char *dst_mask,
        int size
    )
    {
        int n_items_per_thread = (size + get_local_size(0) - 1) / get_local_size(0);

        int current_begin = get_local_id(0) * n_items_per_thread;
        int current_end = min(size, current_begin + n_items_per_thread);

        for (int i = current_begin; i < current_end; ++i) {
            dst[i] = src[i];
            dst_mask[i] = src_mask[i];
        }

        barrier(CLK_LOCAL_MEM_FENCE);
    }
#endif

__device void _corr_coeff(
    __global const enf *a,
    __global const char *mask_a,
    #ifdef USE_LOCAL_MEMORY
        __local const enf *b,
        __local const char *mask_b,
    #else
        __global const enf *b,
        __global const char *mask_b,
    #endif
    int size,
    __global float *coeff,
    __global int *match_len
)
{
    int match_len_local = 0;
    
    // Accumulators for moments
    float sum_a = 0.0f;
    float sum_b = 0.0f;
    float sum_a2 = 0.0f;
    float sum_b2 = 0.0f;
    float sum_ab = 0.0f;

    // SINGLE PASS OPTIMIZATION
    for (size_t i = 0; i < size; ++i) {
        char mask = mask_a[i] & mask_b[i];
        if (mask) {
            float val_a = (float)a[i];
            float val_b = (float)b[i];
            
            sum_a += val_a;
            sum_b += val_b;
            sum_a2 += val_a * val_a;
            sum_b2 += val_b * val_b;
            sum_ab += val_a * val_b;
            match_len_local++;
        }
    }

    if (match_len_local == 0 || (float)match_len_local / size < 0.05f) {
        *coeff = NAN;
        *match_len = 0;
        return;
    }

    float n = (float)match_len_local;
    
    // Pearson Correlation Formula using Raw Moments:
    // (N * Sum(AB) - Sum(A)*Sum(B)) / sqrt([N*Sum(A^2) - (Sum(A))^2] * [N*Sum(B^2) - (Sum(B))^2])
    
    float numerator = n * sum_ab - sum_a * sum_b;
    float var_a = n * sum_a2 - sum_a * sum_a;
    float var_b = n * sum_b2 - sum_b * sum_b;
    
    // Check for constant signal (variance ~ 0)
    if (var_a < 1e-9f || var_b < 1e-9f) {
         *coeff = 0.0f;
    } else {
         *coeff = numerator / sqrt(var_a * var_b);
    }
    *match_len = match_len_local;
}
"""

MIN_MATCH_DURATION = timedelta(minutes=1)
MIN_MATCH_CORR_COEFF = 0.65
APPROX_TARGET_FREQUENCY = 0.1
APPROX_MIN_MATCH_DURATION = MIN_MATCH_DURATION * 0.75
APPROX_MIN_MATCH_CORR_COEFF = MIN_MATCH_CORR_COEFF - 0.1
APPROX_SEARCH_WINDOW = timedelta(seconds=1.0 / APPROX_TARGET_FREQUENCY * 2.0)
MIN_MATCH_LOCAL_MAXIMUM = timedelta(minutes=10)
MAX_BUFFER_SIZE = 64 * 1024 * 1024 

_custom_opencl_ctx = None
_custom_opencl_queue = None
_custom_opencl_program = None
_custom_opencl_buffer_dtype = None
_custom_opencl_kernel = None

def match_signals(
    ref: Signal,
    target: Signal,
    max_matches: Optional[int] = None,
    step: timedelta = timedelta(seconds=1),
    backend: MatchBackend = MatchBackend.NUMPY,
    exhaustive: bool = False
) -> List[Match]:
    if ref.signal_frequency != target.signal_frequency:
        raise ValueError("Signal frequencies should be identical.")
    if ref.network_frequency != target.network_frequency:
        raise ValueError("Network frequencies should be identical.")

    frequency = ref.signal_frequency

    backend_instance = {
        MatchBackend.NUMPY: _compute_corr_coeffs_numpy,
        MatchBackend.OPENCL: _opencl_compute_corr_coeffs_custom,
    }[backend]

    if exhaustive:
        print("  > Mode: Exhaustive Search (skipping approximation step)")
        min_match_len = math.ceil(MIN_MATCH_DURATION.total_seconds() * frequency)
        min_offset = - len(target.signal) + min_match_len
        max_offset = len(ref.signal) - min_match_len
        step_offset = math.ceil(step.total_seconds() * frequency)

        offsets = np.arange(min_offset, max_offset, step_offset)

        offsets, corr_coeffs, match_lens = _compute_filtered_corr_coeffs_with_progress(
            backend_instance, frequency, offsets, ref.signal, target.signal,
            min_match_len, MIN_MATCH_CORR_COEFF,
        )
        return _build_matches(
            frequency, ref.signal, target.signal, offsets, corr_coeffs, match_lens, max_matches
        )

    approx_q = math.floor(frequency / APPROX_TARGET_FREQUENCY)
    approx_frequency = frequency / approx_q
    
    ref_approx = _decimated_masked_array(ref.signal, approx_q)
    target_approx = _decimated_masked_array(target.signal, approx_q)
    min_approx_match_len = math.ceil(APPROX_MIN_MATCH_DURATION.total_seconds() * approx_frequency)

    offset_begin = - len(target_approx) + min_approx_match_len
    offset_end = len(ref_approx) - min_approx_match_len + 1
    approx_step_offset = math.ceil(step.total_seconds() * approx_frequency)
    approx_offsets = np.arange(offset_begin, offset_end, approx_step_offset, dtype=np.int32)
    
    approx_offsets, _approx_corr_coeffs, _approx_match_lens = _compute_filtered_corr_coeffs_with_progress(
        backend_instance, approx_frequency, approx_offsets, ref_approx, target_approx,
        min_approx_match_len, APPROX_MIN_MATCH_CORR_COEFF,
    )

    if len(approx_offsets) < 1:
        return []

    min_match_len = math.ceil(MIN_MATCH_DURATION.total_seconds() * frequency)
    search_window_size = math.ceil(APPROX_SEARCH_WINDOW.total_seconds() * frequency)
    min_offset = - len(target.signal) + min_match_len
    max_offset = len(ref.signal) - min_match_len

    offset_windows = []
    for approx_offset in approx_offsets:
        offset = approx_q * approx_offset
        window_begin = max(min_offset, offset - search_window_size)
        window_end = min(max_offset, offset + search_window_size + 1)
        if len(offset_windows) > 0 and window_begin <= offset_windows[-1][1]:
            offset_windows[-1][1] = window_end
        else:
            offset_windows.append([window_begin, window_end])

    step_offset = math.ceil(step.total_seconds() * frequency)
    offsets = np.concatenate([
        np.arange(window_begin, window_end, step_offset)
        for window_begin, window_end in offset_windows
    ])

    offsets, corr_coeffs, match_lens = _compute_filtered_corr_coeffs_with_progress(
        backend_instance, frequency, offsets, ref.signal, target.signal,
        min_match_len, MIN_MATCH_CORR_COEFF,
    )

    return _build_matches(
        frequency, ref.signal, target.signal, offsets, corr_coeffs, match_lens, max_matches
    )

def _decimated_masked_array(array: np.ma.masked_array, q: int) -> np.ma.masked_array:
    return array[::q]

def _compute_corr_coeffs_numpy(
    offsets: np.ndarray, a: np.ma.masked_array, b: np.ma.masked_array
) -> Tuple[np.ndarray, np.ndarray]:
    corr_coeffs = np.empty(len(offsets), dtype=np.float32)
    match_lens = np.empty(len(offsets), dtype=np.int32)
    for i, offset in enumerate(offsets):
        corr_coeffs[i], match_lens[i] = _corr_coeff(
            a[max(0, offset):offset + len(b)], b[max(0, -offset):len(a) - offset]
        )
    return corr_coeffs, match_lens

def _corr_coeff(a: np.ma.masked_array, b: np.ma.masked_array) -> Tuple[float, int]:
    common_mask = a.mask | b.mask
    valid_count = len(a) - np.sum(common_mask)
    
    if valid_count < 2:
        return np.nan, valid_count

    valid_mask = ~common_mask
    d_a = a.data[valid_mask]
    d_b = b.data[valid_mask]

    try:
        corr = np.corrcoef(d_a, d_b)[0, 1]
        return corr, valid_count
    except Exception:
        return np.nan, valid_count

def _compute_rmses(
    offsets: np.ndarray, a: np.ma.masked_array, b: np.ma.masked_array
) -> Tuple[np.ndarray, np.ndarray]:
    rmses = np.empty(len(offsets), dtype=np.float32)
    for i, offset in enumerate(offsets):
        rmses[i] = _rmse(a[max(0, offset):offset + len(b)], b[max(0, -offset):len(a) - offset])
    return rmses

def _rmse(a: np.ma.masked_array, b: np.ma.masked_array) -> float:
    assert len(a) == len(b)
    diff = (a - b).astype(np.float64)
    return np.sqrt(np.mean(diff**2))

def _filter_coeffs(
    frequency: float, offsets: np.ndarray, corr_coeffs: np.ndarray, match_lens: np.ndarray,
    min_match_len: int, min_match_corr_coeff: float,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    valids = (corr_coeffs >= min_match_corr_coeff) & (match_lens >= min_match_len)
    offsets = offsets[valids].copy()
    corr_coeffs = corr_coeffs[valids].copy()
    match_lens = match_lens[valids].copy()
    return offsets, corr_coeffs, match_lens

def _build_matches(
    frequency: float,
    a: np.ma.masked_array, b: np.ma.masked_array,
    offsets: np.ndarray, corr_coeffs: np.ndarray, match_lens: np.ndarray,
    max_matches: Optional[int],
) -> List[Match]:
    search_window_size = math.ceil(MIN_MATCH_LOCAL_MAXIMUM.total_seconds() * frequency)
    match_mask = np.full(len(offsets), True)
    i = 0
    while i < len(offsets):
        offset = offsets[i]
        corr_coeff = corr_coeffs[i]
        max_search_offset = offset + search_window_size
        j = i + 1
        while j < len(offsets) and offsets[j] < max_search_offset:
            if corr_coeffs[j] < corr_coeff:
                match_mask[j] = False
                j += 1
            else:
                match_mask[i] = False
                break
        i = j
    offsets = offsets[match_mask]
    corr_coeffs = corr_coeffs[match_mask]
    match_lens = match_lens[match_mask]
    
    scores = np.clip(corr_coeffs, 0, 1)
    
    matches_data = sorted(
        zip(offsets, match_lens, corr_coeffs, scores),
        key=lambda m: m[3], 
        reverse=True,
    )
    
    if max_matches is not None:
        matches_data = matches_data[:max_matches]
    
    final_matches = []
    
    top_offsets = np.array([m[0] for m in matches_data], dtype=np.int64)
    if len(top_offsets) > 0:
        top_rmses = _compute_rmses(top_offsets, a, b)
    else:
        top_rmses = []

    for i, (offset, match_len, corr_coeff, score) in enumerate(matches_data):
        if score > 0:
            final_matches.append(Match(
                offset=timedelta(seconds=int(offset / frequency)),
                duration=timedelta(seconds=int(match_len / frequency)),
                corr_coeff=corr_coeff,
                rmse=top_rmses[i] if len(top_rmses) > 0 else 0.0, 
                score=score,
            ))
    
    return final_matches

def _simple_match_scores(frequency, match_lens, corr_coeffs, rmses):
    return np.clip(corr_coeffs, 0, 1)

def _compute_filtered_corr_coeffs_with_progress(
    backend_instance, signal_frequency,
    offsets, a, b,
    min_match_len, min_match_corr_coeff,
):
    offsets_chunks = []
    corr_coeffs_chunks = []
    match_lens_chunks = []

    max_chunk_size = MAX_BUFFER_SIZE // np.int32(0).nbytes
    chunk_size = min(max_chunk_size, 1000)
    
    desc = "Matching (Fine)" if signal_frequency >= 0.5 else "Matching (Approx)"
    total_offsets = len(offsets)
    
    if total_offsets > 0:
        with tqdm(total=total_offsets, desc=desc, unit="offsets") as pbar:
            for chunk_begin in range(0, total_offsets, chunk_size):
                chunk_end = min(total_offsets, chunk_begin + chunk_size)
                chunk_offsets = offsets[chunk_begin:chunk_end]

                min_off = chunk_offsets.min()
                max_off = chunk_offsets.max()
                
                start_idx = max(0, min_off)
                end_idx = min(len(a), max_off + len(b))
                
                if start_idx >= end_idx:
                    chunk_coeffs = np.full(len(chunk_offsets), np.nan, dtype=np.float32)
                    chunk_lens = np.zeros(len(chunk_offsets), dtype=np.int32)
                else:
                    a_slice = a[start_idx:end_idx]
                    
                    adjusted_offsets = chunk_offsets - start_idx
                    
                    chunk_coeffs, chunk_lens = backend_instance(adjusted_offsets, a_slice, b)

                chunk_offsets, chunk_coeffs, chunk_lens = _filter_coeffs(
                    signal_frequency, chunk_offsets, chunk_coeffs, chunk_lens,
                    min_match_len, min_match_corr_coeff,
                )

                offsets_chunks.append(chunk_offsets)
                corr_coeffs_chunks.append(chunk_coeffs)
                match_lens_chunks.append(chunk_lens)
                pbar.update(chunk_end - chunk_begin)
    
    if len(offsets_chunks) > 0:
        offsets = np.concatenate(offsets_chunks)
        corr_coeffs = np.concatenate(corr_coeffs_chunks)
        match_lens = np.concatenate(match_lens_chunks)
    else:
        offsets = np.empty((0,))
        corr_coeffs = np.empty((0,))
        match_lens = np.empty((0,))

    return offsets, corr_coeffs, match_lens

def _opencl_initialize_custom():
    global _custom_opencl_ctx, _custom_opencl_queue, _custom_opencl_program, _custom_opencl_buffer_dtype, _custom_opencl_kernel
    
    if _custom_opencl_ctx is None:
        import pyopencl as cl
        ui.set_input_paused(True)
        time.sleep(0.2) 
        try:
            _custom_opencl_ctx = cl.create_some_context()
            _custom_opencl_queue = cl.CommandQueue(_custom_opencl_ctx)
            compiler_flags = ["-DBACKEND_IS_OPENCL"]
            supports_float16 = all(
                "cl_khr_fp16" in d.extensions.split(" ")
                for d in _custom_opencl_ctx.devices
            )
            if supports_float16:
                _custom_opencl_buffer_dtype = np.float16
                compiler_flags.append("-DUSE_FLOAT16_BUFFERS")
            else:
                _custom_opencl_buffer_dtype = np.float32

            _custom_opencl_program = cl.Program(
                _custom_opencl_ctx, MATCH_KERNEL_SOURCE
            ).build(options=compiler_flags)
            
            try:
                _custom_opencl_kernel = cl.Kernel(_custom_opencl_program, "corr_coeffs")
            except TypeError:
                if hasattr(_custom_opencl_program, "_prg"):
                     _custom_opencl_kernel = cl.Kernel(_custom_opencl_program._prg, "corr_coeffs")
                else:
                    raise
        finally:
            ui.set_input_paused(False)

def _opencl_compute_corr_coeffs_custom(
    offsets: np.ndarray, a: np.ma.masked_array, b: np.ma.masked_array
):
    import pyopencl as cl
    _opencl_initialize_custom()

    offsets_shifted = offsets.astype(np.int32) 
    
    a_float = a.astype(_custom_opencl_buffer_dtype).data
    b_float = b.astype(_custom_opencl_buffer_dtype).data
    a_float[np.isnan(a_float)] = 0.0
    b_float[np.isnan(b_float)] = 0.0

    mask_a_int8 = np.logical_not(a.mask).astype(np.int8)
    mask_b_int8 = np.logical_not(b.mask).astype(np.int8)

    corr_coeffs = np.empty(len(offsets), dtype=np.float32)
    match_lens = np.empty(len(offsets), dtype=np.int32)

    mf = cl.mem_flags
    offsets_gpu = cl.Buffer(_custom_opencl_ctx, mf.READ_ONLY | mf.USE_HOST_PTR, hostbuf=offsets_shifted)
    a_gpu = cl.Buffer(_custom_opencl_ctx, mf.READ_ONLY | mf.USE_HOST_PTR, hostbuf=a_float)
    b_gpu = cl.Buffer(_custom_opencl_ctx, mf.READ_ONLY | mf.USE_HOST_PTR, hostbuf=b_float)
    mask_a_gpu = cl.Buffer(_custom_opencl_ctx, mf.READ_ONLY | mf.USE_HOST_PTR, hostbuf=mask_a_int8)
    mask_b_gpu = cl.Buffer(_custom_opencl_ctx, mf.READ_ONLY | mf.USE_HOST_PTR, hostbuf=mask_b_int8)

    corr_coeffs_gpu = cl.Buffer(_custom_opencl_ctx, mf.WRITE_ONLY, corr_coeffs.nbytes)
    match_lens_gpu = cl.Buffer(_custom_opencl_ctx, mf.WRITE_ONLY, match_lens.nbytes)

    THREADS_PER_BLOCK = 256
    n_blocks = math.ceil(len(offsets) / THREADS_PER_BLOCK)

    kernel_args = [
        offsets_gpu, np.int32(len(offsets_shifted)),
        a_gpu, mask_a_gpu, np.int32(len(a_float)),
        b_gpu, mask_b_gpu, np.int32(len(b_float)),
        corr_coeffs_gpu, match_lens_gpu,
    ]
    for i, arg in enumerate(kernel_args):
        _custom_opencl_kernel.set_arg(i, arg)
    
    cl.enqueue_nd_range_kernel(
        _custom_opencl_queue,
        _custom_opencl_kernel,
        (THREADS_PER_BLOCK * n_blocks,),
        (THREADS_PER_BLOCK,)
    )

    cl.enqueue_copy(_custom_opencl_queue, corr_coeffs, corr_coeffs_gpu)
    cl.enqueue_copy(_custom_opencl_queue, match_lens, match_lens_gpu)

    return corr_coeffs, match_lens