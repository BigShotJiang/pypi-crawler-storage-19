from .types import Signal, Match, AnalysisResult
from .analysis import compute_enf, read_audio
from .match import match_signals, MatchBackend

__version__ = "1.0.0"

__all__ = [
    "Signal",
    "Match",
    "AnalysisResult",
    "compute_enf",
    "read_audio",
    "match_signals",
    "MatchBackend",
]