import argparse
import sys
import threading
from datetime import timedelta, timezone
from typing import Optional

from . import analysis, match, csv_utils, ui
from .types import Signal
from .match import MatchBackend

def main():
    parser = argparse.ArgumentParser(description="Match media ENF against CSV grid data.")
    parser.add_argument("media_file", help="Path to the target media file (audio or video)")
    parser.add_argument("csv_file", help="Path to the reference CSV grid frequency file")
    parser.add_argument("--network-frequency", "-nf", "-f", type=float, default=50.0, help="Network frequency (default: 50.0)")
    parser.add_argument("--backend", "-b", choices=["numpy", "opencl"], default="numpy", help="Matching backend (default: numpy)")
    parser.add_argument("--max-matches", "-m", type=int, default=10, help="Number of top matches to display")
    parser.add_argument("--plot-match", "-pm", action="store_true", help="Plot the best match result")
    parser.add_argument("--plot-target", "-pt", action="store_true", help="Plot the extracted target ENF signal")
    parser.add_argument("--plot-reference", "-pr", action="store_true", help="Plot the reference ENF signal from CSV")
    parser.add_argument("--exhaustive", "-e", action="store_true", help="Perform exhaustive search (slower but more accurate, skips approximation)")
    parser.add_argument("--no-partial", "-np", action="store_true", help="Filter out matches that do not fully overlap with the grid data")
    
    args = parser.parse_args()

    print(f"Loading and analyzing media: {args.media_file}...")
    try:
        audio_data, audio_rate = analysis.read_audio(args.media_file)
    except Exception as e:
        print(f"Error reading media: {e}")
        sys.exit(1)

    enf_result = analysis.compute_enf(audio_data, audio_rate, network_frequency=args.network_frequency)
    
    if enf_result is None:
        print("Error: No ENF signal detected in the audio file.")
        sys.exit(1)
        
    target_signal = enf_result.enf
    print(f"  > Detected ENF signal (Quality: {target_signal.quality():.2%}, Duration: {target_signal.duration})")

    if args.plot_target:
        ui.save_signal_plot(target_signal, "plot_target.png", "Target ENF Signal")

    csv_config = csv_utils.configure_csv_parsing(args.csv_file)
    
    print(f"\nLoading grid data from CSV: {args.csv_file}...")
    print("  (Press 'q' to abort processing at any time)")
    
    monitor_thread = threading.Thread(target=ui.monitor_quit_key, daemon=True)
    monitor_thread.start()

    sparse_grid_data = csv_utils.parse_csv_grid_data(args.csv_file, csv_config, args.network_frequency)
    
    if len(sparse_grid_data[0]) == 0:
        print("Error: No valid data found in CSV.")
        sys.exit(1)

    ref_signal_values, ref_begins_at = csv_utils.resample_with_progress(
        sparse_grid_data, 
        target_signal.signal_frequency
    )
    
    ref_signal = Signal(
        network_frequency=args.network_frequency,
        signal_frequency=target_signal.signal_frequency,
        signal=ref_signal_values,
        begins_at=ref_begins_at
    )
    
    display_tz = csv_config.get('timezone', timezone.utc)
    ref_start_display = ref_signal.begins_at.astimezone(display_tz)
    ref_end_display = ref_signal.ends_at.astimezone(display_tz)
    
    print(f"  > Grid signal loaded (Start: {ref_start_display}, End: {ref_end_display}, Duration: {ref_signal.duration})")

    if args.plot_reference:
        ui.save_signal_plot(ref_signal, "plot_reference.png", "Reference ENF Signal")

    print("Matching signals...")
    backend_enum = MatchBackend(args.backend)
    
    matches = match.match_signals(
        ref_signal, 
        target_signal, 
        max_matches=args.max_matches, 
        backend=backend_enum,
        exhaustive=args.exhaustive
    )

    if args.no_partial:
        original_count = len(matches)
        matches = [
            m for m in matches 
            if m.offset >= timedelta(0) and (m.offset + target_signal.duration) <= ref_signal.duration
        ]
        filtered_count = original_count - len(matches)
        if filtered_count > 0:
            print(f"  > Note: {filtered_count} matches were found but filtered out by --no-partial.")

    if not matches:
        print("No matches found.")
    else:
        tz_name = str(display_tz)
        print(f"\nFound {len(matches)} matches:")
        print(f"{f'START TIME ({tz_name})':<35} {f'END TIME ({tz_name})':<35} {'START (UNIX)':<15} {'END (UNIX)':<15} {'CORR':<10} {'RMSE':<10}")
        print("-" * 120)
        for m in matches:
            match_start_utc = ref_signal.begins_at + m.offset
            match_end_utc = match_start_utc + target_signal.duration
            match_start_display = match_start_utc.astimezone(display_tz)
            match_end_display = match_end_utc.astimezone(display_tz)
            start_unix = match_start_utc.timestamp()
            end_unix = match_end_utc.timestamp()
            
            print(f"{str(match_start_display):<35} {str(match_end_display):<35} {start_unix:<15.3f} {end_unix:<15.3f} {m.corr_coeff:<10.4f} {m.rmse:<10.4f}")

        if args.plot_match:
            print("\nPlotting matches...")
            for i, m in enumerate(matches):
                match_time_utc = ref_signal.begins_at + m.offset
                match_time_display = match_time_utc.astimezone(display_tz)
                timestamp_str = match_time_display.strftime("%Y-%m-%d_%H-%M-%S")
                filename = f"match_{i+1}_{timestamp_str}.png"
                title = f"Match {i+1}: {match_time_display} (Corr: {m.corr_coeff:.4f})"
                ui.save_match_plot(m, ref_signal, target_signal, filename, title)
