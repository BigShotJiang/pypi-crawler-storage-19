# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowInstanceResp:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'engine': 'str',
        'engine_version': 'str',
        'description': 'str',
        'specification': 'str',
        'storage_space': 'int',
        'partition_num': 'str',
        'used_storage_space': 'int',
        'dns_enable': 'bool',
        'connect_address': 'str',
        'port': 'int',
        'status': 'str',
        'instance_id': 'str',
        'resource_spec_code': 'str',
        'charging_mode': 'int',
        'vpc_id': 'str',
        'vpc_name': 'str',
        'created_at': 'str',
        'subnet_name': 'str',
        'subnet_cidr': 'str',
        'user_id': 'str',
        'user_name': 'str',
        'access_user': 'str',
        'order_id': 'str',
        'maintain_begin': 'str',
        'maintain_end': 'str',
        'enable_publicip': 'bool',
        'management_connect_address': 'str',
        'ssl_enable': 'bool',
        'broker_ssl_enable': 'bool',
        'kafka_security_protocol': 'str',
        'sasl_enabled_mechanisms': 'list[str]',
        'ssl_two_way_enable': 'bool',
        'cert_replaced': 'bool',
        'public_management_connect_address': 'str',
        'enterprise_project_id': 'str',
        'is_logical_volume': 'bool',
        'extend_times': 'int',
        'enable_auto_topic': 'bool',
        'type': 'str',
        'product_id': 'str',
        'security_group_id': 'str',
        'security_group_name': 'str',
        'subnet_id': 'str',
        'available_zones': 'list[str]',
        'available_zone_names': 'list[str]',
        'total_storage_space': 'int',
        'public_connect_address': 'str',
        'public_connect_domain_name': 'str',
        'storage_resource_id': 'str',
        'storage_spec_code': 'str',
        'service_type': 'str',
        'storage_type': 'str',
        'retention_policy': 'str',
        'kafka_public_status': 'str',
        'public_bandwidth': 'int',
        'enable_log_collection': 'bool',
        'new_auth_cert': 'bool',
        'cross_vpc_info': 'str',
        'ipv6_enable': 'bool',
        'ipv6_connect_addresses': 'list[str]',
        'connector_enable': 'bool',
        'connector_node_num': 'int',
        'connector_id': 'str',
        'rest_enable': 'bool',
        'rest_connect_address': 'str',
        'public_boundwidth': 'int',
        'message_query_inst_enable': 'bool',
        'vpc_client_plain': 'bool',
        'support_features': 'str',
        'trace_enable': 'bool',
        'agent_enable': 'bool',
        'pod_connect_address': 'str',
        'disk_encrypted': 'bool',
        'disk_encrypted_key': 'str',
        'kafka_private_connect_address': 'str',
        'kafka_private_connect_domain_name': 'str',
        'ces_version': 'str',
        'public_access_enabled': 'str',
        'node_num': 'int',
        'port_protocols': 'PortProtocolsEntity',
        'enable_acl': 'bool',
        'new_spec_billing_enable': 'bool',
        'broker_num': 'int',
        'tags': 'list[TagEntity]',
        'dr_enable': 'bool'
    }

    attribute_map = {
        'name': 'name',
        'engine': 'engine',
        'engine_version': 'engine_version',
        'description': 'description',
        'specification': 'specification',
        'storage_space': 'storage_space',
        'partition_num': 'partition_num',
        'used_storage_space': 'used_storage_space',
        'dns_enable': 'dns_enable',
        'connect_address': 'connect_address',
        'port': 'port',
        'status': 'status',
        'instance_id': 'instance_id',
        'resource_spec_code': 'resource_spec_code',
        'charging_mode': 'charging_mode',
        'vpc_id': 'vpc_id',
        'vpc_name': 'vpc_name',
        'created_at': 'created_at',
        'subnet_name': 'subnet_name',
        'subnet_cidr': 'subnet_cidr',
        'user_id': 'user_id',
        'user_name': 'user_name',
        'access_user': 'access_user',
        'order_id': 'order_id',
        'maintain_begin': 'maintain_begin',
        'maintain_end': 'maintain_end',
        'enable_publicip': 'enable_publicip',
        'management_connect_address': 'management_connect_address',
        'ssl_enable': 'ssl_enable',
        'broker_ssl_enable': 'broker_ssl_enable',
        'kafka_security_protocol': 'kafka_security_protocol',
        'sasl_enabled_mechanisms': 'sasl_enabled_mechanisms',
        'ssl_two_way_enable': 'ssl_two_way_enable',
        'cert_replaced': 'cert_replaced',
        'public_management_connect_address': 'public_management_connect_address',
        'enterprise_project_id': 'enterprise_project_id',
        'is_logical_volume': 'is_logical_volume',
        'extend_times': 'extend_times',
        'enable_auto_topic': 'enable_auto_topic',
        'type': 'type',
        'product_id': 'product_id',
        'security_group_id': 'security_group_id',
        'security_group_name': 'security_group_name',
        'subnet_id': 'subnet_id',
        'available_zones': 'available_zones',
        'available_zone_names': 'available_zone_names',
        'total_storage_space': 'total_storage_space',
        'public_connect_address': 'public_connect_address',
        'public_connect_domain_name': 'public_connect_domain_name',
        'storage_resource_id': 'storage_resource_id',
        'storage_spec_code': 'storage_spec_code',
        'service_type': 'service_type',
        'storage_type': 'storage_type',
        'retention_policy': 'retention_policy',
        'kafka_public_status': 'kafka_public_status',
        'public_bandwidth': 'public_bandwidth',
        'enable_log_collection': 'enable_log_collection',
        'new_auth_cert': 'new_auth_cert',
        'cross_vpc_info': 'cross_vpc_info',
        'ipv6_enable': 'ipv6_enable',
        'ipv6_connect_addresses': 'ipv6_connect_addresses',
        'connector_enable': 'connector_enable',
        'connector_node_num': 'connector_node_num',
        'connector_id': 'connector_id',
        'rest_enable': 'rest_enable',
        'rest_connect_address': 'rest_connect_address',
        'public_boundwidth': 'public_boundwidth',
        'message_query_inst_enable': 'message_query_inst_enable',
        'vpc_client_plain': 'vpc_client_plain',
        'support_features': 'support_features',
        'trace_enable': 'trace_enable',
        'agent_enable': 'agent_enable',
        'pod_connect_address': 'pod_connect_address',
        'disk_encrypted': 'disk_encrypted',
        'disk_encrypted_key': 'disk_encrypted_key',
        'kafka_private_connect_address': 'kafka_private_connect_address',
        'kafka_private_connect_domain_name': 'kafka_private_connect_domain_name',
        'ces_version': 'ces_version',
        'public_access_enabled': 'public_access_enabled',
        'node_num': 'node_num',
        'port_protocols': 'port_protocols',
        'enable_acl': 'enable_acl',
        'new_spec_billing_enable': 'new_spec_billing_enable',
        'broker_num': 'broker_num',
        'tags': 'tags',
        'dr_enable': 'dr_enable'
    }

    def __init__(self, name=None, engine=None, engine_version=None, description=None, specification=None, storage_space=None, partition_num=None, used_storage_space=None, dns_enable=None, connect_address=None, port=None, status=None, instance_id=None, resource_spec_code=None, charging_mode=None, vpc_id=None, vpc_name=None, created_at=None, subnet_name=None, subnet_cidr=None, user_id=None, user_name=None, access_user=None, order_id=None, maintain_begin=None, maintain_end=None, enable_publicip=None, management_connect_address=None, ssl_enable=None, broker_ssl_enable=None, kafka_security_protocol=None, sasl_enabled_mechanisms=None, ssl_two_way_enable=None, cert_replaced=None, public_management_connect_address=None, enterprise_project_id=None, is_logical_volume=None, extend_times=None, enable_auto_topic=None, type=None, product_id=None, security_group_id=None, security_group_name=None, subnet_id=None, available_zones=None, available_zone_names=None, total_storage_space=None, public_connect_address=None, public_connect_domain_name=None, storage_resource_id=None, storage_spec_code=None, service_type=None, storage_type=None, retention_policy=None, kafka_public_status=None, public_bandwidth=None, enable_log_collection=None, new_auth_cert=None, cross_vpc_info=None, ipv6_enable=None, ipv6_connect_addresses=None, connector_enable=None, connector_node_num=None, connector_id=None, rest_enable=None, rest_connect_address=None, public_boundwidth=None, message_query_inst_enable=None, vpc_client_plain=None, support_features=None, trace_enable=None, agent_enable=None, pod_connect_address=None, disk_encrypted=None, disk_encrypted_key=None, kafka_private_connect_address=None, kafka_private_connect_domain_name=None, ces_version=None, public_access_enabled=None, node_num=None, port_protocols=None, enable_acl=None, new_spec_billing_enable=None, broker_num=None, tags=None, dr_enable=None):
        r"""ShowInstanceResp

        The model defined in huaweicloud sdk

        :param name: **参数解释**： 实例名称。 **取值范围**： 不涉及。
        :type name: str
        :param engine: **参数解释**： 引擎。 **取值范围**： kafka
        :type engine: str
        :param engine_version: **参数解释**： Kafka的版本。 **取值范围**： [- 1.1.0](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,sbc,cmcc,ax) [- 2.3.0](tag:g42,tm,hk_g42,ctc,hk_tm,dt,sbc,cmcc) - 2.7 [- 3.x](tag:hws,hws_hk,dt,sbc,hcs,fcs,ctc,tm,hk_tm,hws_eu,ax)
        :type engine_version: str
        :param description: **参数解释**： 实例描述。 **取值范围**： 不涉及。
        :type description: str
        :param specification: **参数解释**： 实例规格。 **取值范围**： 不涉及。
        :type specification: str
        :param storage_space: **参数解释**： 消息存储空间，单位：GB。 **取值范围**： [- Kafka实例规格为c6.2u4g.cluster时，存储空间取值范围300GB ~ 300000GB。 - Kafka实例规格为c6.4u8g.cluster时，存储空间取值范围300GB ~ 600000GB。 - Kafka实例规格为c6.8u16g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.12u24g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.16u32g.cluster时，存储空间取值范围300GB ~ 1500000GB。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax) [- Kafka实例规格为kafka.2u4g.cluster.small时，存储空间取值范围300GB~300000GB。](tag:hws,hws_hk,hws_eu,dt,ax) [- Kafka实例规格为kafka.2u8g.cluster时，存储空间取值范围300GB~300000GB。](tag:fcs) [- Kafka实例规格为kafka.4u16g.cluster时，存储空间取值范围300GB~600000GB。 - Kafka实例规格为kafka.8u32g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.16u64g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.32u128g.cluster时，存储空间取值范围300GB~1500000GB。](tag:hcs,fcs)
        :type storage_space: int
        :param partition_num: **参数解释**： Kafka实例的分区数量。 **取值范围**： 不涉及。
        :type partition_num: str
        :param used_storage_space: **参数解释**： 已使用的消息存储空间，单位：GB。 **取值范围**： 不涉及。
        :type used_storage_space: int
        :param dns_enable: **参数解释**： 实例是否开启域名访问功能。 **取值范围**： - true：开启 - false：未开启
        :type dns_enable: bool
        :param connect_address: **参数解释**： 实例连接IP地址。 **取值范围**： 不涉及。
        :type connect_address: str
        :param port: **参数解释**： 实例连接端口。 **取值范围**： 不涉及。
        :type port: int
        :param status: **参数解释**： 实例的状态。详细状态说明请参考[实例状态说明](kafka-api-180514012.xml)。 **取值范围**： 不涉及。
        :type status: str
        :param instance_id: **参数解释**： 实例ID。 **取值范围**： 不涉及。
        :type instance_id: str
        :param resource_spec_code: **参数解释**： 资源规格标识。 **取值范围**： [- dms.instance.kafka.cluster.c3.mini：Kafka实例的基准带宽为100MByte/秒。 - dms.instance.kafka.cluster.c3.small.2：Kafka实例的基准带宽为300MByte/秒。 - dms.instance.kafka.cluster.c3.middle.2：Kafka实例的基准带宽为600MByte/秒。 - dms.instance.kafka.cluster.c3.high.2：Kafka实例的基准带宽为1200MByte/秒。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax)
        :type resource_spec_code: str
        :param charging_mode: **参数解释**： 付费模式。 **取值范围**： [- 1表示按需计费。 - 0表示包年/包月计费。](tag:hws,hws_hk,ctc,cmcc,ax)[付费模式，暂未使用。](tag:hws_ocb,ocb) [- 1表示按需计费。](tag:dt,g42,tm,hk_g42,hk_tm,hcs,fcs,sbc,hk_sbc,hws_eu)
        :type charging_mode: int
        :param vpc_id: **参数解释**： VPC ID。 **取值范围**： 不涉及。
        :type vpc_id: str
        :param vpc_name: **参数解释**： VPC的名称。 **取值范围**： 不涉及。
        :type vpc_name: str
        :param created_at: **参数解释**： 完成创建时间。  格式为时间戳，指从格林威治时间 1970年01月01日00时00分00秒起至指定时间的偏差总毫秒数。 **取值范围**： 不涉及。
        :type created_at: str
        :param subnet_name: **参数解释**： 子网名称。 **取值范围**： 不涉及。
        :type subnet_name: str
        :param subnet_cidr: **参数解释**： 子网网段。 **取值范围**： 不涉及。
        :type subnet_cidr: str
        :param user_id: **参数解释**： 用户ID。 **取值范围**： 不涉及。
        :type user_id: str
        :param user_name: **参数解释**： 用户名。 **取值范围**： 不涉及。
        :type user_name: str
        :param access_user: **参数解释**： 实例访问用户名。 **取值范围**： 不涉及。
        :type access_user: str
        :param order_id: **参数解释**： 订单ID，只有在包周期计费时才会有order_id值，其他计费方式order_id值为空。 **取值范围**： 不涉及。
        :type order_id: str
        :param maintain_begin: **参数解释**： 维护时间窗开始时间，格式为HH:mm:ss。 **取值范围**： 不涉及。
        :type maintain_begin: str
        :param maintain_end: **参数解释**： 维护时间窗结束时间，格式为HH:mm:ss。 **取值范围**： 不涉及。
        :type maintain_end: str
        :param enable_publicip: **参数解释**： 实例是否开启公网访问功能。 **取值范围**： - true：开启 - false：未开启
        :type enable_publicip: bool
        :param management_connect_address: **参数解释**： Kafka实例的Kafka Manager连接地址。 **取值范围**： 不涉及。
        :type management_connect_address: str
        :param ssl_enable: **参数解释**： 是否开启安全认证。 **取值范围**： - true：开启 - false：未开启
        :type ssl_enable: bool
        :param broker_ssl_enable: **参数解释**： 是否开启broker间副本加密传输。 **取值范围**： - true：开启 - false：未开启
        :type broker_ssl_enable: bool
        :param kafka_security_protocol: **参数解释**： Kafka使用的安全协议。 若实例详情中不存在port_protocols返回参数，则kafka_security_protocol同时代表内网访问、公网访问以及跨VPC访问的安全协议。 若实例详情中存在port_protocols返回参数，则kafka_security_protocol仅代表跨VPC访问的安全协议。内网访问公网访问的安全协议请参考port_protocols参数。 **取值范围**： - PLAINTEXT：既未采用SSL证书进行加密传输，也不支持账号密码认证。性能更好，安全性较低，建议在生产环境下公网访问不使用此方式。 - SASL_SSL：采用SSL证书进行加密传输，支持账号密码认证，安全性更高。 - SASL_PLAINTEXT：明文传输，支持账号密码认证，性能更好，建议使用SCRAM-SHA-512机制。
        :type kafka_security_protocol: str
        :param sasl_enabled_mechanisms: **参数解释**： 开启SASL后使用的认证机制。
        :type sasl_enabled_mechanisms: list[str]
        :param ssl_two_way_enable: **参数解释**： 是否开启双向认证。 **取值范围**： - true：开启 - false：未开启
        :type ssl_two_way_enable: bool
        :param cert_replaced: **参数解释**： 是否开启证书替换。 **取值范围**： - true：开启 - false：未开启
        :type cert_replaced: bool
        :param public_management_connect_address: **参数解释**： 公网访问Kafka Manager连接地址。 **取值范围**： 不涉及。
        :type public_management_connect_address: str
        :param enterprise_project_id: **参数解释**： 企业项目ID。 **取值范围**： 不涉及。
        :type enterprise_project_id: str
        :param is_logical_volume: **参数解释**： 实例扩容时用于区分老实例与新实例。 **取值范围**： - true：新创建的实例，允许磁盘动态扩容不需要重启。 - false：老实例。
        :type is_logical_volume: bool
        :param extend_times: **参数解释**： 实例扩容磁盘次数。 **取值范围**： 不涉及。
        :type extend_times: int
        :param enable_auto_topic: **参数解释**： 是否开启自动创建Topic。 **取值范围**： - true：开启 - false：关闭
        :type enable_auto_topic: bool
        :param type: **参数解释**： 实例类型。 **取值范围**： - single：单机。 - cluster：集群。
        :type type: str
        :param product_id: **参数解释**： 产品标识。 **取值范围**： 不涉及。
        :type product_id: str
        :param security_group_id: **参数解释**： 安全组ID。 **取值范围**： 不涉及。
        :type security_group_id: str
        :param security_group_name: **参数解释**： 安全组名称。 **取值范围**： 不涉及。
        :type security_group_name: str
        :param subnet_id: **参数解释**： 子网ID。 **取值范围**： 不涉及。
        :type subnet_id: str
        :param available_zones: **参数解释**： 实例节点所在的可用区，返回“可用区ID”。
        :type available_zones: list[str]
        :param available_zone_names: **参数解释**： 实例节点所在的可用区名称，返回“可用区名称”。
        :type available_zone_names: list[str]
        :param total_storage_space: **参数解释**： 总共消息存储空间，单位：GB。 **取值范围**： 不涉及。
        :type total_storage_space: int
        :param public_connect_address: **参数解释**： 实例公网连接IP地址。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。
        :type public_connect_address: str
        :param public_connect_domain_name: **参数解释**： 实例公网连接域名。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。
        :type public_connect_domain_name: str
        :param storage_resource_id: **参数解释**： 存储资源ID。 **取值范围**： 不涉及。
        :type storage_resource_id: str
        :param storage_spec_code: **参数解释**： IO规格。 **取值范围**： 不涉及。
        :type storage_spec_code: str
        :param service_type: **参数解释**： 服务类型。 **取值范围**： advanced。
        :type service_type: str
        :param storage_type: **参数解释**： 存储类型。 **取值范围**： hec
        :type storage_type: str
        :param retention_policy: **参数解释**： 消息老化策略。 **取值范围**： - time_base：表示自动删除最老消息。 - produce_reject：表示拒绝消息写入。
        :type retention_policy: str
        :param kafka_public_status: **参数解释**： Kafka公网开启状态。 **取值范围**： - true：开启公网。 - closed：关闭公网。 - false：未使用公网。 - freezed：公网冻结。 - actived：公网解冻。
        :type kafka_public_status: str
        :param public_bandwidth: **参数解释**： kafka公网访问带宽。 **取值范围**： 不涉及。
        :type public_bandwidth: int
        :param enable_log_collection: **参数解释**： 是否开启消息收集功能。 **取值范围**： - true：开启 - false：不开启
        :type enable_log_collection: bool
        :param new_auth_cert: **参数解释**： 是否开启新证书。 **取值范围**： - true：开启 - false：不开启
        :type new_auth_cert: bool
        :param cross_vpc_info: **参数解释**： 跨VPC访问信息。 **取值范围**： 不涉及。
        :type cross_vpc_info: str
        :param ipv6_enable: **参数解释**： 是否开启IPv6。 **取值范围**： - true：开启 - false：不开启
        :type ipv6_enable: bool
        :param ipv6_connect_addresses: **参数解释**： IPv6的连接地址。
        :type ipv6_connect_addresses: list[str]
        :param connector_enable: **参数解释**： 是否开启转储。 **取值范围**： - true：开启 - false：不开启
        :type connector_enable: bool
        :param connector_node_num: **参数解释**： connector节点数量。 **取值范围**： 2-16。
        :type connector_node_num: int
        :param connector_id: **参数解释**： 转储任务ID。 **取值范围**： 不涉及。
        :type connector_id: str
        :param rest_enable: **参数解释**： 是否开启Kafka rest功能。 **取值范围**： - true：开启 - false：不开启
        :type rest_enable: bool
        :param rest_connect_address: **参数解释**：  Kafka rest连接地址。 **取值范围**： 不涉及。
        :type rest_connect_address: str
        :param public_boundwidth: **参数解释**： Kafka公网访问带宽。待删除版本。 **取值范围**： 不涉及。
        :type public_boundwidth: int
        :param message_query_inst_enable: **参数解释**： 是否开启消息查询功能。 **取值范围**： - true：开启 - false：不开启
        :type message_query_inst_enable: bool
        :param vpc_client_plain: **参数解释**： 是否开启VPC明文访问。 **取值范围**： - true：开启 - false：不开启
        :type vpc_client_plain: bool
        :param support_features: **参数解释**： Kafka实例支持的特性功能。 **取值范围**： 不涉及。
        :type support_features: str
        :param trace_enable: **参数解释**： 是否开启消息轨迹功能。 **取值范围**： - true：开启 - false：不开启
        :type trace_enable: bool
        :param agent_enable: **参数解释**： 是否开启代理。 **取值范围**： - true：开启 - false：不开启
        :type agent_enable: bool
        :param pod_connect_address: **参数解释**： 租户侧连接地址。 **取值范围**： 不涉及。
        :type pod_connect_address: str
        :param disk_encrypted: **参数解释**： 是否开启磁盘加密。 **取值范围**： - true：开启 - false：不开启
        :type disk_encrypted: bool
        :param disk_encrypted_key: **参数解释**： 磁盘加密key，未开启磁盘加密时为空。 **取值范围**： 不涉及。
        :type disk_encrypted_key: str
        :param kafka_private_connect_address: **参数解释**： Kafka实例内网连接地址。 **取值范围**： 不涉及。
        :type kafka_private_connect_address: str
        :param kafka_private_connect_domain_name: **参数解释**： Kafka实例内网连接域名。 **取值范围**： 不涉及。
        :type kafka_private_connect_domain_name: str
        :param ces_version: **参数解释**： 云监控版本。 **取值范围**： 不涉及。
        :type ces_version: str
        :param public_access_enabled: **参数解释**： 区分实例什么时候开启的公网访问 **取值范围**： - true：已开启公网访问 - actived：已开启公网访问 - closed：已关闭公网访问 - false：已关闭公网访问
        :type public_access_enabled: str
        :param node_num: **参数解释**： 节点数。 **取值范围**： - [1：Kafka单机实例的节点数。](tag:hws,hws_hk,hws_eu,dt,hcs,ax) - 3~50：Kafka集群实例的节点数。
        :type node_num: int
        :param port_protocols: 
        :type port_protocols: :class:`huaweicloudsdkkafka.v2.PortProtocolsEntity`
        :param enable_acl: **参数解释**： 是否开启访问控制。 **取值范围**： - true：开启 - false：不开启
        :type enable_acl: bool
        :param new_spec_billing_enable: **参数解释**： 是否启用新规格计费。 **取值范围**： - true：开启 - false：不开启
        :type new_spec_billing_enable: bool
        :param broker_num: **参数解释**： 节点数量。 **取值范围**： 不涉及。
        :type broker_num: int
        :param tags: **参数解释**： 标签列表。
        :type tags: list[:class:`huaweicloudsdkkafka.v2.TagEntity`]
        :param dr_enable: **参数解释**：  是否为容灾实例。 **取值范围**： - true：是容灾实例。 - false：不是容灾实例。
        :type dr_enable: bool
        """
        
        

        self._name = None
        self._engine = None
        self._engine_version = None
        self._description = None
        self._specification = None
        self._storage_space = None
        self._partition_num = None
        self._used_storage_space = None
        self._dns_enable = None
        self._connect_address = None
        self._port = None
        self._status = None
        self._instance_id = None
        self._resource_spec_code = None
        self._charging_mode = None
        self._vpc_id = None
        self._vpc_name = None
        self._created_at = None
        self._subnet_name = None
        self._subnet_cidr = None
        self._user_id = None
        self._user_name = None
        self._access_user = None
        self._order_id = None
        self._maintain_begin = None
        self._maintain_end = None
        self._enable_publicip = None
        self._management_connect_address = None
        self._ssl_enable = None
        self._broker_ssl_enable = None
        self._kafka_security_protocol = None
        self._sasl_enabled_mechanisms = None
        self._ssl_two_way_enable = None
        self._cert_replaced = None
        self._public_management_connect_address = None
        self._enterprise_project_id = None
        self._is_logical_volume = None
        self._extend_times = None
        self._enable_auto_topic = None
        self._type = None
        self._product_id = None
        self._security_group_id = None
        self._security_group_name = None
        self._subnet_id = None
        self._available_zones = None
        self._available_zone_names = None
        self._total_storage_space = None
        self._public_connect_address = None
        self._public_connect_domain_name = None
        self._storage_resource_id = None
        self._storage_spec_code = None
        self._service_type = None
        self._storage_type = None
        self._retention_policy = None
        self._kafka_public_status = None
        self._public_bandwidth = None
        self._enable_log_collection = None
        self._new_auth_cert = None
        self._cross_vpc_info = None
        self._ipv6_enable = None
        self._ipv6_connect_addresses = None
        self._connector_enable = None
        self._connector_node_num = None
        self._connector_id = None
        self._rest_enable = None
        self._rest_connect_address = None
        self._public_boundwidth = None
        self._message_query_inst_enable = None
        self._vpc_client_plain = None
        self._support_features = None
        self._trace_enable = None
        self._agent_enable = None
        self._pod_connect_address = None
        self._disk_encrypted = None
        self._disk_encrypted_key = None
        self._kafka_private_connect_address = None
        self._kafka_private_connect_domain_name = None
        self._ces_version = None
        self._public_access_enabled = None
        self._node_num = None
        self._port_protocols = None
        self._enable_acl = None
        self._new_spec_billing_enable = None
        self._broker_num = None
        self._tags = None
        self._dr_enable = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if engine is not None:
            self.engine = engine
        if engine_version is not None:
            self.engine_version = engine_version
        if description is not None:
            self.description = description
        if specification is not None:
            self.specification = specification
        if storage_space is not None:
            self.storage_space = storage_space
        if partition_num is not None:
            self.partition_num = partition_num
        if used_storage_space is not None:
            self.used_storage_space = used_storage_space
        if dns_enable is not None:
            self.dns_enable = dns_enable
        if connect_address is not None:
            self.connect_address = connect_address
        if port is not None:
            self.port = port
        if status is not None:
            self.status = status
        if instance_id is not None:
            self.instance_id = instance_id
        if resource_spec_code is not None:
            self.resource_spec_code = resource_spec_code
        if charging_mode is not None:
            self.charging_mode = charging_mode
        if vpc_id is not None:
            self.vpc_id = vpc_id
        if vpc_name is not None:
            self.vpc_name = vpc_name
        if created_at is not None:
            self.created_at = created_at
        if subnet_name is not None:
            self.subnet_name = subnet_name
        if subnet_cidr is not None:
            self.subnet_cidr = subnet_cidr
        if user_id is not None:
            self.user_id = user_id
        if user_name is not None:
            self.user_name = user_name
        if access_user is not None:
            self.access_user = access_user
        if order_id is not None:
            self.order_id = order_id
        if maintain_begin is not None:
            self.maintain_begin = maintain_begin
        if maintain_end is not None:
            self.maintain_end = maintain_end
        if enable_publicip is not None:
            self.enable_publicip = enable_publicip
        if management_connect_address is not None:
            self.management_connect_address = management_connect_address
        if ssl_enable is not None:
            self.ssl_enable = ssl_enable
        if broker_ssl_enable is not None:
            self.broker_ssl_enable = broker_ssl_enable
        if kafka_security_protocol is not None:
            self.kafka_security_protocol = kafka_security_protocol
        if sasl_enabled_mechanisms is not None:
            self.sasl_enabled_mechanisms = sasl_enabled_mechanisms
        if ssl_two_way_enable is not None:
            self.ssl_two_way_enable = ssl_two_way_enable
        if cert_replaced is not None:
            self.cert_replaced = cert_replaced
        if public_management_connect_address is not None:
            self.public_management_connect_address = public_management_connect_address
        if enterprise_project_id is not None:
            self.enterprise_project_id = enterprise_project_id
        if is_logical_volume is not None:
            self.is_logical_volume = is_logical_volume
        if extend_times is not None:
            self.extend_times = extend_times
        if enable_auto_topic is not None:
            self.enable_auto_topic = enable_auto_topic
        if type is not None:
            self.type = type
        if product_id is not None:
            self.product_id = product_id
        if security_group_id is not None:
            self.security_group_id = security_group_id
        if security_group_name is not None:
            self.security_group_name = security_group_name
        if subnet_id is not None:
            self.subnet_id = subnet_id
        if available_zones is not None:
            self.available_zones = available_zones
        if available_zone_names is not None:
            self.available_zone_names = available_zone_names
        if total_storage_space is not None:
            self.total_storage_space = total_storage_space
        if public_connect_address is not None:
            self.public_connect_address = public_connect_address
        if public_connect_domain_name is not None:
            self.public_connect_domain_name = public_connect_domain_name
        if storage_resource_id is not None:
            self.storage_resource_id = storage_resource_id
        if storage_spec_code is not None:
            self.storage_spec_code = storage_spec_code
        if service_type is not None:
            self.service_type = service_type
        if storage_type is not None:
            self.storage_type = storage_type
        if retention_policy is not None:
            self.retention_policy = retention_policy
        if kafka_public_status is not None:
            self.kafka_public_status = kafka_public_status
        if public_bandwidth is not None:
            self.public_bandwidth = public_bandwidth
        if enable_log_collection is not None:
            self.enable_log_collection = enable_log_collection
        if new_auth_cert is not None:
            self.new_auth_cert = new_auth_cert
        if cross_vpc_info is not None:
            self.cross_vpc_info = cross_vpc_info
        if ipv6_enable is not None:
            self.ipv6_enable = ipv6_enable
        if ipv6_connect_addresses is not None:
            self.ipv6_connect_addresses = ipv6_connect_addresses
        if connector_enable is not None:
            self.connector_enable = connector_enable
        if connector_node_num is not None:
            self.connector_node_num = connector_node_num
        if connector_id is not None:
            self.connector_id = connector_id
        if rest_enable is not None:
            self.rest_enable = rest_enable
        if rest_connect_address is not None:
            self.rest_connect_address = rest_connect_address
        if public_boundwidth is not None:
            self.public_boundwidth = public_boundwidth
        if message_query_inst_enable is not None:
            self.message_query_inst_enable = message_query_inst_enable
        if vpc_client_plain is not None:
            self.vpc_client_plain = vpc_client_plain
        if support_features is not None:
            self.support_features = support_features
        if trace_enable is not None:
            self.trace_enable = trace_enable
        if agent_enable is not None:
            self.agent_enable = agent_enable
        if pod_connect_address is not None:
            self.pod_connect_address = pod_connect_address
        if disk_encrypted is not None:
            self.disk_encrypted = disk_encrypted
        if disk_encrypted_key is not None:
            self.disk_encrypted_key = disk_encrypted_key
        if kafka_private_connect_address is not None:
            self.kafka_private_connect_address = kafka_private_connect_address
        if kafka_private_connect_domain_name is not None:
            self.kafka_private_connect_domain_name = kafka_private_connect_domain_name
        if ces_version is not None:
            self.ces_version = ces_version
        if public_access_enabled is not None:
            self.public_access_enabled = public_access_enabled
        if node_num is not None:
            self.node_num = node_num
        if port_protocols is not None:
            self.port_protocols = port_protocols
        if enable_acl is not None:
            self.enable_acl = enable_acl
        if new_spec_billing_enable is not None:
            self.new_spec_billing_enable = new_spec_billing_enable
        if broker_num is not None:
            self.broker_num = broker_num
        if tags is not None:
            self.tags = tags
        if dr_enable is not None:
            self.dr_enable = dr_enable

    @property
    def name(self):
        r"""Gets the name of this ShowInstanceResp.

        **参数解释**： 实例名称。 **取值范围**： 不涉及。

        :return: The name of this ShowInstanceResp.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this ShowInstanceResp.

        **参数解释**： 实例名称。 **取值范围**： 不涉及。

        :param name: The name of this ShowInstanceResp.
        :type name: str
        """
        self._name = name

    @property
    def engine(self):
        r"""Gets the engine of this ShowInstanceResp.

        **参数解释**： 引擎。 **取值范围**： kafka

        :return: The engine of this ShowInstanceResp.
        :rtype: str
        """
        return self._engine

    @engine.setter
    def engine(self, engine):
        r"""Sets the engine of this ShowInstanceResp.

        **参数解释**： 引擎。 **取值范围**： kafka

        :param engine: The engine of this ShowInstanceResp.
        :type engine: str
        """
        self._engine = engine

    @property
    def engine_version(self):
        r"""Gets the engine_version of this ShowInstanceResp.

        **参数解释**： Kafka的版本。 **取值范围**： [- 1.1.0](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,sbc,cmcc,ax) [- 2.3.0](tag:g42,tm,hk_g42,ctc,hk_tm,dt,sbc,cmcc) - 2.7 [- 3.x](tag:hws,hws_hk,dt,sbc,hcs,fcs,ctc,tm,hk_tm,hws_eu,ax)

        :return: The engine_version of this ShowInstanceResp.
        :rtype: str
        """
        return self._engine_version

    @engine_version.setter
    def engine_version(self, engine_version):
        r"""Sets the engine_version of this ShowInstanceResp.

        **参数解释**： Kafka的版本。 **取值范围**： [- 1.1.0](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,sbc,cmcc,ax) [- 2.3.0](tag:g42,tm,hk_g42,ctc,hk_tm,dt,sbc,cmcc) - 2.7 [- 3.x](tag:hws,hws_hk,dt,sbc,hcs,fcs,ctc,tm,hk_tm,hws_eu,ax)

        :param engine_version: The engine_version of this ShowInstanceResp.
        :type engine_version: str
        """
        self._engine_version = engine_version

    @property
    def description(self):
        r"""Gets the description of this ShowInstanceResp.

        **参数解释**： 实例描述。 **取值范围**： 不涉及。

        :return: The description of this ShowInstanceResp.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this ShowInstanceResp.

        **参数解释**： 实例描述。 **取值范围**： 不涉及。

        :param description: The description of this ShowInstanceResp.
        :type description: str
        """
        self._description = description

    @property
    def specification(self):
        r"""Gets the specification of this ShowInstanceResp.

        **参数解释**： 实例规格。 **取值范围**： 不涉及。

        :return: The specification of this ShowInstanceResp.
        :rtype: str
        """
        return self._specification

    @specification.setter
    def specification(self, specification):
        r"""Sets the specification of this ShowInstanceResp.

        **参数解释**： 实例规格。 **取值范围**： 不涉及。

        :param specification: The specification of this ShowInstanceResp.
        :type specification: str
        """
        self._specification = specification

    @property
    def storage_space(self):
        r"""Gets the storage_space of this ShowInstanceResp.

        **参数解释**： 消息存储空间，单位：GB。 **取值范围**： [- Kafka实例规格为c6.2u4g.cluster时，存储空间取值范围300GB ~ 300000GB。 - Kafka实例规格为c6.4u8g.cluster时，存储空间取值范围300GB ~ 600000GB。 - Kafka实例规格为c6.8u16g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.12u24g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.16u32g.cluster时，存储空间取值范围300GB ~ 1500000GB。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax) [- Kafka实例规格为kafka.2u4g.cluster.small时，存储空间取值范围300GB~300000GB。](tag:hws,hws_hk,hws_eu,dt,ax) [- Kafka实例规格为kafka.2u8g.cluster时，存储空间取值范围300GB~300000GB。](tag:fcs) [- Kafka实例规格为kafka.4u16g.cluster时，存储空间取值范围300GB~600000GB。 - Kafka实例规格为kafka.8u32g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.16u64g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.32u128g.cluster时，存储空间取值范围300GB~1500000GB。](tag:hcs,fcs)

        :return: The storage_space of this ShowInstanceResp.
        :rtype: int
        """
        return self._storage_space

    @storage_space.setter
    def storage_space(self, storage_space):
        r"""Sets the storage_space of this ShowInstanceResp.

        **参数解释**： 消息存储空间，单位：GB。 **取值范围**： [- Kafka实例规格为c6.2u4g.cluster时，存储空间取值范围300GB ~ 300000GB。 - Kafka实例规格为c6.4u8g.cluster时，存储空间取值范围300GB ~ 600000GB。 - Kafka实例规格为c6.8u16g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.12u24g.cluster时，存储空间取值范围300GB ~ 1500000GB。 - Kafka实例规格为c6.16u32g.cluster时，存储空间取值范围300GB ~ 1500000GB。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax) [- Kafka实例规格为kafka.2u4g.cluster.small时，存储空间取值范围300GB~300000GB。](tag:hws,hws_hk,hws_eu,dt,ax) [- Kafka实例规格为kafka.2u8g.cluster时，存储空间取值范围300GB~300000GB。](tag:fcs) [- Kafka实例规格为kafka.4u16g.cluster时，存储空间取值范围300GB~600000GB。 - Kafka实例规格为kafka.8u32g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.16u64g.cluster时，存储空间取值范围300GB~1500000GB。 - Kafka实例规格为kafka.32u128g.cluster时，存储空间取值范围300GB~1500000GB。](tag:hcs,fcs)

        :param storage_space: The storage_space of this ShowInstanceResp.
        :type storage_space: int
        """
        self._storage_space = storage_space

    @property
    def partition_num(self):
        r"""Gets the partition_num of this ShowInstanceResp.

        **参数解释**： Kafka实例的分区数量。 **取值范围**： 不涉及。

        :return: The partition_num of this ShowInstanceResp.
        :rtype: str
        """
        return self._partition_num

    @partition_num.setter
    def partition_num(self, partition_num):
        r"""Sets the partition_num of this ShowInstanceResp.

        **参数解释**： Kafka实例的分区数量。 **取值范围**： 不涉及。

        :param partition_num: The partition_num of this ShowInstanceResp.
        :type partition_num: str
        """
        self._partition_num = partition_num

    @property
    def used_storage_space(self):
        r"""Gets the used_storage_space of this ShowInstanceResp.

        **参数解释**： 已使用的消息存储空间，单位：GB。 **取值范围**： 不涉及。

        :return: The used_storage_space of this ShowInstanceResp.
        :rtype: int
        """
        return self._used_storage_space

    @used_storage_space.setter
    def used_storage_space(self, used_storage_space):
        r"""Sets the used_storage_space of this ShowInstanceResp.

        **参数解释**： 已使用的消息存储空间，单位：GB。 **取值范围**： 不涉及。

        :param used_storage_space: The used_storage_space of this ShowInstanceResp.
        :type used_storage_space: int
        """
        self._used_storage_space = used_storage_space

    @property
    def dns_enable(self):
        r"""Gets the dns_enable of this ShowInstanceResp.

        **参数解释**： 实例是否开启域名访问功能。 **取值范围**： - true：开启 - false：未开启

        :return: The dns_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._dns_enable

    @dns_enable.setter
    def dns_enable(self, dns_enable):
        r"""Sets the dns_enable of this ShowInstanceResp.

        **参数解释**： 实例是否开启域名访问功能。 **取值范围**： - true：开启 - false：未开启

        :param dns_enable: The dns_enable of this ShowInstanceResp.
        :type dns_enable: bool
        """
        self._dns_enable = dns_enable

    @property
    def connect_address(self):
        r"""Gets the connect_address of this ShowInstanceResp.

        **参数解释**： 实例连接IP地址。 **取值范围**： 不涉及。

        :return: The connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._connect_address

    @connect_address.setter
    def connect_address(self, connect_address):
        r"""Sets the connect_address of this ShowInstanceResp.

        **参数解释**： 实例连接IP地址。 **取值范围**： 不涉及。

        :param connect_address: The connect_address of this ShowInstanceResp.
        :type connect_address: str
        """
        self._connect_address = connect_address

    @property
    def port(self):
        r"""Gets the port of this ShowInstanceResp.

        **参数解释**： 实例连接端口。 **取值范围**： 不涉及。

        :return: The port of this ShowInstanceResp.
        :rtype: int
        """
        return self._port

    @port.setter
    def port(self, port):
        r"""Sets the port of this ShowInstanceResp.

        **参数解释**： 实例连接端口。 **取值范围**： 不涉及。

        :param port: The port of this ShowInstanceResp.
        :type port: int
        """
        self._port = port

    @property
    def status(self):
        r"""Gets the status of this ShowInstanceResp.

        **参数解释**： 实例的状态。详细状态说明请参考[实例状态说明](kafka-api-180514012.xml)。 **取值范围**： 不涉及。

        :return: The status of this ShowInstanceResp.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ShowInstanceResp.

        **参数解释**： 实例的状态。详细状态说明请参考[实例状态说明](kafka-api-180514012.xml)。 **取值范围**： 不涉及。

        :param status: The status of this ShowInstanceResp.
        :type status: str
        """
        self._status = status

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ShowInstanceResp.

        **参数解释**： 实例ID。 **取值范围**： 不涉及。

        :return: The instance_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ShowInstanceResp.

        **参数解释**： 实例ID。 **取值范围**： 不涉及。

        :param instance_id: The instance_id of this ShowInstanceResp.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def resource_spec_code(self):
        r"""Gets the resource_spec_code of this ShowInstanceResp.

        **参数解释**： 资源规格标识。 **取值范围**： [- dms.instance.kafka.cluster.c3.mini：Kafka实例的基准带宽为100MByte/秒。 - dms.instance.kafka.cluster.c3.small.2：Kafka实例的基准带宽为300MByte/秒。 - dms.instance.kafka.cluster.c3.middle.2：Kafka实例的基准带宽为600MByte/秒。 - dms.instance.kafka.cluster.c3.high.2：Kafka实例的基准带宽为1200MByte/秒。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax)

        :return: The resource_spec_code of this ShowInstanceResp.
        :rtype: str
        """
        return self._resource_spec_code

    @resource_spec_code.setter
    def resource_spec_code(self, resource_spec_code):
        r"""Sets the resource_spec_code of this ShowInstanceResp.

        **参数解释**： 资源规格标识。 **取值范围**： [- dms.instance.kafka.cluster.c3.mini：Kafka实例的基准带宽为100MByte/秒。 - dms.instance.kafka.cluster.c3.small.2：Kafka实例的基准带宽为300MByte/秒。 - dms.instance.kafka.cluster.c3.middle.2：Kafka实例的基准带宽为600MByte/秒。 - dms.instance.kafka.cluster.c3.high.2：Kafka实例的基准带宽为1200MByte/秒。](tag:hws,hws_eu,hws_hk,ocb,hws_ocb,ctc,g42,hk_g42,tm,hk_tm,dt,ax)

        :param resource_spec_code: The resource_spec_code of this ShowInstanceResp.
        :type resource_spec_code: str
        """
        self._resource_spec_code = resource_spec_code

    @property
    def charging_mode(self):
        r"""Gets the charging_mode of this ShowInstanceResp.

        **参数解释**： 付费模式。 **取值范围**： [- 1表示按需计费。 - 0表示包年/包月计费。](tag:hws,hws_hk,ctc,cmcc,ax)[付费模式，暂未使用。](tag:hws_ocb,ocb) [- 1表示按需计费。](tag:dt,g42,tm,hk_g42,hk_tm,hcs,fcs,sbc,hk_sbc,hws_eu)

        :return: The charging_mode of this ShowInstanceResp.
        :rtype: int
        """
        return self._charging_mode

    @charging_mode.setter
    def charging_mode(self, charging_mode):
        r"""Sets the charging_mode of this ShowInstanceResp.

        **参数解释**： 付费模式。 **取值范围**： [- 1表示按需计费。 - 0表示包年/包月计费。](tag:hws,hws_hk,ctc,cmcc,ax)[付费模式，暂未使用。](tag:hws_ocb,ocb) [- 1表示按需计费。](tag:dt,g42,tm,hk_g42,hk_tm,hcs,fcs,sbc,hk_sbc,hws_eu)

        :param charging_mode: The charging_mode of this ShowInstanceResp.
        :type charging_mode: int
        """
        self._charging_mode = charging_mode

    @property
    def vpc_id(self):
        r"""Gets the vpc_id of this ShowInstanceResp.

        **参数解释**： VPC ID。 **取值范围**： 不涉及。

        :return: The vpc_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._vpc_id

    @vpc_id.setter
    def vpc_id(self, vpc_id):
        r"""Sets the vpc_id of this ShowInstanceResp.

        **参数解释**： VPC ID。 **取值范围**： 不涉及。

        :param vpc_id: The vpc_id of this ShowInstanceResp.
        :type vpc_id: str
        """
        self._vpc_id = vpc_id

    @property
    def vpc_name(self):
        r"""Gets the vpc_name of this ShowInstanceResp.

        **参数解释**： VPC的名称。 **取值范围**： 不涉及。

        :return: The vpc_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._vpc_name

    @vpc_name.setter
    def vpc_name(self, vpc_name):
        r"""Sets the vpc_name of this ShowInstanceResp.

        **参数解释**： VPC的名称。 **取值范围**： 不涉及。

        :param vpc_name: The vpc_name of this ShowInstanceResp.
        :type vpc_name: str
        """
        self._vpc_name = vpc_name

    @property
    def created_at(self):
        r"""Gets the created_at of this ShowInstanceResp.

        **参数解释**： 完成创建时间。  格式为时间戳，指从格林威治时间 1970年01月01日00时00分00秒起至指定时间的偏差总毫秒数。 **取值范围**： 不涉及。

        :return: The created_at of this ShowInstanceResp.
        :rtype: str
        """
        return self._created_at

    @created_at.setter
    def created_at(self, created_at):
        r"""Sets the created_at of this ShowInstanceResp.

        **参数解释**： 完成创建时间。  格式为时间戳，指从格林威治时间 1970年01月01日00时00分00秒起至指定时间的偏差总毫秒数。 **取值范围**： 不涉及。

        :param created_at: The created_at of this ShowInstanceResp.
        :type created_at: str
        """
        self._created_at = created_at

    @property
    def subnet_name(self):
        r"""Gets the subnet_name of this ShowInstanceResp.

        **参数解释**： 子网名称。 **取值范围**： 不涉及。

        :return: The subnet_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._subnet_name

    @subnet_name.setter
    def subnet_name(self, subnet_name):
        r"""Sets the subnet_name of this ShowInstanceResp.

        **参数解释**： 子网名称。 **取值范围**： 不涉及。

        :param subnet_name: The subnet_name of this ShowInstanceResp.
        :type subnet_name: str
        """
        self._subnet_name = subnet_name

    @property
    def subnet_cidr(self):
        r"""Gets the subnet_cidr of this ShowInstanceResp.

        **参数解释**： 子网网段。 **取值范围**： 不涉及。

        :return: The subnet_cidr of this ShowInstanceResp.
        :rtype: str
        """
        return self._subnet_cidr

    @subnet_cidr.setter
    def subnet_cidr(self, subnet_cidr):
        r"""Sets the subnet_cidr of this ShowInstanceResp.

        **参数解释**： 子网网段。 **取值范围**： 不涉及。

        :param subnet_cidr: The subnet_cidr of this ShowInstanceResp.
        :type subnet_cidr: str
        """
        self._subnet_cidr = subnet_cidr

    @property
    def user_id(self):
        r"""Gets the user_id of this ShowInstanceResp.

        **参数解释**： 用户ID。 **取值范围**： 不涉及。

        :return: The user_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._user_id

    @user_id.setter
    def user_id(self, user_id):
        r"""Sets the user_id of this ShowInstanceResp.

        **参数解释**： 用户ID。 **取值范围**： 不涉及。

        :param user_id: The user_id of this ShowInstanceResp.
        :type user_id: str
        """
        self._user_id = user_id

    @property
    def user_name(self):
        r"""Gets the user_name of this ShowInstanceResp.

        **参数解释**： 用户名。 **取值范围**： 不涉及。

        :return: The user_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._user_name

    @user_name.setter
    def user_name(self, user_name):
        r"""Sets the user_name of this ShowInstanceResp.

        **参数解释**： 用户名。 **取值范围**： 不涉及。

        :param user_name: The user_name of this ShowInstanceResp.
        :type user_name: str
        """
        self._user_name = user_name

    @property
    def access_user(self):
        r"""Gets the access_user of this ShowInstanceResp.

        **参数解释**： 实例访问用户名。 **取值范围**： 不涉及。

        :return: The access_user of this ShowInstanceResp.
        :rtype: str
        """
        return self._access_user

    @access_user.setter
    def access_user(self, access_user):
        r"""Sets the access_user of this ShowInstanceResp.

        **参数解释**： 实例访问用户名。 **取值范围**： 不涉及。

        :param access_user: The access_user of this ShowInstanceResp.
        :type access_user: str
        """
        self._access_user = access_user

    @property
    def order_id(self):
        r"""Gets the order_id of this ShowInstanceResp.

        **参数解释**： 订单ID，只有在包周期计费时才会有order_id值，其他计费方式order_id值为空。 **取值范围**： 不涉及。

        :return: The order_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._order_id

    @order_id.setter
    def order_id(self, order_id):
        r"""Sets the order_id of this ShowInstanceResp.

        **参数解释**： 订单ID，只有在包周期计费时才会有order_id值，其他计费方式order_id值为空。 **取值范围**： 不涉及。

        :param order_id: The order_id of this ShowInstanceResp.
        :type order_id: str
        """
        self._order_id = order_id

    @property
    def maintain_begin(self):
        r"""Gets the maintain_begin of this ShowInstanceResp.

        **参数解释**： 维护时间窗开始时间，格式为HH:mm:ss。 **取值范围**： 不涉及。

        :return: The maintain_begin of this ShowInstanceResp.
        :rtype: str
        """
        return self._maintain_begin

    @maintain_begin.setter
    def maintain_begin(self, maintain_begin):
        r"""Sets the maintain_begin of this ShowInstanceResp.

        **参数解释**： 维护时间窗开始时间，格式为HH:mm:ss。 **取值范围**： 不涉及。

        :param maintain_begin: The maintain_begin of this ShowInstanceResp.
        :type maintain_begin: str
        """
        self._maintain_begin = maintain_begin

    @property
    def maintain_end(self):
        r"""Gets the maintain_end of this ShowInstanceResp.

        **参数解释**： 维护时间窗结束时间，格式为HH:mm:ss。 **取值范围**： 不涉及。

        :return: The maintain_end of this ShowInstanceResp.
        :rtype: str
        """
        return self._maintain_end

    @maintain_end.setter
    def maintain_end(self, maintain_end):
        r"""Sets the maintain_end of this ShowInstanceResp.

        **参数解释**： 维护时间窗结束时间，格式为HH:mm:ss。 **取值范围**： 不涉及。

        :param maintain_end: The maintain_end of this ShowInstanceResp.
        :type maintain_end: str
        """
        self._maintain_end = maintain_end

    @property
    def enable_publicip(self):
        r"""Gets the enable_publicip of this ShowInstanceResp.

        **参数解释**： 实例是否开启公网访问功能。 **取值范围**： - true：开启 - false：未开启

        :return: The enable_publicip of this ShowInstanceResp.
        :rtype: bool
        """
        return self._enable_publicip

    @enable_publicip.setter
    def enable_publicip(self, enable_publicip):
        r"""Sets the enable_publicip of this ShowInstanceResp.

        **参数解释**： 实例是否开启公网访问功能。 **取值范围**： - true：开启 - false：未开启

        :param enable_publicip: The enable_publicip of this ShowInstanceResp.
        :type enable_publicip: bool
        """
        self._enable_publicip = enable_publicip

    @property
    def management_connect_address(self):
        r"""Gets the management_connect_address of this ShowInstanceResp.

        **参数解释**： Kafka实例的Kafka Manager连接地址。 **取值范围**： 不涉及。

        :return: The management_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._management_connect_address

    @management_connect_address.setter
    def management_connect_address(self, management_connect_address):
        r"""Sets the management_connect_address of this ShowInstanceResp.

        **参数解释**： Kafka实例的Kafka Manager连接地址。 **取值范围**： 不涉及。

        :param management_connect_address: The management_connect_address of this ShowInstanceResp.
        :type management_connect_address: str
        """
        self._management_connect_address = management_connect_address

    @property
    def ssl_enable(self):
        r"""Gets the ssl_enable of this ShowInstanceResp.

        **参数解释**： 是否开启安全认证。 **取值范围**： - true：开启 - false：未开启

        :return: The ssl_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._ssl_enable

    @ssl_enable.setter
    def ssl_enable(self, ssl_enable):
        r"""Sets the ssl_enable of this ShowInstanceResp.

        **参数解释**： 是否开启安全认证。 **取值范围**： - true：开启 - false：未开启

        :param ssl_enable: The ssl_enable of this ShowInstanceResp.
        :type ssl_enable: bool
        """
        self._ssl_enable = ssl_enable

    @property
    def broker_ssl_enable(self):
        r"""Gets the broker_ssl_enable of this ShowInstanceResp.

        **参数解释**： 是否开启broker间副本加密传输。 **取值范围**： - true：开启 - false：未开启

        :return: The broker_ssl_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._broker_ssl_enable

    @broker_ssl_enable.setter
    def broker_ssl_enable(self, broker_ssl_enable):
        r"""Sets the broker_ssl_enable of this ShowInstanceResp.

        **参数解释**： 是否开启broker间副本加密传输。 **取值范围**： - true：开启 - false：未开启

        :param broker_ssl_enable: The broker_ssl_enable of this ShowInstanceResp.
        :type broker_ssl_enable: bool
        """
        self._broker_ssl_enable = broker_ssl_enable

    @property
    def kafka_security_protocol(self):
        r"""Gets the kafka_security_protocol of this ShowInstanceResp.

        **参数解释**： Kafka使用的安全协议。 若实例详情中不存在port_protocols返回参数，则kafka_security_protocol同时代表内网访问、公网访问以及跨VPC访问的安全协议。 若实例详情中存在port_protocols返回参数，则kafka_security_protocol仅代表跨VPC访问的安全协议。内网访问公网访问的安全协议请参考port_protocols参数。 **取值范围**： - PLAINTEXT：既未采用SSL证书进行加密传输，也不支持账号密码认证。性能更好，安全性较低，建议在生产环境下公网访问不使用此方式。 - SASL_SSL：采用SSL证书进行加密传输，支持账号密码认证，安全性更高。 - SASL_PLAINTEXT：明文传输，支持账号密码认证，性能更好，建议使用SCRAM-SHA-512机制。

        :return: The kafka_security_protocol of this ShowInstanceResp.
        :rtype: str
        """
        return self._kafka_security_protocol

    @kafka_security_protocol.setter
    def kafka_security_protocol(self, kafka_security_protocol):
        r"""Sets the kafka_security_protocol of this ShowInstanceResp.

        **参数解释**： Kafka使用的安全协议。 若实例详情中不存在port_protocols返回参数，则kafka_security_protocol同时代表内网访问、公网访问以及跨VPC访问的安全协议。 若实例详情中存在port_protocols返回参数，则kafka_security_protocol仅代表跨VPC访问的安全协议。内网访问公网访问的安全协议请参考port_protocols参数。 **取值范围**： - PLAINTEXT：既未采用SSL证书进行加密传输，也不支持账号密码认证。性能更好，安全性较低，建议在生产环境下公网访问不使用此方式。 - SASL_SSL：采用SSL证书进行加密传输，支持账号密码认证，安全性更高。 - SASL_PLAINTEXT：明文传输，支持账号密码认证，性能更好，建议使用SCRAM-SHA-512机制。

        :param kafka_security_protocol: The kafka_security_protocol of this ShowInstanceResp.
        :type kafka_security_protocol: str
        """
        self._kafka_security_protocol = kafka_security_protocol

    @property
    def sasl_enabled_mechanisms(self):
        r"""Gets the sasl_enabled_mechanisms of this ShowInstanceResp.

        **参数解释**： 开启SASL后使用的认证机制。

        :return: The sasl_enabled_mechanisms of this ShowInstanceResp.
        :rtype: list[str]
        """
        return self._sasl_enabled_mechanisms

    @sasl_enabled_mechanisms.setter
    def sasl_enabled_mechanisms(self, sasl_enabled_mechanisms):
        r"""Sets the sasl_enabled_mechanisms of this ShowInstanceResp.

        **参数解释**： 开启SASL后使用的认证机制。

        :param sasl_enabled_mechanisms: The sasl_enabled_mechanisms of this ShowInstanceResp.
        :type sasl_enabled_mechanisms: list[str]
        """
        self._sasl_enabled_mechanisms = sasl_enabled_mechanisms

    @property
    def ssl_two_way_enable(self):
        r"""Gets the ssl_two_way_enable of this ShowInstanceResp.

        **参数解释**： 是否开启双向认证。 **取值范围**： - true：开启 - false：未开启

        :return: The ssl_two_way_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._ssl_two_way_enable

    @ssl_two_way_enable.setter
    def ssl_two_way_enable(self, ssl_two_way_enable):
        r"""Sets the ssl_two_way_enable of this ShowInstanceResp.

        **参数解释**： 是否开启双向认证。 **取值范围**： - true：开启 - false：未开启

        :param ssl_two_way_enable: The ssl_two_way_enable of this ShowInstanceResp.
        :type ssl_two_way_enable: bool
        """
        self._ssl_two_way_enable = ssl_two_way_enable

    @property
    def cert_replaced(self):
        r"""Gets the cert_replaced of this ShowInstanceResp.

        **参数解释**： 是否开启证书替换。 **取值范围**： - true：开启 - false：未开启

        :return: The cert_replaced of this ShowInstanceResp.
        :rtype: bool
        """
        return self._cert_replaced

    @cert_replaced.setter
    def cert_replaced(self, cert_replaced):
        r"""Sets the cert_replaced of this ShowInstanceResp.

        **参数解释**： 是否开启证书替换。 **取值范围**： - true：开启 - false：未开启

        :param cert_replaced: The cert_replaced of this ShowInstanceResp.
        :type cert_replaced: bool
        """
        self._cert_replaced = cert_replaced

    @property
    def public_management_connect_address(self):
        r"""Gets the public_management_connect_address of this ShowInstanceResp.

        **参数解释**： 公网访问Kafka Manager连接地址。 **取值范围**： 不涉及。

        :return: The public_management_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._public_management_connect_address

    @public_management_connect_address.setter
    def public_management_connect_address(self, public_management_connect_address):
        r"""Sets the public_management_connect_address of this ShowInstanceResp.

        **参数解释**： 公网访问Kafka Manager连接地址。 **取值范围**： 不涉及。

        :param public_management_connect_address: The public_management_connect_address of this ShowInstanceResp.
        :type public_management_connect_address: str
        """
        self._public_management_connect_address = public_management_connect_address

    @property
    def enterprise_project_id(self):
        r"""Gets the enterprise_project_id of this ShowInstanceResp.

        **参数解释**： 企业项目ID。 **取值范围**： 不涉及。

        :return: The enterprise_project_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._enterprise_project_id

    @enterprise_project_id.setter
    def enterprise_project_id(self, enterprise_project_id):
        r"""Sets the enterprise_project_id of this ShowInstanceResp.

        **参数解释**： 企业项目ID。 **取值范围**： 不涉及。

        :param enterprise_project_id: The enterprise_project_id of this ShowInstanceResp.
        :type enterprise_project_id: str
        """
        self._enterprise_project_id = enterprise_project_id

    @property
    def is_logical_volume(self):
        r"""Gets the is_logical_volume of this ShowInstanceResp.

        **参数解释**： 实例扩容时用于区分老实例与新实例。 **取值范围**： - true：新创建的实例，允许磁盘动态扩容不需要重启。 - false：老实例。

        :return: The is_logical_volume of this ShowInstanceResp.
        :rtype: bool
        """
        return self._is_logical_volume

    @is_logical_volume.setter
    def is_logical_volume(self, is_logical_volume):
        r"""Sets the is_logical_volume of this ShowInstanceResp.

        **参数解释**： 实例扩容时用于区分老实例与新实例。 **取值范围**： - true：新创建的实例，允许磁盘动态扩容不需要重启。 - false：老实例。

        :param is_logical_volume: The is_logical_volume of this ShowInstanceResp.
        :type is_logical_volume: bool
        """
        self._is_logical_volume = is_logical_volume

    @property
    def extend_times(self):
        r"""Gets the extend_times of this ShowInstanceResp.

        **参数解释**： 实例扩容磁盘次数。 **取值范围**： 不涉及。

        :return: The extend_times of this ShowInstanceResp.
        :rtype: int
        """
        return self._extend_times

    @extend_times.setter
    def extend_times(self, extend_times):
        r"""Sets the extend_times of this ShowInstanceResp.

        **参数解释**： 实例扩容磁盘次数。 **取值范围**： 不涉及。

        :param extend_times: The extend_times of this ShowInstanceResp.
        :type extend_times: int
        """
        self._extend_times = extend_times

    @property
    def enable_auto_topic(self):
        r"""Gets the enable_auto_topic of this ShowInstanceResp.

        **参数解释**： 是否开启自动创建Topic。 **取值范围**： - true：开启 - false：关闭

        :return: The enable_auto_topic of this ShowInstanceResp.
        :rtype: bool
        """
        return self._enable_auto_topic

    @enable_auto_topic.setter
    def enable_auto_topic(self, enable_auto_topic):
        r"""Sets the enable_auto_topic of this ShowInstanceResp.

        **参数解释**： 是否开启自动创建Topic。 **取值范围**： - true：开启 - false：关闭

        :param enable_auto_topic: The enable_auto_topic of this ShowInstanceResp.
        :type enable_auto_topic: bool
        """
        self._enable_auto_topic = enable_auto_topic

    @property
    def type(self):
        r"""Gets the type of this ShowInstanceResp.

        **参数解释**： 实例类型。 **取值范围**： - single：单机。 - cluster：集群。

        :return: The type of this ShowInstanceResp.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this ShowInstanceResp.

        **参数解释**： 实例类型。 **取值范围**： - single：单机。 - cluster：集群。

        :param type: The type of this ShowInstanceResp.
        :type type: str
        """
        self._type = type

    @property
    def product_id(self):
        r"""Gets the product_id of this ShowInstanceResp.

        **参数解释**： 产品标识。 **取值范围**： 不涉及。

        :return: The product_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._product_id

    @product_id.setter
    def product_id(self, product_id):
        r"""Sets the product_id of this ShowInstanceResp.

        **参数解释**： 产品标识。 **取值范围**： 不涉及。

        :param product_id: The product_id of this ShowInstanceResp.
        :type product_id: str
        """
        self._product_id = product_id

    @property
    def security_group_id(self):
        r"""Gets the security_group_id of this ShowInstanceResp.

        **参数解释**： 安全组ID。 **取值范围**： 不涉及。

        :return: The security_group_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._security_group_id

    @security_group_id.setter
    def security_group_id(self, security_group_id):
        r"""Sets the security_group_id of this ShowInstanceResp.

        **参数解释**： 安全组ID。 **取值范围**： 不涉及。

        :param security_group_id: The security_group_id of this ShowInstanceResp.
        :type security_group_id: str
        """
        self._security_group_id = security_group_id

    @property
    def security_group_name(self):
        r"""Gets the security_group_name of this ShowInstanceResp.

        **参数解释**： 安全组名称。 **取值范围**： 不涉及。

        :return: The security_group_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._security_group_name

    @security_group_name.setter
    def security_group_name(self, security_group_name):
        r"""Sets the security_group_name of this ShowInstanceResp.

        **参数解释**： 安全组名称。 **取值范围**： 不涉及。

        :param security_group_name: The security_group_name of this ShowInstanceResp.
        :type security_group_name: str
        """
        self._security_group_name = security_group_name

    @property
    def subnet_id(self):
        r"""Gets the subnet_id of this ShowInstanceResp.

        **参数解释**： 子网ID。 **取值范围**： 不涉及。

        :return: The subnet_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._subnet_id

    @subnet_id.setter
    def subnet_id(self, subnet_id):
        r"""Sets the subnet_id of this ShowInstanceResp.

        **参数解释**： 子网ID。 **取值范围**： 不涉及。

        :param subnet_id: The subnet_id of this ShowInstanceResp.
        :type subnet_id: str
        """
        self._subnet_id = subnet_id

    @property
    def available_zones(self):
        r"""Gets the available_zones of this ShowInstanceResp.

        **参数解释**： 实例节点所在的可用区，返回“可用区ID”。

        :return: The available_zones of this ShowInstanceResp.
        :rtype: list[str]
        """
        return self._available_zones

    @available_zones.setter
    def available_zones(self, available_zones):
        r"""Sets the available_zones of this ShowInstanceResp.

        **参数解释**： 实例节点所在的可用区，返回“可用区ID”。

        :param available_zones: The available_zones of this ShowInstanceResp.
        :type available_zones: list[str]
        """
        self._available_zones = available_zones

    @property
    def available_zone_names(self):
        r"""Gets the available_zone_names of this ShowInstanceResp.

        **参数解释**： 实例节点所在的可用区名称，返回“可用区名称”。

        :return: The available_zone_names of this ShowInstanceResp.
        :rtype: list[str]
        """
        return self._available_zone_names

    @available_zone_names.setter
    def available_zone_names(self, available_zone_names):
        r"""Sets the available_zone_names of this ShowInstanceResp.

        **参数解释**： 实例节点所在的可用区名称，返回“可用区名称”。

        :param available_zone_names: The available_zone_names of this ShowInstanceResp.
        :type available_zone_names: list[str]
        """
        self._available_zone_names = available_zone_names

    @property
    def total_storage_space(self):
        r"""Gets the total_storage_space of this ShowInstanceResp.

        **参数解释**： 总共消息存储空间，单位：GB。 **取值范围**： 不涉及。

        :return: The total_storage_space of this ShowInstanceResp.
        :rtype: int
        """
        return self._total_storage_space

    @total_storage_space.setter
    def total_storage_space(self, total_storage_space):
        r"""Sets the total_storage_space of this ShowInstanceResp.

        **参数解释**： 总共消息存储空间，单位：GB。 **取值范围**： 不涉及。

        :param total_storage_space: The total_storage_space of this ShowInstanceResp.
        :type total_storage_space: int
        """
        self._total_storage_space = total_storage_space

    @property
    def public_connect_address(self):
        r"""Gets the public_connect_address of this ShowInstanceResp.

        **参数解释**： 实例公网连接IP地址。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。

        :return: The public_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._public_connect_address

    @public_connect_address.setter
    def public_connect_address(self, public_connect_address):
        r"""Sets the public_connect_address of this ShowInstanceResp.

        **参数解释**： 实例公网连接IP地址。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。

        :param public_connect_address: The public_connect_address of this ShowInstanceResp.
        :type public_connect_address: str
        """
        self._public_connect_address = public_connect_address

    @property
    def public_connect_domain_name(self):
        r"""Gets the public_connect_domain_name of this ShowInstanceResp.

        **参数解释**： 实例公网连接域名。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。

        :return: The public_connect_domain_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._public_connect_domain_name

    @public_connect_domain_name.setter
    def public_connect_domain_name(self, public_connect_domain_name):
        r"""Sets the public_connect_domain_name of this ShowInstanceResp.

        **参数解释**： 实例公网连接域名。当实例开启了公网访问，实例才包含该参数。 **取值范围**： 不涉及。

        :param public_connect_domain_name: The public_connect_domain_name of this ShowInstanceResp.
        :type public_connect_domain_name: str
        """
        self._public_connect_domain_name = public_connect_domain_name

    @property
    def storage_resource_id(self):
        r"""Gets the storage_resource_id of this ShowInstanceResp.

        **参数解释**： 存储资源ID。 **取值范围**： 不涉及。

        :return: The storage_resource_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._storage_resource_id

    @storage_resource_id.setter
    def storage_resource_id(self, storage_resource_id):
        r"""Sets the storage_resource_id of this ShowInstanceResp.

        **参数解释**： 存储资源ID。 **取值范围**： 不涉及。

        :param storage_resource_id: The storage_resource_id of this ShowInstanceResp.
        :type storage_resource_id: str
        """
        self._storage_resource_id = storage_resource_id

    @property
    def storage_spec_code(self):
        r"""Gets the storage_spec_code of this ShowInstanceResp.

        **参数解释**： IO规格。 **取值范围**： 不涉及。

        :return: The storage_spec_code of this ShowInstanceResp.
        :rtype: str
        """
        return self._storage_spec_code

    @storage_spec_code.setter
    def storage_spec_code(self, storage_spec_code):
        r"""Sets the storage_spec_code of this ShowInstanceResp.

        **参数解释**： IO规格。 **取值范围**： 不涉及。

        :param storage_spec_code: The storage_spec_code of this ShowInstanceResp.
        :type storage_spec_code: str
        """
        self._storage_spec_code = storage_spec_code

    @property
    def service_type(self):
        r"""Gets the service_type of this ShowInstanceResp.

        **参数解释**： 服务类型。 **取值范围**： advanced。

        :return: The service_type of this ShowInstanceResp.
        :rtype: str
        """
        return self._service_type

    @service_type.setter
    def service_type(self, service_type):
        r"""Sets the service_type of this ShowInstanceResp.

        **参数解释**： 服务类型。 **取值范围**： advanced。

        :param service_type: The service_type of this ShowInstanceResp.
        :type service_type: str
        """
        self._service_type = service_type

    @property
    def storage_type(self):
        r"""Gets the storage_type of this ShowInstanceResp.

        **参数解释**： 存储类型。 **取值范围**： hec

        :return: The storage_type of this ShowInstanceResp.
        :rtype: str
        """
        return self._storage_type

    @storage_type.setter
    def storage_type(self, storage_type):
        r"""Sets the storage_type of this ShowInstanceResp.

        **参数解释**： 存储类型。 **取值范围**： hec

        :param storage_type: The storage_type of this ShowInstanceResp.
        :type storage_type: str
        """
        self._storage_type = storage_type

    @property
    def retention_policy(self):
        r"""Gets the retention_policy of this ShowInstanceResp.

        **参数解释**： 消息老化策略。 **取值范围**： - time_base：表示自动删除最老消息。 - produce_reject：表示拒绝消息写入。

        :return: The retention_policy of this ShowInstanceResp.
        :rtype: str
        """
        return self._retention_policy

    @retention_policy.setter
    def retention_policy(self, retention_policy):
        r"""Sets the retention_policy of this ShowInstanceResp.

        **参数解释**： 消息老化策略。 **取值范围**： - time_base：表示自动删除最老消息。 - produce_reject：表示拒绝消息写入。

        :param retention_policy: The retention_policy of this ShowInstanceResp.
        :type retention_policy: str
        """
        self._retention_policy = retention_policy

    @property
    def kafka_public_status(self):
        r"""Gets the kafka_public_status of this ShowInstanceResp.

        **参数解释**： Kafka公网开启状态。 **取值范围**： - true：开启公网。 - closed：关闭公网。 - false：未使用公网。 - freezed：公网冻结。 - actived：公网解冻。

        :return: The kafka_public_status of this ShowInstanceResp.
        :rtype: str
        """
        return self._kafka_public_status

    @kafka_public_status.setter
    def kafka_public_status(self, kafka_public_status):
        r"""Sets the kafka_public_status of this ShowInstanceResp.

        **参数解释**： Kafka公网开启状态。 **取值范围**： - true：开启公网。 - closed：关闭公网。 - false：未使用公网。 - freezed：公网冻结。 - actived：公网解冻。

        :param kafka_public_status: The kafka_public_status of this ShowInstanceResp.
        :type kafka_public_status: str
        """
        self._kafka_public_status = kafka_public_status

    @property
    def public_bandwidth(self):
        r"""Gets the public_bandwidth of this ShowInstanceResp.

        **参数解释**： kafka公网访问带宽。 **取值范围**： 不涉及。

        :return: The public_bandwidth of this ShowInstanceResp.
        :rtype: int
        """
        return self._public_bandwidth

    @public_bandwidth.setter
    def public_bandwidth(self, public_bandwidth):
        r"""Sets the public_bandwidth of this ShowInstanceResp.

        **参数解释**： kafka公网访问带宽。 **取值范围**： 不涉及。

        :param public_bandwidth: The public_bandwidth of this ShowInstanceResp.
        :type public_bandwidth: int
        """
        self._public_bandwidth = public_bandwidth

    @property
    def enable_log_collection(self):
        r"""Gets the enable_log_collection of this ShowInstanceResp.

        **参数解释**： 是否开启消息收集功能。 **取值范围**： - true：开启 - false：不开启

        :return: The enable_log_collection of this ShowInstanceResp.
        :rtype: bool
        """
        return self._enable_log_collection

    @enable_log_collection.setter
    def enable_log_collection(self, enable_log_collection):
        r"""Sets the enable_log_collection of this ShowInstanceResp.

        **参数解释**： 是否开启消息收集功能。 **取值范围**： - true：开启 - false：不开启

        :param enable_log_collection: The enable_log_collection of this ShowInstanceResp.
        :type enable_log_collection: bool
        """
        self._enable_log_collection = enable_log_collection

    @property
    def new_auth_cert(self):
        r"""Gets the new_auth_cert of this ShowInstanceResp.

        **参数解释**： 是否开启新证书。 **取值范围**： - true：开启 - false：不开启

        :return: The new_auth_cert of this ShowInstanceResp.
        :rtype: bool
        """
        return self._new_auth_cert

    @new_auth_cert.setter
    def new_auth_cert(self, new_auth_cert):
        r"""Sets the new_auth_cert of this ShowInstanceResp.

        **参数解释**： 是否开启新证书。 **取值范围**： - true：开启 - false：不开启

        :param new_auth_cert: The new_auth_cert of this ShowInstanceResp.
        :type new_auth_cert: bool
        """
        self._new_auth_cert = new_auth_cert

    @property
    def cross_vpc_info(self):
        r"""Gets the cross_vpc_info of this ShowInstanceResp.

        **参数解释**： 跨VPC访问信息。 **取值范围**： 不涉及。

        :return: The cross_vpc_info of this ShowInstanceResp.
        :rtype: str
        """
        return self._cross_vpc_info

    @cross_vpc_info.setter
    def cross_vpc_info(self, cross_vpc_info):
        r"""Sets the cross_vpc_info of this ShowInstanceResp.

        **参数解释**： 跨VPC访问信息。 **取值范围**： 不涉及。

        :param cross_vpc_info: The cross_vpc_info of this ShowInstanceResp.
        :type cross_vpc_info: str
        """
        self._cross_vpc_info = cross_vpc_info

    @property
    def ipv6_enable(self):
        r"""Gets the ipv6_enable of this ShowInstanceResp.

        **参数解释**： 是否开启IPv6。 **取值范围**： - true：开启 - false：不开启

        :return: The ipv6_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._ipv6_enable

    @ipv6_enable.setter
    def ipv6_enable(self, ipv6_enable):
        r"""Sets the ipv6_enable of this ShowInstanceResp.

        **参数解释**： 是否开启IPv6。 **取值范围**： - true：开启 - false：不开启

        :param ipv6_enable: The ipv6_enable of this ShowInstanceResp.
        :type ipv6_enable: bool
        """
        self._ipv6_enable = ipv6_enable

    @property
    def ipv6_connect_addresses(self):
        r"""Gets the ipv6_connect_addresses of this ShowInstanceResp.

        **参数解释**： IPv6的连接地址。

        :return: The ipv6_connect_addresses of this ShowInstanceResp.
        :rtype: list[str]
        """
        return self._ipv6_connect_addresses

    @ipv6_connect_addresses.setter
    def ipv6_connect_addresses(self, ipv6_connect_addresses):
        r"""Sets the ipv6_connect_addresses of this ShowInstanceResp.

        **参数解释**： IPv6的连接地址。

        :param ipv6_connect_addresses: The ipv6_connect_addresses of this ShowInstanceResp.
        :type ipv6_connect_addresses: list[str]
        """
        self._ipv6_connect_addresses = ipv6_connect_addresses

    @property
    def connector_enable(self):
        r"""Gets the connector_enable of this ShowInstanceResp.

        **参数解释**： 是否开启转储。 **取值范围**： - true：开启 - false：不开启

        :return: The connector_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._connector_enable

    @connector_enable.setter
    def connector_enable(self, connector_enable):
        r"""Sets the connector_enable of this ShowInstanceResp.

        **参数解释**： 是否开启转储。 **取值范围**： - true：开启 - false：不开启

        :param connector_enable: The connector_enable of this ShowInstanceResp.
        :type connector_enable: bool
        """
        self._connector_enable = connector_enable

    @property
    def connector_node_num(self):
        r"""Gets the connector_node_num of this ShowInstanceResp.

        **参数解释**： connector节点数量。 **取值范围**： 2-16。

        :return: The connector_node_num of this ShowInstanceResp.
        :rtype: int
        """
        return self._connector_node_num

    @connector_node_num.setter
    def connector_node_num(self, connector_node_num):
        r"""Sets the connector_node_num of this ShowInstanceResp.

        **参数解释**： connector节点数量。 **取值范围**： 2-16。

        :param connector_node_num: The connector_node_num of this ShowInstanceResp.
        :type connector_node_num: int
        """
        self._connector_node_num = connector_node_num

    @property
    def connector_id(self):
        r"""Gets the connector_id of this ShowInstanceResp.

        **参数解释**： 转储任务ID。 **取值范围**： 不涉及。

        :return: The connector_id of this ShowInstanceResp.
        :rtype: str
        """
        return self._connector_id

    @connector_id.setter
    def connector_id(self, connector_id):
        r"""Sets the connector_id of this ShowInstanceResp.

        **参数解释**： 转储任务ID。 **取值范围**： 不涉及。

        :param connector_id: The connector_id of this ShowInstanceResp.
        :type connector_id: str
        """
        self._connector_id = connector_id

    @property
    def rest_enable(self):
        r"""Gets the rest_enable of this ShowInstanceResp.

        **参数解释**： 是否开启Kafka rest功能。 **取值范围**： - true：开启 - false：不开启

        :return: The rest_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._rest_enable

    @rest_enable.setter
    def rest_enable(self, rest_enable):
        r"""Sets the rest_enable of this ShowInstanceResp.

        **参数解释**： 是否开启Kafka rest功能。 **取值范围**： - true：开启 - false：不开启

        :param rest_enable: The rest_enable of this ShowInstanceResp.
        :type rest_enable: bool
        """
        self._rest_enable = rest_enable

    @property
    def rest_connect_address(self):
        r"""Gets the rest_connect_address of this ShowInstanceResp.

        **参数解释**：  Kafka rest连接地址。 **取值范围**： 不涉及。

        :return: The rest_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._rest_connect_address

    @rest_connect_address.setter
    def rest_connect_address(self, rest_connect_address):
        r"""Sets the rest_connect_address of this ShowInstanceResp.

        **参数解释**：  Kafka rest连接地址。 **取值范围**： 不涉及。

        :param rest_connect_address: The rest_connect_address of this ShowInstanceResp.
        :type rest_connect_address: str
        """
        self._rest_connect_address = rest_connect_address

    @property
    def public_boundwidth(self):
        r"""Gets the public_boundwidth of this ShowInstanceResp.

        **参数解释**： Kafka公网访问带宽。待删除版本。 **取值范围**： 不涉及。

        :return: The public_boundwidth of this ShowInstanceResp.
        :rtype: int
        """
        return self._public_boundwidth

    @public_boundwidth.setter
    def public_boundwidth(self, public_boundwidth):
        r"""Sets the public_boundwidth of this ShowInstanceResp.

        **参数解释**： Kafka公网访问带宽。待删除版本。 **取值范围**： 不涉及。

        :param public_boundwidth: The public_boundwidth of this ShowInstanceResp.
        :type public_boundwidth: int
        """
        self._public_boundwidth = public_boundwidth

    @property
    def message_query_inst_enable(self):
        r"""Gets the message_query_inst_enable of this ShowInstanceResp.

        **参数解释**： 是否开启消息查询功能。 **取值范围**： - true：开启 - false：不开启

        :return: The message_query_inst_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._message_query_inst_enable

    @message_query_inst_enable.setter
    def message_query_inst_enable(self, message_query_inst_enable):
        r"""Sets the message_query_inst_enable of this ShowInstanceResp.

        **参数解释**： 是否开启消息查询功能。 **取值范围**： - true：开启 - false：不开启

        :param message_query_inst_enable: The message_query_inst_enable of this ShowInstanceResp.
        :type message_query_inst_enable: bool
        """
        self._message_query_inst_enable = message_query_inst_enable

    @property
    def vpc_client_plain(self):
        r"""Gets the vpc_client_plain of this ShowInstanceResp.

        **参数解释**： 是否开启VPC明文访问。 **取值范围**： - true：开启 - false：不开启

        :return: The vpc_client_plain of this ShowInstanceResp.
        :rtype: bool
        """
        return self._vpc_client_plain

    @vpc_client_plain.setter
    def vpc_client_plain(self, vpc_client_plain):
        r"""Sets the vpc_client_plain of this ShowInstanceResp.

        **参数解释**： 是否开启VPC明文访问。 **取值范围**： - true：开启 - false：不开启

        :param vpc_client_plain: The vpc_client_plain of this ShowInstanceResp.
        :type vpc_client_plain: bool
        """
        self._vpc_client_plain = vpc_client_plain

    @property
    def support_features(self):
        r"""Gets the support_features of this ShowInstanceResp.

        **参数解释**： Kafka实例支持的特性功能。 **取值范围**： 不涉及。

        :return: The support_features of this ShowInstanceResp.
        :rtype: str
        """
        return self._support_features

    @support_features.setter
    def support_features(self, support_features):
        r"""Sets the support_features of this ShowInstanceResp.

        **参数解释**： Kafka实例支持的特性功能。 **取值范围**： 不涉及。

        :param support_features: The support_features of this ShowInstanceResp.
        :type support_features: str
        """
        self._support_features = support_features

    @property
    def trace_enable(self):
        r"""Gets the trace_enable of this ShowInstanceResp.

        **参数解释**： 是否开启消息轨迹功能。 **取值范围**： - true：开启 - false：不开启

        :return: The trace_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._trace_enable

    @trace_enable.setter
    def trace_enable(self, trace_enable):
        r"""Sets the trace_enable of this ShowInstanceResp.

        **参数解释**： 是否开启消息轨迹功能。 **取值范围**： - true：开启 - false：不开启

        :param trace_enable: The trace_enable of this ShowInstanceResp.
        :type trace_enable: bool
        """
        self._trace_enable = trace_enable

    @property
    def agent_enable(self):
        r"""Gets the agent_enable of this ShowInstanceResp.

        **参数解释**： 是否开启代理。 **取值范围**： - true：开启 - false：不开启

        :return: The agent_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._agent_enable

    @agent_enable.setter
    def agent_enable(self, agent_enable):
        r"""Sets the agent_enable of this ShowInstanceResp.

        **参数解释**： 是否开启代理。 **取值范围**： - true：开启 - false：不开启

        :param agent_enable: The agent_enable of this ShowInstanceResp.
        :type agent_enable: bool
        """
        self._agent_enable = agent_enable

    @property
    def pod_connect_address(self):
        r"""Gets the pod_connect_address of this ShowInstanceResp.

        **参数解释**： 租户侧连接地址。 **取值范围**： 不涉及。

        :return: The pod_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._pod_connect_address

    @pod_connect_address.setter
    def pod_connect_address(self, pod_connect_address):
        r"""Sets the pod_connect_address of this ShowInstanceResp.

        **参数解释**： 租户侧连接地址。 **取值范围**： 不涉及。

        :param pod_connect_address: The pod_connect_address of this ShowInstanceResp.
        :type pod_connect_address: str
        """
        self._pod_connect_address = pod_connect_address

    @property
    def disk_encrypted(self):
        r"""Gets the disk_encrypted of this ShowInstanceResp.

        **参数解释**： 是否开启磁盘加密。 **取值范围**： - true：开启 - false：不开启

        :return: The disk_encrypted of this ShowInstanceResp.
        :rtype: bool
        """
        return self._disk_encrypted

    @disk_encrypted.setter
    def disk_encrypted(self, disk_encrypted):
        r"""Sets the disk_encrypted of this ShowInstanceResp.

        **参数解释**： 是否开启磁盘加密。 **取值范围**： - true：开启 - false：不开启

        :param disk_encrypted: The disk_encrypted of this ShowInstanceResp.
        :type disk_encrypted: bool
        """
        self._disk_encrypted = disk_encrypted

    @property
    def disk_encrypted_key(self):
        r"""Gets the disk_encrypted_key of this ShowInstanceResp.

        **参数解释**： 磁盘加密key，未开启磁盘加密时为空。 **取值范围**： 不涉及。

        :return: The disk_encrypted_key of this ShowInstanceResp.
        :rtype: str
        """
        return self._disk_encrypted_key

    @disk_encrypted_key.setter
    def disk_encrypted_key(self, disk_encrypted_key):
        r"""Sets the disk_encrypted_key of this ShowInstanceResp.

        **参数解释**： 磁盘加密key，未开启磁盘加密时为空。 **取值范围**： 不涉及。

        :param disk_encrypted_key: The disk_encrypted_key of this ShowInstanceResp.
        :type disk_encrypted_key: str
        """
        self._disk_encrypted_key = disk_encrypted_key

    @property
    def kafka_private_connect_address(self):
        r"""Gets the kafka_private_connect_address of this ShowInstanceResp.

        **参数解释**： Kafka实例内网连接地址。 **取值范围**： 不涉及。

        :return: The kafka_private_connect_address of this ShowInstanceResp.
        :rtype: str
        """
        return self._kafka_private_connect_address

    @kafka_private_connect_address.setter
    def kafka_private_connect_address(self, kafka_private_connect_address):
        r"""Sets the kafka_private_connect_address of this ShowInstanceResp.

        **参数解释**： Kafka实例内网连接地址。 **取值范围**： 不涉及。

        :param kafka_private_connect_address: The kafka_private_connect_address of this ShowInstanceResp.
        :type kafka_private_connect_address: str
        """
        self._kafka_private_connect_address = kafka_private_connect_address

    @property
    def kafka_private_connect_domain_name(self):
        r"""Gets the kafka_private_connect_domain_name of this ShowInstanceResp.

        **参数解释**： Kafka实例内网连接域名。 **取值范围**： 不涉及。

        :return: The kafka_private_connect_domain_name of this ShowInstanceResp.
        :rtype: str
        """
        return self._kafka_private_connect_domain_name

    @kafka_private_connect_domain_name.setter
    def kafka_private_connect_domain_name(self, kafka_private_connect_domain_name):
        r"""Sets the kafka_private_connect_domain_name of this ShowInstanceResp.

        **参数解释**： Kafka实例内网连接域名。 **取值范围**： 不涉及。

        :param kafka_private_connect_domain_name: The kafka_private_connect_domain_name of this ShowInstanceResp.
        :type kafka_private_connect_domain_name: str
        """
        self._kafka_private_connect_domain_name = kafka_private_connect_domain_name

    @property
    def ces_version(self):
        r"""Gets the ces_version of this ShowInstanceResp.

        **参数解释**： 云监控版本。 **取值范围**： 不涉及。

        :return: The ces_version of this ShowInstanceResp.
        :rtype: str
        """
        return self._ces_version

    @ces_version.setter
    def ces_version(self, ces_version):
        r"""Sets the ces_version of this ShowInstanceResp.

        **参数解释**： 云监控版本。 **取值范围**： 不涉及。

        :param ces_version: The ces_version of this ShowInstanceResp.
        :type ces_version: str
        """
        self._ces_version = ces_version

    @property
    def public_access_enabled(self):
        r"""Gets the public_access_enabled of this ShowInstanceResp.

        **参数解释**： 区分实例什么时候开启的公网访问 **取值范围**： - true：已开启公网访问 - actived：已开启公网访问 - closed：已关闭公网访问 - false：已关闭公网访问

        :return: The public_access_enabled of this ShowInstanceResp.
        :rtype: str
        """
        return self._public_access_enabled

    @public_access_enabled.setter
    def public_access_enabled(self, public_access_enabled):
        r"""Sets the public_access_enabled of this ShowInstanceResp.

        **参数解释**： 区分实例什么时候开启的公网访问 **取值范围**： - true：已开启公网访问 - actived：已开启公网访问 - closed：已关闭公网访问 - false：已关闭公网访问

        :param public_access_enabled: The public_access_enabled of this ShowInstanceResp.
        :type public_access_enabled: str
        """
        self._public_access_enabled = public_access_enabled

    @property
    def node_num(self):
        r"""Gets the node_num of this ShowInstanceResp.

        **参数解释**： 节点数。 **取值范围**： - [1：Kafka单机实例的节点数。](tag:hws,hws_hk,hws_eu,dt,hcs,ax) - 3~50：Kafka集群实例的节点数。

        :return: The node_num of this ShowInstanceResp.
        :rtype: int
        """
        return self._node_num

    @node_num.setter
    def node_num(self, node_num):
        r"""Sets the node_num of this ShowInstanceResp.

        **参数解释**： 节点数。 **取值范围**： - [1：Kafka单机实例的节点数。](tag:hws,hws_hk,hws_eu,dt,hcs,ax) - 3~50：Kafka集群实例的节点数。

        :param node_num: The node_num of this ShowInstanceResp.
        :type node_num: int
        """
        self._node_num = node_num

    @property
    def port_protocols(self):
        r"""Gets the port_protocols of this ShowInstanceResp.

        :return: The port_protocols of this ShowInstanceResp.
        :rtype: :class:`huaweicloudsdkkafka.v2.PortProtocolsEntity`
        """
        return self._port_protocols

    @port_protocols.setter
    def port_protocols(self, port_protocols):
        r"""Sets the port_protocols of this ShowInstanceResp.

        :param port_protocols: The port_protocols of this ShowInstanceResp.
        :type port_protocols: :class:`huaweicloudsdkkafka.v2.PortProtocolsEntity`
        """
        self._port_protocols = port_protocols

    @property
    def enable_acl(self):
        r"""Gets the enable_acl of this ShowInstanceResp.

        **参数解释**： 是否开启访问控制。 **取值范围**： - true：开启 - false：不开启

        :return: The enable_acl of this ShowInstanceResp.
        :rtype: bool
        """
        return self._enable_acl

    @enable_acl.setter
    def enable_acl(self, enable_acl):
        r"""Sets the enable_acl of this ShowInstanceResp.

        **参数解释**： 是否开启访问控制。 **取值范围**： - true：开启 - false：不开启

        :param enable_acl: The enable_acl of this ShowInstanceResp.
        :type enable_acl: bool
        """
        self._enable_acl = enable_acl

    @property
    def new_spec_billing_enable(self):
        r"""Gets the new_spec_billing_enable of this ShowInstanceResp.

        **参数解释**： 是否启用新规格计费。 **取值范围**： - true：开启 - false：不开启

        :return: The new_spec_billing_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._new_spec_billing_enable

    @new_spec_billing_enable.setter
    def new_spec_billing_enable(self, new_spec_billing_enable):
        r"""Sets the new_spec_billing_enable of this ShowInstanceResp.

        **参数解释**： 是否启用新规格计费。 **取值范围**： - true：开启 - false：不开启

        :param new_spec_billing_enable: The new_spec_billing_enable of this ShowInstanceResp.
        :type new_spec_billing_enable: bool
        """
        self._new_spec_billing_enable = new_spec_billing_enable

    @property
    def broker_num(self):
        r"""Gets the broker_num of this ShowInstanceResp.

        **参数解释**： 节点数量。 **取值范围**： 不涉及。

        :return: The broker_num of this ShowInstanceResp.
        :rtype: int
        """
        return self._broker_num

    @broker_num.setter
    def broker_num(self, broker_num):
        r"""Sets the broker_num of this ShowInstanceResp.

        **参数解释**： 节点数量。 **取值范围**： 不涉及。

        :param broker_num: The broker_num of this ShowInstanceResp.
        :type broker_num: int
        """
        self._broker_num = broker_num

    @property
    def tags(self):
        r"""Gets the tags of this ShowInstanceResp.

        **参数解释**： 标签列表。

        :return: The tags of this ShowInstanceResp.
        :rtype: list[:class:`huaweicloudsdkkafka.v2.TagEntity`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this ShowInstanceResp.

        **参数解释**： 标签列表。

        :param tags: The tags of this ShowInstanceResp.
        :type tags: list[:class:`huaweicloudsdkkafka.v2.TagEntity`]
        """
        self._tags = tags

    @property
    def dr_enable(self):
        r"""Gets the dr_enable of this ShowInstanceResp.

        **参数解释**：  是否为容灾实例。 **取值范围**： - true：是容灾实例。 - false：不是容灾实例。

        :return: The dr_enable of this ShowInstanceResp.
        :rtype: bool
        """
        return self._dr_enable

    @dr_enable.setter
    def dr_enable(self, dr_enable):
        r"""Sets the dr_enable of this ShowInstanceResp.

        **参数解释**：  是否为容灾实例。 **取值范围**： - true：是容灾实例。 - false：不是容灾实例。

        :param dr_enable: The dr_enable of this ShowInstanceResp.
        :type dr_enable: bool
        """
        self._dr_enable = dr_enable

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowInstanceResp):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
