# -*- coding: utf-8 -*-
"""
# ---------------------------------------------------------------------------------------------------------
# ProjectName:  python-qdairlines-helper
# FileName:     exception_utils.py
# Description:  异常工具模块
# Author:       ASUS
# CreateDate:   2026/01/07
# Copyright ©2011-2026. Hunan xxxxxxx Company limited. All rights reserved.
# ---------------------------------------------------------------------------------------------------------
"""
from typing import Literal


class DuplicatePaymentError(Exception):
    def __init__(self, order_no: int):
        self.order_no = order_no
        super().__init__(f"订单<{order_no}>重复支付")


class NotEnoughTicketsError(Exception):
    def __init__(self, flight_no: str, seats_status: int, passengers: int):
        self.flight_no = flight_no
        self.seats_status = seats_status
        self.passengers = passengers
        super().__init__(f"青岛航空官网显示航班<{flight_no}>的余票<{seats_status}>少于乘客人数<{passengers}>")


class ExcessiveProfitdError(Exception):
    def __init__(
            self, flight_no: str, query_price: float, order_price: float, reduction_threshold: float,
            asset: Literal["票面价", "销售价"] = "票面价"
    ):
        self.flight_no = flight_no
        self.query_price = query_price
        self.order_price = order_price
        self.reduction_threshold = reduction_threshold
        self.asset = asset
        super().__init__(
            f"航班<{flight_no}>官网价：{query_price} 低于：订单{asset}[{order_price}] - 下降阈值[{reduction_threshold}]，收益过高"
        )


class ExcessiveLossesError(Exception):
    def __init__(
            self, flight_no: str, query_price: float, order_price: float, increase_threshold: float,
            asset: Literal["票面价", "销售价"] = "票面价"
    ):
        self.flight_no = flight_no
        self.query_price = query_price
        self.order_price = order_price
        self.increase_threshold = increase_threshold
        self.asset = asset
        super().__init__(
            f"航班<{flight_no}>官网价：{query_price} 高于：订单{asset}[{order_price}] + 上浮阈值[{increase_threshold}]，亏损太多"
        )


class PaymentChannelError(Exception):
    def __init__(self, channel_name: str):
        self.channel_name = channel_name
        super().__init__(f"支付渠道<{channel_name}>暂不支持")


class PaymentChannelMissError(Exception):
    def __init__(self):
        super().__init__(f"支付渠道参数丢失")


class PaymentTypeError(Exception):
    def __init__(self, payment_type: str):
        self.payment_type = payment_type
        super().__init__(f"付款方式<{payment_type}>暂不支持")


class PassengerTypeError(Exception):
    def __init__(self, passenger_type: str):
        self.passenger_type = passenger_type
        super().__init__(f"乘客类型<{passenger_type}>暂不支持")


class ProductTypeError(Exception):
    def __init__(self, product_type: str):
        self.product_type = product_type
        super().__init__(f"产品类型<{product_type}>暂不支持")


class HFPaymentTypeError(Exception):
    def __init__(self, payment_type: str):
        self.payment_type = payment_type
        super().__init__(f"汇付天下的付款方式<{payment_type}>暂不支持")


class PaymentFailedError(Exception):
    def __init__(self, pre_order_no: str, order_status: str):
        self.pre_order_no = pre_order_no
        self.order_status = order_status
        super().__init__(f"青岛航空官网订单<{pre_order_no}>支付失败，支付结束后的状态<{order_status}>")


class IPBlockError(Exception):

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)
