"""Web管理界面 - 旧版API路由（兼容）

注意：HTML管理界面已迁移到React前端 (/app/)
此文件保留API路由用于向后兼容
"""
import yaml
from pathlib import Path
from fastapi import APIRouter, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from typing import Dict, Any

router = APIRouter(prefix="/admin", tags=["admin"])

CONFIG_PATH = Path("config.yaml")

_handler = None
_scheduler = None
_config = None


def set_references(handler, scheduler, config: dict):
    global _handler, _scheduler, _config
    _handler = handler
    _scheduler = scheduler
    _config = config


def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    
    def convert_to_newlines(obj):
        if isinstance(obj, dict):
            return {k: convert_to_newlines(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_newlines(item) for item in obj]
        elif isinstance(obj, str) and '\\n' in obj:
            return obj.replace('\\n', '\n')
        return obj
    
    return convert_to_newlines(config)


# 默认忽略的 wxid（系统服务号，避免机器人与它们对话形成循环）
DEFAULT_IGNORE_WXIDS = [
    'qqsafe',           # QQ安全中心
    'weixin',           # 微信团队
    'filehelper',       # 文件传输助手
    'floatbottle',      # 漂流瓶
    'medianote',        # 语音记事本
    'newsapp',          # 腾讯新闻
]


def save_config(config: dict):
    def convert_newlines(obj):
        if isinstance(obj, dict):
            return {k: convert_newlines(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_newlines(item) for item in obj]
        elif isinstance(obj, str):
            text = obj.replace('\r\n', '\n').replace('\r', '')
            if '\n' in text:
                # 保留空行，只去除每行末尾空格
                lines = [line.rstrip() for line in text.split('\n')]
                return '\\n'.join(lines)
            return text
        return obj
    
    # 自动合并默认忽略列表
    if 'filter' not in config:
        config['filter'] = {}
    user_ignore = config['filter'].get('ignore_wxids', []) or []
    # 合并用户配置和默认列表，去重
    merged_ignore = list(set(user_ignore + DEFAULT_IGNORE_WXIDS))
    config['filter']['ignore_wxids'] = merged_ignore
    
    converted = convert_newlines(config)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        yaml.dump(converted, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def apply_config(config: dict):
    global _config
    _config = config
    
    if _handler:
        _handler.config = config
        rate_limit = config.get('rate_limit', {})
        _handler.min_interval = rate_limit.get('min_interval', 1)
        _handler.max_interval = rate_limit.get('max_interval', 3)
        filter_config = config.get("filter", {})
        # 合并默认忽略列表
        user_ignore = filter_config.get("ignore_wxids", []) or []
        _handler.ignore_wxids = list(set(user_ignore + DEFAULT_IGNORE_WXIDS))
        _handler.reply_at_all = filter_config.get("reply_at_all", False)
        
        split_config = config.get('message_split', {})
        _handler.split_enabled = split_config.get('enabled', False)
        _handler.split_separator = split_config.get('separator', '/!')
        _handler.split_min_delay = split_config.get('min_delay', 1)
        _handler.split_max_delay = split_config.get('max_delay', 3)
        _handler._image_cache_ttl = config.get('image_cache_ttl', 120)
    
    if _scheduler:
        _scheduler.config = config
        rate_limit = config.get('rate_limit', {})
        _scheduler.min_interval = rate_limit.get('min_interval', 2)
        _scheduler.max_interval = rate_limit.get('max_interval', 5)
        _scheduler.batch_delay = rate_limit.get('batch_delay', 30)
        _scheduler.scheduler.remove_all_jobs()
        _scheduler._setup_nickname_check_tasks()
        _scheduler._setup_scheduled_reminders()


@router.get("/api/config")
async def get_config():
    return load_config()


class ConfigUpdate(BaseModel):
    config: Dict[str, Any]


@router.post("/api/config")
async def update_config(data: ConfigUpdate):
    try:
        save_config(data.config)
        apply_config(data.config)
        return {"status": "ok", "message": "配置已保存并生效"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/api/status")
async def get_status():
    jobs = []
    if _scheduler and _scheduler.scheduler:
        for job in _scheduler.scheduler.get_jobs():
            next_run = None
            try:
                next_run = str(job.next_run_time) if hasattr(job, 'next_run_time') and job.next_run_time else None
            except:
                pass
            jobs.append({"id": job.id, "next_run": next_run})
    
    return {
        "robot_wxid": _scheduler.robot_wxid if _scheduler else None,
        "scheduled_jobs": jobs
    }


@router.get("/api/robot_info")
async def get_robot_info():
    """获取机器人自身信息"""
    import logging
    logger = logging.getLogger(__name__)
    
    if not _handler or not _handler.qianxun:
        logger.warning("robot_info: handler或qianxun未初始化")
        return {"wxid": "", "nickname": "", "error": "服务未初始化"}
    
    robot_wxid = _config.get('qianxun', {}).get('robot_wxid', '') if _config else ''
    if not robot_wxid and _scheduler:
        robot_wxid = _scheduler.robot_wxid or ''
    
    if not robot_wxid:
        logger.warning("robot_info: robot_wxid未配置")
        return {"wxid": "", "nickname": "", "error": "机器人wxid未配置"}
    
    try:
        info = await _handler.qianxun.get_self_info(robot_wxid)
        logger.info(f"robot_info: 获取到信息 {info}")
        if info:
            # 尝试多个可能的字段名
            nickname = info.get("nick") or info.get("nickname") or info.get("nickName") or info.get("name") or robot_wxid
            logger.info(f"robot_info: 解析昵称为 {nickname}")
            return {"wxid": robot_wxid, "nickname": nickname}
        logger.warning("robot_info: API返回空数据")
        return {"wxid": robot_wxid, "nickname": robot_wxid}
    except Exception as e:
        logger.error(f"robot_info: 异常 {e}", exc_info=True)
        return {"wxid": robot_wxid, "nickname": robot_wxid, "error": str(e)}


@router.get("/api/chatrooms")
async def get_chatrooms():
    """获取群聊列表"""
    if not _handler or not _handler.qianxun:
        return {"chatrooms": [], "error": "服务未初始化"}
    
    robot_wxid = _config.get('qianxun', {}).get('robot_wxid', '') if _config else ''
    if not robot_wxid and _scheduler:
        robot_wxid = _scheduler.robot_wxid or ''
    
    if not robot_wxid:
        return {"chatrooms": [], "error": "机器人wxid未配置"}
    
    try:
        chatrooms = await _handler.qianxun.get_chatroom_list(robot_wxid)
        return {"chatrooms": chatrooms}
    except Exception as e:
        return {"chatrooms": [], "error": str(e)}


@router.get("/api/friends")
async def get_friends():
    """获取好友列表"""
    if not _handler or not _handler.qianxun:
        return {"friends": [], "error": "服务未初始化"}
    
    robot_wxid = _config.get('qianxun', {}).get('robot_wxid', '') if _config else ''
    if not robot_wxid and _scheduler:
        robot_wxid = _scheduler.robot_wxid or ''
    
    if not robot_wxid:
        return {"friends": [], "error": "机器人wxid未配置"}
    
    try:
        friends = await _handler.qianxun.get_friend_list(robot_wxid)
        return {"friends": friends}
    except Exception as e:
        return {"friends": [], "error": str(e)}


@router.get("/api/group_members/{group_wxid}")
async def get_group_members(group_wxid: str):
    """获取群成员列表"""
    if not _handler or not _handler.qianxun:
        return {"members": [], "error": "服务未初始化"}
    
    robot_wxid = _config.get('qianxun', {}).get('robot_wxid', '') if _config else ''
    if not robot_wxid and _scheduler:
        robot_wxid = _scheduler.robot_wxid or ''
    
    if not robot_wxid:
        return {"members": [], "error": "机器人wxid未配置"}
    
    try:
        members = await _handler.qianxun.get_group_member_list(robot_wxid, group_wxid, get_nick=True)
        result = []
        for m in members:
            result.append({
                "wxid": m.get("wxid", ""),
                "nickname": m.get("groupNick", "") or m.get("nickname", "") or m.get("wxid", "")
            })
        return {"members": result}
    except Exception as e:
        return {"members": [], "error": str(e)}


@router.get("")
@router.get("/")
async def admin_page():
    """旧版管理界面入口 - 重定向到React前端"""
    return RedirectResponse(url="/app/")
