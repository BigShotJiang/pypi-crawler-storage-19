"""千寻框架API封装 - 带重试机制

重构版本：
- 添加 _request_with_retry() 方法（最多3次，延迟递增）
- 集成 TextProcessor（替换内联的换行符/emoji处理）
- 添加 update_api_url() 方法（配置热更新）
- 保持所有原有API方法签名不变
"""
import httpx
import logging
import base64
import json
import re
from typing import Optional

from ..utils.text_processor import TextProcessor

logger = logging.getLogger(__name__)


class QianXunClient:
    """千寻框架HTTP API客户端（带重试）"""
    
    def __init__(self, api_url: str, max_retries: int = 3, retry_delay: float = 1.0):
        """初始化千寻客户端
        
        Args:
            api_url: 千寻API地址，如 http://192.168.17.181:7777/qianxun/httpapi
            max_retries: 最大重试次数，默认3次
            retry_delay: 初始重试延迟（秒），默认1秒，每次递增
        """
        self.api_url = api_url.rstrip('/')
        # 提取基础URL用于下载文件
        # api_url: http://192.168.17.181:7777/qianxun/httpapi
        # base_url: http://192.168.17.181:7777
        self.base_url = '/'.join(api_url.split('/')[:3])
        self.client = httpx.AsyncClient(timeout=30.0)
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.text_processor = TextProcessor()
    
    def update_api_url(self, new_url: str):
        """更新API地址（配置热更新）
        
        Args:
            new_url: 新的API地址
        """
        self.api_url = new_url.rstrip('/')
        self.base_url = '/'.join(new_url.split('/')[:3])
        logger.info(f"千寻API地址已更新: {self.api_url}")

    async def _request_with_retry(
        self, 
        method: str, 
        url: str, 
        **kwargs
    ) -> httpx.Response:
        """带重试的HTTP请求
        
        Args:
            method: HTTP方法（GET/POST）
            url: 请求URL
            **kwargs: 传递给httpx的其他参数
            
        Returns:
            httpx.Response
            
        Raises:
            最后一次失败的异常
        """
        import asyncio
        
        last_error = None
        for attempt in range(self.max_retries):
            try:
                if method.upper() == 'GET':
                    resp = await self.client.get(url, **kwargs)
                else:
                    resp = await self.client.post(url, **kwargs)
                return resp
            except Exception as e:
                last_error = e
                if attempt < self.max_retries - 1:
                    # 递增延迟：1s, 2s, 3s...
                    delay = self.retry_delay * (attempt + 1)
                    logger.warning(f"请求失败 (尝试 {attempt + 1}/{self.max_retries})，{delay}秒后重试: {e}")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"请求失败，已达最大重试次数 ({self.max_retries}): {e}")
        
        raise last_error
    
    async def send_text(self, robot_wxid: str, to_wxid: str, msg: str) -> bool:
        """发送文本消息
        
        Args:
            robot_wxid: 机器人wxid
            to_wxid: 接收者wxid
            msg: 消息内容
            
        Returns:
            是否发送成功
        """
        try:
            # 使用 TextProcessor 处理换行符和emoji
            msg = self.text_processor.encode_for_qianxun(msg)
            
            payload = {
                "type": "sendText",
                "data": {
                    "wxid": to_wxid,
                    "msg": msg
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            # 千寻返回 code=200 表示成功
            if result.get("code") in (0, 200):
                logger.info(f"发送消息成功: {to_wxid}")
                return True
            else:
                logger.error(f"发送消息失败: {result}")
                return False
        except Exception as e:
            logger.error(f"发送消息异常: {e}")
            return False
    
    async def send_image(
        self, 
        robot_wxid: str, 
        to_wxid: str, 
        image_path: str,
        file_name: str = ""
    ) -> bool:
        """发送图片消息
        
        Args:
            robot_wxid: 机器人wxid
            to_wxid: 接收者wxid
            image_path: 图片路径（本地路径、网络直链或base64）
            file_name: 保存文件名（网络直链时必填）
            
        Returns:
            是否发送成功
        """
        try:
            # 如果是 Data URL 格式，提取纯 base64 数据
            # 格式: data:image/png;base64,xxxxx
            if image_path.startswith('data:'):
                # 去掉 data:image/xxx;base64, 前缀
                if ';base64,' in image_path:
                    image_path = image_path.split(';base64,')[1]
                elif ',' in image_path:
                    image_path = image_path.split(',')[1]
                # 添加 base64, 前缀（千寻框架需要）
                image_path = f"base64,{image_path}"
            
            payload = {
                "type": "sendImage",
                "data": {
                    "wxid": to_wxid,
                    "path": image_path,
                    "fileName": file_name
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            # 千寻返回 code=200 表示成功
            if result.get("code") in (0, 200):
                logger.info(f"发送图片成功: {to_wxid}")
                return True
            else:
                logger.error(f"发送图片失败: {result}")
                return False
        except Exception as e:
            logger.error(f"发送图片异常: {e}")
            return False

    async def send_file(
        self, 
        robot_wxid: str, 
        to_wxid: str, 
        file_path: str,
        file_name: str = ""
    ) -> bool:
        """发送文件
        
        Args:
            robot_wxid: 机器人wxid
            to_wxid: 接收者wxid
            file_path: 文件路径（本地路径、网络直链或base64）
            file_name: 保存文件名（网络直链/base64时必填）
            
        Returns:
            是否发送成功
        """
        try:
            # 如果是 Data URL 格式，提取纯 base64 数据
            # 格式: data:application/pdf;base64,xxxxx
            if file_path.startswith('data:'):
                # 去掉 data:xxx;base64, 前缀
                if ';base64,' in file_path:
                    file_path = file_path.split(';base64,')[1]
                elif ',' in file_path:
                    file_path = file_path.split(',')[1]
                # 添加 base64, 前缀（千寻框架需要）
                file_path = f"base64,{file_path}"
            
            # 处理文件名中的特殊字符（Windows 不允许的字符）
            # 替换空格和其他可能导致问题的字符
            if file_name:
                original_name = file_name
                # 替换 Windows 非法字符: \ / : * ? " < > |
                for char in ['\\', '/', ':', '*', '?', '"', '<', '>', '|']:
                    file_name = file_name.replace(char, '_')
                # 替换空格为下划线，避免编码问题
                file_name = file_name.replace(' ', '_')
                # 替换其他可能导致问题的 Unicode 字符
                # 只保留 ASCII 字符、中文字符和常见符号
                import re
                # 保留字母、数字、中文、下划线、点、横线
                file_name = re.sub(r'[^\w\u4e00-\u9fff.\-]', '_', file_name)
                if original_name != file_name:
                    logger.info(f"文件名已处理: {repr(original_name)} -> {repr(file_name)}")
            
            logger.info(f"发送文件: to={to_wxid}, fileName={repr(file_name)}")
            
            payload = {
                "type": "sendFile",
                "data": {
                    "wxid": to_wxid,
                    "path": file_path,
                    "fileName": file_name
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            if result.get("code") in (0, 200):
                logger.info(f"发送文件成功: {to_wxid}")
                return True
            else:
                logger.error(f"发送文件失败: {result}")
                return False
        except Exception as e:
            logger.error(f"发送文件异常: {e}")
            return False

    async def send_share_url(
        self, 
        robot_wxid: str, 
        to_wxid: str, 
        title: str,
        content: str,
        jump_url: str,
        thumb_path: str = "",
        app: str = ""
    ) -> bool:
        """发送分享链接
        
        Args:
            robot_wxid: 机器人wxid
            to_wxid: 接收者wxid
            title: 标题
            content: 内容描述
            jump_url: 点击跳转地址
            thumb_path: 缩略图路径（本地或网络直链）
            app: 小尾巴（如QQ浏览器为 wx64f9cf5b17af074d）
            
        Returns:
            是否发送成功
        """
        try:
            payload = {
                "type": "sendShareUrl",
                "data": {
                    "wxid": to_wxid,
                    "title": title,
                    "content": content,
                    "jumpUrl": jump_url,
                    "path": thumb_path,
                    "app": app
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            if result.get("code") in (0, 200):
                logger.info(f"发送分享链接成功: {to_wxid}")
                return True
            else:
                logger.error(f"发送分享链接失败: {result}")
                return False
        except Exception as e:
            logger.error(f"发送分享链接异常: {e}")
            return False

    async def send_applet(
        self, 
        robot_wxid: str, 
        to_wxid: str, 
        title: str,
        content: str,
        jump_path: str,
        gh: str,
        thumb_path: str = ""
    ) -> bool:
        """发送小程序
        
        Args:
            robot_wxid: 机器人wxid
            to_wxid: 接收者wxid
            title: 标题
            content: 内容描述
            jump_path: 点击跳转地址（如 pages/index/index.html）
            gh: 小程序gh（如饿了么为 gh_6506303a12bb）
            thumb_path: 缩略图路径（本地或网络直链）
            
        Returns:
            是否发送成功
        """
        try:
            payload = {
                "type": "sendApplet",
                "data": {
                    "wxid": to_wxid,
                    "title": title,
                    "content": content,
                    "jumpPath": jump_path,
                    "gh": gh,
                    "path": thumb_path
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            if result.get("code") in (0, 200):
                logger.info(f"发送小程序成功: {to_wxid}")
                return True
            else:
                logger.error(f"发送小程序失败: {result}")
                return False
        except Exception as e:
            logger.error(f"发送小程序异常: {e}")
            return False

    async def get_contact_info(self, robot_wxid: str, wxid: str) -> Optional[dict]:
        """获取联系人信息
        
        Args:
            robot_wxid: 机器人wxid
            wxid: 联系人wxid
            
        Returns:
            联系人信息字典，失败返回None
        """
        try:
            payload = {
                "type": "getContactInfo",
                "data": {
                    "wxid": wxid
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = json.loads(resp.text, strict=False)
            
            if result.get("code") in (0, 200):
                return result.get("result") or result.get("data")
            return None
        except Exception as e:
            logger.error(f"获取联系人信息异常: {e}")
            return None
    
    async def get_self_info(self, robot_wxid: str) -> Optional[dict]:
        """获取机器人自身信息
        
        Args:
            robot_wxid: 机器人wxid
            
        Returns:
            机器人信息字典，失败返回None
        """
        try:
            payload = {
                "type": "getSelfInfo",
                "data": {
                    "type": "2"  # 2=刷新缓存获取最新数据
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = json.loads(resp.text, strict=False)
            
            logger.info(f"获取机器人信息响应: {result}")
            
            if result.get("code") in (0, 200):
                data = result.get("result") or result.get("data")
                if data:
                    # 使用 TextProcessor 解码昵称中的 emoji
                    if data.get("nick"):
                        data["nick"] = self.text_processor.decode_emoji(data["nick"])
                    if data.get("nickname"):
                        data["nickname"] = self.text_processor.decode_emoji(data["nickname"])
                return data
            return None
        except Exception as e:
            logger.error(f"获取机器人信息异常: {e}", exc_info=True)
            return None
    
    async def close(self):
        """关闭客户端"""
        await self.client.aclose()
    
    async def get_contact_list(self, robot_wxid: str) -> list:
        """获取联系人列表（包括好友和群）
        
        Args:
            robot_wxid: 机器人wxid
            
        Returns:
            联系人列表，每个联系人包含 wxid, nickname 等信息
        """
        try:
            payload = {
                "type": "getContactList",
                "data": {}
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            result = resp.json()
            
            logger.debug(f"获取联系人列表响应: {result}")
            
            if result.get("code") in (0, 200):
                contacts = result.get("result", [])
                if not contacts:
                    contacts = result.get("data", [])
                logger.info(f"获取联系人列表: 共 {len(contacts)} 个")
                return contacts
            else:
                logger.error(f"获取联系人列表失败: {result}")
                return []
        except Exception as e:
            logger.error(f"获取联系人列表异常: {e}")
            return []

    async def get_chatroom_list(self, robot_wxid: str, refresh: bool = True) -> list:
        """获取群聊列表
        
        Args:
            robot_wxid: 机器人wxid
            refresh: 是否强制刷新缓存（默认True，确保获取最新数据）
            
        Returns:
            群聊列表，每个群包含 wxid, nickname 等信息
        """
        try:
            payload = {
                "type": "getGroupList",
                "data": {
                    "type": "2" if refresh else "1"  # 2=刷新缓存，1=从缓存获取
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            logger.info(f"请求群聊列表: {url}")
            resp = await self._request_with_retry('POST', url, json=payload)
            # 使用 strict=False 容忍非法控制字符（群名可能包含特殊字符）
            result = json.loads(resp.text, strict=False)
            
            logger.debug(f"获取群聊列表响应: {result}")
            
            if result.get("code") in (0, 200):
                chatrooms = result.get("result", [])
                # 格式化返回数据，统一字段名
                formatted = []
                for c in chatrooms:
                    nickname = c.get("nick", "") or c.get("wxid", "")
                    # 使用 TextProcessor 解码 emoji
                    nickname = self.text_processor.decode_emoji(nickname)
                    formatted.append({
                        "wxid": c.get("wxid", ""),
                        "nickname": nickname,
                        "memberCount": c.get("groupMemberNum", 0)
                    })
                logger.info(f"获取群聊列表: 共 {len(formatted)} 个群")
                return formatted
            else:
                logger.error(f"获取群聊列表失败: {result}")
                return []
        except Exception as e:
            logger.error(f"获取群聊列表异常: {e}", exc_info=True)
            return []
    
    async def get_friend_list(self, robot_wxid: str, refresh: bool = True) -> list:
        """获取好友列表
        
        Args:
            robot_wxid: 机器人wxid
            refresh: 是否强制刷新缓存
            
        Returns:
            好友列表，每个好友包含 wxid, nickname 等信息
        """
        try:
            payload = {
                "type": "getFriendList",
                "data": {
                    "type": "2" if refresh else "1"  # 2=刷新缓存，1=从缓存获取
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            # 使用 strict=False 容忍非法控制字符
            result = json.loads(resp.text, strict=False)
            
            logger.debug(f"获取好友列表响应: {result}")
            
            if result.get("code") in (0, 200):
                friends = result.get("result", [])
                # 格式化返回数据，统一字段名
                formatted = []
                for f in friends:
                    # 优先使用备注名，其次昵称
                    nickname = f.get("remark", "") or f.get("nick", "") or f.get("wxid", "")
                    # 使用 TextProcessor 解码 emoji
                    nickname = self.text_processor.decode_emoji(nickname)
                    formatted.append({
                        "wxid": f.get("wxid", ""),
                        "nickname": nickname
                    })
                logger.info(f"获取好友列表: 共 {len(formatted)} 个好友")
                return formatted
            else:
                logger.error(f"获取好友列表失败: {result}")
                return []
        except Exception as e:
            logger.error(f"获取好友列表异常: {e}", exc_info=True)
            return []

    async def get_group_member_list(
        self, 
        robot_wxid: str, 
        group_wxid: str, 
        get_nick: bool = True, 
        refresh: bool = False
    ) -> list:
        """获取群成员列表
        
        Args:
            robot_wxid: 机器人wxid
            group_wxid: 群wxid
            get_nick: 是否获取昵称
            refresh: 是否强制刷新缓存
            
        Returns:
            群成员列表，每个成员包含 wxid 和 groupNick
        """
        try:
            payload = {
                "type": "getMemberList",
                "data": {
                    "wxid": group_wxid,
                    "type": "2" if refresh else "1",  # 2=刷新缓存，1=从缓存获取
                    "getNick": "2" if get_nick else "1"
                }
            }
            url = f"{self.api_url}?wxid={robot_wxid}"
            resp = await self._request_with_retry('POST', url, json=payload)
            # 使用 strict=False 容忍非法控制字符
            result = json.loads(resp.text, strict=False)
            
            logger.debug(f"获取群成员列表响应: {result}")
            
            if result.get("code") in (0, 200):
                members = result.get("result", [])
                if not members:
                    members = result.get("data", [])
                # 使用 TextProcessor 解码昵称中的 emoji
                for m in members:
                    if m.get("groupNick"):
                        m["groupNick"] = self.text_processor.decode_emoji(m["groupNick"])
                    if m.get("nickname"):
                        m["nickname"] = self.text_processor.decode_emoji(m["nickname"])
                logger.info(f"获取群成员列表: {group_wxid}, 共 {len(members)} 人")
                return members
            else:
                logger.error(f"获取群成员列表失败: {result}")
                return []
        except Exception as e:
            logger.error(f"获取群成员列表异常: {e}", exc_info=True)
            return []

    async def download_image(self, image_path: str) -> Optional[str]:
        """下载图片并返回 base64 编码
        
        Args:
            image_path: 图片在千寻服务器上的完整路径
            
        Returns:
            base64 编码的图片数据，失败返回 None
        """
        try:
            # 使用千寻的文件下载 API
            url = f"{self.base_url}/qianxun/httpapi/file"
            params = {"path": image_path}
            
            logger.info(f"下载图片: {image_path}")
            resp = await self._request_with_retry('GET', url, params=params)
            
            if resp.status_code == 200:
                # 转换为 base64
                image_data = resp.content
                image_base64 = base64.b64encode(image_data).decode('utf-8')
                logger.info(f"图片下载成功，大小: {len(image_data)} bytes")
                return image_base64
            else:
                logger.error(f"下载图片失败: HTTP {resp.status_code}")
                return None
        except Exception as e:
            logger.error(f"下载图片异常: {e}")
            return None
    
    def parse_image_path(self, msg: str) -> Optional[str]:
        """从消息中解析图片路径
        
        Args:
            msg: 消息内容，格式如 [pic=C:\\path\\to\\image.jpg,isDecrypt=1]
            
        Returns:
            图片路径，解析失败返回 None
        """
        # 匹配 [pic=路径,isDecrypt=x] 格式
        match = re.search(r'\[pic=([^,\]]+)', msg)
        if match:
            return match.group(1)
        return None
    
    def get_image_url(self, image_path: str) -> str:
        """生成千寻图片下载URL
        
        Args:
            image_path: 图片在千寻服务器上的路径
            
        Returns:
            完整的图片下载URL
        """
        from urllib.parse import urlencode
        return f"{self.base_url}/qianxun/httpapi/file?{urlencode({'path': image_path})}"
    
    def parse_voice_info(self, xml_content: str) -> Optional[dict]:
        """从XML消息中解析语音信息
        
        Args:
            xml_content: 语音消息的XML内容
            
        Returns:
            语音信息字典，包含 voicelength 等，解析失败返回 None
        """
        try:
            import xml.etree.ElementTree as ET
            root = ET.fromstring(xml_content)
            voicemsg = root.find('voicemsg')
            if voicemsg is not None:
                return {
                    'voicelength': int(voicemsg.get('voicelength', 0)),
                }
            return None
        except Exception as e:
            logger.error(f"解析语音XML失败: {e}")
            return None
