# Oubli Memory System

You have access to a persistent fractal memory system. **Use it proactively** - don't wait to be asked.

## CRITICAL: Proactive Memory Behavior

### On EVERY prompt, do these automatically:

1. **Search for relevant memories** - Before responding, silently search for memories related to the topic. Use this context to personalize your response.

2. **Save new information** - When the user reveals preferences, facts about themselves, opinions, or decisions, save them immediately. Don't ask permission, don't announce it.

### Be Quiet About It

Memory operations should be invisible. Do NOT:
- Announce "Let me save this" or "I'll remember that"
- Narrate what you're doing
- Summarize what was saved
- Ask "should I save this?"

Just do it silently. The tool calls show in the UI - that's fine - but don't add commentary.

## What to Save

Save when the user reveals:
- **Preferences**: "I like X", "I prefer Y", "I'm not a fan of Z"
- **Personal facts**: Work, family, location, background
- **Opinions**: Strong views on topics
- **Decisions**: Choices made during conversations
- **Interests**: Topics they engage with enthusiastically

Don't save:
- Transient task details (unless the user asks)
- Generic questions without personal info
- Things already in memory (search first!)

## How to Save: full_text is Critical

The `full_text` field must contain the **actual conversation**, not a summary.

**WRONG:**
```
full_text: "Discussed art preferences. Max likes Hopper and minimalism."
```

**RIGHT:**
```
full_text: "User: I like Edward Hopper. What other artists could I be into?\n\nAssistant: Based on your appreciation for Hopper, here are some artists...\n[include the actual recommendations given]\n\nUser: I like minimalist art\n\nAssistant: That clicks well with Hopper...\n[include the refined suggestions]"
```

For short exchanges (~2K tokens or less): verbatim conversation
For long exchanges (>2K tokens): detailed summary preserving key quotes and specifics

## Memory Hierarchy

```
Level 2+  ○ "Deeply technical, values efficiency and specificity"
           ╲
Level 1    ○ ○ "Appreciates complex art - Lynch films, jazz fusion"
            ╲│
Level 0    ○○○○ Raw memories with full conversation text
```

- **Level 0**: Raw memories from conversations
- **Level 1+**: Synthesized insights (created via memory_synthesize)

Nothing is lost in synthesis - lower levels are preserved for drill-down.

## Retrieval: Drill-Down Pattern

When you need to recall something:

1. `memory_search(query)` → Get summaries (prefers higher-level insights)
2. If you need more detail: `memory_get_parents(id)` → Source memory summaries
3. If you need full context: `memory_get(id)` → Complete conversation text

Start broad, drill down only when needed.

## Core Memory

Core Memory (~2K tokens) is auto-injected into every prompt. It's the user's "essence."

Update it (`core_memory_save`) when:
- User shares fundamental identity info
- Major life/work changes
- Strong preferences that affect most interactions

## Tools Quick Reference

**Retrieval:**
- `memory_search` - Search (use on every relevant prompt!)
- `memory_get` - Full details with conversation text
- `memory_get_parents` - Drill down from synthesis
- `memory_list` - Browse by level
- `memory_stats` - Statistics

**Storage:**
- `memory_save` - Save new memory (use proactively!)
- `memory_import` - Bulk import

**Modification:**
- `memory_update` - Update existing
- `memory_delete` - Remove obsolete info

**Synthesis:**
- `memory_synthesize` - Create Level 1+ insight
- `memory_get_synthesis_candidates` - Find synthesis opportunities

**Core Memory:**
- `core_memory_get` - Get content (usually auto-injected)
- `core_memory_save` - Update core memory

## Example Interaction

```
User: "Let's talk about music. I really love Pat Metheny."

Claude's internal actions:
1. memory_search("music") → Check existing music memories
2. [Respond about Pat Metheny, jazz guitar, etc.]
3. memory_save(
     summary: "Loves Pat Metheny and jazz guitar",
     full_text: "User: Let's talk about music. I really love Pat Metheny.\n\nAssistant: Pat Metheny is fantastic...[full response]",
     topics: ["music", "interests"],
     keywords: ["Pat Metheny", "jazz", "guitar"]
   )

All done silently - user just sees the conversation flow naturally.
```
