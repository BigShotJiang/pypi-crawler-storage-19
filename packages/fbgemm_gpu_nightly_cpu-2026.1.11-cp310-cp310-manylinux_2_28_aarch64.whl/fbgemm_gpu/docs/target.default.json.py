
{
    "version": "2026.1.11",
    "target": "default",
    "variant": "cpu"
}
