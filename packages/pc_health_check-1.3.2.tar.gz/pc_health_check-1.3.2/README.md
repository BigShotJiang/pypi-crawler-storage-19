## 🚀 Instalación

```bash
pip install pc-health-check
```

---

## 📖 Uso

### Ejecutar el monitor
```bash
pc-health-check
```


## ✨ Características

- **Monitor de recursos**: Visualiza CPU, RAM, Disco y más

## 🖥️ Sistemas Operativos Soportados

| Sistema | Versión Mínima |
|---------|----------------|
| Windows | 10+ |
| macOS | 10.14+ |
| Linux | Ubuntu 18.04+, Debian 10+ |

—

## 📋 Requisitos

- Python 3.7 o superior
- Conexión a Internet

