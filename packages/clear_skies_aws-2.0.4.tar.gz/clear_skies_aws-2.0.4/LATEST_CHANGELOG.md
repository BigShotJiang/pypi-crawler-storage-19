## [2.0.4] - 2026-01-09

### Added
- Add rds mysql cursor

### Changed
- Use the port forwarder class in [#8](https://github.com/clearskies-py/aws/pull/8)

### Fixed
- Make age dynamic instead of fixed

