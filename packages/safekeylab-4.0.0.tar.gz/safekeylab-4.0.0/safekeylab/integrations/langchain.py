"""
SafeKeyLab LangChain Integration

Provides seamless PII protection for LangChain applications:
- Callback handlers for automatic input/output protection
- Tools for agent-based PII detection
- Chain wrappers for transparent protection
- Retriever wrappers for RAG security

Requirements:
    pip install langchain langchain-core safekeylab

Example:
    from langchain_openai import ChatOpenAI
    from safekeylab.integrations.langchain import SafeKeyLabCallbackHandler

    # Automatic PII protection for all LLM calls
    handler = SafeKeyLabCallbackHandler(api_key="sk_live_xxx")
    llm = ChatOpenAI(callbacks=[handler])

    response = llm.invoke("My SSN is 123-45-6789")
    # Input is automatically sanitized before sending to OpenAI
"""

import os
import logging
from typing import Any, Dict, List, Optional, Union, Callable
from functools import wraps

# Import SafeKey Lab client
from ..unified_client import SafeKeyClient
from ..result_types import ProtectionResult, DetectionResult

logger = logging.getLogger(__name__)


# =============================================================================
# LangChain Callback Handler
# =============================================================================

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
    from langchain_core.outputs import LLMResult
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
    BaseCallbackHandler = object  # Fallback for type hints


class SafeKeyLabCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback handler for automatic PII protection.

    Intercepts LLM inputs and outputs to detect and redact PII.
    Works with any LangChain LLM (OpenAI, Anthropic, etc.).

    Example:
        from langchain_openai import ChatOpenAI
        from safekeylab.integrations.langchain import SafeKeyLabCallbackHandler

        handler = SafeKeyLabCallbackHandler(api_key="sk_live_xxx")
        llm = ChatOpenAI(callbacks=[handler])

        # All inputs are automatically protected
        response = llm.invoke("Contact john@example.com")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        client: Optional[SafeKeyClient] = None,
        protect_input: bool = True,
        protect_output: bool = True,
        log_detections: bool = True,
        raise_on_pii: bool = False,
        entities: Optional[List[str]] = None,
        redaction_type: str = "mask",
    ):
        """
        Initialize the callback handler.

        Args:
            api_key: SafeKey Lab API key (or set SAFEKEYLAB_API_KEY env var)
            client: Pre-configured SafeKeyClient instance
            protect_input: Whether to protect PII in inputs
            protect_output: Whether to scan/protect PII in outputs
            log_detections: Whether to log PII detections
            raise_on_pii: Whether to raise an exception if PII is detected
            entities: List of entity types to detect (default: common PII)
            redaction_type: How to redact - "mask", "hash", "partial", "remove"
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain is required for this integration. "
                "Install with: pip install langchain langchain-core"
            )

        super().__init__()

        if client is None:
            key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
            if not key:
                raise ValueError(
                    "API key required. Pass api_key or set SAFEKEYLAB_API_KEY env var"
                )
            client = SafeKeyClient(api_key=key)

        self.client = client
        self.protect_input = protect_input
        self.protect_output = protect_output
        self.log_detections = log_detections
        self.raise_on_pii = raise_on_pii
        self.redaction_type = redaction_type
        self.entities = entities or [
            "EMAIL", "PHONE", "SSN", "CREDIT_CARD", "NAME",
            "ADDRESS", "DATE_OF_BIRTH", "API_KEY", "PASSWORD"
        ]

        # Statistics
        self.total_inputs_processed = 0
        self.total_outputs_processed = 0
        self.total_pii_detected = 0
        self.pii_by_type: Dict[str, int] = {}

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs: Any,
    ) -> None:
        """Process prompts before sending to LLM."""
        if not self.protect_input:
            return

        for i, prompt in enumerate(prompts):
            self.total_inputs_processed += 1
            result = self.client.protect(prompt, config={
                "entities": self.entities,
                "redaction_type": self.redaction_type
            })

            if result.has_pii:
                self.total_pii_detected += len(result.entities)
                for entity in result.entities:
                    self.pii_by_type[entity.type] = self.pii_by_type.get(entity.type, 0) + 1

                if self.log_detections:
                    logger.warning(
                        f"PII detected in LLM input: {result.entity_types} "
                        f"({result.entity_count} entities)"
                    )

                if self.raise_on_pii:
                    raise PIIDetectedError(
                        f"PII detected in input: {result.entity_types}",
                        entities=result.entities
                    )

                # Replace the prompt with the protected version
                prompts[i] = result.redacted

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        """Process chat messages before sending to LLM."""
        if not self.protect_input:
            return

        for message_list in messages:
            for message in message_list:
                if hasattr(message, 'content') and isinstance(message.content, str):
                    self.total_inputs_processed += 1
                    result = self.client.protect(message.content, config={
                        "entities": self.entities,
                        "redaction_type": self.redaction_type
                    })

                    if result.has_pii:
                        self.total_pii_detected += len(result.entities)
                        for entity in result.entities:
                            self.pii_by_type[entity.type] = self.pii_by_type.get(entity.type, 0) + 1

                        if self.log_detections:
                            logger.warning(
                                f"PII detected in chat message: {result.entity_types}"
                            )

                        if self.raise_on_pii:
                            raise PIIDetectedError(
                                f"PII detected in message: {result.entity_types}",
                                entities=result.entities
                            )

                        # Update message content
                        message.content = result.redacted

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Process LLM output for PII detection."""
        if not self.protect_output:
            return

        for generations in response.generations:
            for generation in generations:
                if hasattr(generation, 'text') and generation.text:
                    self.total_outputs_processed += 1
                    result = self.client.detect(generation.text, config={
                        "entities": self.entities
                    })

                    if result.has_pii:
                        self.total_pii_detected += len(result.entities)
                        for entity in result.entities:
                            self.pii_by_type[entity.type] = self.pii_by_type.get(entity.type, 0) + 1

                        if self.log_detections:
                            logger.warning(
                                f"PII detected in LLM output: {result.entity_types}"
                            )

                        # Optionally redact output
                        protected = self.client.protect(generation.text, config={
                            "entities": self.entities,
                            "redaction_type": self.redaction_type
                        })
                        generation.text = protected.redacted

    def get_statistics(self) -> Dict[str, Any]:
        """Get PII detection statistics."""
        return {
            "total_inputs_processed": self.total_inputs_processed,
            "total_outputs_processed": self.total_outputs_processed,
            "total_pii_detected": self.total_pii_detected,
            "pii_by_type": self.pii_by_type,
        }

    def reset_statistics(self) -> None:
        """Reset detection statistics."""
        self.total_inputs_processed = 0
        self.total_outputs_processed = 0
        self.total_pii_detected = 0
        self.pii_by_type = {}


# =============================================================================
# LangChain Tools
# =============================================================================

try:
    from langchain_core.tools import BaseTool, tool
    from pydantic import BaseModel, Field
    LANGCHAIN_TOOLS_AVAILABLE = True
except ImportError:
    LANGCHAIN_TOOLS_AVAILABLE = False
    BaseTool = object
    BaseModel = object


class PIIProtectionInput(BaseModel):
    """Input schema for PII protection tool."""
    text: str = Field(description="The text to scan and protect from PII")


class PIIDetectionInput(BaseModel):
    """Input schema for PII detection tool."""
    text: str = Field(description="The text to scan for PII")


class SafeKeyLabPIIProtectionTool(BaseTool):
    """
    LangChain tool for PII detection and redaction.

    Use this tool in agents to protect sensitive data.

    Example:
        from langchain.agents import initialize_agent, AgentType
        from langchain_openai import ChatOpenAI
        from safekeylab.integrations.langchain import SafeKeyLabPIIProtectionTool

        tool = SafeKeyLabPIIProtectionTool(api_key="sk_live_xxx")
        agent = initialize_agent(
            tools=[tool],
            llm=ChatOpenAI(),
            agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION
        )
    """

    name: str = "pii_protection"
    description: str = (
        "Detect and redact PII (personally identifiable information) from text. "
        "Use this tool to sanitize user input or any text that might contain "
        "sensitive data like emails, phone numbers, SSNs, credit cards, or API keys."
    )
    args_schema: type = PIIProtectionInput

    client: SafeKeyClient = None
    entities: List[str] = None
    redaction_type: str = "mask"

    def __init__(
        self,
        api_key: Optional[str] = None,
        client: Optional[SafeKeyClient] = None,
        entities: Optional[List[str]] = None,
        redaction_type: str = "mask",
        **kwargs
    ):
        if not LANGCHAIN_TOOLS_AVAILABLE:
            raise ImportError("LangChain tools require: pip install langchain-core pydantic")

        super().__init__(**kwargs)

        if client is None:
            key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
            if not key:
                raise ValueError("API key required")
            client = SafeKeyClient(api_key=key)

        self.client = client
        self.entities = entities or [
            "EMAIL", "PHONE", "SSN", "CREDIT_CARD", "NAME",
            "ADDRESS", "API_KEY", "PASSWORD"
        ]
        self.redaction_type = redaction_type

    def _run(self, text: str) -> str:
        """Protect PII in the given text."""
        result = self.client.protect(text, config={
            "entities": self.entities,
            "redaction_type": self.redaction_type
        })

        if result.has_pii:
            return (
                f"Protected text: {result.redacted}\n"
                f"Found {result.entity_count} PII entities: {result.entity_types}"
            )
        return f"No PII detected. Original text: {text}"

    async def _arun(self, text: str) -> str:
        """Async version of _run."""
        # For now, use sync client
        return self._run(text)


class SafeKeyLabPIIDetectionTool(BaseTool):
    """
    LangChain tool for PII detection (without redaction).

    Use this tool to check if text contains PII without modifying it.
    """

    name: str = "pii_detection"
    description: str = (
        "Detect if text contains PII (personally identifiable information) "
        "without modifying it. Returns a report of what PII was found."
    )
    args_schema: type = PIIDetectionInput

    client: SafeKeyClient = None
    entities: List[str] = None

    def __init__(
        self,
        api_key: Optional[str] = None,
        client: Optional[SafeKeyClient] = None,
        entities: Optional[List[str]] = None,
        **kwargs
    ):
        if not LANGCHAIN_TOOLS_AVAILABLE:
            raise ImportError("LangChain tools require: pip install langchain-core pydantic")

        super().__init__(**kwargs)

        if client is None:
            key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
            if not key:
                raise ValueError("API key required")
            client = SafeKeyClient(api_key=key)

        self.client = client
        self.entities = entities or [
            "EMAIL", "PHONE", "SSN", "CREDIT_CARD", "NAME",
            "ADDRESS", "API_KEY", "PASSWORD"
        ]

    def _run(self, text: str) -> str:
        """Detect PII in the given text."""
        result = self.client.detect(text, config={
            "entities": self.entities
        })

        if result.has_pii:
            entities_info = ", ".join(
                f"{e.type} (confidence: {e.confidence:.2f})"
                for e in result.entities
            )
            return f"PII DETECTED: {entities_info}"
        return "No PII detected in the text."

    async def _arun(self, text: str) -> str:
        """Async version of _run."""
        return self._run(text)


# =============================================================================
# Functional Tool Decorators
# =============================================================================

def create_pii_protection_tool(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
) -> Callable:
    """
    Create a LangChain @tool decorated function for PII protection.

    Example:
        from safekeylab.integrations.langchain import create_pii_protection_tool

        protect_pii = create_pii_protection_tool(api_key="sk_live_xxx")

        # Use with agents
        agent = create_react_agent(llm, [protect_pii])
    """
    if not LANGCHAIN_TOOLS_AVAILABLE:
        raise ImportError("LangChain tools require: pip install langchain-core")

    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    @tool
    def protect_pii(text: str) -> str:
        """
        Detect and redact PII from text.

        Use this to sanitize any text that might contain sensitive
        information like emails, phone numbers, SSNs, or API keys.

        Args:
            text: The text to scan and protect

        Returns:
            Protected text with PII redacted, plus detection summary
        """
        result = client.protect(text)

        if result.has_pii:
            return (
                f"Protected: {result.redacted}\n"
                f"Detected: {result.entity_types}"
            )
        return f"No PII found: {text}"

    return protect_pii


def create_secret_detection_tool(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
) -> Callable:
    """
    Create a LangChain @tool for detecting secrets in code.

    Example:
        from safekeylab.integrations.langchain import create_secret_detection_tool

        detect_secrets = create_secret_detection_tool(api_key="sk_live_xxx")
    """
    if not LANGCHAIN_TOOLS_AVAILABLE:
        raise ImportError("LangChain tools require: pip install langchain-core")

    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    secret_entities = [
        "API_KEY", "AWS_ACCESS_KEY", "AWS_SECRET_KEY", "PRIVATE_KEY",
        "PASSWORD", "CONNECTION_STRING", "JWT_TOKEN", "OAUTH_TOKEN"
    ]

    @tool
    def detect_secrets(code: str) -> str:
        """
        Scan code for hardcoded secrets and credentials.

        Use this to check generated code before outputting it.
        Detects API keys, passwords, private keys, and other secrets.

        Args:
            code: The code or text to scan for secrets

        Returns:
            Report of any secrets found, or confirmation that code is clean
        """
        result = client.protect(code, config={
            "entities": secret_entities,
            "redaction_type": "mask"
        })

        if result.has_pii:
            return (
                f"SECRETS FOUND! {result.entity_count} secrets detected.\n"
                f"Types: {result.entity_types}\n"
                f"Safe version:\n{result.redacted}"
            )
        return "No secrets detected. Code is clean."

    return detect_secrets


# =============================================================================
# Chain Wrappers
# =============================================================================

try:
    from langchain_core.runnables import RunnablePassthrough, RunnableLambda
    from langchain_core.language_models import BaseLanguageModel
    LANGCHAIN_RUNNABLES_AVAILABLE = True
except ImportError:
    LANGCHAIN_RUNNABLES_AVAILABLE = False


def create_protected_chain(
    chain: Any,
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
    protect_input: bool = True,
    protect_output: bool = True,
) -> Any:
    """
    Wrap a LangChain chain with automatic PII protection.

    Example:
        from langchain_openai import ChatOpenAI
        from langchain_core.prompts import ChatPromptTemplate
        from safekeylab.integrations.langchain import create_protected_chain

        prompt = ChatPromptTemplate.from_template("Summarize: {text}")
        llm = ChatOpenAI()
        chain = prompt | llm

        # Wrap with PII protection
        protected_chain = create_protected_chain(chain, api_key="sk_live_xxx")

        # Inputs are automatically sanitized
        result = protected_chain.invoke({"text": "John's SSN is 123-45-6789"})
    """
    if not LANGCHAIN_RUNNABLES_AVAILABLE:
        raise ImportError("Runnables require: pip install langchain-core")

    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    def protect_inputs(inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Protect PII in all string inputs."""
        protected = {}
        for key, value in inputs.items():
            if isinstance(value, str):
                result = client.protect(value)
                protected[key] = result.redacted
            else:
                protected[key] = value
        return protected

    def protect_output(output: Any) -> Any:
        """Protect PII in output."""
        if isinstance(output, str):
            result = client.protect(output)
            return result.redacted
        elif hasattr(output, 'content') and isinstance(output.content, str):
            result = client.protect(output.content)
            output.content = result.redacted
        return output

    # Build protected chain
    protected = chain

    if protect_input:
        protected = RunnableLambda(protect_inputs) | protected

    if protect_output:
        protected = protected | RunnableLambda(protect_output)

    return protected


# =============================================================================
# Retriever Wrapper for RAG Security
# =============================================================================

try:
    from langchain_core.retrievers import BaseRetriever
    from langchain_core.documents import Document
    LANGCHAIN_RETRIEVERS_AVAILABLE = True
except ImportError:
    LANGCHAIN_RETRIEVERS_AVAILABLE = False
    BaseRetriever = object
    Document = object


class SafeKeyLabRetrieverWrapper:
    """
    Wrapper for LangChain retrievers that protects PII in retrieved documents.

    Use this to ensure RAG pipelines don't leak PII from your knowledge base.

    Example:
        from langchain_community.vectorstores import Chroma
        from safekeylab.integrations.langchain import SafeKeyLabRetrieverWrapper

        vectorstore = Chroma(...)
        retriever = vectorstore.as_retriever()

        # Wrap with PII protection
        safe_retriever = SafeKeyLabRetrieverWrapper(
            retriever=retriever,
            api_key="sk_live_xxx"
        )

        # Retrieved documents will have PII redacted
        docs = safe_retriever.invoke("query")
    """

    def __init__(
        self,
        retriever: BaseRetriever,
        api_key: Optional[str] = None,
        client: Optional[SafeKeyClient] = None,
        protect_content: bool = True,
        protect_metadata: bool = False,
        log_detections: bool = True,
    ):
        if not LANGCHAIN_RETRIEVERS_AVAILABLE:
            raise ImportError("Retrievers require: pip install langchain-core")

        if client is None:
            key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
            if not key:
                raise ValueError("API key required")
            client = SafeKeyClient(api_key=key)

        self.retriever = retriever
        self.client = client
        self.protect_content = protect_content
        self.protect_metadata = protect_metadata
        self.log_detections = log_detections

    def invoke(self, query: str, **kwargs) -> List[Document]:
        """Retrieve documents and protect PII."""
        docs = self.retriever.invoke(query, **kwargs)
        return self._protect_documents(docs)

    def get_relevant_documents(self, query: str, **kwargs) -> List[Document]:
        """Retrieve documents and protect PII (legacy method)."""
        docs = self.retriever.get_relevant_documents(query, **kwargs)
        return self._protect_documents(docs)

    def _protect_documents(self, docs: List[Document]) -> List[Document]:
        """Protect PII in a list of documents."""
        protected_docs = []

        for doc in docs:
            protected_content = doc.page_content
            protected_metadata = doc.metadata.copy() if doc.metadata else {}

            if self.protect_content:
                result = self.client.protect(doc.page_content)
                if result.has_pii and self.log_detections:
                    logger.warning(
                        f"PII detected in retrieved document: {result.entity_types}"
                    )
                protected_content = result.redacted

            if self.protect_metadata:
                for key, value in protected_metadata.items():
                    if isinstance(value, str):
                        result = self.client.protect(value)
                        protected_metadata[key] = result.redacted

            protected_docs.append(Document(
                page_content=protected_content,
                metadata=protected_metadata
            ))

        return protected_docs


# =============================================================================
# Exceptions
# =============================================================================

class PIIDetectedError(Exception):
    """Raised when PII is detected and raise_on_pii is True."""

    def __init__(self, message: str, entities: List = None):
        super().__init__(message)
        self.entities = entities or []


# =============================================================================
# Convenience Functions
# =============================================================================

def get_langchain_tools(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
) -> List:
    """
    Get all SafeKeyLab LangChain tools.

    Example:
        from safekeylab.integrations.langchain import get_langchain_tools

        tools = get_langchain_tools(api_key="sk_live_xxx")
        agent = create_react_agent(llm, tools)
    """
    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    return [
        SafeKeyLabPIIProtectionTool(client=client),
        SafeKeyLabPIIDetectionTool(client=client),
    ]
