"""
SafeKeyLab LlamaIndex Integration

Provides callbacks, node postprocessors, and query transformations for LlamaIndex.

Usage:
    from safekeylab.integrations.llamaindex import (
        SafeKeyLabCallbackHandler,
        PIIRedactionNodePostprocessor,
        SafeKeyLabQueryTransform,
    )

    # Use as callback handler
    from llama_index.core import Settings
    from llama_index.core.callbacks import CallbackManager

    handler = SafeKeyLabCallbackHandler(api_key="sk_live_...")
    Settings.callback_manager = CallbackManager([handler])

    # Use as node postprocessor (redact PII from retrieved context)
    from llama_index.core import VectorStoreIndex

    postprocessor = PIIRedactionNodePostprocessor(api_key="sk_live_...")
    query_engine = index.as_query_engine(node_postprocessors=[postprocessor])

    # Use as query transform (protect user queries)
    from llama_index.core.indices.query.query_transform import QueryTransformComponent

    transform = SafeKeyLabQueryTransform(api_key="sk_live_...")
"""

from typing import Any, Dict, List, Optional, Sequence, Callable
import logging
import hashlib

logger = logging.getLogger(__name__)

# Try to import LlamaIndex components
try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    from llama_index.core.callbacks import CBEventType, EventPayload
    from llama_index.core.postprocessor.types import BaseNodePostprocessor
    from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode
    from llama_index.core.indices.query.query_transform.base import BaseQueryTransform
    from llama_index.core.prompts.mixin import PromptMixinType
    LLAMAINDEX_AVAILABLE = True
except ImportError:
    LLAMAINDEX_AVAILABLE = False
    # Define stub classes for when LlamaIndex is not installed
    class BaseCallbackHandler:
        pass
    class BaseNodePostprocessor:
        pass
    class BaseQueryTransform:
        pass
    CBEventType = None
    EventPayload = None
    NodeWithScore = None
    QueryBundle = None
    TextNode = None


class PIIDetectedError(Exception):
    """Raised when PII is detected and blocking is enabled"""
    def __init__(self, detections: List[Dict[str, Any]]):
        self.detections = detections
        types = ", ".join(d.get("type", "UNKNOWN") for d in detections)
        super().__init__(f"PII detected: {types}")


class ThreatDetectedError(Exception):
    """Raised when a security threat is detected"""
    def __init__(self, threats: List[Dict[str, Any]]):
        self.threats = threats
        types = ", ".join(t.get("type", "UNKNOWN") for t in threats)
        super().__init__(f"Security threat detected: {types}")


def _get_safekeylab_client(api_key: str, base_url: Optional[str] = None):
    """Get or create SafeKeyLab client"""
    try:
        from safekeylab import SafeKeyLab
        return SafeKeyLab(api_key=api_key, base_url=base_url)
    except ImportError:
        # Fallback to direct API calls
        import requests

        class SimpleClient:
            def __init__(self, api_key: str, base_url: Optional[str] = None):
                self.api_key = api_key
                self.base_url = base_url or "https://api.safekeylab.com"
                self.session = requests.Session()
                self.session.headers.update({
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                })

            def detect(self, text: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/detect",
                    json={"text": text, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            def protect(self, text: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/protect",
                    json={"text": text, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            def validate_prompt(self, prompt: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/validate-prompt",
                    json={"prompt": prompt, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

        return SimpleClient(api_key, base_url)


if LLAMAINDEX_AVAILABLE:

    class SafeKeyLabCallbackHandler(BaseCallbackHandler):
        """
        LlamaIndex callback handler for SafeKeyLab protection.

        Intercepts LLM calls to detect PII and security threats in prompts
        and responses.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL
            block_on_pii: If True, raise error when PII is detected (default: False)
            block_on_threat: If True, raise error when threats are detected (default: True)
            pii_types: List of PII types to detect (default: all)
            on_pii_detected: Callback when PII is detected
            on_threat_detected: Callback when threat is detected

        Example:
            >>> from llama_index.core import Settings
            >>> from llama_index.core.callbacks import CallbackManager
            >>> handler = SafeKeyLabCallbackHandler(api_key="sk_live_...")
            >>> Settings.callback_manager = CallbackManager([handler])
        """

        def __init__(
            self,
            api_key: str,
            base_url: Optional[str] = None,
            block_on_pii: bool = False,
            block_on_threat: bool = True,
            pii_types: Optional[List[str]] = None,
            on_pii_detected: Optional[Callable[[List[Dict]], None]] = None,
            on_threat_detected: Optional[Callable[[List[Dict]], None]] = None,
        ):
            super().__init__(
                event_starts_to_ignore=[],
                event_ends_to_ignore=[],
            )
            self.client = _get_safekeylab_client(api_key, base_url)
            self.block_on_pii = block_on_pii
            self.block_on_threat = block_on_threat
            self.pii_types = pii_types
            self.on_pii_detected = on_pii_detected
            self.on_threat_detected = on_threat_detected
            self._detections: List[Dict] = []
            self._threats: List[Dict] = []

        def on_event_start(
            self,
            event_type: CBEventType,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            parent_id: str = "",
            **kwargs: Any,
        ) -> str:
            """Handle event start - check inputs for PII and threats"""
            if event_type == CBEventType.LLM and payload:
                # Check messages/prompt for PII and threats
                messages = payload.get(EventPayload.MESSAGES, [])
                prompt = payload.get(EventPayload.PROMPT, "")

                text_to_check = prompt
                if messages:
                    text_to_check = "\n".join(
                        str(m.content) if hasattr(m, 'content') else str(m)
                        for m in messages
                    )

                if text_to_check:
                    self._check_text(text_to_check)

            return event_id

        def on_event_end(
            self,
            event_type: CBEventType,
            payload: Optional[Dict[str, Any]] = None,
            event_id: str = "",
            **kwargs: Any,
        ) -> None:
            """Handle event end - scan LLM outputs"""
            if event_type == CBEventType.LLM and payload:
                response = payload.get(EventPayload.RESPONSE, "")
                if response:
                    response_text = str(response)
                    # Check response for PII leakage
                    try:
                        result = self.client.detect(response_text)
                        if result.get("detections"):
                            logger.warning(
                                f"PII detected in LLM response: "
                                f"{[d['type'] for d in result['detections']]}"
                            )
                    except Exception as e:
                        logger.error(f"Error scanning LLM response: {e}")

        def _check_text(self, text: str) -> None:
            """Check text for PII and threats"""
            try:
                # Check for PII
                detect_result = self.client.detect(text)
                detections = detect_result.get("detections", [])

                if detections:
                    self._detections.extend(detections)
                    logger.warning(
                        f"PII detected: {[d['type'] for d in detections]}"
                    )

                    if self.on_pii_detected:
                        self.on_pii_detected(detections)

                    if self.block_on_pii:
                        raise PIIDetectedError(detections)

                # Check for threats
                validate_result = self.client.validate_prompt(text)
                threats = validate_result.get("threats", [])

                if threats:
                    self._threats.extend(threats)
                    logger.warning(
                        f"Threats detected: {[t['type'] for t in threats]}"
                    )

                    if self.on_threat_detected:
                        self.on_threat_detected(threats)

                    if self.block_on_threat:
                        raise ThreatDetectedError(threats)

            except (PIIDetectedError, ThreatDetectedError):
                raise
            except Exception as e:
                logger.error(f"Error checking text: {e}")

        def start_trace(self, trace_id: Optional[str] = None) -> None:
            """Start a new trace"""
            self._detections = []
            self._threats = []

        def end_trace(
            self,
            trace_id: Optional[str] = None,
            trace_map: Optional[Dict[str, List[str]]] = None,
        ) -> None:
            """End the current trace"""
            if self._detections:
                logger.info(
                    f"Trace complete. Total PII detections: {len(self._detections)}"
                )
            if self._threats:
                logger.info(
                    f"Trace complete. Total threats: {len(self._threats)}"
                )

        def get_detections(self) -> List[Dict]:
            """Get all PII detections from current trace"""
            return self._detections.copy()

        def get_threats(self) -> List[Dict]:
            """Get all threats from current trace"""
            return self._threats.copy()


    class PIIRedactionNodePostprocessor(BaseNodePostprocessor):
        """
        Node postprocessor that redacts PII from retrieved nodes.

        Use this to protect PII in retrieved context before it's sent to the LLM.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL
            pii_types: List of PII types to redact (default: all)
            redaction_style: Style of redaction ('placeholder', 'mask', 'hash')

        Example:
            >>> from llama_index.core import VectorStoreIndex
            >>> postprocessor = PIIRedactionNodePostprocessor(api_key="sk_live_...")
            >>> query_engine = index.as_query_engine(
            ...     node_postprocessors=[postprocessor]
            ... )
        """

        def __init__(
            self,
            api_key: str,
            base_url: Optional[str] = None,
            pii_types: Optional[List[str]] = None,
            redaction_style: str = "placeholder",
        ):
            super().__init__()
            self._client = _get_safekeylab_client(api_key, base_url)
            self._pii_types = pii_types
            self._redaction_style = redaction_style

        @classmethod
        def class_name(cls) -> str:
            return "PIIRedactionNodePostprocessor"

        def _postprocess_nodes(
            self,
            nodes: List[NodeWithScore],
            query_bundle: Optional[QueryBundle] = None,
        ) -> List[NodeWithScore]:
            """Postprocess nodes by redacting PII"""
            processed_nodes = []

            for node_with_score in nodes:
                node = node_with_score.node
                text = node.get_content()

                try:
                    # Redact PII from node content
                    result = self._client.protect(text)
                    redacted_text = result.get("redacted_text", text)

                    if result.get("redactions_count", 0) > 0:
                        logger.debug(
                            f"Redacted {result['redactions_count']} PII items from node"
                        )

                        # Create new node with redacted content
                        new_node = TextNode(
                            text=redacted_text,
                            metadata=node.metadata.copy() if node.metadata else {},
                            id_=node.node_id,
                        )
                        new_node.metadata["_safekeylab_redacted"] = True
                        new_node.metadata["_safekeylab_redactions"] = result.get("redactions", [])

                        processed_nodes.append(
                            NodeWithScore(node=new_node, score=node_with_score.score)
                        )
                    else:
                        processed_nodes.append(node_with_score)

                except Exception as e:
                    logger.error(f"Error redacting PII from node: {e}")
                    processed_nodes.append(node_with_score)

            return processed_nodes


    class SafeKeyLabQueryTransform(BaseQueryTransform):
        """
        Query transform that protects user queries before processing.

        Redacts PII from queries and validates for security threats.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL
            block_on_pii: If True, raise error when PII is detected
            block_on_threat: If True, raise error when threats are detected
            redact_pii: If True, redact PII from query (default: True)

        Example:
            >>> transform = SafeKeyLabQueryTransform(api_key="sk_live_...")
            >>> protected_query = transform.run("My email is john@example.com")
            >>> # protected_query.query_str = "My email is [EMAIL]"
        """

        def __init__(
            self,
            api_key: str,
            base_url: Optional[str] = None,
            block_on_pii: bool = False,
            block_on_threat: bool = True,
            redact_pii: bool = True,
        ):
            super().__init__()
            self._client = _get_safekeylab_client(api_key, base_url)
            self._block_on_pii = block_on_pii
            self._block_on_threat = block_on_threat
            self._redact_pii = redact_pii

        def _get_prompts(self) -> PromptMixinType:
            return {}

        def _update_prompts(self, prompts: PromptMixinType) -> None:
            pass

        def _run(
            self,
            query_bundle: QueryBundle,
            metadata: Optional[Dict[str, Any]] = None,
        ) -> QueryBundle:
            """Transform the query by protecting PII and validating for threats"""
            query_str = query_bundle.query_str

            try:
                # Check for threats
                validate_result = self._client.validate_prompt(query_str)
                threats = validate_result.get("threats", [])

                if threats and self._block_on_threat:
                    raise ThreatDetectedError(threats)

                # Detect and optionally redact PII
                detect_result = self._client.detect(query_str)
                detections = detect_result.get("detections", [])

                if detections:
                    if self._block_on_pii:
                        raise PIIDetectedError(detections)

                    if self._redact_pii:
                        protect_result = self._client.protect(query_str)
                        query_str = protect_result.get("redacted_text", query_str)
                        logger.info(
                            f"Redacted {protect_result.get('redactions_count', 0)} "
                            f"PII items from query"
                        )

                return QueryBundle(
                    query_str=query_str,
                    custom_embedding_strs=query_bundle.custom_embedding_strs,
                    embedding=query_bundle.embedding,
                )

            except (PIIDetectedError, ThreatDetectedError):
                raise
            except Exception as e:
                logger.error(f"Error transforming query: {e}")
                return query_bundle


else:
    # Stubs when LlamaIndex is not installed
    class SafeKeyLabCallbackHandler:
        """LlamaIndex callback handler (requires llama-index to be installed)"""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "LlamaIndex is not installed. "
                "Install it with: pip install llama-index"
            )

    class PIIRedactionNodePostprocessor:
        """Node postprocessor (requires llama-index to be installed)"""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "LlamaIndex is not installed. "
                "Install it with: pip install llama-index"
            )

    class SafeKeyLabQueryTransform:
        """Query transform (requires llama-index to be installed)"""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "LlamaIndex is not installed. "
                "Install it with: pip install llama-index"
            )


__all__ = [
    "SafeKeyLabCallbackHandler",
    "PIIRedactionNodePostprocessor",
    "SafeKeyLabQueryTransform",
    "PIIDetectedError",
    "ThreatDetectedError",
    "LLAMAINDEX_AVAILABLE",
]
