"""
SafeKeyLab Google ADK Integration

Provides native Google Agent Development Kit (ADK) tools for PII protection.

This module enables SafeKey Lab to work seamlessly with Google ADK agents,
allowing PII detection and redaction as native ADK tools.

Requirements:
    pip install google-adk safekeylab

Example:
    from google.adk.agents import Agent
    from safekeylab.integrations.google_adk import create_pii_protection_tool

    # Create the tool
    pii_tool = create_pii_protection_tool(api_key="sk_live_xxx")

    # Use in agent
    agent = Agent(
        name="secure_assistant",
        model="gemini-2.5-flash",
        tools=[pii_tool]
    )
"""

import os
import logging
from typing import Dict, List, Any, Optional, Union, Callable
from functools import wraps

# Import SafeKey Lab client
from ..unified_client import SafeKeyClient
from ..result_types import ProtectionResult, DetectionResult

logger = logging.getLogger(__name__)


# ============================================================================
# ADK Tool Factory Functions
# ============================================================================

def create_pii_protection_tool(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
    entities: Optional[List[str]] = None,
    redaction_type: str = "mask"
) -> Callable:
    """
    Create a Google ADK FunctionTool for PII protection.

    This is the primary integration point for Ardor and other ADK-based platforms.

    Args:
        api_key: SafeKey Lab API key (or use SAFEKEYLAB_API_KEY env var)
        client: Pre-configured SafeKeyClient instance (alternative to api_key)
        entities: List of entity types to detect (default: common PII types)
        redaction_type: How to redact - "mask", "hash", "partial", "remove"

    Returns:
        A function suitable for use with google.adk.tools.FunctionTool

    Example:
        from google.adk.agents import Agent
        from google.adk.tools import FunctionTool
        from safekeylab.integrations.google_adk import create_pii_protection_tool

        protect_pii = create_pii_protection_tool(api_key="sk_live_xxx")
        tool = FunctionTool(protect_pii)

        agent = Agent(
            name="secure_assistant",
            model="gemini-2.5-flash",
            instruction="Always protect PII before processing user input.",
            tools=[tool]
        )
    """
    # Initialize client
    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError(
                "API key required. Pass api_key parameter or set SAFEKEYLAB_API_KEY env var"
            )
        client = SafeKeyClient(api_key=key)

    # Default entities
    default_entities = entities or [
        "EMAIL", "PHONE", "SSN", "CREDIT_CARD", "NAME",
        "ADDRESS", "DATE_OF_BIRTH", "API_KEY", "PASSWORD"
    ]

    def protect_pii(text: str) -> Dict[str, Any]:
        """
        Detect and redact PII from text.

        Use this tool to sanitize user input before processing,
        or to scan output before returning to users. This protects
        sensitive information like emails, phone numbers, SSNs,
        credit cards, and API keys.

        Args:
            text: The text to scan and protect

        Returns:
            Dictionary containing:
            - protected_text: Text with PII redacted
            - original_text: Original input text
            - entities_found: Number of PII entities detected
            - entity_types: List of PII types found
            - processing_time_ms: Time taken to process
        """
        try:
            result = client.protect(text, config={
                "entities": default_entities,
                "redaction_type": redaction_type,
                "return_positions": True
            })

            return {
                "protected_text": result.redacted,
                "original_text": result.original,
                "entities_found": result.entity_count,
                "entity_types": result.entity_types,
                "processing_time_ms": result.processing_time_ms,
                "has_pii": result.has_pii
            }
        except Exception as e:
            logger.error(f"PII protection failed: {e}")
            return {
                "protected_text": text,
                "original_text": text,
                "entities_found": 0,
                "entity_types": [],
                "processing_time_ms": 0,
                "has_pii": False,
                "error": str(e)
            }

    # Add metadata for ADK
    protect_pii.__name__ = "protect_pii"
    protect_pii.__doc__ = """
    Detect and redact PII from text.

    Use this tool to sanitize user input before processing,
    or to scan output before returning to users. This protects
    sensitive information like emails, phone numbers, SSNs,
    credit cards, and API keys.

    Args:
        text: The text to scan and protect

    Returns:
        Dictionary with protected_text and detection metadata
    """

    return protect_pii


def create_secret_detection_tool(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None
) -> Callable:
    """
    Create a Google ADK FunctionTool specifically for detecting secrets in code.

    Optimized for detecting API keys, private keys, credentials, and other
    secrets that may appear in generated code.

    Args:
        api_key: SafeKey Lab API key
        client: Pre-configured SafeKeyClient instance

    Returns:
        A function suitable for use with google.adk.tools.FunctionTool

    Example:
        from safekeylab.integrations.google_adk import create_secret_detection_tool

        detect_secrets = create_secret_detection_tool()

        # Use in code generation agent
        code_agent = Agent(
            name="code_generator",
            tools=[FunctionTool(detect_secrets)]
        )
    """
    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    # Secret-focused entity types
    secret_entities = [
        "API_KEY",
        "AWS_ACCESS_KEY",
        "AWS_SECRET_KEY",
        "GCP_API_KEY",
        "AZURE_KEY",
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "STRIPE_API_KEY",
        "GITHUB_TOKEN",
        "PRIVATE_KEY",
        "SSH_KEY",
        "PASSWORD",
        "CONNECTION_STRING",
        "DATABASE_URL",
        "JWT_TOKEN",
        "OAUTH_TOKEN",
        "WEBHOOK_SECRET"
    ]

    def detect_secrets(code: str) -> Dict[str, Any]:
        """
        Scan code for hardcoded secrets and credentials.

        Use this tool to check generated code before outputting it to users.
        It detects API keys, private keys, passwords, connection strings,
        and other sensitive credentials that should not be exposed.

        Args:
            code: The code or text to scan for secrets

        Returns:
            Dictionary containing:
            - has_secrets: Boolean indicating if secrets were found
            - secrets_found: Number of secrets detected
            - secret_types: List of secret types found (e.g., ["AWS_ACCESS_KEY", "PASSWORD"])
            - safe_code: Code with secrets redacted (if any found)
            - warnings: List of warnings about detected secrets
        """
        try:
            result = client.protect(code, config={
                "entities": secret_entities,
                "redaction_type": "mask",
                "return_positions": True
            })

            warnings = []
            for entity in result.entities:
                warnings.append(
                    f"Found {entity.type} at position {entity.start}-{entity.end}"
                )

            return {
                "has_secrets": result.has_pii,
                "secrets_found": result.entity_count,
                "secret_types": result.entity_types,
                "safe_code": result.redacted,
                "warnings": warnings,
                "processing_time_ms": result.processing_time_ms
            }
        except Exception as e:
            logger.error(f"Secret detection failed: {e}")
            return {
                "has_secrets": False,
                "secrets_found": 0,
                "secret_types": [],
                "safe_code": code,
                "warnings": [],
                "error": str(e)
            }

    detect_secrets.__name__ = "detect_secrets"
    return detect_secrets


def create_output_scanner_tool(
    api_key: Optional[str] = None,
    client: Optional[SafeKeyClient] = None,
    block_on_pii: bool = False
) -> Callable:
    """
    Create a Google ADK FunctionTool for scanning agent outputs.

    Use this to scan LLM responses before returning them to users.
    Can optionally block responses that contain PII.

    Args:
        api_key: SafeKey Lab API key
        client: Pre-configured SafeKeyClient instance
        block_on_pii: If True, return error instead of PII-containing response

    Returns:
        A function suitable for use with google.adk.tools.FunctionTool
    """
    if client is None:
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError("API key required")
        client = SafeKeyClient(api_key=key)

    def scan_output(response: str) -> Dict[str, Any]:
        """
        Scan agent output for PII before returning to user.

        Use this tool to check LLM responses before displaying them.
        This helps prevent accidental PII leakage in agent outputs.

        Args:
            response: The agent response text to scan

        Returns:
            Dictionary containing:
            - safe_to_return: Boolean indicating if response is safe
            - response: Original or redacted response
            - pii_detected: Boolean if PII was found
            - entity_count: Number of PII entities found
            - entity_types: Types of PII detected
        """
        try:
            result = client.detect(response)

            if result.has_pii:
                if block_on_pii:
                    return {
                        "safe_to_return": False,
                        "response": "[Response blocked - contains sensitive information]",
                        "pii_detected": True,
                        "entity_count": result.entity_count,
                        "entity_types": result.entity_types,
                        "blocked": True
                    }
                else:
                    # Redact and return
                    protected = client.protect(response)
                    return {
                        "safe_to_return": True,
                        "response": protected.redacted,
                        "pii_detected": True,
                        "entity_count": result.entity_count,
                        "entity_types": result.entity_types,
                        "redacted": True
                    }
            else:
                return {
                    "safe_to_return": True,
                    "response": response,
                    "pii_detected": False,
                    "entity_count": 0,
                    "entity_types": []
                }
        except Exception as e:
            logger.error(f"Output scanning failed: {e}")
            # Fail safe - block if we can't scan
            if block_on_pii:
                return {
                    "safe_to_return": False,
                    "response": "[Response blocked - scanning failed]",
                    "error": str(e)
                }
            return {
                "safe_to_return": True,
                "response": response,
                "error": str(e)
            }

    scan_output.__name__ = "scan_output"
    return scan_output


# ============================================================================
# ADK Tools Container Class
# ============================================================================

class SafeKeyLabADKTools:
    """
    Container class providing all SafeKey Lab tools for Google ADK.

    Provides a convenient way to get all tools configured with a single client.

    Example:
        from safekeylab.integrations.google_adk import SafeKeyLabADKTools
        from google.adk.agents import Agent
        from google.adk.tools import FunctionTool

        tools = SafeKeyLabADKTools(api_key="sk_live_xxx")

        agent = Agent(
            name="secure_agent",
            model="gemini-2.5-flash",
            tools=[
                FunctionTool(tools.protect_pii),
                FunctionTool(tools.detect_secrets),
                FunctionTool(tools.scan_output)
            ]
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.safekeylab.com",
        **client_kwargs
    ):
        """
        Initialize SafeKey Lab ADK tools.

        Args:
            api_key: SafeKey Lab API key (or set SAFEKEYLAB_API_KEY env var)
            base_url: API base URL
            **client_kwargs: Additional arguments for SafeKeyClient
        """
        key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
        if not key:
            raise ValueError(
                "API key required. Pass api_key or set SAFEKEYLAB_API_KEY env var"
            )

        self.client = SafeKeyClient(
            api_key=key,
            base_url=base_url,
            **client_kwargs
        )

        # Create tools
        self.protect_pii = create_pii_protection_tool(client=self.client)
        self.detect_secrets = create_secret_detection_tool(client=self.client)
        self.scan_output = create_output_scanner_tool(client=self.client)

    def get_all_tools(self) -> List[Callable]:
        """
        Get all SafeKey Lab tools as a list.

        Returns:
            List of tool functions ready for FunctionTool wrapping
        """
        return [
            self.protect_pii,
            self.detect_secrets,
            self.scan_output
        ]

    def create_custom_tool(
        self,
        entities: List[str],
        name: str = "custom_pii_tool",
        redaction_type: str = "mask"
    ) -> Callable:
        """
        Create a custom PII detection tool with specific entity types.

        Args:
            entities: List of entity types to detect
            name: Name for the tool function
            redaction_type: Redaction method

        Returns:
            Custom tool function
        """
        tool = create_pii_protection_tool(
            client=self.client,
            entities=entities,
            redaction_type=redaction_type
        )
        tool.__name__ = name
        return tool


# ============================================================================
# Protected Runner (Advanced Integration)
# ============================================================================

class ProtectedRunner:
    """
    A wrapper that automatically protects PII in inputs and outputs.

    This provides transparent PII protection without modifying agent code.
    Wrap any ADK Runner to automatically sanitize inputs and scan outputs.

    Example:
        from google.adk.runners import Runner
        from safekeylab.integrations.google_adk import ProtectedRunner

        # Create base runner
        base_runner = Runner(agent)

        # Wrap with protection
        runner = ProtectedRunner(
            base_runner,
            api_key="sk_live_xxx",
            protect_input=True,
            scan_output=True
        )

        # Use as normal
        response = await runner.run(session, user_message)
    """

    def __init__(
        self,
        runner: Any,
        api_key: Optional[str] = None,
        client: Optional[SafeKeyClient] = None,
        protect_input: bool = True,
        scan_output: bool = True,
        redact_output: bool = True,
        log_detections: bool = True
    ):
        """
        Initialize protected runner.

        Args:
            runner: The ADK Runner instance to wrap
            api_key: SafeKey Lab API key
            client: Pre-configured SafeKeyClient
            protect_input: Whether to sanitize input before sending to agent
            scan_output: Whether to scan output for PII
            redact_output: Whether to redact PII found in output
            log_detections: Whether to log PII detections
        """
        self.runner = runner
        self.protect_input = protect_input
        self.scan_output = scan_output
        self.redact_output = redact_output
        self.log_detections = log_detections

        if client is None:
            key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
            if not key:
                raise ValueError("API key required")
            client = SafeKeyClient(api_key=key)

        self.client = client

    async def run(self, session: Any, user_message: str, **kwargs) -> Any:
        """
        Run agent with PII protection.

        Args:
            session: ADK Session object
            user_message: User input message
            **kwargs: Additional arguments for runner

        Returns:
            Agent response (potentially with PII redacted)
        """
        # Protect input
        processed_message = user_message
        if self.protect_input:
            result = self.client.protect(user_message)
            if result.has_pii and self.log_detections:
                logger.info(
                    f"PII detected in input: {result.entity_types} "
                    f"({result.entity_count} entities)"
                )
            processed_message = result.redacted

        # Run agent
        response = await self.runner.run(session, processed_message, **kwargs)

        # Scan/redact output
        if self.scan_output and hasattr(response, 'text'):
            detection = self.client.detect(response.text)
            if detection.has_pii:
                if self.log_detections:
                    logger.warning(
                        f"PII detected in output: {detection.entity_types} "
                        f"({detection.entity_count} entities)"
                    )
                if self.redact_output:
                    protected = self.client.protect(response.text)
                    response.text = protected.redacted

        return response

    def run_sync(self, session: Any, user_message: str, **kwargs) -> Any:
        """
        Synchronous version of run().

        For use in non-async contexts.
        """
        import asyncio
        return asyncio.run(self.run(session, user_message, **kwargs))


# ============================================================================
# Convenience Decorators
# ============================================================================

def protect_input(
    api_key: Optional[str] = None,
    entities: Optional[List[str]] = None
):
    """
    Decorator to automatically protect PII in function inputs.

    Example:
        @protect_input(api_key="sk_live_xxx")
        def process_user_data(text: str) -> str:
            # text is already sanitized
            return llm.generate(text)
    """
    key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
    client = SafeKeyClient(api_key=key) if key else None

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            if client is None:
                return func(*args, **kwargs)

            # Protect string arguments
            protected_args = []
            for arg in args:
                if isinstance(arg, str):
                    result = client.protect(arg, config={"entities": entities} if entities else None)
                    protected_args.append(result.redacted)
                else:
                    protected_args.append(arg)

            protected_kwargs = {}
            for key, value in kwargs.items():
                if isinstance(value, str):
                    result = client.protect(value, config={"entities": entities} if entities else None)
                    protected_kwargs[key] = result.redacted
                else:
                    protected_kwargs[key] = value

            return func(*protected_args, **protected_kwargs)

        return wrapper
    return decorator


def scan_output_decorator(
    api_key: Optional[str] = None,
    redact: bool = True,
    raise_on_pii: bool = False
):
    """
    Decorator to automatically scan function outputs for PII.

    Example:
        @scan_output_decorator(api_key="sk_live_xxx", redact=True)
        def get_user_summary(user_id: str) -> str:
            # Output will be scanned and redacted
            return database.get_user_info(user_id)
    """
    key = api_key or os.environ.get("SAFEKEYLAB_API_KEY")
    client = SafeKeyClient(api_key=key) if key else None

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)

            if client is None or not isinstance(result, str):
                return result

            detection = client.detect(result)
            if detection.has_pii:
                if raise_on_pii:
                    raise ValueError(
                        f"PII detected in output: {detection.entity_types}"
                    )
                if redact:
                    protected = client.protect(result)
                    return protected.redacted

            return result

        return wrapper
    return decorator
