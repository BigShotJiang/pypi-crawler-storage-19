"""
SafeKeyLab Semantic Kernel Integration

Provides filters, plugins, and functions for Microsoft Semantic Kernel.

Usage:
    from safekeylab.integrations.semantic_kernel import (
        SafeKeyLabFilter,
        SafeKeyLabPlugin,
        create_pii_protection_function,
    )

    # Use as a filter (intercepts all LLM calls)
    from semantic_kernel import Kernel

    kernel = Kernel()
    sk_filter = SafeKeyLabFilter(api_key="sk_live_...")
    kernel.add_filter("prompt_render", sk_filter.on_prompt_render)
    kernel.add_filter("function_invocation", sk_filter.on_function_invocation)

    # Use as a plugin
    plugin = SafeKeyLabPlugin(api_key="sk_live_...")
    kernel.add_plugin(plugin, "safekeylab")

    # Call plugin functions
    result = await kernel.invoke(plugin["detect_pii"], text="john@example.com")
"""

from typing import Any, Dict, List, Optional, Callable, Union
import logging
import asyncio
from functools import wraps

logger = logging.getLogger(__name__)

# Try to import Semantic Kernel components
try:
    from semantic_kernel import Kernel
    from semantic_kernel.functions import kernel_function
    from semantic_kernel.filters.filter_types import FilterTypes
    from semantic_kernel.filters.functions.function_invocation_context import FunctionInvocationContext
    from semantic_kernel.filters.prompts.prompt_render_context import PromptRenderContext
    from semantic_kernel.contents import ChatMessageContent
    SEMANTIC_KERNEL_AVAILABLE = True
except ImportError:
    SEMANTIC_KERNEL_AVAILABLE = False
    Kernel = None
    kernel_function = lambda **kwargs: lambda f: f
    FilterTypes = None
    FunctionInvocationContext = None
    PromptRenderContext = None
    ChatMessageContent = None


class PIIDetectedError(Exception):
    """Raised when PII is detected and blocking is enabled"""
    def __init__(self, detections: List[Dict[str, Any]]):
        self.detections = detections
        types = ", ".join(d.get("type", "UNKNOWN") for d in detections)
        super().__init__(f"PII detected: {types}")


class ThreatDetectedError(Exception):
    """Raised when a security threat is detected"""
    def __init__(self, threats: List[Dict[str, Any]]):
        self.threats = threats
        types = ", ".join(t.get("type", "UNKNOWN") for t in threats)
        super().__init__(f"Security threat detected: {types}")


def _get_safekeylab_client(api_key: str, base_url: Optional[str] = None):
    """Get or create SafeKeyLab client"""
    try:
        from safekeylab import SafeKeyLab
        return SafeKeyLab(api_key=api_key, base_url=base_url)
    except ImportError:
        import requests

        class SimpleClient:
            def __init__(self, api_key: str, base_url: Optional[str] = None):
                self.api_key = api_key
                self.base_url = base_url or "https://api.safekeylab.com"
                self.session = requests.Session()
                self.session.headers.update({
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                })

            def detect(self, text: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/detect",
                    json={"text": text, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            def protect(self, text: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/protect",
                    json={"text": text, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            def validate_prompt(self, prompt: str, **kwargs) -> Dict[str, Any]:
                resp = self.session.post(
                    f"{self.base_url}/v1/validate-prompt",
                    json={"prompt": prompt, **kwargs},
                    timeout=30,
                )
                resp.raise_for_status()
                return resp.json()

            async def detect_async(self, text: str, **kwargs) -> Dict[str, Any]:
                return await asyncio.to_thread(self.detect, text, **kwargs)

            async def protect_async(self, text: str, **kwargs) -> Dict[str, Any]:
                return await asyncio.to_thread(self.protect, text, **kwargs)

            async def validate_prompt_async(self, prompt: str, **kwargs) -> Dict[str, Any]:
                return await asyncio.to_thread(self.validate_prompt, prompt, **kwargs)

        return SimpleClient(api_key, base_url)


if SEMANTIC_KERNEL_AVAILABLE:

    class SafeKeyLabFilter:
        """
        Semantic Kernel filter for SafeKeyLab protection.

        Intercepts prompt rendering and function invocations to protect
        against PII leakage and security threats.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL
            block_on_pii: If True, raise error when PII is detected
            block_on_threat: If True, raise error when threats are detected
            redact_pii: If True, automatically redact PII from prompts
            pii_types: List of PII types to detect

        Example:
            >>> kernel = Kernel()
            >>> sk_filter = SafeKeyLabFilter(api_key="sk_live_...")
            >>> kernel.add_filter(FilterTypes.PROMPT_RENDERING, sk_filter.on_prompt_render)
        """

        def __init__(
            self,
            api_key: str,
            base_url: Optional[str] = None,
            block_on_pii: bool = False,
            block_on_threat: bool = True,
            redact_pii: bool = True,
            pii_types: Optional[List[str]] = None,
        ):
            self.client = _get_safekeylab_client(api_key, base_url)
            self.block_on_pii = block_on_pii
            self.block_on_threat = block_on_threat
            self.redact_pii = redact_pii
            self.pii_types = pii_types
            self._detections: List[Dict] = []
            self._threats: List[Dict] = []

        async def on_prompt_render(
            self,
            context: PromptRenderContext,
            next: Callable[[PromptRenderContext], Any],
        ) -> None:
            """
            Filter that runs before prompt is rendered.
            Checks for PII and threats in the prompt.
            """
            # Get the rendered prompt
            await next(context)

            rendered_prompt = context.rendered_prompt
            if not rendered_prompt:
                return

            try:
                # Check for threats
                if hasattr(self.client, 'validate_prompt_async'):
                    validate_result = await self.client.validate_prompt_async(rendered_prompt)
                else:
                    validate_result = await asyncio.to_thread(
                        self.client.validate_prompt, rendered_prompt
                    )

                threats = validate_result.get("threats", [])
                if threats:
                    self._threats.extend(threats)
                    logger.warning(f"Threats detected: {[t['type'] for t in threats]}")

                    if self.block_on_threat:
                        raise ThreatDetectedError(threats)

                # Check for PII
                if hasattr(self.client, 'detect_async'):
                    detect_result = await self.client.detect_async(rendered_prompt)
                else:
                    detect_result = await asyncio.to_thread(
                        self.client.detect, rendered_prompt
                    )

                detections = detect_result.get("detections", [])
                if detections:
                    self._detections.extend(detections)
                    logger.warning(f"PII detected: {[d['type'] for d in detections]}")

                    if self.block_on_pii:
                        raise PIIDetectedError(detections)

                    if self.redact_pii:
                        if hasattr(self.client, 'protect_async'):
                            protect_result = await self.client.protect_async(rendered_prompt)
                        else:
                            protect_result = await asyncio.to_thread(
                                self.client.protect, rendered_prompt
                            )
                        context.rendered_prompt = protect_result.get("redacted_text", rendered_prompt)

            except (PIIDetectedError, ThreatDetectedError):
                raise
            except Exception as e:
                logger.error(f"Error in SafeKeyLab filter: {e}")

        async def on_function_invocation(
            self,
            context: FunctionInvocationContext,
            next: Callable[[FunctionInvocationContext], Any],
        ) -> None:
            """
            Filter that runs around function invocations.
            Checks function arguments for PII.
            """
            # Check arguments for PII
            arguments = context.arguments
            if arguments:
                for key, value in arguments.items():
                    if isinstance(value, str) and value:
                        try:
                            if hasattr(self.client, 'detect_async'):
                                detect_result = await self.client.detect_async(value)
                            else:
                                detect_result = await asyncio.to_thread(
                                    self.client.detect, value
                                )

                            detections = detect_result.get("detections", [])
                            if detections:
                                self._detections.extend(detections)

                                if self.block_on_pii:
                                    raise PIIDetectedError(detections)

                                if self.redact_pii:
                                    if hasattr(self.client, 'protect_async'):
                                        protect_result = await self.client.protect_async(value)
                                    else:
                                        protect_result = await asyncio.to_thread(
                                            self.client.protect, value
                                        )
                                    arguments[key] = protect_result.get("redacted_text", value)

                        except (PIIDetectedError, ThreatDetectedError):
                            raise
                        except Exception as e:
                            logger.error(f"Error checking argument {key}: {e}")

            # Continue with the function invocation
            await next(context)

        def get_detections(self) -> List[Dict]:
            """Get all PII detections"""
            return self._detections.copy()

        def get_threats(self) -> List[Dict]:
            """Get all detected threats"""
            return self._threats.copy()

        def clear_history(self) -> None:
            """Clear detection history"""
            self._detections = []
            self._threats = []


    class SafeKeyLabPlugin:
        """
        Semantic Kernel plugin providing SafeKeyLab functions.

        Provides native functions for PII detection, redaction, and prompt validation.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL

        Example:
            >>> kernel = Kernel()
            >>> plugin = SafeKeyLabPlugin(api_key="sk_live_...")
            >>> kernel.add_plugin(plugin, "safekeylab")
            >>> result = await kernel.invoke(plugin["detect_pii"], text="john@example.com")
        """

        def __init__(
            self,
            api_key: str,
            base_url: Optional[str] = None,
        ):
            self.client = _get_safekeylab_client(api_key, base_url)

        @kernel_function(
            name="detect_pii",
            description="Detect PII (personally identifiable information) in text. "
                       "Returns a list of detected PII types and their locations.",
        )
        async def detect_pii(self, text: str) -> str:
            """Detect PII in text"""
            try:
                if hasattr(self.client, 'detect_async'):
                    result = await self.client.detect_async(text)
                else:
                    result = await asyncio.to_thread(self.client.detect, text)

                detections = result.get("detections", [])
                if not detections:
                    return "No PII detected."

                return (
                    f"Found {len(detections)} PII items:\n" +
                    "\n".join(
                        f"- {d['type']}: \"{d['value']}\" (confidence: {d['confidence']:.2f})"
                        for d in detections
                    )
                )
            except Exception as e:
                return f"Error detecting PII: {e}"

        @kernel_function(
            name="redact_pii",
            description="Redact PII from text. Replaces sensitive information with placeholders. "
                       "Use this before storing or processing user data.",
        )
        async def redact_pii(self, text: str) -> str:
            """Redact PII from text"""
            try:
                if hasattr(self.client, 'protect_async'):
                    result = await self.client.protect_async(text)
                else:
                    result = await asyncio.to_thread(self.client.protect, text)

                return result.get("redacted_text", text)
            except Exception as e:
                logger.error(f"Error redacting PII: {e}")
                return text

        @kernel_function(
            name="validate_prompt",
            description="Validate a prompt for security threats like injection attacks. "
                       "Use this to check if user input is safe before using in prompts.",
        )
        async def validate_prompt(self, prompt: str) -> str:
            """Validate a prompt for security threats"""
            try:
                if hasattr(self.client, 'validate_prompt_async'):
                    result = await self.client.validate_prompt_async(prompt)
                else:
                    result = await asyncio.to_thread(self.client.validate_prompt, prompt)

                if result.get("is_safe", True):
                    return "Prompt is safe."

                threats = result.get("threats", [])
                return (
                    f"Prompt has {len(threats)} threats:\n" +
                    "\n".join(
                        f"- {t['type']} ({t['severity']}): {t['description']}"
                        for t in threats
                    ) +
                    f"\nRecommendation: {result.get('recommendation', 'review')}"
                )
            except Exception as e:
                return f"Error validating prompt: {e}"

        @kernel_function(
            name="protect_and_validate",
            description="Full protection: detect PII, redact it, and validate for threats. "
                       "Returns protected text and any warnings.",
        )
        async def protect_and_validate(self, text: str) -> str:
            """Full protection pipeline"""
            try:
                # Validate for threats
                if hasattr(self.client, 'validate_prompt_async'):
                    validate_result = await self.client.validate_prompt_async(text)
                else:
                    validate_result = await asyncio.to_thread(
                        self.client.validate_prompt, text
                    )

                threats = validate_result.get("threats", [])
                threat_warning = ""
                if threats:
                    threat_warning = (
                        f"\n⚠️ Threats detected: {', '.join(t['type'] for t in threats)}"
                    )

                # Detect and redact PII
                if hasattr(self.client, 'detect_async'):
                    detect_result = await self.client.detect_async(text)
                else:
                    detect_result = await asyncio.to_thread(self.client.detect, text)

                detections = detect_result.get("detections", [])
                pii_warning = ""

                if detections:
                    if hasattr(self.client, 'protect_async'):
                        protect_result = await self.client.protect_async(text)
                    else:
                        protect_result = await asyncio.to_thread(self.client.protect, text)

                    text = protect_result.get("redacted_text", text)
                    pii_warning = (
                        f"\n🔒 PII redacted: {', '.join(d['type'] for d in detections)}"
                    )

                return f"{text}{pii_warning}{threat_warning}"

            except Exception as e:
                return f"Error in protection pipeline: {e}"


    def create_safekeylab_kernel(
        api_key: str,
        base_url: Optional[str] = None,
        block_on_pii: bool = False,
        block_on_threat: bool = True,
        redact_pii: bool = True,
    ) -> Kernel:
        """
        Create a Semantic Kernel with SafeKeyLab protection pre-configured.

        Args:
            api_key: SafeKeyLab API key
            base_url: Optional custom API base URL
            block_on_pii: If True, raise error when PII is detected
            block_on_threat: If True, raise error when threats are detected
            redact_pii: If True, automatically redact PII

        Returns:
            Configured Kernel with SafeKeyLab filters and plugin

        Example:
            >>> kernel = create_safekeylab_kernel(api_key="sk_live_...")
            >>> # All LLM calls are now protected
        """
        kernel = Kernel()

        # Add filter
        sk_filter = SafeKeyLabFilter(
            api_key=api_key,
            base_url=base_url,
            block_on_pii=block_on_pii,
            block_on_threat=block_on_threat,
            redact_pii=redact_pii,
        )
        kernel.add_filter(FilterTypes.PROMPT_RENDERING, sk_filter.on_prompt_render)
        kernel.add_filter(FilterTypes.FUNCTION_INVOCATION, sk_filter.on_function_invocation)

        # Add plugin
        plugin = SafeKeyLabPlugin(api_key=api_key, base_url=base_url)
        kernel.add_plugin(plugin, "safekeylab")

        return kernel


else:
    # Stubs when Semantic Kernel is not installed
    class SafeKeyLabFilter:
        """Semantic Kernel filter (requires semantic-kernel to be installed)"""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "Semantic Kernel is not installed. "
                "Install it with: pip install semantic-kernel"
            )

    class SafeKeyLabPlugin:
        """Semantic Kernel plugin (requires semantic-kernel to be installed)"""
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "Semantic Kernel is not installed. "
                "Install it with: pip install semantic-kernel"
            )

    def create_safekeylab_kernel(*args, **kwargs):
        raise ImportError(
            "Semantic Kernel is not installed. "
            "Install it with: pip install semantic-kernel"
        )


__all__ = [
    "SafeKeyLabFilter",
    "SafeKeyLabPlugin",
    "create_safekeylab_kernel",
    "PIIDetectedError",
    "ThreatDetectedError",
    "SEMANTIC_KERNEL_AVAILABLE",
]
