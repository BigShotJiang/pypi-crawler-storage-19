"""
SafeKeyLab Integrations - Pre-built integrations for popular frameworks

Available integrations:
- google_adk: Google Agent Development Kit (ADK) tools
- langchain: LangChain callback handlers, tools, and chain wrappers
- llamaindex: LlamaIndex callback handlers, node postprocessors, query transforms
- semantic_kernel: Microsoft Semantic Kernel filters and plugins
- openai: OpenAI API wrapper
- anthropic: Anthropic API wrapper
"""

from .google_adk import (
    create_pii_protection_tool,
    create_secret_detection_tool,
    create_output_scanner_tool,
    SafeKeyLabADKTools,
    ProtectedRunner,
)

# LangChain integration
try:
    from .langchain import (
        SafeKeyLabCallbackHandler,
        SafeKeyLabPIIProtectionTool,
        SafeKeyLabPIIDetectionTool,
        create_pii_protection_tool as create_langchain_pii_tool,
        create_secret_detection_tool as create_langchain_secret_tool,
        create_protected_chain,
        SafeKeyLabRetrieverWrapper,
        get_langchain_tools,
        PIIDetectedError,
    )
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

# LlamaIndex integration
try:
    from .llamaindex import (
        SafeKeyLabCallbackHandler as LlamaIndexCallbackHandler,
        PIIRedactionNodePostprocessor,
        SafeKeyLabQueryTransform,
        LLAMAINDEX_AVAILABLE,
    )
except ImportError:
    LLAMAINDEX_AVAILABLE = False

# Semantic Kernel integration
try:
    from .semantic_kernel import (
        SafeKeyLabFilter,
        SafeKeyLabPlugin,
        create_safekeylab_kernel,
        SEMANTIC_KERNEL_AVAILABLE,
    )
except ImportError:
    SEMANTIC_KERNEL_AVAILABLE = False

__all__ = [
    # Google ADK
    "create_pii_protection_tool",
    "create_secret_detection_tool",
    "create_output_scanner_tool",
    "SafeKeyLabADKTools",
    "ProtectedRunner",
    # LangChain
    "SafeKeyLabCallbackHandler",
    "SafeKeyLabPIIProtectionTool",
    "SafeKeyLabPIIDetectionTool",
    "create_langchain_pii_tool",
    "create_langchain_secret_tool",
    "create_protected_chain",
    "SafeKeyLabRetrieverWrapper",
    "get_langchain_tools",
    "PIIDetectedError",
    "LANGCHAIN_AVAILABLE",
    # LlamaIndex
    "LlamaIndexCallbackHandler",
    "PIIRedactionNodePostprocessor",
    "SafeKeyLabQueryTransform",
    "LLAMAINDEX_AVAILABLE",
    # Semantic Kernel
    "SafeKeyLabFilter",
    "SafeKeyLabPlugin",
    "create_safekeylab_kernel",
    "SEMANTIC_KERNEL_AVAILABLE",
]
