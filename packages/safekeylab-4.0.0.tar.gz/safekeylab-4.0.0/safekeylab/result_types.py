"""
SafeKeyLab Result Types - Structured result objects for API responses
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class PIIEntity:
    """Represents a detected PII entity"""
    type: str
    value: str
    start: int
    end: int
    confidence: float
    subtype: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "value": self.value,
            "start": self.start,
            "end": self.end,
            "confidence": self.confidence,
            "subtype": self.subtype,
            "metadata": self.metadata
        }


@dataclass
class ProtectionResult:
    """Result from protect() operation - combines detection and redaction"""
    original: str
    redacted: str
    entities: List[PIIEntity]
    processing_time_ms: float
    request_id: str = ""
    cached: bool = False

    @property
    def has_pii(self) -> bool:
        return len(self.entities) > 0

    @property
    def entity_count(self) -> int:
        return len(self.entities)

    @property
    def entity_types(self) -> List[str]:
        return list(set(e.type for e in self.entities))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original": self.original,
            "redacted": self.redacted,
            "entities": [e.to_dict() for e in self.entities],
            "processing_time_ms": self.processing_time_ms,
            "request_id": self.request_id,
            "cached": self.cached,
            "has_pii": self.has_pii,
            "entity_count": self.entity_count
        }


@dataclass
class DetectionResult:
    """Result from detect() operation - detection only, no redaction"""
    text: str
    has_pii: bool
    entities: List[PIIEntity]
    processing_time_ms: float
    request_id: str = ""

    @property
    def entity_count(self) -> int:
        return len(self.entities)

    @property
    def entity_types(self) -> List[str]:
        return list(set(e.type for e in self.entities))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "has_pii": self.has_pii,
            "entities": [e.to_dict() for e in self.entities],
            "processing_time_ms": self.processing_time_ms,
            "request_id": self.request_id,
            "entity_count": self.entity_count
        }


@dataclass
class BatchItem:
    """Single item in a batch processing result"""
    id: str
    redacted: str
    entities_found: int
    entity_types: List[str] = field(default_factory=list)
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "redacted": self.redacted,
            "entities_found": self.entities_found,
            "entity_types": self.entity_types,
            "error": self.error
        }


@dataclass
class BatchResult:
    """Result from batch protect() operation"""
    results: List[BatchItem]
    total_processing_time_ms: float
    documents_processed: int
    total_entities_found: int
    request_id: str = ""

    def __iter__(self):
        return iter(self.results)

    def __len__(self):
        return len(self.results)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "results": [r.to_dict() for r in self.results],
            "total_processing_time_ms": self.total_processing_time_ms,
            "documents_processed": self.documents_processed,
            "total_entities_found": self.total_entities_found,
            "request_id": self.request_id
        }


@dataclass
class HealthCheckResult:
    """Result from health check"""
    status: str
    latency_ms: float
    api_version: str
    timestamp: str


@dataclass
class UsageInfo:
    """API usage information"""
    api_calls: int
    limit: int
    remaining: int
    percentage: float
    reset_at: str
    overage: bool = False
    overage_cost: float = 0.0
