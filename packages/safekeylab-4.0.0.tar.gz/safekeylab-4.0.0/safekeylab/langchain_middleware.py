"""
SafeKeyLab LangChain Middleware - Secure LangChain via SafeKeyLab API

All security checks are performed via SafeKeyLab API.

Usage:
    from langchain.llms import OpenAI
    from safekeylab import SafeKeyLabCallback

    callback = SafeKeyLabCallback(api_key="your-api-key")
    llm = OpenAI(callbacks=[callback])

    # All LLM calls are now protected
    response = llm("Tell me about...")
"""

import logging
from typing import Any, Dict, List
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class SafeKeyLabBlockedError(Exception):
    """Raised when SafeKeyLab blocks a request"""

    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message)
        self.details = details or {}


@dataclass
class CallbackConfig:
    """Configuration for SafeKeyLab callback"""

    # API configuration
    api_key: str = ""
    base_url: str = "https://api.safekeylab.com"

    # Input validation
    validate_input: bool = True
    on_threat: str = "block"  # 'block', 'sanitize', 'log'

    # Output validation
    check_output: bool = True
    redact_output_pii: bool = True

    # PII handling
    allowed_pii_types: List[str] = field(default_factory=list)

    # Chain/Agent validation
    validate_tool_calls: bool = True
    allowed_tools: List[str] = field(default_factory=lambda: ["*"])
    blocked_tools: List[str] = field(default_factory=list)

    # Logging
    log_requests: bool = True
    log_responses: bool = False


# Try to import LangChain - gracefully handle if not installed
try:
    from langchain.callbacks.base import BaseCallbackHandler
    from langchain.schema import LLMResult, AgentAction, AgentFinish

    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

    # Create placeholder classes
    class BaseCallbackHandler:
        pass

    class LLMResult:
        pass

    class AgentAction:
        pass

    class AgentFinish:
        pass


class SafeKeyLabCallback(BaseCallbackHandler):
    """
    LangChain callback that adds SafeKeyLab protection via API.

    All validation is performed via SafeKeyLab API - no local pattern matching.

    Usage:
        from langchain.llms import OpenAI
        from safekeylab import SafeKeyLabCallback

        # Basic usage
        callback = SafeKeyLabCallback(api_key="your-api-key")
        llm = OpenAI(callbacks=[callback])

        # With configuration
        callback = SafeKeyLabCallback(
            api_key="your-api-key",
            on_threat='sanitize',
            redact_output_pii=True,
            allowed_tools=['search', 'calculator']
        )
        llm = OpenAI(callbacks=[callback])
    """

    def __init__(self, api_key: str = None, config: CallbackConfig = None, **kwargs):
        if not LANGCHAIN_AVAILABLE:
            logger.warning("LangChain not installed. Callback will be limited.")

        if config:
            self.config = config
        else:
            self.config = CallbackConfig(api_key=api_key or "", **kwargs)

        self._headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

        self._request_count = 0
        self._blocked_count = 0
        self._pii_detection_count = 0

    def _call_safekeylab_api(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make request to SafeKeyLab API"""
        import requests
        url = f"{self.config.base_url}{endpoint}"
        response = requests.post(url, headers=self._headers, json=data)
        response.raise_for_status()
        return response.json()

    def _validate_input(self, content: str) -> Dict[str, Any]:
        """Validate input via SafeKeyLab API"""
        if not self.config.api_key:
            logger.warning("SafeKeyLab API key not set - skipping validation")
            return {"safe": True}

        try:
            result = self._call_safekeylab_api("/api/v1/prompt/guard", {
                "prompt": content,
                "strictness": "medium"
            })
            return {
                "safe": result.get("is_safe", True),
                "threat_type": ", ".join(result.get("threats_detected", [])),
                "risk_score": result.get("risk_score", 0),
                "sanitized": result.get("sanitized_prompt", content),
            }
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return {"safe": True, "threat_type": None, "risk_score": 0}

    def _detect_pii(self, content: str) -> Dict[str, Any]:
        """Detect PII via SafeKeyLab API"""
        if not self.config.api_key:
            logger.warning("SafeKeyLab API key not set - skipping PII detection")
            return {"found": False, "types": [], "redacted": content}

        try:
            result = self._call_safekeylab_api("/api/v1/pii/scan", {
                "text": content,
                "return_redacted": True
            })
            pii_types = [entity.get("type") for entity in result.get("entities", [])]

            # Filter out allowed PII types
            detected = [t for t in pii_types if t not in self.config.allowed_pii_types]

            return {
                "found": len(detected) > 0,
                "types": detected,
                "redacted": result.get("redacted_text", content),
            }
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return {"found": False, "types": [], "redacted": content}

    def _redact_pii(self, content: str) -> str:
        """Redact PII via SafeKeyLab API"""
        if not self.config.api_key:
            return content

        try:
            result = self._call_safekeylab_api("/api/v1/pii/redact", {
                "text": content,
                "replacement_style": "type"
            })
            return result.get("redacted_text", content)
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return content

    # ===== LLM Callbacks =====

    def on_llm_start(self, serialized: Dict[str, Any], prompts: List[str], **kwargs):
        """Called when LLM starts - validate inputs"""
        self._request_count += 1

        if not self.config.validate_input:
            return

        for i, prompt in enumerate(prompts):
            check = self._validate_input(prompt)

            if not check["safe"]:
                self._blocked_count += 1

                if self.config.on_threat == "block":
                    raise SafeKeyLabBlockedError(
                        f"Prompt {i} blocked: {check['threat_type']}", details=check
                    )
                elif self.config.on_threat == "sanitize":
                    prompts[i] = check.get("sanitized", prompt)
                # 'log' mode: just log
                logger.warning(
                    f"SafeKeyLab: Threat detected in prompt {i}: {check['threat_type']}"
                )

        if self.config.log_requests:
            logger.info(f"SafeKeyLab: LLM start - {len(prompts)} prompts")

    def on_llm_end(self, response: "LLMResult", **kwargs):
        """Called when LLM finishes - check outputs"""
        if not self.config.check_output:
            return

        try:
            for generation in response.generations:
                for gen in generation:
                    pii_check = self._detect_pii(gen.text)

                    if pii_check["found"]:
                        self._pii_detection_count += 1

                        if self.config.redact_output_pii:
                            gen.text = pii_check["redacted"]
                            logger.info(
                                f"SafeKeyLab: PII redacted from output: {pii_check['types']}"
                            )

        except (AttributeError, IndexError) as e:
            logger.debug(f"Could not check LLM output: {e}")

    def on_llm_error(self, error: Exception, **kwargs):
        """Called when LLM errors"""
        logger.error(f"SafeKeyLab: LLM error - {error}")

    # ===== Chat Model Callbacks =====

    def on_chat_model_start(
        self, serialized: Dict[str, Any], messages: List[List[Any]], **kwargs
    ):
        """Called when chat model starts - validate inputs"""
        self._request_count += 1

        if not self.config.validate_input:
            return

        for message_list in messages:
            for msg in message_list:
                # Get content from message
                content = getattr(msg, "content", str(msg))

                if isinstance(content, str):
                    check = self._validate_input(content)

                    if not check["safe"]:
                        self._blocked_count += 1

                        if self.config.on_threat == "block":
                            raise SafeKeyLabBlockedError(
                                f"Message blocked: {check['threat_type']}",
                                details=check,
                            )
                        # Can't easily sanitize in-place for chat messages
                        logger.warning(
                            f"SafeKeyLab: Threat detected: {check['threat_type']}"
                        )

    # ===== Chain Callbacks =====

    def on_chain_start(
        self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs
    ):
        """Called when chain starts"""
        if self.config.log_requests:
            chain_type = serialized.get("name", "Unknown")
            logger.info(f"SafeKeyLab: Chain start - {chain_type}")

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs):
        """Called when chain ends - check outputs"""
        if not self.config.check_output:
            return

        for key, value in outputs.items():
            if isinstance(value, str):
                pii_check = self._detect_pii(value)

                if pii_check["found"]:
                    self._pii_detection_count += 1

                    if self.config.redact_output_pii:
                        outputs[key] = pii_check["redacted"]

    def on_chain_error(self, error: Exception, **kwargs):
        """Called when chain errors"""
        logger.error(f"SafeKeyLab: Chain error - {error}")

    # ===== Agent Callbacks =====

    def on_agent_action(self, action: "AgentAction", **kwargs):
        """Called when agent takes an action - validate tool use"""
        if not self.config.validate_tool_calls:
            return

        tool = action.tool

        # Check if tool is blocked
        if tool in self.config.blocked_tools:
            raise SafeKeyLabBlockedError(
                f"Tool '{tool}' is blocked by policy", details={"tool": tool}
            )

        # Check if tool is allowed
        if "*" not in self.config.allowed_tools:
            if tool not in self.config.allowed_tools:
                raise SafeKeyLabBlockedError(
                    f"Tool '{tool}' not in allowed list",
                    details={"tool": tool, "allowed": self.config.allowed_tools},
                )

        # Validate tool input via API
        tool_input = str(action.tool_input)
        check = self._validate_input(tool_input)

        if not check["safe"]:
            if self.config.on_threat == "block":
                raise SafeKeyLabBlockedError(
                    f"Tool input blocked: {check['threat_type']}", details=check
                )

        logger.info(f"SafeKeyLab: Agent action - tool={tool}")

    def on_agent_finish(self, finish: "AgentFinish", **kwargs):
        """Called when agent finishes"""
        if not self.config.check_output:
            return

        output = finish.return_values.get("output", "")
        if isinstance(output, str):
            pii_check = self._detect_pii(output)

            if pii_check["found"] and self.config.redact_output_pii:
                finish.return_values["output"] = pii_check["redacted"]

    # ===== Tool Callbacks =====

    def on_tool_start(self, serialized: Dict[str, Any], input_str: str, **kwargs):
        """Called when tool starts"""
        if self.config.log_requests:
            tool_name = serialized.get("name", "Unknown")
            logger.info(f"SafeKeyLab: Tool start - {tool_name}")

    def on_tool_end(self, output: str, **kwargs):
        """Called when tool ends - check output"""
        if not self.config.check_output:
            return

        if isinstance(output, str):
            pii_check = self._detect_pii(output)

            if pii_check["found"]:
                self._pii_detection_count += 1
                logger.info(
                    f"SafeKeyLab: PII detected in tool output: {pii_check['types']}"
                )

    def on_tool_error(self, error: Exception, **kwargs):
        """Called when tool errors"""
        logger.error(f"SafeKeyLab: Tool error - {error}")

    # ===== Statistics =====

    def get_statistics(self) -> Dict[str, Any]:
        """Get callback statistics"""
        return {
            "total_requests": self._request_count,
            "blocked_requests": self._blocked_count,
            "pii_detections": self._pii_detection_count,
            "block_rate": (
                self._blocked_count / self._request_count
                if self._request_count > 0
                else 0
            ),
        }


# Convenience function for creating configured callback
def create_safekeylab_callback(
    api_key: str,
    on_threat: str = "block",
    redact_output_pii: bool = True,
    allowed_tools: List[str] = None,
    **kwargs,
) -> SafeKeyLabCallback:
    """
    Create a configured SafeKeyLab callback.

    Args:
        api_key: SafeKeyLab API key (required)
        on_threat: What to do when threat detected ('block', 'sanitize', 'log')
        redact_output_pii: Whether to redact PII from outputs
        allowed_tools: List of allowed tools (for agents)
        **kwargs: Additional config options

    Returns:
        Configured SafeKeyLabCallback instance
    """
    config = CallbackConfig(
        api_key=api_key,
        on_threat=on_threat,
        redact_output_pii=redact_output_pii,
        allowed_tools=allowed_tools or ["*"],
        **kwargs,
    )
    return SafeKeyLabCallback(config=config)
