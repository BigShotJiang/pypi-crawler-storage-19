"""
SafeKeyLab SDK - Enterprise AI Security via SafeKeyLab API

All security checks are performed via SafeKeyLab API.
This SDK provides thin client wrappers for:
- OpenAI
- Anthropic
- LangChain

For API access, visit https://safekeylab.com

SafeKey Lab, Inc.
"""

__version__ = "4.0.0"
__author__ = "SafeKey Lab Inc."

from .client import SafeKeyLab
from .client_v2 import (
    SafeKeyLabClient as SafeKeyLabClientV2,
    RateLimitException,
    QuotaExceededException,
    FeatureNotAvailableException,
    create_client,
)
from .exceptions import SafeKeyLabException, APIError, ValidationError

# New unified client with protect() API
from .unified_client import SafeKeyClient, SafeKeyLabClient
from .result_types import (
    PIIEntity,
    ProtectionResult,
    DetectionResult,
    BatchItem,
    BatchResult,
    HealthCheckResult,
    UsageInfo,
)

# OpenAI wrapper
from .openai_wrapper import (
    SafeKeyLabOpenAI,
    wrap_openai,
    SafeKeyLabConfig as OpenAIConfig,
    SafeKeyLabBlockedError as OpenAIBlockedError,
)

# Anthropic wrapper
from .anthropic_wrapper import (
    SafeKeyLabAnthropic,
    wrap_anthropic,
    SafeKeyLabConfig as AnthropicConfig,
    SafeKeyLabBlockedError as AnthropicBlockedError,
)

# LangChain middleware
from .langchain_middleware import (
    SafeKeyLabCallback,
    CallbackConfig,
    create_safekeylab_callback,
    SafeKeyLabBlockedError,
)

__all__ = [
    # Core clients
    "SafeKeyLab",
    "SafeKeyClient",
    "SafeKeyLabClient",
    "SafeKeyLabClientV2",
    "create_client",
    "RateLimitException",
    "QuotaExceededException",
    "FeatureNotAvailableException",
    # Result types
    "PIIEntity",
    "ProtectionResult",
    "DetectionResult",
    "BatchItem",
    "BatchResult",
    "HealthCheckResult",
    "UsageInfo",
    # Exceptions
    "SafeKeyLabException",
    "APIError",
    "ValidationError",
    # OpenAI wrapper
    "SafeKeyLabOpenAI",
    "wrap_openai",
    "OpenAIConfig",
    "OpenAIBlockedError",
    # Anthropic wrapper
    "SafeKeyLabAnthropic",
    "wrap_anthropic",
    "AnthropicConfig",
    "AnthropicBlockedError",
    # LangChain middleware
    "SafeKeyLabCallback",
    "CallbackConfig",
    "create_safekeylab_callback",
    "SafeKeyLabBlockedError",
]
