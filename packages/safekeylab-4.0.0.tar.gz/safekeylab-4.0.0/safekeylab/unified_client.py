"""
SafeKeyLab Unified Client - Clean API matching documentation

This client provides the `protect()` and `detect()` methods that match
the API documentation and proposal materials.
"""

import time
import requests
import hashlib
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass

from .result_types import (
    PIIEntity,
    ProtectionResult,
    DetectionResult,
    BatchItem,
    BatchResult,
    HealthCheckResult,
    UsageInfo
)
from .exceptions import APIError, ValidationError


# Default entity types for detection
DEFAULT_ENTITIES = [
    "EMAIL", "PHONE", "SSN", "CREDIT_CARD", "NAME", "ADDRESS",
    "DATE_OF_BIRTH", "API_KEY", "PRIVATE_KEY", "PASSWORD"
]


class SafeKeyClient:
    """
    SafeKey Lab unified client with clean protect()/detect() API.

    This is the recommended client for integrations including Google ADK.

    Example:
        client = SafeKeyClient(api_key="sk_live_xxx")
        result = client.protect("Contact john@example.com")
        print(result.redacted)  # "Contact [EMAIL_REDACTED]"
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.safekeylab.com",
        timeout: int = 30,
        max_retries: int = 3,
        cache_enabled: bool = False,
        cache_ttl: int = 300
    ):
        """
        Initialize SafeKey Lab client.

        Args:
            api_key: Your SafeKey Lab API key (sk_live_xxx or sk_test_xxx)
            base_url: API base URL (default: https://api.safekeylab.com)
            timeout: Request timeout in seconds
            max_retries: Maximum retry attempts for failed requests
            cache_enabled: Enable response caching for repeated content
            cache_ttl: Cache time-to-live in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.cache_enabled = cache_enabled
        self.cache_ttl = cache_ttl

        self._cache: Dict[str, tuple] = {}  # hash -> (result, timestamp)
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "SafeKeyLab-SDK/3.0.0"
        })

        # Track last request info
        self.last_request_id: str = ""
        self.last_processing_time: float = 0

    def protect(
        self,
        text: str,
        config: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None
    ) -> ProtectionResult:
        """
        Detect and redact PII from text.

        This is the primary method for PII protection - it detects PII
        and returns redacted text in a single call.

        Args:
            text: Text to scan and protect
            config: Optional configuration dict with:
                - entities: List of entity types to detect (default: all)
                - redaction_type: "mask", "hash", "partial", "replace", "remove"
                - confidence_threshold: Minimum confidence (0.0-1.0)
                - return_positions: Include character positions
            timeout: Override default timeout for this request

        Returns:
            ProtectionResult with redacted text and entity details

        Example:
            result = client.protect("My SSN is 123-45-6789")
            print(result.redacted)  # "My SSN is [SSN_REDACTED]"
            print(result.entities)  # [PIIEntity(type="SSN", ...)]
        """
        start_time = time.time()

        # Check cache
        if self.cache_enabled:
            cache_key = self._cache_key(text, config)
            cached = self._get_cached(cache_key)
            if cached:
                return cached

        # Build request
        payload = {
            "text": text,
            "config": config or {
                "entities": DEFAULT_ENTITIES,
                "redaction_type": "mask",
                "return_positions": True
            }
        }

        # Make request
        response = self._request(
            "POST",
            "/v1/protect",
            payload,
            timeout=timeout or self.timeout
        )

        # Parse response into result object
        entities = [
            PIIEntity(
                type=e.get("type", "UNKNOWN"),
                value=e.get("value", ""),
                start=e.get("start", 0),
                end=e.get("end", 0),
                confidence=e.get("confidence", 0.0),
                subtype=e.get("subtype"),
                metadata=e.get("metadata", {})
            )
            for e in response.get("entities", [])
        ]

        processing_time = (time.time() - start_time) * 1000

        result = ProtectionResult(
            original=response.get("original", text),
            redacted=response.get("redacted", text),
            entities=entities,
            processing_time_ms=response.get("processing_time_ms", processing_time),
            request_id=response.get("request_id", self.last_request_id),
            cached=False
        )

        # Store in cache
        if self.cache_enabled:
            self._set_cached(cache_key, result)

        return result

    def detect(
        self,
        text: str,
        config: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None
    ) -> DetectionResult:
        """
        Detect PII in text without redacting.

        Use this for scanning/alerting when you need to know what PII
        exists but don't need to modify the text.

        Args:
            text: Text to scan
            config: Optional configuration dict
            timeout: Override default timeout

        Returns:
            DetectionResult with entity details

        Example:
            result = client.detect("Contact john@example.com")
            if result.has_pii:
                print(f"Found: {result.entity_types}")
        """
        start_time = time.time()

        payload = {
            "text": text,
            "config": config or {"entities": DEFAULT_ENTITIES}
        }

        response = self._request(
            "POST",
            "/v1/detect",
            payload,
            timeout=timeout or self.timeout
        )

        entities = [
            PIIEntity(
                type=e.get("type", "UNKNOWN"),
                value=e.get("value", ""),
                start=e.get("start", 0),
                end=e.get("end", 0),
                confidence=e.get("confidence", 0.0),
                subtype=e.get("subtype"),
                metadata=e.get("metadata", {})
            )
            for e in response.get("entities", [])
        ]

        processing_time = (time.time() - start_time) * 1000

        return DetectionResult(
            text=text,
            has_pii=len(entities) > 0,
            entities=entities,
            processing_time_ms=response.get("processing_time_ms", processing_time),
            request_id=response.get("request_id", self.last_request_id)
        )

    def protect_batch(
        self,
        documents: List[Dict[str, str]],
        config: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None
    ) -> BatchResult:
        """
        Process multiple documents in a single request.

        More efficient than multiple protect() calls for batch processing.

        Args:
            documents: List of dicts with "id" and "text" keys
            config: Optional configuration dict
            timeout: Override default timeout

        Returns:
            BatchResult with results for each document

        Example:
            docs = [
                {"id": "doc1", "text": "SSN: 123-45-6789"},
                {"id": "doc2", "text": "Email: test@example.com"}
            ]
            result = client.protect_batch(docs)
            for doc in result:
                print(f"{doc.id}: {doc.redacted}")
        """
        start_time = time.time()

        payload = {
            "documents": documents,
            "config": config or {
                "entities": DEFAULT_ENTITIES,
                "redaction_type": "mask",
                "parallel": True
            }
        }

        response = self._request(
            "POST",
            "/v1/protect/batch",
            payload,
            timeout=timeout or self.timeout * 2  # Longer timeout for batch
        )

        results = [
            BatchItem(
                id=r.get("id", ""),
                redacted=r.get("redacted", ""),
                entities_found=r.get("entities_found", 0),
                entity_types=r.get("entity_types", []),
                error=r.get("error")
            )
            for r in response.get("results", [])
        ]

        processing_time = (time.time() - start_time) * 1000

        return BatchResult(
            results=results,
            total_processing_time_ms=response.get("total_processing_time_ms", processing_time),
            documents_processed=response.get("documents_processed", len(results)),
            total_entities_found=sum(r.entities_found for r in results),
            request_id=response.get("request_id", self.last_request_id)
        )

    def create_pattern(
        self,
        name: str,
        pattern: str,
        description: str = "",
        category: str = "CUSTOM",
        confidence: float = 0.9
    ) -> Dict[str, Any]:
        """
        Create a custom PII detection pattern.

        Args:
            name: Unique pattern name (e.g., "employee_id")
            pattern: Regex pattern to match
            description: Human-readable description
            category: Category for grouping (e.g., "INTERNAL_ID")
            confidence: Default confidence score (0.0-1.0)

        Returns:
            Pattern creation response with pattern_id

        Example:
            client.create_pattern(
                name="ardor_project_id",
                pattern=r"proj_[a-zA-Z0-9]{12}",
                description="Ardor project identifier",
                category="INTERNAL_ID"
            )
        """
        payload = {
            "name": name,
            "pattern": pattern,
            "description": description,
            "category": category,
            "confidence": confidence
        }

        return self._request("POST", "/v1/patterns", payload)

    def list_patterns(self) -> List[Dict[str, Any]]:
        """List all custom patterns for this account."""
        return self._request("GET", "/v1/patterns")

    def delete_pattern(self, pattern_id: str) -> Dict[str, Any]:
        """Delete a custom pattern by ID."""
        return self._request("DELETE", f"/v1/patterns/{pattern_id}")

    def get_usage(self) -> UsageInfo:
        """
        Get current API usage statistics.

        Returns:
            UsageInfo with current usage and limits
        """
        response = self._request("GET", "/v1/usage")
        usage = response.get("usage", {})

        return UsageInfo(
            api_calls=usage.get("api_calls", 0),
            limit=usage.get("limit", 0),
            remaining=usage.get("remaining", 0),
            percentage=usage.get("percentage", 0.0),
            reset_at=usage.get("reset_at", ""),
            overage=usage.get("overage", False),
            overage_cost=usage.get("overage_cost", 0.0)
        )

    def health_check(self) -> HealthCheckResult:
        """
        Check API health and connectivity.

        Returns:
            HealthCheckResult with status and latency
        """
        start_time = time.time()
        response = self._request("GET", "/v1/health")
        latency = (time.time() - start_time) * 1000

        return HealthCheckResult(
            status=response.get("status", "unknown"),
            latency_ms=latency,
            api_version=response.get("version", "unknown"),
            timestamp=response.get("timestamp", "")
        )

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None,
        timeout: Optional[int] = None
    ) -> Dict[str, Any]:
        """Make API request with retry logic."""
        url = f"{self.base_url}{endpoint}"
        timeout = timeout or self.timeout

        last_error = None
        for attempt in range(self.max_retries):
            try:
                if method == "GET":
                    response = self._session.get(url, timeout=timeout)
                elif method == "POST":
                    response = self._session.post(url, json=data, timeout=timeout)
                elif method == "DELETE":
                    response = self._session.delete(url, timeout=timeout)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")

                # Store request ID from headers
                self.last_request_id = response.headers.get("X-Request-ID", "")

                # Handle response
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 400:
                    raise ValidationError(response.json().get("error", "Bad request"))
                elif response.status_code == 401:
                    raise APIError("Invalid API key")
                elif response.status_code == 429:
                    # Rate limited - exponential backoff
                    retry_after = int(response.headers.get("Retry-After", 2 ** attempt))
                    if attempt < self.max_retries - 1:
                        time.sleep(retry_after)
                        continue
                    raise APIError(f"Rate limit exceeded. Retry after {retry_after}s")
                else:
                    response.raise_for_status()

            except requests.exceptions.Timeout:
                last_error = APIError(f"Request timeout after {timeout}s")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
            except requests.exceptions.RequestException as e:
                last_error = APIError(f"Request failed: {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue

        raise last_error or APIError("Request failed after retries")

    def _cache_key(self, text: str, config: Optional[Dict]) -> str:
        """Generate cache key for text + config."""
        config_str = str(sorted(config.items())) if config else ""
        content = f"{text}:{config_str}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _get_cached(self, key: str) -> Optional[ProtectionResult]:
        """Get cached result if valid."""
        if key in self._cache:
            result, timestamp = self._cache[key]
            if time.time() - timestamp < self.cache_ttl:
                # Return cached result with cached flag
                return ProtectionResult(
                    original=result.original,
                    redacted=result.redacted,
                    entities=result.entities,
                    processing_time_ms=0,  # Instant from cache
                    request_id=result.request_id,
                    cached=True
                )
            else:
                del self._cache[key]
        return None

    def _set_cached(self, key: str, result: ProtectionResult) -> None:
        """Store result in cache."""
        self._cache[key] = (result, time.time())

        # Simple cache eviction - remove oldest if too large
        if len(self._cache) > 1000:
            oldest_key = min(self._cache, key=lambda k: self._cache[k][1])
            del self._cache[oldest_key]


# Alias for documentation consistency
SafeKeyLabClient = SafeKeyClient
