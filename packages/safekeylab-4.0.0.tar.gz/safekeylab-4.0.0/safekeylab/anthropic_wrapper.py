"""
SafeKeyLab Anthropic Wrapper - Secure Anthropic API calls via SafeKeyLab API
"""

import time
import logging
from typing import List, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger("safekeylab")


class SafeKeyLabBlockedError(Exception):
    """Raised when input/output is blocked by SafeKeyLab"""
    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message)
        self.details = details or {}


@dataclass
class SafeKeyLabConfig:
    """Configuration for SafeKeyLab Anthropic wrapper"""
    api_key: str
    base_url: str = "https://api.safekeylab.com"
    validate_input: bool = True
    validate_output: bool = True
    redact_pii: bool = False
    on_threat: str = "block"  # "block", "sanitize", or "log"
    log_requests: bool = False


class SafeKeyLabAnthropic:
    """
    Anthropic-compatible client with SafeKeyLab security.
    All security checks are performed via SafeKeyLab API.
    """

    def __init__(self, anthropic_client: Any, config: SafeKeyLabConfig):
        self._client = anthropic_client
        self._config = config
        self.messages = self

        self._headers = {
            "Authorization": f"Bearer {config.api_key}",
            "Content-Type": "application/json",
        }

    def _call_safekeylab_api(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Make request to SafeKeyLab API"""
        import requests
        url = f"{self._config.base_url}{endpoint}"
        response = requests.post(url, headers=self._headers, json=data)
        response.raise_for_status()
        return response.json()

    def _validate_input(self, content: str) -> Dict[str, Any]:
        """Validate input via SafeKeyLab API"""
        try:
            result = self._call_safekeylab_api("/api/v1/prompt/guard", {
                "prompt": content,
                "strictness": "medium"
            })
            return {
                "safe": result.get("is_safe", True),
                "threat_type": ", ".join(result.get("threats_detected", [])),
                "risk_score": result.get("risk_score", 0),
                "sanitized": content,
            }
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return {"safe": True, "threat_type": None, "risk_score": 0}

    def _validate_output(self, content: str) -> Dict[str, Any]:
        """Validate output via SafeKeyLab API"""
        try:
            result = self._call_safekeylab_api("/api/v1/output/validate", {
                "output": content,
                "check_pii": True,
                "check_secrets": True,
            })
            return {
                "safe": result.get("is_safe", True),
                "leakage": result.get("leakage_detected", []),
                "risk_score": result.get("risk_score", 0),
            }
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return {"safe": True, "leakage": [], "risk_score": 0}

    def _redact_pii(self, content: str) -> str:
        """Redact PII via SafeKeyLab API"""
        try:
            result = self._call_safekeylab_api("/api/v1/pii/redact", {
                "text": content,
                "replacement_style": "type"
            })
            return result.get("redacted_text", content)
        except Exception as e:
            logger.warning(f"SafeKeyLab API error: {e}")
            return content

    def create(self, model: str, messages: List[Dict[str, Any]], max_tokens: int, **kwargs) -> Any:
        """Create message with security checks"""
        start_time = time.time()

        # 1. Validate all user messages
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check["safe"]:
                            if self._config.on_threat == "block":
                                raise SafeKeyLabBlockedError(
                                    f"Input blocked: {check['threat_type']}",
                                    details=check,
                                )
                            elif self._config.on_threat == "sanitize":
                                messages[i]["content"] = check.get("sanitized", content)

        # 2. Log request if enabled
        if self._config.log_requests:
            logger.info(f"SafeKeyLab: Anthropic request - model={model}")

        # 3. Make Anthropic request
        response = self._client.messages.create(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )

        # 4. Validate output
        if self._config.validate_output and hasattr(response, "content"):
            for block in response.content:
                if hasattr(block, "text") and block.text:
                    check = self._validate_output(block.text)
                    if not check["safe"]:
                        if self._config.on_threat == "block":
                            raise SafeKeyLabBlockedError(
                                "Output blocked: data leakage detected",
                                details=check,
                            )

        # 5. Redact PII if enabled
        if self._config.redact_pii and hasattr(response, "content"):
            for block in response.content:
                if hasattr(block, "text") and block.text:
                    block.text = self._redact_pii(block.text)

        # 6. Log timing
        elapsed = time.time() - start_time
        if self._config.log_requests:
            logger.info(f"SafeKeyLab: Request completed in {elapsed:.2f}s")

        return response

    def stream(self, model: str, messages: List[Dict[str, Any]], max_tokens: int, **kwargs):
        """Stream with security checks on input"""
        # Validate inputs before streaming
        if self._config.validate_input:
            for i, msg in enumerate(messages):
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        check = self._validate_input(content)
                        if not check["safe"]:
                            if self._config.on_threat == "block":
                                raise SafeKeyLabBlockedError(
                                    f"Input blocked: {check['threat_type']}",
                                    details=check,
                                )

        return self._client.messages.stream(
            model=model, messages=messages, max_tokens=max_tokens, **kwargs
        )


def wrap_anthropic(client: Any, api_key: str, **config_kwargs) -> SafeKeyLabAnthropic:
    """
    Wrap an Anthropic client with SafeKeyLab security.

    Args:
        client: Anthropic client instance
        api_key: SafeKeyLab API key
        **config_kwargs: Additional configuration options

    Returns:
        SafeKeyLab-wrapped Anthropic client
    """
    config = SafeKeyLabConfig(api_key=api_key, **config_kwargs)
    return SafeKeyLabAnthropic(client, config)
