"""
SafeKeyLab Exceptions
"""


class SafeKeyLabException(Exception):
    """Base exception for SafeKeyLab SDK"""


class APIError(SafeKeyLabException):
    """API-related errors"""


class ValidationError(SafeKeyLabException):
    """Validation errors"""


class AuthenticationError(SafeKeyLabException):
    """Authentication errors"""


class RateLimitError(SafeKeyLabException):
    """Rate limit errors"""


class ConfigurationError(SafeKeyLabException):
    """Configuration errors"""
