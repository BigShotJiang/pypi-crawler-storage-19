# SafeKeyLab SDK

[![PyPI version](https://badge.fury.io/py/safekeylab.svg)](https://pypi.org/project/safekeylab/)
[![Python Versions](https://img.shields.io/pypi/pyversions/safekeylab.svg)](https://pypi.org/project/safekeylab/)
[![License](https://img.shields.io/badge/License-Proprietary-red.svg)](https://safekeylab.com/terms)

**Enterprise AI Security & PII Protection** - Protect your AI applications from prompt injection, data leaks, and compliance violations.

## Features

- **PII Detection & Redaction** - 30+ entity types with 99.9% accuracy
- **LLM Security Guard** - Block prompt injection, jailbreaks, and adversarial attacks
- **Framework Integrations** - LangChain, LlamaIndex, Semantic Kernel, Google ADK
- **Compliance Ready** - GDPR, HIPAA, SOC2, PCI-DSS reporting

## Installation

```bash
pip install safekeylab
```

With framework integrations:
```bash
pip install safekeylab[langchain]
pip install safekeylab[llamaindex]
pip install safekeylab[semantic-kernel]
pip install safekeylab[google-adk]
pip install safekeylab[all]
```

## Quick Start

```python
from safekeylab import SafeKeyLab

client = SafeKeyLab(api_key="sk_live_...")

# Detect PII
result = client.detect("Contact john@example.com for details")
print(result.entities)

# Redact PII
protected = client.redact("My SSN is 123-45-6789")
print(protected)  # "My SSN is [SSN]"

# Validate prompts for threats
validation = client.validate_prompt("user input here")
if validation.is_safe:
    # Safe to send to LLM
    pass
```

## Framework Integrations

### LangChain
```python
from safekeylab.integrations import SafeKeyLabCallbackHandler

handler = SafeKeyLabCallbackHandler(api_key="sk_live_...")
# Add to your LangChain callbacks
```

### Google ADK
```python
from safekeylab.integrations import SafeKeyLabADKTools

tools = SafeKeyLabADKTools(api_key="sk_live_...")
# Use with Google Agent Development Kit
```

See [documentation](https://safekeylab.com/docs) for LlamaIndex and Semantic Kernel examples.

## Pricing

| Plan | API Calls/mo | Price |
|------|-------------|-------|
| Developer | 1,000 | Free |
| Startup | 10,000 | $49/mo |
| Growth | 100,000 | $299/mo |
| Enterprise | Unlimited | Contact us |

[View full pricing](https://safekeylab.com/pricing)

## Documentation

- [Getting Started](https://safekeylab.com/docs/getting-started)
- [API Reference](https://safekeylab.com/docs/api)
- [Integration Guides](https://safekeylab.com/docs/integrations)

## Support

- Email: support@safekeylab.com
- Documentation: https://safekeylab.com/docs

---

## Terms of Use

By installing, accessing, or using this SDK, you agree to be bound by SafeKeyLab's [Terms of Service](https://safekeylab.com/terms) and [API License Agreement](https://safekeylab.com/api-license).

### Restrictions

- **No Reverse Engineering**: Decompilation, disassembly, or reverse engineering of this SDK is strictly prohibited.
- **No Redistribution**: Redistribution, sublicensing, or resale of this SDK requires prior written consent from SafeKey Lab, Inc.
- **No Derivative Works**: Creating derivative works based on this SDK's proprietary technology is prohibited.
- **Usage Monitoring**: API usage is monitored for compliance and service optimization.

### Intellectual Property

This SDK and all associated documentation, algorithms, and methodologies are proprietary to SafeKey Lab, Inc. and protected by intellectual property laws including patents (pending), copyrights, and trade secrets.

**Patent Pending** - SafeKey Lab, Inc.

### Disclaimer

THIS SDK IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. SAFEKEYLAB SHALL NOT BE LIABLE FOR ANY DAMAGES ARISING FROM USE OF THIS SDK.

---

Copyright 2024-2025 SafeKey Lab, Inc. All rights reserved.
