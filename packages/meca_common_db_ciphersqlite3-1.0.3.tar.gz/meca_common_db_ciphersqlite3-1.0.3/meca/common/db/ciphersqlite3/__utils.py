from importlib import util as _libutil
from sqlite3 import Connection


def set_pw(conn: Connection, pw: str, rk=False):
    key = f'''"x'{pw}'"''' if rk else f'''"{pw}"'''
    cursor = conn.cursor()
    cursor.execute(f'PRAGMA key={key}')
    cursor.close()

_sqlalchemy_installed = _libutil.find_spec('sqlalchemy')

if _sqlalchemy_installed:

    from typing import Callable

    from sqlalchemy import event
    from sqlalchemy.engine import Engine
    
    def _alchemy_pw(self: Engine, pw: str, rk=False) -> Engine:
        conn = self.raw_connection()
        set_pw(conn, pw, rk)
        conn.commit()
        conn.close()
        return self

    def _alchemy_pr(self: Engine, pw: str) -> Engine:
        return _alchemy_pw(self, pw, True)

    def readonly(eg: Engine):
        def _readonly_on_connect(dbapi_connection, connection_record):
            if isinstance(dbapi_connection, Connection):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA query_only = 1")
                cursor.close()

        @event.listens_for(eg, 'connect')
        def __listener(dbapi_connection, connection_record):
            _readonly_on_connect(dbapi_connection, connection_record)

    def _readonly(self: Engine) -> Engine:
        readonly(self)
        return self

    Engine.pw = _alchemy_pw
    Engine.pr = _alchemy_pr
    Engine.readonly = _readonly

    if not hasattr(Engine, '__annotations__'):
        Engine.__annotations__ = {}

    Engine.__annotations__['pw'] = Callable[[Engine, str, bool], Engine]
    Engine.__annotations__['pr'] = Callable[[Engine, str], Engine]
    Engine.__annotations__['readonly'] = Callable[[Engine], Engine]