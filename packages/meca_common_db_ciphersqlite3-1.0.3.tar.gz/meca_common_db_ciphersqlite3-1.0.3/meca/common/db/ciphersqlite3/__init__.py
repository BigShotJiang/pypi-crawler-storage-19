from ctypes import CDLL as __CDLL
from importlib import resources as __resources_loader
from pathlib import Path as __Path

with __resources_loader.path(__package__, 'resources', 'sqlite3.dll') as _dll:
    if __Path(_dll).exists(): __CDLL(_dll)

import sqlite3

from .__utils import _sqlalchemy_installed, set_pw

if _sqlalchemy_installed:
    from .__utils import Engine

__all__ = ['sqlite3', 'set_pw', 'Engine']
