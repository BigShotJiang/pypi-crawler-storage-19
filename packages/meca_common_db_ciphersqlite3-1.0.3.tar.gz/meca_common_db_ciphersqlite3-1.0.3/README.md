## 快速开始

1. 安装包

```bash
pip install meca-common-db-ciphersqlite3
```

2. 使用

直接使用sqlite3读取数据库

```python
from meca.common.db.ciphersqlite3 import sqlite3
conn = sqlite3.connect('test.db')
conn.execute('PRAGMA key=<key>')
row = conn.execute('select * from sqlite_master').fetchone()
conn.close()
print(row)
```

使用sqlalchemy读取数据库

```python
from meca.common.db.ciphersqlite3 import Engine
from sqlalchemy import create_engine
engine :Engine = create_engine('sqlite:///en01.db').pw('<key>').readonly()
...
```

函数

- `.pw`: 设置key
- `.pr`: 设置rawkey
- `.readonly`: 设置只读
