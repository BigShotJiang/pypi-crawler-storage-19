# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AddUserToApp:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'users': 'list[User]'
    }

    attribute_map = {
        'users': 'users'
    }

    def __init__(self, users=None):
        r"""AddUserToApp

        The model defined in huaweicloud sdk

        :param users: 要添加的用户成员列表，空列表时代表清空应用的所有成员
        :type users: list[:class:`huaweicloudsdkroma.v2.User`]
        """
        
        

        self._users = None
        self.discriminator = None

        if users is not None:
            self.users = users

    @property
    def users(self):
        r"""Gets the users of this AddUserToApp.

        要添加的用户成员列表，空列表时代表清空应用的所有成员

        :return: The users of this AddUserToApp.
        :rtype: list[:class:`huaweicloudsdkroma.v2.User`]
        """
        return self._users

    @users.setter
    def users(self, users):
        r"""Sets the users of this AddUserToApp.

        要添加的用户成员列表，空列表时代表清空应用的所有成员

        :param users: The users of this AddUserToApp.
        :type users: list[:class:`huaweicloudsdkroma.v2.User`]
        """
        self._users = users

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AddUserToApp):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
