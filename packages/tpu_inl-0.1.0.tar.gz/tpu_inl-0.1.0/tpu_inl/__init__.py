"""
TPU-INL: Cross-Platform Integrator Neuron Layer Acceleration

Unified API for INL dynamics across:
- TPU (JAX/Pallas)
- GPU (Triton/CUDA)
- CPU (PyTorch fallback)

Usage:
    from tpu_inl import inl_dynamics, MoEIntegrator, get_backend

    # Auto-detects best backend
    x_next, v_next = inl_dynamics(x, v, mu, alpha, beta, gate, dt)

    # Check which backend is active
    print(f"Using backend: {get_backend()}")

Author: Boris Peyriguere / Pacific Prime
"""

__version__ = "0.1.0"

from .autodetect import get_backend, set_backend, Backend
from .ops.inl_dynamics import inl_dynamics, inl_dynamics_step
from .ops.moe_routing import MoERouter, moe_dispatch, moe_combine
from .ops.fused_ops import fused_inl_moe, FusedINLLayer

__all__ = [
    # Backend detection
    "get_backend",
    "set_backend",
    "Backend",
    # INL dynamics
    "inl_dynamics",
    "inl_dynamics_step",
    # MoE routing
    "MoERouter",
    "moe_dispatch",
    "moe_combine",
    # Fused operations
    "fused_inl_moe",
    "FusedINLLayer",
]
