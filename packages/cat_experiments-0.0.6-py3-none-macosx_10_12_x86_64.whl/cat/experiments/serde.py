"""Serialization helpers for persisting experiment artifacts.

DEPRECATED: Import from cat.experiments.protocol instead.
This module re-exports functions from the protocol.serde module for backward compatibility.
"""

from __future__ import annotations

# Re-export from new location for backward compatibility
from .protocol.serde import (
    dataset_example_from_dict,
    dataset_example_to_dict,
    deserialize_datetime,
    experiment_config_from_dict,
    experiment_config_to_dict,
    experiment_result_from_dict,
    experiment_result_to_dict,
    experiment_summary_from_dict,
    experiment_summary_to_dict,
    serialize_datetime,
)

__all__ = [
    "serialize_datetime",
    "deserialize_datetime",
    "experiment_config_to_dict",
    "experiment_config_from_dict",
    "dataset_example_to_dict",
    "dataset_example_from_dict",
    "experiment_result_to_dict",
    "experiment_result_from_dict",
    "experiment_summary_to_dict",
    "experiment_summary_from_dict",
]
