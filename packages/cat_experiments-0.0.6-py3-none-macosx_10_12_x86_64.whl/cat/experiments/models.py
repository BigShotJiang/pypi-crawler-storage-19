"""Core data models for cat-experiments.

DEPRECATED: Import from cat.experiments.protocol instead.
This module re-exports types from the protocol package for backward compatibility.
"""

from __future__ import annotations

# Re-export from new location for backward compatibility
from .protocol import (
    AggregateEvaluationContext,
    DatasetExample,
    EvaluationContext,
    EvaluationMetric,
    EvaluatorResult,
    TestCase,
    TestFunctionOutput,
)

__all__ = [
    "DatasetExample",
    "TestCase",
    "EvaluationContext",
    "EvaluationMetric",
    "AggregateEvaluationContext",
    "TestFunctionOutput",
    "EvaluatorResult",
]
