"""
cat-experiments: Standalone evaluation engine for LLM applications.

A flexible, DataFrame-compatible evaluation system that works standalone
or integrates with cat-cafe server infrastructure.

Primary usage is via the CLI: `cat-experiments run <experiment_file.py>`

Package Structure:
    protocol/ - Shared types (TaskInput, TaskOutput, EvalInput, EvalOutput, etc.)
    sdk/      - Python SDK for writing experiments (@task, @evaluator decorators)
    runner/   - CLI orchestrator, executor, storage backends (eventually Go/Rust)

Recommended imports for writing experiments:
    from cat.experiments.protocol import TaskInput, TaskOutput, EvalInput, EvalOutput
    from cat.experiments.sdk import task, evaluator
    from cat.experiments.sdk.tracing import capture_tool_calls

For runner/orchestration (advanced usage):
    from cat.experiments.runner import Orchestrator, LocalStorageBackend
"""

from __future__ import annotations

# Re-export commonly used types for convenience
# Users can also import directly from subpackages for clarity

# Protocol types
# Core models
from .models import (
    AggregateEvaluationContext,
    DatasetExample,
    EvaluationContext,
    EvaluationMetric,
)
from .protocol import (
    EvalInput,
    EvalOutput,
    TaskInput,
    TaskOutput,
)

# Dataset loading
from .runner.datasets import (
    CatCafeLoader,
    DatasetLoader,
    FileLoader,
    PhoenixLoader,
    load_dataset,
)

# SDK decorators and utilities
from .sdk import (
    ToolCallMatch,
    ToolCallMatchingResult,
    evaluator,
    make_wilson_ci_aggregate,
    match_tool_calls,
    run,
    task,
)

__all__ = [
    # Protocol types
    "TaskInput",
    "TaskOutput",
    "EvalInput",
    "EvalOutput",
    # SDK decorators
    "task",
    "evaluator",
    "run",
    # Core Models
    "DatasetExample",
    "EvaluationContext",
    "AggregateEvaluationContext",
    "EvaluationMetric",
    # Dataset Loading
    "DatasetLoader",
    "FileLoader",
    "CatCafeLoader",
    "PhoenixLoader",
    "load_dataset",
    # Tool Call Matching
    "match_tool_calls",
    "ToolCallMatch",
    "ToolCallMatchingResult",
    # Aggregate Evaluators
    "make_wilson_ci_aggregate",
]
