#!/usr/bin/env python3
#   Copyright 2026 UCP Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""Example usage of the type-safe UCP Client."""

import asyncio
import logging
from ucp_client import UCPClient, UCPClientError
from ucp_sdk.models.schemas.shopping import checkout_create_req
from ucp_sdk.models.schemas.shopping import checkout_update_req
from ucp_sdk.models.schemas.shopping.types import buyer
from ucp_sdk.models.schemas.shopping.types import item_create_req
from ucp_sdk.models.schemas.shopping.types import line_item_create_req
from ucp_sdk.models.schemas.shopping.types.postal_address import PostalAddress

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def example_usage():
    """Demonstrate basic UCP client usage."""
    # Initialize client
    async with UCPClient(
        base_url="http://localhost:8182",
        api_key="your-api-key-here",  # Optional
        ucp_agent_profile='profile="https://agent.example/profile"'
    ) as client:

        try:
            # 1. Get merchant profile (discovery)
            logger.info("Getting merchant profile...")
            profile = await client.get_merchant_profile()
            logger.info(f"Merchant supports {len(profile.ucp.capabilities)} capabilities")
            print(f"Supported services: {list(profile.ucp.services.keys())}")

            # 2. Create a checkout session
            logger.info("Creating checkout session...")
            checkout_request = checkout_create_req.CheckoutCreateRequest(
                buyer=buyer.Buyer(
                    email="customer@example.com",
                    first_name="John",
                    last_name="Doe"
                ),
                items=[
                    item_create_req.ItemCreateRequest(
                        line_items=[
                            line_item_create_req.LineItemCreateRequest(
                                product_id="rose-bouquet",
                                quantity=1,
                                price={"amount": "5000", "currency": "USD"}
                            )
                        ]
                    )
                ],
                billing_address=PostalAddress(
                    first_name="John",
                    last_name="Doe",
                    address1="123 Main St",
                    city="Anytown",
                    province="CA",
                    country="US",
                    zip="12345"
                ),
                shipping_address=PostalAddress(
                    first_name="John",
                    last_name="Doe",
                    address1="123 Main St",
                    city="Anytown",
                    province="CA",
                    country="US",
                    zip="12345"
                )
            )

            checkout = await client.create_checkout(checkout_request)
            checkout_id = checkout.id
            logger.info(f"Created checkout with ID: {checkout_id}")

            # 3. Get checkout details
            logger.info("Getting checkout details...")
            checkout_details = await client.get_checkout(checkout_id)
            logger.info(f"Checkout has {len(checkout_details.items)} items")

            # 4. Update checkout (add discount code)
            logger.info("Updating checkout with discount...")
            update_request = checkout_update_req.CheckoutUpdateRequest(
                discounts=[{
                    "code": "SAVE10",
                    "amount": {"amount": "1000", "currency": "USD"}
                }]
            )

            updated_checkout = await client.update_checkout(checkout_id, update_request)
            logger.info("Checkout updated with discount")

            # 5. Complete checkout with payment
            logger.info("Completing checkout with payment...")
            payment_data = {
                "id": "card_123",
                "type": "card",
                "card": {
                    "number": "4111111111111111",
                    "expiry_month": 12,
                    "expiry_year": 2025,
                    "cvv": "123",
                    "holder_name": "John Doe"
                }
            }

            completed_checkout = await client.complete_checkout(
                checkout_id=checkout_id,
                payment_data=payment_data,
                risk_signals={"device_fingerprint": "abc123"}
            )
            logger.info(f"Checkout completed! Order ID: {completed_checkout.order.id}")

            # 6. Get order details
            logger.info("Getting order details...")
            order = await client.get_order(completed_checkout.order.id)
            logger.info(f"Order status: {order.get('status', 'unknown')}")

        except UCPClientError as e:
            logger.error(f"UCP Client Error: {e}")
            if e.status_code:
                logger.error(f"Status Code: {e.status_code}")
            if e.response_data:
                logger.error(f"Response: {e.response_data}")


async def advanced_example():
    """Advanced usage with error handling and async context."""
    client = UCPClient(
        base_url="http://localhost:8182",
        ucp_agent_profile='profile="https://agent.example/profile"'
    )

    try:
        async with client:
            # Get profile first
            profile = await client.get_merchant_profile()
            print(f"Merchant version: {profile.ucp.version}")

            # Create multiple checkouts with different idempotency keys
            for i in range(3):
                try:
                    checkout_req = checkout_create_req.CheckoutCreateRequest(
                        buyer=buyer.Buyer(email=f"user{i}@example.com"),
                        items=[item_create_req.ItemCreateRequest(
                            line_items=[line_item_create_req.LineItemCreateRequest(
                                product_id="test-product",
                                quantity=1,
                                price={"amount": "1000", "currency": "USD"}
                            )]
                        )]
                    )

                    checkout = await client.create_checkout(
                        checkout_req,
                        idempotency_key=f"checkout-{i}"
                    )
                    print(f"Created checkout {i+1}: {checkout.id}")

                except UCPClientError as e:
                    print(f"Failed to create checkout {i+1}: {e}")

    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        await client._client.aclose()


if __name__ == "__main__":
    print("Running UCP Client Examples...")
    print("\n1. Basic usage example:")
    asyncio.run(example_usage())

    print("\n2. Advanced usage example:")
    asyncio.run(advanced_example())