"""
Django-Flex Middleware

Optional middleware for handling flexible queries through a
centralized endpoint. Supports both unversioned and versioned APIs.

Features:
- Single or multiple endpoints for flex queries
- Automatic model routing
- API versioning with per-version settings
- Request/response logging (optional)
"""

import json
import logging

from django.http import JsonResponse

from django_flex.query import FlexQuery, get_model_by_name
from django_flex.response import FlexResponse
from django_flex.conf import flex_settings


logger = logging.getLogger("django_flex")


class FlexQueryMiddleware:
    """
    Middleware for handling flexible queries through single or multiple endpoints.

    Supports both unversioned (/api/) and versioned (/api/v1/, /api/v2/) APIs
    running simultaneously with different settings per version.

    Setup:
        # settings.py
        MIDDLEWARE = [
            ...
            'django_flex.middleware.FlexQueryMiddleware',
        ]

        # Unversioned only
        DJANGO_FLEX = {
            'MIDDLEWARE_PATH': '/api/',
            'PERMISSIONS': {...},
        }

        # OR: Unversioned + versioned running together
        DJANGO_FLEX = {
            'MIDDLEWARE_PATH': '/api/',  # Unversioned uses top-level settings
            'PERMISSIONS': {...},
            'MAX_LIMIT': 200,

            'VERSIONS': {
                'v1': {
                    'path': '/api/v1/',
                    'PERMISSIONS': {...},  # v1-specific
                    'MAX_LIMIT': 100,
                },
                'v2': {
                    'path': '/api/v2/',
                    'PERMISSIONS': {...},  # v2-specific
                    'MAX_LIMIT': 200,
                },
            },
        }

    Usage:
        # Client sends POST to /api/ (unversioned)
        # OR /api/v1/, /api/v2/ (versioned)
        {
            "_model": "booking",
            "_action": "query",
            "fields": "id, customer.name",
            "filters": {"status": "confirmed"},
            "limit": 20
        }
    """

    def __init__(self, get_response):
        self.get_response = get_response
        self.main_path = getattr(flex_settings, "MIDDLEWARE_PATH", "/api/")
        self.versions = getattr(flex_settings, "VERSIONS", {})

        # Build path -> version_config mapping for fast lookup
        self.path_map = {}

        # Add main (unversioned) path - uses top-level settings
        if self.main_path:
            self.path_map[self.main_path] = None  # None = use top-level settings

        # Add versioned paths
        for version_name, version_config in self.versions.items():
            path = version_config.get("path")
            if path:
                self.path_map[path] = version_config

    def __call__(self, request):
        # Check if this is a flex query request
        if request.method == "POST" and request.path in self.path_map:
            version_config = self.path_map[request.path]
            return self.handle_flex_query(request, version_config)

        return self.get_response(request)

    def _get_setting(self, name, version_config):
        """
        Get a setting value, checking version config first, then top-level.

        Args:
            name: Setting name (e.g., 'PERMISSIONS', 'MAX_LIMIT')
            version_config: Version-specific config dict or None for unversioned

        Returns:
            Setting value from version config, or top-level, or default
        """
        # Check version-specific config first
        if version_config and name in version_config:
            return version_config[name]

        # Fall back to top-level settings
        return getattr(flex_settings, name)

    def handle_flex_query(self, request, version_config=None):
        """Handle a flex query request with optional version-specific settings."""
        # Check authentication if required
        require_auth = self._get_setting("REQUIRE_AUTHENTICATION", version_config)
        if require_auth:
            if not hasattr(request, "user") or not request.user.is_authenticated:
                return JsonResponse(
                    FlexResponse.error("PERMISSION_DENIED", "Authentication required").to_dict(),
                    status=401,
                )

        # Parse request body
        try:
            body = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse(
                FlexResponse.error("INVALID_FILTER", "Invalid JSON body").to_dict(),
                status=400,
            )

        # Extract model and action
        model_name = body.get("_model")
        action = body.get("_action", "query")

        if not model_name:
            return JsonResponse(
                FlexResponse.error("MODEL_NOT_FOUND", "Missing '_model' in request").to_dict(),
                status=400,
            )

        # Normalize action (legacy support)
        if action == "get+" or action == "list":
            action = "query"

        # Get model
        model = get_model_by_name(model_name)
        if model is None:
            return JsonResponse(
                FlexResponse.error("MODEL_NOT_FOUND", f"Model '{model_name}' not found").to_dict(),
                status=404,
            )

        # Build query spec (remove internal keys)
        query_spec = {k: v for k, v in body.items() if not k.startswith("_")}

        # Add id if present in body
        if "id" in body:
            query_spec["id"] = body["id"]

        # Log query if auditing enabled
        audit_queries = self._get_setting("AUDIT_QUERIES", version_config)
        if audit_queries:
            user = getattr(request, "user", None)
            version_name = None
            if version_config:
                # Find version name from path
                for name, cfg in self.versions.items():
                    if cfg is version_config:
                        version_name = name
                        break
            logger.info(
                "flex_query",
                extra={
                    "user": str(user) if user else "anonymous",
                    "model": model_name,
                    "action": action,
                    "query": query_spec,
                    "version": version_name,
                },
            )

        # Execute query with version-specific permissions
        user = request.user if hasattr(request, "user") else None
        permissions = self._get_setting("PERMISSIONS", version_config)

        query = FlexQuery(model)
        query.set_permissions(permissions)
        result = query.execute(query_spec, user=user, action=action)

        # Determine HTTP status
        if result.success:
            status = 200
        elif result.code == "NOT_FOUND":
            status = 404
        elif result.code == "PERMISSION_DENIED":
            status = 403
        else:
            status = 400

        return JsonResponse(result.to_dict(), status=status)
