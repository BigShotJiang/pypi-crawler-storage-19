class NotFound(Exception):
    pass
