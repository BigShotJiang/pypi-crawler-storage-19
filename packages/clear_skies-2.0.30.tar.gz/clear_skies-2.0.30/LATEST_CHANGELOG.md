## [2.0.30] - 2026-01-09

### Added
- Add port forwarder and update docs in [#49](https://github.com/clearskies-py/clearskies/pull/49)
- Add sockets and subsystems

### Fixed
- Lastrowid for mysql
- The cursors

