"""Configuration management for OpenFoundry."""
