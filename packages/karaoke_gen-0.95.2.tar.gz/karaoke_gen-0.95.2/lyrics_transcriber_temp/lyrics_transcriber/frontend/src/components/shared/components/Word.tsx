import React from 'react'
import { COLORS } from '../constants'
import { HighlightedWord } from '../styles'
import { WordProps } from '../types'
import { Tooltip } from '@mui/material'

export const WordComponent = React.memo(function Word({
    word,
    shouldFlash,
    isAnchor,
    isCorrectedGap,
    isUncorrectedGap,
    isCurrentlyPlaying,
    padding = '1px 3px',
    onClick,
    correction
}: WordProps) {
    if (/^\s+$/.test(word)) {
        return word
    }

    const backgroundColor = isCurrentlyPlaying
        ? COLORS.playing
        : shouldFlash
            ? COLORS.highlighted
            : isAnchor
                ? COLORS.anchor
                : isCorrectedGap
                    ? COLORS.corrected
                    : isUncorrectedGap
                        ? COLORS.uncorrectedGap
                        : 'transparent'

    const wordElement = (
        <HighlightedWord
            shouldFlash={shouldFlash}
            style={{
                backgroundColor,
                padding,
                cursor: 'pointer',
                borderRadius: '2px',
                color: isCurrentlyPlaying ? '#ffffff' : 'inherit',
                textDecoration: correction ? 'underline dotted' : 'none',
                textDecorationColor: correction ? '#666666' : 'inherit', // slate-500 for dark mode
                textUnderlineOffset: '2px',
                fontSize: '0.85rem',
                lineHeight: 1.2
            }}
            sx={{
                '&:hover': {
                    backgroundColor: 'rgba(248, 250, 252, 0.08)' // slate-50 hover for dark mode
                }
            }}
            onClick={onClick}
        >
            {word}
        </HighlightedWord>
    )

    if (correction) {
        const tooltipContent = (
            <>
                <strong>Original:</strong> "{correction.originalWord}"<br />
                <strong>Corrected by:</strong> {correction.handler}<br />
                <strong>Source:</strong> {correction.source}<br />
                {correction.reason && (
                    <>
                        <strong>Reason:</strong> {correction.reason}<br />
                    </>
                )}
                {correction.confidence !== undefined && correction.confidence > 0 && (
                    <>
                        <strong>Confidence:</strong> {(correction.confidence * 100).toFixed(0)}%<br />
                    </>
                )}
            </>
        )
        
        return (
            <Tooltip title={tooltipContent} arrow placement="top">
                {wordElement}
            </Tooltip>
        )
    }

    return wordElement
}) 