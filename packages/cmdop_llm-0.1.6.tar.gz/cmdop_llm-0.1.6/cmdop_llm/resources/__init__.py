"""Custom resources for CMDOP LLM service."""

from .ocr import AsyncOCR, OCR
from .search import AsyncSearch, Search
from .vision import AsyncVision, Vision

__all__ = [
    "Vision",
    "AsyncVision",
    "OCR",
    "AsyncOCR",
    "Search",
    "AsyncSearch",
]
