# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from darabonba.model import DaraModel

class AddPrivateDnsDomainNameRequest(DaraModel):
    def __init__(
        self,
        access_instance_id: str = None,
        domain_name_list: List[str] = None,
        region_no: str = None,
    ):
        # This parameter is required.
        self.access_instance_id = access_instance_id
        # This parameter is required.
        self.domain_name_list = domain_name_list
        # This parameter is required.
        self.region_no = region_no

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.access_instance_id is not None:
            result['AccessInstanceId'] = self.access_instance_id

        if self.domain_name_list is not None:
            result['DomainNameList'] = self.domain_name_list

        if self.region_no is not None:
            result['RegionNo'] = self.region_no

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AccessInstanceId') is not None:
            self.access_instance_id = m.get('AccessInstanceId')

        if m.get('DomainNameList') is not None:
            self.domain_name_list = m.get('DomainNameList')

        if m.get('RegionNo') is not None:
            self.region_no = m.get('RegionNo')

        return self

