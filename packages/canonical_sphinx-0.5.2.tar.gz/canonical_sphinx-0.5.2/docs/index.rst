.. starcraft documentation root file

StarCraft
=========

.. toctree::
   :maxdepth: 1
   :hidden:

   tutorials/index
   howto/index
   reference/index
   explanation/index

.. list-table::

    * - | :ref:`Tutorial <tutorial>`
        | **Get started** with a hands-on introduction to Starcraft
      - | :ref:`How-to guides <howto>`
        | **Step-by-step guides** covering key operations and common tasks
    * - | :ref:`Reference <reference>`
        | **Technical information** about Starcraft
      - | :ref:`Explanation <explanation>`
        | **Discussion and clarification** of key topics

Project and community
=====================

Starcraft is a member of the Canonical family. It's an open source project
that warmly welcomes community projects, contributions, suggestions, fixes
and constructive feedback.

* `Ubuntu Code of Conduct <https://ubuntu.com/community/code-of-conduct>`_.
* `Canonical contributor licenses agreement
  <https://ubuntu.com/legal/contributors>`_.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
