#!/usr/bin/env python3
"""Setup script for INL Tokenizer."""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="inl-tokenizer",
    version="1.0.0",
    author="nano3",
    author_email="",
    description="INL-LLM Iterative Tokenizer - Multi-pass refinement with semantic grouping",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Pacific-Prime/pacific-prime",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: Free for non-commercial use",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    license="CC BY-NC 4.0",
    python_requires=">=3.8",
    install_requires=[
        "tokenizers>=0.15.0",
        "datasets>=2.16.0",
        "tqdm>=4.66.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "inl-tokenizer-train=train_inl_tokenizer:main",
            "inl-tokenizer-test=test_inl_tokenizer:main",
        ],
    },
    include_package_data=True,
    keywords="tokenizer nlp llm inl iterative bpe gpt-3 multilingual code",
    project_urls={
        "Bug Reports": "https://github.com/Pacific-Prime/pacific-prime/issues",
        "Source": "https://github.com/Pacific-Prime/pacific-prime",
        "Documentation": "https://github.com/Pacific-Prime/pacific-prime/tree/main/token",
    },
)
