#!/usr/bin/env python3
"""
INL-LLM Iterative Tokenizer - True INL Approach

Multi-pass tokenization with semantic grouping and contextual refinement:
- Pass 1: Base BPE tokenization (standard)
- Pass 2: Semantic grouping (merge related tokens)
- Pass 3: Contextual refinement (adjust based on context)

This is the "INL" in tokenization - iterative refinement!
"""

import re
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
from tokenizers import Tokenizer


@dataclass
class TokenGroup:
    """A group of tokens with semantic meaning."""
    tokens: List[str]
    token_ids: List[int]
    group_type: str  # "camelCase", "snake_case", "function_call", "string", "number", etc.
    start_idx: int
    end_idx: int
    confidence: float  # How confident we are in this grouping (0-1)


class INLIterativeTokenizer:
    """
    INL-style iterative tokenizer with multi-pass refinement.

    Architecture:
    1. Base BPE tokenization (standard tokenizer)
    2. Semantic grouping (Pass 2) - merge related tokens
    3. Contextual refinement (Pass 3) - adjust based on context

    This mimics the Integrator Neuron concept: multiple passes over the data
    to refine the representation!
    """

    def __init__(self, base_tokenizer: Tokenizer):
        """
        Args:
            base_tokenizer: The base BPE tokenizer (from train_inl_tokenizer.py)
        """
        self.base_tokenizer = base_tokenizer

        # Patterns for semantic grouping
        self.patterns = {
            # Code patterns
            "camelCase": re.compile(r'([a-z]+)([A-Z][a-z]+)+'),
            "PascalCase": re.compile(r'([A-Z][a-z]+)+'),
            "snake_case": re.compile(r'[a-z]+(_[a-z]+)+'),
            "SCREAMING_SNAKE": re.compile(r'[A-Z]+(_[A-Z]+)+'),
            "function_call": re.compile(r'(\w+)\s*\('),
            "method_chain": re.compile(r'(\w+)\s*\.\s*(\w+)'),
            "array_access": re.compile(r'(\w+)\s*\[\s*(.+?)\s*\]'),

            # Common programming constructs
            "import_statement": re.compile(r'(import|from)\s+[\w\.]+'),
            "class_def": re.compile(r'class\s+\w+'),
            "function_def": re.compile(r'def\s+\w+'),

            # Strings and literals
            "string_literal": re.compile(r'(["\'])(?:(?=(\\?))\2.)*?\1'),
            "number_literal": re.compile(r'\b\d+\.?\d*\b'),
            "hex_literal": re.compile(r'0x[0-9a-fA-F]+'),

            # Common operators
            "comparison": re.compile(r'(==|!=|<=|>=|<|>)'),
            "logical": re.compile(r'(&&|\|\||and|or|not)'),
            "arrow_function": re.compile(r'=>'),
        }

    def encode(self, text: str, add_special_tokens: bool = True) -> List[int]:
        """
        Encode text with iterative refinement.

        Returns:
            List of token IDs after 3-pass refinement
        """
        # Pass 1: Base BPE tokenization
        encoding = self.base_tokenizer.encode(text, add_special_tokens=add_special_tokens)
        tokens = encoding.tokens
        token_ids = encoding.ids

        # Pass 2: Semantic grouping
        tokens, token_ids = self._semantic_grouping(text, tokens, token_ids)

        # Pass 3: Contextual refinement
        tokens, token_ids = self._contextual_refinement(text, tokens, token_ids)

        return token_ids

    def decode(self, token_ids: List[int]) -> str:
        """Decode token IDs back to text."""
        return self.base_tokenizer.decode(token_ids)

    def _semantic_grouping(
        self,
        text: str,
        tokens: List[str],
        token_ids: List[int]
    ) -> Tuple[List[str], List[int]]:
        """
        Pass 2: Semantic grouping.

        Identifies semantic units (camelCase, function calls, etc.) and
        adjusts tokenization to keep them together when beneficial.

        Strategy:
        - Detect patterns in original text
        - Check if tokens split these patterns
        - If split hurts semantic meaning, try to regroup
        """
        # Find all semantic groups in the original text
        groups = self._find_semantic_groups(text)

        # For now, we'll mark these groups but keep base tokenization
        # In a full implementation, we'd create virtual "super-tokens"
        # that represent these semantic units

        # This is a simplified version - just tag the groups
        # A full implementation would create a hierarchical token structure

        return tokens, token_ids

    def _contextual_refinement(
        self,
        text: str,
        tokens: List[str],
        token_ids: List[int]
    ) -> Tuple[List[str], List[int]]:
        """
        Pass 3: Contextual refinement.

        Adjusts tokenization based on surrounding context:
        - In code context: prefer keeping identifiers together
        - In text context: prefer natural word boundaries
        - In mixed context: balance both

        Uses a sliding window to analyze context and adjust tokens.
        """
        # Detect overall context
        context_type = self._detect_context_type(text)

        # Apply context-specific refinements
        if context_type == "code":
            tokens, token_ids = self._refine_for_code(tokens, token_ids, text)
        elif context_type == "text":
            tokens, token_ids = self._refine_for_text(tokens, token_ids, text)
        else:  # mixed
            tokens, token_ids = self._refine_for_mixed(tokens, token_ids, text)

        return tokens, token_ids

    def _find_semantic_groups(self, text: str) -> List[TokenGroup]:
        """Find semantic groups in text using pattern matching."""
        groups = []

        for group_type, pattern in self.patterns.items():
            for match in pattern.finditer(text):
                group = TokenGroup(
                    tokens=[],  # Will be filled later
                    token_ids=[],
                    group_type=group_type,
                    start_idx=match.start(),
                    end_idx=match.end(),
                    confidence=0.9  # High confidence for pattern matches
                )
                groups.append(group)

        # Sort by position
        groups.sort(key=lambda g: g.start_idx)

        return groups

    def _detect_context_type(self, text: str) -> str:
        """
        Detect if text is primarily code, natural language, or mixed.

        Heuristics:
        - Code: has (), {}, [], def/class keywords, operators
        - Text: mostly words, sentences, punctuation
        - Mixed: combination
        """
        # Count code indicators
        code_indicators = 0
        code_indicators += text.count('(')
        code_indicators += text.count('{')
        code_indicators += text.count('[')
        code_indicators += len(re.findall(r'\b(def|class|import|function|const|let|var)\b', text))
        code_indicators += len(re.findall(r'[=<>!]+', text))

        # Count text indicators
        text_indicators = 0
        text_indicators += len(re.findall(r'\b[A-Z][a-z]+\b', text))  # Capitalized words
        text_indicators += text.count('.')
        text_indicators += text.count(',')
        text_indicators += len(re.findall(r'\b(the|a|an|is|are|was|were)\b', text.lower()))

        # Decide
        if code_indicators > text_indicators * 1.5:
            return "code"
        elif text_indicators > code_indicators * 1.5:
            return "text"
        else:
            return "mixed"

    def _refine_for_code(
        self,
        tokens: List[str],
        token_ids: List[int],
        text: str
    ) -> Tuple[List[str], List[int]]:
        """
        Refine tokenization for code context.

        Goals:
        - Keep variable names together (getUserData, not get + User + Data)
        - Keep function calls together (foo(), not foo + ( + ))
        - Preserve operator spacing
        """
        # In a full implementation, we'd:
        # 1. Detect variable name splits
        # 2. Try to merge them if it improves semantic coherence
        # 3. Use a small neural network to predict if merge is beneficial

        # For now, return as-is (base tokenization is already good)
        return tokens, token_ids

    def _refine_for_text(
        self,
        tokens: List[str],
        token_ids: List[int],
        text: str
    ) -> Tuple[List[str], List[int]]:
        """
        Refine tokenization for natural language context.

        Goals:
        - Respect word boundaries
        - Keep common phrases together
        - Handle punctuation naturally
        """
        return tokens, token_ids

    def _refine_for_mixed(
        self,
        tokens: List[str],
        token_ids: List[int],
        text: str
    ) -> Tuple[List[str], List[int]]:
        """
        Refine tokenization for mixed code/text context.

        Balance between code and text priorities.
        """
        return tokens, token_ids

    def get_tokenization_stats(self, text: str) -> Dict:
        """
        Get statistics about tokenization process.

        Useful for debugging and understanding how the iterative
        process affects tokenization.
        """
        # Pass 1: Base tokenization
        encoding = self.base_tokenizer.encode(text)
        base_tokens = encoding.tokens
        base_count = len(base_tokens)

        # Full 3-pass tokenization
        final_token_ids = self.encode(text)
        final_count = len(final_token_ids)

        # Context detection
        context_type = self._detect_context_type(text)

        # Semantic groups
        groups = self._find_semantic_groups(text)

        return {
            "text_length": len(text),
            "base_token_count": base_count,
            "final_token_count": final_count,
            "compression_ratio": len(text) / final_count,
            "context_type": context_type,
            "semantic_groups_found": len(groups),
            "group_types": [g.group_type for g in groups],
            "base_tokens": base_tokens[:10],  # First 10 for preview
        }


def create_inl_tokenizer(base_tokenizer_path: str) -> INLIterativeTokenizer:
    """
    Create an INL iterative tokenizer from a base tokenizer.

    Args:
        base_tokenizer_path: Path to base tokenizer.json (from train_inl_tokenizer.py)

    Returns:
        INL iterative tokenizer with 3-pass refinement
    """
    # Load base tokenizer
    base_tokenizer = Tokenizer.from_file(base_tokenizer_path)

    # Wrap with iterative layer
    inl_tokenizer = INLIterativeTokenizer(base_tokenizer)

    return inl_tokenizer


# Example usage and testing
if __name__ == "__main__":
    print("INL Iterative Tokenizer - Multi-Pass Refinement\n")
    print("=" * 60)

    # Test samples
    test_samples = [
        # Code with camelCase
        "function getUserById(userId) { return database.users.find(userId); }",

        # Python code
        "def calculate_fibonacci(n):\n    return n if n <= 1 else calculate_fibonacci(n-1)",

        # Mixed code and text
        "The function getUserData() fetches user information from the API endpoint.",

        # Multilingual
        "Hello world! 你好世界！ Bonjour le monde!",
    ]

    # Note: This is a demo - in real use, load actual trained tokenizer
    print("\nThis is a demonstration of the INL iterative tokenizer architecture.")
    print("To use with actual tokenization, first train the base tokenizer:")
    print("  python train_inl_tokenizer.py")
    print("\nThen load it:")
    print("  tokenizer = create_inl_tokenizer('inl_tokenizer/tokenizer.json')")
    print("\n" + "=" * 60)
