"""
MCP HTML Uploader - HTML 文件创建和上传 MCP 服务器
"""

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .server import main

__all__ = ["main"]

