#!/usr/bin/env python3
"""
MCP 服务器 - 提供 HTML 文件创建和文件上传功能
"""

import os
import json
import mimetypes
from pathlib import Path
from typing import Any
from datetime import datetime
import httpx
from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio

# 初始化 MCP 服务器
app = Server("html-file-server")

# 上传接口 URL
UPLOAD_API_URL = "https://v5.kaleido.guru/api/proxyStorage/NoAuth/upload_file"


@app.list_tools()
async def list_tools() -> list[Tool]:
    """列出可用的工具"""
    return [
        Tool(
            name="create_html",
            description="创建一个 HTML 文件。根据提供的内容创建一个格式良好的 HTML 文件，文件名和标题自动生成。",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "HTML 文件的主体内容（可以是完整的 HTML 代码或仅内容）"
                    }
                },
                "required": ["content"]
            }
        ),
        Tool(
            name="upload_file",
            description="上传文件到服务器。支持上传任何类型的文件到指定的 API 接口，返回文件 URL。",
            inputSchema={
                "type": "object",
                "properties": {
                    "file_path": {
                        "type": "string",
                        "description": "要上传的文件路径（相对或绝对路径）"
                    },
                    "token": {
                        "type": "string",
                        "description": "API 认证 Token"
                    }
                },
                "required": ["file_path", "token"]
            }
        ),
        Tool(
            name="create_and_upload_html",
            description="创建 HTML 文件并立即上传到服务器，返回文件 URL。这是创建和上传功能的组合工具，一步完成两个操作。",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "HTML 文件的主体内容（可以是完整的 HTML 代码或仅内容）"
                    },
                    "token": {
                        "type": "string",
                        "description": "API 认证 Token"
                    }
                },
                "required": ["content", "token"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """处理工具调用"""
    
    if name == "create_html":
        return await create_html_file(arguments)
    elif name == "upload_file":
        return await upload_file(arguments)
    elif name == "create_and_upload_html":
        return await create_and_upload_html(arguments)
    else:
        return [TextContent(type="text", text=f"错误：未知的工具 '{name}'")]


async def create_html_file(args: dict) -> list[TextContent]:
    """创建 HTML 文件"""
    try:
        content = args.get("content", "")
        
        # 验证内容
        if not content:
            return [TextContent(type="text", text="错误：必须提供 HTML 内容")]
        
        # 自动生成文件名（使用时间戳）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"page_{timestamp}.html"
        
        # 自动生成标题
        title = "文档"
        
        # 使用当前目录
        output_dir = "."
        
        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # 完整文件路径
        file_path = output_path / filename
        
        # 判断内容是否已经是完整的 HTML
        content_lower = content.strip().lower()
        if content_lower.startswith('<!doctype') or content_lower.startswith('<html'):
            # 已经是完整的 HTML
            html_content = content
        else:
            # 需要包装成完整的 HTML
            html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
</head>
<body>
{content}
</body>
</html>"""
        
        # 写入文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        abs_path = file_path.absolute()
        return [TextContent(
            type="text",
            text=f"成功创建 HTML 文件！\n文件路径：{abs_path}\n文件大小：{len(html_content)} 字节"
        )]
        
    except Exception as e:
        return [TextContent(type="text", text=f"创建 HTML 文件时出错：{str(e)}")]


async def upload_file(args: dict) -> list[TextContent]:
    """上传文件到服务器"""
    try:
        file_path = args.get("file_path", "")
        token = args.get("token", "")
        
        # 验证参数
        if not file_path:
            return [TextContent(type="text", text="错误：必须提供文件路径")]
        
        if not token:
            return [TextContent(type="text", text="错误：必须提供 Token")]
        
        # 转换为 Path 对象
        path = Path(file_path)
        
        # 检查文件是否存在
        if not path.exists():
            return [TextContent(type="text", text=f"错误：文件不存在：{file_path}")]
        
        if not path.is_file():
            return [TextContent(type="text", text=f"错误：路径不是文件：{file_path}")]
        
        # 获取文件信息
        mime_type, _ = mimetypes.guess_type(str(path))
        if mime_type is None:
            mime_type = 'application/octet-stream'
        
        # 读取文件内容
        with open(path, 'rb') as f:
            file_content = f.read()
        
        # 准备上传（使用 form-data，字段名为 file）
        files = {
            'file': (path.name, file_content, mime_type)
        }
        
        # 设置请求头
        headers = {
            'token': token
        }
        
        # 发送 POST 请求
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(UPLOAD_API_URL, files=files, headers=headers)
            
            # 解析响应
            response_data = response.json()
            
            # 提取 fileUrl
            file_url = response_data.get('body', {}).get('fileUrl', '')
            
            if file_url:
                return [TextContent(type="text", text=file_url)]
            else:
                return [TextContent(
                    type="text",
                    text=f"上传失败或未返回 fileUrl\n响应：{json.dumps(response_data, ensure_ascii=False, indent=2)}"
                )]
        
    except httpx.HTTPError as e:
        return [TextContent(type="text", text=f"上传文件时发生网络错误：{str(e)}")]
    except Exception as e:
        return [TextContent(type="text", text=f"上传文件时出错：{str(e)}")]


async def create_and_upload_html(args: dict) -> list[TextContent]:
    """创建 HTML 文件并上传到服务器"""
    try:
        content = args.get("content", "")
        token = args.get("token", "")
        
        # 验证必需参数
        if not content:
            return [TextContent(type="text", text="错误：必须提供 HTML 内容")]
        
        if not token:
            return [TextContent(type="text", text="错误：必须提供 Token")]
        
        # 第一步：创建 HTML 文件
        # 自动生成文件名（使用时间戳）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"page_{timestamp}.html"
        
        # 自动生成标题
        title = "文档"
        
        # 使用当前目录
        output_dir = "."
        
        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # 完整文件路径
        file_path = output_path / filename
        
        # 判断内容是否已经是完整的 HTML
        content_lower = content.strip().lower()
        
        if content_lower.startswith('<!doctype') or content_lower.startswith('<html'):
            html_content = content
        else:
            html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
</head>
<body>
{content}
</body>
</html>"""
        
        # 写入文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # 第二步：上传文件
        mime_type = 'text/html'
        
        # 读取文件内容
        with open(file_path, 'rb') as f:
            file_content = f.read()
        
        # 准备上传（使用 form-data，字段名为 file）
        files = {
            'file': (filename, file_content, mime_type)
        }
        
        # 设置请求头
        headers = {
            'token': token
        }
        
        # 发送 POST 请求
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(UPLOAD_API_URL, files=files, headers=headers)
            
            # 解析响应
            response_data = response.json()
            
            # 提取 fileUrl
            file_url = response_data.get('body', {}).get('fileUrl', '')
            
            if file_url:
                return [TextContent(type="text", text=file_url)]
            else:
                return [TextContent(
                    type="text",
                    text=f"上传失败或未返回 fileUrl\n响应：{json.dumps(response_data, ensure_ascii=False, indent=2)}"
                )]
        
    except httpx.HTTPError as e:
        return [TextContent(type="text", text=f"上传文件时发生网络错误：{str(e)}")]
    except Exception as e:
        return [TextContent(type="text", text=f"创建并上传 HTML 文件时出错：{str(e)}")]


async def async_main():
    """运行服务器（异步入口）"""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


def main():
    """主入口函数"""
    import asyncio
    asyncio.run(async_main())


if __name__ == "__main__":
    main()

