"""Memory Harness - Benchmark AI memory systems."""
__version__ = "1.2.5"
