"""
Language-specific symbol extractors.
"""
