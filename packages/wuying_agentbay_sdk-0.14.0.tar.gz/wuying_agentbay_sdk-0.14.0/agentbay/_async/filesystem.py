import asyncio
import base64
import json
import os
import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Literal, Optional, overload, Tuple, Union

import httpx

from .._common.exceptions import AgentBayError, FileError
from .._common.models.filesystem import (
    BinaryFileContentResult,
    DirectoryListResult,
    DownloadResult,
    FileChangeEvent,
    FileChangeResult,
    FileContentResult,
    FileInfoResult,
    FileSearchResult,
    MultipleFileContentResult,
    UploadResult,
)
from .._common.models import ApiResponse, BoolResult, extract_request_id
from ..api.base_service import BaseService
from ..api.models import ListContextsRequest
from ..api.models._get_and_load_internal_context_request import GetAndLoadInternalContextRequest

from .._common.logger import (
    _log_api_response,
    _log_api_call,
    _log_operation_start,
    _log_operation_error,
    _log_api_response_with_details,
    get_logger,
)

# Initialize logger for this module
_logger = get_logger("filesystem")


class AsyncFileTransfer:
    """
    Provides pre-signed URL upload/download functionality between local and OSS,
    with integration to Session Context synchronization.

    Prerequisites and Constraints:
    - Session must be associated with the corresponding context_id and path through
      CreateSessionParams.context_syncs, and remote_path should fall within that
      synchronization path (or conform to backend path rules).
    - Requires available AgentBay context service (agent_bay.context) and session context.
    """

    def __init__(
        self,
        agent_bay,  # AgentBay instance (for using agent_bay.context service)
        session,  # Created session object (for session.context.sync/info)
        *,
        http_timeout: float = 60.0,
        follow_redirects: bool = True,
    ):
        """
        Initialize FileTransfer with AgentBay client and session.

        Args:
            agent_bay: AgentBay instance for context service access
            session: Created session object for context operations
            http_timeout: HTTP request timeout in seconds (default: 60.0)
            follow_redirects: Whether to follow HTTP redirects (default: True)
        """
        self._agent_bay = agent_bay
        self._context_svc = agent_bay.context
        self._session = session
        self._http_timeout = http_timeout
        self._follow_redirects = follow_redirects
        self._context_id: Optional[str] = None
        self._context_path: Optional[str] = None

        # Task completion states (for compatibility)
        self._finished_states = {
            "success",
            "successful",
            "ok",
            "finished",
            "done",
            "completed",
            "complete",
        }

    async def _ensure_context_id(self) -> Tuple[bool, Optional[str]]:
        """
        Lazy-load the file_transfer context ID for this session.
        This calls GetAndLoadInternalContext with SessionId and ContextTypes=["file_transfer"].
        """
        if self._context_id:
            return True, ""

        try:
            request = GetAndLoadInternalContextRequest(
                authorization=f"Bearer {self._agent_bay.api_key}",
                session_id=self._session._get_session_id(),
                context_types=["file_transfer"],
            )
            _log_api_call("GetAndLoadInternalContext", f"SessionId={self._session._get_session_id()}, ContextTypes=file_transfer")

            client = self._agent_bay.client
            response = await client.get_and_load_internal_context_async(request)

            # Extract context_id from response.body.data.context_id
            response_map = response.to_map()
            body = response_map.get("body", {})
            try:
                response_body = json.dumps(body, ensure_ascii=False, indent=2)
            except Exception:
                response_body = str(body)
            # Check for API-level errors
            if not body.get("Success", True) and body.get("Code"):
                _log_api_response_with_details(
                    api_name="GetAndLoadInternalContext",
                    request_id=extract_request_id(response),
                    success=False,
                    full_response=response_body,
                )
                return False, body.get("Message", "Unknown error")

            _log_api_response_with_details(
                api_name="GetAndLoadInternalContext",
                request_id=extract_request_id(response),
                success=True,
                full_response=response_body,
            )

            data = body.get("Data", {})
            if isinstance(data, list) and len(data) > 0:
                for item in data:
                    if isinstance(item, dict):
                        context_id = item.get("ContextId", "")
                        context_path = item.get("ContextPath", "")
                        if context_id and context_path:
                            self._context_id = context_id
                            self._context_path = context_path
                            return True, ""
            return False, "Response contains no data"
        except Exception as e:
            _log_operation_error("ensure_context_id", str(e), exc_info=True)
            return False, str(e)

    async def upload(
        self,
        local_path: str,
        remote_path: str,
        *,
        content_type: Optional[str] = None,
        wait: bool = True,
        wait_timeout: float = 30.0,
        poll_interval: float = 1.5,
        progress_cb: Optional[
            Callable[[int], None]
        ] = None,  # Callback with cumulative bytes transferred
    ) -> UploadResult:
        """
        Upload workflow:
        1) Get OSS pre-signed URL via context.get_file_upload_url
        2) Upload local file to OSS using the URL (HTTP PUT)
        3) Trigger session.context.sync(mode="download") to sync cloud disk data from OSS
        4) If wait=True, poll session.context.info until upload task reaches completion or timeout

        Returns UploadResult containing request_ids, HTTP status, ETag and other information.
        """
        # 0. Parameter validation
        if not os.path.isfile(local_path):
            return UploadResult(
                success=False,
                request_id_upload_url=None,
                request_id_sync=None,
                http_status=None,
                etag=None,
                bytes_sent=0,
                path=remote_path,
                error_message=f"Local file not found: {local_path}",
            )
        if self._context_id is None:
            ensure_result, message = await self._ensure_context_id()
            if not ensure_result:
                return UploadResult(
                    success=False,
                    request_id_upload_url=None,
                    request_id_sync=None,
                    http_status=None,
                    etag=None,
                    bytes_sent=0,
                    path=remote_path,
                    error_message=message,
                )
        # 1. Get pre-signed upload URL
        url_res = await self._context_svc.get_file_upload_url(
            self._context_id, remote_path
        )
        if not getattr(url_res, "success", False) or not getattr(url_res, "url", None):
            return UploadResult(
                success=False,
                request_id_upload_url=getattr(url_res, "request_id", None),
                request_id_sync=None,
                http_status=None,
                etag=None,
                bytes_sent=0,
                path=remote_path,
                error_message=f"get_file_upload_url failed: {getattr(url_res, 'message', 'unknown error')}",
            )

        upload_url = url_res.url
        req_id_upload = getattr(url_res, "request_id", None)

        print(f"Uploading {local_path} to {upload_url}")

        # 2. PUT upload to pre-signed URL
        try:
            http_status, etag, bytes_sent = await asyncio.to_thread(
                self._put_file_sync,
                upload_url,
                local_path,
                self._http_timeout,
                self._follow_redirects,
                content_type,
                progress_cb,
            )
            print(f"Upload completed with HTTP {http_status}")
            if http_status not in (200, 201, 204):
                return UploadResult(
                    success=False,
                    request_id_upload_url=req_id_upload,
                    request_id_sync=None,
                    http_status=http_status,
                    etag=etag,
                    bytes_sent=bytes_sent,
                    path=remote_path,
                    error_message=f"Upload failed with HTTP {http_status}",
                )
        except Exception as e:
            return UploadResult(
                success=False,
                request_id_upload_url=req_id_upload,
                request_id_sync=None,
                http_status=None,
                etag=None,
                bytes_sent=0,
                path=remote_path,
                error_message=f"Upload exception: {e}",
            )

        # 3. Trigger sync to cloud disk (download mode),download from oss to cloud disk
        req_id_sync = None
        try:
            print("Triggering sync to cloud disk")
            req_id_sync = await self._await_sync(
                "download", remote_path, self._context_id
            )
        except Exception as e:
            return UploadResult(
                success=False,
                request_id_upload_url=req_id_upload,
                request_id_sync=req_id_sync,
                http_status=http_status,
                etag=etag,
                bytes_sent=bytes_sent,
                path=remote_path,
                error_message=f"session.context.sync(upload) failed: {e}",
            )

        print(f"Sync request ID: {req_id_sync}")
        # 4. Optionally wait for task completion
        if wait:
            ok, err = await self._wait_for_task(
                context_id=self._context_id,
                remote_path=remote_path,
                task_type="download",
                timeout=wait_timeout,
                interval=poll_interval,
            )
            if not ok:
                return UploadResult(
                    success=False,
                    request_id_upload_url=req_id_upload,
                    request_id_sync=req_id_sync,
                    http_status=http_status,
                    etag=etag,
                    bytes_sent=bytes_sent,
                    path=remote_path,
                    error_message=f"Upload sync not finished: {err or 'timeout or unknown'}",
                )

        return UploadResult(
            success=True,
            request_id_upload_url=req_id_upload,
            request_id_sync=req_id_sync,
            http_status=http_status,
            etag=etag,
            bytes_sent=bytes_sent,
            path=remote_path,
            error_message=None,
        )

    async def download(
        self,
        remote_path: str,
        local_path: str,
        *,
        overwrite: bool = True,
        wait: bool = True,
        wait_timeout: float = 300.0,
        poll_interval: float = 1.5,
        progress_cb: Optional[
            Callable[[int], None]
        ] = None,  # Callback with cumulative bytes received
    ) -> DownloadResult:
        """
        Download workflow:
        1) Trigger session.context.sync(mode="upload") to sync cloud disk data to OSS
        2) Get pre-signed download URL via context.get_file_download_url
        3) Download the file and save to local local_path
        4) If wait=True, wait for download task to reach completion after step 1
           (ensuring backend has prepared the download object)

        Returns DownloadResult containing sync and download request_ids, HTTP status, byte count, etc.
        """
        # Use default context if none provided
        if self._context_id is None:
            ensure_result, message = await self._ensure_context_id()
            if not ensure_result:
                return DownloadResult(
                    success=False,
                    request_id_download_url=None,
                    request_id_sync=None,
                    http_status=None,
                    bytes_received=0,
                    path=remote_path,
                    local_path=local_path,
                    error_message=message,
                )
        # 1. Trigger cloud disk to OSS download sync
        req_id_sync = None
        try:
            req_id_sync = await self._await_sync(
                "upload", remote_path, self._context_id
            )
        except Exception as e:
            return DownloadResult(
                success=False,
                request_id_download_url=None,
                request_id_sync=req_id_sync,
                http_status=None,
                bytes_received=0,
                path=remote_path,
                local_path=local_path,
                error_message=f"session.context.sync(download) failed: {e}",
            )

        # Optionally wait for task completion (ensure object is ready in OSS)
        if wait:
            ok, err = await self._wait_for_task(
                context_id=self._context_id,
                remote_path=remote_path,
                task_type="upload",
                timeout=wait_timeout,
                interval=poll_interval,
            )
            if not ok:
                return DownloadResult(
                    success=False,
                    request_id_download_url=None,
                    request_id_sync=req_id_sync,
                    http_status=None,
                    bytes_received=0,
                    path=remote_path,
                    local_path=local_path,
                    error_message=f"Download sync not finished: {err or 'timeout or unknown'}",
                )

        # 2. Get pre-signed download URL
        url_res = await self._context_svc.get_file_download_url(
            self._context_id, remote_path
        )
        if not getattr(url_res, "success", False) or not getattr(url_res, "url", None):
            return DownloadResult(
                success=False,
                request_id_download_url=getattr(url_res, "request_id", None),
                request_id_sync=req_id_sync,
                http_status=None,
                bytes_received=0,
                path=remote_path,
                local_path=local_path,
                error_message=f"get_file_download_url failed: {getattr(url_res, 'message', 'unknown error')}",
            )

        download_url = url_res.url
        req_id_download = getattr(url_res, "request_id", None)

        # 3. Download and save to local
        try:
            os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
            if os.path.exists(local_path) and not overwrite:
                return DownloadResult(
                    success=False,
                    request_id_download_url=req_id_download,
                    request_id_sync=req_id_sync,
                    http_status=None,
                    bytes_received=0,
                    path=remote_path,
                    local_path=local_path,
                    error_message=f"Destination exists and overwrite=False: {local_path}",
                )

            http_status, bytes_received = await asyncio.to_thread(
                self._get_file_sync,
                download_url,
                local_path,
                self._http_timeout,
                self._follow_redirects,
                progress_cb,
            )
            if http_status != 200:
                return DownloadResult(
                    success=False,
                    request_id_download_url=req_id_download,
                    request_id_sync=req_id_sync,
                    http_status=http_status,
                    bytes_received=bytes_received,
                    path=remote_path,
                    local_path=local_path,
                    error_message=f"Download failed with HTTP {http_status}",
                )
        except Exception as e:
            return DownloadResult(
                success=False,
                request_id_download_url=req_id_download,
                request_id_sync=req_id_sync,
                http_status=None,
                bytes_received=0,
                path=remote_path,
                local_path=local_path,
                error_message=f"Download exception: {e}",
            )

        return DownloadResult(
            success=True,
            request_id_download_url=req_id_download,
            request_id_sync=req_id_sync,
            http_status=200,
            bytes_received=(
                os.path.getsize(local_path) if os.path.exists(local_path) else 0
            ),
            path=remote_path,
            local_path=local_path,
            error_message=None,
        )

    # ========== Internal Utilities ==========

    async def _await_sync(
        self, mode: str, remote_path: str = "", context_id: str = ""
    ) -> Optional[str]:
        """
        Compatibility wrapper for session.context.sync_context which may be sync or async:
        - Try async call first
        - Fall back to sync call using asyncio.to_thread
        Returns request_id if available
        """
        mode = mode.lower().strip()

        sync_fn = getattr(self._session.context, "sync")
        print(
            f"session.context.sync(mode={mode}, path={remote_path}, context_id={context_id})"
        )
        # Try as coroutine with mode, path, and context_id parameters
        try:
            result = sync_fn(
                mode=mode,
                path=remote_path if remote_path else None,
                context_id=context_id if context_id else None,
            )
            if asyncio.iscoroutine(result):
                out = await result
            else:
                # Sync: run in thread pool
                out = await asyncio.to_thread(
                    sync_fn,
                    mode=mode,
                    path=remote_path if remote_path else None,
                    context_id=context_id if context_id else None,
                )
        except TypeError:
            # Backend may not support all parameters, try with mode and path only
            try:
                result = sync_fn(mode=mode, path=remote_path if remote_path else None)
                if asyncio.iscoroutine(result):
                    out = await result
                else:
                    # Sync: run in thread pool
                    out = await asyncio.to_thread(
                        sync_fn, mode=mode, path=remote_path if remote_path else None
                    )
            except TypeError:
                # Backend may not support mode or path parameter
                try:
                    result = sync_fn(mode=mode)
                    if asyncio.iscoroutine(result):
                        out = await result
                    else:
                        # Sync: run in thread pool
                        out = await asyncio.to_thread(sync_fn, mode=mode)
                except TypeError:
                    # Backend may not support mode parameter
                    result = sync_fn()
                    if asyncio.iscoroutine(result):
                        out = await result
                    else:
                        out = await asyncio.to_thread(sync_fn)
        # Return request_id if available
        success = getattr(out, "success", False)
        print(f"   Result: {success}")
        return getattr(out, "request_id", None)

    async def _wait_for_task(
        self,
        *,
        context_id: str,
        remote_path: str,
        task_type: Optional[str],
        timeout: float,
        interval: float,
    ) -> Tuple[bool, Optional[str]]:
        """
        Poll session.context.info within timeout to check if specified task is completed.
        Returns (True, None) on success, (False, error_msg) on failure.
        """
        deadline = time.time() + timeout
        last_err = None

        while time.time() < deadline:
            try:
                info_fn = getattr(self._session.context, "info")
                # Try calling with filter parameters
                try:
                    res = info_fn(
                        context_id=context_id, path=remote_path, task_type=task_type
                    )
                except TypeError:
                    res = info_fn()

                if asyncio.iscoroutine(res):
                    res = await res  # Compatibility with async info

                # Parse response
                status_list = getattr(res, "context_status_data", None) or []
                for item in status_list:
                    cid = getattr(item, "context_id", None)
                    path = getattr(item, "path", None)
                    ttype = getattr(item, "task_type", None)
                    status = getattr(item, "status", None)
                    err = getattr(item, "error_message", None)

                    if (
                        cid == context_id
                        and path == remote_path
                        and (task_type is None or ttype == task_type)
                    ):
                        if err:
                            return False, f"Task error: {err}"
                        if status and status.lower() in self._finished_states:
                            return True, None
                        # Otherwise continue waiting
                last_err = "task not finished"
            except Exception as e:
                last_err = f"info error: {e}"

            await asyncio.sleep(interval)

        return False, last_err or "timeout"

    @staticmethod
    def _put_file_sync(
        url: str,
        file_path: str,
        timeout: float,
        follow_redirects: bool,
        content_type: Optional[str],
        progress_cb: Optional[Callable[[int], None]],
    ) -> Tuple[int, Optional[str], int]:
        """
        Synchronously PUT file in background thread using httpx.
        Returns (status_code, etag, bytes_sent)
        """
        headers: Dict[str, str] = {}
        if content_type:
            headers["Content-Type"] = content_type

        file_size = os.path.getsize(file_path)

        with httpx.Client(timeout=timeout, follow_redirects=follow_redirects) as client:
            with open(file_path, "rb") as f:
                resp = client.put(url, content=f, headers=headers)
            status = resp.status_code
            etag = resp.headers.get("ETag")
            return status, etag, file_size

    @staticmethod
    def _get_file_sync(
        url: str,
        dest_path: str,
        timeout: float,
        follow_redirects: bool,
        progress_cb: Optional[Callable[[int], None]],
    ) -> Tuple[int, int]:
        """
        Synchronously GET download to local file in background thread using httpx.
        Returns (status_code, bytes_received)
        """
        bytes_recv = 0
        with httpx.Client(timeout=timeout, follow_redirects=follow_redirects) as client:
            with client.stream("GET", url) as resp:
                status = resp.status_code
                if status != 200:
                    # Still consume content to release connection
                    _ = resp.read()
                    return status, 0
                with open(dest_path, "wb") as f:
                    for chunk in resp.iter_bytes():
                        if chunk:
                            f.write(chunk)
                            bytes_recv += len(chunk)
                            if progress_cb:
                                try:
                                    progress_cb(bytes_recv)
                                except Exception:
                                    pass
        return 200, bytes_recv


class AsyncFileSystem(BaseService):
    """
    Handles file operations in the AgentBay cloud environment.
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize FileSystem with FileTransfer capability.

        Args:
            *args: Arguments to pass to BaseService
            **kwargs: Keyword arguments to pass to BaseService
        """
        super().__init__(*args, **kwargs)
        self._file_transfer: Optional[AsyncFileTransfer] = None

    def _ensure_file_transfer(self) -> AsyncFileTransfer:
        """
        Ensure AsyncFileTransfer is initialized with the current session.

        Returns:
            AsyncFileTransfer: The AsyncFileTransfer instance
        """
        if self._file_transfer is None:
            # Get the agent_bay instance from the session
            agent_bay = getattr(self.session, "agent_bay", None)
            if agent_bay is None:
                raise FileError("AsyncFileTransfer requires an AgentBay instance")

            # Get the session from the service
            session = self.session
            if session is None:
                raise FileError("AsyncFileTransfer requires a session")

            self._file_transfer = AsyncFileTransfer(agent_bay, session)

        return self._file_transfer

    async def get_file_transfer_context_path(self) -> Optional[str]:
        """
        Get the context path for file transfer operations.

        This method ensures the context ID is loaded and returns the associated
        context path that was retrieved from GetAndLoadInternalContext API.

        Returns:
            Optional[str]: The context path if available, None otherwise.

        Example:
            ```python
            session = (await agent_bay.create(params)).session
            context_path = await session.file_system.get_file_transfer_context_path()
            if context_path:
                print(f"Context path: {context_path}")
            ```
        """
        file_transfer = self._ensure_file_transfer()
        # Ensure context_id is loaded (this will also load context_path)
        if file_transfer._context_id is None:
            await file_transfer._ensure_context_id()
        return file_transfer._context_path

    # Default chunk size is 50KB (kept for backward compatibility, not used in write_file)
    DEFAULT_CHUNK_SIZE = 50 * 1024

    # MQTT message size limit and optimal chunk size calculation
    # Based on first-principles analysis:
    # - MQTT limit: 63KB = 64512 bytes
    # - Fixed overhead: ~104 bytes (JSON structure: {"path":"...","content":"...","mode":"..."})
    # - Escape overhead: ~12% for typical JSON content (quotes, backslashes, newlines)
    # - Path length: typically 50-100 bytes, max 200 bytes for safety
    #
    # Formula: JSON_size = fixed_overhead + content_bytes * (1 + escape_ratio)
    # Conservative estimate: escape_ratio = 20% (covers most cases)
    # Max content = (64512 - 200) / 1.20 = 53593 bytes
    # We use 51KB (52224 bytes) for extra safety margin (~6-8KB)
    MQTT_SIZE_LIMIT = 63 * 1024  # 63KB = 64512 bytes
    MAX_CONTENT_BYTES = 51 * 1024  # 51KB = 52224 bytes

    @staticmethod
    def _split_string_by_bytes(text: str, max_bytes: int) -> str:
        """
        Split a UTF-8 string at a safe byte boundary without breaking multi-byte characters.

        Args:
            text: The string to split
            max_bytes: Maximum number of bytes for the result

        Returns:
            A substring that fits within max_bytes when encoded as UTF-8
        """
        if not text:
            return text

        # If the entire text fits, return it
        encoded = text.encode('utf-8')
        if len(encoded) <= max_bytes:
            return text

        # Binary search to find the largest prefix that fits
        left, right = 0, len(text)
        result = ""

        while left <= right:
            mid = (left + right) // 2
            candidate = text[:mid]
            candidate_bytes = len(candidate.encode('utf-8'))

            if candidate_bytes <= max_bytes:
                result = candidate
                left = mid + 1
            else:
                right = mid - 1

        return result

    def _handle_error(self, e):
        """
        Convert AgentBayError to FileError for compatibility.

        Args:
            e (Exception): The exception to convert.

        Returns:
            FileError: The converted exception.
        """
        if isinstance(e, FileError):
            return e
        if isinstance(e, AgentBayError):
            return FileError(str(e))
        return e

    async def create_directory(self, path: str) -> BoolResult:
        """
        Create a new directory at the specified path.

        Args:
            path: The path of the directory to create.

        Returns:
            BoolResult: Result object containing success status and error message if
                any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            create_result = await session.file_system.create_directory("/tmp/mydir")
            nested_result = await session.file_system.create_directory("/tmp/parent/child/grandchild")
            await session.delete()
            ```
        """
        args = {"path": path}
        try:
            result = await self.session.call_mcp_tool("create_directory", args)
            _logger.debug(f"📥 create_directory response: {result}")
            if result.success:
                return BoolResult(request_id=result.request_id, success=True, data=True)
            else:
                return BoolResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message,
                )
        except FileError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to create directory: {e}",
            )

    async def delete_file(self, path: str) -> BoolResult:
        """
        Delete a file at the specified path.

        Args:
            path: The path of the file to delete.

        Returns:
            BoolResult: Result object containing success status and error message if any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/to_delete.txt", "hello")
            delete_result = await session.file_system.delete_file("/tmp/to_delete.txt")
            await session.delete()
            ```
        """
        args = {"path": path}
        try:
            result = await self.session.call_mcp_tool("delete_file", args)
            _logger.debug(f"📥 delete_file response: {result}")
            if result.success:
                return BoolResult(request_id=result.request_id, success=True, data=True)
            else:
                return BoolResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message,
                )
        except FileError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to delete file: {e}",
            )

    async def edit_file(
        self, path: str, edits: List[Dict[str, str]], dry_run: bool = False
    ) -> BoolResult:
        """
        Edit a file by replacing occurrences of oldText with newText.

        Args:
            path: The path of the file to edit.
            edits: A list of dictionaries specifying oldText and newText.
            dry_run: If True, preview changes without applying them.

        Returns:
            BoolResult: Result object containing success status and error message if
                any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/config.txt", "DEBUG=false\\nLOG_LEVEL=info")
            edits = [{"oldText": "false", "newText": "true"}]
            edit_result = await session.file_system.edit_file("/tmp/config.txt", edits)
            await session.delete()
            ```
        """
        args = {"path": path, "edits": edits, "dryRun": dry_run}
        try:
            result = await self.session.call_mcp_tool("edit_file", args)
            _logger.debug(f"📥 edit_file response: {result}")
            if result.success:
                return BoolResult(request_id=result.request_id, success=True, data=True)
            else:
                return BoolResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message,
                )
        except FileError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to edit file: {e}",
            )

    async def get_file_info(self, path: str) -> FileInfoResult:
        """
        Get information about a file or directory.

        Args:
            path: The path of the file or directory to inspect.

        Returns:
            FileInfoResult: Result object containing file info and error message if any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/test.txt", "Sample content")
            info_result = await session.file_system.get_file_info("/tmp/test.txt")
            print(info_result.file_info)
            await session.delete()
            ```
        """

        def parse_file_info(file_info_str: str) -> dict:
            """
            Parse a file info string into a dictionary.

            Args:
                file_info_str (str): The file info string to parse.

            Returns:
                dict: A dictionary containing the parsed file info.
            """
            result = {}
            lines = file_info_str.split("\n")
            for line in lines:
                if ":" in line:
                    key, value = line.split(":", 1)
                    key = key.strip()
                    value = value.strip()

                    # Convert boolean values
                    if value.lower() == "true":
                        value = True
                    elif value.lower() == "false":
                        value = False

                    # Convert numeric values
                    try:
                        if isinstance(value, str):
                            value = float(value) if "." in value else int(value)
                    except ValueError:
                        pass

                    result[key] = value
            return result

        args = {"path": path}
        try:
            result = await self.session.call_mcp_tool("get_file_info", args)
            try:
                response_body = json.dumps(
                    getattr(result, "body", result), ensure_ascii=False, indent=2
                )
                _log_api_response(response_body)
            except Exception:
                _logger.debug(f"📥 Response: {result}")
            if result.success:
                file_info = parse_file_info(result.data)
                return FileInfoResult(
                    request_id=result.request_id,
                    success=True,
                    file_info=file_info,
                )
            else:
                return FileInfoResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message or "Failed to get file info",
                )
        except FileError as e:
            return FileInfoResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return FileInfoResult(
                request_id="",
                success=False,
                error_message=f"Failed to get file info: {e}",
            )

    async def list_directory(self, path: str) -> DirectoryListResult:
        """
        List the contents of a directory.

        Args:
            path (str): The path of the directory to list.

        Returns:
            DirectoryListResult: Result object containing directory entries and error message if any.
                - success (bool): True if the operation succeeded
                - entries (List[Dict[str, Union[str, bool]]]): List of directory entries (if success is True)
                    Each entry contains:
                    - name (str): Name of the file or directory
                    - isDirectory (bool): True if entry is a directory, False if file
                - request_id (str): Unique identifier for this API request
                - error_message (str): Error description (if success is False)

        Raises:
            FileError: If the directory does not exist or cannot be accessed.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.create_directory("/tmp/testdir")
            await session.file_system.write_file("/tmp/testdir/file1.txt", "Content 1")
            list_result = await session.file_system.list_directory("/tmp/testdir")
            print(f"Found {len(list_result.entries)} entries")
            await session.delete()
            ```

        Note:
            - Returns empty list for empty directories
            - Each entry includes name and isDirectory flag
            - Does not recursively list subdirectories

        See Also:
            FileSystem.create_directory, FileSystem.get_file_info, FileSystem.read_file
        """

        def parse_directory_listing(text) -> List[Dict[str, Union[str, bool]]]:
            """
            Parse a directory listing text into a list of file/directory entries.

            Args:
                text (str): Directory listing text in format:
                    [DIR] directory_name
                    [FILE] file_name
                    Each entry should be on a new line with [DIR] or [FILE] prefix

            Returns:
                list: List of dictionaries, each containing:
                    - name (str): Name of the file or directory
                    - isDirectory (bool): True if entry is a directory, False if file

            Example:
                Input text:
                    [DIR] folder1
                    [FILE] test.txt

                Returns:
                    [
                        {"name": "folder1", "isDirectory": True},
                        {"name": "test.txt", "isDirectory": False}
                    ]
            """
            result = []
            lines = text.split("\n")

            for line in lines:
                line = line.strip()
                if line == "":
                    continue

                entry_map = {}
                if line.startswith("[DIR]"):
                    entry_map["isDirectory"] = True
                    entry_map["name"] = line.replace("[DIR]", "").strip()
                elif line.startswith("[FILE]"):
                    entry_map["isDirectory"] = False
                    entry_map["name"] = line.replace("[FILE]", "").strip()
                else:
                    # Skip lines that don't match the expected format
                    continue

                result.append(entry_map)

            return result

        args = {"path": path}
        try:
            result = await self.session.call_mcp_tool("list_directory", args)
            try:
                response_body = json.dumps(
                    getattr(result, "body", result), ensure_ascii=False, indent=2
                )
                _log_api_response(response_body)
            except Exception:
                _logger.debug(f"📥 Response: {result}")
            if result.success:
                entries = parse_directory_listing(result.data)
                return DirectoryListResult(
                    request_id=result.request_id, success=True, entries=entries
                )
            else:
                return DirectoryListResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message or "Failed to list directory",
                )
        except FileError as e:
            return DirectoryListResult(
                request_id="", success=False, error_message=str(e)
            )
        except Exception as e:
            return DirectoryListResult(
                request_id="",
                success=False,
                error_message=f"Failed to list directory: {e}",
            )

    async def move_file(self, source: str, destination: str) -> BoolResult:
        """
        Move a file or directory from source path to destination path.

        Args:
            source: The source path of the file or directory.
            destination: The destination path.

        Returns:
            BoolResult: Result object containing success status and error message if
                any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/original.txt", "Test content")
            move_result = await session.file_system.move_file("/tmp/original.txt", "/tmp/moved.txt")
            read_result = await session.file_system.read_file("/tmp/moved.txt")
            await session.delete()
            ```
        """
        args = {"source": source, "destination": destination}
        try:
            result = await self.session.call_mcp_tool("move_file", args)
            _logger.debug(f"📥 move_file response: {result}")
            if result.success:
                return BoolResult(request_id=result.request_id, success=True, data=True)
            else:
                return BoolResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message or "Failed to move file",
                )
        except AgentBayError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to move file: {e}",
            )

    async def _read_file_chunk(
        self, path: str, offset: int = 0, length: int = 0, format_type: str = "text"
    ) -> Union[FileContentResult, BinaryFileContentResult]:
        """
        Internal method to read a file chunk. Used for chunked file operations.

        Args:
            path: The path of the file to read.
            offset: Byte offset to start reading from (0-based).
            length: Number of bytes to read. If 0, reads the entire file from offset.
            format_type: Format to read the file in. "text" (default) or "binary".

        Returns:
            FileContentResult: For text format, contains file content as string.
            BinaryFileContentResult: For binary format, contains file content as bytes.
        """
        args = {"path": path}
        if offset >= 0:
            args["offset"] = offset
        if length >= 0:
            args["length"] = length

        # Only pass format parameter for binary files
        if format_type == "binary":
            args["format"] = "binary"

        try:
            result = await self.session.call_mcp_tool("read_file", args)
            try:
                response_body = json.dumps(
                    getattr(result, "body", result), ensure_ascii=False, indent=2
                )
                _log_api_response(response_body)
            except Exception:
                _logger.debug(f"📥 Response: {result}")
            if result.success:
                if format_type == "binary":
                    # Backend returns base64-encoded string, decode to bytes
                    try:
                        binary_content = base64.b64decode(result.data)
                        return BinaryFileContentResult(
                            request_id=result.request_id,
                            success=True,
                            content=binary_content,
                        )
                    except Exception as e:
                        return BinaryFileContentResult(
                            request_id=result.request_id,
                            success=False,
                            content=b"",
                            error_message=f"Failed to decode base64: {e}",
                        )
                else:
                    # Text format, return as string
                    return FileContentResult(
                        request_id=result.request_id,
                        success=True,
                        content=result.data,
                    )
            else:
                # Error case - return appropriate result type
                if format_type == "binary":
                    return BinaryFileContentResult(
                        request_id=result.request_id,
                        success=False,
                        content=b"",
                        error_message=result.error_message or "Failed to read file",
                    )
                else:
                    return FileContentResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message or "Failed to read file",
                    )
        except FileError as e:
            if format_type == "binary":
                return BinaryFileContentResult(request_id="", success=False, content=b"", error_message=str(e))
            else:
                return FileContentResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            if format_type == "binary":
                return BinaryFileContentResult(
                    request_id="",
                    success=False,
                    content=b"",
                    error_message=f"Failed to read file: {e}",
                )
            else:
                return FileContentResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to read file: {e}",
                )

    async def read_multiple_files(self, paths: List[str]) -> MultipleFileContentResult:
        """
        Read the contents of multiple files at once.

        Args:
            paths: A list of file paths to read.

        Returns:
            MultipleFileContentResult: Result object containing a dictionary mapping
                file paths to contents,
            and error message if any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/file1.txt", "Content of file 1")
            await session.file_system.write_file("/tmp/file2.txt", "Content of file 2")
            await session.file_system.write_file("/tmp/file3.txt", "Content of file 3")
            paths = ["/tmp/file1.txt", "/tmp/file2.txt", "/tmp/file3.txt"]
            read_result = await session.file_system.read_multiple_files(paths)
            await session.delete()
            ```
        """

        def parse_multiple_files_response(text: str) -> Dict[str, str]:
            """
            Parse the response from reading multiple files.

            Args:
                text (str): The response string containing file contents.
                Format: "/path/to/file1.txt: Content of file1\n\n---\n
                    /path/to/file2.txt: \nContent of file2\n"

            Returns:
                Dict[str, str]: A dictionary mapping file paths to their content.
            """
            result = {}
            if not text:
                return result

            lines = text.split("\n")
            current_path = None
            current_content = []

            for i, line in enumerate(lines):
                # Check if this line contains a file path (ends with a colon)
                if ":" in line and not current_path:
                    # Extract path (everything before the first colon)
                    path_end = line.find(":")
                    path = line[:path_end].strip()

                    # Start collecting content (everything after the colon)
                    current_path = path

                    # If there's content on the same line after the colon, add it
                    if len(line) > path_end + 1:
                        content_start = line[path_end + 1 :].strip()
                        if content_start:
                            current_content.append(content_start)

                # Check if this is a separator line
                elif line.strip() == "---":
                    # Save the current file content
                    if current_path:
                        result[current_path] = "\n".join(current_content).strip()
                        current_path = None
                        current_content = []

                # If we're collecting content for a path, add this line
                elif current_path is not None:
                    current_content.append(line)

            # Save the last file content if exists
            if current_path:
                result[current_path] = "\n".join(current_content).strip()

            return result

        args = {"paths": paths}
        try:
            result = await self.session.call_mcp_tool("read_multiple_files", args)
            try:
                response_body = json.dumps(
                    getattr(result, "body", result), ensure_ascii=False, indent=2
                )
                _log_api_response(response_body)
            except Exception:
                _logger.debug(f"📥 Response: {result}")

            if result.success:
                files_content = parse_multiple_files_response(result.data)
                return MultipleFileContentResult(
                    request_id=result.request_id,
                    success=True,
                    contents=files_content,
                )
            else:
                return MultipleFileContentResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message
                    or "Failed to read multiple files",
                )
        except FileError as e:
            return MultipleFileContentResult(
                request_id="", success=False, error_message=str(e)
            )
        except Exception as e:
            return MultipleFileContentResult(
                request_id="",
                success=False,
                error_message=f"Failed to read multiple files: {e}",
            )

    async def search_files(
        self,
        path: str,
        pattern: str,
        exclude_patterns: Optional[List[str]] = None,
    ) -> FileSearchResult:
        """
        Search for files in the specified path using a wildcard pattern.

        Args:
            path: The base directory path to search in.
            pattern: Wildcard pattern to match against file names. Supports * (any characters)
                and ? (single character). Examples: "*.py", "test_*", "*config*".
            exclude_patterns: Optional list of wildcard patterns to exclude from the search.

        Returns:
            FileSearchResult: Result object containing matching file paths and error
                message if any.

        Example:
            ```python
            session = (await agent_bay.create()).session
            await session.file_system.write_file("/tmp/test/test_file1.py", "print('hello')")
            await session.file_system.write_file("/tmp/test/test_file2.py", "print('world')")
            await session.file_system.write_file("/tmp/test/other.txt", "text content")
            search_result = await session.file_system.search_files("/tmp/test", "test_*")
            await session.delete()
            ```
        """
        args = {"path": path, "pattern": pattern}
        if exclude_patterns:
            args["excludePatterns"] = ",".join(exclude_patterns)

        try:
            result = await self.session.call_mcp_tool("search_files", args)
            _logger.debug(f"📥 search_files response: {result}")

            if result.success:
                matching_files = result.data.strip().split("\n") if result.data else []
                # "No matches found" is a successful search with no results, not an error
                if matching_files == ["No matches found"]:
                    return FileSearchResult(
                        request_id=result.request_id,
                        success=True,
                        matches=[],
                        error_message="",
                    )
                return FileSearchResult(
                    request_id=result.request_id,
                    success=True,
                    matches=matching_files,
                )
            else:
                return FileSearchResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message or "Failed to search files",
                )
        except FileError as e:
            return FileSearchResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return FileSearchResult(
                request_id="",
                success=False,
                error_message=f"Failed to search files: {e}",
            )

    async def _write_file_chunk(
        self, path: str, content: str, mode: str = "overwrite"
    ) -> BoolResult:
        """
        Internal method to write a file chunk. Used for chunked file operations.

        Args:
            path: The path of the file to write.
            content: The content to write to the file.
            mode: The write mode ("overwrite" or "append").

        Returns:
            BoolResult: Result object containing success status and error message if
                any.
        """
        if mode not in ["overwrite", "append"]:
            return BoolResult(
                request_id="",
                success=False,
                error_message=(
                    f"Invalid write mode: {mode}. Must be 'overwrite' or " "'append'."
                ),
            )

        args = {"path": path, "content": content, "mode": mode}
        try:
            result = await self.session.call_mcp_tool("write_file", args)
            _logger.debug(f"📥 write_file response: {result}")
            if result.success:
                return BoolResult(request_id=result.request_id, success=True, data=True)
            else:
                return BoolResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=result.error_message or "Failed to write file",
                )
        except FileError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to write file: {e}",
            )

    @overload
    async def read_file(self, path: str) -> FileContentResult: ...

    @overload
    async def read_file(self, path: str, *, format: Literal["text"]) -> FileContentResult: ...

    @overload
    async def read_file(self, path: str, *, format: Literal["bytes"]) -> BinaryFileContentResult: ...

    async def read_file(
        self, path: str, *, format: str = "text"
    ) -> Union[FileContentResult, BinaryFileContentResult]:
        """
        Read the contents of a file. Automatically handles large files by chunking.

        Args:
            path (str): The path of the file to read.
            format (str): Format to read the file in. "text" (default) or "bytes".
                - "text": Returns FileContentResult with content as string (UTF-8)
                - "bytes": Returns BinaryFileContentResult with content as bytes

        Returns:
            FileContentResult: For text format, contains file content as string.
            BinaryFileContentResult: For bytes format, contains file content as bytes.

        Raises:
            FileError: If the file does not exist or is a directory.

        Example:
            ```python
            session = (await agent_bay.create()).session
            
            # Read text file (default)
            text_result = await session.file_system.read_file("/tmp/test.txt")
            print(text_result.content)  # str
            
            # Read binary file
            binary_result = await session.file_system.read_file("/tmp/image.png", format="bytes")
            print(binary_result.content)  # bytes
            
            await session.delete()
            ```

        Note:
            - Automatically handles large files by reading in chunks (default 50KB per chunk)
            - Returns empty string/bytes for empty files
            - Returns error if path is a directory
            - Binary files are returned as bytes (backend uses base64 encoding internally)

        See Also:
            FileSystem.write_file, FileSystem.list_directory, FileSystem.get_file_info
        """
        chunk_size = self.DEFAULT_CHUNK_SIZE

        try:
            # Get file info to check size
            file_info_result = await self.get_file_info(path)
            if not file_info_result.success:
                if format == "bytes":
                    return BinaryFileContentResult(
                        request_id=file_info_result.request_id,
                        success=False,
                        content=b"",
                        error_message=file_info_result.error_message,
                    )
                else:
                    return FileContentResult(
                        request_id=file_info_result.request_id,
                        success=False,
                        error_message=file_info_result.error_message,
                    )

            # Check if file exists and is a file (not a directory)
            if not file_info_result.file_info or file_info_result.file_info.get(
                "isDirectory", False
            ):
                error_msg = f"Path does not exist or is a directory: {path}"
                if format == "bytes":
                    return BinaryFileContentResult(
                        request_id=file_info_result.request_id,
                        success=False,
                        content=b"",
                        error_message=error_msg,
                    )
                else:
                    return FileContentResult(
                        request_id=file_info_result.request_id,
                        success=False,
                        error_message=error_msg,
                    )

            # If the file is empty, return empty content
            file_size = file_info_result.file_info.get("size", 0)
            if file_size == 0:
                if format == "bytes":
                    return BinaryFileContentResult(
                        request_id=file_info_result.request_id,
                        success=True,
                        content=b"",
                        size=0,
                    )
                else:
                    return FileContentResult(
                        request_id=file_info_result.request_id,
                        success=True,
                        content="",
                    )

            # Read the file in chunks
            if format == "bytes":
                # Binary format
                content_chunks = []
                offset = 0
                chunk_count = 0
                while offset < file_size:
                    length = min(chunk_size, file_size - offset)
                    chunk_result = await self._read_file_chunk(path, offset, length, format_type="binary")
                    _log_operation_start(
                        f"ReadLargeFile chunk {chunk_count + 1}",
                        f"{length} bytes at offset {offset}/{file_size}",
                    )

                    if not chunk_result.success:
                        return chunk_result  # Return the error

                    # chunk_result is BinaryFileContentResult for binary format
                    if isinstance(chunk_result, BinaryFileContentResult):
                        content_chunks.append(chunk_result.content)
                    else:
                        # Should not happen, but handle gracefully
                        return BinaryFileContentResult(
                            request_id=chunk_result.request_id,
                            success=False,
                            content=b"",
                            error_message="Unexpected result type for binary format",
                        )

                    offset += length
                    chunk_count += 1

                # Combine all binary chunks
                final_content = b"".join(content_chunks)
                return BinaryFileContentResult(
                    request_id=file_info_result.request_id,
                    success=True,
                    content=final_content,
                    size=len(final_content),
                )
            else:
                # Text format (default)
                content = []
                offset = 0
                chunk_count = 0
                while offset < file_size:
                    length = min(chunk_size, file_size - offset)
                    chunk_result = await self._read_file_chunk(path, offset, length, format_type="text")
                    _log_operation_start(
                        f"ReadLargeFile chunk {chunk_count + 1}",
                        f"{length} bytes at offset {offset}/{file_size}",
                    )

                    if not chunk_result.success:
                        return chunk_result  # Return the error

                    content.append(chunk_result.content)
                    offset += length
                    chunk_count += 1

                return FileContentResult(
                    request_id=file_info_result.request_id,
                    success=True,
                    content="".join(content),
                )

        except FileError as e:
            if format == "bytes":
                return BinaryFileContentResult(request_id="", success=False, content=b"", error_message=str(e))
            else:
                return FileContentResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            if format == "bytes":
                return BinaryFileContentResult(
                    request_id="",
                    success=False,
                    content=b"",
                    error_message=f"Failed to read file: {e}",
                )
            else:
                return FileContentResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to read file: {e}",
                )

    async def read(self, path: str) -> FileContentResult:
        """
        Alias of read_file().
        """
        return await self.read_file(path)

    async def write_file(
        self, path: str, content: str, mode: str = "overwrite"
    ) -> BoolResult:
        """
        Write content to a file. Automatically handles large files by chunking.

        Args:
            path (str): The path of the file to write.
            content (str): The content to write to the file.
            mode (str, optional): The write mode. Defaults to "overwrite".
                - "overwrite": Replace file content
                - "append": Append to existing content

        Returns:
            BoolResult: Result object containing success status and error message if any.
                - success (bool): True if the operation succeeded
                - data (bool): True if the file was written successfully
                - request_id (str): Unique identifier for this API request
                - error_message (str): Error description (if success is False)

        Raises:
            FileError: If the write operation fails.

        Example:
            ```python
            session = (await agent_bay.create()).session
            write_result = await session.file_system.write_file("/tmp/test.txt", "Hello, World!")
            append_result = await session.file_system.write_file("/tmp/test.txt", "\\nNew line", mode="append")
            read_result = await session.file_system.read_file("/tmp/test.txt")
            await session.delete()
            ```

        Note:
            - Automatically handles large files by writing in chunks
            - Chunks are split by byte size to ensure MQTT compatibility (63KB limit)
            - Creates parent directories if they don't exist
            - In "overwrite" mode, replaces the entire file content
            - In "append" mode, adds content to the end of the file

        See Also:
            FileSystem.read_file, FileSystem.create_directory, FileSystem.edit_file
        """
        # Use pre-calculated safe chunk size based on first-principles analysis
        max_content_bytes = self.MAX_CONTENT_BYTES

        content_bytes = len(content.encode('utf-8'))
        _log_operation_start(
            f"WriteLargeFile to {path}",
            f"total size: {content_bytes} bytes (UTF-8), max chunk: {max_content_bytes} bytes",
        )

        # If the content fits in one chunk, write it directly
        if content_bytes <= max_content_bytes:
            return await self._write_file_chunk(path, content, mode)

        try:
            # Split content into chunks by byte size
            remaining_content = content
            is_first_chunk = True
            current_mode = mode

            while remaining_content:
                # Get the next chunk that fits within byte limit
                chunk = self._split_string_by_bytes(remaining_content, max_content_bytes)

                if not chunk:
                    # This should not happen, but handle edge case
                    return BoolResult(
                        request_id="",
                        success=False,
                        error_message="Failed to split content into valid chunks"
                    )

                # Write the chunk
                result = await self._write_file_chunk(path, chunk, current_mode)
                if not result.success:
                    return result

                # Update for next iteration
                chunk_len = len(chunk)
                remaining_content = remaining_content[chunk_len:]

                # After first chunk, switch to append mode
                if is_first_chunk:
                    is_first_chunk = False
                    current_mode = "append"

            return BoolResult(request_id=result.request_id, success=True, data=True)

        except FileError as e:
            return BoolResult(request_id="", success=False, error_message=str(e))
        except Exception as e:
            return BoolResult(
                request_id="",
                success=False,
                error_message=f"Failed to write file: {e}",
            )

    async def write(
        self, path: str, content: str, mode: str = "overwrite"
    ) -> BoolResult:
        """
        Alias of write_file().
        """
        return await self.write_file(path=path, content=content, mode=mode)

    async def list(self, path: str) -> DirectoryListResult:
        """
        Alias of list_directory().
        """
        return await self.list_directory(path)

    async def ls(self, path: str) -> DirectoryListResult:
        """
        Alias of list_directory().
        """
        return await self.list_directory(path)

    async def delete(self, path: str) -> BoolResult:
        """
        Alias of delete_file().
        """
        return await self.delete_file(path)

    async def remove(self, path: str) -> BoolResult:
        """
        Alias of delete_file().
        """
        return await self.delete_file(path)

    async def rm(self, path: str) -> BoolResult:
        """
        Alias of delete_file().
        """
        return await self.delete_file(path)

    async def upload_file(
        self,
        local_path: str,
        remote_path: str,
        *,
        content_type: Optional[str] = None,
        wait: bool = True,
        wait_timeout: float = 30.0,
        poll_interval: float = 1.5,
        progress_cb: Optional[Callable[[int], None]] = None,
    ) -> UploadResult:
        """
        Upload a file from local to remote path using pre-signed URLs.

        Args:
            local_path: Local file path to upload
            remote_path: Remote file path to upload to
            content_type: Optional content type for the file
            wait: Whether to wait for the sync operation to complete
            wait_timeout: Timeout for waiting for sync completion
            poll_interval: Interval between polling for sync completion
            progress_cb: Callback for upload progress updates

        Returns:
            UploadResult: Result of the upload operation

        Example:
            ```python
            params = CreateSessionParams(context_syncs=[ContextSync(context_id="ctx-xxx", path="/workspace")])
            session = (await agent_bay.create(params)).session
            upload_result = await session.file_system.upload_file("/local/file.txt", "/workspace/file.txt")
            await session.delete()
            ```
        """
        try:
            file_transfer = self._ensure_file_transfer()
            result = await file_transfer.upload(
                local_path=local_path,
                remote_path=remote_path,
                content_type=content_type,
                wait=wait,
                wait_timeout=wait_timeout,
                poll_interval=poll_interval,
                progress_cb=progress_cb,
            )
            # Upload completed successfully
            return result
        except Exception as e:
            return UploadResult(
                success=False,
                request_id_upload_url=None,
                request_id_sync=None,
                http_status=None,
                etag=None,
                bytes_sent=0,
                path=remote_path,
                error_message=f"Upload failed: {str(e)}",
            )

    async def download_file(
        self,
        remote_path: str,
        local_path: str,
        *,
        overwrite: bool = True,
        wait: bool = True,
        wait_timeout: float = 30.0,
        poll_interval: float = 1.5,
        progress_cb: Optional[Callable[[int], None]] = None,
    ) -> DownloadResult:
        """
        Download a file from remote path to local path using pre-signed URLs.

        Args:
            remote_path: Remote file path to download from
            local_path: Local file path to download to
            overwrite: Whether to overwrite existing local file
            wait: Whether to wait for the sync operation to complete
            wait_timeout: Timeout for waiting for sync completion
            poll_interval: Interval between polling for sync completion
            progress_cb: Callback for download progress updates

        Returns:
            DownloadResult: Result of the download operation

        Example:
            ```python
            params = CreateSessionParams(context_syncs=[ContextSync(context_id="ctx-xxx", path="/workspace")])
            session = (await agent_bay.create(params)).session
            download_result = await session.file_system.download_file("/workspace/file.txt", "/local/file.txt")
            await session.delete()
            ```
        """

        try:
            file_transfer = self._ensure_file_transfer()
            result = await file_transfer.download(
                remote_path=remote_path,
                local_path=local_path,
                overwrite=overwrite,
                wait=wait,
                wait_timeout=wait_timeout,
                poll_interval=poll_interval,
                progress_cb=progress_cb,
            )
            # Download completed successfully
            return result
        except Exception as e:
            return DownloadResult(
                success=False,
                request_id_download_url=None,
                request_id_sync=None,
                http_status=None,
                bytes_received=0,
                path=remote_path,
                local_path=local_path,
                error_message=f"Download exception: {str(e)}",
            )

    async def _get_file_change(self, path: str) -> FileChangeResult:
        """
        Get file change information for the specified directory path.

        Args:
            path: The directory path to monitor for file changes.

        Returns:
            FileChangeResult: Result object containing parsed file change events and
                error message if any.
        """

        def parse_file_change_data(raw_data: str) -> List[FileChangeEvent]:
            """
            Parse the raw file change data into FileChangeEvent objects.

            Args:
                raw_data (str): Raw JSON string containing file change events.

            Returns:
                List[FileChangeEvent]: List of parsed file change events.
            """
            events = []
            try:
                # Parse the JSON array
                change_data = json.loads(raw_data)
                if isinstance(change_data, list):
                    for event_dict in change_data:
                        if isinstance(event_dict, dict):
                            event = FileChangeEvent._from_dict(event_dict)
                            events.append(event)
                else:
                    print(f"Warning: Expected list but got {type(change_data)}")
            except json.JSONDecodeError as e:
                print(f"Warning: Failed to parse JSON data: {e}")
                print(f"Raw data: {raw_data}")
            except Exception as e:
                print(f"Warning: Unexpected error parsing file change data: {e}")

            return events

        args = {"path": path}
        try:
            result = await self.session.call_mcp_tool("get_file_change", args)
            try:
                print("Response body:")
                print(
                    json.dumps(
                        getattr(result, "body", result), ensure_ascii=False, indent=2
                    )
                )
            except Exception:
                print(f"Response: {result}")

            if result.success:
                # Parse the file change events
                events = parse_file_change_data(result.data)
                return FileChangeResult(
                    request_id=result.request_id,
                    success=True,
                    events=events,
                    raw_data=result.data,
                )
            else:
                return FileChangeResult(
                    request_id=result.request_id,
                    success=False,
                    raw_data=getattr(result, "data", ""),
                    error_message=result.error_message or "Failed to get file change",
                )
        except Exception as e:
            return FileChangeResult(
                request_id="",
                success=False,
                error_message=f"Failed to get file change: {e}",
            )

    def watch_directory(
        self,
        path: str,
        callback: Callable[[List[FileChangeEvent]], None],
        interval: float = 0.5,
        stop_event: Optional[threading.Event] = None,
    ) -> threading.Thread:
        """
        Watch a directory for file changes and call the callback function when changes occur.

        Args:
            path: The directory path to monitor for file changes.
            callback: Callback function that will be called with a list of FileChangeEvent
                objects when changes are detected.
            interval: Polling interval in seconds. Defaults to 0.5.
            stop_event: Optional threading.Event to stop the monitoring. If not provided,
                a new Event will be created and returned via the thread object.

        Returns:
            threading.Thread: The monitoring thread. Call thread.start() to begin monitoring.
                Use the thread's stop_event attribute to stop monitoring.

        Example:
            ```python
            def on_changes(events):
                print(f"Detected {len(events)} changes")
            session = (await agent_bay.create()).session
            await session.file_system.create_directory("/tmp/watch_test")
            monitor_thread = session.file_system.watch_directory("/tmp/watch_test", on_changes)
            monitor_thread.start()
            await session.file_system.write_file("/tmp/watch_test/test1.txt", "content 1")
            await session.file_system.write_file("/tmp/watch_test/test2.txt", "content 2")
            await session.delete()
            ```
        """

        async def _monitor_directory():
            """Internal function to monitor directory changes."""
            print(f"Starting directory monitoring for: {path}")
            print(f"Polling interval: {interval} seconds")

            while not stop_event.is_set():
                try:
                    # Check if session is still valid
                    if (
                        hasattr(self.session, "_is_expired")
                        and self.session._is_expired()
                    ):
                        print(
                            f"Session expired, stopping directory monitoring for: {path}"
                        )
                        stop_event.set()
                        break

                    # Get current file changes
                    result = await self._get_file_change(path)

                    if result.success:
                        current_events = result.events

                        # Only call callback if there are actual events
                        if current_events:
                            print(f"Detected {len(current_events)} file changes:")
                            for event in current_events:
                                print(f"  - {event}")

                            try:
                                callback(current_events)
                            except Exception as e:
                                print(f"Error in callback function: {e}")

                    else:
                        # Check if error is due to session expiry
                        error_msg = result.error_message or ""
                        if "session" in error_msg.lower() and (
                            "expired" in error_msg.lower()
                            or "invalid" in error_msg.lower()
                        ):
                            print(
                                f"Session expired, stopping directory monitoring for: {path}"
                            )
                            stop_event.set()
                            break
                        print(f"Error monitoring directory: {result.error_message}")

                    # Wait for the next poll
                    stop_event.wait(interval)

                except Exception as e:
                    print(f"Unexpected error in directory monitoring: {e}")
                    # Check if exception indicates session expiry
                    error_str = str(e).lower()
                    if "session" in error_str and (
                        "expired" in error_str or "invalid" in error_str
                    ):
                        print(
                            f"Session expired, stopping directory monitoring for: {path}"
                        )
                        stop_event.set()
                        break
                    stop_event.wait(interval)

            print(f"Stopped monitoring directory: {path}")

        # Create stop event if not provided
        if stop_event is None:
            stop_event = threading.Event()

        # Create and configure the monitoring thread
        def _sync_monitor():
            """Synchronous wrapper for async monitoring function."""
            import asyncio

            # Create a new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            try:
                loop.run_until_complete(_monitor_directory())
            finally:
                loop.close()

        monitor_thread = threading.Thread(
            target=_sync_monitor,
            name=f"DirectoryWatcher-{path.replace('/', '_')}",
            daemon=True,
        )

        # Add stop_event as an attribute to the thread for easy access
        monitor_thread.stop_event = stop_event

        return monitor_thread
