import os
import time
import uuid
from typing import TYPE_CHECKING, List, Optional

import httpx

from .._common.exceptions import AgentBayError
from .._common.logger import get_logger
from .._common.models.extension import (
    EXTENSIONS_BASE_PATH,
    Extension,
    ExtensionOption,
)
from .._common.models.response import OperationResult

if TYPE_CHECKING:
    from .agentbay import AsyncAgentBay
    from .context import AsyncContextService

# Initialize logger for this module
_logger = get_logger("extension")

# ==============================================================================
# 2. Core Service Class (Scoped Stateless Model)
# ==============================================================================


class AsyncExtensionsService:
    """
    Provides methods to manage user browser extensions asynchronously.
    This service integrates with the existing context functionality for file operations.

    **Usage** (Simplified - Auto-detection):
    ```python
    # Service automatically detects if context exists and creates if needed
    extensions_service = AsyncExtensionsService(agent_bay, "browser_extensions")

    # Use the service immediately
    extension = await extensions_service.create("/path/to/plugin.zip")
    ```

    **Integration with ExtensionOption (Simplified)**:
    ```python
    # Create extensions and configure for browser sessions
    extensions_service = AsyncExtensionsService(agent_bay, "my_extensions")
    ext1 = await extensions_service.create("/path/to/ext1.zip")
    ext2 = await extensions_service.create("/path/to/ext2.zip")

    # Create extension option for browser integration (no context_id needed!)
    ext_option = await extensions_service.create_extension_option([ext1.id, ext2.id])

    # Use with BrowserContext for session creation
    browser_context = BrowserContext(
        context_id="browser_session",
        auto_upload=True,
        extension_option=ext_option  # All extension config encapsulated
    )
    ```

    **Context Management**:
    - If context_id provided and exists: Uses the existing context
    - If context_id provided but doesn't exist: Creates context with provided name
    - If context_id empty or not provided: Generates default name and creates context
    - No need to manually manage context creation
    """

    def __init__(self, agent_bay: "AsyncAgentBay", context_id: str = ""):
        """
        Initializes the AsyncExtensionsService.

        Args:
            agent_bay (AsyncAgentBay): The AgentBay client instance.
            context_id (str, optional): The context ID or name. If empty or not provided,
                                       a default context name will be generated automatically.
                                       If the context doesn't exist, it will be automatically created
                                       when needed.
        """
        self.agent_bay = agent_bay
        self.context_service: "AsyncContextService" = agent_bay.context

        # Store provided context_id/name for lazy initialization
        self._provided_context_id = context_id

        # Internal state
        self.extension_context = None
        self.context_id = None
        self.context_name = None
        self.auto_created = False
        self._initialized = False

    async def _ensure_context(self):
        """
        Lazily ensure the context exists and is initialized.
        """
        if self._initialized:
            return

        # Generate default context name if context_id is empty
        context_name = self._provided_context_id
        if not context_name or context_name.strip() == "":
            import time

            context_name = f"extensions-{int(time.time())}"
            _logger.info(f"Generated default context name: {context_name}")
            self.auto_created = True  # Flag as auto-created if we generated the name

        # Context doesn't exist, create it
        context_result = await self.context_service.get(context_name, create=True)
        if not context_result.success or not context_result.context:
            raise AgentBayError(
                f"Failed to create extension repository context: {context_name}"
            )

        self.extension_context = context_result.context
        self.context_id = self.extension_context.id
        self.context_name = context_name
        self._initialized = True

    async def _upload_to_cloud(self, local_path: str, remote_path: str):
        """
        An internal helper method that encapsulates the flow of "get upload URL for a specific path and upload".
        Uses the existing context service for file operations.

        Args:
            local_path (str): The path to the local file.
            remote_path (str): The path of the file in context storage.

        Raises:
            AgentBayError: If getting the credential or uploading fails.
        """
        await self._ensure_context()

        # 1. Get upload URL using context service
        try:
            url_result = await self.context_service.get_file_upload_url(
                self.context_id, remote_path
            )
            if not url_result.success or not url_result.url:
                raise AgentBayError(
                    f"Failed to get upload URL: {url_result.url if url_result.url else 'No URL returned'}"
                )

            pre_signed_url = url_result.url
        except Exception as e:
            raise AgentBayError(
                f"An error occurred while requesting the upload URL: {e}"
            ) from e

        # 2. Use the presigned URL to upload the file directly using httpx
        try:
            async with httpx.AsyncClient() as client:
                with open(local_path, "rb") as f:
                    # httpx needs read content for upload usually, or an iterable
                    content = f.read()
                    response = await client.put(pre_signed_url, content=content)
                    response.raise_for_status()  # This will raise an HTTPError if the status is 4xx or 5xx
        except httpx.HTTPStatusError as e:
            raise AgentBayError(
                f"An error occurred while uploading the file: {e}"
            ) from e
        except Exception as e:
            raise AgentBayError(
                f"An error occurred while uploading the file: {e}"
            ) from e

    async def list(self) -> List[Extension]:
        """
        Lists all available browser extensions within this context from the cloud.
        Uses the context service to list files under the extensions directory.

        Returns:
            List[Extension]: List of all extensions in the context.

        Raises:
            AgentBayError: If listing fails.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay, "my-extensions")
            extensions = await extensions_service.list()
            print(f"Found {len(extensions)} extensions")
            ```
        """
        try:
            await self._ensure_context()

            # Use context service to list files in the extensions directory
            file_list_result = await self.context_service.list_files(
                context_id=self.context_id,
                parent_folder_path=EXTENSIONS_BASE_PATH,
                page_number=1,
                page_size=100,  # Reasonable limit for extensions
            )

            if not file_list_result.success:
                raise AgentBayError(
                    "Failed to list extensions: Context file listing failed."
                )

            extensions = []
            for file_entry in file_list_result.entries:
                # Extract the extension ID from the file name
                extension_id = file_entry.file_name
                extensions.append(
                    Extension(
                        id=extension_id,
                        name=file_entry.file_name,
                        created_at=file_entry.gmt_create,
                    )
                )
            return extensions
        except Exception as e:
            raise AgentBayError(
                f"An error occurred while listing browser extensions: {e}"
            ) from e

    async def create(self, local_path: str) -> Extension:
        """
        Uploads a new browser extension from a local path into the current context.

        Args:
            local_path (str): Path to the local extension ZIP file.

        Returns:
            Extension: Extension object with generated ID and metadata.

        Raises:
            FileNotFoundError: If the local file doesn't exist.
            ValueError: If the file format is not supported (only ZIP files allowed).
            AgentBayError: If upload fails.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay, "my-extensions")
            extension = await extensions_service.create("/path/to/extension.zip")
            print(f"Created extension: {extension.id}")
            ```
        """
        if not os.path.exists(local_path):
            raise FileNotFoundError(
                f"The specified local file was not found: {local_path}"
            )

        # Determine the ID and cloud path before uploading
        # Validate file type - only ZIP format is supported
        file_extension = os.path.splitext(local_path)[1].lower()
        if file_extension != ".zip":
            raise ValueError(
                f"Unsupported plugin format '{file_extension}'. Only ZIP format (.zip) is supported."
            )

        extension_id = f"ext_{uuid.uuid4().hex}{file_extension}"
        extension_name = os.path.basename(local_path)
        remote_path = f"{EXTENSIONS_BASE_PATH}/{extension_id}"

        # Use the helper method to perform the cloud upload
        await self._upload_to_cloud(local_path, remote_path)

        # Upload implies creation. Return a locally constructed object with basic info.
        return Extension(id=extension_id, name=extension_name)

    async def update(self, extension_id: str, new_local_path: str) -> Extension:
        """
        Updates an existing browser extension in the current context with a new file.

        Args:
            extension_id (str): ID of the extension to update.
            new_local_path (str): Path to the new extension ZIP file.

        Returns:
            Extension: Updated extension object.

        Raises:
            FileNotFoundError: If the new local file doesn't exist.
            ValueError: If the extension ID doesn't exist in the context.
            AgentBayError: If update fails.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay, "my-extensions")
            updated = await extensions_service.update("ext_abc123.zip", "/path/to/new_version.zip")
            print(f"Updated extension: {updated.id}")
            ```
        """
        if not os.path.exists(new_local_path):
            raise FileNotFoundError(
                f"The specified new local file was not found: {new_local_path}"
            )

        await self._ensure_context()

        # Validate that the extension exists by checking the file list
        extensions = await self.list()
        existing_extensions = {ext.id: ext for ext in extensions}
        if extension_id not in existing_extensions:
            raise ValueError(
                f"Browser extension with ID '{extension_id}' not found in the context. Cannot update."
            )

        remote_path = f"{EXTENSIONS_BASE_PATH}/{extension_id}"

        # Use the helper method to perform the cloud upload (overwrite)
        await self._upload_to_cloud(new_local_path, remote_path)

        return Extension(id=extension_id, name=os.path.basename(new_local_path))

    async def _get_extension_info(self, extension_id: str) -> Optional[Extension]:
        """
        Gets detailed information about a specific browser extension.

        Args:
            extension_id (str): The ID of the extension to get info for.

        Returns:
            Optional[Extension]: Extension object if found, None otherwise.
        """
        try:
            extensions = await self.list()
            for ext in extensions:
                if ext.id == extension_id:
                    return ext
            return None
        except Exception as e:
            _logger.error(
                f"An error occurred while getting extension info for '{extension_id}': {e}"
            )
            return None

    async def cleanup(self) -> bool:
        """
        Cleans up the auto-created context if it was created by this service.

        Returns:
            bool: True if cleanup was successful or not needed, False if cleanup failed.

        Note:
            This method only works if the context was auto-created by this service.
            For existing contexts, no cleanup is performed.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay)
            success = await extensions_service.cleanup()
            print(f"Cleanup success: {success}")
            ```
        """
        await self._ensure_context()

        if not self.auto_created:
            # Context was not auto-created by this service, no cleanup needed
            return True

        try:
            delete_result = await self.context_service.delete(self.extension_context)
            if delete_result:
                _logger.info(
                    f"Extension context deleted: {self.context_name} (ID: {self.context_id})"
                )
                return True
            else:
                _logger.warning(
                    f"Failed to delete extension context: {self.context_name}"
                )
                return False
        except Exception as e:
            _logger.warning(f"Failed to delete extension context: {e}")
            return False

    async def delete(self, extension_id: str) -> bool:
        """
        Deletes a browser extension from the current context.

        Args:
            extension_id (str): ID of the extension to delete.

        Returns:
            bool: True if deletion was successful, False otherwise.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay, "my-extensions")
            success = await extensions_service.delete("ext_abc123.zip")
            print(f"Delete success: {success}")
            ```
        """
        await self._ensure_context()
        remote_path = f"{EXTENSIONS_BASE_PATH}/{extension_id}"
        try:
            # Use context service to delete the file
            delete_result = await self.context_service.delete_file(
                self.context_id, remote_path
            )

            return delete_result.success
        except Exception as e:
            _logger.error(
                f"An error occurred while deleting browser extension '{extension_id}': {e}"
            )
            return False

    async def create_extension_option(self, extension_ids: List[str]) -> ExtensionOption:
        """
        Create an ExtensionOption for the current context with specified extension IDs.

        This is a convenience method that creates an ExtensionOption using the current
        service's context_id and the provided extension IDs. This option can then be
        used with BrowserContext for browser session creation.

        Args:
            extension_ids (List[str]): List of extension IDs to include in the option.
                                     These should be extensions that exist in the current context.

        Returns:
            ExtensionOption: Configuration object for browser extension integration.

        Raises:
            ValueError: If extension_ids is empty or invalid.

        Example:
            ```python
            extensions_service = AsyncExtensionsService(agent_bay, "my-extensions")
            ext_option = await extensions_service.create_extension_option(["ext1.zip", "ext2.zip"])
            print(f"Extension option: {ext_option}")
            ```
        """
        await self._ensure_context()

        cid = self.context_id or self._provided_context_id
        
        return ExtensionOption(context_id=cid, extension_ids=extension_ids)
