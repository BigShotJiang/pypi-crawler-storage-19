"""
Example demonstrating AIBrowser capabilites with AgentBay SDK.
This example shows how to use AIBrowser to solve captcha automatically, including:
- Create AIBrowser session
- Use playwright to connect to AIBrowser instance through CDP protocol
- Set solve_captchas to be True and goto tongcheng website
- We will encounter a captcha and we will solve it automatically.
"""

import os
import time
import asyncio
import base64

from agentbay import AsyncAgentBay
from agentbay import CreateSessionParams
from agentbay import BrowserOption

from playwright.async_api import async_playwright

from agentbay import (
    AsyncBrowser,
    BrowserOption,
    BrowserViewport,
    BrowserScreen,
    BrowserFingerprint,
    BrowserProxy
)

# Polling detection function, continuously checks until condition is met or timeout
async def wait_for_condition(page, condition_code, timeout=30000, interval=200):
    """Polling detection function, continuously checks until condition is met or timeout"""
    start_time = time.time()
    while time.time() - start_time < timeout / 1000:  # timeout is in milliseconds, convert to seconds
        try:
            result = await page.evaluate(condition_code)
            if result:
                return True
        except Exception:
            # Ignore errors, continue polling
            pass
        await asyncio.sleep(interval / 1000)  # interval is in milliseconds, convert to seconds
    return False

async def main():
    # Get API key from environment variable
    api_key = os.getenv("AGENTBAY_API_KEY")
    if not api_key:
        print("Error: AGENTBAY_API_KEY environment variable not set")
        return

    # Initialize AgentBay client
    print("Initializing AgentBay client...")
    agent_bay = AsyncAgentBay(api_key=api_key)

    # Create a session
    print("Creating a new session...")
    params = CreateSessionParams(
        image_id="browser_latest",  # Specify the image ID
    )
    session_result = await agent_bay.create(params)

    if session_result.success:
        session = session_result.session
        print(f"Session created with ID: {session.session_id}")

        browser_option = BrowserOption(
            use_stealth=True,
            solve_captchas=True,
        )
        if await session.browser.initialize(browser_option):
            print("Browser initialized successfully")
            endpoint_url = await session.browser.get_endpoint_url()
            print("endpoint_url =", endpoint_url)

            async with async_playwright() as p:
                browser = await p.chromium.connect_over_cdp(endpoint_url)
                context = browser.contexts[0]
                page = await context.new_page()
                print("🌐 Navigating to tongcheng site...")
                url = "https://passport.ly.com/Passport/GetPassword"
                await page.goto(url, wait_until="domcontentloaded")

                # Use selector to locate input field
                input_element = await page.wait_for_selector('#name_in', timeout=10000)
                print("Found login name input field: #name_in")

                # Clear input field and enter phone number
                phone_number = "15011556760"
                print(f"Entering phone number: {phone_number}")

                await input_element.click()
                await input_element.fill("")  # Clear input field
                await input_element.type(phone_number)
                print("Waiting for captcha")

                # Wait a moment to ensure input is complete
                await asyncio.sleep(1)

                print("Clicking next step button...")
                await page.click('#next_step1')

                # Listen for console messages
                def handle_console(msg):
                    print(f"🔍 Received console message: {msg.text}")
                    if msg.text == "wuying-captcha-solving-started":
                        print("🎯 Captcha processing started")
                        asyncio.create_task(page.evaluate("window.captchaSolvingStarted = true; window.captchaSolvingFinished = false;"))
                    elif msg.text == "wuying-captcha-solving-finished":
                        print("✅ Captcha processing finished")
                        asyncio.create_task(page.evaluate("window.captchaSolvingFinished = true;"))

                page.on("console", handle_console)

                # wait for 1 second
                await asyncio.sleep(1)
                
                started = await wait_for_condition(
                    page,
                    "() => window.captchaSolvingStarted === true",
                    3000,
                    200
                )
                
                if started:
                    print("🎯 Detected captcha processing started, waiting for completion...")
                    finished = await wait_for_condition(
                        page,
                        "() => window.captchaSolvingFinished === true",
                        30000,
                        200
                    )
                    if finished:
                        print("✅ Captcha processing completed")
                    else:
                        print("⚠️ Captcha processing timeout, may still be in progress, continuing execution")
                else:
                    print("⏭️ No captcha processing detected, may not need to handle captcha")

                await asyncio.sleep(2)
                print("Test completed")

                # Keep browser open for a while to observe results
                await asyncio.sleep(5)

                # Take screenshot and print base64, can be pasted directly into Chrome address bar
                try:
                    screenshot_bytes = await page.screenshot(full_page=False)
                    b64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                    print("page_screenshot_base64 = data:image/png;base64,", b64)
                except Exception as e:
                    print("screenshot failed:", e)

                await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
