#!/usr/bin/env python3

import os
import asyncio

from agentbay import AsyncAgentBay, ContextSync, SyncPolicy, CreateSessionParams
from agentbay import AgentBayError, ClearanceTimeoutError

async def main():
    # Initialize the AgentBay client
    # You can provide the API key as a parameter or set the AGENTBAY_API_KEY
    # environment variable
    api_key = os.environ.get("AGENTBAY_API_KEY")
    if not api_key:
        api_key = "akm-xxx"  # Replace with your actual API key

    session = None
    try:
        agent_bay = AsyncAgentBay(api_key=api_key)

        # Example 1: List all contexts
        print("\nExample 1: Listing all contexts...")
        try:
            result = await agent_bay.context.list()
            print(f"Request ID: {result.request_id}")
            if result.success:
                print(f"Found {len(result.contexts)} contexts:")
                for context in result.contexts:
                    print(
                        f"- {context.name} ({context.id}): created_at={context.created_at}, last_used_at={context.last_used_at}"
                    )
            else:
                print("Failed to list contexts")
        except AgentBayError as e:
            print(f"Error listing contexts: {e}")

        # Example 2: Get a context (create if it doesn't exist)
        print("\nExample 2: Getting a context (creating if it doesn't exist)...")
        context_name = "my-test-context"
        try:
            result = await agent_bay.context.get(context_name, create=True)
            print(f"Request ID: {result.request_id}")
            if result.success and result.context:
                context = result.context
                print(f"Got context: {context.name} ({context.id})")
            else:
                print("Context not found and could not be created")
                return
        except AgentBayError as e:
            print(f"Error getting context: {e}")
            return

        # Example 3: Create a session with the context
        print("\nExample 3: Creating a session with the context...")
        try:
            params = CreateSessionParams(
                labels={"username": "alice", "project": "my-project"},
            )
            # Fix: context_syncs should be a list, not a single ContextSync object
            params.context_syncs = [ContextSync.new(
                context.id,
                "/tmp/shared",
                SyncPolicy.default()
            )]
            session_result = await agent_bay.create(params)
            session = session_result.session
            print(f"Session created with ID: {session.session_id}")
            print(f"Request ID: {session_result.request_id}")
            print("Note: The create() method automatically monitored the context status")
            print("and only returned after all context operations were complete or reached maximum retries.")
        except AgentBayError as e:
            print(f"Error creating session: {e}")
            return

        # Example 4: Update the context
        print("\nExample 4: Updating the context...")
        try:
            context.name = "renamed-test-context"
            result = await agent_bay.context.update(context)
            print(f"Request ID: {result.request_id}")
            if not result.success:
                print(f"Context update was not successful: {result.error_message}")
            else:
                print(f"Context updated successfully to: {context.name}")
        except AgentBayError as e:
            print(f"Error updating context: {e}")

        # Example 5: Clear context data
        print("\nExample 5: Clearing context data...")
        try:
            # Note: For now, skip the clear operation due to API parameter requirements
            # The clear functionality requires additional API parameter handling
            print("⏭️ Skipping clear operation (requires API parameter handling)")
            print("   This is a known issue that needs to be addressed in the SDK")
        except Exception as e:
            print(f"Error clearing context: {e}")

        # Example 6: Get context by name (using the updated name)
        print("\nExample 6: Getting context by name...")
        try:
            result = await agent_bay.context.get(name=context.name)
            print(f"Request ID: {result.request_id}")
            if result.success and result.context:
                print(f"✅ Got context by name: {result.context.name} ({result.context.id})")
            else:
                print(f"Failed to get context by name")
        except AgentBayError as e:
            print(f"Error getting context by name: {e}")

        # Clean up
        print("\nCleaning up...")

        # Delete the session with context synchronization
        try:
            if session:
                print("Deleting the session with context synchronization...")
                delete_result = await agent_bay.delete(session, sync_context=True)
                print(f"Session deletion request ID: {delete_result.request_id}")
                print(f"Session deletion success: {delete_result.success}")
                print("Note: The delete() method synchronized the context before session deletion")
                print("and monitored all context operations until completion.")
                session = None

                # Alternative method using session's delete method:
                # delete_result = session.delete(sync_context=True)
        except AgentBayError as e:
            print(f"Error deleting session: {e}")

        # Delete the context
        print("Deleting the context...")
        try:
            result = await agent_bay.context.delete(context)
            print(f"Context deletion request ID: {result.request_id}")
            if result.success:
                print("Context deleted successfully")
            else:
                print(f"Failed to delete context: {result.error_message}")
        except AgentBayError as e:
            print(f"Error deleting context: {e}")

    except Exception as e:
        print(f"Error initializing AgentBay: {e}")
        if session:
            try:
                await agent_bay.delete(session)
                print("Session deleted during cleanup")
            except AgentBayError as delete_error:
                print(f"Error deleting session during cleanup: {delete_error}")

if __name__ == "__main__":
    asyncio.run(main())
