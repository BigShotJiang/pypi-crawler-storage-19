import asyncio
import os
import time

from agentbay import AsyncAgentBay, CreateSessionParams


async def main() -> None:
    api_key = os.getenv("AGENTBAY_API_KEY")
    if not api_key:
        raise RuntimeError("AGENTBAY_API_KEY environment variable not set")

    agent_bay = AsyncAgentBay(api_key=api_key)
    session_result = await agent_bay.create(CreateSessionParams(image_id="linux_latest"))
    if not session_result.success or not session_result.session:
        raise RuntimeError(f"Failed to create session: {session_result.error_message}")

    session = session_result.session
    remote_path = f"/tmp/agentbay_delete_file_example_{int(time.time())}.txt"

    try:
        write_result = await session.file_system.write_file(remote_path, "hello delete_file")
        if not write_result.success:
            raise RuntimeError(f"write_file failed: {write_result.error_message}")

        delete_result = await session.file_system.delete_file(remote_path)
        if not delete_result.success:
            raise RuntimeError(f"delete_file failed: {delete_result.error_message}")

        info_after = await session.file_system.get_file_info(remote_path)
        print("delete_file success:", delete_result.success)
        print("get_file_info after delete success:", info_after.success)
    finally:
        await session.delete()


if __name__ == "__main__":
    asyncio.run(main())



