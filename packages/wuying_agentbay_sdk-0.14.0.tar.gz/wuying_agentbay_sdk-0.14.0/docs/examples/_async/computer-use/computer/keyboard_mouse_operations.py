"""
Computer Keyboard and Mouse Operations Example

This example demonstrates:
1. Simulating keyboard input
2. Simulating mouse operations
3. Automating desktop interactions
"""

import asyncio
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

from agentbay import AsyncAgentBay
from agentbay import CreateSessionParams


async def main():
    """Demonstrate keyboard and mouse operations."""
    print("=== Computer Keyboard and Mouse Operations Example ===\n")

    client = AsyncAgentBay()
    session = None

    try:
        # Create a computer session
        print("Creating computer session...")
        session_result = await client.create(
            CreateSessionParams(image_id="windows_latest")
        )
        session = session_result.session
        print(f"Session created: {session.session_id}")

        # Open notepad
        print("\n1. Opening Notepad...")
        result = await session.command.execute_command("start notepad")
        print("Notepad opened")

        # Wait a moment for notepad to open
        await asyncio.sleep(2)

        # Type some text (demonstration)
        print("\n2. Simulating keyboard input...")
        print("Note: Actual keyboard/mouse simulation would use computer module API")
        print("Example: session.computer.keyboard.type('Hello World')")

        # List running processes
        print("\n3. Listing running processes...")
        result = await session.command.execute_command("tasklist | findstr notepad")
        print(f"Notepad process:\n{result.output}")

        # Close notepad
        print("\n4. Closing Notepad...")
        result = await session.command.execute_command("taskkill /IM notepad.exe /F")
        print("Notepad closed")

        print("\n=== Example completed successfully ===")

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        raise

    finally:
        if session:
            print("\nCleaning up session...")
            await client.delete(session)
            print("Session closed")


if __name__ == "__main__":
    asyncio.run(main())

