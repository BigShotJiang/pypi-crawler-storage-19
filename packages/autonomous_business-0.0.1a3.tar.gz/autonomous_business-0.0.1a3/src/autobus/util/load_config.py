import configparser
import os
import sys

def load_config(config_path=None):
    config = configparser.ConfigParser()

    # 1. Look in the current working directory as a last resort (for local development)
    cwd_config_path = 'config.ini'
    if os.path.exists(cwd_config_path):
        config.read(cwd_config_path)
        return config

    # 2. Look in the user's home directory: ~/.autobus/config.ini
    home_dir_config_path = os.path.join(os.path.expanduser("~"), '.autobus', 'config.ini')
    if os.path.exists(home_dir_config_path):
        config.read(home_dir_config_path)
        return config

    # Handle cases where no config is found (optional)
    print("Warning: No configuration file found in standard locations.", file=sys.stderr)
    return config # Returns an empty config object, handle missing keys gracefully

config = load_config()