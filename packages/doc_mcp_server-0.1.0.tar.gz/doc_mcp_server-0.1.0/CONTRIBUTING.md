# Contributing to Document Analyzer MCP

感谢你对 Document Analyzer MCP 的关注！我们欢迎所有形式的贡献。

## 🤝 如何贡献

### 报告Bug

如果你发现bug，请[创建Issue](https://github.com/yourusername/doc-mcp-server/issues)并提供：

- 操作系统和Python版本
- 详细的复现步骤
- 预期行为 vs 实际行为
- 错误日志（如有）

### 提出新功能

我们欢迎新功能建议！请先[创建Issue](https://github.com/yourusername/doc-mcp-server/issues)讨论：

- 功能描述
- 使用场景
- 可能的实现方案

### 提交代码

1. **Fork仓库**

2. **创建特性分支**
   ```bash
   git checkout -b feature/amazing-feature
   ```

3. **编写代码**
   - 遵循现有代码风格
   - 添加必要的注释（中文）
   - 编写测试用例

4. **运行测试**
   ```bash
   pytest tests/
   ```

5. **提交代码**
   ```bash
   git commit -m "feat: 添加XX功能"
   ```

   提交信息格式：
   - `feat:` - 新功能
   - `fix:` - Bug修复
   - `docs:` - 文档更新
   - `test:` - 测试相关
   - `refactor:` - 代码重构

6. **推送分支**
   ```bash
   git push origin feature/amazing-feature
   ```

7. **创建Pull Request**

## 📝 开发指南

### 环境设置

```bash
# 克隆仓库
git clone https://github.com/yourusername/doc-mcp-server
cd doc-mcp-server

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装开发依赖
pip install -e ".[dev]"
```

### 代码规范

- **Python版本**: 3.10+
- **代码风格**: 遵循PEP 8
- **格式化**: 使用Black
- **类型检查**: 使用mypy
- **注释**: 关键代码必须有中文注释

### 运行测试

```bash
# 运行所有测试
pytest

# 运行特定测试
pytest tests/test_excel_analyzer.py

# 查看覆盖率
pytest --cov=document_analyzer tests/
```

### 代码检查

```bash
# 格式化代码
black src/

# 类型检查
mypy src/
```

## 🎯 优先级功能

我们特别欢迎以下领域的贡献：

### 高优先级
- [ ] PDF文档支持
- [ ] Word文档支持
- [ ] 单元测试覆盖率提升
- [ ] 性能优化

### 中优先级
- [ ] 智能分块算法
- [ ] 向量化存储支持
- [ ] 语义搜索
- [ ] 更多文档格式（Markdown、HTML等）

### 低优先级
- [ ] Web界面
- [ ] CLI工具
- [ ] Docker镜像

## 📚 文档贡献

文档同样重要！你可以：

- 修正文档错误
- 添加使用示例
- 翻译文档（英文）
- 编写教程

## 🌍 社区准则

- 尊重所有贡献者
- 建设性的讨论
- 友好的代码审查
- 及时回复Issue和PR

## 📮 联系方式

- GitHub Issues: [提交问题](https://github.com/yourusername/doc-mcp-server/issues)
- Discord: [加入讨论](https://discord.gg/xxx)
- Email: your.email@example.com

## 📄 许可证

通过贡献代码，你同意你的贡献将遵循[MIT License](LICENSE)。

---

再次感谢你的贡献！🎉
