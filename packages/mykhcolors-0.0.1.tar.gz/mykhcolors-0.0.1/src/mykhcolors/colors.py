# colors.py

"""
Mini project with ansi color codes
"""


def red(text: str) -> str:
    return f"\033[31m{text}\033[0m"


def green(text: str) -> str:
    return f"\033[32m{text}\033[0m"


def yellow(text: str) -> str:
    return f"\033[33m{text}\033[0m"


def bold(text: str) -> str:
    return f"\033[1m{text}\033[0m"


def italic(text: str) -> str:
    return f"\033[3m{text}\033[0m"


def main():
    print(f"{yellow('Hello')} {green('from')} {bold(italic(red('mykhcolors!')))}")
