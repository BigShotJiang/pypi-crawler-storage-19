# SPDX-FileCopyrightText: 2026-present khaz <pykhaz@o2.pl>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
