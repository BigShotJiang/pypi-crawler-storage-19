"""Configuration management for fastlang."""
