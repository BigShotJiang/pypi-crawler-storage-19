from _typeshed import Incomplete
from enum import Enum
from pybiotech.loaders.sdf_loader import SDFLoader as SDFLoader
from pydantic import BaseModel
from rdkit import Chem as Chem

class EInputType(str, Enum):
    CID = 'cid'
    SMILES = 'smiles'
    INCHI = 'InChI'

class EOperationType(str, Enum):
    RECORD = 'record'
    CIDS = 'cids'
    SIDS = 'sids'

class EOutputType(str, Enum):
    SDF = 'SDF'
    JSON = 'JSON'
    XML = 'XML'
    ASNB = 'ASNB'
    ASNT = 'ASNT'
    TXT = 'TXT'
    PNG = 'PNG'

class ALNPConformer(BaseModel):
    PUBCHEM_COMPOUND_CID: str
    PUBCHEM_CONFORMER_ID: str
    RAW: str
    model_config: Incomplete
    def convert_pubchem_cid(cls, v): ...
    def to_chem_mol(self, ignore_error: bool = False) -> Chem.Mol | None: ...

class ALNPCompound(BaseModel):
    PUBCHEM_COMPOUND_CID: str
    RAW: str
    CONFORMER_ID: list[str] | None
    CONFORMERS: dict[str, ALNPConformer] | None
    model_config: Incomplete
    def convert_pubchem_cid(cls, v): ...
    def to_chem_mol(self, ignore_error: bool = False) -> Chem.Mol | None: ...
    def to_conformers_chem_mol(self, ignore_error: bool = False) -> list[Chem.Mol] | None: ...
