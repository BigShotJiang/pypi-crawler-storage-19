"""Apptainer software installation."""
