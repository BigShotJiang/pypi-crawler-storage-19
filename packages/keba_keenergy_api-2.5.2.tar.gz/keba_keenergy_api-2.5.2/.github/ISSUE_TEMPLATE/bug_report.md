---
name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: bug
assignees: ''

---

## Bug

# Describe the bug

A clear and concise description of what the bug is.

## To Reproduce

Steps to reproduce the behavior:

1. ...

## Expected behavior

A clear and concise description of what you expected to happen.

## Screenshots

If applicable, add screenshots to help explain your problem.

## Software and hardware

- Web HMI Software version (`Service -> Systeminformationen -> Software`)
- Device hardware name [e.g. AP440/H-A] (`Service -> Systeminformationen -> Gerät`)

## Additional context

Add any other context about the problem here.
