#!/usr/bin/env python3
"""
Installation helpers for external dependencies
"""
import os
import sys
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, List


def install_cosmos_tokenizer(
    use_docker: bool = False,
    skip_models: bool = True
) -> str:
    """
    Install NVIDIA Cosmos-Tokenizer via pip.
    
    Note: Model downloads are handled separately by checkpoints.py
    
    Args:
        use_docker: Whether to use Docker installation instead
        skip_models: Skip model downloads (handled by checkpoints.py)
    
    Returns:
        Status message indicating successful installation
        
    Raises:
        RuntimeError: If installation fails
    """
    if use_docker:
        return _install_cosmos_docker()
    else:
        return _install_cosmos_pip(skip_models)


def _install_cosmos_pip(skip_models: bool = True) -> str:
    """Install Cosmos-Tokenizer directly via pip from GitHub"""
    
    # Check system requirements
    _check_system_requirements()
    
    print("Installing Cosmos-Tokenizer via pip...")
    
    try:
        # Install directly from GitHub using pip
        print("📦 Installing cosmos-tokenizer from GitHub...")
        _run_command([
            sys.executable, "-m", "pip", "install", 
            "git+https://github.com/NVIDIA/Cosmos-Tokenizer.git"
        ])
        
        print("✅ Cosmos-Tokenizer successfully installed via pip")
        
        # Verify installation
        try:
            _run_command([sys.executable, "-c", "import cosmos_tokenizer; print('Import successful')"])
            print("✅ Installation verified - cosmos_tokenizer can be imported")
        except subprocess.CalledProcessError:
            print("⚠️  Warning: Could not verify installation by importing cosmos_tokenizer")
        
        if skip_models:
            print("\n📋 Next steps:")
            print("  1. Use 'carlib setup download <model>' to download specific models")
            print("  2. Use 'carlib setup list' to see available models")
        
        return "✅ Cosmos-Tokenizer installed successfully via pip"
        
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to install Cosmos-Tokenizer: {e}")


def _install_cosmos_docker() -> str:
    """Install via Docker (deprecated - use pip installation instead)"""
    print("⚠️  Docker installation method is deprecated.")
    print("📦 Using pip installation instead...")
    
    return _install_cosmos_pip(skip_models=True)


def _check_system_requirements() -> None:
    """Check if system meets requirements"""
    # Check Python version
    if sys.version_info < (3, 8):
        raise RuntimeError("Python 3.8 or higher is required for Cosmos-Tokenizer")
    
    # Check for CUDA (optional but recommended)
    try:
        import torch
        if torch.cuda.is_available():
            print(f"✅ CUDA available: {torch.cuda.get_device_name()}")
        else:
            print("⚠️  CUDA not available - CPU-only installation")
    except ImportError:
        print("⚠️  PyTorch not installed - will be installed as dependency")
    
    # Check for pip (should always be available)
    try:
        import pip
        print(f"✅ pip available: {pip.__version__}")
    except ImportError:
        raise RuntimeError("pip is required but not available")


def _run_command(cmd: List[str], check: bool = True) -> subprocess.CompletedProcess:
    """Run a shell command with proper error handling"""
    print(f"Running: {' '.join(cmd)}")
    try:
        result = subprocess.run(
            cmd, 
            check=check, 
            capture_output=True, 
            text=True,
            timeout=300  # 5 minute timeout
        )
        if result.stdout:
            print(result.stdout)
        return result
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"Command timed out: {' '.join(cmd)}")
    except subprocess.CalledProcessError as e:
        if e.stderr:
            print(f"Error: {e.stderr}")
        if check:
            raise
        return e


def install_cosmos_wrapper() -> None:
    """
    Interactive installer for Cosmos-Tokenizer via pip
    """
    print("🚀 Cosmos-Tokenizer Installation Helper")
    print("=" * 50)
    print("\nNote: Models will be managed separately via 'carlib setup' commands")
    
    # Confirm installation
    print("\nThis will install cosmos-tokenizer via pip from GitHub.")
    confirm = input("Proceed with installation? (Y/n): ").strip().lower()
    
    if confirm == 'n':
        print("Installation cancelled.")
        return
    
    # Skip model downloads
    skip_models = input("Skip model downloads? (Y/n): ").strip().lower() != 'n'
    
    try:
        result = install_cosmos_tokenizer(skip_models=skip_models)
        
        print(f"\n✅ Installation complete!")
        print("\n📋 Next steps:")
        print("1. Download models: carlib setup download CI8x8")
        print("2. List available models: carlib setup list")
        print("\n🔥 Usage example:")
        print("""
from cosmos_tokenizer.image_lib import ImageTokenizer
from cosmos_tokenizer.video_lib import VideoTokenizer

# Image tokenizer
image_tokenizer = ImageTokenizer()
tokens = image_tokenizer.encode(image)

# Video tokenizer  
video_tokenizer = VideoTokenizer()
tokens = video_tokenizer.encode(video)
        """)
        
    except RuntimeError as e:
        print(f"\n❌ Installation failed: {e}")
        print("\n🔧 Manual installation:")
        print("pip install git+https://github.com/NVIDIA/Cosmos-Tokenizer.git")


if __name__ == "__main__":
    install_cosmos_wrapper()