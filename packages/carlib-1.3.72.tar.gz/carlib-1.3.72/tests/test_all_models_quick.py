#!/usr/bin/env python3
"""
Quick test for all audio models (DAC, SNAC, EnCodec) with short durations
"""
import sys
from pathlib import Path

def test_model(model_name, model_type, test_mp3, duration=1.0):
    """Test a single model with very short duration"""
    print(f"\n🎵 Testing {model_type.upper()}: {model_name}")
    print("-" * 40)
    
    try:
        from carlib.processors.audio_codecs import AudioProcessor, AudioConfig
        
        config = AudioConfig(
            model_name=model_name,
            model_type=model_type,
            device="cpu",
            max_duration=duration  # Very short for quick test
        )
        
        print("1️⃣ Creating processor...")
        processor = AudioProcessor(config)
        print("✅ Processor created")
        
        print("2️⃣ Loading audio...")
        audio_data, metadata = processor.load_audio(str(test_mp3), duration)
        print(f"✅ Audio loaded: {metadata['num_channels']} channels, {metadata['duration']:.1f}s")
        
        print("3️⃣ Testing encoding...")
        encoded = processor.encode_audio(audio_data, metadata)
        print("✅ Encoding successful!")
        
        return True, "Success"
        
    except Exception as e:
        error_msg = str(e)
        if "channels" in error_msg:
            return False, f"Channel error: {error_msg[:100]}"
        elif "CUDA" in error_msg:
            return False, f"CUDA error: {error_msg[:100]}"
        else:
            return False, f"Error: {error_msg[:100]}"

def main():
    print("🚀 Quick Audio Models Test")
    print("=" * 50)
    
    # Find MP3
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    mp3_files = list(assets_dir.glob("*.mp3"))
    
    if not mp3_files:
        print("❌ No MP3 files found")
        return False
    
    test_mp3 = mp3_files[0]
    print(f"🎵 Test file: {test_mp3.name}")
    
    # Test models with very short duration for speed
    models_to_test = [
        # SNAC models (should work with stereo)
        ("snac_24khz", "snac"),
        
        # EnCodec models (should work)
        ("facebook/encodec_32khz", "encodec"),
        
        # DAC models (test our fix)
        ("dac_24khz", "dac"),
    ]
    
    results = []
    
    for model_name, model_type in models_to_test:
        print(f"\n{'='*60}")
        success, message = test_model(model_name, model_type, test_mp3, duration=1.0)
        results.append({
            'model': f"{model_type}:{model_name}",
            'success': success,
            'message': message
        })
        
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"🏁 Result: {status} - {message}")
    
    # Summary
    print(f"\n{'='*60}")
    print("📋 SUMMARY")
    print(f"{'='*60}")
    
    passed = sum(1 for r in results if r['success'])
    total = len(results)
    
    print(f"📊 Tests passed: {passed}/{total}")
    
    for result in results:
        status = "✅" if result['success'] else "❌"
        print(f"  {result['model']:<25} {status} {result['message']}")
    
    if passed == total:
        print(f"\n🎉 ALL MODELS WORKING!")
        return True
    elif passed > 0:
        print(f"\n⚠️  Some models working, check failures above")
        return True  # Partial success
    else:
        print(f"\n❌ All models failed")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted")
        sys.exit(1)