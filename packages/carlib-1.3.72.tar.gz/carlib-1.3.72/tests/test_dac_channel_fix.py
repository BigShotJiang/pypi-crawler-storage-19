#!/usr/bin/env python3
"""
Focused test to verify DAC channel fix - tests the specific stereo->mono conversion
"""
import sys
from pathlib import Path

def test_dac_channel_conversion():
    """Test that DAC properly converts stereo to mono"""
    print("🔧 Testing DAC Channel Conversion Fix")
    print("=" * 45)
    
    # Find MP3
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    mp3_files = list(assets_dir.glob("*.mp3"))
    
    if not mp3_files:
        print("❌ No MP3 files found")
        return False
    
    test_mp3 = mp3_files[0]
    print(f"🎵 Test file: {test_mp3.name}")
    
    # First check what the original audio looks like
    print(f"\n1️⃣ Analyzing input audio...")
    try:
        import torchaudio
        info = torchaudio.info(str(test_mp3))
        print(f"📊 Original audio: {info.num_channels} channels, {info.sample_rate} Hz")
        
        if info.num_channels == 1:
            print("ℹ️  Audio is already mono - DAC should work without conversion")
        else:
            print("ℹ️  Audio is stereo - DAC needs conversion to mono")
            
    except Exception as e:
        print(f"⚠️  Could not analyze audio: {e}")
    
    # Test the DAC processor directly
    print(f"\n2️⃣ Testing DAC audio loading...")
    try:
        from carlib.processors.audio_codecs import DACAudioProcessor, AudioConfig
        
        config = AudioConfig(
            model_name="dac_24khz",
            model_type="dac",
            device="cpu",
            max_duration=1.0  # Very short test
        )
        
        print("   Creating DAC processor...")
        # This may take time to download model
        import signal
        
        def timeout_handler(signum, frame):
            raise TimeoutError("DAC model download/init taking too long")
        
        # Set a timeout for model initialization
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(60)  # 60 second timeout
        
        try:
            processor = DACAudioProcessor(config)
            signal.alarm(0)  # Cancel timeout
            print("   ✅ DAC processor created")
        except TimeoutError:
            print("   ⏰ DAC processor initialization timed out (model download issue)")
            return False
        
        # Test audio loading - this should do the conversion
        print("   Testing audio loading with conversion...")
        audio_signal, metadata = processor.load_audio(str(test_mp3), 1.0)
        
        print(f"   ✅ Audio loaded successfully!")
        print(f"   📊 Result: {metadata['num_channels']} channels")
        print(f"   📊 Duration: {metadata['duration']:.1f}s")
        print(f"   📊 Sample rate: {metadata['processed_sample_rate']} Hz")
        
        if metadata['num_channels'] == 1:
            print("   🎉 SUCCESS: Audio converted to mono!")
            return True
        else:
            print(f"   ❌ FAILED: Audio still has {metadata['num_channels']} channels")
            return False
            
    except Exception as e:
        error_str = str(e)
        if "channels" in error_str and "expected" in error_str:
            print(f"   ❌ CHANNEL ERROR STILL EXISTS: {error_str}")
            print("   🔧 The fix didn't work - DAC still getting wrong channel count")
            return False
        else:
            print(f"   ❌ OTHER ERROR: {error_str}")
            return False

def test_channel_conversion_logic():
    """Test just the AudioSignal mono conversion without model"""
    print(f"\n3️⃣ Testing AudioSignal mono conversion...")
    
    try:
        from descript_audiotools import AudioSignal
        
        # Find MP3
        project_root = Path(__file__).parent.parent
        assets_dir = project_root / "assets"
        mp3_files = list(assets_dir.glob("*.mp3"))
        test_mp3 = mp3_files[0]
        
        # Load audio
        print("   Loading audio with AudioSignal...")
        signal = AudioSignal(str(test_mp3))
        print(f"   Original: {signal.num_channels} channels")
        
        # Test conversion
        if signal.num_channels > 1:
            print("   Converting to mono...")
            mono_signal = signal.to_mono()
            print(f"   Result: {mono_signal.num_channels} channels")
            
            if mono_signal.num_channels == 1:
                print("   ✅ AudioSignal mono conversion works!")
                return True
            else:
                print("   ❌ AudioSignal mono conversion failed")
                return False
        else:
            print("   ℹ️  Audio already mono - conversion not needed")
            return True
            
    except Exception as e:
        print(f"   ❌ AudioSignal test failed: {e}")
        return False

def main():
    print("🧪 DAC Channel Fix Verification Test")
    print("=" * 50)
    
    # Test 1: AudioSignal conversion logic
    conversion_works = test_channel_conversion_logic()
    
    # Test 2: Full DAC processor test
    dac_works = test_dac_channel_conversion()
    
    # Summary
    print(f"\n{'='*50}")
    print("📋 TEST RESULTS")
    print(f"{'='*50}")
    print(f"AudioSignal conversion: {'✅ PASS' if conversion_works else '❌ FAIL'}")
    print(f"DAC processor test:     {'✅ PASS' if dac_works else '❌ FAIL'}")
    
    if conversion_works and dac_works:
        print(f"\n🎉 DAC channel fix is working!")
        return True
    elif conversion_works and not dac_works:
        print(f"\n⚠️  Conversion works but DAC processor has other issues")
        return False
    else:
        print(f"\n❌ Channel conversion fix needs more work")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n⏹️ Test interrupted")
        sys.exit(1)