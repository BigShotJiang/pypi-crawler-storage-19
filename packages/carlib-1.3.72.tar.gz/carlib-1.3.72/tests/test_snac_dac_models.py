#!/usr/bin/env python3
"""
Test SNAC and DAC audio models with MP3 files from assets folder
"""
import sys
import os
import tempfile
import shutil
from pathlib import Path
import traceback

def test_model_conversion(model_name, model_type, mp3_file_path):
    """Test conversion with specific audio model"""
    print(f"\n🎵 Testing {model_type.upper()} Model: {model_name}")
    print("=" * 50)
    
    # Create temporary directories
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        input_dir = temp_path / "input"
        output_dir = temp_path / "output"
        input_dir.mkdir()
        output_dir.mkdir()
        
        # Copy MP3 file to input directory
        input_file = input_dir / Path(mp3_file_path).name
        shutil.copy2(mp3_file_path, input_file)
        print(f"📁 Input file: {input_file.name}")
        
        try:
            # Test direct processor usage first
            print(f"\n1️⃣ Testing {model_type} processor directly...")
            from carlib.processors.audio_codecs import AudioProcessor, AudioConfig
            
            # Create config for specific model
            config = AudioConfig(
                model_name=model_name,
                model_type=model_type,
                device="cpu",  # Use CPU for testing
                target_sample_rate=None,  # Let model determine
                max_duration=10.0,  # Limit to 10 seconds for testing
                output_format="car"
            )
            
            print(f"📋 Config: model_name={config.model_name}, model_type={config.model_type}")
            
            # Initialize processor
            processor = AudioProcessor(config)
            print(f"✅ {model_type.upper()} processor initialized successfully")
            
            # Test single file processing
            print(f"\n2️⃣ Processing single file...")
            output_file = output_dir / f"{input_file.stem}.car"
            
            result = processor.process_single_file(
                audio_path=str(input_file),
                output_path=str(output_file),
                base_metadata={},
                save_extras=[]
            )
            
            print(f"✅ Single file processing completed")
            print(f"📊 Result status: {result.get('status', 'unknown')}")
            
            if result.get('status') == 'success':
                if output_file.exists():
                    size_kb = output_file.stat().st_size / 1024
                    print(f"📦 Generated CAR file: {output_file.name} ({size_kb:.1f} KB)")
                    
                    # Test loading the generated file
                    print(f"\n3️⃣ Testing CAR file loading...")
                    try:
                        from carlib.loaders import load_single_car
                        data = load_single_car(str(output_file))
                        
                        print(f"✅ CAR file loaded successfully")
                        print(f"🔑 Top-level keys: {list(data.keys())}")
                        
                        if 'data' in data and 'codes' in data['data']:
                            codes = data['data']['codes']
                            if hasattr(codes, 'shape'):
                                print(f"📈 Audio codes shape: {codes.shape}")
                            else:
                                print(f"📈 Audio codes length: {len(codes)}")
                        
                        if 'metadata' in data:
                            metadata = data['metadata']
                            if 'model_name' in metadata:
                                print(f"🏷️  Model in metadata: {metadata['model_name']}")
                            if 'processed_sample_rate' in metadata:
                                print(f"🎵 Sample rate: {metadata['processed_sample_rate']} Hz")
                        
                        return True, "Success"
                        
                    except Exception as e:
                        print(f"❌ CAR file loading failed: {e}")
                        return False, f"Loading failed: {e}"
                        
                else:
                    print(f"❌ Output file not created: {output_file}")
                    return False, "Output file not created"
            else:
                error_msg = result.get('error', 'Unknown error')
                print(f"❌ Processing failed: {error_msg}")
                return False, f"Processing failed: {error_msg}"
                
        except Exception as e:
            print(f"❌ {model_type.upper()} model test failed: {e}")
            traceback.print_exc()
            return False, str(e)

def test_dataset_conversion(model_name, model_type, mp3_file_path):
    """Test dataset conversion with specific model"""
    print(f"\n🔄 Testing dataset conversion with {model_type.upper()}: {model_name}")
    print("=" * 60)
    
    # Create temporary directories
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        input_dir = temp_path / "dataset_input"
        output_dir = temp_path / "dataset_output"
        input_dir.mkdir()
        output_dir.mkdir()
        
        # Copy MP3 file to input directory
        input_file = input_dir / Path(mp3_file_path).name
        shutil.copy2(mp3_file_path, input_file)
        
        try:
            from carlib.dataset_to_car import convert_dataset_to_car
            
            print(f"📁 Input directory: {input_dir}")
            print(f"📁 Output directory: {output_dir}")
            print(f"🎵 Using model: {model_name}")
            
            # Run conversion
            convert_dataset_to_car(
                input_path=str(input_dir),
                output_path=str(output_dir),
                modality="vanilla",
                target_modality="audio",
                parallel=False,  # Sequential for debugging
                num_gpus=0,  # Force CPU
                recursive=False,
                max_files=1,
                config_file=None,  # Use default config
                model_config={
                    "model_name": model_name,
                    "model_type": model_type,
                    "device": "cpu",
                    "max_duration": 10.0
                }
            )
            
            print(f"✅ Dataset conversion completed")
            
            # Check results
            car_files = list(output_dir.glob("*.car"))
            if car_files:
                print(f"🎉 Created {len(car_files)} CAR files:")
                for car_file in car_files:
                    size_kb = car_file.stat().st_size / 1024
                    print(f"  📦 {car_file.name} ({size_kb:.1f} KB)")
                return True, f"Success - created {len(car_files)} files"
            else:
                print(f"❌ No CAR files created")
                return False, "No output files created"
                
        except Exception as e:
            print(f"❌ Dataset conversion failed: {e}")
            traceback.print_exc()
            return False, str(e)

def main():
    """Run comprehensive SNAC and DAC tests"""
    print("🧪 SNAC and DAC Audio Models Test Suite")
    print("=" * 70)
    
    # Find MP3 files in assets
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    
    mp3_files = list(assets_dir.glob("*.mp3"))
    if not mp3_files:
        print("❌ No MP3 files found in assets directory")
        return False
    
    test_mp3 = mp3_files[0]  # Use first MP3 file
    print(f"🎵 Test audio file: {test_mp3.name}")
    
    # Define models to test
    test_models = [
        # DAC Models
        ("dac_44khz", "dac"),
        ("dac_24khz", "dac"),
        ("dac_16khz", "dac"),
        
        # SNAC Models  
        ("snac_44khz", "snac"),
        ("snac_32khz", "snac"),
        ("snac_24khz", "snac"),
        
        # EnCodec models for comparison
        ("facebook/encodec_32khz", "encodec"),
        ("facebook/encodec_24khz", "encodec"),
    ]
    
    results = []
    
    # Test each model
    for model_name, model_type in test_models:
        print(f"\n{'='*70}")
        print(f"🎯 TESTING: {model_type.upper()} - {model_name}")
        print(f"{'='*70}")
        
        # Test 1: Direct processor test
        try:
            success1, msg1 = test_model_conversion(model_name, model_type, test_mp3)
            print(f"📊 Direct processor test: {'✅ PASS' if success1 else '❌ FAIL'} - {msg1}")
        except Exception as e:
            success1, msg1 = False, f"Exception: {e}"
            print(f"📊 Direct processor test: ❌ FAIL - {msg1}")
        
        # Test 2: Dataset conversion test
        try:
            success2, msg2 = test_dataset_conversion(model_name, model_type, test_mp3)
            print(f"📊 Dataset conversion test: {'✅ PASS' if success2 else '❌ FAIL'} - {msg2}")
        except Exception as e:
            success2, msg2 = False, f"Exception: {e}"
            print(f"📊 Dataset conversion test: ❌ FAIL - {msg2}")
        
        # Store results
        results.append({
            'model': f"{model_type}:{model_name}",
            'direct_test': success1,
            'dataset_test': success2,
            'direct_msg': msg1,
            'dataset_msg': msg2
        })
        
        print(f"🏁 {model_type.upper()} {model_name}: {'✅ BOTH PASS' if success1 and success2 else '⚠️ SOME FAIL' if success1 or success2 else '❌ BOTH FAIL'}")
    
    # Final summary
    print(f"\n{'='*70}")
    print(f"📋 FINAL TEST RESULTS")
    print(f"{'='*70}")
    
    total_tests = len(results)
    direct_passes = sum(1 for r in results if r['direct_test'])
    dataset_passes = sum(1 for r in results if r['dataset_test'])
    
    print(f"📊 Total models tested: {total_tests}")
    print(f"📊 Direct processor tests passed: {direct_passes}/{total_tests}")
    print(f"📊 Dataset conversion tests passed: {dataset_passes}/{total_tests}")
    
    print(f"\n🔍 Detailed Results:")
    for result in results:
        direct_status = "✅" if result['direct_test'] else "❌"
        dataset_status = "✅" if result['dataset_test'] else "❌"
        print(f"  {result['model']:<25} | Direct: {direct_status} | Dataset: {dataset_status}")
        
        if not result['direct_test']:
            print(f"    └─ Direct error: {result['direct_msg']}")
        if not result['dataset_test']:
            print(f"    └─ Dataset error: {result['dataset_msg']}")
    
    # Determine overall success
    all_passed = all(r['direct_test'] and r['dataset_test'] for r in results)
    some_passed = any(r['direct_test'] or r['dataset_test'] for r in results)
    
    if all_passed:
        print(f"\n🎉 ALL TESTS PASSED! All audio models are working correctly.")
        return True
    elif some_passed:
        print(f"\n⚠️ PARTIAL SUCCESS: Some models working, others need debugging.")
        return True  # Still return True as partial success
    else:
        print(f"\n❌ ALL TESTS FAILED: Audio models need debugging.")
        return False

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print(f"\n⏹️ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Unexpected error: {e}")
        traceback.print_exc()
        sys.exit(1)