from typing import Any, Literal

# Enum type aliases for validation
VALID_BODY_OVERSIZE_LOG: Literal[{"description": "Disable logging for antivirus oversize file blocking", "help": "Disable logging for antivirus oversize file blocking.", "label": "Disable", "name": "disable"}, {"description": "Enable logging for antivirus oversize file blocking", "help": "Enable logging for antivirus oversize file blocking.", "label": "Enable", "name": "enable"}]
VALID_BODY_SWITCHING_PROTOCOLS_LOG: Literal[{"description": "Disable logging for HTTP/HTTPS switching protocols", "help": "Disable logging for HTTP/HTTPS switching protocols.", "label": "Disable", "name": "disable"}, {"description": "Enable logging for HTTP/HTTPS switching protocols", "help": "Enable logging for HTTP/HTTPS switching protocols.", "label": "Enable", "name": "enable"}]
VALID_BODY_RPC_OVER_HTTP: Literal[{"description": "Enable inspection of RPC over HTTP", "help": "Enable inspection of RPC over HTTP.", "label": "Enable", "name": "enable"}, {"description": "Disable inspection of RPC over HTTP", "help": "Disable inspection of RPC over HTTP.", "label": "Disable", "name": "disable"}]

# Metadata dictionaries
FIELD_TYPES: dict[str, str]
FIELD_DESCRIPTIONS: dict[str, str]
FIELD_CONSTRAINTS: dict[str, dict[str, Any]]
NESTED_SCHEMAS: dict[str, dict[str, Any]]
FIELDS_WITH_DEFAULTS: dict[str, Any]

# Helper functions
def get_field_type(field_name: str) -> str | None: ...
def get_field_description(field_name: str) -> str | None: ...
def get_field_default(field_name: str) -> Any: ...
def get_field_constraints(field_name: str) -> dict[str, Any]: ...
def get_nested_schema(field_name: str) -> dict[str, Any] | None: ...
def get_field_metadata(field_name: str) -> dict[str, Any]: ...
def validate_field_value(field_name: str, value: Any) -> bool: ...
def get_all_fields() -> list[str]: ...
def get_required_fields() -> list[str]: ...
def get_schema_info() -> dict[str, Any]: ...


__all__ = [
    "VALID_BODY_OVERSIZE_LOG",
    "VALID_BODY_SWITCHING_PROTOCOLS_LOG",
    "VALID_BODY_RPC_OVER_HTTP",
    "FIELD_TYPES",
    "FIELD_DESCRIPTIONS",
    "FIELD_CONSTRAINTS",
    "NESTED_SCHEMAS",
    "FIELDS_WITH_DEFAULTS",
    "get_field_type",
    "get_field_description",
    "get_field_default",
    "get_field_constraints",
    "get_nested_schema",
    "get_field_metadata",
    "validate_field_value",
    "get_all_fields",
    "get_required_fields",
    "get_schema_info",
]