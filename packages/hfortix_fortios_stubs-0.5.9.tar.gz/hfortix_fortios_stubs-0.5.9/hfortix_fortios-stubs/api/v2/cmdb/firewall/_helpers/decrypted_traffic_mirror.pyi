from typing import Any, Literal

# Enum type aliases for validation
VALID_BODY_TRAFFIC_TYPE: Literal[{"description": "Mirror decrypted SSL traffic", "help": "Mirror decrypted SSL traffic.", "label": "Ssl", "name": "ssl"}, {"description": "Mirror decrypted SSH traffic", "help": "Mirror decrypted SSH traffic.", "label": "Ssh", "name": "ssh"}]
VALID_BODY_TRAFFIC_SOURCE: Literal[{"description": "Mirror client side decrypted traffic", "help": "Mirror client side decrypted traffic.", "label": "Client", "name": "client"}, {"description": "Mirror server side decrypted traffic", "help": "Mirror server side decrypted traffic.", "label": "Server", "name": "server"}, {"description": "Mirror both client and server side decrypted traffic", "help": "Mirror both client and server side decrypted traffic.", "label": "Both", "name": "both"}]

# Metadata dictionaries
FIELD_TYPES: dict[str, str]
FIELD_DESCRIPTIONS: dict[str, str]
FIELD_CONSTRAINTS: dict[str, dict[str, Any]]
NESTED_SCHEMAS: dict[str, dict[str, Any]]
FIELDS_WITH_DEFAULTS: dict[str, Any]

# Helper functions
def get_field_type(field_name: str) -> str | None: ...
def get_field_description(field_name: str) -> str | None: ...
def get_field_default(field_name: str) -> Any: ...
def get_field_constraints(field_name: str) -> dict[str, Any]: ...
def get_nested_schema(field_name: str) -> dict[str, Any] | None: ...
def get_field_metadata(field_name: str) -> dict[str, Any]: ...
def validate_field_value(field_name: str, value: Any) -> bool: ...
def get_all_fields() -> list[str]: ...
def get_required_fields() -> list[str]: ...
def get_schema_info() -> dict[str, Any]: ...


__all__ = [
    "VALID_BODY_TRAFFIC_TYPE",
    "VALID_BODY_TRAFFIC_SOURCE",
    "FIELD_TYPES",
    "FIELD_DESCRIPTIONS",
    "FIELD_CONSTRAINTS",
    "NESTED_SCHEMAS",
    "FIELDS_WITH_DEFAULTS",
    "get_field_type",
    "get_field_description",
    "get_field_default",
    "get_field_constraints",
    "get_nested_schema",
    "get_field_metadata",
    "validate_field_value",
    "get_all_fields",
    "get_required_fields",
    "get_schema_info",
]