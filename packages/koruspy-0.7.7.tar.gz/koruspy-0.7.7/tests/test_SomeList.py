import pytest
from koruspy import Some, nothing, SomeList

class TestSomeListInit:
    """Testa todas as formas de criar SomeList"""
    
    def test_from_nothing(self):
        # Como o seu __init__ converte nothing/None em [], o valor interno será []
        assert SomeList(nothing).value == []
        assert len(SomeList(nothing)) == 0
    
    def test_from_none(self):
        assert SomeList(None).value == []
    
    def test_from_list(self):
        assert SomeList([1, 2, 3]).value == [1, 2, 3]
    
    def test_from_tuple(self):
        # Seu novo __init__ usa hasattr(__iter__) e transforma em list()
        assert SomeList((1, 2, 3)).value == [1, 2, 3]
    
    def test_from_some(self):
        # Testa o desempacotamento de Some no __init__
        assert SomeList(Some(5)).value == [5]
        assert SomeList(Some([1, 2])).value == [1, 2]
    
    def test_from_somelist(self):
        original = SomeList([1, 2, 3])
        copy = SomeList(original)
        assert copy.value == [1, 2, 3]
        # Testa se usou .copy() como no código do Claude
        copy.append(4)
        assert original.value == [1, 2, 3]
        assert copy.value == [1, 2, 3, 4]

class TestSomeListMutableSequence:
    def test_insert(self):
        lst = SomeList([1, 3])
        # Verificando se o insert retorna self para permitir encadeamento
        result = lst.insert(1, 2)
        assert lst.value == [1, 2, 3]
        assert isinstance(result, SomeList) 

class TestSomeListFunctional:
    def test_map_exception(self):
        # O map agora tem try/except, deve retornar nothing em caso de erro
        result = SomeList([1, "a", 3]).map(lambda x: x / 0)
        assert result is nothing
    
    def test_filter_nothing(self):
        # Testa se remove tanto None quanto o seu objeto nothing
        result = SomeList([1, nothing, 2, None, 3]).filter_nothing()
        assert result.value == [1, 2, 3]

    def test_head(self):
        res = SomeList([10, 20]).head()
        assert res.value == 10  # Acessando .value do Some retornado
        assert SomeList([]).head() is nothing

class TestSomeListEdgeCases:
    def test_pop_empty(self):
        # Sua nova versão do pop verifica if not self.value
        assert SomeList([]).pop() is nothing

    def test_sum_mixed_types(self):
        # Garante que o sum ignore o que não for int ou float
        lst = SomeList([10, "ignorante", Some(20), None])
        assert lst.sum() == 30

class TestSomeListCompatibility:
    def test_some_to_list(self):
        result = Some(5).to_list()
        assert isinstance(result, SomeList)
        assert result.value == [5]
    
    def test_nothing_to_list(self):
        # No seu arquivo _NoneOption.to_list() retornava 'nothing'
        result = nothing.to_list()
        assert result is nothing
