from .Option import Some, nothing, option_of, _NoneOption, SomeList
from .Result import Err, Okay
from .Async_option import AsyncOption, async_option
from .printlnUtils.cythonprintln import println
from .errors import ResultUnwrapError, OptionUnwrapError, KoruspyError 

__all__ = ["Some", "nothing", "SomeList", "println", "Okay", "Err", "option_of", "AsyncOption", "async_option", "ResultUnwrapError", "KoruspyError", "OptionUnwrapError"]


import os
import sys
import subprocess
from setuptools import setup, Extension
from Cython.Build import cythonize

def setup_native():
    try:
        import Cython
    except ImportError:
        print("❌ Cython not found. Install it: pip install cython")
        return
    print("🚀 Compiling koruspy native engine (Cython)...")
    
    # 1. Localiza a pasta da biblioteca
    base_path = os.path.dirname(__file__)
    # Caminho do arquivo .pyx (dentro de printlnUtils)
    pyx_path = os.path.join(base_path, "printlnUtils", "cythonprintln.pyx")
    
    if not os.path.exists(pyx_path):
        print(f"❌ Error: {pyx_path} not found.")
        return

    # 2. Executa a compilação
    try:
        # Usamos o sys.executable para garantir que usa o mesmo Python do SmartIDE
        args = [sys.executable, "-c", 
                f"from setuptools import setup; from Cython.Build import cythonize; "
                f"setup(ext_modules=cythonize('{pyx_path}'))", 
                "build_ext", "--inplace"]
        
        # Roda o comando na raiz da lib para o .so cair no lugar certo
        subprocess.run(args, cwd=base_path, check=True)
        
        print("✅ Success! println is now running at C speed (0.006s).")
    except Exception as e:
        print(f"❌ Compilation failed: {e}")
        
