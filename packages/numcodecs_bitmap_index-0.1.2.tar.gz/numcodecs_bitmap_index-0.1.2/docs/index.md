[![image](https://img.shields.io/github/actions/workflow/status/juntyr/numcodecs-bitmap-index/ci.yml?branch=main)](https://github.com/juntyr/numcodecs-bitmap-index/actions/workflows/ci.yml?query=branch%3Amain)
[![image](https://img.shields.io/pypi/v/numcodecs-bitmap-index.svg)](https://pypi.python.org/pypi/numcodecs-bitmap-index)
[![image](https://img.shields.io/pypi/l/numcodecs-bitmap-index.svg)](https://github.com/juntyr/numcodecs-bitmap-index/blob/main/LICENSE)
[![image](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fraw.githubusercontent.com%2Fjuntyr%2Fnumcodecs-bitmap-index%2Frefs%2Fheads%2Fmain%2Fpyproject.toml)](https://pypi.python.org/pypi/numcodecs-bitmap-index)
[![image](https://readthedocs.org/projects/numcodecs-bitmap-index/badge/?version=latest)](https://numcodecs-bitmap-index.readthedocs.io/en/latest/?badge=latest)

# numcodecs-bitmap-index

[`BitmapIndexCodec`][numcodecs_bitmap_index.BitmapIndexCodec] for the [`numcodecs`][numcodecs] buffer compression API.

## Funding

The `numcodecs-bitmap-index` package has been developed as part of [ESiWACE3](https://www.esiwace.eu), the third phase of the Centre of Excellence in Simulation of Weather and Climate in Europe.

Funded by the European Union. This work has received funding from the European High Performance Computing Joint Undertaking (JU) under grant agreement No 101093054.
