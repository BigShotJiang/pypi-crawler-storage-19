"""Footer widget for displaying shortcuts and status."""

from __future__ import annotations

from rich.console import RenderableType
from rich.table import Table
from rich.text import Text
from textual.widgets import Static

from exobrain.cli.tui.widgets.status_bar import AgentState


class Footer(Static):
    """Footer widget showing shortcuts and agent status.

    Displays:
    - Agent status (left)
    - Keyboard shortcuts (right)
    """

    DEFAULT_CSS = """
    Footer {
        dock: bottom;
        height: 1;
        background: $primary-darken-2;
        color: $text;
        padding: 0 1;
    }
    """

    # Status icons and colors
    STATE_DISPLAY = {
        AgentState.IDLE: ("Ready", "green"),
        AgentState.THINKING: ("Thinking...", "yellow"),
        AgentState.TOOL_CALLING: ("Using tool...", "blue"),
        AgentState.WAITING: ("Waiting...", "cyan"),
        AgentState.STREAMING: ("Streaming...", "green"),
        AgentState.ERROR: ("Error", "red"),
        AgentState.FINISHED: ("Done", "green"),
    }

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._state = AgentState.IDLE
        self._tool_name: str | None = None

    def render(self) -> RenderableType:
        """Render the footer content."""
        table = Table.grid(expand=True)
        table.add_column("status", justify="left", ratio=1)
        table.add_column("shortcuts", justify="right", ratio=2)

        # Left: Status
        status_text, status_color = self.STATE_DISPLAY.get(self._state, ("Unknown", "white"))
        left = Text()
        left.append("  ", style=f"bold {status_color}")
        left.append(status_text, style=status_color)
        if self._state == AgentState.TOOL_CALLING and self._tool_name:
            left.append(f" ({self._tool_name})", style="dim")

        # Right: Shortcuts
        right = Text()
        shortcuts = [
            ("Ctrl+Enter", "Send"),
            ("Ctrl+L", "Clear"),
            ("Ctrl+D", "Exit"),
            ("Ctrl+C", "Cancel"),
        ]
        for i, (key, action) in enumerate(shortcuts):
            if i > 0:
                right.append("  ", style="dim")
            right.append(key, style="bold cyan")
            right.append(f" {action}", style="dim")

        table.add_row(left, right)
        return table

    def set_state(self, state: AgentState, tool_name: str | None = None) -> None:
        """Update the agent state.

        Args:
            state: New agent state
            tool_name: Tool name if state is TOOL_CALLING
        """
        self._state = state
        self._tool_name = tool_name
        self.refresh()

    def set_idle(self) -> None:
        """Set status to idle."""
        self.set_state(AgentState.IDLE)

    def set_thinking(self) -> None:
        """Set status to thinking."""
        self.set_state(AgentState.THINKING)

    def set_streaming(self) -> None:
        """Set status to streaming."""
        self.set_state(AgentState.STREAMING)

    def set_tool_calling(self, tool_name: str) -> None:
        """Set status to tool calling."""
        self.set_state(AgentState.TOOL_CALLING, tool_name)

    def set_finished(self) -> None:
        """Set status to finished."""
        self.set_state(AgentState.FINISHED)

    def set_error(self) -> None:
        """Set status to error."""
        self.set_state(AgentState.ERROR)
