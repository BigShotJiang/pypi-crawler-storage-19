"""Interactive configuration wizard for ExoBrain."""

import sys
from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt

from exobrain.config import get_user_config_path

console = Console()


def run_config_wizard() -> dict:
    """Run interactive configuration wizard.

    Returns:
        Configuration dictionary
    """
    console.print(
        Panel.fit(
            "[bold cyan]ExoBrain Configuration Wizard[/bold cyan]\n\n"
            "Welcome! Let's set up your AI assistant.\n"
            "I'll ask you a few questions to get started.",
            border_style="cyan",
        )
    )

    config = {}

    # 1. Model provider selection
    console.print("\n[bold]Step 1: Model Provider[/bold]")
    console.print("Which AI model provider would you like to use?")
    console.print("  [cyan]1[/cyan]) OpenAI (GPT-4, GPT-4o, etc.)")
    console.print("  [cyan]2[/cyan]) Google Gemini")
    console.print("  [cyan]3[/cyan]) Local models (Ollama, LM Studio)")
    console.print("  [cyan]4[/cyan]) Multiple providers")

    provider_choice = Prompt.ask("\nYour choice", choices=["1", "2", "3", "4"], default="1")

    provider_map = {
        "1": "openai",
        "2": "gemini",
        "3": "local",
        "4": "multiple",
    }
    primary_provider = provider_map[provider_choice]

    # Initialize models config
    config["models"] = {"providers": {}}

    # 2. Configure selected provider(s)
    if primary_provider == "openai" or primary_provider == "multiple":
        console.print("\n[bold]Step 2: OpenAI Configuration[/bold]")

        api_key = Prompt.ask("OpenAI API Key (sk-...)", password=True)

        base_url = Prompt.ask("OpenAI Base URL", default="https://api.openai.com/v1")

        config["models"]["providers"]["openai"] = {
            "api_key": api_key,
            "base_url": base_url,
        }

        if primary_provider == "openai":
            config["models"]["default"] = "openai/gpt-4o"

    if primary_provider == "gemini" or primary_provider == "multiple":
        console.print("\n[bold]Step 2: Google Gemini Configuration[/bold]")

        api_key = Prompt.ask("Gemini API Key", password=True)

        config["models"]["providers"]["gemini"] = {"api_key": api_key}

        if primary_provider == "gemini":
            config["models"]["default"] = "gemini/gemini-pro"

    if primary_provider == "local" or primary_provider == "multiple":
        console.print("\n[bold]Step 2: Local Models Configuration[/bold]")
        console.print("[dim]Make sure Ollama or LM Studio is running[/dim]")

        base_url = Prompt.ask("Local model server URL", default="http://localhost:11434")

        model_name = Prompt.ask("Model name", default="llama2")

        config["models"]["providers"]["local"] = {"base_url": base_url}

        if primary_provider == "local":
            config["models"]["default"] = f"local/{model_name}"

    # If multiple, ask for default
    if primary_provider == "multiple":
        console.print("\n[bold]Which provider should be the default?[/bold]")
        providers_configured = list(config["models"]["providers"].keys())
        for i, p in enumerate(providers_configured, 1):
            console.print(f"  [cyan]{i}[/cyan]) {p}")

        default_choice = Prompt.ask(
            "\nDefault provider",
            choices=[str(i) for i in range(1, len(providers_configured) + 1)],
            default="1",
        )

        default_provider = providers_configured[int(default_choice) - 1]

        if default_provider == "openai":
            config["models"]["default"] = "openai/gpt-4o"
        elif default_provider == "gemini":
            config["models"]["default"] = "gemini/gemini-pro"
        elif default_provider == "local":
            config["models"]["default"] = "local/llama2"

    # 3. Agent settings
    console.print("\n[bold]Step 3: Agent Settings[/bold]")

    configure_advanced = Confirm.ask("Configure advanced agent settings?", default=False)

    config["agent"] = {
        "system_prompt": "You are a helpful AI assistant.",
        "max_conversation_turns": 20,
        "stream": True,
    }

    if configure_advanced:
        temperature = Prompt.ask(
            "Temperature (0.0-1.0, lower is more deterministic)", default="0.7"
        )
        config["agent"]["temperature"] = float(temperature)

        stream = Confirm.ask("Enable streaming responses?", default=True)
        config["agent"]["stream"] = stream

    # 4. Features
    console.print("\n[bold]Step 4: Features[/bold]")

    enable_skills = Confirm.ask("Enable Skills?", default=True)

    enable_shell = Confirm.ask("Enable shell command execution (with permissions)?", default=True)

    config["tools"] = {
        "file_system": True,
        "web_access": True,
        "shell_execution": enable_shell,
        "time_management": True,
    }

    config["skills"] = {"enabled": enable_skills}

    config["permissions"] = {}
    config["mcp"] = {"servers": []}
    config["memory"] = {}
    config["cli"] = {}
    config["logging"] = {}
    config["performance"] = {}

    return config


@click.command(name="init")
def init_config():
    """Initialize ExoBrain configuration with interactive wizard."""
    config_path = get_user_config_path()

    # Check if config already exists
    if config_path.exists():
        overwrite = Confirm.ask(
            f"\n[yellow]Configuration file already exists at:[/yellow]\n{config_path}\n\n"
            "Do you want to overwrite it?",
            default=False,
        )

        if not overwrite:
            console.print("\n[yellow]Configuration unchanged[/yellow]")
            console.print(
                f"[dim]Use 'exobrain config edit' to modify existing configuration[/dim]\n"
            )
            sys.exit(0)

    # Run wizard
    config = run_config_wizard()

    # Ensure directory exists
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Save configuration
    with open(config_path, "w", encoding="utf-8") as f:
        yaml.dump(
            config,
            f,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )

    console.print(
        Panel.fit(
            f"[green]✓ Configuration created successfully![/green]\n\n"
            f"Location: [cyan]{config_path}[/cyan]\n\n"
            f"You can now start using ExoBrain:\n"
            f"  [bold]exobrain chat[/bold]\n\n"
            f"To modify your configuration:\n"
            f"  [bold]exobrain config edit[/bold]\n"
            f"  [bold]exobrain config set <key> <value>[/bold]",
            title="[bold green]Setup Complete[/bold green]",
            border_style="green",
        )
    )
