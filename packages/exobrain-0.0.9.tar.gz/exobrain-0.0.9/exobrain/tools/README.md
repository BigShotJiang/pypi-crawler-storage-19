# ExoBrain Tools 设计文档

本文档说明 ExoBrain 工具系统的设计标准，帮助开发者扩展和添加新工具。

## 核心架构

### 1. 基础类

**`base.py`** 提供了工具系统的核心组件：

- **`ToolParameter`** - 工具参数定义
- **`Tool`** - 所有工具的基类（Pydantic BaseModel）
- **`ToolRegistry`** - 工具注册和管理

### 2. 工具分类

```
tools/
├── base.py              # 基础类和工具注册表
├── file_tools.py        # 文件系统操作
├── shell_tools.py       # Shell 命令执行
├── time_tools.py        # 时间相关工具
├── web_tools.py         # 网络搜索和抓取
└── README.md            # 本文档
```

## 创建新工具的标准流程

### 步骤 1: 定义工具类

继承 `Tool` 基类并遵循以下模式：

```python
from exobrain.tools.base import Tool, ToolParameter
from typing import Any


class MyNewTool(Tool):
    """工具的简短描述（用于 Agent 理解）。"""

    def __init__(self, config_param1: str, config_param2: int) -> None:
        # 1. 先调用 super().__init__()（Pydantic 要求）
        super().__init__(
            name="my_new_tool",  # 工具唯一标识符（snake_case）
            description="详细描述工具的功能和使用场景",  # Agent 会读取这个
            parameters={
                "param1": ToolParameter(
                    type="string",  # string, integer, boolean, array, object
                    description="参数1的描述",
                    required=True,
                ),
                "param2": ToolParameter(
                    type="integer",
                    description="参数2的描述",
                    required=False,
                ),
            },
            requires_permission=True,  # 是否需要权限检查
            permission_scope="my_scope",  # 权限范围标识
        )

        # 2. 然后设置私有属性（必须在 super().__init__() 之后）
        self._config_param1 = config_param1
        self._config_param2 = config_param2

    async def execute(self, **kwargs: Any) -> str:
        """执行工具逻辑。

        Args:
            **kwargs: 从 Agent 传入的参数（对应 parameters 定义）

        Returns:
            str: 工具执行结果（返回给 Agent）
        """
        # 3. 从 kwargs 提取参数
        param1 = kwargs.get("param1", "")
        param2 = kwargs.get("param2", 0)

        # 4. 参数验证
        if not param1:
            return "Error: param1 is required"

        # 5. 执行工具逻辑
        try:
            result = await self._do_work(param1, param2)
            return result
        except Exception as e:
            return f"Error: {e}"

    async def _do_work(self, param1: str, param2: int) -> str:
        """私有方法：实际的工作逻辑。"""
        # 实现具体逻辑
        pass
```

### 步骤 2: 实现权限检查（可选）

如果工具需要权限控制：

```python
class SecureFileTool(Tool):
    def __init__(self, allowed_paths: list[str], denied_paths: list[str]) -> None:
        super().__init__(
            name="secure_file_tool",
            description="A file tool with permission checks",
            parameters={...},
            requires_permission=True,
            permission_scope="file_system",
        )

        # 将路径解析为绝对路径
        self._allowed_paths = [Path(p).expanduser().resolve() for p in allowed_paths]
        self._denied_paths = [Path(p).expanduser().resolve() for p in denied_paths]

    def _check_permission(self, path: Path) -> tuple[bool, str]:
        """检查路径权限。

        Returns:
            tuple[bool, str]: (是否允许, 错误消息)
        """
        path = path.expanduser().resolve()

        # 先检查黑名单（优先级更高）
        for denied in self._denied_paths:
            try:
                path.relative_to(denied)
                return False, f"Access denied: path is in blocked directory {denied}"
            except ValueError:
                continue

        # 再检查白名单
        for allowed in self._allowed_paths:
            try:
                path.relative_to(allowed)
                return True, ""
            except ValueError:
                continue

        return False, f"Access denied: path not in allowed list"

    async def execute(self, **kwargs: Any) -> str:
        path_str = kwargs.get("path", "")
        path = Path(path_str)

        # 权限检查
        allowed, message = self._check_permission(path)
        if not allowed:
            return message

        # 继续执行...
```

### 步骤 3: 注册到 CLI

在 `cli/__init__.py` 中注册工具：

```python
from exobrain.tools.my_new_tool import MyNewTool

def create_agent_from_config(config: Config, ...) -> tuple[Agent, Any]:
    # ...
    tool_registry = ToolRegistry()

    # 注册新工具
    if config.tools.my_feature:  # 检查配置是否启用
        # 从配置获取参数
        my_config = config.permissions.my_scope
        param1 = my_config.get("param1", "default")
        param2 = my_config.get("param2", 42)

        # 注册工具实例
        tool_registry.register(MyNewTool(param1, param2))
```

### 步骤 4: 添加配置

在 `config.py` 中添加配置支持：

```python
class ToolsConfig(BaseModel):
    # ...
    my_feature: bool = False  # 新工具的开关

class PermissionsConfig(BaseModel):
    # ...
    my_scope: dict[str, Any] = Field(default_factory=dict)  # 新工具的权限配置
```

在 `config.yaml` 和 `config.example.yaml` 中添加配置示例：

```yaml
tools:
  my_feature: true

permissions:
  my_scope:
    enabled: true
    param1: "value"
    param2: 42
```

## 设计原则

### ✅ 必须遵守

1. **先调用 `super().__init__()`，再设置私有属性**

   ```python
   # ✅ 正确
   super().__init__(name="tool", ...)
   self._config = config

   # ❌ 错误 - Pydantic 会报错
   self._config = config
   super().__init__(name="tool", ...)
   ```

2. **`execute()` 必须使用 `**kwargs`\*\*

   ```python
   # ✅ 正确
   async def execute(self, **kwargs: Any) -> str:
       param = kwargs.get("param", "")

   # ❌ 错误 - Agent 调用会失败
   async def execute(self, param: str) -> str:
       ...
   ```

3. **始终返回字符串**

   ```python
   # ✅ 正确
   return "Success: file created"
   return json.dumps({"status": "ok", "data": result})

   # ❌ 错误 - 返回类型不一致
   return True
   return {"status": "ok"}
   ```

4. **错误处理要清晰**

   ```python
   # ✅ 正确 - 返回错误消息
   if not valid:
       return "Error: invalid parameter"

   try:
       result = risky_operation()
   except Exception as e:
       return f"Error: {e}"

   # ❌ 错误 - 抛出异常会中断 Agent
   raise ValueError("Invalid parameter")
   ```

5. **描述要详细且面向 Agent**

   ```python
   # ✅ 正确 - Agent 能理解何时使用
   description="Search the web for information. Use this when you need current data or answers requiring up-to-date knowledge."

   # ❌ 错误 - 太简短，Agent 可能误用
   description="Search"
   ```

### 🎯 最佳实践

1. **命名规范**

   - 工具名: `snake_case`（如 `web_search`, `list_directory`）
   - 类名: `PascalCase` + `Tool` 后缀（如 `WebSearchTool`）
   - 文件名: `snake_case` + `_tools.py`（如 `web_tools.py`）

2. **权限优先级**

   - 黑名单（denied）> 白名单（allowed）
   - 先检查黑名单，再检查白名单

3. **输出格式化**

   ```python
   # 用户友好的输出
   result = [
       f"Command: {command}",
       f"Working directory: {work_dir}",
       f"Exit code: {exit_code}",
       "",
       "--- Output ---",
       output,
   ]
   return "\n".join(result)
   ```

4. **异步优先**

   - 所有 I/O 操作使用 `async/await`
   - 使用 `aiofiles`, `httpx.AsyncClient` 等异步库

5. **日志记录**

   ```python
   import logging
   logger = logging.getLogger(__name__)

   async def execute(self, **kwargs: Any) -> str:
       logger.info(f"Executing tool with params: {kwargs}")
       try:
           result = await self._do_work()
           logger.debug(f"Tool result: {result[:100]}")
           return result
       except Exception as e:
           logger.error(f"Tool error: {e}")
           return f"Error: {e}"
   ```

## 工具类型示例

### 1. 简单工具（无权限检查）

```python
class GetCurrentTimeTool(Tool):
    """获取当前时间 - 不需要权限。"""

    def __init__(self) -> None:
        super().__init__(
            name="get_current_time",
            description="Get the current date and time",
            parameters={},  # 无参数
            requires_permission=False,
        )

    async def execute(self, **kwargs: Any) -> str:
        from datetime import datetime
        now = datetime.now()
        return f"Current time: {now.strftime('%Y-%m-%d %H:%M:%S')}"
```

### 2. 带权限检查的工具

参考 `file_tools.py` 中的实现。

### 3. 带配置参数的工具

```python
class WebSearchTool(Tool):
    """网络搜索工具 - 需要配置最大结果数。"""

    def __init__(self, max_results: int = 5) -> None:
        super().__init__(
            name="web_search",
            description="Search the web for information",
            parameters={
                "query": ToolParameter(
                    type="string",
                    description="The search query",
                    required=True,
                ),
            },
            requires_permission=True,
        )
        self._max_results = max_results

    async def execute(self, **kwargs: Any) -> str:
        query = kwargs.get("query", "")
        results = await self._search(query, self._max_results)
        return self._format_results(results)
```

## OpenAI Function Calling 格式

工具会自动转换为 OpenAI function calling 格式：

```python
{
    "type": "function",
    "function": {
        "name": "web_search",
        "description": "Search the web for information...",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query"
                }
            },
            "required": ["query"]
        }
    }
}
```

转换由 `Tool.to_openai_format()` 方法自动处理，无需手动实现。

## 测试建议

```python
# test_my_tool.py
import asyncio
from exobrain.tools.my_tool import MyNewTool


async def test_basic_functionality():
    tool = MyNewTool(param1="test", param2=42)

    # 测试正常情况
    result = await tool.execute(param1="value")
    assert "expected" in result

    # 测试错误处理
    result = await tool.execute(param1="")
    assert "Error" in result

    print("✓ All tests passed")


if __name__ == "__main__":
    asyncio.run(test_basic_functionality())
```

## 常见问题

### Q: 为什么必须先调用 `super().__init__()`？

**A:** `Tool` 继承自 Pydantic `BaseModel`，Pydantic 需要先初始化模型才能设置属性。如果先设置属性会报 `AttributeError`。

### Q: 可以在 `execute()` 中抛出异常吗？

**A:** 不推荐。应该捕获异常并返回错误消息字符串，这样 Agent 可以看到错误并尝试其他方法。

### Q: 如何处理需要流式输出的工具？

**A:** 当前版本返回字符串。未来可以考虑支持 `AsyncIterator[str]` 用于流式输出。

### Q: 权限检查失败时如何处理？

**A:** 在 `execute()` 中调用 `_check_permission()`，如果返回 `False`，直接返回错误消息：

```python
allowed, message = self._check_permission(path)
if not allowed:
    return message  # 返回错误，不抛出异常
```

## 参考实现

查看现有工具的实现以获得灵感：

- **简单工具**: `time_tools.py` - `GetCurrentTimeTool`
- **权限控制**: `file_tools.py` - `ReadFileTool`, `ListDirectoryTool`
- **复杂权限**: `shell_tools.py` - `ShellExecuteTool`
- **网络请求**: `web_tools.py` - `WebSearchTool`, `WebFetchTool`

---

**记住：工具的设计目标是让 Agent 能够轻松理解和正确使用，而不是展示复杂的编程技巧。简单、清晰、可靠。**
