"""File system tools."""

import os
from pathlib import Path
from typing import Any

import aiofiles

from exobrain.tools.base import Tool, ToolParameter


class ReadFileTool(Tool):
    """Tool to read file contents."""

    def __init__(self, allowed_paths: list[str], denied_paths: list[str]) -> None:
        super().__init__(
            name="read_file",
            description="Read the contents of a file",
            parameters={
                "path": ToolParameter(
                    type="string",
                    description="Path to the file to read",
                    required=True,
                )
            },
            requires_permission=True,
            permission_scope="file_system",
        )

        self._allowed_paths = [Path(p).expanduser() for p in allowed_paths]
        self._denied_paths = [Path(p).expanduser() for p in denied_paths]

    def _check_permission(self, path: Path) -> tuple[bool, str]:
        """Check if access to path is allowed."""
        path = path.expanduser().resolve()

        # Check denied paths first
        for denied in self._denied_paths:
            try:
                path.relative_to(denied)
                return (
                    False,
                    f"Access denied: path is in blocked directory {denied}",
                )
            except ValueError:
                continue

        # Check allowed paths
        for allowed in self._allowed_paths:
            try:
                path.relative_to(allowed)
                return True, ""
            except ValueError:
                continue

        return False, f"Access denied: path is not in any allowed directory"

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool."""
        path_str = kwargs.get("path", "")
        if not path_str:
            return "Error: path parameter is required"

        path = Path(path_str)

        # Check permissions
        allowed, message = self._check_permission(path)
        if not allowed:
            return message

        # Check if file exists
        if not path.exists():
            return f"Error: file not found: {path}"

        if not path.is_file():
            return f"Error: path is not a file: {path}"

        # Read file
        try:
            async with aiofiles.open(path, "r", encoding="utf-8") as f:
                content = await f.read()
            return content
        except Exception as e:
            return f"Error reading file: {e}"


class WriteFileTool(Tool):
    """Tool to write contents to a file."""

    def __init__(
        self,
        allowed_paths: list[str],
        denied_paths: list[str],
        max_file_size: int,
        allow_edit: bool = False,
    ) -> None:
        super().__init__(
            name="write_file",
            description="Write content to a file",
            parameters={
                "path": ToolParameter(
                    type="string",
                    description="Path to the file to write",
                    required=True,
                ),
                "content": ToolParameter(
                    type="string",
                    description="Content to write to the file",
                    required=True,
                ),
            },
            requires_permission=True,
            permission_scope="file_system",
        )

        self._allowed_paths = [Path(p).expanduser() for p in allowed_paths]
        self._denied_paths = [Path(p).expanduser() for p in denied_paths]
        self._max_file_size = max_file_size
        self._allow_edit = allow_edit

    def _check_permission(self, path: Path) -> tuple[bool, str]:
        """Check if access to path is allowed."""
        path = path.expanduser().resolve()

        # Check denied paths first
        for denied in self._denied_paths:
            try:
                path.relative_to(denied)
                return (
                    False,
                    f"Access denied: path is in blocked directory {denied}",
                )
            except ValueError:
                continue

        # Check allowed paths
        for allowed in self._allowed_paths:
            try:
                path.relative_to(allowed)
                return True, ""
            except ValueError:
                continue

        return False, f"Access denied: path is not in any allowed directory"

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool."""
        path_str = kwargs.get("path", "")
        content = kwargs.get("content", "")

        if not path_str:
            return "Error: path parameter is required"

        path = Path(path_str)

        # Check permissions
        allowed, message = self._check_permission(path)
        if not allowed:
            return message

        if not self._allow_edit:
            return "Access denied: editing not allowed for this session (requires edit permission)"

        # Check content size
        if len(content.encode("utf-8")) > self._max_file_size:
            return f"Error: content size exceeds maximum of {self._max_file_size} bytes"

        # Create parent directories if needed
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return f"Error creating parent directories: {e}"

        # Write file
        try:
            async with aiofiles.open(path, "w", encoding="utf-8") as f:
                await f.write(content)
            return f"Successfully wrote {len(content)} characters to {path}"
        except Exception as e:
            return f"Error writing file: {e}"


class ListDirectoryTool(Tool):
    """Tool to list directory contents."""

    def __init__(self, allowed_paths: list[str], denied_paths: list[str]) -> None:
        super().__init__(
            name="list_directory",
            description="List the contents of a directory",
            parameters={
                "path": ToolParameter(
                    type="string",
                    description="Path to the directory to list",
                    required=True,
                )
            },
            requires_permission=True,
            permission_scope="file_system",
        )

        self._allowed_paths = [Path(p).expanduser() for p in allowed_paths]
        self._denied_paths = [Path(p).expanduser() for p in denied_paths]

    def _check_permission(self, path: Path) -> tuple[bool, str]:
        """Check if access to path is allowed."""
        path = path.expanduser().resolve()

        # Check denied paths first
        for denied in self._denied_paths:
            try:
                path.relative_to(denied)
                return (
                    False,
                    f"Access denied: path is in blocked directory {denied}",
                )
            except ValueError:
                continue

        # Check allowed paths
        for allowed in self._allowed_paths:
            try:
                path.relative_to(allowed)
                return True, ""
            except ValueError:
                continue

        return False, f"Access denied: path is not in any allowed directory"

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool."""
        path_str = kwargs.get("path", "")
        if not path_str:
            return "Error: path parameter is required"

        path = Path(path_str).expanduser()

        # Check permissions
        allowed, message = self._check_permission(path)
        if not allowed:
            return message

        # Check if directory exists
        if not path.exists():
            return f"Error: directory not found: {path}"

        if not path.is_dir():
            return f"Error: path is not a directory: {path}"

        # List directory
        try:
            entries = []
            for entry in sorted(path.iterdir()):
                entry_type = "dir" if entry.is_dir() else "file"
                size = entry.stat().st_size if entry.is_file() else 0
                entries.append(f"{entry_type:4} {size:>10} {entry.name}")

            if not entries:
                return f"Directory is empty: {path}"

            return "\n".join([f"Contents of {path}:", ""] + entries)
        except Exception as e:
            return f"Error listing directory: {e}"


class SearchFilesTool(Tool):
    """Tool to search for files matching a pattern."""

    def __init__(self, allowed_paths: list[str], denied_paths: list[str]) -> None:
        super().__init__(
            name="search_files",
            description="Search for files matching a pattern (supports wildcards)",
            parameters={
                "pattern": ToolParameter(
                    type="string",
                    description="Pattern to match (e.g., '*.py', 'test_*.txt')",
                    required=True,
                ),
                "path": ToolParameter(
                    type="string",
                    description="Directory to search in (default: current directory)",
                    required=False,
                ),
            },
            requires_permission=True,
            permission_scope="file_system",
        )

        self._allowed_paths = [Path(p).expanduser() for p in allowed_paths]
        self._denied_paths = [Path(p).expanduser() for p in denied_paths]

    def _check_permission(self, path: Path) -> tuple[bool, str]:
        """Check if access to path is allowed."""
        path = path.expanduser().resolve()

        # Check denied paths first
        for denied in self._denied_paths:
            try:
                path.relative_to(denied)
                return (
                    False,
                    f"Access denied: path is in blocked directory {denied}",
                )
            except ValueError:
                continue

        # Check allowed paths
        for allowed in self._allowed_paths:
            try:
                path.relative_to(allowed)
                return True, ""
            except ValueError:
                continue

        return False, f"Access denied: path is not in any allowed directory"

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool."""
        pattern = kwargs.get("pattern", "")
        path_str = kwargs.get("path", ".")

        if not pattern:
            return "Error: pattern parameter is required"

        path = Path(path_str).expanduser().resolve()

        # Check permissions
        allowed, message = self._check_permission(path)
        if not allowed:
            return message

        # Check if directory exists
        if not path.exists():
            return f"Error: directory not found: {path}"

        if not path.is_dir():
            return f"Error: path is not a directory: {path}"

        # Search for files
        try:
            matches = list(path.rglob(pattern))
            if not matches:
                return f"No files found matching pattern: {pattern}"

            results = [f"Found {len(matches)} files matching '{pattern}':"]
            for match in matches[:50]:  # Limit to 50 results
                results.append(str(match))

            if len(matches) > 50:
                results.append(f"\n... and {len(matches) - 50} more")

            return "\n".join(results)
        except Exception as e:
            return f"Error searching files: {e}"
