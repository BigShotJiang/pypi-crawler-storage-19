# ExoBrain CLI UI 设计文档

本文档说明 ExoBrain 命令行界面的 UI 设计和实现。

## 设计目标

1. **减少视觉噪音** - 工具调用不再输出大量重复信息
2. **清晰的信息层次** - 工具输出与 Agent 响应分离
3. **简洁的成功提示** - 成功的工具调用显示为一行总结
4. **完整的错误信息** - 失败的工具调用显示全部细节
5. **流畅的交互体验** - 保持流式响应的实时感

## UI 组件

### 1. StatusPanel (状态面板)

显示 Agent 的实时状态（目前已实现但未使用）。

**功能**：

- Agent 状态（Idle, Thinking, Calling Tools, Finished, Error）
- 当前迭代次数
- Token 使用统计
- 当前正在执行的工具

**未来集成**：可以添加到聊天界面顶部作为实时状态栏。

### 2. ToolCallDisplay (工具调用显示)

提供两种工具调用显示模式：

#### 简洁模式（成功时）

```
✅ shell_execute - Exit code: 0
```

#### 详细模式（失败时）

```
[Tool: shell_execute]
Command: gcc hello.c
Access denied: command not in allowed list
```

**优点**：

- 成功的工具调用不占用太多空间
- 失败的工具调用显示完整信息方便调试
- 用户可以快速扫描工具执行历史

### 3. ConversationDisplay (对话显示)

格式化用户和 Agent 消息（目前未使用，但可扩展）。

## 当前实现

### 流式聊天增强 (`run_streaming_chat`)

**工作流程**：

1. **检测工具调用**

   ```python
   if chunk.startswith("\n\n[Tool:"):
       in_tool_section = True
       # 提取工具名称
       # 开始收集工具输出
   ```

2. **收集工具输出**

   ```python
   if in_tool_section:
       current_tool_output.append(chunk)
       # 检测工具输出是否结束
   ```

3. **检测工具输出结束**

   - 当遇到不以 `\n` 或 `[` 开头的内容时
   - 说明 Agent 开始回复，工具输出结束
   - 渲染工具调用总结

4. **渲染工具总结**

   ```python
   if is_error:
       console.print(full_output, style="red dim")
   else:
       summary = ToolCallDisplay.render_tool_summary(...)
       console.print(summary)
   ```

5. **流式显示 Agent 响应**
   ```python
   console.print(chunk, end="")
   ```

### 示例输出

**之前（冗长）**：

```
[Tool: shell_execute]
Command: mkdir test_dir
Working directory: /home/user/repos/exobrain
Exit code: 0



[Tool: write_file]
Successfully wrote 11 characters to test_dir/hello.txt

我已在当前目录创建了...
```

**现在（简洁）**：

```
✅ shell_execute - Exit code: 0
✅ write_file - Successfully wrote 11 characters to test_dir/hello.txt
我已在当前目录创建了...
```

**失败时（详细）**：

```
[Tool: shell_execute]
Command: gcc hello.c
Access denied: command not in allowed list

让我换一种方式...
```

## UI 库使用

### Rich

使用 `rich` 库提供以下功能：

- **控制台输出** (`Console`) - 彩色文本和格式化
- **面板** (`Panel`) - 带边框的内容块
- **文本样式** (`Text`, `Style`) - 颜色和格式
- **实时更新** (`Live`) - 动态更新内容（未来使用）
- **Markdown 渲染** (`Markdown`) - 渲染 Markdown 格式

**优点**：

- 已经在项目中使用，无需新依赖
- 功能强大，支持丰富的终端特性
- 性能好，适合流式输出

## 配置选项

在 `config.yaml` 中：

```yaml
cli:
  theme: auto # auto, dark, light
  show_timestamps: false
  show_token_usage: true
  syntax_highlighting: true
  render_markdown: true
```

## 未来增强

### 1. 实时状态栏

在聊天界面顶部添加实时更新的状态栏：

```
╭──────────────────────────────────────────╮
│ 🧠 ExoBrain Status                       │
│ State: [🔧] Calling Tools | Iter: 3/10   │
│ Tool: shell_execute (mkdir test)        │
╰──────────────────────────────────────────╯
```

使用 `Rich.Live` 实现实时更新。

### 2. 工具调用折叠/展开

允许用户展开查看成功工具调用的详细信息：

```
✅ shell_execute - Exit code: 0  [+] 展开
```

点击或按键展开：

```
✅ shell_execute - Exit code: 0  [-] 折叠
  Command: ls -la
  Working directory: /home/user/repos

  --- Standard Output ---
  total 316
  drwxr-xr-x  9 user group  4096 ...
```

### 3. 进度指示器

对于长时间运行的工具，显示进度：

```
🔧 shell_execute (python train.py) ... ⠋ Running (15s)
```

### 4. Token 使用统计

在每次对话后显示 token 使用：

```
💬 Response completed
   📊 Tokens: 245 (prompt: 120, completion: 125)
   💰 Cost: ~$0.0012
```

### 5. 工具执行历史

添加 `/tools` 命令查看最近的工具调用：

```
/tools

Recent tool calls:
1. ✅ shell_execute - ls (2s ago)
2. ✅ write_file - hello.txt (5s ago)
3. ❌ shell_execute - gcc (10s ago)
```

### 6. 交互式工具确认

对于危险操作，显示确认提示：

```
⚠️  Tool wants to execute:
    shell_execute: rm important.txt

    [Y] Allow  [N] Deny  [A] Allow all
```

### 7. Textual TUI (可选)

对于需要更复杂 UI 的场景，可以切换到 Textual 全屏界面：

```
╭─ Chat ──────────────────────────╮╭─ Tools ────────╮
│ You: 创建一个 hello world 程序    ││ Recent Calls:  │
│                                  ││ ✅ mkdir        │
│ Assistant:                       ││ ✅ write_file   │
│ 好的，我会帮你创建...             ││ 🔧 gcc ...     │
│                                  │╰────────────────╯
╰──────────────────────────────────╯╭─ Status ───────╮
╭─ Input ──────────────────────────╮│ State: Working │
│ > _                              ││ Iter: 2/10     │
╰──────────────────────────────────╯╰────────────────╯
```

使用 `textual` 库实现（需要添加依赖）。

## 实现指南

### 添加新的 UI 组件

1. **在 `exobrain/cli/ui.py` 中定义组件类**

   ```python
   class MyComponent:
       @staticmethod
       def render(...) -> Panel:
           # 返回 Rich 组件
           pass
   ```

2. **在 `run_streaming_chat` 或 `run_chat_session` 中使用**

   ```python
   component = MyComponent.render(data)
   console.print(component)
   ```

3. **添加配置选项**（如需要）
   ```yaml
   cli:
     my_feature: true
   ```

### 修改工具显示格式

编辑 `ToolCallDisplay.render_tool_summary()` 方法：

```python
@staticmethod
def render_tool_summary(tool_name: str, success: bool, message: str = "") -> Text:
    # 自定义显示逻辑
    icon = "✅" if success else "❌"
    # ...
    return Text.assemble(...)
```

## 最佳实践

1. **保持简洁** - 默认显示最少信息，需要时才展开
2. **即时反馈** - 工具开始执行时立即显示
3. **清晰的状态** - 用户始终知道发生了什么
4. **优雅降级** - 在不支持彩色的终端上也能正常使用
5. **可配置** - 用户可以关闭不需要的功能

## 性能考虑

- **流式输出** - 使用 `end=""` 避免缓冲
- **最小化渲染** - 只在必要时重新渲染组件
- **异步友好** - 所有 UI 操作不阻塞 Agent

---

**版本**: 1.0
**最后更新**: 2026-01-04
