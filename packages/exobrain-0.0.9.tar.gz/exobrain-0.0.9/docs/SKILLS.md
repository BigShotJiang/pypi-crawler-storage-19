# Skills 系统

ExoBrain 的 Skills 系统让 Agent 能够访问和使用专业化的技能指令，这些技能提供了详细的知识、最佳实践和代码示例。

## 概述

Skills 是 Anthropic 格式的知识文档（SKILL.md），包含：

- **名称和描述**：Skill 的用途和适用场景
- **详细指令**：完整的使用指南、代码示例、最佳实践

ExoBrain 采用**工具化 Skills** 的设计，Agent 可以主动选择和获取所需的 skill 指令。

## 工作原理

### 1. Skills 加载

ExoBrain 在启动时从以下位置加载 skills：

- **Anthropic Skills**：`exobrain/skills/anthropic/skills/` (git submodule)
- **用户自定义 Skills**：`~/.exobrain/skills/`
- **配置的 Skills 目录**：在 `config.yaml` 中指定

```yaml
skills:
  enabled: true
  skills_dir: ~/my-custom-skills # 可选
```

### 2. Skills 摘要

加载的 skills 会以摘要形式添加到系统提示词中，让 Agent 了解有哪些 skills 可用：

```
Available Skills Summary:
- slack-gif-creator: Knowledge and utilities for creating animated GIFs optimized for Slack
- web-artifacts-builder: Suite of tools for creating elaborate HTML artifacts
- frontend-design: Create distinctive, production-grade frontend interfaces
...
```

### 3. 按需获取详细指令

当 Agent 需要使用某个 skill 时，可以调用三个 skill 工具：

#### `list_skills()`

列出所有可用的 skills 及其描述

**使用场景**：

- 了解有哪些 skills 可用
- 查找 skill 的准确名称

**示例**：

```python
# Agent 调用
list_skills()

# 返回
Available Skills (16 total):

• slack-gif-creator
  Knowledge and utilities for creating animated GIFs optimized for Slack...

• web-artifacts-builder
  Suite of tools for creating elaborate, multi-component HTML artifacts...
...
```

#### `search_skills(query, max_results=5)`

搜索与查询相关的 skills

**使用场景**：

- 不确定具体 skill 名称
- 想找特定主题相关的 skills

**参数**：

- `query` (必需)：搜索关键词
- `max_results` (可选)：返回的最大结果数，默认 5

**示例**：

```python
# Agent 调用
search_skills(query="create gif")

# 返回
Found 1 skill(s) matching 'create gif':

1. slack-gif-creator
   Knowledge and utilities for creating animated GIFs optimized for Slack...

To get detailed instructions, use: get_skill(skill_name="slack-gif-creator")
```

#### `get_skill(skill_name)`

获取特定 skill 的完整指令

**使用场景**：

- 需要详细的使用指南
- 需要代码示例和最佳实践

**参数**：

- `skill_name` (必需)：Skill 的准确名称

**示例**：

````python
# Agent 调用
get_skill(skill_name="slack-gif-creator")

# 返回完整的 skill 指令
# Skill: slack-gif-creator
**Description**: Knowledge and utilities for creating animated GIFs...

---

# Slack GIF Creator

## Slack Requirements
- Emoji GIFs: 128x128 (recommended)
- Message GIFs: 480x480
- FPS: 10-30
...

## Core Workflow
```python
from core.gif_builder import GIFBuilder
builder = GIFBuilder(width=128, height=128, fps=10)
# ... (详细代码示例)
````

...

```

## 使用流程示例

### 场景 1：用户明确需求

```

用户："用 slack-gif-creator skill 创建一个跳动的球 GIF"

Agent 思考：

1. 看到系统提示词中有 slack-gif-creator skill
2. 调用 get_skill(skill_name="slack-gif-creator")
3. 获得完整的 GIF 创建指令和代码示例
4. 根据指令生成代码

Agent 输出：
"我会使用 slack-gif-creator skill 来创建一个 Slack 优化的 GIF。
根据 skill 指南，我会使用以下参数：

- 尺寸：128x128（适合 Slack emoji）
- FPS：10（保持文件小）
- 帧数：12（约 1.2 秒动画）

让我编写代码..."

[生成使用 GIFBuilder 的正确代码]

```

### 场景 2：用户需求模糊

```

用户："我想做一些网页设计"

Agent 思考：

1. 不确定具体需要哪个 skill
2. 调用 search_skills(query="web design")
3. 查看返回的 skills 列表
4. 可能找到：web-artifacts-builder、frontend-design、theme-factory
5. 根据上下文选择合适的 skill 或询问用户

Agent 输出：
"我找到几个相关的 skills：

1. web-artifacts-builder - 创建复杂的 HTML artifacts
2. frontend-design - 高质量的前端界面设计
3. theme-factory - 为 artifacts 添加主题样式

您想要创建哪种类型的网页设计？"

```

### 场景 3：组合使用多个 Skills

```

用户："创建一个带主题样式和算法艺术的网页 artifact"

Agent 思考：

1. 识别需要多个 skills
2. 依次调用：
   - get_skill(skill_name="web-artifacts-builder")
   - get_skill(skill_name="theme-factory")
   - get_skill(skill_name="algorithmic-art")
3. 整合多个 skills 的指令
4. 生成综合方案

Agent 输出：
"我会结合三个 skills 来完成这个任务：

1. web-artifacts-builder - 构建 HTML 结构
2. theme-factory - 应用主题样式
3. algorithmic-art - 创建算法艺术效果

让我开始实现..."

````

## 已集成的 Skills

ExoBrain 默认集成了 Anthropic 的官方 skills（16 个），包括：

- **algorithmic-art** - 使用 p5.js 创建算法艺术
- **slack-gif-creator** - 创建 Slack 优化的 GIF
- **web-artifacts-builder** - 创建复杂的 HTML artifacts
- **frontend-design** - 高质量前端界面设计
- **theme-factory** - Artifacts 主题样式
- **skill-creator** - 创建新的 skills
- **pptx** - PowerPoint 文档处理
- **pdf** - PDF 文档处理
- **xlsx** - Excel 表格处理
- **docx** - Word 文档处理
- **internal-comms** - 内部沟通文档
- **webapp-testing** - Web 应用测试
- **canvas-design** - Canvas 设计
- **brand-guidelines** - Anthropic 品牌指南
- **doc-coauthoring** - 文档协作
- **mcp-builder** - MCP 服务器构建

## 添加自定义 Skills

### 方法 1：用户目录

在 `~/.exobrain/skills/` 创建 skill 文件夹和 `SKILL.md`：

```bash
mkdir -p ~/.exobrain/skills/my-awesome-skill
cd ~/.exobrain/skills/my-awesome-skill
````

创建 `SKILL.md`：

````markdown
---
name: my-awesome-skill
description: A brief description of what this skill does
license: MIT
---

# My Awesome Skill

## Overview

Detailed explanation of the skill...

## Usage

Step-by-step instructions...

## Examples

```python
# Code examples
```
````

\`\`\`

````

### 方法 2：配置自定义目录

在 `config.yaml` 中指定：

```yaml
skills:
  enabled: true
  skills_dir: ~/projects/my-skills
````

### SKILL.md 格式规范

```markdown
---
name: skill-name # 必需：Skill 唯一标识符
description: Brief description # 必需：简短描述
license: License info # 可选：许可证信息
author: Your Name # 可选：作者信息
version: 1.0.0 # 可选：版本号
---

# Skill Title

[详细的使用指南、代码示例、最佳实践...]
```

## 技术实现

### 架构概览

```
用户消息
    ↓
Agent 识别需要 skill
    ↓
调用 skill 工具 (get_skill, search_skills, list_skills)
    ↓
获取详细 skill 指令
    ↓
基于指令执行任务
```

### 关键组件

1. **SkillLoader** (`exobrain/skills/loader.py`)

   - 加载 SKILL.md 文件
   - 解析 YAML frontmatter 和 markdown 内容
   - 管理 skills 集合

2. **SkillsManager** (`exobrain/skills/manager.py`)

   - 选择相关 skills (`select_skills_for_query`)
   - 构建 skill 上下文 (`build_skills_context`)
   - 提供 skills 摘要 (`get_all_skills_summary`)

3. **Skill Tools** (`exobrain/tools/skill_tools.py`)
   - `GetSkillTool` - 获取特定 skill
   - `SearchSkillsTool` - 搜索 skills
   - `ListSkillsTool` - 列出所有 skills

### 与 Claude.ai 的对齐

ExoBrain 的 skills 实现遵循 Anthropic 的设计理念：

- ✓ 使用 Anthropic 官方 SKILL.md 格式
- ✓ Skills 摘要显示在系统提示词中
- ✓ Agent 主动决定何时获取 skill 指令
- ✓ 按需加载，节省 token

## 配置选项

```yaml
skills:
  enabled: true # 是否启用 skills 系统
  skills_dir: ~/my-skills # 自定义 skills 目录（可选）
```

## 最佳实践

### 对于用户

1. **清晰表达需求**：说明想要使用的 skill 或任务类型

   - 好："用 slack-gif-creator 创建一个 GIF"
   - 好："创建一个适合 Slack 的动画 GIF"

2. **探索可用 skills**：使用 `list_skills` 了解有哪些 skills

3. **组合使用**：复杂任务可以要求使用多个 skills

### 对于 Agent

1. **优先使用 skills**：当任务匹配某个 skill 的描述时，应该获取并使用它

2. **搜索而非猜测**：不确定 skill 名称时，使用 `search_skills`

3. **完整读取指令**：调用 `get_skill` 后，仔细阅读全部指令

4. **遵循最佳实践**：Skills 包含的最佳实践应该被遵循

## 故障排除

### Skills 未加载

检查日志输出：

```bash
exobrain chat --verbose
```

查看是否有 "Loading skills..." 和 "Registered X skills" 消息。

### 找不到特定 Skill

1. 使用 `list_skills` 查看已加载的 skills
2. 检查 skill 名称拼写（区分大小写）
3. 确认 skill 文件位于正确的目录

### Skill 内容不完整

检查 `SKILL.md` 文件：

- 确保有正确的 YAML frontmatter（用 `---` 包围）
- 确保 `name` 和 `description` 字段存在
- 检查文件编码为 UTF-8

## 未来增强

- [ ] 支持基于向量嵌入的语义搜索
- [ ] Skill 版本管理和更新
- [ ] Skill 依赖关系管理
- [ ] Skill 使用统计和推荐
- [ ] 从 URL 或 GitHub 安装 skills
- [ ] Skill 市场和社区共享

---

**版本**: 1.0
**最后更新**: 2026-01-04
