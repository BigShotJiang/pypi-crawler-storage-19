# ExoBrain 技术规范文档

## 1. 项目信息

- **项目名称**: ExoBrain
- **版本**: 0.1.0
- **Python 版本**: 3.10+
- **许可证**: MIT (建议)

## 2. 系统需求

### 2.1 运行环境

- **操作系统**: Linux、macOS、Windows
- **Python**: 3.10 或更高版本
- **内存**: 最低 4GB RAM（本地模型需 8GB+）
- **磁盘**: 最低 2GB 可用空间
- **可选**: CUDA 支持（用于本地模型加速）

### 2.2 依赖项

详见 [pyproject.toml](../pyproject.toml)

## 3. 模型提供者规范

### 3.1 统一接口

所有模型提供者必须实现以下抽象接口:

```python
from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional, List, Dict, Any

class ModelProvider(ABC):
    """模型提供者基类"""

    @abstractmethod
    async def generate(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> Dict[str, Any] | AsyncIterator[Dict[str, Any]]:
        """生成响应"""
        pass

    @abstractmethod
    async def embed(
        self,
        texts: List[str],
        **kwargs
    ) -> List[List[float]]:
        """生成嵌入向量"""
        pass

    @abstractmethod
    def supports_tool_calling(self) -> bool:
        """是否支持工具调用"""
        pass

    @abstractmethod
    def get_context_window(self) -> int:
        """获取上下文窗口大小"""
        pass
```

### 3.2 支持的提供者

#### 3.2.1 OpenAI

- **模型**: GPT-4, GPT-4 Turbo, GPT-3.5 Turbo
- **工具调用**: 支持 Function Calling
- **流式响应**: 支持
- **嵌入模型**: text-embedding-3-small, text-embedding-3-large

#### 3.2.2 Anthropic

- **模型**: Claude 3 Opus, Sonnet, Haiku
- **工具调用**: 支持 Tool Use
- **流式响应**: 支持
- **嵌入模型**: 需使用第三方

#### 3.2.3 本地模型 (llama.cpp)

- **模型格式**: GGUF
- **工具调用**: 通过函数调用语法模拟
- **流式响应**: 支持
- **推荐模型**:
  - Mistral 7B Instruct
  - Llama 3 8B Instruct
  - Qwen 7B Chat

#### 3.2.4 Ollama

- **协议**: OpenAI 兼容 API
- **工具调用**: 部分模型支持
- **流式响应**: 支持
- **本地管理**: 内置模型管理

#### 3.2.5 OpenAI 兼容服务

- **支持**: 任何兼容 OpenAI API 的服务
- **配置**: 自定义 base_url

### 3.3 配置规范

```yaml
models:
  default: openai/gpt-4-turbo

  providers:
    openai:
      api_key: ${OPENAI_API_KEY}
      base_url: https://api.openai.com/v1
      models:
        - gpt-4-turbo
        - gpt-3.5-turbo
      default_params:
        temperature: 0.7
        max_tokens: 4096

    anthropic:
      api_key: ${ANTHROPIC_API_KEY}
      models:
        - claude-3-opus-20240229
        - claude-3-sonnet-20240229
      default_params:
        temperature: 0.7
        max_tokens: 4096

    llamacpp:
      model_path: ~/.exobrain/models/mistral-7b-instruct.gguf
      n_ctx: 8192
      n_gpu_layers: 35
      default_params:
        temperature: 0.7
        top_p: 0.9

    ollama:
      base_url: http://localhost:11434
      models:
        - llama3:8b
        - mistral:7b

  embedding:
    default: openai/text-embedding-3-small
    providers:
      openai:
        model: text-embedding-3-small
      local:
        model: sentence-transformers/all-MiniLM-L6-v2
```

## 4. 工具系统规范

### 4.1 工具定义格式

工具使用标准的 JSON Schema 格式定义:

```python
from pydantic import BaseModel, Field
from typing import Callable, Any, Optional

class ToolParameter(BaseModel):
    type: str
    description: str
    enum: Optional[List[str]] = None
    required: bool = True

class Tool(BaseModel):
    name: str
    description: str
    parameters: Dict[str, ToolParameter]
    function: Callable
    requires_permission: bool = False
    permission_scope: Optional[str] = None

    def to_openai_format(self) -> Dict[str, Any]:
        """转换为 OpenAI 工具格式"""
        pass

    def to_anthropic_format(self) -> Dict[str, Any]:
        """转换为 Anthropic 工具格式"""
        pass
```

### 4.2 内置工具列表

#### 4.2.1 文件系统工具

- `read_file`: 读取文件内容
- `write_file`: 写入文件
- `list_directory`: 列出目录内容
- `search_files`: 搜索文件（支持 glob 模式）
- `get_file_info`: 获取文件元数据

#### 4.2.2 记忆工具

- `recall_conversation`: 回忆历史对话
- `save_memory`: 保存重要信息
- `search_memories`: 搜索记忆

#### 4.2.3 时间管理工具

- `get_current_time`: 获取当前时间
- `create_reminder`: 创建提醒
- `list_reminders`: 列出提醒

#### 4.2.4 Web 工具

- `web_search`: Web 搜索（需配置搜索引擎 API）
- `fetch_url`: 获取网页内容

#### 4.2.5 执行工具

- `execute_python`: 执行 Python 代码（沙箱环境）
- `execute_shell`: 执行 Shell 命令（受限）

### 4.3 权限模型

```yaml
permissions:
  file_system:
    enabled: true
    allowed_paths:
      - ~/Documents/notes
      - ~/Documents/knowledge
    denied_paths:
      - ~/.ssh
      - ~/.aws
    max_file_size: 10485760 # 10MB

  code_execution:
    enabled: false
    timeout: 30
    memory_limit: 512MB

  web_access:
    enabled: true
    allowed_domains:
      - "*" # 允许所有
    blocked_domains:
      - example-blocked.com
```

### 4.4 工具调用流程

```
1. Agent 决策需要调用工具
2. 检查工具权限
3. 验证参数
4. 执行工具（带超时和资源限制）
5. 处理结果/错误
6. 返回给 Agent
7. 记录审计日志
```

## 5. Agent 核心规范

### 5.1 Agent 状态机

```python
from enum import Enum

class AgentState(Enum):
    IDLE = "idle"                    # 空闲
    THINKING = "thinking"            # 思考中
    TOOL_CALLING = "tool_calling"    # 调用工具
    WAITING = "waiting"              # 等待用户输入
    ERROR = "error"                  # 错误状态
    FINISHED = "finished"            # 完成
```

### 5.2 对话消息格式

采用 OpenAI 兼容的消息格式:

```python
class Message(BaseModel):
    role: str  # system, user, assistant, tool
    content: str | List[Dict[str, Any]]
    name: Optional[str] = None
    tool_calls: Optional[List[ToolCall]] = None
    tool_call_id: Optional[str] = None
```

### 5.3 上下文管理

```python
class ContextWindow:
    max_tokens: int
    current_tokens: int
    messages: List[Message]

    def add_message(self, message: Message) -> None:
        """添加消息，自动管理窗口大小"""
        pass

    def summarize_if_needed(self) -> None:
        """超出窗口时进行总结"""
        pass

    def get_messages(self) -> List[Message]:
        """获取当前窗口内的消息"""
        pass
```

### 5.4 渐进式暴露策略

工具根据对话上下文动态暴露:

```python
class ProgressiveExposure:
    """渐进式工具暴露"""

    def get_available_tools(
        self,
        conversation_history: List[Message],
        user_intent: str,
        context: Dict[str, Any]
    ) -> List[Tool]:
        """根据上下文决定暴露哪些工具"""
        pass
```

**暴露策略**:

- **第一层** (始终可用): 基础对话、知识搜索
- **第二层** (检测到需求): 文件系统访问、Web 搜索
- **第三层** (明确请求): 代码执行、系统命令
- **第四层** (专家模式): MCP 服务器、自定义 Agent

## 6. Skills 系统规范

### 6.1 Skill 定义格式

```yaml
# skills/habit_tracker.yaml
name: habit_tracker
version: 1.0.0
description: 追踪和管理用户习惯

triggers:
  - 习惯
  - 打卡
  - 坚持

tools:
  - name: log_habit
    description: 记录习惯完成情况
    parameters:
      habit_name:
        type: string
        description: 习惯名称
      completed:
        type: boolean
        description: 是否完成
      date:
        type: string
        description: 日期 (YYYY-MM-DD)
    implementation: habits.log_habit

  - name: get_habit_stats
    description: 获取习惯统计信息
    parameters:
      habit_name:
        type: string
        description: 习惯名称
      days:
        type: integer
        description: 统计天数
    implementation: habits.get_stats

prompts:
  system: |
    你是一个习惯追踪助手。帮助用户记录和分析他们的习惯。

  examples:
    - user: 我今天完成了跑步
      assistant: 太棒了！让我记录下来。
      tool_call:
        name: log_habit
        arguments:
          habit_name: 跑步
          completed: true
          date: today

configuration:
  storage_path: ~/.exobrain/data/habits
  reminder_enabled: true
```

### 6.2 Skill 加载机制

```python
class SkillLoader:
    """Skill 加载器"""

    def load_skill(self, skill_path: str) -> Skill:
        """从 YAML 加载 Skill"""
        pass

    def register_skill(self, skill: Skill) -> None:
        """注册 Skill"""
        pass

    def get_matching_skills(self, query: str) -> List[Skill]:
        """根据触发词匹配 Skill"""
        pass
```

### 6.3 内置 Skills

- **note_manager**: 笔记管理
- **habit_tracker**: 习惯追踪
- **task_planner**: 任务规划
- **time_manager**: 时间管理
- **meeting_assistant**: 会议助手

## 7. MCP 集成规范

### 7.1 MCP 服务器配置

```yaml
mcp:
  enabled: true
  servers:
    - name: filesystem
      command: npx
      args:
        - -y
        - @modelcontextprotocol/server-filesystem
        - /home/user/documents

    - name: github
      command: npx
      args:
        - -y
        - @modelcontextprotocol/server-github
      env:
        GITHUB_TOKEN: ${GITHUB_TOKEN}

    - name: postgres
      command: npx
      args:
        - -y
        - @modelcontextprotocol/server-postgres
        - postgresql://localhost/mydb

    - name: custom
      command: python
      args:
        - ~/.exobrain/mcp/custom_server.py
```

### 7.2 MCP 客户端接口

```python
class MCPClient:
    """MCP 客户端"""

    async def connect(self, server_config: Dict[str, Any]) -> None:
        """连接到 MCP 服务器"""
        pass

    async def list_tools(self) -> List[Tool]:
        """列出服务器提供的工具"""
        pass

    async def call_tool(
        self,
        name: str,
        arguments: Dict[str, Any]
    ) -> Any:
        """调用 MCP 工具"""
        pass

    async def list_resources(self) -> List[Resource]:
        """列出服务器资源"""
        pass

    async def read_resource(self, uri: str) -> str:
        """读取资源内容"""
        pass
```

### 7.3 自定义 MCP 服务器模板

提供模板帮助用户创建自定义 MCP 服务器:

```python
# templates/mcp_server_template.py
from mcp.server import Server, Tool
from mcp.types import TextContent

app = Server("custom-server")

@app.tool()
async def my_tool(param1: str, param2: int) -> TextContent:
    """工具描述"""
    # 实现逻辑
    result = f"处理 {param1} 和 {param2}"
    return TextContent(type="text", text=result)

if __name__ == "__main__":
    app.run()
```

## 8. CLI 规范

### 8.1 命令结构

```bash
exobrain [OPTIONS] COMMAND [ARGS]...

Commands:
  chat          启动交互式对话
  ask           单次问答
  config        配置管理
  skills        Skills 管理
  mcp           MCP 服务器管理
  models        模型管理

Options:
  --config PATH    配置文件路径
  --verbose        详细输出
  --version        显示版本
  --help           显示帮助
```

### 8.2 交互式 Chat

```bash
exobrain chat [OPTIONS]

Options:
  --model TEXT        使用的模型
  --system TEXT       系统提示
  --tools TEXT        启用的工具（逗号分隔）
  --no-tools          禁用所有工具
  --load FILE         加载对话历史
  --save FILE         保存对话历史
```

### 8.3 UI 设计

使用 Rich/Textual 实现:

- **语法高亮**: 代码块和 JSON
- **Markdown 渲染**: 格式化输出
- **进度指示**: 长时间操作
- **流式输出**: 实时显示生成内容
- **颜色主题**: 可配置的颜色方案

## 10. 配置管理规范

### 10.1 配置文件位置

```
~/.exobrain/config.yaml          # 主配置
~/.exobrain/permissions.yaml     # 权限配置
~/.exobrain/profiles/            # 多配置文件支持
```

### 10.2 环境变量支持

支持 `${VAR_NAME}` 语法引用环境变量:

```yaml
models:
  providers:
    openai:
      api_key: ${OPENAI_API_KEY}
```

### 10.3 配置验证

启动时验证配置:

- 必需字段检查
- 类型验证
- 路径存在性检查
- API 密钥有效性检查（可选）

## 11. 日志和监控规范

### 11.1 日志级别

- **DEBUG**: 详细调试信息
- **INFO**: 一般信息
- **WARNING**: 警告信息
- **ERROR**: 错误信息
- **CRITICAL**: 严重错误

### 11.2 日志格式

```
[2024-01-03 10:30:45] [INFO] [agent.core] User message received
[2024-01-03 10:30:46] [DEBUG] [tools.filesystem] Reading file: /path/to/file
[2024-01-03 10:30:47] [INFO] [model.openai] API call successful (tokens: 234)
```

### 11.3 审计日志

记录敏感操作:

```json
{
  "timestamp": "2024-01-03T10:30:45Z",
  "action": "file_read",
  "path": "/home/user/documents/notes.md",
  "user": "default",
  "result": "success"
}
```

## 12. 测试规范

### 12.1 测试类型

- **单元测试**: 各模块独立测试
- **集成测试**: 模块间交互测试
- **端到端测试**: 完整流程测试
- **性能测试**: 响应时间和资源使用

### 12.2 测试覆盖率

目标: > 80% 代码覆盖率

### 12.3 Mock 策略

- Mock 外部 API 调用
- Mock 文件系统操作
- Mock 模型响应

## 13. 部署和分发

### 13.1 安装方式

```bash
# PyPI
pip install exobrain

# 源码安装
git clone https://github.com/username/exobrain.git
cd exobrain
uv sync
```

### 13.2 依赖管理

使用 uv 管理依赖:

- 核心依赖: 必需
- 可选依赖: 按功能分组（local-models, dev, docs）

### 13.3 版本发布

遵循语义化版本 (Semantic Versioning):

- MAJOR: 不兼容的 API 变更
- MINOR: 向后兼容的功能新增
- PATCH: 向后兼容的问题修复

## 14. 文档规范

### 14.1 文档结构

```
docs/
├── ARCHITECTURE.md      # 架构设计
├── SPECIFICATIONS.md    # 技术规范 (本文档)
├── USER_GUIDE.md        # 用户指南
├── DEVELOPER_GUIDE.md   # 开发者指南
├── API_REFERENCE.md     # API 参考
├── SKILLS_GUIDE.md      # Skills 开发指南
├── MCP_GUIDE.md         # MCP 集成指南
└── EXAMPLES.md          # 使用示例
```

### 14.2 代码文档

- 所有公共 API 必须有文档字符串
- 使用 Google 风格的 docstring
- 类型注解完整

### 14.3 Changelog

维护 CHANGELOG.md 记录所有版本变更

## 15. 性能指标

### 15.1 响应时间

- **首次响应**: < 2 秒
- **工具调用**: < 5 秒
- **知识库检索**: < 500ms
- **流式输出延迟**: < 100ms

### 15.2 资源使用

- **内存占用**: 基础 < 200MB
- **本地模型**: 额外 4-8GB
- **向量索引**: 取决于知识库大小

## 16. 安全和隐私

### 16.1 数据存储

- 所有敏感数据本地存储
- 可选的数据加密
- 定期清理临时文件

### 16.2 API 密钥管理

- 使用环境变量
- 支持密钥管理器集成
- 从不在日志中记录密钥

### 16.3 网络安全

- HTTPS 连接
- 证书验证
- 代理支持

## 17. 国际化

### 17.1 支持的语言

- 初期: 中文、英文
- 扩展: 更多语言

### 17.2 实现方式

- 使用 gettext 或类似库
- 消息和提示可翻译
- 日期和时间本地化

## 18. 贡献指南

### 18.1 代码风格

- 遵循 PEP 8
- 使用 Black 格式化
- 使用 Ruff 进行检查
- 类型注解完整

### 18.2 提交规范

遵循 Conventional Commits:

```
feat: 添加新功能
fix: 修复问题
docs: 文档更新
refactor: 代码重构
test: 测试相关
chore: 构建/工具相关
```

### 18.3 Pull Request 流程

1. Fork 仓库
2. 创建功能分支
3. 编写测试
4. 提交 PR
5. 代码审查
6. 合并

## 19. 路线图

### Phase 1: 核心功能 (v0.1.0 - v0.3.0)

- 基础 Agent 框架
- 多模型支持
- 基础工具系统
- 知识库基础功能
- CLI 界面

### Phase 2: 高级功能 (v0.4.0 - v0.6.0)

- Skills 系统
- MCP 集成
- 渐进式暴露
- Agent 编排
- 改进的 RAG

### Phase 3: 扩展和优化 (v0.7.0 - v1.0.0)

- 性能优化
- Web 界面
- 插件系统
- 多用户支持
- 云端同步（可选）

## 20. 参考资源

- [LangChain Documentation](https://python.langchain.com/)
- [Model Context Protocol](https://modelcontextprotocol.io/)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
- [Anthropic API Reference](https://docs.anthropic.com/)
- [ChromaDB Documentation](https://docs.trychroma.com/)
