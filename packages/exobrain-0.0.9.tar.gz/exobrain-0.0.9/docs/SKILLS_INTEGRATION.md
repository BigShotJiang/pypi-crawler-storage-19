# Anthropic Skills 集成指南

## 概述

ExoBrain 已成功集成 Anthropic 的官方 Skills 仓库作为 git submodule。这提供了 16+ 个高质量的专业技能，涵盖文档处理、设计、开发等多个领域。

## Skills 仓库位置

```
exobrain/skills/anthropic/
├── skills/              # 所有可用的 skills
│   ├── docx/           # Word 文档处理
│   ├── pdf/            # PDF 处理
│   ├── pptx/           # PowerPoint 处理
│   ├── xlsx/           # Excel 处理
│   ├── mcp-builder/    # MCP 服务器开发
│   ├── skill-creator/  # 创建自定义 skills
│   └── ...            # 更多 skills
├── spec/               # Agent Skills 规范
└── template/           # Skill 模板
```

## 可用的 Skills

### 文档处理 Skills

1. **docx** - Word 文档创建、编辑和分析
2. **pdf** - PDF 文档处理和表单填写
3. **pptx** - PowerPoint 演示文稿创建和编辑
4. **xlsx** - Excel 电子表格处理和数据分析

### 开发和技术 Skills

5. **mcp-builder** - 创建 MCP (Model Context Protocol) 服务器
6. **webapp-testing** - 使用 Playwright 测试 Web 应用
7. **skill-creator** - 创建自定义 Skills 的指南

### 创意和设计 Skills

8. **frontend-design** - 创建高质量前端界面
9. **web-artifacts-builder** - 创建复杂的 React Web 应用
10. **canvas-design** - 创建海报和视觉艺术
11. **algorithmic-art** - 使用 p5.js 创建算法艺术
12. **theme-factory** - 为项目创建和应用主题
13. **slack-gif-creator** - 创建优化的 Slack GIF

### 企业和沟通 Skills

14. **doc-coauthoring** - 文档协作编写工作流
15. **internal-comms** - 企业内部沟通文档
16. **brand-guidelines** - Anthropic 品牌指南应用

## 使用 Skills

### 1. 列出所有 Skills

```bash
uv run exobrain --config config.yaml skills list
```

### 2. 搜索 Skills

```bash
uv run exobrain --config config.yaml skills list --search "pdf"
uv run exobrain --config config.yaml skills list -s "document"
```

### 3. 查看 Skill 详情

```bash
uv run exobrain --config config.yaml skills show mcp-builder
uv run exobrain --config config.yaml skills show docx
```

### 4. 在对话中使用 Skills

Skills 会自动加载到 Agent 的系统提示中。当用户的请求匹配某个 Skill 的描述时，Agent 会自动使用该 Skill 的指令。

```bash
uv run exobrain --config config.yaml chat
```

示例对话：

```
You: 帮我创建一个 PDF 表单
Assistant: [自动使用 pdf skill 的指令来处理]

You: 创建一个 MCP 服务器来访问 GitHub API
Assistant: [自动使用 mcp-builder skill 的指令]

You: 设计一个现代化的登录页面
Assistant: [自动使用 frontend-design skill]
```

## Skill 格式

每个 Skill 是一个包含 `SKILL.md` 文件的目录：

```markdown
---
name: my-skill
description: Skill 描述和使用场景
license: Apache-2.0
---

# Skill 标题

## 概述

Skill 的详细说明...

## 指令

具体的执行指令...

## 示例

使用示例...
```

## 创建自定义 Skills

### 方法 1: 使用 skill-creator Skill

```bash
# 查看 skill-creator 指南
uv run exobrain --config config.yaml skills show skill-creator

# 在对话中请求创建
uv run exobrain --config config.yaml chat
You: 帮我创建一个管理待办事项的 Skill
```

### 方法 2: 手动创建

1. 在 `~/.exobrain/skills/` 创建新目录
2. 创建 `SKILL.md` 文件
3. 添加 YAML frontmatter 和指令

示例：

```bash
mkdir -p ~/.exobrain/skills/todo-manager
cat > ~/.exobrain/skills/todo-manager/SKILL.md << 'EOF'
---
name: todo-manager
description: 管理待办事项列表，包括添加、删除和查看任务
---

# 待办事项管理器

## 概述
这个 Skill 帮助用户管理待办事项。

## 指令

当用户请求管理待办事项时：

1. 如果要添加任务：
   - 提取任务描述和优先级
   - 保存到 ~/.exobrain/data/todos.json
   - 确认任务已添加

2. 如果要查看任务：
   - 读取 ~/.exobrain/data/todos.json
   - 按优先级排序显示

3. 如果要删除任务：
   - 从列表中移除指定任务
   - 确认已删除

## 数据格式

使用 JSON 格式存储：
\`\`\`json
{
  "todos": [
    {
      "id": 1,
      "description": "任务描述",
      "priority": "high",
      "completed": false,
      "created_at": "2024-01-01"
    }
  ]
}
\`\`\`
EOF
```

### 方法 3: 使用模板

```bash
# 复制模板
cp -r exobrain/skills/anthropic/template ~/.exobrain/skills/my-new-skill

# 编辑 SKILL.md
vim ~/.exobrain/skills/my-new-skill/SKILL.md
```

## Skills 配置

在 `config.yaml` 中配置 Skills：

```yaml
skills:
  enabled: true
  skills_dir: ~/.exobrain/skills
  builtin_skills:
    - note_manager
    - habit_tracker
  auto_load: true
  # 可选：禁用特定 skills
  disabled_skills:
    - brand-guidelines # 如果不需要 Anthropic 品牌指南
```

## Skills 开发最佳实践

### 1. 命名规范

- 使用小写字母和连字符
- 名称应清晰描述功能
- 示例：`mcp-builder`, `doc-coauthoring`

### 2. 描述清晰

- 在 `description` 中说明：
  - Skill 的功能
  - 何时使用
  - 关键特性
- 包含触发关键词

### 3. 指令具体

- 提供分步骤的清晰指令
- 包含示例
- 说明期望的输出格式

### 4. 包含资源

- 相关文档
- 示例文件
- 辅助脚本

### 5. 测试覆盖

- 提供测试用例
- 验证指令有效性
- 检查边界情况

## 高级用法

### 组合多个 Skills

Agent 可以在一个任务中使用多个 Skills：

```
You: 创建一个 PDF 报告，包含数据可视化和公司品牌风格
Assistant: [组合使用 pdf + xlsx + brand-guidelines skills]
```

### Skill 优先级

Skills 按加载顺序应用。如果有冲突：

1. 用户自定义 Skills (`~/.exobrain/skills/`)
2. Anthropic Skills (`exobrain/skills/anthropic/`)
3. 内置 Skills

### 动态加载

Skills 在每次启动时加载。要重新加载：

```bash
# 重启 CLI
exit
uv run exobrain --config config.yaml chat
```

## 故障排除

### Skill 未加载

检查：

1. `SKILL.md` 文件格式是否正确
2. YAML frontmatter 是否有效
3. `name` 和 `description` 字段是否存在
4. 查看日志：`uv run exobrain --verbose --config config.yaml skills list`

### Skill 冲突

如果多个 Skills 描述相似：

- 重命名以区分用途
- 在 `config.yaml` 中禁用不需要的
- 调整 `description` 使其更具体

### 查看详细日志

```bash
uv run exobrain --verbose --config config.yaml chat
```

## 更新 Anthropic Skills

Anthropic Skills 作为 git submodule，可以更新：

```bash
# 更新到最新版本
cd exobrain/skills/anthropic
git pull origin main
cd ../../..

# 提交更新
git add exobrain/skills/anthropic
git commit -m "Update Anthropic skills to latest version"
```

## 贡献 Skills

### 分享自定义 Skills

1. 创建 GitHub 仓库
2. 按 Agent Skills 规范组织
3. 提供文档和示例
4. 在社区分享

### 提交到 Anthropic Skills

如果创建了通用的高质量 Skill：

1. Fork https://github.com/anthropics/skills
2. 添加你的 Skill
3. 提交 Pull Request

## 资源链接

- [Agent Skills 规范](https://agentskills.io/specification)
- [Anthropic Skills 仓库](https://github.com/anthropics/skills)
- [创建自定义 Skills](https://support.claude.com/en/articles/12512198-creating-custom-skills)
- [使用 Skills 文档](https://support.claude.com/en/articles/12512180-using-skills-in-claude)

## 下一步

1. **探索现有 Skills**: 浏览所有可用的 Skills，了解其功能
2. **在对话中试用**: 在实际对话中使用 Skills
3. **创建自定义 Skills**: 根据个人需求创建专属 Skills
4. **组合使用**: 尝试组合多个 Skills 完成复杂任务
5. **分享经验**: 在社区分享你的 Skills 和使用经验
