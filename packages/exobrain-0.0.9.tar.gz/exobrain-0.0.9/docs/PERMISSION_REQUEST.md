# 权限请求功能

ExoBrain 的权限请求功能允许 Agent 在遇到权限不足时自动向用户请求授权，无需手动修改配置文件。

## 功能特点

- **自动检测** - Agent 在执行工具时自动检测 "Access denied" 错误
- **交互式请求** - 在 CLI 中显示友好的权限请求界面
- **多种授权范围** - 支持一次性、会话级、永久授权
- **自动重试** - 获得授权后自动重新执行被拒绝的操作

## 使用方式

### 权限请求流程

1. **Agent 执行工具遇到权限拒绝**

   ```
   Access denied: command not in allowed list
   ```

2. **系统显示权限请求面板**

   ```
   ╭──────────── Permission Request ────────────╮
   │ ⚠️  Permission Required                    │
   │                                             │
   │ Tool       shell_execute                    │
   │ Action     Execute shell command            │
   │ Resource   gcc --version                    │
   │ Reason     Command not in allowed list     │
   │                                             │
   │ Grant permission for this action?          │
   │                                             │
   │   [y] Yes, once       [n] No               │
   │   [s] Yes, session    [a] Yes, always      │
   ╰─────────────────────────────────────────────╯

   Your choice [y/n/s/a] (n):
   ```

3. **用户选择授权范围**

   - `y` - **一次性授权**：仅本次操作有效
   - `n` - **拒绝**：不授予权限，操作失败
   - `s` - **会话授权**：本次聊天会话期间有效
   - `a` - **永久授权**：写入 `config.yaml`，永久生效

4. **系统自动重试**
   - 如果用户授权，Agent 自动重新执行被拒绝的操作
   - 无需用户再次发起请求

## 授权范围说明

### 一次性授权 (Once - y)

- **生效范围**：仅当前这一次操作
- **适用场景**：临时需要执行某个命令，不希望长期开放权限
- **存储位置**：不存储，仅本次有效
- **示例**：临时执行 `gcc` 编译一个测试程序

### 会话授权 (Session - s)

- **生效范围**：当前聊天会话结束前
- **适用场景**：在本次对话中需要多次使用某项权限
- **存储位置**：Agent 的运行时内存 (`runtime_permissions`)
- **示例**：本次对话需要反复执行 `gcc` 编译和测试

### 永久授权 (Always - a)

- **生效范围**：永久有效，写入配置文件
- **适用场景**：经常使用的命令或路径，希望不再提示
- **存储位置**：`config.yaml` 中的 `permissions` 部分
- **示例**：经常需要用 `gcc` 编译代码，永久添加到允许列表

## 支持的权限类型

### 1. Shell 命令权限

- **触发场景**：执行不在 `allowed_commands` 列表中的命令
- **权限类型**：`command`
- **资源标识**：完整的命令字符串 (如 `gcc --version`)
- **更新位置**：`permissions.shell_execution.allowed_commands`

### 2. 目录访问权限

- **触发场景**：在不允许的目录中执行 shell 命令
- **权限类型**：`directory`
- **资源标识**：工作目录路径
- **更新位置**：`permissions.shell_execution.allowed_directories`

### 3. 文件路径权限

- **触发场景**：读写不在 `allowed_paths` 列表中的文件
- **权限类型**：`path`
- **资源标识**：文件路径
- **更新位置**：`permissions.file_system.allowed_paths`

## 配置示例

### 永久授权后的 config.yaml 变化

**授权前**：

```yaml
permissions:
  shell_execution:
    allowed_commands:
      - ls *
      - git *
      - python *
```

**授权 `gcc *` 后**：

```yaml
permissions:
  shell_execution:
    allowed_commands:
      - ls *
      - git *
      - python *
      - gcc --version # 新增
```

## 安全注意事项

1. **谨慎授予永久权限** - 永久权限会一直生效，确保理解命令的作用
2. **避免通配符滥用** - 如需添加通配符模式，请手动编辑配置文件
3. **定期审查权限** - 检查 `config.yaml` 中的 `permissions` 部分
4. **拒绝危险命令** - 对于 `sudo *`、`rm -rf /` 等危险命令始终拒绝

## 技术实现

### 架构设计

```
┌─────────────┐
│ Agent       │
│ (core.py)   │ - 检测 "Access denied" 错误
└──────┬──────┘ - 调用 permission_callback
       │
       ▼
┌─────────────────────┐
│ Permission Callback │
│ (cli/__init__.py)   │ - 协调请求和更新
└──────┬──────────────┘
       │
       ▼
┌──────────────────────────────────┐
│ UI & Update                      │
│ (cli/permissions.py)             │
├──────────────────────────────────┤
│ • request_permission()           │ - 显示 UI，获取用户选择
│ • update_permission()            │ - 更新会话或配置权限
└──────────────────────────────────┘
```

### 关键代码位置

- **权限检测**：`exobrain/agent/core.py` - `_execute_tool()` 方法
- **权限解析**：`exobrain/agent/core.py` - `_parse_access_denied()` 方法
- **权限请求 UI**：`exobrain/cli/permissions.py` - `request_permission()` 函数
- **权限更新**：`exobrain/cli/permissions.py` - `update_permission()` 函数
- **回调设置**：`exobrain/cli/__init__.py` - `run_chat_session()` 函数

## 未来增强

- [ ] 支持批量授权多个相关权限
- [ ] 添加权限历史记录和审计日志
- [ ] 支持基于正则表达式的权限规则
- [ ] 提供 `/permissions` 命令查看当前权限
- [ ] 支持临时撤销会话权限

---

**版本**: 1.0
**最后更新**: 2026-01-04
