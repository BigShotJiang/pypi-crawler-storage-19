# Shell 命令执行功能

ExoBrain 支持安全的 shell 命令执行，类似于 Claude Code 的功能。该功能通过细粒度的权限配置来确保安全性。

## 功能特性

- ✅ **目录级别的权限控制** - 指定允许/禁止执行命令的目录
- ✅ **命令级别的权限控制** - 指定允许/禁止的命令模式
- ✅ **通配符支持** - 使用 `*` 匹配命令参数（如 `git *`, `ls *`）
- ✅ **正则表达式支持** - 使用 `/pattern/` 定义复杂的命令模式
- ✅ **执行超时** - 防止命令无限期运行
- ✅ **安全优先** - 默认拦截所有危险命令

## 配置说明

### 1. 启用 Shell 执行

在 `config.yaml` 中：

```yaml
# 启用 shell 执行工具
tools:
  shell_execution: true

# 配置 shell 执行权限
permissions:
  shell_execution:
    enabled: true
    timeout: 30 # 命令执行超时（秒）
```

### 2. 配置允许的目录

指定哪些目录可以执行命令：

```yaml
permissions:
  shell_execution:
    allowed_directories:
      - ~/repos # 你的代码仓库
      - ~/Documents # 文档目录
      - ~/Desktop # 桌面
      - ~/projects # 项目目录
```

### 3. 配置禁止的目录

指定哪些目录**绝对不能**执行命令（优先级高于允许列表）：

```yaml
permissions:
  shell_execution:
    denied_directories:
      - ~/.ssh # SSH 密钥
      - ~/.aws # AWS 凭证
      - ~/.config # 配置文件
      - /etc # 系统配置
      - /sys # 系统目录
      - /proc # 进程目录
      - /dev # 设备目录
```

### 4. 配置允许的命令

支持三种模式：

#### 精确匹配

```yaml
allowed_commands:
  - ls # 只允许 "ls" 本身
  - pwd # 只允许 "pwd"
  - top # 只允许 "top"
```

#### 通配符匹配

```yaml
allowed_commands:
  - ls * # 允许 "ls" 及其所有参数
  - git * # 允许所有 git 命令
  - python * # 允许 python 脚本执行
  - npm * # 允许所有 npm 命令
```

#### 正则表达式匹配

```yaml
allowed_commands:
  - /^python[23]?$/ # 匹配 python, python2, python3
  - /^(npm|yarn|pnpm)/ # 匹配多个包管理器
```

### 5. 配置禁止的命令

**重要：禁止命令的优先级高于允许命令**

```yaml
denied_commands:
  # 危险的删除操作
  - rm -rf /
  - rm -rf /*
  - rm -rf ~
  - rm -rf ~/*
  - sudo rm *

  # 权限提升
  - sudo *
  - su *

  # 磁盘操作
  - dd *
  - mkfs *
  - fdisk *

  # 系统控制
  - shutdown *
  - reboot *
  - init *

  # 强制终止进程
  - kill -9 *
  - killall *

  # Fork bomb
  - ":(){ :|:& };:"

  # 危险的权限修改
  - chmod -R 777 *
```

## 使用示例

### 示例 1: 列出文件

```
用户: 请列出当前目录的文件

Agent:
[Tool: shell_execute]
Command: ls
Working directory: /home/user/repos/exobrain
Exit code: 0

--- Standard Output ---
config.yaml
README.md
exobrain/
...
```

### 示例 2: Git 操作

```
用户: 查看 git 状态

Agent:
[Tool: shell_execute]
Command: git status
Working directory: /home/user/repos/exobrain
Exit code: 0

--- Standard Output ---
On branch main
Your branch is up to date with 'origin/main'.
...
```

### 示例 3: 运行 Python 脚本

```
用户: 运行 test.py

Agent:
[Tool: shell_execute]
Command: python test.py
Working directory: /home/user/repos/exobrain
Exit code: 0

--- Standard Output ---
Test passed!
```

### 示例 4: 被拦截的危险命令

```
用户: 执行 sudo rm -rf /

Agent:
[Tool: shell_execute]
Access denied: command matches denied pattern 'sudo *'
```

## 安全建议

### 1. 最小权限原则

只允许真正需要的命令和目录：

```yaml
# ❌ 不推荐：允许所有命令
allowed_commands: []  # 空列表 = 允许所有

# ✅ 推荐：明确列出允许的命令
allowed_commands:
  - ls *
  - git *
  - python *
```

### 2. 总是配置禁止列表

即使允许所有命令，也要明确禁止危险操作：

```yaml
denied_commands:
  - sudo *
  - rm -rf /*
  - dd *
  - shutdown *
```

### 3. 限制目录访问

不要允许访问敏感目录：

```yaml
denied_directories:
  - ~/.ssh # SSH 密钥
  - ~/.aws # 云服务凭证
  - ~/.gnupg # GPG 密钥
  - ~/.password-store # 密码存储
```

### 4. 设置合理的超时

防止命令无限期运行：

```yaml
shell_execution:
  timeout: 30 # 秒
```

### 5. 定期审查配置

定期检查 `~/.exobrain/logs/audit.log` 查看命令执行历史。

## 常见问题

### Q: 为什么我的命令被拦截了？

**A:** 检查以下几点：

1. 命令是否在 `allowed_commands` 列表中？
2. 命令是否匹配 `denied_commands` 中的模式？
3. 工作目录是否在 `allowed_directories` 中？
4. 工作目录是否在 `denied_directories` 中？

### Q: 如何允许所有命令？

**A:** 将 `allowed_commands` 设置为空列表：

```yaml
allowed_commands: [] # 允许所有命令（除了 denied_commands）
```

⚠️ **警告：不推荐这样做，除非你完全信任 agent 和配置。**

### Q: 通配符 `*` 和正则表达式有什么区别？

**A:**

- **通配符** (`git *`): 简单的模式匹配，`*` 匹配任意字符
- **正则表达式** (`/^git.*/`): 更强大的模式，需要用 `/` 包裹

```yaml
# 通配符示例
- git * # 匹配 "git status", "git commit -m 'msg'"

# 正则表达式示例
- /^git\s+\w+$/ # 只匹配 "git status", "git pull" 等单参数命令
```

### Q: 如何调试命令权限问题？

**A:** 启用 DEBUG 日志级别：

```yaml
logging:
  level: DEBUG
```

然后查看日志文件 `~/.exobrain/logs/exobrain.log`。

## 与 Claude Code 的对比

| 特性           | ExoBrain      | Claude Code   |
| -------------- | ------------- | ------------- |
| 目录权限控制   | ✅            | ✅            |
| 命令模式匹配   | ✅            | ✅            |
| 通配符支持     | ✅            | ✅            |
| 正则表达式支持 | ✅            | ❌            |
| 用户可配置     | ✅ 完全可配置 | ⚠️ 部分可配置 |
| 执行确认       | 🚫 删除       | ✅            |

## 未来计划

- [ ] 命令执行历史记录和回放
- [ ] 交互式命令支持（如 `vim`, `less`）
- [ ] 命令输出流式传输
- [ ] 命令别名和快捷方式

## 示例配置

完整的示例配置可以参考 `config.example.yaml` 文件。

---

**注意：Shell 命令执行是一个强大但潜在危险的功能。请务必仔细配置权限，遵循安全最佳实践。**
