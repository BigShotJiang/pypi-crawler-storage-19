#!/usr/bin/env python3
"""
DEPRECATED: Use typequest.py instead

This file is kept for backward compatibility.
The platform has been renamed to TypeQuest.

To run TypeQuest, use:
    python3 typequest.py
"""

print("⚠️  DEPRECATED: This command has been renamed!")
print("📝 The platform is now called TypeQuest")
print("🚀 Please use: python3 typequest.py")
print()

# Still run the application for backward compatibility
if __name__ == "__main__":
    from main import BootsCLI
    app = BootsCLI()
    app.run()