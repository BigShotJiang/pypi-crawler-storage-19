"""
Additional essential Python programming concepts
"""

# Input/Output and Type Conversion Lesson
INPUT_OUTPUT_LESSON = {
    "id": 10,
    "chapter": 4,
    "title": "Input/Output and Type Conversion",
    "slug": "input-output-types",
    "content": '''
# Input/Output and Type Conversion

## Getting User Input

### The input() Function

```python
# Basic input (always returns a string)
name = input("What's your name? ")
print(f"Hello, {name}!")

# Input with prompt
age_str = input("How old are you? ")
print(f"You entered: {age_str}")
print(f"Type: {type(age_str)}")  # <class 'str'>
```

### Converting Input to Numbers

```python
# Convert to integer
age_str = input("Enter your age: ")
age = int(age_str)
print(f"Next year you'll be {age + 1}")

# Convert to float
height_str = input("Enter your height in meters: ")
height = float(height_str)
print(f"Height in centimeters: {height * 100}")

# One-liner conversion
score = int(input("Enter your score: "))
price = float(input("Enter the price: "))
```

### Input Validation

```python
# Validate integer input
def get_integer(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Please enter a valid integer.")

# Validate range
def get_age():
    while True:
        age = get_integer("Enter your age: ")
        if 0 <= age <= 150:
            return age
        print("Age must be between 0 and 150.")

# Validate from choices
def get_choice(prompt, choices):
    while True:
        choice = input(prompt).lower()
        if choice in choices:
            return choice
        print(f"Please choose from: {', '.join(choices)}")

# Usage
age = get_age()
choice = get_choice("Choose (yes/no): ", ["yes", "no", "y", "n"])
```

## Output Formatting

### The print() Function

```python
# Basic printing
print("Hello World")
print("Line 1")
print("Line 2")

# Multiple arguments
name = "Alice"
age = 25
print("Name:", name, "Age:", age)  # Name: Alice Age: 25

# Custom separator
print("apple", "banana", "orange", sep=" | ")  # apple | banana | orange

# Custom ending
print("Loading", end="")
print(".", end="")
print(".", end="")
print(".")  # Loading...

# Print to nowhere (suppress output)
print("This won't show", end="")
```

### String Formatting

```python
name = "Alice"
age = 25
height = 5.6

# f-strings (recommended, Python 3.6+)
print(f"Name: {name}, Age: {age}")
print(f"Height: {height:.1f} feet")
print(f"In 10 years: {age + 10}")

# format() method
print("Name: {}, Age: {}".format(name, age))
print("Name: {n}, Age: {a}".format(n=name, a=age))
print("Height: {:.2f}".format(height))

# % formatting (older style)
print("Name: %s, Age: %d" % (name, age))
print("Height: %.1f" % height)
```

### Advanced Formatting

```python
# Number formatting
pi = 3.14159265359

print(f"Pi: {pi:.2f}")        # Pi: 3.14
print(f"Pi: {pi:.4f}")        # Pi: 3.1416
print(f"Pi: {pi:10.2f}")      # Pi:       3.14 (width 10)
print(f"Pi: {pi:<10.2f}")     # Pi: 3.14       (left align)
print(f"Pi: {pi:^10.2f}")     # Pi:   3.14     (center)

# Integer formatting
number = 42
print(f"Binary: {number:b}")   # Binary: 101010
print(f"Hex: {number:x}")      # Hex: 2a
print(f"Octal: {number:o}")    # Octal: 52
print(f"Zero-padded: {number:05d}")  # Zero-padded: 00042

# Percentage
ratio = 0.857
print(f"Success rate: {ratio:.1%}")  # Success rate: 85.7%
```

## Type Conversion (Casting)

### Basic Type Conversions

```python
# To string
number = 42
text = str(number)
print(f"'{text}' is type {type(text)}")

# To integer
text = "123"
number = int(text)
print(f"{number} is type {type(number)}")

# To float
text = "3.14"
decimal = float(text)
print(f"{decimal} is type {type(decimal)}")

# To boolean
print(bool(1))     # True
print(bool(0))     # False
print(bool(""))    # False
print(bool("hi"))  # True
```

### Advanced Conversions

```python
# List conversions
text = "hello"
letters = list(text)
print(letters)  # ['h', 'e', 'l', 'l', 'o']

numbers = [1, 2, 3, 4, 5]
text = ''.join(map(str, numbers))
print(text)  # "12345"

# Tuple conversions
my_list = [1, 2, 3]
my_tuple = tuple(my_list)
print(my_tuple)  # (1, 2, 3)

# Set conversions (removes duplicates)
numbers = [1, 2, 2, 3, 3, 3]
unique = list(set(numbers))
print(unique)  # [1, 2, 3]
```

### Safe Type Conversion

```python
def safe_int(value, default=0):
    """Safely convert to int with default value"""
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def safe_float(value, default=0.0):
    """Safely convert to float with default value"""
    try:
        return float(value)
    except (ValueError, TypeError):
        return default

# Usage
user_input = "not_a_number"
number = safe_int(user_input, -1)
print(number)  # -1

price = safe_float("19.99", 0.0)
print(price)   # 19.99
```

## Practical Examples

### Example 1: Calculator

```python
def calculator():
    print("Simple Calculator")
    print("Operations: +, -, *, /, %, **")
    
    while True:
        try:
            # Get first number
            num1 = float(input("Enter first number: "))
            
            # Get operation
            operation = input("Enter operation (+, -, *, /, %, **): ")
            if operation not in ['+', '-', '*', '/', '%', '**']:
                print("Invalid operation!")
                continue
            
            # Get second number
            num2 = float(input("Enter second number: "))
            
            # Perform calculation
            if operation == '+':
                result = num1 + num2
            elif operation == '-':
                result = num1 - num2
            elif operation == '*':
                result = num1 * num2
            elif operation == '/':
                if num2 == 0:
                    print("Error: Division by zero!")
                    continue
                result = num1 / num2
            elif operation == '%':
                result = num1 % num2
            elif operation == '**':
                result = num1 ** num2
            
            # Display result
            print(f"{num1} {operation} {num2} = {result}")
            
            # Ask if user wants to continue
            if input("Continue? (y/n): ").lower() != 'y':
                break
                
        except ValueError:
            print("Please enter valid numbers!")
        except Exception as e:
            print(f"An error occurred: {e}")

calculator()
```

### Example 2: User Registration

```python
def register_user():
    print("User Registration")
    
    # Get and validate name
    while True:
        name = input("Full name: ").strip()
        if len(name) >= 2 and name.replace(" ", "").isalpha():
            break
        print("Please enter a valid name (letters and spaces only)")
    
    # Get and validate age
    while True:
        try:
            age = int(input("Age: "))
            if 13 <= age <= 120:
                break
            print("Age must be between 13 and 120")
        except ValueError:
            print("Please enter a valid age")
    
    # Get and validate email
    while True:
        email = input("Email: ").strip().lower()
        if '@' in email and '.' in email:
            break
        print("Please enter a valid email address")
    
    # Get password
    import getpass
    while True:
        password = getpass.getpass("Password: ")
        if len(password) >= 8:
            confirm = getpass.getpass("Confirm password: ")
            if password == confirm:
                break
            print("Passwords don't match")
        else:
            print("Password must be at least 8 characters")
    
    # Display registration info
    print("\\nRegistration successful!")
    print(f"Name: {name}")
    print(f"Age: {age}")
    print(f"Email: {email}")
    print(f"Account type: {'Adult' if age >= 18 else 'Minor'}")

register_user()
```

### Example 3: Data Entry and Summary

```python
def data_collection():
    print("Student Grade Collection")
    students = []
    
    while True:
        print("\\n1. Add student")
        print("2. Show summary")
        print("3. Exit")
        
        choice = input("Choose option: ")
        
        if choice == '1':
            # Get student info
            name = input("Student name: ").strip().title()
            
            # Collect grades
            grades = []
            subjects = ["Math", "Science", "English", "History"]
            
            for subject in subjects:
                while True:
                    try:
                        grade = float(input(f"{subject} grade (0-100): "))
                        if 0 <= grade <= 100:
                            grades.append(grade)
                            break
                        print("Grade must be between 0 and 100")
                    except ValueError:
                        print("Please enter a valid grade")
            
            # Calculate average
            average = sum(grades) / len(grades)
            students.append({
                'name': name,
                'grades': grades,
                'average': average
            })
            
            print(f"Added {name} with average: {average:.1f}")
        
        elif choice == '2':
            if not students:
                print("No students added yet")
                continue
            
            print("\\nStudent Summary:")
            print("-" * 50)
            print(f"{'Name':<15} {'Average':<8} {'Grade'}")
            print("-" * 50)
            
            class_total = 0
            for student in students:
                avg = student['average']
                
                # Determine letter grade
                if avg >= 90:
                    letter = 'A'
                elif avg >= 80:
                    letter = 'B'
                elif avg >= 70:
                    letter = 'C'
                elif avg >= 60:
                    letter = 'D'
                else:
                    letter = 'F'
                
                print(f"{student['name']:<15} {avg:>5.1f}    {letter}")
                class_total += avg
            
            print("-" * 50)
            print(f"Class Average: {class_total / len(students):.1f}")
        
        elif choice == '3':
            break
        else:
            print("Invalid choice")

data_collection()
```

## Best Practices

1. **Always validate input**: Never trust user input
2. **Use descriptive prompts**: Make it clear what you expect
3. **Handle errors gracefully**: Use try-except for conversions
4. **Use f-strings**: Modern and readable string formatting
5. **Provide feedback**: Let users know what happened

Master input/output to create interactive programs that communicate effectively with users!
    ''',
    "is_free": True,
    "xp_reward": 30,
    "exercises": [
        {
            "id": "input-output",
            "title": "Build a Personal Budget Calculator",
            "type": "project",
            "instructions": '''Create a personal budget calculator that takes user input and provides formatted output.

Your calculator should:
1. Ask for monthly income (with validation)
2. Collect expense categories and amounts:
   - Housing, Food, Transportation, Entertainment, Savings
3. Validate all numeric inputs
4. Calculate total expenses and remaining budget
5. Display a formatted budget report with:
   - Each category amount and percentage of income
   - Total expenses and remaining budget
   - Budget status (over/under budget)
6. Use proper string formatting for currency display
7. Allow the user to run multiple calculations''',
            "starter_code": '''# Personal Budget Calculator

def get_income():
    """Get and validate monthly income"""
    pass

def get_expenses():
    """Get expense amounts for each category"""
    categories = ["Housing", "Food", "Transportation", "Entertainment", "Savings"]
    expenses = {}
    # Implement expense collection with validation
    return expenses

def calculate_budget(income, expenses):
    """Calculate budget totals and percentages"""
    pass

def display_report(income, expenses, total_expenses, remaining):
    """Display formatted budget report"""
    pass

# Main program
while True:
    print("Personal Budget Calculator")
    # Implement main program logic
    pass''',
            "solution": '''# Personal Budget Calculator

def get_income():
    """Get and validate monthly income"""
    while True:
        try:
            income = float(input("Enter your monthly income: $"))
            if income > 0:
                return income
            print("Income must be positive!")
        except ValueError:
            print("Please enter a valid number.")

def get_expenses():
    """Get expense amounts for each category"""
    categories = ["Housing", "Food", "Transportation", "Entertainment", "Savings"]
    expenses = {}
    
    print("\\nEnter your monthly expenses:")
    for category in categories:
        while True:
            try:
                amount = float(input(f"{category}: $"))
                if amount >= 0:
                    expenses[category] = amount
                    break
                print("Amount cannot be negative!")
            except ValueError:
                print("Please enter a valid number.")
    
    return expenses

def calculate_budget(income, expenses):
    """Calculate budget totals and percentages"""
    total_expenses = sum(expenses.values())
    remaining = income - total_expenses
    
    # Calculate percentages
    percentages = {}
    for category, amount in expenses.items():
        percentages[category] = (amount / income) * 100 if income > 0 else 0
    
    return total_expenses, remaining, percentages

def display_report(income, expenses, total_expenses, remaining, percentages):
    """Display formatted budget report"""
    print("\\n" + "="*50)
    print("           BUDGET REPORT")
    print("="*50)
    print(f"Monthly Income: ${income:>10,.2f}")
    print("-"*50)
    
    print("EXPENSES:")
    for category, amount in expenses.items():
        pct = percentages[category]
        print(f"{category:<15} ${amount:>8,.2f} ({pct:>5.1f}%)")
    
    print("-"*50)
    print(f"{'Total Expenses':<15} ${total_expenses:>8,.2f} ({(total_expenses/income)*100:>5.1f}%)")
    print(f"{'Remaining':<15} ${remaining:>8,.2f}")
    print("="*50)
    
    # Budget status
    if remaining >= 0:
        print(f"✓ You're UNDER budget by ${remaining:,.2f}")
        if remaining < income * 0.1:  # Less than 10% remaining
            print("⚠ Warning: You have very little left for unexpected expenses!")
    else:
        print(f"✗ You're OVER budget by ${abs(remaining):,.2f}")
        print("⚠ You need to reduce expenses or increase income!")
    
    # Savings check
    savings_pct = percentages.get("Savings", 0)
    if savings_pct >= 20:
        print("🌟 Excellent! You're saving 20% or more of your income.")
    elif savings_pct >= 10:
        print("👍 Good job saving 10% or more of your income.")
    else:
        print("💡 Consider increasing your savings to at least 10% of income.")

# Main program
def main():
    print("Welcome to the Personal Budget Calculator!")
    
    while True:
        print("\\n" + "="*30)
        print("  PERSONAL BUDGET CALCULATOR")
        print("="*30)
        
        # Get input
        income = get_income()
        expenses = get_expenses()
        
        # Calculate budget
        total_expenses, remaining, percentages = calculate_budget(income, expenses)
        
        # Display report
        display_report(income, expenses, total_expenses, remaining, percentages)
        
        # Continue or exit
        print("\\n" + "-"*30)
        choice = input("Calculate another budget? (y/n): ").lower()
        if choice not in ['y', 'yes']:
            print("Thank you for using the Budget Calculator!")
            break

if __name__ == "__main__":
    main()''',
            "test_cases": [
                {
                    "name": "Calculator uses input validation and formatting",
                    "input": "",
                    "expected_contains": ["input(", "float(", "f\"", "try:", "except"]
                }
            ],
            "xp_reward": 45,
            "hints": [
                "Use try-except blocks for input validation",
                "Use f-strings for currency formatting with :,.2f",
                "Calculate percentages as (amount/income) * 100",
                "Use string alignment in formatting: < > ^",
                "Validate that all inputs are positive numbers"
            ]
        }
    ]
}

# File Operations Lesson
FILE_OPERATIONS_LESSON = {
    "id": 11,
    "chapter": 5,
    "title": "File Operations: Reading and Writing Data",
    "slug": "file-operations",
    "content": '''
# File Operations: Reading and Writing Data

## Opening and Closing Files

### The open() Function

```python
# Basic file opening
file = open("data.txt", "r")  # Read mode
content = file.read()
file.close()  # Always close files!

# Better: Using with statement (recommended)
with open("data.txt", "r") as file:
    content = file.read()
# File automatically closes when exiting the with block
```

### File Modes

```python
# Reading modes
with open("file.txt", "r") as f:    # Read (default)
    content = f.read()

with open("file.txt", "rb") as f:   # Read binary
    data = f.read()

# Writing modes
with open("file.txt", "w") as f:    # Write (overwrites existing)
    f.write("Hello World")

with open("file.txt", "a") as f:    # Append (adds to end)
    f.write("More text")

with open("file.txt", "x") as f:    # Exclusive create (fails if exists)
    f.write("New file only")

# Read and write
with open("file.txt", "r+") as f:   # Read and write
    content = f.read()
    f.write("Additional text")
```

## Reading Files

### Reading Entire File

```python
# Read entire file as string
with open("story.txt", "r") as file:
    content = file.read()
    print(content)

# Read file with encoding
with open("international.txt", "r", encoding="utf-8") as file:
    content = file.read()
```

### Reading Line by Line

```python
# Read all lines into a list
with open("lines.txt", "r") as file:
    lines = file.readlines()
    for line in lines:
        print(line.strip())  # Remove newline characters

# Read one line at a time
with open("large_file.txt", "r") as file:
    line = file.readline()
    while line:
        print(line.strip())
        line = file.readline()

# Best: Iterate directly over file object
with open("data.txt", "r") as file:
    for line in file:
        print(line.strip())
```

### Safe File Reading

```python
def read_file_safely(filename):
    """Safely read a file with error handling"""
    try:
        with open(filename, "r") as file:
            return file.read()
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found")
        return None
    except PermissionError:
        print(f"Error: Permission denied for '{filename}'")
        return None
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

# Usage
content = read_file_safely("myfile.txt")
if content is not None:
    print(content)
```

## Writing Files

### Writing Text

```python
# Write string to file
text = "Hello, World!\\nThis is line 2"
with open("output.txt", "w") as file:
    file.write(text)

# Write multiple lines
lines = ["Line 1\\n", "Line 2\\n", "Line 3\\n"]
with open("lines.txt", "w") as file:
    file.writelines(lines)

# Using print() to write to file
with open("output.txt", "w") as file:
    print("Hello", file=file)
    print("World", file=file)
```

### Appending to Files

```python
# Add to existing file
with open("log.txt", "a") as file:
    file.write("New log entry\\n")

# Append with timestamp
from datetime import datetime

def log_message(message, filename="app.log"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(filename, "a") as file:
        file.write(f"[{timestamp}] {message}\\n")

# Usage
log_message("Application started")
log_message("User logged in")
```

## Working with CSV Files

### Reading CSV

```python
import csv

# Basic CSV reading
with open("data.csv", "r") as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        print(row)  # Each row is a list

# CSV with headers
with open("students.csv", "r") as file:
    csv_reader = csv.DictReader(file)
    for row in csv_reader:
        print(f"Name: {row['name']}, Grade: {row['grade']}")
```

### Writing CSV

```python
import csv

# Write basic CSV
data = [
    ["Name", "Age", "City"],
    ["Alice", 25, "New York"],
    ["Bob", 30, "Chicago"],
    ["Charlie", 35, "Los Angeles"]
]

with open("people.csv", "w", newline="") as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(data)

# Write CSV with DictWriter
students = [
    {"name": "Alice", "grade": 95, "subject": "Math"},
    {"name": "Bob", "grade": 87, "subject": "Science"},
    {"name": "Charlie", "grade": 92, "subject": "English"}
]

with open("grades.csv", "w", newline="") as file:
    fieldnames = ["name", "grade", "subject"]
    csv_writer = csv.DictWriter(file, fieldnames=fieldnames)
    
    csv_writer.writeheader()  # Write column headers
    csv_writer.writerows(students)
```

## Working with JSON Files

### Reading JSON

```python
import json

# Read JSON file
with open("data.json", "r") as file:
    data = json.load(file)
    print(data)

# Read JSON string
json_string = '{"name": "Alice", "age": 25, "city": "New York"}'
data = json.loads(json_string)
print(data["name"])  # Alice
```

### Writing JSON

```python
import json

# Python object to JSON file
data = {
    "students": [
        {"name": "Alice", "grade": 95},
        {"name": "Bob", "grade": 87}
    ],
    "class": "Python 101",
    "semester": "Fall 2024"
}

with open("class_data.json", "w") as file:
    json.dump(data, file, indent=2)

# Python object to JSON string
json_string = json.dumps(data, indent=2)
print(json_string)
```

## File and Directory Operations

### Working with Paths

```python
import os
from pathlib import Path

# Using os.path (older method)
file_path = os.path.join("data", "files", "document.txt")
if os.path.exists(file_path):
    print("File exists")

# Using pathlib (recommended, Python 3.4+)
file_path = Path("data") / "files" / "document.txt"
if file_path.exists():
    print("File exists")
    print(f"Size: {file_path.stat().st_size} bytes")
```

### Directory Operations

```python
import os
from pathlib import Path

# Create directories
os.makedirs("data/output", exist_ok=True)  # Create if doesn't exist

# Using pathlib
Path("data/backup").mkdir(parents=True, exist_ok=True)

# List directory contents
for file in os.listdir("data"):
    print(file)

# Using pathlib
data_dir = Path("data")
for file in data_dir.iterdir():
    if file.is_file():
        print(f"File: {file.name}")
    elif file.is_dir():
        print(f"Directory: {file.name}")
```

## Practical Examples

### Example 1: Contact Manager

```python
import json
from pathlib import Path

class ContactManager:
    def __init__(self, filename="contacts.json"):
        self.filename = filename
        self.contacts = self.load_contacts()
    
    def load_contacts(self):
        """Load contacts from JSON file"""
        if Path(self.filename).exists():
            try:
                with open(self.filename, "r") as file:
                    return json.load(file)
            except json.JSONDecodeError:
                print("Warning: Corrupted contacts file, starting fresh")
                return {}
        return {}
    
    def save_contacts(self):
        """Save contacts to JSON file"""
        try:
            with open(self.filename, "w") as file:
                json.dump(self.contacts, file, indent=2)
            return True
        except Exception as e:
            print(f"Error saving contacts: {e}")
            return False
    
    def add_contact(self, name, phone, email=""):
        """Add a new contact"""
        self.contacts[name] = {
            "phone": phone,
            "email": email
        }
        if self.save_contacts():
            print(f"Contact '{name}' added successfully")
        
    def get_contact(self, name):
        """Get contact information"""
        return self.contacts.get(name)
    
    def list_contacts(self):
        """List all contacts"""
        if not self.contacts:
            print("No contacts found")
            return
        
        print("\\nContacts:")
        print("-" * 40)
        for name, info in sorted(self.contacts.items()):
            print(f"Name: {name}")
            print(f"Phone: {info['phone']}")
            if info.get('email'):
                print(f"Email: {info['email']}")
            print("-" * 40)
    
    def delete_contact(self, name):
        """Delete a contact"""
        if name in self.contacts:
            del self.contacts[name]
            if self.save_contacts():
                print(f"Contact '{name}' deleted")
        else:
            print(f"Contact '{name}' not found")

# Usage
cm = ContactManager()
cm.add_contact("Alice Smith", "555-1234", "alice@email.com")
cm.add_contact("Bob Jones", "555-5678")
cm.list_contacts()
```

### Example 2: Expense Tracker

```python
import csv
from datetime import datetime
from pathlib import Path

class ExpenseTracker:
    def __init__(self, filename="expenses.csv"):
        self.filename = filename
        self.setup_file()
    
    def setup_file(self):
        """Create CSV file with headers if it doesn't exist"""
        if not Path(self.filename).exists():
            with open(self.filename, "w", newline="") as file:
                writer = csv.writer(file)
                writer.writerow(["Date", "Category", "Description", "Amount"])
    
    def add_expense(self, category, description, amount):
        """Add a new expense"""
        date = datetime.now().strftime("%Y-%m-%d")
        
        with open(self.filename, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([date, category, description, f"{amount:.2f}"])
        
        print(f"Added expense: ${amount:.2f} for {description}")
    
    def get_expenses(self, category=None):
        """Get expenses, optionally filtered by category"""
        expenses = []
        
        try:
            with open(self.filename, "r") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    if category is None or row["Category"].lower() == category.lower():
                        expenses.append({
                            "date": row["Date"],
                            "category": row["Category"],
                            "description": row["Description"],
                            "amount": float(row["Amount"])
                        })
        except FileNotFoundError:
            print("No expenses file found")
            
        return expenses
    
    def show_summary(self, month=None):
        """Show expense summary"""
        expenses = self.get_expenses()
        
        if month:
            # Filter by month (format: "2024-01")
            expenses = [e for e in expenses if e["date"].startswith(month)]
        
        if not expenses:
            print("No expenses found")
            return
        
        # Calculate totals by category
        categories = {}
        total = 0
        
        for expense in expenses:
            cat = expense["category"]
            amt = expense["amount"]
            categories[cat] = categories.get(cat, 0) + amt
            total += amt
        
        # Display summary
        period = f"for {month}" if month else "total"
        print(f"\\nExpense Summary {period}:")
        print("-" * 30)
        
        for category, amount in sorted(categories.items()):
            percentage = (amount / total) * 100
            print(f"{category:<15} ${amount:>8.2f} ({percentage:>5.1f}%)")
        
        print("-" * 30)
        print(f"{'TOTAL':<15} ${total:>8.2f}")
    
    def export_report(self, filename=None):
        """Export detailed report to file"""
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"expense_report_{timestamp}.txt"
        
        expenses = self.get_expenses()
        
        with open(filename, "w") as file:
            file.write("EXPENSE REPORT\\n")
            file.write("=" * 50 + "\\n")
            file.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n\\n")
            
            # Group by month
            monthly_data = {}
            for expense in expenses:
                month = expense["date"][:7]  # YYYY-MM
                if month not in monthly_data:
                    monthly_data[month] = []
                monthly_data[month].append(expense)
            
            # Write monthly summaries
            for month in sorted(monthly_data.keys()):
                file.write(f"\\n{month}\\n")
                file.write("-" * 20 + "\\n")
                
                month_total = 0
                for expense in monthly_data[month]:
                    file.write(f"{expense['date']} | {expense['category']:<12} | ")
                    file.write(f"{expense['description']:<20} | ${expense['amount']:>8.2f}\\n")
                    month_total += expense['amount']
                
                file.write(f"{'':>45} Total: ${month_total:>8.2f}\\n")
        
        print(f"Report exported to {filename}")

# Usage
tracker = ExpenseTracker()
tracker.add_expense("Food", "Lunch", 12.50)
tracker.add_expense("Transportation", "Gas", 45.00)
tracker.add_expense("Food", "Groceries", 67.30)
tracker.show_summary()
tracker.export_report()
```

## Best Practices

1. **Always use 'with' statements**: Ensures files are properly closed
2. **Handle exceptions**: File operations can fail
3. **Use appropriate encodings**: Specify encoding for text files
4. **Validate file paths**: Check if files exist before operations
5. **Use pathlib**: Modern way to handle file paths
6. **Close files explicitly**: If not using 'with' statements

Master file operations to create programs that persist and process data effectively!
    ''',
    "is_free": True,
    "xp_reward": 45,
    "exercises": [
        {
            "id": "file-operations",
            "title": "Build a Personal Journal App",
            "type": "project",
            "instructions": '''Create a personal journal application that saves entries to files.

Your journal app should:
1. Save journal entries with timestamps to a text file
2. Allow users to:
   - Write new entries
   - View all entries
   - Search entries by keyword
   - Export entries to different formats (txt, csv, json)
3. Handle file operations safely with error handling
4. Store entries with metadata (date, mood, tags)
5. Create backup copies of journal data
6. Use both text files and JSON for different features''',
            "starter_code": '''# Personal Journal App
import json
from datetime import datetime
from pathlib import Path

class Journal:
    def __init__(self, journal_dir="journal_data"):
        self.journal_dir = Path(journal_dir)
        self.setup_directory()
        # Initialize your journal system
    
    def setup_directory(self):
        """Create journal directory if it doesn't exist"""
        pass
    
    def write_entry(self, title, content, mood="neutral", tags=None):
        """Write a new journal entry"""
        pass
    
    def view_entries(self, limit=10):
        """View recent journal entries"""
        pass
    
    def search_entries(self, keyword):
        """Search entries containing keyword"""
        pass
    
    def export_entries(self, format_type="txt"):
        """Export entries to different formats"""
        pass

# Main program
def main():
    journal = Journal()
    
    while True:
        print("\\nPersonal Journal")
        print("1. Write entry")
        print("2. View entries")
        print("3. Search entries")
        print("4. Export entries")
        print("5. Exit")
        
        choice = input("Choose option: ")
        # Implement menu logic

if __name__ == "__main__":
    main()''',
            "solution": '''# Personal Journal App
import json
import csv
from datetime import datetime
from pathlib import Path

class Journal:
    def __init__(self, journal_dir="journal_data"):
        self.journal_dir = Path(journal_dir)
        self.entries_file = self.journal_dir / "entries.json"
        self.setup_directory()
        self.entries = self.load_entries()
    
    def setup_directory(self):
        """Create journal directory if it doesn't exist"""
        self.journal_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        (self.journal_dir / "backups").mkdir(exist_ok=True)
        (self.journal_dir / "exports").mkdir(exist_ok=True)
    
    def load_entries(self):
        """Load entries from JSON file"""
        if self.entries_file.exists():
            try:
                with open(self.entries_file, "r", encoding="utf-8") as file:
                    return json.load(file)
            except json.JSONDecodeError:
                print("Warning: Corrupted journal file, starting fresh")
                self.backup_corrupted_file()
        return []
    
    def save_entries(self):
        """Save entries to JSON file with backup"""
        try:
            # Create backup first
            self.create_backup()
            
            # Save current entries
            with open(self.entries_file, "w", encoding="utf-8") as file:
                json.dump(self.entries, file, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Error saving journal: {e}")
            return False
    
    def create_backup(self):
        """Create backup of current journal"""
        if self.entries_file.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = self.journal_dir / "backups" / f"entries_backup_{timestamp}.json"
            
            try:
                import shutil
                shutil.copy2(self.entries_file, backup_file)
            except Exception as e:
                print(f"Warning: Could not create backup: {e}")
    
    def write_entry(self, title, content, mood="neutral", tags=None):
        """Write a new journal entry"""
        if tags is None:
            tags = []
        
        entry = {
            "id": len(self.entries) + 1,
            "timestamp": datetime.now().isoformat(),
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
            "title": title,
            "content": content,
            "mood": mood,
            "tags": tags,
            "word_count": len(content.split())
        }
        
        self.entries.append(entry)
        
        if self.save_entries():
            print(f"Entry '{title}' saved successfully!")
            
            # Also save as daily text file
            self.save_daily_text_entry(entry)
        else:
            print("Failed to save entry")
    
    def save_daily_text_entry(self, entry):
        """Save entry to daily text file"""
        daily_file = self.journal_dir / f"journal_{entry['date']}.txt"
        
        try:
            with open(daily_file, "a", encoding="utf-8") as file:
                file.write(f"\\n{'='*50}\\n")
                file.write(f"Time: {entry['time']}\\n")
                file.write(f"Title: {entry['title']}\\n")
                file.write(f"Mood: {entry['mood']}\\n")
                if entry['tags']:
                    file.write(f"Tags: {', '.join(entry['tags'])}\\n")
                file.write(f"{'='*50}\\n")
                file.write(f"{entry['content']}\\n")
        except Exception as e:
            print(f"Warning: Could not save daily text file: {e}")
    
    def view_entries(self, limit=10):
        """View recent journal entries"""
        if not self.entries:
            print("No journal entries found")
            return
        
        # Sort by timestamp (most recent first)
        sorted_entries = sorted(self.entries, 
                              key=lambda x: x['timestamp'], 
                              reverse=True)
        
        print(f"\\nShowing last {min(limit, len(sorted_entries))} entries:")
        print("=" * 60)
        
        for i, entry in enumerate(sorted_entries[:limit]):
            print(f"\\n[{i+1}] {entry['title']}")
            print(f"Date: {entry['date']} {entry['time']}")
            print(f"Mood: {entry['mood']} | Words: {entry['word_count']}")
            if entry['tags']:
                print(f"Tags: {', '.join(entry['tags'])}")
            
            # Show preview of content
            preview = entry['content'][:100]
            if len(entry['content']) > 100:
                preview += "..."
            print(f"Content: {preview}")
            print("-" * 40)
    
    def search_entries(self, keyword):
        """Search entries containing keyword"""
        keyword = keyword.lower()
        matches = []
        
        for entry in self.entries:
            # Search in title, content, and tags
            if (keyword in entry['title'].lower() or 
                keyword in entry['content'].lower() or
                any(keyword in tag.lower() for tag in entry['tags'])):
                matches.append(entry)
        
        if not matches:
            print(f"No entries found containing '{keyword}'")
            return
        
        print(f"\\nFound {len(matches)} entries containing '{keyword}':")
        print("=" * 50)
        
        for entry in sorted(matches, key=lambda x: x['timestamp'], reverse=True):
            print(f"\\n{entry['title']} - {entry['date']}")
            
            # Highlight keyword in content preview
            content_preview = entry['content'][:150]
            # Simple highlighting (in real app, could use colors)
            highlighted = content_preview.replace(keyword, f"**{keyword}**")
            print(f"...{highlighted}...")
            print("-" * 30)
    
    def get_statistics(self):
        """Get journal statistics"""
        if not self.entries:
            return {}
        
        total_entries = len(self.entries)
        total_words = sum(entry['word_count'] for entry in self.entries)
        
        # Mood distribution
        moods = {}
        for entry in self.entries:
            mood = entry['mood']
            moods[mood] = moods.get(mood, 0) + 1
        
        # Tags frequency
        tag_freq = {}
        for entry in self.entries:
            for tag in entry['tags']:
                tag_freq[tag] = tag_freq.get(tag, 0) + 1
        
        # Date range
        dates = [entry['date'] for entry in self.entries]
        date_range = f"{min(dates)} to {max(dates)}"
        
        return {
            'total_entries': total_entries,
            'total_words': total_words,
            'avg_words': total_words // total_entries,
            'moods': moods,
            'top_tags': sorted(tag_freq.items(), key=lambda x: x[1], reverse=True)[:5],
            'date_range': date_range
        }
    
    def export_entries(self, format_type="txt"):
        """Export entries to different formats"""
        if not self.entries:
            print("No entries to export")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        export_dir = self.journal_dir / "exports"
        
        if format_type.lower() == "txt":
            filename = export_dir / f"journal_export_{timestamp}.txt"
            self.export_to_txt(filename)
        elif format_type.lower() == "csv":
            filename = export_dir / f"journal_export_{timestamp}.csv"
            self.export_to_csv(filename)
        elif format_type.lower() == "json":
            filename = export_dir / f"journal_export_{timestamp}.json"
            self.export_to_json(filename)
        else:
            print("Unsupported format. Use txt, csv, or json")
            return
        
        print(f"Journal exported to {filename}")
    
    def export_to_txt(self, filename):
        """Export to text format"""
        with open(filename, "w", encoding="utf-8") as file:
            file.write("PERSONAL JOURNAL EXPORT\\n")
            file.write("=" * 50 + "\\n\\n")
            
            stats = self.get_statistics()
            file.write(f"Total Entries: {stats['total_entries']}\\n")
            file.write(f"Total Words: {stats['total_words']}\\n")
            file.write(f"Date Range: {stats['date_range']}\\n\\n")
            
            for entry in sorted(self.entries, key=lambda x: x['timestamp']):
                file.write(f"\\n{'='*60}\\n")
                file.write(f"Title: {entry['title']}\\n")
                file.write(f"Date: {entry['date']} {entry['time']}\\n")
                file.write(f"Mood: {entry['mood']}\\n")
                if entry['tags']:
                    file.write(f"Tags: {', '.join(entry['tags'])}\\n")
                file.write(f"{'='*60}\\n")
                file.write(f"{entry['content']}\\n")
    
    def export_to_csv(self, filename):
        """Export to CSV format"""
        with open(filename, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Time", "Title", "Content", "Mood", "Tags", "Word_Count"])
            
            for entry in self.entries:
                writer.writerow([
                    entry['date'],
                    entry['time'],
                    entry['title'],
                    entry['content'].replace('\\n', ' '),  # Remove newlines for CSV
                    entry['mood'],
                    ', '.join(entry['tags']),
                    entry['word_count']
                ])
    
    def export_to_json(self, filename):
        """Export to JSON format"""
        export_data = {
            "export_date": datetime.now().isoformat(),
            "statistics": self.get_statistics(),
            "entries": self.entries
        }
        
        with open(filename, "w", encoding="utf-8") as file:
            json.dump(export_data, file, indent=2, ensure_ascii=False)

# Main program
def main():
    journal = Journal()
    
    while True:
        print("\\n" + "="*40)
        print("        PERSONAL JOURNAL")
        print("="*40)
        print("1. Write new entry")
        print("2. View recent entries")
        print("3. Search entries")
        print("4. View statistics")
        print("5. Export journal")
        print("6. Exit")
        
        choice = input("\\nChoose option (1-6): ")
        
        if choice == "1":
            print("\\n--- New Journal Entry ---")
            title = input("Entry title: ").strip()
            if not title:
                print("Title cannot be empty")
                continue
            
            print("Enter your content (press Enter twice to finish):")
            content_lines = []
            empty_lines = 0
            while True:
                line = input()
                if line == "":
                    empty_lines += 1
                    if empty_lines >= 2:
                        break
                else:
                    empty_lines = 0
                content_lines.append(line)
            
            content = "\\n".join(content_lines).strip()
            if not content:
                print("Content cannot be empty")
                continue
            
            mood = input("Mood (happy/sad/neutral/excited/anxious): ").strip().lower()
            if not mood:
                mood = "neutral"
            
            tags_input = input("Tags (comma-separated): ").strip()
            tags = [tag.strip() for tag in tags_input.split(",") if tag.strip()]
            
            journal.write_entry(title, content, mood, tags)
        
        elif choice == "2":
            try:
                limit = int(input("Number of entries to show (default 10): ") or "10")
                journal.view_entries(limit)
            except ValueError:
                journal.view_entries()
        
        elif choice == "3":
            keyword = input("Enter search keyword: ").strip()
            if keyword:
                journal.search_entries(keyword)
            else:
                print("Please enter a keyword to search")
        
        elif choice == "4":
            stats = journal.get_statistics()
            if stats:
                print("\\n--- JOURNAL STATISTICS ---")
                print(f"Total Entries: {stats['total_entries']}")
                print(f"Total Words: {stats['total_words']}")
                print(f"Average Words per Entry: {stats['avg_words']}")
                print(f"Date Range: {stats['date_range']}")
                
                print("\\nMood Distribution:")
                for mood, count in stats['moods'].items():
                    print(f"  {mood}: {count}")
                
                if stats['top_tags']:
                    print("\\nTop Tags:")
                    for tag, count in stats['top_tags']:
                        print(f"  {tag}: {count}")
            else:
                print("No statistics available")
        
        elif choice == "5":
            format_type = input("Export format (txt/csv/json): ").strip().lower()
            if format_type in ["txt", "csv", "json"]:
                journal.export_entries(format_type)
            else:
                print("Invalid format. Using txt format.")
                journal.export_entries("txt")
        
        elif choice == "6":
            print("Thank you for using Personal Journal!")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()''',
            "test_cases": [
                {
                    "name": "Journal uses file operations correctly",
                    "input": "",
                    "expected_contains": ["with open", "json.dump", "json.load", "Path", "exists()"]
                }
            ],
            "xp_reward": 70,
            "hints": [
                "Use pathlib.Path for file path operations",
                "Save entries in JSON format for structured data",
                "Use 'with open' statements for safe file handling",
                "Create backup copies before saving new data",
                "Handle file exceptions with try-except blocks"
            ]
        }
    ]
}