"""
User management for CLI application
"""

import sqlite3
import hashlib
import json
from datetime import datetime, timedelta
from cli.config import Config

class UserManager:
    def __init__(self):
        self.config = Config()
    
    def hash_password(self, password):
        """Hash password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register(self, username, email, password):
        """Register a new user"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        try:
            password_hash = self.hash_password(password)
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, last_active)
                VALUES (?, ?, ?, ?)
            ''', (username, email, password_hash, datetime.now().isoformat()))
            
            user_id = cursor.lastrowid
            conn.commit()
            
            # Return user data
            user = {
                'id': user_id,
                'username': username,
                'email': email,
                'xp': 10,  # Starting XP
                'level': 1
            }
            
            # Award welcome achievement
            self.add_achievement(user_id, 'welcome')
            
            conn.close()
            return user
            
        except sqlite3.IntegrityError:
            conn.close()
            return None
    
    def login(self, username, password):
        """Authenticate user"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        password_hash = self.hash_password(password)
        cursor.execute('''
            SELECT id, username, email, total_xp, level 
            FROM users 
            WHERE username = ? AND password_hash = ?
        ''', (username, password_hash))
        
        result = cursor.fetchone()
        
        if result:
            user_id, username, email, total_xp, level = result
            
            # Update last active
            cursor.execute('''
                UPDATE users SET last_active = ? WHERE id = ?
            ''', (datetime.now().isoformat(), user_id))
            conn.commit()
            
            user = {
                'id': user_id,
                'username': username,
                'email': email,
                'xp': total_xp,
                'level': level
            }
            
            conn.close()
            return user
        
        conn.close()
        return None
    
    def user_exists(self, username_or_email):
        """Check if a user exists by username or email"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id FROM users 
            WHERE username = ? OR email = ?
        ''', (username_or_email, username_or_email))
        
        result = cursor.fetchone()
        conn.close()
        
        return result is not None
    
    def get_user_stats(self, user_id):
        """Get comprehensive user statistics"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Get user basic info
        cursor.execute('''
            SELECT total_xp, level, streak_days, last_active
            FROM users WHERE id = ?
        ''', (user_id,))
        
        user_data = cursor.fetchone()
        if not user_data:
            conn.close()
            return {}
        
        total_xp, level, streak_days, last_active = user_data
        
        # Get lessons completed
        cursor.execute('''
            SELECT COUNT(*) FROM user_progress 
            WHERE user_id = ? AND is_completed = TRUE
        ''', (user_id,))
        lessons_completed = cursor.fetchone()[0]
        
        # Get exercises completed
        cursor.execute('''
            SELECT COUNT(*) FROM exercise_submissions 
            WHERE user_id = ? AND is_correct = TRUE
        ''', (user_id,))
        exercises_completed = cursor.fetchone()[0]
        
        # Get courses in progress
        cursor.execute('''
            SELECT COUNT(DISTINCT course_slug) FROM user_progress 
            WHERE user_id = ?
        ''', (user_id,))
        courses_in_progress = cursor.fetchone()[0]
        
        # Get total time spent (in minutes)
        cursor.execute('''
            SELECT SUM(time_spent) FROM user_progress 
            WHERE user_id = ?
        ''', (user_id,))
        total_time = cursor.fetchone()[0] or 0
        
        # Calculate current streak
        streak = self.calculate_streak(user_id)
        
        conn.close()
        
        return {
            'total_xp': total_xp,
            'level': level,
            'streak_days': streak,
            'lessons_completed': lessons_completed,
            'exercises_completed': exercises_completed,
            'courses_in_progress': courses_in_progress,
            'total_time_spent': total_time // 60,  # Convert to minutes
            'last_active': last_active
        }
    
    def calculate_streak(self, user_id):
        """Calculate current learning streak"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Get recent activity (completed lessons/exercises)
        cursor.execute('''
            SELECT DATE(completed_at) as activity_date
            FROM user_progress 
            WHERE user_id = ? AND is_completed = TRUE
            UNION
            SELECT DATE(submitted_at) as activity_date
            FROM exercise_submissions
            WHERE user_id = ? AND is_correct = TRUE
            ORDER BY activity_date DESC
        ''', (user_id, user_id))
        
        dates = [row[0] for row in cursor.fetchall()]
        
        if not dates:
            conn.close()
            return 0
        
        # Calculate consecutive days
        streak = 0
        today = datetime.now().date()
        check_date = today
        
        unique_dates = list(set(dates))
        unique_dates.sort(reverse=True)
        
        for date_str in unique_dates:
            activity_date = datetime.fromisoformat(date_str).date()
            
            if activity_date == check_date:
                streak += 1
                check_date -= timedelta(days=1)
            elif activity_date == check_date + timedelta(days=1):
                # Allow for today if we haven't done anything today yet
                streak += 1
                check_date -= timedelta(days=1)
            else:
                break
        
        # Update streak in database
        cursor.execute('''
            UPDATE users SET streak_days = ? WHERE id = ?
        ''', (streak, user_id))
        conn.commit()
        conn.close()
        
        return streak
    
    def get_recent_activity(self, user_id, limit=10):
        """Get recent user activity"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Get recent completions
        cursor.execute('''
            SELECT 
                'lesson' as type,
                lesson_slug as item,
                completed_at as date,
                10 as xp
            FROM user_progress 
            WHERE user_id = ? AND is_completed = TRUE
            
            UNION ALL
            
            SELECT 
                'exercise' as type,
                exercise_id as item,
                submitted_at as date,
                xp_earned as xp
            FROM exercise_submissions
            WHERE user_id = ? AND is_correct = TRUE
            
            ORDER BY date DESC
            LIMIT ?
        ''', (user_id, user_id, limit))
        
        activities = []
        for row in cursor.fetchall():
            activity_type, item, date, xp = row
            
            # Format the activity description
            if activity_type == 'lesson':
                description = f"Completed lesson: {item.replace('-', ' ').title()}"
            else:
                description = f"Solved exercise: {item.replace('-', ' ').title()}"
            
            activities.append({
                'type': activity_type,
                'description': description,
                'date': datetime.fromisoformat(date).strftime('%Y-%m-%d'),
                'xp': xp
            })
        
        conn.close()
        return activities
    
    def add_xp(self, user_id, amount):
        """Add XP to user and update level"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Get current XP
        cursor.execute('SELECT total_xp FROM users WHERE id = ?', (user_id,))
        current_xp = cursor.fetchone()[0]
        
        new_xp = current_xp + amount
        new_level = (new_xp // 100) + 1
        
        cursor.execute('''
            UPDATE users 
            SET total_xp = ?, level = ?, last_active = ?
            WHERE id = ?
        ''', (new_xp, new_level, datetime.now().isoformat(), user_id))
        
        conn.commit()
        conn.close()
        
        return new_xp, new_level
    
    def add_achievement(self, user_id, achievement_slug):
        """Add achievement to user"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Check if user already has this achievement
        cursor.execute('''
            SELECT id FROM user_achievements 
            WHERE user_id = ? AND achievement_slug = ?
        ''', (user_id, achievement_slug))
        
        if not cursor.fetchone():
            cursor.execute('''
                INSERT INTO user_achievements (user_id, achievement_slug)
                VALUES (?, ?)
            ''', (user_id, achievement_slug))
            conn.commit()
        
        conn.close()
    
    def get_user_profile(self, user_id):
        """Get detailed user profile"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT username, email, bio, github_username, linkedin_url,
                   total_xp, level, streak_days, created_at
            FROM users WHERE id = ?
        ''', (user_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'username': result[0],
                'email': result[1],
                'bio': result[2],
                'github_username': result[3],
                'linkedin_url': result[4],
                'total_xp': result[5],
                'level': result[6],
                'streak_days': result[7],
                'member_since': result[8]
            }
        
        return None
    
    def update_profile(self, user_id, bio=None, github_username=None, linkedin_url=None):
        """Update user profile"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        updates = []
        values = []
        
        if bio is not None:
            updates.append('bio = ?')
            values.append(bio)
        
        if github_username is not None:
            updates.append('github_username = ?')
            values.append(github_username)
        
        if linkedin_url is not None:
            updates.append('linkedin_url = ?')
            values.append(linkedin_url)
        
        if updates:
            values.append(user_id)
            query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
            cursor.execute(query, values)
            conn.commit()
        
        conn.close()