"""
Configuration and database setup for CLI application
"""

import sqlite3
import json
import os
import platform
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

class Config:
    def __init__(self):
        self.app_dir = self.get_config_directory()
        self.db_path = self.app_dir / "boots.db"
        self.config_path = self.app_dir / "config.json"
        self.session_dir = self.app_dir / "sessions"
        self.cache_dir = self.app_dir / "cache"
        
        # Create app directories if they don't exist
        self.app_dir.mkdir(exist_ok=True)
        self.session_dir.mkdir(exist_ok=True)
        self.cache_dir.mkdir(exist_ok=True)
        
        # Initialize database and config
        self.init_database()
        self.init_config()
    
    def get_config_directory(self) -> Path:
        """Get platform-appropriate config directory"""
        system = platform.system()
        
        if system == "Windows":
            # Use AppData on Windows
            return Path(os.getenv("APPDATA", "~")) / "TypeQuest"
        elif system == "Darwin":  # macOS
            # Use Application Support on macOS
            return Path("~/Library/Application Support/TypeQuest").expanduser()
        else:  # Linux and others
            # Use XDG config directory
            xdg_config = os.getenv("XDG_CONFIG_HOME", "~/.config")
            return Path(xdg_config).expanduser() / "boots"
    
    def init_database(self):
        """Initialize SQLite database with tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                total_xp INTEGER DEFAULT 10,
                level INTEGER DEFAULT 1,
                streak_days INTEGER DEFAULT 0,
                last_active TEXT,
                bio TEXT DEFAULT '',
                github_username TEXT DEFAULT '',
                linkedin_url TEXT DEFAULT '',
                subscription_tier TEXT DEFAULT 'free',
                subscription_expires_at TEXT,
                cloud_sync_enabled BOOLEAN DEFAULT TRUE
            )
        ''')
        
        # User progress table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                course_slug TEXT,
                lesson_slug TEXT,
                is_completed BOOLEAN DEFAULT FALSE,
                completed_at TEXT,
                time_spent INTEGER DEFAULT 0,
                last_synced_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Exercise submissions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS exercise_submissions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                exercise_id TEXT,
                code TEXT,
                is_correct BOOLEAN DEFAULT FALSE,
                xp_earned INTEGER DEFAULT 0,
                submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
                hints_used INTEGER DEFAULT 0,
                last_synced_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Achievements table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                achievement_slug TEXT,
                earned_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_synced_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Daily challenges table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily_challenges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                date TEXT,
                completed BOOLEAN DEFAULT FALSE,
                completed_at TEXT,
                xp_earned INTEGER DEFAULT 0,
                last_synced_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Learning goals table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                target_date TEXT,
                is_completed BOOLEAN DEFAULT FALSE,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_synced_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Auth tokens table for cloud sync
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS auth_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                access_token TEXT,
                refresh_token TEXT,
                expires_at TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Sync metadata table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sync_metadata (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                table_name TEXT,
                last_sync_timestamp TEXT,
                sync_status TEXT DEFAULT 'pending'
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def init_config(self):
        """Initialize configuration file"""
        default_config = {
            "app_version": "1.0.0",
            "theme": "dark",
            "auto_save": True,
            "sound_enabled": False,
            "notifications": True,
            "typewriter_speed": "normal",
            "default_dataset": "company_db",
            "cloud_sync": {
                "enabled": True,
                "auto_sync": True,
                "sync_interval": 300  # 5 minutes
            },
            "api": {
                "base_url": "https://api.boots.dev",
                "timeout": 10
            },
            "features": {
                "ai_assistant": True,
                "leaderboard": True,
                "social_features": True
            }
        }
        
        if not self.config_path.exists():
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
    
    def get_config(self) -> Dict[str, Any]:
        """Get configuration settings"""
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.init_config()
            return self.get_config()
    
    def update_config(self, key: str, value: Any):
        """Update a configuration setting"""
        config = self.get_config()
        
        # Support nested keys like "cloud_sync.enabled"
        if '.' in key:
            keys = key.split('.')
            current = config
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = current[k]
            current[keys[-1]] = value
        else:
            config[key] = value
        
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)
    
    def get_config_value(self, key: str, default: Any = None) -> Any:
        """Get a specific configuration value"""
        config = self.get_config()
        
        if '.' in key:
            keys = key.split('.')
            current = config
            for k in keys:
                if isinstance(current, dict) and k in current:
                    current = current[k]
                else:
                    return default
            return current
        
        return config.get(key, default)
    
    def get_db_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    def get_version(self) -> str:
        """Get application version"""
        try:
            from . import __version__
            return __version__
        except ImportError:
            return self.get_config_value("app_version", "1.0.0")
    
    def init_app_directory(self):
        """Initialize application directory structure"""
        # Already done in __init__, but useful for testing
        self.app_dir.mkdir(exist_ok=True)
        self.session_dir.mkdir(exist_ok=True)
        self.cache_dir.mkdir(exist_ok=True)