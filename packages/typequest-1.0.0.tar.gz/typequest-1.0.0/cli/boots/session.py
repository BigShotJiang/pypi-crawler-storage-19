"""
Session management and persistence for CLI application
"""

import json
import uuid
import os
import sqlite3
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List
from rich.console import Console

console = Console()

class SessionManager:
    """Manage CLI sessions and state persistence"""
    
    def __init__(self, config=None):
        self.config = config
        self.current_session_id = None
        self.session_data = {}
        self.session_lock = threading.RLock()
        
        if self.config:
            self.session_dir = self.config.app_dir / "sessions"
            self.current_session_file = self.config.app_dir / "current_session.json"
            self.session_dir.mkdir(exist_ok=True)
            
            # Load or create session
            self._initialize_session()
    
    def _initialize_session(self):
        """Initialize session on startup"""
        
        # Try to load existing session
        existing_session = self._load_current_session()
        
        if existing_session and self._is_session_valid(existing_session):
            self.current_session_id = existing_session["id"]
            self.session_data = existing_session
            self._update_session_access_time()
        else:
            # Create new session
            self.create_new_session()
    
    def create_new_session(self) -> str:
        """Create a new session"""
        
        with self.session_lock:
            session_id = str(uuid.uuid4())
            
            self.session_data = {
                "id": session_id,
                "created_at": datetime.now().isoformat(),
                "last_accessed": datetime.now().isoformat(),
                "user_id": None,
                "organization_id": None,
                "current_course": None,
                "current_lesson": None,
                "progress": {},
                "preferences": self._get_default_preferences(),
                "command_history": [],
                "learning_session": {
                    "start_time": None,
                    "end_time": None,
                    "total_time": 0,
                    "lessons_completed": 0,
                    "exercises_completed": 0,
                    "xp_earned": 0
                },
                "device_info": self._get_device_info(),
                "cli_version": self._get_cli_version()
            }
            
            self.current_session_id = session_id
            self._save_session()
            self._update_current_session_pointer()
            
            return session_id
    
    def get_current_session(self) -> Optional[Dict[str, Any]]:
        """Get current session data"""
        
        with self.session_lock:
            if self.session_data:
                return self.session_data.copy()
            else:
                return self._load_current_session()
    
    def update_session(self, updates: Dict[str, Any]) -> None:
        """Update current session with new data"""
        
        with self.session_lock:
            if not self.session_data:
                self.create_new_session()
            
            # Deep merge updates
            self._deep_merge_dict(self.session_data, updates)
            self.session_data["last_accessed"] = datetime.now().isoformat()
            
            self._save_session()
    
    def set_user_context(self, user_id: str, organization_id: Optional[str] = None):
        """Set user context for session"""
        
        updates = {
            "user_id": user_id,
            "organization_id": organization_id
        }
        
        self.update_session(updates)
    
    def start_learning_session(self, course_slug: str, lesson_slug: str):
        """Start a learning session"""
        
        updates = {
            "current_course": course_slug,
            "current_lesson": lesson_slug,
            "learning_session": {
                "start_time": datetime.now().isoformat(),
                "end_time": None,
                "lessons_completed": 0,
                "exercises_completed": 0,
                "xp_earned": 0
            }
        }
        
        self.update_session(updates)
    
    def end_learning_session(self) -> Dict[str, Any]:
        """End current learning session and return statistics"""
        
        session = self.get_current_session()
        if not session or not session.get("learning_session", {}).get("start_time"):
            return {}
        
        # Calculate session statistics
        start_time = datetime.fromisoformat(session["learning_session"]["start_time"])
        end_time = datetime.now()
        session_duration = (end_time - start_time).total_seconds()
        
        session_stats = {
            "duration": session_duration,
            "lessons_completed": session.get("learning_session", {}).get("lessons_completed", 0),
            "exercises_completed": session.get("learning_session", {}).get("exercises_completed", 0),
            "xp_earned": session.get("learning_session", {}).get("xp_earned", 0),
            "course": session.get("current_course"),
            "lesson": session.get("current_lesson")
        }
        
        # Update session
        updates = {
            "learning_session": {
                **session.get("learning_session", {}),
                "end_time": end_time.isoformat(),
                "total_time": session_duration
            },
            "current_course": None,
            "current_lesson": None
        }
        
        self.update_session(updates)
        
        # Store session statistics in database
        self._store_session_statistics(session_stats)
        
        return session_stats
    
    def record_lesson_completion(self, lesson_slug: str, xp_earned: int = 0):
        """Record lesson completion in current session"""
        
        session = self.get_current_session()
        learning_session = session.get("learning_session", {})
        
        updates = {
            "learning_session": {
                **learning_session,
                "lessons_completed": learning_session.get("lessons_completed", 0) + 1,
                "xp_earned": learning_session.get("xp_earned", 0) + xp_earned
            }
        }
        
        self.update_session(updates)
    
    def record_exercise_completion(self, exercise_id: str, xp_earned: int = 0):
        """Record exercise completion in current session"""
        
        session = self.get_current_session()
        learning_session = session.get("learning_session", {})
        
        updates = {
            "learning_session": {
                **learning_session,
                "exercises_completed": learning_session.get("exercises_completed", 0) + 1,
                "xp_earned": learning_session.get("xp_earned", 0) + xp_earned
            }
        }
        
        self.update_session(updates)
    
    def add_command_to_history(self, command: str, result: str = "", success: bool = True) -> None:
        """Add command to session history"""
        
        history_entry = {
            "timestamp": datetime.now().isoformat(),
            "command": command,
            "result": result[:500] if result else "",  # Truncate long results
            "success": success
        }
        
        session = self.get_current_session()
        command_history = session.get("command_history", [])
        command_history.append(history_entry)
        
        # Keep only last 100 commands
        command_history = command_history[-100:]
        
        self.update_session({"command_history": command_history})
    
    def get_command_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent command history"""
        
        session = self.get_current_session()
        history = session.get("command_history", [])
        
        return history[-limit:] if limit else history
    
    def update_preferences(self, preferences: Dict[str, Any]):
        """Update user preferences"""
        
        session = self.get_current_session()
        current_prefs = session.get("preferences", {})
        current_prefs.update(preferences)
        
        self.update_session({"preferences": current_prefs})
    
    def get_preferences(self) -> Dict[str, Any]:
        """Get user preferences"""
        
        session = self.get_current_session()
        return session.get("preferences", self._get_default_preferences())
    
    def get_session_statistics(self, days: int = 30) -> Dict[str, Any]:
        """Get session statistics for the past N days"""
        
        if not self.config:
            return {}
        
        try:
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            # Create session statistics table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS session_statistics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    user_id TEXT,
                    start_time TEXT,
                    duration REAL,
                    lessons_completed INTEGER,
                    exercises_completed INTEGER,
                    xp_earned INTEGER,
                    course TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Get statistics for the past N days
            cutoff_date = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_sessions,
                    SUM(duration) as total_time,
                    SUM(lessons_completed) as total_lessons,
                    SUM(exercises_completed) as total_exercises,
                    SUM(xp_earned) as total_xp,
                    AVG(duration) as avg_session_time
                FROM session_statistics 
                WHERE created_at >= ?
            ''', (cutoff_date,))
            
            stats = cursor.fetchone()
            
            # Get daily breakdown
            cursor.execute('''
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as sessions,
                    SUM(duration) as time,
                    SUM(lessons_completed) as lessons,
                    SUM(exercises_completed) as exercises
                FROM session_statistics 
                WHERE created_at >= ?
                GROUP BY DATE(created_at)
                ORDER BY date DESC
                LIMIT ?
            ''', (cutoff_date, days))
            
            daily_stats = cursor.fetchall()
            
            # Get course breakdown
            cursor.execute('''
                SELECT 
                    course,
                    COUNT(*) as sessions,
                    SUM(duration) as time,
                    SUM(lessons_completed) as lessons
                FROM session_statistics 
                WHERE created_at >= ? AND course IS NOT NULL
                GROUP BY course
                ORDER BY time DESC
            ''', (cutoff_date,))
            
            course_stats = cursor.fetchall()
            
            conn.close()
            
            return {
                "period_days": days,
                "total": {
                    "sessions": stats[0] or 0,
                    "time": stats[1] or 0.0,
                    "lessons": stats[2] or 0,
                    "exercises": stats[3] or 0,
                    "xp": stats[4] or 0,
                    "avg_session_time": stats[5] or 0.0
                },
                "daily": [
                    {
                        "date": row[0],
                        "sessions": row[1],
                        "time": row[2],
                        "lessons": row[3],
                        "exercises": row[4]
                    }
                    for row in daily_stats
                ],
                "by_course": [
                    {
                        "course": row[0],
                        "sessions": row[1],
                        "time": row[2],
                        "lessons": row[3]
                    }
                    for row in course_stats
                ]
            }
            
        except Exception as e:
            console.print(f"[dim]Error getting session statistics: {e}[/dim]")
            return {}
    
    def cleanup_old_sessions(self, days_to_keep: int = 30):
        """Clean up old session files"""
        
        if not self.config:
            return
        
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            
            # Clean up session files
            for session_file in self.session_dir.glob("*.json"):
                try:
                    # Check file modification time
                    mod_time = datetime.fromtimestamp(session_file.stat().st_mtime)
                    
                    if mod_time < cutoff_date:
                        session_file.unlink()
                        
                except Exception:
                    continue
            
            # Clean up database session statistics
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                DELETE FROM session_statistics 
                WHERE created_at < ?
            ''', (cutoff_date.isoformat(),))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            console.print(f"[dim]Error cleaning up sessions: {e}[/dim]")
    
    def export_session_data(self, output_file: str) -> bool:
        """Export session data to JSON file"""
        
        try:
            session_data = self.get_current_session()
            statistics = self.get_session_statistics(90)  # 90 days of stats
            
            export_data = {
                "current_session": session_data,
                "statistics": statistics,
                "export_date": datetime.now().isoformat(),
                "cli_version": self._get_cli_version()
            }
            
            with open(output_file, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            return True
            
        except Exception as e:
            console.print(f"❌ Export failed: {e}")
            return False
    
    def _load_current_session(self) -> Optional[Dict[str, Any]]:
        """Load current session from file"""
        
        try:
            if not self.current_session_file.exists():
                return None
            
            with open(self.current_session_file, 'r') as f:
                session_pointer = json.load(f)
                session_id = session_pointer.get("current_session")
            
            if not session_id:
                return None
            
            session_file = self.session_dir / f"{session_id}.json"
            if not session_file.exists():
                return None
            
            with open(session_file, 'r') as f:
                return json.load(f)
                
        except (FileNotFoundError, json.JSONDecodeError, KeyError):
            return None
    
    def _save_session(self):
        """Save current session to file"""
        
        if not self.config or not self.session_data:
            return
        
        try:
            session_file = self.session_dir / f"{self.current_session_id}.json"
            with open(session_file, 'w') as f:
                json.dump(self.session_data, f, indent=2)
                
        except Exception as e:
            console.print(f"[dim]Warning: Could not save session: {e}[/dim]")
    
    def _update_current_session_pointer(self):
        """Update current session pointer file"""
        
        try:
            with open(self.current_session_file, 'w') as f:
                json.dump({"current_session": self.current_session_id}, f)
                
        except Exception as e:
            console.print(f"[dim]Warning: Could not update session pointer: {e}[/dim]")
    
    def _update_session_access_time(self):
        """Update session access time"""
        
        if self.session_data:
            self.session_data["last_accessed"] = datetime.now().isoformat()
            self._save_session()
    
    def _is_session_valid(self, session: Dict[str, Any]) -> bool:
        """Check if session is still valid"""
        
        try:
            last_accessed = datetime.fromisoformat(session.get("last_accessed", ""))
            
            # Session expires after 7 days of inactivity
            expiry_time = timedelta(days=7)
            
            return datetime.now() - last_accessed < expiry_time
            
        except (ValueError, TypeError):
            return False
    
    def _store_session_statistics(self, session_stats: Dict[str, Any]):
        """Store session statistics in database"""
        
        if not self.config:
            return
        
        try:
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            # Create table if it doesn't exist
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS session_statistics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    user_id TEXT,
                    start_time TEXT,
                    duration REAL,
                    lessons_completed INTEGER,
                    exercises_completed INTEGER,
                    xp_earned INTEGER,
                    course TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            session = self.get_current_session()
            
            cursor.execute('''
                INSERT INTO session_statistics 
                (session_id, user_id, duration, lessons_completed, exercises_completed, xp_earned, course)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                self.current_session_id,
                session.get("user_id"),
                session_stats.get("duration", 0),
                session_stats.get("lessons_completed", 0),
                session_stats.get("exercises_completed", 0),
                session_stats.get("xp_earned", 0),
                session_stats.get("course")
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            console.print(f"[dim]Error storing session statistics: {e}[/dim]")
    
    def _get_default_preferences(self) -> Dict[str, Any]:
        """Get default user preferences"""
        
        return {
            "typewriter_speed": "normal",
            "sound_enabled": False,
            "notifications_enabled": True,
            "auto_save_progress": True,
            "theme": "dark",
            "language": "en",
            "timezone": "UTC",
            "difficulty_preference": "adaptive",
            "learning_reminders": True,
            "show_progress_animations": True,
            "compact_mode": False
        }
    
    def _get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        
        import platform
        
        return {
            "platform": platform.system(),
            "platform_version": platform.version(),
            "architecture": platform.architecture()[0],
            "python_version": platform.python_version(),
            "hostname": platform.node()
        }
    
    def _get_cli_version(self) -> str:
        """Get CLI version"""
        
        try:
            from . import __version__
            return __version__
        except ImportError:
            return "1.0.0"
    
    def _deep_merge_dict(self, target: Dict[str, Any], source: Dict[str, Any]):
        """Deep merge source dict into target dict"""
        
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_merge_dict(target[key], value)
            else:
                target[key] = value