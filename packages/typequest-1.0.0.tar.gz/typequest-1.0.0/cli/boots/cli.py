"""
Main CLI entry point - this is what gets called when user types 'boots'
"""

import sys
import os
from pathlib import Path

# Handle import paths
try:
    from .main import TypeQuestCLI
    from .config import Config
    from .utils.updater import check_for_updates_async
    from .utils.platform import get_platform_info
except ImportError:
    # Handle development mode
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from typequest.main import TypeQuestCLI
    from typequest.config import Config
    from typequest.utils.updater import check_for_updates_async
    from typequest.utils.platform import get_platform_info

def diagnose_installation():
    """Help users troubleshoot installation issues"""
    
    import shutil
    import subprocess
    from rich.console import Console
    from rich.panel import Panel
    
    console = Console()
    
    console.print("🔍 TypeQuest Installation Diagnostics", style="bold cyan")
    console.print("=" * 40)
    
    # Check if typequest command exists
    typequest_path = shutil.which("typequest")
    if typequest_path:
        console.print(f"✅ typequest command found at: {typequest_path}")
    else:
        console.print("❌ typequest command not found in PATH")
        
        # Suggest solutions
        console.print("\n💡 Try these solutions:")
        console.print("1. Restart your terminal")
        console.print("2. Run: pip install --user typequest-cli")
        console.print("3. Add Python Scripts directory to PATH")
    
    # Check Python installation
    python_path = sys.executable
    console.print(f"🐍 Python executable: {python_path}")
    
    # Check pip installation
    try:
        pip_path = shutil.which("pip")
        console.print(f"📦 pip command: {pip_path}")
    except:
        console.print("❌ pip not found")
    
    # Check if package is installed
    try:
        import typequest
        console.print(f"✅ typequest package found at: {typequest.__file__}")
        console.print(f"📊 Version: {typequest.__version__}")
    except ImportError:
        console.print("❌ typequest package not found")
        console.print("Run: pip install typequest-cli")
    
    # Platform information
    platform_info = get_platform_info()
    console.print(f"\n🖥️  Platform: {platform_info['system']} {platform_info['architecture']}")
    console.print(f"🐍 Python: {platform_info['python_version']}")

def show_help():
    """Show help information"""
    from rich.console import Console
    from rich.panel import Panel
    
    console = Console()
    
    help_text = """[bold cyan]TypeQuest - Interactive Coding Education Platform[/bold cyan]

[bold]Usage:[/bold]
  typequest                Start the interactive CLI
  typequest --help         Show this help message
  typequest --version      Show version information
  typequest --diagnose     Run installation diagnostics
  typequest --update       Check for and install updates
  
[bold]Examples:[/bold]
  typequest               Launch the main application
  typequest --update      Update to the latest version
  
[bold]Support:[/bold]
  🌐 Website: https://typequest.dev
  📚 Docs: https://docs.typequest.dev  
  🐛 Issues: https://github.com/typequest/cli/issues
  💬 Discord: https://discord.gg/typequest
"""
    
    console.print(Panel(help_text, border_style="cyan"))

def show_version():
    """Show version information"""
    from rich.console import Console
    
    console = Console()
    try:
        from . import __version__, __author__
        console.print(f"TypeQuest v{__version__}")
        console.print(f"By {__author__}")
    except ImportError:
        console.print("TypeQuest v1.0.0")
    
    platform_info = get_platform_info()
    console.print(f"Platform: {platform_info['system']} {platform_info['architecture']}")
    console.print(f"Python: {platform_info['python_version']}")

def main():
    """
    Main entry point for the typequest command
    This function gets called when user types 'typequest' in terminal
    """
    
    try:
        # Handle command line arguments
        if len(sys.argv) > 1:
            arg = sys.argv[1]
            
            if arg in ["--help", "-h"]:
                show_help()
                return
            elif arg in ["--version", "-v"]:
                show_version()
                return
            elif arg == "--diagnose":
                diagnose_installation()
                return
            elif arg == "--update":
                from .utils.updater import check_for_updates
                check_for_updates()
                return
            else:
                print(f"Unknown argument: {arg}")
                print("Run 'typequest --help' for usage information")
                return
        
        # Initialize configuration and directories
        config = Config()
        
        # Check for updates (non-blocking)
        check_for_updates_async()
        
        # Create and run the main application
        app = TypeQuestCLI()
        app.run()
        
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        print("\n👋 Thanks for using TypeQuest!")
        sys.exit(0)
        
    except Exception as e:
        # Handle unexpected errors
        print(f"❌ An unexpected error occurred: {e}")
        print("Please report this issue at: https://github.com/typequest/cli/issues")
        print("\nRun 'typequest --diagnose' for troubleshooting help")
        sys.exit(1)

if __name__ == "__main__":
    main()