"""
TypeQuest API Client for CLI
Handles authenticated requests to the TypeQuest service
"""

import requests
import time
from typing import Dict, Any, Optional, List
from rich.console import Console

console = Console()

class TypeQuestAPIClient:
    """Client for making authenticated requests to TypeQuest service"""
    
    def __init__(self, auth_instance):
        """
        Initialize with authentication instance
        
        Args:
            auth_instance: BootsAuth instance for getting tokens
        """
        self.auth = auth_instance
        self.base_url = auth_instance.auth_config.api_base_url
        self.timeout = 10
        
    def _get_headers(self) -> Dict[str, str]:
        """Get headers for authenticated requests"""
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'TypeQuest-CLI/1.0.0'
        }
        
        access_token = self.auth.get_auth_token()
        if access_token:
            headers['Authorization'] = f'Bearer {access_token}'
        
        return headers
    
    def _handle_auth_error(self, response):
        """Handle authentication errors (401/403)"""
        if response.status_code == 401:
            # Try to refresh token
            if self.auth.refresh_token():
                return True  # Indicates retry should happen
            else:
                console.print("❌ [red]Authentication expired. Please login again.[/red]")
                return False
        elif response.status_code == 403:
            console.print("❌ [red]Permission denied. Check your account permissions.[/red]")
            return False
        return False
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """Make an authenticated request with retry logic"""
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers()
        
        # First attempt
        try:
            response = requests.request(
                method, url, 
                headers=headers, 
                timeout=self.timeout,
                **kwargs
            )
            
            # Handle auth errors
            if response.status_code in [401, 403]:
                if self._handle_auth_error(response):
                    # Retry with refreshed token
                    headers = self._get_headers()
                    response = requests.request(
                        method, url,
                        headers=headers,
                        timeout=self.timeout,
                        **kwargs
                    )
            
            return response
            
        except requests.RequestException as e:
            console.print(f"❌ [red]Network error: {e}[/red]")
            return None
    
    def get_user_profile(self) -> Optional[Dict[str, Any]]:
        """Get current user profile"""
        response = self._make_request('GET', '/auth/cli/status/')
        
        if response and response.status_code == 200:
            data = response.json()
            return data.get('user')
        return None
    
    def get_user_preferences(self) -> Dict[str, Any]:
        """Get user preferences"""
        response = self._make_request('GET', '/auth/cli/preferences/')
        
        if response and response.status_code == 200:
            data = response.json()
            return data.get('preferences', {})
        return {}
    
    def update_user_preferences(self, preferences: Dict[str, Any]) -> bool:
        """Update user preferences"""
        response = self._make_request(
            'PATCH', 
            '/auth/cli/preferences/',
            json=preferences
        )
        
        return response and response.status_code == 200
    
    def get_session_info(self) -> Optional[Dict[str, Any]]:
        """Get session information"""
        response = self._make_request('GET', '/auth/cli/session/')
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def validate_token(self) -> Dict[str, Any]:
        """Validate current access token"""
        response = self._make_request('POST', '/auth/cli/validate/')
        
        if response and response.status_code == 200:
            return response.json()
        return {'valid': False, 'error': 'Token validation failed'}
    
    def get_courses(self) -> List[Dict[str, Any]]:
        """Get available courses"""
        response = self._make_request('GET', '/api/courses/')
        
        if response and response.status_code == 200:
            data = response.json()
            return data.get('courses', [])
        return []
    
    def get_course_progress(self, course_id: str) -> Optional[Dict[str, Any]]:
        """Get progress for a specific course"""
        response = self._make_request('GET', f'/api/courses/{course_id}/progress/')
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def submit_exercise(self, exercise_id: str, code: str, language: str = 'sql') -> Dict[str, Any]:
        """Submit an exercise solution"""
        response = self._make_request(
            'POST',
            '/api/exercises/submit/',
            json={
                'exercise_id': exercise_id,
                'code': code,
                'language': language
            }
        )
        
        if response and response.status_code == 200:
            return response.json()
        elif response:
            error_data = response.json() if response.content else {}
            return {
                'success': False,
                'error': error_data.get('error', 'Submission failed')
            }
        return {'success': False, 'error': 'Network error'}
    
    def get_user_stats(self) -> Dict[str, Any]:
        """Get user statistics"""
        response = self._make_request('GET', '/api/users/stats/')
        
        if response and response.status_code == 200:
            return response.json()
        return {}
    
    def get_achievements(self) -> List[Dict[str, Any]]:
        """Get user achievements"""
        response = self._make_request('GET', '/api/users/achievements/')
        
        if response and response.status_code == 200:
            data = response.json()
            return data.get('achievements', [])
        return []
    
    def get_leaderboard(self, scope: str = 'global') -> List[Dict[str, Any]]:
        """Get leaderboard data"""
        response = self._make_request('GET', f'/api/leaderboard/?scope={scope}')
        
        if response and response.status_code == 200:
            data = response.json()
            return data.get('leaderboard', [])
        return []
    
    def sync_progress(self, progress_data: Dict[str, Any]) -> bool:
        """Sync local progress to server"""
        response = self._make_request(
            'POST',
            '/api/sync/progress/',
            json=progress_data
        )
        
        return response and response.status_code == 200
    
    def get_subscription_info(self) -> Optional[Dict[str, Any]]:
        """Get subscription information"""
        response = self._make_request('GET', '/api/subscription/')
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def check_service_health(self) -> bool:
        """Check if the service is healthy"""
        try:
            response = requests.get(
                f"{self.base_url}/auth/cli/health/",
                timeout=5
            )
            return response.status_code == 200
        except requests.RequestException:
            return False
    
    def get_course_by_slug(self, course_slug: str) -> Optional[Dict[str, Any]]:
        """Get course details by slug"""
        response = self._make_request('GET', f'/api/courses/{course_slug}/')
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def get_lesson(self, course_slug: str, lesson_slug: str) -> Optional[Dict[str, Any]]:
        """Get lesson details"""
        response = self._make_request(
            'GET', 
            f'/api/courses/{course_slug}/lessons/{lesson_slug}/'
        )
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def mark_lesson_complete(self, course_slug: str, lesson_slug: str) -> bool:
        """Mark a lesson as complete"""
        response = self._make_request(
            'POST',
            f'/api/courses/{course_slug}/lessons/{lesson_slug}/complete/',
            json={'completed': True}
        )
        
        return response and response.status_code == 200
    
    def get_next_lesson(self, course_slug: str) -> Optional[Dict[str, Any]]:
        """Get the next lesson in a course"""
        response = self._make_request(
            'GET', 
            f'/api/courses/{course_slug}/next-lesson/'
        )
        
        if response and response.status_code == 200:
            return response.json()
        return None
    
    def record_session_activity(self, session_data: Dict[str, Any]) -> bool:
        """Record learning session activity"""
        response = self._make_request(
            'POST',
            '/api/sessions/activity/',
            json=session_data
        )
        
        return response and response.status_code == 200


class TypeQuestAPIError(Exception):
    """Custom exception for API errors"""
    
    def __init__(self, message: str, status_code: Optional[int] = None, response_data: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data or {}