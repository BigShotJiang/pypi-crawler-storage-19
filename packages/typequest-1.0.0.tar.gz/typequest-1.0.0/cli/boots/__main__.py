"""
Allow running boots as a module: python -m boots
"""

from .cli import main

if __name__ == "__main__":
    main()