"""
Auth0-based authentication service for TypeQuest
Supports both individual users and organizations
"""

import requests
import jwt
import json
import time
import webbrowser
import socket
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Union, List
from urllib.parse import urlencode, parse_qs, urlparse
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
import uuid
import hashlib

console = Console()

class TypeQuestSecurityError(Exception):
    """Security-related errors for TypeQuest authentication"""
    pass

class TypeQuestConfig:
    """TypeQuest service configuration settings with security validation"""
    
    # Allowed domains for TypeQuest API (security whitelist)
    ALLOWED_DOMAINS = {
        # Production domains
        "api.typequest.com",
        "typequest-service.onrender.com",
        "typequest-api.herokuapp.com",
        "typequest.railway.app",

        # Development domains (only for local development)
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
    }
    
    # Development-only domains (require explicit opt-in)
    DEV_DOMAINS = {
        "localhost",
        "127.0.0.1", 
        "0.0.0.0"
    }
    
    def __init__(self):
        import os
        
        # Get API URL from environment or use production default
        api_url = os.getenv("TYPEQUEST_API_URL", "https://typequest-service.onrender.com")
        
        # Validate API URL for security
        self.api_base_url = self._validate_and_set_api_url(api_url)
        self.scope = "openid profile email read:user_data write:user_data"
        
        # API endpoints
        self.cli_config_endpoint = f"{self.api_base_url}/auth/cli/config/"
        self.device_code_endpoint = f"{self.api_base_url}/auth/device/code/"
        self.device_token_endpoint = f"{self.api_base_url}/auth/device/token/"
        self.device_refresh_endpoint = f"{self.api_base_url}/auth/device/refresh/"
        self.device_activate_endpoint = f"{self.api_base_url}/auth/device/activate/"
        self.cli_status_endpoint = f"{self.api_base_url}/auth/cli/status/"
        self.cli_health_endpoint = f"{self.api_base_url}/auth/cli/health/"
        self.cli_validate_endpoint = f"{self.api_base_url}/auth/cli/validate/"
        self.cli_preferences_endpoint = f"{self.api_base_url}/auth/cli/preferences/"
        
        # Client ID will be fetched from service
        self._client_id = None
        self._config_fetched = False
    
    def _validate_and_set_api_url(self, api_url: str) -> str:
        """Validate API URL against security whitelist"""
        try:
            parsed = urlparse(api_url)
            domain = parsed.netloc
            
            # Remove port from domain for validation (e.g., localhost:8000 -> localhost)
            domain_without_port = domain.split(':')[0]
            
            # Check if domain is in allowed list
            if domain_without_port not in self.ALLOWED_DOMAINS:
                raise TypeQuestSecurityError(
                    f"Untrusted API domain: {domain}\n"
                    f"Allowed domains: {', '.join(sorted(self.ALLOWED_DOMAINS))}\n"
                    f"This protects against malicious API endpoints that could steal credentials."
                )
            
            # Additional security checks for HTTPS requirement
            if parsed.scheme == "http":
                # Only allow HTTP for localhost development
                if domain_without_port not in self.DEV_DOMAINS:
                    raise TypeQuestSecurityError(
                        f"HTTP not allowed for domain: {domain}\n"
                        f"Use HTTPS for production domains to protect credentials.\n"
                        f"HTTP only allowed for: {', '.join(sorted(self.DEV_DOMAINS))}"
                    )
                
                # Warn about HTTP usage
                console.print(f"[yellow]⚠️  Using HTTP for development: {api_url}[/yellow]")
                console.print("[dim]Note: Production should use HTTPS[/dim]")
            
            elif parsed.scheme == "https":
                # HTTPS is good, additional certificate validation could go here
                pass
            
            else:
                raise TypeQuestSecurityError(
                    f"Invalid URL scheme: {parsed.scheme}\n"
                    f"Only HTTP (localhost) and HTTPS are allowed."
                )
            
            console.print(f"[dim]✓ Validated API URL: {api_url}[/dim]")
            return api_url
            
        except TypeQuestSecurityError:
            raise  # Re-raise security errors
        except Exception as e:
            raise TypeQuestSecurityError(f"Invalid API URL format: {api_url} - {e}")
    
    @property
    def client_id(self) -> str:
        """Get client ID from service (cached)"""
        if not self._config_fetched:
            self._fetch_config()
        return self._client_id or "fallback-client-id"
    
    def _fetch_config(self):
        """Fetch configuration from TypeQuest service with validation"""
        try:
            import requests
            response = requests.get(self.cli_config_endpoint, timeout=5)
            
            if response.status_code == 200:
                config_data = response.json()
                
                # Validate response structure
                if not self._is_valid_config_response(config_data):
                    raise TypeQuestSecurityError("Invalid configuration response format")
                
                self._client_id = config_data.get('client_id', '')
                console.print(f"[dim]✓ Fetched CLI config from service[/dim]")
                
            else:
                console.print(f"[yellow]Warning: Could not fetch config from service (status: {response.status_code})[/yellow]")
                
        except TypeQuestSecurityError:
            console.print("[red]Security Error: Invalid configuration from service[/red]")
            raise
        except Exception as e:
            console.print(f"[yellow]Warning: Could not fetch config from service: {e}[/yellow]")
            console.print("[dim]Using fallback configuration[/dim]")
        finally:
            self._config_fetched = True
    
    def _is_valid_config_response(self, config_data: dict) -> bool:
        """Validate configuration response structure"""
        if not isinstance(config_data, dict):
            return False
        
        # Must contain client_id
        if 'client_id' not in config_data:
            return False
        
        # client_id should be a non-empty string
        client_id = config_data['client_id']
        if not isinstance(client_id, str) or not client_id.strip():
            return False
        
        # Optional: Additional validation of client_id format
        # Auth0 client IDs are typically alphanumeric with specific length
        if len(client_id) < 10:  # Basic sanity check
            return False
        
        return True

class TypeQuestAuthMixin:
    """
    Authentication mixin that provides auth functionality
    Can be used by different components of the CLI
    """
    
    def __init__(self):
        self.auth_config = TypeQuestConfig()
        self.config = None  # Will be injected
        self._current_user = None
        self._current_org = None
        self._auth_tokens = {}
        self._device_code = None
        
    def set_config(self, config):
        """Inject config dependency"""
        self.config = config
        self._load_stored_tokens()
    
    def is_logged_in(self) -> bool:
        """Check if user is currently authenticated"""
        token = self.get_auth_token()
        if not token:
            return False
        
        try:
            # Decode without verification for expiry check
            decoded = jwt.decode(token, options={"verify_signature": False})
            exp = decoded.get('exp', 0)
            
            # Check if token is expired (with 5-minute buffer)
            if exp < time.time() + 300:
                # Try to refresh token
                return self.refresh_token()
            
            return True
        except jwt.InvalidTokenError:
            return False
    
    def get_current_user(self) -> Optional[Dict[str, Any]]:
        """Get current authenticated user"""
        if not self._current_user and self.is_logged_in():
            self._current_user = self._fetch_user_profile()
        return self._current_user
    
    def get_current_organization(self) -> Optional[Dict[str, Any]]:
        """Get current user's organization if they belong to one"""
        if not self._current_org and self.is_logged_in():
            self._current_org = self._fetch_user_organization()
        return self._current_org
    
    def get_auth_token(self) -> Optional[str]:
        """Get current access token"""
        return self._auth_tokens.get('access_token')
    
    def get_refresh_token(self) -> Optional[str]:
        """Get current refresh token"""
        return self._auth_tokens.get('refresh_token')

class TypeQuestAuth(TypeQuestAuthMixin):
    """
    Main authentication service for TypeQuest
    Handles Auth0 integration with support for individual and organizational accounts
    """
    
    def __init__(self, config=None):
        super().__init__()
        if config:
            self.set_config(config)
    
    def login_flow(self) -> bool:
        """
        Complete authentication flow
        Returns True if login successful
        """
        
        console.print("🔐 [bold cyan]TypeQuest Authentication[/bold cyan]")
        console.print()
        
        # Check if already logged in
        if self.is_logged_in():
            user = self.get_current_user()
            if user:
                console.print(f"✅ Already logged in as [bold]{user.get('name', 'Unknown User')}[/bold]")
                return True
        
        # Show login options
        # First check if service is available
        if not self.check_service_health():
            console.print("❌ [red]TypeQuest service is not available[/red]")
            console.print("Please make sure the service is running or check your TYPEQUEST_API_URL")
            return False
        
        auth_method = self._prompt_auth_method()
        
        if auth_method == "device":
            return self._device_code_login()
        elif auth_method == "browser":
            console.print("ℹ️  [yellow]Browser login not supported yet. Using device flow.[/yellow]")
            return self._device_code_login()
        elif auth_method == "organization":
            console.print("ℹ️  [yellow]Organization login not supported yet. Using device flow.[/yellow]")
            return self._device_code_login()
        else:
            return False
    
    def _prompt_auth_method(self) -> str:
        """Prompt user for authentication method"""
        
        methods = [
            "browser - Login via web browser (recommended)",
            "device - Device code flow (for headless systems)",
            "organization - Organization SSO login",
            "back - Go back"
        ]
        
        console.print("Please choose your login method:")
        for i, method in enumerate(methods, 1):
            console.print(f"  {i}. {method}")
        
        while True:
            choice = Prompt.ask("Choose option", choices=["1", "2", "3", "4"], default="1")
            
            method_map = {"1": "browser", "2": "device", "3": "organization", "4": "back"}
            return method_map[choice]
    
    def _browser_login(self) -> bool:
        """Login via web browser"""
        
        console.print("🌐 [yellow]Opening browser for authentication...[/yellow]")
        
        # Generate state and code verifier for PKCE
        state = self._generate_state()
        code_verifier = self._generate_code_verifier()
        code_challenge = self._generate_code_challenge(code_verifier)
        
        # Start local callback server
        callback_port = 8080
        callback_result = {}
        
        def callback_server():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(('localhost', callback_port))
                sock.listen(1)
                
                conn, addr = sock.accept()
                
                # Read the HTTP request
                request = conn.recv(1024).decode('utf-8')
                
                # Extract callback URL
                lines = request.split('\n')
                callback_url = lines[0].split()[1] if lines else ""
                
                # Parse query parameters
                parsed_url = urlparse(f"http://localhost:8080{callback_url}")
                query_params = parse_qs(parsed_url.query)
                
                # Send response to browser
                if 'code' in query_params:
                    response = "HTTP/1.1 200 OK\n\n<html><body><h1>✅ Login Successful!</h1><p>You can close this window and return to the CLI.</p></body></html>"
                    callback_result['success'] = True
                    callback_result['code'] = query_params['code'][0]
                else:
                    response = "HTTP/1.1 400 Bad Request\n\n<html><body><h1>❌ Login Failed</h1><p>Authentication was cancelled or failed.</p></body></html>"
                    callback_result['success'] = False
                
                conn.send(response.encode('utf-8'))
                conn.close()
                sock.close()
                
            except Exception as e:
                callback_result['success'] = False
                callback_result['error'] = str(e)
        
        # Start callback server in background
        server_thread = threading.Thread(target=callback_server, daemon=True)
        server_thread.start()
        
        # Build authorization URL
        auth_params = {
            'response_type': 'code',
            'client_id': self.auth_config.client_id,
            'redirect_uri': self.auth_config.redirect_uri,
            'scope': self.auth_config.scope,
            'state': state,
            'code_challenge': code_challenge,
            'code_challenge_method': 'S256',
            'audience': self.auth_config.audience
        }
        
        auth_url = f"https://{self.auth_config.domain}/authorize?{urlencode(auth_params)}"
        
        # Open browser
        try:
            webbrowser.open(auth_url)
        except Exception:
            console.print("Could not open browser automatically.")
            console.print(f"Please visit: {auth_url}")
        
        # Wait for callback with progress indicator
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Waiting for authentication...", total=None)
            
            # Wait up to 5 minutes
            timeout = 300
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                if callback_result:
                    break
                time.sleep(0.5)
            
            progress.stop()
        
        # Process callback result
        if not callback_result.get('success'):
            console.print("❌ [red]Authentication failed or timed out[/red]")
            return False
        
        # Exchange authorization code for tokens
        return self._exchange_code_for_tokens(callback_result['code'], code_verifier)
    
    def _device_code_login(self) -> bool:
        """Login using device code flow"""
        
        console.print("📱 [yellow]Starting device code authentication...[/yellow]")
        
        # Request device code
        device_code_data = self._request_device_code()
        if not device_code_data:
            console.print("❌ [red]Failed to get device code[/red]")
            return False
        
        # Display user code
        verification_uri = device_code_data['verification_uri']
        user_code = device_code_data['user_code']
        
        panel_content = f"""
[bold cyan]Device Authentication Required[/bold cyan]

1. Visit: [bold blue]{verification_uri}[/bold blue]
2. Enter code: [bold green]{user_code}[/bold green]

[dim]This code expires in {device_code_data.get('expires_in', 600)} seconds[/dim]
"""
        
        console.print(Panel(panel_content, border_style="cyan"))
        
        # Try to open browser
        try:
            if Confirm.ask("Open verification page in browser?", default=True):
                webbrowser.open(verification_uri)
                console.print("\n✅ [green]Browser opened! Complete the login in your browser.[/green]")
                console.print("💡 [dim]Keep this terminal window open - we're waiting for you to authorize...[/dim]")
            else:
                console.print("\n💻 [yellow]Please manually visit the URL above and enter the code.[/yellow]")
        except Exception:
            console.print("\n❌ [red]Could not open browser automatically.[/red]")
            console.print("💻 [yellow]Please manually visit the URL above and enter the code.[/yellow]")
        
        console.print()
        
        # Poll for token
        return self._poll_device_token(device_code_data)
    
    def _organization_login(self) -> bool:
        """Login via organization SSO"""
        
        console.print("🏢 [yellow]Organization SSO Login[/yellow]")
        
        # Get organization domain
        org_domain = Prompt.ask("Enter your organization's domain (e.g., company.boots.dev)")
        
        if not org_domain:
            return False
        
        # Build organization-specific auth URL
        auth_params = {
            'response_type': 'code',
            'client_id': self.auth_config.client_id,
            'redirect_uri': self.auth_config.redirect_uri,
            'scope': f"{self.auth_config.scope} {' '.join(self.auth_config.org_scopes)}",
            'audience': self.auth_config.audience,
            'organization': org_domain
        }
        
        auth_url = f"https://{self.auth_config.domain}/authorize?{urlencode(auth_params)}"
        
        console.print(f"Opening organization login for: [bold]{org_domain}[/bold]")
        
        try:
            webbrowser.open(auth_url)
            console.print("Complete the login in your browser, then return here.")
            Prompt.ask("Press Enter when login is complete")
            
            # In a real implementation, you'd handle the callback properly
            # For now, we'll simulate success
            console.print("✅ [green]Organization login completed[/green]")
            return True
            
        except Exception as e:
            console.print(f"❌ [red]Organization login failed: {e}[/red]")
            return False
    
    def _request_device_code(self) -> Optional[Dict[str, Any]]:
        """Request device authorization code from TypeQuest service"""
        
        try:
            response = requests.post(
                self.auth_config.device_code_endpoint,
                json={
                    'client_id': self.auth_config.client_id,
                    'scope': self.auth_config.scope
                },
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                error_msg = "Unknown error"
                if response.content:
                    try:
                        error_data = response.json()
                        error_msg = error_data.get('error_description', error_msg)
                    except:
                        pass
                console.print(f"❌ Device code request failed: {error_msg}")
                return None
                
        except requests.RequestException as e:
            console.print(f"❌ Device code request failed: {e}")
            return None
    
    def _poll_device_token(self, device_code_data: Dict[str, Any]) -> bool:
        """Poll for device authorization token"""
        
        device_code = device_code_data['device_code']
        interval = device_code_data.get('interval', 5)
        expires_in = device_code_data.get('expires_in', 600)
        
        start_time = time.time()
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Waiting for device authorization...", total=None)
            
            while time.time() - start_time < expires_in:
                try:
                    response = requests.post(
                        self.auth_config.device_token_endpoint,
                        json={
                            'device_code': device_code,
                            'client_id': self.auth_config.client_id
                        },
                        headers={'Content-Type': 'application/json'},
                        timeout=10
                    )
                    
                    if response.status_code == 200:
                        tokens = response.json()
                        self._store_tokens(tokens)
                        progress.stop()
                        console.print("✅ [green]Device authentication successful![/green]")
                        return True
                    elif response.status_code in [400, 403]:  # Both 400 and 403 can have auth pending
                        error_data = response.json() if response.content else {}
                        error = error_data.get('error', '')
                        if error == 'authorization_pending':
                            # Continue polling
                            time.sleep(interval)
                            continue
                        elif error == 'slow_down':
                            # Increase polling interval
                            interval += 5
                            time.sleep(interval)
                            continue
                        else:
                            progress.stop()
                            console.print(f"❌ [red]Authorization failed: {error}[/red]")
                            console.print(f"[dim]Full response: {response.text}[/dim]")
                            return False
                    else:
                        progress.stop()
                        console.print(f"❌ [red]Token request failed: {response.status_code}[/red]")
                        console.print(f"[dim]Response: {response.text}[/dim]")
                        return False
                        
                except requests.RequestException as e:
                    time.sleep(interval)
                    continue
            
            progress.stop()
            console.print("❌ [red]Device authorization timed out[/red]")
            return False
    
    def _exchange_code_for_tokens(self, authorization_code: str, code_verifier: str) -> bool:
        """Exchange authorization code for access tokens"""
        
        try:
            response = requests.post(
                f"https://{self.auth_config.domain}/oauth/token",
                data={
                    'grant_type': 'authorization_code',
                    'client_id': self.auth_config.client_id,
                    'code': authorization_code,
                    'redirect_uri': self.auth_config.redirect_uri,
                    'code_verifier': code_verifier
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=10
            )
            
            if response.status_code == 200:
                tokens = response.json()
                self._store_tokens(tokens)
                console.print("✅ [green]Login successful![/green]")
                return True
            else:
                console.print(f"❌ [red]Token exchange failed: {response.status_code}[/red]")
                return False
                
        except requests.RequestException as e:
            console.print(f"❌ [red]Token exchange failed: {e}[/red]")
            return False
    
    def _store_tokens(self, tokens: Dict[str, Any]):
        """Store authentication tokens securely"""
        
        self._auth_tokens = {
            'access_token': tokens.get('access_token'),
            'refresh_token': tokens.get('refresh_token'),
            'id_token': tokens.get('id_token'),
            'token_type': tokens.get('token_type', 'Bearer'),
            'expires_at': time.time() + tokens.get('expires_in', 3600),
            'scope': tokens.get('scope', '')
        }
        
        # Store user info if included in token response
        if 'user' in tokens:
            self._current_user = tokens['user']
        
        # Store in database if config available
        if self.config:
            try:
                conn = self.config.get_db_connection()
                cursor = conn.cursor()
                
                # Get user ID from token
                user_id = self._get_user_id_from_token(tokens.get('access_token'))
                
                if user_id:
                    cursor.execute('''
                        INSERT OR REPLACE INTO auth_tokens 
                        (user_id, access_token, refresh_token, expires_at)
                        VALUES (?, ?, ?, ?)
                    ''', (
                        user_id,
                        tokens.get('access_token'),
                        tokens.get('refresh_token'),
                        datetime.fromtimestamp(self._auth_tokens['expires_at']).isoformat()
                    ))
                
                conn.commit()
                conn.close()
            except Exception as e:
                console.print(f"[dim]Warning: Could not store tokens: {e}[/dim]")
    
    def _load_stored_tokens(self):
        """Load stored authentication tokens"""
        
        if not self.config:
            return
        
        try:
            conn = self.config.get_db_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT access_token, refresh_token, expires_at 
                FROM auth_tokens 
                ORDER BY created_at DESC 
                LIMIT 1
            ''')
            
            result = cursor.fetchone()
            
            if result:
                access_token, refresh_token, expires_at = result
                expires_timestamp = datetime.fromisoformat(expires_at).timestamp()
                
                if expires_timestamp > time.time():
                    self._auth_tokens = {
                        'access_token': access_token,
                        'refresh_token': refresh_token,
                        'expires_at': expires_timestamp
                    }
            
            conn.close()
        except Exception:
            # Ignore errors when loading tokens
            pass
    
    def refresh_token(self) -> bool:
        """Refresh authentication token via TypeQuest service"""
        
        refresh_token = self.get_refresh_token()
        if not refresh_token:
            return False
        
        try:
            response = requests.post(
                self.auth_config.device_refresh_endpoint,
                json={
                    'refresh_token': refresh_token,
                    'client_id': self.auth_config.client_id
                },
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code == 200:
                tokens = response.json()
                self._store_tokens(tokens)
                return True
            else:
                # Refresh failed, user needs to login again
                self._clear_tokens()
                return False
                
        except requests.RequestException:
            return False
    
    def logout(self) -> bool:
        """Logout user and clear tokens"""
        
        if not self.is_logged_in():
            console.print("ℹ️  [dim]Not currently logged in[/dim]")
            return True
        
        # Logout via Django service (optional - best effort)
        access_token = self.get_auth_token()
        if access_token:
            try:
                # Call Django service logout endpoint
                response = requests.post(
                    f"{self.auth_config.api_base_url}/auth/cli/logout/",
                    headers={
                        'Authorization': f'Bearer {access_token}',
                        'Content-Type': 'application/json'
                    },
                    timeout=5
                )
                # Don't fail if service is unavailable
            except requests.RequestException:
                # Service unavailable - just clear local tokens
                pass
        
        # Always clear local tokens regardless of service response
        self._clear_tokens()
        console.print("✅ [green]Logged out successfully[/green]")
        console.print("[dim]All local session data cleared[/dim]")
        return True
    
    def _clear_tokens(self):
        """Clear stored authentication tokens"""
        
        self._auth_tokens = {}
        self._current_user = None
        self._current_org = None
        
        if self.config:
            try:
                conn = self.config.get_db_connection()
                cursor = conn.cursor()
                cursor.execute('DELETE FROM auth_tokens')
                conn.commit()
                conn.close()
            except Exception:
                pass
    
    def _fetch_user_profile(self) -> Optional[Dict[str, Any]]:
        """Fetch user profile from TypeQuest service"""
        
        status = self.get_auth_status()
        return status.get('user')
    
    def _fetch_user_organization(self) -> Optional[Dict[str, Any]]:
        """Fetch user's organization information"""
        
        access_token = self.get_auth_token()
        if not access_token:
            return None
        
        try:
            # Decode token to get organization info
            decoded = jwt.decode(access_token, options={"verify_signature": False})
            org_id = decoded.get('org_id')
            
            if not org_id:
                return None
            
            # Fetch organization details from API
            response = requests.get(
                f"https://api.typequest.dev/v1/organizations/{org_id}",
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
                
        except (jwt.InvalidTokenError, requests.RequestException):
            return None
    
    def _get_user_id_from_token(self, token: str) -> Optional[str]:
        """Extract user ID from JWT token"""
        
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            return decoded.get('sub')
        except jwt.InvalidTokenError:
            return None
    
    def _generate_state(self) -> str:
        """Generate state parameter for OAuth"""
        return str(uuid.uuid4())
    
    def _generate_code_verifier(self) -> str:
        """Generate code verifier for PKCE"""
        return str(uuid.uuid4()).replace('-', '')
    
    def _generate_code_challenge(self, verifier: str) -> str:
        """Generate code challenge for PKCE"""
        import base64
        
        challenge_bytes = hashlib.sha256(verifier.encode('utf-8')).digest()
        code_challenge = base64.urlsafe_b64encode(challenge_bytes).decode('utf-8')
        return code_challenge.replace('=', '')
    
    def get_organization_members(self) -> List[Dict[str, Any]]:
        """Get organization members (for organization admins)"""
        
        org = self.get_current_organization()
        access_token = self.get_auth_token()
        
        if not org or not access_token:
            return []
        
        try:
            response = requests.get(
                f"https://api.typequest.dev/v1/organizations/{org['id']}/members",
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json().get('members', [])
            else:
                return []
                
        except requests.RequestException:
            return []
    
    def get_auth_status(self) -> Dict[str, Any]:
        """Get comprehensive authentication status from TypeQuest service"""
        
        access_token = self.get_auth_token()
        if not access_token:
            return {
                'logged_in': False,
                'user': None,
                'token_expires_at': None,
                'scopes': [],
                'service_available': self.check_service_health()
            }
        
        try:
            response = requests.get(
                self.auth_config.cli_status_endpoint,
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                status_data = response.json()
                return {
                    'logged_in': status_data.get('authenticated', False),
                    'user': status_data.get('user'),
                    'session_info': status_data.get('session_info'),
                    'token_expires_at': self._auth_tokens.get('expires_at'),
                    'scopes': self._auth_tokens.get('scope', '').split(),
                    'service_available': True
                }
            else:
                return {
                    'logged_in': False,
                    'user': None,
                    'token_expires_at': None,
                    'scopes': [],
                    'service_available': True,
                    'error': 'Authentication failed'
                }
                
        except requests.RequestException:
            return {
                'logged_in': self.is_logged_in(),  # Fallback to local check
                'user': self._current_user,
                'token_expires_at': self._auth_tokens.get('expires_at'),
                'scopes': self._auth_tokens.get('scope', '').split(),
                'service_available': False
            }
    
    def check_service_health(self) -> bool:
        """Check if TypeQuest service is available"""
        try:
            response = requests.get(
                self.auth_config.cli_health_endpoint,
                timeout=5
            )
            return response.status_code == 200
        except requests.RequestException:
            return False
    
    def validate_token(self) -> Dict[str, Any]:
        """Validate current token with TypeQuest service"""
        access_token = self.get_auth_token()
        if not access_token:
            return {'valid': False, 'error': 'No token available'}
        
        try:
            response = requests.post(
                self.auth_config.cli_validate_endpoint,
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return {'valid': False, 'error': 'Token validation failed'}
                
        except requests.RequestException as e:
            return {'valid': False, 'error': f'Network error: {e}'}
    
    def get_user_preferences(self) -> Dict[str, Any]:
        """Get user preferences from TypeQuest service"""
        access_token = self.get_auth_token()
        if not access_token:
            return {}
        
        try:
            response = requests.get(
                self.auth_config.cli_preferences_endpoint,
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('preferences', {})
            else:
                return {}
                
        except requests.RequestException:
            return {}
    
    def update_user_preferences(self, preferences: Dict[str, Any]) -> bool:
        """Update user preferences via TypeQuest service"""
        access_token = self.get_auth_token()
        if not access_token:
            return False
        
        try:
            response = requests.patch(
                self.auth_config.cli_preferences_endpoint,
                json=preferences,
                headers={
                    'Authorization': f'Bearer {access_token}',
                    'Content-Type': 'application/json'
                },
                timeout=10
            )
            
            return response.status_code == 200
                
        except requests.RequestException:
            return False