"""
Cross-platform compatibility utilities
"""

import os
import sys
import platform
import subprocess
from pathlib import Path
from typing import Dict, Any

def get_platform_info() -> Dict[str, Any]:
    """Get platform information"""
    
    return {
        "system": platform.system(),
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "architecture": platform.architecture()[0],
        "machine": platform.machine(),
        "processor": platform.processor(),
    }

def get_config_directory() -> Path:
    """Get platform-appropriate config directory"""
    
    system = platform.system()
    
    if system == "Windows":
        # Use AppData on Windows
        return Path(os.getenv("APPDATA", "~")) / "TypeQuest"
    elif system == "Darwin":  # macOS
        # Use Application Support on macOS
        return Path("~/Library/Application Support/TypeQuest").expanduser()
    else:  # Linux and others
        # Use XDG config directory
        xdg_config = os.getenv("XDG_CONFIG_HOME", "~/.config")
        return Path(xdg_config).expanduser() / "boots"

def open_terminal():
    """Open a new terminal window"""
    
    system = platform.system()
    
    try:
        if system == "Darwin":  # macOS
            subprocess.Popen(["open", "-a", "Terminal"])
        elif system == "Windows":
            subprocess.Popen(["cmd", "/c", "start", "cmd"])
        else:  # Linux
            # Try common terminal emulators
            terminals = ["gnome-terminal", "xterm", "konsole", "terminator"]
            for terminal in terminals:
                try:
                    subprocess.Popen([terminal])
                    break
                except FileNotFoundError:
                    continue
    except Exception:
        pass

def get_shell_info() -> Dict[str, str]:
    """Get information about current shell"""
    
    shell = os.getenv("SHELL", "unknown")
    return {
        "shell": shell,
        "shell_name": Path(shell).name if shell != "unknown" else "unknown"
    }

def setup_shell_completion() -> str:
    """Set up shell completion if possible"""
    
    shell_info = get_shell_info()
    shell_name = shell_info["shell_name"]
    
    completion_script = None
    
    if shell_name == "bash":
        completion_script = """
# TypeQuest completion
_boots_completion() {
    local cur prev
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    
    case ${prev} in
        boots)
            COMPREPLY=( $(compgen -W "--help --version --update --diagnose login logout" -- ${cur}) )
            return 0
            ;;
    esac
}
complete -F _boots_completion boots
"""
    elif shell_name == "zsh":
        completion_script = """
# TypeQuest completion
_boots() {
    local state
    _arguments \\
        '1: :->commands' \\
        '*: :->args'
    
    case $state in
        commands)
            _values 'boots commands' \\
                'login[Login to account]' \\
                'logout[Logout from account]' \\
                '--help[Show help]' \\
                '--version[Show version]' \\
                '--update[Update CLI]' \\
                '--diagnose[Run diagnostics]'
            ;;
    esac
}
compdef _boots boots
"""
    
    return completion_script

def is_admin() -> bool:
    """Check if running with admin/root privileges"""
    
    system = platform.system()
    
    if system == "Windows":
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    else:
        return os.geteuid() == 0

def get_system_python_path() -> str:
    """Get the system Python executable path"""
    return sys.executable

def check_internet_connection() -> bool:
    """Check if internet connection is available"""
    
    try:
        import socket
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except OSError:
        return False