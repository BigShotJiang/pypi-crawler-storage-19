"""
Simplified Claude Code-style input for TypeQuest CLI
Works without external dependencies
"""

import sys
import time
import select
import termios
import tty
from typing import Optional, List, Dict, Any
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.columns import Columns

console = Console()


class SimpleInputMode:
    """Input mode enumeration"""
    ACCEPT = "accept"
    EDIT = "edit"


class SimpleInteractiveInput:
    """
    Simplified Claude Code-style interactive input
    Uses standard terminal capabilities
    """
    
    def __init__(self):
        self.mode = SimpleInputMode.ACCEPT
        self.input_text = ""
        self.settings = {
            "accept_edits": True,
            "multiline": False,
            "typewriter_speed": "normal"
        }
        self.is_unix = hasattr(sys, 'platform') and sys.platform != 'win32'
    
    def show_input_box(self, 
                      prompt: str = "Enter your input:",
                      placeholder: str = "Type your message...",
                      multiline: bool = False) -> str:
        """
        Show interactive input with Claude Code-style interface
        
        Returns:
            The submitted text
        """
        self.settings["multiline"] = multiline
        self.input_text = ""
        
        # Clear screen and show interface
        console.clear()
        self._show_interface(prompt, placeholder)
        
        # Handle input based on platform capabilities
        if self.is_unix:
            return self._handle_unix_input()
        else:
            return self._handle_simple_input()
    
    def _show_interface(self, prompt: str, placeholder: str):
        """Show the input interface"""
        console.print(f"[bold cyan]{prompt}[/bold cyan]")
        console.print()
        
        # Show input area
        self._show_input_area(placeholder)
        
        # Show controls
        self._show_controls()
    
    def _show_input_area(self, placeholder: str):
        """Show the input text area"""
        if self.input_text:
            display_text = self.input_text
        else:
            display_text = Text(placeholder, style="dim")
        
        # Style based on mode
        if self.mode == SimpleInputMode.ACCEPT:
            border_style = "green"
            title = "✓ Accept Mode - Ready to Submit"
        else:
            border_style = "blue"
            title = "✏️ Edit Mode - Type to Modify"
        
        input_panel = Panel(
            display_text,
            title=title,
            border_style=border_style,
            height=5 if not self.settings["multiline"] else 8
        )
        
        console.print(input_panel)
        console.print()
    
    def _show_controls(self):
        """Show keyboard controls and settings"""
        
        # Create controls table
        controls_table = Table(title="🎮 Controls", show_header=False, box=None)
        controls_table.add_column("Key", style="bold cyan", width=12)
        controls_table.add_column("Action", style="white")
        
        if self.mode == SimpleInputMode.ACCEPT:
            controls_table.add_row("Enter", "Submit input")
            controls_table.add_row("E", "Switch to Edit mode")
            controls_table.add_row("S", "Toggle Settings") 
            controls_table.add_row("Ctrl+C", "Cancel/Exit")
        else:
            controls_table.add_row("A", "Switch to Accept mode")
            controls_table.add_row("Enter", "Submit from Edit mode")
            controls_table.add_row("S", "Toggle Settings")
            controls_table.add_row("Ctrl+C", "Cancel/Exit")
        
        # Create settings table
        settings_table = Table(title="⚙️ Settings", show_header=False, box=None)
        settings_table.add_column("Setting", style="bold yellow", width=15)
        settings_table.add_column("Value", style="white")
        
        for key, value in self.settings.items():
            if isinstance(value, bool):
                status = "✓ On" if value else "✗ Off"
                color = "green" if value else "red"
                settings_table.add_row(
                    key.replace('_', ' ').title(),
                    f"[{color}]{status}[/{color}]"
                )
            else:
                settings_table.add_row(
                    key.replace('_', ' ').title(),
                    str(value)
                )
        
        # Show side by side
        columns = Columns([controls_table, settings_table], equal=True)
        console.print(Panel(columns, border_style="dim"))
        console.print()
    
    def _handle_unix_input(self) -> str:
        """Handle input on Unix systems with better terminal control"""
        while True:
            console.print(f"[bold]Current Mode:[/bold] [{'green' if self.mode == SimpleInputMode.ACCEPT else 'blue'}]{self.mode.title()}[/]")
            
            if self.mode == SimpleInputMode.ACCEPT:
                console.print("💡 [dim]Press Enter to submit, E for edit, S for settings, Ctrl+C to cancel[/dim]")
                action = self._get_single_key()
                
                if action == '\r' or action == '\n':  # Enter
                    if self.input_text.strip():
                        return self.input_text
                    else:
                        console.print("[yellow]⚠️ Please enter some text first[/yellow]")
                        time.sleep(1)
                        
                elif action.lower() == 'e':
                    self.mode = SimpleInputMode.EDIT
                    
                elif action.lower() == 's':
                    self._show_settings_menu()
                    
                elif action == '\x03':  # Ctrl+C
                    raise KeyboardInterrupt()
                    
            else:  # EDIT mode
                console.print("✏️ [dim]Type your input (A to accept, Enter to submit, S for settings, Ctrl+C to cancel)[/dim]")
                console.print(f"[dim]Current text: {self.input_text}[/dim]")
                
                action = self._get_line_input()
                
                if action.lower() == 'a':
                    self.mode = SimpleInputMode.ACCEPT
                elif action == '':  # Just Enter
                    if self.input_text.strip():
                        return self.input_text
                    else:
                        console.print("[yellow]⚠️ Please enter some text first[/yellow]")
                        time.sleep(1)
                elif action.lower() == 's':
                    self._show_settings_menu()
                else:
                    self.input_text = action
            
            # Refresh display
            console.clear()
            self._show_interface("Enter your input:", "Type your message...")
    
    def _handle_simple_input(self) -> str:
        """Fallback for systems without advanced terminal control"""
        console.print("[yellow]💡 Simplified input mode[/yellow]")
        
        while True:
            if self.mode == SimpleInputMode.ACCEPT:
                console.print("\n[green]✓ Accept Mode[/green]")
                console.print("Commands: [enter] submit, [e] edit, [s] settings, [ctrl+c] cancel")
                
                try:
                    action = input("> ").strip()
                    
                    if action == "":
                        if self.input_text.strip():
                            return self.input_text
                        else:
                            console.print("[yellow]No text to submit. Use 'e' to enter edit mode.[/yellow]")
                            
                    elif action.lower() == 'e':
                        self.mode = SimpleInputMode.EDIT
                        
                    elif action.lower() == 's':
                        self._show_settings_menu()
                        
                except KeyboardInterrupt:
                    return ""
                    
            else:  # EDIT mode
                console.print("\n[blue]✏️ Edit Mode[/blue]")
                console.print(f"Current: {self.input_text}")
                console.print("Commands: [a] accept mode, [s] settings, or type new text")
                
                try:
                    action = input("> ").strip()
                    
                    if action.lower() == 'a':
                        self.mode = SimpleInputMode.ACCEPT
                    elif action.lower() == 's':
                        self._show_settings_menu()
                    elif action == "":
                        if self.input_text.strip():
                            return self.input_text
                        else:
                            console.print("[yellow]No text to submit.[/yellow]")
                    else:
                        self.input_text = action
                        
                except KeyboardInterrupt:
                    return ""
    
    def _get_single_key(self) -> str:
        """Get a single key press on Unix systems"""
        try:
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            tty.cbreak(fd)
            
            ch = sys.stdin.read(1)
            return ch
            
        except:
            # Fallback to regular input
            return input()[:1]
        finally:
            try:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            except:
                pass
    
    def _get_line_input(self) -> str:
        """Get a line of input"""
        try:
            return input("> ")
        except KeyboardInterrupt:
            raise
    
    def _show_settings_menu(self):
        """Show and handle settings menu"""
        console.print("\n⚙️ [bold]Settings Menu[/bold]")
        console.print("=" * 40)
        
        settings_list = list(self.settings.items())
        for i, (key, value) in enumerate(settings_list, 1):
            status = "✓" if value else "✗" if isinstance(value, bool) else value
            color = "green" if value and isinstance(value, bool) else "red" if not value and isinstance(value, bool) else "yellow"
            console.print(f"{i}. {key.replace('_', ' ').title()}: [{color}]{status}[/{color}]")
        
        console.print("0. Back to input")
        console.print()
        
        try:
            choice = input("Select setting to toggle (0-{}): ".format(len(settings_list)))
            choice_num = int(choice)
            
            if choice_num == 0:
                return
            elif 1 <= choice_num <= len(settings_list):
                key = settings_list[choice_num - 1][0]
                self._toggle_setting(key)
                console.print(f"[green]✓ Toggled {key.replace('_', ' ').title()}[/green]")
                time.sleep(1)
            else:
                console.print("[red]Invalid choice[/red]")
                time.sleep(1)
                
        except (ValueError, KeyboardInterrupt):
            console.print("[yellow]Returning to input...[/yellow]")
            time.sleep(1)
    
    def _toggle_setting(self, setting_name: str):
        """Toggle a setting"""
        if setting_name in self.settings:
            value = self.settings[setting_name]
            
            if isinstance(value, bool):
                self.settings[setting_name] = not value
            elif setting_name == "typewriter_speed":
                speeds = ["slow", "normal", "fast", "instant"]
                try:
                    current_index = speeds.index(value)
                    next_index = (current_index + 1) % len(speeds)
                    self.settings[setting_name] = speeds[next_index]
                except ValueError:
                    self.settings[setting_name] = "normal"


def demo_simple_input():
    """Demo the simplified interactive input"""
    console.print("🎮 [bold cyan]Claude Code-Style Interactive Input Demo[/bold cyan]")
    console.print()
    console.print("[dim]This demo shows the TypeQuest interactive input system[/dim]")
    console.print("[dim]Try switching between Accept and Edit modes![/dim]")
    console.print()
    
    input_box = SimpleInteractiveInput()
    
    try:
        result = input_box.show_input_box(
            prompt="Welcome to TypeQuest! What would you like to learn?",
            placeholder="e.g., Django, Python, SQL, JavaScript...",
            multiline=False
        )
        
        console.print()
        console.print("🎉 [bold green]Thanks for trying the interactive input![/bold green]")
        console.print(f"✅ [green]You entered:[/green] [bold]{result}[/bold]")
        console.print()
        
        # Show another example with multiline
        console.print("Now try a multiline example...")
        result2 = input_box.show_input_box(
            prompt="Describe your learning goals:",
            placeholder="Tell us about your programming background and goals...",
            multiline=True
        )
        
        console.print(f"✅ [green]Your learning goals:[/green]\n{result2}")
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Demo cancelled by user[/yellow]")


if __name__ == "__main__":
    demo_simple_input()