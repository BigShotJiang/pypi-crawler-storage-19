"""
Claude Code-style interactive input system for TypeQuest CLI
Supports accept/edit modes with keyboard shortcuts
"""

import sys
import threading
import time
from typing import Optional, Callable, List, Dict, Any
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.text import Text
from rich.layout import Layout
from rich.align import Align
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

try:
    import keyboard  # For advanced keyboard handling
    KEYBOARD_AVAILABLE = True
except ImportError:
    KEYBOARD_AVAILABLE = False

console = Console()


class InputMode:
    """Input mode enumeration"""
    ACCEPT = "accept"
    EDIT = "edit"


class InteractiveInput:
    """
    Claude Code-style interactive input box with settings controls
    """
    
    def __init__(self):
        self.mode = InputMode.ACCEPT
        self.input_text = ""
        self.cursor_pos = 0
        self.settings = {
            "accept_edits": True,
            "auto_submit": False,
            "multiline": False,
            "typewriter_speed": "normal"
        }
        self.is_active = False
        self._input_thread = None
        self._live_display = None
        
    def show_input_box(self, 
                      prompt: str = "Enter your input:",
                      placeholder: str = "Type your message...",
                      on_submit: Optional[Callable[[str], None]] = None,
                      multiline: bool = False) -> str:
        """
        Show interactive input box with Claude Code-style interface
        
        Args:
            prompt: Text to show above input box
            placeholder: Placeholder text in input
            on_submit: Callback when input is submitted
            multiline: Whether to allow multiline input
            
        Returns:
            The submitted text
        """
        self.settings["multiline"] = multiline
        self.input_text = ""
        self.cursor_pos = 0
        self.is_active = True
        
        # Create layout
        layout = self._create_layout(prompt, placeholder)
        
        with Live(layout, console=console, refresh_per_second=10, screen=True) as live:
            self._live_display = live
            
            try:
                return self._handle_input_loop()
            finally:
                self.is_active = False
                self._live_display = None
    
    def _create_layout(self, prompt: str, placeholder: str) -> Layout:
        """Create the Rich layout for the input interface"""
        layout = Layout()
        
        # Split into header, input, and footer
        layout.split_column(
            Layout(name="header", size=3),
            Layout(name="input", size=7), 
            Layout(name="footer", size=4)
        )
        
        # Header with prompt
        header_text = Text(prompt, style="bold cyan")
        layout["header"].update(Align.left(header_text))
        
        # Input box
        input_panel = self._create_input_panel(placeholder)
        layout["input"].update(input_panel)
        
        # Footer with controls
        footer_panel = self._create_footer_panel()
        layout["footer"].update(footer_panel)
        
        return layout
    
    def _create_input_panel(self, placeholder: str) -> Panel:
        """Create the input text panel"""
        if self.input_text or self.mode == InputMode.EDIT:
            # Show actual text with cursor
            display_text = self.input_text
            if self.mode == InputMode.EDIT:
                # Add cursor indicator
                cursor_char = "|" if int(time.time() * 2) % 2 else " "
                if self.cursor_pos <= len(display_text):
                    display_text = (
                        display_text[:self.cursor_pos] + 
                        cursor_char + 
                        display_text[self.cursor_pos:]
                    )
        else:
            # Show placeholder
            display_text = Text(placeholder, style="dim")
        
        # Style based on mode
        if self.mode == InputMode.ACCEPT:
            border_style = "green"
            title = "✓ Accept Mode"
        else:
            border_style = "blue" 
            title = "✏️ Edit Mode"
        
        return Panel(
            display_text,
            title=title,
            border_style=border_style,
            height=5
        )
    
    def _create_footer_panel(self) -> Panel:
        """Create the footer with keyboard shortcuts and settings"""
        
        # Keyboard shortcuts table
        shortcuts_table = Table(show_header=False, box=None, padding=(0, 1))
        shortcuts_table.add_column("Key", style="bold")
        shortcuts_table.add_column("Action", style="dim")
        
        if self.mode == InputMode.ACCEPT:
            shortcuts_table.add_row("Enter", "Submit")
            shortcuts_table.add_row("Shift+Tab", "Switch to Edit mode")
            shortcuts_table.add_row("Ctrl+C", "Cancel")
        else:
            shortcuts_table.add_row("Shift+Tab", "Switch to Accept mode") 
            shortcuts_table.add_row("Ctrl+Enter", "Submit")
            shortcuts_table.add_row("Ctrl+C", "Cancel")
        
        # Settings display
        settings_text = self._format_settings()
        
        # Combine in layout
        footer_layout = Layout()
        footer_layout.split_row(
            Layout(shortcuts_table, name="shortcuts"),
            Layout(settings_text, name="settings")
        )
        
        return Panel(
            footer_layout,
            title="Controls & Settings",
            border_style="dim"
        )
    
    def _format_settings(self) -> Text:
        """Format current settings display"""
        text = Text()
        text.append("Settings:\n", style="bold")
        
        for key, value in self.settings.items():
            status = "✓" if value else "✗"
            color = "green" if value else "red"
            text.append(f"{status} {key.replace('_', ' ').title()}\n", style=color)
        
        return text
    
    def _handle_input_loop(self) -> str:
        """Handle the main input event loop"""
        if KEYBOARD_AVAILABLE:
            return self._handle_keyboard_input()
        else:
            return self._handle_fallback_input()
    
    def _handle_keyboard_input(self) -> str:
        """Handle input using keyboard library for advanced controls"""
        def on_key_event(event):
            if not self.is_active:
                return
            
            if event.event_type == keyboard.KEY_DOWN:
                self._process_key(event.name)
                self._update_display()
        
        keyboard.hook(on_key_event)
        
        try:
            # Wait for submission
            while self.is_active:
                time.sleep(0.1)
        finally:
            keyboard.unhook_all()
        
        return self.input_text
    
    def _handle_fallback_input(self) -> str:
        """Fallback input handling without keyboard library"""
        console.print("\n[yellow]Advanced keyboard shortcuts not available[/yellow]")
        console.print("[dim]Install 'keyboard' package for full functionality[/dim]")
        
        while self.is_active:
            try:
                if self.mode == InputMode.ACCEPT:
                    console.print("\n[green]Accept Mode[/green] - Press Enter to submit, 's' to switch to edit:")
                    user_input = input("> ")
                    
                    if user_input.lower() == 's':
                        self.mode = InputMode.EDIT
                        continue
                    else:
                        self.input_text = user_input
                        return self.input_text
                
                else:  # EDIT mode
                    console.print("\n[blue]Edit Mode[/blue] - Type your input (Ctrl+Enter to submit, 'a' to accept):")
                    user_input = input("> ")
                    
                    if user_input.lower() == 'a':
                        self.mode = InputMode.ACCEPT
                        continue
                    else:
                        self.input_text = user_input
                        return self.input_text
                        
            except KeyboardInterrupt:
                self.is_active = False
                return ""
    
    def _process_key(self, key_name: str):
        """Process individual key presses"""
        if key_name == 'shift+tab':
            # Toggle between accept and edit modes
            self.mode = InputMode.EDIT if self.mode == InputMode.ACCEPT else InputMode.ACCEPT
            
        elif key_name == 'enter':
            if self.mode == InputMode.ACCEPT:
                # Submit in accept mode
                self.is_active = False
            elif self.settings["multiline"]:
                # Add newline in multiline edit mode
                self.input_text = (
                    self.input_text[:self.cursor_pos] + 
                    '\n' + 
                    self.input_text[self.cursor_pos:]
                )
                self.cursor_pos += 1
        
        elif key_name == 'ctrl+enter':
            # Submit from edit mode
            self.is_active = False
            
        elif key_name == 'ctrl+c':
            # Cancel
            self.input_text = ""
            self.is_active = False
            
        elif key_name == 'backspace':
            if self.mode == InputMode.EDIT and self.cursor_pos > 0:
                self.input_text = (
                    self.input_text[:self.cursor_pos-1] + 
                    self.input_text[self.cursor_pos:]
                )
                self.cursor_pos -= 1
                
        elif key_name == 'delete':
            if self.mode == InputMode.EDIT and self.cursor_pos < len(self.input_text):
                self.input_text = (
                    self.input_text[:self.cursor_pos] + 
                    self.input_text[self.cursor_pos+1:]
                )
                
        elif key_name == 'left':
            if self.mode == InputMode.EDIT and self.cursor_pos > 0:
                self.cursor_pos -= 1
                
        elif key_name == 'right':
            if self.mode == InputMode.EDIT and self.cursor_pos < len(self.input_text):
                self.cursor_pos += 1
                
        elif key_name == 'home':
            if self.mode == InputMode.EDIT:
                self.cursor_pos = 0
                
        elif key_name == 'end':
            if self.mode == InputMode.EDIT:
                self.cursor_pos = len(self.input_text)
                
        elif len(key_name) == 1 and self.mode == InputMode.EDIT:
            # Regular character input in edit mode
            self.input_text = (
                self.input_text[:self.cursor_pos] + 
                key_name + 
                self.input_text[self.cursor_pos:]
            )
            self.cursor_pos += 1
    
    def _update_display(self):
        """Update the live display"""
        if self._live_display:
            # This would update the display - implementation depends on Rich Live API
            pass
    
    def toggle_setting(self, setting_name: str):
        """Toggle a boolean setting"""
        if setting_name in self.settings and isinstance(self.settings[setting_name], bool):
            self.settings[setting_name] = not self.settings[setting_name]
    
    def cycle_setting(self, setting_name: str, values: List[Any]):
        """Cycle through setting values"""
        if setting_name in self.settings:
            current = self.settings[setting_name]
            try:
                current_index = values.index(current)
                next_index = (current_index + 1) % len(values)
                self.settings[setting_name] = values[next_index]
            except ValueError:
                # Current value not in list, use first value
                self.settings[setting_name] = values[0]


def demo_interactive_input():
    """Demo the interactive input system"""
    console.print("🎮 [bold cyan]Interactive Input Demo[/bold cyan]")
    console.print()
    
    input_box = InteractiveInput()
    
    # Test basic input
    result = input_box.show_input_box(
        prompt="Enter a message for TypeQuest:",
        placeholder="What would you like to learn today?",
        multiline=False
    )
    
    console.print(f"\n✅ [green]You entered:[/green] {result}")
    
    # Test multiline input
    result2 = input_box.show_input_box(
        prompt="Enter a longer description:",
        placeholder="Type multiple lines...",
        multiline=True
    )
    
    console.print(f"\n✅ [green]You entered:[/green]\n{result2}")


if __name__ == "__main__":
    demo_interactive_input()