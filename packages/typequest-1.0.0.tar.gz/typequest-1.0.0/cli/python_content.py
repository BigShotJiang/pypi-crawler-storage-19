"""
Python course content including decorators lesson
"""

PYTHON_COURSE_CONTENT = {
    "course": {
        "name": "Learn Python",
        "slug": "learn-python", 
        "description": "Master Python from basics to advanced concepts including data structures, algorithms, OOP, and metaprogramming.",
        "difficulty": "beginner",
        "estimated_hours": 65,
        "track": "programming"
    },
    "lessons": [
        {
            "id": 1,
            "chapter": 1,
            "title": "Variables and Data Types",
            "slug": "variables-data-types",
            "content": """
# Variables and Data Types

## Understanding Variables: The Foundation of Programming

Variables are fundamental building blocks in programming - think of them as labeled boxes where you store different types of information. Unlike some programming languages, Python makes working with variables intuitive and flexible.

### What are Variables?
Variables are containers for storing data values. In Python, variables are created when you assign a value to them. The beauty of Python is that you don't need to declare the type of variable beforehand - Python figures it out automatically based on the value you assign.

**Real-world analogy**: Variables are like labeled containers in a warehouse. Each container has a name (the variable name) and holds something valuable (the data). You can always check what's inside, replace the contents, or use multiple containers to organize different types of items.

### Why Variables Matter
- **Memory Management**: Variables give names to memory locations, making your code readable
- **Flexibility**: You can change what's stored in a variable as your program runs
- **Organization**: Variables help organize and structure your data logically
- **Reusability**: Once stored in a variable, you can use that data multiple times

## Basic Data Types: Python's Built-in Value Types

Python comes with several built-in data types that cover most programming needs. Understanding these types is crucial because they determine what operations you can perform with your data.

### The Four Fundamental Types

### 1. Integer (int) - Whole Numbers
Integers represent whole numbers without decimal points. They can be positive, negative, or zero. Python integers have unlimited precision, meaning you can work with extremely large numbers without overflow errors.

**When to use integers:**
- Counting items (age, quantity, score)
- Mathematical calculations requiring whole numbers
- Array/list indexing
- Loop counters
```python
age = 25
year = 2024
temperature = -10
```

### 2. Float (float) - Decimal Numbers
Floats represent numbers with decimal points. They're essential for precise calculations involving measurements, percentages, and scientific computations.

**When to use floats:**
- Measurements (height, weight, distance)
- Financial calculations (prices, percentages)
- Scientific computations
- Any calculation requiring precision
```python
price = 19.99
pi = 3.14159
percentage = 75.5
```

### 3. String (str) - Text Data
Strings represent text data and are one of the most versatile data types. They can contain letters, numbers, symbols, and even emojis. Strings are immutable in Python, meaning you can't change them in place.

**When to use strings:**
- Names, addresses, descriptions
- User input and output
- File paths and URLs
- Any textual information
```python
name = "Alice"
message = 'Hello World'
description = "A Python course"
```

### 4. Boolean (bool) - True/False Values
Booleans represent logical values - either True or False. They're the foundation of decision-making in programming and are crucial for controlling program flow.

**When to use booleans:**
- Flags to track states (is_logged_in, has_permission)
- Results of comparisons (age > 18)
- Conditional logic
- Loop control
```python
is_student = True
is_logged_in = False
```

## Variable Naming: Writing Clean, Readable Code

Good variable names are like good street signs - they tell you exactly where you are and where you're going. Python has specific rules for naming variables, but following best practices makes your code professional and maintainable.

### Naming Rules (Must Follow)
- Must start with letter or underscore
- Can contain letters, numbers, and underscores
- Case sensitive (`age` and `Age` are different)
- Cannot use Python keywords

```python
# Good variable names
first_name = "John"
user_age = 30
is_valid = True

# Bad variable names (avoid these)
# 123name = "Invalid"  # Starts with number
# user-age = 25        # Contains hyphen
# class = "Python"     # Uses keyword
```

## Type Checking: Understanding Your Data

Python's dynamic typing is powerful, but sometimes you need to know exactly what type of data you're working with. The `type()` function is your detective tool for investigating data types.

Use `type()` function to check variable types:
```python
number = 42
print(type(number))  # <class 'int'>

name = "Python"
print(type(name))    # <class 'str'>
```

## Type Conversion: Transforming Data

Sometimes you need to convert data from one type to another. This is especially common when working with user input (which is always a string) or when performing calculations that require specific data types.

### Why Type Conversion Matters
- User input is always a string, but you might need numbers
- Mathematical operations require compatible types
- Different functions expect specific data types
- Data from files often needs conversion

Convert between types:
```python
# String to int
age_str = "25"
age_int = int(age_str)

# Int to string
score = 100
score_str = str(score)

# String to float
price_str = "19.99"
price_float = float(price_str)
```

## Input and Output: Communicating with Users

Programs become truly useful when they can interact with users. Python's input and output functions make this communication seamless and intuitive.

### The Importance of I/O
- **User Experience**: Programs that interact feel alive and responsive
- **Data Collection**: Gather information to make decisions
- **Feedback**: Provide results and confirmations to users
- **Debugging**: Display information to understand what's happening

### Getting User Input
```python
name = input("Enter your name: ")
age = int(input("Enter your age: "))
```

### Printing Output
```python
print("Hello, World!")
print("My name is", name)
print(f"I am {age} years old")  # f-string formatting
```

## Best Practices: Writing Professional Python Code

Following these practices from the beginning will make you a better programmer and your code more maintainable.

### Why Best Practices Matter
- **Readability**: Code is read more often than written
- **Collaboration**: Others can understand and work with your code
- **Debugging**: Well-named variables make problems easier to find
- **Maintenance**: Future you will thank present you for clear code

1. Use descriptive variable names
2. Follow Python naming conventions (snake_case)
3. Initialize variables before using them
4. Be consistent with naming patterns

Let's practice working with different data types!
            """,
            "is_free": True,
            "xp_reward": 15,
            "exercises": [
                {
                    "id": "variables-basic",
                    "title": "Create Variables",
                    "type": "python",
                    "instructions": """Create variables of different data types and print their values and types.

Create the following variables:
1. `student_name` with your name (string)
2. `student_age` with age 20 (integer)  
3. `grade_average` with value 85.5 (float)
4. `is_enrolled` with value True (boolean)

Then print each variable with its type.""",
                    "starter_code": """# Create variables here
student_name = 
student_age = 
grade_average = 
is_enrolled = 

# Print variables and their types
""",
                    "solution": """# Create variables here
student_name = "Alice"
student_age = 20
grade_average = 85.5
is_enrolled = True

# Print variables and their types
print(f"Name: {student_name}, Type: {type(student_name)}")
print(f"Age: {student_age}, Type: {type(student_age)}")
print(f"Average: {grade_average}, Type: {type(grade_average)}")
print(f"Enrolled: {is_enrolled}, Type: {type(is_enrolled)}")""",
                    "test_cases": [
                        {
                            "name": "Variables created correctly",
                            "input": "",
                            "expected_contains": ["str", "int", "float", "bool"]
                        }
                    ],
                    "xp_reward": 20,
                    "hints": [
                        "Use quotes for string values",
                        "Boolean values are True/False (capitalized)",
                        "Use f-strings for formatted output",
                        "Use type() function to get variable type"
                    ]
                }
            ]
        },
        {
            "id": 2,
            "chapter": 2,
            "title": "Basic Operators",
            "slug": "basic-operators",
            "content": """
# Basic Operators: The Building Blocks of Computation

Operators are the symbols that tell Python to perform specific mathematical, logical, or comparison operations. Think of them as the verbs in your programming sentences - they describe what actions to take with your data.

## Understanding Operator Categories

Python organizes operators into distinct categories, each serving a specific purpose in your programs. Mastering these operators is essential because they form the foundation of all computational logic.

### Why Operators Matter
- **Mathematical Operations**: Perform calculations and data manipulation
- **Decision Making**: Compare values to control program flow
- **Logic Building**: Combine conditions for complex decision trees
- **Efficiency**: Built-in operators are optimized for performance

## Arithmetic Operators: Mathematical Building Blocks
Perform mathematical operations on numeric data types. These operators work with integers and floats, and Python handles type conversion automatically when needed.

```python
a = 10
b = 3

print(a + b)   # Addition: 13
print(a - b)   # Subtraction: 7
print(a * b)   # Multiplication: 30
print(a / b)   # Division: 3.333...
print(a // b)  # Floor division: 3
print(a % b)   # Modulus (remainder): 1
print(a ** b)  # Exponentiation: 1000
```

## Comparison Operators: Making Decisions with Data
Compare values and return True/False. These operators are the foundation of conditional logic and decision-making in your programs. They always return boolean values (True or False).

```python
x = 5
y = 10

print(x == y)  # Equal: False
print(x != y)  # Not equal: True
print(x < y)   # Less than: True
print(x > y)   # Greater than: False
print(x <= y)  # Less than or equal: True
print(x >= y)  # Greater than or equal: False
```

## Logical Operators: Building Complex Logic
Combine boolean expressions to create sophisticated decision-making logic. These operators work with boolean values and are essential for creating complex conditions.

```python
age = 25
has_license = True

# AND operator
can_drive = age >= 18 and has_license
print(can_drive)  # True

# OR operator
is_adult = age >= 18 or age >= 21
print(is_adult)   # True

# NOT operator
is_minor = not (age >= 18)
print(is_minor)   # False
```

## Assignment Operators: Efficient Variable Updates
Assign and modify variables using shorthand notation. These operators combine assignment with arithmetic operations for cleaner, more efficient code.

```python
x = 10

x += 5   # x = x + 5, now x is 15
x -= 3   # x = x - 3, now x is 12
x *= 2   # x = x * 2, now x is 24
x /= 4   # x = x / 4, now x is 6.0
x //= 2  # x = x // 2, now x is 3.0
x %= 2   # x = x % 2, now x is 1.0
```

## Operator Precedence
Order of operations (PEMDAS):
1. Parentheses `()`
2. Exponentiation `**`
3. Multiplication `*`, Division `/`, Floor division `//`, Modulus `%`
4. Addition `+`, Subtraction `-`
5. Comparison operators
6. Logical operators (`not`, `and`, `or`)

```python
result = 2 + 3 * 4    # 14 (not 20)
result = (2 + 3) * 4  # 20

complex_expr = 5 > 3 and 10 < 20 or not False  # True
```

## String Operators
Special operations for strings.

```python
first_name = "John"
last_name = "Doe"

# Concatenation
full_name = first_name + " " + last_name
print(full_name)  # "John Doe"

# Repetition
laugh = "ha" * 3
print(laugh)      # "hahaha"

# Membership
print("John" in full_name)     # True
print("Jane" not in full_name) # True
```

Time to practice using these operators!
            """,
            "is_free": True,
            "xp_reward": 15,
            "exercises": [
                {
                    "id": "arithmetic-operators",
                    "title": "Calculator Operations",
                    "type": "python",
                    "instructions": """Create a simple calculator using arithmetic operators.

Given two numbers, calculate and print:
1. Sum
2. Difference  
3. Product
4. Quotient (regular division)
5. Floor division
6. Remainder
7. Power (first number to the power of second)""",
                    "starter_code": """num1 = 15
num2 = 4

# Calculate and print all operations
sum_result = 
difference = 
product = 
quotient = 
floor_div = 
remainder = 
power = 

print(f"Sum: {sum_result}")
# Add more print statements""",
                    "solution": """num1 = 15
num2 = 4

# Calculate and print all operations
sum_result = num1 + num2
difference = num1 - num2
product = num1 * num2
quotient = num1 / num2
floor_div = num1 // num2
remainder = num1 % num2
power = num1 ** num2

print(f"Sum: {sum_result}")
print(f"Difference: {difference}")
print(f"Product: {product}")
print(f"Quotient: {quotient}")
print(f"Floor Division: {floor_div}")
print(f"Remainder: {remainder}")
print(f"Power: {power}")""",
                    "test_cases": [
                        {
                            "name": "All arithmetic operations work",
                            "input": "",
                            "expected_contains": ["19", "11", "60", "3.75", "3", "50625"]
                        }
                    ],
                    "xp_reward": 25
                }
            ]
        },
        {
            "id": 3,
            "chapter": 3,
            "title": "Conditional Statements", 
            "slug": "conditional-statements",
            "content": """
# Conditional Statements: Teaching Your Program to Think

Conditional statements are the decision-making powerhouses of programming. They allow your program to examine data, compare values, and choose different paths of execution based on the results. Think of them as the "if this, then that" logic that makes programs intelligent.

## The Power of Decision-Making in Code

Every meaningful program needs to make decisions. Whether it's checking if a user is old enough to vote, determining if a password is correct, or deciding which path to take in a game, conditional statements make your programs responsive and intelligent.

### Why Conditionals Matter
- **Program Intelligence**: Make your code respond differently to different situations
- **User Experience**: Provide personalized responses based on user data
- **Error Handling**: Check for problems before they cause crashes
- **Business Logic**: Implement rules and requirements in code

## If Statement: The Foundation of Logic
Execute code only if a condition is true. The if statement is the most basic form of conditional logic - it's like asking a yes/no question and only proceeding if the answer is yes.

```python
age = 18

if age >= 18:
    print("You are an adult")
    print("You can vote")
```

## If-Else Statement: Handling Both Outcomes
Execute different code based on condition. The else clause provides an alternative path when the if condition is false, ensuring your program always has a response.

```python
temperature = 25

if temperature > 30:
    print("It's hot today")
else:
    print("It's not hot today")
```

## If-Elif-Else Statement: Multiple Decision Points
Check multiple conditions in sequence. When you have more than two possible outcomes, elif (else if) allows you to create a chain of conditions that are evaluated in order.

```python
score = 85

if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
elif score >= 60:
    grade = "D"
else:
    grade = "F"

print(f"Your grade is: {grade}")
```

## Nested If Statements: Layered Decision Making
If statements inside other if statements. Sometimes you need to make a decision, and then make another decision based on the first result. Nesting allows for complex, multi-layered logic.

```python
age = 25
has_license = True

if age >= 18:
    if has_license:
        print("You can drive")
    else:
        print("You need a license")
else:
    print("Too young to drive")
```

## Multiple Conditions: Combining Logic
Using logical operators in conditions. Real-world decisions often depend on multiple factors. Logical operators let you combine several conditions into a single, sophisticated decision.

```python
username = "admin"
password = "secret123"

if username == "admin" and password == "secret123":
    print("Login successful")
elif username == "admin" or password == "secret123":
    print("Partial match - check credentials")
else:
    print("Login failed")
```

## Ternary Operator: Concise Decision Making
Short form for simple if-else statements. When you have a simple condition that assigns one of two values, the ternary operator provides an elegant one-liner solution.

```python
age = 20

# Long form
if age >= 18:
    status = "adult"
else:
    status = "minor"

# Short form (ternary)
status = "adult" if age >= 18 else "minor"
print(status)
```

## Common Patterns

### Checking for Empty Values
```python
name = input("Enter your name: ")

if name:  # Truthy check
    print(f"Hello, {name}!")
else:
    print("No name provided")
```

### Range Checking
```python
score = 75

if 0 <= score <= 100:
    print("Valid score")
else:
    print("Invalid score")
```

### Multiple Value Checking
```python
day = "Monday"

if day in ["Saturday", "Sunday"]:
    print("Weekend!")
else:
    print("Weekday")
```

## Best Practices
1. Use meaningful condition names
2. Avoid deep nesting when possible
3. Consider using elif instead of multiple if statements
4. Use truthiness for cleaner code

Let's practice decision making with conditionals!
            """,
            "is_free": True,
            "xp_reward": 15,
            "exercises": [
                {
                    "id": "grade-calculator",
                    "title": "Grade Calculator",
                    "type": "python",
                    "instructions": """Create a grade calculator that converts numeric scores to letter grades.

Use these grade boundaries:
- 90-100: A
- 80-89: B  
- 70-79: C
- 60-69: D
- Below 60: F

Also check if the score is valid (0-100).""",
                    "starter_code": """score = 85

# Add your grade calculation logic here
if score < 0 or score > 100:
    print("Invalid score")
# Add elif statements for grades
""",
                    "solution": """score = 85

# Add your grade calculation logic here
if score < 0 or score > 100:
    print("Invalid score")
elif score >= 90:
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
elif score >= 60:
    print("Grade: D")
else:
    print("Grade: F")""",
                    "test_cases": [
                        {
                            "name": "Correct grade for score 85",
                            "input": "",
                            "expected_output": "Grade: B"
                        }
                    ],
                    "xp_reward": 30
                }
            ]
        },
        {
            "id": 4,
            "chapter": 4,
            "title": "Loops and Control Flow",
            "slug": "loops-control-flow",
            "content": """
# Loops and Control Flow: Automating Repetitive Tasks

Loops are the workhorses of programming - they allow you to execute the same code multiple times without writing it repeatedly. Think of loops as your personal assistants that can perform repetitive tasks tirelessly and accurately.

## The Power of Repetition in Programming

Humans are terrible at repetitive tasks - we get bored, make mistakes, and lose focus. Computers excel at repetition. Loops harness this strength, allowing you to process large amounts of data, repeat actions until conditions are met, and automate workflows.

### Why Loops Are Essential
- **Efficiency**: Write code once, execute many times
- **Data Processing**: Handle collections of information systematically
- **Automation**: Repeat tasks until goals are achieved
- **Scalability**: Process any amount of data with the same code

## For Loops: Processing Collections Systematically
Iterate over sequences (lists, strings, ranges). For loops are perfect when you know what you want to iterate over - whether it's items in a list, characters in a string, or numbers in a range.

### Basic For Loop with Range
```python
# Print numbers 0 to 4
for i in range(5):
    print(i)

# Print numbers 1 to 5
for i in range(1, 6):
    print(i)

# Print even numbers 0 to 8
for i in range(0, 10, 2):
    print(i)
```

### For Loop with Lists
```python
fruits = ["apple", "banana", "cherry"]

# Iterate over items
for fruit in fruits:
    print(fruit)

# Iterate with index
for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")
```

### For Loop with Strings
```python
word = "Python"

for letter in word:
    print(letter)
```

## While Loops: Conditional Repetition
Repeat while condition is true. While loops are perfect when you don't know exactly how many times you need to repeat something - you just know you need to keep going until a condition changes.

```python
# Count down
count = 5
while count > 0:
    print(count)
    count -= 1
print("Blast off!")

# User input validation
password = ""
while len(password) < 6:
    password = input("Enter password (min 6 chars): ")
```

## Loop Control Statements: Fine-Tuning Execution

Sometimes you need more control over loop execution than simple repetition. Loop control statements give you the power to modify loop behavior on the fly.

### Break Statement: Emergency Exit
Exit the loop immediately. Think of break as an emergency exit - when you've found what you're looking for or encountered a condition that makes continuing pointless.

```python
# Find first even number
numbers = [1, 3, 5, 8, 9, 12]

for num in numbers:
    if num % 2 == 0:
        print(f"First even number: {num}")
        break
    print(f"Checking {num}")
```

### Continue Statement: Skip and Move On
Skip current iteration, continue with next. Continue is like saying "skip this one and move to the next" - useful for filtering or avoiding certain conditions.

```python
# Print only odd numbers
for i in range(10):
    if i % 2 == 0:
        continue
    print(i)  # Only prints odd numbers
```

### Pass Statement: Placeholder for Future Code
Placeholder for empty code blocks. Pass is Python's way of saying "nothing to do here, but the syntax requires something." It's useful during development when you're planning code structure.

```python
for i in range(5):
    if i == 3:
        pass  # Do nothing, but syntactically required
    else:
        print(i)
```

## Nested Loops
Loops inside other loops.

```python
# Multiplication table
for i in range(1, 4):
    for j in range(1, 4):
        result = i * j
        print(f"{i} x {j} = {result}")
    print()  # Empty line after each row
```

## Loop with Else
Else clause executes if loop completes without break.

```python
# Search for item
items = ["apple", "banana", "cherry"]
search = "grape"

for item in items:
    if item == search:
        print(f"Found {search}")
        break
else:
    print(f"{search} not found")
```

## Common Loop Patterns

### Accumulator Pattern
```python
# Sum of numbers
total = 0
for i in range(1, 11):
    total += i
print(f"Sum: {total}")

# Build a string
result = ""
for char in "hello":
    result += char.upper()
print(result)  # "HELLO"
```

### Counter Pattern
```python
# Count vowels
text = "hello world"
vowel_count = 0

for char in text:
    if char.lower() in "aeiou":
        vowel_count += 1

print(f"Vowels: {vowel_count}")
```

### Flag Pattern
```python
# Check if all numbers are positive
numbers = [1, 5, -3, 8, 2]
all_positive = True

for num in numbers:
    if num <= 0:
        all_positive = False
        break

print(f"All positive: {all_positive}")
```

## Best Practices
1. Use meaningful variable names in loops
2. Avoid infinite loops (ensure loop condition eventually becomes false)
3. Consider using break and continue to make code clearer
4. Use enumerate() when you need both index and value

Let's practice loops and control flow!
            """,
            "is_free": True,
            "xp_reward": 20,
            "exercises": [
                {
                    "id": "multiplication-table",
                    "title": "Multiplication Table",
                    "type": "python",
                    "instructions": """Create a multiplication table for numbers 1-5.

For each number from 1 to 5, print its multiplication table from 1 to 10.
Format: "2 x 3 = 6"

Add a blank line between each number's table.""",
                    "starter_code": """# Create multiplication table for 1-5
for num in range(1, 6):
    # Create table for current number
    
    # Add blank line
""",
                    "solution": """# Create multiplication table for 1-5
for num in range(1, 6):
    # Create table for current number
    for i in range(1, 11):
        result = num * i
        print(f"{num} x {i} = {result}")
    
    # Add blank line
    print()""",
                    "test_cases": [
                        {
                            "name": "Multiplication table format",
                            "input": "",
                            "expected_contains": ["1 x 1 = 1", "2 x 5 = 10", "5 x 10 = 50"]
                        }
                    ],
                    "xp_reward": 35,
                    "hints": [
                        "Use nested loops - outer for numbers 1-5, inner for 1-10",
                        "Use f-string formatting for clean output",
                        "Add print() for blank lines",
                        "Calculate result as num * i"
                    ]
                }
            ]
        },
        {
            "id": 5,
            "chapter": 5,
            "title": "Lists and Arrays",
            "slug": "lists-arrays",
            "content": """
# Lists and Arrays: Organizing Data Collections

Lists are one of Python's most versatile and powerful data structures. Think of a list as a smart container that can hold multiple items in a specific order, remember where each item is located, and allow you to easily add, remove, or modify items as needed.

## Understanding Lists: Your Data Organization Tool

In real life, we use lists constantly - shopping lists, to-do lists, contact lists. Programming lists work similarly but with superpowers: they can hold any type of data, grow and shrink dynamically, and provide powerful methods for manipulation.

### What are Lists?
Lists are ordered, mutable collections that can store multiple items. They're like numbered filing cabinets where each slot can hold any type of data, and you can always rearrange, add, or remove items.

### Why Lists Are Fundamental
- **Organization**: Group related data together logically
- **Flexibility**: Store different data types in the same list
- **Efficiency**: Built-in methods for common operations
- **Scalability**: Handle any number of items from zero to millions

```python
# Creating lists
fruits = ["apple", "banana", "cherry"]
numbers = [1, 2, 3, 4, 5]
mixed = ["hello", 42, True, 3.14]
empty_list = []

# Alternative creation
colors = list(["red", "green", "blue"])
```

## Accessing List Elements: Finding Your Data

Lists use indexing to locate specific items, like apartment numbers in a building. Understanding indexing is crucial for working effectively with lists.

### Indexing: Pinpoint Access
Python uses zero-based indexing, meaning the first item is at position 0, the second at position 1, and so on.
```python
fruits = ["apple", "banana", "cherry", "date"]

# Positive indexing (starts at 0)
print(fruits[0])   # "apple"
print(fruits[2])   # "cherry"

# Negative indexing (starts at -1 from end)
print(fruits[-1])  # "date"
print(fruits[-2])  # "cherry"
```

### Slicing: Extracting Portions
Slicing allows you to extract a portion of a list, creating a new list with selected elements. It's like photocopying specific pages from a book.
```python
numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

print(numbers[2:5])    # [2, 3, 4]
print(numbers[:3])     # [0, 1, 2]
print(numbers[7:])     # [7, 8, 9]
print(numbers[::2])    # [0, 2, 4, 6, 8]
print(numbers[::-1])   # [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
```

## Modifying Lists: Dynamic Data Management

Lists are mutable, meaning you can change their contents after creation. This flexibility makes them perfect for data that changes over time.

### Adding Elements: Growing Your Collection
Python provides several ways to add new items to lists, each suited for different situations.
```python
fruits = ["apple", "banana"]

# Append to end
fruits.append("cherry")
print(fruits)  # ["apple", "banana", "cherry"]

# Insert at specific position
fruits.insert(1, "orange")
print(fruits)  # ["apple", "orange", "banana", "cherry"]

# Extend with another list
more_fruits = ["grape", "kiwi"]
fruits.extend(more_fruits)
print(fruits)  # ["apple", "orange", "banana", "cherry", "grape", "kiwi"]
```

### Removing Elements: Cleaning Up Your Data
Just as you can add items, you can remove them using various methods depending on how you want to specify what to remove.
```python
fruits = ["apple", "banana", "cherry", "apple"]

# Remove by value (first occurrence)
fruits.remove("apple")
print(fruits)  # ["banana", "cherry", "apple"]

# Remove by index
removed = fruits.pop(1)
print(removed)  # "cherry"
print(fruits)   # ["banana", "apple"]

# Remove last element
last = fruits.pop()
print(last)     # "apple"
print(fruits)   # ["banana"]

# Clear all elements
fruits.clear()
print(fruits)   # []
```

### Modifying Elements
```python
colors = ["red", "green", "blue"]

# Change single element
colors[1] = "yellow"
print(colors)  # ["red", "yellow", "blue"]

# Change multiple elements
colors[0:2] = ["purple", "orange"]
print(colors)  # ["purple", "orange", "blue"]
```

## List Methods

### Useful Methods
```python
numbers = [3, 1, 4, 1, 5, 9, 2, 6]

# Count occurrences
count = numbers.count(1)
print(count)  # 2

# Find index of element
index = numbers.index(4)
print(index)  # 2

# Sort the list (modifies original)
numbers.sort()
print(numbers)  # [1, 1, 2, 3, 4, 5, 6, 9]

# Reverse the list
numbers.reverse()
print(numbers)  # [9, 6, 5, 4, 3, 2, 1, 1]

# Create sorted copy (original unchanged)
original = [3, 1, 4, 1, 5]
sorted_copy = sorted(original)
print(original)     # [3, 1, 4, 1, 5]
print(sorted_copy)  # [1, 1, 3, 4, 5]
```

## List Comprehensions
Create lists in a concise way.

```python
# Traditional way
squares = []
for x in range(10):
    squares.append(x**2)

# List comprehension
squares = [x**2 for x in range(10)]
print(squares)  # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# With condition
even_squares = [x**2 for x in range(10) if x % 2 == 0]
print(even_squares)  # [0, 4, 16, 36, 64]

# String manipulation
words = ["hello", "world", "python"]
uppercase = [word.upper() for word in words]
print(uppercase)  # ["HELLO", "WORLD", "PYTHON"]
```

## Multi-dimensional Lists
Lists containing other lists.

```python
# 2D list (matrix)
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

# Access elements
print(matrix[0])     # [1, 2, 3]
print(matrix[1][2])  # 6

# Modify elements
matrix[0][1] = 99
print(matrix[0])     # [1, 99, 3]
```

## Common Patterns

### Finding Elements
```python
numbers = [10, 25, 30, 45, 60]

# Check if element exists
if 30 in numbers:
    print("Found 30")

# Find maximum and minimum
max_num = max(numbers)
min_num = min(numbers)
print(f"Max: {max_num}, Min: {min_num}")

# Find index of maximum
max_index = numbers.index(max(numbers))
print(f"Max at index: {max_index}")
```

### Copying Lists
```python
original = [1, 2, 3, 4, 5]

# Shallow copy
copy1 = original.copy()
copy2 = original[:]
copy3 = list(original)

# Deep copy (for nested lists)
import copy
nested = [[1, 2], [3, 4]]
deep_copy = copy.deepcopy(nested)
```

## Best Practices
1. Use meaningful list names
2. Be careful with list references vs. copies
3. Use list comprehensions for simple transformations
4. Consider using enumerate() when you need indices
5. Use in operator to check membership

Let's practice working with lists!
            """,
            "is_free": True,
            "xp_reward": 20,
            "exercises": [
                {
                    "id": "list-operations",
                    "title": "List Management",
                    "type": "python",
                    "instructions": """Create a program that manages a shopping list.

1. Start with an empty list
2. Add these items: "eggs", "milk", "bread"
3. Insert "butter" at the beginning
4. Add "cheese" at the end
5. Remove "milk" from the list
6. Print the final list
7. Print the number of items
8. Check if "bread" is in the list""",
                    "starter_code": """# Start with empty shopping list
shopping_list = []

# Add your code here

print("Final list:", shopping_list)
print("Number of items:", len(shopping_list))
print("Bread in list:", "bread" in shopping_list)""",
                    "solution": """# Start with empty shopping list
shopping_list = []

# Add initial items
shopping_list.extend(["eggs", "milk", "bread"])

# Insert butter at beginning
shopping_list.insert(0, "butter")

# Add cheese at end
shopping_list.append("cheese")

# Remove milk
shopping_list.remove("milk")

print("Final list:", shopping_list)
print("Number of items:", len(shopping_list))
print("Bread in list:", "bread" in shopping_list)""",
                    "test_cases": [
                        {
                            "name": "Correct final list",
                            "input": "",
                            "expected_contains": ["butter", "eggs", "bread", "cheese"]
                        }
                    ],
                    "xp_reward": 30,
                    "hints": [
                        "Use extend() to add multiple items at once",
                        "Use insert(0, item) to add at beginning",
                        "Use append() to add at end",
                        "Use remove() to remove by value"
                    ]
                }
            ]
        },
        {
            "id": 6,
            "chapter": 6,
            "title": "Dictionaries and Key-Value Pairs",
            "slug": "dictionaries",
            "content": """
# Dictionaries and Key-Value Pairs: Smart Data Storage

Dictionaries are Python's implementation of hash tables - incredibly efficient data structures that store information as key-value pairs. Think of a dictionary as a smart filing system where instead of looking through every file, you can instantly find what you need by its label.

## Understanding Dictionaries: Real-World Data Relationships

In the real world, we naturally think in terms of relationships: a person has a name, age, and address; a book has a title, author, and ISBN. Dictionaries let you model these natural relationships in code, making your programs more intuitive and powerful.

### What are Dictionaries?
Dictionaries store data in key-value pairs. They're mutable, unordered collections that allow fast lookups by key. Unlike lists where you access items by position, dictionaries let you access items by meaningful names.

### Why Dictionaries Are Powerful
- **Semantic Access**: Use meaningful names instead of numeric indices
- **Fast Lookups**: Find data instantly regardless of dictionary size
- **Natural Modeling**: Represent real-world relationships directly
- **Flexible Structure**: Keys and values can be any immutable/any type respectively

```python
# Creating dictionaries
student = {
    "name": "Alice",
    "age": 20,
    "grade": "A",
    "courses": ["Python", "Math", "Science"]
}

# Empty dictionary
empty_dict = {}
also_empty = dict()
```

## Accessing Dictionary Values

```python
student = {"name": "Alice", "age": 20, "grade": "A"}

# Access by key
print(student["name"])      # "Alice"
print(student["age"])       # 20

# Safe access with get()
print(student.get("name"))           # "Alice"
print(student.get("height"))         # None
print(student.get("height", 160))     # 160 (default value)
```

## Modifying Dictionaries

```python
student = {"name": "Alice", "age": 20}

# Add or update values
student["grade"] = "A"         # Add new key-value pair
student["age"] = 21            # Update existing value
student.update({"city": "New York", "major": "CS"})

# Remove values
del student["age"]             # Remove key-value pair
grade = student.pop("grade")   # Remove and return value
last_item = student.popitem()  # Remove and return last item
student.clear()                # Remove all items
```

## Dictionary Methods

```python
student = {"name": "Alice", "age": 20, "grade": "A"}

# Get all keys, values, items
keys = student.keys()          # dict_keys(['name', 'age', 'grade'])
values = student.values()      # dict_values(['Alice', 20, 'A'])
items = student.items()        # dict_items([('name', 'Alice'), ...])

# Convert to lists if needed
key_list = list(student.keys())

# Check if key exists
if "name" in student:
    print("Name is present")

if "height" not in student:
    print("Height not specified")
```

## Looping Through Dictionaries

```python
student = {"name": "Alice", "age": 20, "grade": "A"}

# Loop through keys
for key in student:
    print(f"{key}: {student[key]}")

# Loop through values
for value in student.values():
    print(value)

# Loop through key-value pairs
for key, value in student.items():
    print(f"{key}: {value}")
```

## Dictionary Comprehensions

```python
# Create dictionary from lists
names = ["Alice", "Bob", "Charlie"]
ages = [20, 21, 22]
students = {name: age for name, age in zip(names, ages)}

# Filter and transform
numbers = [1, 2, 3, 4, 5]
squares = {n: n**2 for n in numbers if n % 2 == 0}
print(squares)  # {2: 4, 4: 16}
```

## Nested Dictionaries

```python
# Dictionary of dictionaries
students = {
    "alice": {
        "age": 20,
        "grade": "A",
        "courses": ["Python", "Math"]
    },
    "bob": {
        "age": 21,
        "grade": "B",
        "courses": ["Java", "Physics"]
    }
}

# Access nested values
print(students["alice"]["grade"])           # "A"
print(students["bob"]["courses"][0])        # "Java"
```

## Common Patterns

### Counting Items
```python
text = "hello world"
letter_count = {}

for letter in text:
    if letter in letter_count:
        letter_count[letter] += 1
    else:
        letter_count[letter] = 1

# Or using get()
for letter in text:
    letter_count[letter] = letter_count.get(letter, 0) + 1
```

### Grouping Data
```python
students = [
    {"name": "Alice", "grade": "A"},
    {"name": "Bob", "grade": "B"},
    {"name": "Charlie", "grade": "A"}
]

# Group by grade
by_grade = {}
for student in students:
    grade = student["grade"]
    if grade not in by_grade:
        by_grade[grade] = []
    by_grade[grade].append(student["name"])
```

## Best Practices
1. Use meaningful key names
2. Use get() for safe access
3. Consider defaultdict for counting/grouping
4. Use dictionary comprehensions for simple transformations
5. Be careful with mutable values (lists, dictionaries)

Master dictionaries to efficiently store and retrieve structured data!

## Why Use Decorators?
- **Separation of Concerns**: Keep your core logic clean
- **Reusability**: Apply the same behavior to multiple functions
- **DRY Principle**: Don't repeat yourself
- **Aspect-Oriented Programming**: Handle cross-cutting concerns like logging, timing, authentication

## Basic Decorator Syntax
```python
def my_decorator(func):
    def wrapper():
        print("Something before the function")
        result = func()
        print("Something after the function")
        return result
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")
```

## How Decorators Work
When you use `@my_decorator`, Python essentially does:
```python
say_hello = my_decorator(say_hello)
```

## Decorators with Arguments
```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with args: {args}")
        result = func(*args, **kwargs)
        print(f"Function returned: {result}")
        return result
    return wrapper

@my_decorator
def add(a, b):
    return a + b
```

## Real-World Examples

### 1. Timing Decorator
```python
import time
import functools

def timer(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.4f} seconds")
        return result
    return wrapper
```

### 2. Authentication Decorator
```python
def require_auth(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Check if user is authenticated
        if not hasattr(wrapper, 'authenticated') or not wrapper.authenticated:
            raise PermissionError("Authentication required")
        return func(*args, **kwargs)
    wrapper.authenticated = False
    return wrapper
```

### 3. Caching Decorator
```python
def cache(func):
    cache_dict = {}
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        key = str(args) + str(kwargs)
        if key in cache_dict:
            print(f"Cache hit for {func.__name__}")
            return cache_dict[key]
        
        result = func(*args, **kwargs)
        cache_dict[key] = result
        return result
    return wrapper
```

## Decorators with Parameters
```python
def repeat(times):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(3)
def greet(name):
    print(f"Hello, {name}!")
```

## Class-Based Decorators
```python
class CountCalls:
    def __init__(self, func):
        self.func = func
        self.count = 0
    
    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"Call {self.count} to {self.func.__name__}")
        return self.func(*args, **kwargs)
```

## Property Decorators
```python
class Circle:
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        return self._radius
    
    @radius.setter
    def radius(self, value):
        if value < 0:
            raise ValueError("Radius cannot be negative")
        self._radius = value
    
    @property
    def area(self):
        return 3.14159 * self._radius ** 2
```

## Best Practices
1. **Use `functools.wraps`** to preserve function metadata
2. **Handle `*args` and `**kwargs`** for maximum flexibility
3. **Return the original function's result**
4. **Consider performance implications** of wrapper functions
5. **Use descriptive names** for your decorators
6. **Document your decorators** well

## Advanced: Decorator Factory Pattern
```python
def validate_types(**expected_types):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Get function signature
            import inspect
            sig = inspect.signature(func)
            bound = sig.bind(*args, **kwargs)
            
            # Validate types
            for param_name, expected_type in expected_types.items():
                if param_name in bound.arguments:
                    value = bound.arguments[param_name]
                    if not isinstance(value, expected_type):
                        raise TypeError(f"{param_name} must be {expected_type.__name__}")
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

@validate_types(name=str, age=int)
def create_user(name, age):
    return {"name": name, "age": age}
```

Now let's practice these concepts with hands-on exercises!
            """,
            "is_free": True,
            "xp_reward": 20,
            "exercises": [
                {
                    "id": "basic-decorator",
                    "title": "Create a Basic Decorator",
                    "type": "python",
                    "instructions": """Create a decorator called `log_calls` that prints "Function called" before executing any decorated function.

Your decorator should work like this:
```python
@log_calls
def say_hello():
    return "Hello, World!"

# When called, should print:
# Function called
# And return: "Hello, World!"
```

Complete the decorator function below:""",
                    "starter_code": """def log_calls(func):
    # Your code here
    pass

@log_calls
def say_hello():
    return "Hello, World!"

# Test your decorator
result = say_hello()
print(f"Result: {result}")""",
                    "solution": """import functools

def log_calls(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print("Function called")
        return func(*args, **kwargs)
    return wrapper

@log_calls
def say_hello():
    return "Hello, World!"

# Test your decorator
result = say_hello()
print(f"Result: {result}")""",
                    "test_cases": [
                        {
                            "name": "Basic decorator functionality",
                            "input": "",
                            "expected_output": "Function called\nResult: Hello, World!"
                        }
                    ],
                    "xp_reward": 30,
                    "hints": [
                        "Remember to define a wrapper function inside your decorator",
                        "Use *args and **kwargs to handle any function signature",
                        "Don't forget to call the original function and return its result",
                        "Use functools.wraps to preserve function metadata"
                    ]
                },
                {
                    "id": "timer-decorator",
                    "title": "Build a Timer Decorator",
                    "type": "python",
                    "instructions": """Create a `timer` decorator that measures how long a function takes to execute and prints the execution time.

Your decorator should:
1. Record the start time before calling the function
2. Call the original function
3. Record the end time after the function completes
4. Print "Function took X.XXXX seconds" (4 decimal places)
5. Return the original result

Test it with the provided slow_function.""",
                    "starter_code": """import time
import functools

def timer(func):
    # Your code here
    pass

@timer
def slow_function():
    time.sleep(0.1)  # Simulate slow operation
    return "Task completed"

# Test your decorator
result = slow_function()
print(f"Result: {result}")""",
                    "solution": """import time
import functools

def timer(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"Function took {execution_time:.4f} seconds")
        return result
    return wrapper

@timer
def slow_function():
    time.sleep(0.1)  # Simulate slow operation
    return "Task completed"

# Test your decorator
result = slow_function()
print(f"Result: {result}")""",
                    "test_cases": [
                        {
                            "name": "Timer decorator measures execution time",
                            "input": "",
                            "expected_pattern": r"Function took 0\.\d{4} seconds\nResult: Task completed"
                        }
                    ],
                    "xp_reward": 40,
                    "hints": [
                        "Use time.time() to get the current timestamp",
                        "Calculate execution time by subtracting start from end time",
                        "Use f-string formatting with :.4f to show 4 decimal places",
                        "Don't forget to return the original function's result"
                    ]
                },
                {
                    "id": "cache-decorator",
                    "title": "Implement a Caching Decorator",
                    "type": "python",
                    "instructions": """Create a `cache` decorator that stores function results to avoid redundant calculations.

Your decorator should:
1. Store results in a dictionary with function arguments as the key
2. Return cached results for repeated calls with same arguments
3. Print "Cache hit!" when returning a cached result
4. Print "Computing result..." when calculating a new result

The provided fibonacci function will help test your caching logic.""",
                    "starter_code": """import functools

def cache(func):
    # Your code here
    pass

@cache
def fibonacci(n):
    print(f"Computing fibonacci({n})")
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Test your decorator
print("First call:")
result1 = fibonacci(5)
print(f"Result: {result1}")

print("\\nSecond call (should use cache):")
result2 = fibonacci(5) 
print(f"Result: {result2}")""",
                    "solution": """import functools

def cache(func):
    cache_dict = {}
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Create a key from arguments
        key = str(args) + str(sorted(kwargs.items()))
        
        if key in cache_dict:
            print("Cache hit!")
            return cache_dict[key]
        
        print("Computing result...")
        result = func(*args, **kwargs)
        cache_dict[key] = result
        return result
    return wrapper

@cache
def fibonacci(n):
    print(f"Computing fibonacci({n})")
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# Test your decorator
print("First call:")
result1 = fibonacci(5)
print(f"Result: {result1}")

print("\\nSecond call (should use cache):")
result2 = fibonacci(5) 
print(f"Result: {result2}")""",
                    "test_cases": [
                        {
                            "name": "Cache decorator avoids recomputation",
                            "input": "",
                            "expected_contains": ["Computing result...", "Cache hit!", "Result: 5"]
                        }
                    ],
                    "xp_reward": 50,
                    "hints": [
                        "Use a dictionary to store cached results",
                        "Create a unique key from the function arguments",
                        "Check if the key exists in cache before computing",
                        "Store the result in cache before returning it"
                    ]
                },
                {
                    "id": "parametrized-decorator",
                    "title": "Create a Parametrized Decorator",
                    "type": "python",
                    "instructions": """Create a `repeat` decorator that takes a parameter specifying how many times to execute the decorated function.

Your decorator should:
1. Accept a `times` parameter
2. Execute the decorated function the specified number of times
3. Return the result of the last execution

Usage example:
```python
@repeat(3)
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")  # Should print "Hello, Alice!" three times
```""",
                    "starter_code": """import functools

def repeat(times):
    # Your code here
    pass

@repeat(3)
def greet(name):
    print(f"Hello, {name}!")

# Test your decorator
greet("Alice")""",
                    "solution": """import functools

def repeat(times):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = None
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(3)
def greet(name):
    print(f"Hello, {name}!")

# Test your decorator
greet("Alice")""",
                    "test_cases": [
                        {
                            "name": "Repeat decorator executes function multiple times",
                            "input": "",
                            "expected_output": "Hello, Alice!\nHello, Alice!\nHello, Alice!"
                        }
                    ],
                    "xp_reward": 45,
                    "hints": [
                        "This is a decorator factory - it returns a decorator",
                        "You need three levels: repeat(times) -> decorator -> wrapper",
                        "Use a for loop to execute the function multiple times",
                        "Return the result of the last execution"
                    ]
                },
                {
                    "id": "property-decorator",
                    "title": "Master Property Decorators",
                    "type": "python",
                    "instructions": """Create a `Temperature` class that uses property decorators to manage temperature conversion between Celsius and Fahrenheit.

Your class should:
1. Store temperature internally in Celsius
2. Have a `celsius` property that can be read and set
3. Have a `fahrenheit` property that converts to/from Fahrenheit
4. Validate that temperature is not below absolute zero (-273.15°C)
5. Raise ValueError for invalid temperatures""",
                    "starter_code": """class Temperature:
    def __init__(self, celsius=0):
        # Your code here
        pass
    
    # Add your property decorators here
    
# Test your class
temp = Temperature(25)
print(f"Celsius: {temp.celsius}")
print(f"Fahrenheit: {temp.fahrenheit}")

temp.fahrenheit = 100
print(f"After setting F to 100:")
print(f"Celsius: {temp.celsius}")
print(f"Fahrenheit: {temp.fahrenheit}")""",
                    "solution": """class Temperature:
    def __init__(self, celsius=0):
        self._celsius = None
        self.celsius = celsius  # Use setter for validation
    
    @property
    def celsius(self):
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            raise ValueError("Temperature cannot be below absolute zero (-273.15°C)")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        celsius_value = (value - 32) * 5/9
        self.celsius = celsius_value  # Use celsius setter for validation

# Test your class
temp = Temperature(25)
print(f"Celsius: {temp.celsius}")
print(f"Fahrenheit: {temp.fahrenheit}")

temp.fahrenheit = 100
print(f"After setting F to 100:")
print(f"Celsius: {temp.celsius}")
print(f"Fahrenheit: {temp.fahrenheit}")""",
                    "test_cases": [
                        {
                            "name": "Temperature class with property decorators",
                            "input": "",
                            "expected_output": "Celsius: 25\nFahrenheit: 77.0\nAfter setting F to 100:\nCelsius: 37.77777777777778\nFahrenheit: 100.0"
                        }
                    ],
                    "xp_reward": 55,
                    "hints": [
                        "Use @property to create getter methods",
                        "Use @property_name.setter to create setter methods", 
                        "Store the actual value in a private attribute (e.g., _celsius)",
                        "Formula: F = C * 9/5 + 32, C = (F - 32) * 5/9",
                        "Use the celsius setter in the fahrenheit setter for validation"
                    ]
                }
            ]
        },
        {
            "id": 7,
            "chapter": 7,
            "title": "Control Structures: Conditions and Loops",
            "slug": "control-structures-advanced",
            "content": """
# Control Structures: Advanced Decision Making and Automation

Building on the foundation of basic conditionals and loops, this lesson explores more sophisticated control structures that give your programs true intelligence. You'll learn to combine conditions with logical operators, create complex decision trees, and implement advanced loop patterns that professional programmers use daily.

## Mastering Advanced Control Flow

Control structures are the nervous system of your programs - they determine how information flows and decisions are made. Advanced control structures let you handle complex real-world scenarios with elegance and efficiency.

### Why Advanced Control Structures Matter
- **Complex Logic**: Handle sophisticated business rules and requirements
- **Elegant Solutions**: Write cleaner, more maintainable code
- **Professional Patterns**: Use techniques employed in production systems
- **Problem Solving**: Break down complex problems into manageable pieces

# Control Structures: Conditions and Loops

## Conditional Statements

### The if Statement

Make decisions in your code based on conditions:

```python
age = 18

if age >= 18:
    print("You can vote!")
    print("You are an adult")
```

### if-else Statement

Handle both true and false cases:

```python
temperature = 75

if temperature > 80:
    print("It's hot outside!")
else:
    print("It's not too hot")
```

### if-elif-else Statement

Handle multiple conditions:

```python
grade = 85

if grade >= 90:
    letter_grade = "A"
elif grade >= 80:
    letter_grade = "B"
elif grade >= 70:
    letter_grade = "C"
elif grade >= 60:
    letter_grade = "D"
else:
    letter_grade = "F"

print(f"Your grade is: {letter_grade}")
```

## Comparison Operators

Compare values to make decisions:

```python
# Equality
5 == 5    # True
5 == 3    # False

# Inequality
5 != 3    # True
5 != 5    # False

# Greater than / less than
10 > 5    # True
3 < 8     # True
5 >= 5    # True (greater than or equal)
4 <= 3    # False (less than or equal)
```

## Logical Operators

Combine multiple conditions:

```python
age = 25
has_license = True

# AND - both conditions must be true
if age >= 18 and has_license:
    print("You can drive!")

# OR - at least one condition must be true
is_weekend = True
is_holiday = False

if is_weekend or is_holiday:
    print("No work today!")

# NOT - reverses the condition
is_raining = False

if not is_raining:
    print("Let's go for a walk!")
```

## For Loops

Repeat code for each item in a sequence:

```python
# Loop through a list
fruits = ["apple", "banana", "orange"]

for fruit in fruits:
    print(f"I like {fruit}")

# Loop through a string
for letter in "Python":
    print(letter)

# Loop with range()
for i in range(5):
    print(f"Number: {i}")

# Range with start, stop, step
for i in range(2, 10, 2):
    print(i)  # Prints: 2, 4, 6, 8
```

## While Loops

Repeat code while a condition is true:

```python
# Basic while loop
count = 1
while count <= 5:
    print(f"Count: {count}")
    count += 1  # Same as count = count + 1

# User input validation
password = ""
while password != "secret":
    password = input("Enter password: ")

print("Access granted!")
```

## Loop Control

Control loop execution with break and continue:

```python
# break - exit the loop early
for i in range(10):
    if i == 5:
        break  # Stop when i equals 5
    print(i)  # Prints: 0, 1, 2, 3, 4

# continue - skip to next iteration
for i in range(10):
    if i % 2 == 0:
        continue  # Skip even numbers
    print(i)  # Prints: 1, 3, 5, 7, 9
```

## Best Practices
1. **Keep conditions simple**: Break complex conditions into multiple if statements
2. **Use meaningful variable names**: Make your code readable
3. **Avoid deep nesting**: Too many nested conditions are hard to read
4. **Handle edge cases**: Consider what happens with unexpected input
5. **Use loop control wisely**: break and continue can make code clearer

Master control structures to make your programs intelligent and dynamic!
            """,
            "is_free": True,
            "xp_reward": 35,
            "exercises": [
                {
                    "id": "control-structures-advanced",
                    "title": "Build a Text Adventure Game",
                    "type": "project",
                    "instructions": """Create a text-based adventure game that uses conditional statements and loops.

Your game should include:
1. A welcome message and story setup
2. Multiple choices using if-elif-else statements
3. A game loop that continues until the player wins or loses
4. Input validation using while loops
5. At least 3 different possible endings
6. Use of logical operators (and, or, not)

Example flow:
- Player enters a mysterious forest
- Encounters different creatures/situations
- Must make choices that affect the outcome
- Game continues until reaching an ending""",
                    "starter_code": """# Text Adventure Game
print("Welcome to the Mysterious Forest!")
print("You find yourself at the edge of a dark forest...")

# Game variables
player_health = 100
has_sword = False
game_over = False

# Main game loop
while not game_over:
    # Your game logic here
    pass

print("Thanks for playing!")""",
                    "solution": """# Text Adventure Game
import random

print("Welcome to the Mysterious Forest!")
print("You find yourself at the edge of a dark forest...")
print()

# Game variables
player_health = 100
has_sword = False
has_key = False
game_over = False

while not game_over and player_health > 0:
    print(f"Health: {player_health}")
    print("\\nChoose your path:")
    print("1. Enter the dark forest")
    print("2. Follow the river")
    print("3. Climb the mountain")
    
    while True:
        choice = input("Enter choice (1-3): ")
        if choice in ["1", "2", "3"]:
            break
        print("Invalid choice. Please enter 1, 2, or 3.")
    
    if choice == "1":
        print("You enter the dark forest and find a sword!")
        has_sword = True
        
        encounter = random.randint(1, 3)
        if encounter == 1:
            print("A wolf appears!")
            if has_sword:
                print("You defeat the wolf with your sword!")
                print("You found a key!")
                has_key = True
            else:
                print("The wolf attacks! You lose 20 health.")
                player_health -= 20
                
    elif choice == "2":
        print("Following the river, you find a peaceful village.")
        if has_key:
            print("The villagers thank you for the key to their treasure!")
            print("YOU WIN! You are rewarded with gold!")
            game_over = True
        else:
            print("The villagers ask if you have their lost key.")
            player_health += 10  # Rest restores health
            
    elif choice == "3":
        print("Climbing the mountain is dangerous!")
        if random.randint(1, 2) == 1:
            print("You slip and fall! Lose 30 health.")
            player_health -= 30
        else:
            print("You find a healing potion! +25 health")
            player_health += 25

if player_health <= 0:
    print("\\nGAME OVER! Your health reached zero.")
else:
    print("\\nThanks for playing!")""",
                    "test_cases": [
                        {
                            "name": "Game uses control structures",
                            "input": "",
                            "expected_contains": ["while", "if", "elif", "else", "and", "or"]
                        }
                    ],
                    "xp_reward": 50,
                    "hints": [
                        "Use a while loop for the main game loop",
                        "Use if-elif-else for handling player choices",
                        "Use logical operators to check multiple conditions",
                        "Include input validation with while loops",
                        "Track game state with boolean variables"
                    ]
                }
            ]
        },
        {
            "id": 8,
            "chapter": 8,
            "title": "Lists and Tuples: Working with Collections",
            "slug": "lists-tuples-advanced",
            "content": """
# Lists and Tuples: Mastering Collection Data Types

This lesson dives deep into Python's two essential sequence types: lists and tuples. You'll learn when to choose each type, master advanced manipulation techniques, and discover powerful patterns that make your data handling more efficient and elegant.

## Understanding Sequence Types: The Right Tool for the Job

Choosing between lists and tuples isn't just about syntax - it's about understanding the nature of your data. This knowledge helps you write more efficient, bug-free code that clearly expresses your intentions to other developers.

### Why Sequence Mastery Matters
- **Performance**: Choose the most efficient data structure for your needs
- **Data Integrity**: Use immutability to prevent accidental changes
- **Code Clarity**: Express your intentions clearly through type choice
- **Memory Efficiency**: Understand the memory implications of your choices

# Lists and Tuples: Working with Collections

## Lists - Mutable Sequences

Lists store multiple items in a single variable and can be changed after creation.

### Creating Lists

```python
# Empty list
empty_list = []
names = list()  # Alternative way

# List with items
fruits = ["apple", "banana", "orange"]
numbers = [1, 2, 3, 4, 5]
mixed = ["hello", 42, 3.14, True]

# List from range
countdown = list(range(10, 0, -1))
print(countdown)  # [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
```

### Accessing List Items

```python
fruits = ["apple", "banana", "orange", "grape"]

# Positive indexing (starts at 0)
print(fruits[0])   # "apple"
print(fruits[1])   # "banana"
print(fruits[-1])  # "grape" (last item)
print(fruits[-2])  # "orange" (second to last)

# Slicing
print(fruits[1:3])   # ["banana", "orange"]
print(fruits[:2])    # ["apple", "banana"]
print(fruits[2:])    # ["orange", "grape"]
print(fruits[:])     # ["apple", "banana", "orange", "grape"] (full copy)
```

### List Methods

```python
numbers = [1, 2, 3]

# Adding items
numbers.append(4)           # Add to end: [1, 2, 3, 4]
numbers.insert(1, 1.5)      # Insert at index: [1, 1.5, 2, 3, 4]
numbers.extend([5, 6])      # Add multiple: [1, 1.5, 2, 3, 4, 5, 6]

# Removing items
numbers.remove(1.5)         # Remove first occurrence: [1, 2, 3, 4, 5, 6]
last_item = numbers.pop()   # Remove and return last: [1, 2, 3, 4, 5]
second_item = numbers.pop(1) # Remove at index: [1, 3, 4, 5]

# Other useful methods
fruits = ["apple", "banana", "apple", "orange"]
count = fruits.count("apple")  # 2
index = fruits.index("banana") # 1
fruits.reverse()               # Reverse in place
fruits.sort()                  # Sort in place
```

## Tuples - Immutable Sequences

Tuples are like lists but cannot be changed after creation.

### Creating Tuples

```python
# Empty tuple
empty_tuple = ()
empty_tuple = tuple()

# Tuple with items
coordinates = (10, 20)
colors = ("red", "green", "blue")

# Single item tuple (comma required!)
single = (42,)  # Without comma, it's just parentheses

# Without parentheses
point = 3, 4
print(point)  # (3, 4)
```

### When to Use Lists vs Tuples

```python
# Use lists for:
shopping_list = ["milk", "bread", "eggs"]  # Items may change
scores = [95, 87, 92, 88]                 # May add more scores

# Use tuples for:
coordinates = (10.5, 20.3)                # Fixed position
rgb_color = (255, 128, 0)                 # Fixed color values
database_record = ("John", 30, "Engineer") # Fixed structure
```

## List Comprehensions

Create lists efficiently with compact syntax:

```python
# Basic syntax: [expression for item in iterable]
squares = [x**2 for x in range(10)]
print(squares)  # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# With condition
even_squares = [x**2 for x in range(10) if x % 2 == 0]
print(even_squares)  # [0, 4, 16, 36, 64]

# Processing strings
names = ["alice", "bob", "charlie"]
capitalized = [name.capitalize() for name in names]
print(capitalized)  # ["Alice", "Bob", "Charlie"]
```

Master lists and tuples to effectively manage collections of data!
            """,
            "is_free": True,
            "xp_reward": 40,
            "exercises": [
                {
                    "id": "lists-tuples-advanced",
                    "title": "Build a Todo List Manager",
                    "type": "project",
                    "instructions": """Create a command-line todo list manager using lists and tuples.

Your program should:
1. Store todos as tuples with (task, priority, completed) structure
2. Use a list to store all todos
3. Implement functions to:
   - Add new todos with priority (1-5)
   - Mark todos as completed
   - Remove todos
   - Show all todos sorted by priority
   - Show only completed/incomplete todos
4. Use list comprehensions where appropriate
5. Allow the user to interact with the program through a menu""",
                    "starter_code": """# Todo List Manager

def add_todo(todo_list, task, priority=3):
    \"\"\"Add a new todo as a tuple (task, priority, completed)\"\"\"
    pass

def mark_completed(todo_list, task_index):
    \"\"\"Mark a todo as completed\"\"\"
    pass

def show_todos(todo_list, show_completed=None):
    \"\"\"Show todos, optionally filter by completion status\"\"\"
    pass

# Main program
todos = []

while True:
    print("\\n=== Todo List Manager ===")
    print("1. Add todo")
    print("2. Mark completed")
    print("3. Show all todos")
    print("4. Show completed todos")
    print("5. Show pending todos")
    print("6. Quit")
    
    choice = input("Choose option: ")
    # Implement menu logic here
    pass""",
                    "solution": """# Todo List Manager

def add_todo(todo_list, task, priority=3):
    \"\"\"Add a new todo as a tuple (task, priority, completed)\"\"\"
    todo = (task, priority, False)
    todo_list.append(todo)
    print(f"Added: {task} (Priority: {priority})")

def mark_completed(todo_list, task_index):
    \"\"\"Mark a todo as completed\"\"\"
    if 0 <= task_index < len(todo_list):
        task, priority, _ = todo_list[task_index]
        todo_list[task_index] = (task, priority, True)
        print(f"Marked completed: {task}")
    else:
        print("Invalid task number")

def show_todos(todo_list, show_completed=None):
    \"\"\"Show todos, optionally filter by completion status\"\"\"
    if not todo_list:
        print("No todos found")
        return
    
    # Filter todos based on completion status
    if show_completed is True:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list) if todo[2]]
        title = "Completed Todos"
    elif show_completed is False:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list) if not todo[2]]
        title = "Pending Todos"
    else:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list)]
        title = "All Todos"
    
    if not filtered_todos:
        print(f"No {title.lower()} found")
        return
    
    # Sort by priority (highest first)
    filtered_todos.sort(key=lambda x: x[1][1], reverse=True)
    
    print(f"\\n{title}:")
    for original_index, (task, priority, completed) in filtered_todos:
        status = "✓" if completed else "○"
        print(f"{original_index + 1:2}. {status} {task} (Priority: {priority})")

# Main program
todos = []

# Sample data
todos.extend([
    ("Learn Python basics", 5, False),
    ("Read a book", 2, False),
    ("Exercise", 4, True),
    ("Buy groceries", 3, False)
])

while True:
    print("\\n" + "="*30)
    print("     Todo List Manager")
    print("="*30)
    print("1. Add todo")
    print("2. Mark completed")
    print("3. Show all todos")
    print("4. Show completed todos")
    print("5. Show pending todos")
    print("6. Quit")
    
    choice = input("\\nChoose option (1-6): ")
    
    if choice == "1":
        task = input("Enter task: ")
        if task.strip():
            try:
                priority = int(input("Enter priority (1-5, default 3): ") or "3")
                if 1 <= priority <= 5:
                    add_todo(todos, task.strip(), priority)
                else:
                    print("Priority must be between 1 and 5")
            except ValueError:
                add_todo(todos, task.strip())
        else:
            print("Task cannot be empty")
    
    elif choice == "2":
        show_todos(todos, show_completed=False)
        if [todo for todo in todos if not todo[2]]:  # Check if any pending todos
            try:
                index = int(input("Enter task number to mark completed: ")) - 1
                mark_completed(todos, index)
            except ValueError:
                print("Please enter a valid number")
    
    elif choice == "3":
        show_todos(todos)
    
    elif choice == "4":
        show_todos(todos, show_completed=True)
    
    elif choice == "5":
        show_todos(todos, show_completed=False)
    
    elif choice == "6":
        print("Goodbye!")
        break
    
    else:
        print("Invalid choice. Please try again.")""",
                    "test_cases": [
                        {
                            "name": "Todo manager uses lists and tuples",
                            "input": "",
                            "expected_contains": ["tuple", "list", "append", "comprehension"]
                        }
                    ],
                    "xp_reward": 60,
                    "hints": [
                        "Store each todo as a tuple: (task, priority, completed)",
                        "Use a list to store all todo tuples",
                        "Use list comprehensions to filter todos",
                        "Remember tuples are immutable - create new ones to 'modify'",
                        "Sort todos by priority using the key parameter"
                    ]
                }
            ]
        },
        {
            "id": 9,
            "chapter": 9,
            "title": "Input/Output and Type Conversion",
            "slug": "input-output-types",
            "content": """
# Input/Output and Type Conversion: Building Interactive Programs

Creating programs that interact with users is where programming becomes truly exciting. This lesson teaches you how to build responsive, user-friendly applications that can gather information, validate input, and provide beautiful formatted output.

## The Art of Human-Computer Interaction

Great programs don't just process data - they communicate. Learning to handle user input gracefully and present output clearly is essential for creating applications that people actually want to use.

### Why I/O Mastery is Critical
- **User Experience**: Create programs people enjoy using
- **Data Validation**: Prevent errors and security issues
- **Professional Polish**: Present information in clear, formatted ways
- **Real-World Applications**: Most programs need to interact with users

# Input/Output and Type Conversion

## Getting User Input

### The input() Function

```python
# Basic input (always returns a string)
name = input("What's your name? ")
print(f"Hello, {name}!")

# Input with prompt
age_str = input("How old are you? ")
print(f"You entered: {age_str}")
print(f"Type: {type(age_str)}")  # <class 'str'>
```

### Converting Input to Numbers

```python
# Convert to integer
age_str = input("Enter your age: ")
age = int(age_str)
print(f"Next year you'll be {age + 1}")

# Convert to float
height_str = input("Enter your height in meters: ")
height = float(height_str)
print(f"Height in centimeters: {height * 100}")

# One-liner conversion
score = int(input("Enter your score: "))
price = float(input("Enter the price: "))
```

### Input Validation

```python
# Validate integer input
def get_integer(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Please enter a valid integer.")

# Validate range
def get_age():
    while True:
        age = get_integer("Enter your age: ")
        if 0 <= age <= 150:
            return age
        print("Age must be between 0 and 150.")

# Usage
age = get_age()
```

## Output Formatting

### String Formatting

```python
name = "Alice"
age = 25
height = 5.6

# f-strings (recommended, Python 3.6+)
print(f"Name: {name}, Age: {age}")
print(f"Height: {height:.1f} feet")
print(f"In 10 years: {age + 10}")

# format() method
print("Name: {}, Age: {}".format(name, age))
print("Height: {:.2f}".format(height))
```

## Type Conversion (Casting)

### Basic Type Conversions

```python
# To string
number = 42
text = str(number)
print(f"'{text}' is type {type(text)}")

# To integer
text = "123"
number = int(text)
print(f"{number} is type {type(number)}")

# To float
text = "3.14"
decimal = float(text)
print(f"{decimal} is type {type(decimal)}")

# To boolean
print(bool(1))     # True
print(bool(0))     # False
print(bool(""))    # False
print(bool("hi"))  # True
```

Master input/output to create interactive programs that communicate effectively with users!
            """,
            "is_free": True,
            "xp_reward": 30,
            "exercises": [
                {
                    "id": "input-output",
                    "title": "Build a Personal Budget Calculator",
                    "type": "project",
                    "instructions": """Create a personal budget calculator that takes user input and provides formatted output.

Your calculator should:
1. Ask for monthly income (with validation)
2. Collect expense categories and amounts:
   - Housing, Food, Transportation, Entertainment, Savings
3. Validate all numeric inputs
4. Calculate total expenses and remaining budget
5. Display a formatted budget report
6. Use proper string formatting for currency display""",
                    "starter_code": """# Personal Budget Calculator

def get_income():
    \"\"\"Get and validate monthly income\"\"\"
    pass

def get_expenses():
    \"\"\"Get expense amounts for each category\"\"\"
    categories = ["Housing", "Food", "Transportation", "Entertainment", "Savings"]
    expenses = {}
    # Implement expense collection with validation
    return expenses

# Main program
income = get_income()
expenses = get_expenses()
# Calculate and display budget report""",
                    "solution": """# Personal Budget Calculator

def get_income():
    \"\"\"Get and validate monthly income\"\"\"
    while True:
        try:
            income = float(input("Enter your monthly income: $"))
            if income > 0:
                return income
            print("Income must be positive!")
        except ValueError:
            print("Please enter a valid number.")

def get_expenses():
    \"\"\"Get expense amounts for each category\"\"\"
    categories = ["Housing", "Food", "Transportation", "Entertainment", "Savings"]
    expenses = {}
    
    print("\\nEnter your monthly expenses:")
    for category in categories:
        while True:
            try:
                amount = float(input(f"{category}: $"))
                if amount >= 0:
                    expenses[category] = amount
                    break
                print("Amount cannot be negative!")
            except ValueError:
                print("Please enter a valid number.")
    
    return expenses

# Main program
print("Personal Budget Calculator")
income = get_income()
expenses = get_expenses()

total_expenses = sum(expenses.values())
remaining = income - total_expenses

print("\\n" + "="*50)
print("           BUDGET REPORT")
print("="*50)
print(f"Monthly Income: ${income:>10,.2f}")
print("-"*50)

print("EXPENSES:")
for category, amount in expenses.items():
    pct = (amount / income) * 100 if income > 0 else 0
    print(f"{category:<15} ${amount:>8,.2f} ({pct:>5.1f}%)")

print("-"*50)
print(f"{'Total Expenses':<15} ${total_expenses:>8,.2f}")
print(f"{'Remaining':<15} ${remaining:>8,.2f}")
print("="*50)

if remaining >= 0:
    print(f"✓ You're UNDER budget by ${remaining:,.2f}")
else:
    print(f"✗ You're OVER budget by ${abs(remaining):,.2f}")""",
                    "test_cases": [
                        {
                            "name": "Calculator uses input validation and formatting",
                            "input": "",
                            "expected_contains": ["input(", "float(", "f\"", "try:", "except"]
                        }
                    ],
                    "xp_reward": 45,
                    "hints": [
                        "Use try-except blocks for input validation",
                        "Use f-strings for currency formatting with :,.2f",
                        "Calculate percentages as (amount/income) * 100",
                        "Use string alignment in formatting: < > ^",
                        "Validate that all inputs are positive numbers"
                    ]
                }
            ]
        },
        {
            "id": 10,
            "chapter": 10,
            "title": "File Operations: Reading and Writing Data",
            "slug": "file-operations",
            "content": """
# File Operations: Persistent Data Management

File operations unlock the power of persistent data storage - the ability to save information that survives beyond your program's execution. This lesson covers everything from basic text files to structured data formats like CSV and JSON, enabling you to build applications that remember.

## The Power of Persistence

Every useful application needs to store and retrieve data. Whether it's user preferences, application logs, or complex datasets, mastering file operations is essential for creating professional-grade software that can maintain state across sessions.

### Why File Operations Are Essential
- **Data Persistence**: Save information permanently
- **Integration**: Exchange data with other systems
- **Backup and Recovery**: Protect against data loss
- **Scalability**: Handle large datasets efficiently

# File Operations: Reading and Writing Data

## Opening and Closing Files

### The open() Function

```python
# Basic file opening
file = open("data.txt", "r")  # Read mode
content = file.read()
file.close()  # Always close files!

# Better: Using with statement (recommended)
with open("data.txt", "r") as file:
    content = file.read()
# File automatically closes when exiting the with block
```

### File Modes

```python
# Reading modes
with open("file.txt", "r") as f:    # Read (default)
    content = f.read()

# Writing modes
with open("file.txt", "w") as f:    # Write (overwrites existing)
    f.write("Hello World")

with open("file.txt", "a") as f:    # Append (adds to end)
    f.write("More text")
```

## Reading Files

### Reading Entire File

```python
# Read entire file as string
with open("story.txt", "r") as file:
    content = file.read()
    print(content)
```

### Reading Line by Line

```python
# Read all lines into a list
with open("lines.txt", "r") as file:
    lines = file.readlines()
    for line in lines:
        print(line.strip())  # Remove newline characters

# Best: Iterate directly over file object
with open("data.txt", "r") as file:
    for line in file:
        print(line.strip())
```

## Writing Files

### Writing Text

```python
# Write string to file
text = "Hello, World!\\nThis is line 2"
with open("output.txt", "w") as file:
    file.write(text)

# Write multiple lines
lines = ["Line 1\\n", "Line 2\\n", "Line 3\\n"]
with open("lines.txt", "w") as file:
    file.writelines(lines)
```

## Working with CSV Files

### Reading CSV

```python
import csv

# Basic CSV reading
with open("data.csv", "r") as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        print(row)  # Each row is a list
```

### Writing CSV

```python
import csv

# Write basic CSV
data = [
    ["Name", "Age", "City"],
    ["Alice", 25, "New York"],
    ["Bob", 30, "Chicago"]
]

with open("people.csv", "w", newline="") as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(data)
```

## Working with JSON Files

### Reading JSON

```python
import json

# Read JSON file
with open("data.json", "r") as file:
    data = json.load(file)
    print(data)
```

### Writing JSON

```python
import json

# Python object to JSON file
data = {
    "students": [
        {"name": "Alice", "grade": 95},
        {"name": "Bob", "grade": 87}
    ],
    "class": "Python 101"
}

with open("class_data.json", "w") as file:
    json.dump(data, file, indent=2)
```

## Best Practices

1. **Always use 'with' statements**: Ensures files are properly closed
2. **Handle exceptions**: File operations can fail
3. **Use appropriate encodings**: Specify encoding for text files
4. **Validate file paths**: Check if files exist before operations

Master file operations to create programs that persist and process data effectively!
            """,
            "is_free": True,
            "xp_reward": 45,
            "exercises": [
                {
                    "id": "file-operations",
                    "title": "Build a Personal Journal App",
                    "type": "project",
                    "instructions": """Create a personal journal application that saves entries to files.

Your journal app should:
1. Save journal entries with timestamps to a text file
2. Allow users to:
   - Write new entries
   - View all entries
   - Search entries by keyword
   - Export entries to different formats (txt, json)
3. Handle file operations safely with error handling
4. Store entries with metadata (date, mood)""",
                    "starter_code": """# Personal Journal App
import json
from datetime import datetime

class Journal:
    def __init__(self, filename="journal.txt"):
        self.filename = filename
    
    def write_entry(self, title, content, mood="neutral"):
        \"\"\"Write a new journal entry\"\"\"
        pass
    
    def view_entries(self, limit=10):
        \"\"\"View recent journal entries\"\"\"
        pass
    
    def search_entries(self, keyword):
        \"\"\"Search entries containing keyword\"\"\"
        pass

# Main program
journal = Journal()
# Add interactive menu here""",
                    "solution": """# Personal Journal App
import json
from datetime import datetime
import os

class Journal:
    def __init__(self, filename="journal.txt"):
        self.filename = filename
        self.json_filename = "journal_entries.json"
        self.entries = self.load_entries()
    
    def load_entries(self):
        \"\"\"Load entries from JSON file\"\"\"
        if os.path.exists(self.json_filename):
            try:
                with open(self.json_filename, "r", encoding="utf-8") as file:
                    return json.load(file)
            except json.JSONDecodeError:
                return []
        return []
    
    def save_entries(self):
        \"\"\"Save entries to JSON file\"\"\"
        with open(self.json_filename, "w", encoding="utf-8") as file:
            json.dump(self.entries, file, indent=2, ensure_ascii=False)
    
    def write_entry(self, title, content, mood="neutral"):
        \"\"\"Write a new journal entry\"\"\"
        entry = {
            "id": len(self.entries) + 1,
            "timestamp": datetime.now().isoformat(),
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
            "title": title,
            "content": content,
            "mood": mood
        }
        
        self.entries.append(entry)
        self.save_entries()
        
        # Also save to text file
        with open(self.filename, "a", encoding="utf-8") as file:
            file.write(f"\\n{'='*50}\\n")
            file.write(f"Date: {entry['date']} {entry['time']}\\n")
            file.write(f"Title: {entry['title']}\\n")
            file.write(f"Mood: {entry['mood']}\\n")
            file.write(f"{'='*50}\\n")
            file.write(f"{entry['content']}\\n")
        
        print(f"Entry '{title}' saved successfully!")
    
    def view_entries(self, limit=10):
        \"\"\"View recent journal entries\"\"\"
        if not self.entries:
            print("No journal entries found")
            return
        
        sorted_entries = sorted(self.entries, key=lambda x: x['timestamp'], reverse=True)
        
        print(f"\\nLast {min(limit, len(sorted_entries))} entries:")
        print("=" * 60)
        
        for entry in sorted_entries[:limit]:
            print(f"\\n{entry['title']} - {entry['date']}")
            print(f"Mood: {entry['mood']}")
            print(f"{entry['content'][:100]}...")
            print("-" * 40)
    
    def search_entries(self, keyword):
        \"\"\"Search entries containing keyword\"\"\"
        keyword = keyword.lower()
        matches = [entry for entry in self.entries 
                  if keyword in entry['title'].lower() or 
                     keyword in entry['content'].lower()]
        
        if not matches:
            print(f"No entries found containing '{keyword}'")
            return
        
        print(f"\\nFound {len(matches)} entries containing '{keyword}':")
        for entry in matches:
            print(f"\\n{entry['title']} - {entry['date']}")
            print(f"{entry['content'][:100]}...")

# Main program
def main():
    journal = Journal()
    
    while True:
        print("\\n=== Personal Journal ===")
        print("1. Write new entry")
        print("2. View recent entries")
        print("3. Search entries")
        print("4. Exit")
        
        choice = input("\\nChoose option: ")
        
        if choice == "1":
            title = input("Entry title: ")
            print("Enter your content (press Enter twice to finish):")
            content_lines = []
            empty_lines = 0
            while True:
                line = input()
                if line == "":
                    empty_lines += 1
                    if empty_lines >= 2:
                        break
                else:
                    empty_lines = 0
                content_lines.append(line)
            
            content = "\\n".join(content_lines)
            mood = input("Mood (happy/sad/neutral/excited): ") or "neutral"
            
            journal.write_entry(title, content, mood)
        
        elif choice == "2":
            limit = int(input("Number of entries to show (default 5): ") or "5")
            journal.view_entries(limit)
        
        elif choice == "3":
            keyword = input("Enter search keyword: ")
            journal.search_entries(keyword)
        
        elif choice == "4":
            print("Goodbye!")
            break
        
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()""",
                    "test_cases": [
                        {
                            "name": "Journal uses file operations correctly",
                            "input": "",
                            "expected_contains": ["with open", "json.dump", "json.load", "encoding"]
                        }
                    ],
                    "xp_reward": 70,
                    "hints": [
                        "Use 'with open' statements for safe file handling",
                        "Save entries in JSON format for structured data",
                        "Handle file exceptions with try-except blocks",
                        "Use encoding='utf-8' for text files",
                        "Store timestamps for chronological ordering"
                    ]
                }
            ]
        }
    ]
}

# Test data for Python exercises
PYTHON_TEST_ENVIRONMENT = {
    "imports": [
        "import functools",
        "import time", 
        "import sys",
        "from io import StringIO"
    ],
    "setup_code": """
# Capture stdout for testing
import sys
from io import StringIO

def capture_output(func, *args, **kwargs):
    old_stdout = sys.stdout
    sys.stdout = captured_output = StringIO()
    try:
        result = func(*args, **kwargs)
        output = captured_output.getvalue()
        return result, output.strip()
    finally:
        sys.stdout = old_stdout
"""
}