#!/usr/bin/env python3
"""
Database setup script for TypeQuest CLI
Supports both local SQLite and hosted PostgreSQL databases
"""
import sys
import os
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table

# Add current directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from database import DatabaseConnection, DatabaseConfig

console = Console()

def show_welcome():
    """Show welcome message"""
    console.print(Panel.fit(
        "🗄️ [bold cyan]TypeQuest Database Setup[/bold cyan]\n\n"
        "Choose your database configuration:\n"
        "• [bold]SQLite[/bold]: Local file database (default, no setup required)\n"
        "• [bold]PostgreSQL[/bold]: Cloud/hosted database (for production use)",
        border_style="cyan"
    ))

def setup_postgresql():
    """Setup PostgreSQL connection"""
    console.print("\n🐘 [bold]PostgreSQL Database Setup[/bold]")
    console.print("[dim]Enter your PostgreSQL connection details:[/dim]\n")
    
    # Get connection details
    host = Prompt.ask("Database Host", default="localhost")
    port = Prompt.ask("Port", default="5432")
    database = Prompt.ask("Database Name")
    username = Prompt.ask("Username")
    password = Prompt.ask("Password", password=True)
    
    # Construct database URL
    db_url = f"postgresql://{username}:{password}@{host}:{port}/{database}"
    
    console.print(f"\n🔗 Testing connection to: [dim]{host}:{port}/{database}[/dim]")
    
    # Test connection
    config = DatabaseConfig()
    config.set_database_url(db_url)
    
    db = DatabaseConnection()
    
    try:
        conn = db.get_connection()
        conn.close()
        console.print("✅ [green]Connection successful![/green]")
        
        # Run schema migration
        console.print("🔧 Setting up database schema...")
        db.execute_schema_migration()
        console.print("✅ [green]Database schema initialized![/green]")
        
        return True
        
    except Exception as e:
        console.print(f"❌ [red]Connection failed: {e}[/red]")
        return False

def setup_sqlite():
    """Setup SQLite database"""
    console.print("\n📁 [bold]SQLite Database Setup[/bold]")
    
    config = DatabaseConfig()
    db_path = config.app_dir / "typequest.db"
    
    console.print(f"Database will be created at: [dim]{db_path}[/dim]")
    
    # Clear any existing PostgreSQL config
    config.set_database_url("")
    
    db = DatabaseConnection()
    db.execute_schema_migration()
    
    console.print("✅ [green]SQLite database initialized![/green]")
    return True

def show_current_config():
    """Show current database configuration"""
    config = DatabaseConfig()
    db_url = config.get_database_url()
    
    if db_url:
        if db_url.startswith('postgresql://'):
            # Parse PostgreSQL URL for display (hide password)
            from urllib.parse import urlparse
            parsed = urlparse(db_url)
            masked_url = f"postgresql://{parsed.username}:***@{parsed.hostname}:{parsed.port}{parsed.path}"
            console.print(f"Current: [cyan]PostgreSQL[/cyan] - {masked_url}")
        else:
            console.print(f"Current: [yellow]Custom[/yellow] - {db_url}")
    else:
        config_path = config.app_dir / "typequest.db"
        console.print(f"Current: [green]SQLite[/green] - {config_path}")

def main():
    """Main setup function"""
    show_welcome()
    console.print()
    show_current_config()
    console.print()
    
    choices = [
        "SQLite (Local file database)",
        "PostgreSQL (Hosted database)", 
        "Show current configuration",
        "Exit"
    ]
    
    while True:
        console.print("What would you like to do?")
        for i, choice in enumerate(choices, 1):
            console.print(f"{i}. {choice}")
        
        selection = Prompt.ask("\nEnter your choice", choices=["1", "2", "3", "4"], default="1")
        
        if selection == "1":
            if setup_sqlite():
                console.print(Panel("✅ [green]SQLite setup complete![/green]\nYou can now use TypeQuest CLI.", border_style="green"))
                break
        
        elif selection == "2":
            if setup_postgresql():
                console.print(Panel("✅ [green]PostgreSQL setup complete![/green]\nYou can now use TypeQuest CLI with your hosted database.", border_style="green"))
                break
            else:
                if Confirm.ask("\nWould you like to try again?"):
                    continue
                else:
                    console.print("Setup cancelled. Falling back to SQLite.")
                    setup_sqlite()
                    break
        
        elif selection == "3":
            console.print()
            show_current_config()
            console.print()
        
        elif selection == "4":
            console.print("Setup cancelled.")
            break

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\nSetup cancelled.")
    except Exception as e:
        console.print(f"\n❌ [red]Error: {e}[/red]")