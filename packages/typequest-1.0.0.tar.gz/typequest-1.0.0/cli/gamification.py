"""
Gamification system for CLI application
"""

from datetime import datetime, timedelta
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from cli.config import Config

console = Console()

class GamificationManager:
    def __init__(self):
        self.config = Config()
        self.achievements = self.load_achievements()
    
    def load_achievements(self):
        """Load achievement definitions"""
        return {
            'welcome': {
                'name': 'Welcome to Boots!',
                'description': 'Create your account and start learning',
                'icon': '🎉',
                'xp_reward': 10,
                'type': 'milestone'
            },
            'first_lesson': {
                'name': 'First Step',
                'description': 'Complete your first lesson',
                'icon': '📚',
                'xp_reward': 15,
                'type': 'milestone'
            },
            'sql_beginner': {
                'name': 'SQL Beginner',
                'description': 'Complete 5 SQL exercises',
                'icon': '🗃️',
                'xp_reward': 25,
                'type': 'progress',
                'requirement': {'type': 'sql_exercises', 'count': 5}
            },
            'problem_solver': {
                'name': 'Problem Solver',
                'description': 'Solve 10 exercises correctly',
                'icon': '🧩',
                'xp_reward': 30,
                'type': 'progress',
                'requirement': {'type': 'exercises_solved', 'count': 10}
            },
            'streak_3': {
                'name': 'Getting Started',
                'description': 'Maintain a 3-day learning streak',
                'icon': '🔥',
                'xp_reward': 20,
                'type': 'streak',
                'requirement': {'type': 'streak_days', 'count': 3}
            },
            'streak_7': {
                'name': 'Week Warrior',
                'description': 'Maintain a 7-day learning streak',
                'icon': '⚡',
                'xp_reward': 50,
                'type': 'streak',
                'requirement': {'type': 'streak_days', 'count': 7}
            },
            'streak_30': {
                'name': 'Consistency King',
                'description': 'Maintain a 30-day learning streak',
                'icon': '👑',
                'xp_reward': 100,
                'type': 'streak',
                'requirement': {'type': 'streak_days', 'count': 30}
            },
            'xp_100': {
                'name': 'Century Club',
                'description': 'Earn 100 total XP',
                'icon': '💯',
                'xp_reward': 25,
                'type': 'milestone',
                'requirement': {'type': 'total_xp', 'count': 100}
            },
            'xp_500': {
                'name': 'Rising Star',
                'description': 'Earn 500 total XP',
                'icon': '⭐',
                'xp_reward': 50,
                'type': 'milestone',
                'requirement': {'type': 'total_xp', 'count': 500}
            },
            'xp_1000': {
                'name': 'Expert Learner',
                'description': 'Earn 1000 total XP',
                'icon': '🏆',
                'xp_reward': 100,
                'type': 'milestone',
                'requirement': {'type': 'total_xp', 'count': 1000}
            },
            'night_owl': {
                'name': 'Night Owl',
                'description': 'Complete exercises after 10 PM',
                'icon': '🦉',
                'xp_reward': 20,
                'type': 'special'
            },
            'early_bird': {
                'name': 'Early Bird',
                'description': 'Complete exercises before 7 AM',
                'icon': '🐦',
                'xp_reward': 20,
                'type': 'special'
            },
            'perfectionist': {
                'name': 'Perfectionist',
                'description': 'Solve 5 exercises without using hints',
                'icon': '🎯',
                'xp_reward': 40,
                'type': 'skill',
                'requirement': {'type': 'no_hints_exercises', 'count': 5}
            }
        }
    
    def check_achievement(self, user_id, achievement_slug):
        """Check and award a specific achievement"""
        if achievement_slug not in self.achievements:
            return False
        
        # Check if user already has this achievement
        if self.has_achievement(user_id, achievement_slug):
            return False
        
        achievement = self.achievements[achievement_slug]
        
        # Special achievements that are manually triggered
        if achievement_slug in ['welcome', 'first_lesson', 'night_owl', 'early_bird']:
            self.award_achievement(user_id, achievement_slug)
            return True
        
        # Check requirement-based achievements
        if 'requirement' in achievement:
            if self.check_requirement(user_id, achievement['requirement']):
                self.award_achievement(user_id, achievement_slug)
                return True
        
        return False
    
    def check_requirement(self, user_id, requirement):
        """Check if user meets a specific requirement"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        req_type = requirement['type']
        target_count = requirement['count']
        
        if req_type == 'sql_exercises':
            cursor.execute('''
                SELECT COUNT(*) FROM exercise_submissions 
                WHERE user_id = ? AND is_correct = TRUE AND exercise_id LIKE '%sql%'
            ''', (user_id,))
            
        elif req_type == 'exercises_solved':
            cursor.execute('''
                SELECT COUNT(*) FROM exercise_submissions 
                WHERE user_id = ? AND is_correct = TRUE
            ''', (user_id,))
            
        elif req_type == 'streak_days':
            from cli.user_manager import UserManager
            user_manager = UserManager()
            current_streak = user_manager.calculate_streak(user_id)
            conn.close()
            return current_streak >= target_count
            
        elif req_type == 'total_xp':
            cursor.execute('SELECT total_xp FROM users WHERE id = ?', (user_id,))
            result = cursor.fetchone()
            current_xp = result[0] if result else 0
            conn.close()
            return current_xp >= target_count
            
        elif req_type == 'no_hints_exercises':
            cursor.execute('''
                SELECT COUNT(*) FROM exercise_submissions 
                WHERE user_id = ? AND is_correct = TRUE AND hints_used = 0
            ''', (user_id,))
        
        else:
            conn.close()
            return False
        
        result = cursor.fetchone()
        current_count = result[0] if result else 0
        conn.close()
        
        return current_count >= target_count
    
    def has_achievement(self, user_id, achievement_slug):
        """Check if user already has an achievement"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id FROM user_achievements 
            WHERE user_id = ? AND achievement_slug = ?
        ''', (user_id, achievement_slug))
        
        result = cursor.fetchone()
        conn.close()
        
        return result is not None
    
    def award_achievement(self, user_id, achievement_slug):
        """Award achievement to user"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO user_achievements (user_id, achievement_slug)
            VALUES (?, ?)
        ''', (user_id, achievement_slug))
        
        # Award XP
        achievement = self.achievements[achievement_slug]
        xp_reward = achievement.get('xp_reward', 0)
        
        if xp_reward > 0:
            cursor.execute('''
                UPDATE users 
                SET total_xp = total_xp + ?, level = (total_xp + ?) / 100 + 1
                WHERE id = ?
            ''', (xp_reward, xp_reward, user_id))
        
        conn.commit()
        conn.close()
        
        # Display achievement notification
        self.display_achievement_notification(achievement)
    
    def display_achievement_notification(self, achievement):
        """Display achievement notification"""
        title = f"{achievement['icon']} Achievement Unlocked!"
        content = f"""
[bold cyan]{achievement['name']}[/bold cyan]
{achievement['description']}

+{achievement.get('xp_reward', 0)} XP
        """
        
        console.print()
        console.print(Panel(
            content.strip(),
            title=title,
            border_style="yellow",
            title_align="center"
        ))
        console.print()
    
    def check_all_achievements(self, user_id):
        """Check all possible achievements for a user"""
        new_achievements = []
        
        for achievement_slug in self.achievements:
            if self.check_achievement(user_id, achievement_slug):
                new_achievements.append(achievement_slug)
        
        return new_achievements
    
    def get_user_achievements(self, user_id):
        """Get all achievements for a user"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT achievement_slug, earned_at
            FROM user_achievements 
            WHERE user_id = ?
            ORDER BY earned_at DESC
        ''', (user_id,))
        
        user_achievements = []
        for row in cursor.fetchall():
            achievement_slug, earned_at = row
            if achievement_slug in self.achievements:
                achievement = self.achievements[achievement_slug].copy()
                achievement['earned_at'] = earned_at
                achievement['slug'] = achievement_slug
                user_achievements.append(achievement)
        
        conn.close()
        return user_achievements
    
    def display_achievements(self, user_id):
        """Display user's achievements"""
        user_achievements = self.get_user_achievements(user_id)
        all_achievements = self.achievements
        
        console.print("\n🏆 [bold cyan]Your Achievements[/bold cyan]\n")
        
        if not user_achievements:
            console.print("📭 [dim]No achievements yet. Start learning to unlock them![/dim]\n")
            return
        
        # Earned achievements
        console.print("✅ [bold green]Earned Achievements[/bold green]")
        earned_table = Table(show_header=False)
        earned_table.add_column("Icon", style="bold", width=4)
        earned_table.add_column("Achievement", style="cyan")
        earned_table.add_column("Description", style="white")
        earned_table.add_column("XP", style="green", justify="right")
        earned_table.add_column("Date", style="dim")
        
        total_achievement_xp = 0
        for achievement in user_achievements:
            earned_table.add_row(
                achievement['icon'],
                achievement['name'],
                achievement['description'],
                f"+{achievement.get('xp_reward', 0)}",
                datetime.fromisoformat(achievement['earned_at']).strftime('%Y-%m-%d')
            )
            total_achievement_xp += achievement.get('xp_reward', 0)
        
        console.print(earned_table)
        
        # Available achievements
        earned_slugs = [a['slug'] for a in user_achievements]
        available = [slug for slug in all_achievements if slug not in earned_slugs]
        
        if available:
            console.print(f"\n🎯 [bold yellow]Available Achievements[/bold yellow]")
            available_table = Table(show_header=False)
            available_table.add_column("Icon", style="dim", width=4)
            available_table.add_column("Achievement", style="dim")
            available_table.add_column("Description", style="dim white")
            available_table.add_column("XP", style="dim", justify="right")
            
            for slug in available[:10]:  # Show first 10
                achievement = all_achievements[slug]
                available_table.add_row(
                    "🔒",
                    achievement['name'],
                    achievement['description'],
                    f"+{achievement.get('xp_reward', 0)}"
                )
            
            console.print(available_table)
        
        console.print(f"\n📊 [bold]Achievement Stats:[/bold]")
        console.print(f"   🏆 Earned: {len(user_achievements)}/{len(all_achievements)}")
        console.print(f"   ⭐ Total Achievement XP: {total_achievement_xp}")
        
        completion_rate = (len(user_achievements) / len(all_achievements)) * 100
        console.print(f"   📈 Completion Rate: {completion_rate:.1f}%")
    
    def get_leaderboard(self, board_type='all_time', limit=20):
        """Get leaderboard data"""
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        if board_type == 'weekly':
            # Get weekly stats (last 7 days)
            start_date = (datetime.now() - timedelta(days=7)).isoformat()
            cursor.execute('''
                SELECT 
                    u.username,
                    u.total_xp,
                    u.level,
                    COUNT(es.id) as exercises_solved
                FROM users u
                LEFT JOIN exercise_submissions es ON u.id = es.user_id 
                    AND es.submitted_at >= ? AND es.is_correct = TRUE
                GROUP BY u.id
                ORDER BY COUNT(es.id) DESC, u.total_xp DESC
                LIMIT ?
            ''', (start_date, limit))
        else:
            # All-time leaderboard
            cursor.execute('''
                SELECT 
                    u.username,
                    u.total_xp,
                    u.level,
                    COUNT(es.id) as exercises_solved,
                    COUNT(DISTINCT ua.achievement_slug) as achievements
                FROM users u
                LEFT JOIN exercise_submissions es ON u.id = es.user_id AND es.is_correct = TRUE
                LEFT JOIN user_achievements ua ON u.id = ua.user_id
                GROUP BY u.id
                ORDER BY u.total_xp DESC
                LIMIT ?
            ''', (limit,))
        
        leaderboard = []
        for i, row in enumerate(cursor.fetchall(), 1):
            leaderboard.append({
                'rank': i,
                'username': row[0],
                'total_xp': row[1],
                'level': row[2],
                'exercises_solved': row[3],
                'achievements': row[4] if board_type == 'all_time' else 0
            })
        
        conn.close()
        return leaderboard
    
    def display_leaderboard(self, board_type='all_time'):
        """Display leaderboard"""
        leaderboard = self.get_leaderboard(board_type)
        
        title = "🏆 All-Time Leaderboard" if board_type == 'all_time' else "📈 Weekly Leaderboard"
        console.print(f"\n{title}\n")
        
        if not leaderboard:
            console.print("📭 [dim]No data available yet[/dim]")
            return
        
        table = Table()
        table.add_column("Rank", style="bold cyan", justify="center", width=6)
        table.add_column("Player", style="bold white")
        table.add_column("Level", style="green", justify="center")
        table.add_column("Total XP", style="cyan", justify="right")
        table.add_column("Exercises", style="yellow", justify="right")
        
        if board_type == 'all_time':
            table.add_column("Achievements", style="purple", justify="right")
        
        for entry in leaderboard:
            rank_display = ""
            if entry['rank'] == 1:
                rank_display = "🥇"
            elif entry['rank'] == 2:
                rank_display = "🥈"
            elif entry['rank'] == 3:
                rank_display = "🥉"
            else:
                rank_display = str(entry['rank'])
            
            if board_type == 'all_time':
                table.add_row(
                    rank_display,
                    entry['username'],
                    str(entry['level']),
                    str(entry['total_xp']),
                    str(entry['exercises_solved']),
                    str(entry['achievements'])
                )
            else:
                table.add_row(
                    rank_display,
                    entry['username'],
                    str(entry['level']),
                    str(entry['total_xp']),
                    str(entry['exercises_solved'])
                )
        
        console.print(table)
        console.print()
    
    def get_daily_challenge(self, user_id, date=None):
        """Get or create daily challenge"""
        if date is None:
            date = datetime.now().date().isoformat()
        
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Check if user completed today's challenge
        cursor.execute('''
            SELECT completed, completed_at, xp_earned
            FROM daily_challenges
            WHERE user_id = ? AND date = ?
        ''', (user_id, date))
        
        result = cursor.fetchone()
        
        if result:
            completed, completed_at, xp_earned = result
            status = {
                'completed': bool(completed),
                'completed_at': completed_at,
                'xp_earned': xp_earned
            }
        else:
            # Create new challenge entry
            cursor.execute('''
                INSERT INTO daily_challenges (user_id, date)
                VALUES (?, ?)
            ''', (user_id, date))
            conn.commit()
            
            status = {
                'completed': False,
                'completed_at': None,
                'xp_earned': 0
            }
        
        conn.close()
        
        # Generate challenge (for simplicity, we'll use a fixed challenge)
        challenge = {
            'title': 'Daily SQL Challenge',
            'description': 'Find all employees earning more than the average salary',
            'query': 'SELECT * FROM employees WHERE salary > (SELECT AVG(salary) FROM employees);',
            'dataset': 'company_db',
            'bonus_xp': 50,
            'status': status
        }
        
        return challenge
    
    def complete_daily_challenge(self, user_id, date=None):
        """Mark daily challenge as completed"""
        if date is None:
            date = datetime.now().date().isoformat()
        
        conn = self.config.get_db_connection()
        cursor = conn.cursor()
        
        # Update challenge status
        cursor.execute('''
            UPDATE daily_challenges 
            SET completed = TRUE, completed_at = ?, xp_earned = 50
            WHERE user_id = ? AND date = ?
        ''', (datetime.now().isoformat(), user_id, date))
        
        # Award XP
        cursor.execute('''
            UPDATE users 
            SET total_xp = total_xp + 50, level = (total_xp + 50) / 100 + 1
            WHERE id = ?
        ''', (user_id,))
        
        conn.commit()
        conn.close()
        
        console.print("\n🎉 [bold green]Daily Challenge Completed![/bold green]")
        console.print("💰 [cyan]+50 Bonus XP earned![/cyan]")
        
        return True