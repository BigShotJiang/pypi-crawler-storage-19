"""
Essential Python programming concepts to add to the comprehensive course
"""

# Control Structures Lesson
CONTROL_STRUCTURES_LESSON = {
    "id": 8,
    "chapter": 2,
    "title": "Control Structures: Conditions and Loops",
    "slug": "control-structures",
    "content": '''
# Control Structures: Conditions and Loops

## Conditional Statements

### The if Statement

Make decisions in your code based on conditions:

```python
age = 18

if age >= 18:
    print("You can vote!")
    print("You are an adult")
```

### if-else Statement

Handle both true and false cases:

```python
temperature = 75

if temperature > 80:
    print("It's hot outside!")
else:
    print("It's not too hot")
```

### if-elif-else Statement

Handle multiple conditions:

```python
grade = 85

if grade >= 90:
    letter_grade = "A"
elif grade >= 80:
    letter_grade = "B"
elif grade >= 70:
    letter_grade = "C"
elif grade >= 60:
    letter_grade = "D"
else:
    letter_grade = "F"

print(f"Your grade is: {letter_grade}")
```

## Comparison Operators

Compare values to make decisions:

```python
# Equality
5 == 5    # True
5 == 3    # False

# Inequality
5 != 3    # True
5 != 5    # False

# Greater than / less than
10 > 5    # True
3 < 8     # True
5 >= 5    # True (greater than or equal)
4 <= 3    # False (less than or equal)
```

## Logical Operators

Combine multiple conditions:

```python
age = 25
has_license = True

# AND - both conditions must be true
if age >= 18 and has_license:
    print("You can drive!")

# OR - at least one condition must be true
is_weekend = True
is_holiday = False

if is_weekend or is_holiday:
    print("No work today!")

# NOT - reverses the condition
is_raining = False

if not is_raining:
    print("Let's go for a walk!")
```

## For Loops

Repeat code for each item in a sequence:

```python
# Loop through a list
fruits = ["apple", "banana", "orange"]

for fruit in fruits:
    print(f"I like {fruit}")

# Loop through a string
for letter in "Python":
    print(letter)

# Loop with range()
for i in range(5):
    print(f"Number: {i}")

# Range with start, stop, step
for i in range(2, 10, 2):
    print(i)  # Prints: 2, 4, 6, 8
```

## While Loops

Repeat code while a condition is true:

```python
# Basic while loop
count = 1
while count <= 5:
    print(f"Count: {count}")
    count += 1  # Same as count = count + 1

# User input validation
password = ""
while password != "secret":
    password = input("Enter password: ")

print("Access granted!")
```

## Loop Control

Control loop execution with break and continue:

```python
# break - exit the loop early
for i in range(10):
    if i == 5:
        break  # Stop when i equals 5
    print(i)  # Prints: 0, 1, 2, 3, 4

# continue - skip to next iteration
for i in range(10):
    if i % 2 == 0:
        continue  # Skip even numbers
    print(i)  # Prints: 1, 3, 5, 7, 9
```

## Nested Loops

Loops inside other loops:

```python
# Multiplication table
for i in range(1, 4):
    for j in range(1, 4):
        result = i * j
        print(f"{i} × {j} = {result}")
    print()  # Empty line after each row
```

## Practical Examples

### Example 1: Number Guessing Game

```python
import random

secret_number = random.randint(1, 100)
attempts = 0
max_attempts = 7

print("Guess the number between 1 and 100!")

while attempts < max_attempts:
    guess = int(input(f"Attempt {attempts + 1}: Enter your guess: "))
    attempts += 1
    
    if guess == secret_number:
        print(f"Congratulations! You found it in {attempts} attempts!")
        break
    elif guess < secret_number:
        print("Too low!")
    else:
        print("Too high!")
        
    if attempts == max_attempts:
        print(f"Game over! The number was {secret_number}")
```

### Example 2: Grade Calculator

```python
total_score = 0
num_tests = 0

print("Enter test scores (enter -1 to finish):")

while True:
    score = float(input("Enter score: "))
    
    if score == -1:
        break
    
    if score < 0 or score > 100:
        print("Please enter a score between 0 and 100")
        continue
    
    total_score += score
    num_tests += 1

if num_tests > 0:
    average = total_score / num_tests
    print(f"Average score: {average:.1f}")
    
    if average >= 90:
        print("Grade: A")
    elif average >= 80:
        print("Grade: B")
    elif average >= 70:
        print("Grade: C")
    else:
        print("Grade: F")
else:
    print("No scores entered")
```

## Best Practices

1. **Keep conditions simple**: Break complex conditions into multiple if statements
2. **Use meaningful variable names**: Make your code readable
3. **Avoid deep nesting**: Too many nested conditions are hard to read
4. **Handle edge cases**: Consider what happens with unexpected input
5. **Use loop control wisely**: break and continue can make code clearer

Master control structures to make your programs intelligent and dynamic!
    ''',
    "is_free": True,
    "xp_reward": 35,
    "exercises": [
        {
            "id": "control-structures",
            "title": "Build a Text Adventure Game",
            "type": "project",
            "instructions": '''Create a text-based adventure game that uses conditional statements and loops.

Your game should include:
1. A welcome message and story setup
2. Multiple choices using if-elif-else statements
3. A game loop that continues until the player wins or loses
4. Input validation using while loops
5. At least 3 different possible endings
6. Use of logical operators (and, or, not)

Example flow:
- Player enters a mysterious forest
- Encounters different creatures/situations
- Must make choices that affect the outcome
- Game continues until reaching an ending''',
            "starter_code": '''# Text Adventure Game
print("Welcome to the Mysterious Forest!")
print("You find yourself at the edge of a dark forest...")

# Game variables
player_health = 100
has_sword = False
game_over = False

# Main game loop
while not game_over:
    # Your game logic here
    pass

print("Thanks for playing!")''',
            "solution": '''# Text Adventure Game
import random

print("Welcome to the Mysterious Forest!")
print("You find yourself at the edge of a dark forest...")
print()

# Game variables
player_health = 100
has_sword = False
has_key = False
game_over = False

while not game_over and player_health > 0:
    print(f"Health: {player_health}")
    print("\\nChoose your path:")
    print("1. Enter the dark forest")
    print("2. Follow the river")
    print("3. Climb the mountain")
    
    while True:
        choice = input("Enter choice (1-3): ")
        if choice in ["1", "2", "3"]:
            break
        print("Invalid choice. Please enter 1, 2, or 3.")
    
    if choice == "1":
        print("You enter the dark forest and find a sword!")
        has_sword = True
        
        encounter = random.randint(1, 3)
        if encounter == 1:
            print("A wolf appears!")
            if has_sword:
                print("You defeat the wolf with your sword!")
                print("You found a key!")
                has_key = True
            else:
                print("The wolf attacks! You lose 20 health.")
                player_health -= 20
                
    elif choice == "2":
        print("Following the river, you find a peaceful village.")
        if has_key:
            print("The villagers thank you for the key to their treasure!")
            print("YOU WIN! You are rewarded with gold!")
            game_over = True
        else:
            print("The villagers ask if you have their lost key.")
            player_health += 10  # Rest restores health
            
    elif choice == "3":
        print("Climbing the mountain is dangerous!")
        if random.randint(1, 2) == 1:
            print("You slip and fall! Lose 30 health.")
            player_health -= 30
        else:
            print("You find a healing potion! +25 health")
            player_health += 25

if player_health <= 0:
    print("\\nGAME OVER! Your health reached zero.")
else:
    print("\\nThanks for playing!")''',
            "test_cases": [
                {
                    "name": "Game uses control structures",
                    "input": "",
                    "expected_contains": ["while", "if", "elif", "else", "and", "or"]
                }
            ],
            "xp_reward": 50,
            "hints": [
                "Use a while loop for the main game loop",
                "Use if-elif-else for handling player choices",
                "Use logical operators to check multiple conditions",
                "Include input validation with while loops",
                "Track game state with boolean variables"
            ]
        }
    ]
}

# Lists and Tuples Lesson
LISTS_TUPLES_LESSON = {
    "id": 9,
    "chapter": 3,
    "title": "Lists and Tuples: Working with Collections",
    "slug": "lists-tuples",
    "content": '''
# Lists and Tuples: Working with Collections

## Lists - Mutable Sequences

Lists store multiple items in a single variable and can be changed after creation.

### Creating Lists

```python
# Empty list
empty_list = []
names = list()  # Alternative way

# List with items
fruits = ["apple", "banana", "orange"]
numbers = [1, 2, 3, 4, 5]
mixed = ["hello", 42, 3.14, True]

# List from range
countdown = list(range(10, 0, -1))
print(countdown)  # [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
```

### Accessing List Items

```python
fruits = ["apple", "banana", "orange", "grape"]

# Positive indexing (starts at 0)
print(fruits[0])   # "apple"
print(fruits[1])   # "banana"
print(fruits[-1])  # "grape" (last item)
print(fruits[-2])  # "orange" (second to last)

# Slicing
print(fruits[1:3])   # ["banana", "orange"]
print(fruits[:2])    # ["apple", "banana"]
print(fruits[2:])    # ["orange", "grape"]
print(fruits[:])     # ["apple", "banana", "orange", "grape"] (full copy)
```

### Modifying Lists

```python
fruits = ["apple", "banana", "orange"]

# Change single item
fruits[1] = "blueberry"
print(fruits)  # ["apple", "blueberry", "orange"]

# Change multiple items
fruits[1:3] = ["kiwi", "mango"]
print(fruits)  # ["apple", "kiwi", "mango"]
```

### List Methods

```python
numbers = [1, 2, 3]

# Adding items
numbers.append(4)           # Add to end: [1, 2, 3, 4]
numbers.insert(1, 1.5)      # Insert at index: [1, 1.5, 2, 3, 4]
numbers.extend([5, 6])      # Add multiple: [1, 1.5, 2, 3, 4, 5, 6]

# Removing items
numbers.remove(1.5)         # Remove first occurrence: [1, 2, 3, 4, 5, 6]
last_item = numbers.pop()   # Remove and return last: [1, 2, 3, 4, 5]
second_item = numbers.pop(1) # Remove at index: [1, 3, 4, 5]
numbers.clear()             # Remove all items: []

# Other useful methods
fruits = ["apple", "banana", "apple", "orange"]
count = fruits.count("apple")  # 2
index = fruits.index("banana") # 1
fruits.reverse()               # Reverse in place
fruits.sort()                  # Sort in place
```

### List Operations

```python
# Concatenation
list1 = [1, 2, 3]
list2 = [4, 5, 6]
combined = list1 + list2  # [1, 2, 3, 4, 5, 6]

# Repetition
repeated = [0] * 5        # [0, 0, 0, 0, 0]

# Membership testing
fruits = ["apple", "banana", "orange"]
print("apple" in fruits)     # True
print("grape" not in fruits) # True

# Length
print(len(fruits))  # 3
```

## Tuples - Immutable Sequences

Tuples are like lists but cannot be changed after creation.

### Creating Tuples

```python
# Empty tuple
empty_tuple = ()
empty_tuple = tuple()

# Tuple with items
coordinates = (10, 20)
colors = ("red", "green", "blue")

# Single item tuple (comma required!)
single = (42,)  # Without comma, it's just parentheses

# Without parentheses
point = 3, 4
print(point)  # (3, 4)
```

### Accessing Tuple Items

```python
point = (10, 20, 30)

# Same as lists
print(point[0])    # 10
print(point[-1])   # 30
print(point[1:3])  # (20, 30)
```

### Tuple Operations

```python
# Concatenation
tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)
combined = tuple1 + tuple2  # (1, 2, 3, 4, 5, 6)

# Repetition
repeated = (0,) * 5  # (0, 0, 0, 0, 0)

# Unpacking
point = (10, 20)
x, y = point
print(f"x: {x}, y: {y}")  # x: 10, y: 20

# Multiple assignment
name, age, city = ("Alice", 25, "New York")
```

### When to Use Lists vs Tuples

```python
# Use lists for:
shopping_list = ["milk", "bread", "eggs"]  # Items may change
scores = [95, 87, 92, 88]                 # May add more scores

# Use tuples for:
coordinates = (10.5, 20.3)                # Fixed position
rgb_color = (255, 128, 0)                 # Fixed color values
database_record = ("John", 30, "Engineer") # Fixed structure
```

## List Comprehensions

Create lists efficiently with compact syntax:

```python
# Basic syntax: [expression for item in iterable]
squares = [x**2 for x in range(10)]
print(squares)  # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# With condition
even_squares = [x**2 for x in range(10) if x % 2 == 0]
print(even_squares)  # [0, 4, 16, 36, 64]

# Processing strings
names = ["alice", "bob", "charlie"]
capitalized = [name.capitalize() for name in names]
print(capitalized)  # ["Alice", "Bob", "Charlie"]

# Nested comprehensions
matrix = [[i + j for j in range(3)] for i in range(3)]
print(matrix)  # [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
```

## Practical Examples

### Example 1: Grade Book

```python
class GradeBook:
    def __init__(self):
        self.students = []  # List of tuples: (name, grades_list)
    
    def add_student(self, name):
        self.students.append((name, []))
    
    def add_grade(self, student_name, grade):
        for i, (name, grades) in enumerate(self.students):
            if name == student_name:
                grades.append(grade)
                break
    
    def get_average(self, student_name):
        for name, grades in self.students:
            if name == student_name and grades:
                return sum(grades) / len(grades)
        return None
    
    def get_class_summary(self):
        summary = []
        for name, grades in self.students:
            if grades:
                avg = sum(grades) / len(grades)
                summary.append((name, avg))
        return sorted(summary, key=lambda x: x[1], reverse=True)

# Usage
gradebook = GradeBook()
gradebook.add_student("Alice")
gradebook.add_student("Bob")
gradebook.add_grade("Alice", 95)
gradebook.add_grade("Alice", 87)
gradebook.add_grade("Bob", 92)

print(f"Alice's average: {gradebook.get_average('Alice')}")
print("Class rankings:", gradebook.get_class_summary())
```

### Example 2: Shopping Cart

```python
def create_shopping_cart():
    cart = []  # List of tuples: (item_name, price, quantity)
    
    def add_item(item_name, price, quantity=1):
        # Check if item already exists
        for i, (name, p, q) in enumerate(cart):
            if name == item_name:
                cart[i] = (name, p, q + quantity)
                return
        # Add new item
        cart.append((item_name, price, quantity))
    
    def remove_item(item_name):
        cart[:] = [(name, price, qty) for name, price, qty in cart 
                   if name != item_name]
    
    def get_total():
        return sum(price * quantity for _, price, quantity in cart)
    
    def show_cart():
        if not cart:
            print("Cart is empty")
            return
        
        print("Shopping Cart:")
        total = 0
        for name, price, quantity in cart:
            subtotal = price * quantity
            total += subtotal
            print(f"  {name}: ${price:.2f} x {quantity} = ${subtotal:.2f}")
        print(f"Total: ${total:.2f}")
    
    return add_item, remove_item, get_total, show_cart

# Usage
add_item, remove_item, get_total, show_cart = create_shopping_cart()
add_item("Apples", 2.50, 3)
add_item("Bread", 3.99)
add_item("Milk", 4.25, 2)
show_cart()
```

## Best Practices

1. **Choose the right data structure**: Lists for changing data, tuples for fixed data
2. **Use meaningful names**: `student_names` not `list1`
3. **Consider list comprehensions**: More readable than loops for simple operations
4. **Be careful with mutability**: Lists can be changed, tuples cannot
5. **Use unpacking**: Clean way to extract tuple values

Master lists and tuples to effectively manage collections of data!
    ''',
    "is_free": True,
    "xp_reward": 40,
    "exercises": [
        {
            "id": "lists-tuples",
            "title": "Build a Todo List Manager",
            "type": "project",
            "instructions": '''Create a command-line todo list manager using lists and tuples.

Your program should:
1. Store todos as tuples with (task, priority, completed) structure
2. Use a list to store all todos
3. Implement functions to:
   - Add new todos with priority (1-5)
   - Mark todos as completed
   - Remove todos
   - Show all todos sorted by priority
   - Show only completed/incomplete todos
4. Use list comprehensions where appropriate
5. Allow the user to interact with the program through a menu''',
            "starter_code": '''# Todo List Manager

def add_todo(todo_list, task, priority=3):
    """Add a new todo as a tuple (task, priority, completed)"""
    pass

def mark_completed(todo_list, task_index):
    """Mark a todo as completed"""
    pass

def show_todos(todo_list, show_completed=None):
    """Show todos, optionally filter by completion status"""
    pass

# Main program
todos = []

while True:
    print("\\n=== Todo List Manager ===")
    print("1. Add todo")
    print("2. Mark completed")
    print("3. Show all todos")
    print("4. Show completed todos")
    print("5. Show pending todos")
    print("6. Quit")
    
    choice = input("Choose option: ")
    # Implement menu logic here
    pass''',
            "solution": '''# Todo List Manager

def add_todo(todo_list, task, priority=3):
    """Add a new todo as a tuple (task, priority, completed)"""
    todo = (task, priority, False)
    todo_list.append(todo)
    print(f"Added: {task} (Priority: {priority})")

def mark_completed(todo_list, task_index):
    """Mark a todo as completed"""
    if 0 <= task_index < len(todo_list):
        task, priority, _ = todo_list[task_index]
        todo_list[task_index] = (task, priority, True)
        print(f"Marked completed: {task}")
    else:
        print("Invalid task number")

def remove_todo(todo_list, task_index):
    """Remove a todo from the list"""
    if 0 <= task_index < len(todo_list):
        removed = todo_list.pop(task_index)
        print(f"Removed: {removed[0]}")
    else:
        print("Invalid task number")

def show_todos(todo_list, show_completed=None):
    """Show todos, optionally filter by completion status"""
    if not todo_list:
        print("No todos found")
        return
    
    # Filter todos based on completion status
    if show_completed is True:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list) if todo[2]]
        title = "Completed Todos"
    elif show_completed is False:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list) if not todo[2]]
        title = "Pending Todos"
    else:
        filtered_todos = [(i, todo) for i, todo in enumerate(todo_list)]
        title = "All Todos"
    
    if not filtered_todos:
        print(f"No {title.lower()} found")
        return
    
    # Sort by priority (highest first)
    filtered_todos.sort(key=lambda x: x[1][1], reverse=True)
    
    print(f"\\n{title}:")
    for original_index, (task, priority, completed) in filtered_todos:
        status = "✓" if completed else "○"
        print(f"{original_index + 1:2}. {status} {task} (Priority: {priority})")

def get_priority():
    """Get priority from user with validation"""
    while True:
        try:
            priority = int(input("Enter priority (1-5, default 3): ") or "3")
            if 1 <= priority <= 5:
                return priority
            else:
                print("Priority must be between 1 and 5")
        except ValueError:
            print("Please enter a valid number")

# Main program
todos = []

# Sample data
todos.extend([
    ("Learn Python basics", 5, False),
    ("Read a book", 2, False),
    ("Exercise", 4, True),
    ("Buy groceries", 3, False)
])

while True:
    print("\\n" + "="*30)
    print("     Todo List Manager")
    print("="*30)
    print("1. Add todo")
    print("2. Mark completed")
    print("3. Remove todo")
    print("4. Show all todos")
    print("5. Show completed todos")
    print("6. Show pending todos")
    print("7. Quit")
    
    choice = input("\\nChoose option (1-7): ")
    
    if choice == "1":
        task = input("Enter task: ")
        if task.strip():
            priority = get_priority()
            add_todo(todos, task.strip(), priority)
        else:
            print("Task cannot be empty")
    
    elif choice == "2":
        show_todos(todos, show_completed=False)
        if [todo for todo in todos if not todo[2]]:  # Check if any pending todos
            try:
                index = int(input("Enter task number to mark completed: ")) - 1
                mark_completed(todos, index)
            except ValueError:
                print("Please enter a valid number")
    
    elif choice == "3":
        show_todos(todos)
        if todos:
            try:
                index = int(input("Enter task number to remove: ")) - 1
                remove_todo(todos, index)
            except ValueError:
                print("Please enter a valid number")
    
    elif choice == "4":
        show_todos(todos)
    
    elif choice == "5":
        show_todos(todos, show_completed=True)
    
    elif choice == "6":
        show_todos(todos, show_completed=False)
    
    elif choice == "7":
        print("Goodbye!")
        break
    
    else:
        print("Invalid choice. Please try again.")''',
            "test_cases": [
                {
                    "name": "Todo manager uses lists and tuples",
                    "input": "",
                    "expected_contains": ["tuple", "list", "append", "comprehension"]
                }
            ],
            "xp_reward": 60,
            "hints": [
                "Store each todo as a tuple: (task, priority, completed)",
                "Use a list to store all todo tuples",
                "Use list comprehensions to filter todos",
                "Remember tuples are immutable - create new ones to 'modify'",
                "Sort todos by priority using the key parameter"
            ]
        }
    ]
}