"""
Django Models and Database lesson content
"""

DJANGO_MODELS_LESSON = {
    "id": 2,
    "chapter": 2,
    "title": "Django Models and Database",
    "slug": "django-models",
    "content": '''
# Django Models and Database: Your Data's Blueprint

Django models are the foundation of every Django application - they're where you define not just what your data looks like, but how it behaves. Think of models as the architectural blueprints for your application's data, complete with business rules, validation, and relationships.

## What are Django Models? The Heart of Your Application

In Django, a model is far more than just a Python class that defines database structure. It's a complete data abstraction that encapsulates everything about your application's entities - their attributes, behaviors, relationships, and business logic.

**Models are Your Single Source of Truth:**
- They define the authoritative structure for each piece of data
- They contain validation rules that ensure data integrity  
- They encapsulate business logic specific to each data type
- They manage relationships between different data entities

### The Magic of the ORM (Object-Relational Mapping)

Django's ORM transforms your Python classes into database tables automatically. This means you write Python code, and Django handles all the complex SQL behind the scenes. No more wrestling with database syntax - focus on your application logic.

### Why Models Matter

Models are the single, definitive source of truth about your data. They contain:
- Essential fields and behaviors of the data you're storing
- Database schema definition  
- Data validation rules
- Business logic related to your data

## Creating Your First Model

Let's create a Book model for our bookstore:

```python
# books/models.py
from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    isbn = models.CharField(max_length=13, unique=True)
    publication_date = models.DateField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    pages = models.IntegerField()
    available = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['title']
        verbose_name_plural = "Books"
```

## Field Types

Django provides many field types:

### Text Fields
- `CharField`: Short text (requires max_length)
- `TextField`: Long text
- `EmailField`: Email validation
- `URLField`: URL validation
- `SlugField`: URL-friendly strings

### Number Fields
- `IntegerField`: Integer numbers
- `DecimalField`: Decimal numbers (requires max_digits and decimal_places)
- `FloatField`: Floating point numbers

### Date/Time Fields
- `DateField`: Date only
- `TimeField`: Time only  
- `DateTimeField`: Date and time

### Other Fields
- `BooleanField`: True/False
- `FileField`: File uploads
- `ImageField`: Image uploads (requires Pillow)

## Field Options

Common options for all fields:

- `null=True`: Allow NULL values in database
- `blank=True`: Allow empty values in forms
- `default`: Default value
- `unique=True`: Ensure uniqueness
- `help_text`: Help text for forms
- `verbose_name`: Human-readable name

## Migrations

Migrations are Django's way of propagating model changes to the database:

```bash
# Create migration files
python manage.py makemigrations

# Apply migrations to database
python manage.py migrate
```

## Database Operations

### Creating Objects

```python
# Method 1: Create and save
book = Book(title="Django Guide", author="John Doe")
book.save()

# Method 2: Create in one step
book = Book.objects.create(
    title="Python Basics",
    author="Jane Smith",
    isbn="1234567890123",
    publication_date="2024-01-01",
    price=29.99,
    pages=350
)
```

### Querying Objects

```python
# Get all books
all_books = Book.objects.all()

# Filter books
available_books = Book.objects.filter(available=True)
expensive_books = Book.objects.filter(price__gt=50)

# Get single object
book = Book.objects.get(isbn="1234567890123")

# Order results
books_by_title = Book.objects.order_by('title')
newest_first = Book.objects.order_by('-created_at')
```

## Model Relationships

### One-to-Many (ForeignKey)

```python
class Author(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    
class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
```

### Many-to-Many

```python
class Category(models.Model):
    name = models.CharField(max_length=50)

class Book(models.Model):
    title = models.CharField(max_length=200)
    categories = models.ManyToManyField(Category)
```

## What's Next?

In the next lesson, we'll explore Django Views - the business logic layer that processes requests and returns responses.

Models store the data, views process it! 📊
    ''',
    "is_free": True,
    "xp_reward": 30,
    "exercises": [
        {
            "id": "django-models",
            "title": "Create Book Model",
            "type": "python",
            "instructions": "Create a comprehensive Book model with all the fields shown in the lesson.",
            "starter_code": "from django.db import models\n\nclass Book(models.Model):\n    # Add your fields here\n    pass",
            "solution": "from django.db import models\n\nclass Book(models.Model):\n    title = models.CharField(max_length=200)\n    author = models.CharField(max_length=100)\n    isbn = models.CharField(max_length=13, unique=True)\n    publication_date = models.DateField()\n    price = models.DecimalField(max_digits=6, decimal_places=2)\n    pages = models.IntegerField()\n    available = models.BooleanField(default=True)\n    created_at = models.DateTimeField(auto_now_add=True)\n    updated_at = models.DateTimeField(auto_now=True)\n    \n    def __str__(self):\n        return self.title\n    \n    class Meta:\n        ordering = ['title']",
            "test_cases": [
                {
                    "name": "Model fields defined correctly",
                    "input": "",
                    "expected_contains": ["CharField", "DecimalField", "BooleanField", "__str__"]
                }
            ],
            "xp_reward": 40,
            "hints": [
                "Remember to import models from django.db",
                "CharField requires max_length parameter",
                "Use DecimalField for prices with max_digits and decimal_places",
                "Add __str__ method to return a string representation"
            ]
        }
    ]
}