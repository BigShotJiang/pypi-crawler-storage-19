"""
Django Introduction and Setup lesson content
"""

DJANGO_INTRODUCTION_LESSON = {
    "id": 1,
    "chapter": 1,
    "title": "Django Introduction and Setup",
    "slug": "django-introduction",
    "content": '''
# Django Introduction and Setup: Building Professional Web Applications

Welcome to Django - the web framework for perfectionists with deadlines! Django isn't just another web framework; it's a complete ecosystem designed to take you from idea to production-ready web application with remarkable speed and reliability.

## What is Django? The Framework That Powers the Web

Django is a high-level Python web framework that enables rapid development of secure and maintainable websites. Born at a busy newspaper, Django was designed to handle the intense demands of newsroom deadlines while maintaining the highest standards of code quality and security.

### The Django Philosophy: Pragmatic Excellence

Django follows the "Don't Repeat Yourself" (DRY) principle and emphasizes convention over configuration. This isn't just about writing less code - it's about writing better code that's maintainable, testable, and scalable.

**Core Principles:**
- **Explicit is better than implicit**: Your code should be clear and readable
- **Loose coupling**: Components should be independent and interchangeable
- **Less code**: Achieve more functionality with fewer lines
- **Quick development**: From prototype to production rapidly

### Why Choose Django? The Professional's Toolkit

Django isn't just popular by accident - it's the framework of choice for companies that need reliability, security, and scalability. Here's why:

- **Fast Development**: Built-in features like admin panel, ORM, authentication save months of development time
- **Security First**: Protection against common vulnerabilities (CSRF, XSS, SQL injection) built into the framework
- **Battle-Tested Scalability**: Powers Instagram's 2 billion users, Pinterest's visual discovery engine, and NASA's mission-critical systems
- **Batteries Included**: Everything you need out of the box - no hunting for compatible libraries
- **Outstanding Documentation**: Comprehensive, beginner-friendly docs that professionals actually read
- **Vibrant Ecosystem**: Thousands of reusable apps and active community support

**Real-World Impact:**
- Instagram handles 95 million photos per day with Django
- Mozilla manages Firefox downloads and updates
- Pinterest serves 400 million monthly active users
- NASA uses Django for mission planning and data analysis

### Django Architecture: The MTV Pattern Explained

Django follows the Model-Template-View (MTV) architectural pattern, a clean separation of concerns that makes applications maintainable and testable. Think of it as organized teamwork where each component has a specific role:

**The MTV Components:**
- **Model**: The data expert - defines structure, relationships, and business rules for your data
- **Template**: The presentation specialist - handles how information looks to users (HTML + Django template language)  
- **View**: The coordinator - contains business logic and orchestrates models and templates

**Why MTV Works:**
- **Separation of Concerns**: Each component has one job and does it well
- **Reusability**: Models can be used by multiple views, templates by multiple contexts
- **Testability**: Each layer can be tested independently
- **Team Collaboration**: Designers work on templates, developers on models/views

**MTV vs MVC:** If you know Model-View-Controller (MVC), Django's "View" is like MVC's "Controller", and Django's "Template" is like MVC's "View". Django uses "View" to mean the component that processes requests and returns responses.

## Setting Up Django

### Prerequisites

Before starting with Django, you should have:
- Python 3.8+ installed
- Basic Python knowledge (variables, functions, classes)
- Understanding of web basics (HTTP, HTML, CSS)

### Installation Steps

1. **Create Virtual Environment**:
```bash
python -m venv django_env
source django_env/bin/activate  # On Windows: django_env\\Scripts\\activate
```

2. **Install Django**:
```bash
pip install Django==5.0
```

3. **Verify Installation**:
```bash
python -c "import django; print(django.get_version())"
```

### Creating Your First Project

```bash
# Create project
django-admin startproject bookstore
cd bookstore

# Run development server
python manage.py runserver
```

Visit http://127.0.0.1:8000 to see the Django welcome page!

### Project Structure

```
bookstore/
    manage.py          # Command-line utility
    bookstore/         # Project package
        __init__.py    
        settings.py    # Project settings
        urls.py        # URL declarations
        wsgi.py        # WSGI entry point
        asgi.py        # ASGI entry point
```

### Important Files

- **manage.py**: Command-line tool for administrative tasks
- **settings.py**: Configuration for your Django project
- **urls.py**: URL routing configuration
- **wsgi.py**: Entry point for WSGI-compatible web servers

## What's Next?

In the next lesson, we'll dive into Django models - the heart of any Django application where we define our data structure and interact with the database.

Ready to build something amazing with Django? Let's go!
    ''',
    "is_free": True,
    "xp_reward": 25,
    "exercises": [
        {
            "id": "django-setup",
            "title": "Django Project Setup",
            "type": "project",
            "instructions": "Set up your first Django project and verify everything works correctly.",
            "starter_code": "# Follow the setup instructions and document each step",
            "solution": "# Successfully created Django project and verified installation",
            "test_cases": [
                {
                    "name": "Django project created",
                    "input": "",
                    "expected_contains": ["manage.py", "settings.py"]
                }
            ],
            "xp_reward": 30,
            "hints": [
                "Use a virtual environment to isolate dependencies",
                "Make sure Python 3.8+ is installed",
                "The development server should start without errors"
            ]
        }
    ]
}