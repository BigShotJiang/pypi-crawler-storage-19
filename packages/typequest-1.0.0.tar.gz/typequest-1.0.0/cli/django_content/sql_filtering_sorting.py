"""
SQL Filtering and Sorting lesson content
"""

SQL_FILTERING_SORTING_LESSON = {
    "id": 33,
    "chapter": 33,  
    "title": "SQL Filtering and Sorting Query Results",
    "slug": "sql-filtering-sorting",
    "content": '''
# SQL Filtering and Sorting: Organizing Data Like a Pro

Think of filtering and sorting as organizing your music playlist. Spotify doesn't just dump all songs randomly - it filters by genre, sorts by popularity, and limits results to what you actually want to hear. SQL's filtering and sorting capabilities work the same way, helping you transform raw data into meaningful insights.

## Advanced WHERE Conditions: Precision Filtering

### Complex Logical Combinations
```sql
-- Instagram: Find rising stars (high engagement, not yet verified)
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE (follower_count > 50000 AND following < 1000) 
   OR (follower_count BETWEEN 10000 AND 50000 AND verified = 0);

-- YouTube: Find educational content with good engagement
SELECT title, views, likes, channel_name, duration
FROM youtube_videos  
WHERE (title LIKE '%Tutorial%' OR title LIKE '%Course%' OR title LIKE '%Learn%')
  AND views > 100000
  AND likes > 5000;
```

**💻 Practice Exercise: Complex WHERE Conditions**

Find Instagram users who are either:
- High-engagement accounts (followers > 100K AND following < 500) 
- OR rising micro-influencers (followers between 25K-75K AND not verified)

```sql
SELECT username, follower_count, following, verified
FROM instagram_users  
WHERE (follower_count > 100000 AND following < 500)
   OR (follower_count BETWEEN 25000 AND 75000 AND verified = 0)
ORDER BY follower_count DESC;

### Advanced Pattern Matching
```sql
-- Instagram: Find themed accounts (food, travel, fitness)
SELECT username, follower_count
FROM instagram_users
WHERE username LIKE '%food%' 
   OR username LIKE '%travel%' 
   OR username LIKE '%fitness%'
   OR username LIKE '%tech%';

-- YouTube: Find programming languages content  
SELECT title, views, channel_name
FROM youtube_videos
WHERE title LIKE '%Python%' 
   OR title LIKE '%JavaScript%' 
   OR title LIKE '%SQL%'
   OR title LIKE '%Java%';

-- Spotify: Find emotional or descriptive song titles
SELECT title, artist, streams
FROM spotify_songs
WHERE title LIKE '%Love%' 
   OR title LIKE '%Heart%' 
   OR title LIKE '%Dream%'
   OR title LIKE '%Night%';
```

**💻 Practice Exercise: Pattern Matching with LIKE**

Find YouTube videos about specific programming topics:
- Titles containing 'Python', 'Django', or 'API'
- Must have more than 50,000 views
- Sort by views descending

```sql
SELECT title, views, channel_name, likes
FROM youtube_videos
WHERE (title LIKE '%Python%' OR title LIKE '%Django%' OR title LIKE '%API%')
  AND views > 50000
ORDER BY views DESC;

### Range and List Filtering
```sql
-- Instagram: Find accounts in the "Goldilocks zone" (engaged but approachable)
SELECT username, follower_count, following
FROM instagram_users  
WHERE follower_count BETWEEN 5000 AND 25000
  AND following BETWEEN 100 AND 2000
  AND verified = 0;

-- YouTube: Find content from top educational channels
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE channel_name IN ('CodeAcademy', 'DataPro', 'DesignMaster', 'DevBootcamp', 'AITech')
  AND duration BETWEEN 600 AND 3600;  -- 10 minutes to 1 hour

-- Spotify: Find hits from the streaming era
SELECT title, artist, year, streams  
FROM spotify_songs
WHERE year IN (2017, 2018, 2019, 2020, 2021)
  AND streams > 1000000;
```

**💻 Practice Exercise: Range and List Filtering**

Find content from specific YouTube channels in a certain view range:
- Channels: 'CodeAcademy', 'DataPro', 'TechTalk', 'DevBootcamp'
- Views between 250,000 and 2,000,000
- Duration between 15-45 minutes (900-2700 seconds)

```sql
SELECT title, views, channel_name, duration, likes
FROM youtube_videos
WHERE channel_name IN ('CodeAcademy', 'DataPro', 'TechTalk', 'DevBootcamp')
  AND views BETWEEN 250000 AND 2000000
  AND duration BETWEEN 900 AND 2700
ORDER BY views DESC;

## ORDER BY: Sorting Your Results

Sorting transforms chaotic data into organized insights. It's the difference between a random pile of photos and a carefully curated Instagram feed.

### Basic Sorting Patterns
```sql
-- Instagram: Rank users by influence (follower count)
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC;  -- Highest first (descending)

-- YouTube: Find most viewed content
SELECT title, views, likes, channel_name
FROM youtube_videos
ORDER BY views DESC;

-- Spotify: Find latest releases
SELECT title, artist, year, streams
FROM spotify_songs  
ORDER BY year DESC, streams DESC;  -- Latest year first, then by popularity
```

**💻 Practice Exercise: Basic Sorting**

Sort Instagram users to find the most influential accounts:
- Show username, follower_count, and verified status
- Sort by follower count from highest to lowest
- Limit to top 15 results

```sql
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC
LIMIT 15;

### Multiple Column Sorting
```sql
-- Instagram: Sort by verification status, then by follower count
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY verified DESC,  -- Verified accounts first (1 before 0)
         follower_count DESC;  -- Then by follower count

-- YouTube: Sort by channel, then by performance within channel
SELECT channel_name, title, views, likes
FROM youtube_videos
ORDER BY channel_name ASC,  -- Alphabetical by channel
         views DESC;         -- Highest views within each channel

-- Spotify: Sort by artist, then by year, then by popularity
SELECT artist, title, year, streams
FROM spotify_songs
ORDER BY artist ASC,
         year DESC,  
         streams DESC;
```

**💻 Practice Exercise: Multiple Column Sorting**

Sort YouTube videos to organize content by channel performance:
- Sort by channel_name alphabetically (A-Z)
- Within each channel, sort by likes from highest to lowest
- Show title, channel_name, views, and likes

```sql
SELECT title, channel_name, views, likes
FROM youtube_videos
ORDER BY channel_name ASC,
         likes DESC;

### Sorting with Calculated Values
```sql
-- Instagram: Sort by engagement ratio (follower to following ratio)
SELECT username, follower_count, following,
       (follower_count * 1.0 / following) AS engagement_ratio
FROM instagram_users  
WHERE following > 0  -- Avoid division by zero
ORDER BY engagement_ratio DESC;

-- YouTube: Sort by engagement rate (likes per view)
SELECT title, views, likes, channel_name,
       (likes * 100.0 / views) AS engagement_rate
FROM youtube_videos
ORDER BY engagement_rate DESC;

-- Spotify: Sort by streams per year (popularity momentum)
SELECT title, artist, year, streams,
       (streams / (2024 - year + 1)) AS annual_stream_rate
FROM spotify_songs
WHERE year > 0
ORDER BY annual_stream_rate DESC;
```

**💻 Practice Exercise: Sorting with Calculated Values**

Calculate and sort Instagram accounts by their influence score:
- Calculate influence_score = follower_count / (following + 1) to avoid division by zero
- Show username, follower_count, following, and influence_score
- Sort by influence_score from highest to lowest
- Limit to top 20 accounts

```sql
SELECT username, follower_count, following,
       (follower_count * 1.0 / (following + 1)) AS influence_score
FROM instagram_users
ORDER BY influence_score DESC
LIMIT 20;

## LIMIT and OFFSET: Controlling Result Size

### Basic LIMIT Usage
```sql
-- Instagram: Top 10 influencers
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC
LIMIT 10;

-- YouTube: Top 5 most viewed videos
SELECT title, views, channel_name
FROM youtube_videos
ORDER BY views DESC
LIMIT 5;

-- Spotify: Top 3 most streamed songs
SELECT title, artist, streams
FROM spotify_songs
ORDER BY streams DESC
LIMIT 3;
```

**💻 Practice Exercise: Basic LIMIT**

Find the top performing content across platforms:
- Get top 7 Instagram users by follower count
- Show username, follower_count, and verified status

```sql
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC
LIMIT 7;

### Pagination with OFFSET
```sql
-- Instagram: Get results 11-20 (second page, 10 per page)
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC
LIMIT 10 OFFSET 10;  -- Skip first 10, get next 10

-- YouTube: Get results 6-10 (videos ranked 6th through 10th)
SELECT title, views, channel_name
FROM youtube_videos
ORDER BY views DESC
LIMIT 5 OFFSET 5;  -- Skip first 5, get next 5
```

**💻 Practice Exercise: Pagination with OFFSET**

Create pagination for Spotify songs:
- Get songs ranked 16-25 (skip first 15, get next 10)
- Sort by streams from highest to lowest
- Show title, artist, year, and streams

```sql
SELECT title, artist, year, streams
FROM spotify_songs
ORDER BY streams DESC
LIMIT 10 OFFSET 15;

## Real-World Query Combinations

### Social Media Analytics Queries
```sql
-- Instagram: Find potential brand partnership opportunities
-- (High engagement, specific follower range, not verified = lower cost)
SELECT username, follower_count, following, 
       (follower_count * 1.0 / following) AS influence_ratio
FROM instagram_users
WHERE follower_count BETWEEN 50000 AND 200000
  AND verified = 0
  AND following < 2000  -- Selective about who they follow
ORDER BY influence_ratio DESC
LIMIT 20;

-- YouTube: Content strategy analysis - find successful tutorial patterns
SELECT title, views, likes, duration, channel_name,
       (likes * 100.0 / views) AS engagement_rate
FROM youtube_videos
WHERE title LIKE '%Tutorial%' 
   OR title LIKE '%How to%'
   OR title LIKE '%Beginner%'
  AND views > 100000
ORDER BY engagement_rate DESC, views DESC
LIMIT 15;
```

**💻 Practice Exercise: Real-World Analytics**

Create a marketing analysis query:
- Find Instagram accounts perfect for brand partnerships
- Criteria: 15K-80K followers, not verified, following less than 1,500 people
- Calculate influence ratio (followers/following)
- Sort by influence ratio, limit to top 25

```sql
SELECT username, follower_count, following, verified,
       (follower_count * 1.0 / following) AS influence_ratio
FROM instagram_users
WHERE follower_count BETWEEN 15000 AND 80000
  AND verified = 0
  AND following < 1500
ORDER BY influence_ratio DESC
LIMIT 25;

### Music Industry Analysis  
```sql
-- Spotify: Find breakout artists (recent high-performing songs)
SELECT artist, title, year, streams,
       (streams / 1000000) AS millions_of_streams
FROM spotify_songs  
WHERE year >= 2019
  AND streams > 2000000
ORDER BY year DESC, streams DESC
LIMIT 25;

-- Spotify: Find "sleeper hits" (older songs still popular)
SELECT title, artist, year, streams,
       (2024 - year) AS years_old,
       (streams / (2024 - year + 1)) AS annual_stream_average
FROM spotify_songs
WHERE year < 2020
  AND streams > 1000000
ORDER BY annual_stream_average DESC
LIMIT 10;
```

### Content Discovery Queries
```sql
-- YouTube: Find "hidden gems" (great content from smaller channels)
SELECT title, views, likes, channel_name,
       (likes * 1.0 / views) AS like_ratio
FROM youtube_videos
WHERE views BETWEEN 10000 AND 100000  -- Not viral, but decent reach
  AND likes > 500
  AND channel_name NOT IN ('CodeAcademy', 'DataPro', 'DesignMaster')  -- Exclude big channels
ORDER BY like_ratio DESC
LIMIT 20;

-- Instagram: Find emerging influencers (rapid growth indicators)  
SELECT username, follower_count, following,
       (follower_count - following) AS net_followers
FROM instagram_users
WHERE follower_count BETWEEN 5000 AND 50000
  AND following < follower_count * 0.5  -- Following less than half their followers
  AND verified = 0
ORDER BY net_followers DESC, follower_count DESC
LIMIT 15;
```

## Advanced Filtering Patterns

### Exclusion Queries
```sql
-- Instagram: Find authentic accounts (exclude likely bots/spam)
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE follower_count > 1000
  AND following < follower_count * 2  -- Not following way more than followers
  AND username NOT LIKE '%123%'     -- Exclude numbered usernames
  AND username NOT LIKE '%bot%'     -- Exclude bot-like names
  AND username NOT LIKE '%spam%'    -- Exclude spam indicators
ORDER BY follower_count DESC;

-- YouTube: Find original content (exclude compilations/reactions)
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE title NOT LIKE '%Compilation%'
  AND title NOT LIKE '%React%'
  AND title NOT LIKE '%Review%'
  AND title NOT LIKE '%Top 10%'
  AND duration > 600  -- Longer than 10 minutes (substantial content)
ORDER BY views DESC;
```

**💻 Practice Exercise: Advanced Filtering (Exclusions)**

Find authentic, engaging Spotify songs by excluding common patterns:
- Exclude titles containing 'Remix', 'Cover', or 'Live'
- Must have more than 5 million streams
- Year must be 2020 or later
- Sort by streams descending

```sql
SELECT title, artist, year, streams
FROM spotify_songs
WHERE title NOT LIKE '%Remix%'
  AND title NOT LIKE '%Cover%'
  AND title NOT LIKE '%Live%'
  AND streams > 5000000
  AND year >= 2020
ORDER BY streams DESC;

### Performance Threshold Queries
```sql
-- Instagram: Find "unicorn" accounts (extremely high performance)
SELECT username, follower_count, following, verified,
       (follower_count * 1.0 / GREATEST(following, 1)) AS follower_ratio
FROM instagram_users
WHERE follower_count > 100000
  AND (follower_count * 1.0 / GREATEST(following, 1)) > 100  -- 100:1 ratio
ORDER BY follower_ratio DESC
LIMIT 10;

-- YouTube: Find viral education content
SELECT title, views, likes, channel_name, duration,
       (likes * 100.0 / views) AS engagement_rate
FROM youtube_videos
WHERE (title LIKE '%Learn%' OR title LIKE '%Tutorial%' OR title LIKE '%Course%')
  AND views > 1000000  -- Viral threshold
  AND engagement_rate > 2.0  -- High engagement
ORDER BY views DESC;
```

**💻 Practice Exercise: Performance Thresholds**

Find "viral potential" YouTube videos with extreme performance metrics:
- Views greater than 2 million
- Engagement rate (likes/views * 100) greater than 8%
- Duration between 5-20 minutes (300-1200 seconds)
- Calculate and show the engagement rate

```sql
SELECT title, views, likes, duration, channel_name,
       (likes * 100.0 / views) AS engagement_rate
FROM youtube_videos
WHERE views > 2000000
  AND (likes * 100.0 / views) > 8.0
  AND duration BETWEEN 300 AND 1200
ORDER BY engagement_rate DESC;

## Query Optimization Best Practices

### Efficient WHERE Clauses
```sql
-- ✅ Filter early, sort later
SELECT username, follower_count, verified
FROM instagram_users
WHERE verified = 1         -- Filter first (reduces dataset)
  AND follower_count > 10000
ORDER BY follower_count DESC  -- Sort the smaller result set
LIMIT 10;

-- ❌ Inefficient: sorting before filtering
-- This would sort all records then filter
```

### Smart LIMIT Usage
```sql
-- ✅ Use LIMIT to reduce data transfer
SELECT title, views, channel_name
FROM youtube_videos  
ORDER BY views DESC
LIMIT 20;  -- Only get what you need

-- ❌ Don't retrieve everything if you only need a few results
-- SELECT * FROM youtube_videos ORDER BY views DESC;
```

### Readable Query Formatting
```sql
-- ✅ Well-formatted, readable query
SELECT 
    username,
    follower_count,
    following,
    verified
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0
  AND following < 2000
ORDER BY follower_count DESC,
         following ASC
LIMIT 25;
```

## Common Query Patterns by Use Case

### Marketing Research
```sql
-- Find micro-influencers for brand partnerships
SELECT username, follower_count, (follower_count * 1.0 / following) AS ratio
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0
ORDER BY ratio DESC
LIMIT 50;
```

### Content Strategy
```sql
-- Find successful content patterns
SELECT title, views, likes, duration
FROM youtube_videos  
WHERE title LIKE '%Tutorial%'
  AND views > 50000
ORDER BY (likes * 100.0 / views) DESC
LIMIT 25;
```

### Competitive Analysis
```sql
-- Find top performers in category
SELECT artist, title, streams, year
FROM spotify_songs
WHERE year >= 2020
ORDER BY streams DESC
LIMIT 100;
```

Mastering filtering and sorting transforms you from someone who can retrieve data into someone who can discover insights. These patterns power the recommendation algorithms at Spotify, the trending algorithms at TikTok, and the search rankings at Google. Every data-driven decision starts with asking the right questions and organizing the answers effectively! 📊🎯
    ''',
    "is_free": False,
    "xp_reward": 95,
    "exercises": [
        {
            "id": "instagram-advanced-filtering",
            "title": "Advanced Instagram Analytics with Complex Filtering",
            "type": "practice",
            "instructions": """Practice complex WHERE conditions and sorting to analyze Instagram user patterns and find business opportunities.

Your tasks:
1. First, explore the data with SELECT * FROM instagram_users;
2. Find micro-influencers (10K-100K followers) who are not verified
3. Find potential rising stars (high follower ratio, not verified)
4. Find top 10 users by follower count
5. Find users sorted by verification status, then by follower count
6. Find authentic accounts (exclude potential bots/spam patterns)

Table: instagram_users
Columns: id, username, email, follower_count, following, verified""",
            "starter_code": """-- Task 1: Explore the data
SELECT * FROM instagram_users;

-- Task 2: Find non-verified micro-influencers (10K-100K followers)
-- Use BETWEEN and AND with verified = 0, order by follower_count DESC


-- Task 3: Find rising stars (follower_count > 25000, following < 1000, not verified)
-- Use multiple AND conditions to find selective, growing accounts


-- Task 4: Find top 10 users by follower count
-- Use ORDER BY and LIMIT to get the most followed accounts


-- Task 5: Sort by verification status first, then by follower count
-- Show verified accounts first, then sort each group by followers (DESC)


-- Task 6: Find authentic accounts (exclude numbered usernames, follower_count > 5000)
-- Use NOT LIKE to exclude usernames containing numbers, filter by follower count
""",
            "solution": """-- Task 1: Explore the data
SELECT * FROM instagram_users;

-- Task 2: Find non-verified micro-influencers (10K-100K followers)
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0
ORDER BY follower_count DESC;

-- Task 3: Find rising stars (selective, growing accounts)
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE follower_count > 25000
  AND following < 1000
  AND verified = 0
ORDER BY follower_count DESC;

-- Task 4: Find top 10 users by follower count  
SELECT username, follower_count, verified
FROM instagram_users
ORDER BY follower_count DESC
LIMIT 10;

-- Task 5: Sort by verification status first, then by follower count
SELECT username, follower_count, following, verified
FROM instagram_users
ORDER BY verified DESC,  -- Verified (1) before non-verified (0)
         follower_count DESC;

-- Task 6: Find authentic accounts (exclude numbered usernames)
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE follower_count > 5000
  AND username NOT LIKE '%123%'
  AND username NOT LIKE '%456%'
  AND username NOT LIKE '%_23'
ORDER BY follower_count DESC;""",
            "test_cases": [
                {
                    "name": "Complex WHERE with BETWEEN and AND",
                    "input": "SELECT * FROM instagram_users WHERE follower_count BETWEEN 10000 AND 100000 AND verified = 0;",
                    "expected_contains": ["WHERE", "BETWEEN", "AND", "verified"]
                },
                {
                    "name": "ORDER BY with multiple columns",
                    "input": "SELECT * FROM instagram_users ORDER BY verified DESC, follower_count DESC;", 
                    "expected_contains": ["ORDER BY", "verified", "follower_count", "DESC"]
                }
            ],
            "xp_reward": 65,
            "hints": [
                "BETWEEN includes both boundary values (10000 AND 100000)", 
                "Use AND to combine multiple WHERE conditions",
                "ORDER BY can sort by multiple columns - first by verified, then by follower_count",
                "NOT LIKE with % wildcards excludes pattern matches",
                "LIMIT comes after ORDER BY to get top results"
            ]
        },
        {
            "id": "youtube-content-discovery", 
            "title": "YouTube Content Discovery with Advanced Sorting",
            "type": "practice",
            "instructions": """Use advanced filtering and sorting to discover patterns in YouTube content performance and find optimization opportunities.

Your tasks:
1. Explore all video data first
2. Find top 5 most viewed videos
3. Find educational content (containing 'Tutorial', 'Course', or 'Learn') with good engagement
4. Find videos sorted by channel, then by views within each channel  
5. Calculate and sort by engagement rate (likes per 100 views)
6. Find "hidden gems" - videos with 100K-500K views and high like ratios

Table: youtube_videos
Columns: id, title, channel_name, views, likes, duration""",
            "starter_code": """-- Task 1: Explore all video data
SELECT * FROM youtube_videos;

-- Task 2: Find top 5 most viewed videos
-- Use ORDER BY views DESC and LIMIT 5


-- Task 3: Find educational content with good engagement (views > 500K, likes > 20K)
-- Use OR with LIKE patterns for 'Tutorial', 'Course', 'Learn' AND engagement thresholds


-- Task 4: Sort by channel, then by views within each channel
-- Use ORDER BY with channel_name ASC, then views DESC


-- Task 5: Calculate and sort by engagement rate (likes per 100 views)
-- Create calculated column for (likes * 100.0 / views), order by it DESC


-- Task 6: Find hidden gems (100K-500K views, high engagement)
-- Use BETWEEN for views, calculate like ratio, filter for ratio > 5.0
""",
            "solution": """-- Task 1: Explore all video data
SELECT * FROM youtube_videos;

-- Task 2: Find top 5 most viewed videos
SELECT title, views, channel_name, likes
FROM youtube_videos
ORDER BY views DESC
LIMIT 5;

-- Task 3: Find educational content with good engagement  
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE (title LIKE '%Tutorial%' 
    OR title LIKE '%Course%' 
    OR title LIKE '%Learn%')
  AND views > 500000
  AND likes > 20000
ORDER BY views DESC;

-- Task 4: Sort by channel, then by views within each channel
SELECT channel_name, title, views, likes
FROM youtube_videos
ORDER BY channel_name ASC,
         views DESC;

-- Task 5: Calculate and sort by engagement rate
SELECT title, views, likes, channel_name,
       (likes * 100.0 / views) AS engagement_rate
FROM youtube_videos
ORDER BY engagement_rate DESC;

-- Task 6: Find hidden gems with high engagement
SELECT title, views, likes, channel_name,
       (likes * 100.0 / views) AS like_ratio
FROM youtube_videos  
WHERE views BETWEEN 100000 AND 500000
  AND (likes * 100.0 / views) > 5.0
ORDER BY like_ratio DESC;""",
            "test_cases": [
                {
                    "name": "ORDER BY with LIMIT",
                    "input": "SELECT * FROM youtube_videos ORDER BY views DESC LIMIT 5;",
                    "expected_contains": ["ORDER BY", "views", "DESC", "LIMIT", "5"]
                },
                {
                    "name": "Calculated column with ORDER BY",
                    "input": "SELECT title, (likes * 100.0 / views) AS rate FROM youtube_videos ORDER BY rate DESC;",
                    "expected_contains": ["likes", "*", "/", "views", "ORDER BY", "rate"]
                }
            ],
            "xp_reward": 70,
            "hints": [
                "Use OR to combine multiple LIKE patterns for educational content",
                "Multiply by 100.0 to get engagement rate as percentage",
                "BETWEEN includes both boundary values for the view count range", 
                "ORDER BY can use calculated columns (engagement_rate)",
                "Use meaningful aliases for calculated columns to improve readability"
            ]
        }
    ]
}