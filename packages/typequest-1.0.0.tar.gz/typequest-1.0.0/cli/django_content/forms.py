"""
Django Forms and User Input lesson content
"""

DJANGO_FORMS_LESSON = {
    "id": 5,
    "chapter": 5,
    "title": "Django Forms and User Input",
    "slug": "django-forms",
    "content": '''
# Django Forms and User Input

## What are Django Forms?

Django Forms provide a powerful way to handle HTML forms, validate user input, and convert form data to Python data types. They make it easy to generate HTML forms, validate user input, and handle form processing securely.

### Why Use Django Forms?

- **Automatic HTML generation**: Generate form HTML automatically
- **Data validation**: Built-in and custom validation rules
- **Security**: CSRF protection and XSS prevention
- **Error handling**: Display validation errors to users
- **Data conversion**: Convert form data to proper Python types
- **Reusability**: Use the same form in multiple views

## Form Basics

### Creating Your First Form

```python
# books/forms.py
from django import forms
from .models import Book

class BookForm(forms.Form):
    title = forms.CharField(
        max_length=200,
        help_text="Enter the book title"
    )
    author = forms.CharField(max_length=100)
    isbn = forms.CharField(
        max_length=13,
        label="ISBN",
        help_text="13-digit ISBN number"
    )
    publication_date = forms.DateField(
        help_text="Publication date (YYYY-MM-DD)"
    )
    price = forms.DecimalField(
        max_digits=6,
        decimal_places=2,
        min_value=0.01
    )
    pages = forms.IntegerField(min_value=1)
    available = forms.BooleanField(
        required=False,
        initial=True,
        help_text="Is this book currently available?"
    )
    description = forms.CharField(
        widget=forms.Textarea,
        required=False,
        help_text="Brief description of the book"
    )
```

### ModelForms

For database-backed forms, use ModelForm:

```python
# books/forms.py
from django import forms
from .models import Book

class BookModelForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'publication_date', 
                 'price', 'pages', 'available', 'description']
        
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'publication_date': forms.DateInput(attrs={'type': 'date'}),
            'price': forms.NumberInput(attrs={'step': '0.01'})
        }
        
        labels = {
            'isbn': 'ISBN Number',
            'available': 'Currently Available'
        }
        
        help_texts = {
            'isbn': 'Enter the 13-digit ISBN',
            'price': 'Price in USD'
        }
```

## Form Fields

### Common Field Types

```python
# Text fields
CharField()                    # Single-line text
EmailField()                   # Email validation
URLField()                     # URL validation
SlugField()                    # Alphanumeric + hyphens/underscores

# Number fields
IntegerField()                 # Integer numbers
DecimalField()                 # Decimal numbers
FloatField()                   # Float numbers

# Choice fields
BooleanField()                 # Checkbox
ChoiceField()                  # Select dropdown
MultipleChoiceField()          # Multiple selections

# Date/time fields
DateField()                    # Date picker
TimeField()                    # Time picker
DateTimeField()                # Date and time

# File fields
FileField()                    # File upload
ImageField()                   # Image upload (requires Pillow)
```

### Field Arguments

Common arguments for all field types:

```python
field = forms.CharField(
    max_length=100,           # Maximum length
    min_length=2,             # Minimum length
    required=True,            # Required field (default)
    initial="Default value",   # Default value
    label="Display Name",     # Form label
    help_text="Help text",    # Help text
    widget=forms.TextInput,   # Custom widget
    validators=[validators]   # Custom validators
)
```

## Form Processing

### Basic Form View

```python
# books/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import BookModelForm

def add_book(request):
    if request.method == 'POST':
        form = BookModelForm(request.POST)
        
        if form.is_valid():
            book = form.save()
            messages.success(request, f'Book "{book.title}" added successfully!')
            return redirect('books:book-detail', book_id=book.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    
    else:
        form = BookModelForm()
    
    context = {'form': form}
    return render(request, 'books/add_book.html', context)
```

### Form Template

```html
<!-- books/templates/books/add_book.html -->
{% extends 'books/base.html' %}

{% block title %}Add New Book - {{ block.super }}{% endblock %}

{% block content %}
<div class="row justify-content-center">
    <div class="col-md-8">
        <h1>Add New Book</h1>
        
        <form method="post" class="needs-validation" novalidate>
            {% csrf_token %}
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        {{ form.title.label_tag }}
                        {{ form.title }}
                        {% if form.title.help_text %}
                            <div class="form-text">{{ form.title.help_text }}</div>
                        {% endif %}
                        {% if form.title.errors %}
                            <div class="invalid-feedback d-block">
                                {{ form.title.errors|first }}
                            </div>
                        {% endif %}
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        {{ form.author.label_tag }}
                        {{ form.author }}
                        {% if form.author.errors %}
                            <div class="invalid-feedback d-block">
                                {{ form.author.errors|first }}
                            </div>
                        {% endif %}
                    </div>
                </div>
            </div>
            
            <!-- Additional form fields... -->
            
            <div class="row">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Add Book</button>
                    <a href="{% url 'books:book-list' %}" class="btn btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
{% endblock %}
```

## Form Validation

### Built-in Validation

Django provides automatic validation based on field types:

```python
class BookForm(forms.Form):
    title = forms.CharField(max_length=200)  # Validates length
    email = forms.EmailField()               # Validates email format
    price = forms.DecimalField(min_value=0)  # Validates minimum value
    pages = forms.IntegerField(min_value=1)  # Validates positive integer
```

### Custom Field Validation

Add custom validation for individual fields:

```python
class BookForm(forms.Form):
    isbn = forms.CharField(max_length=13)
    
    def clean_isbn(self):
        isbn = self.cleaned_data['isbn']
        
        # Remove any dashes or spaces
        isbn = isbn.replace('-', '').replace(' ', '')
        
        # Check length
        if len(isbn) != 13:
            raise forms.ValidationError('ISBN must be exactly 13 digits')
        
        # Check if all characters are digits
        if not isbn.isdigit():
            raise forms.ValidationError('ISBN must contain only digits')
        
        # Check if ISBN already exists
        if Book.objects.filter(isbn=isbn).exists():
            raise forms.ValidationError('A book with this ISBN already exists')
        
        return isbn
```

### Form-wide Validation

Validate across multiple fields:

```python
class BookForm(forms.Form):
    title = forms.CharField(max_length=200)
    author = forms.CharField(max_length=100)
    publication_date = forms.DateField()
    
    def clean(self):
        cleaned_data = super().clean()
        title = cleaned_data.get('title')
        author = cleaned_data.get('author')
        publication_date = cleaned_data.get('publication_date')
        
        # Check if book already exists
        if title and author:
            if Book.objects.filter(title=title, author=author).exists():
                raise forms.ValidationError(
                    f'A book titled "{title}" by {author} already exists'
                )
        
        # Check publication date is not in the future
        from django.utils import timezone
        if publication_date and publication_date > timezone.now().date():
            raise forms.ValidationError(
                'Publication date cannot be in the future'
            )
        
        return cleaned_data
```

## Form Widgets

### Custom Widgets

Customize form appearance with widgets:

```python
class BookForm(forms.Form):
    title = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter book title',
            'autocomplete': 'off'
        })
    )
    
    description = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Enter book description...'
        })
    )
    
    publication_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'type': 'date',
            'class': 'form-control'
        })
    )
    
    category = forms.ChoiceField(
        choices=[
            ('fiction', 'Fiction'),
            ('non-fiction', 'Non-Fiction'),
            ('mystery', 'Mystery'),
            ('science', 'Science'),
        ],
        widget=forms.Select(attrs={'class': 'form-select'})
    )
```

## Search Forms

### Simple Search

```python
# books/forms.py
class BookSearchForm(forms.Form):
    query = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Search by title, author, or ISBN...',
            'class': 'form-control'
        })
    )
    
    category = forms.ChoiceField(
        choices=[('', 'All Categories')] + [
            ('fiction', 'Fiction'),
            ('non-fiction', 'Non-Fiction'),
            ('mystery', 'Mystery'),
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
```

### Search View

```python
def book_search(request):
    form = BookSearchForm(request.GET or None)
    books = []
    
    if form.is_valid():
        query = form.cleaned_data.get('query')
        category = form.cleaned_data.get('category')
        
        books = Book.objects.all()
        
        if query:
            from django.db import models
            books = books.filter(
                models.Q(title__icontains=query) |
                models.Q(author__icontains=query) |
                models.Q(isbn__icontains=query)
            )
        
        if category:
            books = books.filter(category=category)
    
    context = {
        'form': form,
        'books': books,
        'search_performed': form.is_valid() and any(form.cleaned_data.values())
    }
    
    return render(request, 'books/search.html', context)
```

## CSRF Protection

Always include CSRF token in forms:

```html
<form method="post">
    {% csrf_token %}
    <!-- form fields -->
</form>
```

## Messages Framework

Show feedback to users:

```python
from django.contrib import messages

def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        
        if form.is_valid():
            book = form.save()
            messages.success(request, f'Book "{book.title}" added successfully!')
            return redirect('books:book-detail', book_id=book.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    
    return render(request, 'books/add_book.html', {'form': form})
```

Display messages in templates:

```html
{% if messages %}
    {% for message in messages %}
        <div class="alert alert-{{ message.tags }} alert-dismissible fade show">
            {{ message }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    {% endfor %}
{% endif %}
```

## Best Practices

1. **Use ModelForms**: When working with model data
2. **Always validate**: Never trust user input
3. **Provide helpful errors**: Clear error messages
4. **Use CSRF protection**: Include {% csrf_token %}
5. **Style your forms**: Add CSS classes and Bootstrap
6. **Handle GET and POST**: Different behavior for each method
7. **Redirect after POST**: Prevent duplicate submissions

## What's Next?

In the next lesson, we'll explore Django's authentication system - user registration, login, logout, and permissions.

Forms collect data, authentication protects it! 🔐
    ''',
    "is_free": True,
    "xp_reward": 40,
    "exercises": [
        {
            "id": "django-forms",
            "title": "Create Book Forms System",
            "type": "project",
            "instructions": '''Create a complete forms system for your bookstore application.

Create the following in books/forms.py:

1. BookModelForm - A ModelForm for the Book model with:
   - All fields from the Book model
   - Custom widgets for better UX
   - Proper labels and help text
   - Custom validation for ISBN

2. BookSearchForm - A form for searching books with:
   - query field (CharField, not required)
   - category field (ChoiceField with options)
   - price_min and price_max fields

3. Create corresponding views and templates for:
   - Adding new books
   - Searching books
   - Displaying form errors and success messages

Include proper error handling, validation, and user feedback.''',
            "starter_code": '''# books/forms.py
from django import forms
from .models import Book

class BookModelForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'publication_date', 'price', 'pages', 'available']
        
        widgets = {
            # Add your custom widgets here
        }
    
    def clean_isbn(self):
        # Add ISBN validation
        pass

class BookSearchForm(forms.Form):
    # Add search form fields
    pass''',
            "solution": '''# books/forms.py
from django import forms
from .models import Book

class BookModelForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'isbn', 'publication_date', 'price', 'pages', 'available']
        
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter book title'}),
            'author': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter author name'}),
            'isbn': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '13-digit ISBN'}),
            'publication_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'min': '0'}),
            'pages': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
            'available': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        
        labels = {
            'isbn': 'ISBN Number',
            'available': 'Currently Available'
        }
    
    def clean_isbn(self):
        isbn = self.cleaned_data['isbn']
        isbn = isbn.replace('-', '').replace(' ', '')
        
        if len(isbn) != 13:
            raise forms.ValidationError('ISBN must be exactly 13 digits')
        
        if not isbn.isdigit():
            raise forms.ValidationError('ISBN must contain only digits')
        
        return isbn

class BookSearchForm(forms.Form):
    query = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search by title, author, or ISBN...'
        })
    )
    
    category = forms.ChoiceField(
        choices=[('', 'All Categories'), ('fiction', 'Fiction'), ('science', 'Science')],
        required=False,
        widget=forms.Select(attrs={'class': 'form-select'})
    )''',
            "test_cases": [
                {
                    "name": "Complete forms system implemented",
                    "input": "",
                    "expected_contains": ["class BookModelForm", "clean_isbn", "BookSearchForm", "form.is_valid()", "messages.success"]
                }
            ],
            "xp_reward": 70,
            "hints": [
                "Use ModelForm for database-backed forms, regular Form for search",
                "Add clean_isbn method to validate ISBN format",
                "Handle both GET and POST in form views",
                "Use messages framework for user feedback",
                "Add proper CSS classes to widgets for Bootstrap styling"
            ]
        }
    ]
}