"""
Django Database - Lesson 2: Raw SQL in Django
Master raw SQL usage for complex queries and performance optimization
"""

DJANGO_RAW_SQL_LESSON = {
    "id": 45,
    "chapter": 45,
    "title": "Django Raw SQL: When ORM Isn't Enough",
    "slug": "django-raw-sql",
    "description": "Learn when and how to use raw SQL in Django for complex queries and performance optimization",
    "content": '''# Django Raw SQL: When ORM Isn't Enough

## 🎯 When to Use Raw SQL

While Django's ORM handles 90% of database queries, there are scenarios where **raw SQL** is necessary:

- **Complex analytical queries** with window functions and CTEs
- **Database-specific features** not available in Django ORM
- **Performance optimization** for critical queries
- **Legacy database integration** with complex schemas
- **Bulk operations** that need fine-grained control

Think of raw SQL as your **power tool** - use it when Django ORM hits its limits.

## 💾 Advanced Analytics Database

Let's work with a comprehensive e-commerce analytics database:

```sql
-- Orders table with comprehensive data
CREATE TABLE analytics_orders (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    customer_email VARCHAR(254) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    tax_amount DECIMAL(10, 2) NOT NULL,
    shipping_cost DECIMAL(10, 2) DEFAULT 0.00,
    payment_method VARCHAR(50),
    status VARCHAR(20) DEFAULT 'pending',
    shipped_date TIMESTAMP,
    delivery_date TIMESTAMP,
    region VARCHAR(50),
    sales_rep_id INTEGER,
    acquisition_channel VARCHAR(50)
);

-- Order items for detailed analysis
CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    discount_percent DECIMAL(5, 2) DEFAULT 0.00,
    cost_price DECIMAL(10, 2) NOT NULL,
    supplier_id INTEGER,
    FOREIGN KEY (order_id) REFERENCES analytics_orders(id)
);

-- Sample orders data (Amazon-scale patterns)
INSERT INTO analytics_orders (customer_id, customer_email, total_amount, tax_amount, payment_method, status, region, acquisition_channel, order_date) VALUES
(1001, 'sarah.chen@email.com', 1299.99, 104.00, 'credit_card', 'delivered', 'North America', 'organic_search', '2024-11-15 10:30:00'),
(1002, 'mike.rodriguez@email.com', 89.97, 7.20, 'paypal', 'delivered', 'Europe', 'paid_ads', '2024-11-20 14:22:00'),
(1003, 'emma.johnson@email.com', 2499.00, 199.92, 'apple_pay', 'shipped', 'Asia Pacific', 'social_media', '2024-12-01 09:15:00'),
(1004, 'david.kim@email.com', 156.48, 12.52, 'credit_card', 'delivered', 'North America', 'email_marketing', '2024-12-10 16:45:00'),
(1005, 'anna.petrov@email.com', 75.99, 6.08, 'bank_transfer', 'pending', 'Europe', 'affiliate', '2024-12-25 11:30:00'),
(1006, 'raj.patel@email.com', 599.99, 48.00, 'credit_card', 'delivered', 'Asia Pacific', 'organic_search', '2024-12-15 13:20:00');

-- Sample order items (realistic product mix)
INSERT INTO order_items (order_id, product_id, product_name, category, quantity, unit_price, cost_price) VALUES
(1, 1001, 'MacBook Pro 16"', 'Electronics', 1, 1299.99, 950.00),
(2, 2001, 'Wireless Headphones', 'Electronics', 1, 79.99, 45.00),
(2, 2002, 'Phone Case', 'Accessories', 1, 19.98, 8.00),
(3, 1002, 'Gaming Laptop', 'Electronics', 1, 2499.00, 1800.00),
(4, 3001, 'Coffee Maker', 'Home & Kitchen', 1, 129.99, 80.00),
(4, 3002, 'Coffee Beans 2lb', 'Food & Beverage', 2, 13.24, 6.50),
(5, 2003, 'USB Cable', 'Electronics', 3, 25.33, 12.00),
(6, 1003, 'Smartphone', 'Electronics', 1, 599.99, 400.00);

-- Product categories for analysis
CREATE TABLE product_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_category_id INTEGER,
    margin_target DECIMAL(5, 2) DEFAULT 30.00,
    is_seasonal BOOLEAN DEFAULT FALSE
);

INSERT INTO product_categories (name, margin_target, is_seasonal) VALUES
('Electronics', 25.00, false),
('Accessories', 45.00, false),
('Home & Kitchen', 35.00, true),
('Food & Beverage', 20.00, false);
```

## 🔧 Django Raw SQL Methods

### 1. Model.objects.raw() - The Gateway

**Scenario**: Netflix analyzing viewing patterns with complex time calculations

```python
# Complex analytical query for user engagement
class UserEngagement:
    @staticmethod
    def get_high_value_customers():
        """Find customers with sophisticated purchasing patterns"""
        return Customer.objects.raw('''
            SELECT c.*, 
                   COUNT(o.id) as order_count,
                   AVG(o.total_amount) as avg_order_value,
                   SUM(o.total_amount) as total_spent,
                   EXTRACT(EPOCH FROM (MAX(o.order_date) - MIN(o.order_date))) / 86400 as customer_lifetime_days
            FROM customers c
            JOIN analytics_orders o ON c.id = o.customer_id
            WHERE o.status = 'delivered'
            GROUP BY c.id
            HAVING COUNT(o.id) >= 3 
               AND AVG(o.total_amount) > 200
               AND SUM(o.total_amount) > 1000
            ORDER BY total_spent DESC
        ''')

# Using the raw query
high_value_customers = UserEngagement.get_high_value_customers()
for customer in high_value_customers:
    print(f"{customer.email}: ${customer.total_spent} over {customer.customer_lifetime_days} days")
```

### 2. connection.cursor() - Full SQL Power

**Scenario**: Airbnb's revenue analytics with window functions

```python
from django.db import connection

def get_revenue_trends_with_rankings():
    """Complex revenue analysis with window functions"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            WITH monthly_revenue AS (
                SELECT 
                    DATE_TRUNC('month', order_date) as month,
                    region,
                    SUM(total_amount) as revenue,
                    COUNT(*) as order_count,
                    AVG(total_amount) as avg_order_value
                FROM analytics_orders
                WHERE status = 'delivered'
                  AND order_date >= CURRENT_DATE - INTERVAL '12 months'
                GROUP BY DATE_TRUNC('month', order_date), region
            ),
            ranked_regions AS (
                SELECT *,
                       ROW_NUMBER() OVER (PARTITION BY month ORDER BY revenue DESC) as region_rank,
                       LAG(revenue) OVER (PARTITION BY region ORDER BY month) as prev_month_revenue,
                       AVG(revenue) OVER (PARTITION BY region ORDER BY month 
                                         ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) as rolling_3month_avg
                FROM monthly_revenue
            )
            SELECT 
                month,
                region,
                revenue,
                region_rank,
                COALESCE(ROUND(((revenue - prev_month_revenue) / prev_month_revenue) * 100, 2), 0) as growth_rate,
                ROUND(rolling_3month_avg, 2) as rolling_avg
            FROM ranked_regions
            WHERE region_rank <= 3  -- Top 3 regions each month
            ORDER BY month DESC, region_rank
        ''')
        
        columns = [col[0] for col in cursor.description]
        return [dict(zip(columns, row)) for row in cursor.fetchall()]

# Usage
revenue_data = get_revenue_trends_with_rankings()
for row in revenue_data:
    print(f"{row['month'].strftime('%Y-%m')}: {row['region']} - ${row['revenue']:,.2f} ({row['growth_rate']:+.1f}%)")
```

### 3. Raw SQL with Parameters (Safe from SQL Injection)

**Scenario**: Uber's dynamic pricing analysis

```python
def analyze_demand_patterns(region, start_date, min_order_value):
    """Analyze demand patterns with safe parameterization"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            SELECT 
                DATE_TRUNC('hour', order_date) as hour_bucket,
                COUNT(*) as order_count,
                AVG(total_amount) as avg_order_value,
                PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY total_amount) as median_order_value,
                STRING_AGG(DISTINCT acquisition_channel, ', ') as channels
            FROM analytics_orders
            WHERE region = %s
              AND order_date >= %s
              AND total_amount >= %s
              AND status IN ('delivered', 'shipped')
            GROUP BY DATE_TRUNC('hour', order_date)
            HAVING COUNT(*) >= 5  -- Only hours with significant activity
            ORDER BY hour_bucket
        ''', [region, start_date, min_order_value])
        
        return cursor.fetchall()

# Safe usage with parameters
import datetime
patterns = analyze_demand_patterns(
    region='North America',
    start_date=datetime.date(2024, 12, 1),
    min_order_value=50.00
)
```

### 4. Raw SQL for Data Modifications

**Scenario**: Shopify's inventory adjustment with complex business logic

```python
def bulk_update_inventory_with_business_rules():
    """Complex inventory update that would be inefficient in ORM"""
    
    with connection.cursor() as cursor:
        # Update pricing based on inventory levels and seasonality
        cursor.execute('''
            UPDATE products p
            SET 
                price = CASE
                    WHEN inventory_count < min_stock_level THEN price * 1.05  -- 5% increase for low stock
                    WHEN inventory_count > max_stock_level THEN price * 0.95  -- 5% decrease for overstock
                    ELSE price
                END,
                last_price_update = CURRENT_TIMESTAMP
            FROM product_categories pc
            WHERE p.category_id = pc.id
              AND (
                  (inventory_count < min_stock_level AND price < max_allowed_price) OR
                  (inventory_count > max_stock_level AND price > min_allowed_price)
              )
              AND p.last_price_update < CURRENT_DATE - INTERVAL '7 days'
        ''')
        
        rows_affected = cursor.rowcount
        return rows_affected

# Execute the update
updated_count = bulk_update_inventory_with_business_rules()
print(f"Updated pricing for {updated_count} products")
```

## 🏢 Real-World Production Examples

### Amazon's Recommendation Engine Query

```python
def get_frequently_bought_together(product_id, limit=5):
    """Find products frequently bought together (market basket analysis)"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            WITH product_pairs AS (
                SELECT 
                    oi1.product_id as product_a,
                    oi2.product_id as product_b,
                    COUNT(*) as co_occurrence_count
                FROM order_items oi1
                JOIN order_items oi2 ON oi1.order_id = oi2.order_id
                WHERE oi1.product_id = %s
                  AND oi2.product_id != %s
                  AND oi1.order_id IN (
                      SELECT order_id 
                      FROM analytics_orders 
                      WHERE status = 'delivered'
                        AND order_date >= CURRENT_DATE - INTERVAL '6 months'
                  )
                GROUP BY oi1.product_id, oi2.product_id
            ),
            ranked_products AS (
                SELECT 
                    product_b,
                    co_occurrence_count,
                    ROW_NUMBER() OVER (ORDER BY co_occurrence_count DESC) as rank
                FROM product_pairs
            )
            SELECT 
                rp.product_b as recommended_product_id,
                p.product_name,
                rp.co_occurrence_count as times_bought_together,
                ROUND((rp.co_occurrence_count::decimal / 
                      (SELECT COUNT(DISTINCT order_id) 
                       FROM order_items 
                       WHERE product_id = %s)) * 100, 2) as recommendation_strength
            FROM ranked_products rp
            JOIN products p ON rp.product_b = p.id
            WHERE rp.rank <= %s
            ORDER BY rp.co_occurrence_count DESC
        ''', [product_id, product_id, product_id, limit])
        
        return cursor.fetchall()
```

### Stripe's Financial Reconciliation

```python
def generate_daily_financial_report(report_date):
    """Generate comprehensive financial report for accounting"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            WITH daily_metrics AS (
                SELECT
                    DATE(%s) as report_date,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as gross_revenue,
                    SUM(CASE WHEN status = 'delivered' THEN discount_amount ELSE 0 END) as total_discounts,
                    SUM(CASE WHEN status = 'delivered' THEN tax_amount ELSE 0 END) as tax_collected,
                    SUM(CASE WHEN status = 'refunded' THEN total_amount ELSE 0 END) as refunds_issued,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                    COUNT(CASE WHEN status = 'refunded' THEN 1 END) as refunded_orders
                FROM analytics_orders
                WHERE DATE(order_date) = DATE(%s)
            ),
            payment_breakdown AS (
                SELECT
                    payment_method,
                    SUM(total_amount) as method_revenue,
                    COUNT(*) as method_count
                FROM analytics_orders
                WHERE DATE(order_date) = DATE(%s)
                  AND status = 'delivered'
                GROUP BY payment_method
            )
            SELECT 
                dm.*,
                pb.payment_method,
                pb.method_revenue,
                pb.method_count,
                ROUND((dm.gross_revenue - dm.total_discounts - dm.refunds_issued), 2) as net_revenue
            FROM daily_metrics dm
            CROSS JOIN payment_breakdown pb
            ORDER BY pb.method_revenue DESC
        ''', [report_date, report_date, report_date])
        
        return cursor.fetchall()
```

### Discord's Message Analytics

```python
def analyze_peak_usage_patterns():
    """Analyze server usage patterns for capacity planning"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            SELECT
                EXTRACT(hour FROM created_at) as hour_of_day,
                EXTRACT(dow FROM created_at) as day_of_week,
                COUNT(*) as message_count,
                COUNT(DISTINCT user_id) as active_users,
                COUNT(DISTINCT channel_id) as active_channels,
                AVG(LENGTH(content)) as avg_message_length,
                PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY LENGTH(content)) as p95_message_length
            FROM messages
            WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
              AND content IS NOT NULL
              AND LENGTH(content) > 0
            GROUP BY 
                EXTRACT(hour FROM created_at),
                EXTRACT(dow FROM created_at)
            ORDER BY message_count DESC
            LIMIT 24  -- Top 24 hour/day combinations
        ''')
        
        return cursor.fetchall()
```

## ⚡ Performance Optimization with Raw SQL

### 1. Bulk Operations

```python
def bulk_customer_segmentation():
    """Segment millions of customers efficiently"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            UPDATE customers
            SET segment = CASE
                WHEN total_orders >= 20 AND total_spent >= 2000 THEN 'vip'
                WHEN total_orders >= 10 AND total_spent >= 1000 THEN 'loyal'
                WHEN total_orders >= 5 OR total_spent >= 500 THEN 'regular'
                ELSE 'new'
            END
            WHERE last_segment_update < CURRENT_DATE - INTERVAL '7 days'
        ''')
        
        return cursor.rowcount
```

### 2. Database-Specific Features

```python
# PostgreSQL Full-Text Search
def search_products_advanced(query):
    """Advanced product search with ranking"""
    
    with connection.cursor() as cursor:
        cursor.execute('''
            SELECT 
                product_name,
                description,
                ts_rank(search_vector, plainto_tsquery('english', %s)) as relevance_score
            FROM products
            WHERE search_vector @@ plainto_tsquery('english', %s)
            ORDER BY relevance_score DESC
            LIMIT 20
        ''', [query, query])
        
        return cursor.fetchall()
```

## 🛡️ Raw SQL Best Practices

### 1. Always Use Parameterized Queries

```python
# GOOD: Safe from SQL injection
cursor.execute('SELECT * FROM orders WHERE customer_id = %s', [customer_id])

# BAD: Vulnerable to SQL injection
cursor.execute(f'SELECT * FROM orders WHERE customer_id = {customer_id}')
```

### 2. Handle Database Differences

```python
from django.db import connection

def get_date_truncated_sales():
    """Handle database-specific date functions"""
    
    if connection.vendor == 'postgresql':
        date_trunc = "DATE_TRUNC('month', order_date)"
    elif connection.vendor == 'mysql':
        date_trunc = "DATE_FORMAT(order_date, '%Y-%m-01')"
    else:
        date_trunc = "STRFTIME('%Y-%m-01', order_date)"
    
    with connection.cursor() as cursor:
        cursor.execute(f'''
            SELECT {date_trunc} as month, SUM(total_amount)
            FROM analytics_orders
            GROUP BY {date_trunc}
        ''')
        return cursor.fetchall()
```

### 3. Test Performance

```python
import time
from django.db import connection

def performance_test_query():
    """Test query performance with execution plan"""
    
    with connection.cursor() as cursor:
        # PostgreSQL: Get query execution plan
        cursor.execute('EXPLAIN ANALYZE SELECT ...')
        plan = cursor.fetchall()
        
        start_time = time.time()
        cursor.execute('SELECT ...')
        results = cursor.fetchall()
        execution_time = time.time() - start_time
        
        return {
            'results': results,
            'execution_time': execution_time,
            'query_plan': plan
        }
```

## 🎯 Key Takeaways

1. **Raw SQL complements Django ORM** for complex analytical queries
2. **Always use parameterized queries** to prevent SQL injection
3. **Window functions and CTEs** enable sophisticated analytics
4. **Database-specific features** can provide significant performance gains
5. **Test with production data volumes** to ensure performance

Raw SQL gives you the power to leverage your database's full capabilities when Django ORM reaches its limits!
''',
    "difficulty": "intermediate",
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-custom-managers"],
    "exercises": [
        {
            "id": "raw_sql_1",
            "title": "Explore Analytics Orders Table",
            "prompt": "Let's start by examining our analytics orders table structure and data. Write a query to see the order information.",
            "table_name": "analytics_orders",
            "initial_query": "SELECT * FROM analytics_orders LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "analytics_orders"],
            "hint": "Use SELECT * FROM analytics_orders LIMIT 5; to explore the table structure",
            "solution": "SELECT * FROM analytics_orders LIMIT 5;",
            "explanation": "This shows our comprehensive analytics_orders table with fields like customer_id, total_amount, region, acquisition_channel, etc. Raw SQL gives us direct access to all this data for complex analytics."
        },
        {
            "id": "raw_sql_2",
            "title": "Basic Revenue Analysis Query",
            "prompt": "Write a raw SQL query to calculate total revenue by region. Sum the total_amount grouped by region.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "SUM", "GROUP BY", "region"],
            "hint": "Use SUM(total_amount) and GROUP BY region",
            "solution": "SELECT region, SUM(total_amount) as total_revenue FROM analytics_orders WHERE status = 'delivered' GROUP BY region ORDER BY total_revenue DESC;",
            "explanation": "This type of aggregation query is perfect for raw SQL. While Django ORM could handle this, raw SQL gives us direct control and is often more readable for complex business logic."
        },
        {
            "id": "raw_sql_3", 
            "title": "Advanced Customer Segmentation",
            "prompt": "Write a query to find high-value customers: those with total spending > $500 and multiple orders. Show customer_email and their metrics.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "COUNT", "SUM", "GROUP BY", "HAVING"],
            "hint": "Group by customer_email, count orders, sum amounts, then filter with HAVING",
            "solution": "SELECT customer_email, COUNT(*) as order_count, SUM(total_amount) as total_spent FROM analytics_orders WHERE status = 'delivered' GROUP BY customer_email HAVING SUM(total_amount) > 500 AND COUNT(*) > 1 ORDER BY total_spent DESC;",
            "explanation": "This customer segmentation query uses HAVING to filter grouped results - a perfect example of when raw SQL is more natural than Django ORM. The HAVING clause filters after grouping, which is essential for customer analytics."
        },
        {
            "id": "raw_sql_4",
            "title": "Time-Based Analysis Query",
            "prompt": "Write a query to analyze order patterns by acquisition channel. Show channel, order count, and average order value for orders in December 2024.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "AVG", "COUNT", "WHERE", "acquisition_channel"],
            "hint": "Filter by order_date in December 2024, then group by acquisition_channel",
            "solution": "SELECT acquisition_channel, COUNT(*) as order_count, ROUND(AVG(total_amount), 2) as avg_order_value FROM analytics_orders WHERE order_date >= '2024-12-01' AND order_date < '2025-01-01' GROUP BY acquisition_channel ORDER BY avg_order_value DESC;",
            "explanation": "This marketing analysis query shows how different acquisition channels perform. Raw SQL makes it easy to filter by date ranges and calculate channel-specific metrics for business intelligence."
        },
        {
            "id": "raw_sql_5",
            "title": "Complex Multi-Table Analysis",
            "prompt": "Write a query joining analytics_orders and order_items to find the total revenue by product category.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "JOIN", "SUM", "category", "GROUP BY"],
            "hint": "JOIN analytics_orders with order_items, then SUM the amounts by category",
            "solution": "SELECT oi.category, SUM(oi.quantity * oi.unit_price) as category_revenue, COUNT(DISTINCT o.id) as orders_with_category FROM analytics_orders o JOIN order_items oi ON o.id = oi.order_id WHERE o.status = 'delivered' GROUP BY oi.category ORDER BY category_revenue DESC;",
            "explanation": "This cross-table analysis demonstrates raw SQL's power for complex business intelligence. Joining multiple tables and calculating derived metrics like this would be much more complex in Django ORM."
        },
        {
            "id": "raw_sql_6",
            "title": "Window Function for Rankings",
            "prompt": "Use a window function to rank regions by total revenue. Show region, total revenue, and rank.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "RANK", "OVER", "ORDER BY", "SUM"],
            "hint": "Use RANK() OVER (ORDER BY SUM(total_amount) DESC) for ranking",
            "solution": "SELECT region, SUM(total_amount) as total_revenue, RANK() OVER (ORDER BY SUM(total_amount) DESC) as revenue_rank FROM analytics_orders WHERE status = 'delivered' GROUP BY region;",
            "explanation": "Window functions like RANK() are perfect examples of when raw SQL is necessary. Django ORM doesn't support window functions well, making raw SQL essential for advanced analytics like revenue rankings."
        }
    ],
    "key_concepts": [
        "Model.objects.raw() Usage",
        "connection.cursor() for Complex Queries",
        "Parameterized Queries for Security",
        "Window Functions and CTEs",
        "Bulk Operations with Raw SQL",
        "Database-Specific Feature Access",
        "Performance Optimization Techniques",
        "Financial and Business Analytics"
    ]
}