"""
Django Migrations - Lesson 1: Introduction to Migrations
Learn the fundamentals of Django migrations with real-world examples
"""

DJANGO_MIGRATIONS_INTRO_LESSON = {
    "id": 40,
    "chapter": 40,
    "title": "Django Migrations: Introduction and Fundamentals",
    "slug": "django-migrations-intro",
    "description": "Master Django migrations - your database's version control system",
    "content": '''# Django Migrations: Your Database's Version Control System

## 🎯 What Are Django Migrations?

Think of Django migrations like **Git for your database**. Just as Git tracks changes to your code, migrations track changes to your database schema.

**Real-world analogy**: Imagine you're building Instagram's database:
- Day 1: You create a `User` model with basic fields
- Day 30: You add `bio` and `profile_picture` fields
- Day 60: You create a `Post` model with likes and comments
- Day 90: You add a `Story` model that expires after 24 hours

Migrations ensure that **every developer** and **every server** (development, staging, production) has the exact same database structure at any point in time.

## 📱 How Instagram Uses Migrations

Instagram has thousands of database changes. Here's how they might use migrations:

**Initial User Model** (2010):
```python
class User(models.Model):
    username = models.CharField(max_length=30, unique=True)
    email = models.EmailField()
    password = models.CharField(max_length=128)
    date_joined = models.DateTimeField(auto_now_add=True)
```

**Adding Profile Features** (2011):
```python
class User(models.Model):
    username = models.CharField(max_length=30, unique=True)
    email = models.EmailField()
    password = models.CharField(max_length=128)
    date_joined = models.DateTimeField(auto_now_add=True)
    # NEW FIELDS - Migration handles adding these safely
    bio = models.TextField(max_length=150, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', null=True)
    is_verified = models.BooleanField(default=False)
```

## 🔄 The Migration Workflow

### 1. Make Model Changes
```python
# In your models.py
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    # Adding a new field
    author = models.ForeignKey(User, on_delete=models.CASCADE)
```

### 2. Create Migration
```bash
python manage.py makemigrations
```

### 3. Review Generated Migration
```python
# migrations/0002_blogpost_author.py
class Migration(migrations.Migration):
    dependencies = [
        ('blog', '0001_initial'),
    ]
    
    operations = [
        migrations.AddField(
            model_name='blogpost',
            name='author',
            field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='auth.User'),
        ),
    ]
```

### 4. Apply Migration
```bash
python manage.py migrate
```

## 📊 Practice Database: Social Media Platform

For our exercises, we'll use a simplified social media database with these tables:

**users** - Core user information
**posts** - User posts and content  
**comments** - Comments on posts
**likes** - Like relationships
**follows** - User following relationships

```sql
-- Initial users table (before migrations)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(30) UNIQUE NOT NULL,
    email VARCHAR(254) NOT NULL,
    password VARCHAR(128) NOT NULL,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO users (username, email, password) VALUES 
('johndoe', 'john@example.com', 'hashedpassword123'),
('janedoe', 'jane@example.com', 'hashedpassword456'),
('techguru', 'guru@example.com', 'hashedpassword789');
```

## 🎮 Essential Migration Commands

### Check Current Status
```bash
python manage.py showmigrations
```

### View SQL for a Migration
```bash
python manage.py sqlmigrate app_name 0001
```

### Apply Specific Migration
```bash
python manage.py migrate app_name 0001
```

### Rollback to Previous Migration
```bash
python manage.py migrate app_name 0001
```

## ⚠️ Common Migration Gotchas

### 1. The "Field Cannot Be Null" Error
**Problem**: Adding a required field to existing data
```python
# This will fail if users table has existing data!
bio = models.TextField()  # No default, null=False
```

**Solution**: Provide default or allow null initially
```python
bio = models.TextField(default='No bio yet')
# OR
bio = models.TextField(null=True, blank=True)
```

### 2. Circular Dependencies
**Problem**: App A depends on App B, App B depends on App A

**Solution**: Use string references and careful dependency ordering
```python
# Instead of direct import
author = models.ForeignKey('auth.User', on_delete=models.CASCADE)
```

### 3. Large Data Migrations
**Problem**: Migration times out on production with millions of records

**Solution**: Use data migrations with batching
```python
def migrate_user_data_in_batches(apps, schema_editor):
    User = apps.get_model('accounts', 'User')
    batch_size = 1000
    
    for i in range(0, User.objects.count(), batch_size):
        users = User.objects.all()[i:i + batch_size]
        # Process batch
```

## 💡 Pro Tips from Netflix's Engineering Team

1. **Always Review Generated Migrations**: Don't blindly apply them
2. **Test Migrations on Production-Like Data**: Use database dumps
3. **Coordinate Team Migrations**: Merge conflicts in migrations are tricky
4. **Use Descriptive Migration Names**: `--name add_user_verification_status`
5. **Plan Backwards Compatibility**: Consider rollback scenarios

## 🚀 What's Next?

In the next lessons, you'll learn:
- Writing custom data migrations
- Advanced migration operations
- Handling production deployment scenarios
- Schema editor for complex changes

Remember: **Migrations are your safety net**. They ensure your application's data layer evolves safely and predictably!
''',
    "difficulty": "beginner",
    "estimated_time": 25,
    "xp_reward": 15,
    "prerequisites": ["django-models-basics", "django-queryset-fundamentals"],
    "exercises": [
        {
            "id": "migrations_intro_1",
            "title": "Explore the Users Table",
            "prompt": "Let's start by examining our social media platform's users table. Run a query to see all users and their information.",
            "table_name": "users",
            "initial_query": "SELECT * FROM users;",
            "expected_keywords": ["SELECT", "*", "FROM", "users"],
            "hint": "Use SELECT * FROM users; to see all user data",
            "solution": "SELECT * FROM users;",
            "explanation": "This shows all users in our social media platform. Notice the basic fields: id, username, email, password, and date_joined. Soon we'll add more fields through migrations!"
        },
        {
            "id": "migrations_intro_2", 
            "title": "Understanding Migration History",
            "prompt": "In Django, you would run `python manage.py showmigrations` to see migration status. For now, write a query to count total users before we start adding new features.",
            "table_name": "users",
            "expected_keywords": ["SELECT", "COUNT", "users"],
            "hint": "Use COUNT(*) to count all rows",
            "solution": "SELECT COUNT(*) FROM users;",
            "explanation": "Counting users helps us understand our data size before migrations. This is important when planning migrations that affect existing data."
        },
        {
            "id": "migrations_intro_3",
            "title": "Identify Migration Needs", 
            "prompt": "Look at the current users table structure. Write a query to see what information we're missing that Instagram-like apps need (hint: think about profiles).",
            "table_name": "users",
            "expected_keywords": ["SELECT", "username", "email"],
            "hint": "Select the username and email fields to see what's currently stored",
            "solution": "SELECT username, email FROM users;", 
            "explanation": "This shows we only have basic info. Real social platforms need bio, profile_picture, follower_count, is_verified, etc. These would be added through migrations!"
        }
    ],
    "key_concepts": [
        "Migration Definition and Purpose",
        "makemigrations vs migrate Commands", 
        "Migration Dependencies",
        "Schema Evolution Safety",
        "Production Deployment Considerations"
    ]
}