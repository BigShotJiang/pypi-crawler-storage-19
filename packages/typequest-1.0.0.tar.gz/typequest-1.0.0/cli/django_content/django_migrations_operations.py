"""
Django Migrations - Lesson 3: Migration Operations Deep Dive
Master all Django migration operations with practical examples
"""

DJANGO_MIGRATIONS_OPERATIONS_LESSON = {
    "id": 42,
    "chapter": 42,
    "title": "Django Migration Operations Mastery",
    "slug": "django-migrations-operations",
    "description": "Deep dive into all migration operations with real-world scenarios",
    "content": '''# Django Migration Operations: Complete Guide

## 🎯 Understanding Migration Operations

Migration operations are the **building blocks** of Django migrations. Each operation represents a specific change to your database schema or data. Think of them as **atomic database commands** that Django translates into SQL.

## 📊 Our Complete Social Platform Database

Let's work with a full-featured social media platform database:

```sql
-- Posts table for content
CREATE TABLE posts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    author_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    like_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    tags VARCHAR(500),
    FOREIGN KEY (author_id) REFERENCES users_enhanced(id)
);

-- Comments table
CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL,
    author_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_approved BOOLEAN DEFAULT TRUE,
    parent_comment_id INTEGER,
    FOREIGN KEY (post_id) REFERENCES posts(id),
    FOREIGN KEY (author_id) REFERENCES users_enhanced(id),
    FOREIGN KEY (parent_comment_id) REFERENCES comments(id)
);

-- Sample posts data
INSERT INTO posts (title, content, author_id, like_count, comment_count, tags) VALUES 
('The Future of AI', 'Artificial Intelligence is reshaping every industry...', 1, 15420, 892, 'ai,technology,future'),
('Sustainable Energy Solutions', 'Tesla continues to innovate in battery technology...', 1, 23651, 1245, 'energy,sustainability,tesla'),
('Leading with Empathy', 'In times of change, empathetic leadership becomes crucial...', 2, 8934, 567, 'leadership,management,google'),
('Cloud Computing Trends 2024', 'The evolution of cloud infrastructure continues...', 3, 12456, 723, 'cloud,microsoft,azure');

-- Sample comments data  
INSERT INTO comments (post_id, author_id, content) VALUES 
(1, 2, 'Great insights on AI development, Elon!'),
(1, 3, 'This aligns with our AI initiatives at Microsoft.'),
(2, 4, 'Love seeing progress in sustainable technology!'),
(3, 1, 'Empathy in leadership is crucial for innovation.');
```

## 🔧 Schema Operations

### 1. CreateModel Operation

**Real-world scenario**: Adding a new feature like Stories (Instagram/Facebook style)

```python
# Migration: Add Stories feature
operations = [
    migrations.CreateModel(
        name='Story',
        fields=[
            ('id', models.BigAutoField(primary_key=True)),
            ('author', models.ForeignKey('auth.User', on_delete=models.CASCADE)),
            ('content_type', models.CharField(max_length=20, choices=[
                ('image', 'Image'),
                ('video', 'Video'),
                ('text', 'Text'),
            ])),
            ('content_url', models.URLField(blank=True)),
            ('text_content', models.TextField(blank=True)),
            ('created_at', models.DateTimeField(auto_now_add=True)),
            ('expires_at', models.DateTimeField()),
            ('view_count', models.PositiveIntegerField(default=0)),
            ('is_active', models.BooleanField(default=True)),
        ],
        options={
            'ordering': ['-created_at'],
            'indexes': [
                models.Index(fields=['author', 'is_active']),
                models.Index(fields=['expires_at']),
            ],
        },
    ),
]
```

### 2. DeleteModel Operation

**Real-world scenario**: Removing deprecated features

```python
# Migration: Remove old notification system
operations = [
    # First, clean up related data
    migrations.RunSQL(
        "DELETE FROM old_notifications WHERE created_at < NOW() - INTERVAL '90 days'",
        reverse_sql=migrations.RunSQL.noop,
    ),
    # Then remove the model
    migrations.DeleteModel(name='OldNotification'),
]
```

### 3. AddField Operations

**Real-world scenario**: Instagram adding Reels feature to existing posts

```python
# Migration: Add Reels support to existing posts
operations = [
    # Add field to track if post is a reel
    migrations.AddField(
        model_name='post',
        name='is_reel',
        field=models.BooleanField(default=False),
    ),
    # Add reel-specific metadata
    migrations.AddField(
        model_name='post',
        name='video_duration',
        field=models.PositiveIntegerField(null=True, blank=True, 
                                        help_text="Duration in seconds for video content"),
    ),
    # Add music track for reels
    migrations.AddField(
        model_name='post',
        name='music_track',
        field=models.CharField(max_length=200, blank=True),
    ),
]
```

### 4. RemoveField Operations

**Real-world scenario**: Cleaning up unused fields after feature deprecation

```python
# Migration: Remove deprecated fields after Pinterest's layout change
operations = [
    # Remove old board-specific fields
    migrations.RemoveField(
        model_name='pin',
        name='board_position_x',
    ),
    migrations.RemoveField(
        model_name='pin',
        name='board_position_y',
    ),
    # Remove deprecated color field
    migrations.RemoveField(
        model_name='pin',
        name='dominant_color',
    ),
]
```

### 5. AlterField Operations

**Real-world scenario**: Twitter expanding character limit

```python
# Migration: Increase tweet character limit
operations = [
    migrations.AlterField(
        model_name='tweet',
        name='content',
        field=models.CharField(max_length=280),  # Increased from 140
    ),
    # Add field to track character count for legacy tweets
    migrations.AddField(
        model_name='tweet',
        name='character_count',
        field=models.PositiveIntegerField(default=0),
    ),
]
```

## 🗂️ Model Structure Operations

### 6. RenameModel Operation

**Real-world scenario**: LinkedIn renaming "Connections" to "Network"

```python
operations = [
    migrations.RenameModel(
        old_name='Connection',
        new_name='NetworkConnection',
    ),
]
```

### 7. AlterModelTable Operation

**Real-world scenario**: Optimizing table names for better database performance

```python
operations = [
    migrations.AlterModelTable(
        name='UserProfile',
        table='user_profiles',  # More database-friendly name
    ),
]
```

### 8. AlterModelOptions Operation

**Real-world scenario**: Adding better admin interface options

```python
operations = [
    migrations.AlterModelOptions(
        name='post',
        options={
            'verbose_name': 'Blog Post',
            'verbose_name_plural': 'Blog Posts',
            'ordering': ['-created_at', '-like_count'],
            'permissions': [
                ('can_feature_post', 'Can feature posts on homepage'),
                ('can_moderate_post', 'Can moderate community posts'),
            ],
        },
    ),
]
```

## 🔍 Index and Constraint Operations

### 9. AddIndex Operation

**Real-world scenario**: Optimizing Facebook's news feed performance

```python
operations = [
    # Index for news feed queries (posts by friends, recent first)
    migrations.AddIndex(
        model_name='post',
        index=models.Index(
            fields=['author', '-created_at'],
            name='post_author_recent_idx',
        ),
    ),
    # Composite index for trending posts
    migrations.AddIndex(
        model_name='post',
        index=models.Index(
            fields=['-like_count', '-comment_count', '-created_at'],
            name='post_trending_idx',
        ),
    ),
]
```

### 10. RemoveIndex Operation

```python
operations = [
    migrations.RemoveIndex(
        model_name='post',
        name='old_unused_index',
    ),
]
```

### 11. AddConstraint Operation

**Real-world scenario**: Ensuring data integrity like Medium's clapping system

```python
operations = [
    # Ensure users can't clap for their own articles
    migrations.AddConstraint(
        model_name='clap',
        constraint=models.CheckConstraint(
            check=~models.Q(user_id=models.F('article__author_id')),
            name='no_self_clapping',
        ),
    ),
    # Ensure publish date is not in future
    migrations.AddConstraint(
        model_name='article',
        constraint=models.CheckConstraint(
            check=models.Q(published_at__lte=models.functions.Now()),
            name='no_future_publish',
        ),
    ),
]
```

## 💾 Special Data Operations

### 12. RunPython with Complex Logic

**Real-world scenario**: YouTube's algorithm update requiring view history migration

```python
def migrate_view_history(apps, schema_editor):
    """Complex data migration for YouTube-style view tracking"""
    Video = apps.get_model('content', 'Video')
    ViewHistory = apps.get_model('analytics', 'ViewHistory')
    
    # Process videos in batches
    batch_size = 1000
    
    for video in Video.objects.iterator(chunk_size=batch_size):
        # Calculate engagement score from legacy data
        engagement_score = (
            (video.like_count * 2) + 
            (video.comment_count * 3) + 
            (video.share_count * 5)
        ) / max(video.view_count, 1)
        
        # Create analytics record
        ViewHistory.objects.get_or_create(
            video=video,
            defaults={
                'total_views': video.view_count,
                'unique_viewers': video.view_count * 0.7,  # Estimate
                'engagement_score': engagement_score,
                'last_calculated': timezone.now(),
            }
        )

operations = [
    migrations.RunPython(
        migrate_view_history,
        reverse_code=migrations.RunPython.noop,
    ),
]
```

### 13. RunSQL for Performance

**Real-world scenario**: Creating optimized database views for analytics

```python
operations = [
    migrations.RunSQL(
        sql=[
            """
            CREATE MATERIALIZED VIEW user_engagement_summary AS
            SELECT 
                u.id as user_id,
                u.username,
                COUNT(DISTINCT p.id) as posts_count,
                COUNT(DISTINCT c.id) as comments_count,
                COUNT(DISTINCT l.id) as likes_given,
                AVG(p.like_count) as avg_likes_received,
                MAX(p.created_at) as last_post_date
            FROM users_enhanced u
            LEFT JOIN posts p ON u.id = p.author_id
            LEFT JOIN comments c ON u.id = c.author_id  
            LEFT JOIN likes l ON u.id = l.user_id
            GROUP BY u.id, u.username;
            """,
            "CREATE INDEX ON user_engagement_summary (user_id);",
            "CREATE INDEX ON user_engagement_summary (posts_count DESC);",
        ],
        reverse_sql="DROP MATERIALIZED VIEW IF EXISTS user_engagement_summary;",
    ),
]
```

## 🏢 Complex Real-World Migration Examples

### Slack's Message Threading Migration

```python
# Adding threading to existing messages
operations = [
    # Add thread fields
    migrations.AddField(
        model_name='message',
        name='thread_root',
        field=models.ForeignKey('self', null=True, blank=True, 
                              on_delete=models.CASCADE),
    ),
    migrations.AddField(
        model_name='message',
        name='thread_count',
        field=models.PositiveIntegerField(default=0),
    ),
    # Create index for thread performance
    migrations.AddIndex(
        model_name='message',
        index=models.Index(fields=['thread_root', 'created_at']),
    ),
]
```

### Airbnb's Listing Categories Migration

```python
def migrate_listing_categories(apps, schema_editor):
    """Migrate from tags to structured categories"""
    Listing = apps.get_model('properties', 'Listing')
    Category = apps.get_model('properties', 'Category')
    
    # Create standard categories
    categories = {
        'house': ['house', 'home', 'villa'],
        'apartment': ['apartment', 'flat', 'condo'],
        'room': ['room', 'bedroom', 'shared'],
        'unique': ['treehouse', 'boat', 'castle', 'cave'],
    }
    
    category_objects = {}
    for cat_name, keywords in categories.items():
        cat, created = Category.objects.get_or_create(
            name=cat_name,
            defaults={'description': f'{cat_name.title()} accommodations'}
        )
        category_objects[cat_name] = cat
    
    # Categorize existing listings
    for listing in Listing.objects.all():
        tags_lower = listing.tags.lower() if listing.tags else ''
        
        category_assigned = False
        for cat_name, keywords in categories.items():
            if any(keyword in tags_lower for keyword in keywords):
                listing.category = category_objects[cat_name]
                listing.save()
                category_assigned = True
                break
        
        # Default category for unmatched listings
        if not category_assigned:
            listing.category = category_objects['apartment']
            listing.save()

operations = [
    migrations.RunPython(migrate_listing_categories),
]
```

## ⚡ Performance Considerations

### Batch Operations for Large Tables
```python
# DO: Process in batches
def efficient_data_migration(apps, schema_editor):
    Model = apps.get_model('app', 'Model')
    batch_size = 1000
    
    # Use iterator to avoid loading all objects into memory
    for obj in Model.objects.iterator(chunk_size=batch_size):
        # Process individual object
        obj.new_field = calculate_value(obj)
        
    # Bulk update in batches
    Model.objects.bulk_update(Model.objects.all(), ['new_field'], batch_size=batch_size)

# DON'T: Load everything into memory
def inefficient_migration(apps, schema_editor):
    Model = apps.get_model('app', 'Model')
    for obj in Model.objects.all():  # Loads everything!
        obj.save()  # N+1 query problem
```

## 🎯 Key Takeaways

1. **Choose the right operation** for each scenario
2. **Consider performance** with large datasets
3. **Plan for rollbacks** when designing operations
4. **Use constraints and indexes** to maintain data quality
5. **Test thoroughly** with production-like data

Understanding these operations gives you the power to handle any database evolution scenario!
''',
    "difficulty": "intermediate",
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-migrations-intro", "django-migrations-custom"],
    "exercises": [
        {
            "id": "migration_ops_1",
            "title": "Explore Posts Table Structure",
            "prompt": "Let's examine our social media posts table. Write a query to see the structure and some sample data.",
            "table_name": "posts",
            "initial_query": "SELECT * FROM posts LIMIT 3;",
            "expected_keywords": ["SELECT", "*", "FROM", "posts"],
            "hint": "Use SELECT * FROM posts LIMIT 3; to see sample posts",
            "solution": "SELECT * FROM posts LIMIT 3;",
            "explanation": "This shows our posts table structure with title, content, author_id, like_count, tags, etc. Understanding the current schema helps plan migration operations."
        },
        {
            "id": "migration_ops_2",
            "title": "Analyze Field Addition Needs",
            "prompt": "Imagine we want to add a 'is_reel' field like Instagram did. First, let's see posts that might be video content by checking tags for 'video' or similar keywords.",
            "table_name": "posts",
            "expected_keywords": ["SELECT", "WHERE", "tags", "LIKE"],
            "hint": "Use WHERE tags LIKE '%video%' or similar patterns to find video content",
            "solution": "SELECT title, author_id, tags FROM posts WHERE tags LIKE '%energy%' OR tags LIKE '%technology%';",
            "explanation": "This helps identify posts that might become 'reels' when we add the is_reel field. In a real migration, we'd use RunPython to set is_reel=True for video posts."
        },
        {
            "id": "migration_ops_3",
            "title": "Practice Index Optimization Query",
            "prompt": "Write a query that would benefit from the trending posts index we discussed (posts ordered by engagement). Select posts with high like_count and comment_count.",
            "table_name": "posts",
            "expected_keywords": ["SELECT", "ORDER BY", "like_count", "comment_count"],
            "hint": "Order by like_count and comment_count descending to find trending content",
            "solution": "SELECT title, author_id, like_count, comment_count FROM posts ORDER BY like_count DESC, comment_count DESC LIMIT 5;",
            "explanation": "This query benefits from our composite index (like_count, comment_count, created_at). The AddIndex migration operation would speed up this type of trending content query significantly."
        },
        {
            "id": "migration_ops_4",
            "title": "Understand Comments Relationship",
            "prompt": "Explore the comments table structure and its relationship to posts. Write a query to see comments with their associated post titles.",
            "table_name": "comments",
            "expected_keywords": ["SELECT", "JOIN", "posts", "comments"],
            "hint": "Use JOIN to connect comments with posts table on post_id",
            "solution": "SELECT c.content, p.title FROM comments c JOIN posts p ON c.post_id = p.id;",
            "explanation": "This JOIN query shows the relationship between comments and posts. When planning migrations, understanding table relationships helps design proper foreign key constraints and indexes."
        },
        {
            "id": "migration_ops_5",
            "title": "Identify Data for Complex Migrations",
            "prompt": "Find posts by the same author to understand how a data migration might work. Write a query to see all posts by author_id = 1.",
            "table_name": "posts",
            "expected_keywords": ["SELECT", "WHERE", "author_id"],
            "hint": "Use WHERE author_id = 1 to filter posts by specific author",
            "solution": "SELECT title, content, like_count, tags FROM posts WHERE author_id = 1;",
            "explanation": "This type of query helps understand data patterns before writing RunPython migrations. For example, if migrating user data, you'd process all records for each user together for efficiency."
        }
    ],
    "key_concepts": [
        "CreateModel and DeleteModel Operations",
        "AddField and RemoveField Operations", 
        "AlterField for Schema Changes",
        "Index Operations for Performance",
        "Constraint Operations for Data Integrity",
        "RunPython vs RunSQL Usage",
        "Batch Processing Strategies",
        "Performance Optimization Techniques"
    ]
}