"""
SQL Aggregates and Grouping lesson content
"""

SQL_AGGREGATES_LESSON = {
    "id": 37,
    "chapter": 37,
    "title": "SQL Aggregates: GROUP BY, HAVING, and Statistical Analysis",
    "slug": "sql-aggregates",
    "content": '''
# SQL Aggregates: Transforming Data into Business Intelligence

Individual records tell stories, but aggregate functions reveal trends. When Netflix shows "Most Watched Categories," Spotify displays "Top Artists This Year," or Amazon highlights "Best Selling Products by Category," they're using SQL aggregates to transform millions of individual records into actionable business insights.

## What Are SQL Aggregates?

SQL aggregate functions perform calculations on groups of rows to return single values. Instead of looking at individual Instagram posts, you analyze total engagement by user. Instead of examining single purchases, you calculate total revenue by product category.

**Think of aggregates as:**
- **Netflix:** "Which genres have the highest average ratings?"
- **Spotify:** "How many streams does each artist have this year?"
- **Amazon:** "What's the total revenue by product category?"
- **Instagram:** "Which users have the highest average post engagement?"

## Essential Aggregate Functions

### The Core Five Functions

**COUNT() - Counting Records**
```sql
-- Count total records
SELECT COUNT(*) AS total_products FROM shop_products;

-- Count non-NULL values in specific column
SELECT COUNT(sale_price) AS products_on_sale FROM shop_products;

-- Count distinct values
SELECT COUNT(DISTINCT category) AS unique_categories FROM shop_products;
```

**SUM() - Total Values**
```sql
-- Total inventory value
SELECT SUM(price * stock) AS total_inventory_value FROM shop_products;

-- Total discount amount
SELECT SUM(price - sale_price) AS total_discount_amount 
FROM shop_products 
WHERE sale_price IS NOT NULL;
```

**AVG() - Average Values**
```sql
-- Average product price
SELECT AVG(price) AS average_price FROM shop_products;

-- Average engagement rate for videos
SELECT AVG(likes * 100.0 / views) AS avg_engagement_rate FROM video_analytics;
```

**MIN() and MAX() - Extremes**
```sql
-- Price range analysis
SELECT 
    MIN(price) AS lowest_price,
    MAX(price) AS highest_price,
    MAX(price) - MIN(price) AS price_range
FROM shop_products;
```

## Our Practice Tables for Aggregate Analysis

### Table 1: E-commerce Sales Data (sales_data)
**First action: `SELECT * FROM sales_data;`**

```
+----+----------+------------+----------+-------+------------+
| id | product  | category   | quantity | price | order_date |
+----+----------+------------+----------+-------+------------+
| 1  | iPhone   | Electronics| 2        | 999   | 2024-01-15 |
| 2  | MacBook  | Electronics| 1        | 2499  | 2024-01-20 |
| 3  | Coffee   | Kitchen    | 5        | 89    | 2024-02-10 |
| 4  | Shoes    | Fashion    | 3        | 129   | 2024-02-15 |
| 5  | iPad     | Electronics| 1        | 599   | 2024-03-05 |
| 6  | Jacket   | Fashion    | 2        | 199   | 2024-03-10 |
+----+----------+------------+----------+-------+------------+
```

### Table 2: User Activity Data (user_activity)
**First action: `SELECT * FROM user_activity;`**

```
+----+-----------+------------+-----------+-------+
| id | username  | activity   | timestamp | count |
+----+-----------+------------+-----------+-------+
| 1  | sarah_dev | post       | 2024-01-15| 1     |
| 2  | sarah_dev | like       | 2024-01-15| 45    |
| 3  | mike_photo| post       | 2024-02-01| 1     |
| 4  | mike_photo| like       | 2024-02-01| 23    |
| 5  | lisa_art  | post       | 2024-02-10| 1     |
| 6  | lisa_art  | like       | 2024-02-10| 67    |
+----+-----------+------------+-----------+-------+
```

### Table 3: Video Performance Data (video_performance)
**First action: `SELECT * FROM video_performance;`**

```
+----+----------------+-----------+--------+-------+----------+
| id | channel_name   | category  | views  | likes | duration |
+----+----------------+-----------+--------+-------+----------+
| 1  | CodeAcademy    | Education | 125000 | 5200  | 1800     |
| 2  | CodeAcademy    | Education | 89000  | 3800  | 3600     |
| 3  | TechReviews    | Tech      | 234000 | 12400 | 2400     |
| 4  | CookingPro     | Lifestyle | 156000 | 8900  | 2700     |
| 5  | TechReviews    | Tech      | 167000 | 9100  | 3200     |
+----+----------------+-----------+--------+-------+----------+
```

## GROUP BY: The Foundation of Aggregation

GROUP BY transforms your data from individual records to summary statistics by grouping related records together.

### Basic GROUP BY Patterns

**E-commerce Sales by Category**
```sql
-- Total sales and revenue by product category (Amazon-style analysis)
SELECT 
    category,
    COUNT(*) AS total_orders,
    SUM(quantity) AS total_units_sold,
    SUM(quantity * price) AS total_revenue,
    AVG(price) AS average_price
FROM sales_data
GROUP BY category
ORDER BY total_revenue DESC;
```

**User Engagement Analysis**
```sql
-- Social media user activity summary (Instagram/TikTok analytics)
SELECT 
    username,
    COUNT(*) AS total_activities,
    SUM(CASE WHEN activity = 'post' THEN count ELSE 0 END) AS total_posts,
    SUM(CASE WHEN activity = 'like' THEN count ELSE 0 END) AS total_likes,
    MAX(timestamp) AS last_activity
FROM user_activity
GROUP BY username
ORDER BY total_posts DESC;
```

**Channel Performance by Category**
```sql
-- YouTube analytics: channel performance by content category
SELECT 
    category,
    COUNT(*) AS video_count,
    SUM(views) AS total_views,
    AVG(views) AS average_views_per_video,
    SUM(likes) AS total_likes,
    AVG(likes * 100.0 / views) AS avg_engagement_rate
FROM video_performance
GROUP BY category
ORDER BY total_views DESC;
```

### Multiple Column Grouping

**Advanced E-commerce Analysis**
```sql
-- Sales analysis by category and month (business intelligence dashboard)
SELECT 
    category,
    EXTRACT(MONTH FROM order_date) AS month,
    EXTRACT(YEAR FROM order_date) AS year,
    COUNT(*) AS orders_count,
    SUM(quantity * price) AS monthly_revenue,
    AVG(quantity * price) AS avg_order_value
FROM sales_data
GROUP BY category, EXTRACT(MONTH FROM order_date), EXTRACT(YEAR FROM order_date)
ORDER BY year, month, monthly_revenue DESC;
```

**Content Creator Analytics**
```sql
-- YouTube: Channel and category performance analysis
SELECT 
    channel_name,
    category,
    COUNT(*) AS videos_in_category,
    SUM(views) AS category_total_views,
    AVG(duration) AS avg_video_length,
    MAX(likes) AS best_performing_video_likes
FROM video_performance
GROUP BY channel_name, category
ORDER BY channel_name, category_total_views DESC;
```

### Complex Aggregation Patterns

**Time-based Analysis**
```sql
-- Monthly sales trends with growth metrics
SELECT 
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    COUNT(*) AS total_orders,
    SUM(quantity * price) AS monthly_revenue,
    AVG(quantity * price) AS avg_order_value,
    -- Calculate month-over-month growth indicators
    SUM(quantity * price) - LAG(SUM(quantity * price)) OVER (ORDER BY EXTRACT(YEAR FROM order_date), EXTRACT(MONTH FROM order_date)) AS revenue_change
FROM sales_data
GROUP BY EXTRACT(YEAR FROM order_date), EXTRACT(MONTH FROM order_date)
ORDER BY year, month;
```

## HAVING: Filtering Aggregated Results

HAVING filters groups after aggregation, while WHERE filters individual records before aggregation.

### Basic HAVING Usage

**Find High-Performing Categories**
```sql
-- E-commerce: Find categories with significant sales volume
SELECT 
    category,
    COUNT(*) AS order_count,
    SUM(quantity * price) AS total_revenue
FROM sales_data
GROUP BY category
HAVING SUM(quantity * price) > 1000  -- Only categories with >$1000 revenue
ORDER BY total_revenue DESC;
```

**Identify Active Users**
```sql
-- Social media: Find users with high activity levels
SELECT 
    username,
    COUNT(*) AS total_activities,
    SUM(count) AS total_engagement_actions
FROM user_activity
GROUP BY username
HAVING COUNT(*) >= 3  -- Users with 3+ different activities
   AND SUM(count) > 50  -- And >50 total engagement actions
ORDER BY total_engagement_actions DESC;
```

**Content Categories with Good Performance**
```sql
-- YouTube: Find content categories with strong average performance
SELECT 
    category,
    COUNT(*) AS video_count,
    AVG(views) AS avg_views,
    AVG(likes * 100.0 / views) AS avg_engagement_rate
FROM video_performance
GROUP BY category
HAVING COUNT(*) >= 2  -- Categories with multiple videos
   AND AVG(views) > 100000  -- Strong average viewership
ORDER BY avg_engagement_rate DESC;
```

### Complex HAVING Conditions

**Business Intelligence with Multiple Criteria**
```sql
-- E-commerce: Identify premium product categories
SELECT 
    category,
    COUNT(*) AS product_count,
    AVG(price) AS average_price,
    SUM(quantity * price) AS total_revenue,
    MAX(price) AS highest_priced_item
FROM sales_data
GROUP BY category
HAVING COUNT(*) >= 2  -- Categories with multiple products
   AND AVG(price) > 200  -- Premium pricing
   AND SUM(quantity * price) > 500  -- Decent revenue
ORDER BY average_price DESC;
```

**Creator Performance Analysis**
```sql
-- YouTube: Find successful content creators
SELECT 
    channel_name,
    COUNT(*) AS total_videos,
    SUM(views) AS total_views,
    AVG(views) AS avg_views_per_video,
    SUM(likes) AS total_likes
FROM video_performance
GROUP BY channel_name
HAVING COUNT(*) >= 2  -- Channels with multiple videos
   AND AVG(views) > 120000  -- Strong average performance
   AND SUM(views) > 200000  -- Good total reach
ORDER BY total_views DESC;
```

## Advanced Aggregation Techniques

### Statistical Analysis

**Comprehensive Sales Statistics**
```sql
-- E-commerce: Deep statistical analysis by category
SELECT 
    category,
    COUNT(*) AS sample_size,
    -- Central tendency measures
    AVG(quantity * price) AS mean_order_value,
    -- Range and spread
    MIN(quantity * price) AS min_order_value,
    MAX(quantity * price) AS max_order_value,
    MAX(quantity * price) - MIN(quantity * price) AS value_range,
    -- Business metrics
    SUM(quantity) AS total_units,
    SUM(quantity * price) AS total_revenue,
    -- Performance indicators
    CASE 
        WHEN AVG(quantity * price) > 1000 THEN 'High-Value Category'
        WHEN AVG(quantity * price) > 500 THEN 'Medium-Value Category'
        ELSE 'Budget Category'
    END AS category_tier
FROM sales_data
GROUP BY category
ORDER BY total_revenue DESC;
```

**Content Performance Analytics**
```sql
-- YouTube: Comprehensive channel performance metrics
SELECT 
    channel_name,
    COUNT(*) AS video_portfolio_size,
    -- Viewership analytics
    SUM(views) AS total_channel_views,
    AVG(views) AS avg_views_per_video,
    MIN(views) AS lowest_performing_video,
    MAX(views) AS best_performing_video,
    -- Engagement analytics
    SUM(likes) AS total_channel_likes,
    AVG(likes * 100.0 / views) AS avg_engagement_rate,
    -- Content strategy metrics
    AVG(duration) AS avg_video_length,
    -- Performance classification
    CASE 
        WHEN AVG(views) > 150000 THEN 'Top Performer'
        WHEN AVG(views) > 100000 THEN 'Strong Performer'
        ELSE 'Growing Channel'
    END AS channel_tier
FROM video_performance
GROUP BY channel_name
HAVING COUNT(*) >= 2  -- Channels with meaningful sample size
ORDER BY total_channel_views DESC;
```

### Conditional Aggregation

**Advanced Business Metrics**
```sql
-- E-commerce: Conditional aggregation for business intelligence
SELECT 
    category,
    -- Count different order types
    COUNT(*) AS total_orders,
    COUNT(CASE WHEN quantity = 1 THEN 1 END) AS single_item_orders,
    COUNT(CASE WHEN quantity > 1 THEN 1 END) AS bulk_orders,
    -- Revenue breakdown
    SUM(quantity * price) AS total_revenue,
    SUM(CASE WHEN quantity = 1 THEN quantity * price ELSE 0 END) AS single_item_revenue,
    SUM(CASE WHEN quantity > 1 THEN quantity * price ELSE 0 END) AS bulk_revenue,
    -- Performance ratios
    ROUND(
        SUM(CASE WHEN quantity > 1 THEN quantity * price ELSE 0 END) * 100.0 / SUM(quantity * price), 
        2
    ) AS bulk_revenue_percentage
FROM sales_data
GROUP BY category
ORDER BY bulk_revenue_percentage DESC;
```

**User Behavior Segmentation**
```sql
-- Social media: User engagement pattern analysis
SELECT 
    -- User engagement levels
    CASE 
        WHEN SUM(count) > 80 THEN 'Power User'
        WHEN SUM(count) > 40 THEN 'Active User'  
        WHEN SUM(count) > 20 THEN 'Casual User'
        ELSE 'New User'
    END AS user_segment,
    COUNT(DISTINCT username) AS users_in_segment,
    AVG(SUM(count)) AS avg_total_engagement,
    -- Activity breakdown
    AVG(SUM(CASE WHEN activity = 'post' THEN count ELSE 0 END)) AS avg_posts,
    AVG(SUM(CASE WHEN activity = 'like' THEN count ELSE 0 END)) AS avg_likes
FROM user_activity
GROUP BY username
HAVING SUM(count) > 0  -- Active users only
GROUP BY user_segment
ORDER BY avg_total_engagement DESC;
```

## Real-World Aggregation Patterns

### Business Dashboard Metrics

**E-commerce Executive Dashboard**
```sql
-- Comprehensive business performance summary
SELECT 
    'Overall Performance' AS metric_category,
    COUNT(DISTINCT category) AS categories_sold,
    COUNT(*) AS total_orders,
    SUM(quantity) AS total_units_sold,
    SUM(quantity * price) AS total_revenue,
    AVG(quantity * price) AS avg_order_value,
    MAX(quantity * price) AS largest_order,
    -- Growth indicators
    COUNT(CASE WHEN order_date >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) AS recent_orders,
    SUM(CASE WHEN order_date >= CURRENT_DATE - INTERVAL '30 days' THEN quantity * price ELSE 0 END) AS recent_revenue
FROM sales_data;
```

**Content Creator Performance Report**
```sql
-- YouTube creator ecosystem analysis
SELECT 
    'Platform Overview' AS report_section,
    COUNT(DISTINCT channel_name) AS active_channels,
    COUNT(DISTINCT category) AS content_categories,
    COUNT(*) AS total_videos,
    SUM(views) AS platform_total_views,
    AVG(views) AS avg_video_performance,
    SUM(likes) AS platform_total_likes,
    -- Platform health metrics
    AVG(likes * 100.0 / views) AS platform_engagement_rate,
    MAX(views) AS viral_video_views,
    AVG(duration) AS avg_content_length
FROM video_performance;
```

### Comparative Analysis

**Category Performance Comparison**
```sql
-- E-commerce: Category performance ranking and comparison
WITH category_metrics AS (
    SELECT 
        category,
        COUNT(*) AS order_count,
        SUM(quantity * price) AS revenue,
        AVG(quantity * price) AS avg_order_value,
        SUM(quantity) AS units_sold
    FROM sales_data
    GROUP BY category
)
SELECT 
    category,
    revenue,
    avg_order_value,
    units_sold,
    -- Performance rankings
    RANK() OVER (ORDER BY revenue DESC) AS revenue_rank,
    RANK() OVER (ORDER BY avg_order_value DESC) AS aov_rank,
    RANK() OVER (ORDER BY units_sold DESC) AS volume_rank,
    -- Market share analysis
    ROUND(revenue * 100.0 / SUM(revenue) OVER (), 2) AS revenue_market_share,
    -- Performance vs platform average
    CASE 
        WHEN avg_order_value > AVG(avg_order_value) OVER () THEN 'Above Average AOV'
        ELSE 'Below Average AOV'
    END AS aov_performance
FROM category_metrics
ORDER BY revenue DESC;
```

**Channel Performance Benchmarking**
```sql
-- YouTube: Channel performance vs platform benchmarks
WITH channel_stats AS (
    SELECT 
        channel_name,
        COUNT(*) AS video_count,
        SUM(views) AS total_views,
        AVG(views) AS avg_views,
        SUM(likes) AS total_likes,
        AVG(likes * 100.0 / views) AS engagement_rate
    FROM video_performance
    GROUP BY channel_name
)
SELECT 
    channel_name,
    video_count,
    total_views,
    avg_views,
    engagement_rate,
    -- Performance vs platform average
    CASE 
        WHEN avg_views > AVG(avg_views) OVER () THEN 'Above Average'
        ELSE 'Below Average'
    END AS view_performance,
    CASE 
        WHEN engagement_rate > AVG(engagement_rate) OVER () THEN 'High Engagement'
        ELSE 'Standard Engagement'
    END AS engagement_performance,
    -- Market position
    RANK() OVER (ORDER BY total_views DESC) AS total_views_rank,
    RANK() OVER (ORDER BY engagement_rate DESC) AS engagement_rank
FROM channel_stats
ORDER BY total_views DESC;
```

## Common Aggregation Mistakes and Solutions

### Mistake 1: Mixing Aggregated and Non-Aggregated Columns

```sql
-- ❌ This will cause an error
SELECT category, product, SUM(quantity * price)
FROM sales_data
GROUP BY category;  -- Error: product is not in GROUP BY

-- ✅ Correct approaches
-- Option 1: Include all non-aggregated columns in GROUP BY
SELECT category, product, SUM(quantity * price)
FROM sales_data  
GROUP BY category, product;

-- Option 2: Only select aggregated results
SELECT category, SUM(quantity * price) AS revenue
FROM sales_data
GROUP BY category;
```

### Mistake 2: Using WHERE with Aggregated Results

```sql
-- ❌ Wrong: Using WHERE with aggregated functions
SELECT category, SUM(quantity * price) AS revenue
FROM sales_data
GROUP BY category
WHERE SUM(quantity * price) > 1000;  -- Error: can't use aggregate in WHERE

-- ✅ Correct: Use HAVING for aggregated conditions
SELECT category, SUM(quantity * price) AS revenue
FROM sales_data
GROUP BY category
HAVING SUM(quantity * price) > 1000;
```

### Mistake 3: Incorrect NULL Handling

```sql
-- ❌ Might miss important insights
SELECT category, AVG(price) 
FROM sales_data
GROUP BY category;  -- Ignores NULL prices

-- ✅ Better: Explicit NULL handling
SELECT 
    category,
    AVG(price) AS avg_price,
    COUNT(price) AS products_with_price,
    COUNT(*) AS total_products,
    COUNT(*) - COUNT(price) AS products_missing_price
FROM sales_data
GROUP BY category;
```

SQL aggregates transform individual data points into strategic business intelligence. Whether you're optimizing Netflix content recommendations, improving Spotify artist discovery, or maximizing Amazon sales performance, aggregation functions help you discover patterns that drive data-driven decisions across entire platforms! 📊🚀
    ''',
    "is_free": False,
    "xp_reward": 115,
    "exercises": [
        {
            "id": "ecommerce-sales-aggregation",
            "title": "E-commerce Sales Analysis with GROUP BY",
            "type": "practice",
            "instructions": """Practice SQL aggregation to analyze e-commerce sales patterns, calculate business metrics, and identify trends.

Your tasks:
1. First explore the data with SELECT * FROM sales_data;
2. Calculate total sales and revenue by product category
3. Find the best and worst performing categories
4. Analyze sales trends by month
5. Use HAVING to find high-value categories
6. Calculate comprehensive category statistics

Table: sales_data
Columns: id, product, category, quantity, price, order_date""",
            "starter_code": """-- Task 1: Explore the sales data
SELECT * FROM sales_data;

-- Task 2: Calculate sales metrics by category
-- Show category, count of orders, total units sold, total revenue, average order value
-- Use GROUP BY category with COUNT, SUM, AVG


-- Task 3: Find best and worst performing categories by revenue
-- Order results by total revenue DESC to see top performers


-- Task 4: Analyze sales by month
-- Extract month from order_date, group by month, calculate monthly totals
-- Use EXTRACT(MONTH FROM order_date) and GROUP BY


-- Task 5: Use HAVING to find significant categories
-- Find categories with total revenue > 1000 AND more than 1 order
-- Use GROUP BY with HAVING conditions


-- Task 6: Calculate comprehensive statistics by category
-- Show min/max order values, price range, and performance classification
-- Use multiple aggregate functions and CASE for classification
""",
            "solution": """-- Task 1: Explore the sales data
SELECT * FROM sales_data;

-- Task 2: Calculate sales metrics by category
SELECT 
    category,
    COUNT(*) AS total_orders,
    SUM(quantity) AS total_units_sold,
    SUM(quantity * price) AS total_revenue,
    AVG(quantity * price) AS avg_order_value
FROM sales_data
GROUP BY category;

-- Task 3: Find best and worst performing categories by revenue
SELECT 
    category,
    COUNT(*) AS order_count,
    SUM(quantity * price) AS total_revenue,
    AVG(price) AS avg_product_price
FROM sales_data
GROUP BY category
ORDER BY total_revenue DESC;

-- Task 4: Analyze sales by month
SELECT 
    EXTRACT(MONTH FROM order_date) AS month,
    COUNT(*) AS monthly_orders,
    SUM(quantity * price) AS monthly_revenue,
    AVG(quantity * price) AS avg_monthly_order_value
FROM sales_data
GROUP BY EXTRACT(MONTH FROM order_date)
ORDER BY month;

-- Task 5: Use HAVING to find significant categories
SELECT 
    category,
    COUNT(*) AS order_count,
    SUM(quantity * price) AS total_revenue,
    AVG(quantity * price) AS avg_order_value
FROM sales_data
GROUP BY category
HAVING SUM(quantity * price) > 1000
   AND COUNT(*) > 1
ORDER BY total_revenue DESC;

-- Task 6: Calculate comprehensive statistics by category
SELECT 
    category,
    COUNT(*) AS order_count,
    SUM(quantity * price) AS total_revenue,
    AVG(quantity * price) AS avg_order_value,
    MIN(quantity * price) AS min_order_value,
    MAX(quantity * price) AS max_order_value,
    MAX(quantity * price) - MIN(quantity * price) AS order_value_range,
    CASE 
        WHEN AVG(quantity * price) > 1000 THEN 'Premium Category'
        WHEN AVG(quantity * price) > 500 THEN 'Mid-Range Category'
        ELSE 'Budget Category'
    END AS category_tier
FROM sales_data
GROUP BY category
ORDER BY total_revenue DESC;""",
            "test_cases": [
                {
                    "name": "GROUP BY with multiple aggregates",
                    "input": "SELECT category, COUNT(*), SUM(quantity * price) FROM sales_data GROUP BY category;",
                    "expected_contains": ["GROUP BY", "COUNT", "SUM", "category"]
                },
                {
                    "name": "HAVING clause with conditions",
                    "input": "SELECT category, SUM(quantity * price) FROM sales_data GROUP BY category HAVING SUM(quantity * price) > 1000;",
                    "expected_contains": ["GROUP BY", "HAVING", "SUM"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "Use COUNT(*) to count total orders in each group",
                "SUM(quantity * price) calculates total revenue",
                "AVG(quantity * price) gives average order value",
                "EXTRACT(MONTH FROM order_date) extracts month number",
                "HAVING filters groups after aggregation, WHERE filters before"
            ]
        },
        {
            "id": "content-analytics-aggregation",
            "title": "YouTube Analytics with Advanced Aggregation",
            "type": "practice",
            "instructions": """Use advanced aggregation techniques to analyze YouTube content performance, channel metrics, and audience engagement patterns.

Your tasks:
1. Explore video performance data
2. Calculate channel performance metrics
3. Analyze content category performance
4. Find top performing channels using HAVING
5. Create engagement rate analysis by category
6. Build comprehensive channel comparison report

Table: video_performance
Columns: id, channel_name, category, views, likes, duration""",
            "starter_code": """-- Task 1: Explore video performance data
SELECT * FROM video_performance;

-- Task 2: Calculate channel performance metrics
-- Group by channel_name, show video count, total views, average views, total likes
-- Calculate average engagement rate (likes/views * 100)


-- Task 3: Analyze content category performance 
-- Group by category, calculate total views, average views, video count
-- Order by total views DESC to see top categories


-- Task 4: Find successful channels using HAVING
-- Use HAVING to find channels with 2+ videos AND total views > 250000
-- Show channel stats for these high-performers only


-- Task 5: Create engagement analysis by category
-- Calculate average engagement rate, min/max engagement per category
-- Include video count and total likes by category


-- Task 6: Build comprehensive channel comparison 
-- Show channel performance with rankings and classifications
-- Include performance tier based on average views
""",
            "solution": """-- Task 1: Explore video performance data
SELECT * FROM video_performance;

-- Task 2: Calculate channel performance metrics
SELECT 
    channel_name,
    COUNT(*) AS total_videos,
    SUM(views) AS total_views,
    AVG(views) AS avg_views_per_video,
    SUM(likes) AS total_likes,
    AVG(likes * 100.0 / views) AS avg_engagement_rate
FROM video_performance
GROUP BY channel_name
ORDER BY total_views DESC;

-- Task 3: Analyze content category performance
SELECT 
    category,
    COUNT(*) AS video_count,
    SUM(views) AS total_category_views,
    AVG(views) AS avg_views_per_video,
    SUM(likes) AS total_category_likes
FROM video_performance
GROUP BY category
ORDER BY total_category_views DESC;

-- Task 4: Find successful channels using HAVING
SELECT 
    channel_name,
    COUNT(*) AS video_count,
    SUM(views) AS total_views,
    AVG(views) AS avg_views,
    SUM(likes) AS total_likes
FROM video_performance
GROUP BY channel_name
HAVING COUNT(*) >= 2
   AND SUM(views) > 250000
ORDER BY total_views DESC;

-- Task 5: Create engagement analysis by category
SELECT 
    category,
    COUNT(*) AS video_count,
    AVG(likes * 100.0 / views) AS avg_engagement_rate,
    MIN(likes * 100.0 / views) AS min_engagement_rate,
    MAX(likes * 100.0 / views) AS max_engagement_rate,
    SUM(likes) AS total_likes,
    SUM(views) AS total_views
FROM video_performance
GROUP BY category
ORDER BY avg_engagement_rate DESC;

-- Task 6: Build comprehensive channel comparison
SELECT 
    channel_name,
    COUNT(*) AS video_portfolio_size,
    SUM(views) AS total_channel_views,
    AVG(views) AS avg_views_per_video,
    AVG(likes * 100.0 / views) AS avg_engagement_rate,
    AVG(duration) AS avg_video_length,
    CASE 
        WHEN AVG(views) > 150000 THEN 'Top Performer'
        WHEN AVG(views) > 100000 THEN 'Strong Performer'
        ELSE 'Growing Channel'
    END AS performance_tier,
    RANK() OVER (ORDER BY SUM(views) DESC) AS total_views_rank
FROM video_performance
GROUP BY channel_name
ORDER BY total_channel_views DESC;""",
            "test_cases": [
                {
                    "name": "Channel aggregation with engagement rate",
                    "input": "SELECT channel_name, AVG(likes * 100.0 / views) FROM video_performance GROUP BY channel_name;",
                    "expected_contains": ["AVG", "likes", "*", "100.0", "/", "views", "GROUP BY"]
                },
                {
                    "name": "Complex HAVING with multiple conditions",
                    "input": "SELECT category, COUNT(*), SUM(views) FROM video_performance GROUP BY category HAVING COUNT(*) >= 2 AND SUM(views) > 200000;",
                    "expected_contains": ["HAVING", "COUNT", "AND", "SUM"]
                }
            ],
            "xp_reward": 85,
            "hints": [
                "Engagement rate formula: (likes * 100.0 / views) for percentage",
                "Use RANK() OVER (ORDER BY ...) for ranking channels",
                "HAVING filters groups - use it after GROUP BY",
                "AVG(duration) calculates average video length per channel",
                "CASE expressions help create performance tiers"
            ]
        }
    ]
}