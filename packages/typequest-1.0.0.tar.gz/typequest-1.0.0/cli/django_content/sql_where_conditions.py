"""
SQL WHERE Conditions lesson content
"""

SQL_WHERE_CONDITIONS_LESSON = {
    "id": 32,
    "chapter": 32,
    "title": "SQL Queries with WHERE Conditions",
    "slug": "sql-where-conditions",
    "content": '''
# SQL WHERE Conditions: Precision Data Filtering

Think of the WHERE clause as a bouncer at an exclusive club - it only lets through the data that meets your specific criteria. Whether you're finding viral TikTok videos, high-value Amazon customers, or trending Spotify tracks, WHERE clauses help you cut through millions of records to find exactly what matters.

## The WHERE Clause: Your Data Filter

The WHERE clause transforms your SELECT statements from "show me everything" to "show me exactly what I need." It's the difference between scrolling through your entire Instagram feed versus searching for posts from your best friend.

### Basic Syntax:
```sql
SELECT column1, column2
FROM table_name
WHERE condition;
```

**Real-world analogy:** WHERE is like using filters on any app - Amazon's price range, Netflix's genre selector, or Spotify's year filter. It narrows down results to exactly what you want.

## Essential Comparison Operators

### Numeric Comparisons
```sql
-- Instagram: Find influencers (users with 100,000+ followers)
SELECT username, follower_count
FROM instagram_users
WHERE follower_count >= 100000;

-- YouTube: Find viral videos (1M+ views)
SELECT title, views, channel_name
FROM youtube_videos  
WHERE views > 1000000;

-- Spotify: Find recent hits (2020 or later)
SELECT title, artist, year
FROM spotify_songs
WHERE year >= 2020;
```

### Exact Matches
```sql
-- Instagram: Find verified accounts
SELECT username, follower_count
FROM instagram_users
WHERE verified = 1;

-- YouTube: Find specific channel content
SELECT title, views
FROM youtube_videos
WHERE channel_name = 'CodeAcademy';

-- Spotify: Find songs from specific year
SELECT title, artist
FROM spotify_songs
WHERE year = 2021;
```

### Inequality Filters
```sql
-- Instagram: Find non-verified accounts 
SELECT username, follower_count
FROM instagram_users
WHERE verified != 1;
-- or
WHERE verified <> 1;  -- Alternative syntax

-- YouTube: Exclude short videos (less than 10 minutes)
SELECT title, duration
FROM youtube_videos
WHERE duration != 600;  -- 600 seconds = 10 minutes

-- Spotify: Find older music (before streaming era)
SELECT title, artist, year
FROM spotify_songs
WHERE year < 2000;
```

## Advanced Filtering Techniques

### Range Filtering with BETWEEN
```sql
-- Instagram: Find mid-tier influencers (10K-100K followers)
SELECT username, follower_count
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000;

-- YouTube: Find medium-length videos (10-30 minutes)
SELECT title, duration, channel_name
FROM youtube_videos
WHERE duration BETWEEN 600 AND 1800;  -- 10-30 minutes in seconds

-- Spotify: Find 2010s music
SELECT title, artist, year
FROM spotify_songs
WHERE year BETWEEN 2010 AND 2019;
```

### List Filtering with IN
```sql
-- Instagram: Find specific users by username
SELECT username, follower_count, verified
FROM instagram_users
WHERE username IN ('travel_sarah', 'tech_mike', 'fitness_guru');

-- YouTube: Find videos from tech channels
SELECT title, views, channel_name
FROM youtube_videos
WHERE channel_name IN ('CodeAcademy', 'DataPro', 'DevBootcamp');

-- Spotify: Find songs by popular artists
SELECT title, artist, streams
FROM spotify_songs
WHERE artist IN ('Ed Sheeran', 'The Weeknd', 'Dua Lipa');
```

### Exclusion with NOT IN
```sql
-- Instagram: Exclude specific users from analysis
SELECT username, follower_count
FROM instagram_users
WHERE username NOT IN ('spam_account', 'test_user');

-- YouTube: Exclude certain channels
SELECT title, views
FROM youtube_videos
WHERE channel_name NOT IN ('OldChannel', 'InactiveCreator');

-- Spotify: Find non-pop music
SELECT title, artist, year
FROM spotify_songs
WHERE artist NOT IN ('Taylor Swift', 'Ariana Grande');
```

## Text Pattern Matching

### Exact Text Matching
```sql
-- Case-sensitive exact match
SELECT username, email
FROM instagram_users
WHERE username = 'travel_sarah';

-- Case-insensitive matching (database dependent)
SELECT title, artist
FROM spotify_songs
WHERE artist = 'ED SHEERAN';  -- May or may not match 'Ed Sheeran'
```

### Partial Text Matching with LIKE
```sql
-- Instagram: Find travel-related accounts
SELECT username, follower_count
FROM instagram_users
WHERE username LIKE '%travel%';  -- Contains 'travel'

-- YouTube: Find tutorial videos
SELECT title, views, channel_name
FROM youtube_videos
WHERE title LIKE '%Tutorial%';  -- Contains 'Tutorial'

-- Spotify: Find songs with 'love' in the title
SELECT title, artist
FROM spotify_songs
WHERE title LIKE '%love%';
```

### Pattern Matching Wildcards
```sql
-- % = any number of characters
-- _ = exactly one character

-- Instagram: Find usernames starting with 'tech'
SELECT username, follower_count
FROM instagram_users
WHERE username LIKE 'tech%';

-- YouTube: Find titles ending with 'Course'
SELECT title, channel_name
FROM youtube_videos
WHERE title LIKE '%Course';

-- Spotify: Find 4-letter song titles
SELECT title, artist
FROM spotify_songs
WHERE title LIKE '____';  -- Exactly 4 characters
```

## Logical Operators: Combining Conditions

### AND Operator: All Conditions Must Be True
```sql
-- Instagram: Find verified influencers with 100K+ followers
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count >= 100000 
  AND verified = 1;

-- YouTube: Find popular recent coding videos
SELECT title, views, channel_name
FROM youtube_videos
WHERE views > 500000 
  AND title LIKE '%Python%';

-- Spotify: Find recent hits by specific artists
SELECT title, artist, year, streams
FROM spotify_songs
WHERE year >= 2020 
  AND artist = 'Ed Sheeran';
```

### OR Operator: Any Condition Can Be True
```sql
-- Instagram: Find either verified accounts OR those with 200K+ followers
SELECT username, follower_count, verified
FROM instagram_users
WHERE verified = 1 
   OR follower_count >= 200000;

-- YouTube: Find videos from either CodeAcademy OR DataPro
SELECT title, views, channel_name
FROM youtube_videos
WHERE channel_name = 'CodeAcademy' 
   OR channel_name = 'DataPro';

-- Spotify: Find songs from either 2020 or 2021
SELECT title, artist, year
FROM spotify_songs
WHERE year = 2020 
   OR year = 2021;
```

### Complex Logical Combinations
```sql
-- Instagram: Find non-verified accounts with either high followers OR high following
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE verified = 0 
  AND (follower_count >= 50000 OR following >= 1000);

-- YouTube: Find either viral videos OR videos from top channels
SELECT title, views, channel_name
FROM youtube_videos
WHERE views > 1000000 
   OR channel_name IN ('CodeAcademy', 'TechEd', 'DataPro');
```

## NULL Value Handling

### Checking for Missing Data
```sql
-- Find records with missing information
SELECT username, email
FROM instagram_users
WHERE email IS NULL;

-- Find records with complete information
SELECT username, email
FROM instagram_users
WHERE email IS NOT NULL;
```

## Real-World WHERE Clause Applications

### Social Media Analysis
```sql
-- Marketing research: Find micro-influencers (10K-100K followers)
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0;  -- Non-verified accounts often charge less

-- Content strategy: Find successful tech YouTubers
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE title LIKE '%tech%' 
   OR title LIKE '%coding%' 
   OR title LIKE '%programming%'
  AND views > 100000;
```

### Music Industry Analytics
```sql
-- Label research: Find trending artists with multiple hits
SELECT artist, title, streams, year
FROM spotify_songs
WHERE streams > 1000000
  AND year >= 2020
ORDER BY artist, streams DESC;

-- Playlist curation: Find upbeat songs from specific era
SELECT title, artist, year
FROM spotify_songs
WHERE year BETWEEN 2015 AND 2020
  AND (title LIKE '%happy%' OR title LIKE '%dance%' OR title LIKE '%party%');
```

### Content Performance Analysis
```sql
-- YouTube algorithm research: Find optimal video length for engagement
SELECT title, duration, views, likes, channel_name
FROM youtube_videos
WHERE duration BETWEEN 600 AND 1200  -- 10-20 minutes
  AND likes > 10000
  AND views > 100000;

-- Channel growth analysis: Compare verified vs non-verified creators
SELECT 
    CASE WHEN verified = 1 THEN 'Verified' ELSE 'Not Verified' END as status,
    COUNT(*) as user_count,
    AVG(follower_count) as avg_followers
FROM instagram_users
WHERE follower_count > 1000  -- Exclude inactive accounts
GROUP BY verified;
```

## WHERE Clause Best Practices

### 1. Use Appropriate Data Types
```sql
-- ❌ Comparing numbers as text
WHERE follower_count = '100000'

-- ✅ Proper numeric comparison  
WHERE follower_count = 100000
```

### 2. Be Careful with NULL Values
```sql
-- ❌ This won't find NULL values
WHERE email = NULL

-- ✅ Proper NULL checking
WHERE email IS NULL
```

### 3. Use Parentheses for Complex Logic
```sql
-- ❌ Ambiguous logic
WHERE verified = 1 OR follower_count > 100000 AND following < 500

-- ✅ Clear intention with parentheses
WHERE verified = 1 OR (follower_count > 100000 AND following < 500)
```

### 4. Consider Performance
```sql
-- ✅ More efficient (specific first)
WHERE verified = 1 AND follower_count > 100000

-- ❌ Less efficient (expensive calculation first)  
WHERE follower_count > 100000 AND verified = 1
```

## Common WHERE Clause Patterns by Industry

### E-commerce (Amazon-style)
```sql
-- Find bestselling products in price range
SELECT product_name, price, sales_count
FROM products
WHERE price BETWEEN 20 AND 100
  AND sales_count > 1000
  AND category = 'Electronics';
```

### Social Media (Instagram-style)
```sql
-- Find engagement opportunities  
SELECT username, follower_count, following
FROM users
WHERE follower_count < 10000
  AND following > 5000
  AND verified = 0;
```

### Streaming (Netflix-style)
```sql
-- Find binge-worthy content
SELECT title, genre, rating, season_count
FROM shows
WHERE rating >= 8.0
  AND season_count >= 3
  AND genre IN ('Drama', 'Thriller', 'Sci-Fi');
```

The WHERE clause is your precision tool for data analysis. Master these patterns, and you'll be able to slice and dice data like the analytics teams at Facebook, Google, or any major tech company. Every business insight starts with asking the right questions - and WHERE clauses help you find the right answers! 🎯
    ''',
    "is_free": False,
    "xp_reward": 85,
    "exercises": [
        {
            "id": "instagram-influencer-analysis",
            "title": "Instagram Influencer Analysis with WHERE",
            "type": "practice", 
            "instructions": """Use WHERE clauses to analyze Instagram user data and find different types of influencers and accounts.

Your tasks:
1. First, explore the full dataset with SELECT * FROM instagram_users;
2. Find mega-influencers (500K+ followers)
3. Find verified accounts only
4. Find micro-influencers (10K-100K followers) who are not verified
5. Find users with specific usernames
6. Find accounts with high following counts (1000+)

Table: instagram_users
Columns: id, username, email, follower_count, following, verified""",
            "starter_code": """-- Task 1: Explore the full dataset
SELECT * FROM instagram_users;

-- Task 2: Find mega-influencers (500K+ followers)
-- Write a query to find users with follower_count >= 500000


-- Task 3: Find only verified accounts
-- Write a query to find users where verified = 1


-- Task 4: Find non-verified micro-influencers (10K-100K followers)
-- Use AND to combine follower_count range with verified = 0


-- Task 5: Find specific users by username
-- Use IN to find users with usernames 'travel_sarah', 'tech_mike', 'fitness_guru'


-- Task 6: Find accounts with high following counts
-- Find users who follow 1000 or more people
""",
            "solution": """-- Task 1: Explore the full dataset
SELECT * FROM instagram_users;

-- Task 2: Find mega-influencers (500K+ followers)
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count >= 500000;

-- Task 3: Find only verified accounts  
SELECT username, follower_count, verified
FROM instagram_users
WHERE verified = 1;

-- Task 4: Find non-verified micro-influencers (10K-100K followers)
SELECT username, follower_count, verified
FROM instagram_users  
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0;

-- Task 5: Find specific users by username
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE username IN ('travel_sarah', 'tech_mike', 'fitness_guru');

-- Task 6: Find accounts with high following counts
SELECT username, following, follower_count
FROM instagram_users
WHERE following >= 1000;""",
            "test_cases": [
                {
                    "name": "WHERE with numeric comparison",
                    "input": "SELECT * FROM instagram_users WHERE follower_count >= 500000;",
                    "expected_contains": ["WHERE", "follower_count", ">="]
                },
                {
                    "name": "WHERE with BETWEEN and AND",
                    "input": "SELECT * FROM instagram_users WHERE follower_count BETWEEN 10000 AND 100000 AND verified = 0;",
                    "expected_contains": ["BETWEEN", "AND", "verified"]
                }
            ],
            "xp_reward": 55,
            "hints": [
                "Use >= for 'greater than or equal to' comparisons",
                "BETWEEN includes both boundary values (10000 AND 100000)",
                "Use AND to combine multiple conditions",
                "IN operator works with a list of values in parentheses"
            ]
        },
        {
            "id": "youtube-content-filtering",
            "title": "YouTube Content Analysis with WHERE Filters",
            "type": "practice",
            "instructions": """Practice filtering YouTube video data to find specific types of content and performance metrics.

Your tasks:
1. Explore all video data first
2. Find viral videos (2M+ views)  
3. Find videos with high engagement (50K+ likes)
4. Find tutorial content using LIKE pattern matching
5. Find videos from specific channels
6. Find popular recent uploads (1M+ views AND 30K+ likes)

Table: youtube_videos
Columns: id, title, channel_name, views, likes, duration""",
            "starter_code": """-- Task 1: Explore all video data
SELECT * FROM youtube_videos;

-- Task 2: Find viral videos (2M+ views)
-- Write a query for videos with views >= 2000000


-- Task 3: Find videos with high engagement (50K+ likes)
-- Write a query for videos with likes >= 50000


-- Task 4: Find tutorial content
-- Use LIKE to find videos with 'Tutorial' in the title


-- Task 5: Find videos from educational channels  
-- Use IN to find videos from 'CodeAcademy', 'DataPro', or 'DevBootcamp'


-- Task 6: Find popular, highly-engaged content
-- Use AND to find videos with both views >= 1000000 AND likes >= 30000
""",
            "solution": """-- Task 1: Explore all video data
SELECT * FROM youtube_videos;

-- Task 2: Find viral videos (2M+ views)
SELECT title, views, channel_name
FROM youtube_videos  
WHERE views >= 2000000;

-- Task 3: Find videos with high engagement (50K+ likes)
SELECT title, likes, views, channel_name
FROM youtube_videos
WHERE likes >= 50000;

-- Task 4: Find tutorial content
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE '%Tutorial%';

-- Task 5: Find videos from educational channels
SELECT title, channel_name, views, likes
FROM youtube_videos
WHERE channel_name IN ('CodeAcademy', 'DataPro', 'DevBootcamp');

-- Task 6: Find popular, highly-engaged content  
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE views >= 1000000 
  AND likes >= 30000;""",
            "test_cases": [
                {
                    "name": "WHERE with LIKE pattern matching",
                    "input": "SELECT * FROM youtube_videos WHERE title LIKE '%Tutorial%';",
                    "expected_contains": ["WHERE", "title", "LIKE", "%Tutorial%"]
                },
                {
                    "name": "WHERE with multiple AND conditions",
                    "input": "SELECT * FROM youtube_videos WHERE views >= 1000000 AND likes >= 30000;",
                    "expected_contains": ["WHERE", "views", "AND", "likes"]
                }
            ],
            "xp_reward": 60,
            "hints": [
                "Use % wildcards with LIKE for partial text matching",
                "AND combines conditions - both must be true", 
                "IN operator takes a list of values in parentheses",
                "Large numbers like 2000000 represent 2 million"
            ]
        }
    ]
}