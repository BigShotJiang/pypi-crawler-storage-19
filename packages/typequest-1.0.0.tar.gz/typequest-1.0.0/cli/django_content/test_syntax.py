TEST_DICT = {
    "id": 45,
    "title": "Test",
    "content": '''This is a test content.'''
}