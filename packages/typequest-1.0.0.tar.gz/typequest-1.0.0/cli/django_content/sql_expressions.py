"""
SQL Queries with Expressions lesson content
"""

SQL_EXPRESSIONS_LESSON = {
    "id": 36,
    "chapter": 36,
    "title": "SQL Queries with Expressions and Calculations",
    "slug": "sql-expressions",
    "content": '''
# SQL Queries with Expressions: Transforming Data Into Insights

Raw data tells a story, but calculated expressions reveal the plot twists. When Instagram shows engagement rates, Spotify calculates recommendation scores, or Amazon displays savings percentages, they're using SQL expressions to transform basic numbers into meaningful business insights.

## What Are SQL Expressions?

SQL expressions are mathematical calculations, string manipulations, and logical operations that transform data during retrieval. Instead of just selecting stored values, you create new insights on-the-fly.

**Think of expressions as:**
- **Instagram:** Calculating engagement rate from likes and followers
- **Netflix:** Computing viewing hours from start/end timestamps  
- **Amazon:** Displaying discount percentages from original and sale prices
- **Spotify:** Generating popularity scores from plays and age

## Our Practice Tables for Expression Building

### Table 1: E-commerce Products (shop_products)
**First action: `SELECT * FROM shop_products;`**

```
+----+------------------+----------+-------------+-------+
| id | name             | price    | sale_price  | stock |
+----+------------------+----------+-------------+-------+
| 1  | iPhone 15        | 999.00   | 849.00      | 45    |
| 2  | MacBook Pro      | 2499.00  | 2199.00     | 12    |
| 3  | AirPods Pro      | 249.00   | NULL        | 89    |
| 4  | iPad Air         | 599.00   | 499.00      | 23    |
| 5  | Apple Watch      | 399.00   | 349.00      | 67    |
+----+------------------+----------+-------------+-------+
```

### Table 2: YouTube Analytics (video_analytics)
**First action: `SELECT * FROM video_analytics;`**

```
+----+-------------------------+--------+--------+----------+----------+
| id | title                   | views  | likes  | duration | upload_date |
+----+-------------------------+--------+--------+----------+----------+
| 1  | Python Tutorial         | 125000 | 5200   | 1800     | 2024-01-15 |
| 2  | SQL Masterclass        | 89000  | 3800   | 3600     | 2024-02-20 |
| 3  | JavaScript Basics       | 234000 | 12400  | 2400     | 2024-03-10 |
| 4  | React Components        | 156000 | 8900   | 2700     | 2024-04-05 |
| 5  | Database Design         | 67000  | 2100   | 4200     | 2024-05-12 |
+----+-------------------------+--------+--------+----------+----------+
```

### Table 3: Streaming Music (music_streams)
**First action: `SELECT * FROM music_streams;`**

```
+----+------------------+--------------+----------+-------+----------+
| id | song_title       | artist       | streams  | year  | duration |
+----+------------------+--------------+----------+-------+----------+
| 1  | Blinding Lights  | The Weeknd   | 3200000  | 2020  | 200      |
| 2  | Shape of You     | Ed Sheeran   | 5400000  | 2017  | 233      |
| 3  | Bad Habits       | Ed Sheeran   | 2800000  | 2021  | 231      |
| 4  | Levitating       | Dua Lipa     | 4100000  | 2020  | 203      |
| 5  | Good 4 U        | Olivia       | 1900000  | 2021  | 178      |
+----+------------------+--------------+----------+-------+----------+
```

## Mathematical Expressions: The Foundation

### Basic Arithmetic Operations

**E-commerce Pricing Calculations**
```sql
-- Calculate discounts and savings (Amazon-style)
SELECT 
    name,
    price,
    sale_price,
    (price - sale_price) AS discount_amount,
    ROUND((price - sale_price) / price * 100, 2) AS discount_percentage
FROM shop_products
WHERE sale_price IS NOT NULL;

-- Calculate inventory value
SELECT 
    name,
    price,
    stock,
    (price * stock) AS inventory_value,
    CASE 
        WHEN stock < 20 THEN 'Low Stock'
        WHEN stock > 50 THEN 'Well Stocked'
        ELSE 'Normal'
    END AS stock_status
FROM shop_products;
```

**YouTube Performance Metrics**
```sql
-- Calculate engagement rates and content efficiency
SELECT 
    title,
    views,
    likes,
    duration,
    (likes * 100.0 / views) AS engagement_rate_percent,
    (views / (duration / 60.0)) AS views_per_minute,
    ROUND(duration / 60.0, 2) AS duration_minutes
FROM video_analytics;
```

**Music Streaming Analytics**
```sql
-- Calculate song performance and age metrics
SELECT 
    song_title,
    artist,
    streams,
    year,
    (2024 - year) AS age_years,
    (streams / (2024 - year + 1)) AS annual_stream_rate,
    ROUND(duration / 60.0, 2) AS duration_minutes
FROM music_streams;
```

### Advanced Mathematical Functions

**Statistical Analysis**
```sql
-- YouTube content analysis with advanced metrics
SELECT 
    title,
    views,
    likes,
    duration,
    -- Engagement metrics
    (likes * 1000.0 / views) AS likes_per_thousand_views,
    -- Performance scoring
    SQRT(views * likes) AS viral_score,
    -- Content efficiency  
    POWER(views / 1000.0, 0.5) AS reach_index
FROM video_analytics;
```

**Financial Calculations**
```sql
-- E-commerce profitability analysis
SELECT 
    name,
    price,
    sale_price,
    stock,
    -- Revenue calculations
    COALESCE(sale_price, price) AS effective_price,
    (COALESCE(sale_price, price) * stock) AS potential_revenue,
    -- Discount analysis
    CASE 
        WHEN sale_price IS NOT NULL 
        THEN ABS(price - sale_price) 
        ELSE 0 
    END AS discount_amount,
    -- Profit margin estimation (assuming 30% cost)
    (COALESCE(sale_price, price) * 0.7) AS estimated_profit
FROM shop_products;
```

## String Expressions: Text Transformation

### String Concatenation and Formatting

**Creating Display Names and Labels**
```sql
-- Product catalog with formatted display names
SELECT 
    name,
    price,
    sale_price,
    -- Format pricing display
    '$' || CAST(price AS TEXT) AS price_display,
    CASE 
        WHEN sale_price IS NOT NULL 
        THEN name || ' (ON SALE: $' || CAST(sale_price AS TEXT) || ')'
        ELSE name || ' - Regular Price'
    END AS product_display,
    -- Stock status messages
    'Stock: ' || CAST(stock AS TEXT) || ' units' AS stock_message
FROM shop_products;
```

**YouTube Content Categorization**
```sql
-- Video metadata and categorization
SELECT 
    title,
    views,
    -- Extract content type from title
    CASE 
        WHEN title LIKE '%Tutorial%' THEN 'Educational'
        WHEN title LIKE '%Masterclass%' THEN 'Professional'
        WHEN title LIKE '%Basics%' THEN 'Beginner'
        ELSE 'General'
    END AS content_category,
    -- Format view counts
    CASE 
        WHEN views >= 1000000 THEN CAST(views / 1000000 AS TEXT) || 'M views'
        WHEN views >= 1000 THEN CAST(views / 1000 AS TEXT) || 'K views'
        ELSE CAST(views AS TEXT) || ' views'
    END AS views_formatted
FROM video_analytics;
```

**Music Library Organization**
```sql
-- Spotify-style music metadata
SELECT 
    song_title,
    artist,
    year,
    streams,
    -- Create era classifications
    CASE 
        WHEN year >= 2020 THEN '2020s'
        WHEN year >= 2010 THEN '2010s'
        WHEN year >= 2000 THEN '2000s'
        ELSE 'Classic'
    END AS era,
    -- Artist and title display
    artist || ' - ' || song_title AS full_title,
    -- Popularity indicators
    CASE 
        WHEN streams > 3000000 THEN song_title || ' 🔥 (Hot Track)'
        WHEN streams > 1000000 THEN song_title || ' ⭐ (Popular)'
        ELSE song_title
    END AS display_title
FROM music_streams;
```

### Text Analysis and Extraction

**Content Analysis Functions**
```sql
-- Analyze YouTube video titles for SEO insights
SELECT 
    title,
    LENGTH(title) AS title_length,
    -- Count words in title
    LENGTH(title) - LENGTH(REPLACE(title, ' ', '')) + 1 AS word_count,
    -- Extract first word
    SUBSTRING(title, 1, POSITION(' ' IN title) - 1) AS first_word,
    -- Check for engagement keywords
    CASE 
        WHEN UPPER(title) LIKE '%HOW TO%' THEN 'How-To Content'
        WHEN UPPER(title) LIKE '%TUTORIAL%' THEN 'Tutorial Content'
        WHEN UPPER(title) LIKE '%COMPLETE%' THEN 'Comprehensive Guide'
        ELSE 'Standard Content'
    END AS content_type
FROM video_analytics;
```

## Date and Time Expressions

### Date Calculations and Analysis

**Content Age and Performance Analysis**
```sql
-- YouTube video performance over time
SELECT 
    title,
    upload_date,
    views,
    -- Calculate content age
    CURRENT_DATE - upload_date AS days_since_upload,
    -- Performance metrics by age
    views / (CURRENT_DATE - upload_date) AS daily_average_views,
    -- Categorize by upload recency
    CASE 
        WHEN upload_date >= CURRENT_DATE - INTERVAL '30 days' THEN 'Recent'
        WHEN upload_date >= CURRENT_DATE - INTERVAL '90 days' THEN 'Moderate'
        ELSE 'Older Content'
    END AS content_age_category
FROM video_analytics;
```

**Music Era Analysis**
```sql
-- Spotify streaming trends by music age
SELECT 
    song_title,
    artist,
    year,
    streams,
    -- Calculate song age and performance
    (2024 - year) AS song_age_years,
    streams / (2024 - year + 1) AS annual_stream_average,
    -- Categorize by decade
    CASE 
        WHEN year >= 2020 THEN '2020s Era'
        WHEN year >= 2010 THEN '2010s Era'  
        WHEN year >= 2000 THEN '2000s Era'
        ELSE 'Pre-2000s Classic'
    END AS music_era
FROM music_streams;
```

## Conditional Expressions: Smart Logic

### CASE Expressions for Business Logic

**E-commerce Product Categorization**
```sql
-- Amazon-style product analysis and recommendations
SELECT 
    name,
    price,
    sale_price,
    stock,
    -- Price tier analysis
    CASE 
        WHEN COALESCE(sale_price, price) >= 1000 THEN 'Premium'
        WHEN COALESCE(sale_price, price) >= 500 THEN 'Mid-Range'
        WHEN COALESCE(sale_price, price) >= 100 THEN 'Budget'
        ELSE 'Economy'
    END AS price_tier,
    -- Inventory management
    CASE 
        WHEN stock = 0 THEN 'Out of Stock'
        WHEN stock < 15 THEN 'Low Stock - Order Soon'
        WHEN stock < 30 THEN 'Moderate Stock'
        ELSE 'Well Stocked'
    END AS stock_status,
    -- Deal quality assessment
    CASE 
        WHEN sale_price IS NULL THEN 'Regular Price'
        WHEN (price - sale_price) / price > 0.2 THEN 'Great Deal (20%+ off)'
        WHEN (price - sale_price) / price > 0.1 THEN 'Good Deal (10%+ off)'
        ELSE 'Minor Discount'
    END AS deal_quality
FROM shop_products;
```

**YouTube Content Strategy Analysis**
```sql
-- Creator performance insights and recommendations
SELECT 
    title,
    views,
    likes,
    duration,
    -- Content performance rating
    CASE 
        WHEN views > 200000 AND likes > 10000 THEN 'Viral Success'
        WHEN views > 100000 AND likes > 5000 THEN 'Strong Performance'  
        WHEN views > 50000 THEN 'Moderate Success'
        ELSE 'Building Audience'
    END AS performance_rating,
    -- Optimal content length analysis
    CASE 
        WHEN duration BETWEEN 1800 AND 3600 THEN 'Optimal Length (30-60 min)'
        WHEN duration > 3600 THEN 'Long Form Content'
        WHEN duration < 1800 THEN 'Short Form Content'
    END AS content_length_category,
    -- Engagement quality score
    CASE 
        WHEN (likes * 100.0 / views) > 5 THEN 'Highly Engaging'
        WHEN (likes * 100.0 / views) > 3 THEN 'Well Received'
        WHEN (likes * 100.0 / views) > 1 THEN 'Average Engagement'
        ELSE 'Low Engagement'
    END AS engagement_quality
FROM video_analytics;
```

### Complex Conditional Logic

**Music Recommendation Engine Logic**
```sql
-- Spotify-style recommendation scoring
SELECT 
    song_title,
    artist,
    streams,
    year,
    duration,
    -- Multi-factor recommendation score
    CASE 
        -- Recent hits get bonus points
        WHEN year >= 2020 AND streams > 2000000 THEN 95
        -- Classic popular songs
        WHEN streams > 4000000 THEN 90
        -- Recent moderate hits
        WHEN year >= 2021 AND streams > 1000000 THEN 85
        -- Older but still popular
        WHEN streams > 2000000 THEN 80
        -- Newer songs building momentum  
        WHEN year >= 2020 THEN 75
        -- Everything else
        ELSE 70
    END AS recommendation_score,
    -- Duration preferences
    CASE 
        WHEN duration BETWEEN 180 AND 240 THEN 'Perfect Length'
        WHEN duration > 240 THEN 'Long Track'
        ELSE 'Short Track' 
    END AS duration_category,
    -- Artist popularity tier
    CASE 
        WHEN artist IN ('Ed Sheeran', 'The Weeknd') THEN 'Superstar'
        WHEN streams > 3000000 THEN 'Popular Artist'
        ELSE 'Rising Artist'
    END AS artist_tier
FROM music_streams;
```

## Aggregate Expressions in SELECT

### Window Functions and Analytics

**E-commerce Comparative Analysis**
```sql
-- Product performance vs portfolio averages
SELECT 
    name,
    price,
    stock,
    -- Current product metrics
    (price * stock) AS inventory_value,
    -- Comparative metrics
    price - AVG(price) OVER () AS price_vs_average,
    stock - AVG(stock) OVER () AS stock_vs_average,
    -- Ranking within portfolio
    ROW_NUMBER() OVER (ORDER BY price DESC) AS price_rank,
    ROW_NUMBER() OVER (ORDER BY stock DESC) AS stock_rank,
    -- Percentage of total inventory value
    ROUND(
        (price * stock) * 100.0 / SUM(price * stock) OVER (), 
        2
    ) AS percent_of_total_value
FROM shop_products;
```

**YouTube Channel Performance Analysis**
```sql
-- Video performance vs channel averages
SELECT 
    title,
    views,
    likes,
    -- Performance vs portfolio
    views - AVG(views) OVER () AS views_vs_channel_avg,
    (likes * 100.0 / views) AS engagement_rate,
    -- Ranking and percentiles
    RANK() OVER (ORDER BY views DESC) AS view_rank,
    RANK() OVER (ORDER BY likes DESC) AS like_rank,
    -- Running totals
    SUM(views) OVER (ORDER BY upload_date) AS cumulative_views
FROM video_analytics;
```

## Real-World Expression Patterns

### Business Intelligence Calculations

**E-commerce KPIs**
```sql
-- Comprehensive product analysis dashboard
SELECT 
    name,
    price,
    sale_price,
    stock,
    -- Revenue metrics
    COALESCE(sale_price, price) AS selling_price,
    (COALESCE(sale_price, price) * stock) AS max_revenue,
    -- Efficiency metrics
    CASE 
        WHEN sale_price IS NOT NULL 
        THEN ((price - sale_price) * stock)  -- Total discount impact
        ELSE 0 
    END AS total_discount_cost,
    -- Performance indicators
    CASE 
        WHEN stock < 20 THEN 'Reorder Alert'
        WHEN sale_price IS NOT NULL AND stock > 50 THEN 'Promotion Success'
        WHEN stock = 0 THEN 'Stockout Revenue Loss'
        ELSE 'Normal Operations'
    END AS business_alert
FROM shop_products;
```

**Content Creator Analytics**
```sql
-- YouTube creator dashboard metrics
SELECT 
    title,
    upload_date,
    views,
    likes,
    duration,
    -- Performance calculations
    (likes * 1000.0 / views) AS likes_per_thousand,
    (views / GREATEST(duration / 60.0, 1)) AS views_per_minute,
    -- Time-based analysis
    CASE 
        WHEN upload_date >= CURRENT_DATE - INTERVAL '7 days' THEN 'This Week'
        WHEN upload_date >= CURRENT_DATE - INTERVAL '30 days' THEN 'This Month'
        WHEN upload_date >= CURRENT_DATE - INTERVAL '90 days' THEN 'Last 3 Months'
        ELSE 'Older Content'
    END AS upload_period,
    -- Content strategy insights
    CASE 
        WHEN views > 150000 AND duration > 3000 THEN 'Long-Form Success'
        WHEN views > 100000 AND duration < 2000 THEN 'Short-Form Hit'
        WHEN likes * 100.0 / views > 4 THEN 'High Engagement'
        ELSE 'Standard Performance'
    END AS content_insight
FROM video_analytics;
```

### Marketing and Sales Expressions

**Customer Segmentation Logic**
```sql
-- E-commerce customer value segmentation
SELECT 
    name AS product_name,
    price,
    sale_price,
    stock,
    -- Customer targeting segments
    CASE 
        WHEN COALESCE(sale_price, price) > 1500 THEN 'Luxury Shoppers'
        WHEN sale_price IS NOT NULL AND COALESCE(sale_price, price) > 500 THEN 'Deal Seekers'
        WHEN COALESCE(sale_price, price) BETWEEN 200 AND 500 THEN 'Value Conscious'
        ELSE 'Budget Buyers'
    END AS target_segment,
    -- Inventory urgency for marketing
    CASE 
        WHEN stock < 10 THEN 'Create Urgency (Low Stock)'
        WHEN sale_price IS NOT NULL THEN 'Promote Deal'
        WHEN stock > 60 THEN 'Push Volume Sales'
        ELSE 'Standard Marketing'
    END AS marketing_strategy,
    -- Pricing psychology
    CASE 
        WHEN sale_price IS NOT NULL THEN 
            'Was $' || price || ' Now $' || sale_price || ' (Save $' || (price - sale_price) || ')'
        ELSE '$' || price
    END AS marketing_price_display
FROM shop_products;
```

SQL expressions transform raw data into business intelligence. Whether you're calculating Instagram engagement rates, optimizing YouTube content strategy, or maximizing Amazon sales performance, expressions turn numbers into insights that drive real business decisions! 📊🚀
    ''',
    "is_free": False,
    "xp_reward": 105,
    "exercises": [
        {
            "id": "ecommerce-pricing-expressions",
            "title": "E-commerce Pricing and Discount Calculations",
            "type": "practice",
            "instructions": """Practice mathematical expressions to analyze product pricing, discounts, and business metrics for an e-commerce platform.

Your tasks:
1. First explore the data with SELECT * FROM shop_products;
2. Calculate discount amounts and percentages for sale items
3. Calculate inventory values and categorize stock levels
4. Create formatted pricing displays for marketing
5. Analyze price tiers and deal quality
6. Generate business alerts based on stock and pricing

Table: shop_products
Columns: id, name, price, sale_price, stock""",
            "starter_code": """-- Task 1: Explore the product data
SELECT * FROM shop_products;

-- Task 2: Calculate discounts for items on sale
-- Show name, price, sale_price, discount amount, and discount percentage
-- Use (price - sale_price) for amount and (price - sale_price) / price * 100 for percentage


-- Task 3: Calculate inventory values and stock status
-- Show name, price, stock, total inventory value, and stock status category


-- Task 4: Create marketing-friendly pricing displays  
-- Format prices with $ symbols and create sale/regular price messages


-- Task 5: Analyze price tiers and deal quality
-- Categorize products as Premium/Mid-Range/Budget and rate deal quality


-- Task 6: Generate business alerts
-- Create alerts for low stock, out of stock, and promotion opportunities
""",
            "solution": """-- Task 1: Explore the product data
SELECT * FROM shop_products;

-- Task 2: Calculate discounts for items on sale
SELECT 
    name,
    price,
    sale_price,
    (price - sale_price) AS discount_amount,
    ROUND((price - sale_price) / price * 100, 2) AS discount_percentage
FROM shop_products
WHERE sale_price IS NOT NULL;

-- Task 3: Calculate inventory values and stock status
SELECT 
    name,
    price,
    stock,
    (price * stock) AS inventory_value,
    CASE 
        WHEN stock = 0 THEN 'Out of Stock'
        WHEN stock < 20 THEN 'Low Stock'
        WHEN stock > 60 THEN 'Well Stocked'
        ELSE 'Normal Stock'
    END AS stock_status
FROM shop_products;

-- Task 4: Create marketing-friendly pricing displays
SELECT 
    name,
    price,
    sale_price,
    '$' || CAST(price AS TEXT) AS price_display,
    CASE 
        WHEN sale_price IS NOT NULL 
        THEN name || ' - WAS $' || price || ' NOW $' || sale_price || ' (SAVE $' || (price - sale_price) || ')'
        ELSE name || ' - Regular Price $' || price
    END AS marketing_display
FROM shop_products;

-- Task 5: Analyze price tiers and deal quality  
SELECT 
    name,
    price,
    sale_price,
    CASE 
        WHEN COALESCE(sale_price, price) >= 1000 THEN 'Premium'
        WHEN COALESCE(sale_price, price) >= 500 THEN 'Mid-Range'
        ELSE 'Budget'
    END AS price_tier,
    CASE 
        WHEN sale_price IS NULL THEN 'Regular Price'
        WHEN (price - sale_price) / price > 0.15 THEN 'Great Deal (15%+ off)'
        WHEN (price - sale_price) / price > 0.05 THEN 'Good Deal (5%+ off)'
        ELSE 'Minor Discount'
    END AS deal_quality
FROM shop_products;

-- Task 6: Generate business alerts
SELECT 
    name,
    price,
    sale_price,
    stock,
    CASE 
        WHEN stock = 0 THEN 'URGENT: Out of Stock'
        WHEN stock < 15 THEN 'WARNING: Low Stock Alert'
        WHEN sale_price IS NOT NULL AND stock > 50 THEN 'SUCCESS: Promotion Running Well'
        WHEN stock > 80 THEN 'INFO: Consider Promotion'
        ELSE 'OK: Normal Operations'
    END AS business_alert
FROM shop_products;""",
            "test_cases": [
                {
                    "name": "Discount percentage calculation",
                    "input": "SELECT (price - sale_price) / price * 100 AS discount_pct FROM shop_products WHERE sale_price IS NOT NULL;",
                    "expected_contains": ["price", "sale_price", "/", "*", "100"]
                },
                {
                    "name": "CASE expression for categorization",
                    "input": "SELECT CASE WHEN stock < 20 THEN 'Low' ELSE 'Normal' END FROM shop_products;",
                    "expected_contains": ["CASE", "WHEN", "THEN", "ELSE", "END"]
                }
            ],
            "xp_reward": 70,
            "hints": [
                "Use (price - sale_price) to calculate discount amounts",
                "Multiply by 100.0 to get percentages, use ROUND() for clean results",
                "COALESCE(sale_price, price) gets the effective selling price",
                "String concatenation uses || operator in most SQL databases",
                "CASE expressions are perfect for categorizing numerical ranges"
            ]
        },
        {
            "id": "youtube-analytics-expressions",
            "title": "YouTube Performance Analytics with Calculations",
            "type": "practice",
            "instructions": """Use expressions to calculate YouTube video performance metrics, engagement rates, and content insights.

Your tasks:
1. Explore video analytics data
2. Calculate engagement rates and performance metrics
3. Analyze content duration and viewing efficiency
4. Categorize content by performance and type
5. Create formatted display metrics for reporting
6. Calculate content age and trending indicators

Table: video_analytics
Columns: id, title, views, likes, duration, upload_date""",
            "starter_code": """-- Task 1: Explore video analytics data
SELECT * FROM video_analytics;

-- Task 2: Calculate engagement rates and performance metrics
-- Show title, views, likes, engagement rate (likes/views * 100), and likes per thousand views


-- Task 3: Analyze content duration and viewing efficiency
-- Calculate duration in minutes, views per minute, and categorize by length


-- Task 4: Categorize content by performance level
-- Create performance categories based on views and engagement rates


-- Task 5: Create formatted metrics for reporting dashboard
-- Format view counts (K/M notation) and create performance summaries


-- Task 6: Calculate content age and identify trending patterns
-- Calculate days since upload and identify recent high-performers
""",
            "solution": """-- Task 1: Explore video analytics data
SELECT * FROM video_analytics;

-- Task 2: Calculate engagement rates and performance metrics
SELECT 
    title,
    views,
    likes,
    ROUND((likes * 100.0 / views), 3) AS engagement_rate_percent,
    ROUND((likes * 1000.0 / views), 2) AS likes_per_thousand_views
FROM video_analytics;

-- Task 3: Analyze content duration and viewing efficiency
SELECT 
    title,
    duration,
    views,
    ROUND(duration / 60.0, 2) AS duration_minutes,
    ROUND(views / (duration / 60.0), 0) AS views_per_minute,
    CASE 
        WHEN duration >= 3600 THEN 'Long Form (60+ min)'
        WHEN duration >= 1800 THEN 'Medium Form (30-60 min)'
        ELSE 'Short Form (<30 min)'
    END AS content_length_category
FROM video_analytics;

-- Task 4: Categorize content by performance level
SELECT 
    title,
    views,
    likes,
    CASE 
        WHEN views > 200000 AND likes > 8000 THEN 'Viral Hit'
        WHEN views > 100000 THEN 'Strong Performance'
        WHEN views > 50000 THEN 'Moderate Success'
        ELSE 'Building Audience'
    END AS performance_category,
    CASE 
        WHEN (likes * 100.0 / views) > 4 THEN 'Highly Engaging'
        WHEN (likes * 100.0 / views) > 2 THEN 'Good Engagement'
        ELSE 'Average Engagement'
    END AS engagement_level
FROM video_analytics;

-- Task 5: Create formatted metrics for reporting dashboard
SELECT 
    title,
    CASE 
        WHEN views >= 1000000 THEN ROUND(views / 1000000.0, 1) || 'M views'
        WHEN views >= 1000 THEN ROUND(views / 1000.0, 1) || 'K views'
        ELSE views || ' views'
    END AS views_formatted,
    likes || ' likes (' || ROUND((likes * 100.0 / views), 2) || '% rate)' AS engagement_summary,
    ROUND(duration / 60.0, 0) || ' min duration' AS duration_display
FROM video_analytics;

-- Task 6: Calculate content age and identify trending patterns
SELECT 
    title,
    upload_date,
    views,
    likes,
    (CURRENT_DATE - upload_date) AS days_since_upload,
    ROUND(views / (CURRENT_DATE - upload_date), 0) AS daily_average_views,
    CASE 
        WHEN upload_date >= CURRENT_DATE - INTERVAL '30 days' AND views > 100000 THEN 'Trending Recent'
        WHEN upload_date >= CURRENT_DATE - INTERVAL '7 days' THEN 'New Release'
        WHEN views / (CURRENT_DATE - upload_date) > 1000 THEN 'Steady Growth'
        ELSE 'Standard Performance'
    END AS trending_status
FROM video_analytics;""",
            "test_cases": [
                {
                    "name": "Engagement rate calculation",
                    "input": "SELECT (likes * 100.0 / views) AS engagement_rate FROM video_analytics;",
                    "expected_contains": ["likes", "*", "100.0", "/", "views"]
                },
                {
                    "name": "Duration conversion and categorization",
                    "input": "SELECT duration / 60.0 AS minutes, CASE WHEN duration > 3600 THEN 'Long' ELSE 'Short' END FROM video_analytics;",
                    "expected_contains": ["duration", "/", "60.0", "CASE", "3600"]
                }
            ],
            "xp_reward": 75,
            "hints": [
                "Multiply by 100.0 to get engagement as percentage",
                "Duration is in seconds, divide by 60 for minutes",
                "Use ROUND() to make decimal calculations readable",
                "Date arithmetic: CURRENT_DATE - upload_date gives days difference",
                "String concatenation with || creates formatted display text"
            ]
        }
    ]
}