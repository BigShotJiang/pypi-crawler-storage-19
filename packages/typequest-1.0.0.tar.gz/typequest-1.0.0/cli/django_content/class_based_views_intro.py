"""
Django Class-Based Views Introduction lesson content
"""

DJANGO_CBV_INTRO_LESSON = {
    "id": 9,
    "chapter": 9,
    "title": "Introduction to Class-Based Views",
    "slug": "class-based-views-intro", 
    "content": '''
# Introduction to Class-Based Views: Upgrading Your View Toolkit

Think of function-based views as a Swiss Army knife - versatile and straightforward. Class-based views are like upgrading to a professional toolkit where each tool is specialized for specific jobs, inherits features from other tools, and can be easily customized for your exact needs.

## What Are Class-Based Views? From Functions to Objects

You've been writing function-based views (FBVs) - simple Python functions that take a request and return a response. Class-based views (CBVs) are Python classes that do the same job, but with superpowers:

**Function-Based View (The Old Way):**
```python
def book_list(request):
    books = Book.objects.all()
    return render(request, 'books/list.html', {'books': books})

def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'books/detail.html', {'book': book})
```

**Class-Based View (The New Way):**
```python
from django.views.generic import ListView, DetailView

class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'

class BookDetailView(DetailView):
    model = Book
    template_name = 'books/detail.html'
```

## Why Choose Class-Based Views? The Power of Object-Oriented Programming

### 1. **Less Code, More Power**
CBVs handle common patterns automatically. Instead of writing 20 lines for a list view, you write 3 lines and Django handles pagination, filtering, and error handling.

**Real-world analogy:** Instead of building a car from scratch every time, you inherit from a "Car" class and just customize the color, engine, and features you need.

### 2. **Reusability Through Inheritance**
```python
class BaseBookView:
    model = Book
    context_object_name = 'book'

class BookListView(BaseBookView, ListView):
    template_name = 'books/list.html'
    
class BookDetailView(BaseBookView, DetailView):
    template_name = 'books/detail.html'
```

### 3. **Built-in HTTP Method Handling**
CBVs automatically handle different HTTP methods (GET, POST, PUT, DELETE) with separate methods:

```python
class BookView(View):
    def get(self, request, *args, **kwargs):
        # Handle GET requests
        pass
    
    def post(self, request, *args, **kwargs):
        # Handle POST requests
        pass
```

**Restaurant analogy:** Instead of one chef handling all orders, you have specialized chefs - one for appetizers (GET), one for main courses (POST), one for desserts (PUT).

## The Class-Based View Hierarchy: A Family Tree of Functionality

Django's CBVs are organized like a family tree, where each child inherits abilities from its parents:

```
View (Base Class)
├── TemplateView (Displays templates)
├── RedirectView (Handles redirects)
└── GenericView
    ├── ListView (Shows lists of objects)
    ├── DetailView (Shows single object details)
    ├── CreateView (Creates new objects)
    ├── UpdateView (Edits existing objects)
    └── DeleteView (Deletes objects)
```

**Family analogy:** Think of `View` as the grandparent who teaches basic life skills. `ListView` is like a child who inherited those skills and specialized in organizing birthday party guest lists.

## Basic Class-Based View Structure

Every CBV follows a predictable pattern:

```python
from django.views.generic import TemplateView

class HomeView(TemplateView):
    template_name = 'home.html'
    
    def get_context_data(self, **kwargs):
        # Add extra context data
        context = super().get_context_data(**kwargs)
        context['welcome_message'] = 'Welcome to our site!'
        return context
```

### Key Components Explained:

- **Class Name**: Should end with "View" (e.g., `BookListView`)
- **Inheritance**: Inherits from appropriate Django view class
- **Attributes**: Configure behavior (template_name, model, etc.)
- **Methods**: Override to customize behavior

## Your First Class-Based View: Step by Step

Let's convert a simple function-based view to a class-based view:

**Step 1: Function-Based View**
```python
def about_view(request):
    context = {
        'team_size': 50,
        'founded_year': 2020
    }
    return render(request, 'about.html', context)
```

**Step 2: Class-Based View**
```python
from django.views.generic import TemplateView

class AboutView(TemplateView):
    template_name = 'about.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'team_size': 50,
            'founded_year': 2020
        })
        return context
```

**Step 3: URL Configuration**
```python
# urls.py
from django.urls import path
from .views import AboutView

urlpatterns = [
    path('about/', AboutView.as_view(), name='about'),
]
```

## CBV Method Flow: Understanding the Magic

When a request hits a CBV, Django follows a specific sequence (like a recipe):

```
1. dispatch() → Determines which HTTP method to use
2. get() or post() → Handles the specific HTTP method
3. get_context_data() → Gathers data for the template
4. render_to_response() → Creates the HTTP response
```

**Cooking analogy:** It's like a restaurant kitchen workflow:
1. Host seats customer (dispatch)
2. Waiter takes order (get/post)  
3. Chef prepares ingredients (get_context_data)
4. Waiter serves the dish (render_to_response)

## Common CBV Patterns You'll Use Daily

### Pattern 1: Simple Template Display
```python
class ContactView(TemplateView):
    template_name = 'contact.html'
```

### Pattern 2: Display List of Objects
```python
class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    context_object_name = 'books'
    paginate_by = 10
```

### Pattern 3: Show Object Details
```python
class BookDetailView(DetailView):
    model = Book
    template_name = 'books/detail.html'
    context_object_name = 'book'
```

### Pattern 4: Custom Context Data
```python
class DashboardView(TemplateView):
    template_name = 'dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_users'] = User.objects.count()
        context['recent_orders'] = Order.objects.filter(
            created_at__gte=timezone.now() - timedelta(days=7)
        )
        return context
```

## CBVs vs FBVs: Choosing the Right Tool

**Use Class-Based Views When:**
- ✅ You need CRUD operations (Create, Read, Update, Delete)
- ✅ You want to reuse code across multiple views
- ✅ You're building standard web application patterns
- ✅ You need built-in features (pagination, permissions, etc.)

**Use Function-Based Views When:**
- ✅ You have simple, unique logic
- ✅ The view does something very specific
- ✅ You're building APIs or non-standard responses
- ✅ You prefer explicit control over every detail

## Debugging CBVs: Common Beginner Challenges

### Challenge 1: "Where's my method?"
**Problem:** Overriding wrong method name
```python
# ❌ Wrong
class BookListView(ListView):
    def get_context(self, **kwargs):  # Wrong method name
        pass

# ✅ Correct  
class BookListView(ListView):
    def get_context_data(self, **kwargs):  # Correct method name
        pass
```

### Challenge 2: "Forgetting super()"
**Problem:** Not calling parent method
```python
# ❌ Incomplete
def get_context_data(self, **kwargs):
    context = {}  # Missing parent context
    context['extra'] = 'data'
    return context

# ✅ Complete
def get_context_data(self, **kwargs):
    context = super().get_context_data(**kwargs)  # Get parent context
    context['extra'] = 'data'
    return context
```

## Best Practices for CBV Success

1. **Start Simple:** Begin with built-in generic views before creating custom ones
2. **Follow Naming Conventions:** End class names with "View"
3. **Use Descriptive Names:** `BookListView` not `BookView1`
4. **Override Carefully:** Only override methods you need to customize
5. **Read the Docs:** Each generic view has specific attributes and methods

## Practice Exercise: Build Your First CBV

Create a simple blog application using class-based views:

```python
# models.py
class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

# views.py
class PostListView(ListView):
    model = Post
    template_name = 'blog/post_list.html'
    context_object_name = 'posts'
    ordering = ['-created_at']

class PostDetailView(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'
    context_object_name = 'post'

# urls.py
urlpatterns = [
    path('', PostListView.as_view(), name='post-list'),
    path('post/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
]
```

## What's Next?

Now that you understand CBV basics, you're ready to explore:
- Generic display views (ListView, DetailView)
- Generic editing views (CreateView, UpdateView, DeleteView)
- Mixins for shared functionality
- Custom view classes for specific needs

Class-based views are your gateway to writing less code while building more powerful, maintainable Django applications!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/intro/
    ''',
    "is_free": True,
    "xp_reward": 60,
    "exercises": [
        {
            "id": "cbv-conversion",
            "title": "Convert Function to Class-Based View",
            "type": "project",
            "instructions": """Convert the following function-based views to class-based views:

1. A simple about page view
2. A product list view with pagination
3. A contact form view with success message

Your solution should demonstrate:
- Proper CBV inheritance
- Context data customization
- URL configuration with .as_view()
- Template naming conventions""",
            "starter_code": """# Function-based views to convert:

def about_view(request):
    context = {
        'company': 'TechCorp',
        'founded': 2020,
        'team_size': 50
    }
    return render(request, 'about.html', context)

def product_list_view(request):
    products = Product.objects.all()
    paginator = Paginator(products, 10)
    page = request.GET.get('page')
    products = paginator.get_page(page)
    return render(request, 'products/list.html', {'products': products})

def contact_view(request):
    if request.method == 'POST':
        # Handle form submission
        messages.success(request, 'Message sent successfully!')
        return redirect('contact')
    return render(request, 'contact.html')""",
            "solution": """from django.views.generic import TemplateView, ListView
from django.contrib import messages
from django.shortcuts import redirect

class AboutView(TemplateView):
    template_name = 'about.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'company': 'TechCorp',
            'founded': 2020,
            'team_size': 50
        })
        return context

class ProductListView(ListView):
    model = Product
    template_name = 'products/list.html'
    context_object_name = 'products'
    paginate_by = 10

class ContactView(TemplateView):
    template_name = 'contact.html'
    
    def post(self, request, *args, **kwargs):
        # Handle form submission
        messages.success(request, 'Message sent successfully!')
        return redirect('contact')

# urls.py
urlpatterns = [
    path('about/', AboutView.as_view(), name='about'),
    path('products/', ProductListView.as_view(), name='product-list'),
    path('contact/', ContactView.as_view(), name='contact'),
]""",
            "test_cases": [
                {
                    "name": "CBV properly inherits from base classes",
                    "input": "",
                    "expected_contains": ["TemplateView", "ListView", "as_view()"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "Use TemplateView for simple template rendering",
                "ListView automatically handles pagination with paginate_by",
                "Override get_context_data() to add custom context",
                "Use .as_view() in URLs to convert class to view function"
            ]
        }
    ]
}