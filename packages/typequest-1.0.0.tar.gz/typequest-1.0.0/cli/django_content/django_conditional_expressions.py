"""
Django Advanced - Lesson 2: Conditional Expressions (Case/When)
Master Django's conditional logic for sophisticated database queries
"""

DJANGO_CONDITIONAL_EXPRESSIONS_LESSON = {
    "id": 52,
    "chapter": 52,
    "title": "Django Conditional Expressions: Case/When Logic",
    "slug": "django-conditional-expressions",
    "description": "Master Case/When expressions for complex conditional logic in Django queries",
    "content": '''# Django Conditional Expressions: Case/When Logic

## 🎯 Understanding Conditional Expressions

Django's **Conditional Expressions** bring **if-elif-else logic** directly to your database queries. They enable sophisticated business rules and data transformations without pulling data into Python.

**Key Components**:
- **When()** → Encapsulates a condition and its result
- **Case()** → Evaluates conditions in order, like if-elif-else
- **Q objects** → Complex boolean conditions
- **Field lookups** → Database-level comparisons

Think of Case/When as **business logic in the database** - powerful, efficient, and scalable.

## 💾 Customer Management Platform Database

Let's work with a comprehensive CRM system to demonstrate conditional expressions:

```sql
-- Customer profiles with comprehensive data
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(254) UNIQUE NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    total_spent DECIMAL(10, 2) DEFAULT 0.00,
    order_count INTEGER DEFAULT 0,
    support_tickets INTEGER DEFAULT 0,
    lifetime_value DECIMAL(10, 2) DEFAULT 0.00,
    referral_count INTEGER DEFAULT 0,
    age INTEGER,
    location VARCHAR(100),
    subscription_tier VARCHAR(20) DEFAULT 'basic',
    is_active BOOLEAN DEFAULT TRUE,
    risk_score INTEGER DEFAULT 0,
    communication_preference VARCHAR(20) DEFAULT 'email'
);

-- Sample customer data for conditional expressions
INSERT INTO customers (email, first_name, last_name, registration_date, last_login, total_spent, order_count, support_tickets, referral_count, age, location, subscription_tier, risk_score) VALUES
('alice.johnson@email.com', 'Alice', 'Johnson', '2023-01-15', '2024-12-20 10:30:00', 2850.00, 12, 2, 3, 34, 'New York', 'premium', 15),
('bob.smith@email.com', 'Bob', 'Smith', '2023-03-22', '2024-12-25 14:22:00', 5670.00, 28, 1, 8, 28, 'California', 'enterprise', 5),
('carol.davis@email.com', 'Carol', 'Davis', '2023-06-10', '2024-12-18 09:15:00', 890.00, 4, 0, 1, 45, 'Texas', 'basic', 25),
('david.wilson@email.com', 'David', 'Wilson', '2022-09-05', '2024-12-22 16:45:00', 12450.00, 45, 3, 15, 52, 'Florida', 'enterprise', 10),
('eva.garcia@email.com', 'Eva', 'Garcia', '2024-02-14', '2024-12-15 11:30:00', 325.00, 2, 5, 0, 29, 'Arizona', 'basic', 45),
('frank.brown@email.com', 'Frank', 'Brown', '2023-11-20', '2024-12-24 13:20:00', 4200.00, 18, 0, 5, 38, 'Washington', 'premium', 8),
('grace.lee@email.com', 'Grace', 'Lee', '2024-01-08', '2024-11-30 08:45:00', 150.00, 1, 8, 0, 31, 'Oregon', 'basic', 65),
('henry.taylor@email.com', 'Henry', 'Taylor', '2022-12-12', '2024-12-23 15:10:00', 7800.00, 32, 1, 12, 41, 'Nevada', 'enterprise', 12);

-- Order history for customer analysis
CREATE TABLE customer_orders (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    order_value DECIMAL(10, 2) NOT NULL,
    order_status VARCHAR(20) DEFAULT 'completed',
    payment_method VARCHAR(20),
    shipping_cost DECIMAL(5, 2) DEFAULT 0.00,
    discount_applied DECIMAL(5, 2) DEFAULT 0.00,
    product_category VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Sample orders for conditional analysis
INSERT INTO customer_orders (customer_id, order_date, order_value, payment_method, product_category, discount_applied) VALUES
(1, '2024-12-01', 299.99, 'credit_card', 'electronics', 30.00),
(1, '2024-12-15', 189.99, 'credit_card', 'books', 0.00),
(2, '2024-12-10', 899.99, 'paypal', 'computers', 90.00),
(2, '2024-12-20', 450.00, 'credit_card', 'electronics', 45.00),
(3, '2024-12-05', 125.50, 'credit_card', 'books', 0.00),
(3, '2024-12-18', 89.99, 'paypal', 'home', 9.00),
(4, '2024-12-12', 1200.00, 'bank_transfer', 'computers', 120.00),
(4, '2024-12-22', 800.00, 'credit_card', 'electronics', 80.00);

-- Support interactions for customer service analysis
CREATE TABLE support_interactions (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    interaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    interaction_type VARCHAR(30) NOT NULL,
    priority_level VARCHAR(20) DEFAULT 'medium',
    resolution_time_hours INTEGER,
    satisfaction_score INTEGER CHECK (satisfaction_score >= 1 AND satisfaction_score <= 5),
    issue_category VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Sample support data
INSERT INTO support_interactions (customer_id, interaction_type, priority_level, resolution_time_hours, satisfaction_score, issue_category) VALUES
(1, 'chat', 'low', 2, 5, 'product_inquiry'),
(1, 'email', 'medium', 24, 4, 'billing'),
(3, 'phone', 'high', 1, 3, 'technical_issue'),
(5, 'chat', 'high', 4, 2, 'account_access'),
(5, 'email', 'medium', 48, 1, 'refund_request'),
(7, 'chat', 'high', 6, 2, 'technical_issue'),
(7, 'phone', 'high', 3, 3, 'billing');

-- Marketing campaigns for segmentation
CREATE TABLE campaign_responses (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    campaign_name VARCHAR(100) NOT NULL,
    response_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    response_type VARCHAR(20), -- 'click', 'purchase', 'unsubscribe', 'ignore'
    revenue_generated DECIMAL(10, 2) DEFAULT 0.00,
    channel VARCHAR(30), -- 'email', 'sms', 'push', 'social'
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Sample campaign data
INSERT INTO campaign_responses (customer_id, campaign_name, response_type, revenue_generated, channel) VALUES
(1, 'Holiday Sale 2024', 'purchase', 299.99, 'email'),
(2, 'Black Friday Deals', 'purchase', 899.99, 'push'),
(3, 'Summer Collection', 'click', 0.00, 'email'),
(4, 'Premium Upgrade', 'purchase', 1200.00, 'sms'),
(5, 'Welcome Series', 'unsubscribe', 0.00, 'email'),
(6, 'Holiday Sale 2024', 'purchase', 450.00, 'social'),
(7, 'Customer Survey', 'ignore', 0.00, 'email'),
(8, 'Black Friday Deals', 'purchase', 800.00, 'email');
```

## 🔧 Case/When Fundamentals

### 1. Basic Customer Segmentation

**Scenario**: Shopify's customer tier classification

```python
from django.db.models import Case, When, Value, CharField

class CustomerSegmentation:
    @staticmethod
    def classify_customers():
        """Classify customers into segments based on spending"""
        
        return Customer.objects.annotate(
            customer_tier=Case(
                When(total_spent__gte=5000, then=Value('VIP')),
                When(total_spent__gte=2000, then=Value('Premium')),
                When(total_spent__gte=500, then=Value('Regular')),
                default=Value('New'),
                output_field=CharField(max_length=20)
            ),
            
            engagement_level=Case(
                When(order_count__gte=20, then=Value('High')),
                When(order_count__gte=5, then=Value('Medium')),
                default=Value('Low'),
                output_field=CharField(max_length=10)
            ),
            
            risk_category=Case(
                When(risk_score__gte=50, then=Value('High Risk')),
                When(risk_score__gte=25, then=Value('Medium Risk')),
                default=Value('Low Risk'),
                output_field=CharField(max_length=15)
            )
        ).order_by('-total_spent')

    @staticmethod
    def get_marketing_segments():
        """Create targeted marketing segments"""
        
        return Customer.objects.annotate(
            marketing_segment=Case(
                # High-value, low-engagement: Win-back campaign
                When(
                    total_spent__gte=2000,
                    order_count__lte=3,
                    then=Value('Win-back')
                ),
                # High engagement, growing spend: Upsell
                When(
                    order_count__gte=10,
                    total_spent__gte=1000,
                    then=Value('Upsell')
                ),
                # New customers with potential: Nurture
                When(
                    registration_date__gte=timezone.now() - timedelta(days=30),
                    total_spent__gte=100,
                    then=Value('Nurture')
                ),
                # At-risk customers: Retention
                When(
                    risk_score__gte=40,
                    then=Value('Retention')
                ),
                default=Value('General'),
                output_field=CharField(max_length=15)
            )
        )
```

### 2. Complex Conditional Logic

**Scenario**: Netflix's content recommendation scoring

```python
def calculate_customer_scores():
    """Calculate multiple customer scores with complex conditions"""
    
    return Customer.objects.annotate(
        # Loyalty score based on multiple factors
        loyalty_score=Case(
            When(
                registration_date__lt=timezone.now() - timedelta(days=365),
                order_count__gte=10,
                support_tickets__lte=2,
                then=Value(100)
            ),
            When(
                order_count__gte=5,
                support_tickets__lte=1,
                then=Value(75)
            ),
            When(
                order_count__gte=2,
                then=Value(50)
            ),
            default=Value(25),
            output_field=IntegerField()
        ),
        
        # Customer lifetime value prediction
        predicted_clv=Case(
            When(
                customer_tier='VIP',
                engagement_level='High',
                then=F('total_spent') * 2.5
            ),
            When(
                customer_tier='Premium',
                engagement_level__in=['High', 'Medium'],
                then=F('total_spent') * 1.8
            ),
            When(
                order_count__gte=3,
                then=F('total_spent') * 1.3
            ),
            default=F('total_spent') * 1.1,
            output_field=DecimalField(max_digits=10, decimal_places=2)
        ),
        
        # Communication preference optimization
        preferred_channel=Case(
            When(age__gte=50, then=Value('email')),
            When(age__lte=25, then=Value('sms')),
            When(
                location__in=['California', 'New York'],
                then=Value('push')
            ),
            default=Value('email'),
            output_field=CharField(max_length=20)
        ),
        
        # Priority level for customer service
        service_priority=Case(
            When(
                customer_tier='VIP',
                support_tickets__gte=3,
                then=Value('Urgent')
            ),
            When(
                total_spent__gte=2000,
                risk_score__gte=30,
                then=Value('High')
            ),
            When(
                support_tickets__gte=2,
                then=Value('Medium')
            ),
            default=Value('Standard'),
            output_field=CharField(max_length=10)
        )
    )
```

### 3. Q Objects in Conditional Expressions

**Scenario**: Amazon's fraud detection system

```python
from django.db.models import Q

def advanced_customer_analysis():
    """Advanced analysis using Q objects in conditions"""
    
    return Customer.objects.annotate(
        # Fraud risk assessment
        fraud_risk=Case(
            When(
                Q(risk_score__gte=60) | 
                Q(support_tickets__gte=10) |
                Q(total_spent__gt=10000, order_count__lte=3),
                then=Value('High')
            ),
            When(
                Q(risk_score__gte=30) & Q(support_tickets__gte=3),
                then=Value('Medium')
            ),
            default=Value('Low'),
            output_field=CharField(max_length=10)
        ),
        
        # Account status determination
        account_status=Case(
            When(
                Q(is_active=False) | Q(risk_score__gte=80),
                then=Value('Suspended')
            ),
            When(
                Q(last_login__lt=timezone.now() - timedelta(days=90)) &
                Q(total_spent__lt=100),
                then=Value('Dormant')
            ),
            When(
                Q(order_count__gte=5) & Q(support_tickets__lte=2),
                then=Value('Excellent')
            ),
            When(
                Q(total_spent__gte=500),
                then=Value('Active')
            ),
            default=Value('Standard'),
            output_field=CharField(max_length=15)
        ),
        
        # Personalization segment
        personalization_segment=Case(
            When(
                Q(age__gte=18, age__lte=25) & Q(location__in=['California', 'New York']),
                then=Value('Tech Millennials')
            ),
            When(
                Q(age__gte=35, age__lte=55) & Q(total_spent__gte=2000),
                then=Value('Affluent Professionals')
            ),
            When(
                Q(age__gte=55) & Q(subscription_tier='premium'),
                then=Value('Premium Seniors')
            ),
            When(
                Q(referral_count__gte=5),
                then=Value('Brand Advocates')
            ),
            default=Value('General'),
            output_field=CharField(max_length=25)
        )
    )
```

## 📊 Advanced Conditional Patterns

### 4. Time-Based Conditional Logic

**Scenario**: Spotify's subscription renewal predictions

```python
def time_based_customer_insights():
    """Analyze customer behavior based on time patterns"""
    
    current_time = timezone.now()
    
    return Customer.objects.annotate(
        # Customer lifecycle stage
        lifecycle_stage=Case(
            When(
                registration_date__gte=current_time - timedelta(days=30),
                then=Value('New')
            ),
            When(
                registration_date__gte=current_time - timedelta(days=90),
                order_count__gte=2,
                then=Value('Growing')
            ),
            When(
                registration_date__lt=current_time - timedelta(days=365),
                order_count__gte=10,
                then=Value('Loyal')
            ),
            When(
                last_login__lt=current_time - timedelta(days=60),
                then=Value('At Risk')
            ),
            default=Value('Active'),
            output_field=CharField(max_length=15)
        ),
        
        # Seasonal behavior pattern
        seasonal_pattern=Case(
            When(
                registration_date__month__in=[11, 12, 1],  # Winter
                total_spent__gte=1000,
                then=Value('Holiday Shopper')
            ),
            When(
                registration_date__month__in=[6, 7, 8],  # Summer
                order_count__gte=5,
                then=Value('Summer Active')
            ),
            When(
                registration_date__month__in=[9, 10],  # Back to school
                then=Value('Fall Starter')
            ),
            default=Value('Year Round'),
            output_field=CharField(max_length=20)
        ),
        
        # Reactivation potential
        reactivation_potential=Case(
            When(
                last_login__lt=current_time - timedelta(days=30),
                total_spent__gte=500,
                support_tickets__lte=2,
                then=Value('High')
            ),
            When(
                last_login__lt=current_time - timedelta(days=14),
                order_count__gte=3,
                then=Value('Medium')
            ),
            When(
                last_login__lt=current_time - timedelta(days=7),
                then=Value('Low')
            ),
            default=Value('Active'),
            output_field=CharField(max_length=10)
        )
    )
```

### 5. Numerical Range Conditions

**Scenario**: Uber's driver rating system

```python
def numerical_customer_analysis():
    """Analyze customers based on numerical ranges and thresholds"""
    
    return Customer.objects.annotate(
        # Spending behavior classification
        spending_behavior=Case(
            When(total_spent__lt=100, then=Value('Conservative')),
            When(total_spent__lt=500, then=Value('Cautious')),
            When(total_spent__lt=1500, then=Value('Regular')),
            When(total_spent__lt=5000, then=Value('Generous')),
            default=Value('Big Spender'),
            output_field=CharField(max_length=15)
        ),
        
        # Order frequency pattern
        order_frequency=Case(
            When(
                order_count__gte=20,
                registration_date__lt=timezone.now() - timedelta(days=180),
                then=Value('Frequent')
            ),
            When(
                order_count__gte=10,
                registration_date__lt=timezone.now() - timedelta(days=365),
                then=Value('Regular')
            ),
            When(
                order_count__gte=5,
                then=Value('Occasional')
            ),
            default=Value('Rare'),
            output_field=CharField(max_length=15)
        ),
        
        # Age-based targeting
        age_segment=Case(
            When(age__lte=18, then=Value('Gen Z')),
            When(age__lte=28, then=Value('Young Millennial')),
            When(age__lte=38, then=Value('Older Millennial')),
            When(age__lte=50, then=Value('Gen X')),
            When(age__lte=65, then=Value('Young Boomer')),
            default=Value('Senior'),
            output_field=CharField(max_length=20)
        ),
        
        # Support interaction analysis
        support_profile=Case(
            When(support_tickets__gte=5, then=Value('High Touch')),
            When(support_tickets__gte=3, then=Value('Needs Attention')),
            When(support_tickets__eq=1, then=Value('Minimal Contact')),
            default=Value('Self Service'),
            output_field=CharField(max_length=20)
        )
    )
```

## 🏢 Real-World Production Examples

### Stripe's Payment Risk Assessment

```python
def stripe_risk_assessment():
    """Stripe-style payment risk assessment using conditional expressions"""
    
    return Customer.objects.annotate(
        # Payment risk score
        payment_risk=Case(
            When(
                Q(risk_score__gte=70) | 
                Q(support_tickets__gte=8),
                then=Value('Reject')
            ),
            When(
                Q(risk_score__gte=40) & 
                Q(total_spent__lt=500),
                then=Value('Manual Review')
            ),
            When(
                Q(total_spent__gte=2000) & 
                Q(order_count__gte=5) &
                Q(risk_score__lt=20),
                then=Value('Auto Approve')
            ),
            default=Value('Standard Review'),
            output_field=CharField(max_length=20)
        ),
        
        # Transaction limits
        daily_limit=Case(
            When(
                customer_tier='VIP',
                risk_score__lt=15,
                then=Value(50000)
            ),
            When(
                customer_tier='Premium',
                risk_score__lt=25,
                then=Value(10000)
            ),
            When(
                total_spent__gte=1000,
                risk_score__lt=40,
                then=Value(2500)
            ),
            default=Value(500),
            output_field=IntegerField()
        ),
        
        # Fraud monitoring level
        monitoring_level=Case(
            When(
                Q(risk_score__gte=50) |
                Q(registration_date__gte=timezone.now() - timedelta(days=7)),
                then=Value('Enhanced')
            ),
            When(
                risk_score__gte=25,
                then=Value('Standard')
            ),
            default=Value('Light'),
            output_field=CharField(max_length=15)
        )
    )
```

### Airbnb's Host Performance Classification

```python
def airbnb_host_classification():
    """Airbnb-style host performance evaluation"""
    
    return Customer.objects.annotate(
        # Host status (treating customers as hosts)
        host_status=Case(
            When(
                total_spent__gte=5000,  # Revenue generated
                support_tickets__lte=1,  # Few issues
                referral_count__gte=10,  # Good reviews proxy
                then=Value('Superhost')
            ),
            When(
                total_spent__gte=2000,
                support_tickets__lte=3,
                referral_count__gte=3,
                then=Value('Great Host')
            ),
            When(
                order_count__gte=5,
                support_tickets__lte=5,
                then=Value('Good Host')
            ),
            default=Value('New Host'),
            output_field=CharField(max_length=15)
        ),
        
        # Booking priority
        booking_priority=Case(
            When(host_status='Superhost', then=Value(100)),
            When(host_status='Great Host', then=Value(80)),
            When(host_status='Good Host', then=Value(60)),
            default=Value(40),
            output_field=IntegerField()
        ),
        
        # Support response time
        support_sla=Case(
            When(
                host_status='Superhost',
                then=Value('1 hour')
            ),
            When(
                total_spent__gte=1000,
                then=Value('4 hours')
            ),
            default=Value('24 hours'),
            output_field=CharField(max_length=10)
        )
    )
```

### Discord's Community Management

```python
def discord_community_management():
    """Discord-style community member classification"""
    
    return Customer.objects.annotate(
        # Member role assignment
        community_role=Case(
            When(
                referral_count__gte=20,
                support_tickets__lte=1,
                registration_date__lt=timezone.now() - timedelta(days=365),
                then=Value('Community Leader')
            ),
            When(
                referral_count__gte=10,
                order_count__gte=15,
                then=Value('Active Contributor')
            ),
            When(
                order_count__gte=5,
                registration_date__lt=timezone.now() - timedelta(days=180),
                then=Value('Regular Member')
            ),
            When(
                registration_date__gte=timezone.now() - timedelta(days=30),
                then=Value('New Member')
            ),
            default=Value('Casual Member'),
            output_field=CharField(max_length=20)
        ),
        
        # Moderation level needed
        moderation_attention=Case(
            When(
                risk_score__gte=60,
                then=Value('High')
            ),
            When(
                support_tickets__gte=5,
                risk_score__gte=30,
                then=Value('Medium')
            ),
            default=Value('Low'),
            output_field=CharField(max_length=10)
        ),
        
        # Privileges level
        privilege_level=Case(
            When(community_role='Community Leader', then=Value('Full')),
            When(community_role='Active Contributor', then=Value('Enhanced')),
            When(risk_score__gte=40, then=Value('Restricted')),
            default=Value('Standard'),
            output_field=CharField(max_length=15)
        )
    )
```

## ⚡ Performance and Best Practices

### 1. Efficient Conditional Updates

```python
def efficient_bulk_customer_updates():
    """Perform bulk updates using conditional expressions"""
    
    # Update all customers' tiers in one query
    Customer.objects.update(
        subscription_tier=Case(
            When(total_spent__gte=5000, then=Value('enterprise')),
            When(total_spent__gte=2000, then=Value('premium')),
            default=Value('basic'),
            output_field=CharField(max_length=20)
        ),
        
        # Update communication preferences based on age
        communication_preference=Case(
            When(age__lte=25, then=Value('sms')),
            When(age__gte=55, then=Value('email')),
            default=Value('push'),
            output_field=CharField(max_length=20)
        )
    )
```

### 2. Conditional Aggregations

```python
def conditional_aggregation_example():
    """Use conditional expressions in aggregations"""
    
    return Customer.objects.aggregate(
        # Count customers by tier
        vip_customers=Count(
            Case(When(total_spent__gte=5000, then=1))
        ),
        premium_customers=Count(
            Case(When(total_spent__gte=2000, total_spent__lt=5000, then=1))
        ),
        regular_customers=Count(
            Case(When(total_spent__lt=2000, then=1))
        ),
        
        # Revenue by customer tier
        vip_revenue=Sum(
            Case(
                When(total_spent__gte=5000, then='total_spent'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        ),
        
        # Average order value by age group
        young_customer_avg=Avg(
            Case(
                When(age__lte=30, then='total_spent'),
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        )
    )
```

## 🎯 Key Takeaways

1. **Case/When brings if-elif-else logic to the database** → Complex business rules in queries
2. **Q objects enable sophisticated boolean conditions** → Multiple criteria combinations  
3. **Conditional expressions work with F expressions** → Field-based conditional logic
4. **Use output_field for type consistency** → Ensures proper data types
5. **Combine with aggregations for powerful analytics** → Conditional counting and summing
6. **Bulk updates with conditionals are highly efficient** → Update thousands of records in one query

Case/When expressions are essential for implementing complex business logic directly in the database, making your Django applications more efficient and scalable!
''',
    "difficulty": "intermediate",
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-expressions"],
    "exercises": [
        {
            "id": "conditional_1",
            "title": "Explore Customer Data for Segmentation",
            "prompt": "Let's examine our customer data to understand the fields we'll use for conditional expressions. Write a query to see customer profiles with spending and engagement metrics.",
            "table_name": "customers",
            "initial_query": "SELECT * FROM customers LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "customers"],
            "hint": "Use SELECT * FROM customers LIMIT 5; to see the customer data structure",
            "solution": "SELECT * FROM customers LIMIT 5;",
            "explanation": "This shows our customer table with fields like total_spent, order_count, risk_score, age, etc. Case/When expressions will use these fields to create sophisticated customer segmentation logic."
        },
        {
            "id": "conditional_2",
            "title": "Basic Customer Tier Classification", 
            "prompt": "Practice conditional logic by creating customer tiers. Write a query to classify customers as 'VIP' (>=$5000), 'Premium' (>=$2000), 'Regular' (>=$500), or 'New' (<$500) based on total_spent.",
            "table_name": "customers",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "total_spent", "5000", "2000", "500"],
            "hint": "Use CASE WHEN total_spent >= 5000 THEN 'VIP' WHEN... pattern",
            "solution": "SELECT first_name, last_name, total_spent, CASE WHEN total_spent >= 5000 THEN 'VIP' WHEN total_spent >= 2000 THEN 'Premium' WHEN total_spent >= 500 THEN 'Regular' ELSE 'New' END as customer_tier FROM customers ORDER BY total_spent DESC;",
            "explanation": "This conditional logic mirrors Django's Case(When(total_spent__gte=5000, then=Value('VIP')), When(total_spent__gte=2000, then=Value('Premium')), ...). Case/When expressions enable complex business rule classification."
        },
        {
            "id": "conditional_3",
            "title": "Risk Assessment with Multiple Conditions",
            "prompt": "Create a risk assessment using multiple criteria. Write a query to classify customers as 'High Risk' (risk_score >= 50 OR support_tickets >= 5), 'Medium Risk' (risk_score >= 25), or 'Low Risk'.",
            "table_name": "customers",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "risk_score", "support_tickets", "OR", "AND"],
            "hint": "Use CASE WHEN (risk_score >= 50 OR support_tickets >= 5) for complex conditions",
            "solution": "SELECT first_name, last_name, risk_score, support_tickets, CASE WHEN (risk_score >= 50 OR support_tickets >= 5) THEN 'High Risk' WHEN risk_score >= 25 THEN 'Medium Risk' ELSE 'Low Risk' END as risk_category FROM customers ORDER BY risk_score DESC;",
            "explanation": "This demonstrates Q objects in Django: Case(When(Q(risk_score__gte=50) | Q(support_tickets__gte=5), then=Value('High Risk'))). Complex boolean conditions enable sophisticated business logic."
        },
        {
            "id": "conditional_4",
            "title": "Age-Based Marketing Segmentation",
            "prompt": "Create age-based segments for marketing. Write a query to segment customers: 'Gen Z' (<=25), 'Millennial' (26-40), 'Gen X' (41-55), 'Boomer' (>55), handling NULL ages as 'Unknown'.",
            "table_name": "customers",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "age", "25", "40", "55", "NULL"],
            "hint": "Use CASE WHEN age IS NULL for handling missing values, then age ranges",
            "solution": "SELECT first_name, last_name, age, CASE WHEN age IS NULL THEN 'Unknown' WHEN age <= 25 THEN 'Gen Z' WHEN age <= 40 THEN 'Millennial' WHEN age <= 55 THEN 'Gen X' ELSE 'Boomer' END as age_segment FROM customers ORDER BY age ASC;",
            "explanation": "This shows how Case/When handles NULL values and creates demographic segments. The age-based classification helps with targeted marketing campaigns and personalized experiences."
        },
        {
            "id": "conditional_5",
            "title": "Customer Lifecycle Stage Analysis",
            "prompt": "Determine customer lifecycle stages based on registration date and activity. Classify as 'New' (registered in last 30 days), 'Growing' (30-90 days with orders), 'Established' (>90 days), considering order_count > 0 for active customers.",
            "table_name": "customers",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "registration_date", "order_count", "CURRENT_DATE", "INTERVAL"],
            "hint": "Use CURRENT_DATE - INTERVAL '30 days' for date comparisons and include order_count conditions",
            "solution": "SELECT first_name, last_name, registration_date, order_count, CASE WHEN registration_date >= CURRENT_DATE - INTERVAL '30 days' THEN 'New' WHEN registration_date >= CURRENT_DATE - INTERVAL '90 days' AND order_count > 0 THEN 'Growing' WHEN order_count > 0 THEN 'Established' ELSE 'Inactive' END as lifecycle_stage FROM customers ORDER BY registration_date DESC;",
            "explanation": "Time-based conditional logic is crucial for customer lifecycle management. This pattern helps identify customer journey stages and triggers appropriate engagement strategies."
        },
        {
            "id": "conditional_6",
            "title": "Support Priority Assignment",
            "prompt": "Assign support priorities based on customer value and tier. Write a query for priority: 'Urgent' (VIP customers with support tickets), 'High' (Premium+ with >2 tickets), 'Medium' (>$1000 spent), 'Standard' (others).",
            "table_name": "customers",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "total_spent", "support_tickets", "subscription_tier"],
            "hint": "Combine subscription_tier and support_tickets conditions with spending thresholds",
            "solution": "SELECT first_name, last_name, total_spent, subscription_tier, support_tickets, CASE WHEN subscription_tier = 'enterprise' AND support_tickets > 0 THEN 'Urgent' WHEN subscription_tier IN ('premium', 'enterprise') AND support_tickets > 2 THEN 'High' WHEN total_spent > 1000 THEN 'Medium' ELSE 'Standard' END as support_priority FROM customers ORDER BY CASE WHEN subscription_tier = 'enterprise' AND support_tickets > 0 THEN 1 WHEN subscription_tier IN ('premium', 'enterprise') AND support_tickets > 2 THEN 2 WHEN total_spent > 1000 THEN 3 ELSE 4 END;",
            "explanation": "This multi-criteria prioritization demonstrates complex business rules in action. Support priority based on customer value and current issues ensures high-value customers get appropriate attention levels."
        }
    ],
    "key_concepts": [
        "Case/When Conditional Logic",
        "Q Objects for Complex Conditions",
        "Customer Segmentation Patterns",
        "Multi-Criteria Classification",
        "Time-Based Conditional Logic",
        "Numerical Range Conditions",
        "Boolean Expression Combinations",
        "Conditional Aggregation Techniques"
    ]
}