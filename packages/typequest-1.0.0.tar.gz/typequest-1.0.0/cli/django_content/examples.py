"""
Examples of how to use the Django Lesson Management System
"""

from .lesson_manager import DjangoLessonManager, django_lessons
from .lesson_registry import get_available_orders, add_lesson_order

def example_basic_usage():
    """Basic usage examples"""
    
    print("=== Basic Usage Examples ===")
    
    # Get lessons in default order
    lessons = django_lessons.get_all_lessons()
    print(f"Default order: {[l['title'] for l in lessons]}")
    
    # Get lessons for beginners
    beginner_lessons = django_lessons.get_beginner_track()
    print(f"Beginner track: {[l['title'] for l in beginner_lessons]}")
    
    # Get a specific lesson
    intro_lesson = django_lessons.get_lesson('cbv_intro')
    print(f"Intro lesson: {intro_lesson['title']}")
    
    # Get free lessons only
    free_lessons = django_lessons.get_free_lessons()
    print(f"Free lessons: {[l['title'] for l in free_lessons]}")

def example_custom_ordering():
    """Custom ordering examples"""
    
    print("\n=== Custom Ordering Examples ===")
    
    # Create a custom order for API-focused learning
    api_focused_order = [
        'cbv_intro',
        'async_views',
        'generic_editing',
        'mixins',
        'subclassing_views',
        'generic_display',
        'urlconf_usage'
    ]
    
    # Register the custom order
    django_lessons.create_custom_track('api_focused', api_focused_order)
    
    # Get lessons in custom order
    api_lessons = django_lessons.get_all_lessons('api_focused')
    print(f"API-focused track: {[l['title'] for l in api_lessons]}")
    
    # Available ordering configurations
    available_orders = get_available_orders()
    print(f"Available orders: {available_orders}")

def example_difficulty_based():
    """Difficulty-based ordering examples"""
    
    print("\n=== Difficulty-Based Examples ===")
    
    # Easy to hard progression
    easy_to_hard = django_lessons.get_difficulty_track(ascending=True)
    print(f"Easy to hard: {[l['title'] for l in easy_to_hard]}")
    
    # Hard to easy (for experienced developers)
    hard_to_easy = django_lessons.get_difficulty_track(ascending=False)
    print(f"Hard to easy: {[l['title'] for l in hard_to_easy]}")
    
    # Prerequisites-based order
    prereq_order = django_lessons.get_prerequisite_track()
    print(f"Prerequisite order: {[l['title'] for l in prereq_order]}")

def example_filtering():
    """Filtering examples"""
    
    print("\n=== Filtering Examples ===")
    
    # Get high-XP lessons
    high_xp_lessons = django_lessons.get_lessons_by_xp_range(min_xp=80)
    print(f"High XP lessons (80+): {[f\"{l['title']} ({l['xp_reward']} XP)\" for l in high_xp_lessons]}")
    
    # Get premium lessons
    premium_lessons = django_lessons.get_premium_lessons()
    print(f"Premium lessons: {[l['title'] for l in premium_lessons]}")

def example_learning_paths():
    """Learning path examples"""
    
    print("\n=== Learning Path Examples ===")
    
    # Beginner developer path
    beginner_path = django_lessons.get_learning_path_for_goal('beginner')
    print(f"Beginner path: {[l['title'] for l in beginner_path]}")
    
    # CRUD-focused path
    crud_path = django_lessons.get_learning_path_for_goal('crud_focus')
    print(f"CRUD-focused path: {[l['title'] for l in crud_path]}")
    
    # Performance-focused path
    performance_path = django_lessons.get_learning_path_for_goal('performance')
    print(f"Performance path: {[l['title'] for l in performance_path]}")

def example_navigation():
    """Navigation examples"""
    
    print("\n=== Navigation Examples ===")
    
    # Get next lesson
    next_lesson = django_lessons.get_next_lesson('cbv_intro')
    if next_lesson:
        print(f"After intro: {next_lesson['title']}")
    
    # Get previous lesson
    prev_lesson = django_lessons.get_previous_lesson('mixins')
    if prev_lesson:
        print(f"Before mixins: {prev_lesson['title']}")

def example_progress_tracking():
    """Progress tracking examples"""
    
    print("\n=== Progress Tracking Examples ===")
    
    # Get lesson summaries
    summaries = django_lessons.get_lesson_summaries()
    print("Lesson summaries:")
    for summary in summaries:
        print(f"  - {summary['title']} ({summary['xp_reward']} XP, {summary['exercise_count']} exercises)")
    
    # Get progress info
    progress = django_lessons.get_lesson_progress_info()
    print(f"\nTotal progress info:")
    print(f"  - {progress['total_lessons']} lessons")
    print(f"  - {progress['total_xp']} total XP")
    print(f"  - {progress['total_exercises']} exercises")
    print(f"  - {progress['free_lesson_count']} free lessons")

def example_multiple_managers():
    """Multiple manager instances"""
    
    print("\n=== Multiple Manager Instances ===")
    
    # Create manager for advanced students (starting at chapter 10)
    advanced_manager = DjangoLessonManager(default_order='advanced_first', start_chapter=10)
    
    # Create manager for beginners (starting at chapter 1)
    beginner_manager = DjangoLessonManager(default_order='beginner_friendly', start_chapter=1)
    
    advanced_lessons = advanced_manager.get_all_lessons()
    beginner_lessons = beginner_manager.get_all_lessons()
    
    print(f"Advanced track chapters: {[l['chapter'] for l in advanced_lessons]}")
    print(f"Beginner track chapters: {[l['chapter'] for l in beginner_lessons]}")

def run_all_examples():
    """Run all examples"""
    example_basic_usage()
    example_custom_ordering()
    example_difficulty_based()
    example_filtering()
    example_learning_paths()
    example_navigation()
    example_progress_tracking()
    example_multiple_manager_instances()

if __name__ == "__main__":
    run_all_examples()