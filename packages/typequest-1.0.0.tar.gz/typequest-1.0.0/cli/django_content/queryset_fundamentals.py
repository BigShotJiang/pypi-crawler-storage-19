"""
Django QuerySet Fundamentals lesson content
"""

DJANGO_QUERYSET_FUNDAMENTALS_LESSON = {
    "id": 17,
    "chapter": 17,
    "title": "Django QuerySet Fundamentals",
    "slug": "queryset-fundamentals",
    "content": '''
# Django QuerySets: Your Database Conversation Partner

Think of Django QuerySets as your intelligent assistant who speaks fluent SQL but lets you communicate in Python. Just as Netflix's recommendation engine queries millions of viewing records to find "Users who watched this also watched...", Django QuerySets let you ask sophisticated questions about your data using simple, readable Python code.

## Understanding QuerySets: The Lazy Genius Concept

**Real-world analogy:** A QuerySet is like a smart search on YouTube. When you type "Django tutorial" in the search box, YouTube doesn't immediately load every single video. It waits until you hit Enter (evaluation), then efficiently fetches exactly what you need. QuerySets work the same way - they're **lazy** and only hit the database when you actually need the results.

### QuerySet Characteristics
```python
# This doesn't hit the database yet!
videos = Video.objects.filter(category='tutorial')
popular_videos = videos.filter(views__gt=10000)
recent_videos = popular_videos.filter(created_at__gte=last_week)

# Only NOW does it query the database
for video in recent_videos[:10]:  # Get top 10
    print(video.title)
```

**What makes QuerySets special:**
- **Lazy evaluation**: No database query until you actually use the data
- **Chainable**: Stack filters like building blocks
- **Cacheable**: Results stored in memory after first access
- **Sliceable**: Use Python slice notation for pagination

## Basic QuerySet Operations: The CRUD Foundation

### Creating Objects: Adding New Data
```python
# Method 1: Create and save manually (like posting a new Instagram photo)
post = Post(
    author=user,
    image='vacation.jpg',
    caption="Amazing sunset in Santorini! 🌅",
    location="Santorini, Greece"
)
post.save()

# Method 2: Create and save in one step (convenience method)
post = Post.objects.create(
    author=user,
    image='beach.jpg',
    caption="Perfect beach day!",
    location="Malibu, CA"
)

# Method 3: Bulk creation for efficiency (like importing YouTube playlists)
Post.objects.bulk_create([
    Post(author=user1, caption="Morning coffee", location="NYC"),
    Post(author=user2, caption="Workout done!", location="LA"),
    Post(author=user3, caption="New recipe", location="Chicago"),
])
```

### Retrieving All Objects: The Complete Collection
```python
# Get all posts (like scrolling through entire Instagram feed)
all_posts = Post.objects.all()

# Get all users (like Slack's member directory)
all_users = User.objects.all()

# Chain with other operations
public_posts = Post.objects.all().filter(is_public=True)
```

### Basic Filtering: Finding What You Need
```python
# Simple filtering (like Netflix "Action Movies")
action_movies = Movie.objects.filter(genre='action')

# Multiple conditions (like Spotify "Rock songs from 2020")
recent_rock = Song.objects.filter(
    genre='rock',
    release_year=2020
)

# Field lookups (like Amazon "Products under $50")
affordable_products = Product.objects.filter(price__lt=50.00)

# Text searching (like Twitter searching for tweets)
django_tweets = Tweet.objects.filter(content__icontains='django')
```

## Advanced Filtering: Precision Querying

### Excluding Results: What You DON'T Want
```python
# Exclude archived posts (like hiding deleted emails)
active_posts = Post.objects.exclude(is_archived=True)

# Multiple exclusions (like dating app filters)
potential_matches = User.objects.exclude(
    age__lt=25
).exclude(
    location__icontains='Antarctica'
)

# Combining filter and exclude (like job search)
suitable_jobs = Job.objects.filter(
    salary__gte=80000,
    location='Remote'
).exclude(
    company_name__in=['Facebook', 'Meta']  # Personal preference
)
```

### Complex Conditions with Q Objects: Advanced Logic
```python
from django.db.models import Q

# OR conditions (like "Show me posts from friends OR trending")
feed_posts = Post.objects.filter(
    Q(author__in=user.friends.all()) | Q(is_trending=True)
)

# Complex combinations (like Airbnb search filters)
available_places = Listing.objects.filter(
    Q(city='San Francisco') | Q(city='Oakland'),
    Q(price__lte=200),
    Q(available_from__lte=checkin_date) & Q(available_to__gte=checkout_date)
)

# NOT operations (like "Everything except...")
non_spam_emails = Email.objects.filter(
    ~Q(subject__icontains='lottery') & ~Q(sender__endswith='spam.com')
)
```

## Field Lookups: The Power Tools

### Exact and Case-Insensitive Matching
```python
# Exact match (like login validation)
user = User.objects.get(username='john_doe')

# Case-insensitive (like email lookup)
user = User.objects.get(email__iexact='JOHN@EXAMPLE.COM')

# Multiple exact values (like checking user roles)
admins = User.objects.filter(role__in=['admin', 'superuser', 'moderator'])
```

### Text Pattern Matching
```python
# Contains (like YouTube video search)
python_videos = Video.objects.filter(title__icontains='python')

# Starts with (like autocomplete suggestions)
users_starting_j = User.objects.filter(first_name__istartswith='j')

# Ends with (like file extension filtering)
image_files = File.objects.filter(filename__endswith='.jpg')

# Regular expressions (like validating phone numbers)
us_phones = Contact.objects.filter(phone__regex=r'^\\+1-\\d{3}-\\d{3}-\\d{4}$')
```

### Numeric and Date Comparisons
```python
# Numeric comparisons (like product filtering)
expensive_items = Product.objects.filter(price__gt=1000)
budget_friendly = Product.objects.filter(price__lte=50)
mid_range = Product.objects.filter(price__range=(50, 200))

# Date filtering (like Instagram "Stories from today")
from datetime import date, timedelta

today = date.today()
recent_posts = Post.objects.filter(created_at__date=today)
this_week = Post.objects.filter(created_at__gte=today - timedelta(days=7))
this_year = Post.objects.filter(created_at__year=2024)

# Time-specific queries (like business hours)
morning_orders = Order.objects.filter(created_at__time__lt='12:00')
```

### Null and Boolean Checks
```python
# Check for missing data (like incomplete profiles)
incomplete_profiles = Profile.objects.filter(bio__isnull=True)
completed_profiles = Profile.objects.filter(bio__isnull=False)

# Boolean fields (like feature flags)
active_features = Feature.objects.filter(is_enabled=True)
beta_features = Feature.objects.filter(is_beta=True)
```

## Relationship Queries: Following the Connections

### Forward Relationships (ForeignKey)
```python
# Get posts by specific author (like visiting someone's profile)
john_posts = Post.objects.filter(author__username='john_doe')

# Deep relationship traversal (like "Books by authors from California")
california_books = Book.objects.filter(author__profile__state='CA')

# Multiple relationship conditions
verified_author_posts = Post.objects.filter(
    author__profile__is_verified=True,
    author__profile__follower_count__gte=1000
)
```

### Reverse Relationships
```python
# Authors who have written books (like "Users who have posted")
active_authors = Author.objects.filter(books__isnull=False).distinct()

# Users with many followers (like influencer discovery)
influencers = User.objects.filter(followers__count__gte=10000)

# Complex reverse queries
prolific_authors = Author.objects.filter(
    books__publication_year__gte=2020
).annotate(
    book_count=Count('books')
).filter(
    book_count__gte=3
)
```

## QuerySet Chaining: Building Complex Queries

### Progressive Filtering
```python
# Start broad, get specific (like shopping funnel)
products = Product.objects.all()
electronics = products.filter(category='electronics')
phones = electronics.filter(subcategory='smartphone')
iphones = phones.filter(brand='Apple')
recent_iphones = iphones.filter(release_date__year=2024)

# One-liner equivalent
recent_iphones = Product.objects.filter(
    category='electronics',
    subcategory='smartphone',
    brand='Apple',
    release_date__year=2024
)
```

### Ordering and Limiting
```python
# Order by single field (like "Most Recent Posts")
latest_posts = Post.objects.order_by('-created_at')

# Multiple ordering (like "Top Rated, Then Most Recent")
top_products = Product.objects.order_by('-rating', '-created_at')

# Limiting results (like pagination)
first_page = Post.objects.order_by('-created_at')[:10]
second_page = Post.objects.order_by('-created_at')[10:20]

# Random ordering (like "Discover New Content")
random_posts = Post.objects.order_by('?')[:5]
```

## Real-World QuerySet Example: Building a Social Media Feed

```python
from django.db.models import Q, Count, Case, When, IntegerField
from datetime import datetime, timedelta

def get_personalized_feed(user, page=1, per_page=20):
    """
    Create a personalized social media feed like Instagram's algorithm
    Combines multiple ranking factors and content sources
    """
    
    # Calculate pagination offset
    offset = (page - 1) * per_page
    
    # Get posts from multiple sources
    feed_posts = Post.objects.filter(
        # Content from friends
        Q(author__in=user.following.all()) |
        # Trending content
        Q(is_trending=True) |
        # Posts with many likes from last week
        Q(
            created_at__gte=datetime.now() - timedelta(days=7),
            likes_count__gte=100
        ) |
        # Posts with hashtags user follows
        Q(hashtags__in=user.followed_hashtags.all())
    ).exclude(
        # Hide blocked users' content
        author__in=user.blocked_users.all()
    ).exclude(
        # Hide user's own posts
        author=user
    ).exclude(
        # Hide archived posts
        is_archived=True
    ).annotate(
        # Calculate engagement score for ranking
        engagement_score=Case(
            When(author__in=user.following.all(), then=100),  # Friend bonus
            When(is_trending=True, then=50),  # Trending bonus
            default=0,
            output_field=IntegerField()
        ) + F('likes_count') + F('comments_count')
    ).distinct().order_by(
        '-engagement_score',  # Higher engagement first
        '-created_at'         # Then by recency
    )[offset:offset + per_page]
    
    return feed_posts

# Usage examples
my_feed = get_personalized_feed(current_user, page=1)
for post in my_feed:
    print(f"{post.author.username}: {post.caption[:100]}...")
```

## Performance Tips: QuerySet Best Practices

### Avoiding N+1 Queries
```python
# ❌ Bad: This will hit database for each post's author
posts = Post.objects.all()
for post in posts:
    print(post.author.username)  # Database query for each author

# ✅ Good: Fetch authors in one query
posts = Post.objects.select_related('author')
for post in posts:
    print(post.author.username)  # No additional queries
```

### Using only() and defer()
```python
# Only fetch specific fields (like loading thumbnails)
post_titles = Post.objects.only('title', 'created_at')

# Defer large fields (like content bodies)
post_previews = Post.objects.defer('content_body')
```

### Counting Efficiently
```python
# ❌ Expensive: Loads all objects into memory
post_count = len(Post.objects.all())

# ✅ Efficient: Database-level count
post_count = Post.objects.count()

# ✅ Check existence without counting
has_posts = Post.objects.exists()
```

QuerySets are the bridge between your Python application and your database. Master them, and you'll build applications that are both powerful and performant - from simple blogs to complex platforms like Instagram, YouTube, or Netflix! 🚀

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/db/queries/
    ''',
    "is_free": False,
    "xp_reward": 110,
    "exercises": [
        {
            "id": "social-feed-queries",
            "title": "Build a Social Media Feed with QuerySets",
            "type": "project",
            "instructions": """Create a social media feed system with advanced QuerySet operations:

1. Implement a personalized feed algorithm that combines multiple content sources
2. Use Q objects for complex filtering logic
3. Implement efficient relationship queries to avoid N+1 problems
4. Add pagination and ordering for optimal user experience
5. Create search functionality with text lookups

Your solution should demonstrate:
- Complex QuerySet chaining and filtering
- Performance optimization with select_related/prefetch_related
- Advanced field lookups and Q object usage
- Proper pagination and ordering
- Real-world social media features like trending content""",
            "starter_code": """from django.db import models
from django.contrib.auth.models import User
from django.db.models import Q, Count, F, Case, When, IntegerField
from datetime import datetime, timedelta

# Assume these models exist (from previous lessons)
class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(max_length=2200)
    image = models.ImageField(upload_to='posts/', blank=True)
    hashtags = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    is_trending = models.BooleanField(default=False)
    is_archived = models.BooleanField(default=False)

class Follow(models.Model):
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followers')

# Your task: Implement these functions using advanced QuerySets

def get_personalized_feed(user, page=1, per_page=20):
    \"\"\"
    Create a personalized feed combining:
    - Posts from users they follow
    - Trending posts
    - Popular posts from the last week
    - Posts matching their interests
    \"\"\"
    # Implement your QuerySet logic here
    pass

def search_posts(query, user, search_type='all'):
    \"\"\"
    Search posts by content, hashtags, or author
    search_type: 'content', 'hashtags', 'author', or 'all'
    \"\"\"
    # Implement search functionality
    pass

def get_trending_posts(hours=24, min_engagement=50):
    \"\"\"
    Get posts that are trending in the last N hours
    with minimum engagement threshold
    \"\"\"
    # Implement trending algorithm
    pass

def get_user_analytics(user):
    \"\"\"
    Get analytics for a user including:
    - Total posts
    - Average likes per post
    - Most popular post
    - Posting frequency
    \"\"\"
    # Implement analytics queries
    pass

# Test your implementation
# user = User.objects.get(username='testuser')
# feed = get_personalized_feed(user, page=1)
# search_results = search_posts('django', user)""",
            "solution": """from django.db import models
from django.contrib.auth.models import User
from django.db.models import Q, Count, F, Case, When, IntegerField, Avg, Max
from datetime import datetime, timedelta

def get_personalized_feed(user, page=1, per_page=20):
    \"\"\"
    Create a personalized feed combining multiple content sources
    \"\"\"
    offset = (page - 1) * per_page
    
    # Get users the current user follows
    following_users = user.following.values_list('following', flat=True)
    
    # Build complex feed query
    feed_posts = Post.objects.filter(
        # Content sources
        Q(author__in=following_users) |  # Friends' posts
        Q(is_trending=True) |  # Trending content
        Q(  # Popular recent posts
            created_at__gte=datetime.now() - timedelta(days=7),
            likes_count__gte=50
        )
    ).exclude(
        author=user  # Exclude user's own posts
    ).exclude(
        is_archived=True  # Exclude archived content
    ).select_related(
        'author'  # Optimize author access
    ).annotate(
        # Calculate engagement score for ranking
        engagement_score=Case(
            When(author__in=following_users, then=100),  # Friend bonus
            When(is_trending=True, then=75),  # Trending bonus
            When(created_at__gte=datetime.now() - timedelta(hours=6), then=25),  # Recency bonus
            default=0,
            output_field=IntegerField()
        ) + F('likes_count') + (F('comments_count') * 2)  # Comments worth more
    ).distinct().order_by(
        '-engagement_score',
        '-created_at'
    )[offset:offset + per_page]
    
    return feed_posts

def search_posts(query, user, search_type='all'):
    \"\"\"
    Search posts by content, hashtags, or author with privacy respect
    \"\"\"
    base_query = Post.objects.filter(
        is_archived=False
    ).select_related('author')
    
    # Apply search filters based on type
    if search_type == 'content':
        search_filter = Q(content__icontains=query)
    elif search_type == 'hashtags':
        # Handle hashtag search (assume hashtags stored as comma-separated)
        search_filter = Q(hashtags__icontains=query)
    elif search_type == 'author':
        search_filter = Q(
            Q(author__username__icontains=query) |
            Q(author__first_name__icontains=query) |
            Q(author__last_name__icontains=query)
        )
    else:  # search_type == 'all'
        search_filter = Q(
            Q(content__icontains=query) |
            Q(hashtags__icontains=query) |
            Q(author__username__icontains=query) |
            Q(author__first_name__icontains=query) |
            Q(author__last_name__icontains=query)
        )
    
    # Apply privacy filters
    privacy_filter = Q(
        # Public posts
        author__profile__is_private=False
    ) | Q(
        # Private posts from users they follow
        author__in=user.following.values_list('following', flat=True)
    ) | Q(
        # User's own posts
        author=user
    )
    
    results = base_query.filter(
        search_filter & privacy_filter
    ).annotate(
        # Rank by relevance and engagement
        relevance_score=Case(
            # Exact username match gets highest score
            When(author__username__iexact=query, then=1000),
            # Content match gets medium score
            When(content__icontains=query, then=500),
            # Hashtag match gets good score
            When(hashtags__icontains=query, then=300),
            default=0,
            output_field=IntegerField()
        ) + F('likes_count') + F('comments_count')
    ).order_by('-relevance_score', '-created_at')
    
    return results

def get_trending_posts(hours=24, min_engagement=50):
    \"\"\"
    Get posts that are trending based on recent engagement
    \"\"\"
    cutoff_time = datetime.now() - timedelta(hours=hours)
    
    trending_posts = Post.objects.filter(
        created_at__gte=cutoff_time,
        is_archived=False
    ).annotate(
        # Calculate engagement rate (engagement per hour)
        hours_since_post=Case(
            When(created_at__lte=cutoff_time, then=hours),
            default=(
                (datetime.now() - F('created_at')).total_seconds() / 3600
            ),
            output_field=IntegerField()
        ),
        total_engagement=F('likes_count') + F('comments_count'),
        engagement_rate=Case(
            When(hours_since_post__gt=0, 
                 then=F('total_engagement') / F('hours_since_post')),
            default=F('total_engagement'),
            output_field=IntegerField()
        )
    ).filter(
        total_engagement__gte=min_engagement
    ).order_by('-engagement_rate', '-total_engagement')
    
    return trending_posts

def get_user_analytics(user):
    \"\"\"
    Get comprehensive analytics for a user's posting activity
    \"\"\"
    user_posts = user.posts.filter(is_archived=False)
    
    analytics = {
        'total_posts': user_posts.count(),
        'total_likes': user_posts.aggregate(
            total=models.Sum('likes_count')
        )['total'] or 0,
        'total_comments': user_posts.aggregate(
            total=models.Sum('comments_count')
        )['total'] or 0,
        'average_likes': user_posts.aggregate(
            avg=Avg('likes_count')
        )['avg'] or 0,
        'average_comments': user_posts.aggregate(
            avg=Avg('comments_count')
        )['avg'] or 0,
    }
    
    # Get most popular post
    most_popular = user_posts.annotate(
        total_engagement=F('likes_count') + F('comments_count')
    ).order_by('-total_engagement').first()
    
    analytics['most_popular_post'] = most_popular
    
    # Calculate posting frequency (posts per day since first post)
    first_post = user_posts.order_by('created_at').first()
    if first_post:
        days_active = (datetime.now().date() - first_post.created_at.date()).days
        if days_active > 0:
            analytics['posts_per_day'] = analytics['total_posts'] / days_active
        else:
            analytics['posts_per_day'] = analytics['total_posts']
    else:
        analytics['posts_per_day'] = 0
    
    # Recent activity (last 30 days)
    recent_cutoff = datetime.now() - timedelta(days=30)
    recent_posts = user_posts.filter(created_at__gte=recent_cutoff)
    analytics['recent_posts_count'] = recent_posts.count()
    analytics['recent_activity_score'] = recent_posts.aggregate(
        score=models.Sum('likes_count') + models.Sum('comments_count')
    )['score'] or 0
    
    return analytics

def get_posts_by_engagement_level(min_likes=0, max_likes=None, 
                                 min_comments=0, max_comments=None):
    \"\"\"
    Filter posts by engagement levels - useful for content analysis
    \"\"\"
    filters = Q(likes_count__gte=min_likes, comments_count__gte=min_comments)
    
    if max_likes is not None:
        filters &= Q(likes_count__lte=max_likes)
    if max_comments is not None:
        filters &= Q(comments_count__lte=max_comments)
    
    return Post.objects.filter(filters).select_related('author')

def get_posts_with_hashtags(hashtags_list):
    \"\"\"
    Get posts containing any of the specified hashtags
    \"\"\"
    hashtag_filter = Q()
    for hashtag in hashtags_list:
        hashtag_filter |= Q(hashtags__icontains=hashtag)
    
    return Post.objects.filter(
        hashtag_filter,
        is_archived=False
    ).distinct().order_by('-created_at')

# Advanced usage examples
def demonstrate_advanced_queries():
    \"\"\"Examples of complex QuerySet operations\"\"\"
    
    # Find users who are mutual followers
    mutual_followers = User.objects.filter(
        following__following__followers__follower=F('id')
    ).distinct()
    
    # Posts from users with high engagement rates
    engaging_authors = User.objects.annotate(
        avg_engagement=Avg(
            F('posts__likes_count') + F('posts__comments_count')
        )
    ).filter(avg_engagement__gte=100)
    
    high_quality_posts = Post.objects.filter(
        author__in=engaging_authors,
        is_archived=False
    ).order_by('-created_at')
    
    # Posts that mention specific users (simplified)
    def get_posts_mentioning_user(mentioned_user):
        return Post.objects.filter(
            content__icontains=f'@{mentioned_user.username}'
        ).select_related('author')
    
    return {
        'mutual_followers': mutual_followers,
        'high_quality_posts': high_quality_posts,
    }""",
            "test_cases": [
                {
                    "name": "Functions handle QuerySet operations correctly",
                    "input": "",
                    "expected_contains": ["filter", "Q", "annotate", "select_related", "order_by"]
                }
            ],
            "xp_reward": 150,
            "hints": [
                "Use Q objects for complex OR/AND logic combinations",
                "Always use select_related() for ForeignKey relationships to avoid N+1 queries",
                "Combine multiple ranking factors with annotate() and Case/When",
                "Use distinct() when joining across relationships to avoid duplicates",
                "Consider privacy and archived content in all user-facing queries"
            ]
        }
    ]
}