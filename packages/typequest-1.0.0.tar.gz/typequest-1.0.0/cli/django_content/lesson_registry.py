"""
Django Lesson Registry - Manages lesson ordering and metadata
"""

from .class_based_views_intro import DJANGO_CBV_INTRO_LESSON
from .generic_display_views import DJANGO_GENERIC_DISPLAY_LESSON
from .generic_editing_views import DJANGO_GENERIC_EDITING_LESSON
from .mixins import DJANGO_MIXINS_LESSON
from .urlconf_usage import DJANGO_URLCONF_USAGE_LESSON
from .subclassing_views import DJANGO_SUBCLASSING_LESSON
from .async_views import DJANGO_ASYNC_VIEWS_LESSON
from .models_foundations import DJANGO_MODELS_FOUNDATIONS_LESSON
from .model_relationships import DJANGO_MODEL_RELATIONSHIPS_LESSON
from .model_fields_advanced import DJANGO_ADVANCED_FIELDS_LESSON
from .queryset_fundamentals import DJANGO_QUERYSET_FUNDAMENTALS_LESSON
from .queryset_advanced_operations import DJANGO_QUERYSET_ADVANCED_OPERATIONS_LESSON
from .queryset_lookups_optimization import DJANGO_QUERYSET_LOOKUPS_OPTIMIZATION_LESSON
from .model_instance_methods import DJANGO_MODEL_INSTANCE_METHODS_LESSON
from .model_relations_advanced import DJANGO_MODEL_RELATIONS_ADVANCED_LESSON

# Django Migrations Lessons
from .django_migrations_intro import DJANGO_MIGRATIONS_INTRO_LESSON
from .django_migrations_custom import DJANGO_MIGRATIONS_CUSTOM_LESSON
from .django_migrations_operations import DJANGO_MIGRATIONS_OPERATIONS_LESSON
from .django_migrations_schema_editor import DJANGO_MIGRATIONS_SCHEMA_EDITOR_LESSON

# Django Database Lessons
from .django_managers import DJANGO_MANAGERS_LESSON
from .django_raw_sql import DJANGO_RAW_SQL_LESSON
from .django_transactions import DJANGO_TRANSACTIONS_LESSON
from .django_aggregation import DJANGO_AGGREGATION_LESSON
from .django_search import DJANGO_SEARCH_LESSON
from .django_custom_fields import DJANGO_CUSTOM_FIELDS_LESSON
from .django_multi_database import DJANGO_MULTI_DATABASE_LESSON

# Django Expressions Lessons
from .django_expressions import DJANGO_EXPRESSIONS_LESSON
from .django_conditional_expressions import DJANGO_CONDITIONAL_EXPRESSIONS_LESSON
from .django_database_functions import DJANGO_DATABASE_FUNCTIONS_LESSON

# Django Database Management Lessons
from .django_database_configuration import DJANGO_DATABASE_CONFIGURATION_LESSON
from .django_legacy_database import DJANGO_LEGACY_DATABASE_LESSON
from .django_initial_data import DJANGO_INITIAL_DATA_LESSON
from .django_database_optimization import DJANGO_DATABASE_OPTIMIZATION_LESSON
from .django_postgresql_advanced import DJANGO_POSTGRESQL_ADVANCED_LESSON

# Django Foundations Lessons
from .django_settings import DJANGO_SETTINGS_LESSON
from .django_applications import DJANGO_APPLICATIONS_LESSON
from .django_admin_commands import DJANGO_ADMIN_COMMANDS_LESSON
from .django_custom_management_commands import DJANGO_CUSTOM_MANAGEMENT_COMMANDS_LESSON

# Django Async Lessons
from .django_async_fundamentals import DJANGO_ASYNC_FUNDAMENTALS_LESSON
from .django_async_database_operations import DJANGO_ASYNC_DATABASE_OPERATIONS_LESSON
from .django_async_middleware_auth import DJANGO_ASYNC_MIDDLEWARE_AUTH_LESSON

# SQL Course Lessons
from .sql_introduction import SQL_INTRODUCTION_LESSON
from .sql_select_basics_improved import SQL_SELECT_BASICS_LESSON_IMPROVED as SQL_SELECT_BASICS_LESSON
from .sql_where_conditions import SQL_WHERE_CONDITIONS_LESSON
from .sql_filtering_sorting import SQL_FILTERING_SORTING_LESSON
from .sql_joins_basics import SQL_JOINS_BASICS_LESSON
from .sql_outer_joins import SQL_OUTER_JOINS_LESSON
from .sql_expressions import SQL_EXPRESSIONS_LESSON
from .sql_aggregates import SQL_AGGREGATES_LESSON
from .sql_data_modification import SQL_DATA_MODIFICATION_LESSON
from .sql_schema_modification import SQL_SCHEMA_MODIFICATION_LESSON

# Lesson content registry - maps lesson keys to content
LESSON_CONTENT_REGISTRY = {
    'cbv_intro': DJANGO_CBV_INTRO_LESSON,
    'generic_display': DJANGO_GENERIC_DISPLAY_LESSON,
    'generic_editing': DJANGO_GENERIC_EDITING_LESSON,
    'mixins': DJANGO_MIXINS_LESSON,
    'urlconf_usage': DJANGO_URLCONF_USAGE_LESSON,
    'subclassing_views': DJANGO_SUBCLASSING_LESSON,
    'async_views': DJANGO_ASYNC_VIEWS_LESSON,
    'models_foundations': DJANGO_MODELS_FOUNDATIONS_LESSON,
    'model_relationships': DJANGO_MODEL_RELATIONSHIPS_LESSON,
    'model_fields_advanced': DJANGO_ADVANCED_FIELDS_LESSON,
    'queryset_fundamentals': DJANGO_QUERYSET_FUNDAMENTALS_LESSON,
    'queryset_advanced_operations': DJANGO_QUERYSET_ADVANCED_OPERATIONS_LESSON,
    'queryset_lookups_optimization': DJANGO_QUERYSET_LOOKUPS_OPTIMIZATION_LESSON,
    'model_instance_methods': DJANGO_MODEL_INSTANCE_METHODS_LESSON,
    'model_relations_advanced': DJANGO_MODEL_RELATIONS_ADVANCED_LESSON,
    
    # Django Migrations Course
    'django_migrations_intro': DJANGO_MIGRATIONS_INTRO_LESSON,
    'django_migrations_custom': DJANGO_MIGRATIONS_CUSTOM_LESSON,
    'django_migrations_operations': DJANGO_MIGRATIONS_OPERATIONS_LESSON,
    'django_migrations_schema_editor': DJANGO_MIGRATIONS_SCHEMA_EDITOR_LESSON,
    
    # Django Database Course
    'django_managers': DJANGO_MANAGERS_LESSON,
    'django_raw_sql': DJANGO_RAW_SQL_LESSON,
    'django_transactions': DJANGO_TRANSACTIONS_LESSON,
    'django_aggregation': DJANGO_AGGREGATION_LESSON,
    'django_search': DJANGO_SEARCH_LESSON,
    'django_custom_fields': DJANGO_CUSTOM_FIELDS_LESSON,
    'django_multi_database': DJANGO_MULTI_DATABASE_LESSON,
    
    # Django Expressions Course
    'django_expressions': DJANGO_EXPRESSIONS_LESSON,
    'django_conditional_expressions': DJANGO_CONDITIONAL_EXPRESSIONS_LESSON,
    'django_database_functions': DJANGO_DATABASE_FUNCTIONS_LESSON,
    
    # Django Database Management Course
    'django_database_configuration': DJANGO_DATABASE_CONFIGURATION_LESSON,
    'django_legacy_database': DJANGO_LEGACY_DATABASE_LESSON,
    'django_initial_data': DJANGO_INITIAL_DATA_LESSON,
    'django_database_optimization': DJANGO_DATABASE_OPTIMIZATION_LESSON,
    'django_postgresql_advanced': DJANGO_POSTGRESQL_ADVANCED_LESSON,
    
    # Django Foundations Course
    'django_settings': DJANGO_SETTINGS_LESSON,
    'django_applications': DJANGO_APPLICATIONS_LESSON,
    'django_admin_commands': DJANGO_ADMIN_COMMANDS_LESSON,
    'django_custom_management_commands': DJANGO_CUSTOM_MANAGEMENT_COMMANDS_LESSON,
    
    # Django Async Course
    'django_async_fundamentals': DJANGO_ASYNC_FUNDAMENTALS_LESSON,
    'django_async_database_operations': DJANGO_ASYNC_DATABASE_OPERATIONS_LESSON,
    'django_async_middleware_auth': DJANGO_ASYNC_MIDDLEWARE_AUTH_LESSON,
    
    # SQL Course
    'sql_introduction': SQL_INTRODUCTION_LESSON,
    'sql_select_basics': SQL_SELECT_BASICS_LESSON,
    'sql_where_conditions': SQL_WHERE_CONDITIONS_LESSON,
    'sql_filtering_sorting': SQL_FILTERING_SORTING_LESSON,
    'sql_joins_basics': SQL_JOINS_BASICS_LESSON,
    'sql_outer_joins': SQL_OUTER_JOINS_LESSON,
    'sql_expressions': SQL_EXPRESSIONS_LESSON,
    'sql_aggregates': SQL_AGGREGATES_LESSON,
    'sql_data_modification': SQL_DATA_MODIFICATION_LESSON,
    'sql_schema_modification': SQL_SCHEMA_MODIFICATION_LESSON,
}

# Configurable lesson ordering - easy to modify without touching content
LESSON_ORDER_CONFIGS = {
    'default': [
        # Django Foundations Course (early fundamentals)
        'django_settings',
        'django_applications',
        'django_admin_commands',
        'django_custom_management_commands',
        
        # Core Django concepts
        'models_foundations',
        'model_relationships',
        'model_fields_advanced',
        'model_instance_methods',
        'model_relations_advanced',
        'queryset_fundamentals',
        'queryset_advanced_operations',
        'queryset_lookups_optimization',
        'cbv_intro',
        'generic_display', 
        'generic_editing',
        'mixins',
        'urlconf_usage',
        'subclassing_views',
        'async_views',
        
        # Django Migrations Course
        'django_migrations_intro',
        'django_migrations_custom',
        'django_migrations_operations', 
        'django_migrations_schema_editor',
        
        # Django Database Course
        'django_managers',
        'django_raw_sql',
        'django_transactions',
        'django_aggregation',
        'django_search',
        'django_custom_fields',
        'django_multi_database',
        
        # Django Expressions Course
        'django_expressions',
        'django_conditional_expressions',
        'django_database_functions',
        
        # Django Database Management Course
        'django_database_configuration',
        'django_legacy_database', 
        'django_initial_data',
        'django_database_optimization',
        'django_postgresql_advanced',
        
        # Django Async Course
        'django_async_fundamentals',
        'django_async_database_operations', 
        'django_async_middleware_auth',
        
        # SQL Course (complete curriculum from SQLBolt)
        'sql_introduction',
        'sql_select_basics', 
        'sql_where_conditions',
        'sql_filtering_sorting',
        'sql_joins_basics',
        'sql_outer_joins',
        'sql_expressions',
        'sql_aggregates',
        'sql_data_modification',
        'sql_schema_modification'
    ],
    
    'models_focus': [
        'models_foundations',
        'model_relationships',
        'model_fields_advanced',
        'model_instance_methods',
        'model_relations_advanced',
        'queryset_fundamentals',
        'queryset_advanced_operations',
        'queryset_lookups_optimization'
    ],
    
    'sql_course': [
        'sql_introduction',
        'sql_select_basics', 
        'sql_where_conditions',
        'sql_filtering_sorting',
        'sql_joins_basics',
        'sql_outer_joins',
        'sql_expressions',
        'sql_aggregates',
        'sql_data_modification',
        'sql_schema_modification'
    ],
    
    'django_migrations_course': [
        'django_migrations_intro',
        'django_migrations_custom',
        'django_migrations_operations',
        'django_migrations_schema_editor'
    ],
    
    'django_database_course': [
        'django_managers',
        'django_raw_sql', 
        'django_transactions',
        'django_aggregation',
        'django_search',
        'django_custom_fields',
        'django_multi_database'
    ],
    
    'django_expressions_course': [
        'django_expressions',
        'django_conditional_expressions',
        'django_database_functions'
    ],
    
    'django_database_management_course': [
        'django_database_configuration',
        'django_legacy_database',
        'django_initial_data', 
        'django_database_optimization',
        'django_postgresql_advanced'
    ],
    
    'django_foundations_course': [
        'django_settings',
        'django_applications',
        'django_admin_commands',
        'django_custom_management_commands'
    ],
    
    'django_async_course': [
        'django_async_fundamentals',
        'django_async_database_operations',
        'django_async_middleware_auth'
    ],
    
    'views_focus': [
        'cbv_intro',
        'generic_display',
        'urlconf_usage',
        'generic_editing',
        'mixins',
        'subclassing_views',
        'async_views'
    ],
    
    'beginner_friendly': [
        'models_foundations',
        'queryset_fundamentals',
        'model_instance_methods',
        'cbv_intro',
        'generic_display',
        'model_relationships',
        'urlconf_usage',
        'generic_editing',
        'model_fields_advanced',
        'model_relations_advanced',
        'mixins',
        'queryset_advanced_operations',
        'subclassing_views',
        'queryset_lookups_optimization',
        'async_views',
        
        # SQL Course for beginners
        'sql_introduction',
        'sql_select_basics', 
        'sql_where_conditions',
        'sql_filtering_sorting',
        'sql_joins_basics',
        'sql_outer_joins',
        'sql_expressions',
        'sql_aggregates',
        'sql_data_modification',
        'sql_schema_modification'
    ],
    
    'practical_first': [
        'models_foundations',
        'model_instance_methods',
        'queryset_fundamentals',
        'cbv_intro',
        'urlconf_usage',
        'generic_display',
        'model_relationships',
        'generic_editing',
        'mixins',
        'subclassing_views',
        'model_fields_advanced',
        'model_relations_advanced',
        'queryset_advanced_operations',
        'queryset_lookups_optimization',
        'async_views',
        
        # SQL Course (practical approach)
        'sql_introduction',
        'sql_select_basics', 
        'sql_where_conditions',
        'sql_filtering_sorting',
        'sql_joins_basics',
        'sql_outer_joins',
        'sql_expressions',
        'sql_aggregates',
        'sql_data_modification',
        'sql_schema_modification'
    ],
    
    'advanced_first': [
        'async_views',
        'queryset_lookups_optimization',
        'model_relations_advanced',
        'queryset_advanced_operations',
        'subclassing_views',
        'mixins',
        'model_fields_advanced',
        'generic_editing',
        'model_relationships',
        'generic_display',
        'queryset_fundamentals',
        'model_instance_methods',
        'urlconf_usage',
        'models_foundations',
        'cbv_intro'
    ]
}

def get_ordered_lessons(order_config='default', start_chapter=1):
    """
    Get lessons in specified order with sequential chapter numbering
    
    Args:
        order_config (str): The ordering configuration to use
        start_chapter (int): Starting chapter number
        
    Returns:
        list: List of lesson dictionaries with updated chapter numbers
    """
    if order_config not in LESSON_ORDER_CONFIGS:
        raise ValueError(f"Unknown order config: {order_config}")
    
    ordered_lessons = []
    lesson_order = LESSON_ORDER_CONFIGS[order_config]
    
    for index, lesson_key in enumerate(lesson_order):
        if lesson_key not in LESSON_CONTENT_REGISTRY:
            raise KeyError(f"Lesson content not found for key: {lesson_key}")
        
        # Get lesson content and update chapter/id
        lesson = LESSON_CONTENT_REGISTRY[lesson_key].copy()
        lesson['id'] = start_chapter + index
        lesson['chapter'] = start_chapter + index
        
        ordered_lessons.append(lesson)
    
    return ordered_lessons

def get_lesson_by_key(lesson_key):
    """
    Get a specific lesson by its key
    
    Args:
        lesson_key (str): The lesson key
        
    Returns:
        dict: Lesson content dictionary
    """
    if lesson_key not in LESSON_CONTENT_REGISTRY:
        raise KeyError(f"Lesson content not found for key: {lesson_key}")
    
    return LESSON_CONTENT_REGISTRY[lesson_key].copy()

def get_available_orders():
    """
    Get list of available lesson ordering configurations
    
    Returns:
        list: Available order configuration names
    """
    return list(LESSON_ORDER_CONFIGS.keys())

def add_lesson_order(name, lesson_keys):
    """
    Add a new lesson ordering configuration
    
    Args:
        name (str): Name for the new configuration
        lesson_keys (list): List of lesson keys in desired order
    """
    # Validate all lesson keys exist
    for key in lesson_keys:
        if key not in LESSON_CONTENT_REGISTRY:
            raise KeyError(f"Lesson content not found for key: {key}")
    
    LESSON_ORDER_CONFIGS[name] = lesson_keys

def get_lesson_metadata():
    """
    Get metadata for all lessons (without full content)
    
    Returns:
        dict: Mapping of lesson keys to metadata
    """
    metadata = {}
    for key, lesson in LESSON_CONTENT_REGISTRY.items():
        metadata[key] = {
            'title': lesson['title'],
            'slug': lesson['slug'],
            'is_free': lesson['is_free'],
            'xp_reward': lesson['xp_reward'],
            'exercise_count': len(lesson.get('exercises', []))
        }
    return metadata

# Lesson difficulty levels for automatic ordering
LESSON_DIFFICULTY = {
    # Django Foundations (absolute basics)
    'django_settings': 1,                # Beginner - fundamental project configuration
    'django_applications': 2,            # Beginner - app architecture basics
    'django_admin_commands': 3,          # Beginner - command-line operations
    'django_custom_management_commands': 4, # Intermediate - creating custom tools
    
    # Core Django concepts  
    'models_foundations': 5,             # Beginner
    'queryset_fundamentals': 6,          # Beginner
    'model_instance_methods': 7,         # Beginner
    'model_relationships': 8,            # Intermediate
    'cbv_intro': 9,                     # Intermediate
    'urlconf_usage': 10,                # Intermediate
    'generic_display': 11,              # Intermediate
    'generic_editing': 12,              # Intermediate
    'model_fields_advanced': 13,        # Advanced
    'model_relations_advanced': 14,     # Advanced
    'queryset_advanced_operations': 15, # Advanced
    'mixins': 16,                       # Advanced
    'subclassing_views': 17,            # Advanced
    'queryset_lookups_optimization': 18, # Expert
    'async_views': 19,                  # Expert
    
    # Django Migrations difficulty levels
    'django_migrations_intro': 20,          # Beginner
    'django_migrations_custom': 21,         # Intermediate
    'django_migrations_operations': 22,     # Intermediate
    'django_migrations_schema_editor': 23,  # Advanced
    
    # Django Database difficulty levels
    'django_managers': 24,                  # Intermediate
    'django_raw_sql': 25,                  # Intermediate  
    'django_transactions': 26,             # Intermediate
    'django_aggregation': 27,              # Intermediate
    'django_search': 28,                   # Intermediate
    'django_custom_fields': 29,            # Advanced
    'django_multi_database': 30,           # Advanced
    
    # Django Expressions difficulty levels
    'django_expressions': 31,              # Intermediate
    'django_conditional_expressions': 32,  # Intermediate
    'django_database_functions': 33,       # Advanced
    
    # Django Database Management difficulty levels
    'django_database_configuration': 34,   # Intermediate
    'django_legacy_database': 35,          # Advanced
    'django_initial_data': 36,             # Intermediate
    'django_database_optimization': 37,    # Advanced
    'django_postgresql_advanced': 38,      # Advanced
    
    # Django Async difficulty levels  
    'django_async_fundamentals': 49,       # Advanced
    'django_async_database_operations': 50,  # Advanced
    'django_async_middleware_auth': 51,     # Expert
    
    # SQL Course difficulty levels
    'sql_introduction': 52,             # Beginner
    'sql_select_basics': 53,            # Beginner
    'sql_where_conditions': 54,         # Beginner
    'sql_filtering_sorting': 55,        # Intermediate
    'sql_joins_basics': 56,             # Intermediate
    'sql_outer_joins': 57,              # Intermediate
    'sql_expressions': 58,              # Intermediate
    'sql_aggregates': 59,               # Advanced
    'sql_data_modification': 60,        # Advanced
    'sql_schema_modification': 61,      # Advanced
}

def get_lessons_by_difficulty(difficulty_order='ascending', start_chapter=1):
    """
    Get lessons ordered by difficulty level
    
    Args:
        difficulty_order (str): 'ascending' or 'descending'
        start_chapter (int): Starting chapter number
        
    Returns:
        list: List of lessons ordered by difficulty
    """
    # Sort lesson keys by difficulty
    sorted_keys = sorted(
        LESSON_DIFFICULTY.keys(), 
        key=lambda k: LESSON_DIFFICULTY[k],
        reverse=(difficulty_order == 'descending')
    )
    
    ordered_lessons = []
    for index, lesson_key in enumerate(sorted_keys):
        lesson = LESSON_CONTENT_REGISTRY[lesson_key].copy()
        lesson['id'] = start_chapter + index
        lesson['chapter'] = start_chapter + index
        lesson['difficulty_level'] = LESSON_DIFFICULTY[lesson_key]
        
        ordered_lessons.append(lesson)
    
    return ordered_lessons

# Prerequisites mapping for dependency-based ordering
LESSON_PREREQUISITES = {
    # Django Foundations (no prerequisites - these are the absolute basics)
    'django_settings': [],
    'django_applications': ['django_settings'],
    'django_admin_commands': ['django_settings', 'django_applications'],
    'django_custom_management_commands': ['django_settings', 'django_applications', 'django_admin_commands'],
    
    # Core Django concepts (build on foundations)
    'models_foundations': ['django_settings', 'django_applications'],
    'queryset_fundamentals': ['models_foundations'],
    'model_instance_methods': ['models_foundations'],
    'model_relationships': ['models_foundations', 'model_instance_methods'],
    'model_fields_advanced': ['models_foundations', 'model_relationships'],
    'model_relations_advanced': ['model_relationships', 'model_instance_methods'],
    'queryset_advanced_operations': ['queryset_fundamentals', 'model_relationships'],
    'queryset_lookups_optimization': ['queryset_fundamentals', 'queryset_advanced_operations'],
    'cbv_intro': ['models_foundations', 'queryset_fundamentals'],
    'urlconf_usage': ['cbv_intro'],
    'generic_display': ['cbv_intro'],
    'generic_editing': ['cbv_intro', 'generic_display'],
    'mixins': ['cbv_intro', 'generic_display', 'generic_editing'],
    'subclassing_views': ['cbv_intro', 'generic_display', 'generic_editing', 'mixins'],
    'async_views': ['cbv_intro', 'generic_display', 'subclassing_views'],
    
    # Django Migrations prerequisites
    'django_migrations_intro': ['models_foundations'],
    'django_migrations_custom': ['django_migrations_intro'],
    'django_migrations_operations': ['django_migrations_intro'],
    'django_migrations_schema_editor': ['django_migrations_custom', 'django_migrations_operations'],
    
    # Django Database prerequisites
    'django_managers': ['models_foundations', 'queryset_fundamentals'],
    'django_raw_sql': ['models_foundations', 'queryset_fundamentals', 'django_managers'],
    'django_transactions': ['models_foundations', 'queryset_fundamentals', 'django_raw_sql'],
    'django_aggregation': ['models_foundations', 'queryset_fundamentals', 'django_raw_sql'],
    'django_search': ['models_foundations', 'queryset_fundamentals', 'django_aggregation'],
    'django_custom_fields': ['models_foundations', 'queryset_fundamentals', 'django_transactions'],
    'django_multi_database': ['models_foundations', 'django_transactions', 'django_aggregation'],
    
    # Django Expressions prerequisites
    'django_expressions': ['models_foundations', 'queryset_fundamentals', 'django_aggregation'],
    'django_conditional_expressions': ['models_foundations', 'queryset_fundamentals', 'django_expressions'],
    'django_database_functions': ['models_foundations', 'queryset_fundamentals', 'django_expressions', 'django_conditional_expressions'],
    
    # Django Database Management prerequisites
    'django_database_configuration': ['models_foundations', 'django_transactions'],
    'django_legacy_database': ['models_foundations', 'django_database_configuration'],
    'django_initial_data': ['models_foundations', 'django_migrations_intro'],
    'django_database_optimization': ['models_foundations', 'queryset_fundamentals', 'django_aggregation'],
    'django_postgresql_advanced': ['models_foundations', 'django_database_optimization'],
    
    # Django Async prerequisites (building on existing async_views lesson)
    'django_async_fundamentals': ['async_views'],
    'django_async_database_operations': ['async_views', 'django_async_fundamentals', 'django_database_optimization'],
    'django_async_middleware_auth': ['async_views', 'django_async_fundamentals', 'django_async_database_operations'],
    
    # SQL Course prerequisites
    'sql_introduction': [],
    'sql_select_basics': ['sql_introduction'],
    'sql_where_conditions': ['sql_select_basics'],
    'sql_filtering_sorting': ['sql_where_conditions'],
    'sql_joins_basics': ['sql_select_basics', 'sql_where_conditions'],
    'sql_outer_joins': ['sql_joins_basics'],
    'sql_expressions': ['sql_select_basics', 'sql_where_conditions'],
    'sql_aggregates': ['sql_select_basics', 'sql_filtering_sorting'],
    'sql_data_modification': ['sql_select_basics', 'sql_where_conditions'],
    'sql_schema_modification': ['sql_select_basics', 'sql_data_modification'],
}

def get_lessons_by_prerequisites(start_chapter=1):
    """
    Get lessons ordered by prerequisite dependencies (topological sort)
    
    Args:
        start_chapter (int): Starting chapter number
        
    Returns:
        list: List of lessons in dependency order
    """
    def topological_sort(prerequisites):
        # Kahn's algorithm for topological sorting
        in_degree = {lesson: 0 for lesson in prerequisites}
        
        # Calculate in-degrees
        for lesson, deps in prerequisites.items():
            in_degree[lesson] = len(deps)
        
        # Initialize queue with lessons that have no prerequisites
        queue = [lesson for lesson, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            lesson = queue.pop(0)
            result.append(lesson)
            
            # Update in-degrees for lessons that depend on current lesson
            for other_lesson, deps in prerequisites.items():
                if lesson in deps:
                    in_degree[other_lesson] -= 1
                    if in_degree[other_lesson] == 0:
                        queue.append(other_lesson)
        
        return result
    
    sorted_keys = topological_sort(LESSON_PREREQUISITES)
    
    ordered_lessons = []
    for index, lesson_key in enumerate(sorted_keys):
        lesson = LESSON_CONTENT_REGISTRY[lesson_key].copy()
        lesson['id'] = start_chapter + index
        lesson['chapter'] = start_chapter + index
        lesson['prerequisites'] = LESSON_PREREQUISITES[lesson_key]
        
        ordered_lessons.append(lesson)
    
    return ordered_lessons

# Export the main functions for easy importing
__all__ = [
    'get_ordered_lessons',
    'get_lesson_by_key', 
    'get_available_orders',
    'add_lesson_order',
    'get_lesson_metadata',
    'get_lessons_by_difficulty',
    'get_lessons_by_prerequisites',
    'LESSON_ORDER_CONFIGS',
    'LESSON_CONTENT_REGISTRY'
]