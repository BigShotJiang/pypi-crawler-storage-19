"""
Django Foundations - Lesson 2: Django Applications Architecture
Master Django's application system for modular, scalable development
"""

DJANGO_APPLICATIONS_LESSON = {
    "id": 2,
    "chapter": 2,
    "title": "Django Applications: Modular Architecture Mastery",
    "slug": "django-applications",
    "description": "Learn Django's application architecture, app configuration, app registry, and best practices for building modular, reusable applications",
    "content": '''# Django Applications: Modular Architecture Mastery

## 🎯 Building Scalable Django Architecture

**Django applications** are the building blocks of any Django project - they provide modular, reusable functionality that can be shared across projects. Think of apps as **LEGO blocks** that you combine to build complex applications.

**Why Django Apps Matter**:
- **Modularity** → Separate concerns into logical, manageable pieces
- **Reusability** → Apps can be shared across different projects
- **Maintainability** → Easier to update, debug, and extend specific functionality
- **Team collaboration** → Different teams can work on different apps
- **Scalability** → Add/remove features by managing apps

Companies like **Instagram, Spotify, and GitHub** use Django's app architecture to manage massive codebases with hundreds of applications working together.

## 💾 Django Applications Architecture Database

Let's explore how Django applications are structured and configured:

```sql
-- DJANGO APPLICATIONS ARCHITECTURE
-- Database: django_applications_arch

-- Django projects and their application ecosystems
CREATE TABLE django_projects (
    id SERIAL PRIMARY KEY,
    project_name VARCHAR(100) NOT NULL,
    company VARCHAR(100) NOT NULL,
    project_type VARCHAR(50) NOT NULL, -- 'web_app', 'api', 'microservice', 'cms'
    total_apps INTEGER DEFAULT 0,
    django_version VARCHAR(20),
    python_version VARCHAR(20),
    deployment_scale VARCHAR(20), -- 'startup', 'medium', 'enterprise', 'global'
    team_size INTEGER DEFAULT 1,
    lines_of_code INTEGER DEFAULT 0,
    created_date DATE DEFAULT CURRENT_DATE,
    last_updated DATE DEFAULT CURRENT_DATE,
    is_open_source BOOLEAN DEFAULT FALSE
);

-- Sample Django projects from famous companies
INSERT INTO django_projects (project_name, company, project_type, total_apps, django_version, deployment_scale, team_size, lines_of_code, is_open_source) VALUES
('Instagram Core', 'Meta', 'web_app', 47, '4.2', 'global', 150, 2500000, FALSE),
('Spotify Web Player', 'Spotify', 'web_app', 23, '4.1', 'global', 85, 1800000, FALSE),
('GitHub Notifications', 'GitHub', 'microservice', 12, '4.2', 'global', 25, 450000, FALSE),
('Pinterest Core', 'Pinterest', 'web_app', 35, '4.0', 'global', 120, 2100000, FALSE),
('Dropbox Paper', 'Dropbox', 'web_app', 18, '4.1', 'enterprise', 40, 980000, FALSE),
('Mozilla Addons', 'Mozilla', 'web_app', 15, '4.2', 'medium', 12, 320000, TRUE),
('Django CMS Demo', 'Community', 'cms', 8, '4.2', 'startup', 3, 85000, TRUE);

-- Individual Django applications within projects
CREATE TABLE django_apps (
    id SERIAL PRIMARY KEY,
    project_id INTEGER NOT NULL,
    app_name VARCHAR(100) NOT NULL,
    app_label VARCHAR(50) NOT NULL, -- Short identifier used in Django
    verbose_name VARCHAR(150), -- Human-readable name
    app_type VARCHAR(50) NOT NULL, -- 'core', 'business', 'integration', 'utility', 'third_party'
    is_django_builtin BOOLEAN DEFAULT FALSE,
    is_third_party BOOLEAN DEFAULT FALSE,
    is_local_app BOOLEAN DEFAULT TRUE,
    models_count INTEGER DEFAULT 0,
    views_count INTEGER DEFAULT 0,
    templates_count INTEGER DEFAULT 0,
    migrations_count INTEGER DEFAULT 0,
    tests_count INTEGER DEFAULT 0,
    lines_of_code INTEGER DEFAULT 0,
    has_admin_integration BOOLEAN DEFAULT FALSE,
    has_api_endpoints BOOLEAN DEFAULT FALSE,
    has_custom_management_commands BOOLEAN DEFAULT FALSE,
    dependencies TEXT[], -- Other apps this app depends on
    description TEXT,
    maintainer VARCHAR(100),
    created_date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (project_id) REFERENCES django_projects(id)
);

-- Sample Django applications (like Instagram's architecture)
INSERT INTO django_apps (project_id, app_name, app_label, verbose_name, app_type, models_count, views_count, has_admin_integration, has_api_endpoints, dependencies, description) VALUES
-- Instagram Core project apps
(1, 'accounts', 'accounts', 'User Account Management', 'core', 8, 15, TRUE, TRUE, ARRAY['django.contrib.auth'], 'User registration, authentication, profile management'),
(1, 'photos', 'photos', 'Photo Sharing', 'business', 12, 25, TRUE, TRUE, ARRAY['accounts', 'storage'], 'Photo upload, filtering, sharing functionality'),
(1, 'feed', 'feed', 'Activity Feed', 'business', 6, 18, TRUE, TRUE, ARRAY['accounts', 'photos', 'social'], 'Timeline and feed generation'),
(1, 'social', 'social', 'Social Features', 'business', 10, 22, TRUE, TRUE, ARRAY['accounts'], 'Following, likes, comments, social graph'),
(1, 'messaging', 'messaging', 'Direct Messaging', 'business', 8, 16, TRUE, TRUE, ARRAY['accounts'], 'Private messaging and chat features'),
(1, 'notifications', 'notifications', 'Push Notifications', 'integration', 4, 8, TRUE, TRUE, ARRAY['accounts'], 'Push notification system'),
(1, 'analytics', 'analytics', 'Usage Analytics', 'utility', 15, 5, TRUE, FALSE, ARRAY['accounts'], 'User behavior tracking and analytics'),
(1, 'storage', 'storage', 'Media Storage', 'utility', 3, 2, FALSE, FALSE, ARRAY[], 'S3 and CDN integration for media files'),
-- Spotify Web Player apps
(2, 'music', 'music', 'Music Catalog', 'business', 18, 30, TRUE, TRUE, ARRAY['accounts'], 'Music tracks, albums, artist management'),
(2, 'playlists', 'playlists', 'Playlist Management', 'business', 8, 20, TRUE, TRUE, ARRAY['music', 'accounts'], 'User playlist creation and management'),
(2, 'player', 'player', 'Audio Player', 'business', 5, 12, FALSE, TRUE, ARRAY['music'], 'Audio streaming and playback controls'),
(2, 'recommendations', 'recommendations', 'Music Recommendations', 'business', 12, 8, TRUE, TRUE, ARRAY['music', 'accounts'], 'ML-powered music recommendations'),
(2, 'search', 'search', 'Music Search', 'utility', 6, 15, FALSE, TRUE, ARRAY['music'], 'Elasticsearch-powered music search');

-- Built-in Django apps that projects use
INSERT INTO django_apps (project_id, app_name, app_label, app_type, is_django_builtin, models_count, views_count, has_admin_integration, description) VALUES
(1, 'django.contrib.admin', 'admin', 'utility', TRUE, 3, 25, TRUE, 'Django admin interface'),
(1, 'django.contrib.auth', 'auth', 'core', TRUE, 6, 8, TRUE, 'Authentication and authorization'),
(1, 'django.contrib.contenttypes', 'contenttypes', 'core', TRUE, 1, 0, FALSE, 'Content type framework'),
(1, 'django.contrib.sessions', 'sessions', 'core', TRUE, 1, 0, FALSE, 'Session framework'),
(1, 'django.contrib.messages', 'messages', 'utility', TRUE, 0, 0, FALSE, 'Message framework'),
(1, 'django.contrib.staticfiles', 'staticfiles', 'utility', TRUE, 0, 0, FALSE, 'Static file serving');

-- Third-party apps commonly used
INSERT INTO django_apps (project_id, app_name, app_label, app_type, is_third_party, models_count, views_count, description) VALUES
(1, 'rest_framework', 'rest_framework', 'utility', TRUE, 4, 15, 'Django REST Framework for APIs'),
(1, 'corsheaders', 'corsheaders', 'utility', TRUE, 0, 0, 'CORS headers for API access'),
(1, 'celery', 'celery', 'utility', TRUE, 2, 0, 'Distributed task queue'),
(2, 'django_redis', 'django_redis', 'utility', TRUE, 0, 0, 'Redis cache backend'),
(2, 'elasticsearch_dsl', 'elasticsearch_dsl', 'utility', TRUE, 0, 0, 'Elasticsearch integration');

-- App configuration classes (AppConfig)
CREATE TABLE django_app_configs (
    id SERIAL PRIMARY KEY,
    app_id INTEGER NOT NULL,
    config_class_name VARCHAR(100) NOT NULL,
    config_module_path VARCHAR(200) NOT NULL,
    verbose_name VARCHAR(150),
    default_auto_field VARCHAR(100) DEFAULT 'django.db.models.BigAutoField',
    has_custom_ready_method BOOLEAN DEFAULT FALSE,
    ready_method_description TEXT,
    has_custom_label BOOLEAN DEFAULT FALSE,
    custom_label VARCHAR(50),
    initialization_order INTEGER DEFAULT 1, -- Order in which ready() is called
    custom_attributes JSONB DEFAULT '{}'::jsonb,
    FOREIGN KEY (app_id) REFERENCES django_apps(id)
);

-- Sample app configurations
INSERT INTO django_app_configs (app_id, config_class_name, config_module_path, verbose_name, has_custom_ready_method, ready_method_description, custom_attributes) VALUES
(1, 'AccountsConfig', 'accounts.apps', 'User Account Management', TRUE, 'Registers custom user signals and permissions', '{"signal_handlers": ["post_save_user_profile"], "permissions": ["can_moderate_users"]}'::jsonb),
(2, 'PhotosConfig', 'photos.apps', 'Photo Sharing Platform', TRUE, 'Initializes image processing pipeline and storage backends', '{"image_processors": ["resize", "filter", "compress"], "storage_backends": ["s3", "cloudfront"]}'::jsonb),
(3, 'FeedConfig', 'feed.apps', 'Activity Feed System', TRUE, 'Starts background feed generation tasks', '{"background_tasks": ["feed_refresh", "trending_calculation"], "cache_timeout": 300}'::jsonb),
(4, 'SocialConfig', 'social.apps', 'Social Features Hub', TRUE, 'Registers social graph update handlers', '{"graph_algorithms": ["followers", "recommendations"], "rate_limits": {"follow": 100, "like": 500}}'::jsonb);

-- App dependencies and relationships
CREATE TABLE django_app_dependencies (
    id SERIAL PRIMARY KEY,
    dependent_app_id INTEGER NOT NULL,
    dependency_app_id INTEGER NOT NULL,
    dependency_type VARCHAR(50) NOT NULL, -- 'model_import', 'signal_handler', 'utility_function', 'url_include'
    is_hard_dependency BOOLEAN DEFAULT TRUE, -- Whether app can't work without this dependency
    is_circular_safe BOOLEAN DEFAULT TRUE, -- Whether this dependency creates circular imports
    relationship_description TEXT,
    created_date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (dependent_app_id) REFERENCES django_apps(id),
    FOREIGN KEY (dependency_app_id) REFERENCES django_apps(id)
);

-- Sample app dependencies (like Instagram's app relationships)
INSERT INTO django_app_dependencies (dependent_app_id, dependency_app_id, dependency_type, is_hard_dependency, relationship_description) VALUES
(2, 1, 'model_import', TRUE, 'Photos app imports User model from accounts'),
(3, 1, 'model_import', TRUE, 'Feed app needs User model for feed generation'),
(3, 2, 'model_import', TRUE, 'Feed app displays photos in timeline'),
(4, 1, 'model_import', TRUE, 'Social features require User model'),
(5, 1, 'model_import', TRUE, 'Messaging requires User model for participants'),
(6, 1, 'signal_handler', TRUE, 'Notifications listen to user activity signals'),
(7, 1, 'model_import', FALSE, 'Analytics tracks user behavior'),
(7, 2, 'signal_handler', FALSE, 'Analytics tracks photo interactions');

-- App file structure and organization
CREATE TABLE django_app_structure (
    id SERIAL PRIMARY KEY,
    app_id INTEGER NOT NULL,
    file_type VARCHAR(50) NOT NULL, -- 'models', 'views', 'urls', 'admin', 'forms', 'serializers', 'tasks', 'tests'
    file_path VARCHAR(200) NOT NULL,
    file_size_kb INTEGER DEFAULT 0,
    complexity_score INTEGER DEFAULT 1, -- 1-10, based on file complexity
    last_modified DATE DEFAULT CURRENT_DATE,
    maintainer VARCHAR(100),
    has_documentation BOOLEAN DEFAULT FALSE,
    test_coverage_percent INTEGER DEFAULT 0,
    FOREIGN KEY (app_id) REFERENCES django_apps(id)
);

-- Sample file structure for Instagram-style apps
INSERT INTO django_app_structure (app_id, file_type, file_path, file_size_kb, complexity_score, test_coverage_percent, has_documentation) VALUES
-- Accounts app structure
(1, 'models', 'accounts/models.py', 45, 7, 85, TRUE),
(1, 'views', 'accounts/views.py', 78, 8, 92, TRUE),
(1, 'urls', 'accounts/urls.py', 12, 3, 100, TRUE),
(1, 'admin', 'accounts/admin.py', 23, 5, 90, TRUE),
(1, 'forms', 'accounts/forms.py', 34, 6, 88, TRUE),
(1, 'serializers', 'accounts/serializers.py', 28, 5, 85, TRUE),
(1, 'signals', 'accounts/signals.py', 15, 4, 95, TRUE),
(1, 'tests', 'accounts/tests/', 156, 9, 100, TRUE),
-- Photos app structure  
(2, 'models', 'photos/models.py', 67, 8, 82, TRUE),
(2, 'views', 'photos/views.py', 123, 9, 88, TRUE),
(2, 'urls', 'photos/urls.py', 18, 4, 100, TRUE),
(2, 'admin', 'photos/admin.py', 31, 6, 85, TRUE),
(2, 'serializers', 'photos/serializers.py', 45, 7, 90, TRUE),
(2, 'tasks', 'photos/tasks.py', 89, 8, 78, TRUE),
(2, 'tests', 'photos/tests/', 234, 9, 100, TRUE);

-- App performance metrics
CREATE TABLE django_app_metrics (
    id SERIAL PRIMARY KEY,
    app_id INTEGER NOT NULL,
    metric_date DATE DEFAULT CURRENT_DATE,
    request_count INTEGER DEFAULT 0,
    avg_response_time_ms DECIMAL(8, 3) DEFAULT 0,
    error_count INTEGER DEFAULT 0,
    error_rate_percent DECIMAL(5, 2) DEFAULT 0,
    database_queries_per_request DECIMAL(5, 2) DEFAULT 0,
    cache_hit_rate_percent DECIMAL(5, 2) DEFAULT 0,
    memory_usage_mb DECIMAL(8, 2) DEFAULT 0,
    cpu_usage_percent DECIMAL(5, 2) DEFAULT 0,
    active_users INTEGER DEFAULT 0,
    feature_usage_count INTEGER DEFAULT 0,
    FOREIGN KEY (app_id) REFERENCES django_apps(id)
);

-- Sample performance metrics
INSERT INTO django_app_metrics (app_id, request_count, avg_response_time_ms, error_count, error_rate_percent, database_queries_per_request, cache_hit_rate_percent, active_users) VALUES
(1, 145000, 89.5, 234, 0.16, 3.2, 87.5, 89000), -- accounts app
(2, 234000, 156.7, 456, 0.19, 5.8, 92.1, 78000), -- photos app
(3, 567000, 203.4, 789, 0.14, 8.3, 95.2, 85000), -- feed app
(4, 189000, 67.8, 123, 0.07, 2.1, 89.7, 67000), -- social app
(5, 78000, 45.2, 89, 0.11, 1.8, 78.4, 23000); -- messaging app
```

## 🔧 Django Application Architecture Patterns

### 1. Creating and Configuring Django Applications

**Scenario**: Instagram's modular photo-sharing architecture  
*Building scalable, maintainable Django applications*

```python
# accounts/apps.py - User account management app
from django.apps import AppConfig
from django.db.models.signals import post_save, post_delete

class AccountsConfig(AppConfig):
    """
    Configuration for the accounts application
    Handles user authentication, profiles, and account management
    """
    name = 'accounts'
    verbose_name = 'User Account Management'
    default_auto_field = 'django.db.models.BigAutoField'
    
    def ready(self):
        """
        Called when Django starts up
        Register signal handlers and perform initialization
        """
        # Import signal handlers (avoid circular imports)
        from . import signals
        
        # Register custom permissions
        self._register_custom_permissions()
        
        # Initialize user profile creation signals
        self._connect_profile_signals()
        
        # Set up user activity tracking
        self._setup_activity_tracking()
    
    def _register_custom_permissions(self):
        """Register custom permissions for the app"""
        from django.contrib.contenttypes.models import ContentType
        from django.contrib.auth.models import Permission
        from .models import UserProfile
        
        try:
            content_type = ContentType.objects.get_for_model(UserProfile)
            
            # Custom permissions for user management
            custom_permissions = [
                ('can_moderate_users', 'Can moderate user accounts'),
                ('can_view_user_analytics', 'Can view user analytics'),
                ('can_export_user_data', 'Can export user data'),
            ]
            
            for codename, name in custom_permissions:
                Permission.objects.get_or_create(
                    codename=codename,
                    name=name,
                    content_type=content_type,
                )
        except Exception:
            # During migrations, models might not exist yet
            pass
    
    def _connect_profile_signals(self):
        """Connect signals for automatic profile creation"""
        from django.contrib.auth import get_user_model
        from .models import UserProfile
        from .signals import create_user_profile, save_user_profile
        
        User = get_user_model()
        
        post_save.connect(
            create_user_profile,
            sender=User,
            dispatch_uid='create_user_profile'
        )
        
        post_save.connect(
            save_user_profile,
            sender=User,
            dispatch_uid='save_user_profile'
        )
    
    def _setup_activity_tracking(self):
        """Initialize user activity tracking"""
        from .utils import ActivityTracker
        
        # Initialize activity tracker singleton
        ActivityTracker.initialize()

# photos/apps.py - Photo sharing app configuration
from django.apps import AppConfig
import logging

logger = logging.getLogger(__name__)

class PhotosConfig(AppConfig):
    """
    Configuration for the photos application
    Handles photo upload, processing, and sharing
    """
    name = 'photos'
    verbose_name = 'Photo Sharing Platform'
    default_auto_field = 'django.db.models.BigAutoField'
    
    def ready(self):
        """Initialize photo processing and storage systems"""
        
        # Import signal handlers
        from . import signals
        
        # Initialize image processing pipeline
        self._setup_image_processing()
        
        # Configure storage backends
        self._configure_storage()
        
        # Set up background tasks
        self._setup_background_tasks()
    
    def _setup_image_processing(self):
        """Initialize image processing pipeline"""
        from .processors import ImageProcessor
        
        try:
            # Configure image processing pipeline
            processors = [
                'resize_processor',
                'filter_processor', 
                'compression_processor',
                'metadata_extractor'
            ]
            
            ImageProcessor.configure_pipeline(processors)
            logger.info("Image processing pipeline configured")
            
        except Exception as e:
            logger.error(f"Failed to configure image processing: {e}")
    
    def _configure_storage(self):
        """Configure photo storage backends"""
        from django.conf import settings
        from .storage import PhotoStorageManager
        
        try:
            # Configure storage backends based on settings
            storage_config = {
                'primary_backend': getattr(settings, 'PHOTOS_PRIMARY_STORAGE', 's3'),
                'cdn_backend': getattr(settings, 'PHOTOS_CDN_STORAGE', 'cloudfront'),
                'backup_backend': getattr(settings, 'PHOTOS_BACKUP_STORAGE', 'glacier'),
            }
            
            PhotoStorageManager.configure(storage_config)
            logger.info("Photo storage backends configured")
            
        except Exception as e:
            logger.error(f"Failed to configure storage: {e}")
    
    def _setup_background_tasks(self):
        """Setup Celery background tasks for photo processing"""
        try:
            from .tasks import setup_periodic_tasks
            setup_periodic_tasks()
            logger.info("Photo background tasks configured")
            
        except ImportError:
            logger.warning("Celery not available, background tasks disabled")
        except Exception as e:
            logger.error(f"Failed to setup background tasks: {e}")

# feed/apps.py - Activity feed app configuration
from django.apps import AppConfig

class FeedConfig(AppConfig):
    """
    Configuration for the feed application
    Handles activity feed generation and delivery
    """
    name = 'feed'
    verbose_name = 'Activity Feed System'
    default_auto_field = 'django.db.models.BigAutoField'
    
    def ready(self):
        """Initialize feed generation systems"""
        
        # Import signal handlers for feed updates
        from . import signals
        
        # Initialize feed algorithms
        self._setup_feed_algorithms()
        
        # Configure real-time updates
        self._setup_realtime_updates()
        
        # Start background feed refresh
        self._start_feed_refresh_tasks()
    
    def _setup_feed_algorithms(self):
        """Configure feed ranking and filtering algorithms"""
        from .algorithms import FeedAlgorithmManager
        
        algorithms = {
            'chronological': 'ChronologicalFeed',
            'engagement_based': 'EngagementRankedFeed',
            'ml_personalized': 'MLPersonalizedFeed',
        }
        
        FeedAlgorithmManager.register_algorithms(algorithms)
    
    def _setup_realtime_updates(self):
        """Setup WebSocket connections for real-time feed updates"""
        from django.conf import settings
        
        if hasattr(settings, 'WEBSOCKET_ENABLED') and settings.WEBSOCKET_ENABLED:
            from .websockets import FeedWebSocketManager
            FeedWebSocketManager.initialize()
    
    def _start_feed_refresh_tasks(self):
        """Start background tasks for feed generation"""
        try:
            from .tasks import start_feed_refresh_scheduler
            start_feed_refresh_scheduler()
        except ImportError:
            pass  # Celery not available

# social/apps.py - Social features app configuration  
from django.apps import AppConfig

class SocialConfig(AppConfig):
    """
    Configuration for the social application
    Handles following, likes, comments, and social graph
    """
    name = 'social'
    verbose_name = 'Social Features Hub'
    default_auto_field = 'django.db.models.BigAutoField'
    
    def ready(self):
        """Initialize social features and graph algorithms"""
        
        # Import signal handlers
        from . import signals
        
        # Initialize social graph algorithms
        self._setup_social_graph()
        
        # Configure rate limiting
        self._setup_rate_limiting()
        
        # Initialize recommendation engine
        self._setup_recommendations()
    
    def _setup_social_graph(self):
        """Initialize social graph data structures"""
        from .graph import SocialGraphManager
        
        # Configure graph algorithms
        SocialGraphManager.configure({
            'follow_algorithm': 'bidirectional_graph',
            'recommendation_depth': 3,
            'mutual_friends_weight': 0.7,
            'activity_weight': 0.3,
        })
    
    def _setup_rate_limiting(self):
        """Configure rate limits for social actions"""
        from .rate_limits import SocialRateLimiter
        
        limits = {
            'follow_per_hour': 100,
            'like_per_minute': 60,
            'comment_per_minute': 10,
            'share_per_hour': 50,
        }
        
        SocialRateLimiter.configure(limits)
    
    def _setup_recommendations(self):
        """Initialize social recommendations engine"""
        try:
            from .recommendations import SocialRecommendationEngine
            SocialRecommendationEngine.initialize()
        except ImportError:
            pass  # ML libraries not available
```

### 2. App Registry and Discovery Patterns

**Scenario**: Spotify's dynamic app management system

```python
# core/apps.py - Core utilities for app management
from django.apps import AppConfig, apps
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class CoreConfig(AppConfig):
    """
    Core application configuration
    Manages app discovery, health checks, and inter-app communication
    """
    name = 'core'
    verbose_name = 'Core System Utilities'
    
    def ready(self):
        """Initialize core system components"""
        
        # Discover and validate all applications
        self._discover_applications()
        
        # Set up inter-app communication
        self._setup_app_communication()
        
        # Initialize health check system
        self._setup_health_checks()
    
    def _discover_applications(self):
        """
        Discover all installed applications and validate their configuration
        Similar to how Spotify manages hundreds of microservices
        """
        from .registry import AppRegistry
        
        discovered_apps = []
        
        for app_config in apps.get_app_configs():
            app_info = {
                'name': app_config.name,
                'label': app_config.label,
                'verbose_name': app_config.verbose_name,
                'path': app_config.path,
                'models_module': app_config.models_module,
                'has_migrations': self._check_migrations(app_config),
                'has_admin': self._check_admin_integration(app_config),
                'has_api': self._check_api_endpoints(app_config),
                'dependencies': self._get_app_dependencies(app_config),
            }
            
            discovered_apps.append(app_info)
            logger.debug(f"Discovered app: {app_config.name}")
        
        # Register all discovered apps
        AppRegistry.register_apps(discovered_apps)
        
        # Validate app dependencies
        self._validate_app_dependencies(discovered_apps)
    
    def _check_migrations(self, app_config):
        """Check if app has migration files"""
        import os
        migrations_path = os.path.join(app_config.path, 'migrations')
        return os.path.exists(migrations_path)
    
    def _check_admin_integration(self, app_config):
        """Check if app has admin.py file"""
        import os
        admin_path = os.path.join(app_config.path, 'admin.py')
        return os.path.exists(admin_path)
    
    def _check_api_endpoints(self, app_config):
        """Check if app has API endpoints"""
        try:
            # Look for serializers.py or api.py
            import os
            api_indicators = ['serializers.py', 'api.py', 'viewsets.py']
            
            for indicator in api_indicators:
                if os.path.exists(os.path.join(app_config.path, indicator)):
                    return True
            return False
        except Exception:
            return False
    
    def _get_app_dependencies(self, app_config):
        """Analyze app dependencies from imports"""
        dependencies = []
        
        try:
            # This would analyze the app's imports to find dependencies
            # Simplified version - in practice, you'd parse Python files
            if hasattr(app_config, 'dependencies'):
                dependencies = app_config.dependencies
        except Exception:
            pass
        
        return dependencies
    
    def _validate_app_dependencies(self, apps_info):
        """
        Validate that all app dependencies are satisfied
        Prevents circular dependencies and missing dependencies
        """
        app_names = {app['name'] for app in apps_info}
        
        for app in apps_info:
            for dependency in app['dependencies']:
                if dependency not in app_names:
                    # Check if it's a Django built-in app
                    if not dependency.startswith('django.'):
                        logger.warning(
                            f"App {app['name']} depends on missing app: {dependency}"
                        )
    
    def _setup_app_communication(self):
        """Setup inter-app communication system"""
        from .messaging import AppMessagingBus
        
        # Initialize message bus for inter-app communication
        AppMessagingBus.initialize()
        
        # Register event handlers
        self._register_event_handlers()
    
    def _register_event_handlers(self):
        """Register cross-app event handlers"""
        from .events import EventDispatcher
        
        # Example: When a user is created, notify multiple apps
        EventDispatcher.register_handler(
            'user_created',
            [
                'photos.handlers.create_default_album',
                'social.handlers.setup_social_profile',
                'notifications.handlers.send_welcome_notification',
            ]
        )
    
    def _setup_health_checks(self):
        """Initialize health check system for all apps"""
        from .health import AppHealthMonitor
        
        AppHealthMonitor.initialize()
        
        # Register health check endpoints for each app
        for app_config in apps.get_app_configs():
            if hasattr(app_config, 'health_check'):
                AppHealthMonitor.register_health_check(
                    app_config.label,
                    app_config.health_check
                )

# core/registry.py - Application registry management
class AppRegistry:
    """
    Central registry for managing Django applications
    Similar to service discovery in microservices architecture
    """
    
    _apps = {}
    _dependencies = {}
    _health_status = {}
    
    @classmethod
    def register_apps(cls, apps_info):
        """Register discovered applications"""
        for app_info in apps_info:
            cls._apps[app_info['name']] = app_info
            cls._dependencies[app_info['name']] = app_info['dependencies']
            cls._health_status[app_info['name']] = 'unknown'
    
    @classmethod
    def get_app_info(cls, app_name):
        """Get information about a specific app"""
        return cls._apps.get(app_name)
    
    @classmethod
    def get_all_apps(cls):
        """Get information about all registered apps"""
        return cls._apps.copy()
    
    @classmethod
    def get_app_dependencies(cls, app_name):
        """Get dependencies for a specific app"""
        return cls._dependencies.get(app_name, [])
    
    @classmethod
    def get_dependent_apps(cls, app_name):
        """Get apps that depend on the specified app"""
        dependent_apps = []
        
        for app, dependencies in cls._dependencies.items():
            if app_name in dependencies:
                dependent_apps.append(app)
        
        return dependent_apps
    
    @classmethod
    def check_circular_dependencies(cls):
        """Check for circular dependencies between apps"""
        def has_circular_dependency(app, visited, recursion_stack):
            visited[app] = True
            recursion_stack[app] = True
            
            for dependency in cls._dependencies.get(app, []):
                if dependency in cls._apps:  # Only check local apps
                    if not visited.get(dependency, False):
                        if has_circular_dependency(dependency, visited, recursion_stack):
                            return True
                    elif recursion_stack.get(dependency, False):
                        return True
            
            recursion_stack[app] = False
            return False
        
        visited = {}
        recursion_stack = {}
        
        for app_name in cls._apps:
            if not visited.get(app_name, False):
                if has_circular_dependency(app_name, visited, recursion_stack):
                    return True
        
        return False
    
    @classmethod
    def get_load_order(cls):
        """Get apps in dependency load order (topological sort)"""
        # Simplified topological sort
        in_degree = {app: 0 for app in cls._apps}
        
        # Calculate in-degrees
        for app, dependencies in cls._dependencies.items():
            for dep in dependencies:
                if dep in cls._apps:  # Only count local app dependencies
                    in_degree[app] += 1
        
        # Initialize queue with apps that have no dependencies
        queue = [app for app, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            app = queue.pop(0)
            result.append(app)
            
            # Update in-degrees for dependent apps
            for dependent in cls.get_dependent_apps(app):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)
        
        return result

# core/health.py - App health monitoring
class AppHealthMonitor:
    """
    Monitor health status of all Django applications
    """
    
    _health_checks = {}
    _status_cache = {}
    _last_check = {}
    
    @classmethod
    def initialize(cls):
        """Initialize health monitoring system"""
        from django.core.cache import cache
        cls._cache = cache
    
    @classmethod
    def register_health_check(cls, app_label, health_check_func):
        """Register a health check function for an app"""
        cls._health_checks[app_label] = health_check_func
    
    @classmethod
    def check_app_health(cls, app_label):
        """Check health of a specific app"""
        if app_label not in cls._health_checks:
            return {'status': 'unknown', 'message': 'No health check registered'}
        
        try:
            health_check = cls._health_checks[app_label]
            result = health_check()
            
            # Cache result
            cls._status_cache[app_label] = result
            cls._last_check[app_label] = timezone.now()
            
            return result
            
        except Exception as e:
            error_result = {
                'status': 'error',
                'message': f'Health check failed: {str(e)}'
            }
            cls._status_cache[app_label] = error_result
            return error_result
    
    @classmethod
    def check_all_apps(cls):
        """Check health of all registered apps"""
        results = {}
        
        for app_label in cls._health_checks:
            results[app_label] = cls.check_app_health(app_label)
        
        return results
    
    @classmethod
    def get_system_health(cls):
        """Get overall system health status"""
        app_results = cls.check_all_apps()
        
        total_apps = len(app_results)
        healthy_apps = sum(1 for result in app_results.values() 
                          if result.get('status') == 'healthy')
        
        system_status = 'healthy'
        if healthy_apps < total_apps:
            if healthy_apps / total_apps < 0.8:  # Less than 80% healthy
                system_status = 'critical'
            else:
                system_status = 'degraded'
        
        return {
            'overall_status': system_status,
            'healthy_apps': healthy_apps,
            'total_apps': total_apps,
            'app_details': app_results,
            'timestamp': timezone.now().isoformat()
        }
```

## 🎯 Key Takeaways

1. **Django apps provide modularity** → Separate concerns into logical, reusable components
2. **AppConfig classes control initialization** → Use ready() method for app-specific setup
3. **App dependencies must be managed carefully** → Avoid circular imports and missing dependencies
4. **Apps can communicate through signals** → Loose coupling between app components
5. **Health monitoring is essential** → Track app performance and dependencies
6. **App registry provides service discovery** → Central management of all applications
7. **Proper app architecture scales** → Well-designed apps support large, complex systems

Master Django's app architecture for building scalable, maintainable applications!
''',
    "difficulty": "beginner", 
    "estimated_time": 35,
    "xp_reward": 20,
    "prerequisites": ["django-settings"],
    "exercises": [
        {
            "id": "django_apps_1",
            "title": "Explore Django Project Architecture",
            "prompt": "Let's examine how major companies structure their Django projects. Write a query to see project information.",
            "table_name": "django_projects",
            "initial_query": "SELECT * FROM django_projects LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "django_projects"],
            "hint": "Use SELECT * FROM django_projects LIMIT 5; to see project architectures",
            "solution": "SELECT * FROM django_projects LIMIT 5;",
            "explanation": "This table shows how companies like Instagram, Spotify, and GitHub structure their Django projects. Notice the variation in total apps, team sizes, and deployment scales - this reflects how Django apps provide modularity for different project sizes."
        },
        {
            "id": "django_apps_2", 
            "title": "Analyze Application Types and Purposes",
            "prompt": "Examine different types of Django applications. Write a query to see apps categorized by type and functionality.",
            "table_name": "django_apps",
            "expected_keywords": ["SELECT", "app_name", "app_type", "models_count", "has_api_endpoints"],
            "hint": "Group apps by type and show their characteristics",
            "solution": "SELECT app_type, app_name, verbose_name, models_count, views_count, has_admin_integration, has_api_endpoints FROM django_apps WHERE project_id <= 2 ORDER BY app_type, app_name;",
            "explanation": "Django apps are categorized by purpose: core (essential functionality), business (domain logic), utility (helper functions), and integration (external services). This modular approach allows teams to work on different aspects independently."
        },
        {
            "id": "django_apps_3",
            "title": "App Configuration Analysis", 
            "prompt": "Explore app configuration patterns. Write a query to see how apps are configured with custom AppConfig classes.",
            "table_name": "django_app_configs",
            "expected_keywords": ["SELECT", "config_class_name", "verbose_name", "has_custom_ready_method", "ready_method_description"],
            "hint": "Select app configuration information including custom ready methods",
            "solution": "SELECT dac.config_class_name, da.app_name, dac.verbose_name, dac.has_custom_ready_method, dac.ready_method_description FROM django_app_configs dac JOIN django_apps da ON dac.app_id = da.id WHERE dac.has_custom_ready_method = true;",
            "explanation": "AppConfig classes with custom ready() methods perform initialization tasks like registering signals, setting up permissions, and configuring external services. This pattern ensures apps are properly initialized when Django starts."
        },
        {
            "id": "django_apps_4",
            "title": "App Dependencies and Relationships",
            "prompt": "Analyze dependencies between Django applications. Write a query to see how apps depend on each other.",
            "table_name": "django_app_dependencies", 
            "expected_keywords": ["SELECT", "dependent_app_id", "dependency_app_id", "dependency_type", "is_hard_dependency"],
            "hint": "Join with django_apps table to show app names and dependency relationships",
            "solution": "SELECT dep.app_name as dependent_app, target.app_name as dependency_app, dad.dependency_type, dad.is_hard_dependency, dad.relationship_description FROM django_app_dependencies dad JOIN django_apps dep ON dad.dependent_app_id = dep.id JOIN django_apps target ON dad.dependency_app_id = target.id ORDER BY dep.app_name;",
            "explanation": "App dependencies show how Django applications interact. Hard dependencies are required for the app to function, while soft dependencies are optional. Understanding these relationships is crucial for deployment order and testing."
        },
        {
            "id": "django_apps_5",
            "title": "App File Structure and Complexity",
            "prompt": "Examine how Django apps are organized internally. Write a query to see file structures and complexity metrics.",
            "table_name": "django_app_structure",
            "expected_keywords": ["SELECT", "app_id", "file_type", "file_path", "complexity_score", "test_coverage_percent"],
            "hint": "Group by app and file type to see how apps are structured",
            "solution": "SELECT da.app_name, das.file_type, das.file_path, das.complexity_score, das.test_coverage_percent, das.has_documentation FROM django_app_structure das JOIN django_apps da ON das.app_id = da.id WHERE da.project_id = 1 ORDER BY da.app_name, das.file_type;",
            "explanation": "App file structure shows Django's convention-over-configuration approach. Each app typically has models.py, views.py, urls.py, admin.py, and tests/. Complexity scores and test coverage indicate code quality and maintainability."
        },
        {
            "id": "django_apps_6",
            "title": "App Performance Metrics",
            "prompt": "Analyze application performance across different Django apps. Write a query to compare app performance metrics.",
            "table_name": "django_app_metrics",
            "expected_keywords": ["SELECT", "app_id", "request_count", "avg_response_time_ms", "error_rate_percent", "cache_hit_rate_percent"],
            "hint": "Compare performance metrics across apps including response times and error rates",
            "solution": "SELECT da.app_name, dam.request_count, dam.avg_response_time_ms, dam.error_rate_percent, dam.database_queries_per_request, dam.cache_hit_rate_percent, dam.active_users FROM django_app_metrics dam JOIN django_apps da ON dam.app_id = da.id ORDER BY dam.avg_response_time_ms DESC;",
            "explanation": "Performance metrics reveal how different apps perform under load. The feed app handles the most requests but has higher response times due to complex algorithms, while simpler apps like messaging have faster response times but fewer features."
        }
    ],
    "key_concepts": [
        "Django Application Architecture and Modularity",
        "AppConfig Classes and Application Initialization",
        "App Registry and Service Discovery",
        "Inter-App Dependencies and Communication",
        "Application Health Monitoring",
        "File Structure and Code Organization",
        "Performance Monitoring and Metrics",
        "App Types: Core, Business, Utility, Integration"
    ]
}