"""
Django Migrations - Lesson 4: Schema Editor Advanced Techniques
Master the Django Schema Editor for complex database operations
"""

DJANGO_MIGRATIONS_SCHEMA_EDITOR_LESSON = {
    "id": 43,
    "chapter": 43,
    "title": "Django Schema Editor: Advanced Database Control",
    "slug": "django-migrations-schema-editor",
    "description": "Master Django's Schema Editor for complex database operations and optimizations",
    "content": '''# Django Schema Editor: Advanced Database Control

## 🎯 Understanding the Schema Editor

The Django **Schema Editor** is the **low-level engine** that powers all migrations. While migration operations like `AddField` and `CreateModel` are high-level abstractions, the Schema Editor provides **direct control** over database schema changes.

Think of it this way:
- **Migration Operations** = High-level "what to do" (add field, create index)
- **Schema Editor** = Low-level "how to do it" (generate SQL, execute commands)

## 💾 Complex Database for Advanced Operations

Let's work with a sophisticated e-commerce platform database:

```sql
-- Products table with advanced features
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category_id INTEGER,
    brand_id INTEGER,
    sku VARCHAR(50) UNIQUE NOT NULL,
    stock_quantity INTEGER DEFAULT 0,
    weight_grams INTEGER,
    dimensions_json TEXT, -- JSON field for dimensions
    is_active BOOLEAN DEFAULT TRUE,
    featured_until TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    search_vector TEXT -- Full-text search vector
);

-- Orders table with complex relationships
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    total_amount DECIMAL(10, 2) NOT NULL,
    shipping_address_json TEXT, -- JSON field
    payment_method VARCHAR(50),
    payment_status VARCHAR(20) DEFAULT 'pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_at TIMESTAMP,
    delivered_at TIMESTAMP,
    tracking_number VARCHAR(100),
    discount_applied DECIMAL(10, 2) DEFAULT 0.00,
    tax_amount DECIMAL(10, 2) DEFAULT 0.00
);

-- Sample products data
INSERT INTO products (name, description, price, sku, stock_quantity, weight_grams, is_active) VALUES 
('iPhone 15 Pro', 'Latest Apple flagship smartphone', 999.99, 'IPHONE15PRO', 50, 187, true),
('MacBook Air M2', 'Ultra-thin laptop with M2 chip', 1299.99, 'MBA-M2-13', 25, 1240, true),
('AirPods Pro 2', 'Premium wireless earbuds', 249.99, 'APP2-WHITE', 100, 56, true),
('Tesla Model Y', 'Electric SUV with autopilot', 52990.00, 'TMY-2024', 5, 2003000, true);

-- Sample orders data
INSERT INTO orders (user_id, status, total_amount, payment_method, payment_status) VALUES 
(1, 'completed', 999.99, 'credit_card', 'paid'),
(2, 'shipped', 1299.99, 'paypal', 'paid'),
(3, 'pending', 249.99, 'credit_card', 'pending'),
(1, 'completed', 52990.00, 'bank_transfer', 'paid');
```

## 🔧 Core Schema Editor Methods

### 1. Creating Tables with Complex Features

**Real-world scenario**: Amazon adding a new product reviews table with full-text search

```python
from django.db import connection
from django.db.models import Index

def create_advanced_reviews_table(apps, schema_editor):
    """Create reviews table with advanced database features"""
    
    # Define the model structure
    class ReviewTemp:
        _meta = type('Meta', (), {
            'db_table': 'product_reviews',
            'app_label': 'products'
        })()
    
    # Create table with Schema Editor
    with connection.schema_editor() as editor:
        # Create the base table
        editor.execute("""
            CREATE TABLE product_reviews (
                id SERIAL PRIMARY KEY,
                product_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                rating INTEGER CHECK (rating >= 1 AND rating <= 5),
                title VARCHAR(200),
                content TEXT,
                helpful_votes INTEGER DEFAULT 0,
                verified_purchase BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                search_vector tsvector
            )
        """)
        
        # Add indexes for performance
        editor.execute("""
            CREATE INDEX product_reviews_product_rating_idx 
            ON product_reviews (product_id, rating DESC);
        """)
        
        # Add full-text search index (PostgreSQL)
        editor.execute("""
            CREATE INDEX product_reviews_search_idx 
            ON product_reviews USING GIN(search_vector);
        """)
        
        # Add trigger for search vector updates
        editor.execute("""
            CREATE TRIGGER update_review_search_vector
            BEFORE INSERT OR UPDATE ON product_reviews
            FOR EACH ROW EXECUTE FUNCTION 
            tsvector_update_trigger(search_vector, 'pg_catalog.english', title, content);
        """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(create_advanced_reviews_table),
    ]
```

### 2. Advanced Field Modifications

**Real-world scenario**: Shopify optimizing price storage for international currencies

```python
def optimize_price_fields(apps, schema_editor):
    """Convert price storage to support multiple currencies efficiently"""
    
    with connection.schema_editor() as editor:
        # Add new optimized price columns
        editor.execute("""
            ALTER TABLE products 
            ADD COLUMN price_cents INTEGER,
            ADD COLUMN currency_code CHAR(3) DEFAULT 'USD'
        """)
        
        # Migrate existing price data
        editor.execute("""
            UPDATE products 
            SET price_cents = ROUND(price * 100),
                currency_code = 'USD'
            WHERE price_cents IS NULL
        """)
        
        # Add constraints for data integrity
        editor.execute("""
            ALTER TABLE products 
            ADD CONSTRAINT price_cents_positive CHECK (price_cents >= 0),
            ADD CONSTRAINT currency_code_valid CHECK (LENGTH(currency_code) = 3)
        """)
        
        # Create index for currency-based queries
        editor.execute("""
            CREATE INDEX products_currency_price_idx 
            ON products (currency_code, price_cents DESC)
        """)

def reverse_price_optimization(apps, schema_editor):
    """Rollback price optimization"""
    with connection.schema_editor() as editor:
        editor.execute("ALTER TABLE products DROP COLUMN price_cents")
        editor.execute("ALTER TABLE products DROP COLUMN currency_code")

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(
            optimize_price_fields,
            reverse_price_optimization,
        ),
    ]
```

### 3. Complex Index Management

**Real-world scenario**: Netflix optimizing content recommendation queries

```python
def create_recommendation_indexes(apps, schema_editor):
    """Create specialized indexes for content recommendation system"""
    
    with connection.schema_editor() as editor:
        # Composite index for user viewing patterns
        editor.execute("""
            CREATE INDEX user_content_engagement_idx 
            ON user_content_interactions (
                user_id, 
                content_type, 
                interaction_score DESC,
                created_at DESC
            )
        """)
        
        # Partial index for active content only
        editor.execute("""
            CREATE INDEX active_content_popularity_idx 
            ON content (popularity_score DESC, created_at DESC)
            WHERE is_active = TRUE AND content_type = 'movie'
        """)
        
        # Expression index for search functionality
        editor.execute("""
            CREATE INDEX content_search_normalized_idx 
            ON content (LOWER(title), LOWER(description))
        """)
        
        # Unique constraint with condition
        editor.execute("""
            CREATE UNIQUE INDEX user_content_unique_rating_idx 
            ON user_ratings (user_id, content_id)
            WHERE rating IS NOT NULL
        """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(create_recommendation_indexes),
    ]
```

### 4. Database-Specific Optimizations

**Real-world scenario**: Instagram's photo storage optimization

```python
def optimize_for_postgresql(apps, schema_editor):
    """PostgreSQL-specific optimizations for photo storage"""
    
    if 'postgresql' not in schema_editor.connection.vendor:
        return  # Skip for other databases
    
    with connection.schema_editor() as editor:
        # Create ENUM type for photo sizes
        editor.execute("CREATE TYPE photo_size AS ENUM ('thumbnail', 'medium', 'large', 'original')")
        
        # Add photo metadata table with PostgreSQL features
        editor.execute("""
            CREATE TABLE photo_metadata (
                id SERIAL PRIMARY KEY,
                photo_id INTEGER NOT NULL,
                size photo_size NOT NULL,
                width INTEGER NOT NULL,
                height INTEGER NOT NULL,
                file_size_bytes BIGINT NOT NULL,
                storage_path TEXT NOT NULL,
                color_palette INTEGER[] DEFAULT '{}',  -- Array field
                exif_data JSONB,  -- JSON with better indexing
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                UNIQUE(photo_id, size)
            )
        """)
        
        # Create GIN index for JSONB queries
        editor.execute("""
            CREATE INDEX photo_exif_gin_idx 
            ON photo_metadata USING GIN (exif_data)
        """)
        
        # Create index for array operations
        editor.execute("""
            CREATE INDEX photo_color_palette_idx 
            ON photo_metadata USING GIN (color_palette)
        """)

def optimize_for_mysql(apps, schema_editor):
    """MySQL-specific optimizations"""
    
    if 'mysql' not in schema_editor.connection.vendor:
        return
    
    with connection.schema_editor() as editor:
        # MySQL doesn't have arrays, use JSON instead
        editor.execute("""
            CREATE TABLE photo_metadata_mysql (
                id INT AUTO_INCREMENT PRIMARY KEY,
                photo_id INT NOT NULL,
                size ENUM('thumbnail', 'medium', 'large', 'original') NOT NULL,
                metadata JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                UNIQUE KEY unique_photo_size (photo_id, size),
                INDEX metadata_idx (metadata)
            )
        """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(optimize_for_postgresql),
        migrations.RunPython(optimize_for_mysql),
    ]
```

### 5. Advanced Constraint Management

**Real-world scenario**: Uber's ride pricing with complex business rules

```python
def add_ride_pricing_constraints(apps, schema_editor):
    """Add complex business logic constraints for ride pricing"""
    
    with connection.schema_editor() as editor:
        # Ensure surge pricing is reasonable
        editor.execute("""
            ALTER TABLE rides 
            ADD CONSTRAINT surge_multiplier_reasonable 
            CHECK (surge_multiplier >= 1.0 AND surge_multiplier <= 5.0)
        """)
        
        # Ensure ride duration matches distance
        editor.execute("""
            ALTER TABLE rides 
            ADD CONSTRAINT duration_distance_reasonable 
            CHECK (
                (distance_km = 0 AND duration_minutes <= 5) OR
                (distance_km > 0 AND duration_minutes >= (distance_km / 60.0 * 60))
            )
        """)
        
        # Ensure driver can't be passenger on same ride
        editor.execute("""
            ALTER TABLE rides 
            ADD CONSTRAINT driver_not_passenger 
            CHECK (driver_id != passenger_id)
        """)
        
        # Complex constraint for ride scheduling
        editor.execute("""
            ALTER TABLE rides 
            ADD CONSTRAINT scheduled_ride_logic 
            CHECK (
                (is_scheduled = FALSE AND scheduled_for IS NULL) OR
                (is_scheduled = TRUE AND scheduled_for > created_at)
            )
        """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(add_ride_pricing_constraints),
    ]
```

### 6. Schema Editor with Model Introspection

**Real-world scenario**: Airbnb's dynamic pricing table optimization

```python
def optimize_pricing_table_structure(apps, schema_editor):
    """Optimize pricing table based on current data patterns"""
    
    Pricing = apps.get_model('listings', 'Pricing')
    
    with connection.schema_editor() as editor:
        # Analyze current data patterns
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    AVG(base_price) as avg_price,
                    MAX(base_price) as max_price,
                    COUNT(DISTINCT currency) as currency_count
                FROM pricing
            """)
            stats = cursor.fetchone()
            
            avg_price, max_price, currency_count = stats
            
            # Add optimized index based on data patterns
            if currency_count > 5:  # Multiple currencies in use
                editor.execute("""
                    CREATE INDEX pricing_currency_date_idx 
                    ON pricing (currency, date DESC, base_price DESC)
                """)
            
            # Add materialized view for expensive calculations
            if avg_price > 100:  # High-value listings
                editor.execute("""
                    CREATE MATERIALIZED VIEW expensive_listing_stats AS
                    SELECT 
                        listing_id,
                        AVG(base_price) as avg_price,
                        MAX(base_price) as peak_price,
                        COUNT(*) as price_changes
                    FROM pricing
                    WHERE base_price > 100
                    GROUP BY listing_id
                """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(optimize_pricing_table_structure),
    ]
```

## 🏢 Real-World Production Scenarios

### Discord's Message Partitioning

```python
def implement_message_partitioning(apps, schema_editor):
    """Implement table partitioning for Discord-scale message volume"""
    
    if 'postgresql' not in schema_editor.connection.vendor:
        return
    
    with connection.schema_editor() as editor:
        # Create partitioned messages table
        editor.execute("""
            CREATE TABLE messages_partitioned (
                id BIGSERIAL,
                channel_id BIGINT NOT NULL,
                user_id BIGINT NOT NULL,
                content TEXT,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                message_type VARCHAR(20) DEFAULT 'text'
            ) PARTITION BY RANGE (created_at)
        """)
        
        # Create monthly partitions for current and next 12 months
        import datetime
        current_date = datetime.date.today()
        
        for i in range(12):
            start_date = current_date.replace(day=1)
            if start_date.month == 12:
                end_date = start_date.replace(year=start_date.year + 1, month=1)
            else:
                end_date = start_date.replace(month=start_date.month + 1)
            
            partition_name = f"messages_{start_date.year}_{start_date.month:02d}"
            
            editor.execute(f"""
                CREATE TABLE {partition_name} PARTITION OF messages_partitioned
                FOR VALUES FROM ('{start_date}') TO ('{end_date}')
            """)
            
            # Add indexes to each partition
            editor.execute(f"""
                CREATE INDEX {partition_name}_channel_created_idx 
                ON {partition_name} (channel_id, created_at DESC)
            """)
            
            current_date = end_date

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(implement_message_partitioning),
    ]
```

### Stripe's Payment Processing Optimization

```python
def optimize_payment_processing(apps, schema_editor):
    """Optimize database for high-frequency payment processing"""
    
    with connection.schema_editor() as editor:
        # Create optimized payment tracking table
        editor.execute("""
            CREATE TABLE payment_events_optimized (
                id BIGSERIAL PRIMARY KEY,
                payment_id UUID NOT NULL,
                event_type VARCHAR(50) NOT NULL,
                status VARCHAR(30) NOT NULL,
                amount_cents BIGINT NOT NULL,
                currency CHAR(3) NOT NULL,
                processor_response JSONB,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP
            )
        """)
        
        # Specialized indexes for payment queries
        editor.execute("""
            CREATE INDEX payment_events_payment_status_idx 
            ON payment_events_optimized (payment_id, status, created_at DESC)
        """)
        
        editor.execute("""
            CREATE INDEX payment_events_amount_currency_idx 
            ON payment_events_optimized (currency, amount_cents DESC, created_at DESC)
            WHERE status = 'completed'
        """)
        
        # Create function for payment status aggregation
        editor.execute("""
            CREATE OR REPLACE FUNCTION get_payment_status(payment_uuid UUID)
            RETURNS VARCHAR(30) AS $$
            BEGIN
                RETURN (
                    SELECT status 
                    FROM payment_events_optimized 
                    WHERE payment_id = payment_uuid 
                    ORDER BY created_at DESC 
                    LIMIT 1
                );
            END;
            $$ LANGUAGE plpgsql;
        """)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(optimize_payment_processing),
    ]
```

## ⚡ Performance Best Practices

### 1. Minimize Locking
```python
# Use concurrent index creation when possible
with connection.schema_editor() as editor:
    editor.execute("CREATE INDEX CONCURRENTLY new_index ON large_table (column)")
```

### 2. Batch Operations
```python
# Process large tables in batches
with connection.schema_editor() as editor:
    editor.execute("""
        UPDATE large_table 
        SET new_column = calculated_value 
        WHERE id BETWEEN %s AND %s
    """, [batch_start, batch_end])
```

### 3. Test on Production-Like Data
```python
# Always include data volume tests
def test_migration_performance(apps, schema_editor):
    """Test migration performance with realistic data"""
    if settings.DEBUG:
        return  # Skip in development
    
    start_time = time.time()
    
    # Run actual migration logic
    perform_migration_operations()
    
    duration = time.time() - start_time
    if duration > 300:  # 5 minutes
        raise Exception(f"Migration too slow: {duration}s")
```

## 🎯 Key Takeaways

1. **Schema Editor provides direct database control** beyond standard migrations
2. **Database-specific optimizations** can significantly improve performance
3. **Complex constraints** enforce business logic at the database level
4. **Proper indexing strategy** is crucial for large-scale applications
5. **Always test with production-like data** volumes and patterns

The Schema Editor is your tool for implementing **enterprise-grade database optimizations** that go beyond basic Django migrations!
''',
    "difficulty": "advanced",
    "estimated_time": 45,
    "xp_reward": 30,
    "prerequisites": ["django-migrations-intro", "django-migrations-custom", "django-migrations-operations"],
    "exercises": [
        {
            "id": "schema_editor_1",
            "title": "Explore E-commerce Products Table",
            "prompt": "Let's examine our e-commerce products table structure. Write a query to see all product information including pricing and inventory.",
            "table_name": "products",
            "initial_query": "SELECT * FROM products LIMIT 3;",
            "expected_keywords": ["SELECT", "*", "FROM", "products"],
            "hint": "Use SELECT * FROM products LIMIT 3; to see the table structure",
            "solution": "SELECT * FROM products LIMIT 3;",
            "explanation": "This shows our products table with fields like name, price, sku, stock_quantity, weight_grams, etc. The Schema Editor can create complex tables like this with constraints, indexes, and database-specific features."
        },
        {
            "id": "schema_editor_2",
            "title": "Analyze High-Value Products for Optimization",
            "prompt": "The Schema Editor can create conditional indexes. Write a query to find products that might benefit from a 'high-value products' partial index (price > 1000).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "WHERE", "price", "1000"],
            "hint": "Use WHERE price > 1000 to find expensive products",
            "solution": "SELECT name, price, sku, stock_quantity FROM products WHERE price > 1000 ORDER BY price DESC;",
            "explanation": "These high-value products would benefit from a partial index like 'CREATE INDEX expensive_products_idx ON products (price DESC, stock_quantity) WHERE price > 1000'. Partial indexes save space and improve query performance for specific conditions."
        },
        {
            "id": "schema_editor_3",
            "title": "Understanding Complex Relationships",
            "prompt": "Examine the orders table and its structure. Write a query to see orders with their payment status and total amounts.",
            "table_name": "orders", 
            "expected_keywords": ["SELECT", "payment_status", "total_amount", "orders"],
            "hint": "Select fields like payment_status, total_amount, and status from orders",
            "solution": "SELECT id, user_id, status, total_amount, payment_status, order_date FROM orders ORDER BY total_amount DESC;",
            "explanation": "This shows the orders structure with complex business logic fields. The Schema Editor can add constraints like 'CHECK (total_amount > 0)' or 'CHECK (payment_status IN ('pending', 'paid', 'failed'))' to enforce business rules at the database level."
        },
        {
            "id": "schema_editor_4",
            "title": "Identify Constraint Opportunities",
            "prompt": "Write a query to check for any data integrity issues that could be prevented with database constraints. Look for orders with negative or zero amounts.",
            "table_name": "orders",
            "expected_keywords": ["SELECT", "WHERE", "total_amount", "0"],
            "hint": "Use WHERE total_amount <= 0 to find problematic orders",
            "solution": "SELECT * FROM orders WHERE total_amount <= 0;",
            "explanation": "Good! No orders with invalid amounts found. The Schema Editor could add 'ALTER TABLE orders ADD CONSTRAINT positive_amount CHECK (total_amount > 0)' to prevent this data issue in the future."
        },
        {
            "id": "schema_editor_5",
            "title": "Query for Index Optimization Patterns",
            "prompt": "Write a query that would benefit from a composite index on orders. Find recent orders by status, ordered by date.",
            "table_name": "orders",
            "expected_keywords": ["SELECT", "WHERE", "status", "ORDER BY", "order_date"],
            "hint": "Filter by status and order by order_date DESC to see recent orders first",
            "solution": "SELECT id, user_id, status, total_amount, order_date FROM orders WHERE status = 'completed' ORDER BY order_date DESC;",
            "explanation": "This query pattern benefits from a composite index like 'CREATE INDEX orders_status_date_idx ON orders (status, order_date DESC)'. The Schema Editor can create such optimized indexes for common query patterns."
        }
    ],
    "key_concepts": [
        "Schema Editor Direct Database Control",
        "Database-Specific Optimizations",
        "Complex Constraint Implementation", 
        "Advanced Index Strategies",
        "Table Partitioning Techniques",
        "Performance Testing Methodologies",
        "Production Migration Safety",
        "Business Logic Database Enforcement"
    ]
}