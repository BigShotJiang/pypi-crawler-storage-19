"""
SQL SELECT Basics lesson content - IMPROVED with micro-practice
"""

SQL_SELECT_BASICS_LESSON_IMPROVED = {
    "id": 31,
    "chapter": 31,
    "title": "SQL SELECT Queries 101",
    "slug": "sql-select-basics",
    "content": '''
# SQL SELECT Queries 101: Your First Database Conversations

Think of SELECT queries as asking specific questions to a knowledgeable librarian who has instant access to millions of organized records. You can ask for exactly what you need - whether it's "Show me all Marvel movies" or "Find users with more than 10,000 followers" - and get precise answers in milliseconds.

## 1. Basic SELECT Syntax

The SELECT statement is the foundation of SQL. It's how you retrieve data from tables, and it's used in virtually every database interaction across the tech industry.

### Basic Syntax Pattern:
```sql
SELECT column1, column2, column3
FROM table_name;
```

**Real-world analogy:** It's like filling out a form at the DMV. You specify exactly which information you want (columns) from which database (table), and the system returns just that data.

### Our Practice Table: Instagram Users
```
+----+---------------+------------------+----------------+-------------+-----------+
| id | username      | email            | follower_count | following   | verified  |
+----+---------------+------------------+----------------+-------------+-----------+
| 1  | travel_sarah  | sarah@email.com  | 125000         | 890        | 1         |
| 2  | tech_mike     | mike@gmail.com   | 45000          | 1200       | 0         |
| 3  | food_lover_23 | food@yahoo.com   | 78000          | 550        | 0         |
+----+---------------+------------------+----------------+-------------+-----------+
```
''',
    "micro_lessons": [
        {
            "topic": "Basic Syntax",
            "teaching_content": '''
### SELECT ALL Columns (*)

The asterisk (*) means "give me everything" - all columns from the table.

```sql
SELECT * FROM instagram_users;
```

**When to use SELECT *:**
- ✅ Exploring new tables
- ✅ Quick data inspection
- ❌ Production applications (performance)
- ❌ When you only need specific columns
''',
            "immediate_practice": {
                "id": "basic_syntax_practice",
                "title": "🏃‍♂️ Quick Practice: Basic Syntax",
                "type": "sql_practice",
                "practice_type": "basic_syntax",
                "instructions": "Try these SELECT * queries to explore different tables:",
                "tasks": [
                    {
                        "task": "Get all data from the instagram_users table",
                        "expected_query": "SELECT * FROM instagram_users;",
                        "hint": "Use SELECT * to see all columns and rows"
                    },
                    {
                        "task": "Get all data from the youtube_videos table",
                        "expected_query": "SELECT * FROM youtube_videos;",
                        "hint": "Remember the FROM keyword to specify the table"
                    }
                ]
            },
            "comprehension_quiz": {
                "id": "basic_syntax_quiz",
                "title": "🧠 Quick Check: Basic Syntax",
                "questions": [
                    {
                        "question": "What does the * symbol mean in SELECT queries?",
                        "options": [
                            "A) Multiply two columns",
                            "B) Select all columns from the table", 
                            "C) Select the first column only",
                            "D) Create a new column"
                        ],
                        "correct": "B",
                        "explanation": "The asterisk (*) is a wildcard that selects ALL columns from the specified table."
                    },
                    {
                        "question": "Which keyword specifies which table to query?",
                        "options": [
                            "A) SELECT",
                            "B) WHERE",
                            "C) FROM",
                            "D) ORDER"
                        ],
                        "correct": "C",
                        "explanation": "FROM tells SQL which table contains the data you want to retrieve."
                    }
                ]
            }
        },
        {
            "topic": "Select Specific Columns",
            "teaching_content": '''
### SELECT Specific Columns

Instead of getting everything (*), you can request specific columns. This is more efficient and gives you exactly what you need.

```sql
SELECT username, follower_count 
FROM instagram_users;
```

**Result:**
```
+---------------+----------------+
| username      | follower_count |
+---------------+----------------+
| travel_sarah  | 125000         |
| tech_mike     | 45000          |
| food_lover_23 | 78000          |
+---------------+----------------+
```

**Why select specific columns?**
- ⚡ **Faster queries** - Less data transferred
- 💰 **Lower costs** - Especially in cloud databases
- 🎯 **Cleaner results** - Only what you need
- 📱 **Better UX** - Mobile apps don't need all data

**Real-world example:** Netflix doesn't load your entire watch history when showing recommendations - just titles, thumbnails, and ratings!
''',
            "immediate_practice": {
                "id": "specific_columns_practice",
                "title": "🏃‍♂️ Quick Practice: Specific Columns",
                "type": "sql_practice",
                "practice_type": "column_selection",
                "instructions": "Practice selecting only the columns you need:",
                "tasks": [
                    {
                        "task": "Get only usernames and email addresses from instagram_users",
                        "expected_query": "SELECT username, email FROM instagram_users;",
                        "hint": "List the column names separated by commas after SELECT"
                    },
                    {
                        "task": "Get follower_count and verified status only",
                        "expected_query": "SELECT follower_count, verified FROM instagram_users;",
                        "hint": "Remember: no comma after the last column name"
                    },
                    {
                        "task": "Get just the usernames (single column)",
                        "expected_query": "SELECT username FROM instagram_users;",
                        "hint": "When selecting one column, no commas needed"
                    }
                ]
            },
            "comprehension_quiz": {
                "id": "specific_columns_quiz",
                "title": "🧠 Quick Check: Specific Columns",
                "questions": [
                    {
                        "question": "Why is selecting specific columns better than SELECT *?",
                        "options": [
                            "A) It looks more professional",
                            "B) It's faster and uses less bandwidth",
                            "C) It's required by SQL standards",
                            "D) It prevents errors"
                        ],
                        "correct": "B",
                        "explanation": "Selecting only needed columns reduces data transfer, improves performance, and can lower cloud database costs."
                    },
                    {
                        "question": "How do you separate multiple column names in SELECT?",
                        "options": [
                            "A) Semicolons (;)",
                            "B) Spaces only",
                            "C) Commas (,)",
                            "D) Pipe symbols (|)"
                        ],
                        "correct": "C",
                        "explanation": "Column names in SELECT statements are separated by commas, like: SELECT name, email, age"
                    }
                ]
            }
        },
        {
            "topic": "Column Aliases",
            "teaching_content": '''
### Column Aliases (AS Keyword)

Make your results more readable by giving columns custom names using the AS keyword.

```sql
SELECT 
    username AS handle,
    follower_count AS followers,
    following AS following_count
FROM instagram_users;
```

**Result:**
```
+---------------+-----------+-----------------+
| handle        | followers | following_count |
+---------------+-----------+-----------------+
| travel_sarah  | 125000    | 890            |
| tech_mike     | 45000     | 1200           |
| food_lover_23 | 78000     | 550            |
+---------------+-----------+-----------------+
```

**When to use aliases:**
- 📊 **Reports** - Make column names user-friendly
- 🧮 **Calculated fields** - Name formulas meaningfully  
- 🔄 **API responses** - Match frontend expectations
- 📋 **Dashboards** - Clear headers for stakeholders

**Pro tip:** The AS keyword is optional! These work the same:
```sql
SELECT username AS handle FROM users;
SELECT username handle FROM users;      -- Same result!
```

**Real-world example:** An e-commerce dashboard might show `revenue` instead of `order_total_amount_usd` for executives!
''',
            "immediate_practice": {
                "id": "aliases_practice", 
                "title": "🏃‍♂️ Quick Practice: Column Aliases",
                "type": "sql_practice",
                "practice_type": "aliases",
                "instructions": "Make these column names more user-friendly:",
                "tasks": [
                    {
                        "task": "Show username as 'Account Name' and email as 'Email Address'",
                        "expected_query": "SELECT username AS 'Account Name', email AS 'Email Address' FROM instagram_users;",
                        "hint": "Use quotes around alias names that contain spaces"
                    },
                    {
                        "task": "Show follower_count as 'Followers' and following as 'Following'",
                        "expected_query": "SELECT follower_count AS Followers, following AS Following FROM instagram_users;",
                        "hint": "Single-word aliases don't need quotes"
                    },
                    {
                        "task": "Create a user-friendly report with all columns renamed",
                        "expected_query": "SELECT username AS Username, email AS Email, follower_count AS Followers, following AS Following, verified AS Verified FROM instagram_users;",
                        "hint": "Rename each column to be more descriptive"
                    }
                ]
            },
            "comprehension_quiz": {
                "id": "aliases_quiz",
                "title": "🧠 Quick Check: Column Aliases",
                "questions": [
                    {
                        "question": "What's the purpose of column aliases?",
                        "options": [
                            "A) To make queries run faster",
                            "B) To make column names more readable",
                            "C) To hide sensitive data",
                            "D) To create new columns"
                        ],
                        "correct": "B",
                        "explanation": "Aliases rename columns in the result set to be more user-friendly or match specific requirements."
                    },
                    {
                        "question": "When do you need quotes around an alias?",
                        "options": [
                            "A) Always",
                            "B) Never", 
                            "C) When the alias contains spaces",
                            "D) Only for numbers"
                        ],
                        "correct": "C",
                        "explanation": "Aliases with spaces need quotes: 'First Name'. Single-word aliases don't: FirstName"
                    }
                ]
            }
        },
        {
            "topic": "Simple Calculations",
            "teaching_content": '''
### Simple Calculations in SELECT

You can perform calculations right in your SELECT statement! This is powerful for creating derived metrics.

```sql
SELECT 
    username,
    follower_count,
    following,
    follower_count - following AS net_followers,
    ROUND(follower_count / following, 2) AS follower_ratio
FROM instagram_users;
```

**Result:**
```
+---------------+----------------+-----------+---------------+-----------------+
| username      | follower_count | following | net_followers | follower_ratio  |
+---------------+----------------+-----------+---------------+-----------------+
| travel_sarah  | 125000         | 890       | 124110        | 140.45          |
| tech_mike     | 45000          | 1200      | 43800         | 37.50           |
| food_lover_23 | 78000          | 550       | 77450         | 141.82          |
+---------------+----------------+-----------+---------------+-----------------+
```

**Common calculations:**
- ➕ **Addition:** `price + tax AS total_price`
- ➖ **Subtraction:** `budget - spent AS remaining` 
- ✖️ **Multiplication:** `quantity * price AS line_total`
- ➗ **Division:** `completed / total AS completion_rate`

**Real-world examples:**
- **E-commerce:** Calculate profit margins, discounts, tax amounts
- **Analytics:** Conversion rates, growth percentages, averages
- **Finance:** Account balances, interest calculations
- **Social Media:** Engagement rates, follower ratios
''',
            "immediate_practice": {
                "id": "calculations_practice",
                "title": "🏃‍♂️ Quick Practice: Simple Calculations", 
                "type": "sql_practice",
                "practice_type": "calculations",
                "instructions": "Practice creating calculated columns:",
                "tasks": [
                    {
                        "task": "Calculate the difference between followers and following",
                        "expected_query": "SELECT username, follower_count - following AS net_followers FROM instagram_users;",
                        "hint": "Use subtraction (-) to find the difference"
                    },
                    {
                        "task": "Calculate follower-to-following ratio rounded to 1 decimal place",
                        "expected_query": "SELECT username, ROUND(follower_count / following, 1) AS ratio FROM instagram_users;",
                        "hint": "Use ROUND(number, decimal_places) function"
                    },
                    {
                        "task": "Show username and calculate total connections (followers + following)",
                        "expected_query": "SELECT username, follower_count + following AS total_connections FROM instagram_users;",
                        "hint": "Use addition (+) to sum two columns"
                    }
                ]
            },
            "comprehension_quiz": {
                "id": "calculations_quiz",
                "title": "🧠 Quick Check: Calculations",
                "questions": [
                    {
                        "question": "What does this calculate: price * quantity AS total",
                        "options": [
                            "A) Average price",
                            "B) Price per item",
                            "C) Total cost for all items",
                            "D) Quantity percentage"
                        ],
                        "correct": "C", 
                        "explanation": "Multiplying price by quantity gives the total cost: $10 × 5 items = $50 total"
                    },
                    {
                        "question": "How do you round 15.7839 to 2 decimal places in SQL?",
                        "options": [
                            "A) ROUND(15.7839)",
                            "B) ROUND(15.7839, 2)",
                            "C) DECIMAL(15.7839, 2)",
                            "D) TRUNCATE(15.7839)"
                        ],
                        "correct": "B",
                        "explanation": "ROUND(number, decimal_places) - so ROUND(15.7839, 2) = 15.78"
                    }
                ]
            }
        }
    ],
    "final_exercises": [
        {
            "id": "comprehensive_practice",
            "title": "🎯 Comprehensive Practice: Putting It All Together",
            "type": "sql_practice",
            "instructions": "Now combine everything you've learned:",
            "tasks": [
                {
                    "task": "Create an Instagram influencer report showing usernames, followers, and engagement metrics",
                    "requirements": [
                        "Show username as 'Influencer'",
                        "Show follower_count as 'Audience Size'", 
                        "Calculate follower-to-following ratio as 'Influence Score'",
                        "Round the ratio to 2 decimal places"
                    ],
                    "expected_query": "SELECT username AS Influencer, follower_count AS 'Audience Size', ROUND(follower_count / following, 2) AS 'Influence Score' FROM instagram_users;",
                    "hint": "Combine aliases, calculations, and rounding"
                }
            ]
        }
    ],
    "difficulty": "beginner",
    "estimated_time": 30,
    "is_free": False,
    "xp_reward": 75,
    "prerequisites": ["sql-introduction"],
    "key_concepts": [
        "Basic SELECT syntax with FROM",
        "SELECT * vs specific columns",
        "Column aliases with AS keyword", 
        "Simple arithmetic calculations",
        "ROUND function for decimal places",
        "Performance benefits of selective queries"
    ]
}