"""
Django Serialization lesson content
"""

DJANGO_SERIALIZATION_LESSON = {
    "id": 7,
    "chapter": 7,
    "title": "Django Serialization and Data Exchange",
    "slug": "django-serialization",
    "content": '''# Django Serialization and Data Exchange

## What is Serialization?

Serialization converts Django model instances into formats like JSON, XML, or YAML for storage or transmission. Deserialization converts serialized data back into Django objects.

### Why Serialization Matters

- **Data Export**: Export data for backups or migration
- **API Development**: Send data to frontend applications
- **Data Exchange**: Share data between systems
- **Fixtures**: Create test data for development
- **Caching**: Store complex objects in cache

## Basic Serialization

```python
from django.core import serializers
from books.models import Book

# Serialize to JSON
books = Book.objects.all()
json_data = serializers.serialize('json', books)

# Serialize specific fields
json_data = serializers.serialize('json', books, fields=['title', 'author', 'price'])

# Pretty-printed JSON
json_data = serializers.serialize('json', books, indent=2)
```

## Serialization Formats

Django supports multiple formats:

```python
# JSON (most common)
json_data = serializers.serialize('json', books)

# XML
xml_data = serializers.serialize('xml', books)

# YAML (requires PyYAML)
yaml_data = serializers.serialize('yaml', books)
```

## Deserialization

```python
# Deserialize JSON data
for obj in serializers.deserialize('json', json_data):
    obj.save()  # Save to database
    book = obj.object  # Get the actual object
```

## Natural Keys

Use human-readable identifiers:

```python
class Book(models.Model):
    isbn = models.CharField(max_length=13, unique=True)
    
    def natural_key(self):
        return (self.isbn,)
    
    def get_by_natural_key(self, isbn):
        return self.get(isbn=isbn)
```

## API Views

```python
def books_json(request):
    books = Book.objects.filter(available=True)
    data = serializers.serialize('json', books)
    return HttpResponse(data, content_type='application/json')
```

## Data Export

```python
def export_books_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="books.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['Title', 'Author', 'Price'])
    
    for book in Book.objects.all():
        writer.writerow([book.title, book.author, book.price])
    
    return response
```

## Best Practices

1. **Validate all input**: Always validate deserialized data
2. **Use appropriate formats**: JSON for APIs, CSV for exports
3. **Handle errors**: Graceful error handling for invalid data
4. **Performance**: Use select_related for foreign keys
5. **Security**: Validate and sanitize all input data

Master Django serialization for powerful data exchange! 🔄''',
    "is_free": True,
    "xp_reward": 50,
    "exercises": [
        {
            "id": "django-serialization",
            "title": "Build Data Export/Import System",
            "type": "project",
            "instructions": "Create a comprehensive data serialization system with export/import features, API endpoints, and natural keys.",
            "starter_code": "# Add natural keys to models and create export views",
            "solution": "# Complete implementation with serialization, API endpoints, and error handling",
            "test_cases": [
                {
                    "name": "Serialization system working",
                    "input": "",
                    "expected_contains": ["serialize", "deserialize", "natural_key"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "Use Django's built-in serializers module",
                "Implement natural_key methods for models",
                "Add proper error handling for deserialization"
            ]
        }
    ]
}