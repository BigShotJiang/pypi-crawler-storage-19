"""
Django Database - Lesson 1: Custom Managers and QuerySet Methods
Master Django's Manager system with real-world examples
"""

DJANGO_MANAGERS_LESSON = {
    "id": 44,
    "chapter": 44,
    "title": "Django Custom Managers: Power-Up Your Database Queries",
    "slug": "django-custom-managers",
    "description": "Master Django managers to create reusable, efficient database query patterns",
    "content": '''# Django Custom Managers: Your Database Query Powerhouse

## 🎯 What Are Django Managers?

A **Manager** is Django's interface between your models and the database. Think of it as your **personal database assistant** that knows exactly how to fetch the data you need.

Every Django model gets a default manager called `objects`:
```python
User.objects.all()          # Manager in action
Post.objects.filter(...)    # Manager methods
Product.objects.create(...) # Manager for creation
```

But here's where it gets exciting: **custom managers** let you build specialized query patterns that make your code cleaner, faster, and more maintainable.

## 📱 Real-World Example: Instagram's Content Management

Instagram likely uses custom managers to handle different types of content efficiently:

```python
class PostManager(models.Manager):
    def published(self):
        """Only show published posts"""
        return self.filter(status='published', is_active=True)
    
    def trending(self):
        """Posts with high engagement in last 24 hours"""
        return self.published().filter(
            created_at__gte=timezone.now() - timedelta(hours=24)
        ).annotate(
            engagement=F('likes_count') + F('comments_count')
        ).filter(engagement__gt=100).order_by('-engagement')
    
    def for_user_feed(self, user):
        """Personalized feed posts"""
        following_users = user.following.all()
        return self.published().filter(
            author__in=following_users
        ).select_related('author').prefetch_related('tags')

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, default='draft')
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Custom manager
    objects = PostManager()
```

Now Instagram developers can write clean, readable code:
```python
# Instead of complex filtering everywhere
trending_posts = Post.objects.trending()
user_feed = Post.objects.for_user_feed(request.user)
```

## 🗄️ Our E-commerce Database

Let's work with a comprehensive e-commerce database to practice custom managers:

```sql
-- Products table with inventory management
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2) NOT NULL,
    sku VARCHAR(50) UNIQUE NOT NULL,
    category_id INTEGER,
    brand VARCHAR(100),
    stock_quantity INTEGER DEFAULT 0,
    min_stock_level INTEGER DEFAULT 5,
    is_active BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,
    weight_grams INTEGER,
    rating_avg DECIMAL(3, 2) DEFAULT 0.00,
    rating_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample product data
INSERT INTO products (name, description, price, cost_price, sku, category_id, brand, stock_quantity, min_stock_level, is_featured, weight_grams, rating_avg, rating_count) VALUES 
('iPhone 15 Pro Max', 'Latest Apple flagship with titanium design', 1199.99, 800.00, 'IPH15PM-1TB', 1, 'Apple', 45, 10, true, 221, 4.8, 2847),
('MacBook Pro 16"', 'Professional laptop with M3 Max chip', 2499.99, 1800.00, 'MBP16-M3MAX', 2, 'Apple', 12, 5, true, 2140, 4.9, 1563),
('AirPods Pro 2', 'Premium wireless earbuds with ANC', 249.99, 150.00, 'APP2-WHITE', 3, 'Apple', 150, 20, false, 56, 4.7, 8924),
('Samsung Galaxy S24', 'Android flagship with AI features', 899.99, 600.00, 'SGS24-256GB', 1, 'Samsung', 78, 15, true, 168, 4.6, 3421),
('Sony WH-1000XM5', 'Industry-leading noise canceling headphones', 399.99, 250.00, 'WH1000XM5', 3, 'Sony', 25, 10, false, 250, 4.8, 5672),
('Dell XPS 13', 'Ultra-portable business laptop', 1299.99, 900.00, 'XPS13-I7', 2, 'Dell', 8, 5, false, 1200, 4.5, 892),
('Nintendo Switch OLED', 'Hybrid gaming console with OLED screen', 349.99, 200.00, 'NSW-OLED-WHITE', 4, 'Nintendo', 0, 10, true, 420, 4.7, 12453),
('Dyson V15 Detect', 'Cordless vacuum with laser detection', 749.99, 400.00, 'DV15-DETECT', 5, 'Dyson', 18, 8, false, 3100, 4.6, 2834);

-- Orders table for purchase history
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    customer_email VARCHAR(254) NOT NULL,
    customer_name VARCHAR(200),
    status VARCHAR(20) DEFAULT 'pending',
    total_amount DECIMAL(10, 2) NOT NULL,
    shipping_cost DECIMAL(10, 2) DEFAULT 0.00,
    tax_amount DECIMAL(10, 2) DEFAULT 0.00,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    payment_method VARCHAR(50),
    shipping_address TEXT,
    billing_address TEXT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_date TIMESTAMP,
    delivered_date TIMESTAMP,
    tracking_number VARCHAR(100)
);

-- Sample orders data
INSERT INTO orders (customer_email, customer_name, status, total_amount, shipping_cost, tax_amount, payment_method, order_date) VALUES 
('john.doe@email.com', 'John Doe', 'delivered', 1199.99, 0.00, 120.00, 'credit_card', '2024-11-15 10:30:00'),
('sarah.wilson@email.com', 'Sarah Wilson', 'shipped', 2499.99, 49.99, 250.00, 'paypal', '2024-12-01 14:22:00'),
('mike.chen@email.com', 'Mike Chen', 'pending', 899.99, 9.99, 90.00, 'credit_card', '2024-12-25 09:15:00'),
('lisa.brown@email.com', 'Lisa Brown', 'processing', 649.98, 0.00, 65.00, 'apple_pay', '2024-12-26 16:45:00'),
('david.garcia@email.com', 'David Garcia', 'delivered', 1299.99, 0.00, 130.00, 'credit_card', '2024-11-20 11:30:00');

-- Categories for product organization
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INTEGER,
    slug VARCHAR(100) UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

INSERT INTO categories (name, slug, description) VALUES 
(1, 'Smartphones', 'smartphones', 'Mobile phones and accessories'),
(2, 'Laptops', 'laptops', 'Portable computers and notebooks'),
(3, 'Audio', 'audio', 'Headphones, speakers, and audio equipment'),
(4, 'Gaming', 'gaming', 'Gaming consoles and accessories'),
(5, 'Home', 'home', 'Home appliances and smart devices');
```

## 🔧 Types of Custom Managers

### 1. Filtering Managers (Most Common)

**Scenario**: Amazon's product management

```python
class ProductManager(models.Manager):
    def active(self):
        """Only show active products"""
        return self.filter(is_active=True)
    
    def in_stock(self):
        """Products available for purchase"""
        return self.filter(stock_quantity__gt=0)
    
    def low_stock(self):
        """Products needing restocking"""
        return self.filter(
            stock_quantity__lte=F('min_stock_level'),
            is_active=True
        )
    
    def featured(self):
        """Featured products for homepage"""
        return self.active().filter(is_featured=True)
    
    def by_category(self, category_name):
        """Products in specific category"""
        return self.active().filter(
            category__slug=category_name.lower()
        )

class Product(models.Model):
    # ... fields ...
    objects = ProductManager()
```

### 2. Annotation Managers (Performance Boosters)

**Scenario**: Netflix's content recommendations

```python
class ProductManager(models.Manager):
    def with_profit_margin(self):
        """Add profit margin calculation"""
        return self.annotate(
            profit_margin=Case(
                When(cost_price=0, then=Value(0)),
                default=(F('price') - F('cost_price')) / F('price') * 100,
                output_field=DecimalField(max_digits=5, decimal_places=2)
            )
        )
    
    def with_inventory_status(self):
        """Add inventory status indicator"""
        return self.annotate(
            inventory_status=Case(
                When(stock_quantity=0, then=Value('out_of_stock')),
                When(stock_quantity__lte=F('min_stock_level'), then=Value('low_stock')),
                When(stock_quantity__lte=50, then=Value('moderate_stock')),
                default=Value('in_stock'),
                output_field=CharField(max_length=20)
            )
        )
    
    def popular(self):
        """Products with high ratings and reviews"""
        return self.filter(
            rating_count__gte=100,
            rating_avg__gte=4.0
        ).order_by('-rating_avg', '-rating_count')
```

### 3. Complex Query Managers

**Scenario**: Spotify's playlist management

```python
class OrderManager(models.Manager):
    def recent(self, days=30):
        """Orders from last N days"""
        cutoff_date = timezone.now() - timedelta(days=days)
        return self.filter(order_date__gte=cutoff_date)
    
    def high_value(self, min_amount=1000):
        """High-value orders"""
        return self.filter(total_amount__gte=min_amount)
    
    def completed_successfully(self):
        """Orders that were delivered successfully"""
        return self.filter(status='delivered')
    
    def monthly_revenue(self, year, month):
        """Revenue for specific month"""
        return self.filter(
            order_date__year=year,
            order_date__month=month,
            status='delivered'
        ).aggregate(
            total_revenue=Sum('total_amount'),
            total_orders=Count('id'),
            avg_order_value=Avg('total_amount')
        )

class Order(models.Model):
    # ... fields ...
    objects = OrderManager()
```

### 4. Performance-Optimized Managers

**Scenario**: Facebook's news feed optimization

```python
class ProductManager(models.Manager):
    def optimized_for_listing(self):
        """Optimized query for product listing pages"""
        return self.select_related('category').only(
            'id', 'name', 'price', 'sku', 'is_featured',
            'rating_avg', 'rating_count', 'category__name'
        )
    
    def with_related_data(self):
        """Preload related data to avoid N+1 queries"""
        return self.select_related('category').prefetch_related(
            'reviews__customer',
            'tags',
            'variants'
        )
    
    def search_optimized(self, query):
        """Full-text search with ranking"""
        return self.filter(
            Q(name__icontains=query) | 
            Q(description__icontains=query) |
            Q(brand__icontains=query)
        ).annotate(
            search_rank=Case(
                When(name__icontains=query, then=Value(3)),
                When(brand__icontains=query, then=Value(2)),
                default=Value(1),
                output_field=IntegerField()
            )
        ).order_by('-search_rank', '-rating_avg')
```

## 🏢 Real-World Manager Examples

### Airbnb's Listing Manager

```python
class ListingManager(models.Manager):
    def available_for_dates(self, start_date, end_date):
        """Available listings for date range"""
        return self.filter(is_active=True).exclude(
            bookings__start_date__lte=end_date,
            bookings__end_date__gte=start_date,
            bookings__status__in=['confirmed', 'checked_in']
        )
    
    def in_price_range(self, min_price, max_price):
        """Filter by price range"""
        return self.filter(
            price_per_night__gte=min_price,
            price_per_night__lte=max_price
        )
    
    def near_location(self, latitude, longitude, radius_km=10):
        """Find listings near coordinates"""
        # Using database-specific geo queries
        return self.filter(
            # Simplified distance calculation
            latitude__range=(latitude - 0.1, latitude + 0.1),
            longitude__range=(longitude - 0.1, longitude + 0.1)
        )
```

### Uber's Trip Manager

```python
class TripManager(models.Manager):
    def completed_trips(self):
        return self.filter(status='completed')
    
    def driver_earnings(self, driver, start_date, end_date):
        """Calculate driver earnings for period"""
        return self.completed_trips().filter(
            driver=driver,
            completed_at__range=(start_date, end_date)
        ).aggregate(
            total_earnings=Sum('driver_payout'),
            total_trips=Count('id'),
            avg_rating=Avg('driver_rating')
        )
    
    def surge_pricing_active(self):
        """Trips during surge pricing"""
        return self.filter(surge_multiplier__gt=1.0)
```

## 💡 Manager Best Practices

### 1. Keep Managers Focused
```python
# GOOD: Specific, reusable methods
class ProductManager(models.Manager):
    def featured(self):
        return self.filter(is_featured=True)
    
    def in_stock(self):
        return self.filter(stock_quantity__gt=0)

# BAD: Overly specific, not reusable
class ProductManager(models.Manager):
    def featured_iphones_under_1000_in_december(self):
        return self.filter(
            is_featured=True,
            brand='Apple',
            name__contains='iPhone',
            price__lt=1000,
            created_at__month=12
        )
```

### 2. Chain Manager Methods
```python
# Managers return QuerySets, so they're chainable
featured_affordable_products = Product.objects.featured().in_stock().filter(price__lt=500)
```

### 3. Combine with Model Methods
```python
class Product(models.Model):
    # ... fields ...
    objects = ProductManager()
    
    def is_low_stock(self):
        """Instance method for single product"""
        return self.stock_quantity <= self.min_stock_level
    
    @property
    def profit_margin_percent(self):
        if self.cost_price == 0:
            return 0
        return ((self.price - self.cost_price) / self.price) * 100
```

## 🎯 Key Takeaways

1. **Managers encapsulate common query patterns** - making code more readable and maintainable
2. **Chain manager methods** with additional filters for maximum flexibility
3. **Use annotations** in managers for computed fields to improve performance
4. **Keep manager methods focused** and reusable across your application
5. **Select and prefetch related data** in managers to optimize performance

Custom managers turn your models into powerful, efficient data access layers that scale with your application's growth!
''',
    "difficulty": "intermediate",
    "estimated_time": 35,
    "xp_reward": 20,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals"],
    "exercises": [
        {
            "id": "managers_1",
            "title": "Explore E-commerce Product Data",
            "prompt": "Let's start by examining our e-commerce product database. Write a query to see all products and their key information.",
            "table_name": "products",
            "initial_query": "SELECT * FROM products LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "products"],
            "hint": "Use SELECT * FROM products LIMIT 5; to see the product structure",
            "solution": "SELECT * FROM products LIMIT 5;",
            "explanation": "This shows our product table with fields like name, price, cost_price, stock_quantity, rating_avg, etc. These are the fields we'll use to create powerful manager methods for filtering and organizing product data."
        },
        {
            "id": "managers_2",
            "title": "Practice 'Active Products' Manager Logic",
            "prompt": "Custom managers often filter for 'active' items. Write a query to find all active products (where is_active = true).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "WHERE", "is_active", "true"],
            "hint": "Use WHERE is_active = true to filter for active products",
            "solution": "SELECT name, price, brand, stock_quantity FROM products WHERE is_active = true;",
            "explanation": "This simulates a ProductManager.active() method. In Django, this would be: return self.filter(is_active=True). Active filtering is one of the most common manager patterns."
        },
        {
            "id": "managers_3",
            "title": "Implement 'In Stock' Manager Logic",
            "prompt": "Another common manager method is 'in_stock'. Write a query to find products that have stock available (stock_quantity > 0).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "WHERE", "stock_quantity", ">", "0"],
            "hint": "Filter where stock_quantity is greater than 0",
            "solution": "SELECT name, price, stock_quantity, brand FROM products WHERE stock_quantity > 0 ORDER BY stock_quantity DESC;",
            "explanation": "This represents a ProductManager.in_stock() method. Notice the Nintendo Switch has 0 stock - it would be excluded. Manager methods like this prevent showing out-of-stock items to customers."
        },
        {
            "id": "managers_4",
            "title": "Find Low Stock Products (Manager Pattern)",
            "prompt": "Create a query for a 'low_stock' manager method. Find products where stock_quantity is less than or equal to min_stock_level.",
            "table_name": "products", 
            "expected_keywords": ["SELECT", "WHERE", "stock_quantity", "min_stock_level"],
            "hint": "Compare stock_quantity with min_stock_level using <=",
            "solution": "SELECT name, stock_quantity, min_stock_level, brand FROM products WHERE stock_quantity <= min_stock_level ORDER BY stock_quantity ASC;",
            "explanation": "This low_stock manager would help inventory managers identify products needing restocking. In Django: return self.filter(stock_quantity__lte=F('min_stock_level')). The F() expression compares fields within the same row."
        },
        {
            "id": "managers_5",
            "title": "Popular Products Manager Logic",
            "prompt": "Write a query for a 'popular' manager method. Find products with high ratings (rating_avg >= 4.5) and significant review counts (rating_count >= 1000).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "WHERE", "rating_avg", "rating_count", "AND"],
            "hint": "Use WHERE with AND to filter by both rating_avg >= 4.5 AND rating_count >= 1000",
            "solution": "SELECT name, rating_avg, rating_count, price, brand FROM products WHERE rating_avg >= 4.5 AND rating_count >= 1000 ORDER BY rating_avg DESC, rating_count DESC;",
            "explanation": "This popular() manager method finds products with both high ratings and significant review volume, ensuring quality and credibility. This pattern helps create 'Best Sellers' or 'Highly Rated' product sections."
        },
        {
            "id": "managers_6",
            "title": "Profit Margin Analysis (Annotation Pattern)",
            "prompt": "Manager methods often add calculated fields. Write a query that calculates profit margin percentage: ((price - cost_price) / price * 100).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "price", "cost_price", "*", "100"],
            "hint": "Calculate: (price - cost_price) / price * 100 to get profit margin percentage",
            "solution": "SELECT name, price, cost_price, ROUND(((price - cost_price) / price * 100), 2) as profit_margin_percent FROM products ORDER BY profit_margin_percent DESC;",
            "explanation": "This simulates a with_profit_margin() manager method using Django's annotate(). In Django: annotate(profit_margin=((F('price') - F('cost_price')) / F('price')) * 100). This helps identify most profitable products."
        }
    ],
    "key_concepts": [
        "Custom Manager Definition and Usage",
        "Filtering Manager Methods",
        "Annotation and Calculation Managers",
        "Performance-Optimized Queries",
        "Manager Method Chaining",
        "Real-World Manager Patterns",
        "QuerySet Optimization Techniques"
    ]
}