"""
Django Foundations - Lesson 4: Django Custom Management Commands
Master creating custom Django commands for automation and project-specific tasks
"""

DJANGO_CUSTOM_MANAGEMENT_COMMANDS_LESSON = {
    "id": 4,
    "chapter": 4,
    "title": "Django Custom Management Commands: Automation Mastery",
    "slug": "django-custom-management-commands",
    "description": "Learn to create powerful custom Django management commands for automation, data processing, scheduled tasks, and project-specific operations",
    "content": '''# Django Custom Management Commands: Automation Mastery

## 🎯 Extending Django's Command-Line Power

**Custom Django management commands** are your gateway to automating complex operations, processing data, and creating project-specific tools. Think of them as **Swiss Army knives** tailored specifically for your application's needs.

**Why Custom Commands Matter**:
- **Automation and scripting** → Automate repetitive tasks and complex operations
- **Data processing** → Import/export data, generate reports, clean databases
- **Scheduled operations** → Background tasks, cron jobs, and maintenance
- **Development utilities** → Code generation, testing helpers, debugging tools
- **Deployment automation** → Custom deployment steps and environment setup

Companies like **Instagram, Dropbox, and Slack** use hundreds of custom Django commands to manage their platforms, process user data, and maintain their systems.

## 💾 Custom Django Commands Database

Let's explore the ecosystem of custom Django management commands:

```sql
-- CUSTOM DJANGO MANAGEMENT COMMANDS
-- Database: django_custom_commands

-- Custom management commands across different projects
CREATE TABLE custom_django_commands (
    id SERIAL PRIMARY KEY,
    project_name VARCHAR(100) NOT NULL,
    app_name VARCHAR(100) NOT NULL,
    command_name VARCHAR(100) NOT NULL,
    command_category VARCHAR(50) NOT NULL, -- 'data_processing', 'automation', 'maintenance', 'development', 'deployment', 'reporting'
    description TEXT NOT NULL,
    author VARCHAR(100),
    created_date DATE DEFAULT CURRENT_DATE,
    last_modified DATE DEFAULT CURRENT_DATE,
    lines_of_code INTEGER DEFAULT 0,
    complexity_score INTEGER DEFAULT 1, -- 1-10 scale
    usage_frequency VARCHAR(20) DEFAULT 'medium', -- 'high', 'medium', 'low', 'rarely'
    execution_time_category VARCHAR(20) DEFAULT 'fast', -- 'instant', 'fast', 'medium', 'slow', 'long_running'
    requires_database BOOLEAN DEFAULT TRUE,
    requires_external_apis BOOLEAN DEFAULT FALSE,
    requires_file_access BOOLEAN DEFAULT FALSE,
    supports_dry_run BOOLEAN DEFAULT FALSE,
    supports_verbosity BOOLEAN DEFAULT TRUE,
    has_progress_bar BOOLEAN DEFAULT FALSE,
    is_production_safe BOOLEAN DEFAULT TRUE,
    dependencies TEXT[], -- External Python packages required
    example_usage TEXT,
    output_format VARCHAR(50) DEFAULT 'text' -- 'text', 'json', 'csv', 'html', 'email'
);

-- Sample custom commands from famous Django applications
INSERT INTO custom_django_commands (project_name, app_name, command_name, command_category, description, complexity_score, usage_frequency, execution_time_category, supports_dry_run, has_progress_bar, dependencies, example_usage) VALUES
-- Instagram-style commands
('Instagram Clone', 'photos', 'process_images', 'data_processing', 'Batch process and resize user uploaded images', 7, 'high', 'medium', TRUE, TRUE, ARRAY['Pillow', 'boto3'], 'python manage.py process_images --batch-size=100'),
('Instagram Clone', 'analytics', 'generate_user_report', 'reporting', 'Generate comprehensive user engagement reports', 8, 'medium', 'slow', TRUE, TRUE, ARRAY['pandas', 'matplotlib'], 'python manage.py generate_user_report --month=2024-01'),
('Instagram Clone', 'feed', 'rebuild_timelines', 'maintenance', 'Rebuild user timeline caches for all users', 9, 'low', 'long_running', TRUE, TRUE, ARRAY['redis', 'celery'], 'python manage.py rebuild_timelines --chunk-size=1000'),

-- Spotify-style commands
('Music Platform', 'music', 'import_catalog', 'data_processing', 'Import music catalog from external sources', 8, 'medium', 'long_running', TRUE, TRUE, ARRAY['requests', 'mutagen'], 'python manage.py import_catalog --source=spotify --limit=10000'),
('Music Platform', 'recommendations', 'train_ml_models', 'automation', 'Train machine learning recommendation models', 10, 'medium', 'long_running', FALSE, TRUE, ARRAY['scikit-learn', 'tensorflow'], 'python manage.py train_ml_models --algorithm=collaborative'),
('Music Platform', 'users', 'cleanup_inactive_users', 'maintenance', 'Remove inactive user accounts and associated data', 6, 'low', 'medium', TRUE, TRUE, ARRAY[], 'python manage.py cleanup_inactive_users --days=365 --dry-run'),

-- GitHub-style commands
('Code Platform', 'repositories', 'backup_repositories', 'automation', 'Backup all repositories to external storage', 7, 'high', 'long_running', FALSE, TRUE, ARRAY['boto3', 'git'], 'python manage.py backup_repositories --storage=s3'),
('Code Platform', 'users', 'send_digest_emails', 'automation', 'Send weekly digest emails to all active users', 5, 'high', 'fast', TRUE, FALSE, ARRAY['sendgrid'], 'python manage.py send_digest_emails --template=weekly'),
('Code Platform', 'monitoring', 'health_check', 'development', 'Comprehensive system health check', 4, 'high', 'fast', FALSE, FALSE, ARRAY[], 'python manage.py health_check --format=json'),

-- E-commerce platform commands
('E-commerce', 'orders', 'process_payments', 'automation', 'Process pending payment transactions', 8, 'high', 'medium', TRUE, TRUE, ARRAY['stripe', 'paypal-sdk'], 'python manage.py process_payments --provider=stripe'),
('E-commerce', 'inventory', 'sync_warehouse', 'data_processing', 'Synchronize inventory with warehouse systems', 7, 'high', 'medium', TRUE, TRUE, ARRAY['requests'], 'python manage.py sync_warehouse --warehouse=main'),
('E-commerce', 'analytics', 'sales_dashboard', 'reporting', 'Generate sales dashboard data', 6, 'medium', 'fast', FALSE, FALSE, ARRAY['pandas'], 'python manage.py sales_dashboard --period=last_week');

-- Command execution history and metrics
CREATE TABLE custom_command_executions (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    executed_by VARCHAR(100) NOT NULL,
    execution_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    execution_environment VARCHAR(50) NOT NULL, -- 'development', 'staging', 'production', 'cron'
    command_arguments TEXT,
    execution_time_seconds DECIMAL(10,2),
    exit_code INTEGER DEFAULT 0,
    success BOOLEAN DEFAULT TRUE,
    records_processed INTEGER DEFAULT 0,
    files_processed INTEGER DEFAULT 0,
    errors_encountered INTEGER DEFAULT 0,
    memory_usage_mb DECIMAL(10,2),
    cpu_usage_percent DECIMAL(5,2),
    output_size_kb INTEGER DEFAULT 0,
    error_message TEXT,
    warnings_count INTEGER DEFAULT 0,
    dry_run_mode BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (command_id) REFERENCES custom_django_commands(id)
);

-- Sample execution history
INSERT INTO custom_command_executions (command_id, executed_by, execution_environment, command_arguments, execution_time_seconds, records_processed, files_processed, memory_usage_mb) VALUES
(1, 'automation_user', 'production', '--batch-size=100 --format=webp', 1245.67, 15670, 15670, 2048.5),
(2, 'analyst', 'staging', '--month=2024-01 --format=pdf', 3567.89, 125000, 1, 4096.2),
(3, 'devops', 'production', '--chunk-size=1000 --workers=4', 7890.12, 2500000, 0, 8192.8),
(4, 'data_team', 'production', '--source=spotify --limit=10000', 5432.10, 10000, 10000, 1024.3),
(7, 'backup_service', 'production', '--storage=s3 --compress', 12345.67, 50000, 50000, 512.1),
(8, 'email_service', 'production', '--template=weekly --batch-size=500', 234.56, 25000, 0, 256.4);

-- Command argument definitions and validation
CREATE TABLE custom_command_arguments (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    argument_name VARCHAR(100) NOT NULL,
    argument_type VARCHAR(50) NOT NULL, -- 'positional', 'optional', 'flag'
    data_type VARCHAR(50) NOT NULL, -- 'string', 'integer', 'float', 'boolean', 'choice', 'file', 'date'
    is_required BOOLEAN DEFAULT FALSE,
    default_value TEXT,
    choices TEXT[], -- For choice-type arguments
    help_text TEXT NOT NULL,
    validation_regex VARCHAR(200),
    min_value DECIMAL(10,2),
    max_value DECIMAL(10,2),
    example_value TEXT,
    FOREIGN KEY (command_id) REFERENCES custom_django_commands(id)
);

-- Sample argument definitions
INSERT INTO custom_command_arguments (command_id, argument_name, argument_type, data_type, is_required, default_value, help_text, choices, example_value) VALUES
-- process_images command arguments
(1, 'batch_size', 'optional', 'integer', FALSE, '50', 'Number of images to process in each batch', NULL, '100'),
(1, 'format', 'optional', 'choice', FALSE, 'jpeg', 'Output image format', ARRAY['jpeg', 'webp', 'png'], 'webp'),
(1, 'quality', 'optional', 'integer', FALSE, '85', 'Image compression quality (1-100)', NULL, '90'),
(1, 'dry_run', 'flag', 'boolean', FALSE, 'false', 'Preview changes without executing', NULL, NULL),

-- generate_user_report arguments
(2, 'month', 'positional', 'date', TRUE, NULL, 'Month for report generation (YYYY-MM format)', NULL, '2024-01'),
(2, 'format', 'optional', 'choice', FALSE, 'html', 'Report output format', ARRAY['html', 'pdf', 'csv'], 'pdf'),
(2, 'email_recipients', 'optional', 'string', FALSE, NULL, 'Comma-separated list of email recipients', NULL, 'admin@company.com,manager@company.com'),

-- backup_repositories arguments  
(7, 'storage', 'optional', 'choice', FALSE, 'local', 'Backup storage destination', ARRAY['local', 's3', 'gcs'], 's3'),
(7, 'compress', 'flag', 'boolean', FALSE, 'false', 'Compress backup files', NULL, NULL),
(7, 'exclude_forks', 'flag', 'boolean', FALSE, 'false', 'Exclude forked repositories from backup', NULL, NULL);

-- Command templates and code patterns
CREATE TABLE custom_command_templates (
    id SERIAL PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL,
    template_category VARCHAR(50) NOT NULL, -- 'data_processing', 'reporting', 'maintenance', 'api_integration'
    description TEXT NOT NULL,
    use_case TEXT NOT NULL,
    code_template TEXT NOT NULL,
    required_imports TEXT[],
    best_practices TEXT[],
    common_patterns TEXT[],
    example_implementations TEXT[],
    complexity_level VARCHAR(20) DEFAULT 'intermediate' -- 'beginner', 'intermediate', 'advanced', 'expert'
);

-- Sample command templates
INSERT INTO custom_command_templates (template_name, template_category, description, use_case, code_template, required_imports, best_practices, common_patterns) VALUES
('Basic Data Processing Command', 'data_processing', 'Template for commands that process database records in batches', 'Bulk data updates, migrations, cleanup operations', 
'class Command(BaseCommand):
    help = "Process records in batches"
    
    def add_arguments(self, parser):
        parser.add_argument("--batch-size", type=int, default=1000)
        parser.add_argument("--dry-run", action="store_true")
    
    def handle(self, *args, **options):
        # Implementation here
        pass', 
ARRAY['django.core.management.base.BaseCommand', 'django.db import transaction'], 
ARRAY['Use transactions for data integrity', 'Implement dry-run mode', 'Add progress reporting', 'Handle errors gracefully'],
ARRAY['Batch processing with queryset.iterator()', 'Progress bars with tqdm', 'Error logging and recovery']),

('API Integration Command', 'api_integration', 'Template for commands that integrate with external APIs', 'Data synchronization, third-party service updates', 
'class Command(BaseCommand):
    help = "Integrate with external API"
    
    def add_arguments(self, parser):
        parser.add_argument("--api-key", required=True)
        parser.add_argument("--limit", type=int, default=100)
    
    def handle(self, *args, **options):
        # API integration logic
        pass',
ARRAY['requests', 'django.conf import settings', 'json'],
ARRAY['Rate limiting and retry logic', 'Secure API key handling', 'Response validation', 'Error handling for network issues'],
ARRAY['Pagination handling', 'Exponential backoff for retries', 'Response caching']);

-- Command scheduling and automation patterns
CREATE TABLE command_automation_patterns (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    automation_type VARCHAR(50) NOT NULL, -- 'cron', 'celery_periodic', 'kubernetes_cronjob', 'github_actions'
    schedule_expression VARCHAR(200) NOT NULL,
    execution_environment VARCHAR(50) NOT NULL,
    resource_requirements JSONB DEFAULT '{}'::jsonb,
    monitoring_enabled BOOLEAN DEFAULT TRUE,
    alert_on_failure BOOLEAN DEFAULT TRUE,
    max_execution_time_minutes INTEGER DEFAULT 60,
    retry_attempts INTEGER DEFAULT 3,
    retry_delay_seconds INTEGER DEFAULT 300,
    success_webhook_url VARCHAR(500),
    failure_webhook_url VARCHAR(500),
    configuration_notes TEXT,
    FOREIGN KEY (command_id) REFERENCES custom_django_commands(id)
);

-- Sample automation configurations
INSERT INTO command_automation_patterns (command_id, automation_type, schedule_expression, execution_environment, resource_requirements, max_execution_time_minutes, retry_attempts, configuration_notes) VALUES
(1, 'cron', '0 2 * * *', 'production', '{"memory": "2GB", "cpu": "1 core"}'::jsonb, 120, 2, 'Daily image processing at 2 AM UTC'),
(2, 'cron', '0 8 1 * *', 'production', '{"memory": "4GB", "cpu": "2 cores"}'::jsonb, 180, 1, 'Monthly report generation on 1st at 8 AM'),
(3, 'celery_periodic', '0 4 * * 0', 'production', '{"memory": "8GB", "cpu": "4 cores"}'::jsonb, 480, 1, 'Weekly timeline rebuild on Sundays at 4 AM'),
(8, 'cron', '0 9 * * 1', 'production', '{"memory": "512MB", "cpu": "0.5 cores"}'::jsonb, 30, 3, 'Weekly digest emails on Mondays at 9 AM');

-- Command performance and optimization metrics
CREATE TABLE command_performance_metrics (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    metric_date DATE DEFAULT CURRENT_DATE,
    avg_execution_time_seconds DECIMAL(10,2),
    min_execution_time_seconds DECIMAL(10,2),
    max_execution_time_seconds DECIMAL(10,2),
    avg_records_processed INTEGER DEFAULT 0,
    avg_memory_usage_mb DECIMAL(10,2),
    avg_cpu_usage_percent DECIMAL(5,2),
    success_rate_percent DECIMAL(5,2) DEFAULT 100.00,
    error_rate_percent DECIMAL(5,2) DEFAULT 0.00,
    total_executions INTEGER DEFAULT 0,
    performance_score INTEGER DEFAULT 100, -- 1-100 score based on efficiency
    optimization_suggestions TEXT[],
    bottleneck_analysis TEXT,
    FOREIGN KEY (command_id) REFERENCES custom_django_commands(id)
);

-- Sample performance metrics
INSERT INTO command_performance_metrics (command_id, avg_execution_time_seconds, avg_records_processed, avg_memory_usage_mb, success_rate_percent, total_executions, performance_score, optimization_suggestions) VALUES
(1, 1245.67, 15670, 2048.5, 98.5, 150, 85, ARRAY['Consider using multiprocessing', 'Implement image caching', 'Optimize database queries']),
(2, 3567.89, 125000, 4096.2, 99.2, 12, 78, ARRAY['Use database views for complex queries', 'Implement report caching', 'Consider pagination for large datasets']),
(3, 7890.12, 2500000, 8192.8, 95.8, 8, 72, ARRAY['Implement Redis pipelining', 'Use database connection pooling', 'Consider incremental updates']),
(7, 5432.10, 10000, 1024.3, 99.8, 45, 92, ARRAY['Implement parallel processing', 'Use compression for network transfer']);
```

## 🔧 Creating Powerful Custom Django Commands

### 1. Basic Command Structure and Patterns

**Scenario**: Instagram's image processing automation  
*Building robust, production-ready Django commands*

```python
# photos/management/commands/process_images.py
# Instagram-style image processing command

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.conf import settings
from photos.models import Photo
from PIL import Image
import boto3
import os
import time
from tqdm import tqdm
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    """
    Process and optimize user uploaded images
    Used by Instagram for batch image processing and format conversion
    """
    help = 'Process and optimize user uploaded images in batches'
    
    def add_arguments(self, parser):
        """Define command-line arguments"""
        
        # Required arguments
        parser.add_argument(
            '--batch-size',
            type=int,
            default=100,
            help='Number of images to process in each batch (default: 100)'
        )
        
        # Optional arguments with choices
        parser.add_argument(
            '--format',
            choices=['jpeg', 'webp', 'png'],
            default='jpeg',
            help='Output image format (default: jpeg)'
        )
        
        parser.add_argument(
            '--quality',
            type=int,
            default=85,
            help='Image compression quality 1-100 (default: 85)'
        )
        
        # Boolean flags
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Preview changes without actually processing images'
        )
        
        parser.add_argument(
            '--force',
            action='store_true',
            help='Force reprocessing of already processed images'
        )
        
        # Filter options
        parser.add_argument(
            '--user-id',
            type=int,
            help='Process images for specific user only'
        )
        
        parser.add_argument(
            '--created-after',
            type=str,
            help='Process images created after date (YYYY-MM-DD)'
        )
        
        # Output options
        parser.add_argument(
            '--output-format',
            choices=['text', 'json'],
            default='text',
            help='Output format for results (default: text)'
        )
    
    def handle(self, *args, **options):
        """Main command execution"""
        
        # Validate arguments
        self.validate_arguments(options)
        
        # Initialize processing
        self.setup_processing(options)
        
        try:
            # Get images to process
            photos_queryset = self.get_photos_queryset(options)
            
            if options['dry_run']:
                self.stdout.write(
                    self.style.WARNING(
                        f'DRY RUN: Would process {photos_queryset.count()} images'
                    )
                )
                return
            
            # Process images in batches
            self.process_images_in_batches(photos_queryset, options)
            
        except Exception as e:
            logger.error(f'Image processing failed: {e}')
            raise CommandError(f'Processing failed: {e}')
    
    def validate_arguments(self, options):
        """Validate command arguments"""
        
        if options['quality'] < 1 or options['quality'] > 100:
            raise CommandError('Quality must be between 1 and 100')
        
        if options['batch_size'] < 1 or options['batch_size'] > 1000:
            raise CommandError('Batch size must be between 1 and 1000')
        
        # Validate date format if provided
        if options['created_after']:
            try:
                from datetime import datetime
                datetime.strptime(options['created_after'], '%Y-%m-%d')
            except ValueError:
                raise CommandError('Date must be in YYYY-MM-DD format')
    
    def setup_processing(self, options):
        """Initialize processing environment"""
        
        # Setup AWS S3 client if needed
        if hasattr(settings, 'AWS_STORAGE_BUCKET_NAME'):
            self.s3_client = boto3.client('s3')
            self.bucket_name = settings.AWS_STORAGE_BUCKET_NAME
        else:
            self.s3_client = None
        
        # Initialize statistics
        self.stats = {
            'processed': 0,
            'skipped': 0,
            'errors': 0,
            'start_time': time.time()
        }
    
    def get_photos_queryset(self, options):
        """Build queryset for photos to process"""
        
        queryset = Photo.objects.all()
        
        # Filter by user if specified
        if options['user_id']:
            queryset = queryset.filter(user_id=options['user_id'])
        
        # Filter by creation date
        if options['created_after']:
            from datetime import datetime
            date_filter = datetime.strptime(options['created_after'], '%Y-%m-%d').date()
            queryset = queryset.filter(created_at__date__gte=date_filter)
        
        # Skip already processed images unless force is used
        if not options['force']:
            queryset = queryset.filter(is_processed=False)
        
        return queryset.select_related('user').order_by('id')
    
    def process_images_in_batches(self, queryset, options):
        """Process images in batches with progress tracking"""
        
        total_count = queryset.count()
        batch_size = options['batch_size']
        
        self.stdout.write(f'Processing {total_count} images in batches of {batch_size}...')
        
        # Create progress bar
        with tqdm(total=total_count, desc="Processing images") as pbar:
            
            # Process in batches to avoid memory issues
            for offset in range(0, total_count, batch_size):
                batch = queryset[offset:offset + batch_size]
                
                with transaction.atomic():
                    for photo in batch:
                        try:
                            self.process_single_image(photo, options)
                            self.stats['processed'] += 1
                            
                        except Exception as e:
                            logger.error(f'Failed to process image {photo.id}: {e}')
                            self.stats['errors'] += 1
                        
                        pbar.update(1)
                
                # Brief pause to avoid overwhelming the system
                time.sleep(0.1)
        
        # Output final statistics
        self.output_statistics(options)
    
    def process_single_image(self, photo, options):
        """Process a single image with optimization"""
        
        # Skip if already processed and not forcing
        if photo.is_processed and not options['force']:
            self.stats['skipped'] += 1
            return
        
        # Download image from storage
        image_path = self.download_image(photo)
        
        try:
            # Open and process image
            with Image.open(image_path) as img:
                
                # Convert to RGB if necessary
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # Resize if too large (Instagram max: 1080px)
                max_size = 1080
                if img.width > max_size or img.height > max_size:
                    img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
                
                # Save with optimization
                output_path = self.get_output_path(photo, options['format'])
                
                save_kwargs = {
                    'format': options['format'].upper(),
                    'quality': options['quality'],
                    'optimize': True
                }
                
                if options['format'] == 'jpeg':
                    save_kwargs['progressive'] = True
                
                img.save(output_path, **save_kwargs)
            
            # Upload processed image
            self.upload_processed_image(photo, output_path, options)
            
            # Update database
            photo.is_processed = True
            photo.processed_format = options['format']
            photo.save(update_fields=['is_processed', 'processed_format'])
            
        finally:
            # Cleanup temporary files
            self.cleanup_temp_files([image_path, output_path])
    
    def download_image(self, photo):
        """Download image from storage for processing"""
        
        if self.s3_client:
            # Download from S3
            temp_path = f'/tmp/image_{photo.id}_original.jpg'
            self.s3_client.download_file(
                self.bucket_name,
                photo.image.name,
                temp_path
            )
            return temp_path
        else:
            # Use local file
            return photo.image.path
    
    def get_output_path(self, photo, format_type):
        """Get output path for processed image"""
        return f'/tmp/image_{photo.id}_processed.{format_type}'
    
    def upload_processed_image(self, photo, processed_path, options):
        """Upload processed image to storage"""
        
        if self.s3_client:
            # Upload to S3
            key = f'processed/{photo.id}.{options["format"]}'
            self.s3_client.upload_file(
                processed_path,
                self.bucket_name,
                key,
                ExtraArgs={'ContentType': f'image/{options["format"]}'}
            )
    
    def cleanup_temp_files(self, file_paths):
        """Remove temporary files"""
        for path in file_paths:
            try:
                if path and os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass  # File might already be removed
    
    def output_statistics(self, options):
        """Output processing statistics"""
        
        elapsed_time = time.time() - self.stats['start_time']
        
        if options['output_format'] == 'json':
            import json
            stats_output = {
                'processed': self.stats['processed'],
                'skipped': self.stats['skipped'],
                'errors': self.stats['errors'],
                'elapsed_time_seconds': round(elapsed_time, 2),
                'processing_rate': round(self.stats['processed'] / elapsed_time, 2)
            }
            self.stdout.write(json.dumps(stats_output, indent=2))
            
        else:
            # Text format
            self.stdout.write('\n' + '='*50)
            self.stdout.write(self.style.SUCCESS('PROCESSING COMPLETE'))
            self.stdout.write('='*50)
            self.stdout.write(f'Images processed: {self.stats["processed"]}')
            self.stdout.write(f'Images skipped: {self.stats["skipped"]}')
            self.stdout.write(f'Errors encountered: {self.stats["errors"]}')
            self.stdout.write(f'Elapsed time: {elapsed_time:.2f} seconds')
            self.stdout.write(f'Processing rate: {self.stats["processed"] / elapsed_time:.2f} images/sec')
            
            if self.stats['errors'] > 0:
                self.stdout.write(
                    self.style.WARNING(
                        f'Check logs for {self.stats["errors"]} error details'
                    )
                )
```

### 2. Advanced Data Processing Command

**Scenario**: Spotify's analytics and reporting system

```python
# analytics/management/commands/generate_user_report.py
# Spotify-style user engagement analytics

from django.core.management.base import BaseCommand, CommandError
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
from django.db import connection
from django.conf import settings
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import tempfile
import os
import json

class Command(BaseCommand):
    """
    Generate comprehensive user engagement reports
    Used by Spotify for monthly analytics and business intelligence
    """
    help = 'Generate detailed user engagement and analytics reports'
    
    def add_arguments(self, parser):
        """Define command arguments for flexible report generation"""
        
        # Required positional argument
        parser.add_argument(
            'report_month',
            type=str,
            help='Report month in YYYY-MM format (e.g., 2024-01)'
        )
        
        # Report format options
        parser.add_argument(
            '--format',
            choices=['html', 'pdf', 'csv', 'json'],
            default='html',
            help='Report output format (default: html)'
        )
        
        # Email delivery
        parser.add_argument(
            '--email',
            type=str,
            help='Comma-separated list of email recipients'
        )
        
        # Report sections
        parser.add_argument(
            '--sections',
            nargs='+',
            choices=['overview', 'engagement', 'demographics', 'retention', 'growth'],
            default=['overview', 'engagement', 'retention'],
            help='Report sections to include'
        )
        
        # Data filters
        parser.add_argument(
            '--user-segment',
            choices=['all', 'premium', 'free', 'new'],
            default='all',
            help='User segment to analyze'
        )
        
        parser.add_argument(
            '--include-charts',
            action='store_true',
            help='Include data visualization charts'
        )
        
        # Output options
        parser.add_argument(
            '--output-dir',
            type=str,
            default='/tmp/reports',
            help='Directory to save generated reports'
        )
        
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Generate report without sending emails or saving files'
        )
    
    def handle(self, *args, **options):
        """Main report generation logic"""
        
        # Validate and parse arguments
        self.validate_arguments(options)
        
        # Setup report generation
        self.setup_report_generation(options)
        
        try:
            # Generate report data
            report_data = self.generate_report_data(options)
            
            # Create visualizations if requested
            if options['include_charts']:
                chart_paths = self.generate_charts(report_data, options)
                report_data['charts'] = chart_paths
            
            # Generate report in requested format
            report_content = self.generate_report_content(report_data, options)
            
            # Save or email report
            if not options['dry_run']:
                self.deliver_report(report_content, options)
            
            self.output_success_message(options)
            
        except Exception as e:
            self.stderr.write(f'Report generation failed: {e}')
            raise CommandError(f'Failed to generate report: {e}')
    
    def validate_arguments(self, options):
        """Validate command arguments"""
        
        # Validate month format
        try:
            self.report_date = datetime.strptime(options['report_month'], '%Y-%m')
        except ValueError:
            raise CommandError('Report month must be in YYYY-MM format')
        
        # Check if report month is not in the future
        if self.report_date > datetime.now():
            raise CommandError('Cannot generate reports for future months')
        
        # Validate email addresses if provided
        if options['email']:
            import re
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'
            emails = [email.strip() for email in options['email'].split(',')]
            
            for email in emails:
                if not re.match(email_pattern, email):
                    raise CommandError(f'Invalid email address: {email}')
    
    def setup_report_generation(self, options):
        """Initialize report generation environment"""
        
        # Create output directory if it doesn't exist
        os.makedirs(options['output_dir'], exist_ok=True)
        
        # Set matplotlib backend for headless operation
        plt.switch_backend('Agg')
        
        # Configure seaborn for professional charts
        sns.set_style('whitegrid')
        sns.set_palette('husl')
        
        # Calculate date ranges
        self.month_start = self.report_date.replace(day=1)
        self.month_end = (self.month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        self.previous_month_start = (self.month_start - timedelta(days=1)).replace(day=1)
        self.previous_month_end = self.month_start - timedelta(days=1)
    
    def generate_report_data(self, options):
        """Generate comprehensive report data"""
        
        self.stdout.write('Generating report data...')
        
        report_data = {
            'report_month': options['report_month'],
            'generation_date': datetime.now().isoformat(),
            'user_segment': options['user_segment'],
            'sections': {}
        }
        
        # Generate data for each requested section
        for section in options['sections']:
            self.stdout.write(f'Processing {section} section...')
            
            if section == 'overview':
                report_data['sections']['overview'] = self.generate_overview_data(options)
            elif section == 'engagement':
                report_data['sections']['engagement'] = self.generate_engagement_data(options)
            elif section == 'demographics':
                report_data['sections']['demographics'] = self.generate_demographics_data(options)
            elif section == 'retention':
                report_data['sections']['retention'] = self.generate_retention_data(options)
            elif section == 'growth':
                report_data['sections']['growth'] = self.generate_growth_data(options)
        
        return report_data
    
    def generate_overview_data(self, options):
        """Generate overview section data"""
        
        with connection.cursor() as cursor:
            # Total active users
            cursor.execute("""
                SELECT COUNT(DISTINCT user_id) as active_users
                FROM user_activity 
                WHERE activity_date BETWEEN %s AND %s
            """, [self.month_start, self.month_end])
            
            active_users = cursor.fetchone()[0]
            
            # Previous month comparison
            cursor.execute("""
                SELECT COUNT(DISTINCT user_id) as active_users
                FROM user_activity 
                WHERE activity_date BETWEEN %s AND %s
            """, [self.previous_month_start, self.previous_month_end])
            
            previous_active_users = cursor.fetchone()[0]
            
            # Total streaming hours
            cursor.execute("""
                SELECT SUM(listening_duration_minutes) / 60.0 as total_hours
                FROM listening_sessions 
                WHERE created_at BETWEEN %s AND %s
            """, [self.month_start, self.month_end])
            
            total_hours = cursor.fetchone()[0] or 0
        
        return {
            'active_users': active_users,
            'previous_active_users': previous_active_users,
            'user_growth_percent': ((active_users - previous_active_users) / previous_active_users) * 100 if previous_active_users > 0 else 0,
            'total_streaming_hours': round(total_hours, 2),
            'avg_hours_per_user': round(total_hours / active_users, 2) if active_users > 0 else 0
        }
    
    def generate_engagement_data(self, options):
        """Generate user engagement metrics"""
        
        # Use pandas for complex analytics
        query = """
            SELECT 
                user_id,
                COUNT(*) as session_count,
                SUM(listening_duration_minutes) as total_listening_time,
                COUNT(DISTINCT DATE(created_at)) as active_days
            FROM listening_sessions 
            WHERE created_at BETWEEN %s AND %s
            GROUP BY user_id
        """
        
        df = pd.read_sql(query, connection, params=[self.month_start, self.month_end])
        
        return {
            'avg_sessions_per_user': round(df['session_count'].mean(), 2),
            'median_sessions_per_user': round(df['session_count'].median(), 2),
            'avg_listening_time_per_user': round(df['total_listening_time'].mean(), 2),
            'highly_engaged_users': len(df[df['active_days'] >= 20]),  # Active 20+ days
            'engagement_distribution': {
                'low': len(df[df['active_days'] < 5]),
                'medium': len(df[(df['active_days'] >= 5) & (df['active_days'] < 15)]),
                'high': len(df[df['active_days'] >= 15])
            }
        }
    
    def generate_retention_data(self, options):
        """Generate user retention analysis"""
        
        # Cohort analysis for retention
        query = """
            WITH user_cohorts AS (
                SELECT 
                    user_id,
                    DATE_TRUNC('month', first_activity_date) as cohort_month
                FROM (
                    SELECT 
                        user_id,
                        MIN(activity_date) as first_activity_date
                    FROM user_activity
                    GROUP BY user_id
                ) first_activity
            ),
            user_activity_monthly AS (
                SELECT 
                    user_id,
                    DATE_TRUNC('month', activity_date) as activity_month
                FROM user_activity
                WHERE activity_date BETWEEN %s AND %s
                GROUP BY user_id, DATE_TRUNC('month', activity_date)
            )
            SELECT 
                uc.cohort_month,
                COUNT(DISTINCT uc.user_id) as cohort_size,
                COUNT(DISTINCT uam.user_id) as retained_users
            FROM user_cohorts uc
            LEFT JOIN user_activity_monthly uam ON uc.user_id = uam.user_id 
                AND uam.activity_month = %s
            WHERE uc.cohort_month <= %s
            GROUP BY uc.cohort_month
            ORDER BY uc.cohort_month
        """
        
        df = pd.read_sql(query, connection, params=[
            self.month_start, self.month_end, self.month_start, self.month_start
        ])
        
        # Calculate retention rates
        df['retention_rate'] = (df['retained_users'] / df['cohort_size']) * 100
        
        return {
            'overall_retention_rate': round(df['retention_rate'].mean(), 2),
            'cohort_retention_data': df.to_dict('records')
        }
    
    def generate_charts(self, report_data, options):
        """Generate data visualization charts"""
        
        self.stdout.write('Generating charts...')
        chart_paths = {}
        
        if 'engagement' in report_data['sections']:
            chart_paths['engagement_distribution'] = self.create_engagement_chart(
                report_data['sections']['engagement'], options
            )
        
        if 'retention' in report_data['sections']:
            chart_paths['retention_trend'] = self.create_retention_chart(
                report_data['sections']['retention'], options
            )
        
        return chart_paths
    
    def create_engagement_chart(self, engagement_data, options):
        """Create engagement distribution pie chart"""
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        labels = ['Low Engagement', 'Medium Engagement', 'High Engagement']
        sizes = [
            engagement_data['engagement_distribution']['low'],
            engagement_data['engagement_distribution']['medium'],
            engagement_data['engagement_distribution']['high']
        ]
        
        colors = ['#ff9999', '#66b3ff', '#99ff99']
        
        ax.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
        ax.set_title(f'User Engagement Distribution - {options["report_month"]}')
        
        chart_path = os.path.join(options['output_dir'], 'engagement_distribution.png')
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def generate_report_content(self, report_data, options):
        """Generate report content in requested format"""
        
        if options['format'] == 'json':
            return json.dumps(report_data, indent=2, default=str)
        
        elif options['format'] == 'html':
            return render_to_string('reports/user_engagement_report.html', {
                'report_data': report_data,
                'include_charts': options['include_charts']
            })
        
        elif options['format'] == 'csv':
            return self.generate_csv_report(report_data)
        
        # Add PDF generation logic here if needed
        
        return str(report_data)  # Fallback
    
    def deliver_report(self, report_content, options):
        """Save report and send via email if requested"""
        
        # Save report to file
        filename = f"user_report_{options['report_month']}.{options['format']}"
        filepath = os.path.join(options['output_dir'], filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        self.stdout.write(f'Report saved to: {filepath}')
        
        # Send email if recipients specified
        if options['email']:
            self.send_email_report(report_content, filepath, options)
    
    def send_email_report(self, report_content, filepath, options):
        """Send report via email"""
        
        recipients = [email.strip() for email in options['email'].split(',')]
        
        email = EmailMessage(
            subject=f'User Engagement Report - {options["report_month"]}',
            body=f'Please find the attached user engagement report for {options["report_month"]}.',
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=recipients
        )
        
        # Attach report file
        email.attach_file(filepath)
        
        # Attach charts if generated
        if 'charts' in report_content:
            for chart_name, chart_path in report_content['charts'].items():
                email.attach_file(chart_path)
        
        email.send()
        
        self.stdout.write(f'Report emailed to: {", ".join(recipients)}')
    
    def output_success_message(self, options):
        """Output success message with summary"""
        
        self.stdout.write('\n' + '='*60)
        self.stdout.write(self.style.SUCCESS('REPORT GENERATION COMPLETE'))
        self.stdout.write('='*60)
        self.stdout.write(f'Report month: {options["report_month"]}')
        self.stdout.write(f'Format: {options["format"]}')
        self.stdout.write(f'Sections: {", ".join(options["sections"])}')
        self.stdout.write(f'User segment: {options["user_segment"]}')
        
        if options['dry_run']:
            self.stdout.write(self.style.WARNING('DRY RUN: No files saved or emails sent'))
```

## 🎯 Key Takeaways

1. **Custom commands extend Django's functionality** → Create project-specific automation tools
2. **Use BaseCommand for consistent structure** → Leverage Django's command framework
3. **Add comprehensive argument handling** → Support flexible command-line interfaces
4. **Implement proper error handling** → Graceful failures with meaningful messages
5. **Support dry-run mode** → Test command behavior safely
6. **Include progress reporting** → Use progress bars for long-running operations
7. **Design for production use** → Consider performance, monitoring, and automation

Master custom Django commands to automate complex operations and build powerful development tools!
''',
    "difficulty": "intermediate", 
    "estimated_time": 45,
    "xp_reward": 30,
    "prerequisites": ["django-settings", "django-applications", "django-admin-commands"],
    "exercises": [
        {
            "id": "django_custom_commands_1",
            "title": "Explore Custom Django Commands Ecosystem",
            "prompt": "Let's examine custom Django commands used by major applications. Write a query to see command categories and complexity.",
            "table_name": "custom_django_commands",
            "initial_query": "SELECT * FROM custom_django_commands LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "custom_django_commands"],
            "hint": "Use SELECT * FROM custom_django_commands LIMIT 5; to see custom command examples",
            "solution": "SELECT * FROM custom_django_commands LIMIT 5;",
            "explanation": "Custom Django commands span various categories from data processing to automation. Notice how complexity scores reflect the sophistication of operations, and usage frequency indicates their importance in development workflows."
        },
        {
            "id": "django_custom_commands_2", 
            "title": "Command Execution Analysis",
            "prompt": "Analyze custom command execution patterns and performance. Write a query to see execution metrics.",
            "table_name": "custom_command_executions",
            "expected_keywords": ["SELECT", "command_id", "execution_time_seconds", "records_processed", "success"],
            "hint": "Join with custom commands table to see command names and execution details",
            "solution": "SELECT cdc.command_name, cce.execution_environment, cce.execution_time_seconds, cce.records_processed, cce.files_processed, cce.success FROM custom_command_executions cce JOIN custom_django_commands cdc ON cce.command_id = cdc.id ORDER BY cce.execution_time_seconds DESC;",
            "explanation": "Execution logs reveal performance characteristics of custom commands. Long-running commands like timeline rebuilds process millions of records, while simpler commands like health checks execute quickly. Success rates help identify reliable vs. problematic commands."
        },
        {
            "id": "django_custom_commands_3",
            "title": "Command Arguments and Configuration",
            "prompt": "Examine how custom commands handle arguments and options. Write a query to see argument definitions.",
            "table_name": "custom_command_arguments", 
            "expected_keywords": ["SELECT", "command_id", "argument_name", "argument_type", "data_type", "is_required"],
            "hint": "Group by command to see how arguments are structured for different commands",
            "solution": "SELECT cdc.command_name, cca.argument_name, cca.argument_type, cca.data_type, cca.is_required, cca.help_text, cca.example_value FROM custom_command_arguments cca JOIN custom_django_commands cdc ON cca.command_id = cdc.id WHERE cdc.command_name IN ('process_images', 'generate_user_report') ORDER BY cdc.command_name, cca.argument_name;",
            "explanation": "Command arguments provide flexibility and control. Notice how commands use different argument types (positional, optional, flags) and data types (string, integer, choice) to create rich command-line interfaces similar to built-in Django commands."
        },
        {
            "id": "django_custom_commands_4",
            "title": "Command Templates and Patterns",
            "prompt": "Explore reusable command templates and patterns. Write a query to see template categories.",
            "table_name": "custom_command_templates",
            "expected_keywords": ["SELECT", "template_name", "template_category", "complexity_level", "best_practices"],
            "hint": "Look at different template categories and their complexity levels",
            "solution": "SELECT template_name, template_category, complexity_level, description, use_case FROM custom_command_templates ORDER BY template_category, complexity_level;",
            "explanation": "Command templates provide reusable patterns for common operations. Data processing templates handle batch operations, while API integration templates manage external service communication. Best practices ensure reliable and maintainable commands."
        },
        {
            "id": "django_custom_commands_5",
            "title": "Command Automation and Scheduling",
            "prompt": "Analyze how custom commands are automated and scheduled. Write a query to see automation patterns.",
            "table_name": "command_automation_patterns",
            "expected_keywords": ["SELECT", "command_id", "automation_type", "schedule_expression", "execution_environment"],
            "hint": "Join with commands to see which commands are automated and how",
            "solution": "SELECT cdc.command_name, cap.automation_type, cap.schedule_expression, cap.execution_environment, cap.max_execution_time_minutes, cap.retry_attempts FROM command_automation_patterns cap JOIN custom_django_commands cdc ON cap.command_id = cdc.id ORDER BY cap.automation_type, cap.schedule_expression;",
            "explanation": "Command automation patterns show how custom commands integrate into production workflows. Cron schedules handle regular maintenance, while Celery periodic tasks manage complex distributed operations. Resource requirements and retry logic ensure reliable automation."
        },
        {
            "id": "django_custom_commands_6",
            "title": "Command Performance Optimization",
            "prompt": "Examine command performance metrics and optimization suggestions. Write a query to see performance data.",
            "table_name": "command_performance_metrics",
            "expected_keywords": ["SELECT", "command_id", "avg_execution_time_seconds", "performance_score", "optimization_suggestions"],
            "hint": "Look for commands with low performance scores and their optimization suggestions",
            "solution": "SELECT cdc.command_name, cpm.avg_execution_time_seconds, cpm.success_rate_percent, cpm.performance_score, cpm.optimization_suggestions FROM command_performance_metrics cpm JOIN custom_django_commands cdc ON cpm.command_id = cdc.id WHERE cpm.performance_score < 90 ORDER BY cpm.performance_score ASC;",
            "explanation": "Performance metrics identify optimization opportunities for custom commands. Lower performance scores indicate commands that could benefit from improvements like multiprocessing, caching, or database optimization. These insights guide development priorities."
        }
    ],
    "key_concepts": [
        "Custom Django Command Architecture and Structure",
        "Command Arguments and Option Handling",
        "Error Handling and Validation Patterns", 
        "Progress Tracking and User Feedback",
        "Batch Processing and Performance Optimization",
        "Dry-Run Mode and Safe Execution",
        "Command Automation and Scheduling",
        "Production Deployment and Monitoring"
    ]
}