"""
Django Settings and Configuration lesson content
"""

DJANGO_SETTINGS_LESSON = {
    "id": 8,
    "chapter": 8,
    "title": "Django Settings and Configuration",
    "slug": "django-settings",
    "content": '''
# Django Settings and Configuration

## What are Django Settings?

Django settings are Python variables that configure Django's behavior. The settings module is the central configuration point for your Django project, controlling everything from database connections to security settings.

### Why Settings Matter

- **Environment Configuration**: Different settings for development, staging, and production
- **Security**: Configure security-related settings properly
- **Database Configuration**: Set up database connections
- **Static Files**: Configure static file handling
- **Third-party Integration**: Configure external services
- **Performance**: Optimize Django for your specific needs

## The Basics

### Default Settings Module

Django uses the `DJANGO_SETTINGS_MODULE` environment variable to locate your settings:

```python
# Default location: myproject/settings.py
DJANGO_SETTINGS_MODULE = 'myproject.settings'
```

### Basic Settings Structure

```python
# bookstore/settings.py
import os
from pathlib import Path

# Build paths inside the project
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'your-secret-key-here'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Local apps
    'books.apps.BooksConfig',
    'accounts.apps.AccountsConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'bookstore.urls'

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'

# Media files (user uploads)
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
```

## Environment-Based Settings

### Multiple Settings Files

Organize settings for different environments:

```
bookstore/
    settings/
        __init__.py
        base.py        # Common settings
        development.py # Development settings
        staging.py     # Staging settings
        production.py  # Production settings
        testing.py     # Test settings
```

### Base Settings

```python
# bookstore/settings/base.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Apps common to all environments
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party apps
    'rest_framework',
    
    # Local apps
    'books.apps.BooksConfig',
    'accounts.apps.AccountsConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'bookstore.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 8,}
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
```

### Development Settings

```python
# bookstore/settings/development.py
from .base import *
import os

# Development-specific settings
DEBUG = True

SECRET_KEY = 'dev-secret-key-not-for-production'

ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Development database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Development email backend (prints to console)
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Development logging
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
        },
        'books': {
            'handlers': ['console'],
            'level': 'DEBUG',
        },
    },
}

# Debug toolbar for development
INSTALLED_APPS += ['debug_toolbar']
MIDDLEWARE += ['debug_toolbar.middleware.DebugToolbarMiddleware']
INTERNAL_IPS = ['127.0.0.1']
```

### Production Settings

```python
# bookstore/settings/production.py
from .base import *
import os

# Production settings
DEBUG = False

# Load secret key from environment
SECRET_KEY = os.environ['SECRET_KEY']

ALLOWED_HOSTS = ['yourdomain.com', 'www.yourdomain.com']

# Production database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ['DB_NAME'],
        'USER': os.environ['DB_USER'],
        'PASSWORD': os.environ['DB_PASSWORD'],
        'HOST': os.environ['DB_HOST'],
        'PORT': os.environ['DB_PORT'],
    }
}

# Static files for production
STATIC_ROOT = '/var/www/static/'

# Security settings
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_HSTS_SECONDS = 31536000
SECURE_REDIRECT_EXEMPT = []
SECURE_REFERRER_POLICY = 'same-origin'
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# Production email
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.environ['EMAIL_HOST']
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ['EMAIL_HOST_USER']
EMAIL_HOST_PASSWORD = os.environ['EMAIL_HOST_PASSWORD']

# Caching
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': os.environ['REDIS_URL'],
    }
}

# Production logging
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'file': {
            'level': 'ERROR',
            'class': 'logging.FileHandler',
            'filename': '/var/log/django/error.log',
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['file'],
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'ERROR',
            'propagate': False,
        },
    },
}
```

## Using Settings in Python Code

### Accessing Settings

```python
from django.conf import settings

def my_view(request):
    if settings.DEBUG:
        # Development-specific code
        print("Debug mode is on")
    
    # Use media root for file operations
    media_path = settings.MEDIA_ROOT
    
    # Check if feature is enabled
    if getattr(settings, 'FEATURE_FLAG_X', False):
        # Feature is enabled
        pass
    
    return render(request, 'template.html')
```

### Settings in Templates

```python
# Add to context processors in settings
TEMPLATES = [
    {
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.media',
                'django.template.context_processors.static',
                # Custom context processor
                'myapp.context_processors.settings_context',
            ],
        },
    },
]

# myapp/context_processors.py
from django.conf import settings

def settings_context(request):
    return {
        'DEBUG': settings.DEBUG,
        'SITE_NAME': getattr(settings, 'SITE_NAME', 'My Site'),
    }
```

```html
<!-- In templates -->
{% if DEBUG %}
    <div class="debug-info">Debug mode is active</div>
{% endif %}

<title>{{ SITE_NAME }} - Book Store</title>
```

## Environment Variables

### Using python-decouple

```bash
pip install python-decouple
```

```python
# bookstore/settings/production.py
from decouple import config
import dj_database_url

# Load from .env file or environment
DEBUG = config('DEBUG', default=False, cast=bool)
SECRET_KEY = config('SECRET_KEY')
DATABASE_URL = config('DATABASE_URL')

DATABASES = {
    'default': dj_database_url.parse(DATABASE_URL)
}

# Email settings
EMAIL_HOST = config('EMAIL_HOST')
EMAIL_PORT = config('EMAIL_PORT', cast=int)
EMAIL_HOST_USER = config('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD')
```

### .env File Example

```env
# .env file (never commit to version control)
DEBUG=False
SECRET_KEY=your-super-secret-production-key
DATABASE_URL=postgresql://user:password@localhost:5432/bookstore_prod
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
REDIS_URL=redis://localhost:6379/1
```

## Custom Settings

### Creating Custom Settings

```python
# bookstore/settings/base.py

# Custom app settings
BOOKSTORE_SETTINGS = {
    'MAX_BOOKS_PER_USER': 10,
    'ALLOW_GUEST_CHECKOUT': True,
    'DEFAULT_CURRENCY': 'USD',
    'ENABLE_RECOMMENDATIONS': True,
    'MAX_UPLOAD_SIZE': 5 * 1024 * 1024,  # 5MB
}

# Email settings
EMAIL_SETTINGS = {
    'WELCOME_EMAIL_TEMPLATE': 'emails/welcome.html',
    'ORDER_CONFIRMATION_TEMPLATE': 'emails/order_confirmation.html',
    'FROM_EMAIL': 'noreply@bookstore.com',
}

# Third-party API keys
API_KEYS = {
    'GOOGLE_BOOKS_API': config('GOOGLE_BOOKS_API_KEY', default=''),
    'STRIPE_PUBLIC_KEY': config('STRIPE_PUBLIC_KEY', default=''),
    'STRIPE_SECRET_KEY': config('STRIPE_SECRET_KEY', default=''),
}
```

### Using Custom Settings

```python
# books/models.py
from django.conf import settings

class Book(models.Model):
    title = models.CharField(max_length=200)
    
    @property
    def max_upload_size(self):
        return settings.BOOKSTORE_SETTINGS['MAX_UPLOAD_SIZE']

# books/views.py
def add_book(request):
    max_books = settings.BOOKSTORE_SETTINGS['MAX_BOOKS_PER_USER']
    user_book_count = Book.objects.filter(created_by=request.user).count()
    
    if user_book_count >= max_books:
        messages.error(request, f'You can only add up to {max_books} books.')
        return redirect('books:book-list')
    
    # Continue with adding book...
```

## Security Settings

### Essential Security Settings

```python
# Security settings for production
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_HSTS_SECONDS = 31536000  # 1 year
SECURE_REFERRER_POLICY = 'same-origin'
SECURE_SSL_REDIRECT = True

# Session security
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 86400  # 24 hours
SESSION_EXPIRE_AT_BROWSER_CLOSE = True

# CSRF security
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True

# Content Security Policy
CSP_DEFAULT_SRC = ("'self'",)
CSP_STYLE_SRC = ("'self'", "'unsafe-inline'", "cdn.jsdelivr.net")
CSP_SCRIPT_SRC = ("'self'", "cdn.jsdelivr.net")

# Additional security
X_FRAME_OPTIONS = 'DENY'
ALLOWED_HOSTS = ['yourdomain.com']
```

## Settings Validation

### Custom Settings Validation

```python
# bookstore/settings/validation.py
from django.core.exceptions import ImproperlyConfigured

def validate_settings():
    from django.conf import settings
    
    # Check required settings
    required_settings = ['SECRET_KEY', 'DATABASES']
    for setting in required_settings:
        if not hasattr(settings, setting):
            raise ImproperlyConfigured(f"Missing required setting: {setting}")
    
    # Check secret key in production
    if not settings.DEBUG and settings.SECRET_KEY == 'dev-secret-key':
        raise ImproperlyConfigured("SECRET_KEY must be changed in production")
    
    # Validate custom settings
    bookstore_settings = getattr(settings, 'BOOKSTORE_SETTINGS', {})
    if bookstore_settings.get('MAX_BOOKS_PER_USER', 0) <= 0:
        raise ImproperlyConfigured("MAX_BOOKS_PER_USER must be positive")

# In apps.py
from django.apps import AppConfig

class BooksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'books'
    
    def ready(self):
        from .settings.validation import validate_settings
        validate_settings()
```

## Settings Without DJANGO_SETTINGS_MODULE

### Programmatic Settings Configuration

```python
# standalone_script.py
import os
import django
from django.conf import settings

# Configure settings manually
if not settings.configured:
    settings.configure(
        DEBUG=True,
        SECRET_KEY='test-secret-key',
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.auth',
            'django.contrib.contenttypes',
            'books',
        ],
        USE_TZ=True,
    )

# Initialize Django
django.setup()

# Now you can use Django models
from books.models import Book

books = Book.objects.all()
print(f"Found {books.count()} books")
```

## Management Commands with Settings

### Custom Management Command

```python
# books/management/commands/check_settings.py
from django.core.management.base import BaseCommand
from django.conf import settings
import os

class Command(BaseCommand):
    help = 'Check current Django settings configuration'
    
    def add_arguments(self, parser):
        parser.add_argument('--show-sensitive', action='store_true',
                          help='Show sensitive settings (use with caution)')
    
    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Django Settings Check'))
        self.stdout.write('=' * 40)
        
        # Basic settings
        self.stdout.write(f"DEBUG: {settings.DEBUG}")
        self.stdout.write(f"ALLOWED_HOSTS: {settings.ALLOWED_HOSTS}")
        self.stdout.write(f"TIME_ZONE: {settings.TIME_ZONE}")
        
        # Database
        db_engine = settings.DATABASES['default']['ENGINE']
        self.stdout.write(f"Database Engine: {db_engine}")
        
        # Show sensitive data only if requested
        if options['show_sensitive']:
            self.stdout.write(f"SECRET_KEY: {settings.SECRET_KEY}")
        
        # Custom settings
        if hasattr(settings, 'BOOKSTORE_SETTINGS'):
            self.stdout.write("Custom Bookstore Settings:")
            for key, value in settings.BOOKSTORE_SETTINGS.items():
                self.stdout.write(f"  {key}: {value}")
        
        # Environment info
        self.stdout.write(f"Settings Module: {os.environ.get('DJANGO_SETTINGS_MODULE', 'Not set')}")
```

```bash
# Usage
python manage.py check_settings
python manage.py check_settings --show-sensitive
```

## Best Practices

1. **Environment Separation**: Use different settings files for different environments
2. **Secret Management**: Never hardcode secrets, use environment variables
3. **Security First**: Enable security settings in production
4. **Documentation**: Document custom settings and their purpose
5. **Validation**: Validate settings on application startup
6. **Defaults**: Provide sensible defaults for optional settings
7. **Version Control**: Never commit sensitive settings to version control

## What's Next?

Congratulations! You've completed the comprehensive Django course. You now have the knowledge to build robust web applications with Django, from basic setup to advanced configuration.

**Next Steps:**
- Build a complete project using all concepts learned
- Explore Django REST Framework for API development
- Learn about Django deployment strategies
- Study Django performance optimization techniques

You're ready to build amazing web applications with Django! 🚀
    ''',
    "is_free": True,
    "xp_reward": 55,
    "exercises": [
        {
            "id": "django-settings",
            "title": "Configure Multi-Environment Django Project",
            "type": "project",
            "instructions": '''Create a complete multi-environment settings configuration for your bookstore project.

Implement the following:

1. Create environment-specific settings files (base, development, production, testing)
2. Use environment variables for sensitive data
3. Configure different databases for each environment
4. Set up proper security settings for production
5. Create custom settings for your bookstore application
6. Add settings validation
7. Create a management command to check current settings
8. Document all custom settings and their purposes

Test with different environments: development, staging, and production configurations.''',
            "starter_code": '''# bookstore/settings/base.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Common settings for all environments
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'books',
    'accounts',
]

# Add more common settings here

# bookstore/settings/development.py  
from .base import *

DEBUG = True
# Add development-specific settings

# bookstore/settings/production.py
from .base import *

DEBUG = False
# Add production-specific settings''',
            "solution": '''# bookstore/settings/base.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'books.apps.BooksConfig',
    'accounts.apps.AccountsConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'bookstore.urls'

# Custom settings
BOOKSTORE_SETTINGS = {
    'MAX_BOOKS_PER_USER': 10,
    'ALLOW_GUEST_CHECKOUT': True,
    'DEFAULT_CURRENCY': 'USD',
    'MAX_UPLOAD_SIZE': 5 * 1024 * 1024,
}

# bookstore/settings/development.py
from .base import *

DEBUG = True
SECRET_KEY = 'dev-secret-key'
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# bookstore/settings/production.py
from .base import *
from decouple import config

DEBUG = False
SECRET_KEY = config('SECRET_KEY')
ALLOWED_HOSTS = config('ALLOWED_HOSTS', cast=lambda v: [s.strip() for s in v.split(',')])

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': config('DB_NAME'),
        'USER': config('DB_USER'),
        'PASSWORD': config('DB_PASSWORD'),
        'HOST': config('DB_HOST'),
        'PORT': config('DB_PORT'),
    }
}

# Security settings
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# Management command
class Command(BaseCommand):
    help = 'Check Django settings configuration'
    
    def handle(self, *args, **options):
        self.stdout.write("Django Settings Check")
        self.stdout.write(f"DEBUG: {settings.DEBUG}")
        self.stdout.write(f"Database: {settings.DATABASES['default']['ENGINE']}")''',
            "test_cases": [
                {
                    "name": "Complete multi-environment settings implemented",
                    "input": "",
                    "expected_contains": ["base.py", "development.py", "production.py", "config", "SECURE_"]
                }
            ],
            "xp_reward": 90,
            "hints": [
                "Separate common settings in base.py and inherit in environment files",
                "Use python-decouple or similar for environment variable management",
                "Enable all security settings for production environment",
                "Create custom settings dictionary for app-specific configuration",
                "Add validation to ensure required settings are present"
            ]
        }
    ]
}