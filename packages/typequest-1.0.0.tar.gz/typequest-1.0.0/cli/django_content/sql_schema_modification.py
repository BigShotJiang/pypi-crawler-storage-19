"""
SQL Schema Modification lesson content
"""

SQL_SCHEMA_MODIFICATION_LESSON = {
    "id": 39,
    "chapter": 39,
    "title": "SQL Schema Design: CREATE, ALTER, DROP Tables",
    "slug": "sql-schema-modification",
    "content": '''
# SQL Schema Design: Building the Database Architecture

While data modification changes content, schema modification changes structure. When Instagram adds a new feature requiring user badges, Amazon creates tables for a new product category, or Netflix designs tables for a recommendation system, they're using schema modification commands to evolve their database architecture.

## Database Schema: The Foundation

A database schema is like the blueprint of a building - it defines the structure, relationships, and rules that govern how data is organized and stored. Every successful application starts with thoughtful schema design.

**Schema defines:**
- **Tables** (entities in your system)
- **Columns** (attributes of entities)  
- **Data Types** (what kind of data each column holds)
- **Constraints** (rules that ensure data quality)
- **Relationships** (how tables connect to each other)

## CREATE TABLE: Building Your Database Foundation

CREATE TABLE statements define new tables - the core structures that will hold your application's data.

### Basic CREATE TABLE Syntax

```sql
CREATE TABLE table_name (
    column1 datatype constraints,
    column2 datatype constraints,
    column3 datatype constraints,
    table_constraints
);
```

### Real-World Table Creation Examples

**Social Media Platform Tables**
```sql
-- User profiles table (Instagram/TikTok style)
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    bio TEXT,
    follower_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- Posts table with rich metadata
CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(255),
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    is_public BOOLEAN DEFAULT TRUE,
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

**E-commerce Platform Tables**
```sql
-- Product catalog table (Amazon/Shopify style)
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    sale_price DECIMAL(10, 2),
    sku VARCHAR(50) UNIQUE NOT NULL,
    category_id INTEGER,
    brand VARCHAR(100),
    weight DECIMAL(8, 2),
    dimensions VARCHAR(50),
    stock_quantity INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Order management table
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    customer_id INTEGER NOT NULL,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL,
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    shipping_cost DECIMAL(8, 2) DEFAULT 0,
    order_status VARCHAR(20) DEFAULT 'pending',
    payment_status VARCHAR(20) DEFAULT 'pending',
    shipping_address TEXT NOT NULL,
    billing_address TEXT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_date TIMESTAMP,
    delivered_date TIMESTAMP
);
```

**Content Management Tables**
```sql
-- Video/Content library (YouTube/Netflix style)
CREATE TABLE videos (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    creator_id INTEGER NOT NULL,
    duration INTEGER, -- in seconds
    file_url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    category VARCHAR(50),
    tags TEXT, -- JSON or comma-separated
    view_count INTEGER DEFAULT 0,
    like_count INTEGER DEFAULT 0,
    dislike_count INTEGER DEFAULT 0,
    is_published BOOLEAN DEFAULT FALSE,
    is_monetized BOOLEAN DEFAULT FALSE,
    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    published_date TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users(id)
);
```

### Advanced Table Creation Patterns

**Table with Comprehensive Constraints**
```sql
-- User subscription system (Netflix/Spotify style)
CREATE TABLE subscriptions (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    plan_type VARCHAR(20) NOT NULL CHECK (plan_type IN ('free', 'premium', 'family')),
    start_date DATE NOT NULL,
    end_date DATE,
    monthly_price DECIMAL(6, 2) NOT NULL CHECK (monthly_price >= 0),
    payment_method VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    auto_renew BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT valid_subscription_period CHECK (end_date IS NULL OR end_date > start_date),
    UNIQUE KEY unique_active_subscription (user_id, is_active)
);
```

**Analytics and Tracking Tables**
```sql
-- User activity tracking (Google Analytics style)
CREATE TABLE user_activity (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER,
    session_id VARCHAR(100) NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    page_url VARCHAR(500),
    referrer_url VARCHAR(500),
    user_agent TEXT,
    ip_address VARCHAR(45), -- IPv6 compatible
    device_type VARCHAR(20),
    country VARCHAR(50),
    city VARCHAR(100),
    duration_seconds INTEGER,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_activity (user_id, timestamp),
    INDEX idx_session (session_id),
    INDEX idx_activity_type (activity_type, timestamp)
);
```

## Data Types: Choosing the Right Foundation

### Numeric Data Types

```sql
-- Integer types for different ranges
CREATE TABLE numeric_examples (
    tiny_number TINYINT,      -- -128 to 127
    small_number SMALLINT,    -- -32,768 to 32,767  
    regular_number INTEGER,   -- -2,147,483,648 to 2,147,483,647
    big_number BIGINT,        -- Very large numbers
    
    -- Decimal types for precision
    price DECIMAL(10, 2),     -- 10 digits total, 2 after decimal
    percentage DECIMAL(5, 2), -- 5 digits total, 2 after decimal (e.g., 100.50)
    scientific_value FLOAT,   -- Floating point
    precise_calculation DOUBLE -- Double precision
);
```

### String Data Types

```sql
-- String types for different content lengths
CREATE TABLE string_examples (
    username VARCHAR(50),      -- Variable length, max 50 chars
    email VARCHAR(100),        -- Email addresses
    phone CHAR(10),           -- Fixed length (US phone numbers)
    description TEXT,         -- Large text content
    metadata LONGTEXT,        -- Very large text content
    status ENUM('active', 'inactive', 'pending') -- Predefined values
);
```

### Date and Time Types

```sql
-- Date/time types for different use cases
CREATE TABLE datetime_examples (
    birth_date DATE,                    -- YYYY-MM-DD
    login_time TIME,                    -- HH:MM:SS
    created_at TIMESTAMP,               -- Date + time with timezone
    updated_at DATETIME,                -- Date + time without timezone
    event_year YEAR                     -- Just the year
);
```

## ALTER TABLE: Evolving Your Schema

ALTER TABLE statements modify existing table structures - adding features, changing constraints, or optimizing performance.

### Adding Columns (Feature Expansion)

```sql
-- Add new features to existing user table
ALTER TABLE users
ADD COLUMN profile_picture_url VARCHAR(500),
ADD COLUMN is_verified_business BOOLEAN DEFAULT FALSE,
ADD COLUMN subscription_tier VARCHAR(20) DEFAULT 'free';

-- Add new analytics columns to posts table
ALTER TABLE posts
ADD COLUMN share_count INTEGER DEFAULT 0,
ADD COLUMN save_count INTEGER DEFAULT 0,
ADD COLUMN engagement_score DECIMAL(5, 2) DEFAULT 0.0;

-- Add audit columns for compliance
ALTER TABLE products
ADD COLUMN created_by INTEGER,
ADD COLUMN last_modified_by INTEGER,
ADD COLUMN version_number INTEGER DEFAULT 1;
```

### Modifying Existing Columns

```sql
-- Change column data types (careful - may require data migration)
ALTER TABLE users
MODIFY COLUMN bio TEXT; -- Increase size from VARCHAR to TEXT

-- Change column constraints
ALTER TABLE products
MODIFY COLUMN name VARCHAR(300) NOT NULL; -- Increase name length

-- Rename columns for clarity
ALTER TABLE posts
RENAME COLUMN likes_count TO total_likes;
```

### Adding Constraints and Indexes

```sql
-- Add foreign key constraints (enforce data relationships)
ALTER TABLE posts
ADD CONSTRAINT fk_posts_user
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- Add check constraints (business rules)
ALTER TABLE products
ADD CONSTRAINT check_positive_price CHECK (price > 0),
ADD CONSTRAINT check_valid_stock CHECK (stock_quantity >= 0);

-- Add indexes for performance
ALTER TABLE users
ADD INDEX idx_username (username),
ADD INDEX idx_email (email),
ADD INDEX idx_created_at (created_at);

-- Composite indexes for complex queries
ALTER TABLE posts
ADD INDEX idx_user_created (user_id, created_at),
ADD INDEX idx_public_likes (is_public, likes_count);
```

### Real-World Schema Evolution Examples

**Adding Social Features to Platform**
```sql
-- Add commenting system
CREATE TABLE comments (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    parent_comment_id INTEGER, -- For reply threading
    content TEXT NOT NULL,
    likes_count INTEGER DEFAULT 0,
    is_edited BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_comment_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- Update posts table to track comments
ALTER TABLE posts
ADD COLUMN comments_enabled BOOLEAN DEFAULT TRUE;
```

**Adding E-commerce Features**
```sql
-- Add review system
CREATE TABLE product_reviews (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    product_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_title VARCHAR(200),
    review_text TEXT,
    is_verified_purchase BOOLEAN DEFAULT FALSE,
    helpful_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product_review (user_id, product_id)
);

-- Update products table with review aggregates
ALTER TABLE products
ADD COLUMN average_rating DECIMAL(3, 2) DEFAULT 0.0,
ADD COLUMN review_count INTEGER DEFAULT 0;
```

## DROP: Removing Database Structures

DROP statements remove database objects - use with extreme caution in production!

### Dropping Tables

```sql
-- Remove entire tables (DESTRUCTIVE - ALL DATA LOST!)
DROP TABLE IF EXISTS temp_user_data;
DROP TABLE IF EXISTS old_analytics_table;

-- Drop with dependencies (cascade removes related objects)
DROP TABLE posts CASCADE; -- Also drops foreign key constraints referencing this table
```

### Dropping Columns and Constraints

```sql
-- Remove columns no longer needed
ALTER TABLE users
DROP COLUMN old_password_field,
DROP COLUMN deprecated_status;

-- Remove constraints
ALTER TABLE products
DROP CONSTRAINT check_positive_price,
DROP INDEX idx_old_field;

-- Remove foreign key relationships
ALTER TABLE posts
DROP FOREIGN KEY fk_posts_user;
```

## Database Design Best Practices

### 1. Naming Conventions

```sql
-- ✅ Clear, consistent naming
CREATE TABLE user_profiles (
    id INTEGER PRIMARY KEY,
    username VARCHAR(50),
    email_address VARCHAR(100),
    created_at TIMESTAMP,
    is_active BOOLEAN
);

-- ❌ Unclear, inconsistent naming
CREATE TABLE tbl1 (
    ID int,
    nm varchar(50),
    eml varchar(100),
    dt timestamp,
    act boolean
);
```

### 2. Appropriate Data Types

```sql
-- ✅ Right-sized data types
CREATE TABLE products (
    price DECIMAL(10, 2),        -- Exact for money
    description TEXT,            -- Large text content
    category_id SMALLINT,        -- Small range of categories
    is_featured BOOLEAN          -- True/false flag
);

-- ❌ Wasteful or inappropriate types
CREATE TABLE products_bad (
    price FLOAT,                 -- Imprecise for money
    description VARCHAR(50),     -- Too small for descriptions
    category_id BIGINT,         -- Overkill for small ranges
    is_featured VARCHAR(10)     -- Wasteful for true/false
);
```

### 3. Proper Constraints

```sql
-- ✅ Business rules enforced at database level
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    customer_id INTEGER NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL CHECK (total_amount > 0),
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'shipped', 'delivered', 'cancelled')),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);
```

### 4. Performance Considerations

```sql
-- ✅ Strategic indexing for query performance
CREATE TABLE user_activity_log (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    action VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes for common query patterns
    INDEX idx_user_timestamp (user_id, timestamp),
    INDEX idx_action_timestamp (action, timestamp),
    INDEX idx_timestamp (timestamp)
);
```

## Advanced Schema Patterns

### Audit Trail Tables

```sql
-- Track changes to important data
CREATE TABLE user_audit_log (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    field_name VARCHAR(50) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    changed_by INTEGER NOT NULL,
    change_reason VARCHAR(200),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (changed_by) REFERENCES users(id)
);
```

### Flexible Configuration Tables

```sql
-- Application settings that can change without code deployment
CREATE TABLE app_settings (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    data_type VARCHAR(20) NOT NULL CHECK (data_type IN ('string', 'integer', 'boolean', 'json')),
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Polymorphic Relationship Tables

```sql
-- Handle relationships to multiple table types
CREATE TABLE notifications (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    notifiable_type VARCHAR(50) NOT NULL, -- 'post', 'comment', 'user', etc.
    notifiable_id INTEGER NOT NULL,       -- ID of the related record
    notification_type VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_notifiable (notifiable_type, notifiable_id),
    INDEX idx_user_unread (user_id, is_read)
);
```

Schema design is the architectural foundation that enables applications to scale from startup MVPs to platforms serving billions of users. Whether you're building the next Instagram, designing Amazon's product catalog, or architecting Netflix's content delivery system, thoughtful schema design ensures your database can evolve with your business needs! 🏗️📊
    ''',
    "is_free": False,
    "xp_reward": 135,
    "exercises": [
        {
            "id": "social-media-schema-design",
            "title": "Social Media Platform Database Design",
            "type": "practice",
            "instructions": """Design a complete database schema for a social media platform, creating tables with proper data types, constraints, and relationships.

Your tasks:
1. Create a users table with comprehensive profile information
2. Create a posts table with rich content metadata
3. Create a followers table to track user relationships
4. Add proper constraints and foreign keys
5. Create indexes for performance optimization
6. Add a comments table with proper relationships

This exercise simulates building the database foundation for a platform like Instagram or TikTok.""",
            "starter_code": """-- Task 1: Create users table with comprehensive profile fields
-- Include: id (primary key), username, email, full_name, bio, follower_count, 
-- following_count, verified status, profile_picture_url, created_at


-- Task 2: Create posts table with content metadata
-- Include: id (primary key), user_id (foreign key), content, image_url, 
-- likes_count, comments_count, is_public, location, created_at, updated_at


-- Task 3: Create followers table for user relationships
-- Include: id, follower_id, following_id, created_at
-- This represents who follows whom


-- Task 4: Add constraints and foreign keys
-- Add foreign key relationships between tables
-- Add check constraints for positive counts


-- Task 5: Create performance indexes
-- Add indexes for common query patterns (user lookups, timeline queries)


-- Task 6: Create comments table
-- Include: id, post_id, user_id, content, likes_count, created_at
-- Add proper foreign key relationships
""",
            "solution": """-- Task 1: Create users table with comprehensive profile fields
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    bio TEXT,
    follower_count INTEGER DEFAULT 0 CHECK (follower_count >= 0),
    following_count INTEGER DEFAULT 0 CHECK (following_count >= 0),
    verified BOOLEAN DEFAULT FALSE,
    profile_picture_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Task 2: Create posts table with content metadata
CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    image_url VARCHAR(500),
    likes_count INTEGER DEFAULT 0 CHECK (likes_count >= 0),
    comments_count INTEGER DEFAULT 0 CHECK (comments_count >= 0),
    is_public BOOLEAN DEFAULT TRUE,
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Task 3: Create followers table for user relationships  
CREATE TABLE followers (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    follower_id INTEGER NOT NULL,
    following_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_follow_relationship (follower_id, following_id),
    CHECK (follower_id != following_id)
);

-- Task 4: Add additional constraints (already included above in table creation)

-- Task 5: Create performance indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_posts_user_id ON posts(user_id);
CREATE INDEX idx_posts_created_at ON posts(created_at);
CREATE INDEX idx_posts_user_created ON posts(user_id, created_at);
CREATE INDEX idx_followers_follower ON followers(follower_id);
CREATE INDEX idx_followers_following ON followers(following_id);

-- Task 6: Create comments table
CREATE TABLE comments (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    likes_count INTEGER DEFAULT 0 CHECK (likes_count >= 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Add index for comments performance
CREATE INDEX idx_comments_post_id ON comments(post_id);
CREATE INDEX idx_comments_user_id ON comments(user_id);""",
            "test_cases": [
                {
                    "name": "Table creation with constraints",
                    "input": "CREATE TABLE users (id INTEGER PRIMARY KEY AUTO_INCREMENT, username VARCHAR(50) UNIQUE NOT NULL);",
                    "expected_contains": ["CREATE TABLE", "PRIMARY KEY", "UNIQUE", "NOT NULL"]
                },
                {
                    "name": "Foreign key relationships",
                    "input": "ALTER TABLE posts ADD FOREIGN KEY (user_id) REFERENCES users(id);",
                    "expected_contains": ["FOREIGN KEY", "REFERENCES", "user_id", "users"]
                }
            ],
            "xp_reward": 85,
            "hints": [
                "Use AUTO_INCREMENT for primary key IDs",
                "VARCHAR for limited text, TEXT for unlimited content",
                "Add CHECK constraints for positive counts (likes_count >= 0)",
                "UNIQUE constraints prevent duplicate usernames/emails", 
                "Foreign keys maintain data integrity between tables",
                "Indexes improve query performance for common lookups"
            ]
        },
        {
            "id": "ecommerce-schema-evolution",
            "title": "E-commerce Schema Evolution with ALTER TABLE",
            "type": "practice",
            "instructions": """Practice schema evolution by starting with basic tables and adding features using ALTER TABLE, simulating how real e-commerce platforms grow over time.

Your tasks:
1. Create basic products table
2. Create basic orders table  
3. Add new columns for enhanced features
4. Create product reviews table
5. Add indexes for performance
6. Modify existing columns and constraints

This simulates how platforms like Amazon evolved their database schemas as they added features.""",
            "starter_code": """-- Task 1: Create basic products table
-- Include: id (primary key), name, price, stock_quantity, is_active


-- Task 2: Create basic orders table
-- Include: id (primary key), customer_email, total_amount, order_date, status


-- Task 3: Add enhanced features to products table using ALTER TABLE
-- Add: description (TEXT), sku (VARCHAR 50), category, brand, average_rating


-- Task 4: Create product reviews table
-- Include: id, product_id (foreign key), customer_email, rating (1-5), review_text, created_at


-- Task 5: Add performance indexes
-- Add indexes on commonly queried columns (product name, SKU, order status)


-- Task 6: Modify existing columns
-- Change products.name to allow 200 characters instead of default
-- Add check constraint to ensure ratings are between 1 and 5
""",
            "solution": """-- Task 1: Create basic products table
CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price > 0),
    stock_quantity INTEGER DEFAULT 0 CHECK (stock_quantity >= 0),
    is_active BOOLEAN DEFAULT TRUE
);

-- Task 2: Create basic orders table  
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    customer_email VARCHAR(100) NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL CHECK (total_amount > 0),
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending'
);

-- Task 3: Add enhanced features to products table
ALTER TABLE products
ADD COLUMN description TEXT,
ADD COLUMN sku VARCHAR(50) UNIQUE,
ADD COLUMN category VARCHAR(100),
ADD COLUMN brand VARCHAR(100),
ADD COLUMN average_rating DECIMAL(3, 2) DEFAULT 0.0;

-- Task 4: Create product reviews table
CREATE TABLE product_reviews (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    product_id INTEGER NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_customer_product_review (customer_email, product_id)
);

-- Task 5: Add performance indexes
CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_customer ON orders(customer_email);
CREATE INDEX idx_reviews_product ON product_reviews(product_id);
CREATE INDEX idx_reviews_rating ON product_reviews(rating);

-- Task 6: Modify existing columns
ALTER TABLE products
MODIFY COLUMN name VARCHAR(200) NOT NULL;

-- Add constraint to ensure valid order status
ALTER TABLE orders
ADD CONSTRAINT check_order_status 
CHECK (status IN ('pending', 'paid', 'shipped', 'delivered', 'cancelled'));""",
            "test_cases": [
                {
                    "name": "ALTER TABLE ADD COLUMN",
                    "input": "ALTER TABLE products ADD COLUMN description TEXT;",
                    "expected_contains": ["ALTER TABLE", "ADD COLUMN", "description", "TEXT"]
                },
                {
                    "name": "Create index for performance",
                    "input": "CREATE INDEX idx_products_name ON products(name);",
                    "expected_contains": ["CREATE INDEX", "idx_products_name", "ON", "products"]
                }
            ],
            "xp_reward": 90,
            "hints": [
                "Use DECIMAL(10,2) for precise money amounts",
                "CHECK constraints enforce business rules like positive prices",
                "UNIQUE constraints prevent duplicate SKUs",
                "ALTER TABLE ADD COLUMN adds new features to existing tables",
                "CREATE INDEX improves query performance on frequently searched columns",
                "MODIFY COLUMN changes existing column properties"
            ]
        }
    ]
}