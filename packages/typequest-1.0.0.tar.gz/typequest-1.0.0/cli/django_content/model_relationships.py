"""
Django Model Relationships lesson content
"""

DJANGO_MODEL_RELATIONSHIPS_LESSON = {
    "id": 17,
    "chapter": 17,
    "title": "Django Model Relationships",
    "slug": "model-relationships",
    "content": '''
# Django Model Relationships: Connecting Your Digital World

Think of model relationships as the connections in a vast social network. Just like how Facebook connects friends, LinkedIn connects professionals, and Spotify connects artists to albums, Django relationships define how your data pieces fit together to tell the complete story of your application.

## Understanding Relationships: The Digital Ecosystem

Every successful app is built on relationships:
- **Netflix**: Users watch Movies, Movies have Genres, Actors star in Movies
- **Uber**: Drivers complete Rides, Riders book Trips, Cars belong to Drivers  
- **Amazon**: Customers place Orders, Orders contain Products, Products have Reviews

**Real-world analogy:** Relationships are like family trees, organizational charts, or city maps - they show how different entities connect and depend on each other.

## The Three Pillars of Django Relationships

### 1. ForeignKey (Many-to-One): The Foundation Relationship

**Like:** Many employees work for one company, many books have one publisher, many tweets belong to one user.

```python
# Real-world example: Spotify's music catalog
class Artist(models.Model):
    name = models.CharField(max_length=200)
    bio = models.TextField(blank=True)
    country = models.CharField(max_length=100)
    verified = models.BooleanField(default=False)
    monthly_listeners = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return self.name

class Album(models.Model):
    title = models.CharField(max_length=200)
    artist = models.ForeignKey(
        Artist, 
        on_delete=models.CASCADE,  # Delete album if artist is deleted
        related_name='albums'      # Access via artist.albums.all()
    )
    release_date = models.DateField()
    genre = models.CharField(max_length=100)
    total_tracks = models.PositiveIntegerField()
    
    class Meta:
        unique_together = ['title', 'artist']  # No duplicate album titles per artist
    
    def __str__(self):
        return f"{self.title} by {self.artist.name}"

class Song(models.Model):
    title = models.CharField(max_length=200)
    album = models.ForeignKey(
        Album,
        on_delete=models.CASCADE,
        related_name='songs'
    )
    duration = models.DurationField()  # Song length
    track_number = models.PositiveIntegerField()
    plays_count = models.BigIntegerField(default=0)
    
    class Meta:
        unique_together = ['album', 'track_number']
        ordering = ['track_number']
    
    def __str__(self):
        return f"{self.track_number}. {self.title}"
    
    @property
    def duration_minutes(self):
        """Get duration in MM:SS format"""
        total_seconds = int(self.duration.total_seconds())
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        return f"{minutes}:{seconds:02d}"
```

#### ForeignKey `on_delete` Options: Data Safety Rules

```python
class Company(models.Model):
    name = models.CharField(max_length=200)

class Employee(models.Model):
    name = models.CharField(max_length=100)
    company = models.ForeignKey(
        Company,
        on_delete=models.CASCADE,    # Delete employee when company is deleted
        # Other options:
        # on_delete=models.PROTECT,   # Prevent company deletion if has employees
        # on_delete=models.SET_NULL,  # Set employee.company to NULL (requires null=True)
        # on_delete=models.SET_DEFAULT, # Set to default value
        # on_delete=models.DO_NOTHING,  # Don't do anything (dangerous!)
    )
    
    def __str__(self):
        return f"{self.name} ({self.company.name})"
```

### 2. OneToOneField: The Perfect Match Relationship

**Like:** One user has one profile, one person has one passport, one order has one shipping address.

```python
# Real-world example: User profiles (Instagram/Twitter style)
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    bio = models.TextField(max_length=500, blank=True)
    location = models.CharField(max_length=100, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True)
    
    # Social media links
    website = models.URLField(blank=True)
    twitter_handle = models.CharField(max_length=50, blank=True)
    linkedin_profile = models.URLField(blank=True)
    
    # Privacy settings
    is_private = models.BooleanField(default=False)
    show_email = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"
    
    @property
    def display_name(self):
        return self.user.get_full_name() or self.user.username
    
    @property
    def age(self):
        if self.birth_date:
            from datetime import date
            today = date.today()
            return today.year - self.birth_date.year - (
                (today.month, today.day) < (self.birth_date.month, self.birth_date.day)
            )
        return None

# Auto-create profile when user is created
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)  
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
```

#### OneToOneField in E-commerce: Order Details
```python
class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)

class ShippingAddress(models.Model):
    order = models.OneToOneField(
        Order,
        on_delete=models.CASCADE,
        related_name='shipping_address'
    )
    recipient_name = models.CharField(max_length=200)
    address_line_1 = models.CharField(max_length=200)
    address_line_2 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    country = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)
    
    def __str__(self):
        return f"Shipping to {self.recipient_name}"

class OrderTracking(models.Model):
    order = models.OneToOneField(
        Order,
        on_delete=models.CASCADE,
        related_name='tracking'
    )
    tracking_number = models.CharField(max_length=100, unique=True)
    carrier = models.CharField(max_length=50)
    shipped_at = models.DateTimeField(null=True, blank=True)
    estimated_delivery = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Tracking: {self.tracking_number}"
```

### 3. ManyToManyField: The Network Effect Relationship

**Like:** Users follow many users, movies have many genres, students take many classes.

```python
# Real-world example: Social media platform (Twitter/Instagram style)
class HashTag(models.Model):
    name = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    usage_count = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return f"#{self.name}"
    
    @property
    def is_trending(self):
        # Simple trending logic: used more than 1000 times
        return self.usage_count > 1000

class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length=280)  # Twitter-style limit
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Many-to-many relationships
    hashtags = models.ManyToManyField(
        HashTag,
        blank=True,
        related_name='posts'
    )
    
    likes = models.ManyToManyField(
        User,
        through='Like',  # Custom intermediate table
        related_name='liked_posts',
        blank=True
    )
    
    def __str__(self):
        return f"@{self.author.username}: {self.content[:50]}..."
    
    def get_hashtags_list(self):
        """Extract hashtags from content"""
        import re
        hashtag_pattern = r'#(\w+)'
        return re.findall(hashtag_pattern, self.content)
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        
        # Auto-create hashtag relationships
        hashtags_in_content = self.get_hashtags_list()
        for hashtag_name in hashtags_in_content:
            hashtag, created = HashTag.objects.get_or_create(
                name=hashtag_name.lower()
            )
            self.hashtags.add(hashtag)

# Custom through model for additional data
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'post']  # Prevent duplicate likes
    
    def __str__(self):
        return f"{self.user.username} likes post {self.post.id}"

# Follow relationships (self-referential many-to-many)
class Follow(models.Model):
    follower = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='following'
    )
    following = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='followers'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['follower', 'following']
        constraints = [
            models.CheckConstraint(
                condition=~models.Q(follower=models.F('following')),
                name='no_self_follow'
            )
        ]
    
    def __str__(self):
        return f"{self.follower.username} follows {self.following.username}"
```

#### Advanced Many-to-Many: E-learning Platform
```python
class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    instructor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='courses_taught')
    price = models.DecimalField(max_digits=8, decimal_places=2)
    
    def __str__(self):
        return self.title

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    courses = models.ManyToManyField(
        Course,
        through='Enrollment',
        related_name='students'
    )
    
    def __str__(self):
        return self.user.username

class Enrollment(models.Model):
    PROGRESS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('dropped', 'Dropped'),
    ]
    
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    progress = models.CharField(max_length=20, choices=PROGRESS_CHOICES, default='not_started')
    completion_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    grade = models.CharField(max_length=2, blank=True)  # A, B, C, D, F
    
    class Meta:
        unique_together = ['student', 'course']
    
    def __str__(self):
        return f"{self.student.user.username} enrolled in {self.course.title}"
    
    @property
    def is_completed(self):
        return self.progress == 'completed'
```

## Advanced Relationship Patterns

### Generic Foreign Keys: The Universal Connector

**Use case:** Comments that can be attached to any model (posts, photos, videos).

```python
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

class Comment(models.Model):
    # Generic foreign key setup
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    
    # Comment data
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['content_type', 'object_id']),
        ]
    
    def __str__(self):
        return f"Comment by {self.author.username} on {self.content_object}"

# Usage: Comments can be added to any model
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    
class Photo(models.Model):
    image = models.ImageField(upload_to='photos/')
    caption = models.CharField(max_length=200)

# Both can have comments:
# Comment.objects.create(content_object=blog_post, author=user, text="Great post!")
# Comment.objects.create(content_object=photo, author=user, text="Nice photo!")
```

### Self-Referential Relationships: Hierarchical Data

```python
# Organizational hierarchy
class Employee(models.Model):
    name = models.CharField(max_length=100)
    position = models.CharField(max_length=100)
    
    # Self-referential foreign key
    manager = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='direct_reports'
    )
    
    def __str__(self):
        return f"{self.name} ({self.position})"
    
    def get_all_reports(self):
        """Get all employees under this manager (recursive)"""
        direct_reports = self.direct_reports.all()
        all_reports = list(direct_reports)
        
        for report in direct_reports:
            all_reports.extend(report.get_all_reports())
        
        return all_reports
    
    @property
    def is_manager(self):
        return self.direct_reports.exists()

# Comment threading (Reddit/Facebook style)
class ThreadedComment(models.Model):
    post = models.ForeignKey('Post', on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length=1000)
    
    # Self-referential for reply threads
    parent = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='replies'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Comment by {self.author.username}"
    
    @property
    def is_reply(self):
        return self.parent is not None
    
    def get_thread_level(self):
        """Get how deep this comment is in the thread"""
        level = 0
        current = self.parent
        while current:
            level += 1
            current = current.parent
        return level
```

## Relationship Best Practices: Building Scalable Connections

### 1. Choose the Right Relationship Type
```python
# ✅ Correct: One user has one profile
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

# ✅ Correct: Many posts belong to one user
class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)

# ✅ Correct: Posts can have many categories
class Post(models.Model):
    categories = models.ManyToManyField(Category)

# ❌ Wrong: Using ManyToMany when ForeignKey is appropriate
class Post(models.Model):
    author = models.ManyToManyField(User)  # A post has multiple authors? Probably not.
```

### 2. Use Related Names Wisely
```python
class Author(models.Model):
    name = models.CharField(max_length=100)

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(
        Author, 
        on_delete=models.CASCADE,
        related_name='books'  # Access author.books.all()
    )

# Usage:
# author = Author.objects.get(name="J.K. Rowling")
# harry_potter_books = author.books.filter(title__icontains="Harry Potter")
```

### 3. Optimize for Performance
```python
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    categories = models.ManyToManyField('Category')

# ❌ N+1 Query Problem
posts = BlogPost.objects.all()
for post in posts:
    print(post.author.username)  # Hits database for each post!

# ✅ Use select_related for ForeignKey
posts = BlogPost.objects.select_related('author').all()
for post in posts:
    print(post.author.username)  # Only 1 database query!

# ✅ Use prefetch_related for ManyToMany
posts = BlogPost.objects.prefetch_related('categories').all()
for post in posts:
    categories = post.categories.all()  # Already loaded!
```

### 4. Handle Cascading Deletes Thoughtfully
```python
class Customer(models.Model):
    name = models.CharField(max_length=100)

class Order(models.Model):
    customer = models.ForeignKey(
        Customer,
        on_delete=models.PROTECT  # Prevent deleting customer with orders
    )

class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE  # Delete items when order is deleted
    )

class PaymentRecord(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.SET_NULL,  # Keep payment record but remove order reference
        null=True
    )
```

## Real-World Example: Building a Complete E-commerce Model System

```python
from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    parent = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='subcategories'
    )
    
    class Meta:
        verbose_name_plural = "categories"
    
    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.PositiveIntegerField()
    
    # Relationships
    categories = models.ManyToManyField(Category, related_name='products')
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_products'
    )
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.name

class ProductImage(models.Model):
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='images'
    )
    image = models.ImageField(upload_to='products/%Y/%m/')
    alt_text = models.CharField(max_length=200)
    is_primary = models.BooleanField(default=False)
    
    def __str__(self):
        return f"Image for {self.product.name}"

class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    @property
    def total_items(self):
        return sum(item.quantity for item in self.items.all())
    
    @property
    def total_price(self):
        return sum(item.total_price for item in self.items.all())

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    
    class Meta:
        unique_together = ['cart', 'product']
    
    @property
    def total_price(self):
        return self.product.price * self.quantity
    
    def __str__(self):
        return f"{self.quantity}x {self.product.name}"

class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('shipped', 'Shipped'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Order #{self.id} by {self.user.username}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)  # Price at time of order
    
    @property
    def total_price(self):
        return self.price * self.quantity

class Review(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['product', 'user']  # One review per user per product
    
    def __str__(self):
        return f"{self.rating}/5 - {self.title}"
```

Relationships are the DNA of your Django application - they define how your data connects, flows, and creates meaning. Master them, and you'll build applications that can model any real-world complexity! 🚀

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/db/models/ and field references
    ''',
    "is_free": False,
    "xp_reward": 110,
    "exercises": [
        {
            "id": "ecommerce-relationships",
            "title": "Build E-commerce Relationship System",
            "type": "project",
            "instructions": """Create a comprehensive e-commerce system with proper model relationships:

1. User system with profiles and addresses
2. Product catalog with categories and images  
3. Shopping cart and order management
4. Review and rating system
5. Inventory tracking with suppliers

Your solution should demonstrate:
- All three relationship types (ForeignKey, OneToOne, ManyToMany)
- Proper use of related_name and on_delete options
- Self-referential relationships for categories
- Through models for additional data
- Performance optimizations with indexes""",
            "starter_code": """from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

# Build your e-commerce model relationships:

# 1. User Profile (OneToOne with User)
class UserProfile(models.Model):
    # Extend User with profile information
    pass

# 2. Address (ForeignKey to User - users can have multiple addresses)  
class Address(models.Model):
    # User addresses for shipping/billing
    pass

# 3. Category (Self-referential for hierarchy)
class Category(models.Model):
    # Product categories with parent-child relationships
    pass

# 4. Product (ManyToMany with Categories)
class Product(models.Model):
    # Main product model
    pass

# 5. ProductImage (ForeignKey to Product)
class ProductImage(models.Model):
    # Multiple images per product
    pass

# 6. Cart (OneToOne with User)
class Cart(models.Model):
    # Shopping cart
    pass

# 7. CartItem (Through model for Cart-Product relationship)
class CartItem(models.Model):
    # Items in cart with quantities
    pass

# 8. Order (ForeignKey to User)
class Order(models.Model):
    # Customer orders
    pass

# 9. OrderItem (Through model for Order-Product relationship)  
class OrderItem(models.Model):
    # Products in an order
    pass

# 10. Review (ForeignKey to both Product and User)
class Review(models.Model):
    # Product reviews and ratings
    pass""",
            "solution": """from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.urls import reverse
from django.db.models.signals import post_save
from django.dispatch import receiver

class UserProfile(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    phone = models.CharField(max_length=20, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True)
    
    # Preferences
    newsletter_subscription = models.BooleanField(default=True)
    preferred_currency = models.CharField(max_length=3, default='USD')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

class Address(models.Model):
    ADDRESS_TYPES = [
        ('billing', 'Billing'),
        ('shipping', 'Shipping'),
    ]
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='addresses'
    )
    type = models.CharField(max_length=10, choices=ADDRESS_TYPES)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    company = models.CharField(max_length=100, blank=True)
    address_line_1 = models.CharField(max_length=200)
    address_line_2 = models.CharField(max_length=200, blank=True)
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    country = models.CharField(max_length=100)
    is_default = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "addresses"
        indexes = [
            models.Index(fields=['user', 'type']),
        ]
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.city}, {self.country}"

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    
    # Self-referential relationship for hierarchy
    parent = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name='subcategories'
    )
    
    # SEO and display
    meta_title = models.CharField(max_length=200, blank=True)
    meta_description = models.TextField(max_length=300, blank=True)
    is_active = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name_plural = "categories"
        ordering = ['name']
    
    def __str__(self):
        if self.parent:
            return f"{self.parent.name} > {self.name}"
        return self.name
    
    def get_absolute_url(self):
        return reverse('catalog:category', kwargs={'slug': self.slug})
    
    @property
    def is_parent(self):
        return self.subcategories.exists()

class Product(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField()
    short_description = models.CharField(max_length=500, blank=True)
    
    # Pricing
    price = models.DecimalField(max_digits=10, decimal_places=2)
    compare_price = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        null=True, 
        blank=True,
        help_text="Original price for showing discounts"
    )
    cost_price = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    
    # Inventory
    sku = models.CharField(max_length=100, unique=True)
    stock_quantity = models.PositiveIntegerField(default=0)
    low_stock_threshold = models.PositiveIntegerField(default=10)
    
    # Relationships
    categories = models.ManyToManyField(
        Category, 
        related_name='products',
        blank=True
    )
    
    # Meta data
    is_active = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    weight = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['is_active', '-created_at']),
            models.Index(fields=['is_featured']),
            models.Index(fields=['stock_quantity']),
        ]
    
    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('catalog:product', kwargs={'slug': self.slug})
    
    @property
    def is_on_sale(self):
        return self.compare_price and self.price < self.compare_price
    
    @property
    def discount_percentage(self):
        if self.is_on_sale:
            return int(((self.compare_price - self.price) / self.compare_price) * 100)
        return 0
    
    @property
    def is_in_stock(self):
        return self.stock_quantity > 0
    
    @property
    def is_low_stock(self):
        return 0 < self.stock_quantity <= self.low_stock_threshold
    
    @property
    def average_rating(self):
        reviews = self.reviews.filter(is_approved=True)
        if reviews.exists():
            return reviews.aggregate(avg_rating=models.Avg('rating'))['avg_rating']
        return 0
    
    @property
    def review_count(self):
        return self.reviews.filter(is_approved=True).count()

class ProductImage(models.Model):
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='images'
    )
    image = models.ImageField(upload_to='products/%Y/%m/')
    alt_text = models.CharField(max_length=200)
    is_primary = models.BooleanField(default=False)
    sort_order = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['sort_order', 'id']
    
    def __str__(self):
        return f"Image for {self.product.name}"

class Cart(models.Model):
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='cart'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Cart for {self.user.username}"
    
    @property
    def total_items(self):
        return sum(item.quantity for item in self.items.all())
    
    @property
    def subtotal(self):
        return sum(item.total_price for item in self.items.all())
    
    @property
    def is_empty(self):
        return self.items.count() == 0

class CartItem(models.Model):
    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        related_name='items'
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE
    )
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['cart', 'product']
        indexes = [
            models.Index(fields=['cart', 'added_at']),
        ]
    
    def __str__(self):
        return f"{self.quantity}x {self.product.name}"
    
    @property
    def total_price(self):
        return self.product.price * self.quantity

class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending Payment'),
        ('paid', 'Paid'),
        ('processing', 'Processing'),
        ('shipped', 'Shipped'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    ]
    
    # Order identification
    order_number = models.CharField(max_length=50, unique=True)
    
    # Customer info
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='orders'
    )
    
    # Order status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Pricing
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    shipping_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Addresses (snapshot at time of order)
    billing_address = models.TextField()
    shipping_address = models.TextField()
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    shipped_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['status']),
            models.Index(fields=['order_number']),
        ]
    
    def __str__(self):
        return f"Order {self.order_number}"
    
    def get_absolute_url(self):
        return reverse('orders:detail', kwargs={'order_number': self.order_number})
    
    @property
    def can_be_cancelled(self):
        return self.status in ['pending', 'paid']
    
    def save(self, *args, **kwargs):
        if not self.order_number:
            import uuid
            self.order_number = f"ORD-{uuid.uuid4().hex[:8].upper()}"
        super().save(*args, **kwargs)

class OrderItem(models.Model):
    order = models.ForeignKey(
        Order,
        on_delete=models.CASCADE,
        related_name='items'
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE
    )
    
    # Product info at time of order (for historical accuracy)
    product_name = models.CharField(max_length=200)
    product_sku = models.CharField(max_length=100)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField()
    
    class Meta:
        indexes = [
            models.Index(fields=['order']),
        ]
    
    def __str__(self):
        return f"{self.quantity}x {self.product_name}"
    
    @property
    def total_price(self):
        return self.unit_price * self.quantity

class Review(models.Model):
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        related_name='reviews'
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='reviews'
    )
    
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    title = models.CharField(max_length=200)
    content = models.TextField()
    
    # Moderation
    is_approved = models.BooleanField(default=False)
    is_verified_purchase = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['product', 'user']  # One review per user per product
        indexes = [
            models.Index(fields=['product', 'is_approved']),
            models.Index(fields=['user', '-created_at']),
        ]
    
    def __str__(self):
        return f"{self.rating}/5 - {self.title}"

# Signal handlers for automatic relationship management
@receiver(post_save, sender=User)
def create_user_cart_and_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
        Cart.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if hasattr(instance, 'profile'):
        instance.profile.save()""",
            "test_cases": [
                {
                    "name": "Models use proper relationship types and options",
                    "input": "",
                    "expected_contains": ["ForeignKey", "OneToOneField", "ManyToManyField", "related_name", "on_delete"]
                }
            ],
            "xp_reward": 160,
            "hints": [
                "Use OneToOneField for user profiles and carts",
                "Use ForeignKey for one-to-many relationships like user addresses",
                "Use ManyToManyField for products and categories",
                "Add through models for cart items and order items",
                "Include proper indexes for performance optimization"
            ]
        }
    ]
}