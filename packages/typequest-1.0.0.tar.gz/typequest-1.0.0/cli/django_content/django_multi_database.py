"""
Django Database - Lesson 7: Multi-Database Operations
Master Django's multi-database capabilities for scalability and data separation
"""

DJANGO_MULTI_DATABASE_LESSON = {
    "id": 50,
    "chapter": 50,
    "title": "Django Multi-Database: Scaling with Multiple Databases",
    "slug": "django-multi-database",
    "description": "Learn to use multiple databases in Django for read replicas, data separation, and horizontal scaling",
    "content": '''# Django Multi-Database: Scaling with Multiple Databases

## 🎯 Why Multiple Databases?

Modern applications often require **multiple databases** for various reasons:

- **Read/Write Separation** → Write to primary, read from replicas for performance
- **Data Isolation** → Separate databases for different services or features  
- **Geographic Distribution** → Regional databases for reduced latency
- **Database Specialization** → PostgreSQL for complex queries, Redis for caching
- **Compliance Requirements** → Separate databases for different data classifications

Multi-database setups are essential for **high-scale applications** and **microservices architectures**.

## 💾 Multi-Database Architecture Setup

Let's simulate a comprehensive multi-database setup:

```sql
-- PRIMARY DATABASE: Core application data
-- Database: app_primary

-- Users table in primary database
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    profile_data JSONB DEFAULT '{}'::jsonb
);

-- Core application data
INSERT INTO users (username, email, password_hash, profile_data) VALUES
('alice_dev', 'alice@company.com', 'hash123', '{"role": "developer", "team": "backend"}'),
('bob_pm', 'bob@company.com', 'hash456', '{"role": "product_manager", "team": "growth"}'),
('carol_design', 'carol@company.com', 'hash789', '{"role": "designer", "team": "frontend"}'),
('david_data', 'david@company.com', 'hash000', '{"role": "data_scientist", "team": "analytics"}');

-- READ REPLICA DATABASE: Read-only copy for queries
-- Database: app_replica
-- (Contains same data as primary, updated via replication)

-- ANALYTICS DATABASE: Business intelligence and reporting
-- Database: analytics

-- User activity tracking
CREATE TABLE user_activities (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    activity_type VARCHAR(100) NOT NULL,
    activity_data JSONB DEFAULT '{}'::jsonb,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_id VARCHAR(255)
);

-- Page view analytics
CREATE TABLE page_views (
    id SERIAL PRIMARY KEY,
    user_id INTEGER,
    page_url VARCHAR(500) NOT NULL,
    referrer VARCHAR(500),
    view_duration INTEGER, -- in seconds
    device_type VARCHAR(50),
    browser VARCHAR(100),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Business metrics
CREATE TABLE daily_metrics (
    id SERIAL PRIMARY KEY,
    metric_date DATE UNIQUE NOT NULL,
    active_users INTEGER DEFAULT 0,
    new_signups INTEGER DEFAULT 0,
    total_page_views INTEGER DEFAULT 0,
    avg_session_duration DECIMAL(10, 2) DEFAULT 0.00,
    bounce_rate DECIMAL(5, 2) DEFAULT 0.00,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample analytics data
INSERT INTO user_activities (user_id, activity_type, activity_data, ip_address) VALUES
(1, 'login', '{"method": "password", "success": true}', '192.168.1.100'),
(1, 'page_view', '{"page": "/dashboard", "load_time": 1.2}', '192.168.1.100'),
(2, 'login', '{"method": "sso", "success": true}', '192.168.1.101'),
(3, 'feature_usage', '{"feature": "design_tool", "duration": 1800}', '192.168.1.102');

INSERT INTO page_views (user_id, page_url, view_duration, device_type) VALUES
(1, '/dashboard', 120, 'desktop'),
(1, '/projects', 300, 'desktop'),
(2, '/analytics', 450, 'desktop'),
(3, '/design-studio', 1800, 'desktop');

-- CACHE DATABASE: Redis-like fast access data
-- Database: cache_db

-- Session storage
CREATE TABLE user_sessions (
    id SERIAL PRIMARY KEY,
    session_key VARCHAR(255) UNIQUE NOT NULL,
    user_id INTEGER NOT NULL,
    session_data JSONB DEFAULT '{}'::jsonb,
    ip_address INET,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
);

-- Cached data
CREATE TABLE cached_results (
    id SERIAL PRIMARY KEY,
    cache_key VARCHAR(255) UNIQUE NOT NULL,
    cached_data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    hit_count INTEGER DEFAULT 0
);

-- Sample cache data
INSERT INTO user_sessions (session_key, user_id, session_data, expires_at) VALUES
('sess_alice_123', 1, '{"preferences": {"theme": "dark"}, "cart": []}', CURRENT_TIMESTAMP + INTERVAL '7 days'),
('sess_bob_456', 2, '{"preferences": {"theme": "light"}, "dashboard": "analytics"}', CURRENT_TIMESTAMP + INTERVAL '7 days');

-- LOGGING DATABASE: Application logs and audit trails
-- Database: logging

-- Application logs
CREATE TABLE application_logs (
    id SERIAL PRIMARY KEY,
    log_level VARCHAR(20) NOT NULL,
    logger_name VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    user_id INTEGER,
    request_id VARCHAR(100),
    extra_data JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    server_name VARCHAR(100)
);

-- Audit trail
CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id INTEGER,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample logging data
INSERT INTO application_logs (log_level, logger_name, message, user_id, extra_data) VALUES
('INFO', 'auth.views', 'User logged in successfully', 1, '{"login_method": "password"}'),
('WARNING', 'payment.processor', 'Payment processing delayed', 2, '{"amount": 99.99, "reason": "bank_timeout"}'),
('ERROR', 'email.sender', 'Failed to send welcome email', 3, '{"email": "carol@company.com", "error": "smtp_timeout"}');

INSERT INTO audit_logs (user_id, action, resource_type, resource_id, new_values) VALUES
(1, 'CREATE', 'Project', 101, '{"name": "New Website", "status": "active"}'),
(2, 'UPDATE', 'User', 2, '{"email": "bob.new@company.com"}'),
(3, 'DELETE', 'Document', 205, '{"name": "draft_design.pdf"}');
```

## 🔧 Django Multi-Database Configuration

### 1. Database Settings Configuration

**Scenario**: Instagram's database architecture

```python
# settings.py - Multi-database configuration
DATABASES = {
    # Primary database for writes
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'app_primary',
        'USER': 'app_user',
        'PASSWORD': 'secure_password',
        'HOST': 'primary-db.example.com',
        'PORT': '5432',
        'OPTIONS': {
            'sslmode': 'require',
        }
    },
    
    # Read replica for heavy queries
    'replica': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'app_replica',
        'USER': 'replica_user',
        'PASSWORD': 'replica_password',
        'HOST': 'replica-db.example.com',
        'PORT': '5432',
        'OPTIONS': {
            'sslmode': 'require',
        }
    },
    
    # Analytics database for business intelligence
    'analytics': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'analytics',
        'USER': 'analytics_user',
        'PASSWORD': 'analytics_password',
        'HOST': 'analytics-db.example.com',
        'PORT': '5432',
    },
    
    # Cache database for sessions and temporary data
    'cache_db': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'cache_db',
        'USER': 'cache_user',
        'PASSWORD': 'cache_password',
        'HOST': 'cache-db.example.com',
        'PORT': '5432',
    },
    
    # Logging database for audit trails
    'logging': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'logging',
        'USER': 'logging_user',
        'PASSWORD': 'logging_password',
        'HOST': 'logging-db.example.com',
        'PORT': '5432',
    }
}

# Database routing configuration
DATABASE_ROUTERS = [
    'myapp.routers.DatabaseRouter',
]
```

### 2. Database Router - Traffic Direction

**Scenario**: Netflix's database routing for different content types

```python
# myapp/routers.py
class DatabaseRouter:
    """
    A router to control all database operations on models
    """
    
    # App-to-database mapping
    route_app_labels = {
        'analytics': 'analytics',
        'logging': 'logging',
        'cache': 'cache_db',
    }
    
    # Models that should always use replica for reads
    replica_read_models = {
        'auth.User',
        'contenttypes.ContentType',
        'myapp.Product',
        'myapp.Category',
    }
    
    def db_for_read(self, model, **hints):
        """Suggest the database to read from"""
        
        # Route analytics models to analytics database
        if model._meta.app_label == 'analytics':
            return 'analytics'
        
        # Route logging models to logging database
        if model._meta.app_label == 'logging':
            return 'logging'
        
        # Route cache models to cache database
        if model._meta.app_label == 'cache':
            return 'cache_db'
        
        # Use read replica for heavy read models
        model_name = f"{model._meta.app_label}.{model._meta.object_name}"
        if model_name in self.replica_read_models:
            return 'replica'
        
        # Default to primary database
        return 'default'
    
    def db_for_write(self, model, **hints):
        """Suggest the database to write to"""
        
        # Analytics data goes to analytics database
        if model._meta.app_label == 'analytics':
            return 'analytics'
        
        # Logs go to logging database
        if model._meta.app_label == 'logging':
            return 'logging'
        
        # Cache data goes to cache database
        if model._meta.app_label == 'cache':
            return 'cache_db'
        
        # All other writes go to primary
        return 'default'
    
    def allow_relation(self, obj1, obj2, **hints):
        """Allow relations within the same database"""
        db_set = {'default', 'replica'}  # These can relate
        if obj1._state.db in db_set and obj2._state.db in db_set:
            return True
        return None
    
    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """Ensure that certain models' migrations only go to specific databases"""
        
        if app_label == 'analytics':
            return db == 'analytics'
        
        if app_label == 'logging':
            return db == 'logging'
        
        if app_label == 'cache':
            return db == 'cache_db'
        
        # Default apps go to default database
        return db == 'default'
```

### 3. Manual Database Selection

**Scenario**: Amazon's order processing with read/write separation

```python
from django.db import models

class OrderService:
    @staticmethod
    def create_order(user_id, items):
        """Create order - always use primary database for writes"""
        
        # Write operations must use primary database
        order = Order.objects.using('default').create(
            user_id=user_id,
            status='pending',
            total=sum(item['price'] * item['quantity'] for item in items)
        )
        
        for item in items:
            OrderItem.objects.using('default').create(
                order=order,
                product_id=item['product_id'],
                quantity=item['quantity'],
                price=item['price']
            )
        
        # Log the order creation to logging database
        AuditLog.objects.using('logging').create(
            user_id=user_id,
            action='CREATE',
            resource_type='Order',
            resource_id=order.id,
            new_values={
                'status': 'pending',
                'total': str(order.total),
                'item_count': len(items)
            }
        )
        
        return order
    
    @staticmethod
    def get_order_history(user_id):
        """Get order history - can use read replica for better performance"""
        
        # Read from replica for heavy queries
        orders = Order.objects.using('replica').filter(
            user_id=user_id
        ).select_related('user').prefetch_related('items__product')
        
        return orders
    
    @staticmethod
    def get_order_analytics():
        """Get order analytics from analytics database"""
        
        from analytics.models import OrderMetrics
        
        # Use analytics database for business intelligence
        metrics = OrderMetrics.objects.using('analytics').aggregate(
            total_orders=models.Count('order_id'),
            total_revenue=models.Sum('order_total'),
            avg_order_value=models.Avg('order_total')
        )
        
        return metrics
```

### 4. Cross-Database Operations

**Scenario**: Shopify's inventory management across databases

```python
from django.db import transaction

class InventoryService:
    @staticmethod
    def process_purchase(user_id, product_id, quantity):
        """Process purchase across multiple databases"""
        
        # Read product info from replica (performance)
        product = Product.objects.using('replica').get(id=product_id)
        
        # Check inventory in primary database (latest data)
        inventory = Inventory.objects.using('default').select_for_update().get(
            product=product
        )
        
        if inventory.quantity < quantity:
            raise ValueError("Insufficient inventory")
        
        # Use transaction on primary database
        with transaction.atomic(using='default'):
            # Update inventory
            inventory.quantity -= quantity
            inventory.save(using='default')
            
            # Create order
            order = Order.objects.using('default').create(
                user_id=user_id,
                product=product,
                quantity=quantity,
                status='confirmed'
            )
        
        # Log to analytics database (separate transaction)
        try:
            PurchaseEvent.objects.using('analytics').create(
                user_id=user_id,
                product_id=product_id,
                quantity=quantity,
                order_value=product.price * quantity,
                timestamp=timezone.now()
            )
        except Exception as e:
            # Analytics failure shouldn't break purchase
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to log analytics: {e}")
        
        # Cache user's purchase for quick access
        try:
            UserCache.objects.using('cache_db').update_or_create(
                user_id=user_id,
                defaults={
                    'last_purchase_date': timezone.now(),
                    'total_purchases': models.F('total_purchases') + 1
                }
            )
        except Exception:
            pass  # Cache failure is not critical
        
        return order
```

## 🏢 Real-World Production Examples

### Facebook's Multi-Database Architecture

```python
class FacebookDataService:
    """Simulate Facebook's multi-database approach"""
    
    @staticmethod
    def post_content(user_id, content, audience='friends'):
        """Create post across multiple databases"""
        
        # Write to primary database
        post = Post.objects.using('default').create(
            author_id=user_id,
            content=content,
            audience=audience,
            created_at=timezone.now()
        )
        
        # Replicate to regional databases for global access
        for region in ['us_west', 'eu_west', 'asia_pacific']:
            try:
                # Asynchronous replication to regional databases
                RegionalPost.objects.using(region).create(
                    post_id=post.id,
                    author_id=user_id,
                    content=content,
                    region=region
                )
            except Exception as e:
                # Log replication failure
                ReplicationLog.objects.using('logging').create(
                    source_db='default',
                    target_db=region,
                    operation='POST_CREATE',
                    status='FAILED',
                    error_message=str(e)
                )
        
        # Track analytics
        PostAnalytics.objects.using('analytics').create(
            post_id=post.id,
            author_id=user_id,
            audience=audience,
            post_length=len(content)
        )
        
        return post
    
    @staticmethod
    def get_user_feed(user_id, region='default'):
        """Get personalized feed from optimal database"""
        
        # Determine best database based on user's region
        if region == 'default':
            db_name = 'default'
        else:
            db_name = f"{region}_replica"
        
        # Get feed from regional replica
        feed_posts = Post.objects.using(db_name).filter(
            models.Q(audience='public') | 
            models.Q(author__in=get_friends(user_id))
        ).select_related('author').order_by('-created_at')[:50]
        
        # Log feed view to analytics
        FeedView.objects.using('analytics').create(
            user_id=user_id,
            region=region,
            post_count=len(feed_posts)
        )
        
        return feed_posts
```

### Stripe's Payment Processing

```python
class StripePaymentService:
    """Multi-database payment processing like Stripe"""
    
    @staticmethod
    def process_payment(payment_data):
        """Process payment with strict data consistency"""
        
        # Primary database for critical payment data
        with transaction.atomic(using='default'):
            payment = Payment.objects.using('default').create(
                customer_id=payment_data['customer_id'],
                amount=payment_data['amount'],
                currency=payment_data['currency'],
                status='processing'
            )
        
        try:
            # External payment processor call
            processor_response = external_payment_processor(payment_data)
            
            if processor_response['success']:
                # Update payment status
                payment.status = 'completed'
                payment.processor_id = processor_response['transaction_id']
                payment.save(using='default')
                
                # Financial reporting database (immediate consistency)
                FinancialTransaction.objects.using('financial').create(
                    payment_id=payment.id,
                    amount=payment.amount,
                    currency=payment.currency,
                    processor_fee=processor_response['fee'],
                    net_amount=payment.amount - processor_response['fee'],
                    processed_at=timezone.now()
                )
            else:
                payment.status = 'failed'
                payment.failure_reason = processor_response['error']
                payment.save(using='default')
        
        except Exception as e:
            payment.status = 'error'
            payment.error_details = str(e)
            payment.save(using='default')
        
        # Audit logging (eventual consistency is OK)
        try:
            PaymentAudit.objects.using('audit').create(
                payment_id=payment.id,
                action='PAYMENT_PROCESSED',
                status=payment.status,
                user_agent=payment_data.get('user_agent'),
                ip_address=payment_data.get('ip_address')
            )
        except Exception:
            pass  # Audit failure shouldn't break payment
        
        return payment
```

### Netflix's Content Distribution

```python
class NetflixContentService:
    """Content distribution across global databases"""
    
    @staticmethod
    def upload_content(content_data):
        """Upload content to global distribution network"""
        
        # Master content database
        content = Content.objects.using('content_master').create(
            title=content_data['title'],
            description=content_data['description'],
            content_type=content_data['type'],
            upload_status='processing'
        )
        
        # Replicate to regional content databases
        regions = ['us_east', 'us_west', 'eu_west', 'asia_pacific']
        
        for region in regions:
            try:
                RegionalContent.objects.using(f'content_{region}').create(
                    master_content_id=content.id,
                    title=content.title,
                    description=content.description,
                    region=region,
                    availability_date=timezone.now() + timedelta(hours=2)  # Processing time
                )
            except Exception as e:
                # Log replication issues
                ContentReplicationLog.objects.using('operations').create(
                    content_id=content.id,
                    target_region=region,
                    status='FAILED',
                    error=str(e)
                )
        
        # Analytics tracking
        ContentUploadAnalytics.objects.using('analytics').create(
            content_id=content.id,
            content_type=content.content_type,
            file_size=content_data.get('file_size', 0),
            upload_duration=content_data.get('upload_duration', 0)
        )
        
        return content
    
    @staticmethod
    def get_user_recommendations(user_id, region='us_east'):
        """Get personalized recommendations from regional database"""
        
        # Use regional database for better performance
        db_name = f'content_{region}'
        
        # Get user's viewing history from analytics
        viewing_history = ViewingHistory.objects.using('analytics').filter(
            user_id=user_id
        ).values('content_id', 'rating', 'completion_rate')
        
        # Get recommendations from regional content database
        recommendations = RegionalContent.objects.using(db_name).filter(
            availability_date__lte=timezone.now(),
            region=region
        ).exclude(
            master_content_id__in=[h['content_id'] for h in viewing_history]
        )[:20]
        
        # Log recommendation request
        RecommendationLog.objects.using('analytics').create(
            user_id=user_id,
            region=region,
            recommendation_count=len(recommendations)
        )
        
        return recommendations
```

## ⚡ Multi-Database Best Practices

### 1. Connection Pooling and Performance

```python
# settings.py - Optimized database connections
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        # ... connection details ...
        'OPTIONS': {
            'MAX_CONNS': 20,  # Connection pool size
            'sslmode': 'require',
        },
        'CONN_MAX_AGE': 600,  # Connection persistence (10 minutes)
    },
    'replica': {
        'ENGINE': 'django.db.backends.postgresql',
        # ... connection details ...
        'OPTIONS': {
            'MAX_CONNS': 50,  # More connections for read replica
        },
        'CONN_MAX_AGE': 0,  # Don't persist connections for replicas
    }
}
```

### 2. Database Health Monitoring

```python
from django.db import connections
from django.core.management.base import BaseCommand

class DatabaseHealthChecker:
    """Monitor database health across all connections"""
    
    @staticmethod
    def check_all_databases():
        """Check health of all configured databases"""
        health_status = {}
        
        for db_name in connections.databases:
            try:
                connection = connections[db_name]
                
                # Test basic connectivity
                with connection.cursor() as cursor:
                    cursor.execute("SELECT 1")
                    result = cursor.fetchone()
                
                # Check connection pool status
                pool_info = {
                    'database': db_name,
                    'status': 'healthy' if result else 'unhealthy',
                    'connection_count': getattr(connection, 'queries_logged', 0)
                }
                
                health_status[db_name] = pool_info
                
            except Exception as e:
                health_status[db_name] = {
                    'database': db_name,
                    'status': 'error',
                    'error': str(e)
                }
        
        return health_status
```

### 3. Data Consistency Patterns

```python
class DataConsistencyService:
    """Ensure data consistency across databases"""
    
    @staticmethod
    def eventual_consistency_sync():
        """Sync data for eventual consistency"""
        
        # Find records that need syncing
        primary_users = User.objects.using('default').filter(
            last_modified__gte=timezone.now() - timedelta(minutes=5)
        )
        
        for user in primary_users:
            # Sync to analytics database
            try:
                UserAnalytics.objects.using('analytics').update_or_create(
                    user_id=user.id,
                    defaults={
                        'username': user.username,
                        'email': user.email,
                        'is_active': user.is_active,
                        'last_synced': timezone.now()
                    }
                )
            except Exception as e:
                # Log sync failure
                SyncLog.objects.using('logging').create(
                    source_db='default',
                    target_db='analytics',
                    table_name='users',
                    record_id=user.id,
                    status='FAILED',
                    error=str(e)
                )
```

## 🎯 Key Takeaways

1. **Database routers control data flow** across multiple databases automatically
2. **using() parameter provides manual database selection** for specific operations
3. **Cross-database relations are limited** - design accordingly
4. **Read replicas improve performance** for query-heavy applications
5. **Separate databases enable data isolation** and compliance requirements
6. **Monitor database health** and connection pool usage
7. **Plan for eventual consistency** in distributed database architectures

Multi-database setups enable Django applications to scale horizontally and handle enterprise-level data requirements!
''',
    "difficulty": "advanced",
    "estimated_time": 55,
    "xp_reward": 35,
    "prerequisites": ["django-models-foundations", "django-transactions", "django-aggregation"],
    "exercises": [
        {
            "id": "multi_db_1",
            "title": "Explore Primary Database Users",
            "prompt": "Let's start by examining our primary database with core user data. Write a query to see all users in the main application database.",
            "table_name": "users",
            "initial_query": "SELECT * FROM users;",
            "expected_keywords": ["SELECT", "*", "FROM", "users"],
            "hint": "Use SELECT * FROM users; to see the primary user data",
            "solution": "SELECT * FROM users;",
            "explanation": "This shows our primary database with core user accounts. In Django multi-database setups, this would typically be accessed via the 'default' database using User.objects.using('default').all()."
        },
        {
            "id": "multi_db_2",
            "title": "Analytics Database User Activities",
            "prompt": "Look at the analytics database to see user activity tracking. Write a query to see user activities with their types and timestamps.",
            "table_name": "user_activities",
            "expected_keywords": ["SELECT", "user_id", "activity_type", "timestamp", "FROM"],
            "hint": "Select user_id, activity_type, and timestamp to see activity patterns",
            "solution": "SELECT user_id, activity_type, activity_data, timestamp FROM user_activities ORDER BY timestamp DESC;",
            "explanation": "This analytics data would be in a separate 'analytics' database in Django. You'd query it using UserActivity.objects.using('analytics').all(). Separating analytics from core data improves performance and allows specialized optimization."
        },
        {
            "id": "multi_db_3",
            "title": "Cross-Database User Analysis",
            "prompt": "Simulate joining data across databases by finding users who have recent activity. First, identify active user IDs from user_activities, then we'd look them up in the users table.",
            "table_name": "user_activities",
            "expected_keywords": ["SELECT", "DISTINCT", "user_id", "WHERE", "timestamp"],
            "hint": "Find distinct user_ids from recent activities (last day)",
            "solution": "SELECT DISTINCT user_id FROM user_activities WHERE timestamp >= CURRENT_DATE - INTERVAL '1 day';",
            "explanation": "In Django multi-database, you'd query each database separately: active_user_ids = UserActivity.objects.using('analytics').filter(timestamp__gte=yesterday).values_list('user_id', flat=True).distinct(), then users = User.objects.using('default').filter(id__in=active_user_ids)."
        },
        {
            "id": "multi_db_4",
            "title": "Session Data from Cache Database",
            "prompt": "Look at the cache database session storage. Write a query to see active user sessions with their expiration times.",
            "table_name": "user_sessions",
            "expected_keywords": ["SELECT", "user_id", "session_key", "expires_at", "WHERE"],
            "hint": "Filter for active sessions that haven't expired yet",
            "solution": "SELECT user_id, session_key, expires_at, is_active FROM user_sessions WHERE is_active = true AND expires_at > CURRENT_TIMESTAMP ORDER BY expires_at DESC;",
            "explanation": "Session data in the cache database provides fast access for authentication. In Django: Session.objects.using('cache_db').filter(is_active=True, expires_at__gt=timezone.now()). Cache databases are optimized for quick reads and writes."
        },
        {
            "id": "multi_db_5",
            "title": "Audit Trail from Logging Database",
            "prompt": "Examine the logging database for audit trails. Write a query to see user actions and what resources they affected.",
            "table_name": "audit_logs",
            "expected_keywords": ["SELECT", "user_id", "action", "resource_type", "timestamp"],
            "hint": "Select user_id, action, resource_type, and timestamp to see audit trail",
            "solution": "SELECT user_id, action, resource_type, resource_id, timestamp FROM audit_logs ORDER BY timestamp DESC;",
            "explanation": "Audit logs are typically stored in a separate database for security and compliance. In Django: AuditLog.objects.using('logging').all(). This separation ensures audit integrity and doesn't impact application performance."
        },
        {
            "id": "multi_db_6",
            "title": "Daily Metrics Aggregation",
            "prompt": "Look at business metrics in the analytics database. Write a query to see daily metrics like active users and page views.",
            "table_name": "daily_metrics",
            "expected_keywords": ["SELECT", "metric_date", "active_users", "new_signups", "total_page_views"],
            "hint": "Select all the daily metrics columns to see business intelligence data",
            "solution": "SELECT metric_date, active_users, new_signups, total_page_views, avg_session_duration FROM daily_metrics ORDER BY metric_date DESC;",
            "explanation": "Business metrics are often pre-calculated and stored in analytics databases for fast dashboard queries. In Django: DailyMetrics.objects.using('analytics').order_by('-metric_date'). This avoids expensive real-time aggregations on the primary database."
        }
    ],
    "key_concepts": [
        "Multi-Database Configuration",
        "Database Routing and Traffic Direction",
        "Read/Write Database Separation",
        "Cross-Database Operations and Limitations",
        "Manual Database Selection with using()",
        "Data Consistency Patterns",
        "Performance Optimization Strategies",
        "Database Health Monitoring"
    ]
}