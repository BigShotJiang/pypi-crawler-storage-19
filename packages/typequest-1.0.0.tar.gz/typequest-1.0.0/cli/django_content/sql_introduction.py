"""
SQL Introduction lesson content
"""

SQL_INTRODUCTION_LESSON = {
    "id": 30,
    "chapter": 30,
    "title": "Introduction to SQL",
    "slug": "sql-introduction",
    "content": '''
# Introduction to SQL: Your Gateway to Data Mastery

Think of SQL as the universal language of data - like English for international business or JavaScript for web development. Whether you're analyzing Netflix viewing patterns, managing Amazon's product catalog, or organizing Spotify's music library, SQL is the key that unlocks the power of structured data.

## What is SQL?

**SQL (Structured Query Language)** is a programming language designed for managing and querying relational databases. It's like having a conversation with your database - you ask questions in SQL, and the database responds with exactly the data you need.

**Real-world analogy:** Imagine SQL as a super-efficient librarian who can instantly find any book, author, or topic across millions of volumes. Instead of manually searching through endless shelves, you simply describe what you want, and SQL retrieves it instantly.

## Why SQL Matters in the Real World

### Industry Usage Examples:

**Netflix:** Uses SQL to analyze viewing patterns
```sql
-- Find most watched shows by genre
SELECT genre, title, total_views
FROM netflix_content 
WHERE total_views > 1000000
ORDER BY total_views DESC;
```

**Amazon:** Manages product catalogs and customer orders
```sql
-- Find top-selling products this month
SELECT product_name, SUM(quantity) as total_sold
FROM order_items oi
JOIN orders o ON oi.order_id = o.id
WHERE o.order_date >= '2024-01-01'
GROUP BY product_name
ORDER BY total_sold DESC;
```

**Spotify:** Analyzes music preferences and recommendations
```sql
-- Find users' most played genres
SELECT user_id, genre, COUNT(*) as play_count
FROM user_listening_history ulh
JOIN songs s ON ulh.song_id = s.id
GROUP BY user_id, genre
ORDER BY play_count DESC;
```

## Understanding Database Tables

Tables are the foundation of SQL databases. Think of them as sophisticated Excel spreadsheets with strict rules and powerful capabilities.

### Table Structure Analogy:
- **Table = Filing Cabinet** (stores related information)
- **Rows = Individual Files** (specific records)  
- **Columns = File Categories** (consistent properties)

### Example: Instagram Users Table
```
users
+----+----------+-------------+---------------+----------------+
| id | username | email       | follower_count| created_at     |
+----+----------+-------------+---------------+----------------+
| 1  | john_doe | john@email  | 1500          | 2023-01-15     |
| 2  | jane_art | jane@email  | 2300          | 2023-02-20     |
| 3  | mike_dev | mike@email  | 890           | 2023-03-10     |
+----+----------+-------------+---------------+----------------+
```

## Your First SQL Query: SELECT

The `SELECT` statement is like asking "Show me..." - it's how you request data from your database.

### Basic Syntax:
```sql
SELECT column_names
FROM table_name;
```

### Essential Patterns:

**1. Select specific columns:**
```sql
-- Show just usernames and email addresses
SELECT username, email 
FROM users;
```

**2. Select all columns:**
```sql
-- Show everything about users (* means "all columns")
SELECT * 
FROM users;
```

**3. Select with simple calculations:**
```sql
-- Show usernames and follower count in thousands
SELECT username, follower_count / 1000 AS followers_k
FROM users;
```

## Real-World Database Examples

Let's explore tables modeled after famous platforms:

### YouTube Videos Table (youtube_videos)
```
+--------+------------------------+-------------+------------+-------+
| id     | title                  | channel     | views      | likes |
+--------+------------------------+-------------+------------+-------+
| 101    | Python Tutorial        | CodeAcademy | 1200000    | 45000 |
| 102    | SQL for Beginners      | TechEd      | 890000     | 32000 |
| 103    | Web Design Basics      | DesignPro   | 2100000    | 78000 |
| 104    | JavaScript Crash Course| CodeMaster  | 1500000    | 56000 |
+--------+------------------------+-------------+------------+-------+
```

### Amazon Products Table (amazon_products)
```
+----+------------------+-----------+-------+----------+
| id | name             | category  | price | rating   |
+----+------------------+-----------+-------+----------+
| 1  | iPhone 15        | Electronics| 999   | 4.5     |
| 2  | MacBook Pro      | Electronics| 2499  | 4.8     |
| 3  | Coffee Maker     | Kitchen   | 89    | 4.2     |
| 4  | Running Shoes    | Sports    | 129   | 4.6     |
+----+------------------+-----------+-------+----------+
```

### Netflix Shows Table (netflix_shows)
```
+----+------------------+----------+-------+-----------+
| id | title            | genre    | rating| year      |
+----+------------------+----------+-------+-----------+
| 1  | Stranger Things  | Sci-Fi   | 8.7   | 2016     |
| 2  | The Crown        | Drama    | 8.6   | 2016     |
| 3  | Breaking Bad     | Crime    | 9.5   | 2008     |
| 4  | Friends          | Comedy   | 8.9   | 1994     |
+----+------------------+----------+-------+-----------+
```

## Essential SQL Concepts

### 1. Data Types
Understanding what kind of data each column holds:

- **TEXT/VARCHAR:** Usernames, titles, descriptions
- **INTEGER:** IDs, counts, ages
- **DECIMAL/FLOAT:** Prices, ratings, percentages
- **DATE/DATETIME:** Creation dates, timestamps
- **BOOLEAN:** True/false flags (is_active, is_premium)

### 2. Primary Keys
Every table needs a unique identifier (like a social security number):
```sql
-- Each user has a unique ID
SELECT * FROM users WHERE id = 1;  -- Returns exactly one user
```

### 3. Case Sensitivity
SQL keywords are traditionally uppercase, but most databases accept lowercase:
```sql
-- Both of these work identically
SELECT username FROM users;
select username from users;

-- We'll use lowercase for readability
```

## SQL in Modern Applications

### Social Media Platform
```sql
-- Find trending posts (Instagram/TikTok style)
SELECT * FROM posts 
WHERE likes > 10000 
  AND created_at > '2024-01-01';
```

### E-commerce Analysis
```sql
-- Find best-selling products (Amazon style)
SELECT name, SUM(quantity_sold) 
FROM products 
GROUP BY name 
ORDER BY SUM(quantity_sold) DESC;
```

### Streaming Service
```sql
-- Find top-rated content (Netflix style)
SELECT title, rating 
FROM shows 
WHERE rating > 8.0 
ORDER BY rating DESC;
```

## Your SQL Journey Starts Here

Mastering SQL opens doors to:
- **Data Analysis:** Understanding user behavior, sales trends, performance metrics
- **Application Development:** Building dynamic websites and mobile apps
- **Business Intelligence:** Making data-driven decisions
- **Career Growth:** SQL skills are in demand across all tech roles

**Remember:** Every expert was once a beginner. The most complex data analysis starts with a simple `SELECT` statement. Let's begin your journey to data mastery!

**Next:** We'll dive into basic SELECT queries and start exploring real data from famous platforms.
    ''',
    "is_free": True,
    "xp_reward": 50,
    "exercises": [
        {
            "id": "sql-basics-intro",
            "title": "SQL Fundamentals Introduction",
            "type": "conceptual",
            "instructions": """Welcome to SQL! This introductory exercise will help you understand basic concepts without writing code yet.

Answer these conceptual questions to build your SQL foundation:

1. What does SQL stand for and what is its primary purpose?
2. How is a database table similar to a spreadsheet?
3. What is the difference between a row and a column in a table?
4. What does the SELECT statement do in SQL?
5. Why might Netflix or Amazon use SQL in their systems?""",
            "starter_code": """-- This is a SQL comment (starts with --)
-- You'll learn to write queries like this:

-- Example: Get all users
SELECT * FROM users;

-- Example: Get specific information  
SELECT username, email FROM users;

-- For now, just read and understand the structure
-- We'll start writing real queries in the next lesson!""",
            "solution": """Answers to the conceptual questions:

1. SQL stands for Structured Query Language. Its primary purpose is to communicate with relational databases - to store, retrieve, update, and manage data efficiently.

2. A database table is similar to a spreadsheet in that both organize data in rows and columns. However, database tables have stricter rules, better performance, and can handle much larger amounts of data with relationships between different tables.

3. A ROW represents a single record or entry (like one user, one product, one order). A COLUMN represents a specific attribute or property that all records share (like username, price, or date).

4. The SELECT statement retrieves data from database tables. It's like asking "Show me..." and specifying what information you want to see.

5. Netflix uses SQL to analyze viewing patterns, recommend content, and manage their catalog. Amazon uses SQL to track inventory, process orders, analyze customer behavior, and manage their vast product database. Both companies need to quickly access and analyze massive amounts of data.""",
            "test_cases": [
                {
                    "name": "Conceptual understanding",
                    "input": "Understanding check", 
                    "expected_contains": ["SELECT", "database", "table", "rows", "columns"]
                }
            ],
            "xp_reward": 25,
            "hints": [
                "Think of SQL as a language for talking to databases",
                "Tables organize data in a structured, predictable way", 
                "Every major tech company relies on SQL for data management",
                "SELECT is the most fundamental and important SQL command"
            ]
        }
    ]
}