"""
Django URLconf Usage with Class-Based Views lesson content
"""

DJANGO_URLCONF_USAGE_LESSON = {
    "id": 13,
    "chapter": 13,
    "title": "Usage in URLconf - Routing to Class-Based Views",
    "slug": "urlconf-usage",
    "content": '''
# URLconf Usage: Connecting URLs to Class-Based Views

Think of URLconf as the reception desk of a large office building. When visitors (HTTP requests) arrive, the receptionist (URL dispatcher) looks at their destination (URL path) and directs them to the right department (view) using the building directory (URL patterns).

## The .as_view() Method: Converting Classes to Functions

Django's URL system expects function-based views, but we want to use class-based views. The `.as_view()` method is like a translator that converts your class into a function that Django's URL system can understand.

**Restaurant analogy:** A class-based view is like a restaurant kitchen (with chefs, equipment, and processes), but the front door only accepts individual orders. `.as_view()` is like the waiter who takes orders from customers and delivers them to the kitchen.

### Basic URLconf Pattern
```python
# urls.py
from django.urls import path
from .views import BookListView, BookDetailView

urlpatterns = [
    # Convert class to function with .as_view()
    path('books/', BookListView.as_view(), name='book-list'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='book-detail'),
]
```

**What happens behind the scenes:**
1. `BookListView.as_view()` creates a function
2. When a request comes to `/books/`, Django calls this function
3. The function creates an instance of `BookListView`
4. It calls the appropriate method (get, post, etc.)
5. Returns the response

## URL Pattern Variations: Flexible Routing

### Simple Patterns
```python
from django.urls import path
from .views import (
    HomeView, AboutView, ContactView,
    BookListView, BookDetailView, BookCreateView
)

urlpatterns = [
    # Static pages
    path('', HomeView.as_view(), name='home'),
    path('about/', AboutView.as_view(), name='about'),
    path('contact/', ContactView.as_view(), name='contact'),
    
    # Book CRUD operations
    path('books/', BookListView.as_view(), name='book-list'),
    path('books/new/', BookCreateView.as_view(), name='book-create'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='book-detail'),
    path('books/<int:pk>/edit/', BookUpdateView.as_view(), name='book-edit'),
    path('books/<int:pk>/delete/', BookDeleteView.as_view(), name='book-delete'),
]
```

### Advanced URL Patterns with Parameters
```python
from django.urls import path, include
from .views import (
    CategoryBookListView, AuthorBookListView, 
    BookSearchView, BooksByYearView
)

urlpatterns = [
    # Category-based listing
    path('books/category/<slug:category>/', 
         CategoryBookListView.as_view(), 
         name='books-by-category'),
    
    # Author-based listing  
    path('books/author/<int:author_id>/',
         AuthorBookListView.as_view(),
         name='books-by-author'),
    
    # Search functionality
    path('books/search/',
         BookSearchView.as_view(),
         name='book-search'),
    
    # Year-based archives
    path('books/<int:year>/',
         BooksByYearView.as_view(),
         name='books-by-year'),
    
    # Date-based archives with multiple parameters
    path('books/<int:year>/<int:month>/',
         BooksByMonthView.as_view(),
         name='books-by-month'),
]
```

**Library analogy:** These URLs are like different ways to organize and find books:
- `/books/category/fiction/` = Fiction section
- `/books/author/42/` = Books by a specific author  
- `/books/2024/` = Books published in 2024
- `/books/search/` = Search catalog

## Passing Extra Arguments to Views

Sometimes you want to pass additional information to your views without changing the URL structure.

### Static Arguments
```python
from django.urls import path
from .views import BookListView

urlpatterns = [
    # Featured books (same view, different data)
    path('books/featured/',
         BookListView.as_view(
             queryset=Book.objects.filter(is_featured=True),
             template_name='books/featured_list.html',
             context_object_name='featured_books',
             extra_context={'page_title': 'Featured Books'}
         ),
         name='featured-books'),
    
    # Recent books
    path('books/recent/',
         BookListView.as_view(
             queryset=Book.objects.filter(
                 created_at__gte=timezone.now() - timedelta(days=30)
             ),
             template_name='books/recent_list.html',
             extra_context={'page_title': 'Recent Additions'}
         ),
         name='recent-books'),
]
```

**Clothing store analogy:** It's like having the same display system (view) but configuring it to show different collections - "Summer Collection" vs "Winter Collection" using the same display mechanism.

### Dynamic Arguments with kwargs
```python
urlpatterns = [
    # Pass custom arguments to the view
    path('books/special/',
         BookListView.as_view(),
         {'category': 'special', 'featured_only': True},
         name='special-books'),
    
    path('admin/books/',
         BookListView.as_view(),
         {'admin_mode': True},
         name='admin-book-list'),
]

# In your view
class BookListView(ListView):
    model = Book
    
    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Access URL kwargs
        if self.kwargs.get('featured_only'):
            queryset = queryset.filter(is_featured=True)
        
        if self.kwargs.get('admin_mode'):
            # Show all books including drafts for admins
            return queryset
        
        return queryset.filter(is_published=True)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        if self.kwargs.get('admin_mode'):
            context['admin_mode'] = True
            context['page_title'] = 'Admin: All Books'
        
        return context
```

## URL Namespacing: Organizing Large Applications

As applications grow, you need to organize URLs to avoid conflicts and improve maintainability.

### App-Level Namespacing
```python
# books/urls.py (app-specific URLs)
from django.urls import path
from . import views

app_name = 'books'  # Define namespace

urlpatterns = [
    path('', views.BookListView.as_view(), name='list'),
    path('<int:pk>/', views.BookDetailView.as_view(), name='detail'),
    path('create/', views.BookCreateView.as_view(), name='create'),
    path('<int:pk>/edit/', views.BookUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.BookDeleteView.as_view(), name='delete'),
    
    # Author-related URLs
    path('authors/', views.AuthorListView.as_view(), name='author-list'),
    path('authors/<int:pk>/', views.AuthorDetailView.as_view(), name='author-detail'),
]

# main/urls.py (project-level URLs)
from django.urls import path, include

urlpatterns = [
    path('books/', include('books.urls')),  # Include with namespace
    path('blog/', include('blog.urls')),
    path('shop/', include('shop.urls')),
]
```

**Usage in templates and views:**
```html
<!-- In templates -->
<a href="{% url 'books:list' %}">All Books</a>
<a href="{% url 'books:detail' book.pk %}">{{ book.title }}</a>
<a href="{% url 'books:edit' book.pk %}">Edit</a>

<!-- Avoiding namespace collisions -->
<a href="{% url 'blog:list' %}">Blog Posts</a>  <!-- Different from books:list -->
<a href="{% url 'shop:list' %}">Products</a>     <!-- Different from books:list -->
```

```python
# In views
from django.urls import reverse_lazy

class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author']
    success_url = reverse_lazy('books:list')  # Use namespace
```

**Office building analogy:** Namespacing is like having department codes:
- `books:list` = "Books Department, List Section"
- `blog:list` = "Blog Department, List Section"  
- `shop:list` = "Shop Department, List Section"

## Advanced URL Patterns with Class-Based Views

### RESTful API-Style URLs
```python
from django.urls import path
from .views import BookAPIView

urlpatterns = [
    # RESTful book API
    path('api/books/', 
         BookAPIView.as_view(http_method_names=['get', 'post']),
         name='book-api-list'),
    
    path('api/books/<int:pk>/',
         BookAPIView.as_view(http_method_names=['get', 'put', 'delete']),
         name='book-api-detail'),
]

# The view handles different HTTP methods
class BookAPIView(View):
    def get(self, request, pk=None):
        if pk:
            # Return single book
            book = get_object_or_404(Book, pk=pk)
            return JsonResponse({'book': book.title})
        else:
            # Return list of books
            books = Book.objects.all()[:10]
            return JsonResponse({'books': [b.title for b in books]})
    
    def post(self, request):
        # Create new book
        pass
    
    def put(self, request, pk):
        # Update existing book
        pass
    
    def delete(self, request, pk):
        # Delete book
        pass
```

### Conditional URL Routing
```python
from django.urls import path, include
from django.conf import settings

urlpatterns = [
    path('books/', BookListView.as_view(), name='book-list'),
]

# Add debug URLs only in development
if settings.DEBUG:
    urlpatterns += [
        path('debug/books/', 
             BookListView.as_view(extra_context={'debug': True}),
             name='debug-book-list'),
    ]
```

### Multi-Language URL Patterns
```python
from django.urls import path, include
from django.conf.urls.i18n import i18n_patterns

# Non-translated URLs (API, admin, etc.)
urlpatterns = [
    path('api/', include('api.urls')),
    path('admin/', admin.site.urls),
]

# Translated URLs with language prefix
urlpatterns += i18n_patterns(
    path('', HomeView.as_view(), name='home'),
    path('books/', BookListView.as_view(), name='book-list'),
    path('about/', AboutView.as_view(), name='about'),
)

# Generates URLs like:
# /en/books/ (English)
# /es/books/ (Spanish) 
# /fr/books/ (French)
```

## URL Reversing: Dynamic URL Generation

URL reversing lets you generate URLs programmatically instead of hard-coding them.

### In Views
```python
from django.urls import reverse, reverse_lazy
from django.shortcuts import redirect

class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author']
    
    def get_success_url(self):
        # Dynamic URL generation
        return reverse('books:detail', kwargs={'pk': self.object.pk})

def my_view(request):
    # Redirect to another view
    return redirect('books:list')
    
    # Or with parameters
    return redirect('books:detail', pk=42)
```

### In Templates
```html
<!-- Static URLs -->
<a href="{% url 'books:list' %}">All Books</a>

<!-- URLs with parameters -->
<a href="{% url 'books:detail' book.pk %}">{{ book.title }}</a>
<a href="{% url 'books:edit' pk=book.pk %}">Edit</a>

<!-- URLs with multiple parameters -->
<a href="{% url 'books:by-author' author_id=book.author.pk %}">
    More by {{ book.author.name }}
</a>

<!-- Conditional URLs -->
{% if user.is_authenticated %}
    <a href="{% url 'books:create' %}">Add New Book</a>
{% endif %}
```

## Real-World URL Organization Example

Here's how a complete book management application might organize its URLs:

```python
# project/urls.py (main URLs)
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('', include('core.urls')),           # Homepage, about, etc.
    path('books/', include('books.urls')),     # Book management
    path('authors/', include('authors.urls')), # Author management
    path('api/v1/', include('api.urls')),      # API endpoints
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# books/urls.py (book-specific URLs)
from django.urls import path
from . import views

app_name = 'books'

urlpatterns = [
    # Main book views
    path('', views.BookListView.as_view(), name='list'),
    path('search/', views.BookSearchView.as_view(), name='search'),
    path('create/', views.BookCreateView.as_view(), name='create'),
    
    # Individual book operations
    path('<int:pk>/', views.BookDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.BookUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.BookDeleteView.as_view(), name='delete'),
    
    # Category and filtering
    path('category/<slug:category>/', 
         views.CategoryBookListView.as_view(), 
         name='by-category'),
    
    # Archive views
    path('archive/<int:year>/', 
         views.BookYearArchiveView.as_view(),
         name='year-archive'),
    
    path('archive/<int:year>/<int:month>/',
         views.BookMonthArchiveView.as_view(),
         name='month-archive'),
    
    # Special collections
    path('featured/', 
         views.BookListView.as_view(
             queryset=Book.objects.filter(is_featured=True),
             template_name='books/featured.html'
         ),
         name='featured'),
    
    path('bestsellers/',
         views.BookListView.as_view(
             queryset=Book.objects.filter(is_bestseller=True),
             template_name='books/bestsellers.html'
         ),
         name='bestsellers'),
]
```

**Navigation template example:**
```html
<!-- books/base.html -->
<nav class="book-navigation">
    <ul>
        <li><a href="{% url 'books:list' %}">All Books</a></li>
        <li><a href="{% url 'books:featured' %}">Featured</a></li>
        <li><a href="{% url 'books:bestsellers' %}">Bestsellers</a></li>
        <li><a href="{% url 'books:search' %}">Search</a></li>
        
        {% if user.is_authenticated %}
            <li><a href="{% url 'books:create' %}">Add Book</a></li>
        {% endif %}
        
        {% if user.is_staff %}
            <li><a href="{% url 'admin:books_book_changelist' %}">Admin</a></li>
        {% endif %}
    </ul>
</nav>
```

## Performance Considerations

### URL Pattern Optimization
```python
# ❌ Inefficient - complex regex patterns
urlpatterns = [
    path(r'^books/(?P<category>[a-zA-Z0-9_-]+)/$', ...),
    path(r'^books/(?P<pk>\d+)/(?P<action>[a-z]+)/$', ...),
]

# ✅ Efficient - simple patterns first
urlpatterns = [
    path('books/', BookListView.as_view(), name='list'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='detail'),
    path('books/<slug:category>/', CategoryView.as_view(), name='category'),
]
```

### Caching URL Reversals
```python
from functools import lru_cache

class BookDetailView(DetailView):
    model = Book
    
    @lru_cache(maxsize=128)
    def get_success_url(self):
        return reverse('books:list')
```

## Testing URL Patterns

```python
from django.test import TestCase
from django.urls import reverse, resolve
from django.contrib.auth.models import User
from .views import BookListView, BookDetailView

class URLTests(TestCase):
    def test_book_list_url(self):
        url = reverse('books:list')
        self.assertEqual(url, '/books/')
        
        # Test URL resolves to correct view
        resolved = resolve('/books/')
        self.assertEqual(resolved.func.__name__, BookListView.as_view().__name__)
    
    def test_book_detail_url(self):
        url = reverse('books:detail', kwargs={'pk': 1})
        self.assertEqual(url, '/books/1/')
        
        resolved = resolve('/books/1/')
        self.assertEqual(resolved.func.__name__, BookDetailView.as_view().__name__)
        self.assertEqual(resolved.kwargs, {'pk': '1'})
    
    def test_category_url_with_slug(self):
        url = reverse('books:by-category', kwargs={'category': 'fiction'})
        self.assertEqual(url, '/books/category/fiction/')
```

## Common Pitfalls and Solutions

### Pitfall 1: Forgetting .as_view()
```python
# ❌ Wrong - class instead of function
urlpatterns = [
    path('books/', BookListView, name='book-list'),
]

# ✅ Correct - convert to function
urlpatterns = [
    path('books/', BookListView.as_view(), name='book-list'),
]
```

### Pitfall 2: URL Order Matters
```python
# ❌ Wrong order - 'create' will match <int:pk> pattern
urlpatterns = [
    path('books/<int:pk>/', BookDetailView.as_view(), name='detail'),
    path('books/create/', BookCreateView.as_view(), name='create'),  # Never reached!
]

# ✅ Correct order - specific patterns first
urlpatterns = [
    path('books/create/', BookCreateView.as_view(), name='create'),
    path('books/<int:pk>/', BookDetailView.as_view(), name='detail'),
]
```

### Pitfall 3: Circular Import Issues
```python
# ❌ Can cause circular imports
from .views import BookListView  # At module level

urlpatterns = [
    path('books/', BookListView.as_view(), name='list'),
]

# ✅ Better - import in patterns or use strings
urlpatterns = [
    path('books/', 'books.views.BookListView', name='list'),
]
```

URL configuration is the traffic control system of your Django application. Master it to create clean, maintainable, and user-friendly web applications!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/#usage-in-your-urlconf
    ''',
    "is_free": False,
    "xp_reward": 65,
    "exercises": [
        {
            "id": "complete-url-system",
            "title": "Build Complete URL Routing System",
            "type": "project",
            "instructions": """Create a comprehensive URL system for a library management application:

1. Organize URLs with proper namespacing
2. Implement RESTful URL patterns for books
3. Add search and filtering URLs
4. Create admin and user-specific routes
5. Include proper URL reversing in templates and views

Your solution should demonstrate:
- Proper app namespacing with app_name
- URL pattern organization and ordering
- Parameter passing to views
- URL reversing in templates and views
- RESTful API-style endpoints""",
            "starter_code": """# library/urls.py (main project URLs)
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Add your URL includes here
]

# books/urls.py (app-specific URLs)  
from django.urls import path
from . import views

# Define your URL patterns here

# Create view classes that handle the URLs appropriately""",
            "solution": """# library/urls.py (main project URLs)
from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('accounts/', include('django.contrib.auth.urls')),
    path('books/', include('books.urls')),
    path('authors/', include('authors.urls')),
    path('api/v1/', include('api.urls')),
]

# books/urls.py (app-specific URLs)
from django.urls import path
from . import views

app_name = 'books'

urlpatterns = [
    # Main book operations
    path('', views.BookListView.as_view(), name='list'),
    path('search/', views.BookSearchView.as_view(), name='search'),
    path('create/', views.BookCreateView.as_view(), name='create'),
    
    # Individual book operations (specific patterns first)
    path('<int:pk>/', views.BookDetailView.as_view(), name='detail'),
    path('<int:pk>/edit/', views.BookUpdateView.as_view(), name='edit'),
    path('<int:pk>/delete/', views.BookDeleteView.as_view(), name='delete'),
    
    # Category filtering
    path('category/<slug:category>/', 
         views.BookListView.as_view(),
         {'filter_by': 'category'},
         name='by-category'),
    
    # Author filtering
    path('author/<int:author_id>/',
         views.BookListView.as_view(),
         {'filter_by': 'author'},
         name='by-author'),
    
    # Special collections using extra context
    path('featured/',
         views.BookListView.as_view(
             queryset=Book.objects.filter(is_featured=True),
             template_name='books/featured_list.html',
             extra_context={'page_title': 'Featured Books'}
         ),
         name='featured'),
    
    path('recent/',
         views.BookListView.as_view(
             template_name='books/recent_list.html',
             extra_context={'page_title': 'Recent Books'}
         ),
         name='recent'),
    
    # Archive views
    path('archive/<int:year>/',
         views.BookYearArchiveView.as_view(),
         name='year-archive'),
]

# authors/urls.py
from django.urls import path
from . import views

app_name = 'authors'

urlpatterns = [
    path('', views.AuthorListView.as_view(), name='list'),
    path('<int:pk>/', views.AuthorDetailView.as_view(), name='detail'),
    path('create/', views.AuthorCreateView.as_view(), name='create'),
    path('<int:pk>/edit/', views.AuthorUpdateView.as_view(), name='edit'),
]

# api/urls.py (RESTful API)
from django.urls import path
from . import api_views

app_name = 'api'

urlpatterns = [
    # Books API
    path('books/', 
         api_views.BookAPIView.as_view(http_method_names=['get', 'post']),
         name='books'),
    
    path('books/<int:pk>/',
         api_views.BookAPIView.as_view(http_method_names=['get', 'put', 'delete']),
         name='book-detail'),
    
    # Search API
    path('books/search/',
         api_views.BookSearchAPIView.as_view(),
         name='book-search'),
]

# Example view implementations
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    context_object_name = 'books'
    paginate_by = 12
    
    def get_queryset(self):
        queryset = super().get_queryset()
        filter_by = self.kwargs.get('filter_by')
        
        if filter_by == 'category':
            category = self.kwargs.get('category')
            queryset = queryset.filter(category__slug=category)
        elif filter_by == 'author':
            author_id = self.kwargs.get('author_id')
            queryset = queryset.filter(author_id=author_id)
        
        return queryset.select_related('author').prefetch_related('categories')

class BookDetailView(DetailView):
    model = Book
    template_name = 'books/detail.html'
    context_object_name = 'book'

class BookCreateView(CreateView):
    model = Book
    fields = ['title', 'author', 'isbn', 'categories']
    template_name = 'books/create.html'
    
    def get_success_url(self):
        return reverse_lazy('books:detail', kwargs={'pk': self.object.pk})""",
            "test_cases": [
                {
                    "name": "URLs use proper namespacing and .as_view()",
                    "input": "",
                    "expected_contains": ["app_name", ".as_view()", "reverse_lazy"]
                }
            ],
            "xp_reward": 90,
            "hints": [
                "Remember to use app_name for namespacing",
                "Put specific URL patterns before generic ones",
                "Use .as_view() to convert classes to functions",
                "Pass extra arguments via URL kwargs",
                "Use reverse_lazy for success_url in class-based views"
            ]
        }
    ]
}