"""
Django Database Management - Lesson 2: Legacy Database Integration
Master Django's integration with existing legacy databases and data migration strategies
"""

DJANGO_LEGACY_DATABASE_LESSON = {
    "id": 55,
    "chapter": 55,
    "title": "Django Legacy Database Integration: Working with Existing Systems",
    "slug": "django-legacy-database",
    "description": "Learn to integrate Django with legacy databases using inspectdb, handle schema differences, and manage data migrations",
    "content": '''# Django Legacy Database Integration: Working with Existing Systems

## 🎯 Understanding Legacy Database Integration

When building Django applications, you often need to work with **existing databases** that weren't designed for Django. Legacy integration is crucial for **enterprise migrations**, **system modernization**, and **gradual Django adoption**.

**Key Integration Challenges**:
- **Schema Differences** → Non-Django naming conventions and structures
- **Data Type Mapping** → Legacy types that don't match Django field types
- **Relationship Handling** → Foreign keys and constraints in existing systems
- **Business Logic Migration** → Moving stored procedures and triggers to Django
- **Incremental Migration** → Phased transition from legacy to Django

Think of legacy integration as **building bridges between old and new systems** while maintaining data integrity.

## 💾 Legacy Database Scenarios

Let's work with realistic legacy database scenarios that Django developers commonly encounter:

```sql
-- LEGACY ERP SYSTEM (Pre-2010 design)
-- Database: legacy_erp
-- Table naming: NON-Django conventions (uppercase, underscores, prefixes)

-- Legacy customer table with non-Django structure
CREATE TABLE TBL_CUSTOMERS (
    CUST_ID INTEGER PRIMARY KEY,
    CUST_CODE VARCHAR(20) UNIQUE NOT NULL,
    CUST_NAME VARCHAR(200) NOT NULL,
    CUST_EMAIL VARCHAR(100),
    CUST_PHONE VARCHAR(50),
    CUST_ADDRESS TEXT,
    CUST_CITY VARCHAR(100),
    CUST_STATE VARCHAR(50),
    CUST_ZIP VARCHAR(20),
    CUST_CREDIT_LIMIT DECIMAL(15,2) DEFAULT 0.00,
    CUST_CURRENT_BALANCE DECIMAL(15,2) DEFAULT 0.00,
    DATE_CREATED TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    DATE_MODIFIED TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CREATED_BY_USER_ID INTEGER,
    IS_ACTIVE CHAR(1) DEFAULT 'Y',
    CUSTOMER_TYPE_CD VARCHAR(10) DEFAULT 'STD'
);

-- Legacy customer data with typical ERP patterns
INSERT INTO TBL_CUSTOMERS (CUST_ID, CUST_CODE, CUST_NAME, CUST_EMAIL, CUST_PHONE, CUST_CITY, CUST_STATE, CUST_CREDIT_LIMIT, CUST_CURRENT_BALANCE, CREATED_BY_USER_ID, CUSTOMER_TYPE_CD) VALUES
(1001, 'ACME-001', 'Acme Corporation', 'billing@acme.com', '555-0101', 'New York', 'NY', 50000.00, 12345.67, 1, 'VIP'),
(1002, 'TECH-002', 'Tech Solutions Inc', 'accounts@techsol.com', '555-0102', 'San Francisco', 'CA', 25000.00, 5432.10, 1, 'STD'),
(1003, 'GLOBAL-003', 'Global Industries LLC', 'finance@global.com', '555-0103', 'Chicago', 'IL', 75000.00, 23456.78, 2, 'VIP'),
(1004, 'START-004', 'Startup Dynamics', 'billing@startup.com', '555-0104', 'Austin', 'TX', 10000.00, 1234.56, 1, 'STD'),
(1005, 'ENTER-005', 'Enterprise Partners', 'ap@enterprise.com', '555-0105', 'Boston', 'MA', 100000.00, 45678.90, 3, 'ENT');

-- Legacy orders table with ERP-style relationships
CREATE TABLE TBL_ORDERS (
    ORDER_ID INTEGER PRIMARY KEY,
    ORDER_NUMBER VARCHAR(50) UNIQUE NOT NULL,
    CUST_ID INTEGER NOT NULL,
    ORDER_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    SHIP_DATE TIMESTAMP,
    ORDER_STATUS_CD VARCHAR(10) DEFAULT 'PENDING',
    ORDER_TOTAL DECIMAL(15,2) NOT NULL,
    TAX_AMOUNT DECIMAL(15,2) DEFAULT 0.00,
    SHIPPING_AMOUNT DECIMAL(15,2) DEFAULT 0.00,
    DISCOUNT_AMOUNT DECIMAL(15,2) DEFAULT 0.00,
    PAYMENT_TERMS VARCHAR(50),
    SALES_REP_ID INTEGER,
    SHIP_TO_ADDRESS TEXT,
    BILLING_ADDRESS TEXT,
    ORDER_NOTES TEXT,
    FOREIGN KEY (CUST_ID) REFERENCES TBL_CUSTOMERS(CUST_ID)
);

-- Legacy order data
INSERT INTO TBL_ORDERS (ORDER_ID, ORDER_NUMBER, CUST_ID, ORDER_DATE, ORDER_STATUS_CD, ORDER_TOTAL, TAX_AMOUNT, SHIPPING_AMOUNT, SALES_REP_ID, PAYMENT_TERMS) VALUES
(2001, 'ORD-2024-001', 1001, '2024-01-15 10:30:00', 'SHIPPED', 15750.00, 1260.00, 150.00, 101, 'NET 30'),
(2002, 'ORD-2024-002', 1002, '2024-01-20 14:22:00', 'PENDING', 8900.00, 712.00, 100.00, 102, 'NET 15'),
(2003, 'ORD-2024-003', 1003, '2024-02-01 09:15:00', 'DELIVERED', 32500.00, 2600.00, 200.00, 101, 'COD'),
(2004, 'ORD-2024-004', 1001, '2024-02-10 16:45:00', 'PROCESSING', 5420.00, 433.60, 75.00, 103, 'NET 30'),
(2005, 'ORD-2024-005', 1004, '2024-02-15 11:30:00', 'CANCELLED', 2100.00, 168.00, 50.00, 102, 'PREPAID');

-- Legacy product catalog with complex codes
CREATE TABLE TBL_PRODUCTS (
    PROD_ID INTEGER PRIMARY KEY,
    PROD_CODE VARCHAR(30) UNIQUE NOT NULL,
    PROD_NAME VARCHAR(200) NOT NULL,
    PROD_DESCRIPTION TEXT,
    PROD_CATEGORY_CD VARCHAR(20),
    UNIT_PRICE DECIMAL(12,4) NOT NULL,
    COST_PRICE DECIMAL(12,4),
    QTY_ON_HAND INTEGER DEFAULT 0,
    QTY_ALLOCATED INTEGER DEFAULT 0,
    REORDER_LEVEL INTEGER DEFAULT 0,
    REORDER_QTY INTEGER DEFAULT 0,
    VENDOR_PROD_CODE VARCHAR(50),
    UOM_CD VARCHAR(10) DEFAULT 'EACH',
    WEIGHT_LBS DECIMAL(8,2),
    IS_ACTIVE CHAR(1) DEFAULT 'Y',
    DATE_CREATED TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    DATE_MODIFIED TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Legacy product data
INSERT INTO TBL_PRODUCTS (PROD_ID, PROD_CODE, PROD_NAME, PROD_DESCRIPTION, PROD_CATEGORY_CD, UNIT_PRICE, COST_PRICE, QTY_ON_HAND, REORDER_LEVEL, VENDOR_PROD_CODE, WEIGHT_LBS) VALUES
(3001, 'COMP-LAP-001', 'Professional Laptop Computer', 'High-performance laptop for business use', 'COMPUTERS', 1299.99, 899.99, 25, 5, 'VEND-LP-001', 4.5),
(3002, 'COMP-MON-002', '27-inch 4K Monitor', 'Ultra-high definition display monitor', 'MONITORS', 649.99, 425.99, 15, 3, 'VEND-MON-002', 12.3),
(3003, 'OFF-CHR-003', 'Executive Office Chair', 'Ergonomic leather executive chair', 'FURNITURE', 899.99, 456.99, 8, 2, 'VEND-CHR-003', 45.6),
(3004, 'TECH-TAB-004', 'Business Tablet 10-inch', 'Professional tablet for mobile work', 'TABLETS', 499.99, 325.99, 30, 10, 'VEND-TAB-004', 1.8),
(3005, 'ACC-KEY-005', 'Wireless Keyboard Set', 'Professional wireless keyboard and mouse', 'ACCESSORIES', 129.99, 65.99, 50, 15, 'VEND-KEY-005', 2.1);

-- Legacy inventory tracking
CREATE TABLE TBL_INVENTORY_TRANSACTIONS (
    TRANS_ID INTEGER PRIMARY KEY,
    PROD_ID INTEGER NOT NULL,
    TRANS_TYPE_CD VARCHAR(20) NOT NULL,
    TRANS_QTY INTEGER NOT NULL,
    TRANS_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    REFERENCE_DOC VARCHAR(100),
    UNIT_COST DECIMAL(12,4),
    TRANS_NOTES TEXT,
    CREATED_BY_USER_ID INTEGER,
    FOREIGN KEY (PROD_ID) REFERENCES TBL_PRODUCTS(PROD_ID)
);

-- Sample inventory transactions
INSERT INTO TBL_INVENTORY_TRANSACTIONS (TRANS_ID, PROD_ID, TRANS_TYPE_CD, TRANS_QTY, REFERENCE_DOC, UNIT_COST, CREATED_BY_USER_ID) VALUES
(4001, 3001, 'RECEIPT', 50, 'PO-2024-001', 899.99, 1),
(4002, 3001, 'SALE', -2, 'ORD-2024-001', 899.99, 2),
(4003, 3002, 'RECEIPT', 25, 'PO-2024-002', 425.99, 1),
(4004, 3003, 'SALE', -1, 'ORD-2024-003', 456.99, 3),
(4005, 3004, 'ADJUSTMENT', 5, 'ADJ-2024-001', 325.99, 1);

-- Legacy user/employee table with different structure
CREATE TABLE TBL_EMPLOYEES (
    EMP_ID INTEGER PRIMARY KEY,
    EMP_CODE VARCHAR(20) UNIQUE NOT NULL,
    FIRST_NAME VARCHAR(50) NOT NULL,
    LAST_NAME VARCHAR(50) NOT NULL,
    EMAIL_ADDRESS VARCHAR(100) UNIQUE,
    PHONE_NUMBER VARCHAR(20),
    HIRE_DATE DATE,
    JOB_TITLE VARCHAR(100),
    DEPARTMENT_CD VARCHAR(20),
    SALARY_AMOUNT DECIMAL(12,2),
    IS_ACTIVE CHAR(1) DEFAULT 'Y',
    MANAGER_EMP_ID INTEGER,
    LOGIN_USERNAME VARCHAR(50),
    PASSWORD_HASH VARCHAR(255),
    LAST_LOGIN_DATE TIMESTAMP
);

-- Legacy employee data
INSERT INTO TBL_EMPLOYEES (EMP_ID, EMP_CODE, FIRST_NAME, LAST_NAME, EMAIL_ADDRESS, HIRE_DATE, JOB_TITLE, DEPARTMENT_CD, SALARY_AMOUNT, LOGIN_USERNAME) VALUES
(101, 'EMP-001', 'John', 'Smith', 'john.smith@company.com', '2020-01-15', 'Sales Manager', 'SALES', 75000.00, 'jsmith'),
(102, 'EMP-002', 'Sarah', 'Johnson', 'sarah.johnson@company.com', '2021-03-22', 'Sales Representative', 'SALES', 55000.00, 'sjohnson'),
(103, 'EMP-003', 'Mike', 'Davis', 'mike.davis@company.com', '2019-08-10', 'Senior Sales Rep', 'SALES', 65000.00, 'mdavis'),
(104, 'EMP-004', 'Lisa', 'Wilson', 'lisa.wilson@company.com', '2022-01-05', 'Customer Service Manager', 'SUPPORT', 68000.00, 'lwilson'),
(105, 'EMP-005', 'Tom', 'Brown', 'tom.brown@company.com', '2023-06-12', 'Inventory Specialist', 'WAREHOUSE', 48000.00, 'tbrown');
```

## 🔧 Django inspectdb - Automatic Model Generation

### 1. Basic inspectdb Usage

**Scenario**: Migrating a legacy CRM system to Django

```python
# Command to generate models from legacy database
# python manage.py inspectdb > models.py

# Generated models from legacy ERP system (before cleanup)
from django.db import models

class TblCustomers(models.Model):
    cust_id = models.AutoField(primary_key=True)
    cust_code = models.CharField(unique=True, max_length=20)
    cust_name = models.CharField(max_length=200)
    cust_email = models.CharField(max_length=100, blank=True, null=True)
    cust_phone = models.CharField(max_length=50, blank=True, null=True)
    cust_address = models.TextField(blank=True, null=True)
    cust_city = models.CharField(max_length=100, blank=True, null=True)
    cust_state = models.CharField(max_length=50, blank=True, null=True)
    cust_zip = models.CharField(max_length=20, blank=True, null=True)
    cust_credit_limit = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    cust_current_balance = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    date_created = models.DateTimeField(blank=True, null=True)
    date_modified = models.DateTimeField(blank=True, null=True)
    created_by_user_id = models.IntegerField(blank=True, null=True)
    is_active = models.CharField(max_length=1, blank=True, null=True)
    customer_type_cd = models.CharField(max_length=10, blank=True, null=True)

    class Meta:
        managed = False  # Created by 'inspectdb' - Django won't manage this table
        db_table = 'TBL_CUSTOMERS'

class TblOrders(models.Model):
    order_id = models.AutoField(primary_key=True)
    order_number = models.CharField(unique=True, max_length=50)
    cust = models.ForeignKey(TblCustomers, models.DO_NOTHING)  # Foreign key detected
    order_date = models.DateTimeField(blank=True, null=True)
    ship_date = models.DateTimeField(blank=True, null=True)
    order_status_cd = models.CharField(max_length=10, blank=True, null=True)
    order_total = models.DecimalField(max_digits=15, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    shipping_amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True)
    payment_terms = models.CharField(max_length=50, blank=True, null=True)
    sales_rep_id = models.IntegerField(blank=True, null=True)
    ship_to_address = models.TextField(blank=True, null=True)
    billing_address = models.TextField(blank=True, null=True)
    order_notes = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'TBL_ORDERS'
```

### 2. Refactored Legacy Models

**Scenario**: Shopify's legacy integration with modern Django patterns

```python
# models/legacy.py - Cleaned up and Django-optimized legacy models
from django.db import models
from django.utils import timezone
from django.core.validators import EmailValidator

class LegacyCustomer(models.Model):
    """
    Legacy customer model mapped to TBL_CUSTOMERS
    Preserves legacy database structure while adding Django functionality
    """
    
    # Legacy field mappings with Django conventions
    legacy_id = models.AutoField(primary_key=True, db_column='CUST_ID')
    code = models.CharField(max_length=20, unique=True, db_column='CUST_CODE')
    name = models.CharField(max_length=200, db_column='CUST_NAME')
    email = models.EmailField(max_length=100, blank=True, null=True, 
                             db_column='CUST_EMAIL', validators=[EmailValidator()])
    phone = models.CharField(max_length=50, blank=True, null=True, db_column='CUST_PHONE')
    
    # Address fields
    address = models.TextField(blank=True, null=True, db_column='CUST_ADDRESS')
    city = models.CharField(max_length=100, blank=True, null=True, db_column='CUST_CITY')
    state = models.CharField(max_length=50, blank=True, null=True, db_column='CUST_STATE')
    zip_code = models.CharField(max_length=20, blank=True, null=True, db_column='CUST_ZIP')
    
    # Financial fields
    credit_limit = models.DecimalField(max_digits=15, decimal_places=2, default=0, 
                                     db_column='CUST_CREDIT_LIMIT')
    current_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0,
                                        db_column='CUST_CURRENT_BALANCE')
    
    # Audit fields
    date_created = models.DateTimeField(default=timezone.now, db_column='DATE_CREATED')
    date_modified = models.DateTimeField(auto_now=True, db_column='DATE_MODIFIED')
    created_by_user_id = models.IntegerField(blank=True, null=True, 
                                           db_column='CREATED_BY_USER_ID')
    
    # Status fields with choices
    CUSTOMER_TYPES = [
        ('STD', 'Standard'),
        ('VIP', 'VIP Customer'),
        ('ENT', 'Enterprise'),
    ]
    
    is_active = models.BooleanField(default=True)  # Convert CHAR(1) to boolean
    customer_type = models.CharField(max_length=10, choices=CUSTOMER_TYPES, 
                                   default='STD', db_column='CUSTOMER_TYPE_CD')
    
    class Meta:
        db_table = 'TBL_CUSTOMERS'
        managed = True  # Allow Django to manage this table now
        verbose_name = 'Legacy Customer'
        verbose_name_plural = 'Legacy Customers'
        ordering = ['name']
        indexes = [
            models.Index(fields=['code']),
            models.Index(fields=['email']),
            models.Index(fields=['customer_type']),
        ]
    
    def __str__(self):
        return f"{self.code} - {self.name}"
    
    @property
    def available_credit(self):
        """Calculate available credit"""
        return self.credit_limit - self.current_balance
    
    @property
    def full_address(self):
        """Get formatted full address"""
        parts = [self.address, self.city, self.state, self.zip_code]
        return ', '.join(filter(None, parts))
    
    def save(self, *args, **kwargs):
        # Override save to handle legacy Y/N conversion
        super().save(*args, **kwargs)

class LegacyOrder(models.Model):
    """
    Legacy order model with improved relationships and validation
    """
    ORDER_STATUSES = [
        ('PENDING', 'Pending'),
        ('PROCESSING', 'Processing'),
        ('SHIPPED', 'Shipped'),
        ('DELIVERED', 'Delivered'),
        ('CANCELLED', 'Cancelled'),
    ]
    
    legacy_id = models.AutoField(primary_key=True, db_column='ORDER_ID')
    order_number = models.CharField(max_length=50, unique=True, db_column='ORDER_NUMBER')
    
    # Improved foreign key relationship
    customer = models.ForeignKey(
        LegacyCustomer, 
        on_delete=models.PROTECT,  # Protect orders when customer is deleted
        related_name='orders',
        db_column='CUST_ID'
    )
    
    # Date fields
    order_date = models.DateTimeField(default=timezone.now, db_column='ORDER_DATE')
    ship_date = models.DateTimeField(blank=True, null=True, db_column='SHIP_DATE')
    
    # Status and financial fields
    status = models.CharField(max_length=10, choices=ORDER_STATUSES, 
                            default='PENDING', db_column='ORDER_STATUS_CD')
    order_total = models.DecimalField(max_digits=15, decimal_places=2, 
                                    db_column='ORDER_TOTAL')
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0,
                                   db_column='TAX_AMOUNT')
    shipping_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0,
                                        db_column='SHIPPING_AMOUNT')
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0,
                                        db_column='DISCOUNT_AMOUNT')
    
    # Additional fields
    payment_terms = models.CharField(max_length=50, blank=True, null=True,
                                   db_column='PAYMENT_TERMS')
    sales_rep_id = models.IntegerField(blank=True, null=True, db_column='SALES_REP_ID')
    ship_to_address = models.TextField(blank=True, null=True, db_column='SHIP_TO_ADDRESS')
    billing_address = models.TextField(blank=True, null=True, db_column='BILLING_ADDRESS')
    notes = models.TextField(blank=True, null=True, db_column='ORDER_NOTES')
    
    class Meta:
        db_table = 'TBL_ORDERS'
        managed = True
        verbose_name = 'Legacy Order'
        verbose_name_plural = 'Legacy Orders'
        ordering = ['-order_date']
        indexes = [
            models.Index(fields=['order_number']),
            models.Index(fields=['customer', 'order_date']),
            models.Index(fields=['status']),
        ]
    
    def __str__(self):
        return f"{self.order_number} - {self.customer.name}"
    
    @property
    def subtotal(self):
        """Calculate order subtotal before tax and shipping"""
        return self.order_total - self.tax_amount - self.shipping_amount + self.discount_amount
    
    @property
    def is_shipped(self):
        """Check if order has been shipped"""
        return self.status in ['SHIPPED', 'DELIVERED']

class LegacyProduct(models.Model):
    """
    Legacy product model with modern Django features
    """
    legacy_id = models.AutoField(primary_key=True, db_column='PROD_ID')
    code = models.CharField(max_length=30, unique=True, db_column='PROD_CODE')
    name = models.CharField(max_length=200, db_column='PROD_NAME')
    description = models.TextField(blank=True, null=True, db_column='PROD_DESCRIPTION')
    category_code = models.CharField(max_length=20, blank=True, null=True,
                                   db_column='PROD_CATEGORY_CD')
    
    # Pricing
    unit_price = models.DecimalField(max_digits=12, decimal_places=4, db_column='UNIT_PRICE')
    cost_price = models.DecimalField(max_digits=12, decimal_places=4, blank=True, null=True,
                                   db_column='COST_PRICE')
    
    # Inventory
    qty_on_hand = models.IntegerField(default=0, db_column='QTY_ON_HAND')
    qty_allocated = models.IntegerField(default=0, db_column='QTY_ALLOCATED')
    reorder_level = models.IntegerField(default=0, db_column='REORDER_LEVEL')
    reorder_qty = models.IntegerField(default=0, db_column='REORDER_QTY')
    
    # Additional fields
    vendor_product_code = models.CharField(max_length=50, blank=True, null=True,
                                         db_column='VENDOR_PROD_CODE')
    unit_of_measure = models.CharField(max_length=10, default='EACH', db_column='UOM_CD')
    weight_lbs = models.DecimalField(max_digits=8, decimal_places=2, blank=True, null=True,
                                   db_column='WEIGHT_LBS')
    
    # Status and audit
    is_active = models.BooleanField(default=True)
    date_created = models.DateTimeField(default=timezone.now, db_column='DATE_CREATED')
    date_modified = models.DateTimeField(auto_now=True, db_column='DATE_MODIFIED')
    
    class Meta:
        db_table = 'TBL_PRODUCTS'
        managed = True
        verbose_name = 'Legacy Product'
        verbose_name_plural = 'Legacy Products'
        ordering = ['name']
    
    def __str__(self):
        return f"{self.code} - {self.name}"
    
    @property
    def available_quantity(self):
        """Calculate available inventory"""
        return self.qty_on_hand - self.qty_allocated
    
    @property
    def needs_reorder(self):
        """Check if product needs reordering"""
        return self.qty_on_hand <= self.reorder_level
```

## 🔄 Data Migration Strategies

### 3. Legacy Data Transformation

**Scenario**: Airbnb's property management migration

```python
# management/commands/migrate_legacy_data.py
from django.core.management.base import BaseCommand
from django.db import transaction
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Migrate data from legacy ERP to Django models'
    
    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true', help='Preview changes without executing')
        parser.add_argument('--batch-size', type=int, default=1000, help='Batch size for processing')
    
    def handle(self, *args, **options):
        dry_run = options['dry_run']
        batch_size = options['batch_size']
        
        if dry_run:
            self.stdout.write("DRY RUN MODE - No changes will be made")
        
        # Migrate customers
        self.migrate_customers(dry_run, batch_size)
        
        # Migrate orders
        self.migrate_orders(dry_run, batch_size)
        
        # Migrate products
        self.migrate_products(dry_run, batch_size)
        
        self.stdout.write(self.style.SUCCESS('Legacy migration completed!'))
    
    def migrate_customers(self, dry_run, batch_size):
        """Migrate legacy customers with data transformation"""
        from django.db import connection
        
        with connection.cursor() as cursor:
            # Get legacy customer data with transformations
            cursor.execute("""
                SELECT 
                    CUST_ID,
                    CUST_CODE,
                    CUST_NAME,
                    CUST_EMAIL,
                    CUST_PHONE,
                    CUST_ADDRESS,
                    CUST_CITY,
                    CUST_STATE,
                    CUST_ZIP,
                    CUST_CREDIT_LIMIT,
                    CUST_CURRENT_BALANCE,
                    DATE_CREATED,
                    DATE_MODIFIED,
                    CREATED_BY_USER_ID,
                    CASE WHEN IS_ACTIVE = 'Y' THEN TRUE ELSE FALSE END as is_active_bool,
                    CUSTOMER_TYPE_CD
                FROM TBL_CUSTOMERS
                ORDER BY CUST_ID
            """)
            
            customers_data = cursor.fetchall()
        
        self.stdout.write(f"Found {len(customers_data)} customers to migrate")
        
        if not dry_run:
            from myapp.models import Customer  # Assuming new Django model
            
            customers_to_create = []
            for row in customers_data:
                customer = Customer(
                    legacy_id=row[0],
                    code=row[1],
                    name=row[2],
                    email=row[3] if row[3] and '@' in row[3] else None,  # Validate email
                    phone=self.clean_phone_number(row[4]),
                    address=row[5],
                    city=row[6],
                    state=row[7],
                    zip_code=row[8],
                    credit_limit=row[9] or Decimal('0'),
                    current_balance=row[10] or Decimal('0'),
                    date_created=row[11],
                    date_modified=row[12],
                    created_by_user_id=row[13],
                    is_active=row[14],
                    customer_type=row[15] if row[15] in ['STD', 'VIP', 'ENT'] else 'STD'
                )
                customers_to_create.append(customer)
                
                if len(customers_to_create) >= batch_size:
                    with transaction.atomic():
                        Customer.objects.bulk_create(customers_to_create, ignore_conflicts=True)
                    customers_to_create = []
                    self.stdout.write(f"Processed batch of {batch_size} customers")
            
            # Process remaining customers
            if customers_to_create:
                with transaction.atomic():
                    Customer.objects.bulk_create(customers_to_create, ignore_conflicts=True)
        
        self.stdout.write(self.style.SUCCESS(f"Migrated {len(customers_data)} customers"))
    
    def clean_phone_number(self, phone):
        """Clean and standardize phone numbers"""
        if not phone:
            return None
        
        # Remove all non-digit characters
        digits_only = ''.join(filter(str.isdigit, phone))
        
        # Format as (XXX) XXX-XXXX for 10-digit numbers
        if len(digits_only) == 10:
            return f"({digits_only[:3]}) {digits_only[3:6]}-{digits_only[6:]}"
        elif len(digits_only) == 11 and digits_only.startswith('1'):
            # Handle 11-digit numbers starting with 1
            return f"({digits_only[1:4]}) {digits_only[4:7]}-{digits_only[7:]}"
        else:
            return phone  # Return original if can't format
    
    def migrate_orders(self, dry_run, batch_size):
        """Migrate orders with customer relationship mapping"""
        from django.db import connection
        
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    o.ORDER_ID,
                    o.ORDER_NUMBER,
                    o.CUST_ID,
                    o.ORDER_DATE,
                    o.SHIP_DATE,
                    o.ORDER_STATUS_CD,
                    o.ORDER_TOTAL,
                    o.TAX_AMOUNT,
                    o.SHIPPING_AMOUNT,
                    o.DISCOUNT_AMOUNT,
                    o.PAYMENT_TERMS,
                    o.SALES_REP_ID,
                    o.SHIP_TO_ADDRESS,
                    o.BILLING_ADDRESS,
                    o.ORDER_NOTES,
                    c.CUST_CODE
                FROM TBL_ORDERS o
                INNER JOIN TBL_CUSTOMERS c ON o.CUST_ID = c.CUST_ID
                ORDER BY o.ORDER_ID
            """)
            
            orders_data = cursor.fetchall()
        
        self.stdout.write(f"Found {len(orders_data)} orders to migrate")
        
        if not dry_run:
            from myapp.models import Customer, Order
            
            # Create mapping of legacy customer IDs to Django model IDs
            customer_mapping = {}
            for customer in Customer.objects.all():
                customer_mapping[customer.legacy_id] = customer
            
            orders_to_create = []
            for row in orders_data:
                customer_id = row[2]
                
                if customer_id not in customer_mapping:
                    self.stdout.write(
                        self.style.WARNING(f"Customer {customer_id} not found for order {row[1]}")
                    )
                    continue
                
                order = Order(
                    legacy_id=row[0],
                    order_number=row[1],
                    customer=customer_mapping[customer_id],
                    order_date=row[3],
                    ship_date=row[4],
                    status=row[5] if row[5] in ['PENDING', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'] else 'PENDING',
                    order_total=row[6],
                    tax_amount=row[7] or Decimal('0'),
                    shipping_amount=row[8] or Decimal('0'),
                    discount_amount=row[9] or Decimal('0'),
                    payment_terms=row[10],
                    sales_rep_id=row[11],
                    ship_to_address=row[12],
                    billing_address=row[13],
                    notes=row[14]
                )
                orders_to_create.append(order)
                
                if len(orders_to_create) >= batch_size:
                    with transaction.atomic():
                        Order.objects.bulk_create(orders_to_create, ignore_conflicts=True)
                    orders_to_create = []
            
            if orders_to_create:
                with transaction.atomic():
                    Order.objects.bulk_create(orders_to_create, ignore_conflicts=True)
        
        self.stdout.write(self.style.SUCCESS(f"Migrated {len(orders_data)} orders"))
```

### 4. Legacy Database Router

**Scenario**: Gradual migration strategy for large systems

```python
# db_routers.py
class LegacyDatabaseRouter:
    """
    A router to control database operations on legacy models
    """
    
    legacy_apps = ['legacy_app']
    legacy_models = {
        'legacy_app.legacycustomer',
        'legacy_app.legacyorder',
        'legacy_app.legacyproduct',
        'legacy_app.legacyinventorytransaction',
        'legacy_app.legacyemployee',
    }
    
    def db_for_read(self, model, **hints):
        """Suggest the database to read from"""
        if model._meta.app_label in self.legacy_apps:
            return 'legacy'
        return None
    
    def db_for_write(self, model, **hints):
        """Suggest the database to write to"""
        if model._meta.app_label in self.legacy_apps:
            return 'legacy'
        return None
    
    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """Ensure that legacy app migrations only go to legacy database"""
        if app_label in self.legacy_apps:
            return db == 'legacy'
        elif db == 'legacy':
            return False  # Don't migrate non-legacy apps to legacy db
        return None
    
    def allow_relation(self, obj1, obj2, **hints):
        """Allow relations within legacy database or between legacy and default"""
        db_set = {'default', 'legacy'}
        if obj1._state.db in db_set and obj2._state.db in db_set:
            return True
        return None

# Integration service for legacy and modern models
class LegacyIntegrationService:
    """Service to handle integration between legacy and modern Django models"""
    
    @staticmethod
    def sync_customer_to_modern(legacy_customer_id):
        """Sync a legacy customer to the modern Customer model"""
        from legacy_app.models import LegacyCustomer
        from myapp.models import Customer
        
        try:
            legacy_customer = LegacyCustomer.objects.using('legacy').get(
                legacy_id=legacy_customer_id
            )
            
            # Create or update modern customer
            customer, created = Customer.objects.update_or_create(
                legacy_reference_id=legacy_customer.legacy_id,
                defaults={
                    'name': legacy_customer.name,
                    'email': legacy_customer.email,
                    'phone': legacy_customer.phone,
                    'address': legacy_customer.address,
                    'city': legacy_customer.city,
                    'state': legacy_customer.state,
                    'zip_code': legacy_customer.zip_code,
                    'is_active': legacy_customer.is_active,
                    'legacy_synced_at': timezone.now()
                }
            )
            
            return customer, created
            
        except LegacyCustomer.DoesNotExist:
            raise ValueError(f"Legacy customer {legacy_customer_id} not found")
    
    @staticmethod
    def create_order_from_legacy(legacy_order_id):
        """Create a modern order from legacy order data"""
        from legacy_app.models import LegacyOrder
        from myapp.models import Order, Customer
        
        try:
            legacy_order = LegacyOrder.objects.using('legacy').select_related('customer').get(
                legacy_id=legacy_order_id
            )
            
            # Ensure customer exists in modern system
            modern_customer, _ = LegacyIntegrationService.sync_customer_to_modern(
                legacy_order.customer.legacy_id
            )
            
            # Create modern order
            modern_order = Order.objects.create(
                customer=modern_customer,
                order_number=f"LEGACY-{legacy_order.order_number}",
                order_date=legacy_order.order_date,
                status=legacy_order.status.lower(),  # Convert to modern status format
                total_amount=legacy_order.order_total,
                tax_amount=legacy_order.tax_amount,
                shipping_amount=legacy_order.shipping_amount,
                discount_amount=legacy_order.discount_amount,
                notes=f"Migrated from legacy order {legacy_order.order_number}",
                legacy_reference_id=legacy_order.legacy_id
            )
            
            return modern_order
            
        except LegacyOrder.DoesNotExist:
            raise ValueError(f"Legacy order {legacy_order_id} not found")
```

## 🏢 Real-World Legacy Integration Examples

### 5. SAP Integration Pattern

**Scenario**: Enterprise SAP to Django migration

```python
class SAPIntegrationService:
    """Handle SAP ERP integration with Django"""
    
    @staticmethod
    def import_sap_customers():
        """Import customers from SAP system"""
        
        # SAP connection (simplified)
        import pyodbc
        
        connection_string = (
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=sap-server.company.com;'
            'DATABASE=SAP_PROD;'
            'UID=django_integration;'
            'PWD=secure_password'
        )
        
        with pyodbc.connect(connection_string) as connection:
            cursor = connection.cursor()
            
            # SAP customer query with proper joins
            cursor.execute("""
                SELECT 
                    KNA1.KUNNR as customer_number,
                    KNA1.NAME1 as customer_name,
                    KNA1.ORT01 as city,
                    KNA1.REGIO as region,
                    KNA1.LAND1 as country,
                    KNA1.TELF1 as telephone,
                    ADR6.SMTP_ADDR as email_address,
                    KNB1.KLIMK as credit_limit
                FROM KNA1
                LEFT JOIN ADR6 ON KNA1.ADRNR = ADR6.ADDRNUMBER
                LEFT JOIN KNB1 ON KNA1.KUNNR = KNB1.KUNNR
                WHERE KNA1.LOEVM = ''  -- Not marked for deletion
                ORDER BY KNA1.KUNNR
            """)
            
            sap_customers = cursor.fetchall()
        
        # Transform to Django models
        from myapp.models import Customer
        
        customers_created = 0
        customers_updated = 0
        
        for sap_customer in sap_customers:
            customer_data = {
                'name': sap_customer.customer_name,
                'city': sap_customer.city,
                'region': sap_customer.region,
                'country': sap_customer.country,
                'phone': sap_customer.telephone,
                'email': sap_customer.email_address,
                'credit_limit': sap_customer.credit_limit or 0,
                'sap_customer_number': sap_customer.customer_number,
                'last_sap_sync': timezone.now()
            }
            
            customer, created = Customer.objects.update_or_create(
                sap_customer_number=sap_customer.customer_number,
                defaults=customer_data
            )
            
            if created:
                customers_created += 1
            else:
                customers_updated += 1
        
        return {
            'customers_created': customers_created,
            'customers_updated': customers_updated,
            'total_processed': len(sap_customers)
        }

class OracleERPIntegration:
    """Handle Oracle ERP legacy integration"""
    
    @staticmethod
    def migrate_oracle_financials():
        """Migrate financial data from Oracle ERP"""
        import cx_Oracle
        
        # Oracle connection
        dsn = cx_Oracle.makedsn('oracle-erp.company.com', 1521, service_name='ERPDB')
        connection = cx_Oracle.connect(user='django_user', password='oracle_password', dsn=dsn)
        
        cursor = connection.cursor()
        
        # Oracle financial data query
        cursor.execute("""
            SELECT 
                ra.customer_trx_id,
                ra.trx_number,
                ra.trx_date,
                ra.invoice_currency_code,
                ra.payment_terms_name,
                hca.account_number,
                hp.party_name,
                ra.invoice_amount,
                ra.amount_due_remaining
            FROM ra_customer_trx_all ra
            JOIN hz_cust_accounts hca ON ra.bill_to_customer_id = hca.cust_account_id
            JOIN hz_parties hp ON hca.party_id = hp.party_id
            WHERE ra.trx_date >= SYSDATE - 365  -- Last year
            ORDER BY ra.trx_date DESC
        """)
        
        oracle_transactions = cursor.fetchall()
        
        # Process Oracle data
        from myapp.models import Customer, Invoice
        
        for transaction in oracle_transactions:
            # Find or create customer
            try:
                customer = Customer.objects.get(oracle_account_number=transaction[5])
            except Customer.DoesNotExist:
                customer = Customer.objects.create(
                    name=transaction[6],
                    oracle_account_number=transaction[5],
                    created_from_oracle=True
                )
            
            # Create invoice
            invoice, created = Invoice.objects.get_or_create(
                oracle_transaction_id=transaction[0],
                defaults={
                    'customer': customer,
                    'invoice_number': transaction[1],
                    'invoice_date': transaction[2],
                    'currency': transaction[3],
                    'payment_terms': transaction[4],
                    'total_amount': transaction[7],
                    'amount_due': transaction[8],
                    'migrated_from_oracle': True
                }
            )
        
        cursor.close()
        connection.close()
        
        return len(oracle_transactions)
```

## 🎯 Key Takeaways

1. **Use inspectdb as a starting point** → Always refactor generated models for Django best practices
2. **Plan data migration carefully** → Handle data type conversions and validation
3. **Implement gradual migration** → Use database routers for phased transitions
4. **Preserve legacy relationships** → Map foreign keys and constraints properly
5. **Add Django functionality incrementally** → Validation, choices, properties, and methods
6. **Monitor data integrity** → Validate migrated data and handle edge cases
7. **Document legacy mappings** → Track field mappings and business logic transformations

Legacy database integration enables Django to work with existing enterprise systems while gradually modernizing the data layer!
''',
    "difficulty": "advanced",
    "estimated_time": 50,
    "xp_reward": 35,
    "prerequisites": ["django-models-foundations", "django-database-configuration"],
    "exercises": [
        {
            "id": "legacy_1",
            "title": "Explore Legacy Customer Data Structure",
            "prompt": "Let's examine the legacy ERP customer table to understand its structure. Write a query to see all customers from the legacy TBL_CUSTOMERS table.",
            "table_name": "TBL_CUSTOMERS",
            "initial_query": "SELECT * FROM TBL_CUSTOMERS LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "TBL_CUSTOMERS"],
            "hint": "Use SELECT * FROM TBL_CUSTOMERS LIMIT 5; to see the legacy table structure",
            "solution": "SELECT * FROM TBL_CUSTOMERS LIMIT 5;",
            "explanation": "Legacy tables often use non-Django conventions like uppercase table names, underscores, and prefixes. Django's inspectdb command would generate models from this structure, which then need to be refactored for Django best practices."
        },
        {
            "id": "legacy_2",
            "title": "Legacy Data Type Analysis",
            "prompt": "Analyze legacy field types that need conversion. Write a query to see customer codes, names, and the Y/N is_active field that needs boolean conversion.",
            "table_name": "TBL_CUSTOMERS",
            "expected_keywords": ["SELECT", "CUST_CODE", "CUST_NAME", "IS_ACTIVE", "FROM"],
            "hint": "Select CUST_CODE, CUST_NAME, and IS_ACTIVE to see the Y/N values that need conversion",
            "solution": "SELECT CUST_CODE, CUST_NAME, IS_ACTIVE, CUSTOMER_TYPE_CD FROM TBL_CUSTOMERS ORDER BY CUSTOMER_TYPE_CD;",
            "explanation": "Legacy systems often use CHAR(1) Y/N fields instead of boolean. Django's BooleanField requires conversion: IS_ACTIVE = 'Y' becomes is_active = True. The inspectdb process identifies these patterns for manual conversion."
        },
        {
            "id": "legacy_3",
            "title": "Legacy Relationship Mapping",
            "prompt": "Examine legacy foreign key relationships. Write a query to see orders with their customer information by joining TBL_ORDERS and TBL_CUSTOMERS.",
            "table_name": "TBL_ORDERS",
            "expected_keywords": ["SELECT", "JOIN", "TBL_CUSTOMERS", "CUST_ID", "ORDER_NUMBER"],
            "hint": "JOIN TBL_ORDERS with TBL_CUSTOMERS on CUST_ID to see the relationship",
            "solution": "SELECT o.ORDER_NUMBER, o.ORDER_STATUS_CD, c.CUST_NAME, c.CUST_CODE FROM TBL_ORDERS o JOIN TBL_CUSTOMERS c ON o.CUST_ID = c.CUST_ID ORDER BY o.ORDER_DATE DESC;",
            "explanation": "Legacy foreign key relationships are preserved during inspectdb generation. Django creates ForeignKey fields with models.DO_NOTHING on_delete behavior, which should be updated to appropriate choices like PROTECT or CASCADE based on business logic."
        },
        {
            "id": "legacy_4",
            "title": "Legacy Code Pattern Analysis",
            "prompt": "Analyze legacy naming conventions. Write a query to see product codes and categories from TBL_PRODUCTS to understand the coding patterns.",
            "table_name": "TBL_PRODUCTS",
            "expected_keywords": ["SELECT", "PROD_CODE", "PROD_CATEGORY_CD", "PROD_NAME", "FROM"],
            "hint": "Select product codes, categories, and names to see legacy naming patterns",
            "solution": "SELECT PROD_CODE, PROD_CATEGORY_CD, PROD_NAME, UNIT_PRICE FROM TBL_PRODUCTS ORDER BY PROD_CATEGORY_CD, PROD_CODE;",
            "explanation": "Legacy systems often have complex coding schemes (COMP-LAP-001, OFF-CHR-003). Django models can preserve these codes while adding user-friendly fields and methods. The category codes can be converted to Django choices for better validation."
        },
        {
            "id": "legacy_5",
            "title": "Legacy Employee Data Structure",
            "prompt": "Examine the legacy employee/user table. Write a query to see employee codes, names, and departments from TBL_EMPLOYEES.",
            "table_name": "TBL_EMPLOYEES",
            "expected_keywords": ["SELECT", "EMP_CODE", "FIRST_NAME", "LAST_NAME", "DEPARTMENT_CD"],
            "hint": "Select employee information to understand the legacy user management structure",
            "solution": "SELECT EMP_CODE, FIRST_NAME, LAST_NAME, EMAIL_ADDRESS, JOB_TITLE, DEPARTMENT_CD FROM TBL_EMPLOYEES WHERE IS_ACTIVE = 'Y' ORDER BY DEPARTMENT_CD;",
            "explanation": "Legacy employee tables often need integration with Django's User model. This can be done through a profile model that extends User or by creating a custom user model that incorporates legacy fields like employee codes and department codes."
        },
        {
            "id": "legacy_6",
            "title": "Legacy Inventory Transaction Analysis",
            "prompt": "Look at legacy inventory transactions to understand business logic. Write a query to see recent inventory movements by transaction type.",
            "table_name": "TBL_INVENTORY_TRANSACTIONS",
            "expected_keywords": ["SELECT", "TRANS_TYPE_CD", "TRANS_QTY", "REFERENCE_DOC", "FROM"],
            "hint": "Select transaction details to see legacy business logic patterns",
            "solution": "SELECT t.TRANS_TYPE_CD, t.TRANS_QTY, t.REFERENCE_DOC, p.PROD_CODE, p.PROD_NAME FROM TBL_INVENTORY_TRANSACTIONS t JOIN TBL_PRODUCTS p ON t.PROD_ID = p.PROD_ID ORDER BY t.TRANS_DATE DESC;",
            "explanation": "Legacy transaction tables contain business logic that needs to be preserved in Django. Transaction types like RECEIPT, SALE, ADJUSTMENT become Django model choices, and the business rules can be implemented as model methods and Django signals."
        }
    ],
    "key_concepts": [
        "inspectdb Command and Model Generation",
        "Legacy Schema Mapping and Conversion",
        "Data Type Transformation Strategies",
        "Foreign Key Relationship Preservation",
        "Legacy Naming Convention Handling",
        "Gradual Migration Approaches",
        "Data Validation During Migration",
        "Business Logic Preservation Techniques"
    ]
}