"""
SQL SELECT Basics lesson content
"""

SQL_SELECT_BASICS_LESSON = {
    "id": 31,
    "chapter": 31,
    "title": "SQL SELECT Queries 101",
    "slug": "sql-select-basics",
    "content": '''
# SQL SELECT Queries 101: Your First Database Conversations

Think of SELECT queries as asking specific questions to a knowledgeable librarian who has instant access to millions of organized records. You can ask for exactly what you need - whether it's "Show me all Marvel movies" or "Find users with more than 10,000 followers" - and get precise answers in milliseconds.

## The SELECT Statement: Your Database Swiss Army Knife

The SELECT statement is the foundation of SQL. It's how you retrieve data from tables, and it's used in virtually every database interaction across the tech industry.

### Basic Syntax Pattern:
```sql
SELECT column1, column2, column3
FROM table_name;
```

**Real-world analogy:** It's like filling out a form at the DMV. You specify exactly which information you want (columns) from which database (table), and the system returns just that data.

## Exploring Our Practice Tables

Let's work with realistic data modeled after famous platforms. **Remember:** Always start by exploring your table structure!

### Table 1: Instagram Users (instagram_users)
**First action: `SELECT * FROM instagram_users;`**

```
+----+---------------+------------------+----------------+-------------+--------+
| id | username      | email            | follower_count | following   | verified|
+----+---------------+------------------+----------------+-------------+--------+
| 1  | travel_sarah  | sarah@email.com  | 125000         | 890        | 1      |
| 2  | tech_mike     | mike@gmail.com   | 45000          | 1200       | 0      |
| 3  | food_lover_23 | food@yahoo.com   | 78000          | 550        | 0      |
| 4  | fitness_guru  | fit@email.com    | 234000         | 400        | 1      |
| 5  | music_maven   | music@email.com  | 156000         | 750        | 1      |
+----+---------------+------------------+----------------+-------------+--------+
```

### Table 2: YouTube Videos (youtube_videos)
**First action: `SELECT * FROM youtube_videos;`**

```
+----+-------------------------+----------------+----------+--------+----------+
| id | title                   | channel_name   | views    | likes  | duration |
+----+-------------------------+----------------+----------+--------+----------+
| 1  | Python Tutorial Basics  | CodeAcademy    | 1200000  | 45000  | 1800     |
| 2  | SQL for Data Science    | DataPro        | 890000   | 32000  | 2400     |
| 3  | Web Design 2024         | DesignMaster   | 2100000  | 78000  | 3600     |
| 4  | JavaScript Crash Course | DevBootcamp    | 1500000  | 56000  | 4200     |
| 5  | Machine Learning Intro  | AITech         | 750000   | 29000  | 5400     |
+----+-------------------------+----------------+----------+--------+----------+
```

### Table 3: Spotify Songs (spotify_songs)  
**First action: `SELECT * FROM spotify_songs;`**

```
+----+------------------+--------------+----------+--------+-------+
| id | title            | artist       | streams  | likes  | year  |
+----+------------------+--------------+----------+--------+-------+
| 1  | Blinding Lights  | The Weeknd   | 3500000  | 89000  | 2020  |
| 2  | Shape of You     | Ed Sheeran   | 5200000  | 156000 | 2017  |
| 3  | Bad Habits       | Ed Sheeran   | 2800000  | 67000  | 2021  |
| 4  | Levitating       | Dua Lipa     | 4100000  | 112000 | 2020  |
| 5  | Good 4 U        | Olivia       | 1900000  | 78000  | 2021  |
+----+------------------+--------------+----------+--------+-------+
```

## SELECT Fundamentals: From Basic to Professional

### 1. Select All Columns (The Exploration Query)
```sql
-- See everything in the table (like browsing all Instagram profiles)
SELECT * FROM instagram_users;

-- Explore YouTube video database
SELECT * FROM youtube_videos;

-- Browse Spotify music catalog  
SELECT * FROM spotify_songs;
```

**When to use `SELECT *`:**
- ✅ Exploring new data (first look at a table)
- ✅ Small tables or development/testing
- ❌ Production applications (performance issues)
- ❌ Large tables (too much data)

### 2. Select Specific Columns (Focused Data Retrieval)
```sql
-- Instagram: Get just usernames and follower counts (like influencer research)
SELECT username, follower_count 
FROM instagram_users;

-- YouTube: Get video titles and view counts (like trending analysis)
SELECT title, views 
FROM youtube_videos;

-- Spotify: Get song names and artists (like playlist creation)
SELECT title, artist 
FROM spotify_songs;
```

**Professional tip:** Always select only the columns you actually need. This improves performance and reduces data transfer.

### 3. Column Aliases: Making Data Readable
```sql
-- Make column names more readable (like creating reports)
SELECT 
    username AS "Instagram Handle",
    follower_count AS "Followers",
    following AS "Following"
FROM instagram_users;

-- YouTube analytics with better names
SELECT 
    title AS "Video Title",
    channel_name AS "Channel",
    views AS "Total Views",
    likes AS "Total Likes"
FROM youtube_videos;

-- Music streaming data with clear labels
SELECT 
    title AS "Song Name",
    artist AS "Artist Name", 
    streams AS "Stream Count"
FROM spotify_songs;
```

## Real-World SELECT Patterns

### Social Media Analytics
```sql
-- Instagram influencer discovery (marketing teams use this)
SELECT username, follower_count, verified
FROM instagram_users;

-- Content performance analysis (like YouTube Studio)
SELECT title, views, likes, channel_name
FROM youtube_videos;
```

### Music Industry Analysis
```sql
-- Song popularity metrics (like Spotify's internal analytics)
SELECT title, artist, streams, likes, year
FROM spotify_songs;

-- Artist catalog overview
SELECT artist, title, year
FROM spotify_songs;
```

### Content Creator Insights
```sql
-- YouTube channel performance summary
SELECT channel_name, title, views, duration
FROM youtube_videos;

-- Engagement rate calculation preparation
SELECT title, views, likes
FROM youtube_videos;
```

## Advanced SELECT Techniques

### 1. Calculated Columns
```sql
-- Instagram engagement estimation
SELECT 
    username,
    follower_count,
    following,
    (follower_count - following) AS net_followers
FROM instagram_users;

-- YouTube engagement rate (likes per view)
SELECT 
    title,
    views,
    likes,
    (likes * 100.0 / views) AS engagement_rate_percent
FROM youtube_videos;

-- Spotify popularity per year
SELECT 
    title,
    streams,
    year,
    (streams / 1000) AS streams_in_thousands
FROM spotify_songs;
```

### 2. Multiple Calculations
```sql
-- Comprehensive Instagram metrics
SELECT 
    username,
    follower_count AS followers,
    following,
    (follower_count / following) AS follower_ratio,
    CASE 
        WHEN verified = 1 THEN 'Verified' 
        ELSE 'Not Verified' 
    END AS verification_status
FROM instagram_users;
```

### 3. Text Manipulation
```sql
-- Format data for display (like app interfaces)
SELECT 
    'Channel: ' + channel_name AS channel_info,
    'Video: ' + title AS video_info,
    views
FROM youtube_videos;
```

## SELECT Best Practices: Industry Standards

### 1. Readable Query Formatting
```sql
-- ❌ Hard to read
SELECT username,follower_count,following,verified FROM instagram_users;

-- ✅ Professional formatting
SELECT 
    username,
    follower_count,
    following,
    verified
FROM instagram_users;
```

### 2. Meaningful Column Aliases
```sql
-- ❌ Cryptic aliases  
SELECT username AS u, follower_count AS fc FROM instagram_users;

-- ✅ Clear, descriptive aliases
SELECT 
    username AS handle,
    follower_count AS total_followers
FROM instagram_users;
```

### 3. Performance-Conscious Selection
```sql
-- ❌ Selecting unnecessary data
SELECT * FROM youtube_videos;  -- Gets all columns, including large description fields

-- ✅ Select only what you need
SELECT title, views, likes FROM youtube_videos;  -- Much faster
```

## Common SELECT Patterns by Industry

### E-commerce (Amazon style)
```sql
-- Product catalog overview
SELECT 
    product_name,
    price,
    category,
    rating
FROM products;
```

### Social Media (Facebook/Instagram style)  
```sql
-- User engagement summary
SELECT 
    username,
    post_count,
    total_likes,
    average_engagement
FROM user_stats;
```

### Streaming Services (Netflix style)
```sql
-- Content library overview
SELECT 
    title,
    genre,
    release_year,
    rating
FROM movies;
```

## Troubleshooting Common SELECT Issues

### 1. Column Name Errors
```sql
-- ❌ This will fail
SELECT usrname FROM instagram_users;  -- Typo in column name

-- ✅ Correct column name
SELECT username FROM instagram_users;
```

### 2. Table Name Errors  
```sql
-- ❌ This will fail
SELECT * FROM users;  -- Wrong table name

-- ✅ Correct table name
SELECT * FROM instagram_users;
```

### 3. Case Sensitivity (database dependent)
```sql
-- Some databases are case-sensitive
SELECT Username FROM instagram_users;  -- Might fail
SELECT username FROM instagram_users;  -- Safer approach
```

SELECT queries are your gateway to the data world. Master these fundamentals, and you'll be ready to analyze user behavior like Facebook, track content performance like YouTube, or discover music trends like Spotify. Every data-driven decision in tech starts with a well-crafted SELECT statement! 🚀

**Next:** We'll learn to filter this data with WHERE clauses to find exactly what we're looking for.
    ''',
    "is_free": False,
    "xp_reward": 75,
    "exercises": [
        {
            "id": "instagram-users-queries",
            "title": "Instagram Users Data Exploration",
            "type": "practice",
            "instructions": """Practice basic SELECT queries using the Instagram users table.

Your tasks:
1. First, explore the table structure with `SELECT * FROM instagram_users;`
2. Get just usernames and follower counts
3. Show all user information with readable column names
4. Calculate follower-to-following ratios
5. Show verification status in a user-friendly format

Table: instagram_users
Columns: id, username, email, follower_count, following, verified (1=verified, 0=not verified)""",
            "starter_code": """-- Task 1: Explore the table structure
-- Write a query to see all data in the instagram_users table


-- Task 2: Get usernames and follower counts only
-- Show just the username and follower_count columns


-- Task 3: Use aliases to make column names readable
-- Select username (as "Handle"), follower_count (as "Followers"), 
-- and following (as "Following")


-- Task 4: Calculate the follower-to-following ratio
-- Show username, follower_count, following, and calculate the ratio


-- Task 5: Show verification status in a readable format
-- Display username and a calculated column showing "Verified" or "Not Verified"
""",
            "solution": """-- Task 1: Explore the table structure
SELECT * FROM instagram_users;

-- Task 2: Get usernames and follower counts only
SELECT username, follower_count 
FROM instagram_users;

-- Task 3: Use aliases to make column names readable
SELECT 
    username AS "Handle",
    follower_count AS "Followers", 
    following AS "Following"
FROM instagram_users;

-- Task 4: Calculate the follower-to-following ratio
SELECT 
    username,
    follower_count,
    following,
    (follower_count * 1.0 / following) AS follower_ratio
FROM instagram_users;

-- Task 5: Show verification status in a readable format
SELECT 
    username,
    CASE 
        WHEN verified = 1 THEN 'Verified'
        ELSE 'Not Verified'
    END AS verification_status
FROM instagram_users;""",
            "test_cases": [
                {
                    "name": "Basic SELECT with specific columns",
                    "input": "SELECT username, follower_count FROM instagram_users;",
                    "expected_contains": ["username", "follower_count"]
                },
                {
                    "name": "SELECT with aliases",
                    "input": "SELECT username AS handle FROM instagram_users;", 
                    "expected_contains": ["AS", "handle"]
                }
            ],
            "xp_reward": 50,
            "hints": [
                "Always start with SELECT * to see the table structure",
                "Use AS to create readable column aliases",
                "CASE statements help convert numeric codes to readable text",
                "Multiply by 1.0 to force decimal division instead of integer division"
            ]
        },
        {
            "id": "youtube-videos-analysis",
            "title": "YouTube Video Performance Analysis", 
            "type": "practice",
            "instructions": """Practice SELECT queries on YouTube video data to understand content performance.

Your tasks:
1. Explore all video data
2. Show video titles and view counts
3. Calculate engagement rates (likes per 1000 views)
4. Show content duration in a readable format
5. Create a comprehensive video summary

Table: youtube_videos
Columns: id, title, channel_name, views, likes, duration (in seconds)""",
            "starter_code": """-- Task 1: See all video data
-- SELECT all columns from youtube_videos table


-- Task 2: Show video titles and view counts for performance analysis
-- SELECT just title and views columns


-- Task 3: Calculate engagement rate (likes per 1000 views)
-- Show title, views, likes, and calculate likes per 1000 views


-- Task 4: Convert duration from seconds to minutes
-- Show title and duration in minutes (duration / 60)


-- Task 5: Create a comprehensive video summary
-- Show title, channel, views in thousands, and duration in minutes
""",
            "solution": """-- Task 1: See all video data
SELECT * FROM youtube_videos;

-- Task 2: Show video titles and view counts for performance analysis  
SELECT title, views 
FROM youtube_videos;

-- Task 3: Calculate engagement rate (likes per 1000 views)
SELECT 
    title,
    views,
    likes,
    (likes * 1000.0 / views) AS likes_per_1000_views
FROM youtube_videos;

-- Task 4: Convert duration from seconds to minutes
SELECT 
    title,
    duration,
    (duration / 60) AS duration_minutes
FROM youtube_videos;

-- Task 5: Create a comprehensive video summary
SELECT 
    title AS "Video Title",
    channel_name AS "Channel",
    (views / 1000) AS "Views (thousands)",
    (duration / 60) AS "Duration (minutes)",
    (likes * 100.0 / views) AS "Engagement Rate %"
FROM youtube_videos;""",
            "test_cases": [
                {
                    "name": "Calculated columns with division",
                    "input": "SELECT title, (likes * 1000 / views) FROM youtube_videos;",
                    "expected_contains": ["likes", "views", "*", "/"]
                }
            ],
            "xp_reward": 60,
            "hints": [
                "Use * 1000.0 to get decimal results instead of integer division",
                "Duration is stored in seconds, divide by 60 for minutes",
                "Engagement rate is often expressed as percentage of total views",
                "Use meaningful aliases to make your output readable"
            ]
        }
    ]
}