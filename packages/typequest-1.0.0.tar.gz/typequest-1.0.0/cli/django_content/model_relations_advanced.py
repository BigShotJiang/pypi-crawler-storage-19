"""
Django Model Relations Advanced lesson content
"""

DJANGO_MODEL_RELATIONS_ADVANCED_LESSON = {
    "id": 21,
    "chapter": 21,
    "title": "Django Model Relations Advanced",
    "slug": "model-relations-advanced",
    "content": '''
# Advanced Model Relations: The Social Network of Your Database

Think of Django model relations as the connections in a social network like Facebook. Just as people can be friends, follow each other, join groups, and share content, your database objects can have complex relationships that mirror real-world interactions. These relationships power features like LinkedIn's professional networks, Instagram's follower systems, or Amazon's product recommendations.

## Understanding Related Managers: Your Relationship Control Panel

**Real-world analogy:** Related managers are like the contact management system on your smartphone. You can add contacts, remove them, organize them into groups, or clear your entire contact list. Django's related managers give you similar control over database relationships.

### The Related Manager Toolkit

Every relationship in Django comes with a powerful manager that handles the connection between objects:

```python
# Forward relationship (ForeignKey): Like "My posts"
user.posts.all()

# Reverse relationship: Like "Post's comments"  
post.comments.all()

# Many-to-many: Like "User's followed accounts"
user.following.all()
```

## Core Relationship Operations: The CRUD of Connections

### add(): Building New Connections

The `add()` method is like hitting "Follow" on Instagram or "Connect" on LinkedIn.

```python
class YouTubeChannel(models.Model):
    name = models.CharField(max_length=100)
    subscriber_count = models.PositiveIntegerField(default=0)
    
class User(models.Model):
    username = models.CharField(max_length=50)
    subscribed_channels = models.ManyToManyField(YouTubeChannel, related_name='subscribers')

class Playlist(models.Model):
    name = models.CharField(max_length=100)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='playlists')
    videos = models.ManyToManyField('Video', through='PlaylistVideo')

class Video(models.Model):
    title = models.CharField(max_length=200)
    channel = models.ForeignKey(YouTubeChannel, on_delete=models.CASCADE, related_name='videos')

class PlaylistVideo(models.Model):
    """Through model for playlist ordering (like YouTube playlist order)"""
    playlist = models.ForeignKey(Playlist, on_delete=models.CASCADE)
    video = models.ForeignKey(Video, on_delete=models.CASCADE)
    order = models.PositiveIntegerField()
    added_at = models.DateTimeField(auto_now_add=True)

# Adding relationships (like YouTube subscription system)
user = User.objects.get(username='john_doe')
tech_channel = YouTubeChannel.objects.get(name='TechReviews')

# Subscribe to channel (add relationship)
user.subscribed_channels.add(tech_channel)

# Add multiple channels at once (batch subscribe)
gaming_channels = YouTubeChannel.objects.filter(name__contains='Gaming')
user.subscribed_channels.add(*gaming_channels)

# Add using primary keys (efficient for API integrations)
channel_ids = [1, 2, 3, 4, 5]
user.subscribed_channels.add(*channel_ids)

# Adding with through model data (like playlist with custom order)
playlist = user.playlists.create(name="Favorite Tech Videos")
video1 = Video.objects.get(title="iPhone Review")
video2 = Video.objects.get(title="Android vs iOS")

# Add videos to playlist with specific order
PlaylistVideo.objects.create(playlist=playlist, video=video1, order=1)
PlaylistVideo.objects.create(playlist=playlist, video=video2, order=2)

# Bulk add with through_defaults (Django 3.2+)
videos_to_add = Video.objects.filter(channel=tech_channel)[:5]
for i, video in enumerate(videos_to_add):
    playlist.videos.add(video, through_defaults={'order': i + 3})
```

### remove(): Breaking Connections

The `remove()` method is like unfollowing on social media or removing items from a shopping cart.

```python
class ShoppingCart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

class CartItem(models.Model):
    cart = models.ForeignKey(ShoppingCart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

class Product(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    in_stock = models.BooleanField(default=True)

# Removing relationships (like Amazon cart management)
cart = ShoppingCart.objects.get(user=user)
laptop = Product.objects.get(name='MacBook Pro')

# Remove specific product from cart
cart.items.filter(product=laptop).delete()

# Or using related manager remove (for M2M relationships)
# user.subscribed_channels.remove(tech_channel)

# Remove multiple items at once
out_of_stock_products = Product.objects.filter(in_stock=False)
for product in out_of_stock_products:
    CartItem.objects.filter(cart=cart, product=product).delete()

# Remove using primary keys
channel_ids_to_unsubscribe = [5, 7, 9]
user.subscribed_channels.remove(*channel_ids_to_unsubscribe)

# Smart removal with business logic
def remove_expired_subscriptions(user):
    """Remove subscriptions to inactive channels (like cleanup)"""
    inactive_channels = user.subscribed_channels.filter(
        last_video_uploaded__lt=timezone.now() - timedelta(days=365)
    )
    
    for channel in inactive_channels:
        user.subscribed_channels.remove(channel)
        print(f"Unsubscribed from inactive channel: {channel.name}")
```

### set(): Complete Relationship Replacement

The `set()` method is like reorganizing your entire social network or rebuilding a playlist from scratch.

```python
class MusicPlaylist(models.Model):
    name = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='music_playlists')
    songs = models.ManyToManyField('Song', related_name='playlists')
    
class Song(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=100)
    duration_seconds = models.PositiveIntegerField()

class SpotifyImporter:
    """Service to import playlists from Spotify (like playlist migration)"""
    
    @staticmethod
    def sync_playlist_from_spotify(user, spotify_playlist_data):
        """Replace entire playlist with Spotify data"""
        
        playlist_name = spotify_playlist_data['name']
        spotify_songs = spotify_playlist_data['tracks']
        
        # Get or create playlist
        playlist, created = MusicPlaylist.objects.get_or_create(
            user=user,
            name=playlist_name
        )
        
        # Convert Spotify tracks to our Song objects
        song_objects = []
        for track in spotify_songs:
            song, created = Song.objects.get_or_create(
                title=track['name'],
                artist=track['artist'],
                defaults={'duration_seconds': track['duration_ms'] // 1000}
            )
            song_objects.append(song)
        
        # Replace entire playlist content (like Spotify sync)
        playlist.songs.set(song_objects)
        
        return playlist
    
    @staticmethod
    def update_user_recommendations(user, recommended_songs):
        """Update user's recommendation list (like Discover Weekly)"""
        
        # Get or create "Discover Weekly" playlist
        discover_playlist, created = MusicPlaylist.objects.get_or_create(
            user=user,
            name="Discover Weekly"
        )
        
        # Replace with new recommendations (refreshed weekly)
        discover_playlist.songs.set(recommended_songs)
        
        print(f"Updated Discover Weekly with {len(recommended_songs)} new songs")

# Usage examples
spotify_data = {
    'name': 'My Awesome Playlist',
    'tracks': [
        {'name': 'Song 1', 'artist': 'Artist A', 'duration_ms': 180000},
        {'name': 'Song 2', 'artist': 'Artist B', 'duration_ms': 210000},
    ]
}

# Complete playlist replacement
playlist = SpotifyImporter.sync_playlist_from_spotify(user, spotify_data)

# Set using primary keys (efficient for large datasets)
recommended_song_ids = [1, 5, 10, 15, 20, 25, 30]
discover_playlist = MusicPlaylist.objects.get(user=user, name="Discover Weekly")
discover_playlist.songs.set(recommended_song_ids)
```

### clear(): The Fresh Start

The `clear()` method is like clearing your browser history or starting fresh with an empty cart.

```python
class SocialMediaUser(models.Model):
    username = models.CharField(max_length=50, unique=True)
    following = models.ManyToManyField('self', symmetrical=False, related_name='followers')
    blocked_users = models.ManyToManyField('self', symmetrical=False, related_name='blocked_by')

class NotificationSettings(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    subscribed_topics = models.ManyToManyField('Topic', related_name='subscribers')
    
class Topic(models.Model):
    name = models.CharField(max_length=50)
    category = models.CharField(max_length=30)

def reset_user_social_connections(social_user):
    """Complete social media reset (like deactivating and reactivating)"""
    
    # Clear all following relationships (unfollow everyone)
    social_user.following.clear()
    print(f"Unfollowed all users for {social_user.username}")
    
    # Clear all blocked users (fresh start)
    social_user.blocked_users.clear()
    print(f"Unblocked all users for {social_user.username}")
    
    # Reset notification preferences
    if hasattr(social_user, 'notificationsettings'):
        social_user.notificationsettings.subscribed_topics.clear()
        print("Reset all notification subscriptions")

def clear_shopping_session(user):
    """Clear all shopping-related data (like session reset)"""
    
    # Clear shopping cart
    if hasattr(user, 'shoppingcart'):
        user.shoppingcart.items.clear()
        print("Cleared shopping cart")
    
    # Clear wishlist
    if hasattr(user, 'wishlist'):
        user.wishlist.products.clear()
        print("Cleared wishlist")

# Usage examples
social_user = SocialMediaUser.objects.get(username='user123')
reset_user_social_connections(social_user)

# Clear all subscriptions (like unsubscribe all)
user.subscribed_channels.clear()

# Clear with confirmation (like Instagram "Remove all followers")
if user.is_authenticated and user.is_premium:
    user.music_playlists.get(name="Liked Songs").songs.clear()
    print("Cleared all liked songs")
```

### create(): One-Step Relationship Building

The `create()` method is like posting a new photo and automatically tagging friends in one action.

```python
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blog_posts')
    published_at = models.DateTimeField(auto_now_add=True)

class Comment(models.Model):
    post = models.ForeignKey(BlogPost, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')

class InstagramPost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='instagram_posts')
    image = models.ImageField(upload_to='posts/')
    caption = models.TextField(max_length=2200)
    created_at = models.DateTimeField(auto_now_add=True)

class PostTag(models.Model):
    post = models.ForeignKey(InstagramPost, on_delete=models.CASCADE, related_name='tags')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    x_coordinate = models.FloatField()  # Position on image
    y_coordinate = models.FloatField()

def create_blog_comment_thread(post, user, comment_text, parent_comment=None):
    """Create comment and auto-notify (like Medium comments)"""
    
    # Create comment in one step
    comment = post.comments.create(
        author=user,
        text=comment_text,
        parent=parent_comment
    )
    
    # Auto-notify post author (business logic)
    if post.author != user:
        create_notification(
            user=post.author,
            type='comment',
            message=f"{user.username} commented on your post"
        )
    
    # Auto-notify parent comment author (reply notification)
    if parent_comment and parent_comment.author != user:
        create_notification(
            user=parent_comment.author,
            type='reply',
            message=f"{user.username} replied to your comment"
        )
    
    return comment

def create_instagram_post_with_tags(user, image, caption, tagged_users_data):
    """Create post and tag users in one operation (like Instagram tagging)"""
    
    # Create the post
    post = user.instagram_posts.create(
        image=image,
        caption=caption
    )
    
    # Create tags for each user
    for tag_data in tagged_users_data:
        tagged_user = User.objects.get(username=tag_data['username'])
        post.tags.create(
            user=tagged_user,
            x_coordinate=tag_data['x'],
            y_coordinate=tag_data['y']
        )
        
        # Notify tagged user
        create_notification(
            user=tagged_user,
            type='tag',
            message=f"{user.username} tagged you in a post"
        )
    
    return post

# Usage examples
blog_post = BlogPost.objects.get(title='Django Tutorial')
user = User.objects.get(username='student123')

# Create comment in one step
comment = create_blog_comment_thread(
    post=blog_post,
    user=user,
    comment_text="Great tutorial! Very helpful."
)

# Create reply to existing comment
reply = create_blog_comment_thread(
    post=blog_post,
    user=user,
    comment_text="I agree!",
    parent_comment=comment
)

# Create Instagram post with tags
tagged_users = [
    {'username': 'friend1', 'x': 0.3, 'y': 0.7},
    {'username': 'friend2', 'x': 0.6, 'y': 0.4},
]

instagram_post = create_instagram_post_with_tags(
    user=user,
    image=uploaded_image,
    caption="Great day with friends! #memories",
    tagged_users_data=tagged_users
)
```

## Advanced Relationship Patterns: Professional Techniques

### Bulk Operations: Performance at Scale

When dealing with large datasets, bulk operations are essential for performance.

```python
class NetflixRecommendationEngine:
    """Handle recommendations for millions of users efficiently"""
    
    @staticmethod
    def bulk_update_user_recommendations(user_recommendations_data):
        """Update recommendations for thousands of users efficiently"""
        
        # user_recommendations_data = [
        #     {'user_id': 1, 'recommended_movie_ids': [10, 15, 23, 45]},
        #     {'user_id': 2, 'recommended_movie_ids': [12, 18, 25, 30]},
        #     ...
        # ]
        
        for user_data in user_recommendations_data:
            user = User.objects.get(id=user_data['user_id'])
            
            # Get or create recommendations playlist
            recommendations, created = MusicPlaylist.objects.get_or_create(
                user=user,
                name="Netflix Recommendations"
            )
            
            # Bulk set recommendations (much faster than add/remove)
            recommendations.songs.set(user_data['recommended_movie_ids'])
        
        print(f"Updated recommendations for {len(user_recommendations_data)} users")
    
    @staticmethod
    def bulk_add_viewing_history(viewing_sessions):
        """Efficiently record viewing sessions (like Netflix watch history)"""
        
        # Create ViewingSession objects in bulk
        viewing_objects = []
        for session in viewing_sessions:
            viewing_objects.append(ViewingSession(
                user_id=session['user_id'],
                movie_id=session['movie_id'],
                duration_watched=session['duration'],
                watched_at=session['timestamp']
            ))
        
        # Bulk create (single database query)
        ViewingSession.objects.bulk_create(viewing_objects, batch_size=1000)
        
        print(f"Added {len(viewing_objects)} viewing sessions")

class InstagramFollowManager:
    """Manage following relationships efficiently"""
    
    @staticmethod
    def bulk_follow_suggestions(user, suggested_user_ids):
        """Follow multiple suggested users (like "Follow All")"""
        
        # Filter out users already followed
        already_following = user.following.values_list('id', flat=True)
        new_follows = [uid for uid in suggested_user_ids if uid not in already_following]
        
        # Bulk add (single query)
        user.following.add(*new_follows)
        
        # Update follower counts efficiently
        User.objects.filter(id__in=new_follows).update(
            follower_count=F('follower_count') + 1
        )
        
        return len(new_follows)
    
    @staticmethod
    def bulk_unfollow_inactive_users(user, days_inactive=365):
        """Unfollow users who haven't posted recently"""
        
        cutoff_date = timezone.now() - timedelta(days=days_inactive)
        
        # Find inactive users
        inactive_users = user.following.filter(
            last_post_date__lt=cutoff_date
        )
        
        inactive_user_ids = list(inactive_users.values_list('id', flat=True))
        
        # Bulk remove
        user.following.remove(*inactive_user_ids)
        
        # Update follower counts
        User.objects.filter(id__in=inactive_user_ids).update(
            follower_count=F('follower_count') - 1
        )
        
        return len(inactive_user_ids)
```

### Custom Through Models: Advanced Relationship Data

Sometimes relationships need extra data, like when a relationship was created or has specific properties.

```python
class LinkedInConnection(models.Model):
    """Professional networking with relationship metadata"""
    from_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_connections')
    to_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_connections')
    status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('declined', 'Declined'),
        ('blocked', 'Blocked')
    ], default='pending')
    connected_at = models.DateTimeField(null=True, blank=True)
    message = models.TextField(max_length=300, blank=True)  # Connection request message
    relationship_type = models.CharField(max_length=30, choices=[
        ('colleague', 'Colleague'),
        ('friend', 'Friend'),
        ('client', 'Client'),
        ('other', 'Other')
    ], default='other')
    
    class Meta:
        unique_together = ['from_user', 'to_user']
    
    def accept_connection(self):
        """Accept a pending connection request"""
        if self.status == 'pending':
            self.status = 'accepted'
            self.connected_at = timezone.now()
            self.save()
            
            # Create reverse connection for mutual relationship
            LinkedInConnection.objects.get_or_create(
                from_user=self.to_user,
                to_user=self.from_user,
                defaults={
                    'status': 'accepted',
                    'connected_at': timezone.now(),
                    'relationship_type': self.relationship_type
                }
            )
            
            # Send notification
            create_notification(
                user=self.from_user,
                type='connection_accepted',
                message=f"{self.to_user.get_full_name()} accepted your connection request"
            )
            
            return True
        return False
    
    def decline_connection(self):
        """Decline a connection request"""
        if self.status == 'pending':
            self.status = 'declined'
            self.save()
            return True
        return False

class TwitterFollow(models.Model):
    """Twitter-style asymmetric following with notifications"""
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='twitter_following')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='twitter_followers')
    created_at = models.DateTimeField(auto_now_add=True)
    notifications_enabled = models.BooleanField(default=True)
    
    # Follow source tracking (like analytics)
    follow_source = models.CharField(max_length=20, choices=[
        ('search', 'Search'),
        ('suggestion', 'Suggestion'),
        ('profile', 'Profile Visit'),
        ('retweet', 'From Retweet'),
        ('mention', 'From Mention')
    ], default='profile')
    
    class Meta:
        unique_together = ['follower', 'following']
    
    def save(self, *args, **kwargs):
        """Override save to update follower counts"""
        is_new = not self.pk
        super().save(*args, **kwargs)
        
        if is_new:
            # Update counts atomically
            User.objects.filter(id=self.following.id).update(
                follower_count=F('follower_count') + 1
            )
            User.objects.filter(id=self.follower.id).update(
                following_count=F('following_count') + 1
            )
            
            # Send notification if enabled
            if self.following.notification_settings.new_follower_notifications:
                create_notification(
                    user=self.following,
                    type='new_follower',
                    message=f"{self.follower.username} started following you"
                )
    
    def delete(self, *args, **kwargs):
        """Override delete to update follower counts"""
        super().delete(*args, **kwargs)
        
        # Update counts atomically
        User.objects.filter(id=self.following.id).update(
            follower_count=F('follower_count') - 1
        )
        User.objects.filter(id=self.follower.id).update(
            following_count=F('following_count') - 1
        )

def smart_follow_user(follower, target_user, follow_source='profile'):
    """Smart following with business logic (like Twitter's follow system)"""
    
    # Check if already following
    if TwitterFollow.objects.filter(follower=follower, following=target_user).exists():
        return False, "Already following this user"
    
    # Check if user is blocked
    if target_user.blocked_users.filter(id=follower.id).exists():
        return False, "Cannot follow this user"
    
    # Check follow limits (prevent spam)
    daily_follows = TwitterFollow.objects.filter(
        follower=follower,
        created_at__gte=timezone.now() - timedelta(days=1)
    ).count()
    
    if daily_follows >= 100:  # Twitter-like daily limit
        return False, "Daily follow limit reached"
    
    # Create follow relationship
    follow = TwitterFollow.objects.create(
        follower=follower,
        following=target_user,
        follow_source=follow_source
    )
    
    return True, "Successfully followed user"
```

## Real-World Advanced Relations Example: Complete Social Platform

```python
class SocialPlatform:
    """Complete social media platform with advanced relationships"""
    
    class User(models.Model):
        username = models.CharField(max_length=50, unique=True)
        email = models.EmailField(unique=True)
        is_verified = models.BooleanField(default=False)
        follower_count = models.PositiveIntegerField(default=0)
        following_count = models.PositiveIntegerField(default=0)
        
        # Direct relationships
        following = models.ManyToManyField(
            'self',
            through='Follow',
            through_fields=('follower', 'following'),
            symmetrical=False,
            related_name='followers'
        )
        
        blocked_users = models.ManyToManyField(
            'self',
            symmetrical=False,
            related_name='blocked_by'
        )
    
    class Follow(models.Model):
        follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='follows')
        following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followed_by')
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            unique_together = ['follower', 'following']
    
    class Post(models.Model):
        author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
        content = models.TextField(max_length=2200)
        created_at = models.DateTimeField(auto_now_add=True)
        
        # Engagement relationships
        liked_by = models.ManyToManyField(User, through='PostLike', related_name='liked_posts')
        saved_by = models.ManyToManyField(User, related_name='saved_posts', blank=True)
        
    class PostLike(models.Model):
        user = models.ForeignKey(User, on_delete=models.CASCADE)
        post = models.ForeignKey(Post, on_delete=models.CASCADE)
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            unique_together = ['user', 'post']
    
    class Comment(models.Model):
        post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
        author = models.ForeignKey(User, on_delete=models.CASCADE)
        text = models.TextField(max_length=500)
        parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE)
        created_at = models.DateTimeField(auto_now_add=True)
        
        # Comment-specific relationships
        liked_by = models.ManyToManyField(User, related_name='liked_comments', blank=True)
    
    @staticmethod
    def create_comprehensive_post(author, content, tagged_users=None, mentioned_users=None):
        """Create post with all related objects (like Instagram post creation)"""
        
        # Create the main post
        post = SocialPlatform.Post.objects.create(
            author=author,
            content=content
        )
        
        # Process mentions in content
        if mentioned_users:
            for mentioned_user in mentioned_users:
                # Create notification for mention
                create_notification(
                    user=mentioned_user,
                    type='mention',
                    message=f"{author.username} mentioned you in a post",
                    related_object=post
                )
        
        # Process hashtags (would create HashtagPost relationships)
        hashtags = extract_hashtags(content)
        for hashtag in hashtags:
            tag, created = Hashtag.objects.get_or_create(name=hashtag)
            HashtagPost.objects.create(post=post, hashtag=tag)
        
        return post
    
    @staticmethod
    def get_personalized_feed(user, limit=20):
        """Generate personalized feed using complex relationships"""
        
        # Get users that this user follows
        following_users = user.following.all()
        
        # Get posts from followed users
        feed_posts = SocialPlatform.Post.objects.filter(
            author__in=following_users
        ).select_related('author').prefetch_related(
            Prefetch(
                'comments',
                queryset=SocialPlatform.Comment.objects.select_related('author')[:3]
            ),
            'liked_by'
        ).annotate(
            like_count=Count('liked_by'),
            comment_count=Count('comments'),
            is_liked=Exists(
                PostLike.objects.filter(post=OuterRef('pk'), user=user)
            ),
            is_saved=Exists(
                user.saved_posts.filter(pk=OuterRef('pk'))
            )
        ).order_by('-created_at')[:limit]
        
        return feed_posts
    
    @staticmethod
    def bulk_interaction_update(interactions_data):
        """Efficiently process bulk interactions (likes, saves, etc.)"""
        
        # interactions_data = [
        #     {'type': 'like', 'user_id': 1, 'post_id': 10},
        #     {'type': 'save', 'user_id': 1, 'post_id': 15},
        #     {'type': 'unlike', 'user_id': 2, 'post_id': 10},
        # ]
        
        likes_to_create = []
        likes_to_delete = []
        saves_to_add = []
        saves_to_remove = []
        
        for interaction in interactions_data:
            user_id = interaction['user_id']
            post_id = interaction['post_id']
            interaction_type = interaction['type']
            
            if interaction_type == 'like':
                likes_to_create.append(PostLike(user_id=user_id, post_id=post_id))
            elif interaction_type == 'unlike':
                likes_to_delete.append({'user_id': user_id, 'post_id': post_id})
            elif interaction_type == 'save':
                saves_to_add.append({'user_id': user_id, 'post_id': post_id})
            elif interaction_type == 'unsave':
                saves_to_remove.append({'user_id': user_id, 'post_id': post_id})
        
        # Bulk create likes
        if likes_to_create:
            PostLike.objects.bulk_create(likes_to_create, ignore_conflicts=True)
        
        # Bulk delete likes
        if likes_to_delete:
            for like_data in likes_to_delete:
                PostLike.objects.filter(
                    user_id=like_data['user_id'],
                    post_id=like_data['post_id']
                ).delete()
        
        # Bulk handle saves (M2M operations)
        for save_data in saves_to_add:
            user = SocialPlatform.User.objects.get(id=save_data['user_id'])
            user.saved_posts.add(save_data['post_id'])
        
        for unsave_data in saves_to_remove:
            user = SocialPlatform.User.objects.get(id=unsave_data['user_id'])
            user.saved_posts.remove(unsave_data['post_id'])
        
        return len(interactions_data)
```

Advanced model relations are the backbone of sophisticated applications. They enable the complex interactions we see in modern platforms - from LinkedIn's professional networks to Instagram's engagement systems. Master these patterns, and you'll build databases that mirror the complexity and richness of real-world relationships! 🌐

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/ref/models/relations/
    ''',
    "is_free": False,
    "xp_reward": 135,
    "exercises": [
        {
            "id": "social-platform-relations",
            "title": "Build Advanced Social Platform Relations System",
            "type": "project",
            "instructions": """Create a comprehensive social media platform with advanced relationship management:

1. Implement complex relationship models (Follow, Like, Save, Comment)
2. Create advanced related manager operations (add, remove, set, clear, create)
3. Build bulk operation methods for performance at scale
4. Implement custom through models with additional data
5. Create personalized content algorithms using relationships

Your solution should demonstrate:
- Advanced relationship operations with proper error handling
- Bulk operations for performance optimization
- Custom through models with business logic
- Complex queries using relationships
- Real-world social media features and interactions""",
            "starter_code": """from django.db import models
from django.contrib.auth.models import User
from django.db.models import Count, Exists, OuterRef, Prefetch, F
from django.utils import timezone
from datetime import timedelta

class SocialUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='social_profile')
    username = models.CharField(max_length=50, unique=True)
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    is_verified = models.BooleanField(default=False)
    
    # Define your relationships here
    following = models.ManyToManyField(
        'self',
        through='Follow',
        symmetrical=False,
        related_name='followers'
    )

class Follow(models.Model):
    follower = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='follows')
    following = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='followed_by')
    created_at = models.DateTimeField(auto_now_add=True)
    follow_source = models.CharField(max_length=20, default='profile')
    
    class Meta:
        unique_together = ['follower', 'following']

class Post(models.Model):
    author = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(max_length=2200)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Define engagement relationships
    liked_by = models.ManyToManyField(SocialUser, through='PostLike', related_name='liked_posts')

class PostLike(models.Model):
    user = models.ForeignKey(SocialUser, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'post']

# Your task: Implement these relationship management methods

def follow_user(follower, target_user, follow_source='profile'):
    \"\"\"
    Follow a user with validation and business logic:
    - Check if already following
    - Validate follow limits
    - Update follower counts
    - Send notifications
    \"\"\"
    # Implement follow functionality
    pass

def unfollow_user(follower, target_user):
    \"\"\"
    Unfollow a user:
    - Remove follow relationship
    - Update follower counts
    - Handle cleanup
    \"\"\"
    # Implement unfollow functionality
    pass

def bulk_follow_users(follower, user_ids_to_follow):
    \"\"\"
    Follow multiple users efficiently:
    - Filter out invalid/already followed users
    - Bulk create relationships
    - Update counts efficiently
    \"\"\"
    # Implement bulk follow functionality
    pass

def like_post(user, post):
    \"\"\"
    Like a post:
    - Create like relationship
    - Update like counts
    - Send notifications
    \"\"\"
    # Implement like functionality
    pass

def get_personalized_feed(user, limit=20):
    \"\"\"
    Generate personalized feed:
    - Get posts from followed users
    - Optimize queries with select_related/prefetch_related
    - Annotate with interaction data
    - Order by engagement and recency
    \"\"\"
    # Implement feed generation
    pass

def bulk_interaction_processing(interactions_data):
    \"\"\"
    Process bulk user interactions efficiently:
    - Handle likes, unlikes, follows, unfollows
    - Use bulk operations for performance
    - Update related counts
    \"\"\"
    # Implement bulk processing
    pass

# Test your implementation
# user1 = SocialUser.objects.create(username='user1')
# user2 = SocialUser.objects.create(username='user2')
# follow_user(user1, user2, 'suggestion')""",
            "solution": """from django.db import models, transaction
from django.contrib.auth.models import User
from django.db.models import Count, Exists, OuterRef, Prefetch, F, Q
from django.utils import timezone
from datetime import timedelta
from django.core.exceptions import ValidationError

class SocialUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='social_profile')
    username = models.CharField(max_length=50, unique=True)
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    is_verified = models.BooleanField(default=False)
    is_private = models.BooleanField(default=False)
    
    following = models.ManyToManyField(
        'self',
        through='Follow',
        symmetrical=False,
        related_name='followers'
    )
    
    blocked_users = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='blocked_by',
        blank=True
    )
    
    def __str__(self):
        return self.username
    
    class Meta:
        indexes = [
            models.Index(fields=['username']),
            models.Index(fields=['-follower_count']),
        ]

class Follow(models.Model):
    follower = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='follows')
    following = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='followed_by')
    created_at = models.DateTimeField(auto_now_add=True)
    follow_source = models.CharField(max_length=20, choices=[
        ('profile', 'Profile Visit'),
        ('suggestion', 'Suggestion'),
        ('search', 'Search'),
        ('mutual', 'Mutual Friends'),
    ], default='profile')
    
    class Meta:
        unique_together = ['follower', 'following']
        indexes = [
            models.Index(fields=['follower', '-created_at']),
            models.Index(fields=['following', '-created_at']),
        ]
    
    def save(self, *args, **kwargs):
        \"\"\"Update follower counts on save\"\"\"
        is_new = not self.pk
        super().save(*args, **kwargs)
        
        if is_new:
            # Update counts atomically
            SocialUser.objects.filter(id=self.following.id).update(
                follower_count=F('follower_count') + 1
            )
            SocialUser.objects.filter(id=self.follower.id).update(
                following_count=F('following_count') + 1
            )
    
    def delete(self, *args, **kwargs):
        \"\"\"Update follower counts on delete\"\"\"
        super().delete(*args, **kwargs)
        
        # Update counts atomically
        SocialUser.objects.filter(id=self.following.id).update(
            follower_count=F('follower_count') - 1
        )
        SocialUser.objects.filter(id=self.follower.id).update(
            following_count=F('following_count') - 1
        )

class Post(models.Model):
    author = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(max_length=2200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_public = models.BooleanField(default=True)
    
    liked_by = models.ManyToManyField(
        SocialUser, 
        through='PostLike', 
        related_name='liked_posts'
    )
    
    saved_by = models.ManyToManyField(
        SocialUser,
        related_name='saved_posts',
        blank=True
    )
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['-created_at']),
        ]

class PostLike(models.Model):
    user = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='post_likes')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'post']
        indexes = [
            models.Index(fields=['post', '-created_at']),
            models.Index(fields=['user', '-created_at']),
        ]

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(SocialUser, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField(max_length=500)
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE, related_name='replies')
    created_at = models.DateTimeField(auto_now_add=True)
    
    liked_by = models.ManyToManyField(SocialUser, related_name='liked_comments', blank=True)
    
    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['post', 'created_at']),
        ]

def follow_user(follower, target_user, follow_source='profile'):
    \"\"\"
    Follow a user with comprehensive validation and business logic
    \"\"\"
    # Validation checks
    if follower == target_user:
        return False, \"Cannot follow yourself\"
    
    # Check if already following
    if Follow.objects.filter(follower=follower, following=target_user).exists():
        return False, \"Already following this user\"
    
    # Check if blocked by target user
    if target_user.blocked_users.filter(id=follower.id).exists():
        return False, \"Cannot follow this user\"
    
    # Check if follower has blocked the target
    if follower.blocked_users.filter(id=target_user.id).exists():
        return False, \"Cannot follow blocked user\"
    
    # Check daily follow limits (anti-spam)
    today = timezone.now().date()
    daily_follows = Follow.objects.filter(
        follower=follower,
        created_at__date=today
    ).count()
    
    if daily_follows >= 100:  # Twitter-like limit
        return False, \"Daily follow limit reached\"
    
    # Check total following limits
    if follower.following_count >= 5000:  # Instagram-like limit
        return False, \"Following limit reached\"
    
    try:
        with transaction.atomic():
            # Create follow relationship
            follow = Follow.objects.create(
                follower=follower,
                following=target_user,
                follow_source=follow_source
            )
            
            # Send notification to target user
            create_notification(
                user=target_user,
                notification_type='new_follower',
                message=f\"{follower.username} started following you\",
                related_object=follow
            )
            
            return True, \"Successfully followed user\"
            
    except Exception as e:
        return False, f\"Error following user: {str(e)}\"

def unfollow_user(follower, target_user):
    \"\"\"
    Unfollow a user with proper cleanup
    \"\"\"
    try:
        with transaction.atomic():
            # Remove follow relationship
            follow = Follow.objects.get(follower=follower, following=target_user)
            follow.delete()
            
            return True, \"Successfully unfollowed user\"
            
    except Follow.DoesNotExist:
        return False, \"Not following this user\"
    except Exception as e:
        return False, f\"Error unfollowing user: {str(e)}\"

def bulk_follow_users(follower, user_ids_to_follow, follow_source='suggestion'):
    \"\"\"
    Follow multiple users efficiently with validation
    \"\"\"
    if not user_ids_to_follow:
        return 0, \"No users to follow\"
    
    # Remove self from list
    user_ids_to_follow = [uid for uid in user_ids_to_follow if uid != follower.id]
    
    # Get users that exist and are not already followed
    existing_users = SocialUser.objects.filter(
        id__in=user_ids_to_follow
    ).exclude(
        # Exclude blocked users
        Q(blocked_by=follower) | Q(blocked_users=follower)
    ).exclude(
        # Exclude already followed users
        followed_by__follower=follower
    )
    
    # Check daily limits
    today = timezone.now().date()
    daily_follows = Follow.objects.filter(
        follower=follower,
        created_at__date=today
    ).count()
    
    available_follows = max(0, 100 - daily_follows)
    users_to_follow = existing_users[:available_follows]
    
    if not users_to_follow:
        return 0, \"No valid users to follow\"
    
    try:
        with transaction.atomic():
            # Bulk create follow relationships
            follows_to_create = [
                Follow(
                    follower=follower,
                    following=user,
                    follow_source=follow_source
                )
                for user in users_to_follow
            ]
            
            Follow.objects.bulk_create(follows_to_create)
            
            # Update follower counts
            user_ids = [user.id for user in users_to_follow]
            SocialUser.objects.filter(id__in=user_ids).update(
                follower_count=F('follower_count') + 1
            )
            SocialUser.objects.filter(id=follower.id).update(
                following_count=F('following_count') + len(user_ids)
            )
            
            # Send notifications (could be done asynchronously)
            for user in users_to_follow:
                create_notification(
                    user=user,
                    notification_type='new_follower',
                    message=f\"{follower.username} started following you\"
                )
            
            return len(user_ids), f\"Successfully followed {len(user_ids)} users\"
            
    except Exception as e:
        return 0, f\"Error in bulk follow: {str(e)}\"

def like_post(user, post):
    \"\"\"
    Like a post with validation and atomic operations
    \"\"\"
    if post.author == user:
        return False, \"Cannot like your own post\"
    
    # Check if post is accessible (privacy settings)
    if not post.is_public and not Follow.objects.filter(
        follower=user, following=post.author
    ).exists():
        return False, \"Post is not accessible\"
    
    try:
        with transaction.atomic():
            # Create like relationship
            like, created = PostLike.objects.get_or_create(
                user=user,
                post=post
            )
            
            if created:
                # Send notification to post author
                if post.author != user:
                    create_notification(
                        user=post.author,
                        notification_type='post_like',
                        message=f\"{user.username} liked your post\",
                        related_object=post
                    )
                
                return True, \"Successfully liked post\"
            else:
                return False, \"Already liked this post\"
                
    except Exception as e:
        return False, f\"Error liking post: {str(e)}\"

def unlike_post(user, post):
    \"\"\"
    Unlike a post
    \"\"\"
    try:
        like = PostLike.objects.get(user=user, post=post)
        like.delete()
        return True, \"Successfully unliked post\"
    except PostLike.DoesNotExist:
        return False, \"Post not liked\"
    except Exception as e:
        return False, f\"Error unliking post: {str(e)}\"

def save_post(user, post):
    \"\"\"
    Save a post to user's saved posts
    \"\"\"
    if not post.is_public and not Follow.objects.filter(
        follower=user, following=post.author
    ).exists() and post.author != user:
        return False, \"Post is not accessible\"
    
    try:
        user.saved_posts.add(post)
        return True, \"Post saved successfully\"
    except Exception as e:
        return False, f\"Error saving post: {str(e)}\"

def get_personalized_feed(user, limit=20, offset=0):
    \"\"\"
    Generate personalized feed with optimal queries
    \"\"\"
    # Get following user IDs for efficiency
    following_ids = list(
        user.follows.values_list('following_id', flat=True)
    )
    
    if not following_ids:
        # New user - show popular public content
        return Post.objects.filter(
            is_public=True,
            created_at__gte=timezone.now() - timedelta(days=7)
        ).select_related('author').annotate(
            like_count=Count('likes'),
            comment_count=Count('comments'),
            is_liked=Exists(
                PostLike.objects.filter(post=OuterRef('pk'), user=user)
            ),
            is_saved=Exists(
                user.saved_posts.filter(pk=OuterRef('pk'))
            )
        ).order_by('-like_count', '-created_at')[offset:offset + limit]
    
    # Personalized feed from followed users
    feed_posts = Post.objects.filter(
        Q(author_id__in=following_ids) |  # Posts from followed users
        Q(  # Popular posts from users not followed
            is_public=True,
            created_at__gte=timezone.now() - timedelta(hours=24),
            likes__gte=50
        )
    ).select_related(
        'author'
    ).prefetch_related(
        Prefetch(
            'comments',
            queryset=Comment.objects.select_related('author').order_by('-created_at')[:3],
            to_attr='preview_comments'
        )
    ).annotate(
        like_count=Count('likes', distinct=True),
        comment_count=Count('comments', distinct=True),
        is_liked=Exists(
            PostLike.objects.filter(post=OuterRef('pk'), user=user)
        ),
        is_saved=Exists(
            user.saved_posts.filter(pk=OuterRef('pk'))
        ),
        # Engagement score for ranking
        engagement_score=Count('likes', distinct=True) + Count('comments', distinct=True) * 2,
        
        # Friend boost (posts from followed users get priority)
        friend_boost=models.Case(
            models.When(author_id__in=following_ids, then=1000),
            default=0,
            output_field=models.IntegerField()
        )
    ).order_by(
        '-friend_boost',  # Prioritize friends
        '-engagement_score',  # Then by engagement
        '-created_at'  # Then by recency
    )[offset:offset + limit]
    
    return feed_posts

def bulk_interaction_processing(interactions_data):
    \"\"\"
    Process bulk user interactions efficiently
    
    interactions_data format:
    [
        {'type': 'like', 'user_id': 1, 'post_id': 10},
        {'type': 'unlike', 'user_id': 1, 'post_id': 15},
        {'type': 'follow', 'follower_id': 1, 'following_id': 20},
        {'type': 'save', 'user_id': 1, 'post_id': 25},
    ]
    \"\"\"
    if not interactions_data:
        return 0, \"No interactions to process\"
    
    likes_to_create = []
    likes_to_delete = []
    follows_to_create = []
    unfollows_to_process = []
    saves_to_add = []
    saves_to_remove = []
    
    # Group interactions by type
    for interaction in interactions_data:
        interaction_type = interaction['type']
        
        if interaction_type == 'like':
            likes_to_create.append(
                PostLike(
                    user_id=interaction['user_id'],
                    post_id=interaction['post_id']
                )
            )
        elif interaction_type == 'unlike':
            likes_to_delete.append({
                'user_id': interaction['user_id'],
                'post_id': interaction['post_id']
            })
        elif interaction_type == 'follow':
            follows_to_create.append(
                Follow(
                    follower_id=interaction['follower_id'],
                    following_id=interaction['following_id'],
                    follow_source='bulk'
                )
            )
        elif interaction_type == 'unfollow':
            unfollows_to_process.append({
                'follower_id': interaction['follower_id'],
                'following_id': interaction['following_id']
            })
        elif interaction_type == 'save':
            saves_to_add.append({
                'user_id': interaction['user_id'],
                'post_id': interaction['post_id']
            })
        elif interaction_type == 'unsave':
            saves_to_remove.append({
                'user_id': interaction['user_id'],
                'post_id': interaction['post_id']
            })
    
    processed_count = 0
    
    try:
        with transaction.atomic():
            # Process likes
            if likes_to_create:
                PostLike.objects.bulk_create(likes_to_create, ignore_conflicts=True)
                processed_count += len(likes_to_create)
            
            # Process unlikes
            for unlike_data in likes_to_delete:
                deleted_count, _ = PostLike.objects.filter(
                    user_id=unlike_data['user_id'],
                    post_id=unlike_data['post_id']
                ).delete()
                processed_count += deleted_count
            
            # Process follows
            if follows_to_create:
                Follow.objects.bulk_create(follows_to_create, ignore_conflicts=True)
                
                # Update follower counts
                following_ids = [f.following_id for f in follows_to_create]
                follower_ids = [f.follower_id for f in follows_to_create]
                
                SocialUser.objects.filter(id__in=following_ids).update(
                    follower_count=F('follower_count') + 1
                )
                SocialUser.objects.filter(id__in=follower_ids).update(
                    following_count=F('following_count') + 1
                )
                
                processed_count += len(follows_to_create)
            
            # Process unfollows
            for unfollow_data in unfollows_to_process:
                deleted_count, _ = Follow.objects.filter(
                    follower_id=unfollow_data['follower_id'],
                    following_id=unfollow_data['following_id']
                ).delete()
                
                if deleted_count > 0:
                    # Update counts
                    SocialUser.objects.filter(id=unfollow_data['following_id']).update(
                        follower_count=F('follower_count') - 1
                    )
                    SocialUser.objects.filter(id=unfollow_data['follower_id']).update(
                        following_count=F('following_count') - 1
                    )
                    processed_count += deleted_count
            
            # Process saves/unsaves (M2M operations)
            for save_data in saves_to_add:
                user = SocialUser.objects.get(id=save_data['user_id'])
                user.saved_posts.add(save_data['post_id'])
                processed_count += 1
            
            for unsave_data in saves_to_remove:
                user = SocialUser.objects.get(id=unsave_data['user_id'])
                user.saved_posts.remove(unsave_data['post_id'])
                processed_count += 1
        
        return processed_count, f\"Successfully processed {processed_count} interactions\"
        
    except Exception as e:
        return 0, f\"Error processing bulk interactions: {str(e)}\"

def get_mutual_followers(user1, user2):
    \"\"\"
    Get mutual followers between two users
    \"\"\"
    user1_followers = set(
        user1.followed_by.values_list('follower_id', flat=True)
    )
    user2_followers = set(
        user2.followed_by.values_list('follower_id', flat=True)
    )
    
    mutual_follower_ids = user1_followers.intersection(user2_followers)
    
    return SocialUser.objects.filter(
        id__in=mutual_follower_ids
    ).order_by('-follower_count')

def get_follow_suggestions(user, limit=10):
    \"\"\"
    Generate follow suggestions based on mutual connections and interests
    \"\"\"
    # Get users followed by people this user follows
    following_ids = list(user.follows.values_list('following_id', flat=True))
    
    if not following_ids:
        # New user - suggest popular accounts
        return SocialUser.objects.filter(
            is_verified=True
        ).exclude(
            id=user.id
        ).order_by('-follower_count')[:limit]
    
    # Find users followed by friends but not by this user
    suggestions = SocialUser.objects.filter(
        followed_by__follower_id__in=following_ids
    ).exclude(
        id=user.id
    ).exclude(
        followed_by__follower=user  # Not already followed
    ).exclude(
        blocked_by=user  # Not blocked
    ).annotate(
        mutual_connections=Count('followed_by__follower', distinct=True),
        total_followers=F('follower_count')
    ).order_by('-mutual_connections', '-total_followers')[:limit]
    
    return suggestions

def create_notification(user, notification_type, message, related_object=None):
    \"\"\"
    Create notification (placeholder - would integrate with notification system)
    \"\"\"
    # In a real app, this would create notification objects or send push notifications
    print(f\"Notification for {user.username}: {message}\")

# Example usage and testing
def test_social_platform():
    \"\"\"
    Test the social platform functionality
    \"\"\"
    # Create test users
    user1 = SocialUser.objects.create(username='alice')
    user2 = SocialUser.objects.create(username='bob')
    user3 = SocialUser.objects.create(username='charlie')
    
    # Test following
    success, message = follow_user(user1, user2, 'profile')
    print(f\"Follow result: {success} - {message}\")
    
    # Test bulk follow
    users_to_follow = [user3.id]
    count, message = bulk_follow_users(user1, users_to_follow, 'suggestion')
    print(f\"Bulk follow result: {count} - {message}\")
    
    # Create test post
    post = Post.objects.create(
        author=user2,
        content=\"Hello from Bob! #firstpost\"
    )
    
    # Test liking
    success, message = like_post(user1, post)
    print(f\"Like result: {success} - {message}\")
    
    # Test personalized feed
    feed = get_personalized_feed(user1, limit=5)
    print(f\"Feed contains {len(feed)} posts\")
    
    # Test bulk interactions
    interactions = [
        {'type': 'like', 'user_id': user1.id, 'post_id': post.id},
        {'type': 'save', 'user_id': user1.id, 'post_id': post.id},
    ]
    count, message = bulk_interaction_processing(interactions)
    print(f\"Bulk interactions: {count} - {message}\")
    
    return user1, user2, user3, post""",
            "test_cases": [
                {
                    "name": "Functions implement advanced relationship operations",
                    "input": "",
                    "expected_contains": ["add", "remove", "create", "bulk_create", "get_or_create", "transaction.atomic"]
                }
            ],
            "xp_reward": 190,
            "hints": [
                "Use transaction.atomic() for multi-step relationship operations",
                "Implement proper validation before creating relationships",
                "Use bulk operations for performance when processing many interactions",
                "Update denormalized counts (follower_count) with F() expressions",
                "Add proper error handling and meaningful return messages"
            ]
        }
    ]
}