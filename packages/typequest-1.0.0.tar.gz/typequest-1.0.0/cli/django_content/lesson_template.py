"""
Template for new Django lessons
Copy this file and modify for new lesson content
"""

# TODO: Update these values for the new lesson
LESSON_ID = 4
CHAPTER_NUMBER = 4
LESSON_TITLE = "Django Templates and Frontend"
LESSON_SLUG = "django-templates"
XP_REWARD = 35
IS_FREE = True

DJANGO_LESSON_TEMPLATE = {
    "id": LESSON_ID,
    "chapter": CHAPTER_NUMBER,
    "title": LESSON_TITLE,
    "slug": LESSON_SLUG,
    "content": '''
# Lesson Title Here

## Introduction

Brief introduction to the topic...

### Why This Topic Matters

- Point 1
- Point 2
- Point 3

## Main Content

Detailed explanation of the topic with code examples:

```python
# Example code
def example_function():
    return "Hello Django!"
```

## Practical Examples

Real-world examples and use cases...

## Best Practices

1. **Practice 1**: Description
2. **Practice 2**: Description
3. **Practice 3**: Description

## What's Next?

Brief description of the next lesson...

Ready for the next challenge? Let's go!
    ''',
    "is_free": IS_FREE,
    "xp_reward": XP_REWARD,
    "exercises": [
        {
            "id": "exercise-id",
            "title": "Exercise Title",
            "type": "python",  # or "project", "quiz"
            "instructions": "Clear instructions for the exercise...",
            "starter_code": "# Starter code here\npass",
            "solution": "# Solution code here\nprint('Completed!')",
            "test_cases": [
                {
                    "name": "Test case description",
                    "input": "",
                    "expected_contains": ["expected", "strings", "in", "output"]
                }
            ],
            "xp_reward": 40,
            "hints": [
                "Helpful hint 1",
                "Helpful hint 2",
                "Helpful hint 3"
            ]
        }
    ]
}

# To use this template:
# 1. Copy this file to a new lesson file (e.g., templates.py)
# 2. Update the constants at the top
# 3. Replace the content section with your lesson content
# 4. Update the exercise details
# 5. Add the import to __init__.py
# 6. Add the lesson to DJANGO_COURSE_CONTENT["lessons"]