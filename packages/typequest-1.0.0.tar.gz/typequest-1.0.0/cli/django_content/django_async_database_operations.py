"""
Django Async Development - Lesson 2: Async Database Operations
Master Django's async database capabilities for high-performance data operations
"""

DJANGO_ASYNC_DATABASE_OPERATIONS_LESSON = {
    "id": 60,
    "chapter": 60,
    "title": "Django Async Database Operations: High-Performance Data Access",
    "slug": "django-async-database-operations", 
    "description": "Learn Django's async database operations including async ORM, query optimization, and database connection management",
    "content": '''# Django Async Database Operations: High-Performance Data Access

## 🎯 Advancing from Async Views to Async Data

**Building on our async views foundation**, we now dive into Django's **async database operations** - the next critical step in building truly scalable applications. While async views handle external APIs efficiently, async database operations optimize your **data layer performance**.

**Async Database Benefits**:
- **Non-blocking database queries** → Handle multiple database operations concurrently
- **Improved connection efficiency** → Better database pool utilization
- **Reduced query latency** → Parallel data fetching and processing
- **Scalable data operations** → Handle more database-intensive requests
- **Memory efficiency** → Lower memory footprint for database connections

Remember our async ListView examples? Now we'll make the **database operations themselves async** for even better performance.

## 💾 Async Database Performance Database

Let's create a comprehensive database for testing async database operations:

```sql
-- ASYNC DATABASE OPERATIONS TESTING
-- Database: async_db_operations

-- Users table optimized for async operations
CREATE TABLE async_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(150) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    first_name VARCHAR(30),
    last_name VARCHAR(150),
    bio TEXT,
    avatar_url VARCHAR(500),
    follower_count INTEGER DEFAULT 0,
    following_count INTEGER DEFAULT 0,
    post_count INTEGER DEFAULT 0,
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    preferences JSONB DEFAULT '{}'::jsonb
);

-- Sample users for async testing
INSERT INTO async_users (username, email, first_name, last_name, bio, follower_count, following_count, post_count, is_verified) VALUES
('async_alice', 'alice@async.com', 'Alice', 'Johnson', 'Django async enthusiast and software engineer', 15420, 892, 234, TRUE),
('sync_bob', 'bob@sync.com', 'Bob', 'Smith', 'Traditional Django developer learning async', 8934, 456, 156, FALSE), 
('realtime_carol', 'carol@realtime.com', 'Carol', 'Davis', 'Real-time applications specialist', 23456, 1234, 567, TRUE),
('perf_david', 'david@perf.com', 'David', 'Wilson', 'Performance optimization expert', 12678, 678, 389, TRUE),
('scale_eve', 'eve@scale.com', 'Eve', 'Brown', 'Scalability and async patterns advocate', 34567, 1890, 678, FALSE);

-- Posts table for async content operations  
CREATE TABLE async_posts (
    id SERIAL PRIMARY KEY,
    author_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    title VARCHAR(300),
    post_type VARCHAR(20) DEFAULT 'text',
    like_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    share_count INTEGER DEFAULT 0,
    view_count INTEGER DEFAULT 0,
    hashtags VARCHAR(50)[] DEFAULT '{}',
    mentions INTEGER[] DEFAULT '{}',
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES async_users(id)
);

-- Sample posts for async operations
INSERT INTO async_posts (author_id, content, title, post_type, like_count, comment_count, hashtags) VALUES
(1, 'Django async database operations are game-changing for performance! 🚀', 'Async DB Performance', 'text', 156, 23, ARRAY['django', 'async', 'performance']),
(3, 'Real-time features need async database patterns for proper scalability.', 'Real-time Async Patterns', 'text', 234, 45, ARRAY['realtime', 'async', 'scalability']),
(4, 'Measured 3x performance improvement with async database operations.', 'Performance Benchmark', 'text', 89, 12, ARRAY['performance', 'benchmark', 'async']),
(2, 'Learning async patterns - the connection pooling benefits are amazing!', 'Async Learning Journey', 'text', 67, 8, ARRAY['learning', 'async', 'connections']),
(5, 'Building scalable apps requires mastering async database operations.', 'Scalable Architecture', 'text', 123, 19, ARRAY['scalability', 'architecture', 'async']);

-- Comments for nested async operations
CREATE TABLE async_comments (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL,
    author_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    parent_id INTEGER,
    like_count INTEGER DEFAULT 0,
    is_edited BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES async_posts(id),
    FOREIGN KEY (author_id) REFERENCES async_users(id),
    FOREIGN KEY (parent_id) REFERENCES async_comments(id)
);

-- Sample comments for async nested queries
INSERT INTO async_comments (post_id, author_id, content, like_count) VALUES
(1, 2, 'Great explanation of async database benefits!', 12),
(1, 4, 'The performance gains are substantial in my testing.', 8),
(2, 1, 'Async patterns are essential for real-time apps.', 15),
(3, 5, 'Your benchmarks align with my production experience.', 6),
(4, 3, 'Connection pooling optimization is often overlooked.', 9);

-- Async operation metrics tracking
CREATE TABLE async_db_metrics (
    id SERIAL PRIMARY KEY,
    operation_type VARCHAR(100) NOT NULL,
    query_method VARCHAR(50) NOT NULL, -- 'sync', 'async', 'bulk_async'
    execution_time_ms DECIMAL(8, 3) NOT NULL,
    records_processed INTEGER DEFAULT 1,
    concurrent_operations INTEGER DEFAULT 1,
    database_connections_used INTEGER DEFAULT 1,
    memory_usage_mb DECIMAL(8, 2),
    cpu_usage_percent DECIMAL(5, 2),
    cache_hit_ratio DECIMAL(5, 2),
    query_complexity VARCHAR(20), -- 'simple', 'complex', 'nested'
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample async database performance metrics
INSERT INTO async_db_metrics (operation_type, query_method, execution_time_ms, records_processed, concurrent_operations, database_connections_used, query_complexity) VALUES
('user_timeline_fetch', 'sync', 145.6, 50, 1, 1, 'complex'),
('user_timeline_fetch', 'async', 89.2, 50, 5, 1, 'complex'),
('bulk_user_create', 'sync', 234.7, 100, 1, 1, 'simple'),
('bulk_user_create', 'async', 98.4, 100, 10, 2, 'simple'),
('nested_comments_load', 'sync', 189.3, 200, 1, 1, 'nested'),
('nested_comments_load', 'async', 67.8, 200, 8, 2, 'nested'),
('user_search_filter', 'sync', 78.9, 25, 1, 1, 'simple'),
('user_search_filter', 'async', 45.2, 25, 12, 1, 'simple');

-- Connection pool monitoring for async databases
CREATE TABLE async_connection_pools (
    id SERIAL PRIMARY KEY,
    pool_name VARCHAR(100) NOT NULL,
    max_size INTEGER NOT NULL,
    current_checked_out INTEGER DEFAULT 0,
    current_overflow INTEGER DEFAULT 0,
    current_checked_in INTEGER DEFAULT 0,
    total_checkouts BIGINT DEFAULT 0,
    total_connections_created BIGINT DEFAULT 0,
    total_disconnects BIGINT DEFAULT 0,
    avg_checkout_time_ms DECIMAL(8, 3),
    peak_checkout_count INTEGER DEFAULT 0,
    overflow_count INTEGER DEFAULT 0,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample connection pool data
INSERT INTO async_connection_pools (pool_name, max_size, current_checked_out, current_checked_in, total_checkouts, avg_checkout_time_ms, peak_checkout_count) VALUES
('async_primary_pool', 50, 12, 28, 45678, 15.6, 35),
('async_read_replica_pool', 30, 8, 18, 23456, 12.3, 22),
('sync_primary_pool', 20, 18, 2, 12345, 89.7, 20),
('async_analytics_pool', 15, 3, 9, 8901, 45.2, 12);

-- Async query execution plans
CREATE TABLE async_query_plans (
    id SERIAL PRIMARY KEY,
    query_hash VARCHAR(64) NOT NULL,
    query_sql TEXT NOT NULL,
    execution_plan JSONB NOT NULL,
    avg_execution_time_ms DECIMAL(8, 3),
    execution_count INTEGER DEFAULT 0,
    is_async_optimized BOOLEAN DEFAULT FALSE,
    optimization_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_executed TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample query execution plans
INSERT INTO async_query_plans (query_hash, query_sql, execution_plan, avg_execution_time_ms, execution_count, is_async_optimized, optimization_notes) VALUES
('hash123', 'SELECT * FROM async_users WHERE is_active = true', '{"plan": "Seq Scan", "cost": "0..23.50"}', 12.5, 450, TRUE, 'Index scan on is_active field'),
('hash456', 'SELECT u.*, p.* FROM async_users u JOIN async_posts p ON u.id = p.author_id', '{"plan": "Hash Join", "cost": "25.75..89.45"}', 45.8, 234, TRUE, 'Async join optimization applied'),
('hash789', 'SELECT COUNT(*) FROM async_posts WHERE created_at > NOW() - INTERVAL 1 hour', '{"plan": "Aggregate", "cost": "15.25..15.26"}', 8.9, 89, FALSE, 'Could benefit from async aggregation');
```

## 🔧 Django Async ORM Operations

### 1. Basic Async Model Operations

**Scenario**: Instagram's async user management  
*Building on the async view patterns we've mastered*

```python
# models.py - Async-optimized models
from django.db import models
from django.contrib.auth.models import AbstractUser
from asgiref.sync import sync_to_async
import asyncio

class AsyncUser(AbstractUser):
    """User model optimized for async operations"""
    bio = models.TextField(blank=True, max_length=500)
    avatar_url = models.URLField(blank=True)
    follower_count = models.IntegerField(default=0)
    following_count = models.IntegerField(default=0)
    post_count = models.IntegerField(default=0)
    is_verified = models.BooleanField(default=False)
    last_activity = models.DateTimeField(auto_now=True)
    preferences = models.JSONField(default=dict)
    
    class Meta:
        db_table = 'async_users'
        indexes = [
            models.Index(fields=['is_active', 'last_activity']),
            models.Index(fields=['follower_count']),
            models.Index(fields=['is_verified']),
        ]
    
    # Async model methods
    async def aget_followers(self):
        """Get user's followers asynchronously"""
        followers = []
        async for follower in self.followers.select_related().all():
            followers.append(follower)
        return followers
    
    async def aget_timeline(self, limit=50):
        """Get user's timeline posts asynchronously"""
        posts = []
        async for post in AsyncPost.objects.filter(
            author_id__in=await self.aget_following_ids()
        ).select_related('author').order_by('-created_at')[:limit]:
            posts.append(post)
        return posts
    
    async def aget_following_ids(self):
        """Get list of user IDs this user follows"""
        following_ids = []
        async for user in self.following.all():
            following_ids.append(user.id)
        return following_ids

class AsyncPost(models.Model):
    """Post model with async capabilities"""
    author = models.ForeignKey(AsyncUser, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField()
    title = models.CharField(max_length=300, blank=True)
    post_type = models.CharField(max_length=20, default='text')
    like_count = models.IntegerField(default=0)
    comment_count = models.IntegerField(default=0)
    hashtags = models.JSONField(default=list)
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'async_posts'
        indexes = [
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['is_published', '-created_at']),
            models.Index(fields=['-like_count']),
        ]
    
    # Async model operations
    async def aget_comments(self, limit=20):
        """Get post comments asynchronously"""
        comments = []
        async for comment in self.comments.select_related('author').order_by('-created_at')[:limit]:
            comments.append(comment)
        return comments
    
    async def aincrement_views(self):
        """Increment view count asynchronously"""
        await AsyncPost.objects.filter(id=self.id).aupdate(
            view_count=models.F('view_count') + 1
        )

# Async service layer for complex operations
class InstagramAsyncService:
    """Service layer for async Instagram-style operations"""
    
    @staticmethod
    async def create_user_async(username, email, **extra_fields):
        """Create user asynchronously with validation"""
        
        # Check if username exists (async)
        username_exists = await AsyncUser.objects.filter(username=username).aexists()
        if username_exists:
            raise ValueError(f"Username {username} already exists")
        
        # Check if email exists (async) 
        email_exists = await AsyncUser.objects.filter(email=email).aexists()
        if email_exists:
            raise ValueError(f"Email {email} already registered")
        
        # Create user asynchronously
        user = await AsyncUser.objects.acreate(
            username=username,
            email=email,
            **extra_fields
        )
        
        return user
    
    @staticmethod
    async def get_user_dashboard_async(user_id):
        """Get complete user dashboard data asynchronously"""
        
        # Fetch user and related data concurrently
        user_task = AsyncUser.objects.select_related().aget(id=user_id)
        posts_task = AsyncPost.objects.filter(author_id=user_id).order_by('-created_at')[:10]
        followers_task = AsyncUser.objects.filter(following=user_id).count()
        
        # Execute all queries concurrently
        user, recent_posts, follower_count = await asyncio.gather(
            user_task,
            sync_to_async(list)(posts_task),
            sync_to_async(followers_task.acount)(),
            return_exceptions=True
        )
        
        # Handle exceptions
        if isinstance(user, Exception):
            raise user
        
        recent_posts = recent_posts if not isinstance(recent_posts, Exception) else []
        follower_count = follower_count if not isinstance(follower_count, Exception) else 0
        
        return {
            'user': user,
            'recent_posts': recent_posts,
            'follower_count': follower_count,
            'dashboard_generated_at': timezone.now()
        }
    
    @staticmethod 
    async def bulk_create_posts_async(posts_data):
        """Bulk create posts asynchronously for better performance"""
        
        posts_to_create = []
        for post_data in posts_data:
            post = AsyncPost(
                author_id=post_data['author_id'],
                content=post_data['content'],
                title=post_data.get('title', ''),
                post_type=post_data.get('post_type', 'text'),
                hashtags=post_data.get('hashtags', [])
            )
            posts_to_create.append(post)
        
        # Bulk create asynchronously
        created_posts = await sync_to_async(AsyncPost.objects.bulk_create)(
            posts_to_create, 
            batch_size=100
        )
        
        return created_posts
```

### 2. Advanced Async Query Patterns

**Scenario**: Twitter's async timeline generation  
*Extending our async ListView knowledge to complex database patterns*

```python
# async_queries.py - Advanced async query patterns
import asyncio
from django.db import models
from django.db.models import Q, F, Count, Sum, Avg
from asgiref.sync import sync_to_async
from typing import List, Dict, Any

class TwitterAsyncQueries:
    """Advanced async query patterns for Twitter-style features"""
    
    @staticmethod
    async def generate_user_timeline_async(user_id: int, limit: int = 50) -> List[Dict]:
        """Generate user timeline with async optimization
        This builds on our async ListView patterns but with raw database efficiency"""
        
        # Get user's following list asynchronously
        following_ids = []
        async for user in AsyncUser.objects.filter(
            followers=user_id
        ).values_list('id', flat=True):
            following_ids.append(user)
        
        # Add user's own posts
        following_ids.append(user_id)
        
        # Fetch timeline posts with async iteration
        timeline_posts = []
        async for post in AsyncPost.objects.filter(
            author_id__in=following_ids,
            is_published=True
        ).select_related(
            'author'
        ).prefetch_related(
            'comments'
        ).order_by('-created_at')[:limit]:
            
            # Build post data with async operations
            post_data = {
                'id': post.id,
                'content': post.content,
                'author': {
                    'id': post.author.id,
                    'username': post.author.username,
                    'is_verified': post.author.is_verified,
                },
                'created_at': post.created_at.isoformat(),
                'like_count': post.like_count,
                'comment_count': post.comment_count,
                'hashtags': post.hashtags,
            }
            timeline_posts.append(post_data)
        
        return timeline_posts
    
    @staticmethod
    async def get_trending_topics_async() -> List[Dict]:
        """Get trending hashtags using async aggregation"""
        
        # Use async aggregation for trending analysis
        trending_data = await AsyncPost.objects.filter(
            created_at__gte=timezone.now() - timedelta(hours=24)
        ).aggregate(
            total_posts=Count('id'),
            avg_engagement=Avg('like_count')
        )
        
        # Async hashtag analysis (simplified for example)
        hashtag_counts = {}
        async for post in AsyncPost.objects.filter(
            created_at__gte=timezone.now() - timedelta(hours=24)
        ).values_list('hashtags', flat=True):
            
            for hashtag in post or []:
                hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1
        
        # Sort and return trending hashtags
        trending = [
            {'hashtag': tag, 'count': count}
            for tag, count in sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        ]
        
        return trending
    
    @staticmethod
    async def search_users_async(query: str, limit: int = 20) -> List[Dict]:
        """Async user search with complex filtering"""
        
        # Complex search query with async execution
        search_results = []
        async for user in AsyncUser.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(bio__icontains=query)
        ).filter(
            is_active=True
        ).order_by(
            # Boost verified users
            '-is_verified',
            # Then by follower count
            '-follower_count'
        )[:limit]:
            
            user_data = {
                'id': user.id,
                'username': user.username,
                'display_name': f"{user.first_name} {user.last_name}".strip(),
                'bio': user.bio,
                'follower_count': user.follower_count,
                'is_verified': user.is_verified,
                'avatar_url': user.avatar_url,
            }
            search_results.append(user_data)
        
        return search_results
    
    @staticmethod
    async def get_user_engagement_stats_async(user_id: int) -> Dict:
        """Get comprehensive user engagement statistics asynchronously"""
        
        # Run multiple async aggregations concurrently
        post_stats_task = AsyncPost.objects.filter(author_id=user_id).aggregate(
            total_posts=Count('id'),
            total_likes=Sum('like_count'),
            total_comments=Sum('comment_count'),
            avg_likes_per_post=Avg('like_count')
        )
        
        follower_stats_task = AsyncUser.objects.filter(id=user_id).values(
            'follower_count', 'following_count', 'post_count'
        ).first()
        
        recent_activity_task = AsyncPost.objects.filter(
            author_id=user_id,
            created_at__gte=timezone.now() - timedelta(days=30)
        ).count()
        
        # Execute all async queries concurrently
        post_stats, follower_stats, recent_posts = await asyncio.gather(
            sync_to_async(lambda: post_stats_task)(),
            sync_to_async(lambda: follower_stats_task)(),
            sync_to_async(recent_activity_task.acount)(),
            return_exceptions=True
        )
        
        # Combine results
        engagement_stats = {
            'post_statistics': post_stats if not isinstance(post_stats, Exception) else {},
            'follower_statistics': follower_stats if not isinstance(follower_stats, Exception) else {},
            'recent_activity': recent_posts if not isinstance(recent_posts, Exception) else 0,
            'engagement_rate': 0,  # Would calculate based on likes/followers ratio
            'activity_score': 0,   # Would calculate based on posting frequency
        }
        
        # Calculate engagement metrics
        if post_stats and follower_stats:
            total_likes = post_stats.get('total_likes', 0)
            follower_count = follower_stats.get('follower_count', 0)
            if follower_count > 0:
                engagement_stats['engagement_rate'] = (total_likes / follower_count) * 100
        
        return engagement_stats
```

### 3. Async Database Connection Management

**Scenario**: LinkedIn's connection pool optimization

```python
# async_db_management.py - Database connection optimization
import asyncio
import asyncpg
from django.conf import settings
from django.db import connections
from contextlib import asynccontextmanager
import logging

logger = logging.getLogger('async_database')

class AsyncDatabaseManager:
    """Manage async database connections efficiently"""
    
    def __init__(self):
        self.connection_pools = {}
        self.pool_stats = {}
    
    async def create_async_pool(self, database_alias='default'):
        """Create async connection pool for database"""
        
        db_config = settings.DATABASES[database_alias]
        
        # Create asyncpg connection pool
        pool = await asyncpg.create_pool(
            host=db_config['HOST'],
            port=db_config['PORT'],
            user=db_config['USER'],
            password=db_config['PASSWORD'],
            database=db_config['NAME'],
            min_size=5,
            max_size=50,
            command_timeout=60,
            server_settings={
                'application_name': 'django_async_app',
                'search_path': 'public',
            }
        )
        
        self.connection_pools[database_alias] = pool
        self.pool_stats[database_alias] = {
            'total_connections': 0,
            'active_connections': 0,
            'total_queries': 0,
            'avg_query_time': 0,
        }
        
        logger.info(f"Created async pool for {database_alias}")
        return pool
    
    @asynccontextmanager
    async def get_async_connection(self, database_alias='default'):
        """Get async database connection from pool"""
        
        if database_alias not in self.connection_pools:
            await self.create_async_pool(database_alias)
        
        pool = self.connection_pools[database_alias]
        
        async with pool.acquire() as connection:
            self.pool_stats[database_alias]['active_connections'] += 1
            try:
                yield connection
            finally:
                self.pool_stats[database_alias]['active_connections'] -= 1
    
    async def execute_async_query(self, query, params=None, database_alias='default'):
        """Execute async query with connection management"""
        
        start_time = asyncio.get_event_loop().time()
        
        async with self.get_async_connection(database_alias) as connection:
            try:
                if params:
                    result = await connection.fetch(query, *params)
                else:
                    result = await connection.fetch(query)
                
                # Update statistics
                end_time = asyncio.get_event_loop().time()
                execution_time = (end_time - start_time) * 1000  # Convert to ms
                
                stats = self.pool_stats[database_alias]
                stats['total_queries'] += 1
                stats['avg_query_time'] = (
                    (stats['avg_query_time'] * (stats['total_queries'] - 1) + execution_time) 
                    / stats['total_queries']
                )
                
                return result
                
            except Exception as e:
                logger.error(f"Async query failed: {e}")
                raise
    
    async def bulk_insert_async(self, table_name, columns, data, database_alias='default'):
        """Perform bulk insert asynchronously"""
        
        async with self.get_async_connection(database_alias) as connection:
            # Use COPY for maximum performance
            await connection.copy_records_to_table(
                table_name, 
                records=data,
                columns=columns
            )
    
    async def close_all_pools(self):
        """Close all async connection pools"""
        
        for alias, pool in self.connection_pools.items():
            await pool.close()
            logger.info(f"Closed async pool for {alias}")
        
        self.connection_pools.clear()
        self.pool_stats.clear()

# Global async database manager
async_db_manager = AsyncDatabaseManager()

# Async database operations service
class AsyncDatabaseService:
    """High-level async database operations"""
    
    @staticmethod
    async def get_user_timeline_optimized(user_id: int, limit: int = 50):
        """Optimized async timeline query using raw SQL"""
        
        query = """
            SELECT 
                p.id, p.content, p.created_at, p.like_count, p.comment_count,
                u.id as author_id, u.username, u.first_name, u.last_name, u.is_verified
            FROM async_posts p
            JOIN async_users u ON p.author_id = u.id
            WHERE p.author_id IN (
                SELECT following_id FROM user_follows WHERE follower_id = $1
                UNION
                SELECT $1
            )
            AND p.is_published = true
            ORDER BY p.created_at DESC
            LIMIT $2
        """
        
        result = await async_db_manager.execute_async_query(
            query, [user_id, limit]
        )
        
        return [dict(row) for row in result]
    
    @staticmethod
    async def bulk_create_users_async(users_data: List[Dict]):
        """Bulk create users with async optimization"""
        
        columns = ['username', 'email', 'first_name', 'last_name', 'bio']
        
        # Prepare data for bulk insert
        records = []
        for user_data in users_data:
            record = tuple(user_data.get(col, '') for col in columns)
            records.append(record)
        
        await async_db_manager.bulk_insert_async(
            'async_users', columns, records
        )
    
    @staticmethod
    async def get_database_performance_metrics():
        """Get async database performance metrics"""
        
        metrics = {}
        for alias, stats in async_db_manager.pool_stats.items():
            metrics[alias] = {
                'total_queries': stats['total_queries'],
                'active_connections': stats['active_connections'],
                'avg_query_time_ms': round(stats['avg_query_time'], 2),
                'pool_utilization': f"{stats['active_connections']}/50"  # Assuming max 50
            }
        
        return metrics
```

## 🎯 Key Takeaways

1. **Async ORM operations prevent blocking** → `aget()`, `acreate()`, `aupdate()`, `adelete()`
2. **Async iteration with `async for`** → Process large querysets without memory issues  
3. **Concurrent operations with `asyncio.gather()`** → Parallel database operations
4. **Connection pool optimization** → Better resource utilization in async apps
5. **Raw async SQL for performance** → When ORM async isn't enough
6. **Bulk operations are async-friendly** → Handle large datasets efficiently
7. **Monitor async database performance** → Track connection usage and query times

Async database operations complete the picture started with async views - now your entire data pipeline is non-blocking and scalable!
''',
    "difficulty": "advanced", 
    "estimated_time": 50,
    "xp_reward": 35,
    "prerequisites": ["async_views", "django-database-optimization"],
    "exercises": [
        {
            "id": "async_db_1",
            "title": "Explore Async Database Performance",
            "prompt": "Let's examine our async database operations data. Write a query to see performance comparisons between sync and async database operations.",
            "table_name": "async_db_metrics",
            "initial_query": "SELECT * FROM async_db_metrics LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "async_db_metrics"],
            "hint": "Use SELECT * FROM async_db_metrics LIMIT 5; to see async vs sync database performance",
            "solution": "SELECT * FROM async_db_metrics LIMIT 5;",
            "explanation": "This table shows the performance benefits of async database operations. Notice how async operations typically have lower execution times and can handle more concurrent operations, building on the async view patterns we learned."
        },
        {
            "id": "async_db_2", 
            "title": "Async vs Sync Performance Analysis",
            "prompt": "Compare async and sync database operation performance. Write a query to see average execution times by operation type and query method.",
            "table_name": "async_db_metrics",
            "expected_keywords": ["SELECT", "operation_type", "query_method", "AVG", "execution_time_ms", "GROUP BY"],
            "hint": "Group by operation_type and query_method, then calculate average execution times",
            "solution": "SELECT operation_type, query_method, AVG(execution_time_ms) as avg_time, AVG(concurrent_operations) as avg_concurrency FROM async_db_metrics GROUP BY operation_type, query_method ORDER BY operation_type, query_method;",
            "explanation": "Async database operations show significant performance improvements, especially under concurrent load. The async methods handle multiple operations simultaneously while sync methods process them sequentially."
        },
        {
            "id": "async_db_3",
            "title": "User Data for Async Operations",
            "prompt": "Examine the user data that would be used in async ORM operations. Write a query to see users with their engagement metrics.",
            "table_name": "async_users", 
            "expected_keywords": ["SELECT", "username", "follower_count", "post_count", "is_verified"],
            "hint": "Select user fields that would be commonly accessed in async operations",
            "solution": "SELECT username, follower_count, following_count, post_count, is_verified, last_activity FROM async_users ORDER BY follower_count DESC;",
            "explanation": "This user data represents what Django's async ORM operations like aget(), async for loops, and select_related() would work with. The async methods allow fetching this data without blocking other operations."
        },
        {
            "id": "async_db_4",
            "title": "Async Connection Pool Utilization", 
            "prompt": "Analyze async database connection pool efficiency. Write a query to see connection pool utilization rates.",
            "table_name": "async_connection_pools",
            "expected_keywords": ["SELECT", "pool_name", "current_checked_out", "max_size", "total_checkouts"],
            "hint": "Calculate utilization rates by comparing current usage to maximum capacity",
            "solution": "SELECT pool_name, max_size, current_checked_out, (current_checked_out::decimal / max_size * 100) as utilization_percent, avg_checkout_time_ms FROM async_connection_pools ORDER BY utilization_percent DESC;",
            "explanation": "Async connection pools show better utilization rates because connections aren't held by blocking operations. This allows more efficient resource sharing compared to sync database operations."
        },
        {
            "id": "async_db_5",
            "title": "Posts and Comments for Nested Async Queries",
            "prompt": "Look at the post and comment data for async relationship operations. Write a query to see posts with their comment counts.",
            "table_name": "async_posts",
            "expected_keywords": ["SELECT", "title", "content", "author_id", "like_count", "comment_count"],
            "hint": "Select post data that would be used in async prefetch_related and select_related operations",
            "solution": "SELECT p.title, p.like_count, p.comment_count, p.hashtags, u.username FROM async_posts p JOIN async_users u ON p.author_id = u.id ORDER BY p.like_count DESC;",
            "explanation": "This JOIN operation demonstrates the type of relationship data that async ORM operations handle efficiently. Django's async select_related() and prefetch_related() optimize these relationships without blocking."
        },
        {
            "id": "async_db_6",
            "title": "Query Execution Plan Analysis",
            "prompt": "Examine async-optimized query execution plans. Write a query to see which queries are optimized for async operations.",
            "table_name": "async_query_plans",
            "expected_keywords": ["SELECT", "query_sql", "avg_execution_time_ms", "is_async_optimized", "execution_count"],
            "hint": "Select query plan data to see async optimization status and performance",
            "solution": "SELECT query_sql, avg_execution_time_ms, execution_count, is_async_optimized, optimization_notes FROM async_query_plans ORDER BY avg_execution_time_ms ASC;",
            "explanation": "Query execution plans show how async database operations are optimized. Async-optimized queries typically have better execution times and can handle higher concurrency through efficient connection management."
        }
    ],
    "key_concepts": [
        "Async ORM Operations (aget, acreate, aupdate, adelete)",
        "Async Query Iteration with async for", 
        "Concurrent Database Operations with asyncio.gather()",
        "Async Connection Pool Management",
        "Raw Async SQL for Performance Optimization",
        "Bulk Async Operations for Large Datasets", 
        "Async Database Performance Monitoring",
        "Async Model Methods and Relationships"
    ]
}