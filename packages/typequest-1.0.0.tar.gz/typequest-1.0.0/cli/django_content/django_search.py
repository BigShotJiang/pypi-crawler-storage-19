"""
Django Database - Lesson 5: Full-Text Search and Search Optimization
Master Django's search capabilities from basic filtering to advanced full-text search
"""

DJANGO_SEARCH_LESSON = {
    "id": 48,
    "chapter": 48,
    "title": "Django Search: From Basic to Advanced Full-Text",
    "slug": "django-search",
    "description": "Master Django search from basic filtering to advanced full-text search and ranking",
    "content": '''# Django Search: From Basic to Advanced Full-Text

## 🎯 Understanding Search in Django

Search functionality is **essential** for modern applications. Users expect to find what they need quickly and accurately. Django provides multiple search approaches:

- **Basic filtering** → Simple contains/icontains lookups
- **Complex Q objects** → Boolean search logic  
- **Full-text search** → Database-powered search with ranking
- **External search engines** → Elasticsearch, Solr integration

Think of search as your application's **discovery engine** - it can make or break user experience.

## 🔍 Comprehensive Content Database

Let's work with a rich content database (like Medium, Reddit, or Stack Overflow):

```sql
-- Articles/posts table with rich content
CREATE TABLE content_articles (
    id SERIAL PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    author_id INTEGER NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    tags TEXT[], -- PostgreSQL array field for tags
    published_date TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    view_count INTEGER DEFAULT 0,
    upvotes INTEGER DEFAULT 0,
    downvotes INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    reading_time INTEGER, -- estimated reading time in minutes
    difficulty_level VARCHAR(20) DEFAULT 'beginner',
    is_featured BOOLEAN DEFAULT FALSE,
    language VARCHAR(10) DEFAULT 'en',
    search_vector tsvector -- PostgreSQL full-text search vector
);

-- Rich sample content for search testing
INSERT INTO content_articles (title, content, excerpt, author_id, author_name, category, tags, published_date, view_count, upvotes, reading_time, difficulty_level) VALUES
('Getting Started with Django Models', 'Django models are the foundation of any Django application. They define the structure of your database and provide an object-relational mapping (ORM) layer. In this comprehensive guide, we''ll explore how to create, modify, and optimize Django models for real-world applications...', 'Learn Django models from the ground up with practical examples and best practices.', 1, 'Sarah Chen', 'Web Development', ARRAY['django', 'python', 'orm', 'database', 'models'], '2024-11-15 10:30:00', 15420, 342, 12, 'beginner'),

('Advanced Python Decorators Explained', 'Python decorators are one of the most powerful features of the language, yet they often confuse beginners. A decorator is essentially a function that takes another function as an argument and extends or modifies its behavior without explicitly changing it. In this deep dive, we''ll explore decorator patterns, practical use cases, and advanced techniques...', 'Master Python decorators with real-world examples and advanced patterns.', 2, 'Mike Rodriguez', 'Programming', ARRAY['python', 'decorators', 'functions', 'advanced', 'patterns'], '2024-11-20 14:22:00', 8934, 267, 18, 'intermediate'),

('Machine Learning with TensorFlow: A Complete Guide', 'TensorFlow has revolutionized machine learning development, making it accessible to developers worldwide. This comprehensive guide covers everything from basic neural networks to advanced deep learning architectures. We''ll build real projects including image classification, natural language processing, and recommendation systems...', 'Complete TensorFlow tutorial from basics to advanced deep learning projects.', 3, 'Dr. Emma Johnson', 'Machine Learning', ARRAY['tensorflow', 'machine-learning', 'ai', 'neural-networks', 'deep-learning'], '2024-12-01 09:15:00', 23651, 892, 45, 'advanced'),

('React Hooks: Transforming Function Components', 'React Hooks changed the game for React developers by allowing state and lifecycle methods in function components. useState, useEffect, useContext, and custom hooks have simplified React development significantly. In this tutorial, we''ll explore all built-in hooks and learn to create powerful custom hooks for real applications...', 'Master React Hooks to write cleaner, more efficient React applications.', 4, 'David Kim', 'Frontend Development', ARRAY['react', 'hooks', 'javascript', 'frontend', 'components'], '2024-12-10 16:45:00', 12456, 423, 25, 'intermediate'),

('Database Optimization: PostgreSQL Performance Tuning', 'PostgreSQL is a powerful database, but poor optimization can kill performance. This guide covers indexing strategies, query optimization, connection pooling, and monitoring techniques. We''ll analyze real-world scenarios and provide actionable optimization strategies for high-traffic applications...', 'Optimize PostgreSQL performance with proven strategies and real-world examples.', 5, 'Anna Petrov', 'Database', ARRAY['postgresql', 'database', 'optimization', 'performance', 'indexing'], '2024-12-15 11:30:00', 9876, 234, 30, 'advanced'),

('CSS Grid vs Flexbox: When to Use What', 'CSS Grid and Flexbox are both powerful layout systems, but they serve different purposes. Understanding when to use each is crucial for modern web development. This article provides clear guidelines, practical examples, and real-world use cases to help you choose the right tool for each layout challenge...', 'Learn when to use CSS Grid vs Flexbox with practical examples and guidelines.', 6, 'Carlos Santos', 'CSS', ARRAY['css', 'grid', 'flexbox', 'layout', 'responsive'], '2024-12-20 13:20:00', 7654, 189, 15, 'intermediate'),

('Building RESTful APIs with Node.js and Express', 'RESTful APIs are the backbone of modern web applications. This comprehensive guide covers API design principles, Express.js best practices, authentication, error handling, testing, and deployment. We''ll build a complete API from scratch with proper documentation and versioning...', 'Complete guide to building professional RESTful APIs with Node.js and Express.', 7, 'Lisa Wang', 'Backend Development', ARRAY['nodejs', 'express', 'api', 'rest', 'backend'], '2024-12-22 08:45:00', 11234, 356, 35, 'intermediate'),

('Docker for Developers: From Basics to Production', 'Docker has transformed how we develop and deploy applications. This practical guide covers Docker fundamentals, containerization strategies, Docker Compose for multi-service applications, and production deployment patterns. Perfect for developers ready to embrace containerization...', 'Master Docker for development and production with hands-on examples.', 8, 'James Brown', 'DevOps', ARRAY['docker', 'containers', 'devops', 'deployment', 'kubernetes'], '2024-12-23 15:10:00', 8765, 298, 28, 'intermediate'),

('Vue.js 3 Composition API Deep Dive', 'Vue.js 3''s Composition API offers a new way to organize component logic. This detailed exploration covers reactive references, computed properties, lifecycle hooks, and custom composables. We''ll refactor real components and demonstrate advanced patterns for large-scale applications...', 'Explore Vue.js 3 Composition API with practical examples and advanced patterns.', 9, 'Sophie Martin', 'Frontend Development', ARRAY['vuejs', 'composition-api', 'javascript', 'frontend', 'reactive'], '2024-12-24 12:30:00', 6543, 187, 22, 'intermediate'),

('GraphQL: The Future of API Development', 'GraphQL is revolutionizing how we think about APIs. Unlike REST, GraphQL allows clients to request exactly the data they need. This comprehensive tutorial covers schema design, resolvers, mutations, subscriptions, and performance optimization. Build a complete GraphQL API from scratch...', 'Learn GraphQL from fundamentals to advanced patterns with a complete hands-on project.', 10, 'Ahmed Hassan', 'API Development', ARRAY['graphql', 'api', 'schema', 'resolvers', 'mutations'], '2024-12-25 14:20:00', 9321, 412, 40, 'advanced');

-- Comments table for additional search content
CREATE TABLE article_comments (
    id SERIAL PRIMARY KEY,
    article_id INTEGER NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    upvotes INTEGER DEFAULT 0,
    FOREIGN KEY (article_id) REFERENCES content_articles(id)
);

-- Sample comments for richer search data
INSERT INTO article_comments (article_id, author_name, content, upvotes) VALUES
(1, 'Alex Developer', 'Great introduction to Django models! The examples are very clear and practical.', 23),
(1, 'Maria Code', 'This helped me understand the relationship between models and database tables. Thanks!', 15),
(3, 'Data Scientist Joe', 'Excellent TensorFlow tutorial. The deep learning examples are spot on.', 45),
(3, 'ML Student', 'Finally understand neural networks thanks to this comprehensive guide!', 32),
(4, 'React Fan', 'React hooks have indeed transformed how we write components. Great explanation!', 18),
(7, 'Backend Dev', 'This API tutorial is exactly what I needed for my Node.js project.', 27);

-- User profiles for author search
CREATE TABLE user_profiles (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    bio TEXT,
    expertise_areas TEXT[], -- Array of expertise areas
    location VARCHAR(100),
    website VARCHAR(200),
    github_username VARCHAR(50),
    total_articles INTEGER DEFAULT 0,
    reputation_score INTEGER DEFAULT 0
);

-- Sample user profiles
INSERT INTO user_profiles (id, username, full_name, bio, expertise_areas, location, total_articles, reputation_score) VALUES
(1, 'sarahchen', 'Sarah Chen', 'Senior Django developer with 8 years of experience building scalable web applications.', ARRAY['django', 'python', 'web-development', 'postgresql'], 'San Francisco, CA', 45, 8420),
(2, 'mikedev', 'Mike Rodriguez', 'Python expert specializing in clean code and design patterns.', ARRAY['python', 'software-architecture', 'clean-code'], 'Austin, TX', 32, 6750),
(3, 'emmajohnson', 'Dr. Emma Johnson', 'Machine Learning researcher and TensorFlow contributor.', ARRAY['machine-learning', 'tensorflow', 'ai', 'data-science'], 'Boston, MA', 28, 9240),
(4, 'davidk', 'David Kim', 'Frontend architect with expertise in React and modern JavaScript.', ARRAY['react', 'javascript', 'frontend', 'typescript'], 'Seattle, WA', 51, 7890);
```

## 🔧 Basic Search Patterns

### 1. Simple Text Search - The Foundation

**Scenario**: Medium's basic article search

```python
from django.db.models import Q

class ArticleSearch:
    @staticmethod
    def basic_search(query):
        """Basic text search across title and content"""
        
        return ContentArticle.objects.filter(
            Q(title__icontains=query) | 
            Q(content__icontains=query) |
            Q(excerpt__icontains=query)
        ).distinct()

    @staticmethod
    def search_by_category(query, category=None):
        """Search with optional category filter"""
        
        search_filter = Q(title__icontains=query) | Q(content__icontains=query)
        
        if category:
            search_filter &= Q(category=category)
        
        return ContentArticle.objects.filter(search_filter).order_by('-published_date')

# Usage
articles = ArticleSearch.basic_search("django models")
django_articles = ArticleSearch.search_by_category("python", "Web Development")
```

### 2. Advanced Filtering with Q Objects

**Scenario**: Stack Overflow's complex search filters

```python
def advanced_search(query, tags=None, difficulty=None, author=None, date_range=None):
    """Advanced search with multiple filter options"""
    
    # Base text search
    search_query = Q(title__icontains=query) | Q(content__icontains=query)
    
    # Tag filtering (PostgreSQL array field)
    if tags:
        for tag in tags:
            search_query &= Q(tags__icontains=[tag])
    
    # Difficulty filter
    if difficulty:
        search_query &= Q(difficulty_level=difficulty)
    
    # Author filter
    if author:
        search_query &= Q(author_name__icontains=author)
    
    # Date range filter
    if date_range:
        start_date, end_date = date_range
        search_query &= Q(published_date__range=[start_date, end_date])
    
    return ContentArticle.objects.filter(search_query).annotate(
        # Add relevance scoring
        relevance_score=Case(
            When(title__icontains=query, then=Value(3)),
            When(excerpt__icontains=query, then=Value(2)), 
            default=Value(1),
            output_field=IntegerField()
        )
    ).order_by('-relevance_score', '-upvotes', '-view_count')

# Usage
results = advanced_search(
    query="django",
    tags=["python", "orm"],
    difficulty="intermediate", 
    date_range=(datetime(2024, 12, 1), datetime(2024, 12, 31))
)
```

### 3. Search with Ranking and Scoring

**Scenario**: Reddit's post ranking algorithm

```python
from django.db.models import F, Value
from django.db.models.functions import Greatest

def ranked_search(query):
    """Search with sophisticated ranking algorithm"""
    
    return ContentArticle.objects.filter(
        Q(title__icontains=query) | Q(content__icontains=query)
    ).annotate(
        # Title match gets highest score
        title_score=Case(
            When(title__icontains=query, then=Value(10)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Excerpt match gets medium score
        excerpt_score=Case(
            When(excerpt__icontains=query, then=Value(5)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Content match gets base score
        content_score=Case(
            When(content__icontains=query, then=Value(2)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Popularity boost based on engagement
        popularity_score=F('upvotes') + F('view_count') / 100,
        
        # Recency boost (newer content gets slight preference)
        recency_boost=Case(
            When(published_date__gte=timezone.now() - timedelta(days=30), then=Value(2)),
            When(published_date__gte=timezone.now() - timedelta(days=90), then=Value(1)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Combined relevance score
        total_score=F('title_score') + F('excerpt_score') + F('content_score') + 
                   F('popularity_score') / 1000 + F('recency_boost')
        
    ).order_by('-total_score', '-published_date')
```

## 🔍 PostgreSQL Full-Text Search

### 4. Database-Powered Full-Text Search

**Scenario**: GitHub's code and documentation search

```python
from django.contrib.postgres.search import SearchVector, SearchQuery, SearchRank

def full_text_search(query):
    """PostgreSQL full-text search with ranking"""
    
    # Create search vector from multiple fields
    search_vector = SearchVector('title', weight='A') + \
                   SearchVector('excerpt', weight='B') + \
                   SearchVector('content', weight='C') + \
                   SearchVector('author_name', weight='D')
    
    # Create search query
    search_query = SearchQuery(query)
    
    return ContentArticle.objects.annotate(
        search=search_vector,
        rank=SearchRank(search_vector, search_query)
    ).filter(
        search=search_query
    ).order_by('-rank', '-upvotes')

def advanced_full_text_search(query):
    """Advanced full-text search with phrase and boolean operators"""
    
    # Support different query types
    if '"' in query:
        # Phrase search
        search_query = SearchQuery(query, search_type='phrase')
    elif '&' in query or '|' in query:
        # Boolean search
        search_query = SearchQuery(query, search_type='raw')
    else:
        # Standard search
        search_query = SearchQuery(query)
    
    search_vector = SearchVector('title', weight='A') + \
                   SearchVector('excerpt', weight='B') + \
                   SearchVector('content', weight='C')
    
    return ContentArticle.objects.annotate(
        search=search_vector,
        rank=SearchRank(search_vector, search_query),
        # Add headline for search result snippets
        headline=SearchHeadline(
            'content',
            search_query,
            start_sel='<mark>',
            stop_sel='</mark>',
            max_words=30
        )
    ).filter(rank__gt=0.1).order_by('-rank')
```

### 5. Search with Trigram Similarity

**Scenario**: Fuzzy search for typos and variations

```python
from django.contrib.postgres.search import TrigramSimilarity

def fuzzy_search(query, threshold=0.3):
    """Fuzzy search using trigram similarity for typos"""
    
    return ContentArticle.objects.annotate(
        # Calculate similarity for different fields
        title_similarity=TrigramSimilarity('title', query),
        author_similarity=TrigramSimilarity('author_name', query),
        content_similarity=TrigramSimilarity('content', query)
    ).filter(
        # Find articles with similarity above threshold
        title_similarity__gt=threshold
    ).order_by('-title_similarity')

def combined_search(query):
    """Combine exact and fuzzy search for best results"""
    
    # First try exact full-text search
    exact_results = full_text_search(query)
    
    if exact_results.count() >= 10:
        return exact_results
    
    # If few exact results, add fuzzy matches
    fuzzy_results = fuzzy_search(query, threshold=0.2)
    
    # Combine results, avoiding duplicates
    combined_ids = set()
    final_results = []
    
    # Add exact results first
    for article in exact_results:
        combined_ids.add(article.id)
        final_results.append(article)
    
    # Add fuzzy results that aren't already included
    for article in fuzzy_results:
        if article.id not in combined_ids and len(final_results) < 20:
            final_results.append(article)
    
    return final_results
```

## 🏢 Real-World Production Examples

### Medium's Article Discovery

```python
def medium_style_search(query, user_interests=None):
    """Medium-style article discovery with personalization"""
    
    # Base search query
    search_query = Q(title__icontains=query) | Q(content__icontains=query)
    
    articles = ContentArticle.objects.filter(search_query).annotate(
        # Relevance scoring
        text_score=Case(
            When(title__icontains=query, then=Value(5)),
            When(excerpt__icontains=query, then=Value(3)),
            default=Value(1),
            output_field=IntegerField()
        ),
        
        # Quality indicators
        quality_score=(
            F('upvotes') * 2 - F('downvotes') + 
            F('comment_count') * 3 + 
            F('view_count') / 100
        ),
        
        # Reading time preference (articles around 10-15 minutes preferred)
        reading_time_score=Case(
            When(reading_time__range=[8, 18], then=Value(3)),
            When(reading_time__range=[5, 25], then=Value(2)),
            default=Value(1),
            output_field=IntegerField()
        ),
        
        # Personalization based on user interests
        interest_score=Case(
            When(category__in=user_interests or [], then=Value(4)),
            default=Value(0),
            output_field=IntegerField()
        ) if user_interests else Value(0),
        
        # Combined relevance
        relevance=F('text_score') + F('quality_score') / 100 + 
                 F('reading_time_score') + F('interest_score')
    ).order_by('-relevance', '-published_date')
    
    return articles
```

### Stack Overflow's Question Search

```python
def stackoverflow_search(query, tags=None, has_answers=None, score_min=None):
    """Stack Overflow style question/answer search"""
    
    search_filter = Q(title__icontains=query) | Q(content__icontains=query)
    
    # Tag filtering (exact match for Stack Overflow tags)
    if tags:
        for tag in tags:
            search_filter &= Q(tags__contains=[tag])
    
    # Filter by answer availability
    if has_answers:
        search_filter &= Q(comment_count__gt=0)
    
    # Minimum score filter
    if score_min:
        search_filter &= Q(upvotes__gte=score_min)
    
    return ContentArticle.objects.filter(search_filter).annotate(
        # Stack Overflow's scoring algorithm
        so_score=F('upvotes') - F('downvotes'),
        
        # Answer quality indicator
        answer_quality=F('comment_count') * 2 + F('view_count') / 50,
        
        # Combined ranking
        ranking=F('so_score') * 10 + F('answer_quality') + 
               Case(
                   When(title__icontains=query, then=Value(20)),
                   default=Value(5),
                   output_field=IntegerField()
               )
    ).order_by('-ranking', '-published_date')
```

### GitHub's Repository Search

```python
def github_style_search(query, language=None, stars_min=None):
    """GitHub-style repository/code search"""
    
    # Simulate repository search on articles
    search_query = (
        Q(title__icontains=query) | 
        Q(content__icontains=query) |
        Q(author_name__icontains=query)
    )
    
    # Language filter (using category as proxy)
    if language:
        search_query &= Q(category__icontains=language)
    
    # Minimum stars (using upvotes as proxy)
    if stars_min:
        search_query &= Q(upvotes__gte=stars_min)
    
    return ContentArticle.objects.filter(search_query).annotate(
        # GitHub's relevance factors
        name_match=Case(
            When(title__icontains=query, then=Value(100)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        description_match=Case(
            When(excerpt__icontains=query, then=Value(50)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Activity score (combination of stars, forks, recent activity)
        activity_score=F('upvotes') + F('view_count') / 10 + F('comment_count') * 5,
        
        # Recency boost for active repositories
        recency_score=Case(
            When(updated_date__gte=timezone.now() - timedelta(days=30), then=Value(10)),
            When(updated_date__gte=timezone.now() - timedelta(days=90), then=Value(5)),
            default=Value(0),
            output_field=IntegerField()
        ),
        
        # Final GitHub-style ranking
        github_score=F('name_match') + F('description_match') + 
                    F('activity_score') / 10 + F('recency_score')
    ).order_by('-github_score', '-upvotes')
```

## ⚡ Search Performance Optimization

### 1. Database Indexes for Search

```python
# In your Django model
class ContentArticle(models.Model):
    title = models.CharField(max_length=300, db_index=True)  # Index for title searches
    content = models.TextField()
    author_name = models.CharField(max_length=100, db_index=True)  # Author searches
    category = models.CharField(max_length=100, db_index=True)  # Category filtering
    published_date = models.DateTimeField(db_index=True)  # Date range searches
    
    class Meta:
        # Composite indexes for common search patterns
        indexes = [
            models.Index(fields=['category', 'published_date']),  # Category + date
            models.Index(fields=['upvotes', 'published_date']),   # Popular recent
            models.Index(fields=['author_name', 'published_date']), # Author posts
        ]
        
        # PostgreSQL full-text search index
        # This would be created via migration:
        # CREATE INDEX article_search_idx ON content_articles USING GIN (to_tsvector('english', title || ' ' || content));
```

### 2. Search Result Caching

```python
from django.core.cache import cache
import hashlib

def cached_search(query, **filters):
    """Cache search results for performance"""
    
    # Create cache key from query and filters
    cache_data = f"{query}:{sorted(filters.items())}"
    cache_key = f"search:{hashlib.md5(cache_data.encode()).hexdigest()}"
    
    # Try to get from cache first
    cached_results = cache.get(cache_key)
    if cached_results:
        return cached_results
    
    # Perform search if not in cache
    results = advanced_search(query, **filters)[:50]  # Limit results
    
    # Cache for 5 minutes
    cache.set(cache_key, list(results), 300)
    
    return results
```

### 3. Search Analytics and Improvement

```python
class SearchAnalytics:
    @staticmethod
    def track_search(query, results_count, user_id=None):
        """Track search queries for analytics and improvement"""
        
        SearchLog.objects.create(
            query=query,
            results_count=results_count,
            user_id=user_id,
            timestamp=timezone.now()
        )
    
    @staticmethod
    def get_popular_searches(days=7):
        """Find most popular search terms"""
        
        cutoff_date = timezone.now() - timedelta(days=days)
        
        return SearchLog.objects.filter(
            timestamp__gte=cutoff_date
        ).values('query').annotate(
            search_count=Count('id'),
            avg_results=Avg('results_count')
        ).order_by('-search_count')[:20]
    
    @staticmethod
    def get_failed_searches(days=7, max_results=5):
        """Find searches that returned few or no results"""
        
        cutoff_date = timezone.now() - timedelta(days=days)
        
        return SearchLog.objects.filter(
            timestamp__gte=cutoff_date,
            results_count__lte=max_results
        ).values('query').annotate(
            failure_count=Count('id')
        ).order_by('-failure_count')[:20]
```

## 🎯 Key Takeaways

1. **Start simple with icontains** then add complexity as needed
2. **Q objects enable sophisticated boolean search logic**
3. **PostgreSQL full-text search** provides powerful, database-level search
4. **Ranking and scoring** improve search result quality
5. **Fuzzy search with trigrams** handles typos and variations
6. **Proper indexing is crucial** for search performance
7. **Caching frequent searches** dramatically improves response time

Django's search capabilities can scale from simple blog search to enterprise-level discovery engines!
''',
    "difficulty": "intermediate",
    "estimated_time": 45,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-aggregation"],
    "exercises": [
        {
            "id": "search_1",
            "title": "Explore Content Articles Table",
            "prompt": "Let's examine our rich content database. Write a query to see article titles, categories, and author information.",
            "table_name": "content_articles",
            "initial_query": "SELECT * FROM content_articles LIMIT 3;",
            "expected_keywords": ["SELECT", "*", "FROM", "content_articles"],
            "hint": "Use SELECT * FROM content_articles LIMIT 3; to explore the content structure",
            "solution": "SELECT * FROM content_articles LIMIT 3;",
            "explanation": "This shows our comprehensive content table with titles, content, author names, categories, tags, and engagement metrics. Django search will work across these fields to provide relevant results."
        },
        {
            "id": "search_2",
            "title": "Basic Content Search",
            "prompt": "Practice basic text search by finding articles that contain 'Django' in the title or content. Use LIKE with wildcards.",
            "table_name": "content_articles",
            "expected_keywords": ["SELECT", "WHERE", "LIKE", "Django", "OR"],
            "hint": "Use WHERE title LIKE '%Django%' OR content LIKE '%Django%'",
            "solution": "SELECT title, author_name, category FROM content_articles WHERE title LIKE '%Django%' OR content LIKE '%Django%';",
            "explanation": "This basic search simulates Django's icontains lookup: .filter(Q(title__icontains='Django') | Q(content__icontains='Django')). The LIKE operator with % wildcards provides case-sensitive substring matching."
        },
        {
            "id": "search_3", 
            "title": "Search by Category and Difficulty",
            "prompt": "Write a query to find articles in 'Web Development' or 'Programming' categories with 'intermediate' difficulty level.",
            "table_name": "content_articles",
            "expected_keywords": ["SELECT", "WHERE", "category", "difficulty_level", "IN", "AND"],
            "hint": "Use WHERE category IN (...) AND difficulty_level = 'intermediate'",
            "solution": "SELECT title, author_name, category, difficulty_level FROM content_articles WHERE category IN ('Web Development', 'Programming') AND difficulty_level = 'intermediate';",
            "explanation": "This demonstrates Django's field lookups with multiple conditions: .filter(category__in=['Web Development', 'Programming'], difficulty_level='intermediate'). Combining filters allows precise content discovery."
        },
        {
            "id": "search_4",
            "title": "Search with Popularity Ranking",
            "prompt": "Find articles containing 'python' and rank them by popularity (upvotes + view_count/100). Include title, upvotes, and view_count in results.",
            "table_name": "content_articles", 
            "expected_keywords": ["SELECT", "WHERE", "ORDER BY", "upvotes", "view_count"],
            "hint": "Calculate popularity score and order by it DESC",
            "solution": "SELECT title, upvotes, view_count, (upvotes + view_count/100) as popularity_score FROM content_articles WHERE title LIKE '%python%' OR content LIKE '%python%' ORDER BY popularity_score DESC;",
            "explanation": "This ranking system simulates Django's annotation with F expressions: .annotate(popularity=F('upvotes') + F('view_count')/100).order_by('-popularity'). Search ranking is crucial for showing the most relevant and popular content first."
        },
        {
            "id": "search_5",
            "title": "Author and Expertise Search",
            "prompt": "Search for content by authors who have expertise in 'python' or 'django'. Join the content_articles and user_profiles tables.",
            "table_name": "content_articles",
            "expected_keywords": ["SELECT", "JOIN", "WHERE", "expertise_areas", "LIKE"],
            "hint": "JOIN user_profiles and search in the expertise_areas field",
            "solution": "SELECT ca.title, up.full_name, up.expertise_areas FROM content_articles ca JOIN user_profiles up ON ca.author_id = up.id WHERE up.expertise_areas::text LIKE '%python%' OR up.expertise_areas::text LIKE '%django%';",
            "explanation": "This cross-table search demonstrates Django's select_related() for JOINs and searching in array fields. Finding content by author expertise is common in technical platforms like Stack Overflow and Medium."
        },
        {
            "id": "search_6",
            "title": "Recent High-Quality Content Search",
            "prompt": "Find high-quality recent articles: published in December 2024, with upvotes > 200, and reading time between 15-40 minutes. Order by upvotes DESC.",
            "table_name": "content_articles",
            "expected_keywords": ["SELECT", "WHERE", "published_date", "upvotes", "reading_time", "BETWEEN"],
            "hint": "Combine date, upvotes, and reading_time filters with AND",
            "solution": "SELECT title, author_name, upvotes, reading_time, published_date FROM content_articles WHERE published_date >= '2024-12-01' AND published_date < '2025-01-01' AND upvotes > 200 AND reading_time BETWEEN 15 AND 40 ORDER BY upvotes DESC;",
            "explanation": "This multi-criteria search demonstrates Django's complex filtering: .filter(published_date__gte=date, upvotes__gt=200, reading_time__range=[15,40]). Quality content discovery requires multiple relevance signals beyond just text matching."
        }
    ],
    "key_concepts": [
        "Basic Text Search with Q Objects",
        "Advanced Boolean Search Logic", 
        "PostgreSQL Full-Text Search",
        "Search Ranking and Scoring Algorithms",
        "Trigram Similarity for Fuzzy Search",
        "Search Performance Optimization",
        "Search Result Caching Strategies",
        "Search Analytics and Improvement"
    ]
}