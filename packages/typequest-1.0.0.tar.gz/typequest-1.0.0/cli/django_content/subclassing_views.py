"""
Django Subclassing Generic Views lesson content
"""

DJANGO_SUBCLASSING_LESSON = {
    "id": 14,
    "chapter": 14,
    "title": "Subclassing Generic Views",
    "slug": "subclassing-generic-views",
    "content": '''
# Subclassing Generic Views: Customizing Your Perfect View

Think of Django's generic views as high-quality power tools. They work great out of the box, but the real magic happens when you customize them for your specific needs. Subclassing is like adding custom attachments to make these tools perfect for your unique projects.

## Why Subclass Generic Views? Beyond Basic CRUD

While generic views handle common patterns beautifully, real applications have unique requirements:
- Custom business logic
- Special authentication rules
- Complex data relationships
- Performance optimizations
- Integration with external services

**Car analogy:** Generic views are like buying a reliable sedan. Subclassing is like customizing it with better wheels, upgraded sound system, and custom paint - keeping the solid foundation while making it uniquely yours.

## Understanding the View Hierarchy: Your Inheritance Tree

Django's view classes form a family tree where each child inherits capabilities from its parents:

```
View (Base class - handles HTTP dispatch)
├── TemplateView (Renders templates)
├── RedirectView (Handles redirects)
└── GenericView (Database integration)
    ├── DetailView (Single object display)
    ├── ListView (Multiple objects display)
    ├── CreateView (Object creation)
    ├── UpdateView (Object editing)
    ├── DeleteView (Object deletion)
    └── FormView (Form handling)
```

**When you subclass, you inherit ALL the parent's capabilities and can override specific behaviors.**

## Subclassing Strategy: The Method Override Pattern

The key to successful subclassing is understanding which methods to override for different customizations:

### Common Override Points
```python
class CustomBookListView(ListView):
    model = Book
    
    def get_queryset(self):
        """Override to change what objects are displayed"""
        return super().get_queryset().filter(is_published=True)
    
    def get_context_data(self, **kwargs):
        """Override to add extra template context"""
        context = super().get_context_data(**kwargs)
        context['featured_books'] = Book.objects.filter(is_featured=True)[:3]
        return context
    
    def dispatch(self, request, *args, **kwargs):
        """Override to add logic before view processing"""
        if not request.user.is_authenticated:
            return redirect('login')
        return super().dispatch(request, *args, **kwargs)
```

## ListView Customization: Master of Collections

ListView is perfect for displaying collections, but real applications need sophisticated filtering, sorting, and presentation.

### Advanced Filtering and Search
```python
from django.db.models import Q

class AdvancedBookListView(ListView):
    model = Book
    template_name = 'books/advanced_list.html'
    context_object_name = 'books'
    paginate_by = 20
    
    def get_queryset(self):
        """Complex filtering based on user input and preferences"""
        queryset = Book.objects.select_related('author').prefetch_related('categories')
        
        # Search functionality
        search_query = self.request.GET.get('q')
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query) |
                Q(author__name__icontains=search_query) |
                Q(description__icontains=search_query)
            )
        
        # Category filtering
        category = self.request.GET.get('category')
        if category:
            queryset = queryset.filter(categories__slug=category)
        
        # User preference filtering
        if self.request.user.is_authenticated:
            user_profile = self.request.user.profile
            if user_profile.hide_adult_content:
                queryset = queryset.exclude(content_rating='adult')
        
        # Sorting
        sort_by = self.request.GET.get('sort', 'publication_date')
        if sort_by in ['title', 'publication_date', 'rating']:
            if self.request.GET.get('order') == 'desc':
                sort_by = f'-{sort_by}'
            queryset = queryset.order_by(sort_by)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Add filtering and sorting context"""
        context = super().get_context_data(**kwargs)
        
        # Add filter options to template
        context['categories'] = Category.objects.all()
        context['current_category'] = self.request.GET.get('category', '')
        context['current_search'] = self.request.GET.get('q', '')
        context['current_sort'] = self.request.GET.get('sort', 'publication_date')
        context['current_order'] = self.request.GET.get('order', 'asc')
        
        # Add statistics
        context['total_books'] = self.get_queryset().count()
        context['categories_count'] = Category.objects.annotate(
            book_count=Count('books')
        ).order_by('-book_count')
        
        return context
```

**Template usage:**
```html
<!-- books/advanced_list.html -->
<div class="search-filters">
    <form method="get" class="filter-form">
        <input type="text" name="q" value="{{ current_search }}" placeholder="Search books...">
        
        <select name="category">
            <option value="">All Categories</option>
            {% for category in categories %}
                <option value="{{ category.slug }}" 
                    {% if category.slug == current_category %}selected{% endif %}>
                    {{ category.name }}
                </option>
            {% endfor %}
        </select>
        
        <select name="sort">
            <option value="publication_date" {% if current_sort == 'publication_date' %}selected{% endif %}>
                Publication Date
            </option>
            <option value="title" {% if current_sort == 'title' %}selected{% endif %}>
                Title
            </option>
            <option value="rating" {% if current_sort == 'rating' %}selected{% endif %}>
                Rating
            </option>
        </select>
        
        <button type="submit">Filter</button>
    </form>
</div>

<div class="results-info">
    <p>Found {{ total_books }} books</p>
</div>
```

### Multi-Model ListView: Combining Different Data
```python
class DashboardView(TemplateView):
    """Custom view combining data from multiple models"""
    template_name = 'dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Combine data from different models
        context['recent_books'] = Book.objects.select_related('author').order_by(
            '-created_at'
        )[:5]
        
        context['popular_authors'] = Author.objects.annotate(
            book_count=Count('books'),
            avg_rating=Avg('books__rating')
        ).filter(book_count__gte=3).order_by('-avg_rating')[:10]
        
        context['upcoming_releases'] = Book.objects.filter(
            publication_date__gte=timezone.now()
        ).order_by('publication_date')[:5]
        
        # User-specific data
        if self.request.user.is_authenticated:
            context['user_favorites'] = self.request.user.favorite_books.all()[:5]
            context['reading_progress'] = ReadingProgress.objects.filter(
                user=self.request.user,
                is_completed=False
            )[:3]
        
        # Statistics
        context['stats'] = {
            'total_books': Book.objects.count(),
            'total_authors': Author.objects.count(),
            'books_this_month': Book.objects.filter(
                created_at__month=timezone.now().month
            ).count()
        }
        
        return context
```

## DetailView Customization: Deep Object Exploration

DetailView shows individual objects, but custom subclasses can add related data, user interactions, and complex business logic.

### Enhanced DetailView with Related Data
```python
class ComprehensiveBookDetailView(DetailView):
    model = Book
    template_name = 'books/comprehensive_detail.html'
    context_object_name = 'book'
    
    def get_queryset(self):
        """Optimize database queries"""
        return Book.objects.select_related(
            'author', 'publisher'
        ).prefetch_related(
            'categories', 'reviews__user', 'tags'
        )
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Related books by same author
        context['related_books'] = Book.objects.filter(
            author=book.author
        ).exclude(pk=book.pk).order_by('-rating')[:5]
        
        # Similar books by category
        context['similar_books'] = Book.objects.filter(
            categories__in=book.categories.all()
        ).exclude(pk=book.pk).distinct().order_by('-rating')[:5]
        
        # Reviews with pagination
        reviews = book.reviews.filter(is_approved=True).order_by('-created_at')
        paginator = Paginator(reviews, 10)
        page = self.request.GET.get('review_page')
        context['reviews'] = paginator.get_page(page)
        
        # User-specific context
        if self.request.user.is_authenticated:
            context['user_review'] = book.reviews.filter(
                user=self.request.user
            ).first()
            context['is_favorited'] = book in self.request.user.favorite_books.all()
            context['reading_progress'] = ReadingProgress.objects.filter(
                user=self.request.user, book=book
            ).first()
        
        # Analytics
        context['view_count'] = book.view_count
        context['average_rating'] = book.reviews.aggregate(
            avg=Avg('rating')
        )['avg'] or 0
        
        return context
    
    def get(self, request, *args, **kwargs):
        """Track page views"""
        response = super().get(request, *args, **kwargs)
        
        # Increment view count (avoid counting author's own views)
        book = self.get_object()
        if request.user != book.author:
            Book.objects.filter(pk=book.pk).update(
                view_count=F('view_count') + 1
            )
        
        return response
```

## CreateView Customization: Smart Object Creation

CreateView handles object creation, but custom subclasses can add validation, workflow integration, and user experience enhancements.

### Advanced CreateView with Workflow
```python
class SmartBookCreateView(LoginRequiredMixin, CreateView):
    model = Book
    form_class = BookForm
    template_name = 'books/smart_create.html'
    
    def get_form_kwargs(self):
        """Pass additional data to form"""
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs
    
    def form_valid(self, form):
        """Custom logic before saving"""
        book = form.save(commit=False)
        
        # Auto-assign author
        book.author = self.request.user
        
        # Generate unique slug
        book.slug = self.generate_unique_slug(book.title)
        
        # Set initial status based on user type
        if self.request.user.is_staff:
            book.status = 'published'
        else:
            book.status = 'pending_review'
        
        book.save()
        form.save_m2m()  # Save many-to-many relationships
        
        # Send notifications
        if book.status == 'pending_review':
            self.notify_moderators(book)
        
        # Track analytics
        self.track_book_creation(book)
        
        messages.success(
            self.request,
            f'Book "{book.title}" has been {"published" if book.status == "published" else "submitted for review"}!'
        )
        
        return super().form_valid(form)
    
    def generate_unique_slug(self, title):
        """Create a unique slug for the book"""
        base_slug = slugify(title)
        slug = base_slug
        counter = 1
        
        while Book.objects.filter(slug=slug).exists():
            slug = f"{base_slug}-{counter}"
            counter += 1
        
        return slug
    
    def notify_moderators(self, book):
        """Send email to moderators for review"""
        moderators = User.objects.filter(groups__name='Moderators')
        for moderator in moderators:
            send_mail(
                subject=f'New book submission: {book.title}',
                message=f'A new book "{book.title}" by {book.author.username} needs review.',
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[moderator.email]
            )
    
    def track_book_creation(self, book):
        """Track analytics"""
        AnalyticsEvent.objects.create(
            event_type='book_created',
            user=self.request.user,
            object_id=book.pk,
            metadata={
                'book_title': book.title,
                'categories': [cat.name for cat in book.categories.all()]
            }
        )
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = 'Add New Book'
        context['user_books_count'] = Book.objects.filter(
            author=self.request.user
        ).count()
        return context
```

### Custom Form Integration
```python
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'description', 'categories', 'cover_image']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter book title...'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Describe your book...'
            }),
            'categories': forms.CheckboxSelectMultiple(),
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Customize form based on user
        if self.user and not self.user.is_staff:
            # Limit categories for regular users
            self.fields['categories'].queryset = Category.objects.filter(
                is_user_selectable=True
            )
    
    def clean_title(self):
        title = self.cleaned_data['title']
        
        # Check for duplicate titles by same author
        if self.user and Book.objects.filter(
            title=title, author=self.user
        ).exists():
            raise forms.ValidationError(
                "You already have a book with this title."
            )
        
        return title
```

## UpdateView Customization: Intelligent Editing

UpdateView handles object editing with sophisticated permission checking, change tracking, and workflow integration.

### Secure UpdateView with Change Tracking
```python
class SecureBookUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Book
    form_class = BookUpdateForm
    template_name = 'books/secure_update.html'
    
    def test_func(self):
        """Complex permission logic"""
        book = self.get_object()
        user = self.request.user
        
        # Authors can edit their own books
        if user == book.author:
            return True
        
        # Editors can edit books in their assigned categories
        if user.groups.filter(name='Editors').exists():
            user_categories = user.editor_profile.assigned_categories.all()
            book_categories = book.categories.all()
            return any(cat in user_categories for cat in book_categories)
        
        # Admins can edit everything
        return user.is_superuser
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        kwargs['original_instance'] = self.get_object()
        return kwargs
    
    def form_valid(self, form):
        """Track changes and handle workflow"""
        old_book = self.get_object()
        
        # Track what changed
        changed_fields = []
        for field_name in form.changed_data:
            old_value = getattr(old_book, field_name)
            new_value = form.cleaned_data[field_name]
            changed_fields.append({
                'field': field_name,
                'old_value': str(old_value),
                'new_value': str(new_value)
            })
        
        # Save the book
        response = super().form_valid(form)
        
        # Log the changes
        if changed_fields:
            BookChangeLog.objects.create(
                book=self.object,
                user=self.request.user,
                changes=changed_fields,
                timestamp=timezone.now()
            )
        
        # Workflow logic
        if 'status' in form.changed_data:
            self.handle_status_change(old_book.status, self.object.status)
        
        messages.success(
            self.request,
            f'Book "{self.object.title}" has been updated successfully.'
        )
        
        return response
    
    def handle_status_change(self, old_status, new_status):
        """Handle workflow state changes"""
        if old_status == 'draft' and new_status == 'published':
            # Notify followers
            self.notify_book_published()
        elif old_status == 'published' and new_status == 'archived':
            # Handle archival
            self.handle_book_archived()
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Add change history
        context['change_history'] = BookChangeLog.objects.filter(
            book=book
        ).order_by('-timestamp')[:10]
        
        # Add permission context
        context['can_publish'] = self.request.user.has_perm('books.publish_book')
        context['is_author'] = self.request.user == book.author
        
        return context
```

## Combining Multiple Patterns: The Ultimate Custom View

```python
class UltimateBookManagementView(
    LoginRequiredMixin,
    UserPassesTestMixin,
    SuccessMessageMixin,
    ListView
):
    """A comprehensive view combining multiple patterns"""
    model = Book
    template_name = 'books/ultimate_management.html'
    context_object_name = 'books'
    paginate_by = 25
    success_message = "Operation completed successfully!"
    
    # Multiple inheritance capabilities
    def test_func(self):
        """Only allow book managers"""
        return self.request.user.groups.filter(
            name__in=['Editors', 'Authors', 'Administrators']
        ).exists()
    
    def get_queryset(self):
        """Smart filtering based on user role"""
        user = self.request.user
        queryset = Book.objects.select_related('author').prefetch_related('categories')
        
        if user.groups.filter(name='Authors').exists():
            # Authors see only their books
            queryset = queryset.filter(author=user)
        elif user.groups.filter(name='Editors').exists():
            # Editors see books in their categories
            editor_categories = user.editor_profile.assigned_categories.all()
            queryset = queryset.filter(categories__in=editor_categories)
        # Administrators see everything (no additional filtering)
        
        return queryset.distinct()
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Add role-specific data
        user = self.request.user
        context['user_role'] = self.get_user_role(user)
        context['management_stats'] = self.get_management_stats(user)
        context['available_actions'] = self.get_available_actions(user)
        
        return context
    
    def get_user_role(self, user):
        """Determine user's primary role"""
        if user.is_superuser:
            return 'administrator'
        elif user.groups.filter(name='Editors').exists():
            return 'editor'
        elif user.groups.filter(name='Authors').exists():
            return 'author'
        return 'user'
    
    def post(self, request, *args, **kwargs):
        """Handle bulk operations"""
        action = request.POST.get('action')
        book_ids = request.POST.getlist('book_ids')
        
        if action and book_ids:
            books = self.get_queryset().filter(id__in=book_ids)
            
            if action == 'bulk_publish':
                books.update(status='published')
                messages.success(request, f'{books.count()} books published.')
            elif action == 'bulk_archive':
                books.update(status='archived')
                messages.success(request, f'{books.count()} books archived.')
            elif action == 'bulk_delete':
                count = books.count()
                books.delete()
                messages.success(request, f'{count} books deleted.')
        
        return redirect(request.get_full_path())
```

## Testing Custom Views

```python
from django.test import TestCase, Client
from django.contrib.auth.models import User, Group
from django.urls import reverse

class CustomViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('testuser', 'test@example.com', 'pass')
        self.author_group = Group.objects.create(name='Authors')
        self.user.groups.add(self.author_group)
        self.client = Client()
    
    def test_advanced_book_list_search(self):
        """Test search functionality"""
        Book.objects.create(title='Python Programming', author=self.user)
        Book.objects.create(title='Django Web Development', author=self.user)
        
        self.client.login(username='testuser', password='pass')
        response = self.client.get(reverse('books:advanced-list'), {'q': 'Python'})
        
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Python Programming')
        self.assertNotContains(response, 'Django Web Development')
    
    def test_permission_checking(self):
        """Test custom permission logic"""
        other_user = User.objects.create_user('other', 'other@example.com', 'pass')
        book = Book.objects.create(title='Test Book', author=other_user)
        
        self.client.login(username='testuser', password='pass')
        response = self.client.get(reverse('books:edit', kwargs={'pk': book.pk}))
        
        # Should be forbidden - user can't edit other's books
        self.assertEqual(response.status_code, 403)
```

## Performance Optimization in Custom Views

```python
class OptimizedBookListView(ListView):
    model = Book
    
    def get_queryset(self):
        """Highly optimized queryset"""
        return Book.objects.select_related(
            'author', 'publisher'
        ).prefetch_related(
            'categories', 
            Prefetch('reviews', queryset=Review.objects.filter(is_approved=True))
        ).annotate(
            review_count=Count('reviews', filter=Q(reviews__is_approved=True)),
            avg_rating=Avg('reviews__rating', filter=Q(reviews__is_approved=True))
        ).order_by('-created_at')
    
    @method_decorator(cache_page(60 * 15))  # Cache for 15 minutes
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
```

Subclassing generic views unlocks the full power of Django's view system. You get the reliability of battle-tested code with the flexibility to implement any business logic your application requires!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/#subclassing-generic-views
    ''',
    "is_free": False,
    "xp_reward": 85,
    "exercises": [
        {
            "id": "advanced-subclassing-system",
            "title": "Build Advanced View Subclassing System",
            "type": "project",
            "instructions": """Create a comprehensive content management system using advanced view subclassing:

1. Custom ListView with search, filtering, and pagination
2. Enhanced DetailView with related data and user interactions  
3. Workflow-enabled CreateView with notifications
4. Permission-aware UpdateView with change tracking
5. Role-based access control across all views

Your solution should demonstrate:
- Complex queryset customization in get_queryset()
- Rich context data in get_context_data()
- Custom form handling in form_valid()
- Permission checking with test_func()
- Performance optimization techniques""",
            "starter_code": """# models.py (provided)
class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)
    view_count = models.PositiveIntegerField(default=0)
    
class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)

class PostChangeLog(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    changes = models.JSONField()
    timestamp = models.DateTimeField(auto_now_add=True)

# Implement advanced custom views below:""",
            "solution": """from django.views.generic import ListView, DetailView, CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.db.models import Q, Count, Avg, F
from django.contrib import messages
from django.utils import timezone
from django.core.paginator import Paginator

class AdvancedPostListView(ListView):
    model = Post
    template_name = 'posts/advanced_list.html'
    context_object_name = 'posts'
    paginate_by = 15
    
    def get_queryset(self):
        \"\"\"Complex filtering and search\"\"\"
        queryset = Post.objects.select_related('author').prefetch_related('categories')
        
        # Search functionality
        search_query = self.request.GET.get('q')
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query) |
                Q(content__icontains=search_query) |
                Q(author__username__icontains=search_query)
            )
        
        # Status filtering
        status = self.request.GET.get('status')
        if status and status in ['draft', 'published', 'archived']:
            queryset = queryset.filter(status=status)
        
        # User-specific filtering
        if self.request.user.is_authenticated:
            if self.request.GET.get('my_posts'):
                queryset = queryset.filter(author=self.request.user)
        
        # Sorting
        sort_by = self.request.GET.get('sort', '-created_at')
        if sort_by in ['title', '-title', 'created_at', '-created_at', 'view_count', '-view_count']:
            queryset = queryset.order_by(sort_by)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Add filter context
        context['current_search'] = self.request.GET.get('q', '')
        context['current_status'] = self.request.GET.get('status', '')
        context['current_sort'] = self.request.GET.get('sort', '-created_at')
        context['show_my_posts'] = self.request.GET.get('my_posts', False)
        
        # Add statistics
        context['total_posts'] = self.get_queryset().count()
        context['status_counts'] = Post.objects.values('status').annotate(
            count=Count('id')
        ).order_by('status')
        
        return context

class EnhancedPostDetailView(DetailView):
    model = Post
    template_name = 'posts/enhanced_detail.html'
    context_object_name = 'post'
    
    def get_queryset(self):
        return Post.objects.select_related('author').prefetch_related('categories')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = self.get_object()
        
        # Related posts
        context['related_posts'] = Post.objects.filter(
            categories__in=post.categories.all()
        ).exclude(pk=post.pk).distinct()[:5]
        
        # Author's other posts
        context['author_posts'] = Post.objects.filter(
            author=post.author
        ).exclude(pk=post.pk).order_by('-created_at')[:5]
        
        # Change history for authorized users
        if self.request.user.is_staff or self.request.user == post.author:
            context['change_history'] = PostChangeLog.objects.filter(
                post=post
            ).select_related('user').order_by('-timestamp')[:10]
        
        return context
    
    def get(self, request, *args, **kwargs):
        \"\"\"Track view count\"\"\"
        response = super().get(request, *args, **kwargs)
        
        # Increment view count (avoid counting author's views)
        post = self.get_object()
        if request.user != post.author:
            Post.objects.filter(pk=post.pk).update(
                view_count=F('view_count') + 1
            )
        
        return response

class WorkflowPostCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Post
    fields = ['title', 'content', 'categories']
    template_name = 'posts/workflow_create.html'
    success_message = \"Post '%(title)s' has been created successfully!\"
    
    def form_valid(self, form):
        \"\"\"Add workflow logic\"\"\"
        post = form.save(commit=False)
        post.author = self.request.user
        
        # Set status based on user permissions
        if self.request.user.has_perm('posts.can_publish'):
            post.status = 'published'
        else:
            post.status = 'draft'
        
        post.save()
        form.save_m2m()
        
        # Send notifications if published
        if post.status == 'published':
            self.send_publication_notifications(post)
        
        # Track creation
        self.track_post_creation(post)
        
        return super().form_valid(form)
    
    def send_publication_notifications(self, post):
        \"\"\"Notify followers about new post\"\"\"
        # Implementation would send emails/notifications
        pass
    
    def track_post_creation(self, post):
        \"\"\"Track analytics\"\"\"
        # Implementation would log analytics
        pass

class PermissionAwarePostUpdateView(
    LoginRequiredMixin, 
    UserPassesTestMixin, 
    SuccessMessageMixin,
    UpdateView
):
    model = Post
    fields = ['title', 'content', 'categories', 'status']
    template_name = 'posts/permission_update.html'
    success_message = \"Post updated successfully!\"
    
    def test_func(self):
        \"\"\"Complex permission checking\"\"\"
        post = self.get_object()
        user = self.request.user
        
        # Authors can edit their own posts
        if user == post.author:
            return True
        
        # Editors can edit posts in their categories
        if user.has_perm('posts.change_post'):
            return True
        
        # Staff can edit published posts
        if user.is_staff and post.status == 'published':
            return True
        
        return False
    
    def get_form(self, form_class=None):
        \"\"\"Customize form based on permissions\"\"\"
        form = super().get_form(form_class)
        
        # Regular authors can't change status
        if not self.request.user.has_perm('posts.can_publish'):
            if 'status' in form.fields:
                del form.fields['status']
        
        return form
    
    def form_valid(self, form):
        \"\"\"Track changes\"\"\"
        old_post = self.get_object()
        
        # Track what changed
        changed_fields = []
        for field_name in form.changed_data:
            old_value = getattr(old_post, field_name)
            new_value = form.cleaned_data[field_name]
            changed_fields.append({
                'field': field_name,
                'old_value': str(old_value),
                'new_value': str(new_value)
            })
        
        response = super().form_valid(form)
        
        # Log changes
        if changed_fields:
            PostChangeLog.objects.create(
                post=self.object,
                user=self.request.user,
                changes=changed_fields,
                timestamp=timezone.now()
            )
        
        return response
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = self.get_object()
        
        # Add permission context
        context['can_change_status'] = self.request.user.has_perm('posts.can_publish')
        context['is_author'] = self.request.user == post.author
        
        # Add change history
        context['recent_changes'] = PostChangeLog.objects.filter(
            post=post
        ).select_related('user').order_by('-timestamp')[:5]
        
        return context

class RoleBasedPostManagementView(
    LoginRequiredMixin,
    UserPassesTestMixin,
    ListView
):
    model = Post
    template_name = 'posts/role_management.html'
    context_object_name = 'posts'
    paginate_by = 20
    
    def test_func(self):
        \"\"\"Only allow users with management permissions\"\"\"
        return (
            self.request.user.has_perm('posts.view_post') or
            self.request.user.is_staff
        )
    
    def get_queryset(self):
        \"\"\"Filter based on user role\"\"\"
        user = self.request.user
        queryset = Post.objects.select_related('author')
        
        if user.is_superuser:
            # Superusers see everything
            return queryset.order_by('-created_at')
        elif user.has_perm('posts.change_post'):
            # Editors see posts they can modify
            return queryset.filter(
                Q(author=user) | Q(status='published')
            ).order_by('-created_at')
        else:
            # Regular users see only their own posts
            return queryset.filter(author=user).order_by('-created_at')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Add role-specific context
        context['user_role'] = self.get_user_role()
        context['management_stats'] = self.get_management_stats()
        
        return context
    
    def get_user_role(self):
        \"\"\"Determine user's role\"\"\"
        user = self.request.user
        if user.is_superuser:
            return 'admin'
        elif user.has_perm('posts.change_post'):
            return 'editor'
        else:
            return 'author'
    
    def get_management_stats(self):
        \"\"\"Get role-appropriate statistics\"\"\"
        queryset = self.get_queryset()
        
        return {
            'total_posts': queryset.count(),
            'draft_posts': queryset.filter(status='draft').count(),
            'published_posts': queryset.filter(status='published').count(),
            'archived_posts': queryset.filter(status='archived').count(),
        }""",
            "test_cases": [
                {
                    "name": "Views properly override key methods",
                    "input": "",
                    "expected_contains": ["get_queryset", "get_context_data", "form_valid", "test_func"]
                }
            ],
            "xp_reward": 120,
            "hints": [
                "Always call super() when overriding methods",
                "Use select_related and prefetch_related for performance",
                "Implement comprehensive permission checking in test_func()",
                "Track changes by comparing form.changed_data",
                "Add role-specific context for flexible templates"
            ]
        }
    ]
}