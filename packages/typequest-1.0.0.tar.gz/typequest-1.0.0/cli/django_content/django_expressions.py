"""
Django Advanced - Lesson 1: Query Expressions and F Objects
Master Django's query expressions for powerful database-level computations
"""

DJANGO_EXPRESSIONS_LESSON = {
    "id": 51,
    "chapter": 51,
    "title": "Django Query Expressions: F Objects and Advanced Computations",
    "slug": "django-expressions",
    "description": "Master Django query expressions for complex database computations and field references",
    "content": '''# Django Query Expressions: F Objects and Advanced Computations

## 🎯 Understanding Query Expressions

Django **Query Expressions** enable complex database-level computations without pulling data into Python memory. They're the foundation for high-performance Django applications that can scale to millions of records.

**Key Benefits**:
- **Database-level computations** → Much faster than Python loops
- **Avoid race conditions** → Atomic operations prevent data corruption
- **Memory efficient** → No need to load records into Python
- **SQL optimization** → Database engine handles complex operations

Think of expressions as your **direct pipeline to SQL power** within Django's ORM.

## 💾 E-commerce Platform Database

Let's work with a comprehensive e-commerce database to demonstrate expressions:

```sql
-- Product catalog with pricing and inventory
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2) NOT NULL,
    stock_quantity INTEGER DEFAULT 0,
    reserved_quantity INTEGER DEFAULT 0,
    min_stock_level INTEGER DEFAULT 5,
    weight_grams INTEGER,
    rating_sum INTEGER DEFAULT 0,
    rating_count INTEGER DEFAULT 0,
    view_count INTEGER DEFAULT 0,
    sales_count INTEGER DEFAULT 0,
    discount_percentage DECIMAL(5, 2) DEFAULT 0.00,
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample product data for expressions
INSERT INTO products (name, price, cost_price, stock_quantity, weight_grams, rating_sum, rating_count, view_count, sales_count, discount_percentage) VALUES
('iPhone 15 Pro Max', 1199.99, 800.00, 45, 221, 4320, 900, 15420, 2847, 5.00),
('MacBook Pro 16"', 2499.99, 1800.00, 12, 2140, 4851, 990, 8934, 567, 10.00),
('AirPods Pro 2nd Gen', 249.99, 150.00, 150, 56, 4465, 950, 23651, 8924, 0.00),
('Samsung Galaxy S24', 899.99, 600.00, 78, 168, 4140, 900, 12456, 3421, 8.00),
('Sony WH-1000XM5', 399.99, 250.00, 25, 250, 4560, 950, 9876, 5672, 15.00),
('Nintendo Switch OLED', 349.99, 200.00, 0, 420, 4230, 900, 7654, 12453, 0.00),
('Tesla Model Y Key Fob', 175.00, 80.00, 200, 85, 3960, 880, 3210, 892, 5.00),
('iPad Air 5th Gen', 599.99, 380.00, 30, 461, 4275, 950, 11234, 2834, 12.00);

-- Order items for sales analytics
CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    customer_id INTEGER NOT NULL,
    discount_applied DECIMAL(10, 2) DEFAULT 0.00,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sample order data
INSERT INTO order_items (product_id, quantity, unit_price, total_price, customer_id, discount_applied) VALUES
(1, 1, 1199.99, 1199.99, 1001, 60.00),
(2, 1, 2499.99, 2499.99, 1002, 250.00),
(3, 2, 249.99, 499.98, 1003, 0.00),
(4, 1, 899.99, 899.99, 1004, 72.00),
(5, 1, 399.99, 399.99, 1005, 60.00),
(7, 3, 175.00, 525.00, 1006, 26.25),
(8, 1, 599.99, 599.99, 1007, 72.00);

-- Customer accounts for balance operations
CREATE TABLE customer_accounts (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER UNIQUE NOT NULL,
    account_balance DECIMAL(10, 2) DEFAULT 0.00,
    reward_points INTEGER DEFAULT 0,
    total_spent DECIMAL(10, 2) DEFAULT 0.00,
    order_count INTEGER DEFAULT 0,
    last_purchase_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample customer accounts
INSERT INTO customer_accounts (customer_id, account_balance, reward_points, total_spent, order_count) VALUES
(1001, 250.00, 1200, 1199.99, 1),
(1002, 500.00, 2500, 2499.99, 1),
(1003, 100.00, 500, 499.98, 1),
(1004, 150.00, 900, 899.99, 1),
(1005, 75.00, 400, 399.99, 1),
(1006, 300.00, 525, 525.00, 1),
(1007, 200.00, 600, 599.99, 1);

-- Reviews table for rating calculations
CREATE TABLE product_reviews (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL,
    customer_id INTEGER NOT NULL,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    helpful_votes INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sample reviews
INSERT INTO product_reviews (product_id, customer_id, rating, helpful_votes) VALUES
(1, 1001, 5, 45), (1, 1002, 4, 23), (1, 1003, 5, 67),
(2, 1004, 5, 89), (2, 1005, 4, 34), 
(3, 1006, 5, 156), (3, 1007, 5, 234), (3, 1001, 4, 89),
(4, 1002, 4, 45), (4, 1003, 5, 67),
(5, 1004, 5, 123), (5, 1005, 4, 56);
```

## 🔧 F() Expressions - Field References

### 1. Basic Field References

**Scenario**: Amazon's inventory management without race conditions

```python
from django.db.models import F

class InventoryService:
    @staticmethod
    def process_order(product_id, quantity):
        """Safely update inventory using F expressions"""
        
        # Atomic update without race conditions
        Product.objects.filter(id=product_id).update(
            stock_quantity=F('stock_quantity') - quantity,
            reserved_quantity=F('reserved_quantity') + quantity,
            sales_count=F('sales_count') + quantity
        )
        
        # This is safer than:
        # product = Product.objects.get(id=product_id)
        # product.stock_quantity -= quantity  # Race condition risk!
        # product.save()

    @staticmethod
    def restock_product(product_id, new_stock):
        """Add stock and update availability"""
        
        Product.objects.filter(id=product_id).update(
            stock_quantity=F('stock_quantity') + new_stock,
            # Update availability status based on stock levels
            is_available=Case(
                When(stock_quantity__gt=F('min_stock_level'), then=True),
                default=False
            )
        )
```

### 2. Arithmetic Operations with F()

**Scenario**: Shopify's dynamic pricing calculations

```python
class PricingService:
    @staticmethod
    def apply_bulk_discount(category, discount_percent):
        """Apply percentage discount to all products in category"""
        
        Product.objects.filter(category=category).update(
            # Calculate discounted price
            discounted_price=F('price') * (100 - discount_percent) / 100,
            
            # Update discount tracking
            discount_percentage=discount_percent,
            
            # Calculate profit margin after discount
            profit_margin=(F('discounted_price') - F('cost_price')) / F('discounted_price') * 100
        )
    
    @staticmethod
    def calculate_shipping_costs():
        """Calculate shipping based on weight and price"""
        
        return Product.objects.annotate(
            # Base shipping calculation
            base_shipping=Case(
                When(weight_grams__lt=100, then=Value(5.99)),
                When(weight_grams__lt=500, then=Value(9.99)),
                When(weight_grams__lt=1000, then=Value(15.99)),
                default=Value(25.99)
            ),
            
            # Free shipping threshold
            final_shipping=Case(
                When(price__gte=50, then=Value(0.00)),
                default=F('base_shipping')
            ),
            
            # Total cost with shipping
            total_cost=F('price') + F('final_shipping')
        )
```

### 3. Cross-Field Comparisons

**Scenario**: Netflix's content recommendation scoring

```python
def get_business_insights():
    """Analyze product performance with F expressions"""
    
    insights = Product.objects.annotate(
        # Calculate average rating
        average_rating=Case(
            When(rating_count__gt=0, then=F('rating_sum') / F('rating_count')),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Profit per unit
        unit_profit=F('price') - F('cost_price'),
        
        # Profit margin percentage
        profit_margin_percent=Case(
            When(price__gt=0, then=(F('price') - F('cost_price')) / F('price') * 100),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Inventory turnover efficiency
        inventory_efficiency=Case(
            When(stock_quantity__gt=0, then=F('sales_count') / F('stock_quantity')),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Low stock alert
        needs_restock=Case(
            When(stock_quantity__lte=F('min_stock_level'), then=True),
            default=False
        ),
        
        # Conversion rate (sales per view)
        conversion_rate=Case(
            When(view_count__gt=0, then=F('sales_count') / F('view_count') * 100),
            default=0.0,
            output_field=FloatField()
        )
    ).filter(
        # Only profitable products
        unit_profit__gt=0
    ).order_by('-profit_margin_percent')
    
    return insights
```

## 📊 Advanced F() Expression Patterns

### 4. Conditional Updates with F()

**Scenario**: Stripe's account balance management

```python
class AccountService:
    @staticmethod
    def process_payment(customer_id, amount):
        """Process payment with balance updates"""
        
        CustomerAccount.objects.filter(customer_id=customer_id).update(
            # Deduct payment amount
            account_balance=F('account_balance') - amount,
            
            # Update spending totals
            total_spent=F('total_spent') + amount,
            
            # Increment order count
            order_count=F('order_count') + 1,
            
            # Award reward points (1 point per dollar)
            reward_points=F('reward_points') + Cast(amount, IntegerField()),
            
            # Update last purchase date
            last_purchase_date=timezone.now()
        )
    
    @staticmethod
    def apply_loyalty_bonus():
        """Give bonus points to high-value customers"""
        
        CustomerAccount.objects.filter(
            total_spent__gte=1000
        ).update(
            # Bonus: 10% of total spent as extra points
            reward_points=F('reward_points') + Cast(F('total_spent') * 0.1, IntegerField())
        )
```

### 5. Complex Aggregations with F()

**Scenario**: YouTube's video engagement analytics

```python
def calculate_product_metrics():
    """Calculate comprehensive product metrics"""
    
    return Product.objects.annotate(
        # Engagement score based on views and sales
        engagement_score=(
            F('view_count') * 0.1 + 
            F('sales_count') * 10 + 
            F('rating_count') * 5
        ),
        
        # Revenue metrics
        total_revenue=F('sales_count') * F('price'),
        total_profit=F('sales_count') * (F('price') - F('cost_price')),
        
        # Performance ratios
        sales_to_views_ratio=Case(
            When(view_count__gt=0, then=F('sales_count') / F('view_count') * 100),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Inventory status
        available_stock=F('stock_quantity') - F('reserved_quantity'),
        stock_value=F('available_stock') * F('cost_price'),
        
        # Popularity index (composite score)
        popularity_index=(
            F('view_count') * 0.3 +
            F('sales_count') * 0.4 +
            F('rating_count') * 0.3
        ) / 3
        
    ).order_by('-engagement_score')
```

## 🏢 Real-World Production Examples

### Instagram's Photo Engagement

```python
def instagram_style_engagement():
    """Calculate engagement metrics like Instagram"""
    
    return Product.objects.annotate(
        # Engagement rate (likes + comments / views)
        engagement_rate=Case(
            When(view_count__gt=0, then=(
                F('rating_count') + F('sales_count') * 2
            ) / F('view_count') * 100),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Viral coefficient (shares per view)
        viral_coefficient=Case(
            When(view_count__gt=0, then=F('sales_count') / F('view_count')),
            default=0.0,
            output_field=FloatField()
        ),
        
        # Trending score (recent engagement)
        trending_score=(
            F('view_count') * 0.5 +
            F('sales_count') * 3 +
            F('rating_count') * 2
        ),
        
        # Content quality score
        quality_score=Case(
            When(rating_count__gt=0, then=F('rating_sum') / F('rating_count') * F('rating_count')),
            default=0.0,
            output_field=FloatField()
        )
    ).filter(
        trending_score__gt=100  # Minimum threshold for trending
    ).order_by('-trending_score')
```

### Airbnb's Dynamic Pricing

```python
def airbnb_pricing_optimization():
    """Dynamic pricing based on demand and inventory"""
    
    return Product.objects.annotate(
        # Demand indicator
        demand_ratio=Case(
            When(stock_quantity__gt=0, then=F('view_count') / F('stock_quantity')),
            default=F('view_count'),  # High demand if out of stock
            output_field=FloatField()
        ),
        
        # Suggested price adjustment
        price_multiplier=Case(
            When(demand_ratio__gt=10, then=1.2),  # High demand: +20%
            When(demand_ratio__gt=5, then=1.1),   # Medium demand: +10%
            When(demand_ratio__lt=1, then=0.9),   # Low demand: -10%
            default=1.0,
            output_field=FloatField()
        ),
        
        # Dynamic price
        suggested_price=F('price') * F('price_multiplier'),
        
        # Profit at suggested price
        projected_profit=(F('suggested_price') - F('cost_price')) * F('sales_count'),
        
        # Inventory urgency
        urgency_score=Case(
            When(stock_quantity__lte=F('min_stock_level'), then=10),
            When(stock_quantity__lte=F('min_stock_level') * 2, then=7),
            When(stock_quantity__lte=F('min_stock_level') * 5, then=3),
            default=1,
            output_field=IntegerField()
        )
    ).order_by('-projected_profit')
```

### Uber's Surge Pricing Algorithm

```python
def surge_pricing_calculator():
    """Calculate surge pricing based on demand and supply"""
    
    return Product.objects.annotate(
        # Supply availability ratio
        supply_ratio=F('stock_quantity') / Greatest(F('view_count'), 1),
        
        # Demand pressure score
        demand_pressure=Case(
            When(supply_ratio__lt=0.1, then=5.0),  # Very high demand
            When(supply_ratio__lt=0.3, then=3.0),  # High demand
            When(supply_ratio__lt=0.7, then=1.8),  # Medium demand
            When(supply_ratio__lt=1.0, then=1.3),  # Low demand
            default=1.0,  # Normal demand
            output_field=FloatField()
        ),
        
        # Surge price
        surge_price=F('price') * F('demand_pressure'),
        
        # Revenue impact
        potential_revenue=F('surge_price') * F('sales_count'),
        
        # Customer impact score (balance revenue and customer satisfaction)
        customer_impact=Case(
            When(demand_pressure__gt=3, then=F('demand_pressure') * -10),  # High surge hurts satisfaction
            default=F('demand_pressure') * 5,  # Moderate surge acceptable
            output_field=FloatField()
        ),
        
        # Final recommendation score
        recommendation_score=F('potential_revenue') + F('customer_impact')
        
    ).order_by('-recommendation_score')
```

## ⚡ Performance Optimization with F()

### 1. Bulk Operations

```python
def optimize_bulk_updates():
    """Efficient bulk updates using F expressions"""
    
    # Update all products in one query instead of N queries
    Product.objects.filter(is_featured=True).update(
        view_count=F('view_count') + 1000,  # Boost featured products
        popularity_score=F('view_count') * 0.7 + F('sales_count') * 0.3
    )
    
    # Recalculate ratings efficiently
    Product.objects.update(
        average_rating=Case(
            When(rating_count__gt=0, then=F('rating_sum') / F('rating_count')),
            default=0.0,
            output_field=FloatField()
        )
    )
```

### 2. Avoiding N+1 Queries

```python
def efficient_product_listing():
    """Get product listing with computed fields efficiently"""
    
    # Single query instead of multiple
    return Product.objects.select_related('category').annotate(
        # All computations happen in database
        final_price=F('price') * (100 - F('discount_percentage')) / 100,
        profit_per_unit=F('price') - F('cost_price'),
        is_low_stock=Case(
            When(stock_quantity__lte=F('min_stock_level'), then=True),
            default=False
        ),
        performance_score=F('sales_count') + F('view_count') / 100
    ).order_by('-performance_score')
```

## 🎯 Key Takeaways

1. **F() expressions perform operations at the database level** → Much faster than Python
2. **Avoid race conditions** by using atomic field updates
3. **Complex calculations stay in the database** → Reduces memory usage
4. **Chain F() expressions** for sophisticated business logic
5. **Use Case/When with F()** for conditional computations
6. **Bulk operations with F()** are highly efficient for large datasets

F() expressions are essential for building high-performance Django applications that can handle enterprise-scale data operations!
''',
    "difficulty": "intermediate",
    "estimated_time": 45,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-aggregation"],
    "exercises": [
        {
            "id": "expressions_1",
            "title": "Explore Product Data for Expressions",
            "prompt": "Let's examine our e-commerce products table to understand the data we'll use for F expressions. Write a query to see product pricing, inventory, and engagement metrics.",
            "table_name": "products",
            "initial_query": "SELECT * FROM products LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "products"],
            "hint": "Use SELECT * FROM products LIMIT 5; to see the product structure",
            "solution": "SELECT * FROM products LIMIT 5;",
            "explanation": "This shows our products table with fields like price, cost_price, stock_quantity, sales_count, view_count, etc. F expressions will let us perform calculations on these fields directly in the database."
        },
        {
            "id": "expressions_2",
            "title": "Calculate Profit Margins with Field Operations",
            "prompt": "Practice F expression logic by calculating profit margins. Write a query to show product names with their profit per unit (price - cost_price).",
            "table_name": "products",
            "expected_keywords": ["SELECT", "name", "price", "cost_price", "-"],
            "hint": "Calculate price - cost_price to get profit per unit",
            "solution": "SELECT name, price, cost_price, (price - cost_price) as profit_per_unit FROM products ORDER BY profit_per_unit DESC;",
            "explanation": "This calculation simulates Django's F('price') - F('cost_price'). F expressions perform these calculations in the database, avoiding the need to load data into Python for computation."
        },
        {
            "id": "expressions_3",
            "title": "Calculate Average Ratings with Field References",
            "prompt": "Simulate F expression rating calculations. Write a query to calculate average ratings (rating_sum / rating_count) for products with reviews.",
            "table_name": "products",
            "expected_keywords": ["SELECT", "name", "rating_sum", "rating_count", "/"],
            "hint": "Divide rating_sum by rating_count, but handle division by zero",
            "solution": "SELECT name, rating_sum, rating_count, CASE WHEN rating_count > 0 THEN ROUND(rating_sum::decimal / rating_count, 2) ELSE 0 END as average_rating FROM products ORDER BY average_rating DESC;",
            "explanation": "This shows how F expressions handle division: F('rating_sum') / F('rating_count'). The CASE statement prevents division by zero, just like Django's Case/When expressions."
        },
        {
            "id": "expressions_4",
            "title": "Inventory Status with Conditional Logic",
            "prompt": "Practice conditional expressions by determining stock status. Write a query to show products with a 'needs_restock' flag when stock_quantity <= min_stock_level.",
            "table_name": "products",
            "expected_keywords": ["SELECT", "CASE", "WHEN", "stock_quantity", "min_stock_level"],
            "hint": "Use CASE WHEN stock_quantity <= min_stock_level THEN true ELSE false",
            "solution": "SELECT name, stock_quantity, min_stock_level, CASE WHEN stock_quantity <= min_stock_level THEN 'YES' ELSE 'NO' END as needs_restock FROM products ORDER BY stock_quantity ASC;",
            "explanation": "This conditional logic mirrors Django's Case(When(stock_quantity__lte=F('min_stock_level'), then=True), default=False). The database handles the comparison between fields efficiently."
        },
        {
            "id": "expressions_5",
            "title": "Performance Metrics with Multiple Field Operations",
            "prompt": "Create a conversion rate calculation using multiple fields. Write a query to calculate conversion_rate as (sales_count / view_count * 100) for products with views.",
            "table_name": "products",
            "expected_keywords": ["SELECT", "sales_count", "view_count", "*", "100"],
            "hint": "Calculate (sales_count / view_count * 100) and handle zero views",
            "solution": "SELECT name, sales_count, view_count, CASE WHEN view_count > 0 THEN ROUND((sales_count::decimal / view_count * 100), 2) ELSE 0 END as conversion_rate_percent FROM products ORDER BY conversion_rate_percent DESC;",
            "explanation": "This complex calculation demonstrates F expression power: F('sales_count') / F('view_count') * 100. Multiple field operations in a single database query are much more efficient than Python loops."
        },
        {
            "id": "expressions_6",
            "title": "Customer Account Balance Operations",
            "prompt": "Look at the customer accounts table and practice balance updates. Write a query to see customer balances and calculate a 'spending_power' score (account_balance + reward_points * 0.01).",
            "table_name": "customer_accounts",
            "expected_keywords": ["SELECT", "customer_id", "account_balance", "reward_points"],
            "hint": "Calculate account_balance + (reward_points * 0.01) as spending power",
            "solution": "SELECT customer_id, account_balance, reward_points, (account_balance + reward_points * 0.01) as spending_power FROM customer_accounts ORDER BY spending_power DESC;",
            "explanation": "This arithmetic operation simulates F('account_balance') + F('reward_points') * 0.01. F expressions enable complex financial calculations directly in the database, essential for real-time balance operations."
        }
    ],
    "key_concepts": [
        "F() Expression Fundamentals",
        "Database-Level Field References",
        "Arithmetic Operations with F()",
        "Cross-Field Comparisons",
        "Race Condition Prevention",
        "Bulk Update Optimizations", 
        "Complex Business Logic in Queries",
        "Performance Benefits of Database Computation"
    ]
}