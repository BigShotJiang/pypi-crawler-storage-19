"""
Django Model Instance Methods lesson content
"""

DJANGO_MODEL_INSTANCE_METHODS_LESSON = {
    "id": 20,
    "chapter": 20,
    "title": "Django Model Instance Methods",
    "slug": "model-instance-methods",
    "content": '''
# Model Instance Methods: Bringing Your Data to Life

Think of Django model instance methods as the personality and behavior of your data objects. Just as a real person has actions they can perform (walk, talk, calculate), Django model instances have methods that define what they can do. These are the building blocks that power features like Instagram's "Mark as favorite" button, Amazon's product validation, or Netflix's "Add to watchlist" functionality.

## Understanding Instance Methods: Objects with Superpowers

**Real-world analogy:** If a Django model is like a blueprint for a smartphone, then instance methods are like the apps installed on each phone. Every iPhone has the same basic structure (model), but each individual iPhone (instance) can perform specific actions like sending messages, taking photos, or playing music.

### The Instance Lifecycle: Birth to Death

Every Django model instance goes through a lifecycle similar to how a social media post progresses from creation to deletion:

```python
# 1. Creation (like writing a new Instagram post)
post = Post(title="My vacation photos", content="Amazing trip!")

# 2. Validation (like Instagram checking image format)
try:
    post.full_clean()  # Validates before saving
except ValidationError as e:
    print(f"Validation failed: {e}")

# 3. Saving (like publishing the post)
post.save()

# 4. Updates (like editing the caption)
post.title = "Updated vacation photos"
post.save(update_fields=['title'])

# 5. Refresh (like checking for new likes/comments)
post.refresh_from_db()

# 6. Deletion (like removing the post)
post.delete()
```

## Core Instance Methods: The Essential Toolkit

### save(): The Publishing Button

The `save()` method is like hitting "Publish" on any platform - it makes your changes permanent in the database.

```python
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    published_at = models.DateTimeField(null=True, blank=True)
    view_count = models.PositiveIntegerField(default=0)
    slug = models.SlugField(unique=True, blank=True)
    
    def save(self, *args, **kwargs):
        """Override save to add custom logic (like Medium's auto-slug generation)"""
        
        # Auto-generate slug if not provided (like Medium does)
        if not self.slug:
            from django.utils.text import slugify
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1
            
            # Ensure unique slug (like "my-post-1", "my-post-2")
            while BlogPost.objects.filter(slug=slug).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            
            self.slug = slug
        
        # Set published timestamp on first save (like WordPress auto-draft)
        if not self.pk and not self.published_at:
            from django.utils import timezone
            self.published_at = timezone.now()
        
        # Call the parent save method
        super().save(*args, **kwargs)
        
        # Post-save actions (like notifying subscribers)
        if self.pk:  # Only for existing objects
            self.notify_subscribers()
    
    def notify_subscribers(self):
        """Send notifications (like Substack email notifications)"""
        # Implementation would send emails/push notifications
        pass

# Usage examples
post = BlogPost(title="Django Tips", content="Learn Django...", author=user)
post.save()  # Triggers custom logic

# Efficient partial updates (like Facebook's "reaction" updates)
post.view_count += 1
post.save(update_fields=['view_count'])  # Only updates view_count column
```

### delete(): The Remove Button

The `delete()` method is like Instagram's "Delete Post" - it removes the object permanently.

```python
class UserAccount(models.Model):
    username = models.CharField(max_length=50, unique=True)
    email = models.EmailField()
    is_active = models.BooleanField(default=True)
    deletion_requested_at = models.DateTimeField(null=True, blank=True)
    
    def delete(self, *args, **kwargs):
        """Override delete for soft deletion (like Facebook deactivation)"""
        
        # Soft delete: mark as inactive instead of real deletion
        self.is_active = False
        self.deletion_requested_at = timezone.now()
        
        # Anonymize sensitive data (GDPR compliance)
        self.email = f"deleted_{self.pk}@example.com"
        self.username = f"deleted_user_{self.pk}"
        
        self.save(update_fields=['is_active', 'deletion_requested_at', 'email', 'username'])
        
        # Don't call super().delete() to preserve the record
        return (0, {})  # Return expected format
    
    def hard_delete(self):
        """Permanently delete (like admin panel deletion)"""
        super().delete()

# Usage
user_account = UserAccount.objects.get(username='john_doe')
deletion_info = user_account.delete()  # Soft delete
print(f"Deleted: {deletion_info}")  # (0, {}) for soft delete

# Get delete preview (like Gmail's "undo delete")
def get_deletion_preview(instance):
    """Preview what would be deleted (like Django admin's delete confirmation)"""
    # This would show related objects that would also be affected
    return instance._meta.model.objects.filter(pk=instance.pk).delete()
```

### full_clean(): The Quality Control

The `full_clean()` method is like having a strict editor review your content before publication.

```python
class Product(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    category = models.CharField(max_length=50)
    sku = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    
    def clean(self):
        """Custom validation (like Amazon's product listing validation)"""
        from django.core.exceptions import ValidationError
        
        errors = {}
        
        # Price validation
        if self.price <= 0:
            errors['price'] = 'Price must be positive'
        
        # SKU format validation (like Amazon's ASIN format)
        if not self.sku.startswith('PROD-'):
            errors['sku'] = 'SKU must start with PROD-'
        
        # Category-specific validation
        if self.category == 'electronics' and self.price > 10000:
            errors['price'] = 'Electronics over $10,000 need special approval'
        
        # Description quality check (like eBay's listing quality)
        if len(self.description.split()) < 10:
            errors['description'] = 'Description must be at least 10 words'
        
        # Business logic validation
        if not self.is_active and hasattr(self, 'pk') and self.pk:
            # Check if product has pending orders
            if self.orders.filter(status='pending').exists():
                errors['is_active'] = 'Cannot deactivate product with pending orders'
        
        if errors:
            raise ValidationError(errors)
    
    def save(self, *args, **kwargs):
        """Always validate before saving (like Shopify's product validation)"""
        self.full_clean()  # This calls clean() and field validation
        super().save(*args, **kwargs)

# Usage with error handling
try:
    product = Product(
        name="Smartphone",
        price=-100,  # Invalid price
        sku="INVALID",  # Invalid SKU format
        description="Phone",  # Too short
        category="electronics"
    )
    product.save()  # Will raise ValidationError
except ValidationError as e:
    print(f"Validation errors: {e.message_dict}")
    # Output: {'price': ['Price must be positive'], 'sku': ['SKU must start with PROD-'], ...}
```

### refresh_from_db(): The Refresh Button

Like refreshing your social media feed to see new content, `refresh_from_db()` updates your instance with the latest database values.

```python
class LiveStreamStats(models.Model):
    stream_id = models.CharField(max_length=100, unique=True)
    viewer_count = models.PositiveIntegerField(default=0)
    like_count = models.PositiveIntegerField(default=0)
    comment_count = models.PositiveIntegerField(default=0)
    last_updated = models.DateTimeField(auto_now=True)
    
    def get_live_stats(self):
        """Get real-time stats (like YouTube live stream counter)"""
        # Refresh from database to get latest counts
        self.refresh_from_db(fields=['viewer_count', 'like_count', 'comment_count'])
        
        return {
            'viewers': self.viewer_count,
            'likes': self.like_count,
            'comments': self.comment_count,
            'last_updated': self.last_updated
        }
    
    def increment_viewers(self, count=1):
        """Thread-safe viewer increment (like Twitch viewer count)"""
        from django.db.models import F
        
        # Use F() expression for atomic update
        LiveStreamStats.objects.filter(pk=self.pk).update(
            viewer_count=F('viewer_count') + count
        )
        
        # Refresh instance to reflect the change
        self.refresh_from_db(fields=['viewer_count'])

# Usage in a live streaming application
stream_stats = LiveStreamStats.objects.get(stream_id='live123')

# Get current stats (refreshes from database)
current_stats = stream_stats.get_live_stats()
print(f"Current viewers: {current_stats['viewers']}")

# Atomic increment (like real-time counters)
stream_stats.increment_viewers(1)
print(f"Updated viewers: {stream_stats.viewer_count}")
```

## Advanced Instance Methods: Professional Features

### get_absolute_url(): The Permalink Generator

Every good content platform needs permanent links. This method is like getting a shareable URL for any piece of content.

```python
from django.urls import reverse

class YouTubeVideo(models.Model):
    video_id = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=200)
    channel = models.ForeignKey('Channel', on_delete=models.CASCADE)
    upload_date = models.DateTimeField(auto_now_add=True)
    view_count = models.PositiveIntegerField(default=0)
    
    def get_absolute_url(self):
        """Generate canonical URL (like youtu.be/VIDEO_ID)"""
        return reverse('video_detail', kwargs={'video_id': self.video_id})
    
    def get_share_url(self):
        """Generate shareable URL with timestamp (like youtu.be/VIDEO_ID?t=30s)"""
        return f"{self.get_absolute_url()}?utm_source=share"
    
    def get_embed_url(self):
        """Generate embeddable URL (like youtube.com/embed/VIDEO_ID)"""
        return reverse('video_embed', kwargs={'video_id': self.video_id})

class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    published_date = models.DateField()
    
    def get_absolute_url(self):
        """SEO-friendly URLs (like medium.com/@author/post-title-123abc)"""
        return reverse('post_detail', kwargs={
            'year': self.published_date.year,
            'month': self.published_date.month,
            'slug': self.slug
        })
    
    def get_amp_url(self):
        """AMP version URL (like news.google.com AMP pages)"""
        return f"{self.get_absolute_url()}?amp=1"

# Usage in templates
# <a href="{{ post.get_absolute_url }}">Read More</a>
# <meta property="og:url" content="{{ post.get_absolute_url }}" />
```

### Custom Business Logic Methods: The Special Powers

These are custom methods that implement business logic specific to your application.

```python
class EcommerceOrder(models.Model):
    order_number = models.CharField(max_length=20, unique=True)
    customer = models.ForeignKey(User, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def can_be_cancelled(self):
        """Business logic: Can this order be cancelled? (like Amazon's cancellation policy)"""
        if self.status in ['shipped', 'delivered', 'cancelled']:
            return False
        
        # Allow cancellation within 1 hour of order
        from datetime import timedelta
        from django.utils import timezone
        
        cutoff_time = self.created_at + timedelta(hours=1)
        return timezone.now() < cutoff_time
    
    def cancel_order(self):
        """Cancel order with business logic (like e-commerce platforms)"""
        if not self.can_be_cancelled():
            raise ValueError("Order cannot be cancelled at this time")
        
        # Update status
        self.status = 'cancelled'
        
        # Restore inventory
        for item in self.items.all():
            item.product.stock_quantity += item.quantity
            item.product.save(update_fields=['stock_quantity'])
        
        # Process refund
        if self.payment_set.filter(status='completed').exists():
            self.process_refund()
        
        self.save(update_fields=['status'])
    
    def calculate_shipping(self):
        """Calculate shipping cost (like Amazon Prime logic)"""
        if self.customer.profile.is_prime_member:
            return 0  # Free shipping for Prime members
        
        if self.total_amount >= 35:
            return 0  # Free shipping over $35
        
        return 5.99  # Standard shipping
    
    def generate_tracking_number(self):
        """Generate tracking number (like FedEx/UPS tracking)"""
        import random
        import string
        
        prefix = "TRK"
        suffix = ''.join(random.choices(string.digits, k=10))
        return f"{prefix}{suffix}"
    
    def send_confirmation_email(self):
        """Send order confirmation (like every e-commerce platform)"""
        from django.core.mail import send_mail
        
        subject = f"Order Confirmation #{self.order_number}"
        message = f"""
        Dear {self.customer.first_name},
        
        Your order #{self.order_number} has been confirmed.
        Total: ${self.total_amount}
        
        Thank you for your purchase!
        """
        
        send_mail(
            subject,
            message,
            'orders@example.com',
            [self.customer.email]
        )

class SocialMediaPost(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField(max_length=280)  # Twitter-like limit
    created_at = models.DateTimeField(auto_now_add=True)
    like_count = models.PositiveIntegerField(default=0)
    retweet_count = models.PositiveIntegerField(default=0)
    
    def can_be_edited(self):
        """Business rule: Can this post be edited? (like Twitter's edit policy)"""
        from datetime import timedelta
        from django.utils import timezone
        
        # Allow editing within 30 minutes
        edit_window = timedelta(minutes=30)
        return timezone.now() - self.created_at < edit_window
    
    def get_engagement_rate(self):
        """Calculate engagement (like Instagram insights)"""
        total_engagement = self.like_count + self.retweet_count
        # In real app, would factor in follower count
        author_followers = self.author.profile.follower_count or 1
        return (total_engagement / author_followers) * 100
    
    def is_trending(self):
        """Check if post is trending (like Twitter trending topics)"""
        # Simple trending logic: high engagement in short time
        hours_old = (timezone.now() - self.created_at).total_seconds() / 3600
        if hours_old < 24:  # Only recent posts can trend
            engagement_per_hour = (self.like_count + self.retweet_count) / max(hours_old, 1)
            return engagement_per_hour > 10  # Arbitrary threshold
        return False
    
    def extract_hashtags(self):
        """Extract hashtags from content (like all social platforms)"""
        import re
        hashtags = re.findall(r'#(\\w+)', self.content)
        return [tag.lower() for tag in hashtags]
    
    def extract_mentions(self):
        """Extract user mentions (like @username)"""
        import re
        mentions = re.findall(r'@(\\w+)', self.content)
        return mentions
```

## Property Methods: Computed Attributes

Properties are like computed fields that calculate values on-the-fly.

```python
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    birth_date = models.DateField()
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    post_count = models.PositiveIntegerField(default=0)
    
    @property
    def age(self):
        """Calculate current age (like dating app profiles)"""
        from datetime import date
        today = date.today()
        return today.year - self.birth_date.year - (
            (today.month, today.day) < (self.birth_date.month, self.birth_date.day)
        )
    
    @property
    def is_influencer(self):
        """Determine influencer status (like Instagram verification criteria)"""
        return self.follower_count >= 10000
    
    @property
    def engagement_score(self):
        """Calculate engagement score (like social media analytics)"""
        if self.post_count == 0:
            return 0
        
        # Get average likes per post
        avg_likes = self.user.posts.aggregate(
            avg=models.Avg('like_count')
        )['avg'] or 0
        
        return (avg_likes / max(self.follower_count, 1)) * 100
    
    @property
    def follower_to_following_ratio(self):
        """Calculate follow ratio (like social media metrics)"""
        if self.following_count == 0:
            return float('inf') if self.follower_count > 0 else 0
        return self.follower_count / self.following_count

# Usage
profile = UserProfile.objects.get(user__username='celebrity_user')
print(f"Age: {profile.age}")  # Calculated on-the-fly
print(f"Influencer: {profile.is_influencer}")  # True/False based on followers
print(f"Engagement: {profile.engagement_score}%")  # Calculated from posts
```

## Real-World Instance Methods Example: Instagram-Style Photo System

```python
import os
import uuid
from PIL import Image
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

class Photo(models.Model):
    photo_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='photos/%Y/%m/')
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    like_count = models.PositiveIntegerField(default=0)
    is_archived = models.BooleanField(default=False)
    
    # Image processing metadata
    original_width = models.PositiveIntegerField(null=True)
    original_height = models.PositiveIntegerField(null=True)
    file_size = models.PositiveIntegerField(null=True)  # in bytes
    
    def save(self, *args, **kwargs):
        """Custom save with image processing (like Instagram's upload pipeline)"""
        
        # Process image on upload
        if self.image and not self.pk:  # New image
            self.process_uploaded_image()
        
        super().save(*args, **kwargs)
        
        # Generate thumbnails after saving
        if self.image:
            self.generate_thumbnails()
    
    def process_uploaded_image(self):
        """Process uploaded image (like Instagram's image optimization)"""
        if not self.image:
            return
        
        # Open the image
        image = Image.open(self.image)
        
        # Store original dimensions
        self.original_width, self.original_height = image.size
        
        # Calculate file size
        self.file_size = self.image.size
        
        # Auto-rotate based on EXIF data (like phone uploads)
        try:
            from PIL.ExifTags import ORIENTATION
            exif = image._getexif()
            if exif and ORIENTATION in exif:
                orientation = exif[ORIENTATION]
                if orientation == 3:
                    image = image.rotate(180, expand=True)
                elif orientation == 6:
                    image = image.rotate(270, expand=True)
                elif orientation == 8:
                    image = image.rotate(90, expand=True)
        except (AttributeError, KeyError, TypeError):
            pass
        
        # Resize if too large (like Instagram's max resolution)
        max_size = (1080, 1080)
        if image.size[0] > max_size[0] or image.size[1] > max_size[1]:
            image.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        # Save optimized image
        output = ContentFile(b'', name=self.image.name)
        image.save(output, format='JPEG', quality=85, optimize=True)
        self.image = output
    
    def generate_thumbnails(self):
        """Generate thumbnail versions (like Instagram's multiple sizes)"""
        if not self.image:
            return
        
        thumbnails = {
            'small': (150, 150),
            'medium': (320, 320), 
            'large': (640, 640)
        }
        
        base_name = os.path.splitext(self.image.name)[0]
        
        for size_name, dimensions in thumbnails.items():
            thumb_name = f"{base_name}_{size_name}.jpg"
            
            # Create thumbnail
            image = Image.open(self.image)
            image.thumbnail(dimensions, Image.Resampling.LANCZOS)
            
            # Save thumbnail
            thumb_content = ContentFile(b'')
            image.save(thumb_content, format='JPEG', quality=80)
            
            # Store in same directory structure
            default_storage.save(thumb_name, thumb_content)
    
    def get_thumbnail_url(self, size='medium'):
        """Get thumbnail URL (like Instagram's image CDN)"""
        if not self.image:
            return None
        
        base_name = os.path.splitext(self.image.name)[0]
        thumb_name = f"{base_name}_{size}.jpg"
        
        if default_storage.exists(thumb_name):
            return default_storage.url(thumb_name)
        
        # Fallback to original
        return self.image.url
    
    def get_absolute_url(self):
        """Get photo detail URL (like instagram.com/p/ABC123/)"""
        return reverse('photo_detail', kwargs={'photo_id': str(self.photo_id)})
    
    def can_be_deleted_by(self, user):
        """Check if user can delete this photo (permission logic)"""
        # Owner can always delete
        if self.user == user:
            return True
        
        # Admins can delete
        if user.is_staff:
            return True
        
        # Other business logic (moderators, etc.)
        return False
    
    def like_by_user(self, user):
        """Like photo (like Instagram heart button)"""
        like, created = PhotoLike.objects.get_or_create(
            photo=self,
            user=user
        )
        
        if created:
            # Increment like count atomically
            Photo.objects.filter(pk=self.pk).update(
                like_count=F('like_count') + 1
            )
            self.refresh_from_db(fields=['like_count'])
            
            # Send notification to photo owner
            self.notify_owner_of_like(user)
        
        return created  # True if newly liked, False if already liked
    
    def unlike_by_user(self, user):
        """Unlike photo (remove like)"""
        try:
            like = PhotoLike.objects.get(photo=self, user=user)
            like.delete()
            
            # Decrement like count atomically
            Photo.objects.filter(pk=self.pk).update(
                like_count=F('like_count') - 1
            )
            self.refresh_from_db(fields=['like_count'])
            return True
        except PhotoLike.DoesNotExist:
            return False
    
    def is_liked_by(self, user):
        """Check if user has liked this photo"""
        return PhotoLike.objects.filter(photo=self, user=user).exists()
    
    def get_likes_summary(self):
        """Get likes summary (like Instagram's "liked by X and Y others")"""
        recent_likes = PhotoLike.objects.filter(photo=self).select_related('user')[:3]
        
        if self.like_count == 0:
            return "No likes yet"
        elif self.like_count == 1:
            return f"Liked by {recent_likes[0].user.username}"
        elif self.like_count <= 3:
            usernames = [like.user.username for like in recent_likes]
            return f"Liked by {', '.join(usernames)}"
        else:
            first_two = [like.user.username for like in recent_likes[:2]]
            others_count = self.like_count - 2
            return f"Liked by {', '.join(first_two)} and {others_count} others"
    
    def notify_owner_of_like(self, liker):
        """Send notification to photo owner (like Instagram notifications)"""
        if self.user != liker:  # Don't notify self-likes
            # Implementation would send push notification
            pass
    
    def archive(self):
        """Archive photo (like Instagram's archive feature)"""
        self.is_archived = True
        self.save(update_fields=['is_archived'])
    
    def unarchive(self):
        """Unarchive photo"""
        self.is_archived = False
        self.save(update_fields=['is_archived'])
    
    def delete(self, *args, **kwargs):
        """Custom delete to clean up files (like proper file management)"""
        
        # Delete thumbnail files
        if self.image:
            base_name = os.path.splitext(self.image.name)[0]
            for size in ['small', 'medium', 'large']:
                thumb_name = f"{base_name}_{size}.jpg"
                if default_storage.exists(thumb_name):
                    default_storage.delete(thumb_name)
            
            # Delete original image
            if default_storage.exists(self.image.name):
                default_storage.delete(self.image.name)
        
        # Call parent delete
        super().delete(*args, **kwargs)
    
    def __str__(self):
        return f"Photo by {self.user.username} - {self.created_at.strftime('%Y-%m-%d')}"

class PhotoLike(models.Model):
    photo = models.ForeignKey(Photo, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['photo', 'user']
```

Instance methods are the behavioral DNA of your Django models. They define not just what your data looks like, but what it can DO. Master these patterns, and you'll build applications with the same sophistication as the platforms millions use daily! 🚀

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/ref/models/instances/
    ''',
    "is_free": False,
    "xp_reward": 125,
    "exercises": [
        {
            "id": "instagram-photo-system",
            "title": "Build Instagram-Style Photo Management System",
            "type": "project",
            "instructions": """Create a comprehensive photo management system with advanced instance methods:

1. Implement Photo model with image processing and optimization
2. Add validation methods for image quality and content
3. Create engagement methods (like, unlike, archive)
4. Implement thumbnail generation and URL management
5. Add business logic for permissions and user interactions

Your solution should demonstrate:
- Custom save() and delete() methods with file processing
- Validation using clean() and full_clean()
- Property methods for calculated fields
- Business logic methods for user interactions
- Real-world features like Instagram's photo system""",
            "starter_code": """import os
import uuid
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.db.models import F

class Photo(models.Model):
    photo_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to='photos/%Y/%m/')
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    like_count = models.PositiveIntegerField(default=0)
    is_archived = models.BooleanField(default=False)
    
    # Image metadata
    original_width = models.PositiveIntegerField(null=True)
    original_height = models.PositiveIntegerField(null=True)
    file_size = models.PositiveIntegerField(null=True)
    
    # Your task: Implement these methods
    
    def clean(self):
        \"\"\"
        Validate image quality and content:
        - Check image format (only JPEG, PNG allowed)
        - Validate image dimensions (minimum 100x100)
        - Check file size (max 10MB)
        - Validate caption content
        \"\"\"
        # Implement validation logic
        pass
    
    def save(self, *args, **kwargs):
        \"\"\"
        Custom save with image processing:
        - Process uploaded image (resize, optimize)
        - Extract image metadata
        - Generate thumbnails
        \"\"\"
        # Implement custom save logic
        pass
    
    def delete(self, *args, **kwargs):
        \"\"\"
        Custom delete with cleanup:
        - Delete image files and thumbnails
        - Clean up related data
        \"\"\"
        # Implement custom delete logic
        pass
    
    def get_absolute_url(self):
        \"\"\"Generate photo detail URL\"\"\"
        # Implement URL generation
        pass
    
    @property
    def aspect_ratio(self):
        \"\"\"Calculate image aspect ratio\"\"\"
        # Implement aspect ratio calculation
        pass
    
    @property
    def is_landscape(self):
        \"\"\"Check if image is landscape orientation\"\"\"
        # Implement orientation check
        pass
    
    def like_by_user(self, user):
        \"\"\"
        Like photo by user:
        - Create like relationship
        - Update like count atomically
        - Send notifications
        \"\"\"
        # Implement like functionality
        pass
    
    def unlike_by_user(self, user):
        \"\"\"Remove like by user\"\"\"
        # Implement unlike functionality
        pass
    
    def is_liked_by(self, user):
        \"\"\"Check if user has liked this photo\"\"\"
        # Implement like check
        pass
    
    def archive(self):
        \"\"\"Archive photo (hide from public feed)\"\"\"
        # Implement archive functionality
        pass
    
    def can_be_edited_by(self, user):
        \"\"\"Check if user can edit this photo\"\"\"
        # Implement permission logic
        pass

class PhotoLike(models.Model):
    photo = models.ForeignKey(Photo, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['photo', 'user']

# Test your implementation
# photo = Photo(user=user, image=uploaded_file, caption="Test photo")
# photo.save()  # Should process image and generate thumbnails
# photo.like_by_user(another_user)  # Should create like and increment count""",
            "solution": """import os
import uuid
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.db.models import F
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

class Photo(models.Model):
    photo_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to='photos/%Y/%m/')
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    like_count = models.PositiveIntegerField(default=0)
    is_archived = models.BooleanField(default=False)
    
    # Image metadata
    original_width = models.PositiveIntegerField(null=True)
    original_height = models.PositiveIntegerField(null=True)
    file_size = models.PositiveIntegerField(null=True)
    
    def clean(self):
        \"\"\"
        Validate image quality and content
        \"\"\"
        errors = {}
        
        if self.image:
            # Check file size (10MB max)
            if self.image.size > 10 * 1024 * 1024:
                errors['image'] = 'Image file size cannot exceed 10MB'
            
            # Check image format
            valid_formats = ['JPEG', 'PNG']
            try:
                from PIL import Image
                img = Image.open(self.image)
                if img.format not in valid_formats:
                    errors['image'] = f'Image must be in {", ".join(valid_formats)} format'
                
                # Check minimum dimensions
                width, height = img.size
                if width < 100 or height < 100:
                    errors['image'] = 'Image must be at least 100x100 pixels'
                
                # Check maximum dimensions
                if width > 4000 or height > 4000:
                    errors['image'] = 'Image dimensions cannot exceed 4000x4000 pixels'
                
            except Exception as e:
                errors['image'] = 'Invalid image file'
        
        # Caption validation
        if self.caption:
            # Check for spam-like content
            spam_keywords = ['win money', 'click here', 'free gift', 'urgent']
            caption_lower = self.caption.lower()
            if any(keyword in caption_lower for keyword in spam_keywords):
                errors['caption'] = 'Caption contains prohibited content'
            
            # Check for excessive hashtags
            hashtag_count = self.caption.count('#')
            if hashtag_count > 10:
                errors['caption'] = 'Maximum 10 hashtags allowed'
        
        # Location validation
        if self.location and len(self.location) > 100:
            errors['location'] = 'Location cannot exceed 100 characters'
        
        if errors:
            raise ValidationError(errors)
    
    def save(self, *args, **kwargs):
        \"\"\"
        Custom save with image processing
        \"\"\"
        is_new_image = self.image and not self.pk
        
        if is_new_image:
            self.process_uploaded_image()
        
        # Always validate before saving
        self.full_clean()
        
        super().save(*args, **kwargs)
        
        # Generate thumbnails after saving
        if is_new_image:
            self.generate_thumbnails()
    
    def process_uploaded_image(self):
        \"\"\"
        Process uploaded image (resize, optimize, extract metadata)
        \"\"\"
        if not self.image:
            return
        
        try:
            from PIL import Image, ImageOps
            
            # Open and process image
            img = Image.open(self.image)
            
            # Auto-orient based on EXIF data
            img = ImageOps.exif_transpose(img)
            
            # Store original dimensions and file size
            self.original_width, self.original_height = img.size
            self.file_size = self.image.size
            
            # Resize if too large (Instagram-style max resolution)
            max_dimension = 1080
            if img.width > max_dimension or img.height > max_dimension:
                # Calculate new dimensions maintaining aspect ratio
                if img.width > img.height:
                    new_width = max_dimension
                    new_height = int((max_dimension * img.height) / img.width)
                else:
                    new_height = max_dimension
                    new_width = int((max_dimension * img.width) / img.height)
                
                img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            
            # Convert to RGB if necessary (for JPEG saving)
            if img.mode in ('RGBA', 'P'):
                background = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                img = background
            
            # Save optimized image
            output = ContentFile(b'')
            img.save(output, format='JPEG', quality=85, optimize=True)
            
            # Replace the original file
            self.image.file = output
            
        except Exception as e:
            raise ValidationError({'image': f'Error processing image: {str(e)}'})
    
    def generate_thumbnails(self):
        \"\"\"
        Generate thumbnail versions of different sizes
        \"\"\"
        if not self.image:
            return
        
        thumbnail_sizes = {
            'small': (150, 150),
            'medium': (320, 320),
            'large': (640, 640)
        }
        
        try:
            from PIL import Image
            
            base_name = os.path.splitext(self.image.name)[0]
            img = Image.open(self.image)
            
            for size_name, dimensions in thumbnail_sizes.items():
                # Create thumbnail maintaining aspect ratio
                thumb_img = img.copy()
                thumb_img.thumbnail(dimensions, Image.Resampling.LANCZOS)
                
                # Create a square canvas for Instagram-style thumbnails
                canvas = Image.new('RGB', dimensions, (255, 255, 255))
                
                # Center the thumbnail on the canvas
                x = (dimensions[0] - thumb_img.width) // 2
                y = (dimensions[1] - thumb_img.height) // 2
                canvas.paste(thumb_img, (x, y))
                
                # Save thumbnail
                thumb_name = f\"{base_name}_{size_name}.jpg\"
                thumb_content = ContentFile(b'')
                canvas.save(thumb_content, format='JPEG', quality=80, optimize=True)
                
                default_storage.save(thumb_name, thumb_content)
                
        except Exception as e:
            # Thumbnail generation failure shouldn't prevent photo upload
            print(f\"Warning: Could not generate thumbnails: {e}\")
    
    def delete(self, *args, **kwargs):
        \"\"\"
        Custom delete with cleanup
        \"\"\"
        # Delete image files
        if self.image:
            # Delete thumbnails
            base_name = os.path.splitext(self.image.name)[0]
            for size in ['small', 'medium', 'large']:
                thumb_name = f\"{base_name}_{size}.jpg\"
                if default_storage.exists(thumb_name):
                    try:
                        default_storage.delete(thumb_name)
                    except Exception:
                        pass
            
            # Delete original image
            if default_storage.exists(self.image.name):
                try:
                    default_storage.delete(self.image.name)
                except Exception:
                    pass
        
        # Call parent delete
        super().delete(*args, **kwargs)
    
    def get_absolute_url(self):
        \"\"\"Generate photo detail URL\"\"\"
        return reverse('photo_detail', kwargs={'photo_id': str(self.photo_id)})
    
    def get_thumbnail_url(self, size='medium'):
        \"\"\"Get URL for thumbnail of specified size\"\"\"
        if not self.image:
            return None
        
        base_name = os.path.splitext(self.image.name)[0]
        thumb_name = f\"{base_name}_{size}.jpg\"
        
        if default_storage.exists(thumb_name):
            return default_storage.url(thumb_name)
        
        # Fallback to original image
        return self.image.url
    
    @property
    def aspect_ratio(self):
        \"\"\"Calculate image aspect ratio\"\"\"
        if self.original_width and self.original_height:
            return self.original_width / self.original_height
        return 1.0
    
    @property
    def is_landscape(self):
        \"\"\"Check if image is landscape orientation\"\"\"
        return self.aspect_ratio > 1.0
    
    @property
    def is_portrait(self):
        \"\"\"Check if image is portrait orientation\"\"\"
        return self.aspect_ratio < 1.0
    
    @property
    def is_square(self):
        \"\"\"Check if image is square (within tolerance)\"\"\"
        return abs(self.aspect_ratio - 1.0) < 0.1
    
    @property
    def file_size_mb(self):
        \"\"\"Get file size in MB\"\"\"
        if self.file_size:
            return round(self.file_size / (1024 * 1024), 2)
        return 0
    
    @property
    def engagement_rate(self):
        \"\"\"Calculate engagement rate based on likes and user followers\"\"\"
        if hasattr(self.user, 'profile') and self.user.profile.follower_count:
            return (self.like_count / self.user.profile.follower_count) * 100
        return 0
    
    def like_by_user(self, user):
        \"\"\"
        Like photo by user with atomic operations
        \"\"\"
        if user == self.user:
            return False  # Users can't like their own photos
        
        like, created = PhotoLike.objects.get_or_create(
            photo=self,
            user=user
        )
        
        if created:
            # Increment like count atomically
            Photo.objects.filter(pk=self.pk).update(
                like_count=F('like_count') + 1
            )
            
            # Refresh instance to reflect the change
            self.refresh_from_db(fields=['like_count'])
            
            # Send notification to photo owner
            self.notify_owner_of_like(user)
            
            return True
        
        return False  # Already liked
    
    def unlike_by_user(self, user):
        \"\"\"
        Remove like by user
        \"\"\"
        try:
            like = PhotoLike.objects.get(photo=self, user=user)
            like.delete()
            
            # Decrement like count atomically
            Photo.objects.filter(pk=self.pk).update(
                like_count=F('like_count') - 1
            )
            
            # Refresh instance to reflect the change
            self.refresh_from_db(fields=['like_count'])
            
            return True
        except PhotoLike.DoesNotExist:
            return False
    
    def is_liked_by(self, user):
        \"\"\"Check if user has liked this photo\"\"\"
        if not user.is_authenticated:
            return False
        return PhotoLike.objects.filter(photo=self, user=user).exists()
    
    def get_likes_summary(self, requesting_user=None):
        \"\"\"
        Get likes summary like Instagram's \"liked by X and Y others\"
        \"\"\"
        if self.like_count == 0:
            return \"No likes yet\"
        
        recent_likes = PhotoLike.objects.filter(
            photo=self
        ).select_related('user').order_by('-created_at')[:3]
        
        # Check if requesting user is among the likers
        user_liked = False
        if requesting_user and requesting_user.is_authenticated:
            user_liked = self.is_liked_by(requesting_user)
        
        if self.like_count == 1:
            if user_liked:
                return \"Liked by you\"
            return f\"Liked by {recent_likes[0].user.username}\"
        
        elif self.like_count == 2:
            usernames = [like.user.username for like in recent_likes]
            if user_liked:
                other_user = [name for name in usernames if name != requesting_user.username][0]
                return f\"Liked by you and {other_user}\"
            return f\"Liked by {' and '.join(usernames)}\"
        
        else:  # 3 or more likes
            if user_liked:
                other_likes = [like for like in recent_likes if like.user != requesting_user][:2]
                other_usernames = [like.user.username for like in other_likes]
                others_count = self.like_count - 1
                if others_count == 1:
                    return f\"Liked by you and {other_usernames[0]}\"
                elif others_count == 2:
                    return f\"Liked by you, {other_usernames[0]} and {other_usernames[1]}\"
                else:
                    return f\"Liked by you, {other_usernames[0]} and {others_count - 1} others\"
            else:
                first_two = [like.user.username for like in recent_likes[:2]]
                others_count = self.like_count - 2
                return f\"Liked by {', '.join(first_two)} and {others_count} others\"
    
    def archive(self):
        \"\"\"Archive photo (hide from public feed)\"\"\"
        self.is_archived = True
        self.save(update_fields=['is_archived'])
    
    def unarchive(self):
        \"\"\"Unarchive photo\"\"\"
        self.is_archived = False
        self.save(update_fields=['is_archived'])
    
    def can_be_edited_by(self, user):
        \"\"\"Check if user can edit this photo\"\"\"
        # Owner can edit
        if self.user == user:
            return True
        
        # Admin can edit
        if user.is_staff:
            return True
        
        # No one else can edit
        return False
    
    def can_be_deleted_by(self, user):
        \"\"\"Check if user can delete this photo\"\"\"
        return self.can_be_edited_by(user)
    
    def notify_owner_of_like(self, liker):
        \"\"\"
        Send notification to photo owner about new like
        \"\"\"
        if self.user != liker:
            # In a real application, this would send push notifications
            # or create notification objects
            print(f\"Notification: {liker.username} liked your photo\")
    
    def extract_hashtags(self):
        \"\"\"Extract hashtags from caption\"\"\"
        import re
        if not self.caption:
            return []
        
        hashtags = re.findall(r'#(\\w+)', self.caption)
        return [tag.lower() for tag in hashtags]
    
    def extract_mentions(self):
        \"\"\"Extract user mentions from caption\"\"\"
        import re
        if not self.caption:
            return []
        
        mentions = re.findall(r'@(\\w+)', self.caption)
        return [mention.lower() for mention in mentions]
    
    def get_similar_photos(self, limit=5):
        \"\"\"
        Get similar photos based on hashtags and location
        \"\"\"
        hashtags = self.extract_hashtags()
        similar_photos = Photo.objects.filter(
            is_archived=False
        ).exclude(pk=self.pk)
        
        if hashtags:
            # Find photos with similar hashtags
            hashtag_pattern = '|'.join(hashtags)
            similar_photos = similar_photos.filter(
                caption__iregex=f'#({hashtag_pattern})\\\\b'
            )
        elif self.location:
            # Find photos from same location
            similar_photos = similar_photos.filter(
                location__icontains=self.location
            )
        else:
            # Find photos from same user
            similar_photos = similar_photos.filter(user=self.user)
        
        return similar_photos.order_by('-like_count', '-created_at')[:limit]
    
    def __str__(self):
        return f\"Photo by {self.user.username} - {self.created_at.strftime('%Y-%m-%d')}\"
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['-like_count']),
            models.Index(fields=['is_archived']),
        ]

class PhotoLike(models.Model):
    photo = models.ForeignKey(Photo, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='photo_likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['photo', 'user']
        indexes = [
            models.Index(fields=['photo', '-created_at']),
            models.Index(fields=['user', '-created_at']),
        ]
    
    def __str__(self):
        return f\"{self.user.username} likes {self.photo}\"

# Example usage and testing
def test_photo_system():
    \"\"\"
    Test the photo system functionality
    \"\"\"
    from django.contrib.auth.models import User
    from django.core.files.uploadedfile import SimpleUploadedFile
    
    # Create test users
    user1 = User.objects.create_user('photographer', 'photo@example.com', 'pass123')
    user2 = User.objects.create_user('viewer', 'view@example.com', 'pass123')
    
    # Create a test photo (would need actual image file in practice)
    photo = Photo(
        user=user1,
        caption=\"Beautiful sunset! #photography #nature\",
        location=\"Beach, California\"
    )
    
    # Test validation
    try:
        photo.full_clean()
        print(\"Photo validation passed\")
    except ValidationError as e:
        print(f\"Validation errors: {e}\")
    
    # Test liking system
    liked = photo.like_by_user(user2)
    print(f\"Photo liked: {liked}\")
    print(f\"Like count: {photo.like_count}\")
    print(f\"Likes summary: {photo.get_likes_summary(user2)}\")
    
    # Test hashtag extraction
    hashtags = photo.extract_hashtags()
    print(f\"Hashtags: {hashtags}\")
    
    return photo""",
            "test_cases": [
                {
                    "name": "Model has required instance methods",
                    "input": "",
                    "expected_contains": ["clean", "save", "delete", "get_absolute_url", "like_by_user"]
                }
            ],
            "xp_reward": 170,
            "hints": [
                "Use ValidationError for custom validation in clean() method",
                "Implement atomic updates with F() expressions for counters",
                "Use PIL/Pillow for image processing and thumbnail generation",
                "Store metadata like dimensions and file size for efficient access",
                "Implement proper file cleanup in custom delete() method"
            ]
        }
    ]
}