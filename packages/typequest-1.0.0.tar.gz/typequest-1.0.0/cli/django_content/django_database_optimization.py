"""
Django Database Management - Lesson 4: Database Optimization and Performance
Master Django's database optimization techniques for high-performance applications
"""

DJANGO_DATABASE_OPTIMIZATION_LESSON = {
    "id": 57,
    "chapter": 57,
    "title": "Django Database Optimization: Performance and Scalability",
    "slug": "django-database-optimization",
    "description": "Learn advanced Django database optimization techniques including query optimization, indexing, and performance monitoring",
    "content": '''# Django Database Optimization: Performance and Scalability

## 🎯 Understanding Database Optimization

**Database optimization** is critical for Django applications that need to handle **high traffic**, **large datasets**, and **complex queries**. Poor database performance can bottleneck entire applications regardless of other optimizations.

**Key Optimization Areas**:
- **Query Optimization** → select_related, prefetch_related, efficient filters
- **Database Indexing** → Strategic index placement for query performance
- **N+1 Query Prevention** → Avoiding multiple database hits in loops
- **Connection Management** → Pooling, persistent connections, connection limits
- **Query Monitoring** → Profiling, explain plans, slow query detection
- **Caching Strategies** → Database-level and application-level caching

Think of database optimization as **building a highway system** - the right routes and infrastructure determine how fast traffic flows.

## 💾 Performance Optimization Database

Let's create realistic scenarios for database optimization testing:

```sql
-- PERFORMANCE TEST DATABASE: E-commerce with realistic data volumes
-- Database: ecommerce_performance

-- Users table with indexes for common queries
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(150) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    first_name VARCHAR(30),
    last_name VARCHAR(150),
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    is_staff BOOLEAN DEFAULT FALSE,
    profile_data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for user queries
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(is_active);
CREATE INDEX idx_users_date_joined ON users(date_joined);
CREATE INDEX idx_users_last_login ON users(last_login);
CREATE INDEX idx_users_profile_data ON users USING GIN(profile_data);

-- Sample user data (representing 10K+ users)
INSERT INTO users (username, email, first_name, last_name, date_joined, last_login, profile_data) VALUES
('user001', 'user001@example.com', 'John', 'Smith', '2024-01-15 10:30:00', '2024-12-20 14:22:00', '{"preferences": {"theme": "dark", "notifications": true}, "activity_score": 85}'),
('user002', 'user002@example.com', 'Sarah', 'Johnson', '2024-02-20 14:15:00', '2024-12-25 09:15:00', '{"preferences": {"theme": "light", "notifications": false}, "activity_score": 92}'),
('user003', 'user003@example.com', 'Mike', 'Davis', '2024-03-10 11:45:00', '2024-12-24 16:30:00', '{"preferences": {"theme": "dark", "notifications": true}, "activity_score": 78}'),
('user004', 'user004@example.com', 'Lisa', 'Wilson', '2024-04-05 09:20:00', '2024-12-23 12:45:00', '{"preferences": {"theme": "auto", "notifications": true}, "activity_score": 96}'),
('user005', 'user005@example.com', 'Tom', 'Brown', '2024-05-12 16:10:00', '2024-12-22 08:30:00', '{"preferences": {"theme": "light", "notifications": false}, "activity_score": 72}');

-- Products table optimized for e-commerce queries
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    cost_price DECIMAL(10, 2),
    category_id INTEGER,
    brand_id INTEGER,
    sku VARCHAR(100) UNIQUE NOT NULL,
    stock_quantity INTEGER DEFAULT 0,
    weight_kg DECIMAL(8, 3),
    is_active BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,
    rating_avg DECIMAL(3, 2) DEFAULT 0.00,
    rating_count INTEGER DEFAULT 0,
    view_count INTEGER DEFAULT 0,
    sales_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Strategic product indexes for common e-commerce queries
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_brand ON products(brand_id);
CREATE INDEX idx_products_active ON products(is_active);
CREATE INDEX idx_products_featured ON products(is_featured);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_products_rating ON products(rating_avg DESC);
CREATE INDEX idx_products_popularity ON products(view_count DESC, sales_count DESC);
CREATE INDEX idx_products_stock ON products(stock_quantity);
CREATE INDEX idx_products_created ON products(created_at);

-- Composite indexes for complex queries
CREATE INDEX idx_products_active_category_price ON products(is_active, category_id, price);
CREATE INDEX idx_products_active_featured_rating ON products(is_active, is_featured, rating_avg DESC);

-- Sample product data
INSERT INTO products (name, slug, description, price, cost_price, category_id, brand_id, sku, stock_quantity, is_featured, rating_avg, rating_count, view_count, sales_count) VALUES
('iPhone 15 Pro Max', 'iphone-15-pro-max', 'Latest iPhone with advanced camera system', 1199.99, 800.00, 1, 1, 'APPLE-IP15PM-001', 45, TRUE, 4.8, 2847, 15420, 2847),
('MacBook Air M3', 'macbook-air-m3', 'Thin and light laptop with M3 chip', 1099.99, 750.00, 2, 1, 'APPLE-MBA-M3-001', 30, TRUE, 4.9, 1205, 8934, 1205),
('Samsung Galaxy S24 Ultra', 'samsung-galaxy-s24-ultra', 'Premium Android phone with S Pen', 1299.99, 850.00, 1, 2, 'SAMSUNG-GS24U-001', 25, TRUE, 4.7, 1876, 12456, 1876),
('Dell XPS 13', 'dell-xps-13', 'Compact Windows laptop for professionals', 999.99, 650.00, 2, 3, 'DELL-XPS13-001', 20, FALSE, 4.6, 892, 6543, 892),
('Sony WH-1000XM5', 'sony-wh1000xm5', 'Industry-leading noise canceling headphones', 399.99, 250.00, 3, 4, 'SONY-WH1000-001', 75, FALSE, 4.9, 3421, 23651, 3421);

-- Orders table with indexes for order management
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    total_amount DECIMAL(10, 2) NOT NULL,
    tax_amount DECIMAL(10, 2) DEFAULT 0.00,
    shipping_amount DECIMAL(10, 2) DEFAULT 0.00,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    payment_method VARCHAR(50),
    shipping_address JSONB,
    billing_address JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_at TIMESTAMP,
    delivered_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order indexes for common queries
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);
CREATE INDEX idx_orders_total ON orders(total_amount);
CREATE INDEX idx_orders_number ON orders(order_number);

-- Composite indexes for order analytics
CREATE INDEX idx_orders_user_created ON orders(user_id, created_at DESC);
CREATE INDEX idx_orders_status_created ON orders(status, created_at DESC);
CREATE INDEX idx_orders_created_total ON orders(created_at, total_amount);

-- Sample order data
INSERT INTO orders (user_id, order_number, status, total_amount, tax_amount, shipping_amount, payment_method, created_at) VALUES
(1, 'ORD-2024-001', 'delivered', 1349.98, 107.98, 15.00, 'credit_card', '2024-11-15 10:30:00'),
(2, 'ORD-2024-002', 'shipped', 1199.99, 95.99, 0.00, 'paypal', '2024-12-01 14:22:00'),
(1, 'ORD-2024-003', 'processing', 799.98, 63.98, 12.50, 'credit_card', '2024-12-15 16:45:00'),
(3, 'ORD-2024-004', 'pending', 1299.99, 103.99, 0.00, 'apple_pay', '2024-12-20 09:15:00'),
(4, 'ORD-2024-005', 'delivered', 399.99, 31.99, 8.00, 'credit_card', '2024-12-10 11:30:00');

-- Order items for detailed analytics
CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Order items indexes
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
CREATE INDEX idx_order_items_price ON order_items(total_price);

-- Sample order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES
(1, 1, 1, 1199.99, 1199.99),
(1, 5, 1, 149.99, 149.99),
(2, 1, 1, 1199.99, 1199.99),
(3, 2, 1, 799.99, 799.99),
(4, 3, 1, 1299.99, 1299.99),
(5, 5, 1, 399.99, 399.99);

-- Query performance tracking
CREATE TABLE query_performance_logs (
    id SERIAL PRIMARY KEY,
    query_type VARCHAR(100) NOT NULL,
    execution_time_ms DECIMAL(8, 3) NOT NULL,
    rows_returned INTEGER,
    rows_examined INTEGER,
    query_hash VARCHAR(64),
    query_sql TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER,
    endpoint VARCHAR(200)
);

-- Sample performance data
INSERT INTO query_performance_logs (query_type, execution_time_ms, rows_returned, rows_examined, query_hash, endpoint) VALUES
('product_list', 25.341, 25, 25, 'hash123', '/api/products/'),
('user_orders', 45.672, 5, 5, 'hash456', '/api/users/1/orders/'),
('order_details', 15.234, 1, 1, 'hash789', '/api/orders/1/'),
('product_search', 156.789, 42, 5000, 'hash000', '/api/products/search/'),
('category_products', 78.456, 100, 100, 'hash111', '/api/categories/1/products/');
```

## 🔧 Query Optimization Techniques

### 1. select_related() for Forward Relationships

**Scenario**: Instagram's post feed optimization

```python
# models.py
from django.db import models

class User(models.Model):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    profile_image = models.URLField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.CharField(max_length=100, unique=True)
    
class Brand(models.Model):
    name = models.CharField(max_length=100)
    slug = models.CharField(max_length=100, unique=True)

class Product(models.Model):
    name = models.CharField(max_length=200)
    slug = models.CharField(max_length=200, unique=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order_number = models.CharField(max_length=50, unique=True)
    status = models.CharField(max_length=20, default='pending')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

# SLOW - Causes N+1 queries (1 query + N queries for related objects)
def get_orders_slow():
    """Bad example - triggers N+1 queries"""
    orders = Order.objects.all()[:10]
    
    for order in orders:
        # Each iteration causes a separate database query
        print(f"Order {order.order_number} by {order.user.username}")  # Query for user
        print(f"User email: {order.user.email}")  # Uses cached user object
    
    # Total queries: 1 (orders) + 10 (users) = 11 queries

# FAST - Uses select_related() to fetch related objects in one query
def get_orders_optimized():
    """Optimized example - uses select_related()"""
    orders = Order.objects.select_related('user').all()[:10]
    
    for order in orders:
        # No additional database queries - user is already loaded
        print(f"Order {order.order_number} by {order.user.username}")
        print(f"User email: {order.user.email}")
    
    # Total queries: 1 (orders with users via JOIN)

# Multiple select_related() for complex relationships
def get_products_with_category_and_brand():
    """Fetch products with category and brand in one query"""
    products = Product.objects.select_related(
        'category',
        'brand'
    ).filter(is_active=True)[:20]
    
    for product in products:
        print(f"{product.name} - {product.category.name} by {product.brand.name}")
    
    # Only 1 query with JOINs instead of 1 + N + N queries

# Real-world example: E-commerce product listing
class ProductListView:
    @staticmethod
    def get_optimized_product_list():
        """Optimized product listing for e-commerce"""
        return Product.objects.select_related(
            'category',
            'brand'
        ).filter(
            is_active=True,
            stock_quantity__gt=0
        ).order_by('-created_at')
    
    @staticmethod
    def get_product_search_results(query, category_id=None):
        """Optimized product search with filtering"""
        queryset = Product.objects.select_related(
            'category',
            'brand'
        ).filter(
            is_active=True,
            name__icontains=query
        )
        
        if category_id:
            queryset = queryset.filter(category_id=category_id)
        
        return queryset.order_by('-rating_avg', '-view_count')
```

### 2. prefetch_related() for Reverse Relationships

**Scenario**: YouTube's channel and video optimization

```python
from django.db import models
from django.db.models import Prefetch

# SLOW - Causes N+1 queries for reverse relationships
def get_users_with_orders_slow():
    """Bad example - N+1 queries for reverse relationships"""
    users = User.objects.filter(is_active=True)[:10]
    
    for user in users:
        # Each iteration causes a separate query for user's orders
        orders = user.orders.all()  # N queries
        print(f"{user.username} has {orders.count()} orders")
    
    # Total: 1 (users) + N (orders for each user) queries

# FAST - Uses prefetch_related() for reverse relationships
def get_users_with_orders_optimized():
    """Optimized example - uses prefetch_related()"""
    users = User.objects.prefetch_related('orders').filter(is_active=True)[:10]
    
    for user in users:
        # No additional queries - orders are already prefetched
        orders = user.orders.all()
        print(f"{user.username} has {len(orders)} orders")
    
    # Total: 2 queries (1 for users, 1 for all orders)

# Advanced prefetch_related() with custom querysets
def get_users_with_recent_orders():
    """Prefetch only recent orders for each user"""
    recent_orders_prefetch = Prefetch(
        'orders',
        queryset=Order.objects.select_related('user').filter(
            created_at__gte=timezone.now() - timedelta(days=30)
        ).order_by('-created_at'),
        to_attr='recent_orders'
    )
    
    users = User.objects.prefetch_related(recent_orders_prefetch).filter(
        is_active=True
    )
    
    for user in users:
        # Access prefetched recent orders
        for order in user.recent_orders:
            print(f"{user.username}: Order {order.order_number}")

# Complex prefetch example: E-commerce user dashboard
class UserDashboardService:
    @staticmethod
    def get_user_dashboard_data(user_id):
        """Fetch all user dashboard data efficiently"""
        
        # Define custom prefetch querysets
        recent_orders_prefetch = Prefetch(
            'orders',
            queryset=Order.objects.select_related().filter(
                created_at__gte=timezone.now() - timedelta(days=90)
            ).order_by('-created_at'),
            to_attr='recent_orders'
        )
        
        pending_orders_prefetch = Prefetch(
            'orders',
            queryset=Order.objects.filter(status='pending'),
            to_attr='pending_orders'
        )
        
        # Fetch user with optimized related data
        user = User.objects.prefetch_related(
            recent_orders_prefetch,
            pending_orders_prefetch,
            'orders__order_items__product',  # Deep prefetch
            'orders__order_items__product__category'
        ).get(id=user_id)
        
        return {
            'user': user,
            'recent_orders': user.recent_orders,
            'pending_orders': user.pending_orders,
            'total_orders': user.orders.count()
        }
```

### 3. Database Indexes for Query Performance

**Scenario**: Twitter's timeline optimization

```python
# models.py with strategic indexing
class OptimizedModels:
    
    class User(models.Model):
        username = models.CharField(max_length=150, unique=True)  # Automatic index
        email = models.EmailField(unique=True)  # Automatic index
        first_name = models.CharField(max_length=30)
        last_name = models.CharField(max_length=150)
        is_active = models.BooleanField(default=True, db_index=True)  # Manual index
        created_at = models.DateTimeField(auto_now_add=True, db_index=True)
        last_login = models.DateTimeField(null=True, blank=True, db_index=True)
        
        class Meta:
            # Composite indexes for complex queries
            indexes = [
                models.Index(fields=['is_active', 'last_login']),  # Active user login queries
                models.Index(fields=['created_at', 'is_active']),  # Registration analytics
                models.Index(fields=['-last_login']),  # Recent activity queries
            ]
    
    class Product(models.Model):
        name = models.CharField(max_length=200)
        slug = models.CharField(max_length=200, unique=True)  # Automatic index
        category = models.ForeignKey('Category', on_delete=models.CASCADE)  # Automatic index
        brand = models.ForeignKey('Brand', on_delete=models.CASCADE)  # Automatic index
        price = models.DecimalField(max_digits=10, decimal_places=2, db_index=True)
        is_active = models.BooleanField(default=True, db_index=True)
        is_featured = models.BooleanField(default=False, db_index=True)
        stock_quantity = models.IntegerField(default=0, db_index=True)
        rating_avg = models.DecimalField(max_digits=3, decimal_places=2, default=0)
        view_count = models.IntegerField(default=0)
        created_at = models.DateTimeField(auto_now_add=True)
        
        class Meta:
            indexes = [
                # E-commerce specific composite indexes
                models.Index(fields=['is_active', 'category', 'price']),  # Category browsing
                models.Index(fields=['is_active', 'is_featured', '-rating_avg']),  # Featured products
                models.Index(fields=['is_active', '-view_count', '-rating_avg']),  # Popular products
                models.Index(fields=['is_active', 'stock_quantity']),  # Inventory queries
                models.Index(fields=['-created_at', 'is_active']),  # New arrivals
                models.Index(fields=['category', '-rating_avg', '-view_count']),  # Category top products
            ]
    
    class Order(models.Model):
        user = models.ForeignKey(User, on_delete=models.CASCADE)  # Automatic index
        order_number = models.CharField(max_length=50, unique=True)  # Automatic index
        status = models.CharField(max_length=20, default='pending', db_index=True)
        total_amount = models.DecimalField(max_digits=10, decimal_places=2, db_index=True)
        created_at = models.DateTimeField(auto_now_add=True, db_index=True)
        updated_at = models.DateTimeField(auto_now=True)
        
        class Meta:
            indexes = [
                # Order management indexes
                models.Index(fields=['user', '-created_at']),  # User order history
                models.Index(fields=['status', 'created_at']),  # Status-based queries
                models.Index(fields=['-created_at', 'total_amount']),  # Sales analytics
                models.Index(fields=['user', 'status']),  # User's orders by status
                models.Index(fields=['created_at', 'status', 'total_amount']),  # Comprehensive analytics
            ]

# Query optimization using indexes
class OptimizedQueryService:
    
    @staticmethod
    def get_featured_products_by_category(category_id, limit=20):
        """Uses composite index: is_active, is_featured, -rating_avg"""
        return Product.objects.filter(
            is_active=True,
            is_featured=True,
            category_id=category_id
        ).order_by('-rating_avg')[:limit]
    
    @staticmethod
    def get_popular_products_in_price_range(min_price, max_price, limit=50):
        """Uses multiple indexes efficiently"""
        return Product.objects.filter(
            is_active=True,
            price__gte=min_price,
            price__lte=max_price,
            stock_quantity__gt=0
        ).order_by('-view_count', '-rating_avg')[:limit]
    
    @staticmethod
    def get_user_orders_by_status(user_id, status, limit=10):
        """Uses composite index: user, status"""
        return Order.objects.filter(
            user_id=user_id,
            status=status
        ).order_by('-created_at')[:limit]
    
    @staticmethod
    def get_sales_analytics(start_date, end_date):
        """Uses date and amount indexes for analytics"""
        return Order.objects.filter(
            created_at__gte=start_date,
            created_at__lte=end_date,
            status='completed'
        ).aggregate(
            total_sales=models.Sum('total_amount'),
            order_count=models.Count('id'),
            avg_order_value=models.Avg('total_amount')
        )
```

### 4. Query Profiling and Monitoring

**Scenario**: Netflix's query performance monitoring

```python
import time
from django.db import connection
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class QueryProfiler:
    """Profile Django database queries for performance optimization"""
    
    def __init__(self):
        self.reset_queries()
    
    def reset_queries(self):
        """Reset query tracking"""
        if settings.DEBUG:
            connection.queries_log.clear()
    
    def get_query_stats(self):
        """Get detailed query statistics"""
        if not settings.DEBUG:
            return {"error": "DEBUG must be True for query profiling"}
        
        queries = connection.queries
        total_time = sum(float(query['time']) for query in queries)
        
        return {
            'total_queries': len(queries),
            'total_time': round(total_time, 4),
            'queries': queries
        }
    
    def profile_function(self, func, *args, **kwargs):
        """Profile a function's database queries"""
        self.reset_queries()
        start_time = time.time()
        
        result = func(*args, **kwargs)
        
        end_time = time.time()
        stats = self.get_query_stats()
        stats['execution_time'] = round(end_time - start_time, 4)
        
        return result, stats

class QueryOptimizationService:
    """Service for query optimization analysis"""
    
    @staticmethod
    def analyze_slow_queries():
        """Identify and analyze slow queries"""
        from django.db import connection
        
        with connection.cursor() as cursor:
            # PostgreSQL slow query analysis
            cursor.execute("""
                SELECT 
                    query,
                    calls,
                    total_time,
                    mean_time,
                    rows,
                    100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) AS hit_percent
                FROM pg_stat_statements 
                WHERE mean_time > 100  -- Queries taking more than 100ms
                ORDER BY mean_time DESC 
                LIMIT 20
            """)
            
            return cursor.fetchall()
    
    @staticmethod
    def get_query_execution_plan(sql):
        """Get PostgreSQL execution plan for query optimization"""
        from django.db import connection
        
        with connection.cursor() as cursor:
            cursor.execute(f"EXPLAIN ANALYZE {sql}")
            return cursor.fetchall()
    
    @staticmethod
    def monitor_index_usage():
        """Monitor index usage to identify unused indexes"""
        from django.db import connection
        
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    schemaname,
                    tablename,
                    indexname,
                    idx_scan,
                    idx_tup_read,
                    idx_tup_fetch
                FROM pg_stat_user_indexes
                WHERE idx_scan < 10  -- Rarely used indexes
                ORDER BY idx_scan ASC
            """)
            
            return cursor.fetchall()

# Performance testing decorators
def profile_queries(func):
    """Decorator to profile database queries"""
    def wrapper(*args, **kwargs):
        profiler = QueryProfiler()
        result, stats = profiler.profile_function(func, *args, **kwargs)
        
        # Log performance metrics
        logger.info(
            f"Function {func.__name__}: "
            f"{stats['total_queries']} queries, "
            f"{stats['total_time']}s DB time, "
            f"{stats['execution_time']}s total time"
        )
        
        # Alert on performance issues
        if stats['total_queries'] > 50 or stats['total_time'] > 1.0:
            logger.warning(
                f"Performance issue in {func.__name__}: "
                f"Too many queries ({stats['total_queries']}) "
                f"or slow execution ({stats['total_time']}s)"
            )
        
        return result
    
    return wrapper

# Example usage of profiling
@profile_queries
def get_user_dashboard_slow():
    """Example of unoptimized dashboard query"""
    users = User.objects.all()[:10]
    
    dashboard_data = []
    for user in users:
        # N+1 queries - will trigger performance alerts
        recent_orders = user.orders.all()[:5]
        total_spent = sum(order.total_amount for order in user.orders.all())
        
        dashboard_data.append({
            'user': user,
            'recent_orders': recent_orders,
            'total_spent': total_spent
        })
    
    return dashboard_data

@profile_queries
def get_user_dashboard_optimized():
    """Optimized dashboard query"""
    users = User.objects.prefetch_related(
        Prefetch(
            'orders',
            queryset=Order.objects.order_by('-created_at')[:5],
            to_attr='recent_orders'
        )
    ).annotate(
        total_spent=models.Sum('orders__total_amount')
    )[:10]
    
    dashboard_data = []
    for user in users:
        dashboard_data.append({
            'user': user,
            'recent_orders': user.recent_orders,
            'total_spent': user.total_spent or 0
        })
    
    return dashboard_data
```

## ⚡ Advanced Optimization Strategies

### 5. Database-Level Optimizations

**Scenario**: Amazon's inventory management optimization

```python
from django.db import models, connection
from django.db.models import F, Q, Exists, OuterRef, Subquery

class AdvancedOptimizationTechniques:
    
    @staticmethod
    def bulk_update_inventory():
        """Efficient bulk inventory updates"""
        # Use bulk operations instead of individual saves
        products_to_update = []
        
        inventory_updates = [
            {'id': 1, 'stock_quantity': 45},
            {'id': 2, 'stock_quantity': 30},
            {'id': 3, 'stock_quantity': 25},
        ]
        
        for update in inventory_updates:
            product = Product(id=update['id'])
            product.stock_quantity = update['stock_quantity']
            products_to_update.append(product)
        
        # Single query instead of N queries
        Product.objects.bulk_update(products_to_update, ['stock_quantity'])
    
    @staticmethod
    def efficient_exists_queries():
        """Use Exists() for efficient existence checks"""
        
        # SLOW - Loads all related objects
        users_with_orders_slow = User.objects.filter(orders__isnull=False).distinct()
        
        # FAST - Uses EXISTS subquery
        users_with_orders_fast = User.objects.filter(
            Exists(Order.objects.filter(user=OuterRef('pk')))
        )
        
        return users_with_orders_fast
    
    @staticmethod
    def optimized_aggregations():
        """Efficient aggregation queries"""
        
        # Use subqueries for complex aggregations
        newest_order_subquery = Order.objects.filter(
            user=OuterRef('pk')
        ).order_by('-created_at').values('created_at')[:1]
        
        users_with_stats = User.objects.annotate(
            order_count=models.Count('orders'),
            total_spent=models.Sum('orders__total_amount'),
            latest_order_date=Subquery(newest_order_subquery)
        ).filter(order_count__gt=0)
        
        return users_with_stats
    
    @staticmethod
    def efficient_filtering():
        """Optimize complex filtering operations"""
        
        # Use F expressions for database-level comparisons
        profitable_products = Product.objects.filter(
            price__gt=F('cost_price') * 1.5  # 50% markup minimum
        )
        
        # Combine filters efficiently
        popular_affordable_products = Product.objects.filter(
            Q(is_active=True) &
            Q(stock_quantity__gt=0) &
            Q(price__lt=500) &
            Q(rating_avg__gte=4.0) &
            Q(view_count__gte=100)
        ).select_related('category', 'brand')
        
        return popular_affordable_products

class CacheOptimizedQueryService:
    """Implement query-level caching for expensive operations"""
    
    @staticmethod
    @lru_cache(maxsize=100)
    def get_category_product_counts():
        """Cached category product counts"""
        return dict(
            Product.objects.filter(is_active=True)
            .values('category__name')
            .annotate(count=models.Count('id'))
            .values_list('category__name', 'count')
        )
    
    @staticmethod
    def get_trending_products(cache_timeout=300):
        """Get trending products with caching"""
        from django.core.cache import cache
        
        cache_key = 'trending_products'
        trending = cache.get(cache_key)
        
        if trending is None:
            # Expensive query - calculate trending score
            trending = Product.objects.annotate(
                trending_score=models.F('view_count') * 0.3 + 
                              models.F('sales_count') * 0.7
            ).filter(
                is_active=True,
                created_at__gte=timezone.now() - timedelta(days=30)
            ).order_by('-trending_score')[:20]
            
            # Cache for 5 minutes
            cache.set(cache_key, list(trending), cache_timeout)
        
        return trending
```

### 6. Real-World Performance Monitoring

**Scenario**: Facebook's query performance dashboard

```python
import time
import hashlib
from django.db import connection
from django.core.management.base import BaseCommand
from django.utils import timezone

class QueryPerformanceMonitor:
    """Monitor and log query performance in production"""
    
    @staticmethod
    def log_query_performance(query_type, start_time, end_time, rows_returned, query_sql, user_id=None):
        """Log query performance metrics"""
        execution_time = (end_time - start_time) * 1000  # Convert to milliseconds
        query_hash = hashlib.md5(query_sql.encode()).hexdigest()
        
        # Log to performance tracking table
        QueryPerformanceLog.objects.create(
            query_type=query_type,
            execution_time_ms=execution_time,
            rows_returned=rows_returned,
            query_hash=query_hash,
            query_sql=query_sql[:1000],  # Truncate long queries
            user_id=user_id,
            timestamp=timezone.now()
        )
        
        # Alert on slow queries
        if execution_time > 1000:  # > 1 second
            import logging
            logger = logging.getLogger('slow_queries')
            logger.warning(f"Slow query detected: {query_type} took {execution_time}ms")
    
    @staticmethod
    def monitor_query_decorator(query_type):
        """Decorator to monitor query performance"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                start_time = time.time()
                result = func(*args, **kwargs)
                end_time = time.time()
                
                # Get query count and SQL
                if hasattr(result, 'count'):
                    rows_returned = result.count() if callable(result.count) else len(result)
                else:
                    rows_returned = 1
                
                # Log performance
                QueryPerformanceMonitor.log_query_performance(
                    query_type=query_type,
                    start_time=start_time,
                    end_time=end_time,
                    rows_returned=rows_returned,
                    query_sql=str(connection.queries[-1]['sql']) if connection.queries else ''
                )
                
                return result
            return wrapper
        return decorator

# Management command for performance analysis
class Command(BaseCommand):
    help = 'Analyze database performance and suggest optimizations'
    
    def handle(self, *args, **options):
        self.analyze_slow_queries()
        self.check_missing_indexes()
        self.analyze_query_patterns()
    
    def analyze_slow_queries(self):
        """Analyze slow queries from performance logs"""
        slow_queries = QueryPerformanceLog.objects.filter(
            execution_time_ms__gt=1000,
            timestamp__gte=timezone.now() - timedelta(hours=24)
        ).values('query_type', 'query_hash').annotate(
            avg_time=models.Avg('execution_time_ms'),
            count=models.Count('id'),
            max_time=models.Max('execution_time_ms')
        ).order_by('-avg_time')
        
        self.stdout.write("🐌 Slow Queries (last 24 hours):")
        for query in slow_queries:
            self.stdout.write(
                f"  {query['query_type']}: {query['avg_time']:.2f}ms avg, "
                f"{query['max_time']:.2f}ms max, {query['count']} occurrences"
            )
    
    def check_missing_indexes(self):
        """Check for potentially missing indexes"""
        with connection.cursor() as cursor:
            # PostgreSQL query to find table scans
            cursor.execute("""
                SELECT 
                    schemaname,
                    tablename,
                    seq_scan,
                    seq_tup_read,
                    idx_scan,
                    seq_tup_read / seq_scan as avg_seq_read
                FROM pg_stat_user_tables
                WHERE seq_scan > 1000 AND seq_tup_read / seq_scan > 10000
                ORDER BY seq_tup_read DESC
            """)
            
            results = cursor.fetchall()
            
        self.stdout.write("🔍 Tables with potential missing indexes:")
        for result in results:
            self.stdout.write(
                f"  {result[0]}.{result[1]}: {result[2]} seq scans, "
                f"{result[4]:.0f} avg rows per scan"
            )
```

## 🎯 Key Takeaways

1. **Use select_related() for forward relationships** → Eliminates N+1 queries with JOINs
2. **Use prefetch_related() for reverse relationships** → Efficient fetching of related objects
3. **Strategic database indexing** → Composite indexes for complex query patterns
4. **Query profiling and monitoring** → Identify and fix performance bottlenecks
5. **Bulk operations for data modifications** → bulk_create(), bulk_update() for efficiency
6. **Exists() for existence checks** → More efficient than loading full objects
7. **Cache expensive queries** → Reduce database load for repeated operations

Database optimization is essential for Django applications to scale efficiently and provide excellent user experiences!
''',
    "difficulty": "advanced",
    "estimated_time": 55,
    "xp_reward": 35,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-aggregation"],
    "exercises": [
        {
            "id": "optimization_1",
            "title": "Explore Performance Test Database",
            "prompt": "Let's examine our performance optimization database. Write a query to see the users table structure and sample data.",
            "table_name": "users",
            "initial_query": "SELECT * FROM users LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "users"],
            "hint": "Use SELECT * FROM users LIMIT 5; to see the user data structure with performance fields",
            "solution": "SELECT * FROM users LIMIT 5;",
            "explanation": "This users table includes fields optimized for performance queries: indexed email, is_active, date_joined fields, and JSONB profile_data with GIN index for fast JSON queries. These indexes support common user lookup and filtering patterns."
        },
        {
            "id": "optimization_2",
            "title": "Product Query Performance Analysis",
            "prompt": "Analyze product data for optimization opportunities. Write a query to see products with their performance metrics like view_count and sales_count.",
            "table_name": "products",
            "expected_keywords": ["SELECT", "name", "view_count", "sales_count", "rating_avg"],
            "hint": "Select product name and performance metrics to analyze popularity patterns",
            "solution": "SELECT name, price, view_count, sales_count, rating_avg, is_featured FROM products ORDER BY view_count DESC;",
            "explanation": "This query shows product performance data. The indexes on view_count, sales_count, and rating_avg enable fast sorting for 'popular products' queries. Django's select_related() and strategic filtering on these indexed fields prevent slow table scans."
        },
        {
            "id": "optimization_3",
            "title": "Order Performance with User Relationships",
            "prompt": "Examine order data to understand N+1 query scenarios. Write a query joining orders with users to see the relationship pattern.",
            "table_name": "orders",
            "expected_keywords": ["SELECT", "JOIN", "users", "order_number", "username"],
            "hint": "JOIN orders with users to see the foreign key relationship that causes N+1 queries",
            "solution": "SELECT o.order_number, o.total_amount, o.status, u.username, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC;",
            "explanation": "This JOIN demonstrates the user-order relationship that causes N+1 queries in Django when not optimized. Using select_related('user') in Django would fetch this data in a single query instead of 1 + N separate queries."
        },
        {
            "id": "optimization_4",
            "title": "Query Performance Monitoring Data",
            "prompt": "Look at query performance logs to identify optimization opportunities. Write a query to see slow queries and their execution times.",
            "table_name": "query_performance_logs",
            "expected_keywords": ["SELECT", "query_type", "execution_time_ms", "WHERE", ">"],
            "hint": "Filter for queries with high execution times to identify performance issues",
            "solution": "SELECT query_type, execution_time_ms, rows_returned, endpoint FROM query_performance_logs WHERE execution_time_ms > 50 ORDER BY execution_time_ms DESC;",
            "explanation": "Query performance monitoring helps identify slow operations. The product_search query taking 156ms suggests need for better indexing or query optimization. Django's query profiling tools help identify these patterns in production."
        },
        {
            "id": "optimization_5",
            "title": "Order Items Analysis for Prefetch Scenarios",
            "prompt": "Examine order items to understand reverse relationship queries. Write a query to see order items with their product and order information.",
            "table_name": "order_items",
            "expected_keywords": ["SELECT", "JOIN", "products", "orders", "quantity"],
            "hint": "JOIN order_items with both products and orders to see the multi-table relationships",
            "solution": "SELECT oi.quantity, oi.total_price, p.name as product_name, o.order_number FROM order_items oi JOIN products p ON oi.product_id = p.id JOIN orders o ON oi.order_id = o.id;",
            "explanation": "This query shows complex relationships that benefit from Django's prefetch_related(). When fetching orders with their items and products, using prefetch_related('order_items__product') prevents N+1 queries by efficiently fetching all related data."
        },
        {
            "id": "optimization_6",
            "title": "User Activity and Performance Correlation",
            "prompt": "Analyze user engagement patterns. Write a query to find users with multiple orders and their total spending for optimization insights.",
            "table_name": "orders",
            "expected_keywords": ["SELECT", "user_id", "COUNT", "SUM", "GROUP BY", "HAVING"],
            "hint": "Group by user_id and use aggregation functions to find high-value customers",
            "solution": "SELECT user_id, COUNT(*) as order_count, SUM(total_amount) as total_spent, AVG(total_amount) as avg_order_value FROM orders GROUP BY user_id HAVING COUNT(*) > 1 ORDER BY total_spent DESC;",
            "explanation": "This aggregation query identifies high-value users and would benefit from Django's annotate() with Count() and Sum(). The composite index on (user_id, created_at) enables efficient user order analytics without full table scans."
        }
    ],
    "key_concepts": [
        "select_related() for Forward Relationship Optimization",
        "prefetch_related() for Reverse Relationship Efficiency",
        "Strategic Database Indexing Patterns",
        "N+1 Query Problem Prevention",
        "Query Profiling and Performance Monitoring",
        "Bulk Operations for Data Modifications",
        "Database-Level Query Optimization",
        "Production Performance Analysis Techniques"
    ]
}