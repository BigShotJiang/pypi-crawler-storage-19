"""
Django Async Development - Lesson 1: Async Fundamentals and ASGI
Master Django's async capabilities for high-performance web applications
"""

DJANGO_ASYNC_FUNDAMENTALS_LESSON = {
    "id": 59,
    "chapter": 59,
    "title": "Django Async Fundamentals: Building High-Performance Applications",
    "slug": "django-async-fundamentals",
    "description": "Learn Django's async support including async views, ASGI deployment, and performance optimization",
    "content": '''# Django Async Fundamentals: Building High-Performance Applications

## 🎯 Building on Django Async Foundations

**Building on our async class-based views knowledge**, this lesson explores Django's **complete async ecosystem** - from ASGI deployment to production monitoring. While we've learned to make individual views async, now we'll master **application-wide async architecture**.

**Advanced Async Concepts**:
- **ASGI vs WSGI deployment** → Moving beyond development to production async
- **Async middleware pipeline** → Request processing that scales with load
- **Database async patterns** → Moving beyond external APIs to database efficiency
- **Real-time streaming** → Server-Sent Events and WebSocket integration
- **Performance monitoring** → Measuring and optimizing async applications

Think of this as **upgrading from async roads to a complete async transportation system** - infrastructure, monitoring, and optimization.

## 💾 Async Performance Monitoring Database

Let's create a comprehensive database for monitoring async application performance:

```sql
-- ASYNC PERFORMANCE MONITORING DATABASE
-- Database: async_performance

-- Request performance tracking for async vs sync comparison
CREATE TABLE request_performance (
    id SERIAL PRIMARY KEY,
    endpoint VARCHAR(200) NOT NULL,
    method VARCHAR(10) NOT NULL,
    is_async BOOLEAN NOT NULL,
    response_time_ms DECIMAL(8, 3) NOT NULL,
    concurrent_requests INTEGER DEFAULT 1,
    memory_usage_mb DECIMAL(8, 2),
    cpu_usage_percent DECIMAL(5, 2),
    database_queries INTEGER DEFAULT 0,
    database_time_ms DECIMAL(8, 3) DEFAULT 0,
    cache_hits INTEGER DEFAULT 0,
    cache_misses INTEGER DEFAULT 0,
    user_id INTEGER,
    session_id VARCHAR(64),
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample performance data comparing async vs sync
INSERT INTO request_performance (endpoint, method, is_async, response_time_ms, concurrent_requests, memory_usage_mb, cpu_usage_percent, database_queries, database_time_ms, user_id) VALUES
('/api/products/', 'GET', true, 45.2, 100, 85.4, 15.2, 3, 28.5, 1001),
('/api/products/', 'GET', false, 156.7, 100, 245.8, 78.3, 3, 28.5, 1002),
('/api/users/profile/', 'GET', true, 23.1, 50, 42.1, 8.7, 2, 15.3, 1003),
('/api/users/profile/', 'GET', false, 89.4, 50, 128.9, 34.2, 2, 15.3, 1004),
('/api/orders/create/', 'POST', true, 67.8, 25, 65.2, 12.4, 5, 45.2, 1005),
('/api/orders/create/', 'POST', false, 234.5, 25, 189.7, 58.9, 5, 45.2, 1006),
('/ws/notifications/', 'WS', true, 12.3, 500, 156.7, 22.1, 1, 8.9, 1007),
('/api/search/', 'GET', true, 89.1, 200, 78.3, 18.5, 4, 56.7, 1008),
('/api/search/', 'GET', false, 345.6, 200, 312.4, 89.2, 4, 56.7, 1009);

-- Connection pool monitoring for async applications
CREATE TABLE connection_pools (
    id SERIAL PRIMARY KEY,
    pool_name VARCHAR(100) NOT NULL,
    pool_type VARCHAR(50) NOT NULL, -- 'database', 'redis', 'external_api'
    max_connections INTEGER NOT NULL,
    active_connections INTEGER DEFAULT 0,
    idle_connections INTEGER DEFAULT 0,
    waiting_connections INTEGER DEFAULT 0,
    total_requests BIGINT DEFAULT 0,
    failed_requests INTEGER DEFAULT 0,
    avg_wait_time_ms DECIMAL(8, 3) DEFAULT 0,
    avg_execution_time_ms DECIMAL(8, 3) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample connection pool data
INSERT INTO connection_pools (pool_name, pool_type, max_connections, active_connections, idle_connections, waiting_connections, total_requests, avg_wait_time_ms, avg_execution_time_ms) VALUES
('postgres_async', 'database', 50, 15, 25, 0, 45670, 5.2, 23.4),
('redis_async', 'redis', 20, 8, 10, 0, 89234, 1.8, 4.7),
('elasticsearch_async', 'external_api', 15, 5, 8, 2, 12456, 12.3, 67.8),
('postgres_sync', 'database', 50, 35, 5, 10, 23789, 45.7, 89.2),
('third_party_api', 'external_api', 10, 7, 2, 1, 8934, 234.5, 567.9);

-- WebSocket connection tracking
CREATE TABLE websocket_connections (
    id SERIAL PRIMARY KEY,
    connection_id VARCHAR(64) UNIQUE NOT NULL,
    user_id INTEGER,
    channel_name VARCHAR(100) NOT NULL,
    connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    disconnected_at TIMESTAMP,
    messages_sent INTEGER DEFAULT 0,
    messages_received INTEGER DEFAULT 0,
    connection_duration_seconds INTEGER,
    disconnect_reason VARCHAR(100),
    client_ip INET,
    user_agent TEXT
);

-- Sample WebSocket connection data
INSERT INTO websocket_connections (connection_id, user_id, channel_name, connected_at, last_activity, messages_sent, messages_received, client_ip) VALUES
('ws_conn_abc123', 1001, 'notifications', '2024-12-20 10:30:00', '2024-12-20 11:45:00', 23, 45, '192.168.1.100'),
('ws_conn_def456', 1002, 'chat_room_1', '2024-12-20 10:15:00', '2024-12-20 11:50:00', 78, 92, '192.168.1.101'),
('ws_conn_ghi789', 1003, 'live_updates', '2024-12-20 09:45:00', '2024-12-20 11:48:00', 12, 156, '192.168.1.102'),
('ws_conn_jkl000', NULL, 'public_feed', '2024-12-20 11:00:00', '2024-12-20 11:47:00', 5, 34, '192.168.1.103');

-- Async task queue monitoring
CREATE TABLE async_tasks (
    id SERIAL PRIMARY KEY,
    task_id VARCHAR(64) UNIQUE NOT NULL,
    task_name VARCHAR(200) NOT NULL,
    task_type VARCHAR(50) NOT NULL, -- 'background', 'scheduled', 'webhook'
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'running', 'completed', 'failed'
    priority INTEGER DEFAULT 0,
    scheduled_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    execution_time_ms INTEGER,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    error_message TEXT,
    task_data JSONB DEFAULT '{}',
    result_data JSONB DEFAULT '{}',
    worker_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample async task data
INSERT INTO async_tasks (task_id, task_name, task_type, status, scheduled_at, started_at, completed_at, execution_time_ms, task_data) VALUES
('task_email_001', 'send_welcome_email', 'background', 'completed', '2024-12-20 10:30:00', '2024-12-20 10:30:05', '2024-12-20 10:30:12', 7234, '{"user_id": 1001, "template": "welcome"}'),
('task_backup_002', 'database_backup', 'scheduled', 'completed', '2024-12-20 02:00:00', '2024-12-20 02:00:01', '2024-12-20 02:15:34', 934000, '{"tables": ["users", "orders"], "compress": true}'),
('task_webhook_003', 'process_payment', 'webhook', 'running', '2024-12-20 11:45:00', '2024-12-20 11:45:02', NULL, NULL, '{"payment_id": "pay_123", "amount": 99.99}'),
('task_report_004', 'generate_analytics', 'scheduled', 'failed', '2024-12-20 06:00:00', '2024-12-20 06:00:03', '2024-12-20 06:02:15', 132000, '{"date_range": "2024-12-19", "format": "pdf"}'),
('task_notification_005', 'push_notification', 'background', 'pending', '2024-12-20 11:50:00', NULL, NULL, NULL, '{"user_ids": [1001, 1002], "message": "New feature available"}');

-- Real-time event streaming for async applications
CREATE TABLE event_streams (
    id SERIAL PRIMARY KEY,
    stream_name VARCHAR(100) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    event_data JSONB NOT NULL,
    user_id INTEGER,
    session_id VARCHAR(64),
    correlation_id VARCHAR(64),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    subscribers_notified INTEGER DEFAULT 0,
    delivery_attempts INTEGER DEFAULT 0,
    last_delivery_attempt TIMESTAMP
);

-- Sample event stream data
INSERT INTO event_streams (stream_name, event_type, event_data, user_id, session_id, subscribers_notified) VALUES
('user_activity', 'user.login', '{"user_id": 1001, "login_method": "password", "ip": "192.168.1.100"}', 1001, 'sess_abc123', 3),
('order_processing', 'order.created', '{"order_id": "ord_001", "total": 299.99, "items": 2}', 1002, 'sess_def456', 5),
('notification_center', 'message.sent', '{"from_user": 1001, "to_user": 1002, "message_type": "direct"}', 1001, 'sess_abc123', 1),
('analytics_tracking', 'page.view', '{"page": "/products/camera", "duration": 45, "scroll_depth": 75}', 1003, 'sess_ghi789', 2),
('system_monitoring', 'server.alert', '{"alert_type": "high_memory", "value": 85.4, "threshold": 80}', NULL, NULL, 8);

-- ASGI application metrics
CREATE TABLE asgi_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(12, 4) NOT NULL,
    metric_unit VARCHAR(20),
    tags JSONB DEFAULT '{}',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    application_instance VARCHAR(100),
    environment VARCHAR(20) DEFAULT 'production'
);

-- Sample ASGI metrics
INSERT INTO asgi_metrics (metric_name, metric_value, metric_unit, tags, application_instance, environment) VALUES
('concurrent_connections', 1247.0000, 'count', '{"protocol": "http"}', 'app-server-1', 'production'),
('websocket_connections', 523.0000, 'count', '{"channel": "all"}', 'app-server-1', 'production'),
('request_rate', 156.7500, 'requests_per_second', '{"method": "GET"}', 'app-server-1', 'production'),
('response_time_p95', 89.2300, 'milliseconds', '{"endpoint": "/api"}', 'app-server-1', 'production'),
('memory_usage', 78.5600, 'percent', '{"process": "django"}', 'app-server-1', 'production'),
('async_task_queue_size', 23.0000, 'count', '{"queue": "default"}', 'app-server-1', 'production'),
('database_pool_utilization', 65.2100, 'percent', '{"pool": "async"}', 'app-server-1', 'production');
```

## 🔧 Django ASGI and Async Views

### 1. ASGI Configuration and Setup

**Scenario**: Discord's real-time messaging infrastructure  
*Building on our async ListView knowledge from the previous lesson*

```python
# asgi.py - ASGI application configuration
import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import chat.routing

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'discord_clone.settings')

# Initialize Django ASGI application early
django_asgi_app = get_asgi_application()

application = ProtocolTypeRouter({
    # HTTP traffic goes to Django views
    "http": django_asgi_app,
    
    # WebSocket traffic goes to Channels consumers
    "websocket": AuthMiddlewareStack(
        URLRouter(
            chat.routing.websocket_urlpatterns
        )
    ),
})

# settings.py - Async-optimized configuration
import os

# ASGI configuration
ASGI_APPLICATION = 'discord_clone.asgi.application'

# Database configuration for async
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'discord_async',
        'USER': 'discord_user',
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': 'localhost',
        'PORT': '5432',
        'OPTIONS': {
            # Disable persistent connections for async
            'CONN_MAX_AGE': 0,
            # Enable async database operations
            'OPTIONS': {
                'sslmode': 'require',
            }
        },
    }
}

# Cache configuration for async
CACHES = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [('127.0.0.1', 6379)],
        },
    },
}

# Channel layer for WebSocket support
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [('127.0.0.1', 6379)],
            "capacity": 1500,  # Maximum messages in a channel
            "expiry": 60,      # Message expiry time
        },
    },
}

# Async middleware configuration
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    # Note: Session and CSRF middleware can impact async performance
    'discord_clone.middleware.AsyncLoggingMiddleware',
    'discord_clone.middleware.AsyncPerformanceMiddleware',
]

# Async-specific settings
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'async_file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': 'async_performance.log',
        },
    },
    'loggers': {
        'async_performance': {
            'handlers': ['async_file'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}
```

### 2. Async Function-Based Views and Advanced Patterns

**Scenario**: Twitter's real-time timeline and notifications  
*Extending the async patterns we learned in async class-based views*

```python
# views.py - Async function-based view implementations
import asyncio
import aiohttp
from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import aget_object_or_404
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
from asgiref.sync import sync_to_async, async_to_sync
import json
import time

# Async function-based views (complementing our async class-based views)
async def twitter_timeline_async(request):
    """Async function-based view for Twitter-style timeline
    Building on the async ListView patterns we've learned"""
    user_id = request.user.id if request.user.is_authenticated else None
    
    if not user_id:
        return JsonResponse({'error': 'Authentication required'}, status=401)
    
    try:
        # Fetch user's timeline data asynchronously
        timeline_data = await fetch_timeline_async(user_id)
        
        # Get real-time updates from multiple sources concurrently
        notifications, trending, suggested_follows = await asyncio.gather(
            fetch_notifications_async(user_id),
            fetch_trending_topics_async(),
            fetch_suggested_follows_async(user_id),
            return_exceptions=True
        )
        
        # Handle any exceptions from concurrent operations
        if isinstance(notifications, Exception):
            notifications = []
        if isinstance(trending, Exception):
            trending = []
        if isinstance(suggested_follows, Exception):
            suggested_follows = []
        
        response_data = {
            'timeline': timeline_data,
            'notifications': notifications,
            'trending': trending,
            'suggested_follows': suggested_follows,
            'timestamp': time.time()
        }
        
        return JsonResponse(response_data)
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

async def fetch_timeline_async(user_id):
    """Fetch timeline posts asynchronously"""
    from myapp.models import Post, User
    
    # Get user's followed users
    user = await User.objects.aget(id=user_id)
    followed_users = await sync_to_async(list)(
        user.following.all().values_list('id', flat=True)
    )
    
    # Fetch timeline posts with async database operations
    timeline_posts = []
    async for post in Post.objects.filter(
        author_id__in=followed_users + [user_id]
    ).select_related('author').order_by('-created_at')[:50]:
        
        # Convert model instance to dict
        post_data = {
            'id': post.id,
            'content': post.content,
            'author': {
                'id': post.author.id,
                'username': post.author.username,
                'display_name': post.author.get_full_name(),
            },
            'created_at': post.created_at.isoformat(),
            'like_count': post.like_count,
            'retweet_count': post.retweet_count,
        }
        timeline_posts.append(post_data)
    
    return timeline_posts

async def fetch_notifications_async(user_id):
    """Fetch user notifications asynchronously"""
    from myapp.models import Notification
    
    notifications = []
    async for notification in Notification.objects.filter(
        user_id=user_id,
        is_read=False
    ).order_by('-created_at')[:20]:
        
        notification_data = {
            'id': notification.id,
            'type': notification.notification_type,
            'message': notification.message,
            'created_at': notification.created_at.isoformat(),
            'data': notification.data,
        }
        notifications.append(notification_data)
    
    return notifications

async def fetch_trending_topics_async():
    """Fetch trending topics from external API asynchronously"""
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(
                'https://api.trending.com/topics',
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('trending', [])
                else:
                    return []
        except asyncio.TimeoutError:
            return []
        except Exception:
            return []

async def fetch_suggested_follows_async(user_id):
    """Generate suggested follows based on user's interests"""
    from myapp.models import User
    
    # Simulate ML-based recommendation algorithm
    await asyncio.sleep(0.1)  # Simulate processing time
    
    suggested_users = []
    async for user in User.objects.exclude(
        id=user_id
    ).filter(
        is_active=True
    ).order_by('-follower_count')[:10]:
        
        user_data = {
            'id': user.id,
            'username': user.username,
            'display_name': user.get_full_name(),
            'follower_count': user.follower_count,
            'bio': user.bio,
        }
        suggested_users.append(user_data)
    
    return suggested_users

# Async class-based views
class TwitterAPIViewAsync(View):
    """Base async class-based view for Twitter API"""
    
    @method_decorator(csrf_exempt)
    async def dispatch(self, request, *args, **kwargs):
        """Override dispatch to handle async methods"""
        # Check authentication
        if not request.user.is_authenticated:
            return JsonResponse({'error': 'Authentication required'}, status=401)
        
        # Call the appropriate async method
        method = request.method.lower()
        if hasattr(self, method):
            handler = getattr(self, method)
            if asyncio.iscoroutinefunction(handler):
                return await handler(request, *args, **kwargs)
            else:
                # Fallback to sync handling
                return handler(request, *args, **kwargs)
        else:
            return JsonResponse({'error': 'Method not allowed'}, status=405)

class TweetCreateAsync(TwitterAPIViewAsync):
    """Async view for creating tweets"""
    
    async def post(self, request):
        """Handle tweet creation asynchronously"""
        try:
            data = json.loads(request.body)
            content = data.get('content', '').strip()
            
            if not content:
                return JsonResponse({'error': 'Content is required'}, status=400)
            
            if len(content) > 280:
                return JsonResponse({'error': 'Content too long'}, status=400)
            
            # Create tweet asynchronously
            from myapp.models import Post
            
            tweet = await Post.objects.acreate(
                author=request.user,
                content=content,
                post_type='tweet'
            )
            
            # Notify followers asynchronously (background task)
            asyncio.create_task(notify_followers_async(request.user.id, tweet.id))
            
            # Update user's tweet count
            await User.objects.filter(id=request.user.id).aupdate(
                tweet_count=models.F('tweet_count') + 1
            )
            
            response_data = {
                'tweet': {
                    'id': tweet.id,
                    'content': tweet.content,
                    'created_at': tweet.created_at.isoformat(),
                    'author': {
                        'id': request.user.id,
                        'username': request.user.username,
                    }
                }
            }
            
            return JsonResponse(response_data, status=201)
            
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

async def notify_followers_async(user_id, tweet_id):
    """Background task to notify followers of new tweet"""
    from myapp.models import User, Notification
    
    try:
        user = await User.objects.aget(id=user_id)
        followers = []
        
        async for follower in user.followers.all():
            followers.append(follower.id)
        
        # Create notifications for followers in batches
        notifications = []
        for follower_id in followers:
            notification = Notification(
                user_id=follower_id,
                notification_type='new_tweet',
                message=f'{user.username} posted a new tweet',
                data={'tweet_id': tweet_id, 'author_id': user_id}
            )
            notifications.append(notification)
        
        # Bulk create notifications
        await sync_to_async(Notification.objects.bulk_create)(notifications)
        
    except Exception as e:
        # Log error but don't fail the main request
        import logging
        logger = logging.getLogger('async_performance')
        logger.error(f"Failed to notify followers: {e}")
```

### 3. Streaming Responses and Server-Sent Events

**Scenario**: YouTube's live streaming and real-time comments

```python
# streaming_views.py - Real-time data streaming
import asyncio
import json
import time
from django.http import StreamingHttpResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from asgiref.sync import sync_to_async

async def youtube_live_stream_data(request, stream_id):
    """Server-Sent Events for live stream data"""
    
    async def event_stream():
        """Generate server-sent events for live stream"""
        
        # Set up SSE headers
        yield "data: {\"type\": \"connected\", \"stream_id\": \"" + stream_id + "\"}\n\n"
        
        # Stream live data continuously
        while True:
            try:
                # Get real-time stream metrics
                stream_data = await get_live_stream_metrics(stream_id)
                
                # Send viewer count update
                event_data = {
                    "type": "viewer_count",
                    "count": stream_data.get('viewers', 0),
                    "timestamp": time.time()
                }
                yield f"data: {json.dumps(event_data)}\n\n"
                
                # Send live comments
                comments = await get_recent_comments(stream_id)
                for comment in comments:
                    comment_data = {
                        "type": "comment",
                        "comment": comment,
                        "timestamp": time.time()
                    }
                    yield f"data: {json.dumps(comment_data)}\n\n"
                
                # Send stream quality metrics
                quality_data = await get_stream_quality_metrics(stream_id)
                quality_event = {
                    "type": "quality",
                    "metrics": quality_data,
                    "timestamp": time.time()
                }
                yield f"data: {json.dumps(quality_event)}\n\n"
                
                # Wait before next update
                await asyncio.sleep(2)
                
            except Exception as e:
                error_data = {
                    "type": "error",
                    "message": str(e),
                    "timestamp": time.time()
                }
                yield f"data: {json.dumps(error_data)}\n\n"
                break
    
    return StreamingHttpResponse(
        event_stream(),
        content_type='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*',
        }
    )

async def get_live_stream_metrics(stream_id):
    """Get real-time stream metrics"""
    from myapp.models import LiveStream
    
    try:
        stream = await LiveStream.objects.aget(id=stream_id)
        return {
            'viewers': await get_concurrent_viewers(stream_id),
            'duration': (time.time() - stream.started_at.timestamp()) / 60,  # minutes
            'quality': stream.quality,
            'bitrate': stream.bitrate,
            'status': stream.status
        }
    except LiveStream.DoesNotExist:
        return {'viewers': 0, 'status': 'offline'}

async def get_concurrent_viewers(stream_id):
    """Get current viewer count from Redis or database"""
    # In production, this would check Redis or WebSocket connections
    import random
    return random.randint(100, 10000)  # Simulated viewer count

async def get_recent_comments(stream_id):
    """Get recent live comments"""
    from myapp.models import LiveComment
    
    comments = []
    async for comment in LiveComment.objects.filter(
        stream_id=stream_id,
        created_at__gte=time.time() - 30  # Last 30 seconds
    ).select_related('user').order_by('-created_at')[:10]:
        
        comment_data = {
            'id': comment.id,
            'username': comment.user.username,
            'message': comment.message,
            'timestamp': comment.created_at.isoformat(),
        }
        comments.append(comment_data)
    
    return comments

async def get_stream_quality_metrics(stream_id):
    """Get stream quality metrics"""
    # Simulate quality metrics
    return {
        'fps': 60,
        'resolution': '1080p',
        'bitrate': '6000kbps',
        'dropped_frames': 0,
        'latency_ms': 150
    }

# Chunked response streaming for large data
async def large_dataset_export(request):
    """Stream large dataset export"""
    
    async def generate_csv_chunks():
        """Generate CSV data in chunks"""
        
        # CSV header
        yield "id,username,email,created_at,last_login\n"
        
        # Stream user data in chunks
        chunk_size = 1000
        offset = 0
        
        while True:
            users = User.objects.all()[offset:offset + chunk_size]
            user_list = await sync_to_async(list)(users)
            
            if not user_list:
                break
            
            for user in user_list:
                csv_row = f"{user.id},{user.username},{user.email},{user.date_joined},{user.last_login}\n"
                yield csv_row
            
            offset += chunk_size
            
            # Small delay to prevent overwhelming the database
            await asyncio.sleep(0.1)
    
    return StreamingHttpResponse(
        generate_csv_chunks(),
        content_type='text/csv',
        headers={
            'Content-Disposition': 'attachment; filename="users_export.csv"'
        }
    )
```

### 4. Async Middleware and Performance Monitoring

**Scenario**: Slack's performance monitoring and request tracking

```python
# middleware.py - Async middleware implementations
import asyncio
import time
import json
import logging
from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse
from asgiref.sync import sync_to_async

logger = logging.getLogger('async_performance')

class AsyncPerformanceMiddleware:
    """Middleware to monitor async request performance"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization
        self.async_capable = True
        
    async def __call__(self, request):
        # Code to be executed for each request before the view
        start_time = time.time()
        request._async_start_time = start_time
        request._async_db_queries = 0
        
        # Determine if this is an async request
        is_async = asyncio.iscoroutinefunction(self.get_response)
        
        # Get response
        if is_async:
            response = await self.get_response(request)
        else:
            response = self.get_response(request)
        
        # Code to be executed after the view
        end_time = time.time()
        execution_time = (end_time - start_time) * 1000  # Convert to milliseconds
        
        # Log performance metrics
        await self.log_performance_metrics(request, response, execution_time, is_async)
        
        # Add performance headers
        response['X-Response-Time'] = f"{execution_time:.2f}ms"
        response['X-Async-Request'] = str(is_async)
        
        return response
    
    async def log_performance_metrics(self, request, response, execution_time, is_async):
        """Log performance metrics to database"""
        try:
            # Get request details
            endpoint = request.path
            method = request.method
            user_id = request.user.id if request.user.is_authenticated else None
            
            # Create performance log entry
            from myapp.models import RequestPerformance
            
            await RequestPerformance.objects.acreate(
                endpoint=endpoint,
                method=method,
                is_async=is_async,
                response_time_ms=execution_time,
                user_id=user_id,
                database_queries=getattr(request, '_async_db_queries', 0),
                memory_usage_mb=await self.get_memory_usage(),
                timestamp=time.time()
            )
            
        except Exception as e:
            logger.error(f"Failed to log performance metrics: {e}")
    
    async def get_memory_usage(self):
        """Get current memory usage"""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        return memory_info.rss / 1024 / 1024  # Convert to MB

class AsyncRateLimitMiddleware:
    """Async rate limiting middleware"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.async_capable = True
        self.rate_limits = {
            '/api/': {'requests': 100, 'window': 60},  # 100 requests per minute
            '/api/upload/': {'requests': 10, 'window': 60},  # 10 uploads per minute
            '/api/search/': {'requests': 50, 'window': 60},  # 50 searches per minute
        }
    
    async def __call__(self, request):
        # Check rate limit before processing request
        rate_limit_response = await self.check_rate_limit(request)
        if rate_limit_response:
            return rate_limit_response
        
        # Process request
        if asyncio.iscoroutinefunction(self.get_response):
            response = await self.get_response(request)
        else:
            response = self.get_response(request)
        
        return response
    
    async def check_rate_limit(self, request):
        """Check if request exceeds rate limits"""
        try:
            # Get client identifier
            client_id = self.get_client_identifier(request)
            
            # Find matching rate limit rule
            rate_limit = self.get_rate_limit_for_path(request.path)
            if not rate_limit:
                return None
            
            # Check rate limit using Redis or database
            is_limited = await self.is_rate_limited(client_id, request.path, rate_limit)
            
            if is_limited:
                return JsonResponse({
                    'error': 'Rate limit exceeded',
                    'limit': rate_limit['requests'],
                    'window': rate_limit['window'],
                    'retry_after': rate_limit['window']
                }, status=429)
            
            # Record request
            await self.record_request(client_id, request.path)
            
        except Exception as e:
            logger.error(f"Rate limiting error: {e}")
            # On error, allow request to proceed
            pass
        
        return None
    
    def get_client_identifier(self, request):
        """Get unique client identifier for rate limiting"""
        if request.user.is_authenticated:
            return f"user_{request.user.id}"
        else:
            # Use IP address for anonymous users
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                return f"ip_{x_forwarded_for.split(',')[0]}"
            else:
                return f"ip_{request.META.get('REMOTE_ADDR')}"
    
    def get_rate_limit_for_path(self, path):
        """Get rate limit configuration for request path"""
        for pattern, limit in self.rate_limits.items():
            if path.startswith(pattern):
                return limit
        return None
    
    async def is_rate_limited(self, client_id, path, rate_limit):
        """Check if client has exceeded rate limit"""
        # In production, this would use Redis for fast lookups
        # For demo purposes, we'll simulate rate limiting
        import random
        return random.random() < 0.1  # 10% chance of rate limiting
    
    async def record_request(self, client_id, path):
        """Record request for rate limiting tracking"""
        # In production, this would increment counters in Redis
        pass

class AsyncErrorHandlingMiddleware:
    """Middleware to handle async errors gracefully"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.async_capable = True
    
    async def __call__(self, request):
        try:
            if asyncio.iscoroutinefunction(self.get_response):
                response = await self.get_response(request)
            else:
                response = self.get_response(request)
            
            return response
            
        except asyncio.TimeoutError:
            logger.error(f"Async timeout for {request.path}")
            return JsonResponse({
                'error': 'Request timeout',
                'message': 'The request took too long to process'
            }, status=504)
            
        except asyncio.CancelledError:
            logger.warning(f"Async request cancelled for {request.path}")
            return JsonResponse({
                'error': 'Request cancelled',
                'message': 'The request was cancelled'
            }, status=499)
            
        except Exception as e:
            logger.error(f"Async error in {request.path}: {e}")
            return JsonResponse({
                'error': 'Internal server error',
                'message': 'An unexpected error occurred'
            }, status=500)
```

## 🎯 Key Takeaways

1. **ASGI enables true async capabilities** → Use for high-concurrency applications
2. **Async views handle more connections efficiently** → Better resource utilization
3. **Use asyncio.gather() for concurrent operations** → Parallel external API calls
4. **Streaming responses for real-time data** → Server-Sent Events and WebSockets
5. **Async middleware must be properly configured** → Set async_capable = True
6. **Monitor async performance metrics** → Track response times and resource usage
7. **Handle async errors gracefully** → Timeouts, cancellations, and exceptions

Django's async support transforms applications into high-performance, concurrent systems capable of handling modern real-time workloads!
''',
    "difficulty": "advanced",
    "estimated_time": 55,
    "xp_reward": 35,
    "prerequisites": ["django-models-foundations", "async_views"],
    "exercises": [
        {
            "id": "async_fundamentals_1",
            "title": "Explore Async Performance Data",
            "prompt": "Let's examine our async performance monitoring database. Write a query to see request performance comparing async vs sync endpoints.",
            "table_name": "request_performance",
            "initial_query": "SELECT * FROM request_performance LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "request_performance"],
            "hint": "Use SELECT * FROM request_performance LIMIT 5; to see async vs sync performance data",
            "solution": "SELECT * FROM request_performance LIMIT 5;",
            "explanation": "This table tracks real-world async vs sync performance metrics. Notice how async requests typically show lower response times and memory usage when handling concurrent requests. Django's async views excel in I/O-bound scenarios."
        },
        {
            "id": "async_fundamentals_2",
            "title": "Async vs Sync Performance Comparison",
            "prompt": "Compare async and sync performance for the same endpoints. Write a query to see average response times grouped by endpoint and async status.",
            "table_name": "request_performance",
            "expected_keywords": ["SELECT", "endpoint", "is_async", "AVG", "response_time_ms", "GROUP BY"],
            "hint": "Group by endpoint and is_async, then calculate average response times",
            "solution": "SELECT endpoint, is_async, AVG(response_time_ms) as avg_response_time, AVG(memory_usage_mb) as avg_memory FROM request_performance GROUP BY endpoint, is_async ORDER BY endpoint, is_async;",
            "explanation": "This comparison shows async views typically have lower response times under load. The async advantage becomes more pronounced with higher concurrent_requests values, demonstrating Django's improved resource efficiency with async views."
        },
        {
            "id": "async_fundamentals_3",
            "title": "Connection Pool Analysis",
            "prompt": "Examine connection pool efficiency for async applications. Write a query to see connection pool utilization across different pool types.",
            "table_name": "connection_pools",
            "expected_keywords": ["SELECT", "pool_name", "pool_type", "active_connections", "max_connections"],
            "hint": "Select pool information to compare utilization between async and sync pools",
            "solution": "SELECT pool_name, pool_type, active_connections, max_connections, (active_connections::decimal / max_connections * 100) as utilization_percent FROM connection_pools ORDER BY utilization_percent DESC;",
            "explanation": "Async connection pools typically show better utilization ratios. The async pools can handle more connections efficiently because they don't block on I/O operations, allowing for better resource sharing."
        },
        {
            "id": "async_fundamentals_4",
            "title": "WebSocket Connection Monitoring",
            "prompt": "Analyze WebSocket connection patterns for real-time features. Write a query to see active WebSocket connections with their activity levels.",
            "table_name": "websocket_connections",
            "expected_keywords": ["SELECT", "channel_name", "user_id", "messages_sent", "messages_received"],
            "hint": "Select WebSocket connection data to see real-time communication patterns",
            "solution": "SELECT channel_name, user_id, messages_sent, messages_received, (messages_sent + messages_received) as total_activity FROM websocket_connections WHERE disconnected_at IS NULL ORDER BY total_activity DESC;",
            "explanation": "WebSocket connections enable real-time features in async Django applications. High message activity indicates active real-time communication, which async Django handles efficiently without blocking other connections."
        },
        {
            "id": "async_fundamentals_5",
            "title": "Async Task Queue Analysis",
            "prompt": "Examine async task processing patterns. Write a query to see task completion rates and performance by task type.",
            "table_name": "async_tasks",
            "expected_keywords": ["SELECT", "task_type", "status", "COUNT", "AVG", "execution_time_ms"],
            "hint": "Group by task_type and status to analyze task completion patterns",
            "solution": "SELECT task_type, status, COUNT(*) as task_count, AVG(execution_time_ms) as avg_execution_time FROM async_tasks GROUP BY task_type, status ORDER BY task_type, status;",
            "explanation": "Async task queues handle background processing efficiently. Different task types show varying execution times, with async tasks providing better resource utilization for I/O-bound operations like email sending and API calls."
        },
        {
            "id": "async_fundamentals_6",
            "title": "ASGI Application Metrics",
            "prompt": "Monitor ASGI application performance metrics. Write a query to see current application performance indicators.",
            "table_name": "asgi_metrics",
            "expected_keywords": ["SELECT", "metric_name", "metric_value", "tags", "timestamp"],
            "hint": "Select ASGI metrics to see application performance indicators",
            "solution": "SELECT metric_name, metric_value, metric_unit, tags FROM asgi_metrics WHERE timestamp >= CURRENT_TIMESTAMP - INTERVAL '1 hour' ORDER BY metric_name;",
            "explanation": "ASGI metrics show how async Django applications perform under load. Key metrics like concurrent_connections and websocket_connections demonstrate the scalability benefits of async deployment over traditional WSGI."
        }
    ],
    "key_concepts": [
        "ASGI Configuration and Deployment",
        "Async Views and Function-Based Views", 
        "Async Class-Based Views Implementation",
        "Streaming Responses and Server-Sent Events",
        "Async Middleware Development",
        "Performance Monitoring for Async Applications",
        "Connection Pool Management",
        "WebSocket Integration Patterns"
    ]
}