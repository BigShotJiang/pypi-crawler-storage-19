"""
Django Database Management - Lesson 3: Initial Data Management and Fixtures
Master Django's initial data loading, fixtures, and database seeding strategies
"""

DJANGO_INITIAL_DATA_LESSON = {
    "id": 56,
    "chapter": 56,
    "title": "Django Initial Data Management: Fixtures and Database Seeding",
    "slug": "django-initial-data",
    "description": "Learn to manage initial data in Django using fixtures, data migrations, and seeding strategies",
    "content": '''# Django Initial Data Management: Fixtures and Database Seeding

## 🎯 Understanding Initial Data Management

**Initial data management** is crucial for Django applications that need **consistent starting data** across environments. This includes **reference data**, **default configurations**, and **sample content** for development and testing.

**Key Data Categories**:
- **Reference Data** → Countries, states, currencies, categories
- **Configuration Data** → Application settings, feature flags, permissions
- **Sample Data** → Test users, demo content, development datasets
- **Security Data** → Default admin users, groups, permissions
- **Business Data** → Product catalogs, pricing tiers, workflows

Think of initial data as your application's **foundation layer** - the essential data that makes your application functional from day one.

## 💾 Initial Data Management Database

Let's create comprehensive examples of different initial data scenarios:

```sql
-- REFERENCE DATA: Countries and regions
CREATE TABLE countries (
    id SERIAL PRIMARY KEY,
    code VARCHAR(3) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    continent VARCHAR(50) NOT NULL,
    currency_code VARCHAR(3),
    timezone VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Essential country reference data
INSERT INTO countries (code, name, continent, currency_code, timezone) VALUES
('USA', 'United States', 'North America', 'USD', 'America/New_York'),
('CAN', 'Canada', 'North America', 'CAD', 'America/Toronto'),
('GBR', 'United Kingdom', 'Europe', 'GBP', 'Europe/London'),
('DEU', 'Germany', 'Europe', 'EUR', 'Europe/Berlin'),
('FRA', 'France', 'Europe', 'EUR', 'Europe/Paris'),
('JPN', 'Japan', 'Asia', 'JPY', 'Asia/Tokyo'),
('AUS', 'Australia', 'Oceania', 'AUD', 'Australia/Sydney'),
('BRA', 'Brazil', 'South America', 'BRL', 'America/Sao_Paulo');

-- CONFIGURATION DATA: Application settings
CREATE TABLE app_configurations (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    setting_type VARCHAR(20) DEFAULT 'string',
    category VARCHAR(50) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    environment VARCHAR(20) DEFAULT 'all',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Application configuration data
INSERT INTO app_configurations (setting_key, setting_value, setting_type, category, description, environment) VALUES
('MAX_FILE_UPLOAD_SIZE', '10485760', 'integer', 'file_management', 'Maximum file upload size in bytes (10MB)', 'all'),
('DEFAULT_PAGINATION_SIZE', '25', 'integer', 'ui_settings', 'Default number of items per page', 'all'),
('EMAIL_VERIFICATION_REQUIRED', 'true', 'boolean', 'authentication', 'Require email verification for new accounts', 'production'),
('MAINTENANCE_MODE', 'false', 'boolean', 'system', 'Enable maintenance mode', 'all'),
('DEFAULT_LANGUAGE', 'en-US', 'string', 'localization', 'Default application language', 'all'),
('SESSION_TIMEOUT_MINUTES', '120', 'integer', 'security', 'User session timeout in minutes', 'all'),
('ENABLE_DEBUG_TOOLBAR', 'false', 'boolean', 'debugging', 'Enable Django debug toolbar', 'development'),
('API_RATE_LIMIT_PER_HOUR', '1000', 'integer', 'api_settings', 'API calls allowed per hour per user', 'production');

-- SAMPLE DATA: Product categories for e-commerce
CREATE TABLE product_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    parent_id INTEGER,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES product_categories(id)
);

-- Product category hierarchy
INSERT INTO product_categories (id, name, slug, description, parent_id, sort_order) VALUES
(1, 'Electronics', 'electronics', 'Electronic devices and accessories', NULL, 1),
(2, 'Computers', 'computers', 'Desktop and laptop computers', 1, 1),
(3, 'Mobile Devices', 'mobile-devices', 'Smartphones and tablets', 1, 2),
(4, 'Audio Equipment', 'audio-equipment', 'Speakers, headphones, and audio gear', 1, 3),
(5, 'Laptops', 'laptops', 'Portable computers', 2, 1),
(6, 'Desktops', 'desktops', 'Desktop computer systems', 2, 2),
(7, 'Smartphones', 'smartphones', 'Mobile phones', 3, 1),
(8, 'Tablets', 'tablets', 'Tablet computers', 3, 2),
(9, 'Headphones', 'headphones', 'Audio headphones and earbuds', 4, 1),
(10, 'Speakers', 'speakers', 'Audio speakers and sound systems', 4, 2);

-- USER ROLES AND PERMISSIONS: Security setup
CREATE TABLE user_roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default user roles
INSERT INTO user_roles (name, display_name, description, permissions) VALUES
('admin', 'Administrator', 'Full system access', '["user.create", "user.read", "user.update", "user.delete", "admin.access", "system.configure"]'),
('manager', 'Manager', 'Management access to assigned areas', '["user.read", "user.update", "report.access", "team.manage"]'),
('staff', 'Staff Member', 'Standard employee access', '["user.read", "content.create", "content.update", "order.process"]'),
('customer', 'Customer', 'Customer portal access', '["profile.update", "order.view", "order.create", "support.ticket"]'),
('guest', 'Guest User', 'Limited read-only access', '["catalog.view", "product.search"]');

-- BUSINESS DATA: Pricing tiers for SaaS
CREATE TABLE pricing_plans (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    monthly_price DECIMAL(10, 2) NOT NULL,
    annual_price DECIMAL(10, 2),
    features JSONB DEFAULT '[]'::jsonb,
    limits JSONB DEFAULT '{}'::jsonb,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    is_popular BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SaaS pricing plans
INSERT INTO pricing_plans (name, display_name, description, monthly_price, annual_price, features, limits, sort_order, is_popular) VALUES
('free', 'Free Plan', 'Perfect for getting started', 0.00, 0.00, 
 '["Basic dashboard", "Up to 3 projects", "Email support", "Standard templates"]', 
 '{"projects": 3, "users": 1, "storage_gb": 1, "api_calls_per_month": 1000}', 1, false),

('starter', 'Starter Plan', 'Great for small teams', 29.00, 290.00,
 '["Everything in Free", "Up to 10 projects", "Priority email support", "Custom branding", "Basic analytics"]',
 '{"projects": 10, "users": 5, "storage_gb": 10, "api_calls_per_month": 10000}', 2, false),

('professional', 'Professional Plan', 'Best for growing businesses', 79.00, 790.00,
 '["Everything in Starter", "Unlimited projects", "Phone support", "Advanced analytics", "API access", "Integrations"]',
 '{"projects": -1, "users": 25, "storage_gb": 100, "api_calls_per_month": 100000}', 3, true),

('enterprise', 'Enterprise Plan', 'For large organizations', 199.00, 1990.00,
 '["Everything in Professional", "Unlimited users", "24/7 support", "Custom integrations", "SLA guarantee", "Dedicated account manager"]',
 '{"projects": -1, "users": -1, "storage_gb": 1000, "api_calls_per_month": 1000000}', 4, false);

-- WORKFLOW DATA: Order statuses and transitions
CREATE TABLE order_statuses (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    color VARCHAR(7), -- Hex color code
    sort_order INTEGER DEFAULT 0,
    is_initial BOOLEAN DEFAULT FALSE,
    is_final BOOLEAN DEFAULT FALSE,
    allowed_transitions JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Order workflow statuses
INSERT INTO order_statuses (code, name, description, color, sort_order, is_initial, is_final, allowed_transitions) VALUES
('pending', 'Pending', 'Order received, awaiting payment', '#FFA500', 1, true, false, '["paid", "cancelled"]'),
('paid', 'Paid', 'Payment confirmed, ready for processing', '#4CAF50', 2, false, false, '["processing", "cancelled"]'),
('processing', 'Processing', 'Order being prepared for shipment', '#2196F3', 3, false, false, '["shipped", "cancelled"]'),
('shipped', 'Shipped', 'Order dispatched to customer', '#9C27B0', 4, false, false, '["delivered", "returned"]'),
('delivered', 'Delivered', 'Order successfully delivered', '#4CAF50', 5, false, true, '["returned"]'),
('cancelled', 'Cancelled', 'Order cancelled before fulfillment', '#F44336', 6, false, true, '[]'),
('returned', 'Returned', 'Order returned by customer', '#FF5722', 7, false, true, '[]');
```

## 🔧 Django Fixtures - JSON Data Loading

### 1. Creating and Loading JSON Fixtures

**Scenario**: GitHub's repository setup with default labels

```python
# fixtures/github_labels.json
[
  {
    "model": "projects.label",
    "pk": 1,
    "fields": {
      "name": "bug",
      "color": "#d73a49",
      "description": "Something isn't working",
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "projects.label",
    "pk": 2,
    "fields": {
      "name": "enhancement",
      "color": "#a2eeef",
      "description": "New feature or request",
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "projects.label",
    "pk": 3,
    "fields": {
      "name": "documentation",
      "color": "#0075ca",
      "description": "Improvements or additions to documentation",
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "projects.label",
    "pk": 4,
    "fields": {
      "name": "good first issue",
      "color": "#7057ff",
      "description": "Good for newcomers",
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "projects.label",
    "pk": 5,
    "fields": {
      "name": "help wanted",
      "color": "#008672",
      "description": "Extra attention is needed",
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  }
]

# Loading fixtures command:
# python manage.py loaddata github_labels.json

# Dumping existing data to fixture:
# python manage.py dumpdata projects.label --format=json --indent=2 > fixtures/labels.json
```

### 2. Complex Fixture with Relationships

**Scenario**: Slack's workspace setup with channels and permissions

```python
# fixtures/slack_workspace_setup.json
[
  {
    "model": "workspaces.workspace",
    "pk": 1,
    "fields": {
      "name": "Acme Corporation",
      "slug": "acme-corp",
      "description": "Main workspace for Acme Corporation",
      "is_active": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "workspaces.channel",
    "pk": 1,
    "fields": {
      "workspace": 1,
      "name": "general",
      "description": "General discussion for everyone",
      "is_public": true,
      "is_default": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "workspaces.channel",
    "pk": 2,
    "fields": {
      "workspace": 1,
      "name": "announcements",
      "description": "Important company announcements",
      "is_public": true,
      "is_default": false,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "workspaces.channel",
    "pk": 3,
    "fields": {
      "workspace": 1,
      "name": "development",
      "description": "Development team discussions",
      "is_public": false,
      "is_default": false,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "auth.group",
    "pk": 1,
    "fields": {
      "name": "Workspace Admins",
      "permissions": [1, 2, 3, 4, 5]
    }
  },
  {
    "model": "auth.group",
    "pk": 2,
    "fields": {
      "name": "Channel Moderators",
      "permissions": [2, 3, 4]
    }
  },
  {
    "model": "auth.group",
    "pk": 3,
    "fields": {
      "name": "Regular Members",
      "permissions": [4]
    }
  }
]

# Advanced fixture loading in Django settings
# settings.py
FIXTURE_DIRS = [
    os.path.join(BASE_DIR, 'fixtures'),
    os.path.join(BASE_DIR, 'apps', 'core', 'fixtures'),
    os.path.join(BASE_DIR, 'initial_data'),
]

# Load multiple fixtures at once:
# python manage.py loaddata workspace_setup.json user_roles.json countries.json
```

### 3. Environment-Specific Fixtures

**Scenario**: Different data sets for different environments

```python
# fixtures/development/sample_users.json
[
  {
    "model": "auth.user",
    "pk": 1,
    "fields": {
      "username": "admin",
      "first_name": "Admin",
      "last_name": "User",
      "email": "admin@example.com",
      "is_staff": true,
      "is_superuser": true,
      "is_active": true,
      "date_joined": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "auth.user",
    "pk": 2,
    "fields": {
      "username": "testuser1",
      "first_name": "Test",
      "last_name": "User One",
      "email": "test1@example.com",
      "is_staff": false,
      "is_superuser": false,
      "is_active": true,
      "date_joined": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "auth.user",
    "pk": 3,
    "fields": {
      "username": "testuser2",
      "first_name": "Test",
      "last_name": "User Two",
      "email": "test2@example.com",
      "is_staff": false,
      "is_superuser": false,
      "is_active": true,
      "date_joined": "2024-01-01T00:00:00Z"
    }
  }
]

# Management command to load environment-specific data
# management/commands/load_env_data.py
from django.core.management.base import BaseCommand
from django.core.management import call_command
from django.conf import settings
import os

class Command(BaseCommand):
    help = 'Load environment-specific fixtures'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--environment',
            type=str,
            default='development',
            help='Environment to load data for (development, staging, production)'
        )
    
    def handle(self, *args, **options):
        environment = options['environment']
        
        # Common fixtures for all environments
        common_fixtures = [
            'countries.json',
            'app_configurations.json',
            'user_roles.json',
            'pricing_plans.json',
            'order_statuses.json'
        ]
        
        # Environment-specific fixtures
        env_fixtures = {
            'development': [
                'development/sample_users.json',
                'development/demo_products.json',
                'development/test_orders.json'
            ],
            'staging': [
                'staging/staging_users.json',
                'staging/staging_products.json'
            ],
            'production': [
                'production/admin_users.json',
                'production/initial_content.json'
            ]
        }
        
        # Load common fixtures
        self.stdout.write(f"Loading common fixtures...")
        for fixture in common_fixtures:
            try:
                call_command('loaddata', fixture, verbosity=0)
                self.stdout.write(f"  ✓ Loaded {fixture}")
            except Exception as e:
                self.stdout.write(f"  ✗ Failed to load {fixture}: {e}")
        
        # Load environment-specific fixtures
        if environment in env_fixtures:
            self.stdout.write(f"Loading {environment} fixtures...")
            for fixture in env_fixtures[environment]:
                try:
                    call_command('loaddata', fixture, verbosity=0)
                    self.stdout.write(f"  ✓ Loaded {fixture}")
                except Exception as e:
                    self.stdout.write(f"  ✗ Failed to load {fixture}: {e}")
        
        self.stdout.write(
            self.style.SUCCESS(f"Successfully loaded {environment} data!")
        )
```

## 🚀 Data Migrations for Initial Data

### 4. Data Migration for Reference Data

**Scenario**: Stripe's currency and country setup

```python
# migrations/0002_load_countries.py
from django.db import migrations

def load_countries(apps, schema_editor):
    """Load initial country data"""
    Country = apps.get_model('core', 'Country')
    
    countries_data = [
        ('USA', 'United States', 'North America', 'USD', 'America/New_York'),
        ('CAN', 'Canada', 'North America', 'CAD', 'America/Toronto'),
        ('GBR', 'United Kingdom', 'Europe', 'GBP', 'Europe/London'),
        ('DEU', 'Germany', 'Europe', 'EUR', 'Europe/Berlin'),
        ('FRA', 'France', 'Europe', 'EUR', 'Europe/Paris'),
        ('JPN', 'Japan', 'Asia', 'JPY', 'Asia/Tokyo'),
        ('AUS', 'Australia', 'Oceania', 'AUD', 'Australia/Sydney'),
        ('BRA', 'Brazil', 'South America', 'BRL', 'America/Sao_Paulo'),
    ]
    
    countries_to_create = []
    for code, name, continent, currency_code, timezone in countries_data:
        countries_to_create.append(
            Country(
                code=code,
                name=name,
                continent=continent,
                currency_code=currency_code,
                timezone=timezone,
                is_active=True
            )
        )
    
    Country.objects.bulk_create(countries_to_create, ignore_conflicts=True)

def reverse_countries(apps, schema_editor):
    """Remove country data"""
    Country = apps.get_model('core', 'Country')
    Country.objects.all().delete()

class Migration(migrations.Migration):
    dependencies = [
        ('core', '0001_initial'),
    ]
    
    operations = [
        migrations.RunPython(load_countries, reverse_countries),
    ]

# migrations/0003_load_pricing_plans.py
from django.db import migrations
import json

def load_pricing_plans(apps, schema_editor):
    """Load SaaS pricing plans"""
    PricingPlan = apps.get_model('billing', 'PricingPlan')
    
    plans_data = [
        {
            'name': 'free',
            'display_name': 'Free Plan',
            'description': 'Perfect for getting started',
            'monthly_price': 0.00,
            'annual_price': 0.00,
            'features': [
                'Basic dashboard',
                'Up to 3 projects',
                'Email support',
                'Standard templates'
            ],
            'limits': {
                'projects': 3,
                'users': 1,
                'storage_gb': 1,
                'api_calls_per_month': 1000
            },
            'sort_order': 1,
            'is_popular': False
        },
        {
            'name': 'starter',
            'display_name': 'Starter Plan',
            'description': 'Great for small teams',
            'monthly_price': 29.00,
            'annual_price': 290.00,
            'features': [
                'Everything in Free',
                'Up to 10 projects',
                'Priority email support',
                'Custom branding',
                'Basic analytics'
            ],
            'limits': {
                'projects': 10,
                'users': 5,
                'storage_gb': 10,
                'api_calls_per_month': 10000
            },
            'sort_order': 2,
            'is_popular': False
        },
        {
            'name': 'professional',
            'display_name': 'Professional Plan',
            'description': 'Best for growing businesses',
            'monthly_price': 79.00,
            'annual_price': 790.00,
            'features': [
                'Everything in Starter',
                'Unlimited projects',
                'Phone support',
                'Advanced analytics',
                'API access',
                'Integrations'
            ],
            'limits': {
                'projects': -1,
                'users': 25,
                'storage_gb': 100,
                'api_calls_per_month': 100000
            },
            'sort_order': 3,
            'is_popular': True
        }
    ]
    
    for plan_data in plans_data:
        PricingPlan.objects.get_or_create(
            name=plan_data['name'],
            defaults=plan_data
        )

def reverse_pricing_plans(apps, schema_editor):
    """Remove pricing plans"""
    PricingPlan = apps.get_model('billing', 'PricingPlan')
    PricingPlan.objects.all().delete()

class Migration(migrations.Migration):
    dependencies = [
        ('billing', '0001_initial'),
    ]
    
    operations = [
        migrations.RunPython(load_pricing_plans, reverse_pricing_plans),
    ]
```

### 5. Custom Management Commands for Data Loading

**Scenario**: Shopify's product catalog initialization

```python
# management/commands/setup_product_catalog.py
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
import json
import requests

class Command(BaseCommand):
    help = 'Setup initial product catalog with categories and sample products'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--source',
            type=str,
            default='local',
            choices=['local', 'api', 'csv'],
            help='Data source for product catalog'
        )
        parser.add_argument(
            '--categories-only',
            action='store_true',
            help='Only create categories, skip products'
        )
        parser.add_argument(
            '--with-images',
            action='store_true',
            help='Download and attach product images'
        )
    
    def handle(self, *args, **options):
        source = options['source']
        categories_only = options['categories_only']
        with_images = options['with_images']
        
        self.stdout.write("Setting up product catalog...")
        
        try:
            with transaction.atomic():
                # Setup categories
                categories = self.setup_categories()
                self.stdout.write(f"Created {len(categories)} categories")
                
                if not categories_only:
                    # Setup products based on source
                    if source == 'local':
                        products = self.setup_local_products(categories, with_images)
                    elif source == 'api':
                        products = self.setup_api_products(categories, with_images)
                    elif source == 'csv':
                        products = self.setup_csv_products(categories, with_images)
                    
                    self.stdout.write(f"Created {len(products)} products")
                
                self.stdout.write(
                    self.style.SUCCESS('Product catalog setup completed!')
                )
                
        except Exception as e:
            raise CommandError(f'Setup failed: {e}')
    
    def setup_categories(self):
        """Create product category hierarchy"""
        from myapp.models import ProductCategory
        
        categories_data = [
            {
                'name': 'Electronics',
                'slug': 'electronics',
                'description': 'Electronic devices and accessories',
                'parent': None,
                'sort_order': 1
            },
            {
                'name': 'Computers',
                'slug': 'computers',
                'description': 'Desktop and laptop computers',
                'parent': 'Electronics',
                'sort_order': 1
            },
            {
                'name': 'Mobile Devices',
                'slug': 'mobile-devices',
                'description': 'Smartphones and tablets',
                'parent': 'Electronics',
                'sort_order': 2
            },
            {
                'name': 'Audio Equipment',
                'slug': 'audio-equipment',
                'description': 'Speakers, headphones, and audio gear',
                'parent': 'Electronics',
                'sort_order': 3
            }
        ]
        
        # Create parent categories first
        created_categories = {}
        
        for category_data in categories_data:
            parent_name = category_data.pop('parent', None)
            parent = created_categories.get(parent_name) if parent_name else None
            
            category, created = ProductCategory.objects.get_or_create(
                slug=category_data['slug'],
                defaults={
                    'name': category_data['name'],
                    'description': category_data['description'],
                    'parent': parent,
                    'sort_order': category_data['sort_order']
                }
            )
            
            created_categories[category.name] = category
            
            if created:
                self.stdout.write(f"  Created category: {category.name}")
            else:
                self.stdout.write(f"  Category already exists: {category.name}")
        
        return created_categories
    
    def setup_local_products(self, categories, with_images):
        """Create products from local data"""
        from myapp.models import Product
        
        products_data = [
            {
                'name': 'MacBook Pro 16-inch',
                'slug': 'macbook-pro-16',
                'description': 'Powerful laptop for professionals',
                'category': 'Computers',
                'price': 2499.99,
                'cost_price': 1800.00,
                'stock_quantity': 25,
                'sku': 'APPLE-MBP16-001'
            },
            {
                'name': 'iPhone 15 Pro',
                'slug': 'iphone-15-pro',
                'description': 'Latest iPhone with advanced features',
                'category': 'Mobile Devices',
                'price': 999.99,
                'cost_price': 650.00,
                'stock_quantity': 100,
                'sku': 'APPLE-IP15P-001'
            },
            {
                'name': 'Sony WH-1000XM5',
                'slug': 'sony-wh1000xm5',
                'description': 'Premium noise-canceling headphones',
                'category': 'Audio Equipment',
                'price': 399.99,
                'cost_price': 250.00,
                'stock_quantity': 50,
                'sku': 'SONY-WH1000-001'
            }
        ]
        
        created_products = []
        
        for product_data in products_data:
            category_name = product_data.pop('category')
            category = categories.get(category_name)
            
            if not category:
                self.stdout.write(
                    self.style.WARNING(f"Category {category_name} not found, skipping product")
                )
                continue
            
            product, created = Product.objects.get_or_create(
                sku=product_data['sku'],
                defaults={
                    'name': product_data['name'],
                    'slug': product_data['slug'],
                    'description': product_data['description'],
                    'category': category,
                    'price': product_data['price'],
                    'cost_price': product_data['cost_price'],
                    'stock_quantity': product_data['stock_quantity']
                }
            )
            
            created_products.append(product)
            
            if created:
                self.stdout.write(f"  Created product: {product.name}")
            else:
                self.stdout.write(f"  Product already exists: {product.name}")
        
        return created_products
    
    def setup_api_products(self, categories, with_images):
        """Create products from external API"""
        self.stdout.write("Fetching products from external API...")
        
        # Example API integration
        try:
            response = requests.get('https://api.example.com/products', timeout=30)
            response.raise_for_status()
            api_products = response.json()
            
            # Process API products...
            self.stdout.write(f"Fetched {len(api_products)} products from API")
            
            return []  # Return created products
            
        except requests.RequestException as e:
            raise CommandError(f"API request failed: {e}")
    
    def setup_csv_products(self, categories, with_images):
        """Create products from CSV file"""
        import csv
        import os
        
        csv_file_path = os.path.join('fixtures', 'products.csv')
        
        if not os.path.exists(csv_file_path):
            raise CommandError(f"CSV file not found: {csv_file_path}")
        
        created_products = []
        
        with open(csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            
            for row in reader:
                # Process CSV row...
                self.stdout.write(f"Processing: {row['name']}")
        
        return created_products
```

## 🏢 Real-World Initial Data Examples

### 6. WordPress-Style Content Management

**Scenario**: Setting up a CMS with initial content types and templates

```python
# management/commands/setup_cms.py
from django.core.management.base import BaseCommand
from django.db import transaction

class Command(BaseCommand):
    help = 'Setup CMS with initial content types, templates, and sample content'
    
    def handle(self, *args, **options):
        with transaction.atomic():
            self.setup_content_types()
            self.setup_page_templates()
            self.setup_navigation_menus()
            self.setup_widgets()
            self.setup_sample_pages()
        
        self.stdout.write(self.style.SUCCESS('CMS setup completed!'))
    
    def setup_content_types(self):
        """Create content types for CMS"""
        from cms.models import ContentType
        
        content_types = [
            {
                'name': 'Page',
                'slug': 'page',
                'description': 'Static content pages',
                'fields_config': {
                    'title': {'type': 'text', 'required': True},
                    'content': {'type': 'rich_text', 'required': True},
                    'meta_description': {'type': 'text', 'required': False},
                    'featured_image': {'type': 'image', 'required': False}
                }
            },
            {
                'name': 'Blog Post',
                'slug': 'blog-post',
                'description': 'Blog articles and news',
                'fields_config': {
                    'title': {'type': 'text', 'required': True},
                    'content': {'type': 'rich_text', 'required': True},
                    'excerpt': {'type': 'textarea', 'required': False},
                    'author': {'type': 'user_select', 'required': True},
                    'featured_image': {'type': 'image', 'required': False},
                    'tags': {'type': 'tags', 'required': False}
                }
            },
            {
                'name': 'Product',
                'slug': 'product',
                'description': 'E-commerce products',
                'fields_config': {
                    'name': {'type': 'text', 'required': True},
                    'description': {'type': 'rich_text', 'required': True},
                    'price': {'type': 'decimal', 'required': True},
                    'images': {'type': 'image_gallery', 'required': False},
                    'specifications': {'type': 'key_value', 'required': False}
                }
            }
        ]
        
        for ct_data in content_types:
            content_type, created = ContentType.objects.get_or_create(
                slug=ct_data['slug'],
                defaults=ct_data
            )
            
            if created:
                self.stdout.write(f"  Created content type: {content_type.name}")
    
    def setup_page_templates(self):
        """Create page templates"""
        from cms.models import PageTemplate
        
        templates = [
            {
                'name': 'Default Page',
                'slug': 'default-page',
                'template_path': 'cms/templates/page.html',
                'description': 'Standard page layout',
                'is_default': True
            },
            {
                'name': 'Landing Page',
                'slug': 'landing-page',
                'template_path': 'cms/templates/landing.html',
                'description': 'Marketing landing page layout',
                'is_default': False
            },
            {
                'name': 'Blog Post',
                'slug': 'blog-post',
                'template_path': 'cms/templates/blog_post.html',
                'description': 'Blog article layout',
                'is_default': False
            }
        ]
        
        for template_data in templates:
            template, created = PageTemplate.objects.get_or_create(
                slug=template_data['slug'],
                defaults=template_data
            )
            
            if created:
                self.stdout.write(f"  Created template: {template.name}")
```

### 7. Discord-Style Server Setup

**Scenario**: Gaming platform with default channels and roles

```python
# fixtures/discord_server_setup.json
[
  {
    "model": "servers.server",
    "pk": 1,
    "fields": {
      "name": "Gaming Community",
      "description": "A friendly gaming community for all",
      "is_public": true,
      "max_members": 1000,
      "created_at": "2024-01-01T00:00:00Z"
    }
  },
  {
    "model": "servers.channel",
    "pk": 1,
    "fields": {
      "server": 1,
      "name": "welcome",
      "channel_type": "text",
      "description": "Welcome new members here",
      "is_public": true,
      "sort_order": 1
    }
  },
  {
    "model": "servers.channel",
    "pk": 2,
    "fields": {
      "server": 1,
      "name": "general-chat",
      "channel_type": "text",
      "description": "General discussion",
      "is_public": true,
      "sort_order": 2
    }
  },
  {
    "model": "servers.channel",
    "pk": 3,
    "fields": {
      "server": 1,
      "name": "gaming-discussion",
      "channel_type": "text",
      "description": "Talk about games",
      "is_public": true,
      "sort_order": 3
    }
  },
  {
    "model": "servers.channel",
    "pk": 4,
    "fields": {
      "server": 1,
      "name": "General Voice",
      "channel_type": "voice",
      "description": "General voice chat",
      "is_public": true,
      "sort_order": 4
    }
  },
  {
    "model": "servers.role",
    "pk": 1,
    "fields": {
      "server": 1,
      "name": "Admin",
      "color": "#ff0000",
      "permissions": ["manage_server", "manage_channels", "kick_members", "ban_members"],
      "is_default": false,
      "sort_order": 1
    }
  },
  {
    "model": "servers.role",
    "pk": 2,
    "fields": {
      "server": 1,
      "name": "Moderator",
      "color": "#00ff00",
      "permissions": ["manage_channels", "kick_members", "timeout_members"],
      "is_default": false,
      "sort_order": 2
    }
  },
  {
    "model": "servers.role",
    "pk": 3,
    "fields": {
      "server": 1,
      "name": "Member",
      "color": "#0099ff",
      "permissions": ["send_messages", "connect_voice"],
      "is_default": true,
      "sort_order": 3
    }
  }
]
```

## 🎯 Key Takeaways

1. **Use fixtures for reference data** → Countries, currencies, categories that rarely change
2. **Data migrations for complex setup** → Business logic and relationships require code
3. **Environment-specific data loading** → Different data sets for dev, staging, production
4. **Management commands for complex scenarios** → Custom logic, API integration, CSV import
5. **Plan for data updates** → Design fixtures and migrations to handle schema changes
6. **Validate loaded data** → Ensure data integrity and business rule compliance
7. **Document data sources** → Track where initial data comes from and how to update it

Initial data management ensures your Django application starts with the foundation it needs to function properly across all environments!
''',
    "difficulty": "intermediate",
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-migrations-intro"],
    "exercises": [
        {
            "id": "initial_data_1",
            "title": "Explore Reference Data Setup",
            "prompt": "Let's examine the countries reference data that would be loaded via fixtures. Write a query to see all countries with their currencies and timezones.",
            "table_name": "countries",
            "initial_query": "SELECT * FROM countries;",
            "expected_keywords": ["SELECT", "*", "FROM", "countries"],
            "hint": "Use SELECT * FROM countries; to see the reference data structure",
            "solution": "SELECT * FROM countries;",
            "explanation": "Reference data like countries is perfect for Django fixtures because it's stable and needed across all environments. This data would be loaded via fixtures/countries.json and remain consistent across development, staging, and production."
        },
        {
            "id": "initial_data_2",
            "title": "Configuration Data Management",
            "prompt": "Examine application configuration data. Write a query to see all settings organized by category and environment.",
            "table_name": "app_configurations",
            "expected_keywords": ["SELECT", "setting_key", "category", "environment", "FROM"],
            "hint": "Select key configuration fields to see how settings are organized",
            "solution": "SELECT setting_key, setting_value, category, environment, description FROM app_configurations ORDER BY category, environment;",
            "explanation": "Configuration data is ideal for data migrations because it can be environment-specific. Django can load different configurations for development vs production environments using conditional logic in data migration files."
        },
        {
            "id": "initial_data_3",
            "title": "Product Category Hierarchy",
            "prompt": "Look at the product category structure with parent-child relationships. Write a query to see categories with their parent relationships.",
            "table_name": "product_categories",
            "expected_keywords": ["SELECT", "name", "parent_id", "sort_order", "FROM"],
            "hint": "Select name, parent_id, and sort_order to see the hierarchy",
            "solution": "SELECT id, name, parent_id, sort_order, slug FROM product_categories ORDER BY COALESCE(parent_id, 0), sort_order;",
            "explanation": "Hierarchical data like categories requires careful fixture design or data migrations to ensure parent categories are created before child categories. Django's natural key support in fixtures helps manage these dependencies."
        },
        {
            "id": "initial_data_4",
            "title": "User Roles and Permissions Setup",
            "prompt": "Examine the user roles system. Write a query to see role names with their permission sets.",
            "table_name": "user_roles",
            "expected_keywords": ["SELECT", "name", "display_name", "permissions", "FROM"],
            "hint": "Select role information including the JSONB permissions field",
            "solution": "SELECT name, display_name, permissions, description FROM user_roles ORDER BY name;",
            "explanation": "Security data like user roles is critical for initial setup. This data is typically loaded via data migrations rather than fixtures to ensure proper permission assignments and to handle complex relationships with Django's auth system."
        },
        {
            "id": "initial_data_5",
            "title": "SaaS Pricing Plans Configuration",
            "prompt": "Look at the pricing plans for a SaaS application. Write a query to see plans with their pricing and feature information.",
            "table_name": "pricing_plans",
            "expected_keywords": ["SELECT", "name", "monthly_price", "features", "FROM"],
            "hint": "Select pricing plan details including JSONB features and limits",
            "solution": "SELECT name, display_name, monthly_price, annual_price, features, limits, is_popular FROM pricing_plans ORDER BY sort_order;",
            "explanation": "Business configuration like pricing plans combines static data (plan structure) with business logic (pricing calculations). This data is often loaded via custom management commands that can handle complex business rules and validation."
        },
        {
            "id": "initial_data_6",
            "title": "Order Workflow Status Analysis",
            "prompt": "Examine the order status workflow system. Write a query to see order statuses with their allowed transitions.",
            "table_name": "order_statuses",
            "expected_keywords": ["SELECT", "code", "name", "allowed_transitions", "is_final"],
            "hint": "Select status information including the workflow transition rules",
            "solution": "SELECT code, name, color, sort_order, is_initial, is_final, allowed_transitions FROM order_statuses ORDER BY sort_order;",
            "explanation": "Workflow data like order statuses defines business process rules. This type of data is best managed through data migrations because it includes complex business logic (allowed transitions) and may need to be updated as business processes evolve."
        }
    ],
    "key_concepts": [
        "Django Fixtures and JSON Data Loading",
        "Data Migration Strategies for Initial Data",
        "Environment-Specific Data Management",
        "Custom Management Commands for Complex Data",
        "Reference Data vs Configuration Data",
        "Hierarchical Data Loading Patterns",
        "Security Data and Permission Setup",
        "Business Logic in Initial Data"
    ]
}