"""
Django Advanced Model Fields lesson content
"""

DJANGO_ADVANCED_FIELDS_LESSON = {
    "id": 18,
    "chapter": 18,
    "title": "Advanced Model Fields and Validation",
    "slug": "advanced-model-fields",
    "content": '''
# Advanced Model Fields: Mastering Data Types and Validation

Think of Django model fields as the precision instruments in a surgeon's toolkit. While basic CharField and IntegerField are like scalpels - simple and essential - advanced fields are like specialized surgical instruments, each perfectly designed for specific, complex operations in your data architecture.

## Field Types Deep Dive: Choosing the Perfect Tool

### Text Fields: From Tweets to Novels

```python
from django.db import models
from django.core.validators import MinLengthValidator, MaxLengthValidator
import re

class Content(models.Model):
    # Twitter-style short messages
    tweet = models.CharField(
        max_length=280,
        help_text="Keep it concise - Twitter style!"
    )
    
    # Instagram captions with flexible length
    caption = models.TextField(
        max_length=2200,  # Instagram's current limit
        blank=True,
        help_text="Tell your story..."
    )
    
    # Blog post with unlimited content
    blog_content = models.TextField(
        blank=True,
        help_text="Write your masterpiece"
    )
    
    # Slug for SEO-friendly URLs
    slug = models.SlugField(
        unique=True,
        max_length=100,
        help_text="URL-friendly version of title"
    )
    
    # Rich text with HTML content
    rich_content = models.TextField(
        blank=True,
        help_text="HTML content from rich text editor"
    )
    
    def clean_slug(self):
        """Custom slug validation"""
        if self.slug and not re.match(r'^[a-z0-9-]+$', self.slug):
            raise ValidationError("Slug can only contain lowercase letters, numbers, and hyphens")
```

### Email and URL Fields: Validating Digital Addresses

```python
class UserContact(models.Model):
    # Email with built-in validation
    email = models.EmailField(
        unique=True,
        help_text="We'll never spam you!"
    )
    
    # Multiple email validation
    backup_email = models.EmailField(
        blank=True,
        help_text="Secondary email address"
    )
    
    # Website URL
    website = models.URLField(
        blank=True,
        max_length=500,
        help_text="Your personal or professional website"
    )
    
    # Social media profiles
    linkedin_url = models.URLField(blank=True)
    twitter_url = models.URLField(blank=True)
    github_url = models.URLField(blank=True)
    
    def clean(self):
        """Cross-field validation"""
        super().clean()
        
        # Ensure backup email is different from primary
        if self.email and self.backup_email and self.email == self.backup_email:
            raise ValidationError("Backup email must be different from primary email")
        
        # Validate social media URLs
        if self.twitter_url and 'twitter.com' not in self.twitter_url:
            raise ValidationError("Twitter URL must be from twitter.com")
```

### Numeric Fields: Precision Matters

```python
from decimal import Decimal
from django.core.validators import MinValueValidator, MaxValueValidator

class FinancialData(models.Model):
    # Cryptocurrency prices (high precision)
    bitcoin_price = models.DecimalField(
        max_digits=15,  # 1,000,000,000.123456
        decimal_places=6,
        validators=[MinValueValidator(Decimal('0.000001'))]
    )
    
    # Stock prices (standard financial precision)
    stock_price = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        help_text="Price per share in USD"
    )
    
    # Percentage fields (like interest rates)
    interest_rate = models.DecimalField(
        max_digits=5,
        decimal_places=4,  # 99.9999%
        validators=[
            MinValueValidator(Decimal('0')),
            MaxValueValidator(Decimal('100'))
        ]
    )
    
    # Large numbers (YouTube views, social media followers)
    view_count = models.BigIntegerField(
        default=0,
        validators=[MinValueValidator(0)]
    )
    
    # Floating point for calculations
    calculated_score = models.FloatField(
        null=True,
        blank=True,
        help_text="Auto-calculated composite score"
    )
    
    # Small positive integers (ratings, quantities)
    rating = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Rate from 1-5 stars"
    )

class EcommerceProduct(models.Model):
    # Price with currency considerations
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))]
    )
    
    # Weight for shipping calculations
    weight_grams = models.PositiveIntegerField(
        help_text="Product weight in grams"
    )
    
    # Dimensions in millimeters
    length_mm = models.PositiveIntegerField(null=True, blank=True)
    width_mm = models.PositiveIntegerField(null=True, blank=True)
    height_mm = models.PositiveIntegerField(null=True, blank=True)
    
    @property
    def shipping_cost(self):
        """Calculate shipping based on weight and dimensions"""
        base_cost = Decimal('5.00')
        weight_cost = (self.weight_grams / 1000) * Decimal('2.50')
        
        # Volume-based pricing for large items
        if all([self.length_mm, self.width_mm, self.height_mm]):
            volume_cm3 = (self.length_mm * self.width_mm * self.height_mm) / 1000
            if volume_cm3 > 10000:  # Larger than 10L
                weight_cost += Decimal('10.00')
        
        return base_cost + weight_cost
```

### Date and Time Fields: Temporal Precision

```python
from django.utils import timezone
from datetime import timedelta

class EventManagement(models.Model):
    # Event name
    name = models.CharField(max_length=200)
    
    # Date only (birthday, anniversary)
    event_date = models.DateField(
        help_text="The date of the event"
    )
    
    # Full timestamp (meeting start time)
    start_datetime = models.DateTimeField(
        help_text="When the event starts"
    )
    
    # End time
    end_datetime = models.DateTimeField(
        help_text="When the event ends"
    )
    
    # Time only (business hours)
    daily_start_time = models.TimeField(
        null=True,
        blank=True,
        help_text="Time when daily activities start"
    )
    
    # Duration field (video length, meeting duration)
    expected_duration = models.DurationField(
        help_text="Expected length of the event"
    )
    
    # Auto timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def clean(self):
        """Validate date relationships"""
        super().clean()
        
        if self.start_datetime and self.end_datetime:
            if self.end_datetime <= self.start_datetime:
                raise ValidationError("End time must be after start time")
        
        # Prevent events in the past
        if self.start_datetime and self.start_datetime < timezone.now():
            raise ValidationError("Cannot create events in the past")
    
    @property
    def is_happening_now(self):
        now = timezone.now()
        return self.start_datetime <= now <= self.end_datetime
    
    @property
    def time_until_start(self):
        if self.start_datetime > timezone.now():
            return self.start_datetime - timezone.now()
        return None

class ContentScheduling(models.Model):
    title = models.CharField(max_length=200)
    
    # Scheduled publication
    publish_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When to automatically publish this content"
    )
    
    # Expiration date
    expires_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When this content should be unpublished"
    )
    
    @property
    def is_published(self):
        now = timezone.now()
        if self.publish_at and self.publish_at > now:
            return False  # Not yet published
        if self.expires_at and self.expires_at < now:
            return False  # Expired
        return True
```

### Boolean Fields: Smart True/False Logic

```python
class UserPreferences(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    # Standard boolean
    email_notifications = models.BooleanField(
        default=True,
        help_text="Receive email notifications"
    )
    
    # Nullable boolean (three states: True, False, None)
    marketing_consent = models.BooleanField(
        null=True,
        blank=True,
        help_text="Consent to marketing emails (None = not asked yet)"
    )
    
    # Privacy settings
    profile_public = models.BooleanField(
        default=False,
        help_text="Make your profile visible to everyone"
    )
    
    show_online_status = models.BooleanField(
        default=True,
        help_text="Show when you're online"
    )
    
    # Feature flags
    beta_features_enabled = models.BooleanField(
        default=False,
        help_text="Enable experimental features"
    )
    
    def clean(self):
        """Business logic validation"""
        super().clean()
        
        # If profile is public, some notifications should be enabled
        if self.profile_public and not self.email_notifications:
            raise ValidationError(
                "Public profiles should have email notifications enabled for security"
            )
```

### File and Image Fields: Media Management

```python
import os
from django.core.validators import FileExtensionValidator

def user_avatar_path(instance, filename):
    """Generate upload path for user avatars"""
    # File will be uploaded to MEDIA_ROOT/avatars/user_<id>/<filename>
    return f'avatars/user_{instance.user.id}/{filename}'

def validate_image_size(image):
    """Custom validator for image file size"""
    file_size = image.file.size
    limit_mb = 5
    if file_size > limit_mb * 1024 * 1024:
        raise ValidationError(f"Max file size is {limit_mb}MB")

class MediaContent(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
    # User avatar with custom path and validation
    avatar = models.ImageField(
        upload_to=user_avatar_path,
        blank=True,
        validators=[validate_image_size],
        help_text="Profile picture (max 5MB)"
    )
    
    # Document upload with file type restriction
    resume = models.FileField(
        upload_to='resumes/%Y/%m/',
        blank=True,
        validators=[
            FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])
        ],
        help_text="Upload your resume (PDF or Word format)"
    )
    
    # Video content
    video_file = models.FileField(
        upload_to='videos/%Y/%m/',
        blank=True,
        validators=[
            FileExtensionValidator(allowed_extensions=['mp4', 'avi', 'mov'])
        ]
    )
    
    # Thumbnail (auto-generated or uploaded)
    video_thumbnail = models.ImageField(
        upload_to='thumbnails/%Y/%m/',
        blank=True
    )
    
    def save(self, *args, **kwargs):
        # Delete old files when new ones are uploaded
        if self.pk:
            old_instance = MediaContent.objects.get(pk=self.pk)
            if old_instance.avatar and old_instance.avatar != self.avatar:
                old_instance.avatar.delete(save=False)
            if old_instance.resume and old_instance.resume != self.resume:
                old_instance.resume.delete(save=False)
        
        super().save(*args, **kwargs)
    
    def delete(self, *args, **kwargs):
        # Delete files when model instance is deleted
        if self.avatar:
            self.avatar.delete(save=False)
        if self.resume:
            self.resume.delete(save=False)
        super().delete(*args, **kwargs)

class ProductImage(models.Model):
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    
    # Original image
    image = models.ImageField(
        upload_to='products/%Y/%m/',
        validators=[validate_image_size]
    )
    
    # Alt text for accessibility
    alt_text = models.CharField(
        max_length=200,
        help_text="Describe the image for screen readers"
    )
    
    # Image metadata
    is_primary = models.BooleanField(default=False)
    sort_order = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['sort_order', 'id']
        
    def clean(self):
        """Ensure only one primary image per product"""
        super().clean()
        
        if self.is_primary:
            # Check if another primary image exists for this product
            existing_primary = ProductImage.objects.filter(
                product=self.product,
                is_primary=True
            ).exclude(pk=self.pk)
            
            if existing_primary.exists():
                raise ValidationError("Product can only have one primary image")
```

### UUID and Custom Identifier Fields

```python
import uuid
from django.db import models

class UniqueContent(models.Model):
    # Auto-generated UUID for public URLs
    public_id = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False
    )
    
    # Custom alphanumeric ID
    custom_id = models.CharField(
        max_length=20,
        unique=True,
        help_text="Custom identifier for this content"
    )
    
    title = models.CharField(max_length=200)
    
    def save(self, *args, **kwargs):
        if not self.custom_id:
            # Generate custom ID like "CONT-A1B2C3"
            import random
            import string
            chars = string.ascii_uppercase + string.digits
            self.custom_id = 'CONT-' + ''.join(random.choices(chars, k=6))
        
        super().save(*args, **kwargs)
    
    def get_absolute_url(self):
        return f'/content/{self.public_id}/'

# URL shortener model
class ShortURL(models.Model):
    # Original long URL
    original_url = models.URLField()
    
    # Short code (like bit.ly)
    short_code = models.CharField(
        max_length=10,
        unique=True,
        db_index=True
    )
    
    # Usage statistics
    click_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        if not self.short_code:
            self.short_code = self.generate_short_code()
        super().save(*args, **kwargs)
    
    def generate_short_code(self):
        import random
        import string
        chars = string.ascii_letters + string.digits
        while True:
            code = ''.join(random.choices(chars, k=6))
            if not ShortURL.objects.filter(short_code=code).exists():
                return code
    
    def __str__(self):
        return f"{self.short_code} -> {self.original_url[:50]}"
```

### JSON and Flexible Data Fields

```python
class FlexibleContent(models.Model):
    name = models.CharField(max_length=200)
    
    # JSON field for flexible data storage
    metadata = models.JSONField(
        default=dict,
        blank=True,
        help_text="Flexible metadata storage"
    )
    
    # Configuration settings
    settings = models.JSONField(
        default=lambda: {
            'notifications': True,
            'theme': 'light',
            'language': 'en'
        },
        help_text="User or application settings"
    )
    
    # Analytics data
    analytics = models.JSONField(
        default=dict,
        blank=True,
        help_text="Store analytics and metrics"
    )
    
    def add_metadata(self, key, value):
        """Helper method to add metadata"""
        self.metadata[key] = value
        self.save(update_fields=['metadata'])
    
    def get_setting(self, key, default=None):
        """Get a setting value with fallback"""
        return self.settings.get(key, default)
    
    def update_setting(self, key, value):
        """Update a single setting"""
        self.settings[key] = value
        self.save(update_fields=['settings'])
    
    def track_event(self, event_name, data=None):
        """Add analytics event"""
        import datetime
        
        if 'events' not in self.analytics:
            self.analytics['events'] = []
        
        event = {
            'name': event_name,
            'timestamp': datetime.datetime.now().isoformat(),
            'data': data or {}
        }
        
        self.analytics['events'].append(event)
        self.save(update_fields=['analytics'])

class ProductVariant(models.Model):
    """E-commerce product with flexible attributes"""
    product_name = models.CharField(max_length=200)
    
    # Flexible attributes (size, color, material, etc.)
    attributes = models.JSONField(
        default=dict,
        help_text="Product attributes like size, color, material"
    )
    
    # Inventory by location
    inventory = models.JSONField(
        default=dict,
        help_text="Stock levels by warehouse/location"
    )
    
    # Pricing by region
    pricing = models.JSONField(
        default=dict,
        help_text="Prices in different currencies/regions"
    )
    
    def get_attribute(self, attr_name):
        """Get product attribute"""
        return self.attributes.get(attr_name)
    
    def get_stock(self, location='main'):
        """Get stock for specific location"""
        return self.inventory.get(location, 0)
    
    def get_price(self, currency='USD'):
        """Get price in specific currency"""
        return self.pricing.get(currency)
    
    def update_stock(self, location, quantity):
        """Update stock for location"""
        self.inventory[location] = quantity
        self.save(update_fields=['inventory'])
```

## Custom Validators: Building Smart Data Rules

### Email Domain Validation
```python
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
import re

def validate_corporate_email(email):
    """Ensure email is from a corporate domain (not Gmail, Yahoo, etc.)"""
    personal_domains = [
        'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
        'aol.com', 'icloud.com', 'protonmail.com'
    ]
    
    domain = email.split('@')[1].lower()
    if domain in personal_domains:
        raise ValidationError(f'Please use a corporate email address, not {domain}')

def validate_strong_password(password):
    """Validate password strength"""
    if len(password) < 8:
        raise ValidationError('Password must be at least 8 characters long')
    
    if not re.search(r'[A-Z]', password):
        raise ValidationError('Password must contain at least one uppercase letter')
    
    if not re.search(r'[a-z]', password):
        raise ValidationError('Password must contain at least one lowercase letter')
    
    if not re.search(r'\\d', password):
        raise ValidationError('Password must contain at least one digit')
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        raise ValidationError('Password must contain at least one special character')

class CorporateUser(models.Model):
    email = models.EmailField(
        unique=True,
        validators=[validate_corporate_email]
    )
    
    password = models.CharField(
        max_length=128,
        validators=[validate_strong_password]
    )
```

### File Size and Type Validation
```python
def validate_file_size(file):
    """Validate uploaded file size"""
    max_size = 10 * 1024 * 1024  # 10MB
    if file.size > max_size:
        raise ValidationError(f'File too large. Size should not exceed 10MB')

def validate_image_dimensions(image):
    """Validate image dimensions"""
    max_width = 2000
    max_height = 2000
    
    img = Image.open(image)
    width, height = img.size
    
    if width > max_width or height > max_height:
        raise ValidationError(
            f'Image dimensions too large. Maximum size: {max_width}x{max_height}px'
        )

class UserUpload(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    
    document = models.FileField(
        upload_to='documents/',
        validators=[
            validate_file_size,
            FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])
        ]
    )
    
    profile_image = models.ImageField(
        upload_to='profiles/',
        validators=[validate_file_size, validate_image_dimensions]
    )
```

### Business Logic Validation
```python
def validate_future_date(date):
    """Ensure date is in the future"""
    from datetime import date as date_class
    if date <= date_class.today():
        raise ValidationError('Date must be in the future')

def validate_business_hours(time):
    """Ensure time is within business hours"""
    from datetime import time as time_class
    start = time_class(9, 0)  # 9:00 AM
    end = time_class(17, 0)   # 5:00 PM
    
    if not start <= time <= end:
        raise ValidationError('Time must be within business hours (9 AM - 5 PM)')

class BusinessEvent(models.Model):
    title = models.CharField(max_length=200)
    
    event_date = models.DateField(
        validators=[validate_future_date]
    )
    
    start_time = models.TimeField(
        validators=[validate_business_hours]
    )
    
    # Custom validation at model level
    def clean(self):
        super().clean()
        
        # Check for conflicting events
        if self.event_date and self.start_time:
            conflicting = BusinessEvent.objects.filter(
                event_date=self.event_date,
                start_time=self.start_time
            ).exclude(pk=self.pk)
            
            if conflicting.exists():
                raise ValidationError('Another event is scheduled at this time')
```

## Field Options Mastery: Fine-Tuning Your Data

### Advanced Field Configuration
```python
class AdvancedProduct(models.Model):
    # Product identification
    name = models.CharField(
        max_length=200,
        db_index=True,  # Add database index for faster queries
        help_text="Product name as displayed to customers"
    )
    
    # SEO-friendly URL slug
    slug = models.SlugField(
        max_length=200,
        unique=True,
        db_index=True,
        help_text="URL-friendly version of product name"
    )
    
    # Product description
    description = models.TextField(
        blank=True,  # Allow empty in forms
        null=False,  # Don't allow NULL in database
        help_text="Detailed product description"
    )
    
    # Pricing with precision
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        db_index=True,  # Index for price range queries
        validators=[MinValueValidator(Decimal('0.01'))],
        help_text="Price in USD"
    )
    
    # Status with choices
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('discontinued', 'Discontinued'),
        ('out_of_stock', 'Out of Stock'),
    ]
    
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='draft',
        db_index=True,  # Index for status filtering
        help_text="Current product status"
    )
    
    # Timestamps
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True,  # Index for date-based queries
        help_text="When the product was created"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        help_text="When the product was last updated"
    )
    
    # Featured flag
    is_featured = models.BooleanField(
        default=False,
        db_index=True,  # Index for featured product queries
        help_text="Show this product in featured sections"
    )
    
    # Internal notes (not shown to customers)
    internal_notes = models.TextField(
        blank=True,
        help_text="Internal notes for staff only"
    )
    
    class Meta:
        # Composite indexes for common query patterns
        indexes = [
            models.Index(fields=['status', '-created_at']),
            models.Index(fields=['is_featured', 'status']),
            models.Index(fields=['price']),
        ]
        
        # Default ordering
        ordering = ['-created_at']
        
        # Custom table name
        db_table = 'advanced_products'
        
        # Verbose names for admin
        verbose_name = 'Advanced Product'
        verbose_name_plural = 'Advanced Products'
```

Advanced Django model fields are like having a complete workshop of specialized tools. Each field type, validator, and option serves a specific purpose in building robust, scalable applications. Master these tools, and you'll be able to model any real-world complexity with precision and elegance! 🛠️

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/ref/models/fields/
    ''',
    "is_free": False,
    "xp_reward": 105,
    "exercises": [
        {
            "id": "advanced-fields-system",
            "title": "Build Advanced Content Management System",
            "type": "project",
            "instructions": """Create a comprehensive content management system using advanced Django model fields:

1. User system with advanced validation and file uploads
2. Content models with rich metadata and scheduling
3. Media management with file type validation
4. E-commerce integration with flexible pricing
5. Analytics tracking with JSON fields

Your solution should demonstrate:
- All major field types with proper validation
- Custom validators for business logic
- File upload handling with size/type restrictions
- JSON fields for flexible data storage
- Proper indexing for performance
- Clean methods for cross-field validation""",
            "starter_code": """from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, FileExtensionValidator
from django.core.exceptions import ValidationError
from decimal import Decimal
import uuid

# Create your advanced models here:

# 1. Advanced User Profile with validation
class UserProfile(models.Model):
    # Add advanced fields with custom validation
    pass

# 2. Content model with scheduling and metadata
class Content(models.Model):
    # Rich content model with advanced fields
    pass

# 3. Media file model with validation
class MediaFile(models.Model):
    # File uploads with advanced validation
    pass

# 4. Product model with flexible attributes
class Product(models.Model):
    # E-commerce product with JSON fields
    pass

# 5. Analytics model with JSON tracking
class Analytics(models.Model):
    # Analytics tracking with flexible data
    pass

# Add custom validators and clean methods
# Include proper field options (db_index, help_text, etc.)""",
            "solution": """from django.contrib.auth.models import User
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, FileExtensionValidator
from django.core.exceptions import ValidationError
from django.utils import timezone
from decimal import Decimal
import uuid
import re
from PIL import Image

# Custom Validators
def validate_corporate_email(email):
    \"\"\"Ensure email is from a corporate domain\"\"\"
    personal_domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']
    domain = email.split('@')[1].lower()
    if domain in personal_domains:
        raise ValidationError(f'Please use a corporate email address, not {domain}')

def validate_phone_number(phone):
    \"\"\"Validate phone number format\"\"\"
    phone_pattern = r'^\\+?[1-9]\\d{1,14}$'  # International format
    if not re.match(phone_pattern, phone.replace(' ', '').replace('-', '')):
        raise ValidationError('Enter a valid phone number in international format')

def validate_image_size(image):
    \"\"\"Validate uploaded image size\"\"\"
    max_size = 5 * 1024 * 1024  # 5MB
    if image.size > max_size:
        raise ValidationError('Image size cannot exceed 5MB')

def validate_image_dimensions(image):
    \"\"\"Validate image dimensions\"\"\"
    img = Image.open(image)
    max_width, max_height = 2000, 2000
    
    if img.width > max_width or img.height > max_height:
        raise ValidationError(f'Image dimensions cannot exceed {max_width}x{max_height} pixels')

def validate_future_date(date):
    \"\"\"Ensure date is in the future\"\"\"
    if date <= timezone.now().date():
        raise ValidationError('Date must be in the future')

def user_upload_path(instance, filename):
    \"\"\"Generate upload path for user files\"\"\"
    return f'users/{instance.user.id}/{filename}'

class UserProfile(models.Model):
    ROLE_CHOICES = [
        ('viewer', 'Viewer'),
        ('editor', 'Editor'),
        ('admin', 'Administrator'),
        ('super_admin', 'Super Administrator'),
    ]
    
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile'
    )
    
    # Contact information with validation
    corporate_email = models.EmailField(
        blank=True,
        validators=[validate_corporate_email],
        help_text="Your corporate email address"
    )
    
    phone_number = models.CharField(
        max_length=20,
        blank=True,
        validators=[validate_phone_number],
        help_text="Phone number in international format"
    )
    
    # Profile information
    bio = models.TextField(
        max_length=1000,
        blank=True,
        help_text="Tell us about yourself (max 1000 characters)"
    )
    
    website = models.URLField(
        blank=True,
        max_length=500,
        help_text="Your personal or professional website"
    )
    
    # Profile image with validation
    avatar = models.ImageField(
        upload_to=user_upload_path,
        blank=True,
        validators=[validate_image_size, validate_image_dimensions],
        help_text="Profile picture (max 5MB, 2000x2000px)"
    )
    
    # Professional information
    job_title = models.CharField(max_length=200, blank=True)
    company = models.CharField(max_length=200, blank=True)
    
    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='viewer',
        db_index=True
    )
    
    # Location
    country = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=100, blank=True)
    timezone = models.CharField(max_length=50, default='UTC')
    
    # Preferences stored as JSON
    preferences = models.JSONField(
        default=lambda: {
            'theme': 'light',
            'language': 'en',
            'notifications': {
                'email': True,
                'push': True,
                'marketing': False
            }
        },
        help_text="User preferences and settings"
    )
    
    # Verification status
    is_verified = models.BooleanField(default=False, db_index=True)
    verification_date = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['role', 'is_verified']),
            models.Index(fields=['-created_at']),
        ]
    
    def __str__(self):
        return f"{self.user.username}'s Profile"
    
    def get_preference(self, key, default=None):
        \"\"\"Get a specific preference value\"\"\"
        return self.preferences.get(key, default)
    
    def update_preference(self, key, value):
        \"\"\"Update a single preference\"\"\"
        self.preferences[key] = value
        self.save(update_fields=['preferences'])

class Content(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('scheduled', 'Scheduled'),
        ('published', 'Published'),
        ('archived', 'Archived'),
    ]
    
    CONTENT_TYPES = [
        ('article', 'Article'),
        ('tutorial', 'Tutorial'),
        ('news', 'News'),
        ('announcement', 'Announcement'),
    ]
    
    # Unique identifier
    public_id = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False,
        db_index=True
    )
    
    # Content basics
    title = models.CharField(
        max_length=300,
        db_index=True,
        help_text="Content title (max 300 characters)"
    )
    
    slug = models.SlugField(
        max_length=300,
        unique=True,
        db_index=True,
        help_text="URL-friendly version of title"
    )
    
    summary = models.CharField(
        max_length=500,
        blank=True,
        help_text="Brief summary for previews (max 500 characters)"
    )
    
    content_body = models.TextField(help_text="Main content body")
    
    # Classification
    content_type = models.CharField(
        max_length=20,
        choices=CONTENT_TYPES,
        default='article',
        db_index=True
    )
    
    # Author and ownership
    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='authored_content'
    )
    
    editor = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='edited_content',
        help_text="Last person to edit this content"
    )
    
    # Publishing workflow
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='draft',
        db_index=True
    )
    
    # Scheduling
    scheduled_publish_at = models.DateTimeField(
        null=True,
        blank=True,
        validators=[validate_future_date],
        help_text="When to automatically publish this content"
    )
    
    published_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="When to automatically unpublish this content"
    )
    
    # Engagement metrics
    view_count = models.PositiveIntegerField(default=0, db_index=True)
    like_count = models.PositiveIntegerField(default=0)
    share_count = models.PositiveIntegerField(default=0)
    
    # SEO and metadata
    meta_description = models.TextField(
        max_length=160,
        blank=True,
        help_text="Meta description for search engines (max 160 characters)"
    )
    
    keywords = models.TextField(
        blank=True,
        help_text="Comma-separated keywords for SEO"
    )
    
    # Flexible metadata storage
    metadata = models.JSONField(
        default=dict,
        blank=True,
        help_text="Additional metadata and custom fields"
    )
    
    # Features and settings
    is_featured = models.BooleanField(default=False, db_index=True)
    allow_comments = models.BooleanField(default=True)
    is_premium = models.BooleanField(default=False, db_index=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['status', '-published_at']),
            models.Index(fields=['content_type', 'is_featured']),
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['-view_count']),
        ]
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def clean(self):
        \"\"\"Model validation\"\"\"
        super().clean()
        
        # Validate publishing schedule
        if self.scheduled_publish_at and self.expires_at:
            if self.expires_at <= self.scheduled_publish_at:
                raise ValidationError('Expiration date must be after publication date')
        
        # Featured content should be published
        if self.is_featured and self.status not in ['published', 'scheduled']:
            raise ValidationError('Featured content must be published or scheduled')
    
    @property
    def is_published(self):
        \"\"\"Check if content is currently published\"\"\"
        now = timezone.now()
        if self.status != 'published':
            return False
        if self.published_at and self.published_at > now:
            return False
        if self.expires_at and self.expires_at < now:
            return False
        return True
    
    @property
    def reading_time(self):
        \"\"\"Estimate reading time in minutes\"\"\"
        word_count = len(self.content_body.split())
        return max(1, word_count // 200)  # 200 words per minute

class MediaFile(models.Model):
    FILE_TYPES = [
        ('image', 'Image'),
        ('video', 'Video'),
        ('audio', 'Audio'),
        ('document', 'Document'),
        ('other', 'Other'),
    ]
    
    # File identification
    file_id = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False
    )
    
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    # File upload with comprehensive validation
    file = models.FileField(
        upload_to='media/%Y/%m/%d/',
        validators=[
            FileExtensionValidator(
                allowed_extensions=[
                    'jpg', 'jpeg', 'png', 'gif', 'webp',  # Images
                    'mp4', 'avi', 'mov', 'webm',          # Videos
                    'mp3', 'wav', 'ogg',                  # Audio
                    'pdf', 'doc', 'docx', 'txt'          # Documents
                ]
            )
        ]
    )
    
    file_type = models.CharField(
        max_length=10,
        choices=FILE_TYPES,
        db_index=True
    )
    
    file_size = models.PositiveIntegerField(
        help_text="File size in bytes"
    )
    
    mime_type = models.CharField(max_length=100, blank=True)
    
    # Image-specific fields
    width = models.PositiveIntegerField(null=True, blank=True)
    height = models.PositiveIntegerField(null=True, blank=True)
    
    # Video/Audio-specific fields
    duration = models.DurationField(null=True, blank=True)
    
    # Ownership and access
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='uploaded_files'
    )
    
    is_public = models.BooleanField(default=False)
    
    # Usage tracking
    download_count = models.PositiveIntegerField(default=0)
    
    # File metadata
    metadata = models.JSONField(
        default=dict,
        blank=True,
        help_text="File metadata (EXIF, codec info, etc.)"
    )
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['file_type', 'is_public']),
            models.Index(fields=['uploaded_by', '-created_at']),
        ]
    
    def __str__(self):
        return self.title
    
    def clean(self):
        \"\"\"File validation\"\"\"
        super().clean()
        
        if self.file:
            # Check file size (10MB limit)
            max_size = 10 * 1024 * 1024
            if self.file.size > max_size:
                raise ValidationError('File size cannot exceed 10MB')
            
            self.file_size = self.file.size
            
            # Auto-detect file type based on extension
            extension = self.file.name.lower().split('.')[-1]
            image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp']
            video_extensions = ['mp4', 'avi', 'mov', 'webm']
            audio_extensions = ['mp3', 'wav', 'ogg']
            document_extensions = ['pdf', 'doc', 'docx', 'txt']
            
            if extension in image_extensions:
                self.file_type = 'image'
            elif extension in video_extensions:
                self.file_type = 'video'
            elif extension in audio_extensions:
                self.file_type = 'audio'
            elif extension in document_extensions:
                self.file_type = 'document'
            else:
                self.file_type = 'other'

class Product(models.Model):
    PRODUCT_STATUS = [
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('discontinued', 'Discontinued'),
        ('out_of_stock', 'Out of Stock'),
    ]
    
    # Product identification
    product_id = models.CharField(max_length=50, unique=True)
    name = models.CharField(max_length=300, db_index=True)
    slug = models.SlugField(max_length=300, unique=True)
    
    # Product details
    description = models.TextField()
    short_description = models.CharField(max_length=500, blank=True)
    
    # Pricing (supports multiple currencies)
    base_price = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))]
    )
    
    # Flexible pricing for different markets/currencies
    pricing = models.JSONField(
        default=lambda: {'USD': None},
        help_text="Prices in different currencies"
    )
    
    # Product attributes (size, color, material, etc.)
    attributes = models.JSONField(
        default=dict,
        help_text="Product attributes like size, color, weight"
    )
    
    # Inventory management
    stock_quantity = models.PositiveIntegerField(default=0)
    low_stock_threshold = models.PositiveIntegerField(default=10)
    
    # Inventory by location/warehouse
    inventory_locations = models.JSONField(
        default=dict,
        help_text="Stock levels by warehouse/location"
    )
    
    # Product classification
    category = models.CharField(max_length=100, db_index=True)
    tags = models.JSONField(
        default=list,
        blank=True,
        help_text="Product tags for categorization"
    )
    
    # Status and flags
    status = models.CharField(
        max_length=20,
        choices=PRODUCT_STATUS,
        default='draft',
        db_index=True
    )
    
    is_digital = models.BooleanField(default=False)
    is_featured = models.BooleanField(default=False, db_index=True)
    requires_shipping = models.BooleanField(default=True)
    
    # SEO
    meta_title = models.CharField(max_length=200, blank=True)
    meta_description = models.CharField(max_length=300, blank=True)
    
    # Product metrics
    view_count = models.PositiveIntegerField(default=0)
    sales_count = models.PositiveIntegerField(default=0)
    
    # Additional product data
    specifications = models.JSONField(
        default=dict,
        help_text="Technical specifications"
    )
    
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['status', 'is_featured']),
            models.Index(fields=['category', '-created_at']),
            models.Index(fields=['-sales_count']),
        ]
    
    def __str__(self):
        return self.name
    
    def get_price(self, currency='USD'):
        \"\"\"Get price in specific currency\"\"\"
        return self.pricing.get(currency, self.base_price)
    
    def update_price(self, currency, price):
        \"\"\"Update price for specific currency\"\"\"
        self.pricing[currency] = float(price)
        self.save(update_fields=['pricing'])
    
    def get_stock(self, location='main'):
        \"\"\"Get stock for specific location\"\"\"
        return self.inventory_locations.get(location, 0)
    
    def update_stock(self, location, quantity):
        \"\"\"Update stock for specific location\"\"\"
        self.inventory_locations[location] = quantity
        # Also update main stock quantity
        self.stock_quantity = sum(self.inventory_locations.values())
        self.save(update_fields=['inventory_locations', 'stock_quantity'])
    
    @property
    def is_in_stock(self):
        return self.stock_quantity > 0
    
    @property
    def is_low_stock(self):
        return 0 < self.stock_quantity <= self.low_stock_threshold

class Analytics(models.Model):
    METRIC_TYPES = [
        ('page_view', 'Page View'),
        ('user_action', 'User Action'),
        ('conversion', 'Conversion'),
        ('performance', 'Performance'),
    ]
    
    # Event identification
    event_id = models.UUIDField(default=uuid.uuid4, unique=True)
    metric_type = models.CharField(
        max_length=20,
        choices=METRIC_TYPES,
        db_index=True
    )
    
    # Event details
    event_name = models.CharField(max_length=100, db_index=True)
    
    # User and session info
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='analytics_events'
    )
    
    session_id = models.CharField(max_length=100, db_index=True)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)
    
    # Event data (flexible JSON storage)
    event_data = models.JSONField(
        default=dict,
        help_text="Flexible event data storage"
    )
    
    # Context information
    page_url = models.URLField(blank=True)
    referrer_url = models.URLField(blank=True)
    
    # Geographic data
    country = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=100, blank=True)
    
    # Device information
    device_info = models.JSONField(
        default=dict,
        help_text="Device and browser information"
    )
    
    # Timing
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['metric_type', '-timestamp']),
            models.Index(fields=['event_name', '-timestamp']),
            models.Index(fields=['user', '-timestamp']),
            models.Index(fields=['session_id', '-timestamp']),
        ]
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.event_name} - {self.timestamp}"
    
    @classmethod
    def track_event(cls, event_name, user=None, session_id=None, 
                   ip_address=None, event_data=None, **kwargs):
        \"\"\"Helper method to track analytics events\"\"\"
        return cls.objects.create(
            event_name=event_name,
            user=user,
            session_id=session_id,
            ip_address=ip_address,
            event_data=event_data or {},
            **kwargs
        )""",
            "test_cases": [
                {
                    "name": "Models use advanced field types and validation",
                    "input": "",
                    "expected_contains": ["JSONField", "UUIDField", "DecimalField", "validators", "clean"]
                }
            ],
            "xp_reward": 150,
            "hints": [
                "Use JSONField for flexible data storage like preferences and metadata",
                "Add custom validators for business logic validation",
                "Use UUIDField for public identifiers and secure URLs",
                "Include proper field options like db_index and help_text",
                "Implement clean() methods for cross-field validation"
            ]
        }
    ]
}