"""
Django Settings: Configuration Mastery - Enhanced Educational Version
Learn Django's settings system through proper teaching and hands-on practice
"""

DJANGO_SETTINGS_ENHANCED_LESSON = {
    "id": 1,
    "chapter": 1,
    "title": "Django Settings: Configuration Mastery",
    "slug": "django_settings",
    "description": "Master Django's settings system, environment configurations, security best practices, and deployment patterns through hands-on learning",
    "content": '''# Django Settings: Configuration Mastery

## 🎯 Why Django Settings Matter

Welcome to your first Django lesson! Let's start with the **foundation** of every Django project: the settings file.

Think of Django settings as your project's **control panel**. Just like how your phone has settings to control brightness, notifications, and apps, Django has settings to control how your web application behaves.

## 📚 What You'll Learn Today

By the end of this lesson, you'll understand:
- **What Django settings are** and why they're crucial
- **How to structure settings** for different environments (development vs production)
- **Security best practices** to keep your application safe
- **Common settings patterns** used by professional developers

## 🏠 The Settings File: Your Project's Home Base

When you create a Django project with `django-admin startproject myproject`, Django creates a `settings.py` file. This is where **everything** is configured.

### Basic Settings Structure

```python
# settings.py - Every Django project has one

# Basic Project Information
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'your-secret-key-here'
DEBUG = True

# Security Settings
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Applications
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    # Your custom apps go here
]

# Database Configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
```

**Why does this matter?** Each setting controls a specific aspect of your Django application. Let's explore the most important ones.

## 🔧 Essential Django Settings Every Developer Must Know

### 1. DEBUG Setting - Your Development Best Friend

```python
# Development
DEBUG = True  # Shows detailed error pages

# Production  
DEBUG = False  # Shows generic error pages (safer)
```

**What DEBUG does:**
- When `True`: Shows detailed error information (great for development)
- When `False`: Shows generic error pages (essential for production security)

**Real-world tip:** Never deploy with `DEBUG = True` - it exposes sensitive information!

### 2. SECRET_KEY - Your Application's Password

```python
# Good practice - load from environment variable
import os
SECRET_KEY = os.environ.get('SECRET_KEY')

# Bad practice - hardcoded in settings
SECRET_KEY = 'django-insecure-abc123'  # Don't do this!
```

**What SECRET_KEY does:**
- Used for cryptographic signing (sessions, cookies, CSRF tokens)
- Must be unique and secret for each project
- Should never be committed to version control

### 3. ALLOWED_HOSTS - Who Can Access Your Site

```python
# Development
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Production
ALLOWED_HOSTS = ['mywebsite.com', 'www.mywebsite.com']

# Multiple environments
ALLOWED_HOSTS = ['localhost', '127.0.0.1', 'mywebsite.com']
```

**Security protection:** Prevents HTTP Host header attacks.

### 4. INSTALLED_APPS - Your Project's Components

```python
INSTALLED_APPS = [
    # Django's built-in apps
    'django.contrib.admin',      # Admin interface
    'django.contrib.auth',       # User authentication
    'django.contrib.contenttypes',  # Content types framework
    
    # Third-party apps
    'rest_framework',            # Django REST Framework
    'corsheaders',              # CORS headers
    
    # Your custom apps
    'blog',                     # Your blog app
    'users',                    # Your user management app
]
```

**Teaching moment:** Apps are like LEGO blocks - you add them to build features!

## 🌍 Environment-Specific Settings: The Professional Way

Real projects need different settings for different environments. Here's how professionals structure their settings:

### Method 1: Environment Variables (Recommended)

```python
# settings.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Environment-based configuration
DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'
SECRET_KEY = os.environ.get('SECRET_KEY')

# Database - changes based on environment
if os.environ.get('ENVIRONMENT') == 'production':
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('DB_NAME'),
            'USER': os.environ.get('DB_USER'),
            'PASSWORD': os.environ.get('DB_PASSWORD'),
            'HOST': os.environ.get('DB_HOST'),
            'PORT': os.environ.get('DB_PORT', '5432'),
        }
    }
else:
    # Development database
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }
```

### Method 2: Multiple Settings Files

```python
# settings/
#   __init__.py
#   base.py      # Common settings
#   development.py  # Development overrides
#   production.py   # Production overrides

# base.py - Common settings for all environments
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    # ... common apps
]

# development.py
from .base import *

DEBUG = True
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# production.py  
from .base import *

DEBUG = False
ALLOWED_HOSTS = ['mywebsite.com', 'www.mywebsite.com']

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        # ... production database config
    }
}
```

## 🔒 Security Settings: Protecting Your Application

Security is **not optional** in web development. Here are essential security settings:

### Essential Security Settings

```python
# Security settings for production

# SSL/HTTPS settings
SECURE_SSL_REDIRECT = True           # Force HTTPS
SECURE_HSTS_SECONDS = 31536000       # 1 year
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Cookie security
SESSION_COOKIE_SECURE = True         # HTTPS only
CSRF_COOKIE_SECURE = True           # HTTPS only
SESSION_COOKIE_HTTPONLY = True      # No JavaScript access

# Content security
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'            # Prevent clickjacking
```

### Password Security

```python
# Strong password hashing
AUTH_PASSWORD_HASHERS = [
    'django.contrib.auth.hashers.Argon2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher',
    'django.contrib.auth.hashers.BCryptSHA256PasswordHasher',
]

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 8,}
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]
```

## 📁 Static Files and Media Settings

Django needs to know where to find CSS, JavaScript, images, and user uploads:

```python
# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'  # For production
STATICFILES_DIRS = [
    BASE_DIR / 'static',  # Development static files
]

# Media files (User uploads)
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# Static files finders
STATICFILES_FINDERS = [
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
]
```

## 📧 Email Configuration

Configure email for user registration, password resets, and notifications:

```python
# Email settings for different environments

# Development - print emails to console
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Production - real SMTP server
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD')
DEFAULT_FROM_EMAIL = 'noreply@mywebsite.com'
```

## 🚀 Performance Settings

Optimize your Django application for better performance:

```python
# Caching
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
    }
}

# Session configuration
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'default'
SESSION_COOKIE_AGE = 86400  # 1 day

# Database optimization
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'OPTIONS': {
            'MAX_CONNS': 20,
            'CONN_MAX_AGE': 300,  # 5 minutes
        },
        # ... other settings
    }
}
```

## 🛠️ Common Settings Patterns

### Using python-decouple for Environment Variables

```python
# pip install python-decouple
from decouple import config, Csv

DEBUG = config('DEBUG', default=False, cast=bool)
SECRET_KEY = config('SECRET_KEY')
ALLOWED_HOSTS = config('ALLOWED_HOSTS', cast=Csv())

DATABASE_URL = config('DATABASE_URL')
DATABASES = {
    'default': dj_database_url.parse(DATABASE_URL)
}
```

### Settings Validation

```python
# Validate critical settings
import sys

if not SECRET_KEY:
    print("ERROR: SECRET_KEY environment variable is required!")
    sys.exit(1)

if DEBUG and not ALLOWED_HOSTS:
    print("WARNING: ALLOWED_HOSTS is empty in DEBUG mode")
```

## ✅ Settings Best Practices Checklist

**Security:**
- ✅ Never commit SECRET_KEY to version control
- ✅ Use environment variables for sensitive data
- ✅ Set DEBUG = False in production
- ✅ Configure proper ALLOWED_HOSTS
- ✅ Enable HTTPS security headers

**Organization:**
- ✅ Separate settings for different environments
- ✅ Use meaningful variable names
- ✅ Add comments explaining complex settings
- ✅ Group related settings together

**Performance:**
- ✅ Configure appropriate caching
- ✅ Optimize database connections
- ✅ Set up static file serving correctly
- ✅ Configure logging for monitoring

## 🎯 What's Next?

Now that you understand Django settings, you're ready to:
1. **Create Django applications** (our next lesson!)
2. **Configure databases** for your projects
3. **Set up user authentication** securely
4. **Deploy your applications** to production

Remember: **Good settings are the foundation of great Django applications!**
    ''',
    "is_free": True,
    "xp_reward": 75,
    "exercises": [
        {
            "id": "settings-basics-quiz",
            "title": "🧠 Django Settings Fundamentals Quiz",
            "type": "quiz",
            "instructions": "Test your understanding of Django settings basics before hands-on practice.",
            "questions": [
                {
                    "question": "What should you NEVER do with the SECRET_KEY setting?",
                    "options": [
                        "Load it from an environment variable",
                        "Commit it to version control (Git)",
                        "Use it for cryptographic operations",
                        "Make it unique for each project"
                    ],
                    "correct": 1,
                    "explanation": "SECRET_KEY should never be committed to version control as it's sensitive information. Always use environment variables or secure key management."
                },
                {
                    "question": "Which DEBUG setting is correct for production?",
                    "options": ["DEBUG = True", "DEBUG = False", "DEBUG = 'production'", "DEBUG = None"],
                    "correct": 1,
                    "explanation": "DEBUG must be False in production to prevent exposing sensitive error information to users."
                },
                {
                    "question": "What does ALLOWED_HOSTS protect against?",
                    "options": [
                        "SQL injection attacks",
                        "Cross-site scripting (XSS)",
                        "HTTP Host header attacks", 
                        "CSRF attacks"
                    ],
                    "correct": 2,
                    "explanation": "ALLOWED_HOSTS prevents HTTP Host header attacks by validating the Host header in incoming requests."
                },
                {
                    "question": "Which app is automatically included in Django for user authentication?",
                    "options": [
                        "django.contrib.sessions",
                        "django.contrib.auth",
                        "django.contrib.admin", 
                        "django.contrib.contenttypes"
                    ],
                    "correct": 1,
                    "explanation": "django.contrib.auth provides Django's built-in user authentication system."
                }
            ],
            "xp_reward": 20
        },
        {
            "id": "create-basic-settings",
            "title": "🛠️ Create Your First Django Settings File",
            "type": "practice",
            "instructions": """Let's create a proper Django settings file from scratch! You'll configure basic settings for a blog project.

**Scenario:** You're building a personal blog called 'MyBlog' and need to set up the initial configuration.

**Your Tasks:**
1. Set basic project information
2. Configure applications needed for a blog
3. Set up database configuration 
4. Add security settings
5. Configure static files

**Use this template and fill in the missing parts:**""",
            "starter_code": """# MyBlog Django Settings
# Complete the missing configuration

from pathlib import Path
import os

# Build paths inside the project
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
# TODO: Add a secret key (for learning, you can use a simple string)
SECRET_KEY = 

# SECURITY WARNING: don't run with debug turned on in production!
# TODO: Set DEBUG to True for development
DEBUG = 

# TODO: Add allowed hosts for development (localhost and 127.0.0.1)
ALLOWED_HOSTS = 

# Application definition
# TODO: Add the required Django apps for a blog:
# - django.contrib.admin (admin interface)
# - django.contrib.auth (user authentication) 
# - django.contrib.contenttypes (content types)
# - django.contrib.sessions (session framework)
# - django.contrib.messages (messaging framework)
# - django.contrib.staticfiles (static files)
# - blog (your custom blog app)
INSTALLED_APPS = [
    
]

# TODO: Add the default Django middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myblog.urls'

# TODO: Configure database to use SQLite for development
DATABASES = {
    'default': {
        
    }
}

# TODO: Add internationalization settings
LANGUAGE_CODE = 
TIME_ZONE = 
USE_I18N = True
USE_TZ = True

# TODO: Configure static files
STATIC_URL = 
STATICFILES_DIRS = [
    
]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'""",
            "solution": """# MyBlog Django Settings
from pathlib import Path
import os

# Build paths inside the project
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'django-insecure-your-secret-key-here-change-in-production'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Allowed hosts for development
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'blog',  # Your custom blog app
]

# Default Django middleware
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myblog.urls'

# Database configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATICFILES_DIRS = [
    BASE_DIR / 'static',
]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'""",
            "xp_reward": 35,
            "hints": [
                "SECRET_KEY can be any string for learning - use something descriptive",
                "DEBUG = True is correct for development environment",
                "ALLOWED_HOSTS should include 'localhost' and '127.0.0.1'",
                "All django.contrib.* apps are Django's built-in applications",
                "SQLite engine is 'django.db.backends.sqlite3'"
            ]
        },
        {
            "id": "environment-configuration",
            "title": "🌍 Environment-Specific Configuration",
            "type": "challenge",
            "instructions": """Now let's learn how professional developers handle different environments! You'll create settings that work for both development and production.

**Real-world scenario:** Your blog is ready to deploy! You need to configure settings that automatically adapt to development and production environments using environment variables.

**Your mission:**
1. Use environment variables for sensitive data
2. Create database configuration that works in both environments  
3. Add production security settings
4. Set up email configuration for both environments""",
            "starter_code": """# Advanced Settings Configuration
# Create environment-aware settings

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# TODO: Load SECRET_KEY from environment variable 'SECRET_KEY'
# Use a fallback for development: 'dev-secret-key-change-me'
SECRET_KEY = 

# TODO: Load DEBUG from environment variable 'DEBUG' 
# Convert string to boolean (default to True if not set)
DEBUG = 

# TODO: Load ALLOWED_HOSTS from environment variable 'ALLOWED_HOSTS'
# Split by comma and default to ['localhost', '127.0.0.1'] for development
ALLOWED_HOSTS = 

# Standard Django apps
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth', 
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'blog',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myblog.urls'

# TODO: Smart database configuration
# If DATABASE_URL environment variable exists, use PostgreSQL for production
# Otherwise, use SQLite for development
DATABASE_URL = os.environ.get('DATABASE_URL')
if DATABASE_URL:
    # Production database (PostgreSQL)
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('DB_NAME'),
            'USER': os.environ.get('DB_USER'),
            'PASSWORD': os.environ.get('DB_PASSWORD'),
            'HOST': os.environ.get('DB_HOST', 'localhost'),
            'PORT': os.environ.get('DB_PORT', '5432'),
        }
    }
else:
    # Development database (SQLite)
    DATABASES = {
        
    }

# TODO: Production security settings (only apply when DEBUG is False)
if not DEBUG:
    # Add HTTPS security settings
    SECURE_SSL_REDIRECT = 
    SECURE_HSTS_SECONDS = 
    SESSION_COOKIE_SECURE = 
    CSRF_COOKIE_SECURE = 

# TODO: Email configuration
# If in production (DEBUG=False), use SMTP
# If in development (DEBUG=True), use console backend
if DEBUG:
    EMAIL_BACKEND = 
else:
    EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
    EMAIL_HOST = os.environ.get('EMAIL_HOST')
    EMAIL_PORT = int(os.environ.get('EMAIL_PORT', '587'))
    EMAIL_USE_TLS = True
    EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER')
    EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD')

# Static files
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'  # For production

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True""",
            "solution": """# Advanced Settings Configuration
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Load SECRET_KEY from environment variable with fallback
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-me')

# Load DEBUG from environment variable, convert to boolean
DEBUG = os.environ.get('DEBUG', 'True').lower() == 'true'

# Load ALLOWED_HOSTS from environment variable
ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',')

# Standard Django apps
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth', 
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'blog',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'myblog.urls'

# Smart database configuration
DATABASE_URL = os.environ.get('DATABASE_URL')
if DATABASE_URL:
    # Production database (PostgreSQL)
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.postgresql',
            'NAME': os.environ.get('DB_NAME'),
            'USER': os.environ.get('DB_USER'),
            'PASSWORD': os.environ.get('DB_PASSWORD'),
            'HOST': os.environ.get('DB_HOST', 'localhost'),
            'PORT': os.environ.get('DB_PORT', '5432'),
        }
    }
else:
    # Development database (SQLite)
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }

# Production security settings
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SECURE_HSTS_SECONDS = 31536000  # 1 year
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True

# Email configuration
if DEBUG:
    EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
else:
    EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
    EMAIL_HOST = os.environ.get('EMAIL_HOST')
    EMAIL_PORT = int(os.environ.get('EMAIL_PORT', '587'))
    EMAIL_USE_TLS = True
    EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER')
    EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD')

# Static files
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True""",
            "xp_reward": 45,
            "hints": [
                "Use os.environ.get() to safely access environment variables",
                "Convert DEBUG string to boolean with .lower() == 'true'",
                "Split ALLOWED_HOSTS string by comma to create a list",
                "Check if DATABASE_URL exists to determine environment",
                "Security settings should only apply when DEBUG is False"
            ]
        },
        {
            "id": "security-configuration", 
            "title": "🔒 Django Security Configuration",
            "type": "advanced",
            "instructions": """Security is critical in web development! Let's configure Django's security features properly.

**Security scenario:** Your blog will handle user accounts and personal data. You need to implement proper security measures to protect your users.

**Security checklist:**
1. Configure strong password hashing
2. Set up password validation rules
3. Add HTTPS security headers
4. Configure session security  
5. Set up CORS (Cross-Origin Resource Sharing) headers""",
            "starter_code": """# Security-focused Django Settings
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Basic settings
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key')
DEBUG = False  # Production security mode
ALLOWED_HOSTS = ['myblog.com', 'www.myblog.com']

# TODO: Configure strong password hashers in order of preference
# Use Argon2, PBKDF2, and BCrypt
AUTH_PASSWORD_HASHERS = [
    
]

# TODO: Add password validation rules
# Include: UserAttributeSimilarity, MinimumLength (8 chars), CommonPassword, NumericPassword
AUTH_PASSWORD_VALIDATORS = [
    
]

# TODO: HTTPS Security Headers
# Enable SSL redirect, set HSTS to 1 year, include subdomains
SECURE_SSL_REDIRECT = 
SECURE_HSTS_SECONDS = 
SECURE_HSTS_INCLUDE_SUBDOMAINS = 
SECURE_HSTS_PRELOAD = 

# TODO: Cookie Security  
# Make session and CSRF cookies HTTPS-only and HTTP-only
SESSION_COOKIE_SECURE = 
SESSION_COOKIE_HTTPONLY = 
CSRF_COOKIE_SECURE = 
CSRF_COOKIE_HTTPONLY = 

# TODO: Content Security
# Prevent content-type sniffing, XSS attacks, and clickjacking
SECURE_CONTENT_TYPE_NOSNIFF = 
SECURE_BROWSER_XSS_FILTER = 
X_FRAME_OPTIONS = 

# TODO: Session Configuration
# Set session timeout to 1 day (86400 seconds)
# Use database-backed sessions for security
SESSION_COOKIE_AGE = 
SESSION_ENGINE = 

# Standard Django setup
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes', 
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',  # For CORS headers
    'blog',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',  # CORS headers
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# TODO: CORS Configuration for API access
# Allow requests from your frontend domain
CORS_ALLOWED_ORIGINS = [
    
]

# TODO: Add trusted CSRF origins
CSRF_TRUSTED_ORIGINS = [
    
]""",
            "solution": """# Security-focused Django Settings
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Basic settings
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key')
DEBUG = False  # Production security mode
ALLOWED_HOSTS = ['myblog.com', 'www.myblog.com']

# Strong password hashers in order of preference
AUTH_PASSWORD_HASHERS = [
    'django.contrib.auth.hashers.Argon2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2PasswordHasher',
    'django.contrib.auth.hashers.PBKDF2SHA1PasswordHasher', 
    'django.contrib.auth.hashers.BCryptSHA256PasswordHasher',
]

# Password validation rules
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
        'OPTIONS': {'min_length': 8,}
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# HTTPS Security Headers
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000  # 1 year
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Cookie Security
SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True

# Content Security
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'

# Session Configuration
SESSION_COOKIE_AGE = 86400  # 1 day
SESSION_ENGINE = 'django.contrib.sessions.backends.db'

# Standard Django setup
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes', 
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',
    'blog',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# CORS Configuration
CORS_ALLOWED_ORIGINS = [
    'https://myblog.com',
    'https://www.myblog.com',
]

# Trusted CSRF origins
CSRF_TRUSTED_ORIGINS = [
    'https://myblog.com',
    'https://www.myblog.com',
]""",
            "xp_reward": 50,
            "hints": [
                "Argon2 is the most secure password hasher",
                "HSTS seconds: 31536000 = 1 year in seconds",
                "X_FRAME_OPTIONS should be 'DENY' to prevent clickjacking",
                "Secure cookies require HTTPS (True for production)",
                "CORS origins should include https:// protocol"
            ]
        },
        {
            "id": "debugging-settings",
            "title": "🐛 Debug Settings Configuration Issues",
            "type": "debugging",
            "instructions": """Every Django developer encounters settings issues! Let's practice debugging common configuration problems.

**Debug scenario:** A junior developer's settings file has several issues preventing the Django app from working properly. Find and fix the problems!""",
            "exercises": [
                {
                    "broken_code": """# Broken settings.py
SECRET_KEY = ''  # Empty secret key
DEBUG = 'True'   # String instead of boolean
ALLOWED_HOSTS = 'localhost'  # String instead of list

INSTALLED_APPS = [
    'django.contrib.admin'
    'django.contrib.auth'  # Missing comma
    'django.contrib.contenttypes',
    'blog'  # Missing comma
]

DATABASES = {
    'default': {
        'ENGINE': 'sqlite3',  # Wrong engine name
        'NAME': 'db.sqlite3',  # Should use BASE_DIR
    }
}""",
                    "issue": "Multiple syntax and configuration errors",
                    "fixed_code": """# Fixed settings.py
SECRET_KEY = 'django-insecure-fix-this-in-production'  # Valid secret key
DEBUG = True   # Boolean value
ALLOWED_HOSTS = ['localhost', '127.0.0.1']  # List format

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',  # Added comma
    'django.contrib.contenttypes',
    'blog',  # Added comma
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',  # Full engine name
        'NAME': BASE_DIR / 'db.sqlite3',  # Use BASE_DIR
    }
}""",
                    "explanation": "SECRET_KEY can't be empty, DEBUG must be boolean, ALLOWED_HOSTS must be a list, missing commas cause syntax errors, and database engine needs full path."
                },
                {
                    "broken_code": """# Security issues
DEBUG = True  # In production!
SECRET_KEY = 'abc123'  # Hardcoded weak key
ALLOWED_HOSTS = []  # Empty hosts in production

SESSION_COOKIE_SECURE = False  # Insecure cookies
CSRF_COOKIE_SECURE = False
X_FRAME_OPTIONS = 'ALLOWALL'  # Wrong value""",
                    "issue": "Security vulnerabilities",
                    "fixed_code": """# Security fixed
DEBUG = False  # Production safe
SECRET_KEY = os.environ.get('SECRET_KEY')  # From environment
ALLOWED_HOSTS = ['mysite.com', 'www.mysite.com']  # Specific hosts

SESSION_COOKIE_SECURE = True  # Secure cookies
CSRF_COOKIE_SECURE = True
X_FRAME_OPTIONS = 'DENY'  # Proper value""",
                    "explanation": "Production should never have DEBUG=True, secret keys should come from environment variables, and security settings should be properly configured."
                }
            ],
            "xp_reward": 25
        }
    ]
}