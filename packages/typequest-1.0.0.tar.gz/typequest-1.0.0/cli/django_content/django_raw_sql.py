"""
Django Database - Lesson 2: Raw SQL in Django
Master raw SQL usage for complex queries and performance optimization
"""

DJANGO_RAW_SQL_LESSON = {
    "id": 45,
    "chapter": 45,
    "title": "Django Raw SQL: When ORM Isn't Enough",
    "slug": "django-raw-sql",
    "description": "Learn when and how to use raw SQL in Django for complex queries and performance optimization",
    "content": '''# Django Raw SQL: When ORM Isn't Enough

## 🎯 When to Use Raw SQL

While Django's ORM handles 90% of database queries, there are scenarios where **raw SQL** is necessary:

- **Complex analytical queries** with window functions and CTEs
- **Database-specific features** not available in Django ORM
- **Performance optimization** for critical queries
- **Legacy database integration** with complex schemas
- **Reporting and analytics** requiring advanced SQL

Companies like **Instagram, Spotify, and Netflix** use raw SQL for their most demanding database operations.

## 💾 Analytics Database for Raw SQL Examples

Let's create a comprehensive analytics database that showcases raw SQL capabilities:

```sql
-- ANALYTICS DATABASE FOR RAW SQL EXAMPLES
-- Database: analytics_db

-- Customer analytics table with comprehensive customer data
CREATE TABLE analytics_orders (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(20) UNIQUE NOT NULL,
    customer_id INTEGER NOT NULL,
    customer_email VARCHAR(254) NOT NULL,
    customer_segment VARCHAR(50) DEFAULT 'regular', -- 'premium', 'regular', 'new'
    order_date DATE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    tax_amount DECIMAL(10,2) DEFAULT 0.00,
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'confirmed', 'shipped', 'delivered', 'cancelled'
    region VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    acquisition_channel VARCHAR(50), -- 'organic', 'paid_social', 'email', 'referral', 'direct'
    payment_method VARCHAR(30), -- 'credit_card', 'paypal', 'bank_transfer', 'apple_pay'
    device_type VARCHAR(20), -- 'mobile', 'desktop', 'tablet'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample analytics data (like Instagram's user engagement analytics)
INSERT INTO analytics_orders (order_id, customer_id, customer_email, customer_segment, order_date, total_amount, discount_amount, tax_amount, region, country, acquisition_channel, payment_method, device_type, status) VALUES
('ORD-2024-001', 1001, 'alice@example.com', 'premium', '2024-12-01', 299.99, 30.00, 24.00, 'North America', 'USA', 'organic', 'credit_card', 'mobile', 'delivered'),
('ORD-2024-002', 1002, 'bob@example.com', 'regular', '2024-12-02', 149.50, 0.00, 11.96, 'Europe', 'Germany', 'paid_social', 'paypal', 'desktop', 'delivered'),
('ORD-2024-003', 1003, 'carol@example.com', 'new', '2024-12-03', 89.99, 9.00, 6.40, 'Asia Pacific', 'Japan', 'email', 'credit_card', 'mobile', 'shipped'),
('ORD-2024-004', 1001, 'alice@example.com', 'premium', '2024-12-05', 599.99, 60.00, 43.20, 'North America', 'USA', 'direct', 'apple_pay', 'desktop', 'delivered'),
('ORD-2024-005', 1004, 'dave@example.com', 'regular', '2024-12-07', 199.99, 20.00, 14.40, 'Europe', 'France', 'referral', 'credit_card', 'tablet', 'delivered'),
('ORD-2024-006', 1005, 'eve@example.com', 'premium', '2024-12-10', 449.99, 0.00, 36.00, 'North America', 'Canada', 'organic', 'credit_card', 'mobile', 'confirmed'),
('ORD-2024-007', 1002, 'bob@example.com', 'regular', '2024-12-12', 299.99, 30.00, 21.60, 'Europe', 'Germany', 'email', 'paypal', 'desktop', 'delivered'),
('ORD-2024-008', 1006, 'frank@example.com', 'new', '2024-12-15', 79.99, 0.00, 6.40, 'Asia Pacific', 'Australia', 'paid_social', 'credit_card', 'mobile', 'pending'),
('ORD-2024-009', 1007, 'grace@example.com', 'premium', '2024-12-18', 799.99, 80.00, 57.60, 'North America', 'USA', 'direct', 'apple_pay', 'desktop', 'shipped'),
('ORD-2024-010', 1003, 'carol@example.com', 'regular', '2024-12-20', 129.99, 13.00, 9.36, 'Asia Pacific', 'Japan', 'organic', 'credit_card', 'tablet', 'delivered');

-- Order items for detailed product analysis
CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id VARCHAR(20) NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES analytics_orders(id)
);

-- Sample order items data
INSERT INTO order_items (order_id, product_id, product_name, category, quantity, unit_price, total_price) VALUES
(1, 'PRD-001', 'Wireless Headphones', 'Electronics', 1, 299.99, 299.99),
(2, 'PRD-002', 'Running Shoes', 'Footwear', 1, 149.50, 149.50),
(3, 'PRD-003', 'Coffee Mug', 'Kitchen', 2, 44.99, 89.98),
(4, 'PRD-001', 'Wireless Headphones', 'Electronics', 2, 299.99, 599.98),
(5, 'PRD-004', 'Yoga Mat', 'Fitness', 1, 199.99, 199.99),
(6, 'PRD-005', 'Bluetooth Speaker', 'Electronics', 1, 449.99, 449.99),
(7, 'PRD-002', 'Running Shoes', 'Footwear', 2, 149.50, 299.00),
(8, 'PRD-003', 'Coffee Mug', 'Kitchen', 1, 79.99, 79.99),
(9, 'PRD-006', 'Smart Watch', 'Electronics', 1, 799.99, 799.99),
(10, 'PRD-007', 'Backpack', 'Accessories', 1, 129.99, 129.99);

-- Customer lifetime value table for advanced analytics
CREATE TABLE customer_analytics (
    customer_id INTEGER PRIMARY KEY,
    first_order_date DATE,
    last_order_date DATE,
    total_orders INTEGER DEFAULT 0,
    total_spent DECIMAL(12,2) DEFAULT 0.00,
    avg_order_value DECIMAL(10,2) DEFAULT 0.00,
    customer_lifetime_days INTEGER DEFAULT 0,
    preferred_category VARCHAR(50),
    risk_score INTEGER DEFAULT 0, -- 0-100, higher = more likely to churn
    acquisition_cost DECIMAL(8,2) DEFAULT 0.00,
    predicted_ltv DECIMAL(12,2) DEFAULT 0.00 -- Machine learning predicted lifetime value
);

-- Sample customer analytics data
INSERT INTO customer_analytics (customer_id, first_order_date, last_order_date, total_orders, total_spent, avg_order_value, customer_lifetime_days, preferred_category, risk_score, acquisition_cost, predicted_ltv) VALUES
(1001, '2024-12-01', '2024-12-05', 2, 899.98, 449.99, 4, 'Electronics', 15, 25.50, 1200.00),
(1002, '2024-11-15', '2024-12-12', 3, 599.48, 199.83, 27, 'Footwear', 25, 18.75, 800.00),
(1003, '2024-12-03', '2024-12-20', 2, 219.98, 109.99, 17, 'Kitchen', 35, 22.00, 450.00),
(1004, '2024-12-07', '2024-12-07', 1, 199.99, 199.99, 0, 'Fitness', 45, 30.00, 300.00),
(1005, '2024-12-10', '2024-12-10', 1, 449.99, 449.99, 0, 'Electronics', 40, 28.50, 600.00),
(1006, '2024-12-15', '2024-12-15', 1, 79.99, 79.99, 0, 'Kitchen', 65, 35.00, 150.00),
(1007, '2024-12-18', '2024-12-18', 1, 799.99, 799.99, 0, 'Electronics', 20, 40.00, 1500.00);

-- Product performance analytics
CREATE TABLE product_analytics (
    product_id VARCHAR(20) PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    total_units_sold INTEGER DEFAULT 0,
    total_revenue DECIMAL(12,2) DEFAULT 0.00,
    avg_selling_price DECIMAL(10,2) DEFAULT 0.00,
    profit_margin_percent DECIMAL(5,2) DEFAULT 0.00,
    inventory_turnover DECIMAL(8,2) DEFAULT 0.00,
    customer_rating DECIMAL(3,2) DEFAULT 0.00,
    return_rate_percent DECIMAL(5,2) DEFAULT 0.00,
    seasonal_index DECIMAL(5,2) DEFAULT 1.00 -- 1.0 = normal, >1 = higher seasonal demand
);

-- Sample product analytics
INSERT INTO product_analytics (product_id, product_name, category, total_units_sold, total_revenue, avg_selling_price, profit_margin_percent, inventory_turnover, customer_rating, return_rate_percent, seasonal_index) VALUES
('PRD-001', 'Wireless Headphones', 'Electronics', 3, 899.97, 299.99, 35.50, 4.2, 4.5, 5.2, 1.3),
('PRD-002', 'Running Shoes', 'Footwear', 3, 448.50, 149.50, 45.20, 6.8, 4.7, 8.1, 0.9),
('PRD-003', 'Coffee Mug', 'Kitchen', 3, 214.96, 71.65, 60.00, 12.5, 4.2, 2.1, 1.1),
('PRD-004', 'Yoga Mat', 'Fitness', 1, 199.99, 199.99, 40.25, 3.2, 4.6, 3.5, 1.5),
('PRD-005', 'Bluetooth Speaker', 'Electronics', 1, 449.99, 449.99, 38.75, 2.8, 4.4, 4.2, 1.2),
('PRD-006', 'Smart Watch', 'Electronics', 1, 799.99, 799.99, 42.50, 2.1, 4.8, 6.8, 1.4),
('PRD-007', 'Backpack', 'Accessories', 1, 129.99, 129.99, 55.30, 8.4, 4.3, 4.1, 0.8);
```

## 🔧 Raw SQL Patterns in Django

### 1. Model.objects.raw() for Complex Queries

**Scenario**: Netflix's customer segmentation using raw SQL

```python
# models.py
from django.db import models

class Customer(models.Model):
    customer_id = models.IntegerField()
    email = models.EmailField()
    segment = models.CharField(max_length=50)
    total_spent = models.DecimalField(max_digits=12, decimal_places=2)
    risk_score = models.IntegerField()
    
    class Meta:
        db_table = 'analytics_orders'

# Using raw SQL for complex customer analysis
def get_high_value_customers():
    """Get customers with high lifetime value using raw SQL"""
    
    # Complex query that's difficult with Django ORM
    return Customer.objects.raw("""
        SELECT DISTINCT customer_id, customer_email as email, 
               customer_segment as segment,
               SUM(total_amount) OVER (PARTITION BY customer_id) as total_spent,
               RANK() OVER (ORDER BY SUM(total_amount) DESC) as value_rank
        FROM analytics_orders 
        WHERE status = 'delivered'
          AND order_date >= CURRENT_DATE - INTERVAL '12 months'
        ORDER BY total_spent DESC
        LIMIT 100
    """)

# Using parameterized queries for security
def get_customers_by_region_and_date(region, start_date, min_order_value):
    """Get customers filtered by region and minimum order value"""
    
    return Customer.objects.raw("""
        SELECT customer_id, customer_email as email,
               COUNT(*) as order_count,
               SUM(total_amount) as total_spent,
               AVG(total_amount) as avg_order_value
        FROM analytics_orders
        WHERE region = %s 
          AND order_date >= %s
          AND total_amount >= %s
          AND status = 'delivered'
        GROUP BY customer_id, customer_email
        HAVING COUNT(*) >= 2
        ORDER BY total_spent DESC
        """, [region, start_date, min_order_value])
```

### 2. connection.cursor() for Advanced Operations

**Scenario**: Spotify's music analytics requiring complex SQL

```python
# analytics/services.py
from django.db import connection
from typing import List, Dict, Any

class AdvancedAnalyticsService:
    """Service for complex analytics requiring raw SQL"""
    
    @staticmethod
    def get_revenue_analytics_by_region() -> List[Dict[str, Any]]:
        """Get comprehensive revenue analytics by region using raw SQL"""
        
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH regional_metrics AS (
                    SELECT 
                        region,
                        COUNT(*) as total_orders,
                        COUNT(DISTINCT customer_id) as unique_customers,
                        SUM(total_amount) as total_revenue,
                        AVG(total_amount) as avg_order_value,
                        SUM(total_amount) / COUNT(DISTINCT customer_id) as revenue_per_customer,
                        SUM(CASE WHEN customer_segment = 'premium' THEN total_amount ELSE 0 END) as premium_revenue
                    FROM analytics_orders 
                    WHERE status = 'delivered'
                      AND order_date >= CURRENT_DATE - INTERVAL '30 days'
                    GROUP BY region
                ),
                regional_growth AS (
                    SELECT 
                        region,
                        SUM(total_amount) as current_month_revenue,
                        LAG(SUM(total_amount)) OVER (ORDER BY region) as previous_month_revenue
                    FROM analytics_orders
                    WHERE status = 'delivered'
                      AND order_date >= CURRENT_DATE - INTERVAL '60 days'
                    GROUP BY region, DATE_TRUNC('month', order_date)
                )
                SELECT 
                    rm.region,
                    rm.total_orders,
                    rm.unique_customers,
                    rm.total_revenue,
                    rm.avg_order_value,
                    rm.revenue_per_customer,
                    rm.premium_revenue,
                    COALESCE((rm.total_revenue - rg.previous_month_revenue) / rg.previous_month_revenue * 100, 0) as growth_rate_percent
                FROM regional_metrics rm
                LEFT JOIN regional_growth rg ON rm.region = rg.region
                ORDER BY rm.total_revenue DESC
            """)
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    @staticmethod
    def get_customer_cohort_analysis() -> List[Dict[str, Any]]:
        """Perform cohort analysis using advanced SQL"""
        
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH customer_cohorts AS (
                    SELECT 
                        customer_id,
                        MIN(order_date) as cohort_month,
                        order_date
                    FROM analytics_orders
                    WHERE status = 'delivered'
                    GROUP BY customer_id, order_date
                ),
                cohort_sizes AS (
                    SELECT 
                        DATE_TRUNC('month', cohort_month) as cohort_month,
                        COUNT(DISTINCT customer_id) as cohort_size
                    FROM customer_cohorts
                    GROUP BY DATE_TRUNC('month', cohort_month)
                ),
                cohort_activity AS (
                    SELECT 
                        DATE_TRUNC('month', cc.cohort_month) as cohort_month,
                        DATE_TRUNC('month', cc.order_date) as activity_month,
                        COUNT(DISTINCT cc.customer_id) as active_customers
                    FROM customer_cohorts cc
                    GROUP BY 
                        DATE_TRUNC('month', cc.cohort_month),
                        DATE_TRUNC('month', cc.order_date)
                )
                SELECT 
                    cs.cohort_month,
                    cs.cohort_size,
                    ca.activity_month,
                    ca.active_customers,
                    ROUND(ca.active_customers::decimal / cs.cohort_size * 100, 2) as retention_rate,
                    (EXTRACT(YEAR FROM ca.activity_month) - EXTRACT(YEAR FROM cs.cohort_month)) * 12 + 
                    EXTRACT(MONTH FROM ca.activity_month) - EXTRACT(MONTH FROM cs.cohort_month) as month_offset
                FROM cohort_sizes cs
                JOIN cohort_activity ca ON cs.cohort_month = ca.cohort_month
                ORDER BY cs.cohort_month, ca.activity_month
            """)
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    @staticmethod
    def get_product_recommendation_data(product_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get product recommendation data using complex SQL analysis"""
        
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH product_cooccurrence AS (
                    -- Find products frequently bought together
                    SELECT 
                        oi1.product_id as base_product,
                        oi2.product_id as recommended_product,
                        COUNT(*) as cooccurrence_count,
                        COUNT(*) / (SELECT COUNT(DISTINCT order_id) FROM order_items WHERE product_id = %s)::decimal as lift
                    FROM order_items oi1
                    JOIN order_items oi2 ON oi1.order_id = oi2.order_id
                    WHERE oi1.product_id = %s 
                      AND oi2.product_id != %s
                    GROUP BY oi1.product_id, oi2.product_id
                ),
                product_performance AS (
                    SELECT 
                        product_id,
                        AVG(unit_price) as avg_price,
                        SUM(quantity) as total_sold,
                        COUNT(DISTINCT order_id) as order_frequency
                    FROM order_items
                    GROUP BY product_id
                )
                SELECT 
                    pc.recommended_product as product_id,
                    pc.cooccurrence_count,
                    pc.lift,
                    pp.avg_price,
                    pp.total_sold,
                    pp.order_frequency,
                    RANK() OVER (ORDER BY pc.lift DESC, pc.cooccurrence_count DESC) as recommendation_rank
                FROM product_cooccurrence pc
                JOIN product_performance pp ON pc.recommended_product = pp.product_id
                ORDER BY pc.lift DESC, pc.cooccurrence_count DESC
                LIMIT %s
                """, [product_id, product_id, product_id, limit])
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

### 3. Financial Analytics with Window Functions

**Scenario**: PayPal's financial reporting system

```python
class FinancialReportingService:
    """Advanced financial analytics requiring window functions"""
    
    @staticmethod
    def generate_monthly_financial_report(report_date):
        """Generate comprehensive monthly financial report"""
        
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH monthly_metrics AS (
                    SELECT 
                        DATE_TRUNC('month', order_date) as month,
                        region,
                        SUM(total_amount) as gross_revenue,
                        SUM(discount_amount) as total_discounts,
                        SUM(tax_amount) as total_tax,
                        COUNT(*) as order_count,
                        COUNT(DISTINCT customer_id) as unique_customers
                    FROM analytics_orders
                    WHERE status IN ('delivered', 'shipped')
                      AND order_date >= %s - INTERVAL '12 months'
                      AND order_date <= %s
                    GROUP BY DATE_TRUNC('month', order_date), region
                ),
                metrics_with_trends AS (
                    SELECT *,
                        LAG(gross_revenue) OVER (PARTITION BY region ORDER BY month) as prev_month_revenue,
                        SUM(gross_revenue) OVER (PARTITION BY region ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) as rolling_3month_revenue,
                        ROW_NUMBER() OVER (PARTITION BY month ORDER BY gross_revenue DESC) as region_rank
                    FROM monthly_metrics
                )
                SELECT 
                    month,
                    region,
                    gross_revenue,
                    total_discounts,
                    (gross_revenue - total_discounts) as net_revenue,
                    total_tax,
                    order_count,
                    unique_customers,
                    CASE 
                        WHEN prev_month_revenue > 0 
                        THEN ROUND((gross_revenue - prev_month_revenue) / prev_month_revenue * 100, 2)
                        ELSE NULL 
                    END as growth_rate_percent,
                    ROUND(rolling_3month_revenue / 3, 2) as rolling_3month_avg,
                    region_rank,
                    ROUND(gross_revenue / unique_customers, 2) as revenue_per_customer
                FROM metrics_with_trends
                WHERE month = %s
                ORDER BY gross_revenue DESC
            """, [report_date, report_date, report_date])
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    @staticmethod
    def get_customer_segmentation_analysis():
        """Advanced customer segmentation using percentiles and scoring"""
        
        with connection.cursor() as cursor:
            cursor.execute("""
                WITH customer_metrics AS (
                    SELECT 
                        customer_id,
                        customer_email,
                        COUNT(*) as order_frequency,
                        SUM(total_amount) as total_spent,
                        AVG(total_amount) as avg_order_value,
                        MAX(order_date) as last_order_date,
                        MIN(order_date) as first_order_date,
                        EXTRACT(DAYS FROM (CURRENT_DATE - MAX(order_date))) as days_since_last_order
                    FROM analytics_orders
                    WHERE status = 'delivered'
                    GROUP BY customer_id, customer_email
                ),
                customer_percentiles AS (
                    SELECT *,
                        PERCENT_RANK() OVER (ORDER BY total_spent) as spending_percentile,
                        PERCENT_RANK() OVER (ORDER BY order_frequency) as frequency_percentile,
                        PERCENT_RANK() OVER (ORDER BY days_since_last_order DESC) as recency_percentile
                    FROM customer_metrics
                ),
                customer_segments AS (
                    SELECT *,
                        (spending_percentile + frequency_percentile + recency_percentile) / 3 as overall_score,
                        CASE 
                            WHEN spending_percentile >= 0.8 AND frequency_percentile >= 0.8 THEN 'Champions'
                            WHEN spending_percentile >= 0.6 AND frequency_percentile >= 0.6 THEN 'Loyal Customers'
                            WHEN recency_percentile >= 0.8 THEN 'New Customers'
                            WHEN days_since_last_order > 90 THEN 'At Risk'
                            WHEN days_since_last_order > 180 THEN 'Cannot Lose Them'
                            ELSE 'Regular'
                        END as customer_segment
                    FROM customer_percentiles
                )
                SELECT 
                    customer_segment,
                    COUNT(*) as customer_count,
                    ROUND(AVG(total_spent), 2) as avg_total_spent,
                    ROUND(AVG(order_frequency), 2) as avg_order_frequency,
                    ROUND(AVG(avg_order_value), 2) as avg_order_value,
                    ROUND(AVG(days_since_last_order), 1) as avg_days_since_last_order,
                    ROUND(AVG(overall_score) * 100, 1) as avg_score
                FROM customer_segments
                GROUP BY customer_segment
                ORDER BY avg_total_spent DESC
            """)
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
```

### 4. Full-Text Search and Complex Filters

**Scenario**: Amazon's product search with raw SQL

```python
class ProductSearchService:
    """Advanced product search using database-specific features"""
    
    @staticmethod
    def advanced_product_search(query: str, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Advanced product search with full-text search and filters"""
        
        with connection.cursor() as cursor:
            # Using PostgreSQL's full-text search capabilities
            cursor.execute("""
                SELECT 
                    oi.product_id,
                    oi.product_name,
                    oi.category,
                    AVG(oi.unit_price) as avg_price,
                    SUM(oi.quantity) as total_sold,
                    COUNT(DISTINCT oi.order_id) as order_count,
                    ts_rank(to_tsvector('english', oi.product_name), plainto_tsquery('english', %s)) as search_rank
                FROM order_items oi
                JOIN analytics_orders ao ON oi.order_id = ao.id
                WHERE to_tsvector('english', oi.product_name) @@ plainto_tsquery('english', %s)
                  AND ao.status = 'delivered'
                GROUP BY oi.product_id, oi.product_name, oi.category
                ORDER BY search_rank DESC, total_sold DESC
                LIMIT 50
                """, [query, query])
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    @staticmethod
    def get_trending_products(days: int = 7) -> List[Dict[str, Any]]:
        """Get trending products using velocity calculations"""
        
        with connection.cursor() as cursor:
            cursor.execute(f"""
                WITH recent_sales AS (
                    SELECT 
                        oi.product_id,
                        oi.product_name,
                        oi.category,
                        SUM(oi.quantity) as recent_quantity,
                        COUNT(DISTINCT oi.order_id) as recent_orders
                    FROM order_items oi
                    JOIN analytics_orders ao ON oi.order_id = ao.id
                    WHERE ao.order_date >= CURRENT_DATE - INTERVAL '{days} days'
                      AND ao.status = 'delivered'
                    GROUP BY oi.product_id, oi.product_name, oi.category
                ),
                historical_sales AS (
                    SELECT 
                        oi.product_id,
                        AVG(daily_sales.daily_quantity) as avg_daily_quantity
                    FROM order_items oi
                    JOIN analytics_orders ao ON oi.order_id = ao.id
                    JOIN (
                        SELECT 
                            oi2.product_id,
                            DATE(ao2.order_date) as sale_date,
                            SUM(oi2.quantity) as daily_quantity
                        FROM order_items oi2
                        JOIN analytics_orders ao2 ON oi2.order_id = ao2.id
                        WHERE ao2.order_date >= CURRENT_DATE - INTERVAL '30 days'
                          AND ao2.order_date < CURRENT_DATE - INTERVAL '{days} days'
                          AND ao2.status = 'delivered'
                        GROUP BY oi2.product_id, DATE(ao2.order_date)
                    ) daily_sales ON oi.product_id = daily_sales.product_id
                    GROUP BY oi.product_id
                )
                SELECT 
                    rs.product_id,
                    rs.product_name,
                    rs.category,
                    rs.recent_quantity,
                    rs.recent_orders,
                    COALESCE(hs.avg_daily_quantity, 0) as historical_avg_daily,
                    CASE 
                        WHEN COALESCE(hs.avg_daily_quantity, 0) > 0 
                        THEN ROUND((rs.recent_quantity / {days}::decimal) / hs.avg_daily_quantity * 100, 2)
                        ELSE NULL 
                    END as trend_score
                FROM recent_sales rs
                LEFT JOIN historical_sales hs ON rs.product_id = hs.product_id
                WHERE rs.recent_quantity >= 5  -- Minimum volume threshold
                ORDER BY trend_score DESC NULLS LAST, rs.recent_quantity DESC
                LIMIT 20
                """)
            
            columns = [col[0] for col in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
```

## 🎯 Key Takeaways

1. **Raw SQL complements Django ORM** for complex analytical queries
2. **Always use parameterized queries** to prevent SQL injection
3. **Window functions and CTEs** enable sophisticated analytics
4. **Database-specific features** can provide significant performance gains
5. **Test with production data volumes** to ensure performance

Raw SQL gives you the power to leverage your database's full capabilities when Django ORM reaches its limits!
''',
    "difficulty": "intermediate",
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-custom-managers"],
    "exercises": [
        {
            "id": "raw_sql_1",
            "title": "Explore Analytics Orders Table",
            "prompt": "Let's start by examining our analytics orders table structure and data. Write a query to see the order information.",
            "table_name": "analytics_orders",
            "initial_query": "SELECT * FROM analytics_orders LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "analytics_orders"],
            "hint": "Use SELECT * FROM analytics_orders LIMIT 5; to explore the table structure",
            "solution": "SELECT * FROM analytics_orders LIMIT 5;",
            "explanation": "This shows our comprehensive analytics_orders table with fields like customer_id, total_amount, region, acquisition_channel, etc. Raw SQL gives us direct access to all this data for complex analytics."
        },
        {
            "id": "raw_sql_2",
            "title": "Basic Revenue Analysis Query",
            "prompt": "Write a raw SQL query to calculate total revenue by region. Sum the total_amount grouped by region.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "SUM", "GROUP BY", "region"],
            "hint": "Use SUM(total_amount) and GROUP BY region",
            "solution": "SELECT region, SUM(total_amount) as total_revenue FROM analytics_orders WHERE status = 'delivered' GROUP BY region ORDER BY total_revenue DESC;",
            "explanation": "This type of aggregation query is perfect for raw SQL. While Django ORM could handle this, raw SQL gives us direct control and is often more readable for complex business logic."
        },
        {
            "id": "raw_sql_3", 
            "title": "Advanced Customer Segmentation",
            "prompt": "Write a query to find high-value customers: those with total spending > $500 and multiple orders. Show customer_email and their metrics.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "COUNT", "SUM", "GROUP BY", "HAVING"],
            "hint": "Group by customer_email, count orders, sum amounts, then filter with HAVING",
            "solution": "SELECT customer_email, COUNT(*) as order_count, SUM(total_amount) as total_spent FROM analytics_orders WHERE status = 'delivered' GROUP BY customer_email HAVING SUM(total_amount) > 500 AND COUNT(*) > 1 ORDER BY total_spent DESC;",
            "explanation": "This customer segmentation query uses HAVING to filter grouped results - a perfect example of when raw SQL is more natural than Django ORM. The HAVING clause filters after grouping, which is essential for customer analytics."
        },
        {
            "id": "raw_sql_4",
            "title": "Time-Based Analysis Query",
            "prompt": "Write a query to analyze order patterns by acquisition channel. Show channel, order count, and average order value for orders in December 2024.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "AVG", "COUNT", "WHERE", "acquisition_channel"],
            "hint": "Filter by order_date in December 2024, then group by acquisition_channel",
            "solution": "SELECT acquisition_channel, COUNT(*) as order_count, ROUND(AVG(total_amount), 2) as avg_order_value FROM analytics_orders WHERE order_date >= '2024-12-01' AND order_date < '2025-01-01' GROUP BY acquisition_channel ORDER BY avg_order_value DESC;",
            "explanation": "This marketing analysis query shows how different acquisition channels perform. Raw SQL makes it easy to filter by date ranges and calculate channel-specific metrics for business intelligence."
        },
        {
            "id": "raw_sql_5",
            "title": "Complex Multi-Table Analysis",
            "prompt": "Write a query joining analytics_orders and order_items to find the total revenue by product category.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "JOIN", "SUM", "category", "GROUP BY"],
            "hint": "JOIN analytics_orders with order_items, then SUM the amounts by category",
            "solution": "SELECT oi.category, SUM(oi.quantity * oi.unit_price) as category_revenue, COUNT(DISTINCT o.id) as orders_with_category FROM analytics_orders o JOIN order_items oi ON o.id = oi.order_id WHERE o.status = 'delivered' GROUP BY oi.category ORDER BY category_revenue DESC;",
            "explanation": "This cross-table analysis demonstrates raw SQL's power for complex business intelligence. Joining multiple tables and calculating derived metrics like this would be much more complex in Django ORM."
        },
        {
            "id": "raw_sql_6",
            "title": "Window Function for Rankings",
            "prompt": "Use a window function to rank regions by total revenue. Show region, total revenue, and rank.",
            "table_name": "analytics_orders",
            "expected_keywords": ["SELECT", "RANK", "OVER", "ORDER BY", "SUM"],
            "hint": "Use RANK() OVER (ORDER BY SUM(total_amount) DESC) for ranking",
            "solution": "SELECT region, SUM(total_amount) as total_revenue, RANK() OVER (ORDER BY SUM(total_amount) DESC) as revenue_rank FROM analytics_orders WHERE status = 'delivered' GROUP BY region;",
            "explanation": "Window functions like RANK() are perfect examples of when raw SQL is necessary. Django ORM doesn't support window functions well, making raw SQL essential for advanced analytics like revenue rankings."
        }
    ],
    "key_concepts": [
        "Model.objects.raw() Usage",
        "connection.cursor() for Complex Queries",
        "Parameterized Queries for Security",
        "Window Functions and CTEs",
        "Bulk Operations with Raw SQL",
        "Database-Specific Feature Access",
        "Performance Optimization Techniques",
        "Financial and Business Analytics"
    ]
}