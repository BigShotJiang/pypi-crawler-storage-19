"""
SQL OUTER JOINs lesson content
"""

SQL_OUTER_JOINS_LESSON = {
    "id": 35,
    "chapter": 35,
    "title": "SQL OUTER JOINs: Finding Missing Connections",
    "slug": "sql-outer-joins", 
    "content": '''
# SQL OUTER JOINs: Discovering What's Missing

INNER JOINs show you connected data, but what about the gaps? OUTER JOINs reveal the complete picture - like finding Instagram users who haven't posted yet, products with no orders, or songs with no playlist placements. Understanding what's missing is often as valuable as understanding what's there.

## The Power of OUTER JOINs

Think of OUTER JOINs as conducting a comprehensive audit. While INNER JOINs are like asking "Show me successful partnerships," OUTER JOINs ask "Show me everyone, including those without partnerships."

**Real-world scenarios where OUTER JOINs matter:**
- **E-commerce:** Find products with zero sales (inventory issues)
- **Social Media:** Identify inactive users (engagement strategies)  
- **Streaming:** Discover unplayed songs (recommendation opportunities)
- **SaaS:** Find customers who haven't used features (onboarding gaps)

## Understanding the JOIN Spectrum

### INNER JOIN (Review)
```sql
-- Only shows records that exist in BOTH tables
SELECT u.username, p.content
FROM social_users u
INNER JOIN social_posts p ON u.id = p.user_id;
-- Result: Only users who have posted content
```

### LEFT JOIN (LEFT OUTER JOIN)
```sql
-- Shows ALL records from LEFT table, plus matches from RIGHT table
SELECT u.username, p.content
FROM social_users u  -- LEFT table (all users kept)
LEFT JOIN social_posts p ON u.id = p.user_id;
-- Result: All users, including those who haven't posted (content = NULL)
```

### RIGHT JOIN (RIGHT OUTER JOIN)  
```sql
-- Shows ALL records from RIGHT table, plus matches from LEFT table
SELECT u.username, p.content
FROM social_users u
RIGHT JOIN social_posts p ON u.id = p.user_id;  -- RIGHT table (all posts kept)
-- Result: All posts, even if user data is missing (username = NULL)
```

### FULL OUTER JOIN
```sql
-- Shows ALL records from BOTH tables
SELECT u.username, p.content
FROM social_users u
FULL OUTER JOIN social_posts p ON u.id = p.user_id;
-- Result: All users AND all posts, whether connected or not
```

## Our Practice Tables with Missing Data

### Table 1: Social Media Users (social_users)
**First action: `SELECT * FROM social_users;`**

```
+----+-----------+----------------+-------------+
| id | username  | email          | verified    |
+----+-----------+----------------+-------------+
| 1  | sarah_dev | sarah@email    | 1           |
| 2  | mike_photo| mike@email     | 0           |
| 3  | lisa_art  | lisa@email     | 1           |
| 4  | john_travel| john@email    | 0           |
| 5  | alice_code| alice@email    | 0           |
+----+-----------+----------------+-------------+
```

### Table 2: Social Media Posts (social_posts)
```
+----+---------+-------------------+-------+
| id | user_id | content           | likes |
+----+---------+-------------------+-------+
| 101| 1       | Learning SQL!     | 150   |
| 102| 1       | Database design   | 89    |
| 103| 2       | Sunset photos     | 234   |
| 104| 3       | Digital art       | 456   |
| 105| 99      | Orphaned post     | 12    |  -- No matching user
+----+---------+-------------------+-------+
```

**Note:** User ID 4 (john_travel) and ID 5 (alice_code) have no posts. Post 105 has user_id 99 (no matching user).

## LEFT JOIN: Finding Users Without Content

LEFT JOIN keeps all users and shows which ones haven't posted:

```sql
-- E-commerce: Find customers who haven't placed orders
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id;

-- Results show:
-- sarah_dev: 2 posts (normal data)
-- mike_photo: 1 post (normal data)  
-- lisa_art: 1 post (normal data)
-- john_travel: NULL post (no content yet!)
-- alice_code: NULL post (inactive user!)
```

### Business Applications of LEFT JOIN

**1. Customer Engagement Analysis**
```sql
-- Find customers who registered but never purchased
SELECT 
    c.customer_name,
    c.registration_date,
    o.order_date,
    o.total_amount
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.id IS NULL;  -- Only customers with no orders
```

**2. Content Creator Insights**
```sql
-- Find creators who haven't uploaded recently
SELECT 
    u.username,
    u.verified,
    p.upload_date
FROM creators u
LEFT JOIN recent_posts p ON u.id = p.creator_id
WHERE p.id IS NULL;  -- Creators with no recent content
```

**3. Product Inventory Analysis**
```sql
-- Find products that have never been ordered
SELECT 
    pr.product_name,
    pr.price,
    pr.category,
    oi.quantity
FROM products pr
LEFT JOIN order_items oi ON pr.id = oi.product_id
WHERE oi.id IS NULL;  -- Products with zero sales
```

## RIGHT JOIN: Finding Orphaned Data

RIGHT JOIN keeps all posts and shows which ones have missing user data:

```sql
-- Find posts from deleted or missing user accounts
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes
FROM social_users u
RIGHT JOIN social_posts p ON u.id = p.user_id;

-- Results show all posts, including:
-- Post 105: username = NULL (orphaned content!)
```

### When to Use RIGHT JOIN

**1. Data Integrity Checks**
```sql
-- Find orders with invalid customer references
SELECT 
    c.customer_name,
    o.order_id,
    o.total_amount
FROM customers c
RIGHT JOIN orders o ON c.id = o.customer_id
WHERE c.id IS NULL;  -- Orders with no valid customer
```

**2. Content Moderation**
```sql
-- Find comments on deleted posts
SELECT 
    p.title,
    c.comment_text,
    c.created_at
FROM posts p
RIGHT JOIN comments c ON p.id = c.post_id
WHERE p.id IS NULL;  -- Comments on missing posts
```

## FULL OUTER JOIN: The Complete Picture

FULL OUTER JOIN shows everything - connected and unconnected data:

```sql
-- Complete audit: all users and all posts
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes
FROM social_users u
FULL OUTER JOIN social_posts p ON u.id = p.user_id;

-- Shows:
-- All users (including those with no posts)
-- All posts (including orphaned ones)
-- All normal user-post connections
```

### Business Intelligence with FULL OUTER JOIN

**1. Platform Health Assessment**
```sql
-- Complete view of user activity vs content creation
SELECT 
    u.username,
    COUNT(p.id) AS post_count,
    CASE 
        WHEN u.id IS NULL THEN 'Orphaned Content'
        WHEN COUNT(p.id) = 0 THEN 'Inactive User'
        ELSE 'Active Creator'
    END AS user_status
FROM social_users u
FULL OUTER JOIN social_posts p ON u.id = p.user_id
GROUP BY u.username, u.id;
```

**2. Comprehensive Sales Analysis**
```sql
-- All customers and all products, regardless of purchase history
SELECT 
    c.customer_name,
    p.product_name,
    oi.quantity,
    oi.price
FROM customers c
FULL OUTER JOIN order_items oi ON c.id = oi.customer_id
FULL OUTER JOIN products p ON oi.product_id = p.id;
```

## Advanced OUTER JOIN Patterns

### Multiple OUTER JOINs

**Social Media Analytics: Users, Posts, and Comments**
```sql
-- Complete engagement picture
SELECT 
    u.username,
    p.content,
    c.comment_text
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
LEFT JOIN social_comments c ON p.id = c.post_id
ORDER BY u.username, p.id, c.id;
```

**E-commerce: Customers, Orders, and Products**
```sql
-- Customer journey analysis with gaps
SELECT 
    cust.customer_name,
    o.order_date,
    p.product_name,
    oi.quantity
FROM customers cust
LEFT JOIN orders o ON cust.id = o.customer_id
LEFT JOIN order_items oi ON o.id = oi.order_id
LEFT JOIN products p ON oi.product_id = p.id;
```

### Conditional OUTER JOINs

**Time-based Analysis**
```sql
-- Find users who were active last month but not this month
SELECT 
    u.username,
    last_month.post_count AS last_month_posts,
    this_month.post_count AS this_month_posts
FROM social_users u
LEFT JOIN (
    SELECT user_id, COUNT(*) AS post_count
    FROM social_posts 
    WHERE created_at >= '2024-11-01' AND created_at < '2024-12-01'
    GROUP BY user_id
) last_month ON u.id = last_month.user_id
LEFT JOIN (
    SELECT user_id, COUNT(*) AS post_count  
    FROM social_posts
    WHERE created_at >= '2024-12-01' AND created_at < '2025-01-01'
    GROUP BY user_id
) this_month ON u.id = this_month.user_id
WHERE last_month.post_count > 0 AND this_month.post_count IS NULL;
```

## NULL Handling in OUTER JOINs

### Identifying Missing Data
```sql
-- Find specific types of missing connections
SELECT 
    u.username,
    p.content,
    CASE 
        WHEN p.id IS NULL THEN 'No Posts Yet'
        WHEN u.id IS NULL THEN 'Orphaned Post'  
        ELSE 'Connected Data'
    END AS connection_status
FROM social_users u
FULL OUTER JOIN social_posts p ON u.id = p.user_id;
```

### Replacing NULL Values
```sql
-- Make missing data more readable
SELECT 
    COALESCE(u.username, 'Unknown User') AS username,
    COALESCE(p.content, 'No content posted') AS content,
    COALESCE(p.likes, 0) AS likes
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id;
```

## Real-World OUTER JOIN Scenarios

### 1. E-commerce Analytics
```sql
-- Customer lifecycle analysis
SELECT 
    c.customer_name,
    c.registration_date,
    COALESCE(recent_orders.order_count, 0) AS recent_orders,
    COALESCE(total_spent.amount, 0) AS lifetime_value
FROM customers c
LEFT JOIN (
    SELECT customer_id, COUNT(*) AS order_count
    FROM orders 
    WHERE order_date >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY customer_id
) recent_orders ON c.id = recent_orders.customer_id
LEFT JOIN (
    SELECT customer_id, SUM(total_amount) AS amount
    FROM orders
    GROUP BY customer_id  
) total_spent ON c.id = total_spent.customer_id;
```

### 2. Social Media Engagement
```sql
-- Creator performance with engagement gaps
SELECT 
    u.username,
    u.verified,
    COALESCE(posts.post_count, 0) AS total_posts,
    COALESCE(engagement.avg_likes, 0) AS avg_likes_per_post
FROM social_users u
LEFT JOIN (
    SELECT user_id, COUNT(*) AS post_count
    FROM social_posts
    GROUP BY user_id
) posts ON u.id = posts.user_id
LEFT JOIN (
    SELECT user_id, AVG(likes) AS avg_likes
    FROM social_posts
    GROUP BY user_id
) engagement ON u.id = engagement.user_id
WHERE u.verified = 1;  -- Focus on verified creators
```

### 3. Streaming Platform Analysis
```sql
-- Content performance across all catalog
SELECT 
    s.title AS song_title,
    s.artist,
    COALESCE(plays.play_count, 0) AS total_plays,
    COALESCE(playlists.playlist_count, 0) AS playlist_additions
FROM songs s
LEFT JOIN (
    SELECT song_id, COUNT(*) AS play_count
    FROM user_plays
    GROUP BY song_id
) plays ON s.id = plays.song_id
LEFT JOIN (
    SELECT song_id, COUNT(*) AS playlist_count
    FROM playlist_songs
    GROUP BY song_id
) playlists ON s.id = playlists.song_id
WHERE plays.play_count IS NULL;  -- Find unplayed songs
```

## Performance Considerations

### Efficient OUTER JOIN Queries
```sql
-- ✅ Filter after JOIN for better performance
SELECT u.username, p.content
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
WHERE u.verified = 1;  -- Filter users first

-- ❌ Less efficient nested filtering
SELECT u.username, p.content
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id AND u.verified = 1;
```

### Index Optimization
```sql
-- Ensure indexes on JOIN columns
-- CREATE INDEX idx_posts_user_id ON social_posts(user_id);
-- CREATE INDEX idx_users_id ON social_users(id);

-- This makes OUTER JOINs much faster
SELECT u.username, COUNT(p.id) AS post_count
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
GROUP BY u.username;
```

## Common OUTER JOIN Patterns

### 1. Gap Analysis
```sql
-- Find missing elements in sequences
SELECT 
    expected.month,
    COALESCE(actual.sales_count, 0) AS actual_sales
FROM (
    SELECT generate_series(1, 12) AS month
) expected
LEFT JOIN (
    SELECT EXTRACT(month FROM order_date) AS month, COUNT(*) AS sales_count
    FROM orders
    WHERE EXTRACT(year FROM order_date) = 2024
    GROUP BY EXTRACT(month FROM order_date)
) actual ON expected.month = actual.month;
```

### 2. User Segmentation
```sql
-- Classify users by activity level
SELECT 
    u.username,
    CASE 
        WHEN p.post_count IS NULL THEN 'Inactive'
        WHEN p.post_count >= 10 THEN 'Power User'
        WHEN p.post_count >= 3 THEN 'Active'
        ELSE 'Casual'
    END AS user_segment
FROM social_users u
LEFT JOIN (
    SELECT user_id, COUNT(*) AS post_count
    FROM social_posts
    GROUP BY user_id
) p ON u.id = p.user_id;
```

### 3. Reporting Templates
```sql
-- Monthly active user report with gaps
SELECT 
    months.month,
    COALESCE(active_users.user_count, 0) AS active_users,
    COALESCE(new_posts.post_count, 0) AS new_posts
FROM (
    SELECT generate_series(1, 12) AS month
) months
LEFT JOIN (
    SELECT 
        EXTRACT(month FROM last_login) AS month,
        COUNT(DISTINCT user_id) AS user_count
    FROM user_sessions
    WHERE EXTRACT(year FROM last_login) = 2024
    GROUP BY EXTRACT(month FROM last_login)
) active_users ON months.month = active_users.month
LEFT JOIN (
    SELECT 
        EXTRACT(month FROM created_at) AS month,
        COUNT(*) AS post_count
    FROM social_posts
    WHERE EXTRACT(year FROM created_at) = 2024
    GROUP BY EXTRACT(month FROM created_at)
) new_posts ON months.month = new_posts.month;
```

## Troubleshooting OUTER JOINs

### 1. Unexpected NULL Values
```sql
-- Debug: Check for unexpected NULLs
SELECT 
    'Users without posts' AS category,
    COUNT(*) AS count
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
WHERE p.id IS NULL

UNION ALL

SELECT 
    'Posts without users' AS category,
    COUNT(*) AS count
FROM social_users u
RIGHT JOIN social_posts p ON u.id = p.user_id
WHERE u.id IS NULL;
```

### 2. Performance Issues
```sql
-- ❌ Cartesian explosion with multiple OUTER JOINs
SELECT u.username, p.content, c.comment_text
FROM users u
LEFT JOIN posts p ON u.id = p.user_id
LEFT JOIN comments c ON u.id = c.user_id;  -- Wrong! Links comments to users directly

-- ✅ Proper relationship hierarchy
SELECT u.username, p.content, c.comment_text
FROM users u
LEFT JOIN posts p ON u.id = p.user_id
LEFT JOIN comments c ON p.id = c.post_id;  -- Correct relationship
```

OUTER JOINs reveal the complete story of your data - both the connections and the gaps. Master these patterns, and you'll uncover insights that competitors miss: which customers are at risk of churning, which products need marketing boost, or which features users ignore. The most valuable business intelligence often comes from understanding what's NOT happening! 🔍📊
    ''',
    "is_free": False,
    "xp_reward": 120,
    "exercises": [
        {
            "id": "social-media-outer-joins",
            "title": "Social Media Gap Analysis with OUTER JOINs",
            "type": "practice", 
            "instructions": """Practice OUTER JOINs to find missing connections and analyze user engagement gaps in social media data.

Your tasks:
1. First explore each table: SELECT * FROM social_users; SELECT * FROM social_posts;
2. Use LEFT JOIN to find all users, including those without posts
3. Use RIGHT JOIN to find all posts, including orphaned ones
4. Use FULL OUTER JOIN to see complete picture
5. Find specifically users who haven't posted (identify inactive users)
6. Count posts per user, including users with zero posts

Tables:
- social_users: id, username, email, verified
- social_posts: id, user_id, content, likes""",
            "starter_code": """-- Task 1: Explore table structures
SELECT * FROM social_users;
-- Also explore social_posts table

-- Task 2: LEFT JOIN - All users, including those without posts
-- Show username, verified status, and content (NULLs for users without posts)


-- Task 3: RIGHT JOIN - All posts, including orphaned ones  
-- Show username and content (NULLs for orphaned posts)


-- Task 4: FULL OUTER JOIN - Complete picture
-- Show all users and all posts, regardless of connections


-- Task 5: Find users who haven't posted yet (WHERE post IS NULL)
-- Use LEFT JOIN then filter for NULL posts to find inactive users


-- Task 6: Count posts per user, including zero counts
-- Use LEFT JOIN with GROUP BY and COUNT() to show all users with post counts
""",
            "solution": """-- Task 1: Explore table structures
SELECT * FROM social_users;
SELECT * FROM social_posts;

-- Task 2: LEFT JOIN - All users, including those without posts
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id;

-- Task 3: RIGHT JOIN - All posts, including orphaned ones
SELECT 
    u.username,
    p.content,
    p.likes
FROM social_users u
RIGHT JOIN social_posts p ON u.id = p.user_id;

-- Task 4: FULL OUTER JOIN - Complete picture
SELECT 
    u.username,
    u.verified,
    p.content,
    p.likes
FROM social_users u
FULL OUTER JOIN social_posts p ON u.id = p.user_id;

-- Task 5: Find users who haven't posted yet
SELECT 
    u.username,
    u.email,
    u.verified
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
WHERE p.id IS NULL;

-- Task 6: Count posts per user, including zero counts
SELECT 
    u.username,
    u.verified,
    COUNT(p.id) AS post_count
FROM social_users u
LEFT JOIN social_posts p ON u.id = p.user_id
GROUP BY u.username, u.verified
ORDER BY post_count DESC;""",
            "test_cases": [
                {
                    "name": "LEFT JOIN syntax",
                    "input": "SELECT u.username, p.content FROM social_users u LEFT JOIN social_posts p ON u.id = p.user_id;",
                    "expected_contains": ["LEFT JOIN", "ON", "u.id", "p.user_id"]
                },
                {
                    "name": "Finding NULL values",
                    "input": "SELECT * FROM social_users u LEFT JOIN social_posts p ON u.id = p.user_id WHERE p.id IS NULL;",
                    "expected_contains": ["WHERE", "IS NULL", "LEFT JOIN"]
                }
            ],
            "xp_reward": 80,
            "hints": [
                "LEFT JOIN keeps all records from the left table (social_users)",
                "RIGHT JOIN keeps all records from the right table (social_posts)",
                "Use WHERE column IS NULL to find missing connections",
                "COUNT(p.id) will count actual posts, giving 0 for users with no posts",
                "FULL OUTER JOIN shows everything from both tables"
            ]
        },
        {
            "id": "ecommerce-gap-analysis",
            "title": "E-commerce Customer and Order Gap Analysis",
            "type": "practice",
            "instructions": """Use OUTER JOINs to analyze customer behavior and find business opportunities in e-commerce data.

Your tasks:
1. Explore customer and order tables
2. Find all customers, including those who never ordered
3. Find customers who registered but never purchased (business opportunity!)
4. Calculate customer lifetime value, including zero-value customers
5. Find the most recent order date for each customer
6. Identify high-value customers vs inactive customers

Tables:
- customers: id, name, email, registration_date
- orders: id, customer_id, order_date, total_amount""",
            "starter_code": """-- Task 1: Explore both tables
SELECT * FROM customers LIMIT 5;
-- Also explore orders table

-- Task 2: All customers with their order information (LEFT JOIN)
-- Show customer name, email, and order details (NULLs for no orders)


-- Task 3: Find customers who never ordered  
-- Use LEFT JOIN then filter WHERE order IS NULL


-- Task 4: Calculate customer lifetime value (including zeros)
-- Use LEFT JOIN with SUM(total_amount), handle NULLs with COALESCE


-- Task 5: Find most recent order per customer
-- Use LEFT JOIN with MAX(order_date) grouped by customer


-- Task 6: Customer segmentation by order behavior
-- Classify customers as 'High Value', 'Active', or 'Inactive' based on order data
""",
            "solution": """-- Task 1: Explore both tables
SELECT * FROM customers LIMIT 5;
SELECT * FROM orders LIMIT 5;

-- Task 2: All customers with their order information
SELECT 
    c.name,
    c.email,
    c.registration_date,
    o.order_date,
    o.total_amount
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id;

-- Task 3: Find customers who never ordered
SELECT 
    c.name,
    c.email,
    c.registration_date
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.id IS NULL;

-- Task 4: Calculate customer lifetime value (including zeros)
SELECT 
    c.name,
    c.email,
    COALESCE(SUM(o.total_amount), 0) AS lifetime_value,
    COUNT(o.id) AS order_count
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
GROUP BY c.name, c.email
ORDER BY lifetime_value DESC;

-- Task 5: Find most recent order per customer
SELECT 
    c.name,
    c.email,
    MAX(o.order_date) AS last_order_date,
    COUNT(o.id) AS total_orders
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
GROUP BY c.name, c.email;

-- Task 6: Customer segmentation by order behavior
SELECT 
    c.name,
    COALESCE(SUM(o.total_amount), 0) AS lifetime_value,
    COUNT(o.id) AS order_count,
    CASE 
        WHEN COUNT(o.id) = 0 THEN 'Inactive'
        WHEN SUM(o.total_amount) >= 500 THEN 'High Value'
        WHEN COUNT(o.id) >= 3 THEN 'Active'
        ELSE 'Casual'
    END AS customer_segment
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
GROUP BY c.name
ORDER BY lifetime_value DESC;""",
            "test_cases": [
                {
                    "name": "Customer lifetime value calculation",
                    "input": "SELECT c.name, SUM(o.total_amount) FROM customers c LEFT JOIN orders o ON c.id = o.customer_id GROUP BY c.name;",
                    "expected_contains": ["SUM", "LEFT JOIN", "GROUP BY"]
                },
                {
                    "name": "Customer segmentation with CASE",
                    "input": "SELECT CASE WHEN COUNT(o.id) = 0 THEN 'Inactive' ELSE 'Active' END FROM customers c LEFT JOIN orders o ON c.id = o.customer_id GROUP BY c.id;",
                    "expected_contains": ["CASE", "WHEN", "COUNT", "LEFT JOIN"]
                }
            ],
            "xp_reward": 90,
            "hints": [
                "Use COALESCE to replace NULL sums with 0",
                "GROUP BY is essential when using aggregate functions like SUM and COUNT",
                "WHERE column IS NULL finds records with no matches",
                "CASE statements help create customer segments based on calculated values",
                "MAX(order_date) finds the most recent order for each customer"
            ]
        }
    ]
}