"""
Django Advanced - Lesson 3: Database Functions
Master Django's database functions for advanced data manipulation and analysis
"""

DJANGO_DATABASE_FUNCTIONS_LESSON = {
    "id": 53,
    "chapter": 53,
    "title": "Django Database Functions: Advanced Data Manipulation",
    "slug": "django-database-functions",
    "description": "Master Django's database functions for text, date, math operations and window functions",
    "content": '''# Django Database Functions: Advanced Data Manipulation

## 🎯 Understanding Database Functions

Django's **Database Functions** provide direct access to database-specific capabilities for data transformation, analysis, and computation. They enable sophisticated data processing without pulling data into Python.

**Function Categories**:
- **Comparison Functions** → Cast, Coalesce, Greatest, Least
- **Date Functions** → Extract, Trunc, Now, timedelta operations
- **Math Functions** → Abs, Round, trigonometric functions
- **Text Functions** → Concat, Length, Upper, Lower, substring operations  
- **Window Functions** → Rank, RowNumber, Lag, Lead, partitioning
- **Aggregate Functions** → Advanced aggregation with database functions

Think of database functions as **SQL superpowers within Django** - enabling complex operations that scale with your data.

## 💾 Content Management System Database

Let's work with a comprehensive CMS database to demonstrate database functions:

```sql
-- Blog posts with rich metadata
CREATE TABLE blog_posts (
    id SERIAL PRIMARY KEY,
    title VARCHAR(300) NOT NULL,
    slug VARCHAR(300) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    author_name VARCHAR(100) NOT NULL,
    author_email VARCHAR(254) NOT NULL,
    published_date TIMESTAMP,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    view_count INTEGER DEFAULT 0,
    like_count INTEGER DEFAULT 0,
    comment_count INTEGER DEFAULT 0,
    reading_time_minutes INTEGER,
    word_count INTEGER,
    category VARCHAR(100),
    tags TEXT, -- Comma-separated tags
    meta_description VARCHAR(160),
    featured_image_url VARCHAR(500),
    is_published BOOLEAN DEFAULT FALSE,
    is_featured BOOLEAN DEFAULT FALSE,
    seo_score DECIMAL(3, 1) DEFAULT 0.0
);

-- Sample blog post data
INSERT INTO blog_posts (title, slug, content, excerpt, author_name, author_email, published_date, view_count, like_count, comment_count, reading_time_minutes, word_count, category, tags, is_published, seo_score) VALUES
('Getting Started with Machine Learning', 'getting-started-machine-learning', 'Machine learning is transforming how we solve complex problems. This comprehensive guide covers the fundamentals of ML, from basic concepts to practical implementation. We''ll explore supervised learning, unsupervised learning, and reinforcement learning with real-world examples...', 'Learn machine learning fundamentals with practical examples and real-world applications.', 'Dr. Sarah Chen', 'sarah@example.com', '2024-11-15 10:30:00', 15420, 342, 89, 12, 2800, 'Technology', 'machine learning,ai,data science,python', TRUE, 8.5),

('The Future of Web Development', 'future-web-development', 'Web development continues to evolve at a rapid pace. From React and Vue to emerging technologies like WebAssembly, developers need to stay current with the latest trends. This article explores upcoming technologies that will shape web development in the next decade...', 'Explore the cutting-edge technologies shaping the future of web development.', 'Mike Rodriguez', 'mike@example.com', '2024-12-01 14:22:00', 8934, 267, 45, 8, 1850, 'Technology', 'web development,react,vue,webassembly,frontend', TRUE, 7.2),

('Sustainable Living: A Complete Guide', 'sustainable-living-complete-guide', 'Sustainable living isn''t just a trend—it''s a necessity for our planet''s future. This comprehensive guide provides practical tips for reducing your environmental footprint through simple daily changes. From energy conservation to waste reduction, discover actionable steps you can take today...', 'Practical tips and strategies for adopting a more sustainable lifestyle.', 'Emma Johnson', 'emma@example.com', '2024-12-10 09:15:00', 23651, 892, 156, 15, 3200, 'Lifestyle', 'sustainability,environment,green living,eco-friendly', TRUE, 9.1),

('Advanced Python Programming Techniques', 'advanced-python-programming', 'Python''s simplicity makes it accessible, but mastering advanced techniques unlocks its true power. This article dives deep into decorators, metaclasses, context managers, and async programming. Learn how to write more efficient, elegant Python code that scales...', 'Master advanced Python concepts to write more efficient and elegant code.', 'David Kim', 'david@example.com', '2024-12-05 16:45:00', 12456, 423, 78, 18, 4100, 'Programming', 'python,programming,advanced,decorators,async', TRUE, 8.8),

('Digital Marketing Strategies for 2025', 'digital-marketing-strategies-2025', 'Digital marketing landscape changes rapidly. What worked yesterday might not work tomorrow. This strategic guide covers the latest digital marketing trends, from AI-powered personalization to voice search optimization. Discover how to build a future-proof marketing strategy...', 'Stay ahead with cutting-edge digital marketing strategies for the coming year.', 'Lisa Wang', 'lisa@example.com', '2024-12-15 11:30:00', 9876, 234, 67, 10, 2300, 'Marketing', 'digital marketing,ai,personalization,voice search,strategy', TRUE, 7.9),

('Mastering Remote Work Productivity', 'mastering-remote-work-productivity', 'Remote work is here to stay, but productivity challenges remain real. This guide shares proven strategies for maintaining focus, managing time, and staying connected with your team. Learn from successful remote workers and build habits that boost your productivity...', 'Proven strategies and tips for maximizing productivity while working remotely.', 'James Brown', 'james@example.com', '2024-12-20 13:20:00', 7654, 189, 34, 12, 2650, 'Business', 'remote work,productivity,time management,work from home', TRUE, 8.3),

('Introduction to Blockchain Technology', 'introduction-blockchain-technology', 'Blockchain technology extends far beyond cryptocurrency. This beginner-friendly introduction explains how blockchain works, its applications across industries, and potential future developments. Understand the fundamentals without getting lost in technical jargon...', 'A beginner-friendly guide to understanding blockchain technology and its applications.', 'Alex Thompson', 'alex@example.com', '2024-12-22 08:45:00', 11234, 356, 92, 14, 3400, 'Technology', 'blockchain,cryptocurrency,distributed systems,fintech', FALSE, 6.8),

('Healthy Cooking on a Budget', 'healthy-cooking-budget', 'Eating healthy doesn''t have to break the bank. This practical guide shows how to prepare nutritious, delicious meals without overspending. From meal planning to smart shopping strategies, discover how to maintain a healthy diet on any budget...', 'Learn how to eat healthy while staying within your budget with practical tips and recipes.', 'Maria Garcia', 'maria@example.com', '2024-12-25 15:10:00', 6543, 187, 23, 9, 2100, 'Health', 'healthy eating,budget cooking,nutrition,meal planning', TRUE, 7.6);

-- Comments for text analysis
CREATE TABLE post_comments (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL,
    author_name VARCHAR(100) NOT NULL,
    author_email VARCHAR(254) NOT NULL,
    content TEXT NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_approved BOOLEAN DEFAULT TRUE,
    upvotes INTEGER DEFAULT 0,
    parent_comment_id INTEGER,
    FOREIGN KEY (post_id) REFERENCES blog_posts(id),
    FOREIGN KEY (parent_comment_id) REFERENCES post_comments(id)
);

-- Sample comments
INSERT INTO post_comments (post_id, author_name, author_email, content, upvotes) VALUES
(1, 'Tech Enthusiast', 'tech@reader.com', 'Excellent introduction to ML! The examples really helped clarify complex concepts.', 45),
(1, 'Data Scientist', 'data@analyst.com', 'Great overview. Would love to see a follow-up on deep learning specifics.', 32),
(2, 'Frontend Developer', 'frontend@dev.com', 'WebAssembly section was particularly insightful. Thanks for the detailed explanation!', 28),
(3, 'Eco Warrior', 'green@planet.com', 'Implementing these tips has already reduced my carbon footprint significantly!', 67),
(4, 'Python Developer', 'python@coder.com', 'The metaclasses explanation finally made them click for me. Brilliant writing!', 41),
(5, 'Marketing Manager', 'marketing@pro.com', 'AI personalization strategies are game-changers. Already testing some approaches.', 23),
(6, 'Remote Worker', 'remote@worker.com', 'These productivity tips transformed my work-from-home routine. Highly recommended!', 35);

-- User analytics for function demonstrations
CREATE TABLE user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    session_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_end TIMESTAMP,
    pages_viewed INTEGER DEFAULT 0,
    time_on_site_seconds INTEGER DEFAULT 0,
    referrer_url VARCHAR(500),
    user_agent TEXT,
    ip_address INET,
    device_type VARCHAR(50),
    browser VARCHAR(100),
    country VARCHAR(100),
    region VARCHAR(100),
    city VARCHAR(100)
);

-- Sample session data
INSERT INTO user_sessions (user_id, session_start, session_end, pages_viewed, time_on_site_seconds, device_type, browser, country, region, city) VALUES
(1001, '2024-12-20 10:15:00', '2024-12-20 10:45:30', 5, 1830, 'desktop', 'Chrome', 'United States', 'California', 'San Francisco'),
(1002, '2024-12-20 14:22:15', '2024-12-20 14:50:22', 3, 1687, 'mobile', 'Safari', 'United Kingdom', 'England', 'London'),
(1003, '2024-12-20 16:30:45', '2024-12-20 17:15:12', 8, 2667, 'desktop', 'Firefox', 'Germany', 'Bavaria', 'Munich'),
(1004, '2024-12-21 09:10:30', '2024-12-21 09:35:45', 4, 1515, 'tablet', 'Chrome', 'Canada', 'Ontario', 'Toronto'),
(1005, '2024-12-21 13:45:20', '2024-12-21 14:20:35', 6, 2115, 'desktop', 'Chrome', 'Australia', 'New South Wales', 'Sydney'),
(1006, '2024-12-21 18:20:10', '2024-12-21 18:55:30', 7, 2120, 'mobile', 'Safari', 'Japan', 'Tokyo', 'Tokyo'),
(1007, '2024-12-22 11:30:25', '2024-12-22 12:10:40', 9, 2415, 'desktop', 'Edge', 'France', 'Île-de-France', 'Paris');

-- Newsletter subscriptions for date functions
CREATE TABLE newsletter_subscriptions (
    id SERIAL PRIMARY KEY,
    email VARCHAR(254) UNIQUE NOT NULL,
    subscribed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    unsubscribed_date TIMESTAMP,
    subscription_source VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    preferences JSONB DEFAULT '{}'::jsonb,
    engagement_score DECIMAL(3, 2) DEFAULT 0.00
);

-- Sample newsletter data
INSERT INTO newsletter_subscriptions (email, subscribed_date, subscription_source, engagement_score) VALUES
('subscriber1@email.com', '2024-01-15 10:30:00', 'blog_signup', 0.85),
('subscriber2@email.com', '2024-03-22 14:15:00', 'social_media', 0.62),
('subscriber3@email.com', '2024-06-10 09:45:00', 'direct_visit', 0.78),
('subscriber4@email.com', '2024-09-05 16:20:00', 'referral', 0.91),
('subscriber5@email.com', '2024-11-18 11:55:00', 'blog_signup', 0.43),
('subscriber6@email.com', '2024-12-01 13:30:00', 'social_media', 0.56);
```

## 🔧 Text Functions - Content Manipulation

### 1. String Operations and Analysis

**Scenario**: Medium's content analysis and SEO optimization

```python
from django.db.models.functions import (
    Concat, Length, Upper, Lower, Substr, Replace, 
    Trim, LTrim, RTrim, Reverse
)
from django.db.models import Value, CharField

class ContentAnalysis:
    @staticmethod
    def analyze_content_metrics():
        """Analyze blog post content using text functions"""
        
        return BlogPost.objects.annotate(
            # Create full author info
            author_display=Concat(
                Upper('author_name'),
                Value(' ('),
                'author_email',
                Value(')'),
                output_field=CharField()
            ),
            
            # Content length analysis
            title_length=Length('title'),
            content_length=Length('content'),
            excerpt_length=Length('excerpt'),
            
            # SEO-friendly slug analysis
            slug_words=Length('slug') - Length(Replace('slug', Value('-'), Value(''))) + 1,
            
            # Tag analysis
            tag_count=Length('tags') - Length(Replace('tags', Value(','), Value(''))) + 1,
            
            # First words of title for social media
            title_first_50=Substr('title', 1, 50),
            
            # Author first name extraction
            author_first_name=Substr(
                'author_name',
                1,
                Position(' ', 'author_name') - 1
            ),
            
            # Content quality score based on length
            content_quality=Case(
                When(content_length__gte=3000, then=Value('Excellent')),
                When(content_length__gte=2000, then=Value('Good')),
                When(content_length__gte=1000, then=Value('Fair')),
                default=Value('Needs Improvement'),
                output_field=CharField(max_length=20)
            )
        ).order_by('-content_length')

    @staticmethod
    def content_seo_optimization():
        """SEO analysis using text functions"""
        
        return BlogPost.objects.annotate(
            # Title optimization
            title_word_count=Length('title') - Length(Replace('title', Value(' '), Value(''))) + 1,
            title_seo_score=Case(
                When(title_length__range=[30, 60], then=Value(10)),
                When(title_length__range=[20, 80], then=Value(7)),
                default=Value(3),
                output_field=IntegerField()
            ),
            
            # Meta description optimization
            meta_length=Length('meta_description'),
            meta_seo_score=Case(
                When(meta_length__range=[120, 160], then=Value(10)),
                When(meta_length__range=[100, 180], then=Value(7)),
                default=Value(3),
                output_field=IntegerField()
            ),
            
            # Slug optimization
            slug_clean=Lower(Replace('slug', Value('-'), Value(' '))),
            slug_seo_score=Case(
                When(slug_words__range=[3, 6], then=Value(10)),
                When(slug_words__range=[2, 8], then=Value(7)),
                default=Value(3),
                output_field=IntegerField()
            ),
            
            # Overall SEO score
            total_seo_score=F('title_seo_score') + F('meta_seo_score') + F('slug_seo_score')
            
        ).order_by('-total_seo_score')
```

### 2. Advanced Text Processing

**Scenario**: Twitter's content moderation and analysis

```python
def advanced_text_analysis():
    """Advanced text analysis for content quality"""
    
    return BlogPost.objects.annotate(
        # Reading level estimation (simplified)
        avg_word_length=Cast(F('content_length') / F('word_count'), FloatField()),
        
        # Sentence estimation
        sentence_count=Length('content') - Length(Replace('content', Value('.'), Value(''))),
        words_per_sentence=Cast(F('word_count') / F('sentence_count'), FloatField()),
        
        # Content categorization based on length
        content_type=Case(
            When(word_count__gte=3000, then=Value('Long-form Article')),
            When(word_count__gte=1500, then=Value('Medium Article')),
            When(word_count__gte=800, then=Value('Short Article')),
            default=Value('Brief Post'),
            output_field=CharField(max_length=20)
        ),
        
        # Title analysis for clickbait detection
        title_upper=Upper('title'),
        has_numbers=Case(
            When(title__regex=r'[0-9]', then=True),
            default=False,
            output_field=BooleanField()
        ),
        
        # Author domain extraction
        author_domain=Substr(
            'author_email',
            Position('@', 'author_email') + 1,
            Length('author_email')
        ),
        
        # Content preview for social sharing
        social_preview=Case(
            When(excerpt__isnull=False, then=Substr('excerpt', 1, 150)),
            default=Substr('content', 1, 150),
            output_field=CharField(max_length=150)
        )
    ).order_by('-word_count')
```

## 📅 Date Functions - Temporal Analysis

### 3. Date Extraction and Manipulation

**Scenario**: Google Analytics-style temporal analysis

```python
from django.db.models.functions import (
    Extract, Trunc, Now, 
    TruncDay, TruncWeek, TruncMonth, TruncYear
)

class TemporalAnalysis:
    @staticmethod
    def publication_analytics():
        """Analyze publication patterns over time"""
        
        return BlogPost.objects.annotate(
            # Extract date components
            publish_year=Extract('published_date', 'year'),
            publish_month=Extract('published_date', 'month'),
            publish_day=Extract('published_date', 'day'),
            publish_weekday=Extract('published_date', 'week_day'),
            publish_hour=Extract('published_date', 'hour'),
            
            # Publication timing analysis
            publish_season=Case(
                When(publish_month__in=[12, 1, 2], then=Value('Winter')),
                When(publish_month__in=[3, 4, 5], then=Value('Spring')),
                When(publish_month__in=[6, 7, 8], then=Value('Summer')),
                default=Value('Fall'),
                output_field=CharField(max_length=10)
            ),
            
            # Day type classification
            day_type=Case(
                When(publish_weekday__in=[1, 7], then=Value('Weekend')),
                default=Value('Weekday'),
                output_field=CharField(max_length=10)
            ),
            
            # Time of day analysis
            time_of_day=Case(
                When(publish_hour__range=[6, 11], then=Value('Morning')),
                When(publish_hour__range=[12, 17], then=Value('Afternoon')),
                When(publish_hour__range=[18, 21], then=Value('Evening')),
                default=Value('Night'),
                output_field=CharField(max_length=10)
            ),
            
            # Days since publication
            days_since_publish=Extract(
                Now() - F('published_date'), 'days'
            ),
            
            # Content freshness score
            freshness_score=Case(
                When(days_since_publish__lte=7, then=Value(100)),
                When(days_since_publish__lte=30, then=Value(80)),
                When(days_since_publish__lte=90, then=Value(60)),
                When(days_since_publish__lte=365, then=Value(40)),
                default=Value(20),
                output_field=IntegerField()
            )
        ).order_by('-published_date')

    @staticmethod
    def engagement_over_time():
        """Analyze content engagement patterns"""
        
        return BlogPost.objects.annotate(
            # Truncate to different periods
            publish_day=TruncDay('published_date'),
            publish_week=TruncWeek('published_date'),
            publish_month=TruncMonth('published_date'),
            
            # Engagement velocity (engagement per day since publish)
            engagement_total=F('view_count') + F('like_count') * 5 + F('comment_count') * 10,
            engagement_velocity=Case(
                When(days_since_publish__gt=0, 
                     then=F('engagement_total') / F('days_since_publish')),
                default=F('engagement_total'),
                output_field=FloatField()
            ),
            
            # Performance classification
            performance_tier=Case(
                When(engagement_velocity__gte=1000, then=Value('Viral')),
                When(engagement_velocity__gte=500, then=Value('High Performing')),
                When(engagement_velocity__gte=100, then=Value('Good')),
                default=Value('Needs Promotion'),
                output_field=CharField(max_length=20)
            )
        )
```

### 4. Session and User Activity Analysis

**Scenario**: Firebase Analytics-style user behavior tracking

```python
def user_session_analysis():
    """Analyze user session patterns with date functions"""
    
    return UserSession.objects.annotate(
        # Session duration calculation
        session_duration_seconds=Extract(
            F('session_end') - F('session_start'), 'epoch'
        ),
        
        # Session timing analysis
        session_hour=Extract('session_start', 'hour'),
        session_day=Extract('session_start', 'week_day'),
        
        # Time classification
        session_period=Case(
            When(session_hour__range=[9, 17], then=Value('Business Hours')),
            When(session_hour__range=[18, 22], then=Value('Evening')),
            When(session_hour__range=[23, 24], then=Value('Late Night')),
            When(session_hour__range=[0, 6], then=Value('Early Morning')),
            default=Value('Morning'),
            output_field=CharField(max_length=20)
        ),
        
        # Engagement quality
        pages_per_minute=Case(
            When(session_duration_seconds__gt=60,
                 then=F('pages_viewed') * 60.0 / F('session_duration_seconds')),
            default=F('pages_viewed'),
            output_field=FloatField()
        ),
        
        # Session quality score
        quality_score=Case(
            When(
                session_duration_seconds__gte=300,
                pages_viewed__gte=3,
                then=Value(100)
            ),
            When(
                session_duration_seconds__gte=180,
                pages_viewed__gte=2,
                then=Value(75)
            ),
            When(
                session_duration_seconds__gte=60,
                then=Value(50)
            ),
            default=Value(25),
            output_field=IntegerField()
        )
    ).order_by('-session_duration_seconds')
```

## 🔢 Math Functions - Numerical Analysis

### 5. Advanced Mathematical Operations

**Scenario**: YouTube's engagement and recommendation algorithms

```python
from django.db.models.functions import (
    Abs, Round, Ceil, Floor, 
    Sin, Cos, Tan, Sqrt, Power, Ln, Log
)

class MathematicalAnalysis:
    @staticmethod
    def advanced_engagement_metrics():
        """Calculate advanced engagement metrics"""
        
        return BlogPost.objects.annotate(
            # Engagement rate calculations
            total_interactions=F('view_count') + F('like_count') + F('comment_count'),
            
            # Logarithmic view scaling (for viral content)
            log_views=Case(
                When(view_count__gt=1, then=Ln(F('view_count'))),
                default=0.0,
                output_field=FloatField()
            ),
            
            # Engagement velocity with diminishing returns
            engagement_momentum=Sqrt(F('total_interactions')) * F('freshness_score') / 100,
            
            # Content quality score using power functions
            quality_index=Power(
                (F('like_count') + 1) / (F('view_count') + 1) * 1000, 0.5
            ),
            
            # Viral coefficient calculation
            viral_coefficient=Round(
                F('like_count') * F('comment_count') / Greatest(F('view_count'), 1),
                precision=3
            ),
            
            # Reading engagement estimation
            reading_completion_rate=Case(
                When(
                    reading_time_minutes__gt=0,
                    then=Round(
                        Least(F('time_on_site_seconds') / (F('reading_time_minutes') * 60), 1.0) * 100,
                        precision=1
                    )
                ),
                default=0.0,
                output_field=FloatField()
            ),
            
            # Content performance normalization
            performance_percentile=Round(
                F('engagement_momentum') / F('days_since_publish') * 100,
                precision=2
            )
        ).order_by('-engagement_momentum')

    @staticmethod
    def seo_score_calculation():
        """Advanced SEO scoring with mathematical functions"""
        
        return BlogPost.objects.annotate(
            # Content length score (optimal around 2000 words)
            length_score=Case(
                When(word_count__exact=2000, then=Value(100)),
                default=Round(
                    100 - Abs(F('word_count') - 2000) / 50.0,
                    precision=1
                ),
                output_field=FloatField()
            ),
            
            # Title length score (optimal 50-60 characters)
            title_score=Case(
                When(title_length__range=[50, 60], then=Value(100)),
                default=Round(
                    100 - Power(Abs(F('title_length') - 55), 1.5),
                    precision=1
                ),
                output_field=FloatField()
            ),
            
            # Engagement rate (likes per view)
            engagement_rate=Round(
                F('like_count') * 100.0 / Greatest(F('view_count'), 1),
                precision=2
            ),
            
            # Readability score estimation
            readability_score=Round(
                206.835 - (1.015 * F('words_per_sentence')) - (84.6 * F('avg_word_length')),
                precision=1
            ),
            
            # Compound SEO score
            compound_seo_score=Round(
                (F('length_score') + F('title_score') + F('engagement_rate') * 2) / 4,
                precision=1
            )
        ).order_by('-compound_seo_score')
```

## 🏢 Window Functions - Advanced Analytics

### 6. Ranking and Analytical Functions

**Scenario**: LinkedIn's content ranking and competitive analysis

```python
from django.db.models import Window
from django.db.models.functions import (
    Rank, DenseRank, RowNumber, 
    Lag, Lead, FirstValue, LastValue,
    NthValue, Ntile
)

class WindowFunctionAnalysis:
    @staticmethod
    def content_ranking_analysis():
        """Rank content using window functions"""
        
        return BlogPost.objects.annotate(
            # Global rankings
            view_rank=Window(
                expression=Rank(),
                order_by=F('view_count').desc()
            ),
            
            engagement_rank=Window(
                expression=DenseRank(),
                order_by=(F('like_count') + F('comment_count')).desc()
            ),
            
            # Category-based rankings
            category_view_rank=Window(
                expression=Rank(),
                partition_by=['category'],
                order_by=F('view_count').desc()
            ),
            
            category_engagement_rank=Window(
                expression=RowNumber(),
                partition_by=['category'],
                order_by=(F('like_count') + F('comment_count')).desc()
            ),
            
            # Performance percentiles
            view_percentile=Window(
                expression=Ntile(100),
                order_by=F('view_count')
            ),
            
            # Time-based analysis
            previous_post_views=Window(
                expression=Lag('view_count', 1),
                partition_by=['author_name'],
                order_by='published_date'
            ),
            
            next_post_views=Window(
                expression=Lead('view_count', 1),
                partition_by=['author_name'],
                order_by='published_date'
            ),
            
            # Author performance tracking
            author_best_performance=Window(
                expression=FirstValue('view_count'),
                partition_by=['author_name'],
                order_by=F('view_count').desc()
            ),
            
            author_latest_performance=Window(
                expression=LastValue('view_count'),
                partition_by=['author_name'],
                order_by='published_date'
            ),
            
            # Growth indicators
            view_growth=Case(
                When(
                    previous_post_views__isnull=False,
                    then=Round(
                        (F('view_count') - F('previous_post_views')) * 100.0 / F('previous_post_views'),
                        precision=2
                    )
                ),
                default=0.0,
                output_field=FloatField()
            )
        ).order_by('-view_count')

    @staticmethod
    def author_performance_analytics():
        """Analyze author performance trends"""
        
        return BlogPost.objects.annotate(
            # Author post numbering
            author_post_number=Window(
                expression=RowNumber(),
                partition_by=['author_name'],
                order_by='published_date'
            ),
            
            # Rolling averages
            author_avg_views=Window(
                expression=Avg('view_count'),
                partition_by=['author_name'],
                order_by='published_date',
                frame=Window.frame(start=-2, end=0)  # 3-post rolling average
            ),
            
            # Performance comparison
            above_author_average=Case(
                When(view_count__gt=F('author_avg_views'), then=True),
                default=False,
                output_field=BooleanField()
            ),
            
            # Author quartiles
            author_performance_quartile=Window(
                expression=Ntile(4),
                partition_by=['author_name'],
                order_by='view_count'
            ),
            
            # Consistency measurement
            author_view_stddev=Window(
                expression=StdDev('view_count'),
                partition_by=['author_name']
            )
        ).order_by('author_name', 'published_date')
```

### 7. Advanced Window Operations

**Scenario**: TikTok's trending and discovery algorithms

```python
def trending_content_analysis():
    """Advanced trending analysis using window functions"""
    
    return BlogPost.objects.annotate(
        # Momentum calculation (recent performance vs historical)
        recent_momentum=Window(
            expression=Avg('view_count'),
            order_by='published_date',
            frame=Window.frame(start=-6, end=0)  # Last 7 posts
        ),
        
        historical_baseline=Window(
            expression=Avg('view_count'),
            order_by='published_date',
            frame=Window.frame(start=-29, end=-7)  # Previous period
        ),
        
        momentum_ratio=Case(
            When(
                historical_baseline__gt=0,
                then=F('recent_momentum') / F('historical_baseline')
            ),
            default=1.0,
            output_field=FloatField()
        ),
        
        # Trending indicators
        is_trending=Case(
            When(
                momentum_ratio__gte=1.5,
                view_percentile__gte=75,
                then=True
            ),
            default=False,
            output_field=BooleanField()
        ),
        
        # Competitive positioning
        category_competition_index=Window(
            expression=Count('id'),
            partition_by=['category', TruncWeek('published_date')]
        ),
        
        # Discovery potential
        discovery_score=Round(
            F('quality_index') * F('freshness_score') / 100 * F('momentum_ratio'),
            precision=2
        )
    ).filter(
        is_published=True
    ).order_by('-discovery_score')
```

## ⚡ Performance Optimization with Database Functions

### 8. Efficient Bulk Operations

```python
def efficient_content_processing():
    """Efficient content processing using database functions"""
    
    # Bulk update content metrics
    BlogPost.objects.update(
        # Update reading time estimation
        reading_time_minutes=Round(F('word_count') / 200.0),  # 200 WPM average
        
        # Update SEO scores
        seo_score=Round(
            (F('title_score') + F('meta_score') + F('content_score')) / 3,
            precision=1
        ),
        
        # Update content freshness
        freshness_score=Case(
            When(
                published_date__gte=timezone.now() - timedelta(days=7),
                then=Value(100)
            ),
            When(
                published_date__gte=timezone.now() - timedelta(days=30),
                then=Value(80)
            ),
            default=Value(60),
            output_field=IntegerField()
        )
    )
```

### 9. Complex Reporting Queries

```python
def generate_content_report():
    """Generate comprehensive content performance report"""
    
    return BlogPost.objects.aggregate(
        # Content volume metrics
        total_posts=Count('id'),
        published_posts=Count('id', filter=Q(is_published=True)),
        total_words=Sum('word_count'),
        
        # Engagement metrics
        total_views=Sum('view_count'),
        avg_views_per_post=Avg('view_count'),
        median_views=Window(
            expression=NthValue('view_count', 
                               Count('id') / 2 + 1),
            order_by='view_count'
        ),
        
        # Content quality metrics
        avg_reading_time=Avg('reading_time_minutes'),
        avg_seo_score=Round(Avg('seo_score'), precision=2),
        
        # Author diversity
        unique_authors=Count('author_name', distinct=True),
        posts_per_author=Round(
            Count('id') / Count('author_name', distinct=True),
            precision=1
        ),
        
        # Category distribution
        categories_count=Count('category', distinct=True),
        
        # Performance distribution
        high_performing_posts=Count(
            'id',
            filter=Q(view_count__gte=10000)
        ),
        viral_posts=Count(
            'id',
            filter=Q(view_count__gte=50000)
        )
    )
```

## 🎯 Key Takeaways

1. **Database functions perform complex operations in the database** → Much faster than Python
2. **Text functions enable sophisticated content analysis** → SEO optimization, readability scoring
3. **Date functions provide powerful temporal analytics** → Trend analysis, seasonality detection
4. **Math functions enable advanced calculations** → Engagement algorithms, scoring systems
5. **Window functions unlock analytical capabilities** → Rankings, moving averages, growth analysis
6. **Combine functions for comprehensive business logic** → Multi-dimensional analysis and insights

Database functions transform Django into a powerful analytics platform capable of handling complex data science operations at scale!
''',
    "difficulty": "advanced",
    "estimated_time": 50,
    "xp_reward": 30,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-expressions", "django-conditional-expressions"],
    "exercises": [
        {
            "id": "db_functions_1",
            "title": "Explore Blog Posts for Function Analysis",
            "prompt": "Let's examine our blog posts table to understand the data we'll analyze with database functions. Write a query to see post titles, content metrics, and engagement data.",
            "table_name": "blog_posts",
            "initial_query": "SELECT * FROM blog_posts LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "blog_posts"],
            "hint": "Use SELECT * FROM blog_posts LIMIT 5; to see the blog post structure",
            "solution": "SELECT * FROM blog_posts LIMIT 5;",
            "explanation": "This shows our comprehensive blog posts table with fields like title, content, word_count, view_count, reading_time_minutes, etc. Database functions will help us analyze and transform this rich dataset."
        },
        {
            "id": "db_functions_2",
            "title": "Text Length Analysis",
            "prompt": "Practice text functions by analyzing content lengths. Write a query to show post titles with their character lengths and word counts.",
            "table_name": "blog_posts",
            "expected_keywords": ["SELECT", "title", "LENGTH", "word_count"],
            "hint": "Use LENGTH() function to get character count of titles",
            "solution": "SELECT title, LENGTH(title) as title_length, word_count, LENGTH(content) as content_length FROM blog_posts ORDER BY title_length DESC;",
            "explanation": "This demonstrates Django's Length() function: .annotate(title_length=Length('title')). Text analysis functions help with SEO optimization and content quality assessment."
        },
        {
            "id": "db_functions_3",
            "title": "Author Name Manipulation",
            "prompt": "Practice string manipulation by extracting author first names. Write a query to show author names and extract just the first name (before the space).",
            "table_name": "blog_posts",
            "expected_keywords": ["SELECT", "author_name", "SUBSTRING", "POSITION"],
            "hint": "Use SUBSTRING and POSITION to extract text before the first space",
            "solution": "SELECT author_name, SUBSTRING(author_name, 1, POSITION(' ' IN author_name) - 1) as first_name FROM blog_posts WHERE POSITION(' ' IN author_name) > 0;",
            "explanation": "This simulates Django's Substr() function combined with Position(): Substr('author_name', 1, Position(' ', 'author_name') - 1). String manipulation functions enable content personalization and data formatting."
        },
        {
            "id": "db_functions_4",
            "title": "Date Component Extraction",
            "prompt": "Practice date functions by extracting publication timing. Write a query to show post titles with the year, month, and day extracted from published_date.",
            "table_name": "blog_posts",
            "expected_keywords": ["SELECT", "title", "EXTRACT", "year", "month", "day", "published_date"],
            "hint": "Use EXTRACT(year FROM published_date) for date components",
            "solution": "SELECT title, published_date, EXTRACT(year FROM published_date) as pub_year, EXTRACT(month FROM published_date) as pub_month, EXTRACT(day FROM published_date) as pub_day FROM blog_posts WHERE published_date IS NOT NULL ORDER BY published_date DESC;",
            "explanation": "This demonstrates Django's Extract() function: .annotate(pub_year=Extract('published_date', 'year')). Date extraction enables temporal analysis, seasonal trends, and time-based grouping."
        },
        {
            "id": "db_functions_5",
            "title": "Mathematical Content Analysis",
            "prompt": "Use math functions to calculate engagement rates. Write a query to calculate engagement_rate as (like_count + comment_count) / view_count * 100, rounded to 2 decimal places.",
            "table_name": "blog_posts",
            "expected_keywords": ["SELECT", "title", "ROUND", "like_count", "comment_count", "view_count"],
            "hint": "Calculate (like_count + comment_count) / view_count * 100 and use ROUND(value, 2)",
            "solution": "SELECT title, view_count, like_count, comment_count, ROUND((like_count + comment_count)::decimal / NULLIF(view_count, 0) * 100, 2) as engagement_rate FROM blog_posts WHERE view_count > 0 ORDER BY engagement_rate DESC;",
            "explanation": "This shows Django's Round() function: Round((F('like_count') + F('comment_count')) / F('view_count') * 100, precision=2). Mathematical functions enable sophisticated analytics and KPI calculations."
        },
        {
            "id": "db_functions_6",
            "title": "Content Performance Ranking",
            "prompt": "Practice ranking functions by creating content performance ranks. Write a query to rank posts by view_count (highest first) and show rank, title, and view_count.",
            "table_name": "blog_posts",
            "expected_keywords": ["SELECT", "RANK", "OVER", "ORDER BY", "view_count", "DESC"],
            "hint": "Use RANK() OVER (ORDER BY view_count DESC) for ranking",
            "solution": "SELECT RANK() OVER (ORDER BY view_count DESC) as view_rank, title, view_count, author_name FROM blog_posts WHERE is_published = true ORDER BY view_rank;",
            "explanation": "This demonstrates Django's Window functions: Window(expression=Rank(), order_by=F('view_count').desc()). Window functions enable advanced analytics like rankings, percentiles, and moving averages."
        }
    ],
    "key_concepts": [
        "Text Functions (Concat, Length, Upper, Lower, Substr)",
        "Date Functions (Extract, Trunc, Now, temporal analysis)",
        "Math Functions (Round, Abs, Power, trigonometric)",
        "Window Functions (Rank, RowNumber, Lag, Lead)",
        "Comparison Functions (Cast, Coalesce, Greatest)",
        "Advanced String Manipulation",
        "Temporal Pattern Analysis",
        "Performance Ranking and Analytics"
    ]
}