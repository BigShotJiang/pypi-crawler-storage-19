"""
Django Models Foundations lesson content
"""

DJANGO_MODELS_FOUNDATIONS_LESSON = {
    "id": 16,
    "chapter": 16,
    "title": "Django Models Foundations",
    "slug": "models-foundations",
    "content": '''
# Django Models Foundations: Your Database Blueprint

Think of Django models as architectural blueprints for a skyscraper. Just as architects create detailed plans that specify every room, door, and electrical outlet, Django models define the exact structure of your database tables, complete with data types, relationships, and constraints.

## Understanding Models: The Digital Twin Concept

Every successful app has a **digital twin** of real-world entities. Instagram has models for Users, Photos, and Comments. Spotify models Artists, Albums, and Playlists. Your Django models are the Python representation of these real-world concepts.

**Real-world analogy:** A model is like a factory mold - it defines the exact shape and properties that every database record will have, just like how a cookie cutter ensures every cookie has the same shape.

## Model Definition: Your Database Contract

### Basic Model Structure
```python
from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    publication_date = models.DateField()
    isbn = models.CharField(max_length=13, unique=True)
    pages = models.PositiveIntegerField()
    is_available = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.title} by {self.author}"
```

**What Django creates behind the scenes:**
- Database table named `app_book`
- Auto-generated primary key `id`
- Proper SQL column types for each field
- Database indexes for performance

### Real-World Example: Social Media Post Model
```python
class Post(models.Model):
    # Content fields
    caption = models.TextField(max_length=2200)  # Instagram's caption limit
    image = models.ImageField(upload_to='posts/%Y/%m/%d/')
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Engagement tracking
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    
    # Visibility settings
    is_public = models.BooleanField(default=True)
    is_archived = models.BooleanField(default=False)
    
    # Location (optional)
    location = models.CharField(max_length=200, blank=True)
    
    class Meta:
        ordering = ['-created_at']  # Newest first
        verbose_name = "Social Media Post"
        verbose_name_plural = "Social Media Posts"
        
    def __str__(self):
        return f"Post: {self.caption[:50]}..."
    
    @property
    def engagement_rate(self):
        """Calculate engagement rate as percentage"""
        total_engagement = self.likes_count + self.comments_count
        # In a real app, you'd factor in follower count
        return (total_engagement / max(1, 100)) * 100  # Simplified calculation
```

## Field Types: The Building Blocks

Django provides field types that map to real-world data patterns:

### Text Fields: From Tweets to Novels
```python
class Content(models.Model):
    # Short text - like Twitter username
    username = models.CharField(max_length=30)
    
    # Medium text - like YouTube video title
    title = models.CharField(max_length=100)
    
    # Long text - like blog post content
    body = models.TextField()
    
    # Structured text - like Wikipedia article
    content = models.TextField(
        help_text="Use markdown formatting"
    )
```

### Numeric Fields: From Prices to Ratings
```python
class Product(models.Model):
    # Whole numbers - like quantity in stock
    stock_quantity = models.PositiveIntegerField()
    
    # Decimal precision - like Amazon product price
    price = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Floating point - like average rating
    average_rating = models.FloatField(default=0.0)
    
    # Big numbers - like YouTube view count
    view_count = models.BigIntegerField(default=0)
```

### Date and Time Fields: Tracking Digital Life
```python
class UserActivity(models.Model):
    # Date only - like birth date
    birth_date = models.DateField()
    
    # Full timestamp - like tweet posted time
    posted_at = models.DateTimeField(auto_now_add=True)
    
    # Time only - like business hours
    opens_at = models.TimeField()
    
    # Duration - like video length (using DurationField)
    video_duration = models.DurationField()
```

### Boolean Fields: Digital Yes/No Decisions
```python
class UserPreferences(models.Model):
    # Simple true/false
    email_notifications = models.BooleanField(default=True)
    
    # Nullable boolean (True/False/None)
    is_premium = models.BooleanField(null=True, blank=True)
    
    # Privacy settings
    profile_public = models.BooleanField(default=False)
    show_online_status = models.BooleanField(default=True)
```

## Field Options: Fine-Tuning Your Data

### Essential Field Options
```python
class User(models.Model):
    # Required field
    email = models.EmailField(unique=True)
    
    # Optional field
    bio = models.TextField(blank=True, null=True)
    
    # Field with choices - like Netflix content ratings
    RATING_CHOICES = [
        ('G', 'General Audiences'),
        ('PG', 'Parental Guidance'),
        ('PG13', 'Parents Strongly Cautioned'),
        ('R', 'Restricted'),
        ('NC17', 'Adults Only'),
    ]
    content_rating = models.CharField(
        max_length=4,
        choices=RATING_CHOICES,
        default='G'
    )
    
    # Field with default value
    join_date = models.DateTimeField(auto_now_add=True)
    
    # Field with validation
    age = models.PositiveIntegerField(
        help_text="Must be 13 or older",
        # Custom validation would be added in clean() method
    )
```

### Advanced Field Configuration
```python
class VideoContent(models.Model):
    # File upload with custom path
    thumbnail = models.ImageField(
        upload_to='thumbnails/%Y/%m/%d/',
        blank=True,
        help_text="Recommended size: 1280x720"
    )
    
    # URL field for external content
    external_url = models.URLField(
        blank=True,
        help_text="Link to external video"
    )
    
    # UUID for public sharing (like YouTube video IDs)
    public_id = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
        unique=True
    )
    
    # JSON field for flexible metadata
    metadata = models.JSONField(
        default=dict,
        blank=True,
        help_text="Video metadata like resolution, codecs, etc."
    )
```

## Model Methods: Bringing Your Data to Life

### Essential Model Methods
```python
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.CharField(max_length=100)
    publication_date = models.DateTimeField()
    view_count = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        """String representation - shows in admin and debugging"""
        return self.title
    
    def get_absolute_url(self):
        """Canonical URL for this object"""
        from django.urls import reverse
        return reverse('blog:post-detail', kwargs={'pk': self.pk})
    
    @property
    def is_recent(self):
        """Check if post was published in the last 7 days"""
        from django.utils import timezone
        from datetime import timedelta
        return self.publication_date >= timezone.now() - timedelta(days=7)
    
    @property
    def reading_time(self):
        """Estimate reading time (average 200 words per minute)"""
        word_count = len(self.content.split())
        minutes = max(1, word_count // 200)
        return f"{minutes} min read"
    
    def increment_views(self):
        """Thread-safe view counter increment"""
        from django.db.models import F
        BlogPost.objects.filter(pk=self.pk).update(view_count=F('view_count') + 1)
        self.refresh_from_db()
```

### Advanced Model Methods
```python
class EcommerceProduct(models.Model):
    name = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.PositiveIntegerField()
    
    def save(self, *args, **kwargs):
        """Override save for custom logic"""
        # Auto-generate slug from name
        if not self.slug:
            from django.utils.text import slugify
            self.slug = slugify(self.name)
        
        # Validate profit margin
        if self.price <= self.cost:
            raise ValueError("Price must be higher than cost")
        
        super().save(*args, **kwargs)
    
    def clean(self):
        """Model validation"""
        from django.core.exceptions import ValidationError
        
        if self.stock_quantity < 0:
            raise ValidationError("Stock quantity cannot be negative")
        
        if self.price <= 0:
            raise ValidationError("Price must be positive")
    
    @classmethod
    def low_stock_products(cls, threshold=10):
        """Class method to find products with low stock"""
        return cls.objects.filter(stock_quantity__lte=threshold)
    
    @property
    def profit_margin(self):
        """Calculate profit margin percentage"""
        return ((self.price - self.cost) / self.cost) * 100
    
    @property
    def is_in_stock(self):
        """Check if product is available"""
        return self.stock_quantity > 0
```

## Model Meta Options: Configuration Central

### Common Meta Configurations
```python
class Article(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    publication_date = models.DateTimeField()
    category = models.CharField(max_length=50)
    
    class Meta:
        # Database table name
        db_table = 'blog_articles'
        
        # Default ordering (like Medium's latest articles)
        ordering = ['-publication_date', 'title']
        
        # Human-readable names
        verbose_name = 'Blog Article'
        verbose_name_plural = 'Blog Articles'
        
        # Composite uniqueness (no duplicate titles by same author)
        unique_together = ['title', 'author']
        
        # Database indexes for performance
        indexes = [
            models.Index(fields=['category', '-publication_date']),
            models.Index(fields=['author']),
        ]
        
        # Custom permissions
        permissions = [
            ('can_feature_article', 'Can feature articles on homepage'),
            ('can_schedule_publication', 'Can schedule future publication'),
        ]
```

### Advanced Meta Options
```python
class Transaction(models.Model):
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    user_age = models.PositiveIntegerField()
    transaction_date = models.DateTimeField()
    status = models.CharField(max_length=20)
    
    class Meta:
        # Database constraints (like banking rules)
        constraints = [
            # Ensure positive amounts
            models.CheckConstraint(
                condition=models.Q(amount__gt=0),
                name='positive_amount'
            ),
            # Age restrictions
            models.CheckConstraint(
                condition=models.Q(user_age__gte=18),
                name='adult_users_only'
            ),
            # Unique transaction per user per day (simplified)
            models.UniqueConstraint(
                fields=['user', 'transaction_date'],
                name='one_transaction_per_day'
            ),
        ]
        
        # Partial index for active transactions only
        indexes = [
            models.Index(
                fields=['status', '-transaction_date'],
                condition=models.Q(status='active'),
                name='active_transactions_idx'
            ),
        ]
```

## Real-World Model Example: Building Instagram's Core Models

```python
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
import uuid

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(max_length=150, blank=True)
    website = models.URLField(blank=True)
    profile_picture = models.ImageField(
        upload_to='profile_pics/',
        blank=True
    )
    is_private = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return f"@{self.user.username}"

class Post(models.Model):
    # Unique identifier for URLs (like Instagram)
    public_id = models.UUIDField(default=uuid.uuid4, unique=True)
    
    # Content
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    image = models.ImageField(upload_to='posts/%Y/%m/%d/')
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Engagement
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    
    # Visibility
    is_archived = models.BooleanField(default=False)
    allow_comments = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['-likes_count']),
        ]
    
    def __str__(self):
        return f"Post by @{self.author.username} - {self.created_at.strftime('%Y-%m-%d')}"
    
    @property
    def is_recent(self):
        return self.created_at >= timezone.now() - timezone.timedelta(hours=24)
    
    def get_absolute_url(self):
        return f"/p/{self.public_id}/"

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)
    likes_count = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['post', 'created_at']),
        ]
    
    def __str__(self):
        return f"Comment by @{self.author.username}: {self.text[:50]}..."

class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        # Prevent duplicate likes
        unique_together = ['user', 'post']
        indexes = [
            models.Index(fields=['post', '-created_at']),
        ]
    
    def __str__(self):
        return f"@{self.user.username} liked post {self.post.public_id}"
```

## Best Practices: Building Robust Models

### 1. Always Include Timestamps
```python
class BaseModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        abstract = True  # This won't create a database table
```

### 2. Use Descriptive Field Names
```python
# ❌ Poor naming
class User(models.Model):
    n = models.CharField(max_length=100)  # What is 'n'?
    d = models.DateTimeField()  # What is 'd'?

# ✅ Clear naming
class User(models.Model):
    full_name = models.CharField(max_length=100)
    registration_date = models.DateTimeField()
```

### 3. Add Helpful Model Methods
```python
class Order(models.Model):
    status = models.CharField(max_length=20)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    @property
    def can_be_cancelled(self):
        """Business logic: can cancel within 1 hour if not shipped"""
        if self.status in ['shipped', 'delivered', 'cancelled']:
            return False
        
        one_hour_ago = timezone.now() - timedelta(hours=1)
        return self.created_at > one_hour_ago
    
    def calculate_tax(self, tax_rate=0.08):
        """Calculate tax based on total"""
        return self.total * Decimal(str(tax_rate))
```

### 4. Use Constraints for Data Integrity
```python
class Event(models.Model):
    name = models.CharField(max_length=200)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    capacity = models.PositiveIntegerField()
    
    class Meta:
        constraints = [
            # End date must be after start date
            models.CheckConstraint(
                condition=models.Q(end_date__gt=models.F('start_date')),
                name='valid_event_duration'
            ),
            # Capacity must be reasonable
            models.CheckConstraint(
                condition=models.Q(capacity__gte=1) & models.Q(capacity__lte=100000),
                name='reasonable_capacity'
            ),
        ]
```

Models are the foundation of your Django application - they represent your business logic in code and ensure your data stays organized, validated, and accessible. Master them, and you'll build applications that can scale from startup to unicorn! 🚀

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/db/models/
    ''',
    "is_free": False,
    "xp_reward": 95,
    "exercises": [
        {
            "id": "instagram-core-models",
            "title": "Build Instagram's Core Models",
            "type": "project",
            "instructions": """Create the core models for a social media platform like Instagram:

1. User profile model with bio, profile picture, and follower counts
2. Post model with image, caption, location, and engagement tracking
3. Comment model with text and like counts
4. Like model to track user likes on posts
5. Follow model to track user relationships

Your solution should demonstrate:
- Proper field types and options
- Model relationships (ForeignKey, OneToOne)
- Model methods and properties
- Meta options for ordering and constraints
- Database optimization with indexes""",
            "starter_code": """from django.contrib.auth.models import User
from django.db import models
import uuid

# Create your models here:
# 1. UserProfile - extends User with social media fields
# 2. Post - main content model with image and engagement
# 3. Comment - comments on posts
# 4. Like - track likes on posts
# 5. Follow - track user relationships

# Remember to include:
# - Proper __str__ methods
# - get_absolute_url methods
# - Properties for calculated fields
# - Meta options for ordering and constraints""",
            "solution": """from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
from django.utils import timezone
from datetime import timedelta
import uuid

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(max_length=150, blank=True)
    website = models.URLField(blank=True)
    profile_picture = models.ImageField(
        upload_to='profile_pics/%Y/%m/',
        blank=True,
        help_text="Profile picture (recommended: 400x400px)"
    )
    is_private = models.BooleanField(default=False)
    is_verified = models.BooleanField(default=False)
    
    # Denormalized counts for performance
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    posts_count = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "User Profile"
        verbose_name_plural = "User Profiles"
        indexes = [
            models.Index(fields=['is_verified']),
            models.Index(fields=['-follower_count']),
        ]
    
    def __str__(self):
        return f"@{self.user.username}"
    
    def get_absolute_url(self):
        return reverse('profile:detail', kwargs={'username': self.user.username})
    
    @property
    def is_influencer(self):
        \"\"\"Check if user has significant following\"\"\"
        return self.follower_count >= 10000

class Post(models.Model):
    # Unique public identifier (like Instagram post URLs)
    public_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    
    # Core content
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    image = models.ImageField(
        upload_to='posts/%Y/%m/%d/',
        help_text="Post image (recommended: 1080x1080px)"
    )
    caption = models.TextField(max_length=2200, blank=True)
    location = models.CharField(max_length=100, blank=True)
    
    # Hashtags and mentions (simplified as text field)
    hashtags = models.TextField(blank=True, help_text="Comma-separated hashtags")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Engagement metrics (denormalized for performance)
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    
    # Post settings
    is_archived = models.BooleanField(default=False)
    allow_comments = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['author', '-created_at']),
            models.Index(fields=['-likes_count']),
            models.Index(fields=['-created_at']),
            models.Index(fields=['public_id']),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(likes_count__gte=0),
                name='positive_likes_count'
            ),
            models.CheckConstraint(
                condition=models.Q(comments_count__gte=0),
                name='positive_comments_count'
            ),
        ]
    
    def __str__(self):
        return f"Post by @{self.author.username} - {self.created_at.strftime('%Y-%m-%d')}"
    
    def get_absolute_url(self):
        return reverse('posts:detail', kwargs={'public_id': str(self.public_id)})
    
    @property
    def is_recent(self):
        \"\"\"Check if post was created in the last 24 hours\"\"\"
        return self.created_at >= timezone.now() - timedelta(hours=24)
    
    @property
    def engagement_rate(self):
        \"\"\"Calculate basic engagement rate\"\"\"
        total_engagement = self.likes_count + self.comments_count
        # In real app, would factor in author's follower count
        return total_engagement
    
    def get_hashtag_list(self):
        \"\"\"Get list of hashtags from the hashtags field\"\"\"
        if not self.hashtags:
            return []
        return [tag.strip().lstrip('#') for tag in self.hashtags.split(',') if tag.strip()]

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField(max_length=500)
    
    # Reply functionality (simplified)
    parent = models.ForeignKey(
        'self', 
        null=True, 
        blank=True, 
        on_delete=models.CASCADE,
        related_name='replies'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    likes_count = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['post', 'created_at']),
            models.Index(fields=['author', '-created_at']),
        ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(likes_count__gte=0),
                name='positive_comment_likes'
            ),
        ]
    
    def __str__(self):
        return f"Comment by @{self.author.username}: {self.text[:50]}..."
    
    @property
    def is_reply(self):
        \"\"\"Check if this is a reply to another comment\"\"\"
        return self.parent is not None
    
    def get_replies(self):
        \"\"\"Get all replies to this comment\"\"\"
        return self.replies.all().order_by('created_at')

class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        # Prevent duplicate likes
        unique_together = ['user', 'post']
        indexes = [
            models.Index(fields=['post', '-created_at']),
            models.Index(fields=['user', '-created_at']),
        ]
    
    def __str__(self):
        return f"@{self.user.username} liked {self.post}"

class Follow(models.Model):
    follower = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='following'
    )
    following = models.ForeignKey(
        User, 
        on_delete=models.CASCADE, 
        related_name='followers'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        # Prevent duplicate follows and self-follows
        unique_together = ['follower', 'following']
        constraints = [
            models.CheckConstraint(
                condition=~models.Q(follower=models.F('following')),
                name='no_self_follow'
            ),
        ]
        indexes = [
            models.Index(fields=['follower', '-created_at']),
            models.Index(fields=['following', '-created_at']),
        ]
    
    def __str__(self):
        return f"@{self.follower.username} follows @{self.following.username}"

# Signal handlers to update denormalized counts
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

@receiver([post_save, post_delete], sender=Like)
def update_post_likes_count(sender, instance, **kwargs):
    \"\"\"Update post likes count when like is added/removed\"\"\"
    post = instance.post
    post.likes_count = post.likes.count()
    post.save(update_fields=['likes_count'])

@receiver([post_save, post_delete], sender=Comment)
def update_post_comments_count(sender, instance, **kwargs):
    \"\"\"Update post comments count when comment is added/removed\"\"\"
    post = instance.post
    post.comments_count = post.comments.count()
    post.save(update_fields=['comments_count'])

@receiver([post_save, post_delete], sender=Follow)
def update_follow_counts(sender, instance, **kwargs):
    \"\"\"Update follower/following counts when follow relationship changes\"\"\"
    # Update follower's following count
    follower_profile = instance.follower.profile
    follower_profile.following_count = instance.follower.following.count()
    follower_profile.save(update_fields=['following_count'])
    
    # Update following's follower count  
    following_profile = instance.following.profile
    following_profile.follower_count = instance.following.followers.count()
    following_profile.save(update_fields=['follower_count'])

@receiver([post_save, post_delete], sender=Post)
def update_user_posts_count(sender, instance, **kwargs):
    \"\"\"Update user's posts count when post is added/removed\"\"\"
    profile = instance.author.profile
    profile.posts_count = instance.author.posts.filter(is_archived=False).count()
    profile.save(update_fields=['posts_count'])""",
            "test_cases": [
                {
                    "name": "Models have proper relationships and methods",
                    "input": "",
                    "expected_contains": ["ForeignKey", "OneToOneField", "__str__", "get_absolute_url"]
                }
            ],
            "xp_reward": 140,
            "hints": [
                "Use UUIDs for public post identifiers (Instagram-style URLs)",
                "Add denormalized count fields for performance",
                "Include proper constraints to prevent invalid data",
                "Use signals to keep denormalized counts updated",
                "Add indexes for common query patterns"
            ]
        }
    ]
}