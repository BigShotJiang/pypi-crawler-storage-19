"""
Django Database - Lesson 4: Aggregation and Data Analysis
Master Django's aggregation functions for powerful data analytics
"""

DJANGO_AGGREGATION_LESSON = {
    "id": 47,
    "chapter": 47,
    "title": "Django Aggregation: Powerful Data Analytics",
    "slug": "django-aggregation",
    "description": "Master Django's aggregation functions for complex data analysis and business intelligence",
    "content": '''# Django Aggregation: Powerful Data Analytics

## 🎯 Understanding Django Aggregation

Django's **aggregation framework** transforms your application into a powerful analytics engine. Instead of pulling data into Python for calculations, aggregations happen **in the database** for maximum performance.

**Key Benefits**:
- **Database-level calculations** → Much faster than Python loops
- **Memory efficient** → No need to load all records into memory  
- **SQL optimization** → Database engine optimizes complex queries
- **Real-time analytics** → Perfect for dashboards and reporting

Think of aggregations as your **business intelligence toolkit** within Django.

## 📊 Comprehensive Analytics Database

Let's work with a complete business analytics database:

```sql
-- Sales data table (like Shopify's order analytics)
CREATE TABLE sales_data (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(20) UNIQUE NOT NULL,
    customer_id INTEGER NOT NULL,
    customer_email VARCHAR(254) NOT NULL,
    sales_rep_id INTEGER,
    product_category VARCHAR(100) NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    shipping_cost DECIMAL(10, 2) DEFAULT 0.00,
    tax_amount DECIMAL(10, 2) NOT NULL,
    total_revenue DECIMAL(10, 2) NOT NULL,
    cost_of_goods DECIMAL(10, 2) NOT NULL,
    order_date TIMESTAMP NOT NULL,
    region VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    acquisition_channel VARCHAR(50),
    customer_segment VARCHAR(50),
    is_return BOOLEAN DEFAULT FALSE
);

-- Comprehensive sample data for analytics
INSERT INTO sales_data (order_id, customer_id, customer_email, sales_rep_id, product_category, product_name, quantity, unit_price, discount_amount, tax_amount, total_revenue, cost_of_goods, order_date, region, country, acquisition_channel, customer_segment) VALUES
('ORD-001', 1001, 'sarah.chen@email.com', 101, 'Electronics', 'iPhone 15 Pro', 1, 999.99, 50.00, 95.00, 1044.99, 650.00, '2024-11-15 10:30:00', 'North America', 'USA', 'organic_search', 'premium'),
('ORD-002', 1002, 'mike.rodriguez@email.com', 102, 'Electronics', 'Samsung Galaxy S24', 2, 899.99, 100.00, 144.00, 1843.98, 1100.00, '2024-11-20 14:22:00', 'Europe', 'Spain', 'paid_ads', 'regular'),
('ORD-003', 1003, 'emma.johnson@email.com', 101, 'Computers', 'MacBook Air M2', 1, 1299.99, 0.00, 130.00, 1429.99, 850.00, '2024-12-01 09:15:00', 'Asia Pacific', 'Australia', 'social_media', 'premium'),
('ORD-004', 1004, 'david.kim@email.com', 103, 'Audio', 'AirPods Pro 2nd Gen', 3, 249.99, 25.00, 67.48, 817.45, 450.00, '2024-12-10 16:45:00', 'North America', 'Canada', 'email_marketing', 'regular'),
('ORD-005', 1005, 'anna.petrov@email.com', 102, 'Accessories', 'iPhone Case Premium', 5, 49.99, 10.00, 22.46, 262.41, 125.00, '2024-12-15 11:30:00', 'Europe', 'Germany', 'affiliate', 'budget'),
('ORD-006', 1006, 'raj.patel@email.com', 101, 'Electronics', 'iPad Air 5th Gen', 1, 599.99, 0.00, 60.00, 659.99, 380.00, '2024-12-20 13:20:00', 'Asia Pacific', 'India', 'organic_search', 'premium'),
('ORD-007', 1007, 'carlos.santos@email.com', 103, 'Computers', 'Dell XPS 13', 1, 1199.99, 120.00, 108.00, 1187.99, 750.00, '2024-12-22 08:45:00', 'South America', 'Brazil', 'social_media', 'regular'),
('ORD-008', 1002, 'mike.rodriguez@email.com', 102, 'Audio', 'Sony WH-1000XM5', 1, 399.99, 0.00, 40.00, 439.99, 250.00, '2024-12-23 15:10:00', 'Europe', 'Spain', 'email_marketing', 'premium'),
('ORD-009', 1008, 'lisa.wang@email.com', 101, 'Electronics', 'Apple Watch Series 9', 2, 429.99, 43.00, 81.60, 898.58, 520.00, '2024-12-24 12:30:00', 'Asia Pacific', 'Singapore', 'paid_ads', 'premium'),
('ORD-010', 1009, 'james.brown@email.com', 103, 'Accessories', 'Wireless Charger', 10, 39.99, 50.00, 35.99, 434.89, 200.00, '2024-12-25 14:20:00', 'North America', 'USA', 'organic_search', 'budget');

-- Customer table for advanced analytics
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(254) UNIQUE NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50), 
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lifetime_value DECIMAL(10, 2) DEFAULT 0.00,
    total_orders INTEGER DEFAULT 0,
    preferred_category VARCHAR(100),
    is_vip BOOLEAN DEFAULT FALSE
);

-- Sample customer data
INSERT INTO customers (id, email, first_name, last_name, registration_date, total_orders, preferred_category) VALUES
(1001, 'sarah.chen@email.com', 'Sarah', 'Chen', '2024-01-15', 5, 'Electronics'),
(1002, 'mike.rodriguez@email.com', 'Mike', 'Rodriguez', '2024-03-20', 8, 'Electronics'),
(1003, 'emma.johnson@email.com', 'Emma', 'Johnson', '2024-02-10', 3, 'Computers'),
(1004, 'david.kim@email.com', 'David', 'Kim', '2024-05-05', 12, 'Audio'),
(1005, 'anna.petrov@email.com', 'Anna', 'Petrov', '2024-06-12', 4, 'Accessories'),
(1006, 'raj.patel@email.com', 'Raj', 'Patel', '2024-04-18', 6, 'Electronics'),
(1007, 'carlos.santos@email.com', 'Carlos', 'Santos', '2024-07-22', 2, 'Computers'),
(1008, 'lisa.wang@email.com', 'Lisa', 'Wang', '2024-08-30', 7, 'Electronics'),
(1009, 'james.brown@email.com', 'James', 'Brown', '2024-09-15', 3, 'Accessories');
```

## 🔧 Basic Aggregation Functions

### 1. Simple Aggregations - The Foundation

**Scenario**: Amazon's daily sales dashboard

```python
from django.db.models import Sum, Count, Avg, Min, Max
from django.db.models import F, Q

class SalesDashboard:
    @staticmethod
    def get_daily_metrics():
        """Basic daily sales metrics like Amazon's seller dashboard"""
        
        today_sales = SalesData.objects.filter(
            order_date__date=timezone.now().date()
        ).aggregate(
            total_revenue=Sum('total_revenue'),
            total_orders=Count('order_id', distinct=True),
            avg_order_value=Avg('total_revenue'),
            highest_sale=Max('total_revenue'),
            lowest_sale=Min('total_revenue')
        )
        
        return today_sales

# Example output:
# {
#   'total_revenue': Decimal('12547.89'),
#   'total_orders': 156,
#   'avg_order_value': Decimal('80.43'),
#   'highest_sale': Decimal('2499.99'),
#   'lowest_sale': Decimal('19.99')
# }
```

### 2. Conditional Aggregations - Smart Filtering

**Scenario**: Shopify's performance analytics by customer segment

```python
from django.db.models import Case, When, DecimalField

def analyze_customer_segments():
    """Analyze revenue by customer segment with conditional logic"""
    
    segment_analysis = SalesData.objects.aggregate(
        premium_revenue=Sum(
            Case(
                When(customer_segment='premium', then='total_revenue'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        ),
        regular_revenue=Sum(
            Case(
                When(customer_segment='regular', then='total_revenue'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        ),
        budget_revenue=Sum(
            Case(
                When(customer_segment='budget', then='total_revenue'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        ),
        premium_orders=Count(
            Case(
                When(customer_segment='premium', then='order_id'),
                output_field=IntegerField()
            )
        ),
        high_value_orders=Count(
            Case(
                When(total_revenue__gte=1000, then='order_id'),
                output_field=IntegerField()
            )
        )
    )
    
    return segment_analysis
```

## 📈 Advanced Aggregation Patterns

### 3. Group By Aggregations - Category Analysis

**Scenario**: Netflix's content performance analysis

```python
def analyze_category_performance():
    """Analyze sales performance by product category"""
    
    category_stats = SalesData.objects.values('product_category').annotate(
        total_revenue=Sum('total_revenue'),
        total_units_sold=Sum('quantity'),
        average_order_value=Avg('total_revenue'),
        order_count=Count('order_id', distinct=True),
        profit_margin=Avg(
            (F('total_revenue') - F('cost_of_goods')) / F('total_revenue') * 100
        ),
        top_product=Max('total_revenue')  # Highest single sale in category
    ).order_by('-total_revenue')
    
    return list(category_stats)

# Example output:
# [
#   {
#     'product_category': 'Electronics',
#     'total_revenue': Decimal('4547.55'),
#     'total_units_sold': 7,
#     'average_order_value': Decimal('649.65'),
#     'order_count': 7,
#     'profit_margin': 35.2,
#     'top_product': Decimal('1044.99')
#   },
#   ...
# ]
```

### 4. Time-Based Aggregations - Trends Analysis

**Scenario**: Uber's demand forecasting

```python
from django.db.models import Extract, TruncMonth, TruncWeek

def analyze_sales_trends():
    """Analyze sales trends over time periods"""
    
    # Monthly trends
    monthly_trends = SalesData.objects.annotate(
        month=TruncMonth('order_date')
    ).values('month').annotate(
        monthly_revenue=Sum('total_revenue'),
        monthly_orders=Count('order_id', distinct=True),
        avg_monthly_order=Avg('total_revenue'),
        new_customers=Count('customer_id', distinct=True)
    ).order_by('month')
    
    # Weekly patterns (which day of week performs best?)
    weekly_patterns = SalesData.objects.annotate(
        day_of_week=Extract('order_date', 'week_day')
    ).values('day_of_week').annotate(
        daily_revenue=Sum('total_revenue'),
        daily_orders=Count('order_id'),
        avg_order_size=Avg('quantity')
    ).order_by('day_of_week')
    
    # Hourly patterns
    hourly_patterns = SalesData.objects.annotate(
        hour=Extract('order_date', 'hour')
    ).values('hour').annotate(
        hourly_revenue=Sum('total_revenue'),
        hourly_orders=Count('order_id')
    ).order_by('hour')
    
    return {
        'monthly_trends': list(monthly_trends),
        'weekly_patterns': list(weekly_patterns),
        'hourly_patterns': list(hourly_patterns)
    }
```

### 5. Complex Multi-Dimensional Analysis

**Scenario**: Airbnb's market analysis by region and time

```python
def multi_dimensional_analysis():
    """Complex analysis across multiple dimensions"""
    
    region_channel_analysis = SalesData.objects.values(
        'region', 'acquisition_channel'
    ).annotate(
        revenue=Sum('total_revenue'),
        orders=Count('order_id', distinct=True),
        customers=Count('customer_id', distinct=True),
        avg_order_value=Avg('total_revenue'),
        profit=Sum(F('total_revenue') - F('cost_of_goods')),
        profit_margin=Avg(
            (F('total_revenue') - F('cost_of_goods')) / F('total_revenue') * 100
        ),
        # Customer acquisition cost efficiency
        revenue_per_customer=Sum('total_revenue') / Count('customer_id', distinct=True)
    ).filter(
        orders__gte=1  # Only include combinations with actual orders
    ).order_by('-revenue')
    
    return list(region_channel_analysis)
```

## 🏢 Real-World Production Examples

### Stripe's Revenue Analytics

```python
def stripe_style_revenue_analytics():
    """Comprehensive revenue analytics like Stripe's dashboard"""
    
    # Current month performance
    current_month = timezone.now().replace(day=1, hour=0, minute=0, second=0)
    
    analytics = SalesData.objects.filter(
        order_date__gte=current_month
    ).aggregate(
        # Core metrics
        gross_revenue=Sum('total_revenue'),
        net_revenue=Sum(F('total_revenue') - F('tax_amount') - F('discount_amount')),
        total_transactions=Count('order_id', distinct=True),
        
        # Customer metrics
        unique_customers=Count('customer_id', distinct=True),
        returning_customers=Count(
            Case(
                When(customer_id__in=SalesData.objects.filter(
                    order_date__lt=current_month
                ).values('customer_id'), then='customer_id'),
                output_field=IntegerField()
            ), distinct=True
        ),
        
        # Financial metrics
        average_transaction_value=Avg('total_revenue'),
        total_refunds=Sum(
            Case(
                When(is_return=True, then='total_revenue'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        ),
        
        # Performance ratios
        refund_rate=Count(
            Case(When(is_return=True, then=1))
        ) * 100.0 / Count('order_id'),
        
        # Growth metrics (vs last month)
        new_customer_revenue=Sum(
            Case(
                When(~Q(customer_id__in=SalesData.objects.filter(
                    order_date__lt=current_month
                ).values('customer_id')), then='total_revenue'),
                default=0,
                output_field=DecimalField(max_digits=10, decimal_places=2)
            )
        )
    )
    
    return analytics
```

### Amazon's Seller Analytics

```python
def amazon_seller_analytics(seller_id):
    """Amazon-style seller performance dashboard"""
    
    last_30_days = timezone.now() - timedelta(days=30)
    
    seller_performance = SalesData.objects.filter(
        sales_rep_id=seller_id,
        order_date__gte=last_30_days
    ).aggregate(
        # Sales performance
        total_sales=Sum('total_revenue'),
        units_sold=Sum('quantity'),
        orders_processed=Count('order_id', distinct=True),
        
        # Customer satisfaction proxy
        avg_order_size=Avg('quantity'),
        repeat_customer_rate=Count(
            'customer_id', 
            filter=Q(customer_id__in=SalesData.objects.filter(
                sales_rep_id=seller_id,
                order_date__lt=last_30_days
            ).values('customer_id'))
        ) / Count('customer_id', distinct=True) * 100,
        
        # Profitability
        gross_profit=Sum(F('total_revenue') - F('cost_of_goods')),
        profit_margin=Avg(
            (F('total_revenue') - F('cost_of_goods')) / F('total_revenue') * 100
        ),
        
        # Category diversification
        categories_sold=Count('product_category', distinct=True),
        top_category_revenue=Max('total_revenue'),
        
        # Channel effectiveness
        best_channel_orders=Count(
            Case(When(acquisition_channel='organic_search', then=1))
        ),
        paid_channel_roi=Sum(
            Case(
                When(acquisition_channel__in=['paid_ads', 'social_media'], 
                     then=F('total_revenue') - F('cost_of_goods')),
                default=0,
                output_field=DecimalField()
            )
        )
    )
    
    return seller_performance
```

### Discord's Community Analytics

```python
def discord_community_analytics():
    """Discord-style community engagement analytics"""
    
    # Simulate message/engagement data analysis
    community_stats = SalesData.objects.annotate(
        engagement_score=F('quantity') * 2 + F('total_revenue') / 100
    ).aggregate(
        # Core engagement
        total_interactions=Sum('quantity'),
        unique_participants=Count('customer_id', distinct=True),
        avg_engagement=Avg('engagement_score'),
        
        # Time-based patterns
        peak_hour_activity=Count(
            Case(When(order_date__hour__in=[18, 19, 20, 21], then=1))
        ),
        weekend_activity=Count(
            Case(When(order_date__week_day__in=[1, 7], then=1))
        ),
        
        # Community health
        active_contributors=Count(
            Case(When(engagement_score__gte=50, then='customer_id')),
            distinct=True
        ),
        engagement_distribution=Avg('engagement_score'),
        
        # Growth indicators
        new_member_activity=Count(
            Case(
                When(customer_id__in=Customer.objects.filter(
                    registration_date__gte=timezone.now() - timedelta(days=7)
                ).values('id'), then=1)
            )
        )
    )
    
    return community_stats
```

## ⚡ Performance Optimization Techniques

### 1. Using select_related with Aggregations

```python
def optimized_customer_analytics():
    """Optimized customer analytics with proper JOINs"""
    
    customer_stats = Customer.objects.select_related().annotate(
        total_spent=Sum('salesdata__total_revenue'),
        order_count=Count('salesdata__order_id', distinct=True),
        avg_order_value=Avg('salesdata__total_revenue'),
        last_order_date=Max('salesdata__order_date'),
        favorite_category=Window(
            expression=Count('salesdata__product_category'),
            partition_by=['id'],
            order_by=F('salesdata__product_category').desc()
        )
    ).order_by('-total_spent')
    
    return customer_stats
```

### 2. Database Functions for Complex Calculations

```python
from django.db.models import Window, Rank
from django.db.models.functions import Dense_Rank, Lag

def advanced_ranking_analytics():
    """Advanced ranking and window function analytics"""
    
    ranked_sales = SalesData.objects.annotate(
        # Rank products by revenue within each category
        category_rank=Window(
            expression=Rank(),
            partition_by=['product_category'],
            order_by=F('total_revenue').desc()
        ),
        
        # Dense rank for handling ties
        dense_category_rank=Window(
            expression=Dense_Rank(),
            partition_by=['product_category'], 
            order_by=F('total_revenue').desc()
        ),
        
        # Running total within category
        running_total=Window(
            expression=Sum('total_revenue'),
            partition_by=['product_category'],
            order_by=F('order_date').asc(),
            frame=Window.frame(start=Window.UNBOUNDED_PRECEDING)
        ),
        
        # Previous order value for growth analysis
        previous_order_value=Window(
            expression=Lag('total_revenue'),
            partition_by=['customer_id'],
            order_by=F('order_date').asc()
        )
    ).order_by('product_category', '-total_revenue')
    
    return ranked_sales
```

## 🎯 Key Takeaways

1. **Aggregations happen in the database** → Much faster than Python calculations
2. **Use annotations for per-record calculations** and aggregate for summary statistics
3. **Conditional aggregations** enable sophisticated business intelligence
4. **Time-based grouping** reveals trends and patterns  
5. **Multi-dimensional analysis** provides comprehensive business insights
6. **Window functions** enable advanced ranking and comparative analytics

Django's aggregation framework transforms your application into a powerful analytics platform that rivals dedicated BI tools!
''',
    "difficulty": "intermediate",
    "estimated_time": 50,
    "xp_reward": 30,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-raw-sql"],
    "exercises": [
        {
            "id": "aggregation_1",
            "title": "Explore Sales Data Structure",
            "prompt": "Let's start by examining our comprehensive sales data table. Write a query to see the structure and sample data.",
            "table_name": "sales_data",
            "initial_query": "SELECT * FROM sales_data LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "sales_data"],
            "hint": "Use SELECT * FROM sales_data LIMIT 5; to see the sales data structure",
            "solution": "SELECT * FROM sales_data LIMIT 5;",
            "explanation": "This shows our comprehensive sales analytics table with fields like total_revenue, product_category, region, customer_segment, etc. Django aggregations will work on this rich dataset to provide business intelligence."
        },
        {
            "id": "aggregation_2",
            "title": "Basic Revenue Aggregation",
            "prompt": "Practice basic aggregation by calculating total revenue, average order value, and order count from all sales data.",
            "table_name": "sales_data",
            "expected_keywords": ["SELECT", "SUM", "AVG", "COUNT", "total_revenue"],
            "hint": "Use SUM() for total revenue, AVG() for average, and COUNT() for order count",
            "solution": "SELECT SUM(total_revenue) as total_revenue, AVG(total_revenue) as avg_order_value, COUNT(*) as total_orders FROM sales_data;",
            "explanation": "This basic aggregation simulates Django's .aggregate(total=Sum('total_revenue'), avg=Avg('total_revenue'), count=Count('id')). These are the foundation metrics for any business dashboard."
        },
        {
            "id": "aggregation_3",
            "title": "Group By Category Analysis",
            "prompt": "Write a query to analyze sales performance by product category. Show category, total revenue, and order count for each category.",
            "table_name": "sales_data",
            "expected_keywords": ["SELECT", "GROUP BY", "product_category", "SUM", "COUNT"],
            "hint": "Group by product_category and calculate aggregations for each group",
            "solution": "SELECT product_category, SUM(total_revenue) as category_revenue, COUNT(*) as category_orders FROM sales_data GROUP BY product_category ORDER BY category_revenue DESC;",
            "explanation": "This simulates Django's .values('product_category').annotate(revenue=Sum('total_revenue'), orders=Count('id')). Grouping enables analysis of performance by different business dimensions."
        },
        {
            "id": "aggregation_4",
            "title": "Regional Performance Analysis",
            "prompt": "Analyze sales performance by region. Calculate total revenue, average order value, and unique customers for each region.",
            "table_name": "sales_data",
            "expected_keywords": ["SELECT", "GROUP BY", "region", "SUM", "AVG", "COUNT DISTINCT"],
            "hint": "Group by region and use COUNT(DISTINCT customer_id) for unique customers",
            "solution": "SELECT region, SUM(total_revenue) as regional_revenue, AVG(total_revenue) as avg_order_value, COUNT(DISTINCT customer_id) as unique_customers FROM sales_data GROUP BY region ORDER BY regional_revenue DESC;",
            "explanation": "This multi-metric regional analysis demonstrates Django's power to calculate multiple aggregations in one query. COUNT(DISTINCT) is essential for customer analytics."
        },
        {
            "id": "aggregation_5",
            "title": "Customer Segment Profitability",
            "prompt": "Analyze profitability by customer segment. Calculate total revenue, total profit (revenue - cost_of_goods), and profit margin for each segment.",
            "table_name": "sales_data",
            "expected_keywords": ["SELECT", "GROUP BY", "customer_segment", "SUM", "-"],
            "hint": "Calculate profit as (total_revenue - cost_of_goods) and profit margin as percentage",
            "solution": "SELECT customer_segment, SUM(total_revenue) as segment_revenue, SUM(total_revenue - cost_of_goods) as segment_profit, ROUND(AVG((total_revenue - cost_of_goods) / total_revenue * 100), 2) as profit_margin_pct FROM sales_data GROUP BY customer_segment ORDER BY segment_profit DESC;",
            "explanation": "This profitability analysis shows how Django aggregations can perform complex business calculations. The profit margin calculation demonstrates using field expressions in aggregations."
        },
        {
            "id": "aggregation_6",
            "title": "Time-Based Sales Trends",
            "prompt": "Analyze sales trends by month. Extract the month from order_date and show monthly revenue and order counts.",
            "table_name": "sales_data", 
            "expected_keywords": ["SELECT", "EXTRACT", "month", "GROUP BY", "order_date"],
            "hint": "Use EXTRACT(month FROM order_date) to get the month, then group by it",
            "solution": "SELECT EXTRACT(month FROM order_date) as sales_month, SUM(total_revenue) as monthly_revenue, COUNT(*) as monthly_orders FROM sales_data GROUP BY EXTRACT(month FROM order_date) ORDER BY sales_month;",
            "explanation": "Time-based aggregations are crucial for trend analysis. This demonstrates Django's TruncMonth() and Extract() functions for temporal analytics, essential for business intelligence dashboards."
        }
    ],
    "key_concepts": [
        "Basic Aggregation Functions (Sum, Count, Avg, Min, Max)",
        "Conditional Aggregations with Case/When",
        "Group By Analysis for Business Dimensions", 
        "Time-Based Trend Analysis",
        "Multi-Dimensional Analytics",
        "Window Functions and Rankings",
        "Performance Optimization with select_related",
        "Real-World Business Intelligence Patterns"
    ]
}