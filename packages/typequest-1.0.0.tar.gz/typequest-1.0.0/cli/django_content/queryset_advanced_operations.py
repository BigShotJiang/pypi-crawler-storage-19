"""
Django QuerySet Advanced Operations lesson content
"""

DJANGO_QUERYSET_ADVANCED_OPERATIONS_LESSON = {
    "id": 18,
    "chapter": 18,
    "title": "Django QuerySet Advanced Operations",
    "slug": "queryset-advanced-operations",
    "content": '''
# Advanced QuerySet Operations: Database Wizardry in Python

Think of advanced QuerySet operations as the difference between a basic calculator and a scientific calculator. While basic queries get the job done, advanced operations let you build sophisticated features like Netflix's recommendation engine, Amazon's product analytics, or Spotify's music discovery algorithms - all with elegant Python code that translates to highly optimized SQL.

## Aggregation: Turning Data into Insights

**Real-world analogy:** Aggregation is like having a personal data analyst who can instantly tell you "the average rating of all Marvel movies" or "total sales by quarter" without manually counting through millions of records.

### Basic Aggregations: The Essential Statistics
```python
from django.db.models import Count, Sum, Avg, Max, Min

# Netflix-style analytics
movie_stats = Movie.objects.aggregate(
    total_movies=Count('id'),
    average_rating=Avg('rating'),
    highest_rated=Max('rating'),
    total_runtime=Sum('duration_minutes'),
    shortest_movie=Min('duration_minutes')
)
# Returns: {'total_movies': 15420, 'average_rating': 6.8, ...}

# E-commerce revenue analysis (like Amazon's dashboard)
sales_summary = Order.objects.filter(
    status='completed',
    created_at__year=2024
).aggregate(
    total_revenue=Sum('total_amount'),
    average_order=Avg('total_amount'),
    largest_order=Max('total_amount'),
    total_orders=Count('id')
)

# Social media engagement (like Instagram insights)
post_analytics = Post.objects.filter(
    author=user,
    created_at__gte=last_month
).aggregate(
    total_likes=Sum('likes_count'),
    total_comments=Sum('comments_count'),
    average_engagement=Avg('likes_count') + Avg('comments_count'),
    most_popular=Max('likes_count')
)
```

### Advanced Aggregation with Conditional Logic
```python
from django.db.models import Case, When, IntegerField, DecimalField

# YouTube-style content analysis
video_performance = Video.objects.aggregate(
    # Conditional counting
    viral_videos=Count(
        Case(When(view_count__gte=1000000, then=1))
    ),
    popular_videos=Count(
        Case(When(view_count__gte=100000, then=1))
    ),
    
    # Weighted averages (views matter more for new videos)
    weighted_rating=Avg(
        Case(
            When(upload_date__gte=last_week, 
                 then='rating' * 'view_count' / 1000),
            default='rating',
            output_field=DecimalField()
        )
    )
)

# E-learning platform success metrics (like Coursera analytics)
course_metrics = Enrollment.objects.aggregate(
    completion_rate=Count(
        Case(When(status='completed', then=1))
    ) * 100.0 / Count('id'),
    
    average_progress=Avg('progress_percentage'),
    
    # Revenue by course type
    premium_revenue=Sum(
        Case(
            When(course__is_premium=True, then='amount_paid'),
            default=0,
            output_field=DecimalField()
        )
    )
)
```

## Annotation: Adding Computed Fields

**Real-world analogy:** Annotation is like having a smart spreadsheet that automatically calculates formulas for every row. Instagram uses this to show "2 hours ago" timestamps or "142 likes" without storing these calculated values.

### Basic Annotations: Enhancing Your Data
```python
# Social media feed with calculated engagement
posts_with_engagement = Post.objects.annotate(
    total_engagement=F('likes_count') + F('comments_count'),
    engagement_per_hour=F('likes_count') / 
        Cast((Now() - F('created_at')).total_seconds() / 3600, IntegerField()),
    is_viral=Case(
        When(likes_count__gte=10000, then=True),
        default=False,
        output_field=BooleanField()
    )
).order_by('-total_engagement')

# E-commerce product listing with calculated fields
products_with_metrics = Product.objects.annotate(
    # Total revenue from this product
    total_revenue=Sum('orderitem__total_price'),
    
    # Number of times ordered
    order_count=Count('orderitem__order', distinct=True),
    
    # Average order quantity
    avg_quantity=Avg('orderitem__quantity'),
    
    # Profit margin calculation
    profit_margin=((F('price') - F('cost')) / F('price')) * 100,
    
    # Stock status
    stock_status=Case(
        When(stock_quantity=0, then=Value('Out of Stock')),
        When(stock_quantity__lte=5, then=Value('Low Stock')),
        When(stock_quantity__lte=20, then=Value('Limited')),
        default=Value('In Stock'),
        output_field=CharField()
    )
)
```

### Complex Annotations with Subqueries
```python
from django.db.models import OuterRef, Subquery

# User profiles with dynamic stats (like LinkedIn profiles)
users_with_stats = User.objects.annotate(
    # Latest post date
    latest_post_date=Subquery(
        Post.objects.filter(
            author=OuterRef('pk')
        ).order_by('-created_at').values('created_at')[:1]
    ),
    
    # Total followers
    follower_count=Count('followers', distinct=True),
    
    # Average post engagement
    avg_post_engagement=Avg(
        'posts__likes_count'
    ) + Avg('posts__comments_count'),
    
    # Most used hashtag
    top_hashtag=Subquery(
        Post.objects.filter(
            author=OuterRef('pk')
        ).values('hashtags').annotate(
            hashtag_count=Count('hashtags')
        ).order_by('-hashtag_count').values('hashtags')[:1]
    )
)

# Restaurant reviews with contextual ratings (like Yelp)
restaurants_with_context = Restaurant.objects.annotate(
    # Overall rating
    average_rating=Avg('reviews__rating'),
    
    # Recent rating trend (last 30 days vs. overall)
    recent_rating=Avg(
        'reviews__rating',
        filter=Q(reviews__created_at__gte=thirty_days_ago)
    ),
    
    # Peak busy hours
    peak_hour_reviews=Count(
        'reviews',
        filter=Q(reviews__visit_time__hour__in=[12, 13, 18, 19, 20])
    ),
    
    # Price comparison with neighborhood average
    price_vs_neighborhood=F('average_price') - Subquery(
        Restaurant.objects.filter(
            neighborhood=OuterRef('neighborhood')
        ).aggregate(
            avg_price=Avg('average_price')
        ).values('avg_price')
    )
)
```

## Performance Optimization: select_related and prefetch_related

**Real-world analogy:** These are like having a smart personal assistant who anticipates what information you'll need and gathers it all in one trip, rather than making multiple trips for each piece of information.

### select_related: Joining Forward Relationships
```python
# ❌ N+1 Query Problem (like making multiple API calls)
posts = Post.objects.all()
for post in posts:
    print(f"{post.title} by {post.author.username}")  # Database hit for each author!

# ✅ Optimized with select_related (like a JOIN in SQL)
posts = Post.objects.select_related('author', 'category')
for post in posts:
    print(f"{post.title} by {post.author.username}")  # No additional queries!

# Complex example: Blog with nested relationships
blog_posts = BlogPost.objects.select_related(
    'author',                    # Author info
    'author__profile',           # Author's profile
    'category',                  # Post category
    'category__parent_category'  # Category hierarchy
)

# E-commerce order details (like Amazon order page)
orders = Order.objects.select_related(
    'customer',
    'customer__address',
    'shipping_address',
    'payment_method'
)
```

### prefetch_related: Optimizing Reverse and Many-to-Many Relationships
```python
# ❌ N+1 Problem with reverse relationships
authors = Author.objects.all()
for author in authors:
    for book in author.books.all():  # Query for each author!
        print(f"{book.title}")

# ✅ Optimized with prefetch_related
authors = Author.objects.prefetch_related('books')
for author in authors:
    for book in author.books.all():  # No additional queries!
        print(f"{book.title}")

# Advanced prefetch with custom QuerySets
# Like loading YouTube channel with top 5 most popular videos
channels = YouTubeChannel.objects.prefetch_related(
    Prefetch(
        'videos',
        queryset=Video.objects.filter(
            is_published=True
        ).order_by('-view_count')[:5],
        to_attr='top_videos'
    )
)

for channel in channels:
    for video in channel.top_videos:  # Pre-fetched top 5 videos
        print(f"{video.title}: {video.view_count} views")
```

### Advanced Prefetch Patterns
```python
from django.db.models import Prefetch

# Social media user with optimized content loading
users_with_content = User.objects.prefetch_related(
    # Recent posts with engagement data
    Prefetch(
        'posts',
        queryset=Post.objects.filter(
            created_at__gte=last_week,
            is_archived=False
        ).select_related('author').order_by('-created_at')[:10],
        to_attr='recent_posts'
    ),
    
    # Followers with profile info
    Prefetch(
        'followers',
        queryset=User.objects.select_related('profile'),
        to_attr='followers_with_profiles'
    ),
    
    # Popular hashtags
    Prefetch(
        'posts__hashtags',
        queryset=Hashtag.objects.annotate(
            usage_count=Count('posts')
        ).order_by('-usage_count')[:5],
        to_attr='popular_hashtags'
    )
)

# E-commerce category page optimization (like Amazon category browsing)
categories_with_products = Category.objects.prefetch_related(
    Prefetch(
        'products',
        queryset=Product.objects.filter(
            is_active=True,
            stock_quantity__gt=0
        ).select_related('brand').annotate(
            avg_rating=Avg('reviews__rating'),
            review_count=Count('reviews')
        ).order_by('-avg_rating')[:20],
        to_attr='featured_products'
    )
)
```

## Bulk Operations: Efficiency at Scale

**Real-world analogy:** Bulk operations are like processing thousands of documents at once instead of handling them one by one. This is how platforms like Gmail can move thousands of emails to trash instantly.

### Bulk Create: Mass Data Import
```python
# Importing social media posts from API (like data migration)
posts_to_create = []
for post_data in api_response['posts']:
    posts_to_create.append(Post(
        author_id=post_data['author_id'],
        content=post_data['content'],
        hashtags=','.join(post_data['hashtags'])
    ))

# Create all posts in one database operation
Post.objects.bulk_create(posts_to_create, batch_size=1000)

# E-commerce inventory update (like Amazon warehouse sync)
products_to_create = [
    Product(sku=f"ITEM{i}", name=f"Product {i}", price=19.99)
    for i in range(1, 10000)
]
Product.objects.bulk_create(products_to_create, batch_size=500)
```

### Bulk Update: Mass Data Changes
```python
# Update all user notification preferences (like privacy law compliance)
User.objects.filter(
    country='EU'
).update(
    email_marketing_consent=False,
    data_processing_consent=True,
    updated_at=timezone.now()
)

# Mark old posts as archived (like automatic cleanup)
Post.objects.filter(
    created_at__lt=one_year_ago,
    author__is_active=False
).update(is_archived=True)

# Bulk price adjustment (like Black Friday sales)
Product.objects.filter(
    category__name='Electronics'
).update(
    sale_price=F('price') * 0.8,  # 20% discount
    is_on_sale=True
)
```

### Conditional Bulk Updates
```python
from django.db.models import Case, When

# Dynamic status updates based on conditions (like order processing)
Order.objects.update(
    status=Case(
        When(
            created_at__gte=timezone.now() - timedelta(hours=1),
            payment_status='paid',
            then=Value('processing')
        ),
        When(
            created_at__gte=timezone.now() - timedelta(days=1),
            payment_status='paid',
            then=Value('shipped')
        ),
        When(
            payment_status='failed',
            then=Value('cancelled')
        ),
        default=F('status'),
        output_field=CharField()
    )
)

# User tier adjustments (like loyalty program updates)
User.objects.annotate(
    total_spent=Sum('orders__total_amount')
).update(
    tier=Case(
        When(total_spent__gte=10000, then=Value('platinum')),
        When(total_spent__gte=5000, then=Value('gold')),
        When(total_spent__gte=1000, then=Value('silver')),
        default=Value('bronze'),
        output_field=CharField()
    )
)
```

## Advanced Query Techniques: Expert-Level Operations

### Window Functions: Advanced Analytics
```python
from django.db.models import Window, F, Rank, RowNumber

# Ranking posts within each category (like trending by genre)
posts_with_ranking = Post.objects.annotate(
    category_rank=Window(
        expression=Rank(),
        partition_by=[F('category')],
        order_by=F('likes_count').desc()
    ),
    
    # Row number for pagination within category
    row_num=Window(
        expression=RowNumber(),
        partition_by=[F('category')],
        order_by=F('created_at').desc()
    )
).filter(category_rank__lte=10)  # Top 10 in each category

# Sales performance ranking (like leaderboards)
sales_reps_performance = SalesRep.objects.annotate(
    total_sales=Sum('orders__total_amount'),
    monthly_rank=Window(
        expression=Rank(),
        order_by=Sum('orders__total_amount').desc()
    )
)
```

### Subqueries and EXISTS: Complex Logic
```python
# Users who have posted in the last week (efficient EXISTS check)
active_users = User.objects.filter(
    Exists(
        Post.objects.filter(
            author=OuterRef('pk'),
            created_at__gte=last_week
        )
    )
)

# Products with no recent orders (inventory analysis)
slow_moving_products = Product.objects.filter(
    ~Exists(
        OrderItem.objects.filter(
            product=OuterRef('pk'),
            order__created_at__gte=last_month
        )
    )
)

# Complex recommendation logic (like "Users who bought this also bought")
def get_product_recommendations(product_id, limit=5):
    return Product.objects.filter(
        Exists(
            OrderItem.objects.filter(
                product=OuterRef('pk'),
                order__orderitem__product_id=product_id
            ).exclude(
                product_id=product_id  # Don't recommend the same product
            )
        )
    ).annotate(
        co_purchase_count=Count(
            'orderitem__order__orderitem',
            filter=Q(orderitem__order__orderitem__product_id=product_id)
        )
    ).order_by('-co_purchase_count')[:limit]
```

## Real-World Advanced Example: Building Analytics Dashboard

```python
def get_platform_analytics_dashboard(date_range_days=30):
    """
    Comprehensive analytics dashboard like what you'd see in 
    YouTube Studio, Instagram Insights, or Amazon Seller Central
    """
    end_date = timezone.now()
    start_date = end_date - timedelta(days=date_range_days)
    
    # User engagement metrics
    user_metrics = User.objects.filter(
        last_login__gte=start_date
    ).annotate(
        posts_this_period=Count(
            'posts',
            filter=Q(posts__created_at__gte=start_date)
        ),
        total_engagement=Sum(
            F('posts__likes_count') + F('posts__comments_count'),
            filter=Q(posts__created_at__gte=start_date)
        )
    ).aggregate(
        active_users=Count('id'),
        total_posts=Sum('posts_this_period'),
        average_engagement_per_user=Avg('total_engagement'),
        top_creator_engagement=Max('total_engagement')
    )
    
    # Content performance analysis
    content_metrics = Post.objects.filter(
        created_at__gte=start_date
    ).annotate(
        engagement_rate=Cast(
            (F('likes_count') + F('comments_count')) * 100.0 / 
            Greatest(F('views_count'), 1), 
            DecimalField()
        ),
        hours_since_posted=Cast(
            (Now() - F('created_at')).total_seconds() / 3600,
            IntegerField()
        )
    ).aggregate(
        total_content=Count('id'),
        average_engagement_rate=Avg('engagement_rate'),
        viral_content=Count(
            Case(When(likes_count__gte=10000, then=1))
        ),
        trending_content=Count(
            Case(
                When(
                    hours_since_posted__lte=24,
                    likes_count__gte=1000,
                    then=1
                )
            )
        )
    )
    
    # Growth metrics (comparing periods)
    previous_start = start_date - timedelta(days=date_range_days)
    
    previous_metrics = User.objects.filter(
        date_joined__range=[previous_start, start_date]
    ).count()
    
    current_signups = User.objects.filter(
        date_joined__gte=start_date
    ).count()
    
    growth_rate = ((current_signups - previous_metrics) / 
                   max(previous_metrics, 1)) * 100
    
    # Platform health indicators
    platform_health = {
        'average_session_duration': UserSession.objects.filter(
            created_at__gte=start_date
        ).aggregate(
            avg_duration=Avg('duration_seconds')
        )['avg_duration'],
        
        'content_moderation_rate': Post.objects.filter(
            created_at__gte=start_date
        ).annotate(
            is_flagged=Case(
                When(reports_count__gte=5, then=True),
                default=False,
                output_field=BooleanField()
            )
        ).aggregate(
            moderation_rate=Count(
                Case(When(is_flagged=True, then=1))
            ) * 100.0 / Count('id')
        )['moderation_rate'],
        
        'user_retention_rate': calculate_retention_cohort(start_date)
    }
    
    return {
        'period': f"{date_range_days} days",
        'user_metrics': user_metrics,
        'content_metrics': content_metrics,
        'growth_rate': round(growth_rate, 2),
        'platform_health': platform_health,
        'top_performing_content': Post.objects.filter(
            created_at__gte=start_date
        ).annotate(
            engagement_score=F('likes_count') + F('comments_count') * 2
        ).order_by('-engagement_score')[:10]
    }

def calculate_retention_cohort(start_date):
    """Calculate user retention using cohort analysis"""
    cohort_users = User.objects.filter(
        date_joined__gte=start_date - timedelta(days=7),
        date_joined__lt=start_date
    )
    
    retained_users = cohort_users.filter(
        last_login__gte=start_date
    )
    
    if cohort_users.count() > 0:
        return (retained_users.count() / cohort_users.count()) * 100
    return 0
```

Advanced QuerySet operations transform your Django application from a simple data handler into an intelligent analytics platform. These techniques power the dashboards and insights you see in major platforms - from social media analytics to e-commerce intelligence! 📊

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/ref/models/querysets/
    ''',
    "is_free": False,
    "xp_reward": 130,
    "exercises": [
        {
            "id": "analytics-dashboard-querysets",
            "title": "Build an Analytics Dashboard with Advanced QuerySets",
            "type": "project",
            "instructions": """Create a comprehensive analytics dashboard using advanced QuerySet operations:

1. Implement user engagement analytics with aggregations and annotations
2. Build content performance metrics with window functions and ranking
3. Create growth analysis comparing time periods
4. Optimize queries using select_related and prefetch_related
5. Use bulk operations for data processing efficiency

Your solution should demonstrate:
- Complex aggregations with conditional logic (Case/When)
- Advanced annotations with subqueries and computed fields
- Performance optimization techniques
- Window functions for ranking and analytics
- Real-world business intelligence features""",
            "starter_code": """from django.db import models
from django.contrib.auth.models import User
from django.db.models import *
from datetime import datetime, timedelta
from django.utils import timezone

# Assume these models exist (expanded from previous lessons)
class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(max_length=2200)
    hashtags = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    likes_count = models.PositiveIntegerField(default=0)
    comments_count = models.PositiveIntegerField(default=0)
    views_count = models.PositiveIntegerField(default=0)
    is_trending = models.BooleanField(default=False)
    category = models.CharField(max_length=50, default='general')

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    follower_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    total_likes_received = models.PositiveIntegerField(default=0)

class UserSession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    duration_seconds = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

# Your task: Implement these analytics functions

def get_user_engagement_analytics(days=30):
    \"\"\"
    Calculate comprehensive user engagement metrics:
    - Active users count
    - Average posts per user
    - Top content creators
    - Engagement rate trends
    \"\"\"
    # Implement user engagement analysis
    pass

def get_content_performance_metrics(days=30):
    \"\"\"
    Analyze content performance:
    - Total content created
    - Average engagement per post
    - Viral content identification
    - Category performance breakdown
    \"\"\"
    # Implement content performance analysis
    pass

def get_platform_growth_analysis(current_days=30, compare_days=30):
    \"\"\"
    Compare growth between two time periods:
    - User acquisition rates
    - Content creation trends
    - Engagement growth
    \"\"\"
    # Implement growth comparison analysis
    pass

def get_top_performers_ranking(category='all', days=30):
    \"\"\"
    Rank users and content using window functions:
    - Top creators by engagement
    - Trending posts ranking
    - Category leaders
    \"\"\"
    # Implement ranking system
    pass

def optimize_dashboard_queries():
    \"\"\"
    Demonstrate query optimization techniques:
    - Use select_related and prefetch_related
    - Minimize N+1 query problems
    - Efficient data loading
    \"\"\"
    # Implement optimized queries
    pass

# Test your implementation
# analytics = get_user_engagement_analytics()
# performance = get_content_performance_metrics()""",
            "solution": """from django.db import models
from django.contrib.auth.models import User
from django.db.models import *
from datetime import datetime, timedelta
from django.utils import timezone

def get_user_engagement_analytics(days=30):
    \"\"\"
    Calculate comprehensive user engagement metrics
    \"\"\"
    end_date = timezone.now()
    start_date = end_date - timedelta(days=days)
    
    # User activity analysis with annotations
    user_analytics = User.objects.filter(
        last_login__gte=start_date
    ).annotate(
        # Posts created in period
        posts_this_period=Count(
            'posts',
            filter=Q(posts__created_at__gte=start_date)
        ),
        
        # Total engagement received
        total_engagement_received=Sum(
            F('posts__likes_count') + F('posts__comments_count'),
            filter=Q(posts__created_at__gte=start_date)
        ),
        
        # Average engagement per post
        avg_engagement_per_post=Case(
            When(posts_this_period__gt=0, 
                 then=F('total_engagement_received') / F('posts_this_period')),
            default=0,
            output_field=FloatField()
        ),
        
        # User activity score
        activity_score=Case(
            When(posts_this_period__gte=10, then=100),
            When(posts_this_period__gte=5, then=75),
            When(posts_this_period__gte=1, then=50),
            default=25,
            output_field=IntegerField()
        ),
        
        # Days since last post
        days_since_last_post=Case(
            When(posts__isnull=True, then=999),
            default=Cast(
                (Now() - Max('posts__created_at')).total_seconds() / 86400,
                IntegerField()
            )
        )
    ).aggregate(
        # Overall platform metrics
        total_active_users=Count('id'),
        average_posts_per_user=Avg('posts_this_period'),
        average_engagement_per_user=Avg('total_engagement_received'),
        highly_active_users=Count(
            Case(When(posts_this_period__gte=5, then=1))
        ),
        power_users=Count(
            Case(When(activity_score=100, then=1))
        ),
        engagement_leaders=Count(
            Case(When(total_engagement_received__gte=1000, then=1))
        )
    )
    
    # Engagement rate trends by day
    daily_engagement = Post.objects.filter(
        created_at__gte=start_date
    ).extra(
        select={'day': 'date(created_at)'}
    ).values('day').annotate(
        posts_count=Count('id'),
        total_likes=Sum('likes_count'),
        total_comments=Sum('comments_count'),
        avg_engagement=Avg(F('likes_count') + F('comments_count'))
    ).order_by('day')
    
    return {
        'period_days': days,
        'user_metrics': user_analytics,
        'daily_trends': list(daily_engagement),
        'top_creators': User.objects.filter(
            last_login__gte=start_date
        ).annotate(
            period_engagement=Sum(
                F('posts__likes_count') + F('posts__comments_count'),
                filter=Q(posts__created_at__gte=start_date)
            )
        ).order_by('-period_engagement')[:10]
    }

def get_content_performance_metrics(days=30):
    \"\"\"
    Analyze content performance across multiple dimensions
    \"\"\"
    end_date = timezone.now()
    start_date = end_date - timedelta(days=days)
    
    # Content analysis with advanced annotations
    content_metrics = Post.objects.filter(
        created_at__gte=start_date
    ).annotate(
        # Engagement calculations
        total_engagement=F('likes_count') + F('comments_count'),
        engagement_rate=Case(
            When(views_count__gt=0, 
                 then=Cast(F('total_engagement') * 100.0 / F('views_count'), DecimalField())),
            default=0,
            output_field=DecimalField(max_digits=5, decimal_places=2)
        ),
        
        # Time-based metrics
        hours_since_posted=Cast(
            (Now() - F('created_at')).total_seconds() / 3600,
            IntegerField()
        ),
        
        # Performance categories
        performance_tier=Case(
            When(total_engagement__gte=10000, then=Value('Viral')),
            When(total_engagement__gte=1000, then=Value('Popular')),
            When(total_engagement__gte=100, then=Value('Good')),
            When(total_engagement__gte=10, then=Value('Average')),
            default=Value('Low'),
            output_field=CharField()
        ),
        
        # Velocity score (engagement per hour)
        velocity_score=Case(
            When(hours_since_posted__gt=0,
                 then=F('total_engagement') / F('hours_since_posted')),
            default=F('total_engagement'),
            output_field=FloatField()
        )
    ).aggregate(
        # Overall content statistics
        total_posts=Count('id'),
        average_engagement=Avg('total_engagement'),
        average_engagement_rate=Avg('engagement_rate'),
        viral_posts=Count(Case(When(performance_tier='Viral', then=1))),
        popular_posts=Count(Case(When(performance_tier='Popular', then=1))),
        high_velocity_posts=Count(Case(When(velocity_score__gte=100, then=1))),
        
        # Content quality metrics
        quality_score=Avg(
            Case(
                When(engagement_rate__gte=10, then=100),
                When(engagement_rate__gte=5, then=80),
                When(engagement_rate__gte=2, then=60),
                When(engagement_rate__gte=1, then=40),
                default=20,
                output_field=IntegerField()
            )
        )
    )
    
    # Category performance breakdown
    category_performance = Post.objects.filter(
        created_at__gte=start_date
    ).values('category').annotate(
        posts_count=Count('id'),
        total_engagement=Sum(F('likes_count') + F('comments_count')),
        avg_engagement=Avg(F('likes_count') + F('comments_count')),
        top_post_engagement=Max(F('likes_count') + F('comments_count')),
        engagement_rate=Avg(
            Case(
                When(views_count__gt=0,
                     then=Cast((F('likes_count') + F('comments_count')) * 100.0 / F('views_count'), 
                              DecimalField())),
                default=0,
                output_field=DecimalField(max_digits=5, decimal_places=2)
            )
        )
    ).order_by('-avg_engagement')
    
    return {
        'period_days': days,
        'content_metrics': content_metrics,
        'category_breakdown': list(category_performance),
        'trending_posts': Post.objects.filter(
            created_at__gte=start_date
        ).annotate(
            engagement_score=F('likes_count') + F('comments_count') * 2
        ).order_by('-engagement_score')[:20]
    }

def get_platform_growth_analysis(current_days=30, compare_days=30):
    \"\"\"
    Compare growth metrics between two time periods
    \"\"\"
    end_date = timezone.now()
    current_start = end_date - timedelta(days=current_days)
    compare_start = current_start - timedelta(days=compare_days)
    
    # Current period metrics
    current_metrics = {
        'new_users': User.objects.filter(
            date_joined__gte=current_start
        ).count(),
        
        'new_posts': Post.objects.filter(
            created_at__gte=current_start
        ).count(),
        
        'total_engagement': Post.objects.filter(
            created_at__gte=current_start
        ).aggregate(
            total=Sum(F('likes_count') + F('comments_count'))
        )['total'] or 0,
        
        'active_users': User.objects.filter(
            last_login__gte=current_start
        ).count()
    }
    
    # Previous period metrics
    previous_metrics = {
        'new_users': User.objects.filter(
            date_joined__gte=compare_start,
            date_joined__lt=current_start
        ).count(),
        
        'new_posts': Post.objects.filter(
            created_at__gte=compare_start,
            created_at__lt=current_start
        ).count(),
        
        'total_engagement': Post.objects.filter(
            created_at__gte=compare_start,
            created_at__lt=current_start
        ).aggregate(
            total=Sum(F('likes_count') + F('comments_count'))
        )['total'] or 0,
        
        'active_users': User.objects.filter(
            last_login__gte=compare_start,
            last_login__lt=current_start
        ).count()
    }
    
    # Calculate growth rates
    growth_rates = {}
    for metric in current_metrics:
        current_val = current_metrics[metric]
        previous_val = previous_metrics[metric]
        
        if previous_val > 0:
            growth_rates[f'{metric}_growth_rate'] = round(
                ((current_val - previous_val) / previous_val) * 100, 2
            )
        else:
            growth_rates[f'{metric}_growth_rate'] = 100.0 if current_val > 0 else 0.0
    
    return {
        'current_period': current_metrics,
        'previous_period': previous_metrics,
        'growth_rates': growth_rates,
        'analysis_periods': {
            'current': f'Last {current_days} days',
            'compare': f'Previous {compare_days} days'
        }
    }

def get_top_performers_ranking(category='all', days=30):
    \"\"\"
    Rank users and content using window functions and advanced queries
    \"\"\"
    end_date = timezone.now()
    start_date = end_date - timedelta(days=days)
    
    # User ranking with window functions
    user_rankings = User.objects.filter(
        posts__created_at__gte=start_date
    ).annotate(
        total_posts=Count('posts', filter=Q(posts__created_at__gte=start_date)),
        total_engagement=Sum(
            F('posts__likes_count') + F('posts__comments_count'),
            filter=Q(posts__created_at__gte=start_date)
        ),
        avg_engagement_per_post=Case(
            When(total_posts__gt=0,
                 then=F('total_engagement') / F('total_posts')),
            default=0,
            output_field=FloatField()
        )
    ).annotate(
        # Ranking by total engagement
        engagement_rank=Window(
            expression=Rank(),
            order_by=F('total_engagement').desc()
        ),
        
        # Ranking by average engagement per post
        quality_rank=Window(
            expression=Rank(),
            order_by=F('avg_engagement_per_post').desc()
        ),
        
        # Ranking by post volume
        volume_rank=Window(
            expression=Rank(),
            order_by=F('total_posts').desc()
        )
    ).filter(total_posts__gte=1).order_by('engagement_rank')[:50]
    
    # Content ranking within categories
    content_filters = Q(created_at__gte=start_date)
    if category != 'all':
        content_filters &= Q(category=category)
    
    post_rankings = Post.objects.filter(content_filters).annotate(
        engagement_score=F('likes_count') + F('comments_count') * 2,
        
        # Rank within category
        category_rank=Window(
            expression=Rank(),
            partition_by=[F('category')],
            order_by=F('engagement_score').desc()
        ),
        
        # Overall platform rank
        platform_rank=Window(
            expression=Rank(),
            order_by=F('engagement_score').desc()
        ),
        
        # Recency rank (for trending identification)
        recency_rank=Window(
            expression=Rank(),
            order_by=F('created_at').desc()
        )
    ).order_by('platform_rank')[:100]
    
    return {
        'user_rankings': list(user_rankings.values(
            'username', 'total_posts', 'total_engagement', 
            'engagement_rank', 'quality_rank', 'volume_rank'
        )),
        'content_rankings': list(post_rankings.values(
            'id', 'content', 'category', 'engagement_score',
            'category_rank', 'platform_rank', 'author__username'
        )),
        'category_leaders': Post.objects.filter(
            content_filters
        ).values('category').annotate(
            top_post=Max(F('likes_count') + F('comments_count')),
            total_posts=Count('id'),
            avg_engagement=Avg(F('likes_count') + F('comments_count'))
        ).order_by('-avg_engagement')
    }

def optimize_dashboard_queries():
    \"\"\"
    Demonstrate optimized query patterns for dashboard performance
    \"\"\"
    # Optimized user dashboard with minimal queries
    users_optimized = User.objects.select_related(
        'profile'  # Get profile info in same query
    ).prefetch_related(
        Prefetch(
            'posts',
            queryset=Post.objects.filter(
                created_at__gte=timezone.now() - timedelta(days=7)
            ).order_by('-created_at')[:5],
            to_attr='recent_posts'
        )
    ).annotate(
        total_engagement=Sum(F('posts__likes_count') + F('posts__comments_count')),
        post_count=Count('posts')
    )
    
    # Bulk analytics calculation
    def calculate_bulk_user_stats():
        \"\"\"Efficiently update user statistics\"\"\"
        users_to_update = []
        
        for user in User.objects.all():
            stats = user.posts.aggregate(
                total_likes=Sum('likes_count'),
                total_posts=Count('id'),
                avg_engagement=Avg(F('likes_count') + F('comments_count'))
            )
            
            # Update profile with calculated stats
            if hasattr(user, 'profile'):
                user.profile.total_likes_received = stats['total_likes'] or 0
                users_to_update.append(user.profile)
        
        # Bulk update for efficiency
        UserProfile.objects.bulk_update(
            users_to_update, 
            ['total_likes_received'], 
            batch_size=500
        )
    
    return {
        'optimized_users': users_optimized[:20],
        'query_count_without_optimization': 'N+1 queries per user',
        'query_count_with_optimization': '3-4 queries total',
        'bulk_update_function': calculate_bulk_user_stats
    }

def comprehensive_dashboard_example():
    \"\"\"
    Complete example combining all advanced QuerySet techniques
    \"\"\"
    # Multi-dimensional analytics in single complex query
    dashboard_data = Post.objects.filter(
        created_at__gte=timezone.now() - timedelta(days=30),
        is_archived=False
    ).select_related(
        'author', 'author__profile'
    ).annotate(
        # Performance metrics
        engagement_score=F('likes_count') + F('comments_count') * 2,
        engagement_rate=Case(
            When(views_count__gt=0,
                 then=Cast(F('engagement_score') * 100.0 / F('views_count'), DecimalField())),
            default=0
        ),
        
        # Time-based analysis
        days_since_posted=Cast(
            (Now() - F('created_at')).total_seconds() / 86400, IntegerField()
        ),
        
        # Author context
        author_avg_engagement=Avg(
            'author__posts__likes_count',
            filter=Q(author__posts__created_at__gte=timezone.now() - timedelta(days=90))
        ),
        
        # Performance vs. author baseline
        performance_vs_baseline=Case(
            When(author_avg_engagement__gt=0,
                 then=F('engagement_score') / F('author_avg_engagement')),
            default=1.0
        ),
        
        # Trending indicators
        is_trending_candidate=Case(
            When(
                engagement_score__gte=1000,
                days_since_posted__lte=2,
                performance_vs_baseline__gte=1.5,
                then=True
            ),
            default=False,
            output_field=BooleanField()
        )
    ).order_by('-engagement_score')
    
    return dashboard_data[:50]""",
            "test_cases": [
                {
                    "name": "Functions use advanced QuerySet operations",
                    "input": "",
                    "expected_contains": ["annotate", "aggregate", "Window", "Rank", "Case", "When", "Subquery"]
                }
            ],
            "xp_reward": 180,
            "hints": [
                "Use annotate() with Case/When for conditional calculations",
                "Window functions are perfect for ranking and percentile calculations",
                "Combine multiple aggregations in a single query for efficiency",
                "Use select_related and prefetch_related to avoid N+1 query problems",
                "Consider using bulk operations for large-scale data updates"
            ]
        }
    ]
}