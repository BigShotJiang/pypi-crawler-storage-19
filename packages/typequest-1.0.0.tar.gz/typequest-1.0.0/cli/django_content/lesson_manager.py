"""
Django Lesson Manager - High-level interface for lesson management
"""

from .lesson_registry import (
    get_ordered_lessons,
    get_lesson_by_key,
    get_available_orders,
    get_lesson_metadata,
    get_lessons_by_difficulty,
    get_lessons_by_prerequisites,
    add_lesson_order
)

class DjangoLessonManager:
    """
    High-level manager for Django lessons with flexible ordering
    """
    
    def __init__(self, default_order='default', start_chapter=1):
        """
        Initialize lesson manager
        
        Args:
            default_order (str): Default ordering configuration
            start_chapter (int): Starting chapter number
        """
        self.default_order = default_order
        self.start_chapter = start_chapter
    
    def get_all_lessons(self, order=None):
        """
        Get all lessons in specified order
        
        Args:
            order (str): Ordering configuration name
            
        Returns:
            list: Ordered list of lessons
        """
        order = order or self.default_order
        return get_ordered_lessons(order, self.start_chapter)
    
    def get_lesson(self, lesson_key):
        """
        Get a specific lesson by key
        
        Args:
            lesson_key (str): Lesson identifier
            
        Returns:
            dict: Lesson content
        """
        return get_lesson_by_key(lesson_key)
    
    def get_beginner_track(self):
        """
        Get lessons ordered for beginners
        
        Returns:
            list: Beginner-friendly lesson order
        """
        return get_ordered_lessons('beginner_friendly', self.start_chapter)
    
    def get_practical_track(self):
        """
        Get lessons with practical examples first
        
        Returns:
            list: Practical-first lesson order
        """
        return get_ordered_lessons('practical_first', self.start_chapter)
    
    def get_difficulty_track(self, ascending=True):
        """
        Get lessons ordered by difficulty
        
        Args:
            ascending (bool): True for easy to hard, False for hard to easy
            
        Returns:
            list: Difficulty-ordered lessons
        """
        order = 'ascending' if ascending else 'descending'
        return get_lessons_by_difficulty(order, self.start_chapter)
    
    def get_prerequisite_track(self):
        """
        Get lessons ordered by prerequisites (dependency order)
        
        Returns:
            list: Dependency-ordered lessons
        """
        return get_lessons_by_prerequisites(self.start_chapter)
    
    def get_free_lessons(self, order=None):
        """
        Get only free lessons
        
        Args:
            order (str): Ordering configuration
            
        Returns:
            list: Free lessons only
        """
        all_lessons = self.get_all_lessons(order)
        return [lesson for lesson in all_lessons if lesson.get('is_free', False)]
    
    def get_premium_lessons(self, order=None):
        """
        Get only premium lessons
        
        Args:
            order (str): Ordering configuration
            
        Returns:
            list: Premium lessons only
        """
        all_lessons = self.get_all_lessons(order)
        return [lesson for lesson in all_lessons if not lesson.get('is_free', False)]
    
    def get_lessons_by_xp_range(self, min_xp=0, max_xp=float('inf'), order=None):
        """
        Get lessons within XP range
        
        Args:
            min_xp (int): Minimum XP reward
            max_xp (int): Maximum XP reward
            order (str): Ordering configuration
            
        Returns:
            list: Filtered lessons
        """
        all_lessons = self.get_all_lessons(order)
        return [
            lesson for lesson in all_lessons 
            if min_xp <= lesson.get('xp_reward', 0) <= max_xp
        ]
    
    def get_lesson_summaries(self):
        """
        Get summary information for all lessons
        
        Returns:
            list: Lesson summaries with metadata
        """
        metadata = get_lesson_metadata()
        summaries = []
        
        for key, meta in metadata.items():
            summaries.append({
                'key': key,
                'title': meta['title'],
                'slug': meta['slug'],
                'is_free': meta['is_free'],
                'xp_reward': meta['xp_reward'],
                'exercise_count': meta['exercise_count']
            })
        
        return summaries
    
    def create_custom_track(self, name, lesson_keys):
        """
        Create a custom lesson track
        
        Args:
            name (str): Track name
            lesson_keys (list): List of lesson keys in desired order
        """
        add_lesson_order(name, lesson_keys)
    
    def get_learning_path_for_goal(self, goal):
        """
        Get recommended learning path based on learning goal
        
        Args:
            goal (str): Learning goal ('beginner', 'crud_focus', 'advanced', 'performance')
            
        Returns:
            list: Recommended lesson order
        """
        goal_to_order = {
            'beginner': 'beginner_friendly',
            'crud_focus': 'practical_first', 
            'advanced': 'advanced_first',
            'performance': ['cbv_intro', 'async_views', 'subclassing_views', 'mixins', 'generic_display', 'generic_editing', 'urlconf_usage'],
            'dependency': 'prerequisite'
        }
        
        if goal == 'dependency':
            return self.get_prerequisite_track()
        elif goal == 'performance':
            # Custom order for performance-focused learning
            add_lesson_order('performance_focused', goal_to_order[goal])
            return get_ordered_lessons('performance_focused', self.start_chapter)
        else:
            order = goal_to_order.get(goal, 'default')
            return self.get_all_lessons(order)
    
    def get_next_lesson(self, current_lesson_key, order=None):
        """
        Get the next lesson in sequence
        
        Args:
            current_lesson_key (str): Current lesson key
            order (str): Ordering configuration
            
        Returns:
            dict or None: Next lesson or None if current is last
        """
        lessons = self.get_all_lessons(order)
        
        for i, lesson in enumerate(lessons):
            if lesson['slug'] == current_lesson_key or lesson.get('key') == current_lesson_key:
                if i + 1 < len(lessons):
                    return lessons[i + 1]
                break
        
        return None
    
    def get_previous_lesson(self, current_lesson_key, order=None):
        """
        Get the previous lesson in sequence
        
        Args:
            current_lesson_key (str): Current lesson key
            order (str): Ordering configuration
            
        Returns:
            dict or None: Previous lesson or None if current is first
        """
        lessons = self.get_all_lessons(order)
        
        for i, lesson in enumerate(lessons):
            if lesson['slug'] == current_lesson_key or lesson.get('key') == current_lesson_key:
                if i > 0:
                    return lessons[i - 1]
                break
        
        return None
    
    def get_lesson_progress_info(self, order=None):
        """
        Get information about lesson progression
        
        Args:
            order (str): Ordering configuration
            
        Returns:
            dict: Progress information
        """
        lessons = self.get_all_lessons(order)
        
        total_xp = sum(lesson.get('xp_reward', 0) for lesson in lessons)
        total_exercises = sum(len(lesson.get('exercises', [])) for lesson in lessons)
        free_lessons = [l for l in lessons if l.get('is_free', False)]
        
        return {
            'total_lessons': len(lessons),
            'total_xp': total_xp,
            'total_exercises': total_exercises,
            'free_lesson_count': len(free_lessons),
            'premium_lesson_count': len(lessons) - len(free_lessons),
            'lesson_titles': [l['title'] for l in lessons]
        }

# Create a default instance for easy use
django_lessons = DjangoLessonManager()

# Export commonly used functions
def get_django_lessons(order='default'):
    """Convenience function to get Django lessons"""
    return django_lessons.get_all_lessons(order)

def get_beginner_django_lessons():
    """Convenience function to get beginner-friendly Django lessons"""
    return django_lessons.get_beginner_track()

def get_django_lesson(key):
    """Convenience function to get a specific Django lesson"""
    return django_lessons.get_lesson(key)

__all__ = [
    'DjangoLessonManager',
    'django_lessons',
    'get_django_lessons',
    'get_beginner_django_lessons', 
    'get_django_lesson'
]