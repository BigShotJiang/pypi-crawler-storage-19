"""
Django Asynchronous Class-Based Views lesson content
"""

DJANGO_ASYNC_VIEWS_LESSON = {
    "id": 15,
    "chapter": 15,
    "title": "Asynchronous Class-Based Views",
    "slug": "async-class-based-views",
    "content": '''
# Asynchronous Class-Based Views: Supercharging Performance

Imagine your web application as a busy restaurant kitchen. Traditional synchronous views are like having one chef who must complete each order before starting the next. Asynchronous views are like having a master chef who can start multiple dishes simultaneously, dramatically increasing the kitchen's throughput!

## Understanding Async in Django: The Concurrency Revolution

Django's async support allows your application to handle multiple requests simultaneously without blocking. This is especially powerful for:
- **External API calls** (waiting for responses from other services)
- **Database operations** (complex queries that take time)
- **File I/O operations** (reading/writing large files)
- **Real-time features** (WebSocket connections, live updates)

**Coffee shop analogy:** Instead of one barista making each drink from start to finish (sync), you have multiple baristas working on different parts of orders simultaneously (async) - one steaming milk while another grinds beans.

## When to Use Async Views: The Sweet Spots

### Perfect Use Cases ✅
- Views that make external HTTP requests
- Complex database queries with multiple joins
- File upload/download handling
- Real-time data processing
- Integration with third-party services

### When Sync is Better ❌
- Simple CRUD operations
- Quick database lookups
- Static content serving
- Basic form processing

**Rule of thumb:** If your view spends time waiting for external resources, async can help!

## Basic Async Class-Based Views

### Converting a Sync View to Async
```python
# Synchronous view (traditional)
class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # This blocks while waiting for external API
        context['weather'] = requests.get('https://api.weather.com/current').json()
        return context

# Asynchronous view (new way)
import asyncio
import aiohttp
from django.views.generic import ListView
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt

class AsyncBookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    
    async def get_context_data(self, **kwargs):
        context = await super().get_context_data(**kwargs)
        
        # Non-blocking external API call
        async with aiohttp.ClientSession() as session:
            async with session.get('https://api.weather.com/current') as response:
                context['weather'] = await response.json()
        
        return context
```

**The magic:** While waiting for the weather API, the server can process other requests!

## Async ListView: Handling Collections Efficiently

### Advanced Async ListView with Multiple External Calls
```python
import asyncio
import aiohttp
from django.views.generic import ListView
from django.db import models
from asgiref.sync import sync_to_async

class ComprehensiveAsyncBookListView(ListView):
    model = Book
    template_name = 'books/comprehensive_list.html'
    context_object_name = 'books'
    paginate_by = 20
    
    async def get_context_data(self, **kwargs):
        # Get base context (this involves database queries)
        context = await super().get_context_data(**kwargs)
        
        # Run multiple external calls concurrently
        weather_task = self.get_weather_data()
        stock_task = self.get_book_stock_data()
        reviews_task = self.get_external_reviews()
        news_task = self.get_book_news()
        
        # Wait for all external calls to complete
        weather, stock_info, external_reviews, book_news = await asyncio.gather(
            weather_task, stock_task, reviews_task, news_task,
            return_exceptions=True  # Don't let one failure break everything
        )
        
        # Add results to context (with error handling)
        context['weather'] = weather if not isinstance(weather, Exception) else None
        context['stock_info'] = stock_info if not isinstance(stock_info, Exception) else {}
        context['external_reviews'] = external_reviews if not isinstance(external_reviews, Exception) else []
        context['book_news'] = book_news if not isinstance(book_news, Exception) else []
        
        return context
    
    async def get_weather_data(self):
        """Get current weather (simulating slow external API)"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.openweathermap.org/data/2.5/weather',
                    params={'q': 'New York', 'appid': 'your-api-key'},
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as response:
                    return await response.json()
        except asyncio.TimeoutError:
            return {'error': 'Weather service timeout'}
        except Exception as e:
            return {'error': f'Weather service error: {str(e)}'}
    
    async def get_book_stock_data(self):
        """Get inventory data from external warehouse system"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://warehouse-api.example.com/inventory',
                    headers={'Authorization': 'Bearer your-token'},
                    timeout=aiohttp.ClientTimeout(total=3)
                ) as response:
                    return await response.json()
        except Exception:
            return {'books_in_stock': 'unknown'}
    
    async def get_external_reviews(self):
        """Fetch reviews from Goodreads or similar service"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.goodreads.com/book/review_counts',
                    timeout=aiohttp.ClientTimeout(total=4)
                ) as response:
                    return await response.json()
        except Exception:
            return []
    
    async def get_book_news(self):
        """Get latest book industry news"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.publishersnews.com/latest',
                    timeout=aiohttp.ClientTimeout(total=3)
                ) as response:
                    return await response.json()
        except Exception:
            return []

    async def get_queryset(self):
        """Override queryset method for async database operations"""
        # Convert sync database query to async
        return await sync_to_async(
            lambda: list(
                Book.objects.select_related('author')
                .prefetch_related('categories')
                .filter(is_published=True)
                .order_by('-publication_date')
            )
        )()
```

**Performance boost:** Instead of 15+ seconds waiting for sequential API calls, all calls happen simultaneously, completing in ~5 seconds!

## Async DetailView: Rich Object Display

### Async DetailView with Related Data Enrichment
```python
class AsyncBookDetailView(DetailView):
    model = Book
    template_name = 'books/async_detail.html'
    context_object_name = 'book'
    
    async def get_context_data(self, **kwargs):
        context = await super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Launch multiple async operations
        tasks = [
            self.get_similar_books(book),
            self.get_author_social_data(book.author),
            self.get_price_comparison(book.isbn),
            self.get_reading_analytics(book),
            self.update_view_count(book)  # Non-blocking database update
        ]
        
        # Execute all tasks concurrently
        (similar_books, author_social, price_data, 
         analytics, _) = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Add results to context
        context.update({
            'similar_books': similar_books if not isinstance(similar_books, Exception) else [],
            'author_social': author_social if not isinstance(author_social, Exception) else {},
            'price_comparison': price_data if not isinstance(price_data, Exception) else {},
            'analytics': analytics if not isinstance(analytics, Exception) else {}
        })
        
        return context
    
    async def get_similar_books(self, book):
        """Find similar books using external recommendation service"""
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.bookrecommendations.com/similar',
                json={'isbn': book.isbn, 'categories': [c.name for c in book.categories.all()]},
                timeout=aiohttp.ClientTimeout(total=4)
            ) as response:
                data = await response.json()
                return data.get('recommendations', [])
    
    async def get_author_social_data(self, author):
        """Get author's social media stats"""
        if not hasattr(author, 'social_profile'):
            return {}
        
        social_tasks = []
        if author.social_profile.twitter_handle:
            social_tasks.append(self.get_twitter_stats(author.social_profile.twitter_handle))
        if author.social_profile.instagram_handle:
            social_tasks.append(self.get_instagram_stats(author.social_profile.instagram_handle))
        
        if social_tasks:
            results = await asyncio.gather(*social_tasks, return_exceptions=True)
            return {'social_stats': results}
        return {}
    
    async def get_price_comparison(self, isbn):
        """Compare prices across different retailers"""
        retailers = [
            'https://api.amazon.com/price',
            'https://api.barnesandnoble.com/price',
            'https://api.bookdepository.com/price'
        ]
        
        price_tasks = []
        async with aiohttp.ClientSession() as session:
            for retailer_url in retailers:
                task = session.get(
                    retailer_url,
                    params={'isbn': isbn},
                    timeout=aiohttp.ClientTimeout(total=3)
                )
                price_tasks.append(task)
            
            prices = []
            for task in asyncio.as_completed(price_tasks):
                try:
                    async with await task as response:
                        data = await response.json()
                        prices.append(data)
                except Exception:
                    continue  # Skip failed requests
            
            return {'price_comparison': prices}
    
    async def get_reading_analytics(self, book):
        """Get reading analytics from analytics service"""
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f'https://analytics.booksite.com/book/{book.id}/stats',
                timeout=aiohttp.ClientTimeout(total=2)
            ) as response:
                return await response.json()
    
    async def update_view_count(self, book):
        """Async database update for view counting"""
        await sync_to_async(
            Book.objects.filter(pk=book.pk).update
        )(view_count=models.F('view_count') + 1)
```

## Async Form Views: Non-Blocking User Interactions

### Async CreateView with External Validations
```python
from django.views.generic import CreateView
from django.contrib import messages
from django.http import JsonResponse

class AsyncBookCreateView(CreateView):
    model = Book
    fields = ['title', 'isbn', 'description', 'author']
    template_name = 'books/async_create.html'
    
    async def form_valid(self, form):
        """Handle form with async validations"""
        book = form.save(commit=False)
        
        # Run validations concurrently
        validation_tasks = [
            self.validate_isbn_uniqueness(book.isbn),
            self.verify_author_exists(book.author.name),
            self.check_content_policy(book.description),
            self.generate_book_metadata(book)
        ]
        
        try:
            isbn_valid, author_valid, content_valid, metadata = await asyncio.gather(
                *validation_tasks
            )
            
            # Check all validations passed
            if not isbn_valid:
                form.add_error('isbn', 'This ISBN already exists in our system')
                return await self.form_invalid(form)
            
            if not author_valid:
                form.add_error('author', 'Author verification failed')
                return await self.form_invalid(form)
            
            if not content_valid:
                form.add_error('description', 'Content does not meet our guidelines')
                return await self.form_invalid(form)
            
            # Apply metadata
            if metadata:
                book.genre = metadata.get('predicted_genre')
                book.reading_level = metadata.get('reading_level')
            
            # Save the book
            await sync_to_async(book.save)()
            
            # Trigger async post-creation tasks
            asyncio.create_task(self.post_creation_tasks(book))
            
            messages.success(self.request, f'Book "{book.title}" created successfully!')
            return await super().form_valid(form)
            
        except Exception as e:
            form.add_error(None, f'Validation error: {str(e)}')
            return await self.form_invalid(form)
    
    async def validate_isbn_uniqueness(self, isbn):
        """Check if ISBN exists in external databases"""
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://api.worldcat.org/registry/lookup',
                params={'isbn': isbn}
            ) as response:
                data = await response.json()
                return not data.get('exists_in_library', False)
    
    async def verify_author_exists(self, author_name):
        """Verify author exists in external author database"""
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://api.authordb.com/verify',
                params={'name': author_name}
            ) as response:
                data = await response.json()
                return data.get('verified', False)
    
    async def check_content_policy(self, description):
        """Check content against policy using AI service"""
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.moderationservice.com/check',
                json={'text': description}
            ) as response:
                data = await response.json()
                return data.get('approved', True)
    
    async def generate_book_metadata(self, book):
        """Use AI to generate book metadata"""
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.bookmetadata.com/analyze',
                json={
                    'title': book.title,
                    'description': book.description
                }
            ) as response:
                return await response.json()
    
    async def post_creation_tasks(self, book):
        """Background tasks after book creation"""
        tasks = [
            self.notify_followers(book),
            self.generate_recommendations(book),
            self.update_search_index(book)
        ]
        
        await asyncio.gather(*tasks, return_exceptions=True)
    
    async def notify_followers(self, book):
        """Notify author's followers about new book"""
        # Implementation would send notifications
        pass
```

### Async AJAX Form Handler
```python
class AsyncBookQuickCreateView(View):
    """Handle AJAX book creation with instant feedback"""
    
    async def post(self, request, *args, **kwargs):
        try:
            # Parse JSON data
            data = json.loads(request.body)
            
            # Validate and create book asynchronously
            validation_result = await self.validate_book_data(data)
            
            if validation_result['valid']:
                book = await self.create_book_async(data)
                
                # Return success response
                return JsonResponse({
                    'success': True,
                    'book_id': book.id,
                    'message': f'Book "{book.title}" created successfully!',
                    'redirect_url': f'/books/{book.id}/'
                })
            else:
                return JsonResponse({
                    'success': False,
                    'errors': validation_result['errors']
                })
                
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f'Server error: {str(e)}'
            })
    
    async def validate_book_data(self, data):
        """Async validation of book data"""
        errors = {}
        
        # Basic validation
        if not data.get('title'):
            errors['title'] = 'Title is required'
        
        if not data.get('isbn'):
            errors['isbn'] = 'ISBN is required'
        
        # External validations (run concurrently if basic validation passes)
        if not errors:
            isbn_check, title_check = await asyncio.gather(
                self.check_isbn_exists(data['isbn']),
                self.check_title_duplicate(data['title'])
            )
            
            if isbn_check:
                errors['isbn'] = 'ISBN already exists'
            if title_check:
                errors['title'] = 'Similar title already exists'
        
        return {
            'valid': len(errors) == 0,
            'errors': errors
        }
    
    async def create_book_async(self, data):
        """Create book with async operations"""
        # Create book instance
        book = Book(
            title=data['title'],
            isbn=data['isbn'],
            description=data.get('description', '')
        )
        
        # Save to database
        await sync_to_async(book.save)()
        
        # Trigger background tasks
        asyncio.create_task(self.post_creation_background_tasks(book))
        
        return book
```

## Performance Monitoring and Optimization

### Async View with Performance Metrics
```python
import time
import logging
from django.core.cache import cache

logger = logging.getLogger(__name__)

class PerformanceMonitoredAsyncView(ListView):
    model = Book
    
    async def dispatch(self, request, *args, **kwargs):
        start_time = time.time()
        
        try:
            response = await super().dispatch(request, *args, **kwargs)
            
            # Log performance metrics
            duration = time.time() - start_time
            logger.info(f'Async view completed in {duration:.2f}s')
            
            # Cache frequently requested data
            cache_key = f'book_list_{request.GET.urlencode()}'
            await sync_to_async(cache.set)(cache_key, response.content, 300)
            
            return response
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f'Async view failed after {duration:.2f}s: {str(e)}')
            raise
    
    async def get_context_data(self, **kwargs):
        # Use cached data when available
        cache_key = f'book_context_{self.request.GET.urlencode()}'
        cached_context = await sync_to_async(cache.get)(cache_key)
        
        if cached_context:
            return cached_context
        
        context = await super().get_context_data(**kwargs)
        
        # Cache the context
        await sync_to_async(cache.set)(cache_key, context, 180)
        
        return context
```

### Database Query Optimization for Async Views
```python
from django.db import models
from asgiref.sync import sync_to_async

class OptimizedAsyncBookListView(ListView):
    model = Book
    
    async def get_queryset(self):
        """Optimized async database queries"""
        
        @sync_to_async
        def get_books():
            return list(Book.objects.select_related(
                'author', 'publisher'
            ).prefetch_related(
                'categories',
                'reviews__user'
            ).filter(
                is_published=True
            ).annotate(
                review_count=models.Count('reviews'),
                avg_rating=models.Avg('reviews__rating')
            ).order_by('-publication_date'))
        
        return await get_books()
    
    async def get_context_data(self, **kwargs):
        context = await super().get_context_data(**kwargs)
        
        # Run multiple database queries concurrently
        stats_task = self.get_book_statistics()
        categories_task = self.get_popular_categories()
        authors_task = self.get_featured_authors()
        
        stats, categories, authors = await asyncio.gather(
            stats_task, categories_task, authors_task
        )
        
        context.update({
            'stats': stats,
            'popular_categories': categories,
            'featured_authors': authors
        })
        
        return context
    
    @sync_to_async
    def get_book_statistics(self):
        return {
            'total_books': Book.objects.count(),
            'published_this_month': Book.objects.filter(
                publication_date__month=timezone.now().month
            ).count(),
            'avg_rating': Book.objects.aggregate(
                avg=models.Avg('reviews__rating')
            )['avg']
        }
    
    @sync_to_async
    def get_popular_categories(self):
        return list(Category.objects.annotate(
            book_count=models.Count('books')
        ).order_by('-book_count')[:10])
    
    @sync_to_async  
    def get_featured_authors(self):
        return list(Author.objects.filter(
            is_featured=True
        ).select_related('profile')[:5])
```

## Error Handling and Resilience

### Robust Async View with Circuit Breaker Pattern
```python
import asyncio
from datetime import datetime, timedelta

class CircuitBreakerAsyncView(ListView):
    """Async view with circuit breaker for external services"""
    
    def __init__(self):
        super().__init__()
        self.circuit_breaker = {
            'failures': 0,
            'last_failure': None,
            'state': 'closed'  # closed, open, half-open
        }
    
    async def get_context_data(self, **kwargs):
        context = await super().get_context_data(**kwargs)
        
        # Only call external services if circuit breaker allows
        if self.should_call_external_service():
            try:
                external_data = await self.call_external_service()
                context['external_data'] = external_data
                self.record_success()
            except Exception as e:
                self.record_failure()
                logger.warning(f'External service failed: {str(e)}')
                context['external_data'] = self.get_fallback_data()
        else:
            context['external_data'] = self.get_fallback_data()
        
        return context
    
    def should_call_external_service(self):
        """Circuit breaker logic"""
        if self.circuit_breaker['state'] == 'closed':
            return True
        elif self.circuit_breaker['state'] == 'open':
            # Check if enough time has passed to try again
            if (datetime.now() - self.circuit_breaker['last_failure']).seconds > 60:
                self.circuit_breaker['state'] = 'half-open'
                return True
            return False
        else:  # half-open
            return True
    
    def record_failure(self):
        """Record external service failure"""
        self.circuit_breaker['failures'] += 1
        self.circuit_breaker['last_failure'] = datetime.now()
        
        if self.circuit_breaker['failures'] >= 3:
            self.circuit_breaker['state'] = 'open'
    
    def record_success(self):
        """Record external service success"""
        self.circuit_breaker['failures'] = 0
        self.circuit_breaker['state'] = 'closed'
    
    async def call_external_service(self):
        """Call external service with timeout"""
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://external-api.example.com/data',
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return await response.json()
    
    def get_fallback_data(self):
        """Provide fallback data when external service fails"""
        return {
            'message': 'External service temporarily unavailable',
            'cached_data': cache.get('external_service_cache', {})
        }
```

## Testing Async Views

```python
import pytest
from django.test import AsyncClient
from django.contrib.auth.models import User

@pytest.mark.asyncio
class TestAsyncViews:
    
    async def test_async_book_list_view(self):
        """Test async book list view performance"""
        client = AsyncClient()
        
        start_time = time.time()
        response = await client.get('/books/async/')
        duration = time.time() - start_time
        
        assert response.status_code == 200
        assert duration < 10  # Should complete within 10 seconds
        assert 'books' in response.context
    
    async def test_async_view_with_external_api_failure(self):
        """Test async view handles external API failures gracefully"""
        client = AsyncClient()
        
        # Mock external API to fail
        with patch('aiohttp.ClientSession.get', side_effect=aiohttp.ClientError):
            response = await client.get('/books/async-detail/1/')
            
            assert response.status_code == 200
            # Should have fallback data instead of crashing
            assert 'external_data' in response.context
    
    async def test_async_form_submission(self):
        """Test async form submission"""
        client = AsyncClient()
        user = await sync_to_async(User.objects.create_user)(
            'testuser', 'test@example.com', 'password'
        )
        
        await client.force_login(user)
        
        response = await client.post('/books/async-create/', {
            'title': 'Test Book',
            'isbn': '1234567890',
            'description': 'A test book'
        })
        
        assert response.status_code == 302  # Redirect after successful creation
```

## Best Practices for Async Views

### 1. Always Handle Exceptions
```python
async def get_external_data(self):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=5) as response:
                return await response.json()
    except asyncio.TimeoutError:
        logger.warning('External API timeout')
        return None
    except Exception as e:
        logger.error(f'External API error: {str(e)}')
        return None
```

### 2. Use Timeouts for All External Calls
```python
# ✅ Good - with timeout
async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as response:
    return await response.json()

# ❌ Bad - no timeout (can hang forever)
async with session.get(url) as response:
    return await response.json()
```

### 3. Implement Circuit Breakers for Reliability
```python
# Prevent cascading failures from external services
if external_service_healthy():
    data = await call_external_service()
else:
    data = get_cached_or_fallback_data()
```

### 4. Monitor Performance and Errors
```python
import logging

logger = logging.getLogger(__name__)

async def monitored_async_operation(self):
    start_time = time.time()
    try:
        result = await external_operation()
        logger.info(f'Operation completed in {time.time() - start_time:.2f}s')
        return result
    except Exception as e:
        logger.error(f'Operation failed after {time.time() - start_time:.2f}s: {str(e)}')
        raise
```

## Performance Comparison: Sync vs Async

**Traditional Sync View:**
- 3 external API calls × 2 seconds each = 6+ seconds total
- Blocks server thread during waiting
- Can handle ~100 concurrent requests

**Async View:**
- 3 external API calls running simultaneously = ~2 seconds total
- Server thread free to handle other requests while waiting
- Can handle 1000+ concurrent requests

**The async advantage becomes dramatic under load!**

Asynchronous class-based views represent the future of high-performance web development. Master them to build applications that scale gracefully and provide exceptional user experiences!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/#asynchronous-class-based-views
    ''',
    "is_free": False,
    "xp_reward": 90,
    "exercises": [
        {
            "id": "async-performance-system",
            "title": "Build High-Performance Async View System",
            "type": "project",
            "instructions": """Create a comprehensive async view system for a book recommendation platform:

1. Async ListView with concurrent external API calls
2. Async DetailView with multiple data enrichment sources
3. Async CreateView with external validation services
4. Error handling and fallback mechanisms
5. Performance monitoring and circuit breaker pattern

Your solution should demonstrate:
- Concurrent async operations with asyncio.gather()
- Proper error handling with try/except blocks
- Timeout management for external services
- Fallback data for service failures
- Performance monitoring and logging""",
            "starter_code": """# Install required packages first:
# pip install aiohttp asyncio

import asyncio
import aiohttp
import time
import logging
from django.views.generic import ListView, DetailView, CreateView
from asgiref.sync import sync_to_async

# Implement async views with external integrations:
# - Book recommendation service
# - Price comparison service  
# - Review aggregation service
# - Inventory checking service
# - Author social media stats

# Create views that demonstrate async performance benefits""",
            "solution": """import asyncio
import aiohttp
import time
import logging
from django.views.generic import ListView, DetailView, CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.core.cache import cache
from asgiref.sync import sync_to_async
from django.db import models

logger = logging.getLogger(__name__)

class AsyncBookRecommendationListView(ListView):
    model = Book
    template_name = 'books/async_recommendations.html'
    context_object_name = 'books'
    paginate_by = 20
    
    async def get_context_data(self, **kwargs):
        start_time = time.time()
        context = await super().get_context_data(**kwargs)
        
        # Launch multiple external API calls concurrently
        try:
            weather_task = self.get_weather_reading_suggestions()
            trending_task = self.get_trending_books()
            deals_task = self.get_book_deals()
            author_events_task = self.get_author_events()
            
            # Wait for all external calls with timeout
            weather_data, trending_data, deals_data, events_data = await asyncio.wait_for(
                asyncio.gather(
                    weather_task, trending_task, deals_task, author_events_task,
                    return_exceptions=True
                ),
                timeout=8.0  # Overall timeout for all operations
            )
            
            # Add results with error handling
            context['weather_suggestions'] = weather_data if not isinstance(weather_data, Exception) else {}
            context['trending_books'] = trending_data if not isinstance(trending_data, Exception) else []
            context['current_deals'] = deals_data if not isinstance(deals_data, Exception) else []
            context['author_events'] = events_data if not isinstance(events_data, Exception) else []
            
        except asyncio.TimeoutError:
            logger.warning('External services timeout - using fallback data')
            context.update({
                'weather_suggestions': self.get_cached_weather_suggestions(),
                'trending_books': self.get_cached_trending_books(),
                'current_deals': [],
                'author_events': []
            })
        
        # Add performance metrics
        duration = time.time() - start_time
        context['load_time'] = f'{duration:.2f}'
        logger.info(f'Async recommendation view loaded in {duration:.2f}s')
        
        return context
    
    async def get_weather_reading_suggestions(self):
        \"\"\"Get book suggestions based on current weather\"\"\"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.openweathermap.org/data/2.5/weather?q=NewYork&appid=demo',
                    timeout=aiohttp.ClientTimeout(total=3)
                ) as response:
                    weather = await response.json()
                    
                    # Suggest books based on weather
                    if weather.get('weather', [{}])[0].get('main') == 'Rain':
                        return {'suggestion': 'Cozy indoor reads', 'genre': 'mystery'}
                    else:
                        return {'suggestion': 'Adventure books', 'genre': 'adventure'}
        except Exception as e:
            logger.warning(f'Weather service failed: {str(e)}')
            return {}
    
    async def get_trending_books(self):
        \"\"\"Get currently trending books\"\"\"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.goodreads.com/trending',
                    timeout=aiohttp.ClientTimeout(total=4)
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.warning(f'Trending service failed: {str(e)}')
            return []
    
    async def get_book_deals(self):
        \"\"\"Get current book deals and promotions\"\"\"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.bookdeals.com/current',
                    timeout=aiohttp.ClientTimeout(total=3)
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.warning(f'Deals service failed: {str(e)}')
            return []
    
    async def get_author_events(self):
        \"\"\"Get upcoming author events\"\"\"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    'https://api.authorevents.com/upcoming',
                    timeout=aiohttp.ClientTimeout(total=2)
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.warning(f'Events service failed: {str(e)}')
            return []
    
    def get_cached_weather_suggestions(self):
        return cache.get('weather_suggestions', {'suggestion': 'Popular reads', 'genre': 'fiction'})
    
    def get_cached_trending_books(self):
        return cache.get('trending_books', [])

class AsyncBookDetailView(DetailView):
    model = Book
    template_name = 'books/async_detail.html'
    context_object_name = 'book'
    
    async def get_context_data(self, **kwargs):
        context = await super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Circuit breaker pattern for external services
        if self.should_call_external_services():
            try:
                # Launch multiple enrichment tasks
                enrichment_tasks = [
                    self.get_price_comparison(book.isbn),
                    self.get_external_reviews(book.isbn),
                    self.get_author_social_stats(book.author),
                    self.get_similar_books(book),
                    self.update_view_analytics(book)
                ]
                
                price_data, reviews, social_stats, similar_books, _ = await asyncio.gather(
                    *enrichment_tasks, return_exceptions=True
                )
                
                # Add enriched data
                context['price_comparison'] = price_data if not isinstance(price_data, Exception) else {}
                context['external_reviews'] = reviews if not isinstance(reviews, Exception) else []
                context['author_social'] = social_stats if not isinstance(social_stats, Exception) else {}
                context['similar_books'] = similar_books if not isinstance(similar_books, Exception) else []
                
                self.record_external_success()
                
            except Exception as e:
                logger.error(f'External enrichment failed: {str(e)}')
                self.record_external_failure()
                context.update(self.get_fallback_enrichment_data())
        else:
            context.update(self.get_fallback_enrichment_data())
        
        return context
    
    async def get_price_comparison(self, isbn):
        \"\"\"Compare prices across retailers\"\"\"
        retailers = [
            {'name': 'Amazon', 'url': 'https://api.amazon.com/price'},
            {'name': 'Barnes & Noble', 'url': 'https://api.bn.com/price'},
            {'name': 'Book Depository', 'url': 'https://api.bookdep.com/price'}
        ]
        
        async with aiohttp.ClientSession() as session:
            price_tasks = []
            for retailer in retailers:
                task = self.get_retailer_price(session, retailer, isbn)
                price_tasks.append(task)
            
            results = await asyncio.gather(*price_tasks, return_exceptions=True)
            return {'prices': [r for r in results if not isinstance(r, Exception)]}
    
    async def get_retailer_price(self, session, retailer, isbn):
        \"\"\"Get price from a specific retailer\"\"\"
        try:
            async with session.get(
                retailer['url'],
                params={'isbn': isbn},
                timeout=aiohttp.ClientTimeout(total=2)
            ) as response:
                data = await response.json()
                return {
                    'retailer': retailer['name'],
                    'price': data.get('price', 'N/A'),
                    'availability': data.get('in_stock', False)
                }
        except Exception:
            return {
                'retailer': retailer['name'],
                'price': 'N/A',
                'availability': False
            }
    
    async def get_external_reviews(self, isbn):
        \"\"\"Get reviews from external review sites\"\"\"
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://api.goodreads.com/book/reviews',
                params={'isbn': isbn},
                timeout=aiohttp.ClientTimeout(total=4)
            ) as response:
                return await response.json()
    
    async def get_author_social_stats(self, author):
        \"\"\"Get author's social media statistics\"\"\"
        if not hasattr(author, 'social_profile'):
            return {}
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://api.socialmedia.com/author-stats',
                params={'author_id': author.id},
                timeout=aiohttp.ClientTimeout(total=3)
            ) as response:
                return await response.json()
    
    async def get_similar_books(self, book):
        \"\"\"Get AI-powered book recommendations\"\"\"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.bookai.com/recommendations',
                json={
                    'book_id': book.id,
                    'title': book.title,
                    'genres': [g.name for g in book.genres.all()]
                },
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                return await response.json()
    
    async def update_view_analytics(self, book):
        \"\"\"Update view analytics asynchronously\"\"\"
        await sync_to_async(
            Book.objects.filter(pk=book.pk).update
        )(view_count=models.F('view_count') + 1)
    
    def should_call_external_services(self):
        \"\"\"Circuit breaker logic\"\"\"
        failure_count = cache.get('external_service_failures', 0)
        return failure_count < 3
    
    def record_external_success(self):
        cache.delete('external_service_failures')
    
    def record_external_failure(self):
        failures = cache.get('external_service_failures', 0) + 1
        cache.set('external_service_failures', failures, 300)  # 5 minute timeout
    
    def get_fallback_enrichment_data(self):
        return {
            'price_comparison': {'message': 'Price data temporarily unavailable'},
            'external_reviews': [],
            'author_social': {},
            'similar_books': []
        }

class AsyncBookCreateView(LoginRequiredMixin, CreateView):
    model = Book
    fields = ['title', 'isbn', 'description', 'author']
    template_name = 'books/async_create.html'
    
    async def form_valid(self, form):
        \"\"\"Validate form with external services\"\"\"
        book = form.save(commit=False)
        
        try:
            # Run external validations concurrently
            validation_tasks = [
                self.validate_isbn_exists(book.isbn),
                self.validate_content_policy(book.description),
                self.get_book_metadata(book.title, book.description)
            ]
            
            isbn_exists, content_approved, metadata = await asyncio.wait_for(
                asyncio.gather(*validation_tasks),
                timeout=10.0
            )
            
            # Check validation results
            if isbn_exists:
                form.add_error('isbn', 'This ISBN is already registered')
                return await self.form_invalid(form)
            
            if not content_approved:
                form.add_error('description', 'Content does not meet guidelines')
                return await self.form_invalid(form)
            
            # Apply AI-generated metadata
            if metadata:
                book.genre = metadata.get('predicted_genre')
                book.reading_level = metadata.get('reading_level')
                book.keywords = metadata.get('keywords', [])
            
            # Save the book
            await sync_to_async(book.save)()
            
            # Trigger background tasks (don't wait for them)
            asyncio.create_task(self.post_creation_tasks(book))
            
            messages.success(
                self.request, 
                f'Book \"{book.title}\" created successfully with AI enhancements!'
            )
            return await super().form_valid(form)
            
        except asyncio.TimeoutError:
            form.add_error(None, 'Validation services are temporarily slow. Please try again.')
            return await self.form_invalid(form)
        except Exception as e:
            logger.error(f'Book creation validation failed: {str(e)}')
            form.add_error(None, 'Validation failed. Please check your data and try again.')
            return await self.form_invalid(form)
    
    async def validate_isbn_exists(self, isbn):
        \"\"\"Check if ISBN already exists in global databases\"\"\"
        async with aiohttp.ClientSession() as session:
            async with session.get(
                'https://api.worldcat.org/isbn-check',
                params={'isbn': isbn},
                timeout=aiohttp.ClientTimeout(total=5)
            ) as response:
                data = await response.json()
                return data.get('exists', False)
    
    async def validate_content_policy(self, description):
        \"\"\"AI content moderation\"\"\"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.openai.com/v1/moderations',
                json={'input': description},
                headers={'Authorization': 'Bearer your-api-key'},
                timeout=aiohttp.ClientTimeout(total=6)
            ) as response:
                data = await response.json()
                return not data.get('results', [{}])[0].get('flagged', False)
    
    async def get_book_metadata(self, title, description):
        \"\"\"AI-powered metadata generation\"\"\"
        async with aiohttp.ClientSession() as session:
            async with session.post(
                'https://api.bookmetadata.ai/analyze',
                json={
                    'title': title,
                    'description': description
                },
                timeout=aiohttp.ClientTimeout(total=8)
            ) as response:
                return await response.json()
    
    async def post_creation_tasks(self, book):
        \"\"\"Background tasks after book creation\"\"\"
        tasks = [
            self.notify_author_network(book),
            self.generate_marketing_copy(book),
            self.update_recommendation_engine(book)
        ]
        
        await asyncio.gather(*tasks, return_exceptions=True)
    
    async def notify_author_network(self, book):
        # Implementation for notifying author's followers
        pass
    
    async def generate_marketing_copy(self, book):
        # Implementation for AI-generated marketing content
        pass
    
    async def update_recommendation_engine(self, book):
        # Implementation for updating recommendation algorithms
        pass""",
            "test_cases": [
                {
                    "name": "Async views use proper async/await syntax",
                    "input": "",
                    "expected_contains": ["async def", "await", "asyncio.gather", "aiohttp.ClientSession"]
                }
            ],
            "xp_reward": 130,
            "hints": [
                "Use asyncio.gather() to run multiple tasks concurrently",
                "Always set timeouts for external HTTP calls",
                "Implement proper error handling with try/except blocks",
                "Use sync_to_async for database operations in async views",
                "Consider circuit breaker patterns for external service resilience"
            ]
        }
    ]
}