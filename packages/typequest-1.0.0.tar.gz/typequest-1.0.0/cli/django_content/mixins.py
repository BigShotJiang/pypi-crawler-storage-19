"""
Django Mixins with Class-Based Views lesson content
"""

DJANGO_MIXINS_LESSON = {
    "id": 12,
    "chapter": 12,
    "title": "Using Mixins with Class-Based Views",
    "slug": "django-mixins",
    "content": '''
# Using Mixins with Class-Based Views: Building with LEGO Blocks

Think of mixins as specialized LEGO pieces that add specific functionality to your views. Just like you can combine different LEGO pieces to build complex structures, mixins let you combine small, focused pieces of functionality to create powerful, customized views.

## What Are Mixins? The Building Blocks of Functionality

A mixin is a class that provides a specific piece of functionality but isn't meant to be used on its own. It's designed to be combined with other classes to add capabilities.

**Real-world analogy:** Mixins are like smartphone features - camera, GPS, music player. Your phone (view) combines these features (mixins) to create a complete device, but you wouldn't use just a camera module by itself.

### The Power of Composition Over Inheritance

Instead of creating one giant class that does everything, mixins let you:
- ✅ Combine small, focused functionalities
- ✅ Reuse code across different views
- ✅ Test individual pieces separately
- ✅ Add/remove features easily

**Kitchen analogy:** Instead of having one super-appliance, you have a mixer, a blender, and a toaster that you combine as needed for different recipes.

## Django's Built-in Mixins: Your Standard Toolkit

Django provides many pre-built mixins for common web application needs:

### Authentication Mixins
```python
from django.contrib.auth.mixins import (
    LoginRequiredMixin, 
    PermissionRequiredMixin,
    UserPassesTestMixin
)

# Must be logged in
class MyProtectedView(LoginRequiredMixin, ListView):
    model = Book
    login_url = '/accounts/login/'

# Must have specific permission
class AdminOnlyView(PermissionRequiredMixin, CreateView):
    permission_required = 'books.add_book'
    model = Book
    fields = ['title', 'author']

# Custom logic test
class AuthorOnlyEditView(UserPassesTestMixin, UpdateView):
    model = Book
    fields = ['title', 'description']
    
    def test_func(self):
        book = self.get_object()
        return self.request.user == book.author
```

**Security guard analogy:** Authentication mixins are like different types of security checkpoints:
- `LoginRequiredMixin` = "Show your ID to enter"
- `PermissionRequiredMixin` = "You need VIP access for this area"
- `UserPassesTestMixin` = "Custom security check based on specific rules"

### Access Control Mixins in Action

```python
class PostEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content']
    template_name = 'blog/edit_post.html'
    
    def test_func(self):
        post = self.get_object()
        # Allow editing if user is author OR staff member
        return (
            self.request.user == post.author or 
            self.request.user.is_staff
        )
    
    def handle_no_permission(self):
        # Custom handling when test fails
        if not self.request.user.is_authenticated:
            return redirect('login')
        else:
            messages.error(self.request, "You don't have permission to edit this post.")
            return redirect('post-list')
```

### Form Mixins for Enhanced User Experience

```python
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy

class BookCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Book
    fields = ['title', 'author', 'isbn']
    success_message = "Book '%(title)s' was created successfully!"
    success_url = reverse_lazy('book-list')
    
    def get_success_message(self, cleaned_data):
        # Dynamic success message
        return f"🎉 Your book '{cleaned_data['title']}' is now available!"
```

## Creating Custom Mixins: Your Personal Toolkit

Custom mixins let you package reusable functionality for your specific application needs.

### Example 1: Ownership Mixin
```python
class OwnerRequiredMixin:
    """Ensure user owns the object they're trying to access"""
    
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        if obj.owner != self.request.user:
            raise PermissionDenied("You can only access your own items.")
        return obj

class MyBookEditView(OwnerRequiredMixin, UpdateView):
    model = Book
    fields = ['title', 'description']
```

### Example 2: Activity Tracking Mixin
```python
from django.utils import timezone

class ActivityTrackingMixin:
    """Track user activity for analytics"""
    
    def dispatch(self, request, *args, **kwargs):
        # Log the activity
        if request.user.is_authenticated:
            ActivityLog.objects.create(
                user=request.user,
                action=f"{self.__class__.__name__}",
                timestamp=timezone.now(),
                ip_address=request.META.get('REMOTE_ADDR')
            )
        return super().dispatch(request, *args, **kwargs)

class TrackedBookListView(ActivityTrackingMixin, ListView):
    model = Book
    # Now automatically logs when users view book list
```

### Example 3: Cache Optimization Mixin
```python
from django.core.cache import cache
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page

class CacheMixin:
    """Add caching functionality to views"""
    cache_timeout = 300  # 5 minutes default
    
    @method_decorator(cache_page(cache_timeout))
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

class CachedBookListView(CacheMixin, ListView):
    model = Book
    cache_timeout = 600  # Cache for 10 minutes
```

### Example 4: JSON Response Mixin
```python
import json
from django.http import JsonResponse

class JSONResponseMixin:
    """Add JSON response capabilities to views"""
    
    def render_to_json_response(self, context, **response_kwargs):
        return JsonResponse(
            self.get_data(context),
            **response_kwargs
        )
    
    def get_data(self, context):
        """Override this to customize JSON data"""
        return context

class BookAPIView(JSONResponseMixin, DetailView):
    model = Book
    
    def render_to_response(self, context, **response_kwargs):
        if self.request.headers.get('Accept') == 'application/json':
            return self.render_to_json_response(context, **response_kwargs)
        return super().render_to_response(context, **response_kwargs)
    
    def get_data(self, context):
        book = context['object']
        return {
            'title': book.title,
            'author': book.author.name,
            'isbn': book.isbn,
            'rating': book.rating
        }
```

## Advanced Mixin Patterns

### Pattern 1: Multi-Tenant Application Support
```python
class TenantMixin:
    """Filter objects by current tenant"""
    
    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(tenant=self.request.user.tenant)
    
    def form_valid(self, form):
        form.instance.tenant = self.request.user.tenant
        return super().form_valid(form)

class TenantBookListView(TenantMixin, ListView):
    model = Book  # Automatically filtered by tenant
```

### Pattern 2: Audit Trail Mixin
```python
class AuditMixin:
    """Track who created/modified objects"""
    
    def form_valid(self, form):
        if hasattr(form.instance, 'created_by') and not form.instance.pk:
            # New object - set creator
            form.instance.created_by = self.request.user
        
        if hasattr(form.instance, 'modified_by'):
            # Always set who modified it
            form.instance.modified_by = self.request.user
            
        return super().form_valid(form)

class AuditedBookCreateView(AuditMixin, CreateView):
    model = Book
    fields = ['title', 'author']
    # Automatically tracks who created the book
```

### Pattern 3: Search Functionality Mixin
```python
class SearchMixin:
    """Add search capabilities to ListView"""
    search_fields = []
    
    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q')
        
        if query and self.search_fields:
            from django.db.models import Q
            search_filter = Q()
            
            for field in self.search_fields:
                search_filter |= Q(**{f"{field}__icontains": query})
            
            queryset = queryset.filter(search_filter)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_query'] = self.request.GET.get('q', '')
        return context

class SearchableBookListView(SearchMixin, ListView):
    model = Book
    search_fields = ['title', 'author__name', 'description']
    # Now supports ?q=search_term in URL
```

## Mixin Order Matters: The Method Resolution Order (MRO)

The order of mixins in your class definition is crucial because Python follows the Method Resolution Order:

```python
# ❌ Wrong order - LoginRequiredMixin might not work as expected
class BadView(CreateView, LoginRequiredMixin):
    model = Book
    fields = ['title']

# ✅ Correct order - Mixins first, then base view
class GoodView(LoginRequiredMixin, CreateView):
    model = Book
    fields = ['title']
```

**Rule of thumb:** Mixins first, Django's base view class last.

### Understanding MRO with a Visual Example
```python
class A:
    def method(self):
        print("A's method")

class B(A):
    def method(self):
        print("B's method")
        super().method()

class C(A):
    def method(self):
        print("C's method") 
        super().method()

class D(B, C):  # MRO: D -> B -> C -> A
    pass

# Calling D().method() prints:
# B's method
# C's method  
# A's method
```

## Complex Real-World Example: E-commerce Product View

```python
class BaseEcommerceMixin:
    """Common e-commerce functionality"""
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['cart_count'] = self.get_cart_count()
        context['currency'] = self.request.session.get('currency', 'USD')
        return context
    
    def get_cart_count(self):
        if self.request.user.is_authenticated:
            return CartItem.objects.filter(user=self.request.user).count()
        return self.request.session.get('cart_count', 0)

class AnalyticsMixin:
    """Track page views for analytics"""
    
    def dispatch(self, request, *args, **kwargs):
        # Track page view
        PageView.objects.create(
            user=request.user if request.user.is_authenticated else None,
            page=request.path,
            user_agent=request.META.get('HTTP_USER_AGENT'),
            timestamp=timezone.now()
        )
        return super().dispatch(request, *args, **kwargs)

class ProductRecommendationMixin:
    """Add product recommendations"""
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        if hasattr(self, 'object') and self.object:
            # Get recommendations based on current product
            context['recommended_products'] = Product.objects.filter(
                category=self.object.category
            ).exclude(pk=self.object.pk)[:4]
        
        return context

class ProductDetailView(
    BaseEcommerceMixin,
    AnalyticsMixin, 
    ProductRecommendationMixin,
    DetailView
):
    model = Product
    template_name = 'shop/product_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Add product-specific data
        product = self.get_object()
        context['reviews'] = product.reviews.filter(is_approved=True)[:10]
        context['average_rating'] = product.get_average_rating()
        context['in_stock'] = product.inventory > 0
        
        return context
```

**This single view now has:**
- ✅ Shopping cart integration (BaseEcommerceMixin)
- ✅ Analytics tracking (AnalyticsMixin)
- ✅ Product recommendations (ProductRecommendationMixin)
- ✅ Product display (DetailView)
- ✅ Reviews and ratings (custom get_context_data)

## Testing Mixins: Ensuring Reliability

```python
from django.test import TestCase, RequestFactory
from django.contrib.auth.models import User

class ActivityTrackingMixinTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user('testuser', 'test@example.com', 'pass')
    
    def test_tracks_authenticated_user_activity(self):
        request = self.factory.get('/books/')
        request.user = self.user
        
        view = TrackedBookListView()
        view.request = request
        view.dispatch(request)
        
        # Check that activity was logged
        self.assertEqual(ActivityLog.objects.count(), 1)
        log = ActivityLog.objects.first()
        self.assertEqual(log.user, self.user)
        self.assertEqual(log.action, 'TrackedBookListView')
```

## Best Practices for Mixin Usage

### 1. Keep Mixins Focused
```python
# ✅ Good - Single responsibility
class TimestampMixin:
    """Add created/updated timestamps"""
    pass

class OwnershipMixin:
    """Handle object ownership"""
    pass

# ❌ Bad - Too many responsibilities  
class EverythingMixin:
    """Timestamps, ownership, caching, analytics..."""
    pass
```

### 2. Use Descriptive Names
```python
# ✅ Clear purpose
class PermissionRequiredMixin
class SuccessMessageMixin  
class JSONResponseMixin

# ❌ Unclear purpose
class HelperMixin
class UtilsMixin
class BaseMixin
```

### 3. Document Your Mixins
```python
class CacheMixin:
    """
    Adds view-level caching functionality.
    
    Attributes:
        cache_timeout: Cache duration in seconds (default: 300)
        
    Usage:
        class MyView(CacheMixin, ListView):
            cache_timeout = 600  # Override default
    """
    cache_timeout = 300
```

### 4. Provide Sensible Defaults
```python
class PaginationMixin:
    """Add pagination with reasonable defaults"""
    paginate_by = 20  # Good default
    paginate_orphans = 5  # Prevent tiny last pages
    
    def get_paginate_by(self, queryset):
        # Allow runtime customization
        return self.request.GET.get('per_page', self.paginate_by)
```

## Common Pitfalls and Solutions

### Pitfall 1: Mixin Order Issues
```python
# ❌ Wrong - PermissionRequiredMixin might not work
class BadView(CreateView, PermissionRequiredMixin):
    pass

# ✅ Correct - Mixins before base view
class GoodView(PermissionRequiredMixin, CreateView):
    pass
```

### Pitfall 2: Forgetting super() Calls
```python
# ❌ Breaks the mixin chain
class BrokenMixin:
    def get_context_data(self, **kwargs):
        context = {}  # Missing super() call!
        context['my_data'] = 'value'
        return context

# ✅ Properly chains to next mixin
class WorkingMixin:
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['my_data'] = 'value'
        return context
```

### Pitfall 3: Mixin Conflicts
```python
# Both mixins override the same method - potential conflict
class MixinA:
    def get_queryset(self):
        return super().get_queryset().filter(active=True)

class MixinB: 
    def get_queryset(self):
        return super().get_queryset().filter(featured=True)

# Solution: Create a combined mixin
class ActiveFeaturedMixin:
    def get_queryset(self):
        return super().get_queryset().filter(active=True, featured=True)
```

## Practice Exercise: Build a Complete Mixin System

Create a blog system with these mixins:
1. `AuthorRequiredMixin` - Only post authors can edit
2. `DraftMixin` - Handle draft vs published posts
3. `ViewCountMixin` - Track post popularity
4. `SlugGenerationMixin` - Auto-generate slugs
5. `SEODataMixin` - Add meta descriptions and keywords

This will give you hands-on experience building a real mixin architecture!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/mixins/
    ''',
    "is_free": False,
    "xp_reward": 70,
    "exercises": [
        {
            "id": "blog-mixin-system",
            "title": "Build Complete Blog Mixin System",
            "type": "project",
            "instructions": """Create a comprehensive blog system using custom mixins:

1. AuthorRequiredMixin - Ensure only post authors can edit their posts
2. DraftMixin - Handle draft vs published post logic
3. ViewCountMixin - Track and display post popularity
4. SlugGenerationMixin - Auto-generate SEO-friendly URLs
5. SEODataMixin - Add meta descriptions for search engines

Your solution should demonstrate:
- Proper mixin composition and ordering
- Method chaining with super() calls
- Reusable, focused functionality
- Real-world business logic
- Testing considerations""",
            "starter_code": """# models.py (provided)
class Post(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True, blank=True)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    is_published = models.BooleanField(default=False)
    view_count = models.PositiveIntegerField(default=0)
    meta_description = models.TextField(max_length=160, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

# Implement the mixins and views below:""",
            "solution": """from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.utils.text import slugify
from django.shortcuts import get_object_or_404
from django.db.models import F

class AuthorRequiredMixin(UserPassesTestMixin):
    \"\"\"Ensure only post authors can access their posts\"\"\"
    
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author

class DraftMixin:
    \"\"\"Handle draft vs published post logic\"\"\"
    
    def get_queryset(self):
        queryset = super().get_queryset()
        user = self.request.user
        
        if user.is_authenticated and hasattr(self, 'show_drafts') and self.show_drafts:
            # Show user's drafts
            return queryset.filter(author=user)
        else:
            # Only show published posts
            return queryset.filter(is_published=True)

class ViewCountMixin:
    \"\"\"Track post popularity\"\"\"
    
    def get_object(self, queryset=None):
        obj = super().get_object(queryset)
        
        # Increment view count (avoid counting author views)
        if hasattr(obj, 'view_count') and self.request.user != obj.author:
            Post.objects.filter(pk=obj.pk).update(view_count=F('view_count') + 1)
            obj.refresh_from_db()
        
        return obj

class SlugGenerationMixin:
    \"\"\"Auto-generate SEO-friendly slugs\"\"\"
    
    def form_valid(self, form):
        if not form.instance.slug and hasattr(form.instance, 'title'):
            base_slug = slugify(form.instance.title)
            slug = base_slug
            counter = 1
            
            # Ensure unique slug
            while Post.objects.filter(slug=slug).exists():
                slug = f\"{base_slug}-{counter}\"
                counter += 1
            
            form.instance.slug = slug
        
        return super().form_valid(form)

class SEODataMixin:
    \"\"\"Add meta descriptions for search engines\"\"\"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        if hasattr(self, 'object') and self.object:
            # Auto-generate meta description if empty
            if not self.object.meta_description:
                content_words = self.object.content.split()[:20]
                context['meta_description'] = ' '.join(content_words) + '...'
            else:
                context['meta_description'] = self.object.meta_description
        
        return context

# Example usage combining mixins
class PostDetailView(ViewCountMixin, SEODataMixin, DetailView):
    model = Post
    template_name = 'blog/post_detail.html'
    context_object_name = 'post'

class PostUpdateView(
    LoginRequiredMixin,
    AuthorRequiredMixin, 
    SlugGenerationMixin,
    UpdateView
):
    model = Post
    fields = ['title', 'content', 'is_published', 'meta_description']
    template_name = 'blog/post_update.html'

class PostListView(DraftMixin, ListView):
    model = Post
    template_name = 'blog/post_list.html'
    context_object_name = 'posts'
    paginate_by = 10
    ordering = ['-created_at']

class MyDraftsView(DraftMixin, ListView):
    model = Post
    template_name = 'blog/my_drafts.html'
    context_object_name = 'posts'
    show_drafts = True  # Enable draft viewing
    
    def get_queryset(self):
        return super().get_queryset().filter(is_published=False)""",
            "test_cases": [
                {
                    "name": "Mixins properly chain with super() calls",
                    "input": "",
                    "expected_contains": ["super().get_object", "super().form_valid", "super().get_context_data"]
                }
            ],
            "xp_reward": 100,
            "hints": [
                "Remember mixin order: custom mixins first, base view last",
                "Always call super() to maintain the method chain",
                "Use F expressions for atomic database updates",
                "Make mixins focused on single responsibilities",
                "Test edge cases like duplicate slugs"
            ]
        }
    ]
}