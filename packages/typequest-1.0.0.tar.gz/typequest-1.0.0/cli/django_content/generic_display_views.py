"""
Django Generic Display Views lesson content
"""

DJANGO_GENERIC_DISPLAY_LESSON = {
    "id": 10,
    "chapter": 10,
    "title": "Built-in Generic Display Views",
    "slug": "generic-display-views",
    "content": '''
# Built-in Generic Display Views: Your Pre-Built View Components

Imagine Django as a furniture store where instead of building chairs and tables from scratch, you can pick from beautifully crafted, ready-to-use pieces and just customize the upholstery and finish. Generic display views are Django's furniture collection for displaying data!

## The Power of Generic Views: Standing on Giants' Shoulders

Generic views solve the 80% of common web development tasks that every developer faces:
- Show a list of blog posts
- Display product details
- Create a user profile page
- Build a photo gallery

Instead of writing these patterns over and over, Django provides pre-built, battle-tested solutions that you can customize to your heart's content.

**The Magic:** You describe WHAT you want (show books), not HOW to do it (query database, handle pagination, render template). Django figures out the HOW.

## TemplateView: The Foundation Stone

`TemplateView` is like a blank canvas - perfect for static pages that don't need database data but want to use Django's template system.

### Basic TemplateView Usage
```python
from django.views.generic import TemplateView

class HomeView(TemplateView):
    template_name = 'home.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['welcome_message'] = 'Welcome to our amazing website!'
        context['features'] = ['Fast', 'Reliable', 'Beautiful']
        return context
```

**Perfect for:**
- Home pages
- About us pages  
- Static content with dynamic elements
- Landing pages

### Real-World TemplateView Example: Company About Page
```python
class AboutView(TemplateView):
    template_name = 'company/about.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'company_name': 'TechCorp',
            'founded_year': 2020,
            'employee_count': 50,
            'office_locations': ['New York', 'San Francisco', 'London'],
            'mission': 'Making technology accessible to everyone'
        })
        return context
```

**Template (about.html):**
```html
<div class="hero">
    <h1>About {{ company_name }}</h1>
    <p>{{ mission }}</p>
</div>

<div class="stats">
    <div class="stat">
        <h3>{{ founded_year }}</h3>
        <p>Founded</p>
    </div>
    <div class="stat">
        <h3>{{ employee_count }}+</h3>
        <p>Team Members</p>
    </div>
</div>

<div class="locations">
    <h2>Our Offices</h2>
    {% for location in office_locations %}
        <span class="location">{{ location }}</span>
    {% endfor %}
</div>
```

## ListView: The Data Showcase Master

`ListView` is like a museum curator who knows exactly how to display collections beautifully. Give it a model, and it handles querying, pagination, and presentation.

### Basic ListView Magic
```python
from django.views.generic import ListView
from .models import Book

class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    context_object_name = 'books'
    paginate_by = 12
```

**That's it!** This view automatically:
- Queries all Book objects
- Paginates results (12 per page)
- Handles page navigation
- Passes data to template as 'books'

### Advanced ListView Customization

#### Filtering and Ordering
```python
class PopularBooksView(ListView):
    model = Book
    template_name = 'books/popular.html'
    context_object_name = 'books'
    paginate_by = 10
    ordering = ['-rating', '-publication_date']
    
    def get_queryset(self):
        return Book.objects.filter(
            rating__gte=4.0,
            is_available=True
        ).select_related('author')
```

**Library analogy:** Instead of showing every book in the library, you're curating a "Staff Picks" section with only highly-rated, available books, sorted by rating.

#### Dynamic Filtering Based on URL Parameters
```python
class BooksByCategoryView(ListView):
    model = Book
    template_name = 'books/category.html'
    context_object_name = 'books'
    paginate_by = 15
    
    def get_queryset(self):
        category = self.kwargs['category']
        return Book.objects.filter(
            category__slug=category
        ).order_by('-publication_date')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['category'] = self.kwargs['category']
        context['total_books'] = self.get_queryset().count()
        return context
```

**URL Configuration:**
```python
# urls.py
path('books/category/<str:category>/', 
     BooksByCategoryView.as_view(), 
     name='books-by-category')
```

### ListView Template Power

**Template (books/list.html):**
```html
<div class="books-header">
    <h1>Our Book Collection</h1>
    <p>Discover amazing stories from {{ books|length }} books</p>
</div>

<div class="books-grid">
    {% for book in books %}
        <div class="book-card">
            <img src="{{ book.cover_image.url }}" alt="{{ book.title }}">
            <h3>{{ book.title }}</h3>
            <p>by {{ book.author.name }}</p>
            <div class="rating">
                {% for i in "12345" %}
                    {% if forloop.counter <= book.rating %}
                        ⭐
                    {% endif %}
                {% endfor %}
            </div>
            <a href="{% url 'book-detail' book.pk %}">Read More</a>
        </div>
    {% empty %}
        <p>No books available at the moment.</p>
    {% endfor %}
</div>

<!-- Pagination -->
{% if is_paginated %}
    <div class="pagination">
        <span class="page-info">
            Page {{ page_obj.number }} of {{ page_obj.paginator.num_pages }}
        </span>
        
        {% if page_obj.has_previous %}
            <a href="?page=1" class="page-link">« First</a>
            <a href="?page={{ page_obj.previous_page_number }}" class="page-link">‹ Prev</a>
        {% endif %}
        
        {% if page_obj.has_next %}
            <a href="?page={{ page_obj.next_page_number }}" class="page-link">Next ›</a>
            <a href="?page={{ page_obj.paginator.num_pages }}" class="page-link">Last »</a>
        {% endif %}
    </div>
{% endif %}
```

## DetailView: The Spotlight Expert

`DetailView` is like a museum guide who specializes in one exhibit, knowing every detail and presenting it perfectly. It takes a single object and displays it beautifully.

### Basic DetailView Usage
```python
class BookDetailView(DetailView):
    model = Book
    template_name = 'books/detail.html'
    context_object_name = 'book'
```

**Automatic Magic:**
- Finds book by primary key (pk) from URL
- Handles 404 if book doesn't exist
- Passes book object to template

### Enhanced DetailView with Related Data
```python
class BookDetailView(DetailView):
    model = Book
    template_name = 'books/detail.html'
    context_object_name = 'book'
    
    def get_queryset(self):
        return Book.objects.select_related('author', 'publisher').prefetch_related(
            'reviews', 'categories'
        )
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        
        # Add related data
        context['related_books'] = Book.objects.filter(
            author=book.author
        ).exclude(pk=book.pk)[:5]
        
        context['recent_reviews'] = book.reviews.filter(
            is_approved=True
        ).order_by('-created_at')[:10]
        
        context['average_rating'] = book.reviews.aggregate(
            avg_rating=models.Avg('rating')
        )['avg_rating'] or 0
        
        return context
```

### DetailView Template Showcase

**Template (books/detail.html):**
```html
<article class="book-detail">
    <header class="book-header">
        <div class="book-cover">
            <img src="{{ book.cover_image.url }}" alt="{{ book.title }}">
        </div>
        <div class="book-info">
            <h1>{{ book.title }}</h1>
            <h2>by {{ book.author.name }}</h2>
            
            <div class="book-meta">
                <p><strong>Publisher:</strong> {{ book.publisher.name }}</p>
                <p><strong>Published:</strong> {{ book.publication_date|date:"F j, Y" }}</p>
                <p><strong>Pages:</strong> {{ book.page_count }}</p>
                <p><strong>Rating:</strong> {{ average_rating|floatformat:1 }}/5</p>
            </div>
            
            <div class="book-categories">
                {% for category in book.categories.all %}
                    <span class="category-tag">{{ category.name }}</span>
                {% endfor %}
            </div>
        </div>
    </header>
    
    <section class="book-description">
        <h3>About This Book</h3>
        <p>{{ book.description|linebreaks }}</p>
    </section>
    
    <section class="related-books">
        <h3>More by {{ book.author.name }}</h3>
        <div class="related-books-grid">
            {% for related_book in related_books %}
                <div class="mini-book-card">
                    <img src="{{ related_book.cover_image.url }}" alt="{{ related_book.title }}">
                    <h4><a href="{% url 'book-detail' related_book.pk %}">{{ related_book.title }}</a></h4>
                </div>
            {% endfor %}
        </div>
    </section>
    
    <section class="reviews">
        <h3>Recent Reviews</h3>
        {% for review in recent_reviews %}
            <div class="review">
                <div class="review-header">
                    <strong>{{ review.reviewer_name }}</strong>
                    <span class="rating">{{ review.rating }}/5</span>
                    <span class="date">{{ review.created_at|date:"M j, Y" }}</span>
                </div>
                <p>{{ review.content|truncatewords:50 }}</p>
            </div>
        {% empty %}
            <p>No reviews yet. Be the first to review!</p>
        {% endfor %}
    </section>
</article>
```

## Advanced Patterns and Best Practices

### Pattern 1: Search and Filter Integration
```python
class BookSearchView(ListView):
    model = Book
    template_name = 'books/search.html'
    context_object_name = 'books'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = Book.objects.all()
        query = self.request.GET.get('q')
        category = self.request.GET.get('category')
        min_rating = self.request.GET.get('min_rating')
        
        if query:
            queryset = queryset.filter(
                Q(title__icontains=query) | 
                Q(author__name__icontains=query) |
                Q(description__icontains=query)
            )
        
        if category:
            queryset = queryset.filter(categories__slug=category)
            
        if min_rating:
            queryset = queryset.filter(rating__gte=min_rating)
            
        return queryset.distinct().order_by('-publication_date')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['query'] = self.request.GET.get('q', '')
        context['selected_category'] = self.request.GET.get('category', '')
        context['categories'] = Category.objects.all()
        context['search_count'] = self.get_queryset().count()
        return context
```

### Pattern 2: Multiple Object Types in One View
```python
class DashboardView(TemplateView):
    template_name = 'dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Gather data from multiple models
        context['recent_books'] = Book.objects.filter(
            publication_date__gte=timezone.now() - timedelta(days=30)
        )[:5]
        
        context['popular_authors'] = Author.objects.annotate(
            book_count=Count('books')
        ).order_by('-book_count')[:10]
        
        context['featured_categories'] = Category.objects.filter(
            is_featured=True
        )
        
        context['stats'] = {
            'total_books': Book.objects.count(),
            'total_authors': Author.objects.count(),
            'books_this_month': Book.objects.filter(
                publication_date__month=timezone.now().month
            ).count()
        }
        
        return context
```

## Performance Optimization Tips

### 1. Use select_related and prefetch_related
```python
class OptimizedBookListView(ListView):
    model = Book
    
    def get_queryset(self):
        return Book.objects.select_related(
            'author', 'publisher'
        ).prefetch_related(
            'categories', 'reviews'
        )
```

### 2. Cache Expensive Queries
```python
from django.core.cache import cache

class BookStatsView(TemplateView):
    template_name = 'books/stats.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Cache expensive aggregations
        stats = cache.get('book_stats')
        if stats is None:
            stats = {
                'total_books': Book.objects.count(),
                'avg_rating': Book.objects.aggregate(
                    avg=models.Avg('rating')
                )['avg'],
                'popular_categories': Category.objects.annotate(
                    book_count=Count('books')
                ).order_by('-book_count')[:5]
            }
            cache.set('book_stats', stats, 300)  # Cache for 5 minutes
            
        context['stats'] = stats
        return context
```

## Common Pitfalls and Solutions

### Pitfall 1: Forgetting context_object_name
```python
# ❌ Template will use default 'object_list'
class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'

# ✅ Template uses readable 'books'
class BookListView(ListView):
    model = Book
    template_name = 'books/list.html'
    context_object_name = 'books'
```

### Pitfall 2: Not handling empty querysets
```html
<!-- ❌ No empty state -->
{% for book in books %}
    <div>{{ book.title }}</div>
{% endfor %}

<!-- ✅ Handles empty state -->
{% for book in books %}
    <div>{{ book.title }}</div>
{% empty %}
    <p>No books found. <a href="{% url 'book-create' %}">Add one!</a></p>
{% endfor %}
```

## Practice Exercise: Build a Complete Display System

Create a book library system with:
1. Home page (TemplateView)
2. All books list (ListView) 
3. Books by category (ListView with filtering)
4. Book details (DetailView)
5. Author profile with their books

This exercise will reinforce all the concepts and prepare you for building real applications!

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/class-based-views/generic-display/
    ''',
    "is_free": False,
    "xp_reward": 75,
    "exercises": [
        {
            "id": "library-display-system",
            "title": "Build a Complete Book Library Display System",
            "type": "project",
            "instructions": """Create a comprehensive book library system using generic display views:

1. Home page showing featured books and statistics
2. Complete book list with pagination and search
3. Category-based book filtering
4. Detailed book view with related books and reviews
5. Author profile pages

Your solution should demonstrate:
- TemplateView for static pages
- ListView with pagination and filtering
- DetailView with context enrichment
- Proper template organization
- Performance optimization techniques""",
            "starter_code": """# models.py (provided)
class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    
class Author(models.Model):
    name = models.CharField(max_length=200)
    bio = models.TextField()
    
class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    categories = models.ManyToManyField(Category)
    description = models.TextField()
    rating = models.DecimalField(max_digits=3, decimal_places=2)
    publication_date = models.DateField()
    is_featured = models.BooleanField(default=False)

# Implement the views below:""",
            "solution": """from django.views.generic import TemplateView, ListView, DetailView
from django.db.models import Q, Count, Avg
from django.utils import timezone
from datetime import timedelta

class HomeView(TemplateView):
    template_name = 'library/home.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'featured_books': Book.objects.filter(is_featured=True)[:6],
            'recent_books': Book.objects.filter(
                publication_date__gte=timezone.now() - timedelta(days=30)
            )[:5],
            'stats': {
                'total_books': Book.objects.count(),
                'total_authors': Author.objects.count(),
                'avg_rating': Book.objects.aggregate(avg=Avg('rating'))['avg']
            }
        })
        return context

class BookListView(ListView):
    model = Book
    template_name = 'library/book_list.html'
    context_object_name = 'books'
    paginate_by = 12
    
    def get_queryset(self):
        queryset = Book.objects.select_related('author').prefetch_related('categories')
        query = self.request.GET.get('q')
        if query:
            queryset = queryset.filter(
                Q(title__icontains=query) | Q(author__name__icontains=query)
            )
        return queryset.order_by('-publication_date')

class BooksByCategoryView(ListView):
    model = Book
    template_name = 'library/books_by_category.html'
    context_object_name = 'books'
    paginate_by = 15
    
    def get_queryset(self):
        return Book.objects.filter(
            categories__slug=self.kwargs['category_slug']
        ).select_related('author')

class BookDetailView(DetailView):
    model = Book
    template_name = 'library/book_detail.html'
    context_object_name = 'book'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        book = self.get_object()
        context['related_books'] = Book.objects.filter(
            author=book.author
        ).exclude(pk=book.pk)[:5]
        return context

class AuthorDetailView(DetailView):
    model = Author
    template_name = 'library/author_detail.html'
    context_object_name = 'author'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        author = self.get_object()
        context['author_books'] = Book.objects.filter(
            author=author
        ).order_by('-publication_date')
        return context""",
            "test_cases": [
                {
                    "name": "Views use proper generic base classes",
                    "input": "",
                    "expected_contains": ["TemplateView", "ListView", "DetailView", "get_context_data"]
                }
            ],
            "xp_reward": 100,
            "hints": [
                "Use select_related and prefetch_related for performance",
                "Add search functionality with Q objects",
                "Don't forget pagination with paginate_by",
                "Use context_object_name for readable template variables"
            ]
        }
    ]
}