"""
Django Foundations - Lesson 3: Django Admin Commands and Management
Master Django's command-line interface for development and deployment
"""

DJANGO_ADMIN_COMMANDS_LESSON = {
    "id": 3,
    "chapter": 3,
    "title": "Django Admin Commands: Command-Line Mastery",
    "slug": "django-admin-commands",
    "description": "Master Django's built-in management commands for development, deployment, database management, and project administration",
    "content": '''# Django Admin Commands: Command-Line Mastery

## 🎯 Django's Powerful Command-Line Interface

**Django admin commands** are your Swiss Army knife for Django development - they handle everything from creating projects to managing databases, running tests, and deploying applications. These commands are essential for **development workflows and production operations**.

**Why Django Commands Matter**:
- **Project lifecycle management** → From creation to deployment and maintenance
- **Database operations** → Migrations, data loading, and backup operations
- **Development efficiency** → Testing, debugging, and development server management
- **Production deployment** → Static file collection, user management, and system maintenance
- **Automation and scripting** → Integrate Django operations into CI/CD pipelines

Companies like **Instagram, Pinterest, and Mozilla** rely heavily on Django commands for their development workflows and production operations.

## 💾 Django Commands Usage Database

Let's explore Django's command ecosystem and usage patterns:

```sql
-- DJANGO ADMIN COMMANDS AND USAGE
-- Database: django_commands_usage

-- Core Django management commands
CREATE TABLE django_commands (
    id SERIAL PRIMARY KEY,
    command_name VARCHAR(100) NOT NULL,
    command_category VARCHAR(50) NOT NULL, -- 'project', 'database', 'development', 'testing', 'deployment', 'user_management'
    description TEXT NOT NULL,
    django_app VARCHAR(100), -- Which Django app provides this command
    is_built_in BOOLEAN DEFAULT TRUE,
    is_production_safe BOOLEAN DEFAULT TRUE,
    requires_database BOOLEAN DEFAULT FALSE,
    requires_settings BOOLEAN DEFAULT TRUE,
    common_usage_frequency VARCHAR(20) DEFAULT 'medium', -- 'high', 'medium', 'low'
    introduced_in_version VARCHAR(20),
    deprecated_in_version VARCHAR(20),
    example_usage TEXT,
    common_options TEXT[],
    output_type VARCHAR(50) DEFAULT 'text' -- 'text', 'json', 'files', 'database_changes'
);

-- Sample Django built-in commands (comprehensive list)
INSERT INTO django_commands (command_name, command_category, description, django_app, requires_database, common_usage_frequency, example_usage, common_options) VALUES
-- Project management
('startproject', 'project', 'Creates a new Django project directory structure', 'django.core', FALSE, 'high', 'django-admin startproject mysite', ARRAY['--template', '--extension', '--name']),
('startapp', 'project', 'Creates a new Django application directory structure', 'django.core', FALSE, 'high', 'python manage.py startapp blog', ARRAY['--template', '--extension', '--name']),

-- Database commands
('migrate', 'database', 'Applies database migrations', 'django.core', TRUE, 'high', 'python manage.py migrate', ARRAY['--fake', '--fake-initial', '--run-syncdb', '--database']),
('makemigrations', 'database', 'Creates new migration files for model changes', 'django.core', TRUE, 'high', 'python manage.py makemigrations', ARRAY['--dry-run', '--merge', '--empty', '--name']),
('showmigrations', 'database', 'Shows all migrations and their status', 'django.core', TRUE, 'medium', 'python manage.py showmigrations', ARRAY['--list', '--plan', '--database']),
('sqlmigrate', 'database', 'Prints SQL for a specific migration', 'django.core', TRUE, 'medium', 'python manage.py sqlmigrate blog 0001', ARRAY['--database', '--backwards']),
('dbshell', 'database', 'Opens database command-line client', 'django.core', TRUE, 'medium', 'python manage.py dbshell', ARRAY['--database']),

-- Development commands
('runserver', 'development', 'Starts Django development server', 'django.core', FALSE, 'high', 'python manage.py runserver', ARRAY['--noreload', '--nothreading', '--ipv6', '--insecure']),
('shell', 'development', 'Opens interactive Python shell with Django environment', 'django.core', TRUE, 'high', 'python manage.py shell', ARRAY['--interface', '--no-startup', '--command']),
('check', 'development', 'Checks for potential problems in Django project', 'django.core', FALSE, 'high', 'python manage.py check', ARRAY['--tag', '--list-tags', '--deploy', '--fail-level']),

-- Testing commands
('test', 'testing', 'Runs tests for Django applications', 'django.core', TRUE, 'high', 'python manage.py test', ARRAY['--pattern', '--top-level-directory', '--keepdb', '--parallel', '--debug-mode']),

-- User management
('createsuperuser', 'user_management', 'Creates an admin user account', 'django.contrib.auth', TRUE, 'medium', 'python manage.py createsuperuser', ARRAY['--username', '--email', '--noinput']),
('changepassword', 'user_management', 'Changes password for specified user', 'django.contrib.auth', TRUE, 'low', 'python manage.py changepassword admin', ARRAY['--database']),

-- Static files
('collectstatic', 'deployment', 'Collects static files into STATIC_ROOT', 'django.contrib.staticfiles', FALSE, 'high', 'python manage.py collectstatic', ARRAY['--noinput', '--clear', '--link', '--dry-run']),
('findstatic', 'development', 'Finds absolute paths for given static files', 'django.contrib.staticfiles', FALSE, 'low', 'python manage.py findstatic css/base.css', ARRAY['--first']),

-- Internationalization
('makemessages', 'development', 'Extracts translatable strings for internationalization', 'django.core', FALSE, 'medium', 'python manage.py makemessages -l es', ARRAY['--locale', '--domain', '--extension', '--ignore']),
('compilemessages', 'deployment', 'Compiles .po files to .mo files for translation', 'django.core', FALSE, 'medium', 'python manage.py compilemessages', ARRAY['--locale', '--exclude', '--use-fuzzy']),

-- Content types and sessions
('remove_stale_contenttypes', 'database', 'Removes stale content types', 'django.contrib.contenttypes', TRUE, 'low', 'python manage.py remove_stale_contenttypes', ARRAY['--noinput']),
('clearsessions', 'database', 'Removes expired session records', 'django.contrib.sessions', TRUE, 'medium', 'python manage.py clearsessions', ARRAY[]);

-- Command usage statistics across different environments
CREATE TABLE django_command_usage (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    environment VARCHAR(50) NOT NULL, -- 'development', 'staging', 'production', 'ci_cd'
    usage_frequency INTEGER DEFAULT 0, -- Times used per week
    success_rate DECIMAL(5,2) DEFAULT 100.00,
    avg_execution_time_seconds DECIMAL(8,2) DEFAULT 0,
    common_errors TEXT[],
    automation_level VARCHAR(20) DEFAULT 'manual', -- 'manual', 'scripted', 'automated'
    team_role VARCHAR(50), -- 'developer', 'devops', 'admin', 'qa'
    last_used DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (command_id) REFERENCES django_commands(id)
);

-- Sample usage statistics (like Instagram's development practices)
INSERT INTO django_command_usage (command_id, environment, usage_frequency, success_rate, avg_execution_time_seconds, automation_level, team_role) VALUES
-- startproject and startapp (development)
(1, 'development', 2, 100.00, 5.2, 'manual', 'developer'),
(2, 'development', 8, 99.50, 2.8, 'manual', 'developer'),

-- migrate commands (all environments)
(3, 'development', 25, 98.50, 15.6, 'manual', 'developer'),
(3, 'staging', 5, 99.80, 45.2, 'scripted', 'devops'),
(3, 'production', 3, 99.95, 180.7, 'automated', 'devops'),
(4, 'development', 20, 95.00, 8.3, 'manual', 'developer'),
(4, 'ci_cd', 50, 98.00, 12.1, 'automated', 'devops'),

-- runserver (development only)
(8, 'development', 100, 99.00, 0.5, 'manual', 'developer'),

-- test commands
(11, 'development', 40, 92.00, 45.8, 'manual', 'developer'),
(11, 'ci_cd', 200, 95.50, 120.3, 'automated', 'qa'),

-- collectstatic (deployment)
(14, 'staging', 10, 99.00, 25.4, 'scripted', 'devops'),
(14, 'production', 5, 99.80, 78.9, 'automated', 'devops');

-- Command execution logs and monitoring
CREATE TABLE django_command_logs (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    execution_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    environment VARCHAR(50) NOT NULL,
    user_role VARCHAR(50),
    execution_time_seconds DECIMAL(8,2),
    exit_code INTEGER DEFAULT 0,
    success BOOLEAN DEFAULT TRUE,
    command_line TEXT NOT NULL,
    output_size_kb INTEGER DEFAULT 0,
    error_message TEXT,
    database_changed BOOLEAN DEFAULT FALSE,
    files_created INTEGER DEFAULT 0,
    files_modified INTEGER DEFAULT 0,
    memory_usage_mb DECIMAL(8,2),
    FOREIGN KEY (command_id) REFERENCES django_commands(id)
);

-- Sample command execution logs
INSERT INTO django_command_logs (command_id, environment, user_role, execution_time_seconds, command_line, output_size_kb, database_changed, files_created) VALUES
(2, 'development', 'developer', 2.34, 'python manage.py startapp accounts', 0.5, FALSE, 8),
(4, 'development', 'developer', 5.67, 'python manage.py makemigrations accounts', 0.2, FALSE, 1),
(3, 'development', 'developer', 12.45, 'python manage.py migrate', 1.2, TRUE, 0),
(8, 'development', 'developer', 0.45, 'python manage.py runserver 8000', 0.1, FALSE, 0),
(11, 'ci_cd', 'qa', 78.92, 'python manage.py test --parallel 4', 15.6, FALSE, 0),
(14, 'production', 'devops', 45.78, 'python manage.py collectstatic --noinput', 2.3, FALSE, 1247);

-- Command best practices and patterns
CREATE TABLE django_command_patterns (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    pattern_name VARCHAR(100) NOT NULL,
    pattern_type VARCHAR(50) NOT NULL, -- 'best_practice', 'anti_pattern', 'optimization', 'security'
    description TEXT NOT NULL,
    example_good TEXT,
    example_bad TEXT,
    risk_level VARCHAR(20) DEFAULT 'low', -- 'low', 'medium', 'high', 'critical'
    applies_to_environments TEXT[] DEFAULT ARRAY['all'],
    recommendation TEXT,
    FOREIGN KEY (command_id) REFERENCES django_commands(id)
);

-- Sample patterns and best practices
INSERT INTO django_command_patterns (command_id, pattern_name, pattern_type, description, example_good, example_bad, risk_level, applies_to_environments, recommendation) VALUES
(3, 'Zero-downtime migrations', 'best_practice', 'Use migration strategies that don''t lock database tables', 'python manage.py migrate --database=replica', 'python manage.py migrate (on production with traffic)', 'high', ARRAY['production'], 'Always test migrations on staging first and consider zero-downtime strategies'),
(8, 'Development server security', 'security', 'Never use runserver in production', 'Use gunicorn/uwsgi in production', 'python manage.py runserver 0.0.0.0:8000 in production', 'critical', ARRAY['production'], 'Always use proper WSGI server in production environments'),
(11, 'Parallel testing', 'optimization', 'Use parallel testing for faster test execution', 'python manage.py test --parallel auto', 'python manage.py test (single threaded)', 'low', ARRAY['development', 'ci_cd'], 'Use parallel testing to reduce CI/CD pipeline times'),
(14, 'Static files collection', 'best_practice', 'Always use --noinput in automated deployments', 'python manage.py collectstatic --noinput', 'python manage.py collectstatic (prompts for input)', 'medium', ARRAY['production', 'staging'], 'Use --noinput flag in deployment scripts to avoid hanging'),
(4, 'Migration naming', 'best_practice', 'Use descriptive names for migrations', 'python manage.py makemigrations --name add_user_email_index', 'python manage.py makemigrations (auto-generated name)', 'low', ARRAY['all'], 'Use descriptive migration names for better tracking and debugging');

-- Command options and flags detailed reference
CREATE TABLE django_command_options (
    id SERIAL PRIMARY KEY,
    command_id INTEGER NOT NULL,
    option_name VARCHAR(100) NOT NULL,
    option_type VARCHAR(20) NOT NULL, -- 'flag', 'value', 'choice'
    is_required BOOLEAN DEFAULT FALSE,
    default_value TEXT,
    choices TEXT[], -- For choice-type options
    description TEXT NOT NULL,
    example_usage TEXT,
    security_implications TEXT,
    performance_impact VARCHAR(20) DEFAULT 'none', -- 'none', 'low', 'medium', 'high'
    FOREIGN KEY (command_id) REFERENCES django_commands(id)
);

-- Sample detailed options for key commands
INSERT INTO django_command_options (command_id, option_name, option_type, description, example_usage, performance_impact, security_implications) VALUES
-- migrate command options
(3, '--fake', 'flag', 'Mark migrations as run without actually executing SQL', 'python manage.py migrate --fake', 'high', 'Can cause database inconsistencies if misused'),
(3, '--fake-initial', 'flag', 'Mark initial migrations as run for existing databases', 'python manage.py migrate --fake-initial', 'medium', 'Safe for initial setup of existing databases'),
(3, '--database', 'value', 'Specify database alias to migrate', 'python manage.py migrate --database=analytics', 'none', 'Ensure proper database permissions'),

-- runserver options
(8, '--noreload', 'flag', 'Disable auto-reload of server on file changes', 'python manage.py runserver --noreload', 'medium', 'None - development only'),
(8, '--insecure', 'flag', 'Serve static files even when DEBUG=False', 'python manage.py runserver --insecure', 'low', 'Never use in production - security risk'),

-- test command options
(11, '--keepdb', 'flag', 'Preserve test database between test runs', 'python manage.py test --keepdb', 'high', 'Faster test runs but may hide database-related issues'),
(11, '--parallel', 'value', 'Run tests in parallel using specified processes', 'python manage.py test --parallel 4', 'high', 'Faster tests but may mask race conditions'),
(11, '--debug-mode', 'flag', 'Turn on debug mode for tests', 'python manage.py test --debug-mode', 'low', 'May expose sensitive information in test output'),

-- collectstatic options
(14, '--noinput', 'flag', 'Do not prompt for user input', 'python manage.py collectstatic --noinput', 'none', 'Essential for automated deployments'),
(14, '--clear', 'flag', 'Clear existing files before collecting', 'python manage.py collectstatic --clear', 'medium', 'Removes all files - ensure backups exist'),
(14, '--dry-run', 'flag', 'Show what would be collected without actually doing it', 'python manage.py collectstatic --dry-run', 'low', 'Safe for testing collection behavior');

-- CI/CD integration patterns
CREATE TABLE django_cicd_patterns (
    id SERIAL PRIMARY KEY,
    pattern_name VARCHAR(100) NOT NULL,
    pipeline_stage VARCHAR(50) NOT NULL, -- 'build', 'test', 'deploy', 'post_deploy'
    commands_sequence TEXT[] NOT NULL,
    execution_environment VARCHAR(50) NOT NULL,
    parallel_execution BOOLEAN DEFAULT FALSE,
    failure_action VARCHAR(50) DEFAULT 'stop', -- 'stop', 'continue', 'rollback'
    typical_duration_minutes INTEGER DEFAULT 5,
    success_criteria TEXT,
    company_example VARCHAR(100),
    description TEXT
);

-- Sample CI/CD patterns used by major Django shops
INSERT INTO django_cicd_patterns (pattern_name, pipeline_stage, commands_sequence, execution_environment, typical_duration_minutes, success_criteria, company_example, description) VALUES
('Basic Django Testing', 'test', ARRAY['python manage.py check', 'python manage.py test --parallel auto'], 'ci_cd', 8, 'All commands exit with code 0', 'GitHub Actions', 'Standard testing pipeline for Django applications'),
('Migration Safety Check', 'build', ARRAY['python manage.py makemigrations --check', 'python manage.py migrate --plan'], 'ci_cd', 2, 'No pending migrations, valid migration plan', 'GitLab CI', 'Ensures migrations are properly committed and valid'),
('Production Deployment', 'deploy', ARRAY['python manage.py migrate --noinput', 'python manage.py collectstatic --noinput --clear'], 'production', 15, 'Database updated, static files collected', 'Instagram', 'Standard production deployment sequence'),
('Security and Quality Check', 'build', ARRAY['python manage.py check --deploy', 'python manage.py check --tag security'], 'ci_cd', 3, 'No security or deployment issues found', 'Mozilla', 'Comprehensive security and deployment readiness check');
```

## 🔧 Essential Django Admin Commands Mastery

### 1. Project and Application Management

**Scenario**: Instagram's development workflow  
*Creating and managing Django projects and apps efficiently*

```bash
# Creating a new Django project (like Instagram's initial setup)
django-admin startproject instagram_clone

# Navigate to project directory
cd instagram_clone

# Create core applications following Instagram's architecture
python manage.py startapp accounts      # User management
python manage.py startapp photos       # Photo sharing
python manage.py startapp feed         # Activity feed
python manage.py startapp social       # Following/followers
python manage.py startapp messaging    # Direct messages
python manage.py startapp notifications # Push notifications

# Using custom templates for consistent app structure
python manage.py startapp analytics \\
    --template=/path/to/custom/app/template

# Creating apps with specific naming conventions
python manage.py startapp blog \\
    --name=blog_app \\
    --extension=py,txt,yaml

# Project structure validation
python manage.py check
# Output: System check identified no issues (0 silenced).

# Checking for deployment-specific issues
python manage.py check --deploy
# Output: System check identified 2 issues:
# WARNINGS:
# security.W004: You have not set the SECURE_SSL_REDIRECT setting to True
# security.W008: Your SECURE_SSL_REDIRECT setting is not set to True
```

### 2. Database Management Commands

**Scenario**: Pinterest's database management workflow

```bash
# Creating migrations for model changes
python manage.py makemigrations
# Output:
# Migrations for 'accounts':
#   accounts/migrations/0001_initial.py
#     - Create model User
#     - Create model Profile

# Creating named migrations for better tracking
python manage.py makemigrations accounts \\
    --name add_user_email_verification
# Creates: accounts/migrations/0002_add_user_email_verification.py

# Creating empty migration for data migration
python manage.py makemigrations accounts --empty
# Creates empty migration file for custom SQL or data operations

# Checking for migration conflicts before applying
python manage.py makemigrations --check
# Exit code 0 if no pending migrations, 1 if changes detected

# Viewing migration plan before applying
python manage.py showmigrations
# Output:
# accounts
#  [X] 0001_initial
#  [ ] 0002_add_user_email_verification
# photos  
#  [ ] 0001_initial

# Applying all pending migrations
python manage.py migrate
# Output:
# Operations to perform:
#   Apply all migrations: accounts, photos, social
# Running migrations:
#   Applying accounts.0002_add_user_email_verification... OK
#   Applying photos.0001_initial... OK

# Applying migrations to specific database
python manage.py migrate --database=analytics
# For multi-database setups

# Viewing SQL for a specific migration (without applying)
python manage.py sqlmigrate accounts 0002
# Output: SQL statements that would be executed

# Fake-applying migrations for existing databases
python manage.py migrate --fake-initial
# Marks initial migrations as applied without running SQL

# Rolling back migrations
python manage.py migrate accounts 0001
# Rolls back to migration 0001

# Opening database shell for direct SQL access
python manage.py dbshell
# Opens database command-line client (psql, mysql, sqlite3, etc.)
```

### 3. Development and Testing Commands

**Scenario**: Spotify's development and testing practices

```bash
# Starting development server
python manage.py runserver
# Default: http://127.0.0.1:8000/

# Running on custom host and port
python manage.py runserver 0.0.0.0:8080
# Accessible from other machines on network

# Development server with specific options
python manage.py runserver \\
    --noreload \\           # Disable auto-reload
    --nothreading \\        # Disable threading
    --insecure             # Serve static files even when DEBUG=False

# Opening Django shell with full project environment
python manage.py shell
# Interactive Python shell with Django environment loaded

# Using specific Python shell interface
python manage.py shell --interface=ipython
# Uses IPython if available (better interface)

# Running shell command directly
python manage.py shell --command="
from accounts.models import User
print(f'Total users: {User.objects.count()}')
"

# Running comprehensive project checks
python manage.py check
# Checks for common Django issues

# Checking specific aspects
python manage.py check --tag models    # Model-specific checks
python manage.py check --tag security  # Security checks
python manage.py check --deploy       # Deployment readiness

# Running tests for all applications
python manage.py test
# Discovers and runs all tests

# Running tests for specific apps
python manage.py test accounts photos
# Only tests accounts and photos apps

# Parallel testing for faster execution
python manage.py test --parallel auto
# Uses optimal number of processes

# Testing with database preservation
python manage.py test --keepdb
# Reuses test database between runs (faster)

# Verbose testing with detailed output
python manage.py test --verbosity=2
# Shows detailed test execution information

# Running specific test methods
python manage.py test accounts.tests.UserModelTest.test_user_creation
# Runs single test method
```

### 4. User and Security Management

**Scenario**: GitHub's user management operations

```bash
# Creating superuser account
python manage.py createsuperuser
# Interactive prompts:
# Username: admin
# Email address: admin@company.com
# Password: 
# Password (again):

# Creating superuser non-interactively (for scripts)
python manage.py createsuperuser \\
    --username=admin \\
    --email=admin@company.com \\
    --noinput
# Uses DJANGO_SUPERUSER_PASSWORD environment variable

# Changing user password
python manage.py changepassword admin
# Prompts for new password

# Changing password for specific database
python manage.py changepassword admin --database=users

# Clearing expired sessions (important for security)
python manage.py clearsessions
# Removes expired session records from database

# Removing stale content types (after app removal)
python manage.py remove_stale_contenttypes
# Cleans up ContentType records for deleted apps
```

### 5. Static Files and Deployment Commands

**Scenario**: Netflix's deployment pipeline

```bash
# Collecting static files for production
python manage.py collectstatic
# Collects all static files to STATIC_ROOT

# Non-interactive collection (for deployment scripts)
python manage.py collectstatic --noinput
# No prompts, overwrites existing files

# Clearing existing files before collection
python manage.py collectstatic --clear --noinput
# Removes all existing static files first

# Dry run to see what would be collected
python manage.py collectstatic --dry-run
# Shows files that would be collected without actually doing it

# Finding static files (debugging)
python manage.py findstatic css/base.css
# Output: /path/to/static/css/base.css

# Finding first occurrence of static file
python manage.py findstatic css/base.css --first
# Shows only the first matching file
```

### 6. Internationalization Commands

**Scenario**: Mozilla's multi-language support

```bash
# Extracting translatable strings
python manage.py makemessages --locale=es
# Creates Spanish translation files

# Extracting for multiple locales
python manage.py makemessages --locale=es --locale=fr
# Creates Spanish and French translation files

# Extracting from specific domains
python manage.py makemessages \\
    --locale=es \\
    --domain=django        # Default messages
# Or --domain=djangojs     # JavaScript messages

# Excluding certain directories
python manage.py makemessages \\
    --locale=es \\
    --ignore=venv/* \\
    --ignore=node_modules/*

# Compiling message files for deployment
python manage.py compilemessages
# Compiles .po files to .mo files

# Compiling for specific locale
python manage.py compilemessages --locale=es
```

### 7. Advanced Command Usage and Scripting

**Scenario**: Instagram's automated operations

```bash
# Combining commands for deployment pipeline
#!/bin/bash
set -e  # Exit on any error

echo "Starting deployment..."

# 1. Check for issues
python manage.py check --deploy
if [ $? -ne 0 ]; then
    echo "Deployment checks failed!"
    exit 1
fi

# 2. Apply database migrations
python manage.py migrate --noinput
if [ $? -ne 0 ]; then
    echo "Database migration failed!"
    exit 1
fi

# 3. Collect static files
python manage.py collectstatic --noinput --clear
if [ $? -ne 0 ]; then
    echo "Static file collection failed!"
    exit 1
fi

# 4. Compile translation files
python manage.py compilemessages
if [ $? -ne 0 ]; then
    echo "Translation compilation failed!"
    exit 1
fi

# 5. Clear expired sessions
python manage.py clearsessions

echo "Deployment completed successfully!"

# Using environment-specific settings
export DJANGO_SETTINGS_MODULE=myproject.settings.production
python manage.py migrate --settings=myproject.settings.production

# Running commands with specific Python path
PYTHONPATH=/custom/path python manage.py shell

# Setting verbosity levels
python manage.py migrate --verbosity=0  # Silent
python manage.py migrate --verbosity=1  # Minimal (default)
python manage.py migrate --verbosity=2  # Verbose
python manage.py migrate --verbosity=3  # Very verbose

# Using no-input flags for automation
python manage.py flush --noinput              # Clear database
python manage.py migrate --noinput            # Apply migrations
python manage.py collectstatic --noinput      # Collect static files
python manage.py loaddata fixture --noinput   # Load data

# Command timing and monitoring
time python manage.py test
# Output: real 2m30.123s user 1m45.234s sys 0m12.456s

# Running commands with memory profiling
python -m memory_profiler manage.py migrate

# Background command execution
nohup python manage.py long_running_command > output.log 2>&1 &
```

## 🎯 Key Takeaways

1. **startproject and startapp initialize Django projects** → Foundation for all Django development
2. **migrate and makemigrations manage database schema** → Essential for database evolution
3. **runserver provides development environment** → Never use in production
4. **test command ensures code quality** → Use --parallel for faster execution
5. **collectstatic prepares static files** → Critical for production deployment
6. **check validates project configuration** → Use --deploy flag for production readiness
7. **Commands support automation** → Use --noinput and proper exit codes for scripts

Master Django commands for efficient development and reliable deployments!
''',
    "difficulty": "beginner", 
    "estimated_time": 40,
    "xp_reward": 25,
    "prerequisites": ["django-settings", "django-applications"],
    "exercises": [
        {
            "id": "django_commands_1",
            "title": "Explore Django Built-in Commands",
            "prompt": "Let's examine Django's comprehensive command system. Write a query to see the core Django commands.",
            "table_name": "django_commands",
            "initial_query": "SELECT * FROM django_commands LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "django_commands"],
            "hint": "Use SELECT * FROM django_commands LIMIT 5; to see Django's built-in commands",
            "solution": "SELECT * FROM django_commands LIMIT 5;",
            "explanation": "Django provides numerous built-in commands for different aspects of development. Commands are categorized by purpose: project management, database operations, development tools, testing, deployment, and user management."
        },
        {
            "id": "django_commands_2", 
            "title": "Command Usage Patterns by Environment",
            "prompt": "Analyze how Django commands are used across different environments. Write a query to compare usage patterns.",
            "table_name": "django_command_usage",
            "expected_keywords": ["SELECT", "environment", "usage_frequency", "success_rate", "automation_level"],
            "hint": "Group by environment and command to see usage patterns",
            "solution": "SELECT dc.command_name, dcu.environment, dcu.usage_frequency, dcu.success_rate, dcu.automation_level, dcu.team_role FROM django_command_usage dcu JOIN django_commands dc ON dcu.command_id = dc.id ORDER BY dcu.environment, dcu.usage_frequency DESC;",
            "explanation": "Usage patterns vary significantly by environment. Development uses commands frequently and manually, while production uses fewer commands but with higher automation. CI/CD environments have the highest automated usage for testing and deployment."
        },
        {
            "id": "django_commands_3",
            "title": "Command Execution Performance Analysis",
            "prompt": "Examine command execution logs and performance. Write a query to see command execution patterns.",
            "table_name": "django_command_logs", 
            "expected_keywords": ["SELECT", "command_id", "execution_time_seconds", "success", "database_changed"],
            "hint": "Join with commands table to see execution performance by command type",
            "solution": "SELECT dc.command_name, dcl.environment, dcl.execution_time_seconds, dcl.success, dcl.database_changed, dcl.files_created FROM django_command_logs dcl JOIN django_commands dc ON dcl.command_id = dc.id ORDER BY dcl.execution_time_seconds DESC;",
            "explanation": "Command execution logs reveal performance characteristics. Database commands like migrations take longer and modify data, while simple commands like startapp are fast and create files. Success rates are generally high for well-tested commands."
        },
        {
            "id": "django_commands_4",
            "title": "Django Command Best Practices",
            "prompt": "Explore best practices and anti-patterns for Django commands. Write a query to see command usage patterns.",
            "table_name": "django_command_patterns",
            "expected_keywords": ["SELECT", "pattern_name", "pattern_type", "risk_level", "applies_to_environments"],
            "hint": "Filter by pattern type and risk level to see critical best practices",
            "solution": "SELECT dc.command_name, dcp.pattern_name, dcp.pattern_type, dcp.risk_level, dcp.example_good, dcp.example_bad, dcp.recommendation FROM django_command_patterns dcp JOIN django_commands dc ON dcp.command_id = dc.id WHERE dcp.risk_level IN ('high', 'critical') ORDER BY dcp.risk_level DESC;",
            "explanation": "Command best practices prevent critical errors. High-risk patterns include using runserver in production (security risk) and running migrations without testing (database risk). Following these patterns ensures safe and reliable Django operations."
        },
        {
            "id": "django_commands_5",
            "title": "Command Options and Configuration",
            "prompt": "Analyze command options and their implications. Write a query to see detailed command options.",
            "table_name": "django_command_options",
            "expected_keywords": ["SELECT", "option_name", "option_type", "description", "security_implications", "performance_impact"],
            "hint": "Focus on options with security or performance implications",
            "solution": "SELECT dc.command_name, dco.option_name, dco.option_type, dco.description, dco.security_implications, dco.performance_impact FROM django_command_options dco JOIN django_commands dc ON dco.command_id = dc.id WHERE dco.security_implications IS NOT NULL OR dco.performance_impact != 'none' ORDER BY dc.command_name, dco.option_name;",
            "explanation": "Command options can significantly impact security and performance. Options like --insecure have security implications, while --parallel and --keepdb affect performance. Understanding these implications is crucial for safe and efficient Django operations."
        },
        {
            "id": "django_commands_6",
            "title": "CI/CD Integration Patterns",
            "prompt": "Examine how Django commands are integrated into CI/CD pipelines. Write a query to see automation patterns.",
            "table_name": "django_cicd_patterns",
            "expected_keywords": ["SELECT", "pattern_name", "pipeline_stage", "commands_sequence", "typical_duration_minutes"],
            "hint": "Look at different pipeline stages and their command sequences",
            "solution": "SELECT pattern_name, pipeline_stage, commands_sequence, execution_environment, typical_duration_minutes, success_criteria, company_example FROM django_cicd_patterns ORDER BY pipeline_stage, typical_duration_minutes;",
            "explanation": "CI/CD patterns show how Django commands are orchestrated for automated development workflows. Each stage has specific commands: build (checks), test (testing), deploy (migrations and static files), with companies like Instagram and GitHub providing real-world examples."
        }
    ],
    "key_concepts": [
        "Django Project and App Management Commands",
        "Database Migration and Management Commands",
        "Development Server and Testing Commands", 
        "User Management and Security Commands",
        "Static Files and Deployment Commands",
        "Internationalization and Translation Commands",
        "Command Automation and Scripting Patterns",
        "CI/CD Integration Best Practices"
    ]
}