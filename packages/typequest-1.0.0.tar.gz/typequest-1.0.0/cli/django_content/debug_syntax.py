TEST_DICT = {
    "description": "Test description",
    "content": '''This is test content
with multiple lines
and various characters'''
}

print("Syntax is valid!")
print(TEST_DICT)