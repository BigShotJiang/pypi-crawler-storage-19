"""
Django Database Management - Lesson 1: Database Configuration and Connection Management
Master Django's database configuration for production-ready applications
"""

DJANGO_DATABASE_CONFIGURATION_LESSON = {
    "id": 54,
    "chapter": 54,
    "title": "Django Database Configuration: Production-Ready Database Setup",
    "slug": "django-database-configuration",
    "description": "Learn to configure Django databases for different environments, connection pooling, and production deployment",
    "content": '''# Django Database Configuration: Production-Ready Database Setup

## 🎯 Understanding Database Configuration

Django's **database configuration** is the foundation of any scalable application. Proper configuration affects **performance, reliability, and scalability** at every level of your application.

**Key Configuration Areas**:
- **Database Engine Selection** → PostgreSQL, MySQL, SQLite, Oracle
- **Connection Management** → Pooling, timeouts, persistent connections
- **Environment-Specific Settings** → Development, staging, production
- **Security Configuration** → SSL, authentication, access controls
- **Performance Tuning** → Connection limits, query timeouts

Think of database configuration as your application's **data highway** - it must be robust, fast, and secure.

## 💾 Multi-Environment Database Setup

Let's simulate a comprehensive database configuration for different environments:

```sql
-- DEVELOPMENT DATABASE: Local PostgreSQL
-- Database: company_dev

-- User accounts for development
CREATE TABLE dev_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_staff BOOLEAN DEFAULT FALSE,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    profile_data JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample development users
INSERT INTO dev_users (username, email, password_hash, is_staff, profile_data) VALUES
('admin_dev', 'admin@company.dev', 'dev_hash_123', TRUE, '{"role": "admin", "env": "development"}'),
('alice_dev', 'alice@company.dev', 'dev_hash_456', FALSE, '{"role": "developer", "team": "backend"}'),
('bob_test', 'bob@company.dev', 'dev_hash_789', FALSE, '{"role": "tester", "team": "qa"}'),
('carol_design', 'carol@company.dev', 'dev_hash_000', FALSE, '{"role": "designer", "team": "frontend"}');

-- Application configuration settings
CREATE TABLE app_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    environment VARCHAR(20) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Environment-specific settings
INSERT INTO app_settings (setting_key, setting_value, environment) VALUES
('DEBUG', 'true', 'development'),
('ALLOWED_HOSTS', '["localhost", "127.0.0.1"]', 'development'),
('DATABASE_POOL_SIZE', '5', 'development'),
('CACHE_TIMEOUT', '300', 'development'),
('EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend', 'development'),
('STATIC_URL', '/static/', 'development'),
('MEDIA_URL', '/media/', 'development'),
('SESSION_EXPIRE_SECONDS', '3600', 'development');

-- Database connection monitoring
CREATE TABLE connection_stats (
    id SERIAL PRIMARY KEY,
    database_name VARCHAR(100) NOT NULL,
    connection_count INTEGER DEFAULT 0,
    max_connections INTEGER DEFAULT 0,
    active_queries INTEGER DEFAULT 0,
    slow_queries INTEGER DEFAULT 0,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    environment VARCHAR(20) NOT NULL
);

-- Sample connection statistics
INSERT INTO connection_stats (database_name, connection_count, max_connections, active_queries, environment) VALUES
('company_dev', 3, 20, 1, 'development'),
('company_staging', 15, 50, 8, 'staging'),
('company_prod', 45, 100, 23, 'production');

-- Performance metrics table
CREATE TABLE database_performance (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10, 4) NOT NULL,
    database_name VARCHAR(100) NOT NULL,
    environment VARCHAR(20) NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample performance data
INSERT INTO database_performance (metric_name, metric_value, database_name, environment) VALUES
('avg_query_time_ms', 45.2300, 'company_dev', 'development'),
('connection_pool_usage', 15.5000, 'company_dev', 'development'),
('slow_query_count', 2.0000, 'company_dev', 'development'),
('cache_hit_ratio', 85.7500, 'company_dev', 'development'),
('avg_query_time_ms', 125.4500, 'company_prod', 'production'),
('connection_pool_usage', 78.2000, 'company_prod', 'production'),
('slow_query_count', 15.0000, 'company_prod', 'production'),
('cache_hit_ratio', 92.1500, 'company_prod', 'production');
```

## 🔧 Django Database Engine Configuration

### 1. PostgreSQL Configuration (Production Recommended)

**Scenario**: Instagram's production database setup

```python
# settings/production.py - Instagram-style PostgreSQL configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'instagram_prod',
        'USER': 'instagram_user',
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': 'postgres-primary.instagram.com',
        'PORT': '5432',
        'OPTIONS': {
            # SSL Configuration for security
            'sslmode': 'require',
            'sslcert': '/path/to/client-cert.pem',
            'sslkey': '/path/to/client-key.pem',
            'sslrootcert': '/path/to/ca-cert.pem',
            
            # Connection pooling for performance
            'pool': True,
            'pool_pre_ping': True,
            'pool_recycle': 300,  # 5 minutes
            
            # Advanced PostgreSQL options
            'server_side_cursors': True,
            'isolation_level': psycopg2.extensions.ISOLATION_LEVEL_READ_COMMITTED,
            
            # Query optimization
            'options': '-c default_transaction_isolation=read-committed'
        },
        'CONN_MAX_AGE': 600,  # 10 minutes persistent connections
        'CONN_HEALTH_CHECKS': True,  # Django 4.1+
        'AUTOCOMMIT': True,
        'ATOMIC_REQUESTS': True,  # Wrap each request in a transaction
    },
    
    # Read replica for heavy queries
    'read_replica': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'instagram_replica',
        'USER': 'instagram_read_user',
        'PASSWORD': os.environ.get('REPLICA_DB_PASSWORD'),
        'HOST': 'postgres-replica.instagram.com',
        'PORT': '5432',
        'OPTIONS': {
            'sslmode': 'require',
            'pool': True,
            'pool_pre_ping': True,
            'server_side_cursors': True,
        },
        'CONN_MAX_AGE': 60,  # Shorter for read replicas
    },
    
    # Analytics database
    'analytics': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'instagram_analytics',
        'USER': 'analytics_user',
        'PASSWORD': os.environ.get('ANALYTICS_DB_PASSWORD'),
        'HOST': 'analytics-db.instagram.com',
        'PORT': '5432',
        'OPTIONS': {
            'sslmode': 'require',
            # Larger work memory for analytics queries
            'options': '-c work_mem=256MB -c maintenance_work_mem=1GB'
        },
        'CONN_MAX_AGE': 0,  # Don't persist analytics connections
    }
}

# Database routing for Instagram's architecture
DATABASE_ROUTERS = ['instagram.db_routers.InstagramDatabaseRouter']
```

### 2. MySQL Configuration for High Performance

**Scenario**: YouTube's MySQL optimization

```python
# settings/mysql_config.py - YouTube-style MySQL configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'youtube_prod',
        'USER': 'youtube_app',
        'PASSWORD': os.environ.get('MYSQL_PASSWORD'),
        'HOST': 'mysql-cluster-writer.youtube.com',
        'PORT': '3306',
        'OPTIONS': {
            # InnoDB storage engine optimization
            'init_command': """
                SET sql_mode='STRICT_TRANS_TABLES';
                SET innodb_lock_wait_timeout=20;
                SET autocommit=1;
            """,
            
            # Character set configuration
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci',
            
            # SSL for production
            'ssl': {
                'ca': '/path/to/mysql-ca-cert.pem',
                'cert': '/path/to/mysql-client-cert.pem',
                'key': '/path/to/mysql-client-key.pem',
            },
            
            # Connection pooling
            'pool_name': 'youtube_pool',
            'pool_size': 32,
            'pool_reset_session': True,
            
            # Performance optimization
            'sql_mode': 'STRICT_TRANS_TABLES',
            'isolation_level': 'READ-COMMITTED',
        },
        'CONN_MAX_AGE': 3600,  # 1 hour for video platform
        'TEST': {
            'CHARSET': 'utf8mb4',
            'COLLATION': 'utf8mb4_unicode_ci',
        }
    },
    
    # Sharded databases for video metadata
    'videos_shard_1': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'youtube_videos_1',
        'USER': 'youtube_videos',
        'PASSWORD': os.environ.get('VIDEOS_DB_PASSWORD'),
        'HOST': 'videos-shard-1.youtube.com',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        }
    },
    
    'videos_shard_2': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'youtube_videos_2',
        'USER': 'youtube_videos',
        'PASSWORD': os.environ.get('VIDEOS_DB_PASSWORD'),
        'HOST': 'videos-shard-2.youtube.com',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        }
    }
}
```

### 3. SQLite Configuration for Development

**Scenario**: Django development setup

```python
# settings/development.py - Optimized SQLite for development
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db' / 'development.sqlite3',
        'OPTIONS': {
            # SQLite optimization for development
            'timeout': 30,
            'check_same_thread': False,
            
            # Performance pragmas
            'init_command': \'\'\'
                PRAGMA foreign_keys=ON;
                PRAGMA journal_mode=WAL;
                PRAGMA synchronous=NORMAL;
                PRAGMA cache_size=1000;
                PRAGMA temp_store=memory;
            \'\'\'
        },
        'CONN_MAX_AGE': 0,  # No persistent connections for SQLite
    },
    
    # In-memory database for testing
    'test_memory': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ':memory:',
        'OPTIONS': {
            'init_command': \'\'\'
                PRAGMA foreign_keys=ON;
                PRAGMA synchronous=OFF;
                PRAGMA journal_mode=MEMORY;
            \'\'\'
        }
    }
}
```

## 📊 Environment-Specific Configuration

### 4. Development Environment Setup

**Scenario**: Spotify's development configuration

```python
# settings/development.py
class DevelopmentDatabaseConfig:
    @staticmethod
    def get_config():
        return {
            'default': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'spotify_dev',
                'USER': 'spotify_dev_user',
                'PASSWORD': 'dev_password_123',
                'HOST': 'localhost',
                'PORT': '5432',
                'OPTIONS': {
                    # Development-friendly settings
                    'pool': False,  # No pooling in development
                    'sslmode': 'disable',  # No SSL locally
                    
                    # Debug-friendly options
                    'options': '-c log_statement=all -c log_duration=on'
                },
                'CONN_MAX_AGE': 0,  # Close connections immediately
                'ATOMIC_REQUESTS': False,  # Manual transaction management in dev
                
                # Test database configuration
                'TEST': {
                    'NAME': 'test_spotify_dev',
                    'CHARSET': 'utf8',
                    'COLLATION': 'utf8_general_ci',
                    'CREATE_DB': True,
                    'USER': 'test_user',
                    'PASSWORD': 'test_password',
                }
            }
        }
```

### 5. Staging Environment Configuration

**Scenario**: Airbnb's staging setup

```python
# settings/staging.py
class StagingDatabaseConfig:
    @staticmethod
    def get_config():
        return {
            'default': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'airbnb_staging',
                'USER': 'airbnb_staging_user',
                'PASSWORD': os.environ.get('STAGING_DB_PASSWORD'),
                'HOST': 'staging-db.airbnb.com',
                'PORT': '5432',
                'OPTIONS': {
                    'sslmode': 'require',
                    'pool': True,
                    'pool_size': 10,  # Moderate pool size for staging
                    'pool_pre_ping': True,
                    
                    # Production-like settings but less aggressive
                    'connect_timeout': 10,
                    'server_side_cursors': True,
                },
                'CONN_MAX_AGE': 300,  # 5 minutes
                'CONN_HEALTH_CHECKS': True,
            },
            
            # Staging analytics database
            'analytics': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'airbnb_staging_analytics',
                'USER': 'staging_analytics_user',
                'PASSWORD': os.environ.get('STAGING_ANALYTICS_PASSWORD'),
                'HOST': 'staging-analytics.airbnb.com',
                'PORT': '5432',
                'OPTIONS': {
                    'sslmode': 'require',
                    # Smaller work memory for staging
                    'options': '-c work_mem=64MB -c maintenance_work_mem=256MB'
                },
                'CONN_MAX_AGE': 60,
            }
        }
```

### 6. Production Environment Configuration

**Scenario**: Netflix's production database setup

```python
# settings/production.py
class ProductionDatabaseConfig:
    @staticmethod
    def get_config():
        return {
            'default': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'netflix_prod',
                'USER': 'netflix_prod_user',
                'PASSWORD': os.environ.get('PROD_DB_PASSWORD'),
                'HOST': 'prod-db-cluster.netflix.com',
                'PORT': '5432',
                'OPTIONS': {
                    # Maximum security
                    'sslmode': 'require',
                    'sslcert': '/opt/netflix/certs/client.crt',
                    'sslkey': '/opt/netflix/certs/client.key',
                    'sslrootcert': '/opt/netflix/certs/ca.crt',
                    
                    # High-performance connection pooling
                    'pool': True,
                    'pool_size': 50,
                    'pool_max_overflow': 100,
                    'pool_pre_ping': True,
                    'pool_recycle': 3600,  # 1 hour
                    
                    # Production optimization
                    'server_side_cursors': True,
                    'isolation_level': psycopg2.extensions.ISOLATION_LEVEL_READ_COMMITTED,
                    'connect_timeout': 10,
                    'command_timeout': 60,
                    
                    # PostgreSQL-specific optimizations
                    'options': \'\'\'
                        -c shared_preload_libraries=pg_stat_statements
                        -c log_min_duration_statement=1000
                        -c log_checkpoints=on
                        -c log_connections=on
                        -c log_disconnections=on
                    \'\'\'
                },
                'CONN_MAX_AGE': 600,  # 10 minutes
                'CONN_HEALTH_CHECKS': True,
                'AUTOCOMMIT': True,
                'ATOMIC_REQUESTS': True,
            },
            
            # Read replicas for different regions
            'read_replica_us_west': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'netflix_replica_us_west',
                'USER': 'netflix_read_user',
                'PASSWORD': os.environ.get('REPLICA_US_WEST_PASSWORD'),
                'HOST': 'read-replica-us-west.netflix.com',
                'PORT': '5432',
                'OPTIONS': {
                    'sslmode': 'require',
                    'pool': True,
                    'pool_size': 30,
                    'server_side_cursors': True,
                },
                'CONN_MAX_AGE': 300,
            },
            
            'read_replica_eu': {
                'ENGINE': 'django.db.backends.postgresql',
                'NAME': 'netflix_replica_eu',
                'USER': 'netflix_read_user',
                'PASSWORD': os.environ.get('REPLICA_EU_PASSWORD'),
                'HOST': 'read-replica-eu.netflix.com',
                'PORT': '5432',
                'OPTIONS': {
                    'sslmode': 'require',
                    'pool': True,
                    'pool_size': 30,
                    'server_side_cursors': True,
                },
                'CONN_MAX_AGE': 300,
            }
        }
```

## 🔄 Connection Management and Monitoring

### 7. Connection Pool Management

**Scenario**: Uber's connection pool optimization

```python
from django.db import connections
from django.core.management.base import BaseCommand
import time
import psutil

class DatabaseConnectionManager:
    @staticmethod
    def monitor_connections():
        """Monitor database connection health across all databases"""
        connection_status = {}
        
        for alias in connections.databases.keys():
            try:
                connection = connections[alias]
                
                # Check basic connectivity
                with connection.cursor() as cursor:
                    cursor.execute("SELECT 1")
                    result = cursor.fetchone()
                
                # Get connection pool information
                pool_info = {
                    'alias': alias,
                    'status': 'healthy' if result else 'unhealthy',
                    'queries_executed': len(connection.queries),
                    'connection_created': hasattr(connection, 'connection'),
                    'isolation_level': getattr(connection.connection, 'isolation_level', None) if hasattr(connection, 'connection') else None
                }
                
                # PostgreSQL-specific connection info
                if connection.vendor == 'postgresql' and hasattr(connection, 'connection'):
                    pool_info.update({
                        'server_version': connection.connection.server_version,
                        'protocol_version': connection.connection.protocol_version,
                        'autocommit': connection.connection.autocommit,
                        'closed': connection.connection.closed
                    })
                
                connection_status[alias] = pool_info
                
            except Exception as e:
                connection_status[alias] = {
                    'alias': alias,
                    'status': 'error',
                    'error': str(e),
                    'timestamp': time.time()
                }
        
        return connection_status
    
    @staticmethod
    def optimize_connection_pools():
        """Optimize connection pools based on current load"""
        system_load = psutil.cpu_percent(interval=1)
        memory_usage = psutil.virtual_memory().percent
        
        # Adjust connection limits based on system resources
        if system_load > 80 or memory_usage > 85:
            # Reduce connection pool sizes under high load
            optimization_strategy = 'conservative'
            recommended_pool_size = 10
        elif system_load < 30 and memory_usage < 50:
            # Increase pool sizes when resources are available
            optimization_strategy = 'aggressive'
            recommended_pool_size = 50
        else:
            optimization_strategy = 'balanced'
            recommended_pool_size = 25
        
        return {
            'strategy': optimization_strategy,
            'recommended_pool_size': recommended_pool_size,
            'system_load': system_load,
            'memory_usage': memory_usage,
            'timestamp': time.time()
        }

    @staticmethod
    def close_old_connections():
        """Close old connections to prevent connection leaks"""
        for alias in connections.databases.keys():
            try:
                connection = connections[alias]
                connection.close_if_unusable_or_obsolete()
            except Exception as e:
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"Failed to close connection {alias}: {e}")
```

### 8. Database Health Monitoring

**Scenario**: Amazon RDS monitoring integration

```python
import boto3
import time
from django.conf import settings
from django.core.cache import cache

class AWSRDSMonitor:
    def __init__(self):
        self.cloudwatch = boto3.client('cloudwatch', region_name='us-west-2')
        self.rds = boto3.client('rds', region_name='us-west-2')
    
    def get_database_metrics(self, db_instance_identifier):
        """Get comprehensive database metrics from AWS CloudWatch"""
        end_time = time.time()
        start_time = end_time - 3600  # Last hour
        
        metrics_to_fetch = [
            'CPUUtilization',
            'DatabaseConnections',
            'FreeableMemory',
            'ReadLatency',
            'WriteLatency',
            'ReadIOPS',
            'WriteIOPS',
            'FreeStorageSpace',
            'ReplicaLag'  # For read replicas
        ]
        
        metrics_data = {}
        
        for metric_name in metrics_to_fetch:
            try:
                response = self.cloudwatch.get_metric_statistics(
                    Namespace='AWS/RDS',
                    MetricName=metric_name,
                    Dimensions=[
                        {
                            'Name': 'DBInstanceIdentifier',
                            'Value': db_instance_identifier
                        }
                    ],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=300,  # 5-minute intervals
                    Statistics=['Average', 'Maximum']
                )
                
                if response['Datapoints']:
                    latest_point = max(response['Datapoints'], key=lambda x: x['Timestamp'])
                    metrics_data[metric_name] = {
                        'average': latest_point['Average'],
                        'maximum': latest_point['Maximum'],
                        'timestamp': latest_point['Timestamp']
                    }
            
            except Exception as e:
                metrics_data[metric_name] = {'error': str(e)}
        
        return metrics_data
    
    def check_connection_health(self):
        """Check health of all database connections"""
        health_report = {
            'timestamp': time.time(),
            'databases': {},
            'overall_status': 'healthy'
        }
        
        for alias, config in settings.DATABASES.items():
            try:
                # Get basic connection info
                connection = connections[alias]
                
                with connection.cursor() as cursor:
                    # Test basic query
                    cursor.execute("SELECT 1")
                    
                    # Get database-specific health info
                    if connection.vendor == 'postgresql':
                        cursor.execute("""
                            SELECT 
                                count(*) as active_connections,
                                max(extract(epoch from (now() - query_start))) as longest_query_seconds
                            FROM pg_stat_activity 
                            WHERE state = 'active'
                        """)
                        health_info = cursor.fetchone()
                        
                        health_report['databases'][alias] = {
                            'status': 'healthy',
                            'active_connections': health_info[0],
                            'longest_query_seconds': health_info[1] or 0,
                            'vendor': 'postgresql'
                        }
                        
                    elif connection.vendor == 'mysql':
                        cursor.execute("SHOW STATUS LIKE 'Threads_connected'")
                        connections_result = cursor.fetchone()
                        cursor.execute("SHOW STATUS LIKE 'Slow_queries'")
                        slow_queries_result = cursor.fetchone()
                        
                        health_report['databases'][alias] = {
                            'status': 'healthy',
                            'active_connections': connections_result[1] if connections_result else 0,
                            'slow_queries': slow_queries_result[1] if slow_queries_result else 0,
                            'vendor': 'mysql'
                        }
                        
            except Exception as e:
                health_report['databases'][alias] = {
                    'status': 'error',
                    'error': str(e)
                }
                health_report['overall_status'] = 'degraded'
        
        # Cache health report for monitoring dashboard
        cache.set('database_health_report', health_report, timeout=60)
        
        return health_report
```

## ⚡ Performance Optimization Patterns

### 9. Connection Pooling Strategies

**Scenario**: LinkedIn's database optimization

```python
# settings/production.py - LinkedIn-style connection optimization
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'linkedin_prod',
        'USER': 'linkedin_app',
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': 'prod-cluster.linkedin.com',
        'PORT': '5432',
        'OPTIONS': {
            # Advanced connection pooling
            'pool': {
                # Pool configuration
                'min_connections': 5,
                'max_connections': 50,
                'max_overflow': 20,
                'pool_timeout': 30,
                'pool_recycle': 3600,
                'pool_pre_ping': True,
                
                # Connection validation
                'pool_reset_on_return': 'commit',
                'echo_pool': False,  # Set to True for debugging
            },
            
            # PostgreSQL-specific optimizations
            'server_side_cursors': True,
            'isolation_level': psycopg2.extensions.ISOLATION_LEVEL_READ_COMMITTED,
            
            # Performance tuning
            'options': \'\'\'
                -c shared_buffers=256MB
                -c effective_cache_size=1GB
                -c maintenance_work_mem=64MB
                -c checkpoint_completion_target=0.9
                -c wal_buffers=16MB
                -c default_statistics_target=100
            \'\'\'
        },
        'CONN_MAX_AGE': 600,
        'CONN_HEALTH_CHECKS': True,
        'AUTOCOMMIT': True,
        'ATOMIC_REQUESTS': True,
    }
}

# Connection pool monitoring
CONNECTION_POOL_SETTINGS = {
    'MONITOR_POOLS': True,
    'POOL_METRICS_INTERVAL': 60,  # seconds
    'ALERT_THRESHOLDS': {
        'pool_usage_percent': 80,
        'connection_wait_time_ms': 1000,
        'failed_connections_per_minute': 5,
    }
}
```

## 🎯 Key Takeaways

1. **Choose the right database engine** for your use case → PostgreSQL for most applications
2. **Configure connection pooling** for production environments → Improves performance and resource usage
3. **Use environment-specific configurations** → Different settings for development, staging, production
4. **Implement SSL/TLS** for production databases → Security is non-negotiable
5. **Monitor connection health** continuously → Prevent performance degradation
6. **Plan for horizontal scaling** with read replicas → Handle growing traffic efficiently
7. **Optimize database-specific settings** → Leverage engine-specific features

Proper database configuration is the foundation of a scalable, secure, and performant Django application!
''',
    "difficulty": "intermediate",
    "estimated_time": 45,
    "xp_reward": 30,
    "prerequisites": ["django-models-foundations", "django-transactions"],
    "exercises": [
        {
            "id": "db_config_1",
            "title": "Explore Development Environment Settings",
            "prompt": "Let's examine our development database configuration. Write a query to see all application settings for the development environment.",
            "table_name": "app_settings",
            "initial_query": "SELECT * FROM app_settings WHERE environment = 'development';",
            "expected_keywords": ["SELECT", "*", "FROM", "app_settings", "WHERE", "development"],
            "hint": "Filter app_settings for environment = 'development' to see dev-specific configuration",
            "solution": "SELECT * FROM app_settings WHERE environment = 'development';",
            "explanation": "Development environment settings typically include DEBUG=true, local hosts, and less strict configurations. In Django, these would be in settings/development.py with appropriate database configurations for local development."
        },
        {
            "id": "db_config_2",
            "title": "Database Connection Monitoring",
            "prompt": "Practice monitoring database connections. Write a query to see connection statistics across different environments, showing connection counts and max connections.",
            "table_name": "connection_stats",
            "expected_keywords": ["SELECT", "database_name", "connection_count", "max_connections", "environment"],
            "hint": "Select database_name, connection_count, max_connections, and environment from connection_stats",
            "solution": "SELECT database_name, connection_count, max_connections, environment, timestamp FROM connection_stats ORDER BY environment, timestamp DESC;",
            "explanation": "Connection monitoring shows how database pools are being utilized. High connection counts relative to max_connections indicate need for pool optimization or scaling. Django's CONN_MAX_AGE and connection pooling settings directly impact these metrics."
        },
        {
            "id": "db_config_3",
            "title": "Performance Metrics Analysis",
            "prompt": "Analyze database performance across environments. Write a query to compare average query times between development and production environments.",
            "table_name": "database_performance",
            "expected_keywords": ["SELECT", "environment", "avg_query_time_ms", "AVG", "GROUP BY"],
            "hint": "Group by environment and calculate averages for avg_query_time_ms metric",
            "solution": "SELECT environment, AVG(metric_value) as avg_query_time FROM database_performance WHERE metric_name = 'avg_query_time_ms' GROUP BY environment ORDER BY avg_query_time;",
            "explanation": "Production databases typically have higher query times due to larger datasets and more complex operations. Django's database optimization settings like connection pooling, query optimization, and proper indexing help reduce these times."
        },
        {
            "id": "db_config_4",
            "title": "Connection Pool Usage Analysis",
            "prompt": "Examine connection pool efficiency. Write a query to find databases with high connection pool usage (>75%) that might need scaling.",
            "table_name": "database_performance",
            "expected_keywords": ["SELECT", "database_name", "connection_pool_usage", "WHERE", ">", "75"],
            "hint": "Filter for connection_pool_usage metric where value > 75",
            "solution": "SELECT database_name, environment, metric_value as pool_usage_percent FROM database_performance WHERE metric_name = 'connection_pool_usage' AND metric_value > 75 ORDER BY metric_value DESC;",
            "explanation": "High connection pool usage indicates the need to increase pool size or optimize connection management. Django's connection pool settings can be tuned to handle more concurrent connections or implement connection recycling strategies."
        },
        {
            "id": "db_config_5",
            "title": "User Account Configuration by Environment",
            "prompt": "Look at user configurations across environments. Write a query to see development users and their roles from the profile data.",
            "table_name": "dev_users",
            "expected_keywords": ["SELECT", "username", "email", "profile_data", "FROM"],
            "hint": "Select user information including the JSONB profile_data field",
            "solution": "SELECT username, email, is_staff, profile_data FROM dev_users ORDER BY is_staff DESC, username;",
            "explanation": "Development environments often have different user configurations with test accounts and elevated privileges. Django's user model can store additional profile information in JSONField, allowing flexible user metadata storage across different environments."
        },
        {
            "id": "db_config_6",
            "title": "Cache Performance Comparison",
            "prompt": "Compare caching effectiveness across environments. Write a query to see cache hit ratios for different database environments.",
            "table_name": "database_performance",
            "expected_keywords": ["SELECT", "environment", "cache_hit_ratio", "WHERE", "ORDER BY"],
            "hint": "Filter for cache_hit_ratio metric and compare across environments",
            "solution": "SELECT environment, database_name, metric_value as cache_hit_ratio, recorded_at FROM database_performance WHERE metric_name = 'cache_hit_ratio' ORDER BY environment, metric_value DESC;",
            "explanation": "Cache hit ratios indicate how effectively your database caching is working. Production environments typically have higher cache hit ratios due to query patterns. Django's caching framework and database query caching can be configured to improve these ratios."
        }
    ],
    "key_concepts": [
        "Database Engine Selection and Configuration",
        "Environment-Specific Database Settings",
        "Connection Pool Management and Optimization",
        "SSL/TLS Security Configuration",
        "Connection Health Monitoring",
        "Multi-Database Architecture Setup",
        "Performance Tuning and Optimization",
        "Database-Specific Advanced Options"
    ]
}