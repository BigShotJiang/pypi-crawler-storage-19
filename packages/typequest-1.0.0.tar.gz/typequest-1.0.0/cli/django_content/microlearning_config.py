"""
Micro-learning Configuration System
Allows fine-tuned control over practice sessions, attempts, and formatting
"""

# Micro-learning settings table - configurable per topic type
MICROLEARNING_SETTINGS = {
    # Global defaults
    'default': {
        'max_attempts_per_task': 2,
        'show_hint_after_attempt': 1,
        'show_solution_after_attempts': 2,
        'allow_skip_task': True,
        'immediate_feedback': True,
        'progress_celebration': True,
        'task_spacing': True,  # Add visual spacing between tasks
        'input_box_style': 'clean',  # 'clean', 'boxed', 'highlighted'
    },
    
    # Basic syntax concepts (easier, more forgiving)
    'basic_syntax': {
        'max_attempts_per_task': 3,
        'show_hint_after_attempt': 1,
        'show_solution_after_attempts': 3,
        'allow_skip_task': True,
        'encouragement_messages': True,
    },
    
    # Column selection (medium difficulty)
    'column_selection': {
        'max_attempts_per_task': 2,
        'show_hint_after_attempt': 1,
        'show_solution_after_attempts': 2,
        'partial_credit': True,  # Accept partially correct answers
    },
    
    # Advanced calculations (harder, fewer attempts)
    'calculations': {
        'max_attempts_per_task': 2,
        'show_hint_after_attempt': 2,  # Only show hint after second attempt
        'show_solution_after_attempts': 2,
        'syntax_checking': 'strict',
    },
    
    # Alias practice (focus on formatting)
    'aliases': {
        'max_attempts_per_task': 2,
        'show_hint_after_attempt': 1,
        'case_sensitive': False,  # More forgiving for aliases
        'quote_flexible': True,   # Accept both quoted and unquoted
    }
}

# Visual formatting settings
VISUAL_FORMATTING = {
    'task_header': {
        'icon': '🎯',
        'style': 'bold white',
        'underline': True,
        'spacing_above': 1,
        'spacing_below': 0,
    },
    
    'input_prompt': {
        'style': 'bright_blue',
        'prefix': '💭 ',
        'background_box': True,
        'box_width': 60,
        'prompt_text': 'Enter your SQL query:',
    },
    
    'feedback': {
        'correct': {
            'icon': '✅',
            'style': 'bold green',
            'celebration': ['Great job!', 'Perfect!', 'Excellent!', 'Well done!'],
        },
        'incorrect': {
            'icon': '❌',
            'style': 'bold red',
            'encouragement': ['Not quite right, try again!', 'Close! Give it another shot!', 'Almost there!'],
        },
        'hint': {
            'icon': '💡',
            'style': 'bold yellow',
            'prefix': 'Hint: ',
        },
        'solution': {
            'icon': '📋',
            'style': 'bold cyan',
            'prefix': 'Expected query: ',
            'box_style': True,
        }
    },
    
    'separators': {
        'task_separator': '─' * 50,
        'section_separator': '═' * 60,
        'mini_separator': '┄' * 30,
    }
}

# Practice progression settings
PROGRESSION_SETTINGS = {
    'beginner': {
        'max_attempts_per_task': 3,
        'show_detailed_explanations': True,
        'auto_advance_on_correct': False,  # Ask before moving on
        'celebration_level': 'high',
    },
    
    'intermediate': {
        'max_attempts_per_task': 2,
        'show_detailed_explanations': True,
        'auto_advance_on_correct': True,
        'celebration_level': 'medium',
    },
    
    'advanced': {
        'max_attempts_per_task': 1,
        'show_detailed_explanations': False,
        'auto_advance_on_correct': True,
        'celebration_level': 'minimal',
    }
}

def get_microlearning_settings(topic_type='default', user_level='beginner'):
    """
    Get appropriate settings for a specific topic and user level
    
    Args:
        topic_type (str): The type of topic (basic_syntax, calculations, etc.)
        user_level (str): User skill level (beginner, intermediate, advanced)
    
    Returns:
        dict: Combined settings for this practice session
    """
    # Start with defaults
    settings = MICROLEARNING_SETTINGS['default'].copy()
    
    # Apply topic-specific settings
    if topic_type in MICROLEARNING_SETTINGS:
        settings.update(MICROLEARNING_SETTINGS[topic_type])
    
    # Apply user level settings
    if user_level in PROGRESSION_SETTINGS:
        settings.update(PROGRESSION_SETTINGS[user_level])
    
    return settings

def get_visual_settings():
    """Get visual formatting settings"""
    return VISUAL_FORMATTING

def get_encouragement_message(attempt_number, is_correct=False):
    """Get appropriate encouragement message"""
    if is_correct:
        messages = VISUAL_FORMATTING['feedback']['correct']['celebration']
        return f"✨ {messages[(attempt_number - 1) % len(messages)]} ✨"
    else:
        messages = VISUAL_FORMATTING['feedback']['incorrect']['encouragement']
        return messages[(attempt_number - 1) % len(messages)]

# Export main functions
__all__ = [
    'get_microlearning_settings',
    'get_visual_settings', 
    'get_encouragement_message',
    'MICROLEARNING_SETTINGS',
    'VISUAL_FORMATTING',
    'PROGRESSION_SETTINGS'
]