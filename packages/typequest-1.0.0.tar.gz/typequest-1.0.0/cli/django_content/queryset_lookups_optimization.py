"""
Django QuerySet Lookups and Optimization lesson content
"""

DJANGO_QUERYSET_LOOKUPS_OPTIMIZATION_LESSON = {
    "id": 19,
    "chapter": 19,
    "title": "Django QuerySet Lookups and Optimization",
    "slug": "queryset-lookups-optimization",
    "content": '''
# QuerySet Lookups & Optimization: Precision Querying at Scale

Think of Django's field lookups as a sophisticated search engine like Google's - you can search for exact phrases, partial matches, date ranges, or complex patterns. Meanwhile, query optimization is like having a GPS that finds the fastest route through your database, ensuring your app performs like YouTube loading millions of videos instantly, not like a dial-up connection from the 90s.

## Field Lookups: The Search Operators

**Real-world analogy:** Field lookups are like the search filters on Amazon. You can search for "exact product name," "contains certain words," "price range," "released after date," or "customer rating above X stars." Each lookup type is a different way to slice through your data.

### Exact and Case-Insensitive Matching

#### exact: Precise Matching
```python
# Login validation (case-sensitive)
user = User.objects.get(username__exact='john_doe')
# SQL: WHERE username = 'john_doe'

# Product SKU lookup (exact match required)
product = Product.objects.get(sku__exact='LAPTOP-HP-001')

# Boolean field exact matching
active_subscriptions = Subscription.objects.filter(is_active__exact=True)
# Same as: is_active=True
```

#### iexact: Case-Insensitive Exact Matching
```python
# Email login (case doesn't matter)
user = User.objects.get(email__iexact='JOHN@EXAMPLE.COM')
# Matches: john@example.com, John@Example.com, JOHN@EXAMPLE.COM

# Company name lookup (handle capitalization variations)
companies = Company.objects.filter(name__iexact='apple inc')
# Matches: "Apple Inc", "APPLE INC", "apple inc"

# Domain filtering for social media
social_posts = Post.objects.filter(
    url__iexact='https://instagram.com/post/123'
)
```

### Text Pattern Matching: Finding Needles in Haystacks

#### contains and icontains: Substring Search
```python
# YouTube video search (case-sensitive)
python_videos = Video.objects.filter(title__contains='Python')
# Matches: "Learn Python", "Python Tutorial" but NOT "python basics"

# Global search (case-insensitive) - like Instagram hashtag search
all_python_content = Post.objects.filter(content__icontains='python')
# Matches: "Python", "PYTHON", "python", "PyThOn"

# Product search across name and description
laptops = Product.objects.filter(
    Q(name__icontains='laptop') | Q(description__icontains='laptop')
)

# Multi-field content search (like Twitter search)
def search_tweets(query):
    return Tweet.objects.filter(
        Q(text__icontains=query) |
        Q(hashtags__icontains=query) |
        Q(author__username__icontains=query)
    )
```

#### startswith and istartswith: Prefix Matching
```python
# Autocomplete suggestions (like Google search suggestions)
suggestions = User.objects.filter(
    username__istartswith='joh'
).values_list('username', flat=True)[:10]
# Returns: ['john_doe', 'johnny', 'johanna', ...]

# File type filtering
image_files = FileUpload.objects.filter(filename__endswith='.jpg')
python_files = CodeFile.objects.filter(filename__endswith='.py')

# Phone number validation (US numbers)
us_phone_numbers = Contact.objects.filter(phone__startswith='+1')

# URL routing analysis
api_requests = Request.objects.filter(path__startswith='/api/')
admin_requests = Request.objects.filter(path__startswith='/admin/')
```

#### endswith and iendswith: Suffix Matching
```python
# Email domain analysis (like corporate email filtering)
gmail_users = User.objects.filter(email__iendswith='@gmail.com')
company_emails = User.objects.filter(email__iendswith='@company.com')

# File extension categorization
images = MediaFile.objects.filter(
    Q(filename__iendswith='.jpg') |
    Q(filename__iendswith='.png') |
    Q(filename__iendswith='.gif')
)

# Website domain tracking
social_media_links = Link.objects.filter(
    Q(url__iendswith='instagram.com') |
    Q(url__iendswith='twitter.com') |
    Q(url__iendswith='linkedin.com')
)
```

### List and Range Lookups: Bulk Operations

#### in: Multiple Value Matching
```python
# User role checking (like permission system)
privileged_users = User.objects.filter(
    role__in=['admin', 'moderator', 'editor']
)

# Product category filtering (like Amazon department filtering)
electronics = Product.objects.filter(
    category__in=['smartphones', 'laptops', 'tablets', 'headphones']
)

# Date-based filtering (specific months)
holiday_orders = Order.objects.filter(
    created_at__month__in=[11, 12]  # November, December
)

# Status filtering (workflow states)
actionable_tickets = SupportTicket.objects.filter(
    status__in=['new', 'in_progress', 'needs_review']
)
```

#### range: Value Between Limits
```python
# Price filtering (like shopping site price slider)
affordable_products = Product.objects.filter(price__range=(50, 200))
# SQL: WHERE price BETWEEN 50 AND 200

# Date range queries (like analytics dashboard)
this_quarter_orders = Order.objects.filter(
    created_at__range=(quarter_start, quarter_end)
)

# Age demographics (like dating app filtering)
target_demographic = UserProfile.objects.filter(age__range=(25, 35))

# Score filtering (like gaming leaderboards)
top_performers = GameScore.objects.filter(score__range=(9000, 10000))
```

### Numeric Comparisons: Mathematical Operations

#### Greater Than and Less Than Lookups
```python
# High-value customer identification
vip_customers = Customer.objects.filter(lifetime_value__gte=10000)

# Recent content (like "Posts from last week")
recent_posts = Post.objects.filter(
    created_at__gte=timezone.now() - timedelta(days=7)
)

# Low inventory alerts (like warehouse management)
low_stock_products = Product.objects.filter(stock_quantity__lte=10)

# Performance filtering (like app store ratings)
high_rated_apps = App.objects.filter(
    average_rating__gte=4.5,
    review_count__gte=100
)

# Engagement thresholds (like viral content detection)
viral_posts = Post.objects.filter(
    likes_count__gte=10000,
    shares_count__gte=1000
)
```

### Date and Time Lookups: Temporal Intelligence

#### Date Component Extraction
```python
# Birthday notifications (like Facebook reminders)
today = timezone.now().date()
birthday_users = User.objects.filter(
    birth_date__month=today.month,
    birth_date__day=today.day
)

# Annual reports (like year-end analytics)
this_year_sales = Order.objects.filter(created_at__year=2024)

# Weekly patterns (like business intelligence)
weekend_orders = Order.objects.filter(
    created_at__week_day__in=[1, 7]  # Sunday=1, Saturday=7
)

# Time-based analysis (like peak hours identification)
lunch_hour_orders = Order.objects.filter(
    created_at__time__range=(time(11, 30), time(13, 30))
)

# Monthly trends
december_signups = User.objects.filter(date_joined__month=12)
q4_revenue = Order.objects.filter(created_at__quarter=4)
```

#### Advanced Date Filtering
```python
# Social media activity patterns
morning_posts = Post.objects.filter(
    created_at__time__lt=time(12, 0)  # Before noon
)

evening_activity = UserSession.objects.filter(
    start_time__hour__gte=18  # After 6 PM
)

# Business day filtering
weekday_orders = Order.objects.filter(
    created_at__week_day__range=(2, 6)  # Monday to Friday
)

# Seasonal analysis (like retail patterns)
summer_sales = Product.objects.filter(
    sales__created_at__month__in=[6, 7, 8]  # June, July, August
).annotate(
    summer_revenue=Sum('sales__total_amount')
)
```

### Null and Boolean Checks: Handling Missing Data

#### isnull: Missing Value Detection
```python
# Profile completion analysis (like LinkedIn profile strength)
incomplete_profiles = UserProfile.objects.filter(bio__isnull=True)
complete_profiles = UserProfile.objects.filter(bio__isnull=False)

# Data quality auditing
missing_descriptions = Product.objects.filter(description__isnull=True)
products_needing_images = Product.objects.filter(main_image__isnull=True)

# Customer relationship management
customers_without_phone = Customer.objects.filter(phone__isnull=True)
unverified_emails = User.objects.filter(email_verified_at__isnull=True)
```

### Regular Expression Lookups: Pattern Matching

#### regex and iregex: Advanced Pattern Matching
```python
# Phone number validation (US format)
valid_us_phones = Contact.objects.filter(
    phone__regex=r'^\\+1-\\d{3}-\\d{3}-\\d{4}$'
)

# Email domain analysis (corporate emails)
corporate_emails = User.objects.filter(
    email__regex=r'^[^@]+@(?!gmail|yahoo|hotmail)[^@]+\\.[^@]+$'
)

# Content moderation (like detecting spam patterns)
potential_spam = Comment.objects.filter(
    text__iregex=r'(win|free|prize|click here|limited time)'
)

# Product code validation (specific format)
valid_product_codes = Product.objects.filter(
    sku__regex=r'^[A-Z]{3}-\\d{4}-[A-Z]{2}$'  # Format: ABC-1234-XY
)

# URL validation
social_media_posts = Post.objects.filter(
    content__regex=r'https?://(instagram|twitter|facebook)\\.com/\\S+'
)
```

## Query Optimization: Performance at Scale

**Real-world analogy:** Query optimization is like the difference between a well-organized warehouse (Amazon's fulfillment centers) and a messy garage. One can find items instantly, the other requires searching through everything.

### Database Indexes: Highway Systems for Data

#### Understanding Index Impact
```python
# Before: Slow query without index
slow_query = User.objects.filter(email='user@example.com')
# Database scans every user record

# After: Fast query with database index
# In migration:
class Migration:
    operations = [
        models.RunSQL(
            "CREATE INDEX idx_user_email ON auth_user (email);"
        )
    ]

# Model-level index definition
class User(models.Model):
    email = models.EmailField(db_index=True)  # Single field index
    
    class Meta:
        indexes = [
            models.Index(fields=['email', 'is_active']),  # Composite index
            models.Index(fields=['-created_at']),         # Descending index
        ]
```

### Query Analysis and Debugging

#### Using explain() for Query Analysis
```python
# Analyze query performance
query = Post.objects.filter(
    author__profile__is_verified=True,
    likes_count__gte=100
).select_related('author')

# Get query execution plan
print(query.explain())
# Shows: indexes used, join types, estimated costs

# Detailed analysis with options
print(query.explain(options={
    'ANALYZE': True,
    'BUFFERS': True,
    'VERBOSE': True
}))
```

#### Identifying N+1 Query Problems
```python
# ❌ N+1 Problem Example
posts = Post.objects.all()[:10]
for post in posts:
    print(f"{post.title} by {post.author.username}")  # 11 queries total!

# ✅ Optimized Solution
posts = Post.objects.select_related('author')[:10]
for post in posts:
    print(f"{post.title} by {post.author.username}")  # 1 query total!

# ❌ N+1 with reverse relationships
authors = Author.objects.all()[:5]
for author in authors:
    print(f"Books: {author.books.count()}")  # 6 queries total!

# ✅ Optimized with prefetch
authors = Author.objects.prefetch_related('books')[:5]
for author in authors:
    print(f"Books: {author.books.count()}")  # 2 queries total!
```

### Advanced Optimization Techniques

#### Custom Database Functions
```python
from django.db.models import Func

class Round(Func):
    function = 'ROUND'
    template = '%(function)s(%(expressions)s, %(precision)s)'

# Usage: Round ratings to 1 decimal place
products = Product.objects.annotate(
    rounded_rating=Round('average_rating', 1)
)

# Search optimization with full-text search
class SearchVector(Func):
    function = 'to_tsvector'
    
# PostgreSQL full-text search
search_results = Article.objects.annotate(
    search=SearchVector('title', 'content')
).filter(search='django')
```

#### Raw SQL for Complex Operations
```python
# When QuerySet API isn't enough
complex_analytics = User.objects.raw(\"\"\"
    SELECT u.id, u.username,
           COUNT(p.id) as post_count,
           COALESCE(SUM(p.likes_count), 0) as total_likes,
           RANK() OVER (ORDER BY COALESCE(SUM(p.likes_count), 0) DESC) as likes_rank
    FROM auth_user u
    LEFT JOIN app_post p ON u.id = p.author_id
    WHERE u.date_joined >= %s
    GROUP BY u.id, u.username
    ORDER BY total_likes DESC
    LIMIT 100
\"\"\", [timezone.now() - timedelta(days=30)])

# Execute raw SQL with parameters
with connection.cursor() as cursor:
    cursor.execute(\"\"\"
        UPDATE app_userprofile 
        SET follower_count = (
            SELECT COUNT(*) FROM app_follow 
            WHERE following_id = app_userprofile.user_id
        )
    \"\"\")
```

## Real-World Optimization Example: Social Media Search

```python
class OptimizedSocialMediaSearch:
    """
    Highly optimized search system like Twitter's search functionality
    """
    
    @staticmethod
    def search_posts(query, user=None, filters=None, page=1, per_page=20):
        """
        Multi-faceted search with performance optimizations
        """
        base_query = Post.objects.select_related(
            'author', 'author__profile'
        ).prefetch_related(
            Prefetch(
                'hashtags',
                queryset=Hashtag.objects.only('name')
            )
        )
        
        # Text search optimization
        search_filters = Q()
        
        if query:
            # Optimize for different search patterns
            if query.startswith('@'):
                # Username search
                username = query[1:]
                search_filters = Q(author__username__istartswith=username)
            elif query.startswith('#'):
                # Hashtag search
                hashtag = query[1:]
                search_filters = Q(hashtags__name__iexact=hashtag)
            elif query.startswith('url:'):
                # URL search
                url = query[4:]
                search_filters = Q(content__icontains=url)
            else:
                # Full-text search
                search_filters = Q(
                    Q(content__icontains=query) |
                    Q(author__username__icontains=query) |
                    Q(hashtags__name__icontains=query)
                )
        
        # Apply filters
        if filters:
            if filters.get('date_from'):
                search_filters &= Q(created_at__gte=filters['date_from'])
            if filters.get('date_to'):
                search_filters &= Q(created_at__lte=filters['date_to'])
            if filters.get('min_likes'):
                search_filters &= Q(likes_count__gte=filters['min_likes'])
            if filters.get('verified_only'):
                search_filters &= Q(author__profile__is_verified=True)
        
        # Privacy filtering
        privacy_filter = Q(is_public=True)
        if user and user.is_authenticated:
            # Include posts from users they follow
            privacy_filter |= Q(author__in=user.following.all())
            # Include their own posts
            privacy_filter |= Q(author=user)
        
        # Combine all filters
        final_query = base_query.filter(
            search_filters & privacy_filter
        ).annotate(
            # Relevance scoring
            relevance_score=Case(
                # Exact username match gets highest score
                When(author__username__iexact=query, then=1000),
                # Exact hashtag match
                When(hashtags__name__iexact=query.lstrip('#'), then=800),
                # Content starts with query
                When(content__istartswith=query, then=600),
                # Content contains query
                When(content__icontains=query, then=400),
                # Author username contains query
                When(author__username__icontains=query, then=300),
                default=0,
                output_field=IntegerField()
            ),
            
            # Engagement boost
            engagement_boost=F('likes_count') + F('comments_count') * 2,
            
            # Recency boost
            recency_boost=Case(
                When(
                    created_at__gte=timezone.now() - timedelta(hours=24),
                    then=100
                ),
                When(
                    created_at__gte=timezone.now() - timedelta(days=7),
                    then=50
                ),
                default=0,
                output_field=IntegerField()
            ),
            
            # Combined ranking score
            total_score=F('relevance_score') + F('engagement_boost') + F('recency_boost')
        ).distinct().order_by('-total_score', '-created_at')
        
        # Pagination
        offset = (page - 1) * per_page
        return final_query[offset:offset + per_page]
    
    @staticmethod
    def get_trending_hashtags(hours=24, limit=20):
        """
        Efficiently calculate trending hashtags
        """
        cutoff_time = timezone.now() - timedelta(hours=hours)
        
        return Hashtag.objects.filter(
            posts__created_at__gte=cutoff_time
        ).annotate(
            usage_count=Count('posts'),
            total_engagement=Sum(
                F('posts__likes_count') + F('posts__comments_count')
            ),
            trend_score=F('usage_count') * 10 + F('total_engagement')
        ).filter(
            usage_count__gte=5  # Minimum usage threshold
        ).order_by('-trend_score')[:limit]
    
    @staticmethod
    def optimize_user_feed(user, page=1, per_page=20):
        """
        Highly optimized personal feed generation
        """
        # Get following list once
        following_ids = list(user.following.values_list('following_id', flat=True))
        
        if not following_ids:
            # New user - show popular content
            return Post.objects.filter(
                is_public=True,
                created_at__gte=timezone.now() - timedelta(days=7)
            ).select_related('author').annotate(
                engagement_score=F('likes_count') + F('comments_count')
            ).order_by('-engagement_score')[:per_page]
        
        # Optimized feed query
        feed_posts = Post.objects.filter(
            Q(author_id__in=following_ids) |  # Use IDs for efficiency
            Q(  # Popular content from last 24 hours
                is_public=True,
                created_at__gte=timezone.now() - timedelta(hours=24),
                likes_count__gte=100
            )
        ).select_related(
            'author'
        ).prefetch_related(
            Prefetch(
                'comments',
                queryset=Comment.objects.select_related('author')[:3],
                to_attr='preview_comments'
            )
        ).annotate(
            # Feed ranking algorithm
            feed_score=Case(
                # Friends' content gets priority
                When(author_id__in=following_ids, then=1000),
                default=0,
                output_field=IntegerField()
            ) + F('likes_count') + F('comments_count') * 2
        ).order_by('-feed_score', '-created_at')
        
        # Pagination
        offset = (page - 1) * per_page
        return feed_posts[offset:offset + per_page]

# Usage examples
search_service = OptimizedSocialMediaSearch()

# Text search
results = search_service.search_posts(
    query="python programming",
    filters={'min_likes': 10, 'verified_only': True}
)

# Username search
user_posts = search_service.search_posts(query="@django_dev")

# Trending analysis
trending = search_service.get_trending_hashtags(hours=6)
```

## Performance Monitoring and Best Practices

### Query Performance Monitoring
```python
import time
from django.db import connection
from django.conf import settings

class QueryProfiler:
    """Monitor and profile database queries"""
    
    def __init__(self):
        self.start_time = None
        self.start_queries = len(connection.queries)
    
    def __enter__(self):
        self.start_time = time.time()
        self.start_queries = len(connection.queries)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = time.time()
        end_queries = len(connection.queries)
        
        execution_time = end_time - self.start_time
        query_count = end_queries - self.start_queries
        
        print(f"Execution time: {execution_time:.2f}s")
        print(f"Database queries: {query_count}")
        
        if settings.DEBUG:
            # Show actual queries in development
            for query in connection.queries[self.start_queries:]:
                print(f"Query: {query['sql'][:100]}...")
                print(f"Time: {query['time']}s")

# Usage
with QueryProfiler():
    posts = Post.objects.select_related('author').prefetch_related('comments')[:10]
    for post in posts:
        print(f"{post.title} - {post.comments.count()} comments")
```

### Essential Optimization Checklist
```python
# ✅ Query Optimization Checklist

# 1. Always use select_related for forward relationships
posts = Post.objects.select_related('author', 'category')

# 2. Use prefetch_related for reverse/M2M relationships
posts = Post.objects.prefetch_related('comments', 'tags')

# 3. Use only() and defer() for large objects
posts = Post.objects.only('title', 'created_at')  # Only these fields
posts = Post.objects.defer('content')  # All fields except content

# 4. Use values() and values_list() for simple data
usernames = User.objects.values_list('username', flat=True)
user_data = User.objects.values('id', 'username', 'email')

# 5. Use exists() instead of checking length
if Post.objects.filter(author=user).exists():  # ✅ Good
if len(Post.objects.filter(author=user)) > 0:   # ❌ Bad

# 6. Use count() instead of len()
post_count = Post.objects.count()               # ✅ Good
post_count = len(Post.objects.all())           # ❌ Bad

# 7. Use bulk operations for mass updates
Post.objects.bulk_create(posts_list)           # ✅ Good
for post in posts_list:                        # ❌ Bad
    post.save()

# 8. Add database indexes for frequent queries
class Meta:
    indexes = [
        models.Index(fields=['status', '-created_at']),
        models.Index(fields=['author', 'category']),
    ]
```

Mastering field lookups and query optimization transforms your Django application from a basic CRUD app into a high-performance platform capable of handling millions of users. These techniques power the search and discovery features in platforms like Instagram, YouTube, and Amazon! 🚀

**Source:** Based on Django 6.0 Documentation - https://docs.djangoproject.com/en/6.0/topics/db/queries/ & https://docs.djangoproject.com/en/6.0/ref/models/lookups/
    ''',
    "is_free": False,
    "xp_reward": 120,
    "exercises": [
        {
            "id": "search-optimization-system",
            "title": "Build an Optimized Search and Discovery System",
            "type": "project",
            "instructions": """Create a comprehensive search and discovery system with advanced lookups and optimization:

1. Implement multi-faceted search with various field lookups
2. Create trending content discovery using date/time lookups
3. Build user recommendation system with complex queries
4. Optimize all queries for performance using best practices
5. Add query profiling and monitoring capabilities

Your solution should demonstrate:
- Comprehensive use of field lookups (exact, contains, range, date, regex)
- Query optimization techniques (select_related, prefetch_related, indexes)
- Advanced search features (autocomplete, filters, ranking)
- Performance monitoring and profiling
- Real-world search functionality like major platforms""",
            "starter_code": """from django.db import models, connection
from django.contrib.auth.models import User
from django.db.models import *
from datetime import datetime, timedelta
from django.utils import timezone
import time
import re

# Assume these models exist (expanded from previous lessons)
class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    title = models.CharField(max_length=200)
    content = models.TextField(max_length=5000)
    hashtags = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    likes_count = models.PositiveIntegerField(default=0)
    views_count = models.PositiveIntegerField(default=0)
    is_public = models.BooleanField(default=True)
    category = models.CharField(max_length=50, default='general')

class Hashtag(models.Model):
    name = models.CharField(max_length=100, unique=True)
    posts = models.ManyToManyField(Post, related_name='hashtag_objects')

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    is_verified = models.BooleanField(default=False)
    follower_count = models.PositiveIntegerField(default=0)
    bio = models.TextField(max_length=500, blank=True)

# Your task: Implement these search and optimization functions

def advanced_text_search(query, filters=None):
    \"\"\"
    Implement comprehensive text search using multiple lookup types:
    - Exact matching for usernames and hashtags
    - Contains/icontains for content search
    - Regex for pattern matching
    - Multiple field search
    \"\"\"
    # Implement advanced text search
    pass

def date_time_based_discovery(time_period='today', content_type='trending'):
    \"\"\"
    Use date/time lookups for content discovery:
    - Today's posts, this week, this month, this year
    - Peak hour analysis
    - Seasonal content patterns
    - Time-based trending
    \"\"\"
    # Implement date/time based discovery
    pass

def build_recommendation_engine(user, recommendation_type='similar_users'):
    \"\"\"
    Create recommendations using complex lookups:
    - Users with similar interests (hashtag overlap)
    - Content recommendations based on engagement patterns
    - Geographic recommendations
    - Activity-based suggestions
    \"\"\"
    # Implement recommendation engine
    pass

def optimize_search_performance(search_function):
    \"\"\"
    Optimize search queries for performance:
    - Use select_related and prefetch_related appropriately
    - Implement query analysis and profiling
    - Add database indexes suggestions
    - Minimize database hits
    \"\"\"
    # Implement performance optimization
    pass

class QueryProfiler:
    \"\"\"
    Profile database queries for performance analysis
    \"\"\"
    def __init__(self):
        pass
    
    def __enter__(self):
        # Implement query profiling start
        pass
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Implement query profiling end
        pass

def autocomplete_suggestions(partial_query, suggestion_type='all'):
    \"\"\"
    Create autocomplete functionality:
    - Username suggestions (startswith)
    - Hashtag suggestions (contains)
    - Content title suggestions
    - Smart ranking based on popularity
    \"\"\"
    # Implement autocomplete
    pass

# Test your implementation
# results = advanced_text_search("python programming")
# trending = date_time_based_discovery('today', 'trending')""",
            "solution": """from django.db import models, connection
from django.contrib.auth.models import User
from django.db.models import *
from datetime import datetime, timedelta, time
from django.utils import timezone
import re

def advanced_text_search(query, filters=None, user=None):
    \"\"\"
    Comprehensive text search using multiple lookup types
    \"\"\"
    base_query = Post.objects.select_related('author', 'author__profile')
    search_filters = Q()
    
    if not query:
        return base_query.none()
    
    # Clean and prepare query
    query = query.strip()
    
    # Different search patterns
    if query.startswith('@'):
        # Username exact search
        username = query[1:]
        search_filters = Q(author__username__iexact=username)
        
    elif query.startswith('#'):
        # Hashtag exact search
        hashtag = query[1:]
        search_filters = Q(hashtags__icontains=f'#{hashtag}')
        
    elif query.startswith('"') and query.endswith('"'):
        # Exact phrase search
        exact_phrase = query[1:-1]
        search_filters = Q(content__icontains=exact_phrase)
        
    elif re.match(r'^\\w+@\\w+\\.\\w+$', query):
        # Email pattern - search for posts mentioning emails
        search_filters = Q(content__iregex=r'\\\\b' + re.escape(query) + r'\\\\b')
        
    elif query.startswith('url:'):
        # URL search
        url_pattern = query[4:]
        search_filters = Q(content__icontains=url_pattern)
        
    elif len(query) >= 3 and query.startswith('/') and query.endswith('/'):
        # Regex search (advanced users)
        regex_pattern = query[1:-1]
        try:
            search_filters = Q(content__iregex=regex_pattern)
        except:
            # Fallback to contains if regex is invalid
            search_filters = Q(content__icontains=query)
            
    else:
        # Multi-field comprehensive search
        search_terms = query.split()
        
        for term in search_terms:
            term_filter = Q(
                Q(title__icontains=term) |
                Q(content__icontains=term) |
                Q(author__username__icontains=term) |
                Q(author__first_name__icontains=term) |
                Q(author__last_name__icontains=term) |
                Q(hashtags__icontains=term)
            )
            
            if not search_filters:
                search_filters = term_filter
            else:
                search_filters &= term_filter  # AND logic for multiple terms
    
    # Apply additional filters
    if filters:
        if filters.get('date_from'):
            search_filters &= Q(created_at__gte=filters['date_from'])
        if filters.get('date_to'):
            search_filters &= Q(created_at__lte=filters['date_to'])
        if filters.get('category'):
            search_filters &= Q(category__iexact=filters['category'])
        if filters.get('min_likes'):
            search_filters &= Q(likes_count__gte=filters['min_likes'])
        if filters.get('verified_only'):
            search_filters &= Q(author__profile__is_verified=True)
        if filters.get('has_hashtags'):
            search_filters &= Q(hashtags__isnull=False, hashtags__ne='')
    
    # Privacy filtering
    privacy_filter = Q(is_public=True)
    if user and user.is_authenticated:
        # Include posts from followed users
        following_ids = user.following.values_list('following_id', flat=True)
        privacy_filter |= Q(author_id__in=following_ids)
        # Include own posts
        privacy_filter |= Q(author=user)
    
    # Combine filters and add relevance scoring
    results = base_query.filter(
        search_filters & privacy_filter
    ).annotate(
        # Relevance scoring based on match location
        relevance_score=Case(
            # Title exact match gets highest score
            When(title__iexact=query, then=1000),
            # Title contains query
            When(title__icontains=query, then=800),
            # Content starts with query
            When(content__istartswith=query, then=600),
            # Username exact match
            When(author__username__iexact=query.lstrip('@'), then=900),
            # Username contains query
            When(author__username__icontains=query, then=400),
            # Content contains query
            When(content__icontains=query, then=300),
            # Hashtag match
            When(hashtags__icontains=query.lstrip('#'), then=500),
            default=100,
            output_field=IntegerField()
        ),
        
        # Engagement boost
        engagement_score=F('likes_count') + F('views_count') / 10,
        
        # Recency boost
        recency_score=Case(
            When(created_at__gte=timezone.now() - timedelta(days=1), then=50),
            When(created_at__gte=timezone.now() - timedelta(days=7), then=25),
            When(created_at__gte=timezone.now() - timedelta(days=30), then=10),
            default=0,
            output_field=IntegerField()
        ),
        
        # Author credibility boost
        author_score=Case(
            When(author__profile__is_verified=True, then=100),
            When(author__profile__follower_count__gte=10000, then=50),
            When(author__profile__follower_count__gte=1000, then=25),
            default=0,
            output_field=IntegerField()
        ),
        
        # Total search score
        search_score=F('relevance_score') + F('engagement_score') + F('recency_score') + F('author_score')
    ).distinct().order_by('-search_score', '-created_at')
    
    return results

def date_time_based_discovery(time_period='today', content_type='trending', category=None):
    \"\"\"
    Advanced date/time-based content discovery
    \"\"\"
    now = timezone.now()
    base_query = Post.objects.select_related('author', 'author__profile')
    
    # Define time periods
    time_filters = {
        'hour': now - timedelta(hours=1),
        'today': now.replace(hour=0, minute=0, second=0, microsecond=0),
        'yesterday': now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1),
        'week': now - timedelta(days=7),
        'month': now.replace(day=1, hour=0, minute=0, second=0, microsecond=0),
        'year': now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0),
        'weekend': now - timedelta(days=2)  # For weekend analysis
    }
    
    # Apply time filter
    if time_period in time_filters:
        time_filter = Q(created_at__gte=time_filters[time_period])
    else:
        # Custom date range
        if isinstance(time_period, dict):
            time_filter = Q(created_at__range=(time_period['start'], time_period['end']))
        else:
            time_filter = Q(created_at__gte=now - timedelta(days=7))  # Default to week
    
    # Category filter
    if category:
        time_filter &= Q(category__iexact=category)
    
    # Content type specific logic
    if content_type == 'trending':
        # Trending content based on engagement velocity
        results = base_query.filter(time_filter).annotate(
            hours_since_post=Cast(
                (Now() - F('created_at')).total_seconds() / 3600.0,
                FloatField()
            ),
            engagement_rate=Case(
                When(hours_since_post__gt=0,
                     then=(F('likes_count') + F('views_count') / 10) / F('hours_since_post')),
                default=F('likes_count') + F('views_count') / 10,
                output_field=FloatField()
            ),
            total_engagement=F('likes_count') + F('views_count') / 10
        ).filter(
            total_engagement__gte=10  # Minimum engagement threshold
        ).order_by('-engagement_rate', '-total_engagement')
        
    elif content_type == 'peak_hours':
        # Analyze posting patterns by hour
        results = base_query.filter(time_filter).extra(
            select={'hour': 'EXTRACT(hour FROM created_at)'}
        ).values('hour').annotate(
            post_count=Count('id'),
            avg_likes=Avg('likes_count'),
            avg_views=Avg('views_count'),
            total_engagement=Sum(F('likes_count') + F('views_count'))
        ).order_by('-total_engagement')
        
    elif content_type == 'seasonal':
        # Seasonal content analysis
        results = base_query.filter(time_filter).extra(
            select={
                'month': 'EXTRACT(month FROM created_at)',
                'day_of_week': 'EXTRACT(dow FROM created_at)'
            }
        ).values('month', 'day_of_week').annotate(
            post_count=Count('id'),
            avg_engagement=Avg(F('likes_count') + F('views_count'))
        ).order_by('-avg_engagement')
        
    elif content_type == 'business_hours':
        # Business hours vs after-hours analysis
        results = base_query.filter(time_filter).annotate(
            is_business_hours=Case(
                When(
                    created_at__time__gte=time(9, 0),
                    created_at__time__lt=time(17, 0),
                    created_at__week_day__in=[2, 3, 4, 5, 6],  # Mon-Fri
                    then=True
                ),
                default=False,
                output_field=BooleanField()
            )
        ).values('is_business_hours').annotate(
            post_count=Count('id'),
            avg_engagement=Avg(F('likes_count') + F('views_count'))
        )
        
    else:  # Default: recent popular content
        results = base_query.filter(time_filter).annotate(
            engagement_score=F('likes_count') + F('views_count') / 10
        ).order_by('-engagement_score', '-created_at')
    
    return results

def build_recommendation_engine(user, recommendation_type='similar_users', limit=20):
    \"\"\"
    Advanced recommendation system using complex queries
    \"\"\"
    
    if recommendation_type == 'similar_users':
        # Find users with similar hashtag interests
        user_hashtags = set()
        user_posts = Post.objects.filter(author=user, hashtags__isnull=False)
        for post in user_posts:
            hashtags = re.findall(r'#(\\w+)', post.hashtags.lower())
            user_hashtags.update(hashtags)
        
        if not user_hashtags:
            # Fallback: users in same categories
            user_categories = Post.objects.filter(author=user).values_list('category', flat=True).distinct()
            similar_users = User.objects.filter(
                posts__category__in=user_categories
            ).exclude(id=user.id).annotate(
                common_categories=Count('posts__category', distinct=True),
                total_engagement=Sum(F('posts__likes_count') + F('posts__views_count'))
            ).order_by('-common_categories', '-total_engagement')[:limit]
        else:
            # Users with overlapping hashtag usage
            hashtag_pattern = '|'.join(user_hashtags)
            similar_users = User.objects.filter(
                posts__hashtags__iregex=f'#({hashtag_pattern})\\\\b'
            ).exclude(id=user.id).annotate(
                hashtag_overlap_score=Count(
                    'posts',
                    filter=Q(posts__hashtags__iregex=f'#({hashtag_pattern})\\\\b')
                ),
                total_posts=Count('posts'),
                engagement_score=Sum(F('posts__likes_count') + F('posts__views_count'))
            ).filter(
                hashtag_overlap_score__gte=2  # At least 2 posts with common hashtags
            ).order_by('-hashtag_overlap_score', '-engagement_score')[:limit]
        
        return similar_users
    
    elif recommendation_type == 'content_for_user':
        # Recommend content based on user's engagement patterns
        user_engaged_categories = Post.objects.filter(
            author=user
        ).values('category').annotate(
            post_count=Count('id')
        ).order_by('-post_count').values_list('category', flat=True)[:5]
        
        # Content from similar engagement patterns
        recommended_posts = Post.objects.exclude(
            author=user
        ).filter(
            category__in=user_engaged_categories,
            is_public=True,
            created_at__gte=timezone.now() - timedelta(days=30)
        ).annotate(
            engagement_score=F('likes_count') + F('views_count') / 5,
            category_relevance=Case(
                *[When(category=cat, then=idx * 10) for idx, cat in enumerate(reversed(list(user_engaged_categories)), 1)],
                default=0,
                output_field=IntegerField()
            )
        ).order_by('-category_relevance', '-engagement_score')[:limit]
        
        return recommended_posts
    
    elif recommendation_type == 'trending_hashtags':
        # Trending hashtags based on recent usage and growth
        recent_posts = Post.objects.filter(
            created_at__gte=timezone.now() - timedelta(days=7),
            hashtags__isnull=False
        )
        
        hashtag_stats = {}
        for post in recent_posts:
            hashtags = re.findall(r'#(\\w+)', post.hashtags.lower())
            for hashtag in hashtags:
                if hashtag not in hashtag_stats:
                    hashtag_stats[hashtag] = {'count': 0, 'engagement': 0}
                hashtag_stats[hashtag]['count'] += 1
                hashtag_stats[hashtag]['engagement'] += post.likes_count + post.views_count
        
        # Sort by engagement and usage
        trending = sorted(
            hashtag_stats.items(),
            key=lambda x: (x[1]['engagement'], x[1]['count']),
            reverse=True
        )[:limit]
        
        return [{'hashtag': tag, 'stats': stats} for tag, stats in trending]
    
    elif recommendation_type == 'explore_users':
        # Diverse user discovery based on different factors
        explore_users = User.objects.exclude(id=user.id).annotate(
            recent_posts=Count(
                'posts',
                filter=Q(posts__created_at__gte=timezone.now() - timedelta(days=30))
            ),
            total_engagement=Sum(F('posts__likes_count') + F('posts__views_count')),
            diversity_score=Count('posts__category', distinct=True),
            consistency_score=Case(
                When(recent_posts__gte=5, then=50),
                When(recent_posts__gte=2, then=25),
                When(recent_posts__gte=1, then=10),
                default=0,
                output_field=IntegerField()
            )
        ).filter(
            recent_posts__gte=1  # Active users only
        ).annotate(
            discovery_score=F('total_engagement') / 10 + F('diversity_score') * 20 + F('consistency_score')
        ).order_by('-discovery_score')[:limit]
        
        return explore_users
    
    return User.objects.none()

def optimize_search_performance(search_function):
    \"\"\"
    Performance optimization wrapper for search functions
    \"\"\"
    def optimized_wrapper(*args, **kwargs):
        # Add performance optimizations
        original_result = search_function(*args, **kwargs)
        
        # If it's a QuerySet, apply optimizations
        if hasattr(original_result, 'select_related'):
            # Add common optimizations
            optimized_result = original_result.select_related(
                'author', 'author__profile'
            ).prefetch_related(
                Prefetch(
                    'author__posts',
                    queryset=Post.objects.only('id', 'likes_count', 'created_at'),
                    to_attr='recent_posts_preview'
                )
            ).only(
                'id', 'title', 'content', 'created_at', 'likes_count', 'views_count',
                'author__id', 'author__username', 'author__profile__is_verified'
            )
            
            return optimized_result
        
        return original_result
    
    return optimized_wrapper

class QueryProfiler:
    \"\"\"
    Comprehensive query profiling and performance monitoring
    \"\"\"
    
    def __init__(self, description=\"Query Block\"):
        self.description = description
        self.start_time = None
        self.start_query_count = 0
        self.queries = []
    
    def __enter__(self):
        self.start_time = time.time()
        self.start_query_count = len(connection.queries)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = time.time()
        end_query_count = len(connection.queries)
        
        execution_time = end_time - self.start_time
        query_count = end_query_count - self.start_query_count
        self.queries = connection.queries[self.start_query_count:end_query_count]
        
        print(f"\\n📊 {self.description} Performance Report:")
        print(f"⏱️  Execution Time: {execution_time:.3f}s")
        print(f"🔍 Database Queries: {query_count}")
        
        if query_count > 0:
            total_query_time = sum(float(q['time']) for q in self.queries)
            print(f"💾 Total Query Time: {total_query_time:.3f}s")
            print(f"📈 Average Query Time: {total_query_time/query_count:.3f}s")
            
            # Identify slow queries
            slow_queries = [q for q in self.queries if float(q['time']) > 0.1]
            if slow_queries:
                print(f"⚠️  Slow Queries ({len(slow_queries)}):")
                for q in slow_queries:
                    print(f"   {q['time']}s: {q['sql'][:100]}...")
            
            # Check for potential N+1 problems
            if query_count > 10:
                print(f"⚡ Potential N+1 Problem: {query_count} queries detected")
        
        print("-" * 50)

def autocomplete_suggestions(partial_query, suggestion_type='all', limit=10):
    \"\"\"
    Smart autocomplete with ranking and relevance
    \"\"\"
    if len(partial_query) < 2:
        return []
    
    suggestions = []
    partial_lower = partial_query.lower()
    
    if suggestion_type in ['all', 'users']:
        # Username suggestions with popularity scoring
        user_suggestions = User.objects.filter(
            username__istartswith=partial_lower
        ).select_related('profile').annotate(
            post_count=Count('posts'),
            follower_count=Coalesce('profile__follower_count', 0),
            is_verified=Coalesce('profile__is_verified', False),
            popularity_score=F('follower_count') + F('post_count') * 10 + Case(
                When(is_verified=True, then=1000),
                default=0,
                output_field=IntegerField()
            )
        ).order_by('-popularity_score', 'username')[:limit//2]
        
        for user in user_suggestions:
            suggestions.append({
                'type': 'user',
                'value': f'@{user.username}',
                'display': f'@{user.username}',
                'meta': {
                    'followers': user.follower_count,
                    'verified': user.is_verified,
                    'posts': user.post_count
                }
            })
    
    if suggestion_type in ['all', 'hashtags']:
        # Hashtag suggestions based on recent usage
        hashtag_pattern = f'#{partial_lower}'
        recent_hashtags = Post.objects.filter(
            hashtags__icontains=hashtag_pattern,
            created_at__gte=timezone.now() - timedelta(days=30)
        ).values('hashtags').annotate(
            usage_count=Count('hashtags')
        )
        
        # Extract and rank hashtags
        hashtag_counts = {}
        for post in recent_hashtags:
            hashtags = re.findall(r'#(\\w+)', post['hashtags'].lower())
            for tag in hashtags:
                if tag.startswith(partial_lower):
                    hashtag_counts[tag] = hashtag_counts.get(tag, 0) + post['usage_count']
        
        sorted_hashtags = sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)
        for tag, count in sorted_hashtags[:limit//2]:
            suggestions.append({
                'type': 'hashtag',
                'value': f'#{tag}',
                'display': f'#{tag}',
                'meta': {'usage_count': count}
            })
    
    if suggestion_type in ['all', 'content']:
        # Content title suggestions
        title_suggestions = Post.objects.filter(
            title__icontains=partial_lower,
            is_public=True
        ).annotate(
            engagement=F('likes_count') + F('views_count')
        ).order_by('-engagement').values('title', 'engagement')[:limit//3]
        
        for post in title_suggestions:
            suggestions.append({
                'type': 'content',
                'value': post['title'],
                'display': post['title'][:50] + '...' if len(post['title']) > 50 else post['title'],
                'meta': {'engagement': post['engagement']}
            })
    
    # Sort all suggestions by relevance and type priority
    type_priority = {'user': 3, 'hashtag': 2, 'content': 1}
    suggestions.sort(key=lambda x: (type_priority.get(x['type'], 0), -x['meta'].get('usage_count', 0), -x['meta'].get('followers', 0)), reverse=True)
    
    return suggestions[:limit]

# Performance testing and usage examples
def demonstrate_optimization():
    \"\"\"Show the difference between optimized and unoptimized queries\"\"\"
    
    print("🚀 Testing Search Performance\\n")
    
    # Test 1: Basic search without optimization
    print("Test 1: Unoptimized Search")
    with QueryProfiler("Unoptimized Search"):
        results = Post.objects.filter(content__icontains='python')[:10]
        for post in results:
            author_name = post.author.username  # N+1 query
            verified = post.author.profile.is_verified if hasattr(post.author, 'profile') else False
    
    # Test 2: Optimized search
    print("\\nTest 2: Optimized Search")
    with QueryProfiler("Optimized Search"):
        results = Post.objects.filter(
            content__icontains='python'
        ).select_related('author', 'author__profile')[:10]
        for post in results:
            author_name = post.author.username  # No additional queries
            verified = post.author.profile.is_verified if hasattr(post.author, 'profile') else False
    
    # Test 3: Advanced search with profiling
    print("\\nTest 3: Advanced Search System")
    with QueryProfiler("Advanced Search"):
        search_results = advanced_text_search("python programming", {
            'min_likes': 5,
            'verified_only': True
        })[:20]
        
        # Process results
        for post in search_results:
            print(f"📝 {post.title} by @{post.author.username}")

# Example usage
if __name__ == "__main__":
    # Search examples
    results = advanced_text_search("django tutorial")
    trending = date_time_based_discovery('today', 'trending')
    autocomplete = autocomplete_suggestions('pyt', 'all', 5)""",
            "test_cases": [
                {
                    "name": "Functions implement advanced lookups and optimization",
                    "input": "",
                    "expected_contains": ["icontains", "istartswith", "iregex", "select_related", "prefetch_related", "annotate"]
                }
            ],
            "xp_reward": 160,
            "hints": [
                "Use different lookup types for different search patterns (exact, contains, regex)",
                "Implement query profiling to measure and optimize performance",
                "Combine multiple field lookups with Q objects for complex search logic",
                "Always use select_related and prefetch_related for relationship optimization",
                "Create relevance scoring with Case/When for intelligent search ranking"
            ]
        }
    ]
}