"""
Enhanced SQL WHERE Conditions lesson with more exercises, quizzes, and microlearnings
"""

SQL_WHERE_CONDITIONS_ENHANCED_LESSON = {
    "id": 32,
    "chapter": 32,
    "title": "SQL Queries with WHERE Conditions - Master Data Filtering",
    "slug": "sql-where-conditions-enhanced",
    "content": '''
# SQL WHERE Conditions: Precision Data Filtering

Think of the WHERE clause as a bouncer at an exclusive club - it only lets through the data that meets your specific criteria. Whether you're finding viral TikTok videos, high-value Amazon customers, or trending Spotify tracks, WHERE clauses help you cut through millions of records to find exactly what matters.

## 🎯 Learning Objectives
By the end of this lesson, you'll be able to:
- Filter data using comparison operators (=, >, <, >=, <=, !=)
- Use range filters with BETWEEN and IN operators
- Apply pattern matching with LIKE and wildcards
- Combine conditions with AND, OR, and NOT
- Handle NULL values properly in queries
- Write complex multi-condition filters for real-world scenarios

## The WHERE Clause: Your Data Filter

The WHERE clause transforms your SELECT statements from "show me everything" to "show me exactly what I need." It's the difference between scrolling through your entire Instagram feed versus searching for posts from your best friend.

### Basic Syntax:
```sql
SELECT column1, column2
FROM table_name
WHERE condition;
```

**Real-world analogy:** WHERE is like using filters on any app - Amazon's price range, Netflix's genre selector, or Spotify's year filter. It narrows down results to exactly what you want.

## 📊 Microlearning: Comparison Operators

### Numeric Comparisons
```sql
-- Instagram: Find influencers (users with 100,000+ followers)
SELECT username, follower_count
FROM instagram_users
WHERE follower_count >= 100000;

-- YouTube: Find viral videos (1M+ views)
SELECT title, views, channel_name
FROM youtube_videos  
WHERE views > 1000000;

-- Spotify: Find recent hits (2020 or later)
SELECT title, artist, year
FROM spotify_songs
WHERE year >= 2020;
```

### Exact Matches
```sql
-- Instagram: Find verified accounts
SELECT username, follower_count
FROM instagram_users
WHERE verified = 1;

-- YouTube: Find specific channel content
SELECT title, views
FROM youtube_videos
WHERE channel_name = 'CodeAcademy';

-- Spotify: Find songs from specific year
SELECT title, artist
FROM spotify_songs
WHERE year = 2021;
```

### Inequality Filters
```sql
-- Instagram: Find non-verified accounts 
SELECT username, follower_count
FROM instagram_users
WHERE verified != 1;
-- or
WHERE verified <> 1;  -- Alternative syntax

-- YouTube: Exclude short videos (less than 10 minutes)
SELECT title, duration
FROM youtube_videos
WHERE duration != 600;  -- 600 seconds = 10 minutes

-- Spotify: Find older music (before streaming era)
SELECT title, artist, year
FROM spotify_songs
WHERE year < 2000;
```

## 🎯 Advanced Filtering Techniques

### Range Filtering with BETWEEN
```sql
-- Instagram: Find mid-tier influencers (10K-100K followers)
SELECT username, follower_count
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000;

-- YouTube: Find medium-length videos (10-30 minutes)
SELECT title, duration, channel_name
FROM youtube_videos
WHERE duration BETWEEN 600 AND 1800;  -- 10-30 minutes in seconds

-- Spotify: Find 2010s music
SELECT title, artist, year
FROM spotify_songs
WHERE year BETWEEN 2010 AND 2019;
```

### List Filtering with IN
```sql
-- Instagram: Find specific users by username
SELECT username, follower_count, verified
FROM instagram_users
WHERE username IN ('travel_sarah', 'tech_mike', 'fitness_guru');

-- YouTube: Find videos from tech channels
SELECT title, views, channel_name
FROM youtube_videos
WHERE channel_name IN ('CodeAcademy', 'DataPro', 'DevBootcamp');

-- Spotify: Find songs by popular artists
SELECT title, artist, streams
FROM spotify_songs
WHERE artist IN ('Ed Sheeran', 'The Weeknd', 'Dua Lipa');
```

### Exclusion with NOT IN
```sql
-- Instagram: Exclude specific users from analysis
SELECT username, follower_count
FROM instagram_users
WHERE username NOT IN ('spam_account', 'test_user');

-- YouTube: Exclude certain channels
SELECT title, views
FROM youtube_videos
WHERE channel_name NOT IN ('OldChannel', 'InactiveCreator');

-- Spotify: Find non-pop music
SELECT title, artist, year
FROM spotify_songs
WHERE artist NOT IN ('Taylor Swift', 'Ariana Grande');
```

## 📝 Text Pattern Matching

### Partial Text Matching with LIKE
```sql
-- Instagram: Find travel-related accounts
SELECT username, follower_count
FROM instagram_users
WHERE username LIKE '%travel%';  -- Contains 'travel'

-- YouTube: Find tutorial videos
SELECT title, views, channel_name
FROM youtube_videos
WHERE title LIKE '%Tutorial%';  -- Contains 'Tutorial'

-- Spotify: Find songs with 'love' in the title
SELECT title, artist
FROM spotify_songs
WHERE title LIKE '%love%';
```

### Pattern Matching Wildcards
```sql
-- % = any number of characters
-- _ = exactly one character

-- Instagram: Find usernames starting with 'tech'
SELECT username, follower_count
FROM instagram_users
WHERE username LIKE 'tech%';

-- YouTube: Find titles ending with 'Course'
SELECT title, channel_name
FROM youtube_videos
WHERE title LIKE '%Course';

-- Spotify: Find 4-letter song titles
SELECT title, artist
FROM spotify_songs
WHERE title LIKE '____';  -- Exactly 4 characters
```

## 🔗 Logical Operators: Combining Conditions

### AND Operator: All Conditions Must Be True
```sql
-- Instagram: Find verified influencers with 100K+ followers
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count >= 100000 
  AND verified = 1;

-- YouTube: Find popular recent coding videos
SELECT title, views, channel_name
FROM youtube_videos
WHERE views > 500000 
  AND title LIKE '%Python%';

-- Spotify: Find recent hits by specific artists
SELECT title, artist, year, streams
FROM spotify_songs
WHERE year >= 2020 
  AND artist = 'Ed Sheeran';
```

### OR Operator: Any Condition Can Be True
```sql
-- Instagram: Find either verified accounts OR those with 200K+ followers
SELECT username, follower_count, verified
FROM instagram_users
WHERE verified = 1 
   OR follower_count >= 200000;

-- YouTube: Find videos from either CodeAcademy OR DataPro
SELECT title, views, channel_name
FROM youtube_videos
WHERE channel_name = 'CodeAcademy' 
   OR channel_name = 'DataPro';

-- Spotify: Find songs from either 2020 or 2021
SELECT title, artist, year
FROM spotify_songs
WHERE year = 2020 
   OR year = 2021;
```

### Complex Logical Combinations
```sql
-- Instagram: Find non-verified accounts with either high followers OR high following
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE verified = 0 
  AND (follower_count >= 50000 OR following >= 1000);

-- YouTube: Find either viral videos OR videos from top channels
SELECT title, views, channel_name
FROM youtube_videos
WHERE views > 1000000 
   OR channel_name IN ('CodeAcademy', 'TechEd', 'DataPro');
```

## ❓ NULL Value Handling

### Checking for Missing Data
```sql
-- Find records with missing information
SELECT username, email
FROM instagram_users
WHERE email IS NULL;

-- Find records with complete information
SELECT username, email
FROM instagram_users
WHERE email IS NOT NULL;
```

## 📈 Real-World WHERE Clause Applications

### Social Media Analysis
```sql
-- Marketing research: Find micro-influencers (10K-100K followers)
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0;  -- Non-verified accounts often charge less

-- Content strategy: Find successful tech YouTubers
SELECT title, views, likes, channel_name
FROM youtube_videos
WHERE title LIKE '%tech%' 
   OR title LIKE '%coding%' 
   OR title LIKE '%programming%'
  AND views > 100000;
```

### Music Industry Analytics
```sql
-- Label research: Find trending artists with multiple hits
SELECT artist, title, streams, year
FROM spotify_songs
WHERE streams > 1000000
  AND year >= 2020
ORDER BY artist, streams DESC;

-- Playlist curation: Find upbeat songs from specific era
SELECT title, artist, year
FROM spotify_songs
WHERE year BETWEEN 2015 AND 2020
  AND (title LIKE '%happy%' OR title LIKE '%dance%' OR title LIKE '%party%');
```

## ⚡ WHERE Clause Best Practices

### 1. Use Appropriate Data Types
```sql
-- ❌ Comparing numbers as text
WHERE follower_count = '100000'

-- ✅ Proper numeric comparison  
WHERE follower_count = 100000
```

### 2. Be Careful with NULL Values
```sql
-- ❌ This won't find NULL values
WHERE email = NULL

-- ✅ Proper NULL checking
WHERE email IS NULL
```

### 3. Use Parentheses for Complex Logic
```sql
-- ❌ Ambiguous logic
WHERE verified = 1 OR follower_count > 100000 AND following < 500

-- ✅ Clear intention with parentheses
WHERE verified = 1 OR (follower_count > 100000 AND following < 500)
```

### 4. Consider Performance
```sql
-- ✅ More efficient (specific first)
WHERE verified = 1 AND follower_count > 100000

-- ❌ Less efficient (expensive calculation first)  
WHERE follower_count > 100000 AND verified = 1
```

## 🏭 Common WHERE Clause Patterns by Industry

### E-commerce (Amazon-style)
```sql
-- Find bestselling products in price range
SELECT product_name, price, sales_count
FROM products
WHERE price BETWEEN 20 AND 100
  AND sales_count > 1000
  AND category = 'Electronics';
```

### Social Media (Instagram-style)
```sql
-- Find engagement opportunities  
SELECT username, follower_count, following
FROM users
WHERE follower_count < 10000
  AND following > 5000
  AND verified = 0;
```

### Streaming (Netflix-style)
```sql
-- Find binge-worthy content
SELECT title, genre, rating, season_count
FROM shows
WHERE rating >= 8.0
  AND season_count >= 3
  AND genre IN ('Drama', 'Thriller', 'Sci-Fi');
```

The WHERE clause is your precision tool for data analysis. Master these patterns, and you'll be able to slice and dice data like the analytics teams at Facebook, Google, or any major tech company. Every business insight starts with asking the right questions - and WHERE clauses help you find the right answers! 🎯
    ''',
    "is_free": False,
    "xp_reward": 110,
    "exercises": [
        {
            "id": "where-basics-quiz",
            "title": "🧠 WHERE Clause Fundamentals Quiz",
            "type": "quiz",
            "instructions": "Test your understanding of WHERE clause basics before moving to hands-on practice.",
            "questions": [
                {
                    "question": "Which operator would you use to find users with exactly 50,000 followers?",
                    "options": [">=", "=", "BETWEEN", "LIKE"],
                    "correct": 1,
                    "explanation": "The = operator is used for exact matches. To find exactly 50,000 followers, use WHERE follower_count = 50000"
                },
                {
                    "question": "What's the correct way to check for NULL email addresses?",
                    "options": ["WHERE email = NULL", "WHERE email IS NULL", "WHERE email == NULL", "WHERE email = ''"],
                    "correct": 1,
                    "explanation": "NULL values must be checked using IS NULL or IS NOT NULL. Regular comparison operators don't work with NULL values."
                },
                {
                    "question": "Which wildcard character means 'exactly one character' in LIKE patterns?",
                    "options": ["%", "_", "*", "?"],
                    "correct": 1,
                    "explanation": "The underscore (_) represents exactly one character, while % represents any number of characters."
                },
                {
                    "question": "What does this query find: WHERE follower_count BETWEEN 1000 AND 5000",
                    "options": ["Users with 1001-4999 followers", "Users with 1000-5000 followers", "Users with 1000+ followers", "Users with less than 5000 followers"],
                    "correct": 1,
                    "explanation": "BETWEEN is inclusive, so it includes both boundary values (1000 and 5000)."
                },
                {
                    "question": "In this condition: WHERE verified = 1 OR follower_count > 100000 AND following < 500, which operation happens first?",
                    "options": ["OR", "AND", "Both at same time", "Left to right order"],
                    "correct": 1,
                    "explanation": "AND has higher precedence than OR. Use parentheses for clarity: WHERE verified = 1 OR (follower_count > 100000 AND following < 500)"
                }
            ],
            "xp_reward": 25
        },
        {
            "id": "instagram-micro-analysis",
            "title": "📱 Instagram Microlearning: Basic Filtering",
            "type": "microlearning",
            "instructions": "Quick 5-minute practice with Instagram data filtering fundamentals.",
            "content": """
## 📱 Instagram Data Analysis Microlearning

Let's practice basic WHERE clauses with Instagram user data. This is a quick session - each query should take 30 seconds to write!

### Dataset Overview:
```sql
-- The instagram_users table contains:
id, username, email, follower_count, following, verified (0 or 1), created_at
```

### Your Tasks (Complete each in order):
            """,
            "exercises": [
                {
                    "prompt": "Find all verified Instagram users (verified = 1)",
                    "solution": "SELECT username, follower_count FROM instagram_users WHERE verified = 1;",
                    "hint": "Use the = operator to check if verified equals 1"
                },
                {
                    "prompt": "Find users with more than 100,000 followers",
                    "solution": "SELECT username, follower_count FROM instagram_users WHERE follower_count > 100000;",
                    "hint": "Use the > operator for 'greater than' comparisons"
                },
                {
                    "prompt": "Find users who follow between 500 and 2000 people",
                    "solution": "SELECT username, following FROM instagram_users WHERE following BETWEEN 500 AND 2000;",
                    "hint": "BETWEEN is perfect for range queries - it includes both boundary values"
                }
            ],
            "xp_reward": 15
        },
        {
            "id": "instagram-influencer-analysis",
            "title": "📸 Instagram Influencer Analysis with WHERE",
            "type": "practice", 
            "instructions": """Use WHERE clauses to analyze Instagram user data and find different types of influencers and accounts.

Your tasks:
1. First, explore the full dataset with SELECT * FROM instagram_users;
2. Find mega-influencers (500K+ followers)
3. Find verified accounts only
4. Find micro-influencers (10K-100K followers) who are not verified
5. Find users with specific usernames
6. Find accounts with high following counts (1000+)
7. Find potential bot accounts (following > 5000 AND follower_count < 1000)

Table: instagram_users
Columns: id, username, email, follower_count, following, verified""",
            "starter_code": """-- Task 1: Explore the full dataset
SELECT * FROM instagram_users;

-- Task 2: Find mega-influencers (500K+ followers)
-- Write a query to find users with follower_count >= 500000


-- Task 3: Find only verified accounts
-- Write a query to find users where verified = 1


-- Task 4: Find non-verified micro-influencers (10K-100K followers)
-- Use AND to combine follower_count range with verified = 0


-- Task 5: Find specific users by username
-- Use IN to find users with usernames 'travel_sarah', 'tech_mike', 'fitness_guru'


-- Task 6: Find accounts with high following counts
-- Find users who follow 1000 or more people


-- Task 7: Find potential bot accounts
-- Find accounts with following > 5000 AND follower_count < 1000
""",
            "solution": """-- Task 1: Explore the full dataset
SELECT * FROM instagram_users;

-- Task 2: Find mega-influencers (500K+ followers)
SELECT username, follower_count, verified
FROM instagram_users
WHERE follower_count >= 500000;

-- Task 3: Find only verified accounts  
SELECT username, follower_count, verified
FROM instagram_users
WHERE verified = 1;

-- Task 4: Find non-verified micro-influencers (10K-100K followers)
SELECT username, follower_count, verified
FROM instagram_users  
WHERE follower_count BETWEEN 10000 AND 100000
  AND verified = 0;

-- Task 5: Find specific users by username
SELECT username, follower_count, following, verified
FROM instagram_users
WHERE username IN ('travel_sarah', 'tech_mike', 'fitness_guru');

-- Task 6: Find accounts with high following counts
SELECT username, following, follower_count
FROM instagram_users
WHERE following >= 1000;

-- Task 7: Find potential bot accounts
SELECT username, following, follower_count, verified
FROM instagram_users
WHERE following > 5000 AND follower_count < 1000;""",
            "test_cases": [
                {
                    "name": "WHERE with numeric comparison",
                    "input": "SELECT * FROM instagram_users WHERE follower_count >= 500000;",
                    "expected_contains": ["WHERE", "follower_count", ">="]
                },
                {
                    "name": "WHERE with BETWEEN and AND",
                    "input": "SELECT * FROM instagram_users WHERE follower_count BETWEEN 10000 AND 100000 AND verified = 0;",
                    "expected_contains": ["BETWEEN", "AND", "verified"]
                }
            ],
            "xp_reward": 35,
            "hints": [
                "Use >= for 'greater than or equal to' comparisons",
                "BETWEEN includes both boundary values (10000 AND 100000)",
                "Use AND to combine multiple conditions",
                "IN operator works with a list of values in parentheses"
            ]
        },
        {
            "id": "youtube-pattern-matching",
            "title": "🎬 YouTube Pattern Matching Challenge",
            "type": "challenge",
            "instructions": """Master LIKE patterns and wildcards by finding specific YouTube content patterns.

Pattern Matching Rules:
- % = any number of characters (including zero)
- _ = exactly one character

Your advanced challenges:
1. Find all tutorial videos (title contains 'Tutorial')
2. Find programming languages in titles ('Python', 'Java', 'JavaScript', 'C++')
3. Find titles starting with 'How to'
4. Find titles ending with 'Course' or 'Bootcamp'
5. Find 4-letter channel names exactly
6. Find videos about specific topics using complex LIKE patterns

Table: youtube_videos
Columns: id, title, channel_name, views, likes, duration, category""",
            "starter_code": """-- Challenge 1: Find tutorial videos
-- Use LIKE to find videos with 'Tutorial' anywhere in the title


-- Challenge 2: Find programming content
-- Use multiple OR conditions with LIKE to find Python, Java, JavaScript, or C++ content


-- Challenge 3: Find 'How to' videos  
-- Use LIKE to find titles that start with 'How to'


-- Challenge 4: Find courses and bootcamps
-- Use LIKE with OR to find titles ending with 'Course' OR 'Bootcamp'


-- Challenge 5: Find 4-letter channel names
-- Use LIKE with underscore wildcards for exactly 4 characters


-- Challenge 6: Advanced pattern matching
-- Find videos about 'web development' OR 'data science' (case variations allowed)
""",
            "solution": """-- Challenge 1: Find tutorial videos
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE '%Tutorial%';

-- Challenge 2: Find programming content
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE '%Python%' 
   OR title LIKE '%Java%'
   OR title LIKE '%JavaScript%' 
   OR title LIKE '%C++%';

-- Challenge 3: Find 'How to' videos
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE 'How to%';

-- Challenge 4: Find courses and bootcamps
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE '%Course' 
   OR title LIKE '%Bootcamp';

-- Challenge 5: Find 4-letter channel names
SELECT DISTINCT channel_name, COUNT(*) as video_count
FROM youtube_videos
WHERE channel_name LIKE '____'
GROUP BY channel_name;

-- Challenge 6: Advanced pattern matching
SELECT title, channel_name, views
FROM youtube_videos
WHERE title LIKE '%web development%' 
   OR title LIKE '%Web Development%'
   OR title LIKE '%data science%' 
   OR title LIKE '%Data Science%';""",
            "xp_reward": 45,
            "hints": [
                "Use % at the beginning AND end for 'contains' patterns: '%Tutorial%'",
                "Use % only at the end for 'starts with' patterns: 'How to%'",
                "Use % only at the beginning for 'ends with' patterns: '%Course'",
                "Four underscores (____) match exactly 4 characters",
                "Consider case sensitivity - you might need multiple LIKE patterns"
            ]
        },
        {
            "id": "spotify-complex-conditions",
            "title": "🎵 Spotify Complex Conditions Master Class", 
            "type": "advanced",
            "instructions": """Apply advanced WHERE clause techniques to analyze Spotify music data with complex multi-condition filters.

Business Scenarios:
1. Find potential hit songs (high streams, recent, specific genres)
2. Identify breakout artists (multiple songs with good performance)
3. Find playlist-worthy tracks (specific criteria combinations)
4. Analyze music trends across different eras
5. Create targeted music recommendations

Table: spotify_songs  
Columns: id, title, artist, year, genre, streams, duration_ms, danceability, energy, valence""",
            "starter_code": """-- Scenario 1: Find potential 2023 hit songs
-- Criteria: year = 2023, streams > 1000000, genre in ('Pop', 'Hip-Hop', 'Electronic')


-- Scenario 2: Find breakout artists from 2020-2023
-- Multiple songs with streams > 500000 in recent years


-- Scenario 3: Find upbeat workout playlist tracks  
-- energy > 0.7, danceability > 0.6, duration between 3-5 minutes (180000-300000 ms)


-- Scenario 4: Find nostalgic hits from the 90s
-- year between 1990-1999, streams > 100000 (still popular today)


-- Scenario 5: Find feel-good songs for happy playlists
-- valence > 0.7 (happiness), energy > 0.5, any year after 2010


-- Scenario 6: Complex recommendation engine
-- For users who like Ed Sheeran: similar valence range (0.4-0.8), acoustic style
-- Exclude Ed Sheeran himself from results
""",
            "solution": """-- Scenario 1: Find potential 2023 hit songs
SELECT title, artist, streams, genre
FROM spotify_songs
WHERE year = 2023 
  AND streams > 1000000 
  AND genre IN ('Pop', 'Hip-Hop', 'Electronic')
ORDER BY streams DESC;

-- Scenario 2: Find breakout artists from 2020-2023
SELECT artist, COUNT(*) as hit_count, AVG(streams) as avg_streams
FROM spotify_songs
WHERE year BETWEEN 2020 AND 2023 
  AND streams > 500000
GROUP BY artist
HAVING COUNT(*) >= 2
ORDER BY hit_count DESC, avg_streams DESC;

-- Scenario 3: Find upbeat workout playlist tracks
SELECT title, artist, energy, danceability, duration_ms
FROM spotify_songs
WHERE energy > 0.7 
  AND danceability > 0.6 
  AND duration_ms BETWEEN 180000 AND 300000
ORDER BY energy DESC, danceability DESC;

-- Scenario 4: Find nostalgic hits from the 90s
SELECT title, artist, year, streams
FROM spotify_songs
WHERE year BETWEEN 1990 AND 1999 
  AND streams > 100000
ORDER BY streams DESC;

-- Scenario 5: Find feel-good songs for happy playlists  
SELECT title, artist, year, valence, energy
FROM spotify_songs
WHERE valence > 0.7 
  AND energy > 0.5 
  AND year > 2010
ORDER BY valence DESC;

-- Scenario 6: Complex recommendation engine
SELECT title, artist, valence, energy
FROM spotify_songs
WHERE artist != 'Ed Sheeran'
  AND valence BETWEEN 0.4 AND 0.8
  AND energy BETWEEN 0.3 AND 0.7  -- Similar to Ed Sheeran's style
  AND year >= 2015
ORDER BY valence;""",
            "xp_reward": 55,
            "hints": [
                "Combine multiple conditions with AND for strict criteria",
                "Use BETWEEN for numeric ranges like years and duration", 
                "IN operator is perfect for checking multiple genre values",
                "Use != or <> to exclude specific artists",
                "ORDER BY helps surface the best results first"
            ]
        },
        {
            "id": "null-values-debugging",
            "title": "🔍 NULL Values Debugging Challenge",
            "type": "debugging", 
            "instructions": """Debug and fix common WHERE clause mistakes, especially with NULL values.

You'll see broken queries with explanations of what's wrong. Fix each one!

Common Issues:
- Incorrect NULL handling
- Missing parentheses in complex conditions
- Wrong operators for data types
- Logic errors in AND/OR combinations""",
            "exercises": [
                {
                    "broken_query": "SELECT username FROM users WHERE email = NULL;",
                    "issue": "Incorrect NULL checking",
                    "fixed_query": "SELECT username FROM users WHERE email IS NULL;",
                    "explanation": "Use IS NULL or IS NOT NULL for checking NULL values, never = NULL"
                },
                {
                    "broken_query": "SELECT * FROM products WHERE price = '50' AND category = Electronics;", 
                    "issue": "Data type and string quoting errors",
                    "fixed_query": "SELECT * FROM products WHERE price = 50 AND category = 'Electronics';",
                    "explanation": "Numbers should not be quoted, text values must be quoted"
                },
                {
                    "broken_query": "SELECT * FROM users WHERE verified = 1 OR follower_count > 10000 AND following < 500;",
                    "issue": "Missing parentheses causing logic confusion",
                    "fixed_query": "SELECT * FROM users WHERE verified = 1 OR (follower_count > 10000 AND following < 500);",
                    "explanation": "AND has higher precedence than OR. Use parentheses to clarify intention."
                },
                {
                    "broken_query": "SELECT * FROM videos WHERE title LIKE 'Tutorial';",
                    "issue": "Missing wildcards in LIKE pattern",
                    "fixed_query": "SELECT * FROM videos WHERE title LIKE '%Tutorial%';",
                    "explanation": "LIKE without wildcards is just an exact match. Use % for partial matching."
                },
                {
                    "broken_query": "SELECT * FROM songs WHERE artist IN Ed Sheeran, Taylor Swift;",
                    "issue": "Missing parentheses and quotes in IN list",
                    "fixed_query": "SELECT * FROM songs WHERE artist IN ('Ed Sheeran', 'Taylor Swift');",
                    "explanation": "IN values must be in parentheses and strings must be quoted"
                }
            ],
            "xp_reward": 30
        },
        {
            "id": "ecommerce-final-challenge",
            "title": "🛒 E-commerce Analytics Final Challenge",
            "type": "capstone",
            "instructions": """Apply everything you've learned to solve real e-commerce business problems using complex WHERE clauses.

You're a data analyst at TechMart (like Amazon). Use the orders, products, and customers tables to answer business questions:

Tables:
- customers: id, name, email, registration_date, country, vip_status
- products: id, name, category, price, stock_quantity, rating, release_date  
- orders: id, customer_id, product_id, order_date, quantity, total_amount

Business Questions to Answer:""",
            "starter_code": """-- 1. Customer Segmentation: Find VIP customers who made large orders (>$500) in 2023


-- 2. Inventory Alert: Find low-stock electronics products (stock < 10, category = 'Electronics')


-- 3. Product Performance: Find highly-rated recent products (rating >= 4.0, released after 2022)


-- 4. Customer Retention: Find customers who registered in 2022 but haven't ordered since 2023-06-01


-- 5. International Sales: Find orders from customers outside the US with total > $200


-- 6. Premium Product Analysis: Find expensive products (>$100) with low ratings (<3.0)


-- 7. Seasonal Trends: Find customers who made multiple orders during Q4 2023 (Oct-Dec)


-- 8. Cross-sell Opportunities: Find customers who bought 'Electronics' but never 'Accessories'
""",
            "solution": """-- 1. Customer Segmentation: Find VIP customers who made large orders (>$500) in 2023
SELECT DISTINCT c.name, c.email, o.total_amount, o.order_date
FROM customers c
JOIN orders o ON c.id = o.customer_id
WHERE c.vip_status = 1 
  AND o.total_amount > 500
  AND YEAR(o.order_date) = 2023
ORDER BY o.total_amount DESC;

-- 2. Inventory Alert: Find low-stock electronics products (stock < 10, category = 'Electronics')
SELECT name, stock_quantity, price
FROM products
WHERE category = 'Electronics' 
  AND stock_quantity < 10
ORDER BY stock_quantity ASC;

-- 3. Product Performance: Find highly-rated recent products (rating >= 4.0, released after 2022)
SELECT name, rating, release_date, category, price
FROM products
WHERE rating >= 4.0 
  AND release_date > '2022-12-31'
ORDER BY rating DESC;

-- 4. Customer Retention: Find customers who registered in 2022 but haven't ordered since 2023-06-01
SELECT c.name, c.email, c.registration_date, MAX(o.order_date) as last_order
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE YEAR(c.registration_date) = 2022
GROUP BY c.id, c.name, c.email, c.registration_date
HAVING MAX(o.order_date) < '2023-06-01' OR MAX(o.order_date) IS NULL;

-- 5. International Sales: Find orders from customers outside the US with total > $200
SELECT c.name, c.country, o.total_amount, o.order_date
FROM customers c
JOIN orders o ON c.id = o.customer_id
WHERE c.country != 'US' 
  AND o.total_amount > 200
ORDER BY o.total_amount DESC;

-- 6. Premium Product Analysis: Find expensive products (>$100) with low ratings (<3.0)
SELECT name, price, rating, category
FROM products
WHERE price > 100 
  AND rating < 3.0
ORDER BY price DESC;

-- 7. Seasonal Trends: Find customers who made multiple orders during Q4 2023 (Oct-Dec)
SELECT c.name, COUNT(o.id) as order_count, SUM(o.total_amount) as total_spent
FROM customers c
JOIN orders o ON c.id = o.customer_id
WHERE o.order_date BETWEEN '2023-10-01' AND '2023-12-31'
GROUP BY c.id, c.name
HAVING COUNT(o.id) >= 2
ORDER BY order_count DESC;

-- 8. Cross-sell Opportunities: Find customers who bought 'Electronics' but never 'Accessories'
SELECT DISTINCT c.name, c.email
FROM customers c
JOIN orders o1 ON c.id = o1.customer_id
JOIN products p1 ON o1.product_id = p1.id
WHERE p1.category = 'Electronics'
  AND NOT EXISTS (
    SELECT 1 
    FROM orders o2 
    JOIN products p2 ON o2.product_id = p2.id
    WHERE o2.customer_id = c.id 
      AND p2.category = 'Accessories'
  );""",
            "xp_reward": 75,
            "difficulty": "advanced",
            "business_impact": "These queries solve real e-commerce challenges: customer segmentation, inventory management, performance analysis, and cross-selling opportunities."
        }
    ],
    "assessment": {
        "id": "where-conditions-mastery",
        "title": "🏆 WHERE Conditions Mastery Assessment",
        "type": "comprehensive_test",
        "time_limit_minutes": 45,
        "passing_score": 80,
        "questions": [
            {
                "type": "multiple_choice",
                "question": "What is the correct way to find products with a price between $50 and $150 (inclusive)?",
                "options": [
                    "WHERE price > 50 AND price < 150",
                    "WHERE price BETWEEN 50 AND 150", 
                    "WHERE price >= 50 OR price <= 150",
                    "WHERE price IN (50, 150)"
                ],
                "correct": 1,
                "points": 5,
                "explanation": "BETWEEN is inclusive and is the most readable option for range queries."
            },
            {
                "type": "code_completion", 
                "question": "Complete this query to find Instagram users who are either verified OR have more than 100K followers:",
                "incomplete_code": "SELECT username, follower_count, verified\nFROM instagram_users\nWHERE _____________;",
                "correct_answer": "verified = 1 OR follower_count > 100000",
                "points": 10,
                "test_cases": ["Must include OR operator", "Must check verified = 1", "Must check follower_count > 100000"]
            },
            {
                "type": "error_identification",
                "question": "Identify and explain what's wrong with this query:",
                "buggy_code": "SELECT * FROM users WHERE email = NULL AND username LIKE 'tech';",
                "errors": [
                    "Should use 'email IS NULL' instead of 'email = NULL'",
                    "LIKE pattern needs wildcards: 'tech%' or '%tech%' for partial matching"
                ],
                "points": 10
            },
            {
                "type": "performance_optimization",
                "question": "Which query will perform better and why?",
                "option_a": "WHERE category = 'Electronics' AND price > 100 AND stock > 0",
                "option_b": "WHERE price > 100 AND stock > 0 AND category = 'Electronics'", 
                "correct": "option_a",
                "explanation": "Filtering by exact matches (category = 'Electronics') first reduces the dataset before expensive numeric comparisons.",
                "points": 15
            }
        ],
        "practical_section": {
            "scenario": "You're analyzing an e-commerce database to improve business performance",
            "tasks": [
                {
                    "task": "Find potential fraud: orders with unusually high quantities (>50) OR high amounts (>$2000)",
                    "points": 20,
                    "expected_keywords": ["WHERE", "quantity", "total_amount", "OR", ">"]
                },
                {
                    "task": "Customer segmentation: Find VIP customers who haven't ordered in the last 6 months",
                    "points": 25,
                    "expected_keywords": ["WHERE", "vip_status", "order_date", "NULL", "IS", "NOT EXISTS", "DATE"]
                }
            ]
        },
        "xp_reward": 100
    }
}