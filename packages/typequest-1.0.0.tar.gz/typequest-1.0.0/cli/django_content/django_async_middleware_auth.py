"""
Django Async Development - Lesson 3: Async Middleware and Authentication
Master Django's async middleware, authentication, and security patterns
"""

DJANGO_ASYNC_MIDDLEWARE_AUTH_LESSON = {
    "id": 61,
    "chapter": 61,
    "title": "Django Async Middleware and Authentication: Secure Async Applications",
    "slug": "django-async-middleware-auth", 
    "description": "Learn Django's async middleware patterns, authentication systems, and security considerations for async applications",
    "content": '''# Django Async Middleware and Authentication: Secure Async Applications

## 🎯 Building on Our Async Foundation

**Extending our async database operations knowledge**, we now explore **async middleware and authentication** - essential components for production async applications. While async views and database operations handle requests efficiently, async middleware ensures **security and request processing** remains non-blocking.

**Async Middleware Benefits**:
- **Non-blocking authentication** → User validation without blocking other requests
- **Async request/response processing** → Middleware chains execute concurrently
- **Scalable session management** → Handle authentication at scale
- **Async security checks** → Rate limiting and validation without blocking
- **Concurrent middleware execution** → Process multiple middleware layers efficiently

Building on our async ListView and database patterns, we'll secure these operations with proper async authentication.

## 💾 Async Security and Authentication Database

Let's create a comprehensive database for testing async authentication and middleware:

```sql
-- ASYNC AUTHENTICATION AND SECURITY TESTING
-- Database: async_auth_security

-- Enhanced users table for async authentication
CREATE TABLE async_auth_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(150) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    first_name VARCHAR(30),
    last_name VARCHAR(150),
    is_active BOOLEAN DEFAULT TRUE,
    is_staff BOOLEAN DEFAULT FALSE,
    is_superuser BOOLEAN DEFAULT FALSE,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    failed_login_attempts INTEGER DEFAULT 0,
    account_locked_until TIMESTAMP,
    email_verified BOOLEAN DEFAULT FALSE,
    phone_number VARCHAR(20),
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    profile_image_url VARCHAR(500),
    timezone VARCHAR(50) DEFAULT 'UTC',
    preferences JSONB DEFAULT '{}'::jsonb,
    created_by_admin BOOLEAN DEFAULT FALSE
);

-- Sample authenticated users
INSERT INTO async_auth_users (username, email, password_hash, first_name, last_name, is_active, is_staff, email_verified, two_factor_enabled) VALUES
('admin_user', 'admin@asyncapp.com', 'pbkdf2_sha256$320000$abc123...', 'Admin', 'User', TRUE, TRUE, TRUE, TRUE),
('secure_alice', 'alice@secure.com', 'pbkdf2_sha256$320000$def456...', 'Alice', 'Security', TRUE, FALSE, TRUE, TRUE),
('mobile_bob', 'bob@mobile.com', 'pbkdf2_sha256$320000$ghi789...', 'Bob', 'Mobile', TRUE, FALSE, TRUE, FALSE),
('api_carol', 'carol@api.com', 'pbkdf2_sha256$320000$jkl012...', 'Carol', 'API', TRUE, FALSE, TRUE, FALSE),
('locked_dave', 'dave@locked.com', 'pbkdf2_sha256$320000$mno345...', 'Dave', 'Locked', FALSE, FALSE, FALSE, FALSE);

-- Async session management
CREATE TABLE async_user_sessions (
    session_key VARCHAR(40) PRIMARY KEY,
    user_id INTEGER,
    session_data TEXT NOT NULL,
    ip_address INET,
    user_agent TEXT,
    is_mobile BOOLEAN DEFAULT FALSE,
    location_country VARCHAR(2),
    location_city VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    login_method VARCHAR(20) DEFAULT 'password', -- 'password', 'oauth', '2fa', 'sso'
    device_fingerprint VARCHAR(128),
    FOREIGN KEY (user_id) REFERENCES async_auth_users(id)
);

-- Sample active sessions
INSERT INTO async_user_sessions (session_key, user_id, session_data, ip_address, user_agent, is_mobile, location_country, expires_at, login_method) VALUES
('async_session_1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p', 1, 'admin_session_data', '192.168.1.100', 'Mozilla/5.0 Chrome/91.0', FALSE, 'US', CURRENT_TIMESTAMP + INTERVAL '7 days', 'password'),
('secure_session_2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q', 2, 'alice_secure_data', '10.0.0.50', 'Mozilla/5.0 Safari/14.0', FALSE, 'CA', CURRENT_TIMESTAMP + INTERVAL '2 hours', '2fa'),
('mobile_session_3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r', 3, 'bob_mobile_data', '203.0.113.25', 'Mobile App v2.1', TRUE, 'GB', CURRENT_TIMESTAMP + INTERVAL '30 days', 'oauth'),
('api_session_4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s', 4, 'carol_api_data', '198.51.100.75', 'API Client v1.5', FALSE, 'DE', CURRENT_TIMESTAMP + INTERVAL '1 hour', 'password');

-- Async authentication logs
CREATE TABLE async_auth_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER,
    username VARCHAR(150),
    action VARCHAR(50) NOT NULL, -- 'login', 'logout', 'failed_login', 'password_change', '2fa_verify'
    ip_address INET,
    user_agent TEXT,
    success BOOLEAN NOT NULL,
    failure_reason VARCHAR(200),
    session_key VARCHAR(40),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processing_time_ms DECIMAL(8, 3),
    middleware_chain TEXT[], -- Array of middleware that processed this request
    is_async_request BOOLEAN DEFAULT FALSE,
    request_id UUID,
    geo_location POINT,
    risk_score INTEGER DEFAULT 0, -- 0-100, higher = more suspicious
    FOREIGN KEY (user_id) REFERENCES async_auth_users(id)
);

-- Sample authentication logs
INSERT INTO async_auth_logs (user_id, username, action, ip_address, user_agent, success, session_key, processing_time_ms, middleware_chain, is_async_request, risk_score) VALUES
(1, 'admin_user', 'login', '192.168.1.100', 'Chrome Browser', TRUE, 'async_session_1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p', 15.6, ARRAY['SecurityMiddleware', 'AuthenticationMiddleware', 'AsyncAuthMiddleware'], TRUE, 5),
(2, 'secure_alice', '2fa_verify', '10.0.0.50', 'Safari Browser', TRUE, 'secure_session_2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q', 23.4, ARRAY['SecurityMiddleware', 'TwoFactorMiddleware', 'AsyncAuthMiddleware'], TRUE, 2),
(3, 'mobile_bob', 'failed_login', '203.0.113.25', 'Mobile App', FALSE, NULL, 45.7, ARRAY['SecurityMiddleware', 'RateLimitMiddleware'], TRUE, 25),
(4, 'carol_api', 'login', '198.51.100.75', 'API Client', TRUE, 'api_session_4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s', 8.9, ARRAY['SecurityMiddleware', 'APIAuthMiddleware'], TRUE, 8),
(5, 'locked_dave', 'failed_login', '192.0.2.100', 'Unknown Client', FALSE, NULL, 67.2, ARRAY['SecurityMiddleware', 'AccountLockMiddleware'], TRUE, 85);

-- Async rate limiting
CREATE TABLE async_rate_limits (
    id SERIAL PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL, -- IP address, user ID, or API key
    identifier_type VARCHAR(20) NOT NULL, -- 'ip', 'user', 'api_key'
    endpoint VARCHAR(200) NOT NULL,
    request_count INTEGER DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    window_duration_seconds INTEGER DEFAULT 3600, -- 1 hour
    limit_per_window INTEGER DEFAULT 1000,
    blocked BOOLEAN DEFAULT FALSE,
    last_request TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    requests_blocked INTEGER DEFAULT 0,
    async_processed BOOLEAN DEFAULT TRUE,
    middleware_name VARCHAR(100) DEFAULT 'AsyncRateLimitMiddleware'
);

-- Sample rate limit data
INSERT INTO async_rate_limits (identifier, identifier_type, endpoint, request_count, limit_per_window, blocked, requests_blocked) VALUES
('192.168.1.100', 'ip', '/api/v1/posts/', 45, 100, FALSE, 0),
('10.0.0.50', 'ip', '/auth/login/', 3, 5, FALSE, 0),
('203.0.113.25', 'ip', '/auth/login/', 8, 5, TRUE, 3),
('api_user_4', 'user', '/api/v1/users/', 234, 1000, FALSE, 0),
('198.51.100.75', 'ip', '/api/v1/timeline/', 567, 500, TRUE, 67);

-- Async middleware performance metrics
CREATE TABLE async_middleware_metrics (
    id SERIAL PRIMARY KEY,
    middleware_name VARCHAR(100) NOT NULL,
    request_path VARCHAR(500) NOT NULL,
    method VARCHAR(10) NOT NULL,
    processing_time_ms DECIMAL(8, 3) NOT NULL,
    memory_usage_mb DECIMAL(8, 2),
    cpu_usage_percent DECIMAL(5, 2),
    cache_hit BOOLEAN DEFAULT FALSE,
    database_queries INTEGER DEFAULT 0,
    external_api_calls INTEGER DEFAULT 0,
    is_async BOOLEAN DEFAULT TRUE,
    concurrent_requests INTEGER DEFAULT 1,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_authenticated BOOLEAN DEFAULT FALSE,
    response_size_bytes INTEGER DEFAULT 0,
    error_occurred BOOLEAN DEFAULT FALSE
);

-- Sample middleware performance data
INSERT INTO async_middleware_metrics (middleware_name, request_path, method, processing_time_ms, memory_usage_mb, database_queries, is_async, concurrent_requests, user_authenticated) VALUES
('AsyncAuthMiddleware', '/api/v1/posts/', 'GET', 12.5, 15.2, 2, TRUE, 25, TRUE),
('AsyncSecurityMiddleware', '/admin/users/', 'POST', 8.7, 12.8, 1, TRUE, 15, TRUE),
('SyncAuthMiddleware', '/api/v1/posts/', 'GET', 45.6, 28.4, 2, FALSE, 1, TRUE),
('AsyncRateLimitMiddleware', '/auth/login/', 'POST', 3.2, 5.4, 1, TRUE, 50, FALSE),
('AsyncSessionMiddleware', '/dashboard/', 'GET', 18.9, 22.1, 3, TRUE, 35, TRUE),
('SyncSessionMiddleware', '/dashboard/', 'GET', 67.3, 45.6, 3, FALSE, 1, TRUE);

-- OAuth and external authentication
CREATE TABLE async_oauth_providers (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    provider VARCHAR(50) NOT NULL, -- 'google', 'github', 'facebook', 'twitter'
    provider_user_id VARCHAR(200) NOT NULL,
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMP,
    scope TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    profile_data JSONB DEFAULT '{}'::jsonb,
    FOREIGN KEY (user_id) REFERENCES async_auth_users(id)
);

-- Sample OAuth data
INSERT INTO async_oauth_providers (user_id, provider, provider_user_id, scope, profile_data) VALUES
(2, 'google', '104857234567890123456', ARRAY['email', 'profile'], '{"picture": "https://lh3.googleusercontent.com/abc123", "locale": "en"}'),
(3, 'github', '12345678', ARRAY['user:email', 'read:user'], '{"avatar_url": "https://avatars.githubusercontent.com/u/12345678", "company": "Tech Corp"}'),
(4, 'facebook', 'fb_987654321', ARRAY['email', 'public_profile'], '{"picture": {"data": {"url": "https://graph.facebook.com/v12.0/987654321/picture"}}}'),
(1, 'google', '200857234567890123999', ARRAY['email', 'profile', 'openid'], '{"picture": "https://lh3.googleusercontent.com/def456", "locale": "en-US"}');

-- Two-factor authentication
CREATE TABLE async_two_factor_auth (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    secret_key VARCHAR(32) NOT NULL,
    backup_codes TEXT[], -- Array of backup codes
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_verified TIMESTAMP,
    verification_attempts INTEGER DEFAULT 0,
    method VARCHAR(20) DEFAULT 'totp', -- 'totp', 'sms', 'email'
    phone_number VARCHAR(20),
    email_backup VARCHAR(254),
    device_name VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES async_auth_users(id)
);

-- Sample 2FA data
INSERT INTO async_two_factor_auth (user_id, secret_key, backup_codes, is_verified, method, device_name) VALUES
(1, 'JBSWY3DPEHPK3PXP', ARRAY['12345678', '87654321', '11111111', '22222222', '33333333'], TRUE, 'totp', 'Admin iPhone'),
(2, 'HXDMVJECJJWSRB3H', ARRAY['99999999', '88888888', '77777777', '66666666', '55555555'], TRUE, 'totp', 'Alice Android'),
(3, 'MVYGG33ENFPW2SLU', ARRAY['44444444', '00000000', '12121212', '34343434', '56565656'], FALSE, 'sms', 'Bob Mobile'),
(4, 'OV4HI2DPNVWG653U', ARRAY['78787878', '90909090', '13131313', '24242424', '35353535'], FALSE, 'email', 'Carol Laptop');
```

## 🔧 Django Async Middleware Implementation

### 1. Core Async Authentication Middleware

**Scenario**: GitHub's async user authentication system  
*Building on our async database operations for user management*

```python
# async_auth_middleware.py - Core async authentication
import asyncio
import time
import logging
from typing import Optional, Dict, Any
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.core.cache import cache
from django.utils.deprecation import MiddlewareMixin
from asgiref.sync import sync_to_async
from django.contrib.sessions.models import Session
import jwt
from datetime import datetime, timedelta

logger = logging.getLogger('async_auth')
User = get_user_model()

class AsyncAuthenticationMiddleware:
    """High-performance async authentication middleware
    Building on our async database patterns for user verification"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.cache_timeout = 300  # 5 minutes
        
    async def __call__(self, request):
        """Process request with async authentication"""
        
        start_time = time.time()
        
        # Async authentication
        request.user = await self.authenticate_user(request)
        
        # Continue to view
        response = await self.get_response(request)
        
        # Log authentication performance
        processing_time = (time.time() - start_time) * 1000
        await self.log_auth_metrics(request, processing_time)
        
        return response
    
    async def authenticate_user(self, request: HttpRequest) -> Optional[User]:
        """Authenticate user asynchronously with caching"""
        
        # Check for JWT token first (API authentication)
        auth_header = request.META.get('HTTP_AUTHORIZATION')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            user = await self.authenticate_jwt_token(token)
            if user:
                return user
        
        # Check for session authentication
        session_key = request.session.session_key
        if session_key:
            user = await self.authenticate_session(session_key)
            if user:
                return user
        
        # Return anonymous user if no authentication
        return AnonymousUser()
    
    async def authenticate_jwt_token(self, token: str) -> Optional[User]:
        """Authenticate JWT token asynchronously"""
        
        try:
            # Check cache first for performance
            cache_key = f"jwt_user_{token[:20]}"
            cached_user_id = await sync_to_async(cache.get)(cache_key)
            
            if cached_user_id:
                # Get user from database asynchronously
                try:
                    user = await User.objects.aget(id=cached_user_id, is_active=True)
                    return user
                except User.DoesNotExist:
                    pass
            
            # Decode JWT token
            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            
            if user_id:
                # Async user lookup
                try:
                    user = await User.objects.aget(id=user_id, is_active=True)
                    
                    # Cache for performance
                    await sync_to_async(cache.set)(cache_key, user.id, self.cache_timeout)
                    
                    return user
                except User.DoesNotExist:
                    logger.warning(f"JWT token references non-existent user: {user_id}")
            
        except jwt.ExpiredSignatureError:
            logger.info("JWT token expired")
        except jwt.InvalidTokenError as e:
            logger.warning(f"Invalid JWT token: {e}")
        except Exception as e:
            logger.error(f"JWT authentication error: {e}")
        
        return None
    
    async def authenticate_session(self, session_key: str) -> Optional[User]:
        """Authenticate session asynchronously"""
        
        try:
            # Check cache first
            cache_key = f"session_user_{session_key}"
            cached_user_id = await sync_to_async(cache.get)(cache_key)
            
            if cached_user_id:
                try:
                    user = await User.objects.aget(id=cached_user_id, is_active=True)
                    return user
                except User.DoesNotExist:
                    pass
            
            # Get session data asynchronously
            try:
                session = await Session.objects.select_related().aget(
                    session_key=session_key,
                    expire_date__gt=datetime.now()
                )
                
                session_data = session.get_decoded()
                user_id = session_data.get('_auth_user_id')
                
                if user_id:
                    user = await User.objects.aget(id=user_id, is_active=True)
                    
                    # Cache for performance
                    await sync_to_async(cache.set)(cache_key, user.id, self.cache_timeout)
                    
                    return user
                    
            except Session.DoesNotExist:
                logger.debug(f"Session not found: {session_key}")
            
        except Exception as e:
            logger.error(f"Session authentication error: {e}")
        
        return None
    
    async def log_auth_metrics(self, request: HttpRequest, processing_time: float):
        """Log authentication performance metrics asynchronously"""
        
        try:
            # Create metrics entry without blocking
            asyncio.create_task(self.create_auth_log_entry(
                request, processing_time
            ))
            
        except Exception as e:
            logger.error(f"Failed to log auth metrics: {e}")
    
    async def create_auth_log_entry(self, request: HttpRequest, processing_time: float):
        """Create authentication log entry asynchronously"""
        
        # This would integrate with your async database operations
        # Using the patterns we learned in the previous lesson
        auth_log_data = {
            'user_id': getattr(request.user, 'id', None),
            'username': getattr(request.user, 'username', 'anonymous'),
            'action': 'auth_check',
            'ip_address': self.get_client_ip(request),
            'user_agent': request.META.get('HTTP_USER_AGENT', ''),
            'success': not isinstance(request.user, AnonymousUser),
            'processing_time_ms': processing_time,
            'is_async_request': True,
            'request_path': request.path,
        }
        
        # Async database insert (using patterns from previous lesson)
        # await AsyncAuthLog.objects.acreate(**auth_log_data)
    
    def get_client_ip(self, request: HttpRequest) -> str:
        """Get client IP address"""
        
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', '')


class AsyncSessionMiddleware:
    """Async session management middleware"""
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    async def __call__(self, request):
        """Process sessions asynchronously"""
        
        # Initialize session
        await self.process_session(request)
        
        response = await self.get_response(request)
        
        # Save session asynchronously  
        await self.save_session(request)
        
        return response
    
    async def process_session(self, request: HttpRequest):
        """Process request session asynchronously"""
        
        session_key = request.COOKIES.get(settings.SESSION_COOKIE_NAME)
        
        if session_key:
            # Load existing session asynchronously
            request.session = await self.load_session(session_key)
        else:
            # Create new session
            request.session = {}
    
    async def load_session(self, session_key: str) -> Dict[str, Any]:
        """Load session data asynchronously"""
        
        try:
            session = await Session.objects.aget(
                session_key=session_key,
                expire_date__gt=datetime.now()
            )
            return session.get_decoded()
            
        except Session.DoesNotExist:
            return {}
    
    async def save_session(self, request: HttpRequest):
        """Save session data asynchronously"""
        
        if hasattr(request, 'session') and request.session:
            # Async session save logic would go here
            pass
```

### 2. Async Rate Limiting and Security Middleware

**Scenario**: Twitter's async rate limiting system

```python
# async_security_middleware.py - Security and rate limiting
import asyncio
import time
import hashlib
from typing import Dict, Optional, Tuple
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.core.cache import cache
from django.conf import settings
from asgiref.sync import sync_to_async
import redis.asyncio as redis

class AsyncRateLimitMiddleware:
    """Advanced async rate limiting middleware 
    Extending our async database operations for security"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.redis_client = None
        self.rate_limits = {
            'anonymous': {'requests': 100, 'window': 3600},  # 100/hour
            'authenticated': {'requests': 1000, 'window': 3600},  # 1000/hour
            'premium': {'requests': 5000, 'window': 3600},  # 5000/hour
            'api': {'requests': 10000, 'window': 3600},  # 10000/hour
        }
    
    async def __call__(self, request):
        """Process request with async rate limiting"""
        
        # Check rate limit asynchronously
        rate_limit_result = await self.check_rate_limit(request)
        
        if rate_limit_result['blocked']:
            return JsonResponse({
                'error': 'Rate limit exceeded',
                'retry_after': rate_limit_result['retry_after'],
                'limit': rate_limit_result['limit'],
                'remaining': 0
            }, status=429)
        
        # Add rate limit headers to request for view access
        request.rate_limit_info = rate_limit_result
        
        response = await self.get_response(request)
        
        # Add rate limit headers to response
        self.add_rate_limit_headers(response, rate_limit_result)
        
        return response
    
    async def check_rate_limit(self, request: HttpRequest) -> Dict:
        """Check rate limits asynchronously using Redis"""
        
        # Get rate limit key and tier
        limit_key, tier = await self.get_rate_limit_key(request)
        
        # Get rate limit configuration
        config = self.rate_limits.get(tier, self.rate_limits['anonymous'])
        
        # Use Redis for distributed rate limiting
        redis_client = await self.get_redis_client()
        
        # Current window
        current_time = int(time.time())
        window_start = current_time - (current_time % config['window'])
        
        # Redis key for this window
        redis_key = f"rate_limit:{limit_key}:{window_start}"
        
        # Get current count
        current_count = await redis_client.get(redis_key)
        current_count = int(current_count) if current_count else 0
        
        # Check if blocked
        blocked = current_count >= config['requests']
        
        if not blocked:
            # Increment counter
            pipe = redis_client.pipeline()
            pipe.incr(redis_key)
            pipe.expire(redis_key, config['window'])
            await pipe.execute()
            current_count += 1
        
        # Calculate retry after time
        retry_after = config['window'] - (current_time % config['window'])
        
        return {
            'blocked': blocked,
            'current_count': current_count,
            'limit': config['requests'],
            'remaining': max(0, config['requests'] - current_count),
            'retry_after': retry_after if blocked else 0,
            'tier': tier,
            'window_seconds': config['window']
        }
    
    async def get_rate_limit_key(self, request: HttpRequest) -> Tuple[str, str]:
        """Generate rate limit key and determine tier"""
        
        # Determine user tier
        if hasattr(request, 'user') and request.user.is_authenticated:
            if hasattr(request.user, 'is_premium') and request.user.is_premium:
                tier = 'premium'
            elif request.path.startswith('/api/'):
                tier = 'api'
            else:
                tier = 'authenticated'
            
            # Use user ID as key
            key = f"user:{request.user.id}"
        else:
            tier = 'anonymous'
            
            # Use IP address as key for anonymous users
            ip_address = self.get_client_ip(request)
            key = f"ip:{ip_address}"
        
        return key, tier
    
    async def get_redis_client(self):
        """Get Redis client for rate limiting"""
        
        if not self.redis_client:
            self.redis_client = redis.Redis(
                host=settings.REDIS_HOST,
                port=settings.REDIS_PORT,
                db=settings.REDIS_DB,
                decode_responses=True
            )
        
        return self.redis_client
    
    def get_client_ip(self, request: HttpRequest) -> str:
        """Get client IP address"""
        
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', '')
    
    def add_rate_limit_headers(self, response: HttpResponse, rate_info: Dict):
        """Add rate limiting headers to response"""
        
        response['X-RateLimit-Limit'] = str(rate_info['limit'])
        response['X-RateLimit-Remaining'] = str(rate_info['remaining'])
        response['X-RateLimit-Reset'] = str(int(time.time()) + rate_info.get('retry_after', 0))
        response['X-RateLimit-Tier'] = rate_info['tier']


class AsyncSecurityMiddleware:
    """Comprehensive async security middleware"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.suspicious_patterns = [
            r'(?i)(union|select|insert|update|delete|drop|alter|create)',
            r'(?i)(script|javascript|vbscript|onload|onerror)',
            r'(?i)(<script|<iframe|<object|<embed)',
            r'(?i)(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e\\)',
        ]
    
    async def __call__(self, request):
        """Process request with async security checks"""
        
        # Perform security checks asynchronously
        security_check = await self.perform_security_checks(request)
        
        if security_check['blocked']:
            await self.log_security_event(request, security_check)
            return JsonResponse({
                'error': 'Request blocked for security reasons',
                'incident_id': security_check['incident_id']
            }, status=403)
        
        # Add security context to request
        request.security_context = security_check
        
        response = await self.get_response(request)
        
        # Add security headers
        self.add_security_headers(response)
        
        return response
    
    async def perform_security_checks(self, request: HttpRequest) -> Dict:
        """Perform comprehensive security checks"""
        
        checks = await asyncio.gather(
            self.check_sql_injection(request),
            self.check_xss_patterns(request),
            self.check_path_traversal(request),
            self.check_suspicious_user_agent(request),
            self.check_ip_reputation(request),
            return_exceptions=True
        )
        
        # Calculate risk score
        risk_score = 0
        alerts = []
        
        for check in checks:
            if isinstance(check, dict):
                risk_score += check.get('risk_points', 0)
                if check.get('alert'):
                    alerts.append(check['alert'])
        
        # Determine if request should be blocked
        blocked = risk_score > 50  # Configurable threshold
        
        return {
            'blocked': blocked,
            'risk_score': risk_score,
            'alerts': alerts,
            'checks_performed': len([c for c in checks if isinstance(c, dict)]),
            'incident_id': hashlib.md5(f"{request.path}{time.time()}".encode()).hexdigest()[:16]
        }
    
    async def check_sql_injection(self, request: HttpRequest) -> Dict:
        """Check for SQL injection patterns"""
        
        risk_points = 0
        alert = None
        
        # Check query parameters
        for key, value in request.GET.items():
            if any(pattern in value.lower() for pattern in ['union', 'select', 'insert', 'update']):
                risk_points += 30
                alert = f"Potential SQL injection in parameter: {key}"
                break
        
        # Check POST data
        if hasattr(request, 'body') and request.body:
            body_str = request.body.decode('utf-8', errors='ignore').lower()
            if any(pattern in body_str for pattern in ['union', 'select', 'insert']):
                risk_points += 40
                alert = "Potential SQL injection in request body"
        
        return {'risk_points': risk_points, 'alert': alert}
    
    async def check_xss_patterns(self, request: HttpRequest) -> Dict:
        """Check for XSS patterns"""
        
        risk_points = 0
        alert = None
        
        # Check for script tags and javascript
        request_data = str(request.GET) + str(getattr(request, 'POST', ''))
        
        if any(pattern in request_data.lower() for pattern in ['<script', 'javascript:', 'onload=', 'onerror=']):
            risk_points += 35
            alert = "Potential XSS attack detected"
        
        return {'risk_points': risk_points, 'alert': alert}
    
    async def check_path_traversal(self, request: HttpRequest) -> Dict:
        """Check for path traversal attacks"""
        
        risk_points = 0
        alert = None
        
        if any(pattern in request.path for pattern in ['../', '..\\', '%2e%2e']):
            risk_points += 45
            alert = "Path traversal attack detected"
        
        return {'risk_points': risk_points, 'alert': alert}
    
    async def check_suspicious_user_agent(self, request: HttpRequest) -> Dict:
        """Check for suspicious user agents"""
        
        risk_points = 0
        alert = None
        
        user_agent = request.META.get('HTTP_USER_AGENT', '').lower()
        
        suspicious_agents = ['sqlmap', 'nikto', 'nmap', 'masscan', 'gobuster']
        if any(agent in user_agent for agent in suspicious_agents):
            risk_points += 50
            alert = "Suspicious user agent detected"
        
        return {'risk_points': risk_points, 'alert': alert}
    
    async def check_ip_reputation(self, request: HttpRequest) -> Dict:
        """Check IP reputation asynchronously"""
        
        risk_points = 0
        alert = None
        
        # This would integrate with external threat intelligence APIs
        # For demo purposes, we'll simulate some checks
        
        ip_address = self.get_client_ip(request)
        
        # Check if IP is in internal blacklist (async cache check)
        is_blacklisted = await sync_to_async(cache.get)(f"blacklisted_ip:{ip_address}")
        if is_blacklisted:
            risk_points += 60
            alert = f"IP address {ip_address} is blacklisted"
        
        return {'risk_points': risk_points, 'alert': alert}
    
    def get_client_ip(self, request: HttpRequest) -> str:
        """Get client IP address"""
        
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', '')
    
    async def log_security_event(self, request: HttpRequest, security_check: Dict):
        """Log security events asynchronously"""
        
        # This would use our async database operations from the previous lesson
        event_data = {
            'incident_id': security_check['incident_id'],
            'ip_address': self.get_client_ip(request),
            'user_agent': request.META.get('HTTP_USER_AGENT', ''),
            'path': request.path,
            'method': request.method,
            'risk_score': security_check['risk_score'],
            'alerts': security_check['alerts'],
            'blocked': security_check['blocked'],
            'timestamp': time.time(),
        }
        
        # Async logging without blocking the response
        asyncio.create_task(self.create_security_log_entry(event_data))
    
    async def create_security_log_entry(self, event_data: Dict):
        """Create security log entry asynchronously"""
        
        # This would integrate with your async logging system
        # Using the async database patterns from previous lessons
        pass
    
    def add_security_headers(self, response: HttpResponse):
        """Add security headers to response"""
        
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['X-XSS-Protection'] = '1; mode=block'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response['Content-Security-Policy'] = "default-src 'self'"
```

### 3. Async Two-Factor Authentication Middleware

**Scenario**: Slack's async 2FA verification system

```python
# async_2fa_middleware.py - Two-factor authentication
import asyncio
import pyotp
import qrcode
import io
import base64
from typing import Dict, Optional
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from asgiref.sync import sync_to_async

class AsyncTwoFactorMiddleware:
    """Async two-factor authentication middleware
    Integrating with our async authentication patterns"""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.required_paths = ['/admin/', '/api/admin/', '/settings/']
        self.exempt_paths = ['/auth/2fa/', '/auth/login/', '/auth/logout/']
    
    async def __call__(self, request):
        """Process request with async 2FA verification"""
        
        # Check if 2FA is required for this path
        if self.requires_2fa(request):
            # Verify 2FA asynchronously
            verification_result = await self.verify_2fa_status(request)
            
            if not verification_result['verified']:
                # Redirect to 2FA verification page
                if request.path not in self.exempt_paths:
                    return redirect(reverse('auth:2fa_verify'))
        
        response = await self.get_response(request)
        
        return response
    
    def requires_2fa(self, request: HttpRequest) -> bool:
        """Check if request path requires 2FA"""
        
        # Skip if user not authenticated
        if not hasattr(request, 'user') or not request.user.is_authenticated:
            return False
        
        # Check if path requires 2FA
        return any(request.path.startswith(path) for path in self.required_paths)
    
    async def verify_2fa_status(self, request: HttpRequest) -> Dict:
        """Verify 2FA status asynchronously"""
        
        user = request.user
        
        # Check if user has 2FA enabled
        two_factor_config = await self.get_user_2fa_config(user.id)
        
        if not two_factor_config:
            return {'verified': True, 'reason': '2FA not enabled'}
        
        # Check session for 2FA verification
        session_2fa_verified = request.session.get(f'2fa_verified_{user.id}', False)
        session_2fa_time = request.session.get(f'2fa_verified_time_{user.id}', 0)
        
        # Check if verification is still valid (30 minutes)
        current_time = time.time()
        if session_2fa_verified and (current_time - session_2fa_time) < 1800:
            return {'verified': True, 'reason': 'Session verified'}
        
        return {
            'verified': False, 
            'reason': '2FA verification required',
            'config': two_factor_config
        }
    
    async def get_user_2fa_config(self, user_id: int) -> Optional[Dict]:
        """Get user's 2FA configuration asynchronously"""
        
        # This uses our async database patterns from previous lessons
        try:
            # Simulated async database call
            # config = await TwoFactorAuth.objects.aget(
            #     user_id=user_id, 
            #     is_verified=True
            # )
            
            # For demo, return sample config
            config = {
                'id': 1,
                'user_id': user_id,
                'method': 'totp',
                'is_verified': True,
                'backup_codes_remaining': 3
            }
            
            return config
            
        except Exception:
            return None


class AsyncTwoFactorService:
    """Service for async 2FA operations"""
    
    @staticmethod
    async def setup_2fa_for_user(user_id: int) -> Dict:
        """Set up 2FA for user asynchronously"""
        
        # Generate secret key
        secret = pyotp.random_base32()
        
        # Create TOTP instance
        totp = pyotp.TOTP(secret)
        
        # Generate QR code
        qr_uri = totp.provisioning_uri(
            name=f"user_{user_id}",
            issuer_name="AsyncApp"
        )
        
        # Generate QR code image
        qr_code = qrcode.QRCode(version=1, box_size=10, border=5)
        qr_code.add_data(qr_uri)
        qr_code.make(fit=True)
        
        # Create QR code image
        qr_image = qr_code.make_image(fill_color="black", back_color="white")
        
        # Convert to base64 for display
        buffer = io.BytesIO()
        qr_image.save(buffer, format='PNG')
        qr_image_b64 = base64.b64encode(buffer.getvalue()).decode()
        
        # Generate backup codes
        backup_codes = [
            ''.join([str(random.randint(0, 9)) for _ in range(8)])
            for _ in range(10)
        ]
        
        # Save 2FA config asynchronously (using patterns from previous lessons)
        await AsyncTwoFactorService.save_2fa_config(
            user_id, secret, backup_codes
        )
        
        return {
            'secret': secret,
            'qr_code': qr_image_b64,
            'backup_codes': backup_codes,
            'setup_complete': True
        }
    
    @staticmethod
    async def verify_2fa_token(user_id: int, token: str) -> Dict:
        """Verify 2FA token asynchronously"""
        
        # Get user's 2FA config
        config = await AsyncTwoFactorService.get_2fa_config(user_id)
        
        if not config:
            return {'valid': False, 'reason': '2FA not configured'}
        
        # Verify TOTP token
        totp = pyotp.TOTP(config['secret'])
        
        if totp.verify(token):
            # Update last verified time
            await AsyncTwoFactorService.update_last_verified(user_id)
            
            return {
                'valid': True,
                'method': 'totp',
                'verification_time': time.time()
            }
        
        # Check backup codes
        if token in config.get('backup_codes', []):
            # Remove used backup code
            await AsyncTwoFactorService.remove_backup_code(user_id, token)
            
            return {
                'valid': True,
                'method': 'backup_code',
                'verification_time': time.time(),
                'backup_codes_remaining': len(config['backup_codes']) - 1
            }
        
        # Log failed attempt
        await AsyncTwoFactorService.log_failed_attempt(user_id, token)
        
        return {
            'valid': False,
            'reason': 'Invalid token',
            'attempts_remaining': 3  # Would track actual attempts
        }
    
    @staticmethod
    async def save_2fa_config(user_id: int, secret: str, backup_codes: list):
        """Save 2FA configuration asynchronously"""
        
        # This would use our async database operations
        config_data = {
            'user_id': user_id,
            'secret_key': secret,
            'backup_codes': backup_codes,
            'is_verified': False,
            'created_at': time.time()
        }
        
        # Async save using patterns from previous lesson
        # await TwoFactorAuth.objects.acreate(**config_data)
    
    @staticmethod
    async def get_2fa_config(user_id: int) -> Optional[Dict]:
        """Get 2FA configuration asynchronously"""
        
        # This would use async database operations
        # config = await TwoFactorAuth.objects.aget(user_id=user_id)
        
        # For demo
        return {
            'secret': 'JBSWY3DPEHPK3PXP',
            'backup_codes': ['12345678', '87654321'],
            'is_verified': True
        }
    
    @staticmethod
    async def update_last_verified(user_id: int):
        """Update last verification time asynchronously"""
        
        # Async update using database patterns
        # await TwoFactorAuth.objects.filter(user_id=user_id).aupdate(
        #     last_verified=timezone.now()
        # )
        pass
    
    @staticmethod
    async def remove_backup_code(user_id: int, used_code: str):
        """Remove used backup code asynchronously"""
        
        # Get current backup codes and remove used one
        # This would integrate with async database operations
        pass
    
    @staticmethod
    async def log_failed_attempt(user_id: int, token: str):
        """Log failed 2FA attempt asynchronously"""
        
        # Async logging without blocking
        asyncio.create_task(AsyncTwoFactorService.create_failed_attempt_log(
            user_id, token
        ))
    
    @staticmethod
    async def create_failed_attempt_log(user_id: int, token: str):
        """Create failed attempt log entry"""
        
        # This would use async database operations
        log_data = {
            'user_id': user_id,
            'action': '2fa_failed',
            'token_attempted': token[:4] + '*' * (len(token) - 4),
            'timestamp': time.time(),
            'ip_address': '0.0.0.0',  # Would get from request context
        }
        
        # Async log creation
        pass
```

## 🎯 Key Takeaways

1. **Async authentication prevents blocking** → Non-blocking user verification and session management
2. **Middleware chains execute concurrently** → Better performance than sync middleware stacks
3. **Async rate limiting scales efficiently** → Handle high-traffic scenarios without blocking
4. **Security checks run in parallel** → Multiple security validations without latency
5. **2FA verification is non-blocking** → Smooth user experience with async verification
6. **Caching optimizes async auth** → Reduce database calls with intelligent caching
7. **Logging happens asynchronously** → Security events tracked without response delays

Async middleware completes our async application stack - from views to database operations to security and authentication, everything runs efficiently without blocking!
''',
    "difficulty": "advanced", 
    "estimated_time": 55,
    "xp_reward": 40,
    "prerequisites": ["async_views", "django_async_fundamentals", "django_async_database_operations"],
    "exercises": [
        {
            "id": "async_middleware_1",
            "title": "Explore Async Authentication Data",
            "prompt": "Let's examine the async authentication system data. Write a query to see user authentication information.",
            "table_name": "async_auth_users",
            "initial_query": "SELECT * FROM async_auth_users LIMIT 5;",
            "expected_keywords": ["SELECT", "*", "FROM", "async_auth_users"],
            "hint": "Use SELECT * FROM async_auth_users LIMIT 5; to see user authentication data",
            "solution": "SELECT * FROM async_auth_users LIMIT 5;",
            "explanation": "This table contains user data that async authentication middleware would process. Notice fields like failed_login_attempts and two_factor_enabled that support async security features."
        },
        {
            "id": "async_middleware_2", 
            "title": "Session Management Analysis",
            "prompt": "Examine async session management data. Write a query to see active user sessions with their details.",
            "table_name": "async_user_sessions",
            "expected_keywords": ["SELECT", "session_key", "user_id", "ip_address", "login_method", "expires_at"],
            "hint": "Select session information including user, IP, login method, and expiration",
            "solution": "SELECT session_key, user_id, ip_address, user_agent, login_method, last_activity, expires_at FROM async_user_sessions WHERE is_active = true ORDER BY last_activity DESC;",
            "explanation": "Async session middleware manages these sessions without blocking. Notice login_method and device_fingerprint fields that enable sophisticated async authentication patterns."
        },
        {
            "id": "async_middleware_3",
            "title": "Authentication Performance Metrics",
            "prompt": "Analyze authentication performance between sync and async processing. Write a query to compare processing times.",
            "table_name": "async_auth_logs",
            "expected_keywords": ["SELECT", "action", "success", "processing_time_ms", "is_async_request", "AVG"],
            "hint": "Group by is_async_request and calculate average processing times",
            "solution": "SELECT is_async_request, action, AVG(processing_time_ms) as avg_time, COUNT(*) as requests, SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful FROM async_auth_logs GROUP BY is_async_request, action ORDER BY is_async_request DESC, avg_time ASC;",
            "explanation": "This shows how async authentication processing performs better than sync. Async requests typically have lower processing times and can handle more concurrent authentication checks."
        },
        {
            "id": "async_middleware_4",
            "title": "Rate Limiting Data Analysis", 
            "prompt": "Examine async rate limiting data. Write a query to see which identifiers are being rate limited.",
            "table_name": "async_rate_limits",
            "expected_keywords": ["SELECT", "identifier", "identifier_type", "request_count", "limit_per_window", "blocked"],
            "hint": "Select rate limiting information showing current usage versus limits",
            "solution": "SELECT identifier, identifier_type, endpoint, request_count, limit_per_window, (request_count::decimal / limit_per_window * 100) as usage_percent, blocked, requests_blocked FROM async_rate_limits ORDER BY usage_percent DESC;",
            "explanation": "Async rate limiting middleware tracks usage across different identifier types (IP, user, API key) without blocking legitimate requests. The async_processed field shows these were handled asynchronously."
        },
        {
            "id": "async_middleware_5",
            "title": "Middleware Performance Comparison",
            "prompt": "Compare async vs sync middleware performance. Write a query to analyze processing time differences.",
            "table_name": "async_middleware_metrics", 
            "expected_keywords": ["SELECT", "middleware_name", "processing_time_ms", "is_async", "concurrent_requests", "AVG"],
            "hint": "Group by middleware type and async status to compare performance",
            "solution": "SELECT middleware_name, is_async, AVG(processing_time_ms) as avg_time, AVG(concurrent_requests) as avg_concurrency, AVG(memory_usage_mb) as avg_memory, COUNT(*) as total_requests FROM async_middleware_metrics GROUP BY middleware_name, is_async ORDER BY middleware_name, is_async DESC;",
            "explanation": "This comparison shows async middleware significantly outperforms sync middleware, especially under concurrent load. Async middleware can handle many more concurrent requests with lower memory usage."
        },
        {
            "id": "async_middleware_6",
            "title": "Two-Factor Authentication Data",
            "prompt": "Examine two-factor authentication data for async processing. Write a query to see 2FA configurations.",
            "table_name": "async_two_factor_auth",
            "expected_keywords": ["SELECT", "user_id", "method", "is_verified", "verification_attempts", "device_name"],
            "hint": "Select 2FA setup information including method, verification status, and device details",
            "solution": "SELECT user_id, method, is_verified, verification_attempts, device_name, created_at, last_verified FROM async_two_factor_auth WHERE is_verified = true ORDER BY last_verified DESC;",
            "explanation": "Async 2FA middleware processes these configurations without blocking user requests. The system supports multiple 2FA methods (TOTP, SMS, email) and tracks verification attempts asynchronously."
        }
    ],
    "key_concepts": [
        "Async Authentication Middleware Patterns",
        "Non-blocking User Session Management", 
        "Async Rate Limiting and Security Checks",
        "Concurrent Middleware Chain Processing",
        "Async Two-Factor Authentication",
        "Security Event Logging Without Blocking",
        "Async Caching for Authentication Performance",
        "Middleware Performance Optimization"
    ]
}