"""
Django Database - Lesson 3: Database Transactions in Django
Master transaction management for data consistency and integrity
"""

DJANGO_TRANSACTIONS_LESSON = {
    "id": 46,
    "chapter": 46,
    "title": "Django Transactions: Ensuring Data Consistency",
    "slug": "django-transactions",
    "description": "Master Django transactions for maintaining data integrity in complex operations",
    "content": '''# Django Transactions: Ensuring Data Consistency

## 🎯 Understanding Database Transactions

A **database transaction** is a sequence of database operations that are treated as a **single unit of work**. Think of it as an "all-or-nothing" operation:

- **All operations succeed** ✅ → Transaction commits
- **Any operation fails** ❌ → Transaction rolls back (all changes undone)

This is crucial for maintaining **data consistency** in applications like:
- **Bank transfers** (debit one account, credit another)
- **E-commerce orders** (update inventory, create order, charge payment)
- **User registration** (create user, send email, log activity)

## 💰 Financial System Database

Let's work with a banking/financial system database to understand transactions:

```sql
-- Bank accounts table
CREATE TABLE bank_accounts (
    id SERIAL PRIMARY KEY,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    account_holder_name VARCHAR(100) NOT NULL,
    balance DECIMAL(15, 2) DEFAULT 0.00,
    account_type VARCHAR(20) DEFAULT 'checking',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transaction history table
CREATE TABLE account_transactions (
    id SERIAL PRIMARY KEY,
    account_id INTEGER NOT NULL,
    transaction_type VARCHAR(20) NOT NULL, -- 'debit', 'credit', 'transfer'
    amount DECIMAL(15, 2) NOT NULL,
    balance_after DECIMAL(15, 2) NOT NULL,
    description TEXT,
    reference_number VARCHAR(50) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    related_account_id INTEGER, -- For transfers
    FOREIGN KEY (account_id) REFERENCES bank_accounts(id)
);

-- Sample bank accounts
INSERT INTO bank_accounts (account_number, account_holder_name, balance, account_type) VALUES
('ACC-001-12345', 'Alice Johnson', 5000.00, 'checking'),
('ACC-002-67890', 'Bob Smith', 3500.00, 'savings'),
('ACC-003-11111', 'Carol Davis', 10000.00, 'checking'),
('ACC-004-22222', 'David Wilson', 750.00, 'savings'),
('ACC-005-33333', 'Eva Brown', 0.00, 'checking');

-- Sample transaction history
INSERT INTO account_transactions (account_id, transaction_type, amount, balance_after, description, reference_number) VALUES
(1, 'credit', 5000.00, 5000.00, 'Initial deposit', 'TXN-001'),
(2, 'credit', 3500.00, 3500.00, 'Initial deposit', 'TXN-002'),
(3, 'credit', 10000.00, 10000.00, 'Initial deposit', 'TXN-003'),
(4, 'credit', 750.00, 750.00, 'Initial deposit', 'TXN-004');

-- Orders table for e-commerce transactions
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    payment_status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inventory table for stock management
CREATE TABLE inventory_items (
    id SERIAL PRIMARY KEY,
    product_name VARCHAR(200) NOT NULL,
    sku VARCHAR(50) UNIQUE NOT NULL,
    quantity_available INTEGER NOT NULL DEFAULT 0,
    reserved_quantity INTEGER NOT NULL DEFAULT 0,
    price DECIMAL(10, 2) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample inventory
INSERT INTO inventory_items (product_name, sku, quantity_available, price) VALUES
('iPhone 15 Pro', 'IP15P-128GB', 50, 999.99),
('MacBook Air M2', 'MBA-M2-256GB', 25, 1199.99),
('AirPods Pro', 'APP-2ND-GEN', 100, 249.99),
('iPad Air', 'IPA-256GB-WIFI', 30, 599.99);
```

## 🔧 Django Transaction Methods

### 1. Atomic Decorator - The Clean Approach

**Scenario**: Bank transfer between accounts (must be atomic)

```python
from django.db import transaction
from decimal import Decimal

@transaction.atomic
def transfer_money(from_account_id, to_account_id, amount, description=""):
    """
    Transfer money between accounts atomically
    If any step fails, entire transaction rolls back
    """
    from_account = BankAccount.objects.select_for_update().get(id=from_account_id)
    to_account = BankAccount.objects.select_for_update().get(id=to_account_id)
    
    # Business logic validation
    if from_account.balance < amount:
        raise ValueError("Insufficient funds")
    
    if not from_account.is_active or not to_account.is_active:
        raise ValueError("One or both accounts are inactive")
    
    # Generate unique reference number
    import uuid
    ref_number = f"TXN-{uuid.uuid4().hex[:8].upper()}"
    
    # Perform the transfer (all operations in one transaction)
    from_account.balance -= amount
    to_account.balance += amount
    
    from_account.save()
    to_account.save()
    
    # Record transaction history
    AccountTransaction.objects.create(
        account_id=from_account_id,
        transaction_type='debit',
        amount=amount,
        balance_after=from_account.balance,
        description=f"Transfer to {to_account.account_number}: {description}",
        reference_number=f"{ref_number}-OUT",
        related_account_id=to_account_id
    )
    
    AccountTransaction.objects.create(
        account_id=to_account_id,
        transaction_type='credit',
        amount=amount,
        balance_after=to_account.balance,
        description=f"Transfer from {from_account.account_number}: {description}",
        reference_number=f"{ref_number}-IN",
        related_account_id=from_account_id
    )
    
    return ref_number

# Usage - either all succeeds or all fails
try:
    ref = transfer_money(1, 2, Decimal('500.00'), "Monthly rent payment")
    print(f"Transfer successful: {ref}")
except Exception as e:
    print(f"Transfer failed: {e}")
```

### 2. Context Manager - Fine-Grained Control

**Scenario**: E-commerce order processing with inventory management

```python
def process_order(customer_id, items):
    """
    Process e-commerce order with inventory updates
    Complex multi-step transaction with validation
    """
    try:
        with transaction.atomic():
            # Create the order
            order = Order.objects.create(
                customer_id=customer_id,
                total_amount=Decimal('0.00'),
                status='processing'
            )
            
            total_amount = Decimal('0.00')
            
            for item in items:
                product_sku = item['sku']
                quantity = item['quantity']
                
                # Lock inventory row for update
                inventory = InventoryItem.objects.select_for_update().get(sku=product_sku)
                
                # Check availability
                if inventory.quantity_available < quantity:
                    raise ValueError(f"Insufficient inventory for {product_sku}")
                
                # Reserve inventory
                inventory.quantity_available -= quantity
                inventory.reserved_quantity += quantity
                inventory.save()
                
                # Calculate line total
                line_total = inventory.price * quantity
                total_amount += line_total
                
                # Create order item record
                OrderItem.objects.create(
                    order=order,
                    product_sku=product_sku,
                    quantity=quantity,
                    unit_price=inventory.price,
                    line_total=line_total
                )
            
            # Update order total
            order.total_amount = total_amount
            order.status = 'confirmed'
            order.save()
            
            # Log successful order
            OrderLog.objects.create(
                order=order,
                event='order_confirmed',
                details=f"Order for ${total_amount} confirmed"
            )
            
            return order
            
    except Exception as e:
        # Transaction automatically rolls back on exception
        print(f"Order processing failed: {e}")
        raise

# Usage
try:
    order = process_order(customer_id=1, items=[
        {'sku': 'IP15P-128GB', 'quantity': 1},
        {'sku': 'APP-2ND-GEN', 'quantity': 2}
    ])
    print(f"Order {order.id} processed successfully")
except Exception as e:
    print(f"Order failed: {e}")
```

### 3. Savepoints - Nested Transaction Control

**Scenario**: Complex user registration with multiple services

```python
def register_user_with_services(email, password, profile_data):
    """
    Register user with multiple external services
    Use savepoints for partial rollback
    """
    with transaction.atomic():
        # Create core user account
        user = User.objects.create_user(email=email, password=password)
        
        try:
            # Savepoint before risky operations
            savepoint = transaction.savepoint()
            
            # Create user profile
            profile = UserProfile.objects.create(
                user=user,
                **profile_data
            )
            
            # Attempt to create external service accounts
            try:
                # Create email service account
                email_service_id = create_email_service_account(user.email)
                user.email_service_id = email_service_id
                
                # Create analytics tracking
                analytics_id = create_analytics_profile(user.id)
                user.analytics_id = analytics_id
                
                user.save()
                
                # Release savepoint - all services succeeded
                transaction.savepoint_commit(savepoint)
                
            except ExternalServiceError:
                # Rollback to savepoint - keep user but skip external services
                transaction.savepoint_rollback(savepoint)
                
                # Log the issue
                UserLog.objects.create(
                    user=user,
                    event='registration_partial',
                    details='External services unavailable'
                )
        
        except Exception:
            # Major error - rollback everything
            raise
        
        # Send welcome email (outside critical path)
        try:
            send_welcome_email(user.email)
        except Exception:
            # Email failure shouldn't break registration
            UserLog.objects.create(
                user=user,
                event='welcome_email_failed',
                details='Welcome email could not be sent'
            )
        
        return user
```

### 4. Manual Transaction Management

**Scenario**: Batch processing with commit control

```python
def batch_update_account_interest():
    """
    Apply interest to savings accounts in batches
    Commit periodically for long-running operations
    """
    savings_accounts = BankAccount.objects.filter(
        account_type='savings',
        is_active=True
    ).order_by('id')
    
    batch_size = 100
    processed = 0
    
    with transaction.atomic():
        for account in savings_accounts.iterator(chunk_size=batch_size):
            # Calculate monthly interest (0.5% APY)
            monthly_interest = account.balance * Decimal('0.005') / 12
            
            if monthly_interest > Decimal('0.01'):  # Minimum interest threshold
                # Update account balance
                account.balance += monthly_interest
                account.save()
                
                # Record interest transaction
                AccountTransaction.objects.create(
                    account_id=account.id,
                    transaction_type='credit',
                    amount=monthly_interest,
                    balance_after=account.balance,
                    description='Monthly interest payment',
                    reference_number=f"INT-{account.id}-{timezone.now().strftime('%Y%m')}"
                )
                
                processed += 1
                
                # Commit every batch to avoid long-running transactions
                if processed % batch_size == 0:
                    transaction.commit()
                    print(f"Processed {processed} accounts...")
    
    return processed
```

## 🏢 Real-World Production Examples

### Stripe's Payment Processing

```python
@transaction.atomic
def process_payment_with_retry(order_id, payment_method_id):
    """
    Process payment with automatic retry logic
    Ensures payment and order state consistency
    """
    order = Order.objects.select_for_update().get(id=order_id)
    
    if order.payment_status != 'pending':
        raise ValueError("Order already processed")
    
    # Create payment intent record
    payment_intent = PaymentIntent.objects.create(
        order=order,
        amount=order.total_amount,
        currency='USD',
        status='processing'
    )
    
    try:
        # Call external payment processor
        payment_result = stripe.PaymentIntent.create(
            amount=int(order.total_amount * 100),  # Stripe uses cents
            currency='usd',
            payment_method=payment_method_id,
            confirm=True,
        )
        
        if payment_result.status == 'succeeded':
            # Payment successful - update all related records
            order.payment_status = 'paid'
            order.status = 'processing'
            order.save()
            
            payment_intent.external_id = payment_result.id
            payment_intent.status = 'succeeded'
            payment_intent.save()
            
            # Create accounting record
            AccountingEntry.objects.create(
                type='revenue',
                amount=order.total_amount,
                order=order,
                payment_intent=payment_intent
            )
            
            return payment_result
        else:
            raise PaymentException(f"Payment failed: {payment_result.status}")
            
    except Exception as e:
        # Payment failed - mark as failed but don't lose order data
        payment_intent.status = 'failed'
        payment_intent.error_message = str(e)
        payment_intent.save()
        
        order.payment_status = 'failed'
        order.save()
        
        raise
```

### Airbnb's Booking System

```python
@transaction.atomic
def create_booking(listing_id, guest_id, check_in, check_out):
    """
    Create booking with availability validation and calendar blocking
    """
    # Lock listing for update
    listing = Listing.objects.select_for_update().get(id=listing_id)
    
    # Check availability (no overlapping bookings)
    overlapping = Booking.objects.filter(
        listing=listing,
        status__in=['confirmed', 'checked_in'],
        check_in__lt=check_out,
        check_out__gt=check_in
    ).exists()
    
    if overlapping:
        raise BookingException("Listing not available for selected dates")
    
    # Calculate pricing
    nights = (check_out - check_in).days
    base_price = listing.price_per_night * nights
    service_fee = base_price * Decimal('0.03')  # 3% service fee
    tax = base_price * Decimal('0.10')  # 10% tax
    total_price = base_price + service_fee + tax
    
    # Create booking
    booking = Booking.objects.create(
        listing=listing,
        guest_id=guest_id,
        check_in=check_in,
        check_out=check_out,
        base_price=base_price,
        service_fee=service_fee,
        tax_amount=tax,
        total_price=total_price,
        status='confirmed'
    )
    
    # Block calendar dates
    for i in range(nights):
        date = check_in + timedelta(days=i)
        CalendarBlock.objects.create(
            listing=listing,
            date=date,
            booking=booking,
            block_type='booking'
        )
    
    # Update listing stats
    listing.total_bookings += 1
    listing.save()
    
    return booking
```

### Discord's Message Moderation

```python
def moderate_message_with_actions(message_id, moderation_action):
    """
    Moderate message with related user actions
    Uses savepoints for complex moderation logic
    """
    with transaction.atomic():
        message = Message.objects.select_for_update().get(id=message_id)
        user = message.author
        
        # Apply moderation action
        if moderation_action == 'delete':
            message.is_deleted = True
            message.deleted_at = timezone.now()
            message.save()
            
        elif moderation_action == 'timeout':
            savepoint = transaction.savepoint()
            
            try:
                # Timeout user
                user.is_timed_out = True
                user.timeout_until = timezone.now() + timedelta(hours=24)
                user.save()
                
                # Delete message
                message.is_deleted = True
                message.deleted_at = timezone.now()
                message.save()
                
                # Log moderation action
                ModerationLog.objects.create(
                    user=user,
                    message=message,
                    action=moderation_action,
                    moderator_id=get_current_moderator(),
                    reason="Automated timeout for policy violation"
                )
                
                transaction.savepoint_commit(savepoint)
                
            except Exception:
                transaction.savepoint_rollback(savepoint)
                raise
        
        # Update user violation count (always happens)
        user.violation_count += 1
        if user.violation_count >= 3:
            user.is_banned = True
        user.save()
```

## ⚡ Transaction Performance Best Practices

### 1. Keep Transactions Short

```python
# GOOD: Short, focused transaction
@transaction.atomic
def update_inventory(product_id, quantity):
    product = Product.objects.select_for_update().get(id=product_id)
    product.stock -= quantity
    product.save()

# BAD: Long transaction with external calls
@transaction.atomic
def bad_order_processing(order_data):
    order = create_order(order_data)
    send_email(order.customer.email)  # External service call!
    process_payment(order)            # Another external call!
    update_inventory(order.items)     # Should be atomic, but not with emails
```

### 2. Use select_for_update for Concurrency

```python
@transaction.atomic
def safe_account_update(account_id, amount):
    # Lock row to prevent concurrent modifications
    account = BankAccount.objects.select_for_update().get(id=account_id)
    account.balance += amount
    account.save()
```

### 3. Handle Deadlocks

```python
from django.db import transaction
import time

def transfer_with_deadlock_handling(from_id, to_id, amount, max_retries=3):
    """Handle potential deadlocks in money transfers"""
    
    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                # Always lock accounts in same order to prevent deadlocks
                account_ids = sorted([from_id, to_id])
                accounts = BankAccount.objects.select_for_update().filter(
                    id__in=account_ids
                ).order_by('id')
                
                from_account = next(a for a in accounts if a.id == from_id)
                to_account = next(a for a in accounts if a.id == to_id)
                
                if from_account.balance < amount:
                    raise InsufficientFundsError()
                
                from_account.balance -= amount
                to_account.balance += amount
                
                from_account.save()
                to_account.save()
                
                return True
                
        except transaction.TransactionManagementError:
            if attempt == max_retries - 1:
                raise
            time.sleep(0.1 * (attempt + 1))  # Exponential backoff
    
    return False
```

## 🎯 Key Takeaways

1. **Transactions ensure data consistency** in multi-step operations
2. **@transaction.atomic** is the cleanest way to handle transactions
3. **Savepoints allow partial rollbacks** in complex operations
4. **select_for_update** prevents race conditions in concurrent access
5. **Keep transactions short** to avoid performance issues
6. **Handle external service failures** gracefully with proper rollback

Transactions are essential for building reliable, consistent applications that handle money, inventory, user data, and other critical operations!
''',
    "difficulty": "intermediate", 
    "estimated_time": 45,
    "xp_reward": 25,
    "prerequisites": ["django-models-foundations", "django-queryset-fundamentals", "django-raw-sql"],
    "exercises": [
        {
            "id": "transactions_1",
            "title": "Explore Bank Accounts Table",
            "prompt": "Let's examine our bank accounts table to understand the data we'll be working with in transactions. Write a query to see all accounts and their balances.",
            "table_name": "bank_accounts",
            "initial_query": "SELECT * FROM bank_accounts;",
            "expected_keywords": ["SELECT", "*", "FROM", "bank_accounts"],
            "hint": "Use SELECT * FROM bank_accounts; to see all account information",
            "solution": "SELECT * FROM bank_accounts;",
            "explanation": "This shows our bank accounts with account numbers, holder names, and current balances. In Django transactions, we'd lock these records with select_for_update() to prevent concurrent modifications during transfers."
        },
        {
            "id": "transactions_2", 
            "title": "Verify Account Balances for Transfer",
            "prompt": "Before performing a money transfer, we need to check account balances. Write a query to find accounts that have sufficient balance for a $1000 transfer.",
            "table_name": "bank_accounts",
            "expected_keywords": ["SELECT", "WHERE", "balance", "1000"],
            "hint": "Filter accounts where balance >= 1000",
            "solution": "SELECT account_number, account_holder_name, balance FROM bank_accounts WHERE balance >= 1000.00 AND is_active = true;",
            "explanation": "This identifies accounts that could safely transfer $1000. In a Django transaction, we'd validate this condition inside the @transaction.atomic block before updating balances."
        },
        {
            "id": "transactions_3",
            "title": "Analyze Transaction History",
            "prompt": "Look at the transaction history to understand how account balances change. Write a query to see all transactions with their effects on account balances.",
            "table_name": "account_transactions", 
            "expected_keywords": ["SELECT", "transaction_type", "amount", "balance_after"],
            "hint": "Select relevant fields like transaction_type, amount, and balance_after",
            "solution": "SELECT account_id, transaction_type, amount, balance_after, description, created_at FROM account_transactions ORDER BY created_at DESC;",
            "explanation": "Transaction history shows how each operation affects account balances. In Django, every database operation within a transaction would either all commit together or all rollback if any step fails."
        },
        {
            "id": "transactions_4",
            "title": "Simulate Transfer Validation Logic",
            "prompt": "Write a query to simulate checking if a transfer is possible. Find if account 1 can transfer $500 to account 2 by checking both accounts exist and source has sufficient funds.",
            "table_name": "bank_accounts",
            "expected_keywords": ["SELECT", "WHERE", "id", "balance"],
            "hint": "Check that both accounts exist and account 1 has balance >= 500",
            "solution": "SELECT (SELECT balance >= 500.00 FROM bank_accounts WHERE id = 1 AND is_active = true) AS can_transfer, (SELECT COUNT(*) FROM bank_accounts WHERE id IN (1, 2) AND is_active = true) AS accounts_exist;",
            "explanation": "This validation logic would be part of our Django transaction. The @transaction.atomic decorator ensures that if validation fails, no changes are made to either account."
        },
        {
            "id": "transactions_5",
            "title": "Check Inventory for Order Processing",
            "prompt": "For our e-commerce transaction example, check inventory availability. Write a query to see which products have sufficient stock for an order (quantity > 10).",
            "table_name": "inventory_items",
            "expected_keywords": ["SELECT", "WHERE", "quantity_available", "10"],
            "hint": "Filter where quantity_available > 10",
            "solution": "SELECT product_name, sku, quantity_available, price FROM inventory_items WHERE quantity_available > 10 ORDER BY quantity_available DESC;",
            "explanation": "Inventory checks are critical in e-commerce transactions. Django's transaction.atomic ensures that inventory deduction and order creation either both succeed or both fail, preventing overselling."
        },
        {
            "id": "transactions_6",
            "title": "Calculate Order Totals for Transaction",
            "prompt": "Calculate the total value of an order using multiple inventory items. Write a query to find the total cost if someone ordered 2 iPhones and 1 MacBook.",
            "table_name": "inventory_items",
            "expected_keywords": ["SELECT", "SUM", "price", "*"],
            "hint": "Use price * quantity and SUM for specific products",
            "solution": "SELECT SUM(price * quantity) as total_cost FROM (SELECT price, 2 as quantity FROM inventory_items WHERE sku = 'IP15P-128GB' UNION SELECT price, 1 as quantity FROM inventory_items WHERE sku = 'MBA-M2-256GB') as order_items;",
            "explanation": "Order total calculations must be atomic with inventory updates. If payment fails, both the inventory reservation and order record creation would rollback together in a Django transaction."
        }
    ],
    "key_concepts": [
        "ACID Transaction Properties",
        "@transaction.atomic Decorator Usage",
        "Transaction Context Managers",
        "Savepoint Management",
        "select_for_update for Concurrency",
        "Deadlock Prevention Strategies",
        "External Service Integration",
        "Performance Optimization in Transactions"
    ]
}